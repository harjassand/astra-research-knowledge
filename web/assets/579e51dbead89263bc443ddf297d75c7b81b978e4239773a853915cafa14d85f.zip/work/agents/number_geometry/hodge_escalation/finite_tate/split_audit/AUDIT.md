# Audit: specialization of a Kuga--Satake retraction

Date: 7 October 2026. Status: conditional implication audited; the two released foundational claims were assumed, not audited here.

## Verdict

No nonroutine additional gap was found in the proposed implication from (H) rational Hodge for all complex CM abelian varieties and (KS) algebraicity of the prescribed transcendental Kuga--Satake injection for all complex projective K3 surfaces, to rational Tate for arbitrary finite products of K3 surfaces over finite fields and their Hilbert schemes of points. The route proves a splitting in homological/cohomological realizations, not a Chow splitting. Crystalline Tate and strong Tate need an explicit semisimplicity/full-Tate argument; a bare l-adic cycle-class surjectivity statement is not enough on its own.

Two routine details must be written accurately:

1. The specific complex cycle need not literally descend to a number field. Its Betti class has a representative over Qbar by a Hilbert-scheme specialization argument; that representative descends to some number field.
2. The generic transcendental projector generally does not specialize to the special fiber's transcendental projector. It need not do so: the generic projectors already sum to the whole diagonal on cohomology and this identity specializes.

## Explicit splitting

Let S/C be projective K3, let T = NS(S)_Q^perp in H^2(S,Q), and let B = A_S x A_S have dimension d. Choose a degree-one rational zero-cycle o. Then pi_0 = o x S, pi_4 = S x o, and pi_2 = Delta_S - pi_0 - pi_4 are algebraic Chow--Kunneth projectors. If D_1,...,D_r is a rational divisor basis for NS and M_ij = D_i.D_j, then

    pi_NS = sum_ij (M^-1)_ij D_i x D_j,
    pi_T = pi_2 - pi_NS.

The nondegeneracy of M is the Hodge index theorem. These projectors can be defined after a finite extension of any number field of definition. In particular a rational point is unnecessary: normalize any closed point by its degree.

Let Gamma in CH^2(S x B)_Q realize the specified KS injection on T. Put f = Gamma o pi_T. Choose an ample divisor L on B. The image f(T) lies in primitive H^2(B), since T has no rational Tate quotient and the quotient H^2(B)/P^2(B) is Q(-1). This also follows directly for the prescribed H^1(A) tensor H^1(A) target with the product polarization.

On T and P^2(B), use the polarizations

    b_S(x,y) = - integral_S x.y,
    b_B(u,v) = - integral_B u.v.L^(d-2).

The correspondence

    a = pi_T o transpose(Gamma) o (cup L^(d-2)) : H^2(B) -> T

is the polarization adjoint of f on its image. It is represented by a codimension-d cycle on B x S; transpose(Gamma) alone would have the wrong cohomological degree when d != 2. The Hodge Hermitian metrics are positive definite, so e = a f is invertible on T: the kernel of f-adjoint f is the kernel of f. This argument does not assume that f is an isometry or that e is scalar.

If chi_e(t)=t^n+c_(n-1)t^(n-1)+...+c_1 t+c_0, then c_0 != 0 and

    e^-1 = -(1/c_0)(e^(n-1)+c_(n-1)e^(n-2)+...+c_1 id_T).

Interpret id_T as pi_T and e as the algebraic correspondence a f. Therefore the same rational polynomial is an algebraic correspondence. With r=e^-1 a, we have r f = pi_T on ALL cohomology (pi_T kills all degrees except the T part of degree two). Adding the NS, H^0 and H^4 Tate summands gives a cohomological retraction of h(S) into h(B) plus Tate motives. It is not legitimate to upgrade this to r f = pi_T modulo rational equivalence without nilpotence or another extra input.

## Arithmetic and specialization

The final published IIK Theorem 1.1 defines a CM lifting globally: a K3 scheme over the localization O_(F,v) of a number field, with the given finite-field surface as special fiber. After a finite field extension every finite-height K3 has such a lifting, including characteristics 2 and 3. Thus no local-to-global algebraization premise is missing.

For the generic CM K3, the KS Hodge structure has commutative Mumford--Tate group (a torus extension of the weight-two torus by the central G_m); its abelian variety is CM and has a model over a number field. Serre--Tate Theorem 6 ensures potentially good reduction at the chosen place. Choose a finite number field extension containing the definitions of S, B, o, the divisors, ample class, and cycle representatives, and over which B has good reduction. The smooth proper K3 model is retained under this base change.

Cycle-class descent: for a fixed smooth projective Y/Qbar, each component of a complex algebraic cycle is a C-point of a Hilbert scheme over Qbar. Choose a connected component containing that point and a Qbar point in the same component. The fibers of the universal flat family have identical Betti cycle class on the constant ambient Y_C (algebraic equivalence suffices). The resulting representative is over Qbar, hence over a finite number field. Apply this to the cycle on the already descended ambient S x B. The Betti retraction identity consequently holds in generic l-adic cohomology by comparison.

Close the cycles in the smooth proper products over the valuation ring and specialize them. Compatibility of cycle classes and correspondences with smooth proper base change yields r_0 f_0 = pi_(T,0) and pi_(0,0)+pi_(4,0)+pi_(NS,0)+pi_(T,0)=Delta_(S_0) on l-adic cohomology. The possibility that rho(S_0)>rho(S_generic) does not affect either identity.

For several K3 surfaces no common characteristic-zero CM lift is needed. Construct their retractions separately, then enlarge the finite residue field to one common extension. Tensor retractions produce an algebraic cohomological retraction of every product into a finite direct sum of Tate-twisted products of finite-field abelian varieties. Every such product is again abelian. Milne's Hodge-CM => abelian-Tate implication supplies every codimension of Tate for these targets. Applying the algebraic retraction to cycle representatives gives Tate classes on the K3 product. Finally normalized finite-field trace/pushforward descends cycles to the originally requested field.

## Supersingular factors and Hilbert schemes

IIK Lemma 10.6 establishes rho=22 for supersingular K3, including p=2 (using the corrected characteristic-two Tate theorem). Its geometric H^2 is therefore spanned by divisors after finite extension. All its cohomology is Tate. The Kunneth argument in IIK Lemma 10.7 and Remark 10.8 covers all powers, and the same argument works for arbitrary products/mixed finite-height and supersingular factors. No supersingular CM lifting is being asserted or needed.

de Cataldo--Migliorini Theorem 6.2.1 gives h(S^[n]) as a direct sum of Tate twists of motives of products of symmetric powers of S; Remark 6.2.2 explicitly extends the theorem to any field. A symmetric-power term is the rational symmetrizing direct summand of the relevant S^m. The incidence and symmetrization correspondences transfer Tate to Hilbert schemes and arbitrary finite products thereof. Division by group orders is valid over Q even if the characteristic divides them. This is independent of whether the KS splitting is a Chow splitting.

## Crystalline and strong Tate

The narrow independent auditor verified Milne, The Tate conjecture over finite fields, Theorem 1.4 and Theorem 1.11: full Tate/strong Tate includes pole-order equality, equality of numerical and homological equivalence, and the equivalent realization statements, including p-adic crystalline. Precisely, Theorem 1.4(b) requires T^r + S^r + T^(d-r), not just T^r + S^r; the all-codimension transfer supplies complementary Tate. The needed Frobenius semisimplicity is available: H^*(B) for finite-field abelian B is exterior algebra on semisimple H^1; algebraic retractions preserve semisimplicity. Tensor products and summands preserve it. If a retraction is only over F_(q^m), semisimplicity of Frob_q^m implies semisimplicity of Frob_q in characteristic zero because all eigenvalues are nonzero. Supersingular Tate summands and dCM symmetrizing summands also retain semisimplicity.

IIK Lemma 10.4 illustrates the l-adic-to-crystalline argument through the numerical-cycle rank, the realization-independent Frobenius characteristic polynomial and Hilbert 90 for the semilinear absolute Frobenius. Remark 10.5 (NOT Lemma 10.5) separately records crystalline semisimplicity. One can use this strong-Tate route rather than claiming that a Betti/l-adic homologically zero specialized correspondence is automatically crystalline homologically zero without explanation.

## Failure ledger and scope

- No fatal splitting/descent gap found after the stated repairs.
- Raw transpose Gamma does not give degree-preserving retraction; Lefschetz L^(d-2) is essential.
- The positive-metric argument is needed if e is not scalar.
- Literal descent of an arbitrary cycle is false; descent of the cohomology class is sufficient and routine.
- Generic NS = special NS is unnecessary and should not be assumed.
- A cohomological splitting does not establish a Chow splitting or finite dimensionality of the Chow motive.
- IIK finite-height lifting alone does not cover supersingular surfaces; rank-22 divisor spanning supplies them.
- Rational l-adic Tate surjectivity alone should not be labeled strong/crystalline Tate; include semisimplicity and the standard equivalence.
- This audit does not validate the release's Hodge-CM theorem or universal KS-algebraicity theorem, establish novelty, or establish an unconditional theorem if either premise fails.

## Primary sources

- IIK published article, Theorem 1.1; definition of CM lifting immediately before it; Lemmas 10.4, 10.6, 10.7, Remark 10.5, Remark 10.8: https://doi.org/10.1017/fms.2021.24 ; PDF https://www.cambridge.org/core/services/aop-cambridge-core/content/view/9E14D5849CED8ABFC81CC49818267366/S2050509421000244a.pdf/cm-liftings-of-dollark3dollar-surfaces-over-finite-fields-and-their-applications-to-the-tate-conjecture.pdf . The published theorem points to Corollary 9.10; arXiv v2 pointed to Corollary 9.9.
- Serre--Tate, Good reduction of abelian varieties, Annals 88 (1968), Theorem 6: https://doi.org/10.2307/1970722 ; https://wstein.org/papers/bib/Serre-Tate-Good_Reduction_of_Abelian_Varieties.pdf . Scan text extraction did not expose the theorem itself; theorem number independently matches current author lecture notes and parent supplied citation.
- Milne, Lefschetz motives and the Tate conjecture (1999), Theorem 7.1, with correction on sufficiently large auxiliary CM fields: https://www.jmilne.org/math/articles/1999b.html . The correction adds a real subfield of degree >2 inert at p. Parent pinned cm-consequences.tex expressly includes this correction.
- Milne, The Tate conjecture over finite fields, Theorems 1.4, 1.11: https://www.jmilne.org/math/articles/2007e.pdf . Independent auditor's exact statements/source excerpts are in crystalline_audit/.
- de Cataldo--Migliorini, The Chow groups and the motive of the Hilbert scheme of points on a surface, Journal of Algebra 251 (2002), Theorem 6.2.1 and Remark 6.2.2 (printed p846): https://www.math.stonybrook.edu/~mde/MyPublishedPapers/MotiveHilbSchJournOfAlg.pdf .
- Primary published discussion of KS splitting in homological motives, Section 5.2 (Conjecture 5.4 discussion): https://www.cambridge.org/core/journals/compositio-mathematica/article/sixfolds-of-generalized-kummer-type-and-k3-surfaces/F6E8A0F77300183F77DADC8F699B2BAE .

## Strongest next check

At the implication level the decisive remaining dependency is foundational: independent audit of the two release theorems. Do not broaden this positive transfer audit into validation of their proofs. For drafting, spell out the degree-corrected adjoint, same-class descent, and semisimplicity-to-strong/crystalline step; these remove the actual ambiguity points.
