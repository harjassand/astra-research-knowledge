# Decisive source locations

## Tate equivalence: all three hypotheses, not two

Milne, AIM talk version 2.2, printed p.3, Theorem 1.4(b):

    T^r(X,ell) + S^r(X,ell) + T^{d-r}(X,ell).

This is equivalent to Theorem 1.4(a), namely T^r plus E^r, and to the numerical-rank pole formula 1.4(d). The all-codimension transfer supplies the complementary Tate hypothesis. T^r plus S^r alone is not the cited general implication.

Printed p.6, Theorem 1.11: the same equivalence permits ell=p. The p-adic definitions and the Q_p-to-W(F_q)[1/p] fixed-space descent equation appear on printed p.5. Printed p.3, Theorem 1.5: middle-degree partial semisimplicity for X x X yields full Frobenius semisimplicity of X.

Source: https://www.jmilne.org/math/articles/2007e.pdf . Web parse had 1919 lines; relevant ranges were 180–229 and 344–412. These are retrieval locations, not independent mathematical evidence.

## Explicit crystalline linear algebra

Milne, *Rational Tate classes*, §§1.3–1.5, printed pp.3–4: pi=phi^a over F_{p^a}; isocrystal semisimplicity iff pi is semisimple; H^{phi=1} is a Q_p-form of H^{pi=1}. Theorem 1.7, printed pp.5–6, transfers the spanning/nondegenerate-pairing condition to all primes, including p; Remark 1.8(b), p.6, identifies this as the p-extension of Tate 1994 Theorem 2.9.

Source: https://www.jmilne.org/math/articles/2009b.pdf . Web parse locations 169–227 and 315–359.

IIK published 2021: Theorem 1.1 refers to **Corollary 9.10**, printed p.52; Corollary 9.9 instead concerns the group I. Lemma 10.4 and Remark 10.5 are printed p.54. The former is the square case of the numerical-rank/characteristic-polynomial/Hilbert-90 argument in AUDIT.md; the latter supplies full crystalline semisimplicity for K3. The correct numbering is **Remark** 10.5, not Lemma 10.5. The arXiv 77-page draft uses different page numbers and Corollary numbering; use printed pp.54–55 of the 70-page published version.

Source: https://doi.org/10.1017/fms.2021.24 . Exact published PDF URL is in AUDIT.md and the supersingular-primary note.

Katz–Messing Theorem 1, printed p.74, equates each cohomological Frobenius polynomial with its ell-adic counterpart; the preceding paragraph lists crystalline among the applicable theories. Author PDF: https://web.math.princeton.edu/~nmk/old/katzmessing.pdf . Local source and image of the theorem page: katzmessing.pdf and katz-page-2-img2.png in this directory. The full-volume GDZ link exceeded the web fetch limit; the author copy is complete and small.

## Supersingular and Hilbert sources

IIK published Lemma 10.6, printed pp.54–55; Lemma 10.7 / Remark 10.8, p.55. The characteristic-2 attribution requires the 2020 erratum to Kim–Madapusi Pera; the published IIK citation incorporates it.

de Cataldo–Migliorini Theorem 6.2.1 / Remark 6.2.2, printed p.846: the Hilbert-scheme decomposition holds over any field, every n. Author-hosted published PDF: https://www.math.stonybrook.edu/~mde/MyPublishedPapers/MotiveHilbSchJournOfAlg.pdf . Rational quotient projector is (1/|G|) sum_{g in G} Gamma_g, including p dividing |G|. This applies to actual S^[n], not arbitrary varieties merely deformation equivalent to one in characteristic zero.

Independent narrow verification is recorded in supersingular_primary/AUDIT.md and supersingular_primary/hilbert_caveat/AUDIT.md.
