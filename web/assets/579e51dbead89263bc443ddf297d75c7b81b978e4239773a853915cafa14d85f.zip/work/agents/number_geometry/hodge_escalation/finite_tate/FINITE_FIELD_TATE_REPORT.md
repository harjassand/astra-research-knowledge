# Conditional finite-field consequences of family 032

Status: proof-level conditional composition, not an independent proof of either released frontier theorem. The released Kuga–Satake proof and CM Hodge proof have not been fully audited here. No priority claim is made for the composition.

## Precise assumptions and conclusion

Assume (CM-HC): the rational Hodge conjecture for every complex CM abelian variety, all dimensions and codimensions. Assume (KS-ALG): for every projective complex K3 surface S, an algebraic rational cycle realizes the standard embedding T(S) -> H²(KS(T(S)) × KS(T(S))). These are the two family-032 premises used below; the separate theorem about arbitrary complex K3 products is not needed.

**Conditional theorem.** Let k=F_q have arbitrary positive characteristic, and let

    Y = A × C_1 × ... × C_u × S_1^[n_1] × ... × S_v^[n_v]

where A is an arbitrary abelian variety, the C_i are smooth projective geometrically connected curves, the S_i are arbitrary smooth projective K3 surfaces over k, and n_i≥1. Distinct/repeated K3 factors, supersingular factors and mixed heights are permitted. For every codimension r and every ℓ≠char(k),

    CH^r(Y) ⊗ Q_ℓ -> H_et^{2r}(Y_bar,Q_ℓ(r))^{Gal(k_bar/k)}

is onto. Frobenius is semisimple. Numerical and ℓ-adic homological equivalence agree on rational cycles, including after every finite extension. The strong Tate equality identifies the rank of numerical codimension-r cycles over k with the order of the zeta-function pole at s=r. The corresponding crystalline Tate surjectivity also follows; see the dimension argument below.

The same assertions hold for direct summands, Tate twists, sums and tensor products admitted by **algebraic cohomological correspondences** from these motives. This covers projective bundles and blowups whose centers and ambient motives are already in the class. It does not cover arbitrary varieties merely because their Frobenius eigenvalues resemble those of abelian varieties.

## Decisive sources

Pinned OpenAI commit: adc7f1241b42e322a6451854ab7e4b4c146bf78a. Preprints subtree: 272ca94583c1dca3188bbc3a1caa068cb7af4b55.

1. [Released algebraic KS manuscript](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Algebraicity-of-Kuga-Satake-Correspondences-for-K3-Surfaces-October-3-2026/build/manuscript.tex), theorem `thm:main`, source lines 109–121 in local `sources/ks.tex`. It specifies CH²(S×A_S×A_S), the full even-Clifford target, and transported isogenous models. Lines 79–105 specify T(S), twists and cycle action.
2. [Released CM Hodge consequences](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-rational-Hodge-conjecture-for-CM-abelian-varieties-September-30-2026/build/sections/07-consequences.tex), corollary `cc:tate`, local source lines 213–251. [Its premise](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-rational-Hodge-conjecture-for-CM-abelian-varieties-September-30-2026/build/sections/01-introduction.tex) is theorem `thm:cm`, lines 17–29. The consequence uses corrected Milne 1999 Theorem 7.1.
3. [Ito–Ito–Koshikawa, CM liftings of K3 surfaces](https://arxiv.org/html/1809.09604), Theorem 1.1/Corollary 9.9: a finite-height K3 has a CM lifting after finite extension, in every characteristic. The definition in §1.1 is a smooth K3 over a localization of a numberfield at a finite place, not merely a formal local lift. Lemma 10.6 supplies supersingular iff geometric Picard number 22 in every characteristic, including 2. Theorem 9.7 additionally constructs compatible integral Kuga–Satake lifts, but the simpler proof below does not need that extra compatibility.
4. [Serre–Tate, Good reduction of abelian varieties](https://annals.math.princeton.edu/1968/88-3/p05), Annals 88 (1968), 492–517, §5/Theorem 6: CM abelian varieties have potentially good reduction everywhere. Local copy downloaded from [primary-paper scan](https://wstein.org/papers/bib/Serre-Tate-Good_Reduction_of_Abelian_Varieties.pdf).
5. [de Cataldo–Migliorini, Chow groups and motive of Hilbert schemes](https://arxiv.org/html/math/0005249), Theorem 6.2.1 and Remark 6.2.2: rational Chow-motive decomposition into twisted symmetric-power summands, valid over any field. The universal incidence correspondences are defined over the base field.
6. [Milne, Lefschetz motives and Tate](https://www.jmilne.org/math/articles/1999bP.pdf), Theorem 7.1 and formulation (0.1); [author's corrections](https://www.jmilne.org/math/articles/1999b.html). Introduction Remark (a), pp. 2–3, explicitly rejects the claim that each Tate class lifts to a Hodge class on a single CM lifting.
7. [Milne, The Tate conjecture over finite fields](https://www.jmilne.org/math/articles/2007e.pdf), Theorem 1.4(b) and Theorem 1.11 give the standard strong/crystalline equivalences. Theorem 1.4(b) requires Tate in BOTH complementary codimensions together with semisimplicity. The argument here supplies all three hypotheses. IIK Lemma 10.4 and Remark 10.5 give an explicit prototype of the numerical-rank and semilinear-descent argument.

Prior-art boundary: ordinary self-powers were already proved by Zarhin, J. Algebraic Geometry 5 (1996), 151–172, Corollary 6.1.2, as recorded in IIK Remark 1.6(4). Supersingular self-powers are already formal from rank 22 (IIK Remark 10.8), and all K3 squares were proved by IIK Theorem 1.5. [Yu–Yui](https://homepage.ntu.edu.tw/~jdyu/Math/4.pdf), Corollary 3.4, proves Tate for the product of two finite-height K3 surfaces with different heights; this is another old mixed-height subcase. Thus these subcases are not new consequences. The all-factors/all-powers theorem removes higher-tensor and arbitrary-product restrictions by the stronger release premises.

## Proof: finite-height K3 cohomology retracts through an abelian variety

Fix a finite-height S/k. By IIK, after a finite extension there is a smooth projective CM K3 lift S_R over the localization R of a numberfield at a place above p. Write its characteristic-zero fiber S_0. We may enlarge the numberfield and residue field throughout; descent back to k is dealt with at the end.

The normalized weight-zero K3 Mumford–Tate group of T(S_0)(1) is a torus. In the KS spin construction, its inverse image in GSpin lies in a torus: GSpin -> SO has central kernel G_m, and inverse images of orthogonal tori are tori. Consequently the weight-one KS Hodge structure has commutative Mumford–Tate group, so A=KS(T(S_0)) is CM. Such A is defined over a numberfield after extension and acquires good reduction at the chosen place by Serre–Tate. Thus B=A×A has a smooth abelian model over an enlarged R. No identification of this B_special with the intrinsic positive-characteristic KS variety is required.

Let π_T∈CH²(S_0×S_0)_Q be the usual transcendental projector. Construct it using a degree-one rational zero-cycle, the Künneth projector π_2, a rational basis D_i of NS(S_0), and the inverse of the nonsingular divisor intersection matrix. The source and target of π_T are the same surface. The complement of π_T in π_2 is the divisor motive and is algebraically split into Tate objects.

By KS-ALG, an algebraic correspondence Γ realizes an injective Hodge map

    f:T(S_0) -> H²(B,Q).

Replace Γ by Γ∘π_T. Choose a rational ample class h_B on B, b=dim B. The image f(T) is primitive: pairing with h_B^{b−1} would give a Hodge morphism T -> Q(-1), which vanishes because T has no nonzero rational Hodge class of type (1,1). Therefore the restriction to f(T) of the primitive cup-product polarization on B is nondegenerate.

Define the correspondence-induced rational endomorphism of T

    c = π_T ∘ transpose(Γ) ∘ L_B^{b−2} ∘ Γ ∘ π_T.

Here Γ has codimension 2 on S_0×B. Its transpose acts from H^{2b−2}(B) to H²(S_0), so the displayed degree accounting is exact. On T, c is the adjoint composite f†f for the source and target polarizations and is invertible. Let P∈Q[t] be a polynomial agreeing with c^{-1} on T, supplied by Cayley–Hamilton since c's characteristic polynomial has nonzero constant term. Then

    ρ = P(c) ∘ π_T ∘ transpose(Γ) ∘ L_B^{b−2}

is induced by rational algebraic correspondences and satisfies ρf=id_T in Betti cohomology. The identity here is cohomological. It need not be equality modulo rational equivalence.

For descent of Γ: a cycle supplied over C can be replaced by one with the same Betti class defined over Qbar. Each cycle component lies on a Hilbert-scheme component for the fixed Qbar variety S_0×B; choose a Qbar closed point in that component, using constancy of the cohomology class in a connected flat family. The finitely many resulting cycle components, divisor classes and correspondences then descend to a finite numberfield extension. This replacement is necessary; the initially supplied complex cycle need not literally descend.

Specialize these cycles and the divisor/point projectors over the good models. Smooth proper base change and compatibility of cycle specialization preserve ρf=π_T. The specialized π_T is the orthogonal complement of the **specializations of generic NS classes**. It need not be the actual transcendental projector of S_special: any new special-fiber divisors may lie inside its image. This causes no problem because the complementary generic divisor projector and π_T still sum to π_2.

Hence the entire H²(S_special), and therefore its entire cohomology, is an algebraic cohomological retract of abelian cohomology together with Tate pieces. The construction is rational and preserves all prime-to-p realizations. Crystalline compatibility can be established as well from good-reduction comparison, but is unnecessary for the final crystalline dimension proof below.

## Supersingular and mixed factors

For supersingular S, IIK Lemma 10.6 gives ρ(S_bar)=22. After finite extension, divisor classes span H²(S_bar,Q_ℓ(1)). Together with a rational degree-one zero-cycle, these classes algebraically identify H⁰, H², H⁴ with Tate objects at the cohomological level. Odd cohomology vanishes. No CM lift of a supersingular K3 is asserted or needed.

For a finite collection of finite-height and supersingular factors, choose a common finite residue-field extension containing every field of definition used. Their individual numberfield lifts need not be the same lift or even the same global field. Take tensor products of their already-specialized algebraic injections and retractions. Künneth places the tensor products of their abelian target cohomologies inside the appropriate cohomology of a product of abelian varieties. Each invariant tensor is therefore the image of a Tate class on an abelian variety. CM-HC and corrected Milne imply that class is algebraic. Applying the algebraic retraction yields the required cycle class on the K3 product.

This proves full Tate surjectivity on arbitrary K3 products. A curve motive is a sum of Tate pieces and h¹ of its Jacobian via algebraic correspondences; adding arbitrary curves and abelian factors is the same tensor argument.

Finally, if α is invariant over k and represented by z over k_m, the norm cycle m^{-1}π_*z has class α because

    cl(m^{-1}π_*z) = m^{-1} Σ_{σ∈Gal(k_m/k)} σ(α) = α.

All coefficients are rational/ℓ-adic, so m divisible by p or ℓ is harmless. This is surjectivity from CH⊗Q_ℓ. An arbitrary Q_ℓ-valued α is not claimed to be represented by one rational-coefficient cycle.

## Hilbert schemes, semisimplicity, strong and crystalline Tate

For any n≥1, de Cataldo–Migliorini give

    h(S^[n]) ≅ ⊕_{ν partition n} h(S^(ν))(n−length(ν)).

Here the symmetric-power motive is the invariant summand of h(S^{length(ν)}) under the finite product of permutation groups appropriate to ν. The rational averaging projector and incidence correspondences transfer the previous result to every Hilbert scheme and every mixed product of Hilbert schemes, curves and abelian varieties. There is no restriction p>n: rational denominators remain invertible in the cohomological coefficient field.

Frobenius is semisimple on each K3 H²: for finite-height factors this follows from the abelian retraction (also from the existing KS ℓ-adic embedding); supersingular factors are Tate after extension. Abelian Frobenius is semisimple; tensor products, sums and invariant direct summands remain semisimple in characteristic zero. If F^m is semisimple then F is semisimple. Thus the full class above has semisimple Frobenius over the original field.

Tate in complementary codimensions plus semisimplicity implies numerical=ℓ-adic homological equivalence. A nonzero invariant class has a nonzero pairing with an invariant class in the complementary degree by semisimplicity and Poincaré duality. Complementary Tate makes the latter algebraic. A numerically trivial cycle cannot have such a pairing. Passing to a field defining a cycle proves the geometric equality as well.

Let a_r be the multiplicity of q^r as Frobenius eigenvalue on H^{2r}. The preceding statements give dim_Q A_num^r(Y)=a_r. The eigenvalue multiplicities agree in prime-to-p and crystalline cohomology by the smooth proper trace formulas/Weil weight separation. Crystalline Frob_q is semisimple on K3 surfaces by the existing KS realization and supersingular divisor spanning (IIK Remark 10.5, including its characteristic-two reference); it is semisimple on abelian varieties and curves. Tensor products and the actual dCM correspondences then prove crystalline semisimplicity throughout this class. A rational basis z_1,...,z_{a_r} of numerical cycles has an invertible intersection pairing matrix with complementary rational cycles. Therefore its crystalline classes are Q_p-linearly independent. The crystalline Tate space has Q_p-dimension a_r, so these classes span it. In the usual W(F_q)[1/p] notation this space is the φ=p^r fixed space for absolute semilinear crystalline Frobenius (equivalently the q-Frobenius eigen-q^r space with Hilbert-90 descent). This proves crystalline Tate without an extra CM-crystalline transfer hypothesis.

For the same reason, the zeta pole order at s=r equals a_r, giving the strong Tate equality. The rational numerical cycle quotient is the common algebraic realization space; this does not identify arbitrary unrelated ℓ-adic vectors with one common rational cycle.

## Failure ledger and true remaining obstacle

* Direct Hodge-to-Tate specialization of an arbitrary tensor on a fixed lift is invalid. Tate tensors need not become Hodge on that lift. Milne's Introduction Remark (a) gives a stronger counterexample even among abelian varieties. The above proof uses finite-field abelian Tate **after** specializing the KS split.
* A cohomological splitting does not prove a Chow-motive splitting. The identity ρf−π_T is only homologically trivial. To invert at the Chow level one needs nilpotence for such K3 self-correspondences, or another direct Chow construction. Full Tate does not supply that nilpotence.
* It is invalid to substitute the special transcendental projector for specialization of the generic one when the Picard number jumps. The whole-cohomology argument explicitly retains the generic divisor complement.
* Rational Tate gives algebraic spans with coefficient extension; integral Tate or torsion cycle assertions are not proved.
* General hyperkähler varieties over finite fields do not follow merely from their H² being K3-like. Their entire motive must admit the required algebraic retraction. Hilbert schemes have precisely this via dCM; arbitrary deformations do not inherit it for free.

Strongest new attack beyond this consequence: obtain a Chow-level KS left inverse for arbitrary finite-height K3 (equivalently remove the homologically trivial error by a valid nilpotence mechanism). This would produce abelian-type Chow motives and finite dimensionality, but it is not supplied by family032's cohomological KS statement. Another frontier is an algebraic whole-motive retraction for arbitrary K3^[n]-type deformations over finite fields; H² controls only part of the required motive.

Assessment: finite-field Tate for arbitrary K3/Hilbert products is a substantial statement, but its proof under the released premises is a routine composition of KS splitting, CM lifting/good reduction and motivic Hilbert decomposition. It should be reported as a conditional consequence of the release, not promoted into a new historical-calibre independent breakthrough.

## Secondary direct route: common ordinary lifts need only the product-Hodge premise

Assume only the released theorem that rational Hodge holds on arbitrary products of projective complex K3 surfaces, `thm:main` in [pinned introduction](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/build/manuscript/introduction.tex), local `sources/k3-products-introduction.tex`, lines 14–22. Then Tate for arbitrary products of **ordinary** K3 surfaces follows directly by common canonical lifts. This avoids invoking the separate CM-HC/KS premises at the implication level.

Take canonical lifts of all ordinary factors over the same W(k), after finite extension as necessary, and choose one common embedding of the algebraic closure of its fraction field into C. Let V_i=H²(S_i,lift,Q(1)). [Yu, Special lifts of ordinary K3 surfaces](https://homepage.ntu.edu.tw/~jdyu/Math/clK3.pdf), Lemmas 1.6, 2.2 and 2.3, supplies rational lifted Frobenius F_i, and identifies the Hodge (1,-1) line with the unique normalized-Frobenius eigenspace of positive p-adic valuation. The (−1,1) line has the opposite valuation, and all (0,0) eigenspaces have valuation zero. Thus the Hodge cocharacter weights on V_i are, up to the uniform sign convention, exactly v_p(λ)/v_p(q) for normalized eigenvalues λ of F_i/q. They are −1,0,1.

Let D be the Q-Zariski closure of the common tuple (F_1/q,...,F_m/q) acting on ⊕V_i; take a common sufficiently divisible power to remove finite components. Over Qbar, multiplicative eigenvalue relations define this torus. The SAME chosen p-adic valuation annihilates every such relation. Therefore assigning each eigencharacter its normalized valuation defines a cocharacter ν of D_C. The preceding simultaneous eigenline identification gives ν=±μ, where μ is the joint Hodge cocharacter. It follows that μ lies in D_C, so every D-invariant rational tensor is Hodge. This is a joint argument; it does not infer a product identity merely from Yu Theorem 2.5 for individual factors.

The Frobenius-fixed subspace in a Künneth tensor expression is the coefficient extension of ker(F−1) in the rational lifted representation. Its rational basis consists of Hodge classes by the cocharacter argument. Apply the product-Hodge premise and specialize the resulting cycles. Normalized finite-field trace returns to the original k. All Künneth terms H⁰ and H⁴ are elementary Tate terms. This proves all-codimension rational Tate for arbitrary ordinary products.

Why this direct proof stops at height>1: normalized Newton slopes are ±1/h on h-dimensional blocks, while the Hodge cocharacter has weight ±1 on one line and weight zero on the remaining lines. Equality μ=±ν is then false. At the elementary representation level, if W_+, W_- are h-dimensional reciprocal Frobenius-character blocks, all of W_+⊗W_- is ν-fixed, whereas a tensor e_1⊗f_2 has nonzero μ-weight when e_1 is the Hodge positive line and f_2 is outside the negative line. This does not assert such a chosen tensor is rational on a specific K3; it identifies the exact missing implication. The all-height KS-specialization route above avoids it.

This ordinary implication has also been independently audited in `split_audit/AUDIT.md` / the auditor's follow-up. Its novelty has not been established; ordinary self-powers are old, and correlated products require precisely the joint cocharacter argument.
