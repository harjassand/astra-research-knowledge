# Hilbert scheme motive: characteristic source audit

Audit date: 2026-10-07. Scope: the de Cataldo-Migliorini decomposition and transfer of Tate homological motives. No Kuga-Satake audit.

## Verdict

There is no characteristic restriction p>n in the rational Chow-motive decomposition. It applies to every n over arbitrary fields. The symmetric-power terms must be interpreted as invariant summands of motives of smooth powers. A Tate input in a specified homological-motive category transfers to Hilbert schemes in that same category; it does not by itself upgrade the input to Chow-Tate.

## Exact primary references

1. M. A. de Cataldo and L. Migliorini, *The Chow Groups and the Motive of the Hilbert Scheme of Points on a Surface*, Journal of Algebra 251 (2002), 824-848, DOI 10.1006/jabr.2001.9105.
   - Published author-hosted PDF: https://www.math.stonybrook.edu/~mde/MyPublishedPapers/MotiveHilbSchJournOfAlg.pdf
   - arXiv: https://arxiv.org/abs/math/0005249
   - **Theorem 6.2.1, printed p. 846 / PDF p. 23**: rational effective Chow-motive decomposition for an irreducible nonsingular projective surface over an algebraically closed field, without a characteristic assumption.
   - **Remark 6.2.2, same page** explicitly extends the theorem to any field.
   - **Section 2, p. 827**: for nu=1^{a_1}...n^{a_n}, l(nu)=sum a_i and S^(nu)=product_i S^(a_i)=S^{l(nu)}/G_nu, G_nu=product_i Sigma_{a_i}.
   - **Section 4.3, pp. 832-833**, quotient correspondences and rational averaging; **Lemma 4.3.1** gives push-pull symmetrization. **Section 5.1, p. 834** defines m_nu=(-1)^{n-l(nu)} product_j nu_j; **Proposition 5.1.4** gives the diagonal composition. The necessary denominators are inverted in Q even when divisible by p.

2. C. Vial, *On the motive of some hyperKähler varieties*, J. reine angew. Math. 725 (2017), 235-247, DOI 10.1515/crelle-2015-0008.
   - Author-hosted final preprint: https://www.math.uni-bielefeld.de/~vial/MultCK.pdf
   - arXiv: https://arxiv.org/abs/1406.1073
   - **Section 1, preprint p. 4**, immediately before **Theorem 1.1**, explains rational quotient motives/correspondences as finite-group invariants. **Theorem 1.1** restates the de Cataldo-Migliorini decomposition over an arbitrary field, using the contravariant twist convention l(nu)-n. The paper's broader complex-geometric results need not be imported here.

3. L. Fu and Z. Li, *Supersingular Irreducible Symplectic Varieties*.
   - Published author PDF: https://irma.math.unistra.fr/~lfu/articles/Supersingular%20ISV.pdf
   - Final arXiv v5: https://arxiv.org/abs/1808.05851v5
   - **Section 4.5, printed p. 179 / PDF p. 33**, proof of **Theorem 1.3(iii)** explicitly invokes
     h(S^[n])(n) ≅ ⊕_{nu partitions n} h(S^{l(nu)})^{G_nu}(l(nu))
     and reduces Tate type of the Hilbert scheme to Tate type of S. This is direct primary-literature corroboration in positive characteristic.
   - The general moduli-space theorem has a Mukai-vector coprimality hypothesis; that is not a p>n restriction on the Hilbert-scheme decomposition.

## Unambiguous formulation and deduction

Use L for the Lefschetz motive, avoiding conflicting signs of '(r)' among conventions. Then the theorem reads

h(S^[n]) ≅ ⊕_{nu partitions n} (S^{l(nu)}, e_nu, 0) ⊗ L^{n-l(nu)},

e_nu = |G_nu|^{-1} sum_{g in G_nu} Gamma_g.

This is an object of the ordinary pseudo-abelian category of rational Chow motives. It does not require treating a possibly singular S^(nu) as a smooth projective variety. The group order is a rational scalar, so p dividing |G_nu| causes no projector obstruction. Likewise rational crystalline realization takes values over W(k)[1/p].

Formal inference: quotient this Chow isomorphism by the homological equivalence associated with the chosen Weil cohomology H. If h_H(S) is a finite sum of Tate motives, then its tensor powers are; every e_nu-image is a direct summand of such a sum, hence Tate; the sum and Lefschetz twists above remain Tate. Therefore h_H(S^[n]) is Tate for every n, including p<=n. Finite products of these Hilbert schemes are Tate by tensor closure.

## Limits / failure ledger

- A merely homological Tate input yields a homological Tate conclusion. It does not prove Chow-Tate, finite-dimensional Chow motive, injectivity of cycle class maps, or absence of integral torsion.
- Crystalline and ell-adic homological equivalence should not be silently identified. Apply the formal transfer within the realization for which the K3 input has been established, or verify a common Chow-level input.
- Over a finite base field, geometric Tate type after algebraic closure need not be split Tate over that exact finite field. Divisor/projector fields of definition must be charged; after a finite extension defining all needed divisor data, the split statement transfers.
- Twist signs differ: the original paper's effective convention writes n-l(nu), whereas Vial/Fu-Li's contravariant convention writes l(nu)-n. The formulation in powers of L removes ambiguity.
- This audit confirms exact published theorem scope; it is not a fresh independent reconstruction of every intersection-theoretic step. No primary-source erratum imposing p>n was located.

## Verification/provenance

Downloaded the original published de Cataldo-Migliorini PDF and published Fu-Li PDF into this directory, extracted with bundled pypdf, and rendered the de Cataldo-Migliorini theorem page. The source rendering directly confirms both Theorem 6.2.1 and Remark 6.2.2. Local files: dcm.pdf, dcm.txt, dcm_theorem.png, fu_li.pdf, fu_li.txt.

Strongest next check belongs to the K3-base audit: establish the Tate decomposition in precisely the intended crystalline or Chow category and record the base field over which its divisor projectors are defined.
