# Shared real-quadratic K3 products: a conditional GHC theorem

Status: a proof-level conditional consequence of family032, developed jointly with `/root/number_geometry`. The release proofs themselves are theorem inputs here, not independently certified. Priority is not established. This is stronger than the source's stated self-power GHC, but it does not prove GHC for arbitrary mixed K3 products.

## Exact inputs from the pinned release

Commit: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

1. Rational HC for every finite product of projective complex K3 surfaces: `The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/build/manuscript/introduction.tex`, `thm:main`.
2. Algebraicity of the prescribed full-even-Clifford Kuga–Satake tensor for every projective K3: `Algebraicity-of-Kuga-Satake-Correspondences-for-K3-Surfaces-October-3-2026/build/manuscript.tex`, main theorem. The product-Hodge manuscript also proves this as `thm:exact-ks`.
3. Exact KS implies HC and GHC on every self-power: `Algebraic-Kuga-Satake-correspondences-and-Hodge-conjectures-on-a-K3-quadratic-locus-September-30-2026/build/paper.tex`, `ext:criterion`, lines 151–160.
4. More precisely, input (2) supplies, for every K3 `S`, every `1 <= k <= dim T(S)`, and `Z=A_S^2`, `n=dim Z`, a return
   `R_k in CH^{n+k-1}(Z x S^k)_Q`, with a right inverse on `wedge^k T(S)`. Its whole image is supported in codimension `k-1`: `ghc:prop:exterior-coniveau`, lines 631–674.

Primary pinned URLs are obtained by appending those exact paths to `https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/`. Local exact source copies are in `sources/` beside this report.

## The theorem

Let `E` be a real quadratic field, with a fixed real embedding `sigma_0` and its conjugate `sigma_1`. Let `S_1,...,S_r` be projective complex K3 surfaces. Put `V_i=T(S_i)(1)`.

Assume:

- `End_Hdg(T(S_i))=E`, with compatible identifications making the active embedding of every factor `sigma_0`;
- `dim_E T(S_i)=3`;
- the joint Hodge group of the `V_i` is the full independent product
  `G = Res_{E/Q} product_i SO(V_i,q_i)`;
- the even Clifford quaternion algebras `C_E^+(V_i,q_i)` all have the same `E`-Brauer class, equivalently are isomorphic to a quaternion algebra `D/E`.

Then, conditional on inputs (1)–(4), the rational generalized Hodge conjecture holds on every finite product of powers of the `S_i`, in every degree and for every rational sub-Hodge structure. In particular it holds on `S_1 x ... x S_r`.

No restriction is imposed on the degree or multiplicity of a substructure. Joint-group independence and the common quaternion class are actual hypotheses. This report does not remove them.

## Auxiliary K3 construction

For `i != j`, let `U_ij=D` as an `E`-vector space, with the two spin factors acting by

`(g_i,g_j): x -> g_i x g_j^{-1}`.

Start with `q_ij=-Nrd_D`. At `sigma_0`, each original rank-three form has signature `(2,1)`, so `D_sigma0=M_2(R)`. Here `q_ij` has signature `(2,2)`. At `sigma_1`, the original forms are negative definite and `D_sigma1=H`; `q_ij` is negative definite of dimension four. The active left and right spin circles can lie in opposite orientation components. If necessary replace the form by `a_ij(-Nrd_D)`, with `a_ij in E^*` positive at `sigma_1` and of the sign at `sigma_0` that makes the selected period plane positive. Weak approximation supplies such an `a_ij`. The active signature `(2,2)` and inactive negative definiteness are unchanged. Thus `Tr_{E/Q} q_ij` has rational dimension eight and signature `(2,6)`.

The tensor of the two active spin lines gives a K3-type Hodge structure on `U_ij`: after weight-zero normalization its extreme Hodge lines have weights `+1,-1`, once each, and all other weights are zero. The conjugate real component is entirely weight zero. With the preceding orientation/sign convention, the form gives positivity on the active period plane and negativity on the `(1,1)` part.

This rational quadratic Hodge structure embeds in the rational K3 lattice. One way to justify the lattice step is to choose a rational complement of dimension fourteen and signature `(1,13)`, with determinant and local Hasse invariants making the sum isometric to the K3 lattice. The necessary Hilbert-product relation holds because both prescribed forms are global. Rank fourteen removes the small-dimensional local existence exceptions; Hasse–Minkowski gives the complement. Intersecting the rational subspace with the integral K3 lattice and applying the polarized period theorem realizes it by a projective K3 `S_ij`. Full independent joint Hodge group implies that `U_ij` has no nonzero rational `(1,1)` vector and has endomorphism field `E`, so it is the entire transcendental space of `S_ij`.

For primary references, Milne's author-hosted `Class Field Theory`, Chapter VIII, Theorem 6.3 and the following local classification discussion give Hasse–Minkowski and dimension/discriminant/Hasse invariants (`https://www.jmilne.org/math/CourseNotes/CFTc.pdf`, PDF pp. 260–262). Huybrechts's author-hosted `Lectures on K3 surfaces` gives the period theorem and projectivity criterion (`https://www.math.uni-bonn.de/people/huybrech/K3Global.pdf`; use the published edition's Chapters 6–7 and 14, since draft numbering differs). The local complement existence is also immediate from the fact that anisotropic quadratic forms over a nonarchimedean local field of characteristic zero have dimension at most four: a rank-fourteen complement with the required Witt class exists. This is rational, not integral, prescribed isometry; taking the primitive intersection inside the integral K3 lattice is permitted.

Representation-theoretically,

`wedge_E^2 U_ij = Ad_i direct-sum Ad_j`.

Each `Ad_i` is the original three-dimensional `V_i` representation, up to a scalar in its invariant quadratic form. Rational Hodge maps need not preserve that scalar. Consequently:

- `V_{i,sigma}` occurs in `wedge_Q^2 T(S_ij)(2)`;
- `V_{i,sigma0} tensor V_{j,sigma1}` occurs in `wedge_Q^4 T(S_ij)(4)`;
- for `i=j`, `V_{i,sigma0} tensor V_{i,sigma1}` occurs in `wedge_Q^2 T(S_i)(2)`.

The exterior degree in the second statement is **four**, not two. It comes from the summand `wedge^2 U_sigma0 tensor wedge^2 U_sigma1` of `wedge_Q^4 U`.

All auxiliary K3 varieties can be fixed before choosing the particular sub-Hodge structure to be supported; finitely many pairwise auxiliaries suffice for a fixed finite list of original factors.

## Carrier counting for an arbitrary simple substructure

Let `H` be a simple rational Hodge substructure of `H^{2d}(X,Q)`, where `X` is a product of powers of the original surfaces. Suppose its Hodge coniveau is at least `p`, and put `b=d-p`. Normalize `H` to weight zero by `H(d)`.

Choose one complex irreducible constituent of `H(d)`. For each `SO_3` factor at place `sigma`, let `k_{i,sigma}` be its integer highest weight measured in vector units. An `SO_3` tensor representation has integer nonnegative `k`; a vector contributes `k=1` (the corresponding `SL_2` highest weight is `2`). Set

`L_sigma=sum_i k_{i,sigma}`.

The active Hodge cocharacter is a standard rotation in each active rank-three factor. The chosen constituent has Hodge level `2 L_sigma0`. Its Galois conjugate, which occurs in the rational `H`, swaps the two places and has level `2 L_sigma1`. Thus

`max(L_sigma0,L_sigma1) <= b`.

Make a token list of length `L_sigma0`, with `k_{i,sigma0}` tokens labelled `i`, and an analogous list at `sigma1`. Pair their tokens arbitrarily, padding the shorter list by blanks. There are

`c=max(L_sigma0,L_sigma1) <= b`

columns. For each column:

- two different labels `i,j` use the single carrier `wedge_Q^4 T(S_ij)(4)`;
- equal labels `i,i` use `wedge_Q^2 T(S_i)(2)`;
- one label and one blank use `T(S_i)(1)`.

The selected complex summands of these carriers are precisely the required standard representations at their assigned places. Their tensor product contains the Cartan component with highest weights `(k_{i,sigma})`. Therefore a tensor product `C` of **c** full rational exterior carriers shares a complex constituent with `H(d)`.

There is a minor central-cover point. Adding the auxiliary `S_ij` can enlarge the joint Hodge group by a finite central cover, since `U_ij` is a tensor of spin, rather than vector, representations. It adds no Lie algebra factor: all auxiliary circles lift the original joint circle through a finite spin cover. Call the enlarged connected group `G'`. The original `H(d)` remains rationally simple as a `G'` representation because `G'` maps onto `G`. The chosen complex summand of `C` has the same Lie representation as `H(d)`; connectedness gives the same group representation. Scalar extension of invariants then yields

`Hom_{G'}(C,H(d)) tensor_Q C = Hom_{G'_C}(C_C,H(d)_C) != 0`.

Any nonzero rational map is surjective, by rational simplicity. This avoids asserting that a particular complex projector descends to `Q`.

If `c=0`, `H(d)` is trivial and the ordinary Hodge conjecture already puts `H` in codimension `d`. Otherwise we have obtained a rational Hodge surjection from `c <= d-p` exterior carriers.

## Algebraicity and the support calculation

Write the `a`th carrier as `wedge^{k_a} T(Aux_a)`, put `s=sum_a k_a`, and let `Y=product_a Aux_a^{k_a}`. Then `dim Y=2s`, and the rational Hodge surjection is

`C(s) -> H(d)`, with `C subset H^{2s}(Y,Q)`.

Extend it by zero on a rational Hodge complement. By ordinary HC on the mixed K3 product `Y x X`, input (1) gives

`C_f in CH^{s+d}(Y x X)_Q`.

For each carrier, input (4) supplies an algebraic return from `Z_a=A_{Aux_a}^2`, `n_a=dim Z_a`, of codimension `n_a+k_a-1`. Their product gives a correspondence from `Z=product_a Z_a` of codimension `N+s-c`, where `N=sum_a n_a`, with image containing `C` on `H^{2c}(Z,Q)`. Composition with `C_f` has codimension

`(N+s-c)+(s+d)-2s = N+d-c`

on `Z x X`. Every component of a representative cycle has proper image in `X` of codimension at least `d-c`. Hence

`H subset N^{d-c} H^{2d}(X,Q) subset N^p H^{2d}(X,Q)`.

Semisimplicity and finite unions treat arbitrary rational sub-Hodge structures. Odd cohomology vanishes. Conversely geometric coniveau is contained in Hodge coniveau by the standard Gysin/support argument, so the filtrations coincide.

## Why the naive argument failed, and why this one is different

For just two independent rank-three RM K3s over the same real quadratic field, the rational cross constituent

`(V1_sigma0 tensor V2_sigma1) direct-sum (V1_sigma1 tensor V2_sigma0)`

has normalized Hodge level two, so `b=1`. It does not occur in a single exterior power of either original `V_1` or original `V_2`; the naive individual-return count is two. The auxiliary `S_12` places it in the one exterior carrier `wedge^4 T(S_12)(4)`, repairing exactly that deficit. The new ingredient is an auxiliary K3 whose orthogonal representation joins the two spin factors, not a claim that self-power GHC is automatically closed under arbitrary products.

## Boundaries and next attacks

1. For a general RM field of degree `e`, one efficient exterior carrier can need tokens from many different original factors at different embeddings. A pairwise rank-four auxiliary only joins two factor labels. A naive tensor of `e` spin modules has larger Hodge level at the active place and ceases to be K3 type when `e>2`. The token proof above therefore uses the quadratic field essentially.
2. If the quaternion classes differ, the Tits algebra of `spin_i tensor spin_j` is `D_i tensor_E D_j`, whose Brauer class is `[D_i]+[D_j]`. A four-dimensional `E` vector representation exists exactly when this class vanishes, equivalently `[D_i]=[D_j]`. Over a number field, a nonzero exponent-two Brauer class has Schur index two; the descended irreducible representation then has `E`-dimension eight and the desired complex `2 tensor 2` representation occurs with multiplicity two. Its extreme active Hodge space consequently has dimension two, so this replacement is not K3 type. Passing to a splitting field also enlarges the rational Hodge structure and does not automatically restore a unique extreme Hodge line. The common-class assumption is therefore a real construction boundary, not a notation choice.
3. For larger `E`-dimension, a spin representation has a higher-dimensional holomorphic space; a tensor of two spins is no longer K3 type. The simple auxiliary construction does not extend directly.
4. If the joint Hodge group is not the independent product, highest-weight indexing and rational Galois alignment require a separate argument. Shared `SL_2` graphs produce additional carrier shortcuts, but the source's central-sign proof alone does not supply all supports.
5. HC on K3 products does not imply HC on their products with arbitrary auxiliary abelian varieties. The source's tensor-group equality is explicitly only on the original `V_i`. This proof stays inside actual K3 products when algebraizing the quotient map.
6. The theorem is a candidate conditional consequence, not external validation of the release or a certified novelty claim.

## Prior-art checks made

- Zarhin's orthogonal/unitary Hodge-group classification is the representation-theoretic background.
- Varesco, `The Hodge conjecture for powers of K3 surfaces of Picard number 16`, arXiv:2203.09778, proves a conditional ordinary-HC result on specified K3 families, with exceptional determinant tensors. It does not state the above mixed GHC theorem.
- Abdulali, `Hodge structures on abelian varieties of type III`, Annals 155 (2002), arXiv:math/0410024, proves ordinary-to-general implications for certain type-III varieties; its existence of an effective Tate twist with no abelian realization warns against a blanket effective-realization claim.
- Zhu, `Hodge structure of K3 type with real multiplication and Simple Abelian Fourfolds with Definite Quaternionic Multiplication`, arXiv:1906.10157, Theorems 5.1–5.2 (PDF pp. 7–9), identifies ternary RM KS factors with generalized Mumford constructions and maps all definite-QM abelian fourfolds back to quadratic-RM Picard-rank-sixteen K3 surfaces. Type III is therefore directly relevant to the present subclass.
- Vial, `Generic cycles, Lefschetz representations, and the generalized Hodge and Bloch conjectures for abelian varieties`, author PDF `https://www.math.uni-bielefeld.de/~vial/SymAbelian.pdf`, Theorem 3.7, gives strong GHC for full Lefschetz subrepresentations of abelian varieties of totally real type. Its type-III Lefschetz group is the full orthogonal group `O`, whereas the generic Hodge group is its identity component `SO`. Section 3.2, footnote 4, explicitly distinguishes this convention from Murty's connected one. The crossed shared-field substructure need not be stable under the disconnected orientation flips: flipping one factor can change crossed weights to aligned weights and increase its Hodge level. Thus equality with the connected Lefschetz group does not automatically place the cross constituent under Theorem 3.7.
- Markman, arXiv:2509.23079, explicitly leaves semiregularity for the broader RM secant-sheaf strategy unaddressed; CM-cycle algebraicity alone is insufficient to assert transport along a Hodge locus.

These are boundary checks, not an exhaustive priority search.
