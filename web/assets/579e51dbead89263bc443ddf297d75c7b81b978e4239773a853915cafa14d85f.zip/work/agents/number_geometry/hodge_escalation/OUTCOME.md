# Hodge escalation outcome

The nonroutine progress is a conditional generalized Hodge theorem for arbitrary products of independent rank-three RM K3 surfaces over one real quadratic field with a common even-Clifford quaternion class. Its proof constructs pairwise auxiliary rank-eight K3 Hodge structures, matches highest-weight tokens across the two embeddings, and composes one exterior return per matched column. See `SHARED_RM_GHC.md` for the exact quantifiers, proof and limitations. This repairs a concrete shared-field counterexample to the naive individual-carrier argument.

The unrestricted mixed-product GHC remains unproved. The sharper next lemma is an algebraic crossed-spin shuffle for distinct quaternion classes; the common-class construction fails at exactly the nonzero Tits/Brauer obstruction. CM algebraicity alone cannot transport that shuffle along its Hodge locus, because no semiregular perfect-complex representative has been supplied.

Routine conditional escalation also survives independent audit: all-codimension Tate for arbitrary finite-field K3 products, all characteristics and mixed heights, then K3 Hilbert schemes and products with curves/abelian varieties. This uses released CM Hodge plus exact algebraic KS; ordinary products admit a second proof from mixed K3 Hodge and canonical lifts. Details and primary prior-art boundaries are in `finite_tate/FINITE_FIELD_TATE_REPORT.md`.

No Chow-level KS retraction, Kimura finite dimensionality, full mixed GHC, general complex-abelian Hodge theorem, or externally validated release correctness is claimed.

## Failure ledger

- Individual self-power GHC is not automatically product-stable. For two independent rank-three RM factors over a shared real quadratic field, the crossed rational constituent has Hodge level two but needs two original exterior carriers. Auxiliary K3s repair this only under the stated common-quaternion hypotheses.
- In a shared `SL_2` graph, an endpoint representation across a long `SO_4` chain also has level two while no one original edge exterior power carries it. Algebraic path carriers or additional auxiliaries are needed.
- A representation-level crossed KS abelian `H^2` carrier is insufficient: ordinary HC on K3 products does not supply a map into an arbitrary auxiliary abelian variety.
- The source's mixed tensor-group conclusion is explicitly restricted to the `V_i`; extending it silently to arbitrary crossed weight-one spin words would assume the missing shuffle.
- Milne's specialization/CM transport gives algebraic cycles on good-reduction special fibers. It does not give Hodge conjecture for arbitrary complex abelian varieties.
- CM-Hodge algebraicity and a perfect-complex Chern class do not guarantee injectivity of the semiregularity trace. The release's specific mirror realization plus sharp `Ext^2` bound is the mechanism; it cannot be replaced by an unproved general deformation principle.
- Cohomological KS retractions specialize and suffice for Tate surjectivity, but do not give Chow retractions without nilpotence or another construction.

## Provenance

All released source copies in `sources/` were fetched at commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Tree retrieval used the supplied preprints SHA `272ca94583c1dca3188bbc3a1caa068cb7af4b55`, then the four family032 subtrees, avoiding a truncated whole-repository recursive tree. This audit does not certify the foundational release proofs or priority of the conditional consequence.
