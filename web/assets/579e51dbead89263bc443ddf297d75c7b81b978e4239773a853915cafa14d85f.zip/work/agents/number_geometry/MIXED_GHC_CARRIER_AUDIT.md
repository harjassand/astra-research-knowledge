# Mixed K3 generalized Hodge: exact carrier audit

Status: an independently derived conditional subclass theorem and an exact counterexample to a proposed general carrier lemma. No unrestricted generalized Hodge theorem is proved. The imported OpenAI theorems remain manuscript claims, not externally certified premises.

Pinned release: `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

## Target and changed premises

Target: for every finite ordered product X of projective complex K3 surfaces, and every rational sub-Hodge structure H of H^(2d)(X,Q) of Hodge coniveau at least p, prove H is contained in geometric coniveau N^p.

New mechanisms available from family 032:

1. Exact algebraic Kuga–Satake correspondence for every projective K3 surface.
2. Ordinary rational Hodge conjecture on arbitrary mixed K3 products.
3. The quadratic-locus companion's exact-KS criterion constructs, for T=T(S) and every k, algebraic exterior return maps from H^2(Z), Z=A^2, to wedge^k T inside H^(2k)(S^k). The return has codimension dim(Z)+k−1 and hence support codimension k−1 on S^k.

Exact source handles:

- `Algebraic-Kuga-Satake-correspondences-and-Hodge-conjectures-on-a-K3-quadratic-locus-September-30-2026/build/paper.tex`, `ghc:prop:exterior-coniveau`, lines 631–674; `ghc:lem:k3-carriers`, lines 952–1110; final support computation lines 1112–1180.
- `The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/build/manuscript/mixed.tex`, `eq:mixed-group-goal` and the final proof: equality of algebraic and Hodge tensor-group actions is asserted only on the original V_i=T(S_i)(1). It must not silently be upgraded to every auxiliary abelian object.

## A complete conditional subclass theorem

Let S_1,...,S_r be projective complex K3 surfaces, V_i=T(S_i)(1), and E_i=End_Hdg(T(S_i)). Assume:

(A) Every E_i is totally real, including E_i=Q.

(B) Hg(⊕_i V_i)=∏_i Hg(V_i), with Hg(V_i)=Res_(E_i/Q) SO(V_i,q_i).

(C) The Galois action on the embeddings of all E_i is independent: the natural map from Gal(Qbar/Q) to the product of the finite permutation groups on the embedding sets is surjective. Pairwise linearly disjoint Galois closures suffice.

(D) Exact algebraic exterior return maps exist for each S_i, and ordinary rational HC holds on every mixed product of their powers.

Then GHC holds on every product X=∏_i S_i^(m_i).

Proof. It suffices by polarizable semisimplicity to treat a rationally simple H⊂H^(2d)(X,Q), with Hodge coniveau at least p. After twisting by d and using algebraic Künneth projectors, H(d) occurs in a direct sum of tensor words in the V_i; all remaining slots are Tate. The trivial representation is handled by ordinary HC, giving codimension-d support.

For a nontrivial H choose a complex irreducible constituent. It has, for each i and embedding σ of E_i, an integral orthogonal highest weight λ_(i,σ); put w_(i,σ)=λ_(i,σ),1≥0. The standard K3 Hodge cocharacter is active on one embedding σ_i^0 for each i, with vector weights 1,0,...,0,−1. By product independence in (B), the maximum value of this cocharacter on a constituent is Σ_i w_(i,σ_i^0), and its negative also occurs. This uses the weight polytope of the orthogonal standard tensor representations; it includes SO_3, SO_4, and the signed middle-exterior components in even rank.

Define c_i=max_σ w_(i,σ). Rationality of H makes every Galois-conjugate highest-weight tuple occur in H_C. Assumption (C) supplies one Galois element simultaneously transporting a maximizing embedding for every i to its active embedding. Consequently H(d) has level at least 2Σ_i c_i. Its level is at most 2(d−p), so c=Σ_i c_i≤d−p.

For each i, pack the signed Young columns over the embeddings of E_i into c_i full rational exterior carriers of V_i, exactly as in `ghc:lem:k3-carriers`. Padding columns at an embedding with zeros does not add a return. Their tensor product C shares the chosen complex constituent with H_C. Scalar extension of Hom_G(C,H(d)) shows a nonzero rational Hodge map C→H(d), surjective by rational simplicity. Write s for the total exterior degree and realize C before normalization inside H^(2s)(Y,Q), where Y is a mixed product of the S_i of dimension 2s.

Extend this quotient map by zero on a rational Hodge complement. Poincaré duality identifies it with a rational Hodge class of codimension s+d on Y×X. Assumption (D) supplies an algebraic correspondence C_f in CH^(s+d)(Y×X)_Q realizing it.

The exterior product of the c individual returns comes from a product Z of abelian squares. Write n=dim(Z). Its correspondence R has codimension n+s−c on Z×Y and its action from H^(2c)(Z) has image containing C. Composition has codimension

    (n+s−c)+(s+d)−dim(Y) = n+d−c

on Z×X. Its cycle support has dimension at most dim(X)−d+c, so its image is supported in codimension d−c≥p on X. This image contains H. A finite union of supports handles nonsimple H. QED under (A)–(D).

This is a mechanism theorem, not claimed as novel prior art or historical-calibre progress. It explicitly identifies the additional joint hypothesis used beyond the source's self-power proof.

## Exact shared-field obstruction

The embedding-independence hypothesis cannot be removed by merely copying the self-power argument.

Take E real quadratic, with embeddings σ_0 and σ_1. Consider two independent K3-type modules V_1,V_2 of E-dimension three, both active at σ_0. Suppose their joint group is the full product of their individual restriction-of-scalars SO_3 groups. Over C write U_(i,j) for the three-dimensional standard module at embedding σ_j. The rational tensor product V_1⊗_Q V_2 decomposes according to

    E⊗_Q E ≅ E × E.

The cross factor H is rational, and

    H_C = (U_(1,0)⊗U_(2,1)) ⊕ (U_(1,1)⊗U_(2,0)).

Each summand is irreducible for the split product group; they are interchanged by the nontrivial Galois element. Thus H is rationally simple. In each summand only one standard factor is active. Therefore normalized H has Hodge types (1,−1),(0,0),(−1,1), each of dimension six, and level two. Inside H^4(S_1×S_2), it has Hodge coniveau one.

But no single wedge^k V_1 or wedge^k V_2 contains H: every exterior power of V_1 is trivial on all V_2 simple factors and vice versa, whereas every constituent of H acts nontrivially on a simple factor from each surface. Thus there is no surjection from one individual exterior carrier to H. The proposed count c≤b with b=1 is false for the original individual returns. The naive construction spends c=2 and proves only support codimension d−c=0.

This does not refute GHC. It identifies the first genuinely new return needed: an algebraic H^2 carrier for the cross factor H, whose return to H^4(S_1×S_2) has codimension dim(Z)+1 and hence divisor support.

K3 surfaces with real quadratic multiplication and E-dimension three occur in primary literature: van Geemen, *Real multiplication on K3 surfaces and Kuga Satake varieties*, Michigan Math. J. 56 (2008), Example 3.4 and Proposition 5.7; van Geemen–Schütt, *On families of K3 surfaces with real multiplication*, Forum Math. Sigma, 2025, Section 2.5–2.6 and references. Generic independent periods in the respective RM families avoid additional diagonal identifications. For the counterexample to the representation lemma, existence of the displayed polarizable modules already suffices.

## Strongest next lemma: algebraic spin shuffle

At a splitting field, each individual KS constituent has the form

    W_1 = spin(U_(1,0))⊗spin(U_(1,1)),
    W_2 = spin(U_(2,0))⊗spin(U_(2,1)).

A crossed quadratic sum U_(1,0)⊕U_(2,1), with its Galois conjugate, has exactly one active positive period plane in each real component. Its Clifford spin realization is weight one. End of this crossed realization contains the cross H via Clifford multiplication, giving a representation-level H^2 carrier.

The missing algebraic object is the period-compatible regrouping tensor

    W_1⊗W_2  ↔  W_cross⊗W_other_cross

and the associated exact projected return. Weight-one algebraicity does not prove this: the shuffle is an isomorphism between weight-two tensor products, not a homomorphism of abelian varieties. CM Hodge algebraicity does not apply to its independent non-CM spin factors. The source's auxiliary-spin proposition supplies a degree-four metric contraction tensor within one crossed abelian variety; it does not by itself identify that tensor with the original two-surface realization.

Any attempt to complete mixed GHC should prove this shuffle algebraic with a stated rational projector and cycle codimension, or produce a stronger Tannakian action equality that actually includes the crossed End object. Checking C=G only on the original V_i is insufficient for this transport.

## Failure ledger

- CM specialization to arbitrary abelian Hodge was not adopted: transport of absolute Hodge classes is not algebraic spread.
- Ordinary Chowla2 does not imply arbitrary ordinary higher correlations. Source 007's graph test is bilinear, while the direct triple dilation gives a multilinear hypergraph form. Its analytic Fourier centering does not establish the necessary small-scale higher-uniformity estimate.
- Combining every self-power GHC with ordinary HC on mixed K3 products is insufficient without the joint carrier count. The shared-field cross constituent above is an exact obstruction.
- Existence of a weight-one crossed spin Hodge structure is not the algebraicity of its shuffle/return.

## Primary-source URLs

- https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Algebraic-Kuga-Satake-correspondences-and-Hodge-conjectures-on-a-K3-quadratic-locus-September-30-2026/build/paper.tex
- https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/build/manuscript/mixed.tex
- https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/build/manuscript/auxiliary.tex
- https://arxiv.org/abs/math/0609839
- https://arxiv.org/abs/2310.05196
- https://www.cambridge.org/core/journals/forum-of-mathematics-sigma/article/on-families-of-k3-surfaces-with-real-multiplication/26D90B781A518CB95969B4473C8852C8
- https://arxiv.org/abs/2203.09778 (Varesco: prior conditional self-power HC, not unrestricted mixed GHC).
