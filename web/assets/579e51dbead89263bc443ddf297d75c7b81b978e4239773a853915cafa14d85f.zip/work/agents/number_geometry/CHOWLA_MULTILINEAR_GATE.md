# Ordinary Chowla escalation: an exact analytic-gate counterexample

Status: no three-point ordinary Chowla proof. A precise counterexample shows why the released bilinear centering argument cannot be extended using its short Fourier input alone.

Pinned source: OpenAI commit adc7f1241b42e322a6451854ab7e4b4c146bf78a, `Ordinary-two-point-correlations-of-multiplicative-functions-September-24-2026/build/qualitative/analytic-transfer.tex`, `eq:mrt-fixed-length`, `eq:analytic-rough-target`, `eq:analytic-overlap`, `eq:analytic-large-bound`. The source graph Proposition `prop:graph-estimate` in `qualitative/graph-setup.tex` tests F(x)G(x+hd), not a multilinear product.

## What a direct triple extension would need

For shifts 0,h,k, the centering expansion naturally asks for a bound of the form

    limsup_(Y→∞) (1/Y) | Σ_(z≤Y) b0(z) Σ_(M<w≤τM) c_w/w · b1(z+hw)b2(z+kw) |
       ≪ B^(−1−ε),

uniformly over |c_w|≤1 on P0-rough w, with P0=exp(B^(1−ε)), P0/τ≤M≤exp(C0 B), all B/M parameters fixed before Y→∞. The two-point proof gets its corresponding bound from a rough-number Fourier multiplier plus fixed-frequency short-interval exponential sums. A triple form requires more information.

## Counterexample to sufficiency of the Fourier input

Choose an irrational α and set e(t)=exp(2πit). For h=1,k=2 put

    b0(z)=e(αz²),  b1(z)=e(−2αz²),  b2(z)=e(αz²),
    c_w=e(−2αw²) on rough w.

For every z,w the phase identity is exact:

    z²−2(z+w)²+(z+2w)² = 2w².

Hence the triple expression, for every Y, is exactly

    Σ_(M<w≤τM, w P0-rough) 1/w.

Take M=P0 and a fixed τ in (1,2). The primes in this interval alone give, by PNT, a lower bound asymptotic to (log τ)/log P0, hence ≍B^(−1+ε), much larger than B^(−1−ε).

Nevertheless every b_i satisfies a *stronger* version of the source's fixed-frequency averaged short Fourier bound. If β is any of α,−2α and D is a fixed integer, equidistribution of 2βy mod one gives, for every fixed ξ,

    lim_(Y→∞) (1/Y) Σ_(y≤Y) | Σ_(t=1)^D e(β(y+t)²+ξ(y+t)) |
       = ∫_0^1 | Σ_(t=1)^D e(βt²+(u+ξ)t) | du
       ≤ sqrt(D),

by Cauchy–Schwarz and Fourier orthogonality. The same bound holds with the supremum over ξ outside the long average, since translation of u removes ξ and the equidistribution error is uniform for the fixed trigonometric polynomial family. Thus its normalization is at most D^(−1/2), which is much smaller than (log log D)/(log D), the Fourier input used in the source. Endpoint changes from integer to continuous short-interval averaging are harmless in the fixed-D limit.

The sequences in this counterexample are not multiplicative. The result therefore does not refute a possible triple Elliott/Chowla centering theorem using genuinely new multiplicative information. It proves that copying the source's Fourier input and rough-multiplier frequency split is insufficient; quadratic structure survives the three-point average even when every individual sequence passes the exact Fourier test.

## Distinct graph gate

Triple dilation leads to a centered divisibility hypergraph testing F0(x)F1(x+hd)F2(x+kd). The released bilinear graph's operator norm is not a norm bound for this tensor form. Both the hypergraph moment/rank-witness estimate and the preceding quadratic-sensitive analytic centering require direct new arguments.

The modern primary higher-uniformity theorem is Matomäki–Radziwiłł–Tao–Teräväinen–Ziegler, Annals of Mathematics 197 (2023), 739–857. Its stated averaged Gowers/nilsequence uniformity range H≥X^θ, θ>0 fixed, does not automatically apply when D is fixed before X→∞ in this release's qualitative order of limits. A stronger appropriate range must be proved or sourced rather than inferred.

## Sources

- https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Ordinary-two-point-correlations-of-multiplicative-functions-September-24-2026/build/qualitative/analytic-transfer.tex
- https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Ordinary-two-point-correlations-of-multiplicative-functions-September-24-2026/build/qualitative/graph-setup.tex
- https://annals.math.princeton.edu/2023/197-2/p03
- https://arxiv.org/abs/1708.02610 (Tao–Teräväinen logarithmic higher correlations: different averaging contract).
