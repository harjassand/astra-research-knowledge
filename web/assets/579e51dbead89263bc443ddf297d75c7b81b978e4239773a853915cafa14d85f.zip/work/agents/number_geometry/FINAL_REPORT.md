# Number theory / arithmetic geometry / logic outcome

## Strongest constructive outcome

Conditional on the released family032 algebraic exact Kuga–Satake and ordinary Hodge results, we reconstructed a generalized Hodge theorem for arbitrary mixed products of independent rank-three RM K3 surfaces over one real quadratic field with a common even-Clifford quaternion class.

The new local mechanism is a pairwise auxiliary K3 surface of rational transcendental rank eight. Its fourth exterior power carries a shared-field cross tensor using only one return from H² of an abelian square. Matching highest-weight tokens across the two real embeddings makes the number of returns equal to half the actual Hodge level. Composition with a mixed-K3 ordinary-HC quotient map gives exactly the required support codimension.

This mechanism repairs an exact counterexample to the naive idea that independent self-power GHC automatically extends to mixed products. The conditional proof was independently reconstructed by hodge_escalation. Priority and foundational release correctness are unverified; this is not an unrestricted GHC proof or a historical-calibre claim.

Main proof and independent audit:

- `SHARED_RM_AUXILIARY_K3_ROUTE.md`
- `hodge_escalation/SHARED_RM_GHC.md`
- `MIXED_GHC_CARRIER_AUDIT.md`
- `EXTERIOR_CHARACTER_FIXTURE.json` (exact character fixture only)

## Exact next frontier

Two independent rank-three RM K3 surfaces over the same real quadratic field but with distinct quaternion Brauer classes are the smallest remaining test. The spin-tensor representation has nonsplit Tits algebra of index two, forcing multiplicity two and h^(2,0)=2 for its E-rational realization; the auxiliary K3 pairing above therefore fails. One must prove an algebraic crossed-spin shuffle/return or another mixed carrier. The source's auxiliary metric tensor and its tensor-group conclusion restricted to the original V_i do not establish that transport.

## Analytic-number-theory negative result

`CHOWLA_MULTILINEAR_GATE.md` gives an exact quadratic-phase counterexample: each factor passes the released averaged fixed-frequency short Fourier input at strength D^(−1/2), but their three-point rough-divisor average remains ≍B^(−1+ε), whereas the proposed centering extension needs B^(−1−ε). The example is not multiplicative; it refutes the sufficiency of the available Fourier input, not Chowla. A centered divisibility hypergraph estimate is also absent.

## Routine conditional consequence checked separately

`hodge_escalation/finite_tate/FINITE_FIELD_TATE_REPORT.md` and its nested audits reconstruct all-codimension rational Tate for arbitrary finite-field K3 products, all characteristics and mixed heights, then for actual K3 Hilbert schemes and products with curves/abelian varieties. This uses CM-Hodge plus cohomological KS retractions; it does not provide Chow retractions, Kimura finiteness, or arbitrary deformation-family claims. The ordinary common-canonical-lift route supplies a second scoped proof. These are routine conditional escalations of the released premises, not novel foundational proofs.

## Closest prior art actually checked

- Abdulali, *Hodge structures on abelian varieties of type III*, Annals 155 (2002), Theorem 4.1 and Corollary 4.3: domination/self-power GHC for one simple general-PEL type-III fiber. Direct applicability to independently varying mixed cross supports was not established.
- Zhu, arXiv:1906.10157, Theorems 5.1–5.2: rank-six quadratic-RM K3/definite-quaternion abelian-fourfold KS correspondence.
- Varesco, arXiv:2203.09778: prior conditional self-power ordinary HC.
- van Geemen–Schütt, arXiv:2310.05196: real-multiplication K3 families and rank bounds.

No absence-of-prior-art or model-consensus inference is used.
