# Acquired exact all-scale certificate: two reversible linkages

## Interface, acquisition, and scope

Network A⇌2B and B⇌2A, with four independently controlled measurable rates k_j∈[1,4]. Complexes are actual nonnegative integer exponents. The two reaction vectors (−1,2) and (2,−1) have determinant −3, so S=R² and P=R_{>0}² is unbounded. Each reversible linkage is endotactic; their union is endotactic. This particular certificate's soundness is proved below without relying on N33.

`acquire_two_linkage.py` enumerates a fixed rational five-facet ansatz; it does not input successful barrier coefficients. The exact Fraction checker uses sufficient conditions derived below, independent of the search order. Its first accepted result follows 4,850 candidate checks. This is acquired witness evidence for one unbounded network, not a general CAD implementation, not a proof of the rational-family theorem, and not an efficient compiler claim.

Output `two_linkage_certificate.json`:

    q=4, η=1/4, z_P=1/8, p=4, a=1/2,
    A=2, B=7, C=1/3, s=3/4.

## Dynamics and family

Write the concentrations as x,y, and t=z². Then

    f_x=−k_1 x+k_2 y²+2k_3 y−2k_4 x²,
    f_y= 2k_1 x−2k_2 y²−k_3 y+k_4 x²,
    f_x+f_y=k_1x+k_3y−k_4x²−k_2y².

For 0<z≤1/8 define

    F_z(x,y)=min{0, x−2t, y−2t,
                    (3/4)(x+y−7t), (1/3)t^{-1}−x−y},
    Q_z={x≥2t, y≥2t, 7t≤x+y≤(1/3)t^{-1}}.

The plateau is nonempty (it contains (1,1)), compact, convex, and strictly inside [sqrt(h),1/sqrt(h)]², where h=z⁴=t²: its lower coordinates are ≥2t>t and upper coordinates ≤(1/3)t^{-1}<t^{-1}.

The central box [h^{1/4},h^{-1/4}]²=[z,z^{-1}]² is contained in Q_z. Indeed z≥2z², 2z≥7z², and 2z^{-1}≤(1/3)z^{-2} for z≤1/8.

## Exact active-slope drift throughout the larger box

Let (x,y)∈B_h=[t²,t^{-2}]². The constant label has slope zero. Every other slope is nonneutral because S=R². All estimates hold for every rate vector in [1,4]^4 and all ties.

If x−2t is active, comparison with 0 gives x≤2t. Comparison with the small-total facet gives

    y≥(1/3)x+(13/3)t≥(13/3)t.

Therefore

    f_x≥2y−4x−8x²
        ≥[(26/3)−8−32t]t
        ≥(1/6)t
        ≥(1/2)t²,

using t≤1/64. The y-facet has the same bound by symmetry.

If (3/4)(x+y−7t) is active, comparison with 0 gives x+y≤7t. Also x+y≥2t² from the box. Since x²+y²≤(x+y)²,

    (3/4)(f_x+f_y)
      ≥(3/4)(x+y)[1−4(x+y)]
      ≥(3/4)(2t²)(1−28/64)
      =(27/32)t²≥(1/2)t².

If (1/3)t^{-1}−x−y is active, x+y≥(1/3)t^{-1}≥64/3. Since x²+y²≥(x+y)²/2,

    −(f_x+f_y)≥(x+y)²/2−4(x+y)≥1280/9>(1/2)t².

Thus every active nonzero affine slope has derivative at least (1/2)z⁴ uniformly on B_h. The exact checker obtained respective margins 1/6, 27/32, and 1280/9. It checks symbolic sufficient inequalities valid for the complete continuous scale interval, not sample grid points.

## Global absorption

Every positive (x⁰,y⁰) is in a central box for some sufficiently small z_0≤1/8, hence in Q_{z_0}. The finite affine-min a.e. chain rule and the active-slope bounds keep it there globally. The compact positive plateau misses the boundary of B_{z_0⁴}, so no finite escape or extinction occurs.

Iterate z_{j+1}=min{sqrt(z_j),1/8}. Q_{z_j} is contained in B_{z_{j+1}⁴}; strict drift enters Q_{z_{j+1}} in finite time. The finite sequence reaches 1/8. Therefore the final common rational absorber is

    x≥1/32, y≥1/32, 7/64≤x+y≤64/3.

Its invariance and global absorption hold simultaneously for all measurable rate paths in [1,4]^4, with initial-dependent, rate-path-independent entry bounds from the finite W(z) sum in `GLOBAL_RECOGNIZER.md`.

## Checker derivation for the searched ansatz

For arbitrary rational A,B,C,s,z_P,a, let t_P=z_P² and

    F=min{0,x−At,y−At,s(x+y−Bt),C/t−x−y}.

The checker requires A>1, 0<C<1, 0<s<1; c=(1,1) belongs to every plateau; and central-box conditions z_P A≤1, z_P B≤2, 2z_P≤C.

At an active coordinate facet, the same comparison gives x≤At and y≥(B−A/s)t. Hence coordinate drift≥L t, where

    L=2κ(B−A/s)−K A−2K A²t_P.

Require B−A/s>0 and L≥a t_P.

At the small-total facet require κ−K B t_P>0 and

    2s(κ−K B t_P)≥a.

At the large-total facet set U_min=C/t_P and require U_min≥2K/κ and

    U_min(κ U_min/2−K)≥a t_P².

These exact rational tests imply the desired drift≥a t²=a z⁴. Failed tests only reject this sufficient proof, unless a separate outward witness is provided.
