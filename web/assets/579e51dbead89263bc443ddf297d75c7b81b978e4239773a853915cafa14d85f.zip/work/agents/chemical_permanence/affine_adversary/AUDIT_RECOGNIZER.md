# Independent audit: global recognizer and two-linkage acquisition

Audited `../GLOBAL_RECOGNIZER.md`, `../TWO_LINKAGE_PROOF.md`, and `../acquire_two_linkage.py`. The rational-family existence statement is assumed here only as the internally reconstructed candidate theorem recorded in `RATIONAL_AFFINE_RECONSTRUCTION.md`; I did not upgrade it to an externally accepted theorem.

## Verdict

I found no mismatch that falsely certifies global absorption in the stated certificate format or in the concrete two-linkage fixture. The finite universal obligations have a direct soundness proof independent of N33. Completeness and termination on promised rational endotactic inputs are conditional on the rational-family candidate. The actual script is a specialized sufficient checker for the displayed network and ansatz, not a generic network/QE verifier.

I independently copied the script byte-for-byte to this audit's own directory and ran the copy. It returned the same first accepted tuple after 4,850 candidates:

    A=2, B=7, C=1/3, s=3/4, z_P=1/8, a=1/2.
    margins: coordinate 1/6; small-total 27/32; large-total 1280/9.
    absorber: x≥1/32, y≥1/32, 7/64≤x+y≤64/3.

The replay wrote only `affine_adversary/two_linkage_certificate.json`; no parent/shared file was changed. The finite replay checks acquisition reproducibility. The mathematical all-scale estimates below provide the continuous-scale proof. I also inspected and replayed the subsequently hardened `--verify` implementation: the successful certificate passes; a consistently edited B=2 candidate (including its facet and absorber metadata) is rejected by the sufficient proof conditions.

## Global certificate soundness

### Exact finite obligations

For each enumerated tuple, q is a positive even integer, qη is a positive integer, all slopes and Laurent coefficients are rational, and a>0. Therefore every exponent in (A)–(D) is an integer power of z or a nonnegative integer power of a concentration coordinate. The active-label relation is exactly

    L_λ(z,x)≤L_μ(z,x) for every μ,

including every tie. Orthogonality is decidable directly from rational products r_λ·ν_e=0 for all e. No supplied basis or approximate test is required.

Every finite Laurent expression can be multiplied by z^N for a sufficiently large integer N. Under the quantified assumption z>0 this factor is strictly positive, so signs and strictness are preserved. Thus the obligations are finite first-order real-field sentences with rational coefficients. The individual fixed tuple's decision procedure terminates; no uncharged infinite-domain oracle is required.

The rate-box-vertex alternative is valid: at fixed z,x, the expression in (D) is affine in the independent rate coordinates. Its minimum on their rectangular box occurs at a vertex. Checking all 2^|R| vertices is sufficient and incurs that explicit cost.

### Plateau and neutral slopes

The specified zero label makes F_z≤M on all R^d. The conjunction L_λ≥M is consequently exactly {F_z=M}; no missing reverse inclusion occurs. (A) gives nonemptiness. (B) quantifies over every x in the global polyhedron, not merely x in B_z, so it proves positivity and boundedness rather than assuming them.

At every point of Q_z, M is automatically the least constant offset: all constant labels must satisfy their inequalities L_λ≥M there. Thus the soundness argument does not additionally need a separate least-constant obligation.

For x∈c+S and r_λ⊥S,

    L_λ(z,x)=L_λ(z,c)≥M(z).

At x∉Q_z, F_z<M, so no neutral label is active. Off the plateau within the class, (D) and the finite-affine-min a.e. chain rule therefore give derivative at least a z^p. On the whole box the derivative is nonnegative, including ties with the constant label. The argument uses neither strict increase at every time nor differentiability of the measurable rate path.

Starting in Q_z, monotonicity while in B_z and the global upper bound F_z≤M force the trajectory to remain in Q_z. Because (B) places Q_z strictly inside B_z, a first exit is impossible. Uniform local Lipschitz bounds in x and boundedness of the mass-action vector field on a positive neighborhood of Q_z give global Carathéodory continuation. The vector field lies in S at almost every time, preserving the class.

### Coverage, scale transitions, and waiting time

The exponent qη is positive, so the central boxes in (C) expand to exhaust the positive orthant as z→0. Thus each positive initial point belongs to some Q_{z_0}; this is not merely an assertion of local safety from a supplied initial compact range.

Since z_{j+1}≤sqrt(z_j), (B) gives

    Q_{z_j}⊂int[z_j^(q/2),z_j^(−q/2)]^d
              ⊂int B_{z_{j+1}}.

The previous plateau's invariance keeps the trajectory in this next box indefinitely. Strict drift therefore guarantees entry into the next plateau. Repeated square roots of z_0<1 reach the cap z_P<1 after finitely many steps. No nesting of the actual plateaux is assumed or needed.

The minimum formula used in W(z) is exact: finite minimization over labels commutes with minimization over the box, and each individual affine form is minimized coordinatewise at its appropriate box endpoint. W(z) is finite and nonnegative. Starting anywhere in the box, integrating a z^p until entry proves the stated waiting bound. The total bound depends on the initial point, and is independent of the chosen rate path; no single time for all points of an unbounded class is claimed.

At a rational positive initial point, a small rational z_0 satisfying (C) can be found by exact rational comparisons because qη is an integer. Subsequent scales are real algebraic numbers obtained by square roots and exact comparisons with rational z_P. Laurent evaluations, finite minima, and sums in W are then exact real-algebraic calculations. At the final rational z_P, Q_P has rational inequalities, including rational class equations.

## Conditional completeness

The order of choices is sound. After obtaining rational slopes and rational power exponents, choose q clearing all denominators and even. The finitely many zero-slope offsets become Laurent polynomials in z. Their pairwise differences have eventually fixed signs, so one fixed zero label is least on one entire sufficiently small interval. This is an eventual sign claim, not a presumption that an arbitrary fixed label is least.

H is a positive rational minimum for the rational family and rational actual complexes. Choose rational 0<η<min(H,1/2), then enlarge q to make qη integral while preserving the earlier denominator clearing and parity. M=max_e||y_e||_1 is an integer because the promised input complexes are nonnegative integer vectors, so p=qM is an allowed integer. The N33 drift coefficient a=κH is rational and positive.

All source cutoffs hold on a whole sufficiently small interval, allowing one rational z_P below them. Uniform activity forces all active slopes in the central box to be zero; the least fixed zero label then proves (C). The global plateau argument supplies (A),(B), and weighted drift supplies (D). Hence, conditional on rational-family existence, the certificate class contains a witness for every promised input.

Enumeration by finite encoding length has finitely many candidates at each length. Every individual QE decision terminates. A finite witnessing tuple therefore occurs after finitely many prior decisions. This is a terminating acquisition algorithm on the promised endotactic class, without any useful running-time, bit-height, family-size, or precision bound. Outside that promise it remains positive semidecision only.

## Exact two-linkage stoichiometry and factors

The declared reactions give

    A→2B: ν_1=(−1,2), rate k_1 x;
    2B→A: ν_2=(1,−2), rate k_2 y²;
    B→2A: ν_3=(2,−1), rate k_3 y;
    2A→B: ν_4=(−2,1), rate k_4 x².

Thus the displayed dynamics are exact, including every factor 2:

    f_x=−k_1x+k_2y²+2k_3y−2k_4x²,
    f_y=2k_1x−2k_2y²−k_3y+k_4x²,
    f_x+f_y=k_1x+k_3y−k_2y²−k_4x².

The two independent forward vectors have determinant −3, so the positive class is the full unbounded positive quadrant. The target derivatives for the nonzero slopes are f_x, f_y, s(f_x+f_y), and −(f_x+f_y); the factor s is included in the checker and proof.

Set t=z², t_P=1/64, s=3/4. Geometric conditions give c=(1,1) in every plateau, global positivity/compactness, strict containment in [t,t^(−1)]², and central-box coverage. All conditions are non-strict where sufficient; the strict A>1 and C<1 provide the required separation from the larger box boundary.

At an active x-coordinate label, x≤At. Comparison with the small-total label gives the exact stronger inequality

    y≥((1−s)/s)x+(B−A/s)t.

Dropping its first positive term is legal. With A=2,B=7,s=3/4, y≥(13/3)t. For every independent rate vector in [1,4]^4,

    f_x≥2y−4x−8x²
       ≥(2/3−32t)t≥(1/6)t≥(1/2)t².

The y-coordinate estimate follows by swapping x,y and the corresponding independent rate indices, which leaves the common rate box invariant.

At the active small-total label, u=x+y≤7t and u≥2t². Therefore

    s(f_x+f_y)≥s u(1−4u)
                 ≥2s(1−28t_P)t²=(27/32)t²≥(1/2)t².

At the active large-total label, u≥(1/3)/t≥64/3. The function g(u)=u²/2−4u is increasing for u≥64/3. Hence

    −(f_x+f_y)≥g(u)≥g(64/3)=1280/9≥(1/2)t².

All implications use active comparisons with ≤, so ties are covered. No state or scale sampling enters these proofs.

The checker's generic sufficient inequalities are also correctly derived: L≥a t_P implies L t≥a t²; 2s(κ−KBt_P)≥a handles the small-total label; and g(U_min)≥a t_P² handles the large-total label for every t≤t_P. The requirement U_min≥2K/κ ensures g is nonnegative and increasing on the whole relevant range.

## Scope limitations and negative control

* `check(candidate)` uses hand-derived formulas for this specific network. The hardened `--verify` interface now explicitly binds the supplied network, rate box, representative, scale/drift parameters, facet data, and final absorber to that specific interface. It also enforces a>0. The proof formulas are still specialized rather than automatically derived from arbitrary supplied stoichiometry.
* The script is not the general QE recognizer, and no successful generic CAD/QE run is evidenced by its output.
* Rejected ansatz tuples are failure of these sufficient conditions, not proofs of nonpermanence.

For the B=2 altered plateau at z=1/8, take x=y=1/32 and rates (4,1,1,4). Both coordinate facets and the zero label are active; the small-total label is strictly higher. Exact substitution gives

    f_x=−4/32+1/1024+2/32−8/1024=−71/1024<0.

The altered plateau's x lower boundary therefore has an actual outward vector field, independently confirming failure of invariance for this particular rejected candidate. This counterexample concerns that plateau, not the original network's permanence.

No required correction to the current theorem candidate, fixture proof, or reported acquisition output was found.
