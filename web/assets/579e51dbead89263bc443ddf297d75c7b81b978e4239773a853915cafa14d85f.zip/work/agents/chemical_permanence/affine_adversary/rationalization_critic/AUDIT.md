# Independent adversarial audit of rational affine reconstruction

Audited `../RATIONAL_AFFINE_RECONSTRUCTION.md` against
`../../sources/endotactic_permanence.tex`, Lemma `lem:affine` and
Corollary `cor:activity`, and `../../sources/OA149-affine.tex`.
Source pin recorded by the reconstruction:
https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026

## Verdict

I found no counterexample or unresolved analytic gap in the strengthened
induction. I endorse its rational-family existence conclusion, subject to
the explicit recursive parameter invariant below. This is an independent
mathematical audit, not formal verification or a priority assessment. It
does not validate the separate quantifier-elimination witness encoding.

## The precise bookkeeping obligation

For every selected node of the finite proof tree, pull its external
parameters and internal variables back to the one final parameter vector.
The final allowed system must imply that node's complete allowed system:
shared/lift identities, all base cube-boundary equalities, every base-zero
comparison at every slope used by that node, and any preserved exponent
equalities. Take the union of these pulled-back equations. Every such
equation is rational affine because lifting only selects coordinates or
inserts a center variable; it introduces no products of parameters.

The base real vector solves the union. At the rational-data root the union
therefore has rational points dense in its real solution space, including
when the space has dimension zero. The remaining inequalities needed by
the actual proof are strict at the base, hence they hold in a relative
neighborhood. Some of these strict inequalities involve fixed irrational
radii; that does not affect rational density in the affine equality space.

Only nodes retained by the finite subcover are included. The continuum of
unused local constructions contributes neither variables nor equations.
Final lifted root slopes may already represent the descendant comparison
zeros; no separate insufficiency counterexample for that representation
was established. The full recursive invariant avoids relying on it.

## Why the analytic steps survive

1. **Tolerance continuity on the allowed stratum.** At a fixed base slope,
   each zero comparison stays exactly zero and is omitted throughout.
   Each nonzero comparison stays nonzero nearby and its absolute value
   converges to the base value. Thus the finite minimum defining the
   tolerance converges. No continuity across a comparison hyperplane is
   being asserted.

2. **Uniform offset asymptotics.** A finite negative sum with base exponent
   gaps at least `g > 0` has, for all sufficiently near allowed parameters,
   gaps at least `g/2`. Consequently its ratio to the lower power is at
   most `N h^(g/2)` in absolute value. This handles arbitrary coupling of
   parameter convergence and `h -> 0`; no bound on
   `(theta_n - theta_0) log(h_n)` is needed.

3. **Local induction.** Comparison with the baseline uses coefficients
   bounded below by a positive limiting threshold gap. It forces every
   raised limiting coordinate to be at least its base threshold. The
   selected child then receives a limiting point in its base cube even
   when the approximating points approach that cube from outside. Its
   moving external parameters satisfy its equations by the invariant.
   The type `k+1` competitor uses only strictly positive limiting exponent
   gaps. At type `m-1`, the sole unraised limiting coordinate equals the
   base center. Each resulting tolerance bound is strict.

4. **Enlarged active-limit closedness.** For points `p_j` converging to `p`,
   take an actual active witness for each `p_j` with parameter distance,
   `h`, and point distance all below `1/j`. The resulting sequence still
   satisfies the same allowed equations and converges to the base
   parameters, and it witnesses `p` in the enlarged set. This requires no
   continuity of active labels. The bad set is a finite union of closed
   subsets of the base cube, hence compact. The strict slice conclusion
   excludes the slice; a positive minimum distance in the minimum
   coordinate then supplies the base interval.

5. **Gluing.** At the base, all selected cut margins and center gaps are
   strict. The comparison to the next baseline has leading positive term
   `h^q`, with every other term separated by a fixed limiting exponent
   gap. The comparison to the previous baseline has a positive coefficient
   bounded away from zero multiplying a coordinate with exponent strictly
   below `q`. Therefore a globally active limiting point lies between the
   base cuts, strictly inside its selected base interval. There is no need
   to assert a new neighborhood theorem for shifted intervals at every
   perturbed parameter; the enlarged limit set already covers the sequence.

6. **One neighborhood and one cutoff.** Negating the claimed existence of
   `delta > 0` and `h_0 > 0` gives bad witnesses with parameter distance
   below `1/n` and `h_n < 1/n`. Finiteness fixes a label on a subsequence
   and root-cube compactness fixes the limiting point. Tolerance continuity
   passes the bad weak inequality to the limit, contradicting the strict
   strengthened sequential conclusion. Rational density then selects a
   rational parameter vector in this common neighborhood.

The induction also proves, rather than assumes, that offsets remain finite
negative sums of powers: singleton offsets are zero; a lift adds one
negative power; gluing adds finitely many negative powers. All resulting
base exponent gaps above the relevant lower endpoint are strict and
remain so after the rational perturbation.

## Scope and strongest remaining attack

The conclusion is existence of a finite rational family and an all-small-
scale activity cutoff. No family-size, denominator, exponent-height, or
cutoff bound has been proved. For root lower endpoint `a = -1`, negative
rational exponents are permitted; a future verifier must encode Laurent
Puiseux offsets rather than silently require polynomial exponents.

For rational actual complexes, the source definitions of `H`, `L`, and `M`
are rational once slopes are rational. This does not make every evaluated
offset rational at an arbitrary rational `h`; an exact verifier needs a
common-denominator substitution and positivity-safe clearing of powers.
The decisive remaining attack is the independently specified verifier:
does its finite first-order formula cover all scales, all active ties, and
the full absorption conclusion with the correct quantifiers? That is not
settled by this existence proof.
