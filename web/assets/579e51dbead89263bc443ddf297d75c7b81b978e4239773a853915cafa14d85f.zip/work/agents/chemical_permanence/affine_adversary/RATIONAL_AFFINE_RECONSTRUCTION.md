# Rational finite affine families: reconstruction and adversarial scope

Source inspected: `../sources/endotactic_permanence.tex`, Lemma `lem:affine`, Corollary `cor:activity`, Proposition `prop:plateau`, Sections 2–5; and `../sources/OA149-affine.tex`, `OA149-trapping.tex`, `OA149-permanence.tex`.

Pinned primary source: https://github.com/openai/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026 . N33 candidate source is the supplied Astra P package, `outputs/endotactic_permanence.tex`.

## Audit outcome at the original interface

The finite-family activity and global compact plateau arguments survive my line-by-line adversarial reconstruction. The local type-k comparison uses only strict limiting exponent gaps; the diagonal closedness argument for limiting activity retains actual active points and does not assume offset continuity. The finite gluing uses strictly overlapping intervals after pruning containment; both endpoint orders follow from their center order. The plateau uses the least constant label, which is active everywhere on the plateau, then convexity to rule out every point outside the positive box. No nesting of scale plateaux is required.

This is an independent reconstruction, not external acceptance or a formal verification. I have not audited the entire manuscript's consequences or priority.

## The rationality question

The arbitrary-positive-tolerance lemma does **not** by itself imply rational slopes. Fix an irrational point p in a rational cube, and set E(r)=||p-r||∞/2 for every rational r, with any positive values at irrational r (including p). No rational slope can meet ||p-r||∞<E(r). Thus rationality must use the network tolerance's finite rational hyperplane structure.

For the network tolerance it does use that structure. The following strengthened induction gives an existence proof of rational families. It does not provide a useful bound on family size, bit length, or cutoff.

### Rational-family theorem

Let a<b be rational, let D be a finite set of nonzero rational vectors in Q^m, and let η>0 and c_v>0 be rational. Define

    E(r)=min({η} ∪ {|r·v|/c_v : v∈D, r·v≠0}).

There exist a finite nonempty family of slopes r_λ∈Q^m∩[a,b]^m and offsets

    b_λ(h)=−Σ_{j=1}^{n_λ} h^{γ_{λj}},    γ_{λj}∈Q, γ_{λj}>a,

and h_act>0 such that, for 0<h<h_act and p∈[a,b]^m, every label active at X_h(p) satisfies

    ||p−r_λ||∞<E(r_λ).

The empty sum is allowed. Multiple equal exponents are allowed, hence coefficients may be negative integers. The theorem applies to N33 with η=1/2 and c_v=2||v||_1.

### Why fixed-h perturbation is insufficient

A label's activity can change at arbitrarily small h after a tiny slope perturbation. One therefore cannot obtain this theorem by rationalizing the delivered affine family separately at one fixed h. The construction below instead chooses a family stable under a joint parameter perturbation as h tends to zero. Preserving zero products is essential: E jumps upwards at a comparison hyperplane.

## Strengthened induction with moving parameters

The induction permits external real parameters z. Cube endpoints a(z)<b(z) and the finitely many comparison forms ℓ_j(s,z) are rational affine functions of their arguments. Positive denominators and η are fixed rational numbers. The tolerance is

    E_z(s)=min({η} ∪ {|ℓ_j(s,z)|/c_j : ℓ_j(s,z)≠0}).

This extension is needed because lifting a lower-dimensional slope replaces off-U entries by a varying parent center t, so a homogeneous comparison r·v becomes affine in the lower-dimensional slope s and t. Denominators remain fixed.

A finite construction has a finite parameter vector θ: all local centers t, thresholds β, and gluing cuts q appearing at all depths. A coordinate of every slope is one of these center variables or an external endpoint. Offsets are finite negative sums of powers whose exponents are threshold or cut variables. Thus all coordinates and power exponents are rational affine expressions in (z,θ).

At a base real parameter vector (z⁰,θ⁰), impose the following rational affine equalities:

1. Every shared-variable/lift identity in the finite construction.
2. Every cube-boundary equality holding at the base, such as a chosen center t=a(z) or t=b(z).
3. Every zero comparison ℓ_j(r_λ(z⁰,θ⁰),z⁰)=0, for every slope at every node of the finite selected construction tree, including local baselines and recursively lifted slopes. Form the final equality system by taking the union of each selected child's complete allowed system and pulling it back through its parent-variable substitutions. Preserving only the final root slopes' zeros is not the stipulated system; no counterexample to a carefully implemented root-only representation is claimed, since descendant zeros may already be inherited by lifted root labels. Local families unused by the finite subcover are not in this finite tree and introduce no constraints.
4. Equalities between power exponents at the base, if the same exponent occurs in different roles.

The equality coefficients are rational. All remaining domain, threshold, cut, and exponent-gap conditions are strict at the base. They hold throughout a sufficiently small relative neighborhood of the base. Every originally nonzero comparison retains its sign there; every originally zero comparison remains zero by item 3. Hence

    E_{zⁿ}(r_λ(zⁿ,θⁿ)) → E_{z⁰}(r_λ(z⁰,θ⁰))

whenever allowed parameter vectors converge to the base.

The strengthened conclusion is the following sequential stability statement:

    If (zⁿ,θⁿ)→(z⁰,θ⁰) within these equalities and the preserved strict
    conditions, h_n→0, pⁿ→p∈[a(z⁰),b(z⁰)]^m, and a fixed label λ is
    active in the perturbed family at X_{h_n}(pⁿ), then
    ||p−r_λ(z⁰,θ⁰)||∞ < E_{z⁰}(r_λ(z⁰,θ⁰)).

The approximating pⁿ may lie outside the cube. We construct a family satisfying this strengthened conclusion; it is not asserted for every family supplied by the original lemma.

### Local fixed-minimum construction

Fix the base t∈[a,b]. The singleton baseline has slope t·1 and offset 0. For m=1, or t=b, it has the strengthened local property on μ(p)=t, since p=t·1. If t=b, preserve this boundary equality under perturbation. Include the zero comparison equalities for this baseline.

For m>1 and t<b, choose β_k exactly as in the original proof:

    t<β_k<b,  β_k<β_{k−1},  β_k−t<E(r)

for every previously constructed type-(k−1) slope. The inequalities are strict. For each |U|=k, apply the strengthened induction in dimension k to [β_k,b]^U and the lifted tolerance E_z(r(s,t)), with t and β_k included among the external parameters. Lift each resulting label to slope r(s,t) and offset

    −h^{β_k}+d(h),  d(h)=−Σ h^γ,  γ>β_k.

The finite set of strict gaps γ−β_k at the base has a positive minimum. Consequently, uniformly for sufficiently near allowed parameter vectors,

    d_n(h_n)/h_n^{β_k^n}→0.

This is the required uniform little-o fact; pointwise little-o at each perturbed parameter would not suffice.

Suppose a perturbed type-k label is active, parameters converge to the base, and pⁿ→p with μ(p)=t. Comparison with the perturbed baseline gives

    Σ_{i∈U}(r_i^n−t_n)h_n^{p_i^n}
       ≤ h_n^{β_k^n}−d_n(h_n)=(1+o(1))h_n^{β_k^n}.

All coefficients are bounded below by a fixed positive number. If p_i<β_k at the limit, then p_i^n−β_k^n is eventually bounded above by a fixed negative number, and the corresponding ratio diverges. Therefore p_i≥β_k on U.

Activity restricted to labels lifted on that same U is exactly lower-dimensional activity: all off-U contributions and −h^{β_k^n} are shared. The strengthened lower-dimensional induction gives the strict tolerance bound on U, evaluated at the limiting lifted slope and limiting external parameters.

If k<m−1 and an unraised coordinate satisfies p_j>β_{k+1}, choose a type-(k+1) competitor raised on U∪{j}. All limiting exponents on this set are strictly greater than β_{k+1}. Its excess above the perturbed baseline is

    −h_n^{β_{k+1}^n}+o(h_n^{β_{k+1}^n}).

The putative active label's excess is 0 for k=0 and at least

    −h_n^{β_k^n}+o(h_n^{β_k^n})

otherwise. The strict limiting gap β_k−β_{k+1}>0 makes the competitor smaller eventually. Thus p_j≤β_{k+1}. The preserved strict base inequality β_{k+1}−t<E(r) bounds every off-U error. If k=m−1, the one unraised coordinate equals t because μ(p)=t and every raised coordinate exceeds t. This proves the strengthened local property.

### Neighborhood extension: the necessary modification

For a fixed label λ in this local tree, define A*_{λ,t} to consist of limits p in the base cube of sequences of actual active points for which both h_n→0 and allowed local-tree parameters converge to their base values. This is closed: for p_j→p, select one actual witnessing point with h<1/j, parameter distance<1/j, and point distance<1/j from p_j. The selected diagonal sequence witnesses p.

The finite union

    B*_t=⋃_λ {p∈A*_{λ,t}: ||p−r_λ⁰||∞≥E(r_λ⁰)}

is compact. The strengthened local proof excludes every point with μ(p)=t. Therefore there is ρ_t>0 such that no point of B*_t has μ(p)∈(t−ρ_t,t+ρ_t). Shrink ρ_t so that all nonzero local offset power exponents at the base exceed t+ρ_t by a fixed positive amount.

This is precisely where the original proof must be strengthened. Using its bad limit set with parameters fixed would leave the rationality argument unproved. The larger A* set handles all permitted parameter perturbations at once.

### Finite gluing under perturbation

Take a finite subcover of [a,b] by the resulting intervals I_t. Prune containment and order centers. Choose cuts q_j strictly as in the original proof, so

    t_j<q_j<t_{j+1},   [q_{j−1},q_j]⊂I_{t_j}.

All chosen containment margins are strict. Include the selected trees, cuts, and any endpoint equalities in the final parameter vector. Shift family j by −Σ_{ℓ<j}h^{q_ℓ}.

The radii ρ_t are auxiliary base constants, not output parameters. They may remain irrational. The limiting proof below uses the original base intervals and their strict containment margins; it never assumes a newly perturbed family's own bad set has the same radius. Thus rationality is required only of slope/exponent parameters and the rational equality system, not of these auxiliary compactness radii.

For an active perturbed label in family j, let the parameters tend to their base values and pⁿ→p. If μ(p)>q_j at the limit, subtract the perturbed next baseline. The difference is

    (r^n−t_{j+1}^n·1)·X_{h_n}(pⁿ)+c_n(h_n)+h_n^{q_j^n}
       = h_n^{q_j^n}(1+o(1))>0.

All limiting coordinate exponents exceed q_j; local offset exponents exceed q_j by a fixed limiting gap. If μ(p)<q_{j−1}, subtract the perturbed previous baseline. Every coordinate coefficient has a fixed positive lower bound, one coordinate exponent is strictly below q_{j−1}, and the local offset is uniformly o(h_n^{q_{j−1}^n}). Dividing by h_n^{q_{j−1}^n} gives +∞. Both cases contradict activity.

Thus q_{j−1}≤μ(p)≤q_j at the base. The limiting minimum belongs to I_{t_j}; perturbed global activity implies perturbed local activity, so the enlarged bad-set guarantee gives the strict bound. This proves the strengthened induction.

## Rational perturbation and quantifiers

Return to the root cube with rational a,b, no external parameters, and rational D. The accumulated equalities form a rational affine system with a real solution θ⁰. Its solution space has a rational particular solution and rational basis, so rational points are dense in it. Preserve every base equality, and take a rational parameter vector in a sufficiently small relative neighborhood. All remaining finitely many strict construction conditions survive.

Why there is one such neighborhood and one all-small-h cutoff: if this failed, there would be allowed θⁿ→θ⁰, h_n→0, pⁿ in the rational root cube, and fixed active labels after subselection, violating

    ||pⁿ−r_λ(θⁿ)||∞<E(r_λ(θⁿ)).

Compactness gives pⁿ→p. Preserved zero products imply E(r_λ(θⁿ))→E(r_λ(θ⁰)). The violating weak inequality passes to the limit, contradicting the strengthened sequential conclusion. Therefore some δ>0 and h_act>0 work for every allowed θ with ||θ−θ⁰||<δ and every 0<h<h_act. Choose a rational θ there.

The resulting family has rational slopes and rational power exponents, and the original activity implication at every sufficiently small h. The final rational h cutoff can be chosen smaller than the real cutoff. This suffices to re-run the original weighted drift and plateau proof. Its H, L, M are rational for integer/rational exponent diagrams, and c may be rational when a rational positive class representative is supplied.

This proof is existential and supplies **no numerical bound** on the rational neighborhood, number of labels, denominator, or exponent height. An exhaustive rational enumeration plus an independently sound universal verifier may acquire a witness, with no useful running-time bound asserted.

## Failure ledger / exact remaining checks

* The general arbitrary E lemma cannot be rationalized: explicit irrational-p counterexample above.
* Independent rationalization at a fixed h does not establish an all-small-h certificate.
* Rationalizing slopes without preserving zero r·v products invalidates continuity of E.
* Reusing the delivered fixed-parameter B_t rather than enlarged B*_t leaves a logical gap.
* The strengthened induction must permit moving cube endpoints and external affine tolerance parameters; otherwise recursive lifts are not covered.
* Every offset little-o must come from finitely many preserved strictly positive exponent gaps; a merely pointwise little-o interface would not justify joint perturbation.
* Root's QE verifier still needs an exact encoding and a completeness audit. This note does not prove that encoding sound or complete.

Strongest next attack: independently audit the rational-affine proof-tree formulation, especially the merged zero-product constraints and the enlarged diagonal A* compactness. If they survive, audit the QE witness conditions themselves rather than infer a compiler from a generic semialgebraic claim.

## Exact one-dimensional consistency check

For the network tolerance in dimension one, E(r)=|r|/2 at r≠0 and E(0)=1/2 on [−1,1]. Take ordered rational slopes

    r=(−1, −1/2, 0, 1/2, 1)

and rational cuts

    q=(−2/3, −1/3, 1/3, 2/3).

Set b_j(h)=−Σ_{ℓ<j}h^{q_ℓ}. Consecutive affine branches intersect at x=2h^{q_j}; their p-coordinates are q_j−log(2)/|log(h)|. Ordered intersections make each branch active precisely between its consecutive intersections (with ties retained). For h<2^(−12), log(2)/|log(h)|<1/12. The active exponent ranges then lie strictly inside the respective balls of radii E(r_j), including at every tie. This is an exact elementary instance of rational slopes/power exponents; it is a consistency check, not evidence for the general induction.
