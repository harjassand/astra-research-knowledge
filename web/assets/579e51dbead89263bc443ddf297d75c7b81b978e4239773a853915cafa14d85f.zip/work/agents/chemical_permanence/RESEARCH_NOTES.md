# Chemical permanence audit and consequence attacks

Source snapshots: shared `work/repository/astra_commit.txt` and `openai_commit.txt`; source URLs below. All permanence conclusions presently depend on the reconstructed N33 affine-geometry theorem. Internal audit is not external validation or priority clearance.

## Independent reconstruction completed

N33 `sources/endotactic_permanence.tex`, `lem:drift`, `prop:plateau`, `lem:neutral`, `lem:chain`, `prop:entry`, `sec:absorption`:

For active slope r, a minimum essential source w in direction -r has r.nu>=2H. Every negative reaction has source above w, so x^u<=h^H x^w. Thus r.f>=x^w(2κH-KLh^H)>=κH h^M. The weights r.nu are indispensable. For r orthogonal to S all flux terms vanish. A neutral slope cannot be active below the global plateau on c+S. The finite affine minimum has the a.e. chain rule, giving finite entry on a box. Initial points lie on a sufficiently small plateau; nonnested square-root scale iteration gives a common absorber on unbounded classes. No gap found in these steps; affine lemma independently delegated for adversarial review.

## Target 1: global constructive recognition

Input: rational nonnegative integer actual complexes, rational positive rate interval, rational positive class representative c. A finite family of rational slopes and rational-Puiseux offsets would permit checking *all scales* via quantifier elimination over real closed fields after h=z^q. Certificate includes global compact plateau, central-box coverage, and active-slope drift throughout B_h. The crucial unresolved improvement over N34 is rational all-scale family existence; fixed-scale rationalization is insufficient. A strengthened joint-parameter stability proof of the affine induction is being attacked independently.

## Target 2: equal-diffusion spatial permanence

Proposed rigorous conditional extension: bounded connected smooth domain, homogeneous Neumann conditions, SAME scalar diffusion D>0 for every species, actual finite endotactic reactions with rates within [κ,K]. For positive continuous initial profiles whose mean lies in c+S, one global positive compact convex concentration range K_hP (not pointwise K_hP∩(c+S)) eventually contains every spatial concentration. Conserved projections r.u, r∈Sperp, solve heat and converge uniformly to r.c. At c each nonzero neutral label has strict slack over plateau; after finite heat homogenization these labels cannot be active below plateau. Max affine deficit is decreased at rate δ_h by reaction; common diffusion satisfies the scalar maximum principle. A finite scale chain reaches the final range. If each point initially lies in c+S, no homogenization wait is needed and the waiting bound is independent of domain, mesh, and diffusion size.

Scope: finite entry into an invariant *concentration range*. Infinite-dimensional profile set is bounded, not automatically compact in C. Conservation fields homogenize only asymptotically, so exact pointwise class entry is not asserted. Unequal diffusion does not satisfy the affine maximum-principle identity. For merely measurable rates use integrated maximum principle or approximation; never all-times Dini derivatives.

## Failure ledger

- General endotactic global attraction to one equilibrium is false; weakly reversible planar deficiency-one mass-action systems can oscillate. Primary example literature: Boros and Hofbauer, https://pmc.ncbi.nlm.nih.gov/articles/PMC10901957/ .
- Deterministic permanence does not imply stochastic nonexplosion, positive recurrence, or all-time survival. Primary source: Anderson et al., tier structure strongly endotactic, https://doi.org/10.1016/j.spa.2020.07.012 . Strongly endotactic stochastic models can even explode.
- N35 finite-horizon molecular safety does not yield PDE permanence under mesh refinement: exponential safety exponent degrades as O(V h^4). Our PDE argument is deterministic and uses a common diffusion operator.
- Rational all-scale parameter approximation cannot be inferred from N34's strict fixed-scale rationalization.

## Primary sources read or located

- https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/web/pages/d-326696af15b5e02b.html (complete N33 TeX source)
- https://raw.githubusercontent.com/openai/math/main/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/build/sections/affine.tex (OA149 affine lemma)
- https://raw.githubusercontent.com/openai/math/main/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/build/sections/permanence.tex
- Craciun–Deshpande 2020, endotactic embedding in toric differential inclusions: https://arxiv.org/abs/1906.08384
- Gopalkrishnan–Miller–Shiu, geometric GAC, strongly endotactic permanence: https://people.tamu.edu/~annejls/geometricGAC.pdf
- Equal-diffusion convex Lyapunov/global-existence mechanisms have classical antecedents; quoted author manuscript survey https://oaktrust.library.tamu.edu/server/api/core/bitstreams/39708dc7-b9df-4036-bc20-6a3ec5245205/content . No novelty claim for the maximum-principle mechanism.
