# Chemical permanence: reconstructed bottleneck and new consequence package

**Outcome:** two serious targets were directly attacked. The global constructive-recognition target now has a full mathematical candidate proof plus an exact acquired/replayed certificate on a genuinely unbounded two-dimensional class. The spatial target has a full conditional common-diffusion permanence proof and an entropy-attraction escalation; generic unequal-diffusion permanence remains unresolved.

This is internal mathematical work, not external correctness, formal proof, or priority certification. No simulation, model consensus, or finite fixture is offered as a general theorem. No general CAD compiler was implemented.

## Load-bearing source audit

N33 complete supplied TeX was retrieved selectively from its exact HTML source. OA149 affine/trapping/permanence TeX was retrieved. Five decisive originals were subsequently re-fetched at the shared pinned commits and matched byte for byte; see `SOURCE_PROVENANCE.json`.

Source `sources/endotactic_permanence.tex`: affine activity Lemma at line 162; weighted essential-source drift at line 462; global plateau at 538; neutral exclusion at 574; entry at 619; nonnested global absorption at 679. I independently reconstructed drift, plateau, a.e. affine-min chain rule, and scale iteration. The affine adversary reconstructed the discontinuous-tolerance gluing and plateau proof, then a separate critic reviewed the new rationality argument. No specific substantive gap was found in the assigned chain. This is not external validation of the upstream claimed Extended Permanence theorem.

The actual changed premise is the fixed finite affine family with strict ratebox-uniform projected drift: r.f≥κHh^M for every active r outside S^⊥, while neutral slopes vanish. Mere deterministic permanence or a local facet certificate would not supply either new target.

## Target 1: acquired global certificates on unbounded classes

`GLOBAL_RECOGNIZER.md` contains the exact input/output contract, finite all-scale obligations, direct soundness proof, real-closed-field encoding, completeness composition, and charged exhaustive acquisition procedure.

Input: rational actual integer chemical complexes, rational positive rate box, rational positive class representative; promised endotactic diagram. Output: rational compact convex common absorber even if the positive class is unbounded; exact finite entry-bound procedure for rational initial points. Search is only a positive semidecision outside the endotactic promise. Budget exhaustion is UNKNOWN. No polynomial time, certificate-size, bit-height, or useful runtime bound is claimed.

The novel proof bottleneck was rational *all-scale* affine existence, not N34's already established fixed-scale rationalization. `affine_adversary/RATIONAL_AFFINE_RECONSTRUCTION.md` strengthens the affine induction to allow every proof-tree parameter to move jointly with h→0; enlarged compact active-limit sets then guarantee robust neighborhoods. Preserve all recursive rational linear zero-product/structural/boundary equalities. Rational points are dense in that full affine equality space, and the tolerance is continuous on the preserved zero strata. The finite uniform exponent gaps control all little-o terms. Rational slopes and rational-Puiseux offsets follow.

`affine_adversary/rationalization_critic/AUDIT.md` independently reviewed that reconstruction; `affine_adversary/AUDIT_RECOGNIZER.md` reviews the downstream certificate encoding and example; its final audit found no actual mismatch at the stated interface.

After h=z^q, the all-scale obligations are rational polynomial/Laurent-polynomial statements. Positive z powers clear Laurent denominators. Exact quantifier elimination can decide every candidate. Rational all-scale existence implies exhaustive acquisition halts for every promised rational endotactic input. The proof closes the previously named unbounded all-scale recognition gap at the level of computability, subject to the full internal proof candidate surviving external review.

Concrete execution: `acquire_two_linkage.py` searched a supplied rational five-facet *ansatz*, varying all intercept multipliers, one facet slope weight, scale cap and drift margin; first exact accepted certificate occurred after 4,850 checks. Network A⇌2B, B⇌2A, independent rates [1,4], S=R² (determinant −3), so the entire positive orthant is an unbounded class. Certificate:

    F_z=min{0,x−2z²,y−2z²,(3/4)(x+y−7z²),(1/3)z^{-2}−x−y},
    0<z≤1/8,  h=z⁴,  active nonzero slope drift≥(1/2)z⁴.

Final absorber:

    x,y≥1/32,   7/64≤x+y≤64/3.

`TWO_LINKAGE_PROOF.md` directly proves the continuous all-scale inequalities from actual stoichiometry, independently of N33. `two_linkage_certificate.json` is the acquired witness. The exact script and its `--verify` replay were run, then copied/replayed independently in the affine adversary's directory with identical result. Margins: 1/6, 27/32, 1280/9. A rejected altered candidate B=2 has an exact outward witness at x=y=1/32, rates (4,1,1,4), f_x=−71/1024. `VALIDATION.json` records these scopes. This execution does not validate general compiler completeness.

## Target 2: spatial permanence and attraction

`pde_adversary/REPORT.md` proves, conditional on the reconstructed finite affine family, common scalar diffusion PDE permanence on bounded connected smooth domains with Neumann conditions, arbitrary spatially/time-varying measurable ratebox rates and uniformly positive continuous initial profiles. Initial mean lies in c+S. One common positive compact *concentration range* K_hP eventually contains every spatial state. It depends only on network/ratebox/mean class, not on diffusion magnitude, domain, initial profile, or rate path; waiting time can depend on initial profile and heat mixing.

The proof uses finite-max Kato comparison for z=M_h−F_h(u): common scalar diffusion is dissipative, while reaction gives −δ_h on {z>0} once nonzero neutral labels are excluded. Each neutral projection r.u solves the scalar heat equation and converges to r.c. Every such label has strict finite slack at c because all labels active at c have slope zero. A finite heat wait followed by the nonnested square-root scale chain gives entry ≤T_*+ΣW_hj. If initial states lie pointwise in c+S, T_*=0 and the entry bound is independent of diffusion/domain.

Exact scope correction: the absorbing range is the full K_hP, not K_hP∩(c+S). Conserved projections homogenize asymptotically, so exact finite pointwise class entry is false. The explicit A⇌B heat-mode counterexample in the audit demonstrates this.

`EXPONENTIAL_ATTRACTION.md` escalates the result for fixed homogeneous complex-balanced rates. Once the positive range is obtained, entropy dissipation controls the S-projected log concentrations; diffusion/Poincaré controls their spatial fluctuations; mean conservation controls the neutral mean log component by strict monotonicity of exp. This yields H≤C(D_R+D_D), hence entropy and L² exponential convergence to the homogeneous complex-balanced equilibrium. No assumption excluding boundary equilibria is needed because the positive range supplies coercivity. The entropy mechanism is standard and exact matching prior-art status remains unresolved.

## Unequal diffusion: progress and exact remaining obstacle

`pde_adversary/UNEQUAL_DIFFUSION.md` supplies two nontrivial sufficient extensions.

1. **Relative-reaction bridge:** given a global uniform upper bound U and |f_i/u_i|≤A_i, scalar heat-kernel comparison gives α_i mean_i≤u_i≤β_i mean_i after fixed warm-up. Exact mean effective rates avg(k_eu^y)/mean(u)^y are then bounded above and below. N33 mean permanence gives pointwise permanence for arbitrary D_i>0. A chemical syntactic sufficient condition is ν_e,i≠0⇒y_e,i≥1. This does not acquire U.
2. **Compatible normals:** if each potentially active affine slope r_λ is a left eigenvector of the diffusion matrix with positive eigenvalue, its projection obeys one scalar diffusion equation, recovering max-principle absorption. For distinct diagonal diffusivities the permitted facets are coordinate aligned; equal-diffusivity blocks permit oblique facets within each block. Invariance-only facet compatibility is insufficient for the global absorption chain because nonfacet labels can control drift away from the plateau.

Generic bounded loss plus bounded additive production does not justify own-species sup/mean comparability. A precise scalar bounded-source pulse example keeps v positive globally≤1 while sup(v)/mean(v)→∞. This refutes the analytic inference, not the arbitrary fixed-endotactic PDE theorem. The missing network-specific estimate is relative production/spatial correlation control; a generic global upper bound alone does not supply it by the proposed argument. Arbitrary unequal diffusion and arbitrary endotactic diagrams remain unresolved, as does acquisition of generic global PDE bounds.

## Prior art and limitations

- Endotactic toric-differential-inclusion embedding: Craciun–Deshpande, https://arxiv.org/abs/1906.08384 . Strongly endotactic permanence predates this update: Gopalkrishnan–Miller–Shiu, https://people.tamu.edu/~annejls/geometricGAC.pdf .
- Common-diffusion convex invariant regions are classical: Chueh–Conley–Smoller 1977, https://iumj.org/article/2645/ . The new composition is the all-endotactic strict affine family plus neutral heat homogenization.
- Complex-balanced entropy methods and selected boundary-equilibrium cases: Desvillettes–Fellner–Tang, https://arxiv.org/abs/1604.04536 .
- Deterministic permanence cannot establish stochastic recurrence/nonexplosion; strongly endotactic stochastic systems can be transient or explosive: https://doi.org/10.1016/j.spa.2020.07.012 . N35 remains finite-horizon acquired-certificate safety.
- Arbitrary endotactic global attraction to one equilibrium is false; weakly reversible planar deficiency-one oscillators exist: https://pmc.ncbi.nlm.nih.gov/articles/PMC10901957/ .

Strongest next attacks: formal or cold external audit of the full rational-affine proof-tree construction and universal compiler obligations; practical exact QE synthesis on a genuinely non-strong endotactic unbounded network; network-specific bounded relative-production estimates for arbitrary unequal diffusion. No historical-calibre breakthrough is asserted.
