# Exact global absorption certificates for unbounded rational classes

**Status:** candidate theorem conditional on the rational affine-family reconstruction in `affine_adversary/RATIONAL_AFFINE_RECONSTRUCTION.md`, itself reconstructed from OA149/N33. Soundness of the certificate format below is proved directly. A general CAD/QE implementation has not been written or run. No efficiency bound or novelty clearance is claimed.

## Input and output

Input: finite actual integer nonnegative reaction complexes y_e→y'_e in Z_{≥0}^d; positive rational κ≤K; positive rational class representative c. Write ν_e=y'_e−y_e and S=span_R{ν_e}. The promised class consists of endotactic diagrams. Rates may be arbitrary measurable paths in [κ,K]. All assertions are classwise for P=(c+S)∩R_{>0}^d; P may be unbounded.

Output: a finite exact rational certificate describing a rational compact convex positive polytope Q_P⊂P, common invariant and absorbing for all admissible rate paths, and a finite algebraic evaluation procedure for an entry bound at any positive rational initial point in P. Enumeration and every QE call are charged; no polynomial running time, certificate size, bit height, or useful practical bound is supplied.

## Certificate fields

- A positive even integer q.
- Rational z_P∈(0,1), η∈(0,1/2), a>0, with qη an integer, and integer p≥0.
- Finitely many rational slopes r_λ∈Q^d and Laurent polynomials b_λ(z)∈Q[z,z^{-1}].
- One specified zero-slope label λ_0, and M(z)=b_{λ_0}(z).

For 0<z≤z_P set h=z^q,

    L_λ(z,x)=r_λ·x+b_λ(z),
    F_z(x)=min_λ L_λ(z,x),
    B_z=[z^q,z^{-q}]^d,
    Q_z={x∈R^d: L_λ(z,x)≥M(z) for every λ}.

The zero label gives F_z≤M globally, and Q_z={F_z=M}.

## Finite universal verification obligations

For every 0<z≤z_P:

(A) c∈Q_z.

(B) If x∈Q_z, then z^{q/2}<x_i<z^{-q/2} for each i. This quantifies x over all of R^d, not merely over a supplied box. Thus Q_z is nonempty, closed, convex, compact, and positive, and it misses the boundary of B_z.

(C) If z^{qη}≤x_i≤z^{-qη} for every i, then x∈Q_z. These expanding central boxes eventually contain every positive x as z→0.

(D) For each r_λ not orthogonal to S, every x∈B_z at which λ is active (equivalently L_λ≤L_μ for every μ), and every rate vector k∈[κ,K]^R,

    r_λ·Σ_e k_e x^{y_e}ν_e ≥ a z^p.

Orthogonality is tested exactly by r_λ·ν_e=0 for all e; orthogonal slopes give zero derivative identically.

All expressions are Laurent-polynomial in z and polynomial in x,k, with rational coefficients. Since z>0, multiplication by a sufficiently high positive power of z clears Laurent denominators without changing inequality direction. Consequently each obligation is a sentence over the real closed field with rational coefficients and is decidable by a finite exact quantifier-elimination algorithm. Rate quantification can alternatively be replaced by the 2^{|R|} rate-box vertices, since (D) is affine in k. This is an exponential charged option, not a free oracle.

## Direct soundness proof

Let an accepted certificate be fixed. Neutral slopes are inactive below the plateau on P: if r_λ⊥S then L_λ(z,x)=L_λ(z,c)≥M(z) for every x∈c+S, while F_z(x)<M(z) off Q_z. Along an absolutely continuous trajectory in B_z, the finite-affine-min a.e. chain rule gives nonnegative derivative for F_z, and derivative at least a z^p until Q_z is reached.

The plateau is forward invariant: starting at F_z=M, nonnegative drift and F_z≤M force equality while the state remains in B_z; (B) prohibits first exit from B_z. Local Carathéodory continuation on this positive compact set gives a global positive trajectory.

Given x^0∈P, choose 0<z_0≤z_P so that x^0 belongs to the central box in (C). Then x^0∈Q_{z_0} and its trajectory is global and stays there. Iterate

    z_{j+1}=min{sqrt(z_j),z_P}.

By (B), Q_{z_j}⊂int B_{z_{j+1}}. Thus while in Q_{z_j}, the trajectory lies in B_{z_{j+1}} and enters Q_{z_{j+1}} in finite time by strict drift. Repeated square roots reach z_P in finitely many steps. No nesting of Q_z is needed. Therefore Q_P=Q_{z_P}∩(c+S) is the claimed common invariant absorber even for unbounded P.

An explicit scale waiting bound is

    W(z)=[M(z)−min_{x∈B_z}F_z(x)]/(a z^p).

There is an exact finite formula,

    min_{x∈B_z}F_z(x)
      =min_λ[b_λ(z)+Σ_{r_λi≥0}r_λi z^q+Σ_{r_λi<0}r_λi z^{-q}].

The total entry time is at most Σ_{j=1}^N W(z_j). At rational x^0 one can choose rational z_0 by exact comparisons, then every z_j is algebraic and the finite computations are exact real-algebraic computations. At z_P every coefficient defining Q_P is rational.

## Candidate completeness and acquisition

The rational-family reconstruction asserts that, for the network tolerance E(r)=min(1/2, |r·v|/(2||v||_1) over nonzero products), the OA149/N33 affine family can be chosen with rational slopes and finite negative sums of rational powers h^γ. Choose q clearing all exponent denominators and even. These offsets become Laurent polynomials in z after h=z^q.

First select a fixed least constant label: differences between the finitely many rational-Puiseux constant offsets become Laurent polynomials after the substitution and have eventually fixed signs, so one label is least throughout some entire small-z interval. Choose rational η with 0<η<min(H,1/2), enlarge q further so qη∈Z, and set a=κH, p=qM, where H is the finite rational projected margin and M=max_e||y_e||_1 is an integer. Uniform activity implies (C) whenever |log x_i/log h|≤η, because every active slope must then have all coordinates zero: a nonzero coordinate would force |log x_i/log h|≥H. The N33 global-plateau proof gives (A),(B), and its weighted drift gives (D), at every sufficiently small h. Pick rational z_P below the resulting cutoffs. Thus a certificate exists if the rational-family reconstruction is correct.

Enumerate all finite certificate tuples above in increasing finite encoding length, and decide (A)–(D) by exact QE. Return the first accepted tuple. Every individual decision terminates; existence forces the enumeration to terminate on every promised rational endotactic input. Non-endotactic inputs may also yield a genuine certificate, but endless search is not a disproof. A finite resource-limited implementation must return UNKNOWN if its search budget ends.

This would close N34's *all-scale global recognition gap* at the level of computability. It supplies no efficient recognition or synthesis bound. It uses neither an already supplied global-basin certificate nor an uncharged infinite-domain oracle: the global obligations are finitely encoded and decidable.

## Explicit unbounded-class fixture

Network 0⇌A with κ=1,K=4, S=R and c=1. Let h=z^4, 0<z≤1/4,

    F_z(x)=min{0, x−2z², (1/2)z^{-2}−x},
    Q_z=[2z²,(1/2)z^{-2}],
    η=1/4, a=1/2, p=0.

(A) follows from 2z²≤1/8<1<8≤(1/2)z^{-2}. (B) is strict because Q_z lies between 2sqrt(h) and (1/2)/sqrt(h). (C) follows from z≥2z² and z^{-1}≤(1/2)z^{-2} for z≤1/2. At the lower active facet x≤2z², f=k_0−k_1x≥1−8z²≥1/2. At the upper active facet x≥(1/2)z^{-2}, −f=k_1x−k_0≥(1/2)z^{-2}−4≥4≥1/2. Thus (D) is exact for every scale, state, and rate path in the specified intervals. This demonstrates the certificate format on an unbounded positive class; it does not validate completeness for all endotactic networks.
