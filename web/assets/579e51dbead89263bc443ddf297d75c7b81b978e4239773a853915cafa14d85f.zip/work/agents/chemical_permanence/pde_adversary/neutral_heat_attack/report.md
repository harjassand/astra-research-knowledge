# Independent neutral-heat and finite-entry audit

Status: conditional on the supplied finite affine plateau hypotheses, the
proposed pointwise **plateau** absorption argument survives this attack for
strictly positive common diffusion `D > 0`. No assessment of the upstream
N33 affine construction is made here. Exact finite-time absorption into the
ODE *class intersection* is false; a counterexample is given below.

## Conditional hypotheses used

For each scale in a finite chain, write

`L_lambda,h(x) = r_lambda . x + b_lambda(h)`,
`F_h = min_lambda L_lambda,h`, `M_h = F_h(c)`,
`K_h = {F_h = M_h}`.

Use only these supplied properties:

1. The label family is finite; `F_h <= M_h` globally; a zero-slope label has
   constant value `M_h`.
2. `K_h` is a compact positive convex set contained in `int B_sqrt(h)`.
3. Every label active at `c` has zero slope.
4. At every `x in B_h`, every active slope satisfies `r . f >= 0`; if
   `r notin S^perp`, it satisfies `r . f >= delta_h > 0`, uniformly over the
   measurable rate box.
5. The initial profile range is contained in an invariant `K_h0`.

The PDE is `u_t = D Delta u + f(t,xi,u)`, with homogeneous Neumann conditions
on a bounded connected smooth domain, and the same scalar `D > 0` for every
species. Choose `c` in the positive mean stoichiometric class, so
`r.c = mean(r.u0)` for every `r in S^perp`.

## Neutral slack is enough, and is necessarily strict

If `r_lambda in S^perp` and `r_lambda != 0`, property 3 gives

`gamma_lambda,h := L_lambda,h(c) - M_h > 0`.

Equality would make this nonzero slope active at `c`, contradicting that
property. Since the family is finite, there is a positive minimum of these
gaps at each fixed scale whenever such labels exist. No uniform-in-scale
gap is needed.

The scalar projection `v_lambda = r_lambda.u` satisfies exactly

`(v_lambda)_t = D Delta v_lambda`, `partial_n v_lambda = 0`,

because `r_lambda.f = 0` a.e. Its spatial mean is `r_lambda.c`.
Connectedness and `D > 0` imply uniform Neumann heat convergence
`v_lambda(t,.) -> r_lambda.c`. Thus there is a finite time `T_h`, independent
of the rate path, after which

`L_lambda,h(u(t,xi)) >= M_h + gamma_lambda,h/2`

for every nonzero neutral label and every point. Zero-slope labels also
cannot minimize below `M_h`. Consequently every active label at a deficit
point `F_h(u) < M_h` is nonneutral for all `t >= T_h`.

There are finitely many labels and finitely many scales in the square-root
chain, so one may choose `T_* = max_j T_hj < infinity` once, wait in the
initial invariant plateau, and then perform the whole scale chain.

## A weak parabolic proof gives genuine finite entry

At a scale where the full profile remains in `B_h`, define

`z_lambda = M_h - L_lambda,h(u)`,
`z = max_lambda z_lambda = M_h - F_h(u) >= 0`.

Each affine projection satisfies, weakly,

`(partial_t - D Delta) z_lambda = -r_lambda.f`.

The finite-maximum Kato inequality has the useful direction

`(partial_t - D Delta) z <= max_{lambda active at z} (-r_lambda.f)`.

This direction follows from `max(a,b) = (a+b+|a-b|)/2`; the convex kink
contributes a nonpositive distribution after applying `-D Delta`.
Iterating gives the finite-label form, with a convex combination of active
sources on ties. Every active source has the required sign, so ties cause
no issue. Since the reaction term is bounded on the invariant positive
compact range, standard parabolic Sobolev regularity away from `t=0`
justifies Kato for the mild solution even when rates are merely measurable
in both time and space.

After `T_h`, neutral exclusion gives

`(partial_t - D Delta) z <= -delta_h 1_{z>0}`.

At `z=0`, all active projected reaction drifts are nonnegative, so the
right side can be taken as zero there. The Neumann condition passes to the
weak maximum inequality.

Starting at a time `s >= T_h`, put `Z = ||z(s,.)||_infinity` and
`v(t) = (Z - delta_h(t-s))_+`. On the set `{z > v}` before the barrier reaches
zero, `z > 0` and the source of `z-v` is nonpositive. Testing with
`(z-v)_+` proves `z <= v`. Continuity gives `z=0` by `s + Z/delta_h`.
Thereafter the same inequality with the zero barrier proves invariance.
Therefore this is finite entry, not merely asymptotic approach.

One convenient bound is

`W_h = (M_h - min_{x in B_h} F_h(x))/delta_h`.

For the finite square-root chain `h_(j+1)=min(sqrt(h_j),h_P)`, a bound is

`T_entry <= T_* + sum_{j=1}^N W_hj`.

During each waiting and entry stage, the previous invariant plateau lies
in the next box. No nesting of the different plateau sets is assumed.
The final full-space plateau depends only on the supplied diagram/rate
box and the chosen positive representative of the mean class; entry time
also depends on the initial profile, domain, and diffusion.

## Two precise overclaims that fail

### Exact pointwise mean class at finite time

For `A <-> B` with both rate constants 1, take the smooth connected domain
`Omega=(0,pi)`, common `D>0`, and

`u_A(0,xi) = u_B(0,xi) = (1 + epsilon cos xi)/2`, `0<epsilon<1`.

This reversible diagram is endotactic. The solution is exactly

`u_A(t,xi) = u_B(t,xi) = (1 + epsilon exp(-Dt) cos xi)/2`.

The mean representative is `c=(1/2,1/2)`, and `S=span((-1,1))`. The ODE
mean class is `c+S={a+b=1}`. The pointwise sum is
`1 + epsilon exp(-Dt) cos xi`, so the profile does not lie pointwise in
`c+S` at any finite time. Hence finite pointwise entry into
`K_hP intersect (c+S)` is false. Entry into the full-dimensional plateau
`K_hP`, which has strict neutral slack about `c`, remains compatible with
this example. Any statement saying that neutral quantities become
exactly spatially constant after a finite mixing time is also false.

### Zero diffusion

If `D=0` is allowed, neutral quantities never homogenize. For the same
`A <-> B` network, every profile `u_A=u_B=g(xi)>0` is stationary. Profiles
with a fixed spatial mean can have arbitrarily tall narrow continuous
peaks. They cannot all enter a fixed compact pointwise target chosen from
that mean class. Strict `D>0` is essential to this proof and claim.

## Source locations and failure ledger

Supplied source:
`work/agents/chemical_permanence/sources/endotactic_permanence.tex`.
The plateau/active-at-c hypotheses occur at lines 537-570; the ODE neutral
class lemma at lines 573-583; the nonnested scale argument at lines
700-715. The source's finite-compartment invariance corollary at lines
858-917 establishes neither the present heat mixing step nor PDE
absorption. Upstream N33 correctness remains a separate conditional
dependency.

Source provenance is N33 card evidence `d-326696af15b5e02b`, original
relative source `updates/P/package/outputs/endotactic_permanence.tex`,
available from
https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/updates/P/package/outputs/endotactic_permanence.tex .

Attack ledger: finite neutral slack survives; infinitely many neutral
labels could fail but are outside the supplied finite interface;
unbounded mixing delays are allowed because the claim has
initial-dependent entry time; a direct spatial-minimum derivative proof
is insufficiently justified for merely measurable coefficients but the
weak Kato argument repairs it; exact finite pointwise class absorption
and allowing `D=0` have the explicit counterexamples above.

Strongest next attack: review the upstream affine family hypothesis
separately. Under the stated conditional hypotheses, no further
neutral-slack or finite-entry obstruction was found.
