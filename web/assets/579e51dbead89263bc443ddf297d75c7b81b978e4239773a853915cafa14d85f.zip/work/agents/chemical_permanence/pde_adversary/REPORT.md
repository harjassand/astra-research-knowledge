# Conditional common-diffusion permanence: adversarial audit

Status: the proposed implication survives the audit, conditional on the supplied N33 finite-affine plateau hypotheses. This is not an acceptance or independent verification of N33. No counterexample to the correctly scoped PDE implication was found. The measurable-rate maximum principle admits a direct weak proof, so smooth rates are unnecessary.

## Exact input and conclusion

Let Ω be a bounded connected smooth domain in R^m, D>0, and let

    u_t = D Δu + Σ_e k_e(t,ξ) u^{y_e} ν_e,   ∂νu=0.

The diagram is fixed, finite, and endotactic; k_e are jointly measurable with κ≤k_e≤K almost everywhere. Require u0∈C(Ω̄;R^d_{>0}), so all coordinates have a strictly positive minimum on Ω̄. The stoichiometric span is S=span{ν_e}. Fix a positive c and assume the initial spatial mean lies in c+S.

Conditional input from N33: a finite affine family L_{λ,h}(x)=r_λ·x+b_λ(h), F_h=min_λ L_{λ,h}, a scale h_P and constants H,M such that, for every 0<h≤h_P:

1. F_h≤M_h=F_h(c) globally, and K_h={F_h=M_h} is compact convex with K_h⊂int B_{√h}, B_h=[h,h^{-1}]^d.
2. Every active label at c has zero slope.
3. For x∈B_h and every λ active in F_h(x), r_λ·f(t,ξ,x)≥0, and ≥δ_h=κHh^M whenever r_λ∉S^⊥, uniformly over every point in the rate box.
4. Every supplied compact positive initial range fits some K_{h0}, with h0≤h_P.

Then the PDE has a unique global positive mild solution. Its entire spatial range remains in K_{h0}. There is finite T(u0,D,Ω) such that range(u(t,·))⊂K_{h_P} for every t≥T. K_{h_P} depends only on the diagram, rate box, and chosen positive representative of the mean class, and does not depend on D, Ω, u0, or the rate path.

The set of profiles that is invariant and absorbing in the fixed mean class is

    {v∈C(Ω̄;R^d): range(v)⊂K_{h_P},  mean(v)−c∈S}.

Do not replace its range constraint by range(v)⊂K_{h_P}∩(c+S). The latter is generally false in finite time.

Theorem locations in the supplied source: `sources/endotactic_permanence.tex`, Lemma `lem:drift` (weighted essential-source drift, around line 473), Proposition `prop:plateau` (global compact plateau, around line 537), Lemma `lem:neutral` (classwise neutral exclusion, line 573), Proposition `prop:entry` (finite entry, around line 619), Section `sec:absorption` (finite scale chain, around line 680), and Corollary `cor:transport` (common-species finite transport, around line 859). These upstream hypotheses remain conditional.

## Weak maximum principle, including merely measurable rates

At a fixed scale, on any time interval where range(u)⊂B_h, define

    z_h(t,ξ)=M_h−F_h(u(t,ξ))=max_λ [M_h−L_{λ,h}(u(t,ξ))] ≥ 0,
    Z_h(t)=||z_h(t,·)||∞.

The finite-max Kato inequality gives

    (∂t−DΔ) z_h ≤ 0,   ∂ν z_h=0,

in the weak subsolution sense. Here is a direct proof. Each affine projected deficit v_λ=M_h−L_{λ,h}(u) solves

    (∂t−DΔ)v_λ = −r_λ·f(t,ξ,u).

Apply the scalar chain rule to the smooth convex maximum

    z_ε=ε log Σ_λ exp(v_λ/ε).

Its heat operator equals the softmax average of the affine right sides minus D times a nonnegative gradient-variance term. As ε↓0, z_ε→max v_λ uniformly, and the softmax weights concentrate on labels active in F_h(u). The right sides are uniformly bounded on B_h. Dominated convergence and the active-slope inequalities yield the displayed weak inequality. The Neumann condition passes because every affine projection has homogeneous Neumann data. This calculation may first be made for smooth solutions and then passed by standard local parabolic regularity/approximation; bounded measurable forcing gives the needed weak regularity on every interval away from t=0.

Consequently Z_h is nonincreasing while range(u)⊂B_h. If initially range(u)⊂K_h, then z_h(0)=0 and comparison with zero forces z_h=0. Since K_h lies strictly inside the positive box, the standard first-exit argument and local mild-solution continuation prove global invariance and positivity. The reaction map is uniformly locally Lipschitz and bounded on a neighborhood of this compact positive set, including for real or negative powers.

Suppose additionally that every nonzero neutral label r_λ∈S^⊥ satisfies L_{λ,h}(u(t,ξ))>M_h throughout the time interval. At every point with z_h>0, no neutral label is active. At points with z_h=0, all active reaction projections still have the nonnegative sign. Therefore the same Kato proof gives

    (∂t−DΔ) z_h ≤ −δ_h 1_{z_h>0}.

Comparison with the spatially constant barrier

    w(t)=[Z_h(s)−δ_h(t−s)]_+

gives Z_h(t)≤w(t). One can verify comparison without appealing to a discontinuous-source theorem: test the difference against (z_h−w)_+; wherever z_h>w≥0, z_h>0, and the difference of right sides is nonpositive. Initial positive part is zero. Thus exact entry occurs by s+Z_h(s)/δ_h, bounded above by

    s+W_h,   W_h=[M_h−min_{x∈B_h}F_h(x)]/δ_h.

The all-times upper Dini inequality D^+Z_h≤−δ_h when Z_h>0 follows from this integrated comparison. A naive evaluation of u_t or k_e at every time is not valid for merely measurable rates; the weak proof establishes the stronger integrated statement instead.

## Neutral heat modes and the finite chain

For every r∈S^⊥, q_r=r·u satisfies the scalar homogeneous Neumann heat equation because r·f=0. Thus

    r·u(t)=P_t(r·u0),
    mean(r·u0)=r·c,
    ||r·u(t)−r·c||∞→0.

Connectedness, D>0, and Neumann heat mixing are the precise reasons the last assertion holds. No spatial homogeneity of rates is used.

For each nonzero neutral label and every chain scale, the slack

    σ_{λ,h}=L_{λ,h}(c)−M_h

is strictly positive: equality would make that nonzero slope active at c, contrary to input 2. The labels and the chosen chain are finite, so their minimum slack is positive. Therefore choose a finite T_* such that all neutral projection errors are at most half their respective slack for every t≥T_*.

Choose h0 with range(u0)⊂K_{h0}, and h_{j+1}=min{√h_j,h_P}. The chain reaches h_P in finitely many transitions N. Initial K_{h0} invariance gives global existence before T_*. The inner-box property yields K_{h_j}⊂B_{h_{j+1}}. Beginning at T_*, apply the preceding entry comparison successively and use invariance after each entry. This proves

    T_entry ≤ T_* + Σ_{j=1}^N W_{h_j}.

For N=0 the initial range is already in the final plateau and T_entry=0. If no nonzero neutral label exists, take T_*=0. If S={0}, after heat mixing all affine inequalities already hold, so the strict reaction step is vacuous; the conclusion still holds.

If u0(ξ)−c∈S for every ξ, all neutral projections are exactly constant from time zero. Hence T_*=0, and the finite entry bound depends on the initial range and N33 constants but is independent of D and Ω. This pointwise-common-class version also permits D=0.

For a supplied compact positive initial range Q, h0 can be chosen uniformly for Q. Standard heat contraction/mixing estimates bound T_* uniformly over all profiles with range⊂Q and mean in c+S. Thus the conclusion is uniform over that entire initial-range family, not just one profile.

## Sharp scope failures

1. **Finite pointwise entry into the affine mean class is false.** On Ω=(0,π), take A⇌B with both rates 1, S=span{(-1,1)}, c=(1/2,1/2), and

       u_A(t,ξ)=u_B(t,ξ)=(1+ε e^{−Dt} cos ξ)/2,   0<ε<1.

   Reaction vanishes identically and this is an exact positive Neumann solution. The mean equals c. Yet u_A+u_B is nonconstant at every finite t, so u(t,ξ) is not pointwise in c+S. The proposed full-plateau conclusion is not contradicted.

2. **Without mixing, fixed mean is insufficient.** With D=0, the same A⇌B diagram has every positive profile with u_A=u_B stationary. A fixed mean allows arbitrarily small minima (and arbitrarily high narrow peaks). No compact positive plateau depending only on that mean can absorb every such profile. A disconnected Neumann domain likewise permits nonhomogenizing componentwise neutral means.

3. **Different species diffusion is outside this proof.** For unequal D_i, an oblique projection r·u no longer solves the same scalar heat equation, and the convex-max diffusion inequality has no sign. This is a failure of the proof interface, not a proof that all unequal-diffusion permanence statements are false.

4. **Uniform initial positivity matters for the stated power-law interface.** Merely being positive inside Ω while tending to zero on the boundary does not give an initial compact positive range; negative exponents can also obstruct initial well-posedness. The safe statement uses C(Ω̄;R^d_{>0}) or bounded initial data with an essential positive lower bound.

5. **No convergence or uniqueness of a steady state is implied.** Spatially heterogeneous rate paths can maintain spatial variation and temporal oscillation inside the plateau.

## Strongest clean extensions

The argument depends on common transport, convexity, constant preservation, and mixing of the finitely many neutral projections. It therefore extends to a common scalar uniformly elliptic Markov diffusion/advection operator with reflecting boundary, provided its scalar semigroup converges uniformly to the invariant mean. With an invariant probability measure μ, replace ordinary spatial mean by μ-mean. Reversibility is unnecessary. The abstract clean version uses a common positivity-preserving constant-preserving Feller semigroup P_t on a compact state space, with uniform convergence P_t q→∫q dμ for the finitely many neutral initial projections; reaction maps must satisfy the same bounded/Lipschitz and affine drift hypotheses. Convexity preserves the plateaux under transport, and common affine projections evolve exactly under P_t.

Finite spatially and temporally varying convex mixtures/switching among endotactic diagrams with the same S are also covered, using N33's common affine family and uniform per-mode drift. No dwell-time or positive lower mixture weights are required. Without a common span, only the initial-range invariant-trap statement transfers; common absorption requires an additional uniformly active span/drift hypothesis.

For constant D replaced by D(t)≥0, the Neumann neutral formula uses heat time ∫_0^t D(s)ds. Divergence of this heat time suffices for mean-class homogenization; a positive constant lower bound is unnecessary. For pointwise-common-class data, no homogenization is required.

A further immediate conditional consequence is a positive time-periodic PDE solution when the spatial rate field is periodic in time. The period map on the closed convex profile set {range⊂K_hP, mean−c∈S} is continuous, compact by parabolic smoothing, and invariant; Schauder supplies a fixed point. This gives existence only, not uniqueness or attraction.

## Prior-art and provenance boundary

The equal-diffusion convex-invariant-region principle is classical, not a new mechanism. Primary reference: K. N. Chueh, C. Conley and J. Smoller, *Positively Invariant Regions for Systems of Nonlinear Diffusion Equations*, Indiana Univ. Math. J. 26 (1977), 373–392, DOI 10.1512/iumj.1977.26.26029. Official publisher record: https://iumj.org/article/2645/ ; official opening-page PDF: https://iumj.s3-us-west-2.amazonaws.com/abstracts/26029_abs.pdf . The publisher metadata and opening-page description were retrieved, but the complete paper was not acquired during this audit; no exact old theorem is used as a black box here.

The prospective new deduction is the composition of N33's conditional all-endotactic finite-affine strict drift and nonnested absorption chain with neutral-mode heat homogenization. The finite-max parabolic argument itself is standard maximum-principle technology. Literature searches for the exact all-endotactic robust common-diffusion PDE statement did not locate a primary matching theorem, but this is not priority clearance.

Independent adversarial subaudit: `neutral_heat_attack/report.md`. Its exact A⇌B example and finite-max Kato route agree with this report. Agreement is scoped checking, not proof certification.

Failure ledger: no conditional PDE counterexample found; finite pointwise affine-class entry refuted; zero diffusion with only fixed mean refuted; differing diffusion proof unsupported; upstream N33 correctness and historical priority remain open.

Strongest next attack: independently validate the upstream affine activity lemma and weighted essential-source estimate, because those are the load-bearing unaccepted premises. The downstream PDE bridge has no additional network-theoretic bottleneck under the common scalar mixing interface.
