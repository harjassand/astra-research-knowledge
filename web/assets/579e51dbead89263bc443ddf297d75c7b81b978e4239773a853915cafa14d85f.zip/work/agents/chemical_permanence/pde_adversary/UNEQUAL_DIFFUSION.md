# Unequal diagonal diffusion: precise sufficient classes and unresolved gap

This note interprets a "positive globally bounded solution" as one that is strictly positive at each finite time and uniformly bounded above, without assuming a time-uniform lower bound. If the latter is already assumed, pointwise permanence is already given.

All N33 uses below are conditional. Ω is bounded, connected and smooth, and each species has homogeneous Neumann boundary data.

## Sufficient condition via exact effective rates

Consider u_i,t=D_iΔu_i+f_i(t,ξ,u), D_i>0, with a global solution satisfying 0<u_i≤B. Assume, in addition,

    |f_i(t,ξ,u(t,ξ))/u_i(t,ξ)| ≤ A_i < ∞

almost everywhere, uniformly for all t≥0. Set a_i=f_i/u_i, so each species solves a scalar linear parabolic equation with bounded measurable potential. This hypothesis bounds both loss and relative production.

Let P_i(t) be the scalar Neumann heat semigroup for D_i. For any fixed τ>0, comparison gives

    e^{−A_iτ}P_i(τ)u_i(t−τ) ≤ u_i(t) ≤ e^{A_iτ}P_i(τ)u_i(t−τ),  t≥τ.

The scalar heat kernel p_i(τ,ξ,ζ) is bounded above and strictly positively bounded below on Ω̄×Ω̄. Write m_i(t)=|Ω|^{-1}∫u_i(t). Integration also gives e^{−A_iτ}m_i(t−τ)≤m_i(t)≤e^{A_iτ}m_i(t−τ). Therefore, for every t≥τ and ξ,

    α_i m_i(t) ≤ u_i(t,ξ) ≤ β_i m_i(t),
    α_i=e^{−2A_iτ}|Ω|min p_i(τ)>0,
    β_i=e^{2A_iτ}|Ω|max p_i(τ)<∞.

This is an elementary heat-kernel comparison; no uncharged Harnack hypothesis is hidden.

For the original fixed power-law diagram define, exactly,

    k_eff,e(t) = [|Ω|^{-1}∫_Ω k_e(t,ξ)u(t,ξ)^{y_e}dξ] / m(t)^{y_e}.

Then the spatial mean solves the same diagram:

    m'(t)=Σ_e k_eff,e(t)m(t)^{y_e}ν_e.

For signed real exponents, the rate bounds are

    κ ∏_{y_e,i≥0}α_i^{y_e,i} ∏_{y_e,i<0}β_i^{y_e,i}
       ≤ k_eff,e(t)
       ≤ K ∏_{y_e,i≥0}β_i^{y_e,i} ∏_{y_e,i<0}α_i^{y_e,i}.

Finitely many edges supply one strictly positive finite effective rate box. These rates are measurable. They can depend on the actual solution: N33 permits arbitrary measurable admissible rate paths, so such dependence does not invalidate the application. The mean stays in its ordinary mean stoichiometric class because ∫Δu_i=0 and every ν_e lies in S.

Conditional N33 permanence applied from time τ gives one eventual positive compact bound for m. Multiplying its coordinate lower bounds by α_i, and upper bounds by β_i, gives pointwise permanence for the unequal-diffusion PDE. The resulting absorber depends on the supplied upper bound B and relative-reaction constants, as well as Ω and the D_i. This argument does not acquire the assumed global upper bound.

A syntactic sufficient condition for chemical mass-action kinetics is

    ν_e,i ≠ 0  ⇒  y_e,i ≥ 1.

Every reaction contributing to species i then contains that species in its source. Since all source exponents are nonnegative integers and u≤B, every summand of f_i/u_i is uniformly bounded. Explicitly one may take A_i=KΣ_{e:ν_e,i≠0}|ν_e,i| max{1,B}^{|y_e|_1−1}. This condition is sufficient, not necessary. Networks such as A⇌2A satisfy it. Ordinary conversions A⇌B do not.

## Why generic chemical boundedness is insufficient for this route

For chemical mass-action systems, negative contributions to f_i contain u_i and a global upper bound controls the loss coefficient. One can write

    u_i,t−D_iΔu_i = −a_i(t,ξ)u_i+b_i(t,ξ),
    0≤a_i≤A_B,  0≤b_i≤B_B.

But b_i/u_i need not be bounded. The displayed decomposition does not imply instantaneous own-species sup/mean comparability.

Here is an exact obstruction to that proposed analytic inference, without claiming it is an endotactic-network counterexample. On any fixed smooth connected domain consider

    v_t=DΔv−v+b(t,ξ),   ∂νv=0,   v(0)=1,
    0≤b≤1.

Choose balls of radii r_n↓0 centered at one interior point, and let b=1 on the nth ball only during a final pulse of duration r_n²; set b=0 between pulses. Choose each quiet interval so long that the previous solution is at most r_n^{m+3} everywhere at the next pulse start. Comparison gives 0<v≤1 for all times. At the pulse endpoint, the heat-kernel integral on the ball yields v(center)≥c r_n². Integrating the scalar equation gives mean(v)≤r_n^{m+3}+C r_n^{m+2}. Thus

    sup(v)/mean(v) ≥ c' r_n^{−m} → ∞.

The initial datum is strictly positive; the solution is global and uniformly bounded; loss and additive source coefficients are bounded. Hence those hypotheses alone cannot justify bounded effective monomial rates. This b is an arbitrary bounded source and is not claimed to arise from a fixed endotactic diagram with every edge rate bounded below. It identifies the failure of the own-species Harnack step, while the original network-specific question remains open.

For a mixed monomial the missing estimate is even stronger: controlling each species' marginal mean does not control spatial correlations in ∫u^y. Without pointwise comparability, an effective coefficient can diverge or vanish as marginal means approach zero. A proof for general endotactic PDEs would need a network-specific correlation/relative-production argument, not merely boundedness and scalar heat positivity.

## Compatible-normal class: exact geometry

Let the species diffusion matrix be a constant positive diagonal matrix D=diag(D_1,...,D_d). Suppose every nonzero label normal in the N33 finite affine family satisfies

    r_λ^T D = d_λ r_λ^T,   d_λ>0.

Each affine projected deficit v_λ=M_h−b_λ(h)−r_λ·u then satisfies its own scalar equation

    ∂t v_λ−d_λΔv_λ = −r_λ·f,   ∂νv_λ=0.

At a global maximum of v_λ over label and space, the corresponding λ is active in F_h(u), and the scalar diffusion contribution has the correct sign. Classical maximum principles therefore reproduce initial-plateau invariance and the strict global-deficit decrease whenever neutral active labels have been excluded. For every neutral label r_λ∈S^⊥, r_λ·u solves scalar Neumann heat with diffusivity d_λ and converges uniformly to r_λ·c. The finite neutral slack and scale-chain proof then apply exactly as in the common-D case. This gives a conditional classwise pointwise-plateau absorber without assuming a pre-existing global upper bound.

For merely measurable rates, use smooth ratebox-preserving approximation and pass the invariant and finite-entry estimates through uniform mild-solution convergence on finite intervals. For the initial approximation use the vector pure-diffusion semigroup: compatibility means every affine inequality evolves by its own scalar heat semigroup, so this approximation preserves all initial plateau inequalities. The same neutral waiting time is uniform over the approximants. Bounded reactions on the invariant initial plateau provide the convergence control.

Do not use the single scalar Kato inequality from the common-D case unchanged: different labels have different d_λ, so their maximum need not satisfy one fixed scalar diffusion equation. The projected scalar maximum principle or the classical invariant-region theorem is the appropriate route.

For diagonal D, the eigenvector condition is completely explicit: the nonzero coordinates of r_λ must all belong to one block of species having the same diffusion coefficient. Consequently all genuine plateau facet normals separate by equal-diffusivity blocks, and the plateau is a Cartesian product of block polytopes. If all D_i are distinct, its facets must be coordinate aligned, so the plateau is a box. Generic N33 affine families are not known to have this special geometry. The condition is a useful exactly testable sufficient class, not a generic unequal-diffusion theorem.

It is enough to impose compatibility on every label that can actually be active in the relevant B_h ranges. Compatibility of only the genuine facets of K_h guarantees invariance of K_h, but does not by itself transfer the finite global absorption argument: removing nonfacet labels can create new active labels outside K_h where the supplied strict drift has not been proved.

## Current boundary

Established conditionally: common-D PDE permanence; unequal-D permanence under bounded relative reactions plus a supplied upper bound; unequal-D permanence for compatible finite affine normals. Refuted: the generic inference from bounded loss/additive source and global upper boundedness to own-species sup/mean comparability. Still unresolved: pointwise permanence for arbitrary unequal positive diagonal diffusion and an arbitrary endotactic chemical diagram under only global upper boundedness.
