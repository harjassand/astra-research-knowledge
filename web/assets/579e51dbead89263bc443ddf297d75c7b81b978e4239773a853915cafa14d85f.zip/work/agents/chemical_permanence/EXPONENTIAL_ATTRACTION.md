# Escalation: complex-balanced spatial global attraction after permanence

**Scope/status:** this is a standard entropy consequence of the new positive compact range, not a novelty claim for entropy methods. For the common-diffusion PDE theorem, it remains conditional on the internally reconstructed N33/affine permanence proof. Fixed, spatially homogeneous rates and a positive complex-balanced equilibrium c_* in the mean stoichiometric class are required. No absence-of-boundary-equilibria hypothesis is used. Arbitrary endotactic systems may oscillate and are not claimed to converge.

Let Ω be bounded, connected and smooth, with Neumann conditions. Suppose a global solution of the complex-balanced chemical system has entered a common pointwise range 0<m≤u_i≤M. This follows from the common-D permanence theorem; it also follows under the unequal-D sufficient hypotheses in `pde_adversary/UNEQUAL_DIFFUSION.md`. Use normalized spatial measure dξ/|Ω|.

Write z_i=log(u_i/c_{*,i}), q_y=exp(y·z), a_e=k_e c_*^{y_e}. The entropy

    H(u)=avg∫Σ_i [u_i log(u_i/c_{*,i})−u_i+c_{*,i}]

satisfies exactly

    dH/dt=−D_R−D_D,
    D_R=avg∫Σ_e a_e[q_{y_e}log(q_{y_e}/q_{y'_e})−q_{y_e}+q_{y'_e}],
    D_D=avg∫Σ_i D_i u_i|∇z_i|².

The telescoping linear q terms cancel by complex balance at c_*. Rates must be fixed and homogeneous for this identity.

Let B bound every |z_i|, and R bound every |y_e·z| and |y'_e·z|. The scalar Bregman inequality

    a log(a/b)−a+b≥(a−b)²/[2max(a,b)]

and the exponential mean-value theorem give

    D_R≥(1/2)e^{−3R} avg∫Σ_e a_e(ν_e·z)²
       ≥c_R avg∫|Proj_S z|²,

where c_R>0 is the finite positive smallest eigenvalue of Σ_e a_eν_eν_e^T restricted to S, times the displayed factor. Also D_D≥m D_min avg∫|∇z|².

It remains to control the neutral component of the spatial mean log concentration. Set z̄=avg z=s+n, with s∈S,n∈S^⊥. Mean conservation says avg(u−c_*)∈S, hence

    n·avg(u−c_*)=0.

Since |n_i|≤B√d=:B_n,

    n·[c_*e^n−c_*]≥c_{*,min}e^{−B_n}|n|².

The conservation equality and the Lipschitz bound for exp on [−B_n,B_n] imply

    c_{*,min}e^{−B_n}|n|²
      ≤|n| |c_*e^n−avg(c_*e^z)|
      ≤|n|c_{*,max}e^{B_n}(|s|+||z−z̄||_2).

Thus

    |n|≤(c_{*,max}/c_{*,min})e^{2B_n}(|s|+||z−z̄||_2).

Poincaré controls ||z−z̄||_2² by C_P² avg∫|∇z|²; Jensen controls |s|² by avg∫|Proj_S z|². Finally the elementary integral identity

    e^z z−e^z+1=∫_0^z t e^t dt≤(1/2)e^B z²

shows H≤C(D_R+D_D), with finite explicit C determined by the positive range, equilibrium, network eigenvalue, diffusion minimum, and Poincaré constant. Therefore

    H(u(t))≤H(u(T))exp[−(t−T)/C],  t≥T.

The strong convexity of x log(x/c_*)−x+c_* on the fixed range gives exponential L² convergence to the homogeneous c_*. Standard bounded-coefficient parabolic smoothing yields uniform spatial convergence as well; the entropy and L² bounds above do not require that additional regularity assertion.

The positive range, not an assumption excluding boundary equilibria, supplies the coercivity. This is the precise spatial global-attraction consequence. Prior entropy literature already treats complex-balanced systems without boundary equilibria and selected networks with accessible boundary equilibria, e.g. Desvillettes–Fellner–Tang, https://arxiv.org/abs/1604.04536 . A broader primary-source novelty comparison is still required.
