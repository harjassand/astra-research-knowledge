# A universal bound-entangled sequence for identical qubit noise

**Date:** 8 October 2026. **Pinned prior capital:** Astra commit `ca22fffaeab073aaa1bbb690ce1b4250fc272956`. **Late repository reconciliation:** `687dfc0640ee80654bcbdbe38cb13d6e1f1586ce`; the current start guide, upstream route, priorities, quantum topic route and N160 review notice were read. These are two distinct snapshots, not an implicit moving revision.

**Status:** complete internal mathematical derivations, exact rational certificates, and newly executed diagnostics. No independent agent, external referee, or proof assistant verified the theorems. Historical priority is not established. This is a new engineered state family, not a claimed extension of the original bath-selected state to arbitrary channels. No October-2026-release theorem is a validity premise.

## 1. Definitions and main results

Let N=2n be even and let J_a=(1/2) sum_i sigma_a^(i), with J^2=J_x^2+J_y^2+J_z^2. Let P_{N,j} project onto the **entire** total-spin-j subspace, including all multiplicities, for j=0,...,n. Write

\[
m_{N,j}=\binom{N}{n-j}-\binom{N}{n-j-1},\qquad d_{N,j}=(2j+1)m_{N,j},
\]

where out-of-range binomial coefficients are zero. Define

\[
f_j=\frac1{(2j+1)!!},\quad
Z_N=\sum_{j=0}^n d_{N,j}f_j,\quad
R_N=\frac1{Z_N}\sum_{j=0}^n f_jP_{N,j}.                 \tag{1}
\]

Thus f_0=1 and f_{j+1}=f_j/(2j+3). Each R_N is an explicit rational density matrix. It is invariant under permutations and under common SU(2) rotations. Let SEP_N denote full separability across the N physical qubits. Let PPT_1(N) denote positivity under every **single-qubit** partial transpose, not under all bipartitions. Let SEP_1(N) denote separability across each single-qubit-versus-rest cut. Different cuts may use different decompositions. A two-producible state is a mixture of products of blocks of size at most two, with the partition allowed to vary between mixture components.

### Theorem A: sharp total-spin floor

R_N belongs to SEP_1(N) and is two-producible. For every increasing real function g on {0,...,n},

\[
\operatorname{tr}\rho\,g(\widehat j)\ge
\operatorname{tr}R_N\,g(\widehat j)\quad\text{for every }\rho\in\mathrm{PPT}_1(N),
\qquad
\widehat j=(\sqrt{I+4J^2}-I)/2.                          \tag{2}
\]

The same sharp bound therefore holds over SEP_1(N), and R_N attains it. It simultaneously minimizes all increasing total-spin statistics. For strictly increasing g it is the unique **permutation- and rotation-invariant** minimizer; uniqueness among unrestricted states is not asserted.

In particular, put C_N=tr(R_N J^2). Then

\[
\min_{\rho\in\mathrm{PPT}_1(N)}\operatorname{tr}(\rho J^2)
=\min_{\rho\in\mathrm{SEP}_1(N)}\operatorname{tr}(\rho J^2)=C_N,
\]

\[
C_N\longrightarrow C_*:=\frac{23F+15}{6F+4}=3.8065898954731177\ldots<4,
\quad
F=e^{1/2}\sqrt{\pi/2}\,\operatorname{erf}(1/\sqrt2).
                                                               \tag{3}
\]

Every even N>=4 gives R_N not in SEP_N, and its entanglement depth is exactly two. Because it is separable across every singleton cut, no pure entanglement can be distilled by N separate laboratories, even using many copies. This is multipartite bound entanglement, **not** a solution to bipartite NPT bound entanglement and not genuine N-partite entanglement.

### Theorem B: channel-universal survival

Fix **any** qubit completely positive trace-preserving map Lambda, applied identically and independently at all sites. The sequence R_N is independent of Lambda. Exactly one of the following occurs:

1. Lambda tensor Lambda is entanglement-annihilating, meaning it maps **every physical two-qubit input** to a separable output. Then Lambda^{tensor N}(R_N) is fully separable for every even N.
2. Lambda tensor Lambda is not entanglement-annihilating. Then Lambda^{tensor N}(R_N) is entangled for every sufficiently large even N. These outputs remain in SEP_1(N) and two-producible, so they are bound entangled and have depth exactly two.

Equivalently,

\[
\{\Lambda:\Lambda^{\otimes2}\text{ is EA}\}
=\bigcap_{N\ge2,\ N\text{ even}}
\{\Lambda:\Lambda^{\otimes N}(R_N)\in\mathrm{SEP}_N\}.       \tag{4}
\]

The non-EA side is eventually true, not just true along a selected subsequence. N may depend badly on the fixed channel. No uniform bound for channels approaching their boundary is implicit. For arbitrary nonunital channels the proof gives binary entanglement survival, not a uniform trace-distance gap or efficient laboratory certification.

This is also an exact characterization of channels which annihilate all singleton-separable, two-producible states at all even sizes: the annihilators are precisely the two-qubit EA channels. Channels outside that set are detected by the **one fixed sequence** (1). It does not characterize channels annihilating arbitrary higher-depth states or the different notion of entanglement-breaking channels.

### Theorem C: finite unital size, bounded witness, and sample count

Suppose Lambda is unital with Bloch matrix T, let s=||T||_F^2, and let omega_N=Lambda^{tensor N}(R_N). Then exactly

\[
\langle J_a\rangle_{\omega_N}=0,\quad
\langle J^2\rangle_{\omega_N}
=\frac{N(3-s)}4+\frac{sC_N}3.                              \tag{5}
\]

The known two-qubit EA criterion [F12] is s<=1. When s>1, the sufficient finite-size condition

\[
N>\frac{16s}{3(s-1)}                                     \tag{6}
\]

already guarantees bound entanglement, detected by three collective second moments. This is sufficient, not an exact finite-N separability boundary.

There is a bounded-score version with no postselection. Let delta=s-1>0 and t=2delta/3. On one preparation, choose a in {x,y,z} uniformly, measure every local sigma_a/2, sum to obtain j_a, and return the score

\[
S=\exp(-t j_a^2/N)\in[0,1].                               \tag{7}
\]

For every fully separable state, the expected score is at most

\[
B_N(t)=\frac{1+2/\sqrt{1+t/2}}3+\frac{t^{3/2}}{\sqrt N}.    \tag{8}
\]

If N delta>=4096, the target's expected score exceeds B_N(t) by at least delta^2/72. Consequently

\[
\inf_{\sigma\in\mathrm{SEP}_N}
\operatorname{TV}(\mathcal M_N(\omega_N),\mathcal M_N(\sigma))
\ge\delta^2/72,                                          \tag{9}
\]

where M_N records the chosen axis and sum. Half trace distance has the same lower bound. An independent-copy test at the midpoint of the guaranteed score gap has total error at most alpha using

\[
m\ge \left\lceil10368\,\delta^{-4}\ln(2/\alpha)\right\rceil. \tag{10}
\]

The constants are conservative analytic bounds, not numerical optima. The score requires calibrated spin axes and a known or conservatively bounded delta. Acquisition/calibration costs, N local measurements per preparation, and repeated state preparation remain real costs.

## 2. Why every central spin state is two-producible

For each j, prepare n-j singlets and 2j qubits in the same pure state |r>. Average |r><r|^{tensor 2j} over the Bloch sphere, obtaining P_sym/(2j+1). Average the resulting N-qubit state over all site permutations. The result commutes with permutations and common rotations, is supported in spin j, and therefore equals P_{N,j}/d_{N,j} by Schur-Weyl decomposition. This proves the exact representation

\[
R_N=\sum_j p_{N,j}\,\mathbb E_{\pi,r}
U_\pi\big(S_-^{\otimes(n-j)}\otimes |r\rangle\langle r|^{\otimes2j}\big)U_\pi^\dagger,
\quad p_{N,j}=d_{N,j}f_j/Z_N.                             \tag{11}
\]

Every summand has entangled clusters of size only two. The random pairing and coherent-state labels are **not** retained as accessible side information. Retaining labels describes a different state/resource. The representation is inherited machinery from the prior Astra singlet-pair work, not a novelty claim.

## 3. Exact singleton PPT and separability inequalities

Let a general central state have nonnegative coefficients h_j. Fix one qubit, and decompose the rest into spin k=1/2,3/2,...,n-1/2. Put h_+=h_{k+1/2}, h_-=h_{k-1/2}. Ignoring a positive overall normalization and the rest's local multiplicity register, the block is

\[
aI+b\,\sigma\cdot K,
\quad a=\frac{(k+1)h_++kh_-}{2k+1},\quad
b=\frac{h_+-h_-}{2k+1}.                                  \tag{12}
\]

Conjugating the qubit transpose by sigma_y changes sigma to -sigma. Its two eigenvalues are

\[
a-bk=\frac{h_++2kh_-}{2k+1}\ge0,
\qquad
a+b(k+1)=\frac{2(k+1)h_+-h_-}{2k+1}.                     \tag{13}
\]

Thus all singleton transposes are positive exactly when

\[
h_j\le(2j+3)h_{j+1},\qquad j=0,...,n-1.                  \tag{14}
\]

For these qubit-spin invariant blocks, the PPT interval is also the separable interval. One can verify this without assuming PPT suffices in arbitrary 2-by-d systems: the common SU(2) twirls of an aligned qubit and spin-k coherent state, and an anti-aligned pair, are separable and realize the extreme ratios b/a=1/(k+1) and -1/(k+1). Their convex combinations cover exactly (13), after normalization. The spin-k and multiplicity flags are local on the rest side. This explicitly supplies a separable decomposition. The general qubit-spin invariant classification has established antecedents [S03].

Our f_j saturates (14). Hence R_N is singleton-separable, including the equality boundary. Its singleton partial transposes generally have zero eigenvalues; strict robustness of this property to arbitrary perturbations is not asserted.

## 4. Global stochastic optimality, not only symmetric optimality

Twirling any rho in PPT_1(N) by common SU(2) rotations and all permutations preserves the PPT_1 property and all total-spin probabilities. The twirled state is central with coefficients h_j satisfying (14). Since f_j=(2j+3)f_{j+1},

\[
a_j:=h_j/f_j\quad\text{is nondecreasing in }j.
\]

The spin distribution of the twirled state is the R_N distribution reweighted by a_j. Thus, for increasing g,

\[
\mathbb E_\rho g-\mathbb E_{R_N}g
=\frac{\operatorname{Cov}_{p_N}(g,a)}{\mathbb E_{p_N}a}\ge0.
                                                               \tag{15}
\]

The last inequality follows from the identity

\[
2\operatorname{Cov}(g,a)
=\sum_{j,k}p_jp_k(g_j-g_k)(a_j-a_k)\ge0.
\]

Zeros among h_j cause no difficulty. Every p_{N,j} is positive. If g is strictly increasing, equality forces a_j constant, giving uniqueness of the central optimizer. Because R_N itself is in SEP_1(N), all bounds also are attained within the smaller singleton-separable set. This proves Theorem A's sharp optimization claim.

## 5. Uniform exponential moments and the exact limiting constant

Write N=2n and

\[
A_{N,j}=\frac{m_{N,j}}{(2j+1)m_{N,0}}
=\prod_{\ell=0}^{j-1}\frac{n-\ell}{n+2+\ell},\qquad A_{N,0}=1. \tag{16}
\]

Extend A_{N,j}=0 for j>n. This is decreasing in j, lies in [0,1], and tends to 1 at each fixed j as N tends to infinity. Therefore

\[
p_{N,j}=\frac{(2j+1)^2f_j A_{N,j}}{\sum_k(2k+1)^2f_kA_{N,k}}.\tag{17}
\]

For every fixed b and every fixed nonnegative integer r,

\[
\sum_{j\ge0}(2j+1)^2f_j e^{bj}(1+j)^r<\infty             \tag{18}
\]

by the ratio test. Since the denominator in (17) is >=1, these series bound moments uniformly in N. Decreasing reweighting by A_{N,j} also shows that p_N is stochastically dominated by

\[
p_{\infty,j}=\frac{(2j+1)^2f_j}{\sum_k(2k+1)^2f_k}.       \tag{19}
\]

Dominated convergence gives convergence of every exponentially weighted polynomial moment.

For the displayed closed form, let F(x)=sum_j f_j x^j. The integral identity

\[
F(x)=\int_0^1 e^{x(1-u^2)/2}\,du
\]

follows by integrating the Taylor series (or a beta integral). The recurrence yields 2xF'(x)+F(x)=1+xF(x). At x=1, if M_r=sum_j j^r f_j and F=F(1),

\[
M_1=1/2,\quad M_2=F/2,\quad M_3=(F+1)/2,\quad M_4=5F/4+3/4.
\]

Hence sum_j (2j+1)^2 f_j=3F+2 and sum_j j(j+1)(2j+1)^2f_j=(23F+15)/2, proving (3). C_*<4 follows exactly from F+1>0. Thus C_N<4. For N>=8 this violates the full-separable bound <J^2>>=N/2. At N=4 and 6 the exact moments are 3/2 and 108/59, respectively, also violations. N=2 has C_2=1 and is separable.

The inequality <J^2>>=N/2 follows from sum_a Var(J_a)>=N/2 for all full-separable states: a product component has sum of single-qubit variances at least N/2, and mixing adds a nonnegative variance of means. This collective-spin mechanism is established prior work [T07].

## 6. Universal channel proof: the easy direction and the exact interfaces

If Lambda tensor Lambda is EA, it converts every pair in (11) into a separable two-qubit state. It also preserves separability of the unpaired factors. Each component becomes fully separable, and so does the mixture. More generally, it annihilates all two-producible inputs at every size. This direction requires no normal form and holds on the channel boundary.

For the converse first assume Lambda is **strictly positive**: every nonzero positive semidefinite input has a positive definite output. The quantum Sinkhorn theorem supplies invertible filters A_0,B such that

\[
\Phi=\Phi_{A_0}\circ\Lambda\circ\Phi_B
\quad\text{is CPTP and unital},\qquad \Phi_X(Y)=XYX^\dagger. \tag{20}
\]

This is an established external theorem, not something certified by our numerical scaling script; the exact strict-positivity hypothesis and its role are retained [F21, Sec. II; Aubrun–Szarek 2017, Prop. 2.32 cited there]. Normal-form entanglement analysis is also established [F18].

Invertible product congruences preserve separability in both directions, and prefilters map the positive cone onto itself. Consequently Lambda tensor Lambda is EA iff Phi tensor Phi is EA. By the identical-unital theorem [F12, Prop. 2], if Lambda tensor Lambda is not EA, then s=||T_Phi||_F^2>1.

The crucial same-channel identity is

\[
(B\otimes B)|\psi^-\rangle=(\det B)|\psi^-\rangle.        \tag{21}
\]

It is valid for any complex two-by-two B. It would not hold with arbitrary different filters on the two sites. This is why identical noise, not merely independent noise, is essential.

Let Psi_0=Phi_{A_0} circle Lambda and H_0=Psi_0^*(I). Trace preservation in (20) gives B^dagger H_0 B=I and det H_0=|det B|^{-2}. Rescale Psi_0 by (det H_0)^{-1/2}, corresponding to a scalar rescaling of A_0, to obtain a CP map Psi with H=Psi^*(I) and det H=1. Equation (21) then gives **exactly**

\[
(\Psi\otimes\Psi)(S_-)
=(\Phi\otimes\Phi)(S_-)=:\tau.                          \tag{22}
\]

Tau is normalized with both local marginals I/2. Its collective pair spin has zero mean and

\[
\operatorname{tr}(\tau J_{\rm pair}^2)=\frac{3-s}{2}=2v_0,
\quad v_0=(3-s)/4<1/2.                                  \tag{23}
\]

No input filter B is physically applied to R_N. Only an output filter is used as a mathematical entanglement witness. This distinction is essential for a channel-independent input family.

## 7. Why factorial tails remove the filtering obstruction

Write the eigenvalues of H as e^{+b},e^{-b}, with b>=0. In (11), every pair is mapped to the normalized state tau. The unpaired 2j-qubit factor contributes a positive trace z_j satisfying

\[
0<z_j\le e^{2bj},\qquad z_0=1.
\]

After normalization of Psi^{tensor N}(R_N), the spin-label mixing probabilities obey

\[
\widetilde p_{N,j}
=\frac{p_{N,j}z_j}{\sum_kp_{N,k}z_k}
\le\frac{p_{N,j}}{p_{N,0}}e^{2bj}
\le(2j+1)^2 f_j e^{2bj}.                                \tag{24}
\]

Thus the expected active-spin energy is bounded, uniformly in N, by the finite number

\[
C(b)=\sum_{j=0}^\infty j(j+1)(2j+1)^2 f_j e^{2bj}.        \tag{25}
\]

The normalized output has a mixture of n-j independent pair states tau and a state on 2j active qubits. Pair means vanish; the active total-spin operator has J_active^2<=j(j+1)I. Consequently

\[
\left\langle J^2\right\rangle_{
\Psi^{\otimes N}(R_N)/\operatorname{tr}\Psi^{\otimes N}(R_N)}
\le Nv_0+C(b).                                         \tag{26}
\]

Whenever N(s-1)>4C(b), the right side is <N/2. The filtered output is entangled. A product filter cannot create entanglement from a fully separable input, so Lambda^{tensor N}(R_N) was already entangled.

This changes the obstruction in the prior thermal approach: exponential sector weights can be overwhelmed by a fixed exponential filter tilt, whereas the factorial weights tolerate **every fixed tilt**. The latter assertion is exactly (18), not an analogy between unrelated Gaussian limits.

To turn A into a legal local Kraus operator, divide it by its operator norm. This changes success probability but not the normalized state in (26). Success may decrease exponentially with N. No nonvanishing unfiltered-distance bound follows from this argument.

### Boundary channels

For arbitrary Lambda outside the two-qubit EA set, choose a sufficiently small fixed epsilon>0 such that

\[
\Lambda_\epsilon=D_{1-\epsilon}\circ\Lambda
\]

is still outside that set. Such an epsilon exists: one two-qubit input gives an entangled output, and entanglement persists in an open neighborhood of that finite-dimensional output because the separable set is compact. Lambda_epsilon is strictly positive. The preceding proof applies to the **same R_N** and yields entanglement after Lambda_epsilon at every sufficiently large even N. Since its extra depolarization is local, Lambda^{tensor N}(R_N) must also be entangled. All such outputs retain singleton separability and depth<=2. This proves Theorem B for every qubit CPTP map, including rank-deficient/boundary channels.

## 8. Exact finite unital moments and bounded-score proof

Rotation invariance gives zero input magnetization and isotropic pair correlations. Summing them after T proves (5), hence (6) using C_N<4. For a general affine channel r->c+Tr there is also the exact identity

\[
\sum_a\operatorname{Var}_{\Lambda^{\otimes N}R_N}J_a
=\frac{N(3-\|T\|_F^2-|c|^2)}4+\frac{\|T\|_F^2C_N}{3}.    \tag{27}
\]

This yields a sufficient condition with ||T||_F^2+|c|^2>1, but is not a complete nonunital criterion (Section 9).

For the bounded score, first take an arbitrary product state with Bloch vectors r_i and fix an axis a. The scaled local outcomes are independent, supported on +/-1/(2 sqrt N). Let their sum have mean mu_a and variance

\[
c_a=\frac1{4N}\sum_i(1-r_{ia}^2),\quad
0\le c_a\le1/4,\quad\sum_ac_a\ge1/2.                    \tag{28}
\]

A scalar Lindeberg replacement by a Gaussian of the same mean and variance, for f(x)=exp(-t x^2), gives the uniform estimate

\[
\left|\mathbb E f(J_a/\sqrt N)
-\frac{e^{-t\mu_a^2/(1+2tc_a)}}{\sqrt{1+2tc_a}}\right|
\le t^{3/2}/\sqrt N.                                    \tag{29}
\]

Details of constants: the centered summands have absolute third moments summing to at most 1/(4 sqrt N). Matching independent Gaussians have absolute third moments summing to sqrt(2/pi)/(4 sqrt N). Taylor's remainder is bounded by one sixth of their sum times ||f'''||_infinity; ||f'''||_infinity<=12 t^{3/2}. Their product is <t^{3/2}/sqrt N. This proof is uniform in arbitrary means and heterogeneous mixed product factors.

Discarding the Gaussian mean factor increases the right side. The convex decreasing function c->(1+2tc)^(-1/2) has its maximal sum over (28) at a permutation of (0,1/4,1/4). Consequently

\[
\sum_a\mathbb E e^{-tJ_a^2/N}
\le1+2/\sqrt{1+t/2}+3t^{3/2}/\sqrt N.                    \tag{30}
\]

Mixture linearity extends this to all full-separable states. For the target, e^{-x}>=1-x and (5) give

\[
\sum_a\mathbb E_{\omega_N} e^{-tJ_a^2/N}
\ge3-t\left[\frac{3-s}{4}+\frac{sC_N}{3N}\right].         \tag{31}
\]

Use (1+x)^(-1/2)<=1-x/2+3x^2/8 for x>=0 and t=2delta/3. The difference between (31) and (30) is at least

\[
\frac{\delta^2}{12}
-\frac{2sC_N\delta}{9N}
-3(2\delta/3)^{3/2}/\sqrt N.                             \tag{32}
\]

If N delta>=4096, s<=3 and C_N<4 show that the last two terms are at most

\[
\delta^2\left[\frac{8}{3\cdot4096}+\frac2{64}\right].
\]

The remaining gap is >delta^2/24. Dividing by three proves (8)-(9). Hoeffding's inequality applied to [0,1] scores at the midpoint of a gap g=delta^2/72 gives total error <=2exp(-m g^2/2), proving (10).

This test does not infer finite-N trace distance from weak convergence or from filtering. It directly bounds finite-N measurement laws. No entangling measurement is required: one common chosen axis and N local measurements suffice.

**Optional entropic corollary.** Randomizing a pass bit with probability equal to the score, data processing and binary Pinsker give E_R>=2g^2=delta^4/2592 nats. The same lower bound holds for the regularized relative entropy to full separability across N laboratories: sequential local tests leave any laboratory-separable alternative laboratory-separable conditional on every past history, so the KL chain rule gives m times the one-copy lower bound even with arbitrary local cross-copy quantum correlations. This is a small positive bound, not a logarithmic growth claim after fixed noise.

## 9. A nonunital exact certificate and a Gaussian-level obstruction

Consider generalized amplitude damping with excited-population retention eta=1/4 and equilibrium ground occupation p=9/10. Its Bloch data are

\[
T=\operatorname{diag}(1/2,1/2,1/4),\qquad c=(0,0,3/5).
\]

The naive score is s+|c|^2=369/400=0.9225<1, so (27) never certifies the large-N output. Nevertheless the noisy singlet is

\[
\tau=\frac1{1600}
\begin{pmatrix}999&0&0&0\\0&281&-200&0\\0&-200&281&0\\0&0&0&39\end{pmatrix}.
\]

Its partial transpose has minimum eigenvalue -1/1600 exactly. Thus the channel is not two-qubit EA.

Put q=sqrt(13/333) and use the same legal output filter A=diag(sqrt q,1) at each site. The normalized filtered pair is locally maximally mixed with negative diagonal correlations and

\[
s_{\rm normal}=\frac{681q-39}{39+281q}>101/100.
\]

The local effect H=Lambda^*(A^2) has eigenvalues (37q+3)/40 and (27q+13)/40, whose ratio is <2. On rescaling det H to one, exp(2b)<2. Therefore C(b) is bounded by

\[
\sum_{j\ge0} j(j+1)(2j+1)^2 f_j 2^j<140.
\]

All inequalities have rational certificates: 9879/50000<q<19759/100000; the square bounds bracket 13/333. Sum the last series through j=20 and bound its tail from j=21 by twice that term, since subsequent ratios are <1/2. The resulting exact upper bound is

203608905133531562240396468 / 1457007828631998733715625 < 140.

For N=60000, (26) gives

\[
\langle J^2\rangle_{\rm filtered}<60000(199/400)+140=29990<30000=N/2.
\]

This is a finite-size entanglement certificate beyond the naive affine criterion. It is not a useful high-success experiment: the pair filter trace is p_pair=0.1181510262..., and the full success probability has log p_success=(N/2) log p_pair+O(1)=-1.0678957948... N+O(1). Normalization of the O(1) spin sector does not remove this exponential cost.

There is also a precise reason not to expect the simple Gaussian argument to solve everything. Eight mixed-qubit Bloch vectors can match the first two centered collective fluctuation moments of this noisy family: take all four sign choices in each of

\[
(\pm1/\sqrt{10},\ \pm1/\sqrt{10},\ 17/20),
\quad
(\pm\sqrt{2/5},\ \pm\sqrt{2/5},\ 7/20).
\]

Their lengths squared are 369/400, their mean is c, and their second moment is cc^T+TT^T. Balanced product arrays (N divisible by eight) therefore have the same centered one-axis Gaussian characteristic limits as the noisy R_N family. This is **not** a proof of full quantum trace proximity or exact separability. It demonstrates that leading Gaussian means and covariances alone cannot reveal all of the nonunital entanglement proved above.

## 10. Examples, dynamical implication, and preparation interface

**Depolarization.** For T=lambda I, the exact asymptotic boundary remains lambda=1/sqrt3, but the construction is different and the finite sufficient size is now explicit. At lambda=29/50=0.58, (6) certifies every even N>=586. The bounded-score uniform size bound is more conservative. These thresholds must not be interchanged.

**Zero-temperature amplitude damping.** Let eta be the excited-population retention. Then T=diag(sqrt eta,sqrt eta,eta), |c|=1-eta. Equation (27), with C_N<4, certifies entanglement whenever

\[
N>\frac{8(2+\eta)}{3\eta},\qquad\eta>0.
\]

Complete damping eta=0 destroys all entanglement. Thus every fixed incomplete amplitude damping preserves the bound entanglement at sufficiently large size; e.g. eta=0.1 is certified at every even N>=58. This is a sufficient finite-N criterion, not an optimal onset.

**Entanglement lifetime.** For any continuous qubit CPTP semigroup Lambda_t, let tau_2 be the first time Lambda_t tensor Lambda_t becomes EA, and tau_N the first time Lambda_t^{tensor N}(R_N) becomes fully separable. By the semigroup property separability is absorbing, and by continuity the finite death times are attained. Theorem B gives

\[
\lim_{N\to\infty,\ N\text{ even}}\tau_N=\tau_2,
\]

including infinity. For each fixed t<tau_2, eventual survival follows; at or beyond tau_2, every two-producible input is destroyed. This is an equality of limiting binary entanglement lifetimes, not of distillable entanglement, channel capacity, or useful experimental signal sizes.

**Preparation.** Equation (11) is a constructive preparation recipe: sample j from the rational distribution p_N; prepare n-j singlets and 2j identically oriented pure qubits; apply a uniformly random permutation; discard the classical labels. It requires order N entangled-pair preparation and potentially nonlocal routing. It is not free entanglement creation by local operations, and it is not a proof that the original collective bath prepares R_N.

Exact finite-support coherent decompositions can replace the Haar average: for M=2j use M+1 equally spaced azimuths and ceil((M+1)/2) Gauss-Legendre polar nodes with positive weights. Azimuth sums kill all nonzero harmonics through order M; polar quadrature integrates the remaining diagonal polynomials through degree M. The amplitudes/weights are algebraic. Compiling rotations to a gate set introduces precision costs. The j weights have polynomial-size integer descriptions using the common denominator (N+1)!!; exact random integer sampling has expected, not fixed, random-bit cost. No laboratory implementation or gate-accurate compiler was executed here. Approximating R_N is much less demanding for the bounded unital witness than for exponentially rare nonunital filtering.

## 11. Verification record and source status

`universal_probe_checks.py` was executed: four dense states (N=2,4,6,8), 20 singleton partial transposes, 28 depolarizing moment comparisons, 16 random-channel filtering/normalizer checks, 50 rational moment evaluations through N=100, and 50 independently formulated linear programs for the singleton-PPT energy optimum. Maximum dense moment error was 4.45e-16; depolarizing formula error 8.00e-15; normalization error 3.78e-15; pair congruence error 5.51e-15; LP objective error 3.38e-14. Float LP agreement does not certify the general optimization theorem.

`bounded_witness_and_certificates.py` was separately executed: 280 exact-convolution product-score diagnostics, 48 dense target-score diagnostics, the rational GAD certificate, and Gaussian-matched product moments. The four-qubit symbolic certificate is

- eigenvalues of R_4: 3/16 (multiplicity 2), 1/16 (9), 1/80 (5);
- eigenvalues of each singleton partial transpose: 0 (5), 1/8 (6), 1/20 (5);
- tr(R_4 J^2)=3/2 < 2.

These are internal computations and direct proofs, not independent researcher agreement or a formal verification of asymptotic theorems. Random-channel Sinkhorn convergence was checked numerically; the universal existence premise is the published theorem, not the test.

### Primary literature and novelty boundaries

[S03] John Schliemann, *Entanglement in SU(2)-invariant quantum spin systems*, Phys. Rev. A 68, 012309 (2003), arXiv:quant-ph/0212114. The qubit-spin PPT/separability interval is established antecedent, and is reconstructed above.

[T07] G. Toth, C. Knapp, O. Guhne, H. J. Briegel, *Optimal spin squeezing inequalities detect bound entanglement in spin models*, Phys. Rev. Lett. 99, 250405 (2007), arXiv:quant-ph/0702219. Collective-spin witnesses and thermal bound entanglement are not new claims here.

[F12] S. N. Filippov, T. Rybar, M. Ziman, *Local two-qubit entanglement-annihilating channels*, Phys. Rev. A 85, 012303 (2012), arXiv:1110.3757, Proposition 2. The unital squared-singular-value boundary is an external dependency, not newly discovered.

[F18] S. N. Filippov, V. V. Frizen, D. V. Kolobova, *Ultimate entanglement robustness of two-qubit states against general local noises*, Phys. Rev. A 97, 012322 (2018), arXiv:1708.08208v2. Normal-form optimization of two-qubit robustness is established work. Abstract/related reconstruction read; full text was not reliably fetched in this run.

[F21] S. N. Filippov, *Entanglement robustness in trace decreasing quantum dynamics caused by depolarization and polarization dependent losses*, Quanta 10, 15-21 (2021), arXiv:2109.01546v2, Section II. Its explicit quantum Sinkhorn statement and inverse-filter interface were read. It attributes the strict-positive normal-form theorem to Gurvits (2004), Georgiou–Pavon (2015), and clarifications by Aubrun–Szarek (2015, 2017); Proposition 2.32 is in Aubrun–Szarek, *Alice and Bob Meet Banach* (2017), Section 2.4.3. These original proofs were not independently re-proved here. An early draft misidentified this upstream attribution; the primary reference list was checked and corrected before delivery.

[M24] A. Moharramipour et al., *Symmetry enforced entanglement in maximally mixed states*, PRX Quantum 5, 040336 (2024), arXiv:2406.08542v2. Entanglement of invariant-sector projectors, local invisibility, and logarithmic entanglement are prior art. Their MMIS is a fixed invariant-sector state, not the factorial mixture (1), and their symmetry-preserving channel setting differs from arbitrary identical local channels.

[P21] K. F. Pal, G. Toth, E. Bene, T. Vertesi, *Bound entangled singlet-like states for quantum metrology*, Phys. Rev. Research 3, 023101 (2021), arXiv:2002.12409. Bound entanglement approaching a singlet's performance in an operational task is not a new general theme; this work concerns a different, bipartite high-dimensional metrological setting.

The proposed advances are the explicit factorial sequence, its simultaneous global singleton-PPT spin optimization, the channel-independent same-sequence universal survival theorem, and the finite bounded-score guarantees. Searches did not locate an exact prior statement, but some exact-string searches returned mostly irrelevant results. That is weak negative evidence, not priority clearance. No comparison in significance with the strongest October 2026 release results is certified.


## 12. Additional consequences and interface reconciliation

The companion note `CASIMIR_EXTREMALITY_AND_ENTROPY.md` proves an exact full-separability maximization for exp(-t J^2), attained by a balanced up/down product state. It reconstructs the positive common-rotation measure by a finite random-walk limit and Holder's inequality. It then proves, for this new R_N:

- ordinary single-copy E_R(R_N)=ln N+O(1), with explicit upper/lower finite-N bounds;
- half-trace distance to full separability >=max(0,1-7/sqrt N-2/N).

The collective Casimir effect is not a three-setting LOCC measurement, and the logarithmic E_R conclusion is not asserted for regularized E_R. The local noisy test in Theorem C and the noiseless global bound have different operational contracts. The companion diagnostics were executed separately, sharing basic spin constructors only.

The late repository snapshot has ingested the preceding thermal threshold as N160 and retains G-UNITAL-NOISE-BOUNDED-SCORES for that **original bath-selected family**. Theorem C here supplies bounded scores for the **new engineered factorial family**, so it does not close that original-family gate. No repository file was edited or pushed.
