# Universal bound-entangled qubit-noise probes

Research checkpoint, 8 October 2026. Internal mathematical derivations and executed diagnostics; no external review, priority clearance, independent agents or proof-assistant formalization. No equivalence in significance to the strongest October 2026 mathematics release results is claimed.

## Read first

`UNIVERSAL_BOUND_ENTANGLEMENT_PROOF.md` is the complete main construction, global singleton-PPT optimization, arbitrary-identical-channel survival proof, bounded unital witness, finite-size certificates, resource charges, and prior-art comparison.

`CASIMIR_EXTREMALITY_AND_ENTROPY.md` supplies the separate balanced-product extremality proof and ordinary single-copy ln N entanglement-entropy law and near-unit noiseless trace-distance bound. It explicitly does not assert the same regularized law or local implementability of the Casimir effect.

`RESEARCH_STATE.md` identifies exact dependencies, failed transfers, original-family versus new-family interfaces, and the highest-value continuation. `SOURCES.json` records primary-source read depths and both immutable repository revisions. `PROPOSED_CARD.txt` is a scoped intake candidate, not an approved numbered repository card.

## Reproduce

Use Python 3.10 or later. The exact executed environment is in ENVIRONMENT.json; requirements.txt pins the installed numerical-library versions. No network access, models, cloud APIs, GPU, or separate agents are needed by the diagnostic scripts.

```bash
python -m pip install -r requirements.txt
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
python universal_probe_checks.py
python bounded_witness_and_certificates.py
python casimir_extremality_checks.py
```

Each script writes its JSON outputs next to itself and prints a summary. Existing `*_run.log` and `*_results.json` are actual executed outputs, not examples. They can be overwritten on rerun. Small platform-dependent floating errors are expected; the exact symbolic/rational certificates should not change. Seeds are fixed and recorded. The scripts share basic matrix/spin constructors and are not independent-agent verifications.

`explore_affine.py` and `sinkhorn_audit.py`, with their run logs, preserve exploratory falsification tests separately. They are not required for the proof. They print non-JSON NumPy representations and are deliberately not conflated with the final structured diagnostics.

The main script checks exact rational N4 spectra, 20 singleton transposes, 28 depolarizing formulas, 16 random-channel filtering interfaces, 50 exact moments and 50 independently formulated LP objectives. The bounded-score script checks 280 product and 48 target fixtures and a rational N60000 nonunital certificate. The Casimir script checks 1200 product fixtures, 24 balanced equalities and 10 entropy brackets. These finite computations do not certify continuum or all-size theorems.

## Resource and scope cautions

R_N is an engineered state with factorial total-spin weights. It is not the state prepared from I/2^N by the original collective thermal bath. The original thermal bounded-witness gate remains unresolved by this packet.

Channels act identically and independently on physical qubits, after preparation. No assertion covers different maps at different sites, correlated noise, higher local dimension, or arbitrary all-depth noise tolerance. The nonunital proof's filtering can have exponentially small success. The explicit unital three-axis test does not require that filtering.

Singleton separability is not full separability or positivity across all larger cuts. Depth is exactly two, not genuine N-party entanglement. No quantum-capacity, sensing, computing, thermodynamic or distillation advantage is proved.

MANIFEST.json hashes every delivered file except itself. Hashes establish integrity, not mathematical correctness. The repository was not modified or pushed. The ZIP is a local research handoff.
