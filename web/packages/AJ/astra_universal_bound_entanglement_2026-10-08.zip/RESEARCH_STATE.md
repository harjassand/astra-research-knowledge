# Research state: universal bound-entangled channel probes

**Date:** 8 October 2026. **Status:** internally derived mathematical results, executed diagnostics, no external review/priority clearance/proof-assistant formalization. No parallel agents. The requested comparison with the strongest October 2026 OpenAI release results has not been established.

## Exact strongest result

For even N=2n, R_N is proportional to sum_j P_{N,j}/(2j+1)!!, where P includes all spin multiplicities. For every fixed identical independent qubit CPTP noise Lambda, the same input sequence has this dichotomy:

- Lambda tensor Lambda EA on every physical two-qubit input => all Lambda^N(R_N) fully separable.
- Not EA => Lambda^N(R_N) is entangled for every sufficiently large even N.

All R_N (N>=4) and all entangled outputs are singleton-separable and depth exactly two. They are bound entangled for N separated labs, not necessarily PPT on larger cuts and not genuinely N-partite entangled. This is a state construction, not a claim that the earlier collective bath prepares it.

## New versus inherited

Inherited and reconstructed: Schur decomposition; random singlet pairs plus coherent-spin representation; qubit/rest-spin singleton-PPT block calculation; standard collective variance witness.

Established external premises: identical-unital two-qubit EA criterion, Filippov–Rybar–Ziman 2012 Prop.2; strict-positive quantum Sinkhorn normal form, read with its exact invertibility/positivity contract in Filippov 2021 Sec.II. The latter credits Gurvits, Georgiou–Pavon and Aubrun–Szarek. An early draft's erroneous upstream author attribution was corrected from the source bibliography; no false reference remains a premise.

Proposed new claims, historical priority UNKNOWN:
1. Factorial central sequence is simultaneously stochastically minimal in total spin among **all** singleton-PPT states; exact limiting minimum <J^2> is 3.8065898954731177...
2. One fixed bound-entangled, two-producible sequence attains the EA boundary of every identical qubit channel, including nonunital and rank-deficient channels.
3. Explicit finite unital witness, and bounded no-postselection three-axis score with gap delta^2/72 at N delta>=4096 and sample count ceiling[10368 delta^-4 ln(2/alpha)].
4. Exact balanced-product extremality for positive common-rotation averages, especially exp(-tJ^2); ordinary single-copy E_R(R_N)=ln N+O(1) and near-unit noiseless half-trace distance >=1-7/sqrt N-2/N.
5. For every continuous qubit CPTP semigroup, binary entanglement lifetimes of R_N converge to the two-qubit EA time.

## Dependency graph

Singleton block coefficients h_j<= (2j+3)h_(j+1)
 -> saturated f_j=1/(2j+1)!!
 -> singleton separability, decreasing spin distribution, global stochastic optimum.

Central Schur projector = random singlet-pair/coherent-product mixture
 -> depth<=2 and exact EA-side separability.

Quantum Sinkhorn + identical-filter singlet determinant identity
 -> output-only filtering with normalized, zero-mean unital-equivalent pair states.
Factorial spin tails tolerate every fixed exponential filter tilt
 -> uniformly O(1) active-spin cost versus extensive variance deficit
 -> universal non-EA survival.
Small extra local depolarization
 -> strict-positive approximation preserving a fixed pair entanglement witness
 -> arbitrary boundary channels, same input sequence.

Exact unital pair correlations + product-state smooth Lindeberg estimate
 -> finite bounded three-axis score and sample count, no postselection.

Positive common-rotation probability measures + Holder + balanced qubit products
 -> sharp heat-effect full-SEP bound
 -> single-copy KL lower and explicit separable comparator upper
 -> ln N ordinary E_R and noiseless trace-distance->1.

## Repository and file provenance

Original prior snapshot: ca22fffaeab073aaa1bbb690ce1b4250fc272956.
Late reconciliation snapshot: 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce, commit timestamp 2026-10-08T09:47:55Z.
The current start guide, upstream route, priorities, quantum topic route, and N160-sharp-unital-noise-boundary review notice were read. Original previous-turn complete proof and restart were read directly from mounted conversation files using Files. No full-corpus claim is made.

IMPORTANT: N160 and the current G-UNITAL-NOISE-BOUNDED-SCORES gate concern the original thermal family with typical j~sqrt N. New R_N has tight j=O(1). Its bounded-score theorem does NOT resolve that gate for the original input. Current critical-bath N179/N180 results are not premises. The unrelated Formanek correction in the latest state is retained as a reason not to repeat the historical no-go gloss; it plays no part in this investigation.

## Adversarial checks and rejected transfers

1. Pair entanglement in an unrecorded mixture does not prove mixture entanglement. The new proof supplies a full collective witness after an output-only product filter.
2. Sinkhorn prefilter B is NOT applied to R_N. Applying it would violate channel independence. Its determinant action on every singlet is the bridge that avoids changing the input.
3. Identical maps are essential. Different B_i do not satisfy the same singlet identity. No site-dependent/correlated-noise theorem follows.
4. A generic nonunital substitution s+|c|^2>1 is incomplete. Exact generalized amplitude damping eta=1/4,p=9/10 has score .9225 but singlet PT eigenvalue -1/1600. R_60000 has an exact output-filtered witness.
5. That GAD output's leading centered Gaussian limits also have an explicit separable product realization. Matching fluctuation means/covariances does not prove state-level trace proximity or separability; it blocks a proposed simple Gaussian-only converse.
6. Postselection in the general proof can cost exp(-cN). For the explicit GAD witness log success=-1.0678957948...N+O(1). Binary survival is not an efficient laboratory advantage or a nonvanishing unfiltered gap.
7. Unital finite-size second-moment certification and bounded-score/sample-size certification have different thresholds. At lambda=.58 the former gives even N>=586, not the latter.
8. Ordinary E_R=ln N+O(1) is NOT automatically regularized. The Casimir effect is not N-party LOCC, so conditioning can invalidate the laboratory-separable alternative class. Only the separate small noisy lower bound in Theorem C is regularization-safe.
9. Singleton-PPT is not fully PPT. Separability at each singleton cut does not imply full separability or a common product decomposition across all sites.
10. No result in this packet resolves bipartite NPT bound entanglement, proves GME, quantum capacity, fault-tolerant advantage, sensing gain, thermodynamic gain, or efficient entanglement distillation.
11. The pure singlet pair already tests two-qubit noise. The construction's claim is identical boundary attainment by bound-entangled states, not a superior way to characterize a channel.
12. Some exact-string and broad web searches returned irrelevant results. No-hit searches are not a priority certificate. The related primary literature was read at the depths recorded in SOURCES.json.

## Actual verification record

Main script: 4 dense states N2/4/6/8; 20 singleton PTs; 28 depolarizing exact-moment comparisons; 16 random-channel normal-form/normalizer checks; 50 exact rational spin moments; 50 independently formulated LP objectives. Maximum errors in results JSON.

Bounded/certificate script: 280 exact-convolution product-score diagnostics and 48 dense target-score diagnostics, exact four-qubit spectra in main script, exact rational GAD finite-size certificate, exact Gaussian-matched affine moments. Floating evaluations of finite convolution laws are not rational interval proofs; they are exact-distribution diagnostics evaluated numerically.

Additional Casimir script: 24 balanced-product equality checks, 1200 random pure-product fixtures, 10 relative-entropy brackets through N512. Maximum balanced equality error 1.27e-14.

Exploratory affine and Sinkhorn scripts are retained separately. They are not independent-agent verification. Python/sympy exact identities and spectra are not a formalization of the all-size proof.

## Highest-value continuation

The mathematically strongest unresolved operational question is whether arbitrary nonunital non-EA channels preserve a nonvanishing **unfiltered** separation from full separability for this fixed sequence, or whether there is a binary-survival/vanishing-distance regime. The exact GAD fixture should be the first test: its obvious Gaussian limits have separable realizations and its current certificate has exponentially small success. Any successful route must use a genuinely stronger observable/state comparison rather than reasserting the covariance criterion.

A separate information-theoretic gate is the exact regularized relative-entropy growth of R_N. The single-copy ln N theorem does not close it. Avoid conditioning on a global collective measurement while pretending laboratory separability is preserved.

Specialist audit priorities: global twirling and stochastic dominance; normal-form scalar/determinant normalization; uniformly bounded tilted active-spin weight; operational measurement/sample constants; priority comparison with permutation-invariant mixed states and channel-robustness literature. These are explicit complete derivations here, not missing premises, but remain externally unreviewed.

No repository changes were pushed. All outputs are a local reproducibility handoff.
