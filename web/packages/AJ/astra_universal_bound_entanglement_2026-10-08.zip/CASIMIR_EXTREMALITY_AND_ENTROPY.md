# Balanced-product extremality and the amount of entanglement

**Continuation, 8 October 2026. Status:** self-contained internal derivation, not external verification or historical priority clearance. This note concerns the new factorial-spin sequence R_N, not the old collective-thermal state. N=2n is even. Logs are natural. Definitions and Theorems A–C are in `UNIVERSAL_BOUND_ENTANGLEMENT_PROOF.md`.

## Theorem D: an exact full-separability bound

For every t>=0,

\[
\max_{\sigma\in\mathrm{SEP}_N}\operatorname{tr}(\sigma e^{-tJ^2})
=b_N(t):=\frac1{\binom{2n}{n}}\sum_{j=0}^n m_{N,j}e^{-tj(j+1)}. \tag{D1}
\]

The bound is attained by the pure product state with n spins up and n spins down along any one common axis, and also by its common-rotation/permutation twirl. It is an optimization over **all** fully separable states, not only invariant states. At t=infinity it gives the singlet-projector bound 1/(n+1).

More generally, for any conjugation-invariant probability measure mu on SU(2),

\[
\left|\int\prod_{i=1}^N\langle r_i|U|r_i\rangle\,d\mu(U)\right|
\le\int|\langle\uparrow|U|\uparrow\rangle|^{N}d\mu(U). \tag{D2}
\]

The right side is exactly the expectation of the corresponding averaged tensor-power operator on the balanced product. This statement about an integral does not claim that every central positive operator has such a positive group measure.

### Proof of the extremality statement

For a pure product, apply triangle inequality and Holder with N equal exponents:

\[
\left|\int\prod_i\langle r_i|U|r_i\rangle d\mu\right|
\le\prod_i\left(\int|\langle r_i|U|r_i\rangle|^N d\mu\right)^{1/N}.
\]

Every factor has the same value, because pure qubit states are a single SU(2) orbit and mu is conjugation-invariant. For SU(2), the two diagonal entries of U in any orthonormal basis are complex conjugates. The balanced product therefore has integrand exactly |U_00|^(2n), attaining the bound pointwise. Mixed product factors and arbitrary separable mixtures follow by convexity.

To obtain e^(-tJ^2), one does not need to assume a signed Fourier representation is positive. For an integer L, let each independent rotation have angle a_L=sqrt(6t/L), with a uniformly random spatial axis. Its distribution is conjugation-invariant. In the N-qubit representation,

\[
\mathbb E e^{ia_L\widehat u\cdot J}=I-tJ^2/L+O_N(L^{-2}).
\]

The tensor-power average of the product of L independent rotations is the Lth power of this matrix, which tends in operator norm to e^(-tJ^2). The convolution measure remains a conjugation-invariant **probability** measure. Apply (D2) at each L and pass to the limit. This also reconstructs the required positive heat-measure representation without importing a new research theorem.

Finally, the diagonal entries of P_{N,j} are equal on computational strings of magnetization zero, because site permutations act transitively on those strings. The trace of P_{N,j} on that magnetization subspace is m_{N,j}; the subspace dimension is binom(2n,n). Thus the balanced-product spin probabilities are m_{N,j}/binom(2n,n), proving (D1).

## Independent finite-size entanglement check

The t=infinity case proves max_SEP tr(sigma P_{N,0})=1/(n+1). For R_N, that probability is m_{N,0}/Z_N. Set q_j=m_{N,j}/binom(2n,n). Since sum_j q_j=1,

\[
Z_N/\binom{2n}{n}=\sum_jq_j(2j+1)f_j\le1.
\]

For every even N>=4, q_2>0 and (2*2+1)f_2=1/3<1, so this inequality is strict. Hence R_N has singlet probability >1/(n+1) and is entangled. For N=2 equality holds. This supplies an all-size proof independent of the C_N calculation. For N=4 the exact target singlet probability is 3/8, exceeding the separable maximum 1/3.

## Consequence 1: an exact leading relative-entropy law

Define the ordinary, single-copy relative entropy to full separability by

\[
E_R(R_N)=\inf_{\sigma\in\mathrm{SEP}_N}D(R_N\|\sigma).
\]

Then

\[
\boxed{E_R(R_N)=\ln N+O(1).} \tag{D3}
\]

More explicitly, for every fixed t>0,

\[
\ln(n+1)-\ln H(t)-tC_N\le E_R(R_N)\le\ln(n+1),
\quad H(t)=\sum_{j\ge0}(2j+1)e^{-tj(j+1)}. \tag{D4}
\]

**Lower bound.** Measurement of total spin and classical relative-entropy data processing give, for any separable sigma with spin probabilities q_j,

\[
D(R_N\|\sigma)\ge D(p_N\|q)\ge-tC_N-\ln\sum_jq_je^{-tj(j+1)}
\ge-tC_N-\ln b_N(t).
\]

The multiplicity identity

\[
\frac{m_{N,j}}{\binom{2n}{n}}=
\frac{2j+1}{n+j+1}\frac{\binom{2n}{n-j}}{\binom{2n}{n}}
\le\frac{2j+1}{n+1}
\]

implies b_N(t)<=H(t)/(n+1). Since C_N<4, the lower bound has coefficient one in ln N.

**Upper bound.** Twirl the balanced product over common rotations and all permutations. The resulting fully separable state tau_N is central, with spin law q_j=m_{N,j}/binom(2n,n) and coefficient 1/[(2j+1)binom(2n,n)] on P_{N,j}. Therefore

\[
D(R_N\|\tau_N)=\sum_jp_{N,j}\ln\left[(2j+1)f_j\binom{2n}{n}/Z_N\right].
\]

Here (2j+1)f_j<=1, while Z_N>=m_{N,0}=binom(2n,n)/(n+1). Every likelihood ratio in this sum is <=n+1, proving the upper bound. The exact displayed finite sum is generally sharper.

**Important limit:** (D3) is NOT a theorem for regularized relative entropy. The total-spin measurement is not an N-laboratory LOCC measurement. Applying it sequentially to an alternative with within-laboratory cross-copy entanglement need not preserve laboratory separability after conditioning. The usual single-copy proof cannot silently establish E_R^infinity=ln N+O(1). That remains open here.

## Consequence 2: near-unit distance despite singleton separability

The half-trace distance obeys the explicit bound

\[
\boxed{\operatorname{dist}_{\rm tr}(R_N,\mathrm{SEP}_N)
\ge\max\{0,1-7/\sqrt N-2/N\}.} \tag{D5}
\]

Use the bounded global effect e^(-tJ^2). Its target expectation is >=1-tC_N>1-4t and its separable expectation is <=H(t)/(n+1). For j>=1,

\[
(2j+1)e^{-tj(j+1)}\le\frac{3}{2t}
\left(e^{-t(j-1)j}-e^{-tj(j+1)}\right),
\]

using 1-e^(-x)>=xe^(-x). Telescoping yields H(t)<=1+3/(2t). Setting t=N^(-1/2) gives b_N(t)<=3/sqrt N+2/N, proving (D5).

This effect can be measured by resolving total spin and scoring e^(-tj(j+1)), but a full total-spin measurement is a collective operation. It is NOT the local three-axis measurement in Theorem C. Both facts coexist: a three-axis local witness certifies noisy entanglement with the stated constant gap, while the stronger near-unit noiseless distance is established using a global effect.

## Scope and verification

The balanced-product extremality proof is separate from the Gaussian replacement argument in Theorem C. Its decisive ingredients are a positive conjugation-invariant measure, Holder's inequality, the conjugate SU(2) diagonal entries, and the exact magnetization-zero multiplicity count. For odd N, higher local dimension, arbitrary central operators, signed kernels, or regularized relative entropy, the same conclusion has not been proved here.

The diagnostic `casimir_extremality_checks.py` tests dense finite-N heat operators on random product states and checks exact equality on the balanced product, then evaluates the distinct central-state relative entropy and its analytic brackets. Finite fixtures support algebra and do not certify a continuum optimization or asymptotic theorem. Historical novelty of (D1) and (D3) remains unestablished; search results did not supply a sufficiently precise priority comparison.
