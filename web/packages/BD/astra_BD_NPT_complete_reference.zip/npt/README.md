# Research package — 9 October 2026

**No foundational problem is resolved.** Start with `RESEARCH_RECORD.md` for the exact target, proved identities, complete algebraic proofs, restricted consequences, and unclosed obligation. Do not interpret numerical nonnegativity as an all-copy theorem.

## Contents

`npt_core.py`, `verify_identity.py`, `verify_general_block.py` and their receipts implement the block identities. `graph_code_search.py`, `mixed_graph_search.py`, `focused_graph_search.py`, and `verify_graph_exact.py` implement restricted graph-basis tests with exact finite-field arithmetic. `search_witness.py` is an uncertified complex rank-two local optimizer. JSON files retain outcomes and seeds. `SOURCE_MANIFEST.json` records reading scope and repository pins. `SHA256SUMS` hashes the other delivered files.

## Reproduce

Python 3 with NumPy is needed for the exact calculations. SciPy is needed only for the local optimization script. These scripts use no internet access and make no repository changes. Run from this directory:

```sh
python verify_identity.py
python verify_general_block.py
python verify_graph_exact.py
python graph_code_search.py --n 6 --graphs 4 --batch 512 --check
python graph_code_search.py --n 8 --graphs 4 --batch 512
python mixed_graph_search.py --n 6 --graphs 4 --batch 512 --check
python focused_graph_search.py
python search_witness.py --help
```

To reduce numerical-library thread overhead, set `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1` before the commands. Graph searches scale exponentially with the number of sites, and the exact implementation deliberately rejects sizes beyond its integer-safety bound. Re-running scripts overwrites the corresponding local receipts. Floating-point search outputs can differ across library versions and hardware; they are not exact certificates.

The code and record have not been formally verified or externally reviewed. Algebraic proofs, finite exact calculations, exploratory numerical searches and historical priority are separate evidence levels.
