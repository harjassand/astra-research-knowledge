# NPT bound-entanglement investigation: exact block identities and finite witness tests

**Date:** 9 October 2026, Australia/Brisbane.  
**Outcome:** No foundational problem was resolved. This is not a 10/10 result.

The completed mathematics below consists of exact identities and their stated restricted consequences. No all-copy Werner theorem, NPT bound-entangled state, or distillability counterexample is established. Historical priority is unestablished; these identities use established partial-trace and swap algebra. The attached computations are finite checks, not substitutes for the algebraic proofs. There has been no proof-assistant verification or external review of this record.

## 1. Research capital and inherited mathematics

Astra was entered through `00_START_HERE.txt`. Its accessed revision was
`4e3b480b9b85cb608d170eed5f739496cb5c85b4`.
The relevant raw status record was
`frontier/cards/N304-Werner-all-copy-open-target.json`.
The exact investigation was read through
`web/pages/d-a75bfd3037c2b9ca.html`; its logical source path and evidence-object path were not directly retrievable through the repository contents API. The source explicitly leaves the all-copy target unresolved and restricts its positive Schur argument to product-ray support planes. Those restrictions were not removed here.

OpenAI math was accessed at
`fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.
The original `coherence.tex` and `secret-key.tex` sections of the dimension-ten zero-secret-key manuscript were examined. Their represented class uses local maps that are both completely positive and completely copositive. Every represented state is PPT: if a local map is input-completely-copositive, write it as N composed with input transpose, with N completely positive. Conjugating the Kraus operators of N shows that output transpose composed with the original map is also completely positive. Thus a partial transpose on one output leaves completely positive maps acting on a positive input. Consequently, that representation supplies no NPT candidate by itself. Its four-effect inequality was not imported with weakened hypotheses.

Primary literature inspected includes the rank-two criterion and two-copy proofs in Fraser–Huber–Pozsgay–Vona, arXiv:2607.24309v1 [S3], and Bharti–Gajjala–Haug, arXiv:2607.24479v1 [S4]. The exact two-copy inequality is prior mathematics, not a result of this run. Qi et al., arXiv:2402.18037v1 [S5], already investigate rank-one reformulations and Hessian questions; neither the general perturbative viewpoint nor a rank-one-pair reformulation is claimed as new. The source-reported October three-copy rational certificate was not independently replayed and is not an assumption of any result below.

## 2. Fixed foundational target

The target is existence of a finite-dimensional state with negative partial transpose that is undistillable under arbitrary finite-copy local operations and classical communication. The candidate selected was

\[
\rho_*=(2I_9-F_3)/15,
\]

where \(F_3\) swaps the two qutrit factors. The symmetric and antisymmetric subspaces have dimensions six and three, so the eigenvalues of \(\rho_*\) are \(1/15\) and \(3/15\), with these multiplicities. Thus it is positive with trace one.

With \(\Omega=\sum_{j=0}^2e_j\otimes e_j\),

\[
\rho_*^\Gamma=\frac2{15}\left(I-\frac12\Omega\Omega^*\right),
\qquad \rho_*^\Gamma\Omega=-\Omega/15.
\]

It is therefore NPT. For \(H_n=(\mathbb C^3)^{\otimes n}\), define

\[
q_n(C)=\sum_{S\subseteq[n]}(-1/2)^{|S|}\|\operatorname{Tr}_S C\|_F^2.
\tag{1}
\]

Partial trace contracts matching row and column slots, retaining the untraced order. Vectorization and expansion of the tensor product give

\[
\langle\operatorname{vec}C,(\rho_*^\Gamma)^{\otimes n}\operatorname{vec}C\rangle
=(2/15)^nq_n(C),
\qquad \operatorname{SR}(\operatorname{vec}C)=\operatorname{rank}C.
\tag{2}
\]

The exact missing statement is

\[
q_n(C)\ge0\quad\text{for every }n\ge1\text{ and every complex }C\text{ with rank at most two}.
\tag{T}
\]

This is the established Werner formulation [S4, Sections 2–3], not a new reduction. At one copy, \(|\operatorname{Tr}C|\le\|C\|_1\le\sqrt2\|C\|_F\) proves the claim. The two-copy literature provides the next case. Neither a fixed-copy result nor local positivity around some zero witnesses establishes (T).

A negative value for this particular candidate would refute its proposed undistillability, not disprove the existential NPT bound-entanglement question.

## 3. Completed rank-preserving block identity

All identities also apply when the remaining physical dimensions are unequal. Write
\(H=\bigotimes_{i=1}^m\mathbb C^{d_i}\), and define \(q_{\boldsymbol d}\) as in (1). Empty products mean \(H=\mathbb C\) and \(q_\varnothing(z)=|z|^2\).

Let

\[
b_{\boldsymbol d}(A,B)=\sum_{S\subseteq[m]}(-1/2)^{|S|}
\operatorname{Tr}\big[(\operatorname{Tr}_S A)^*\operatorname{Tr}_S B\big],
\]

so \(q_{\boldsymbol d}(A)=b_{\boldsymbol d}(A,A)\). Let \(F_i\) exchange the two copies of the \(i\)-th factor of \(H\otimes H\), and set

\[
R_{\boldsymbol d}=\prod_{i=1}^m(I-\tfrac12F_i).
\tag{3}
\]

These commuting factors are positive definite; each has eigenvalues among \(1/2,3/2\). In particular, \(R_{\boldsymbol d}\succeq2^{-m}I\).

### Lemma: crossed swap contraction

For arbitrary \(u,v,x,y\in H\),

\[
b_{\boldsymbol d}(uv^*,xy^*)
=\langle u\otimes y,R_{\boldsymbol d}(x\otimes v)\rangle.
\tag{4}
\]

**Proof.** For each subset \(S\), directly contracting the row and column indices yields

\[
\operatorname{Tr}\big[(\operatorname{Tr}_Suv^*)^*\operatorname{Tr}_Sxy^*\big]
=\langle u\otimes y,F_S(x\otimes v)\rangle,
\qquad F_S=\prod_{i\in S}F_i.
\]

For example, on a traced single slot the contraction is
\(\langle u,v\rangle\langle y,x\rangle\); on an untraced slot it is
\(\langle u,x\rangle\langle y,v\rangle\). The same index matching works for entangled vectors across the remaining slots; no factorization of these vectors is assumed. Summing over \(S\) proves (4). In particular,

\[
q_{\boldsymbol d}(xv^*)=\langle x\otimes v,R_{\boldsymbol d}(x\otimes v)\rangle\ge0.
\tag{5}
\]

### Theorem: qutrit lifting identity

For arbitrary \(u,v,x_0,x_1,y_0,y_1\in H\) and real \(\varepsilon\), put

\[
C_\varepsilon=\sum_{a=0}^1
(e_a\otimes u+\varepsilon e_2\otimes x_a)
(e_a\otimes v+\varepsilon e_2\otimes y_a)^*,
\qquad D=x_0y_0^*+x_1y_1^*.
\tag{6}
\]

Both matrices have rank at most two. Exactly,

\[
\boxed{
q_{(3,\boldsymbol d)}(C_\varepsilon)
=\varepsilon^2\sum_{a=0}^1
\big\|R_{\boldsymbol d}^{1/2}(x_a\otimes v-u\otimes y_a)\big\|^2
+\frac{\varepsilon^4}{2}q_{\boldsymbol d}(D).
}
\tag{7}
\]

**Proof.** For any matrix with first-factor blocks \(C_{ij}\), separating the traced and untraced first slot in (1) gives

\[
q_{(d,\boldsymbol d)}(C)=\sum_{i,j=0}^{d-1}q_{\boldsymbol d}(C_{ij})
-\frac12q_{\boldsymbol d}\left(\sum_iC_{ii}\right).
\tag{8}
\]

The matrix in (6) has blocks

\[
C_\varepsilon=
\begin{pmatrix}
uv^*&0&\varepsilon uy_0^*\\
0&uv^*&\varepsilon uy_1^*\\
\varepsilon x_0v^*&\varepsilon x_1v^*&\varepsilon^2D
\end{pmatrix}.
\]

Writing \(A=uv^*\), its first-slot trace is \(2A+\varepsilon^2D\). Expanding (8) cancels the constant terms and leaves

\[
\varepsilon^2\sum_a\big[q(x_av^*)+q(uy_a^*)-2\operatorname{Re}b(A,x_ay_a^*)\big]
+\tfrac12\varepsilon^4q(D).
\]

Equations (4) and (5) turn each bracket into the squared norm in (7). This proves the identity for arbitrary complex vectors, without a lower-copy positivity premise. □

### Exact consequences and limits

The coefficient of \(\varepsilon^2\) is nonnegative for every number of remaining sites. This is the Hessian coefficient only along the displayed transverse family; it is not a statement about every tangent direction of every rank-two matrix.

If \(u,v\ne0\) and this coefficient vanishes, positive definiteness of \(R\) implies
\(x_a\otimes v=u\otimes y_a\) for each \(a\). Equality of these simple tensors gives \(x_a=c_au\), \(y_a=c_av\), with the same complex scalar. Hence
\(D=(|c_0|^2+|c_1|^2)uv^*\) has rank at most one and (7) is nonnegative for all \(\varepsilon\).

If \(q_{(3,\boldsymbol d)}(C_\varepsilon)<0\), then \(\varepsilon\ne0\) and necessarily \(q_{\boldsymbol d}(D)<0\). Therefore, a counterexample at the smallest possible copy count cannot belong to this entire lifting family. This is a restricted minimal-counterexample exclusion, not an exclusion of all counterexamples.

The missing coverage is substantive: arbitrary pairs of vectors in \((\mathbb C^3)^{\otimes n}\) do not possess the repeated upper-block structure in (6). No transformation preserving (1) that imposes this structure on an arbitrary rank-two matrix was proved. Also, the sign of \(q_{\boldsymbol d}(D)\) for general rank-two \(D\) remains precisely a lower-copy instance of the original problem.

### Dimension-descent extension

Let the first local dimension be \(d\ge3\), and for \(p=2,\ldots,d-1\) choose vectors \(x_{pa},y_{pa}\in H\). Replace the two factors in (6) by

\[
e_a\otimes u+\varepsilon\sum_{p=2}^{d-1}e_p\otimes x_{pa},\qquad
e_a\otimes v+\varepsilon\sum_{p=2}^{d-1}e_p\otimes y_{pa}.
\]

Define \(X_a=\sum_{p=2}^{d-1}f_{p-2}\otimes x_{pa}\),
\(Y_a=\sum_{p=2}^{d-1}f_{p-2}\otimes y_{pa}\), and
\(D=\sum_aX_aY_a^*\) on \(\mathbb C^{d-2}\otimes H\). Then

\[
q_{(d,\boldsymbol d)}(C_\varepsilon)
=\varepsilon^2\sum_{p,a}\|R_{\boldsymbol d}^{1/2}(x_{pa}\otimes v-u\otimes y_{pa})\|^2
+\varepsilon^4q_{(d-2,\boldsymbol d)}(D).
\tag{9}
\]

To prove this, apply (8). The lower-right block contributes its own first-factor quadratic form; the cross terms with \(2uv^*\) supply the displayed squares through (4). When \(d=3\), the remaining one-dimensional first factor multiplies \(q_{\boldsymbol d}\) by \(1/2\), recovering (7).

## 4. A different construction: exact graph-basis witness evaluation

The block calculation did not settle (T). A separate constructive search used complex graph-basis dyads, including different left and right graphs. The evaluation below proves exactly what the attached integer searches test; it does not prove positivity for every graph or every rank-two matrix.

Let \(\omega=e^{2\pi i/3}\), \(G\) a symmetric zero-diagonal matrix over \(\mathbb F_3\), and

\[
Q_G(z)=\sum_{i<j}G_{ij}z_iz_j,\qquad
|G_a\rangle=3^{-n/2}\sum_{z\in\mathbb F_3^n}\omega^{Q_G(z)+a\cdot z}|z\rangle.
\tag{10}
\]

These vectors form an orthonormal basis by character orthogonality.

### Same-graph closed formula

Fix \(\delta,v\in\mathbb F_3^n\), \(v\ne0\), and set
\(X=|G_0\rangle\langle G_{-\delta}|\),
\(Y=|G_v\rangle\langle G_{v-\delta}|\).
For each \(S\), write \(R=[n]\setminus S\),
\(M=G_{S,R}\), \(r=\operatorname{rank}_{\mathbb F_3}M\), and \(b=-\delta_S\).
Set \(a_S=3^{-r}\) when \(Mk=b\) is soluble, and zero otherwise. Set \(b_S=0\) unless this system is soluble and \(v_R\) belongs to the row space of \(M\). If both conditions hold, choose any solution \(k_0\) and set

\[
b_S=3^{-r}\omega^{v_R\cdot k_0}.
\]

This is independent of the solution because \(v_R\) annihilates \(\ker M\). With

\[
A=\sum_S(-1/2)^{|S|}a_S,\qquad B=\sum_S(-1/2)^{|S|}b_S,
\]

one has, for all complex \(\alpha,\beta\),

\[
q_n(\alpha X+\beta Y)=A(|\alpha|^2+|\beta|^2)+2\operatorname{Re}(\overline\alpha\beta B).
\tag{11}
\]

**Proof.** Direct summation over the traced variables gives

\[
(\operatorname{Tr}_S|G_a\rangle\langle G_b|)_{x,y}
=3^{-|R|}\omega^{Q_{G_R}(x)-Q_{G_R}(y)+a_R\cdot x-b_R\cdot y}
\mathbf1\{M(x-y)=b_S-a_S\}.
\tag{12}
\]

Here the labels \(a,b\) in (12) are arbitrary basis labels, distinct from the scalar quantities \(a_S,b_S\) defined above. For the diagonal norm, count the \(3^{|R|-r}\) admissible differences and \(3^{|R|}\) choices of \(y\), obtaining \(3^{-r}\). For the cross inner product, the phase remaining on the difference is \(v_R\cdot(x-y)\). The character sum over \(\ker M\) vanishes unless \(v_R\in\operatorname{row}M\); otherwise its value is \(3^{-r}\omega^{v_R\cdot k_0}\). Summing with the coefficients in (1) proves (11). □

Thus this whole two-dimensional dyad span is nonnegative exactly when \(A\ge|B|\). Writing \(A=a/L\), \(B=(p+q\omega)/L\), the test becomes the integer inequality
\(a^2\ge p^2-pq+q^2\), together with \(a\ge0\).

### Different left and right graphs

For graphs \(G,H\), take
\(X=|G_0\rangle\langle H_{-\delta}|\),
\(Y=|G_v\rangle\langle H_{w-\delta}|\), with \(v,w\ne0\).
Every linear combination still has rank at most two. The required two-by-two matrix is

\[
K=\begin{pmatrix}q_n(X)&b_n(X,Y)\\\overline{b_n(X,Y)}&q_n(Y)\end{pmatrix}.
\]

Its positivity is equivalent to positivity of the diagonals and the determinant. By (4), each summand in these three entries is a finite quadratic character sum. To make the evaluation reconstructible, write \(z=(x,y)\in\mathbb F_3^{2n}\),
\(A_0=\operatorname{diag}(2G,2H)\), and let \(P_S\) swap corresponding \(x,y\) coordinates in \(S\). The swap expectation
\(\langle G_a\otimes H_d,F_S(G_c\otimes H_b)\rangle\) equals

\[
3^{-2n}\sum_z\omega^{z^TAz+\ell^Tz},\quad
A=P_S^TA_0P_S-A_0,\quad
\ell=P_S^T(c,b)-(a,d).
\tag{13}
\]

Diagonalize by a congruence over \(\mathbb F_3\):
\(E^TAE=\operatorname{diag}(d_1,\ldots,d_r,0)\), with each \(d_i\in\{1,2\}\), and \(\ell'=E^T\ell\).
If any of the last \(2n-r\) coordinates of \(\ell'\) is nonzero, the sum is zero. Otherwise, completing squares and using
\(\sum_{t\in\mathbb F_3}\omega^{t^2}=1+2\omega\) and
\(\sum_t\omega^{2t^2}=-(1+2\omega)\) gives exactly

\[
\omega^{-\sum_{i=1}^r d_i(\ell_i')^2}
\frac{(-1)^{\#\{i:d_i=2\}}(1+2\omega)^r}{3^r}.
\tag{14}
\]

Equations (13)–(14), summed over \(S\) with coefficient \((-1/2)^{|S|}\), evaluate every entry of \(K\). They include singular quadratic forms. Since \((1+2\omega)^2=-3\), the result lies in \(\mathbb Q(\omega)\). There are \(2^n\) subsets: this is an exponential-time formula, not a polynomial-time arbitrary-witness algorithm.

The implementation uses scale \(L=2^n3^n\), representing an entry by two integers \((p,q)\). The smaller same-graph formula uses \(2^n3^{\lfloor n/2\rfloor}\). Integer arithmetic is restricted to \(n\le16\) in the supplied implementation; at that bound a conservative coordinate-sum bound \(2\,4^n3^n<2^{63}\) avoids signed-int64 overflow. Determinant products are converted to arbitrary-precision Python integers.

## 5. What was actually checked

- **Block identities:** 24 exact real-integer checks of (7), plus 36 of (9), all passed. Sixteen additional complex floating-point checks of (7) had maximum relative residual below \(8\times10^{-15}\). The proof is the algebra above, not the finite checks.
- **Negative and zero controls:** the checker returned \(q_1(I_3)=-3/2\) and \(q_1(\operatorname{diag}(1,1,0))=0\). The negative control has rank three and is inadmissible for (T).
- **Unrestricted parameter searches:** twelve complex rank-two L-BFGS runs, six at three copies and six at four copies, found no negative value. These are local searches, not certified minima or fixed-copy proofs.
- **Exact graph tests:** 4,096 same-graph tests at six/eight copies, 2,048 mixed-graph tests at six copies, and 4,352 focused tests at eight copies. All 10,496 tests had nonnegative two-by-two forms. This count includes repetitions; it is not a claim of 10,496 distinct spans. Positivity covers every complex linear combination within each tested dyad span, not all rank-two matrices.
- **Independent arithmetic checks:** 48 complex entries from (13)–(14) agreed exactly with direct enumeration of all characters at one through four sites, using integer counts rather than Gaussian elimination. The independent same-graph and mixed-graph formulas also agreed exactly on 24 label pairs at two/four/six sites. Separate floating-point materializations supplied 72 same-graph and 60 mixed-graph comparisons.

All receipts, seeds and scripts are included. Finite evidence does not establish (T), global positivity of the graph families, historical novelty, or independent formal verification.

## 6. Final scientific status

**Completed:** the rank-preserving identities (7) and (9), their restricted minimal-counterexample consequence, and the exact graph-state evaluation formulas with reconstructible implementations.

**Not completed:** nonnegativity for arbitrary rank-two matrices at every copy count; a negative admissible witness; a new NPT bound-entangled state; a reduction that actually removes the global compatibility problem; or a historic foundational breakthrough.

No claim in this record should be entered as a solved foundational problem. The missing step is not another constant or numerical precision improvement: it is an argument controlling arbitrary complex rank-two support pairs, outside the special block and graph constructions.

## Source locators

[S1] Astra, pinned revision and relevant source routes above: https://github.com/harjassand/astra-research-knowledge/tree/4e3b480b9b85cb608d170eed5f739496cb5c85b4

[S2] OpenAI math, pinned revision: https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb ; original sections under `preprints/Entanglement-with-zero-distillable-secret-key-in-local-dimension-ten-September-27-2026/build/source/sections/`.

[S3] Fraser, Huber, Pozsgay and Vona, *On the two-copy distillability of Werner states and a new partial trace inequality*, accessed v1: https://arxiv.org/html/2607.24309v1

[S4] Bharti, Gajjala and Haug, *Two-copy nondistillability of Werner states: sharp partial-trace inequalities and finite-copy extensions*, accessed v1: https://arxiv.org/html/2607.24479v1

[S5] Qi, Gupur, Wu and Guo, *Unveiling NPT bound problem: From Distillability Sets to Inequalities and Multivariable Insights*, accessed v1, especially Sections V–VI: https://arxiv.org/html/2402.18037v1
