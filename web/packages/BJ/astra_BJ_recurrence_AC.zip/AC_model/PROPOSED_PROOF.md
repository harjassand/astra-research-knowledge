# Excluding absolutely-continuous invariant models

Status: detailed proof candidate for closed compact smooth manifolds. It modifies the source's finite-word construction and adapts its switching proof; it is not the identical symbolic system in the source paper. The boundary case is not included. I have not run an independent audit or formal verification.

## 1. Exact target

> **Theorem (AC obstruction).** There exists an ergodic invertible standard nonatomic probability-preserving system \((X,T,\mu_0)\) with zero Kolmogorov–Sinai entropy such that no closed compact smooth finite-dimensional manifold \(M\), smooth diffeomorphism \(S:M\to M\), and \(S\)-invariant ergodic probability \(\mu\ll\nu\) can realize it measurably, where \(\nu\) is any smooth positive volume on \(M\). A zero-dimensional compact manifold is finite and cannot support the nonatomic system, so the proof only needs to treat positive dimension.

The invariant density \(d\mu/d\nu\) may be merely measurable, unbounded, and may vanish on a set of positive \(\nu\)-measure. Thus the system can have no absolutely-continuous invariant model at all. Since a smooth diffeomorphism preserves the smooth-volume measure class, the Lebesgue decomposition of an invariant probability is invariant. An ergodic invariant probability is therefore either absolutely continuous or singular. Consequently every smooth model of this system, if one exists, must carry a purely singular invariant probability.

This does **not** exclude singular invariant Borel measures. It is a necessary-condition result for any remaining smooth model, not a solution of the arbitrary-measure smooth-realization problem.

## 2. Pinned source and what is changed

Source: OpenAI `math` repository, commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`, preprint directory `preprints/A-finite-entropy-system-without-a-smooth-positive-volume-model-September-25-2026/`, PDF SHA-256 `67d6dd8619de6c6fc11eb88edd3791b180a2c3c9bc6d5a6a68f272a5ab445687`.

Pinned link: [source PDF at the pinned revision](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finite-entropy-system-without-a-smooth-positive-volume-model-September-25-2026/paper.pdf).

The source proves Theorem 1.1 only for smooth positive invariant densities. Its introduction explicitly distinguishes invariant measures merely equivalent to volume and says no obstruction for all equivalent-to-volume measures is asserted (PDF pp. 2–3, Remark 7.4). The result here changes the source's finite-word tolerance sequence, so it establishes existence of a modified system from the same construction, not a stronger theorem about the source's already-fixed example.

The argument combines two source-dependent reconstructions with new transfer steps:

* Source Proposition 2.2 supplies stationary derivative control under the invariant \(\mu\); source §§3–4 (finite-interval estimates, orbit-array switch, relative-minor cancellation, and injectivity) are rerun with a localized smooth pair-law reference.
* Source Theorem 5.1 is rebuilt with vanishing TV tolerances; source §§6–7 then provide the zero-entropy system, list tests, and graph contradiction, transferred through a small-contamination decomposition.

## 3. Uniform absolute continuity for the main component

Suppose the model measure \(\mu\) is invariant and \(\mu\ll\nu\), and write \(f=d\mu/d\nu\). Let \(D\subset M\) be an exactly invariant conull set on which the hypothetical measurable conjugacy \(J:D\to X\) and its inverse satisfy the orbit identities. For any small \(\epsilon>0\), choose \(0<a<b<\infty\) and a compact set
\[
 K\subset D\cap\{a\le f\le b\},\qquad \mu(K)>1-\epsilon.
\]
This is possible by truncating \(f\) away from zero and infinity, intersecting D, then using regularity. Then \(\nu(K)\ge\mu(K)/b>0\), and \(\nu|_K\ll\mu\) with density \(d\nu|_K/d\mu=1/f\le1/a\).

For any probability \(\lambda\ll\mu\), define
\[
 \omega_\lambda(s)=\sup_{\mu(A)\le s}\lambda(A).
\]
Then \(\omega_\lambda(s)\to0\) as \(s\downarrow0\), and invariance of \(\mu\) yields
\[
 (S^t)_*\lambda(A)\le\omega_\lambda(\mu(A))\quad(t\in\mathbb Z). \tag{3.1}
\]
Thus the normalized K-law and every one of its shifts are uniformly absolutely continuous with respect to \(\mu\). No such conclusion is needed for the small discarded component.

## 4. Localized smooth-switch lemma for a vanishing density

By outer regularity choose an open \(U\supset K\) with \(\nu(U\setminus K)<\epsilon\nu(K)\). Choose a smooth domain \(O\) with smooth, hence \(\nu\)-null, boundary and \(K\subset O\Subset U\). For example, take a smooth cutoff equal to one near K and supported in U, then take O to be a superlevel set at a regular value in (0,1), using Sard's theorem. Choose a bump \(g\in C^\infty(M)\), \(0\le g\le1\), equal to one on a neighborhood of \(\overline O\) and supported in U. Put
\[
 Z=\int g\,d\nu,\qquad \widetilde\nu=Z^{-1}g\nu,\qquad p=\widetilde\nu(K).
\]
Then \(Z\ge\nu(K)\), \(Z\le\nu(U)<(1+\epsilon)\nu(K)\), so \(p>1/(1+\epsilon)>1-\epsilon\). Also \(\widetilde\nu(M\setminus O)\le\nu(U\setminus K)/\nu(K)<\epsilon\). On O, \(g=1\), hence \(\widetilde\nu=Z^{-1}\nu\). The normalized main component \(\widetilde\nu_K=\widetilde\nu|_K/p=\nu|_K/\nu(K)\) is absolutely continuous with respect to \(\mu\), with density at most \(1/(a\nu(K))\). Define
\[
 \omega_K(s)=\sup_{\mu(A)\le s}\widetilde\nu_K(A)\longrightarrow0.
\]
Invariance of \(\mu\) gives the exact uniform-shift estimate
\[
 (S^t)_*\widetilde\nu_K(A)=\widetilde\nu_K(S^{-t}A)
 \le\omega_K(\mu(S^{-t}A))=\omega_K(\mu(A)). \tag{4.1}
\]

### Lemma 4.1 (localized switch)
Fix this localized reference \(\widetilde\nu\) and its main mass \(p=\widetilde\nu(K)\). For every additional loss parameter \(\eta>0\), for all sufficiently large dyadic \(n=2^k\), there is a finite Borel partition \(\mathcal P_k\) of M and a retained set \(G_k\) with complementary switches \(z_k,w_k\) such that:

1. \(\log\#\mathcal P_k\le C B_kn\), where \(\sum_k B_k^{16}<\infty\);
2. the cell-weighted pair law
   \[
   \rho_k=\sum_{Q\in\mathcal P_k,\,\widetilde\nu(Q)>0}
      \frac{(\widetilde\nu|_Q)\otimes(\widetilde\nu|_Q)}{\widetilde\nu(Q)}
   \]
   satisfies \(\rho_k(G_k)\ge1-8(1-p)-\eta\);
3. the pair map \(\Phi_k=(z_k,w_k)\) is measurable and injective on \(G_k\), and its restriction to a countable measurable partition of \(G_k\) agrees piecewise with smooth local diffeomorphisms;
4. writing \(g_k=b_k^{1/2}\), the first switch obeys the source's quantitative shadow bound
   \[
   \max_{0\le t\le n}d_M(S^tz_k(x,y),S^tx)
   +\max_{-n\le t\le0}d_M(S^tz_k(x,y),S^ty)
   \le e^{C g_k n}r=o(1),
   \]
   uniformly on \(G_k\), with the analogous bound for \(w_k\) after exchanging \(x,y\);
5. the unnormalized output satisfies \((z_k)_*(\rho_k|_{G_k})\le2\widetilde\nu\).

#### Proof
This is a restriction of the source §4 construction, not an invocation of its invariant-volume theorem. I spell out the interfaces and changed estimates.

**Derivative and cell data.** Apply source Proposition 2.2 to the invariant measure \(\mu\), with a parameter \(\delta_g>0\) to be chosen. Its proof explicitly permits an arbitrary invariant probability. It supplies compact frame/base good sets \(\widetilde A_k,A_k\), with \(\mu(A_k^c)<\delta_g\), the same dyadic sequence \(b_k\) satisfying \(\sum b_k^2<\infty\), and the same finite-interval derivative estimates. Put \(B_k=b_k^{1/8}\), and use exactly the source scales
\[
 h_0=e^{-B_kn},\qquad r=e^{-2B_kn},\qquad \delta_k=e^{-3B_kn/2},
\]
with its auxiliary \(g_k,L_k\). Thus \(\sum B_k^{16}=\sum b_k^2<\infty\). Source §§3.1–3.3 (finite-interval splitting, nearby-base stability, and relative exterior-power perturbation) are unchanged: they are deterministic consequences of the good frame-path estimates.

Use the same finite chart atlas and coarse grid as source §4. In each coarse bin whose closure lies in O and which meets \(A_k\), use the source's common fast/slow reference spaces and its product cells of scale r. Retain only full product cells whose closures lie in O. The number of these cells is no greater than in source (4.6). Put every point not assigned to one of them in a single catch-all cell \(Q_0\). Therefore
\[
 \#\mathcal P_k\le1+e^{CB_kn},\qquad \log\#\mathcal P_k\le C'B_kn
\]
for all large k. This also handles bins not meeting \(A_k\), partial cells, and all of \(M\setminus O\).

**Retained mass without invariance of the reference law.** Let \(\Gamma\) be the finite union of fixed chart-region faces and \(\partial O\); it is \(\nu\)-null and hence \(\mu\)-null. Define \(R_k\) to consist of points in \(A_k\), in the retained interiors of full product cells, whose two endpoints at times \(\pm n\) lie in coarse bins at the source margin \(\tau h_0\) from translated grid faces and at distance at least \(C h_0\) from \(\Gamma\). There is no manifold-boundary clause because M is closed.

The good-base loss obeys
\[
 \widetilde\nu(A_k^c)\le(1-p)+p\omega_K(\delta_g).
\]
The initial product-coordinate strips have \(\widetilde\nu\)-mass \(O(\tau)+o(1)\): on O the density is the fixed smooth density \(Z^{-1}\nu\), and source's relative-volume strip estimate applies. Partial product cells cost \(O(r/h_0)\). Starting chart-region faces, and points of O whose coarse-bin closures are not contained in O, lie in fixed-boundary layers of width \(O(h_0)\), so they cost \(O(h_0)\) under the same smooth law. The endpoint coarse-grid strips are treated separately by randomized translations below; this is needed because \(\widetilde\nu\) is not invariant.

For endpoint *grid* faces, choose each grid translation independently and uniformly in a fundamental coarse cube. For any fixed point, the chance to lie within \(\tau h_0\) of a grid face is at most \(2d\tau\); integrating proves expected strip mass \(O(\tau)\) for every probability law. Apply this simultaneously to the two endpoint laws \((S^{n})_*\widetilde\nu\) and \((S^{-n})_*\widetilde\nu\); a choice of translations makes their total loss \(O(\tau)\), with no invariance assumption.

For the fixed faces \(\Gamma\), use \(\widetilde\nu=p\widetilde\nu_K+(1-p)\widetilde\nu_{bad}\). At each endpoint time t,
\[
 (S^t)_*\widetilde\nu(N_{Ch_0}(\Gamma))
 \le p\omega_K\bigl(\mu(N_{Ch_0}(\Gamma))\bigr)+(1-p).
\]
Since \(\mu(\Gamma)=0\), the modulus term tends to zero. Combining these estimates, for a fixed atlas-dependent C,
\[
 \widetilde\nu(R_k^c)\le
  4(1-p)+p\omega_K(\delta_g)+C\tau
  +2p\omega_K\bigl(\mu(N_{Ch_0}(\Gamma))\bigr)+o(1). \tag{4.2}
\]
The four \((1-p)\) contributions charge respectively the non-K base, exclusion of \(M\setminus O\), and the two endpoint fixed-face tails. Here \(\widetilde\nu(M\setminus O)\le1-p\), since K lies in O and g=1 on K. The two endpoint fixed-face main components give the displayed factor 2. The \(C\tau\) term includes the initial product-coordinate strips and randomized endpoint-grid strips. Given any additional loss \(\eta>0\), choose \(\delta_g\) so \(p\omega_K(\delta_g)<\eta/8\), choose \(\tau\) so \(C\tau<\eta/8\), and then k large so the remaining face-neighborhood and asymptotic terms total less than \(\eta/4\). Thus \(\widetilde\nu(R_k^c)<4(1-p)+\eta/2\). The modulus tends to zero, and \(\mu(N_h(\Gamma))\to0\) because \(\mu(\Gamma)=0\). This fixed localization need not be changed to make the additional loss arbitrarily small.

Let \(G_k=(R_k\times R_k)\cap\bigcup_{Q\ne Q_0}(Q\times Q)\). The law \(\rho_k\) is supported on pairs in the same partition cell and both marginals are exactly \(\widetilde\nu\); R_k meets only active product cells. Consequently
\[
 \rho_k(G_k)=\rho_k(R_k\times R_k)\ge1-2\widetilde\nu(R_k^c)>1-8(1-p)-\eta.
\]
Also \(Q_0\subset R_k^c\), so \(\widetilde\nu(Q_0)<4(1-p)+\eta/2\); under the cell-weighted pair law the entire catch-all contribution is exactly \(\widetilde\nu(Q_0)\), not its square. This proves retention and the partition interface.

**Orbit switch, Jacobian, and output domination.** For each retained pair in one active product cell, use source Lemma 4.2 with the source endpoint projections. Its hypotheses are the good frame-path estimates and endpoint wall margins just established; it does not use invariance of the pair-law reference. The same finite-interval linear inverse and nonlinear contraction produce the future/past orbit join z, its complementary join w, and the source uniform shadowing bound (4.11). The product-coordinate estimate (4.12) and retained cell margins put z,w in their original cell Q⊂O.

On this active cell \(g\equiv1\), so \(\widetilde\nu=Z^{-1}\nu\) with a constant factor. Source Lemma 4.3's relative-minor calculation and exact determinant identity (4.23) therefore give the same pair-map Jacobian \(1+o(1)\) relative to \(\widetilde\nu\otimes\widetilde\nu\); the two constant factors cancel. This is the only density calculation needed, and it is local to Q.

For clarity, source Lemma 4.4 has exactly the needed hypotheses after localization. The strict product-cell margins put both outputs in their original cell, so the ordered output pair recovers that cell. Its endpoint margins recover the four endpoint-bin labels by
\[
(U_x,V_x,U_y,V_y)=\bigl(\operatorname{bin}(S^nz),\operatorname{bin}(S^{-n}w),
\operatorname{bin}(S^nw),\operatorname{bin}(S^{-n}z)\bigr).
\]
These labels fix the four endpoint maps. If two input pairs have the same output pair, the boundary-uniqueness argument applied to the two true input orbits in the same recovered charts gives equality of the first inputs and then of the second inputs. Nonsingularity from Lemma 4.3 makes each fixed-label branch a local smooth diffeomorphism. The retained domain is Borel and second countable, so a countable cover by these branch neighborhoods gives measurability and a countable measurable partition into smooth pieces. Restricting to active cells changes none of these arguments; the catch-all cell is excluded and has no image.

On Q×Q the pair law has density \(1/\widetilde\nu(Q)\) relative to \(\widetilde\nu\otimes\widetilde\nu\). For every Borel E, change of variables on the countable pieces, injectivity, and the inverse Jacobian bound ≤2 give
\[
 \Phi_{k*}(\rho_k|_{G_k})(E)
 \le \sum_{Q\ne Q_0}\frac{2(\widetilde\nu\otimes\widetilde\nu)(E\cap(Q\times Q))}{\widetilde\nu(Q)}
 \le 2\rho_k(E).
\]
Here all outputs stay in their input cell, and no cell restriction is renormalized. The first marginal of \(\rho_k\) is exactly \(\widetilde\nu\), since \(\sum_Q(\widetilde\nu|_Q)\widetilde\nu(Q)/\widetilde\nu(Q)=\widetilde\nu\). Taking first marginals proves \((z_k)_*(\rho_k|_{G_k})\le2\widetilde\nu\), without any invariance assumption on \(\widetilde\nu\). This proves all five conclusions. ∎

The coding-domain null set is charged explicitly. Since \(K\subset D\), \(\mu(D^c)=0\), and D is invariant, for every integer t,
\[
(S^t)_*\widetilde\nu(D^c)\le p\omega_K(\mu(D^c))+(1-p)=1-p<\epsilon.
\]
Thus each input time marginal loses at most \(1-p\). If \(\sigma=(z_k)_*(\rho_k|_{G_k})\), then \(\sigma\le2\widetilde\nu\) implies
\[
(S^t)_*\sigma(D^c)\le2(S^t)_*\widetilde\nu(D^c)\le2(1-p)<2\epsilon.
\]
No symbolic code is used off D.

First choose the localization so \(p>.999\), possible since \(\epsilon\) is arbitrary; in particular \(2(1-p)<.002\). Then apply Lemma 4.1 with additional loss \(\eta=.001\). Its bound gives \(\rho(G_k)>1-.008-.001=.991\), so the later argument may use \(\rho(G_k)\ge.99\). The source Proposition 2.2 parameter independently makes \(\omega_K(\delta_g)\) as small as needed.

## 5. Vanishing TV errors and entropy transfer

### 5.1 Rebuild the finite word families

In source Theorem 5.1 replace the fixed tolerance \(10^{-4}\) at level i by
\[
 \vartheta_i=2^{-K_i/16}\longrightarrow0
\]
in both (W3) and (W4). This creates new finite word families and a modified symbolic system. The random-word proof is unchanged except that the bounds \(F_i,E_i\) in (5.10),(5.12) acquire \(+\log_2(1/\vartheta_i)=K_i/16\). More explicitly, if \(K=K_{i-1}\), the source bound becomes \(\log_2 F_i\le B_0(K)-14-3K_i/16\). Since \(B_0(K)\le2^{K/4}\le2^{K/3}/8\le K_i/8\) by (5.15),(5.7), this is at most \(-K_i/16\). Likewise \(\log_2 E_i\le B_0(K_i)-14+K_i/16-\ell_{i+1}/2\), which is less than \(-2^{K_i}/4\) by \(B_0(K_i)\le2^{K_i/4}\) and \(\ell_{i+1}\ge2^{K_i}\). The distance-failure bound \(T_i\) is unchanged. The growth estimates (5.6)–(5.7) therefore still make \(F_i<1/2\), \(E_i<1/4\), and \(T_i<1/4\) at every level, increasing the freely chosen initial \(K_1\) if needed. Properties (W1),(W2), the length/cardinality growth, zero entropy, and recognition estimates are unchanged.

### 5.2 Small sets of list values

For \(L_{i,D}(x,t)\) from (6.1), put \(q=D-1\), \(N=q\ell_i\). Retaining the atom bound in (W3), the source boundary-start decomposition and modified (W3),(W4) give
\[
 \mu_0\{L_{i,D}(\cdot,t)\in A\}
 \le \beta_i+\vartheta_i+\vartheta_{i+1}
      +2|A|2^{-q(\ell_i-2K_i)},\quad \beta_i=D_i^*/N_i\to0, \tag{5.1}
\]
for every \(A\subset W_i^q\), allowed D, and integer t. For any fixed \(\alpha>0\),
\[
 \sup_{|A|\le2^{(1-\alpha)N}}
 \mu_0\{L_{i,D}(\cdot,t)\in A\}\to0, \tag{5.2}
\]
uniformly in tests and t, since \(2K_i/\ell_i\to0\).

Let \(J:(M,\mu)\to(X,\mu_0)\) be the hypothetical isomorphism and \(\lambda=J_*\widetilde\nu\), extending J arbitrarily off D. Then
\[
 \lambda=p\lambda_K+(1-p)\lambda_{bad},\qquad
 \lambda_K=J_*\widetilde\nu_K\ll\mu_0.
\]
By (4.1), all shifts of \(\lambda_K\) uniformly transfer the small-set estimate (5.2). The heavy-atom argument from source Proposition 6.3 then gives
\[
 H_{\lambda_K}(L_{i,D}(\cdot,t))\ge(1-2\alpha)N
\]
for sufficiently large i, uniformly in allowed D and t. Concavity of Shannon entropy yields the exact contamination factor
\[
 H_{\lambda}(L_{i,D}(\cdot,t))\ge p(1-2\alpha)N. \tag{5.3}
\]
For example, take \(p>.999\), \(\alpha=.002\); the coefficient exceeds .994. This is enough for the source's .99 threshold after cell conditioning along the selected tests. Define the transported modulus \(\omega_K^X(s)=\sup_{\mu_0(B)\le s}\lambda_K(B)\); since J is an isomorphism on D, \(\omega_K^X(s)\le\omega_K(s)\to0\).

## 6. Contradiction and what is left open

Choose tests by source Lemma 7.1 using the unchanged bound \(\sum_k B_k^{16}<\infty\). Then \(H(C)\le\log\#\mathcal D_{\log n}=o(N)\) for the sampled cell C. Since (5.3) gives list entropy greater than .994N, eventually \(H(U|C),H(V|C)\ge.99N\). Conditional subadditivity gives average one-entry entropy at least \(.99\ell_i\). Given C and an entry index, the two inputs are independent under the pair law. The unchanged binary symplectic estimate in source Lemma 7.2 implies
\[
 \mathbb E_\rho Z\le.62. \tag{6.1}
\]
The catch-all cell causes no additional entropy cost beyond H(C); the full pair-law marginals remain exactly \(\widetilde\nu\).

For the lower bound, let \(a:M\to\mathcal A\) be the finite symbol observable transported from X by J on D (extend it arbitrarily off D). Choose Borel representatives of its atoms and disjoint compact cores \(C_b\subset D\cap a^{-1}(b)\) with \(\mu(M\setminus C)<\delta_c\), where \(C=\bigcup_b C_b\); inner regularity gives these cores. Distinct nonempty cores have positive pairwise distance. The main input law \(\widetilde\nu_K\) misses C at any time by at most \(\omega_K(\delta_c)\), while the bad input component contributes at most \(1-p<\epsilon\). For every t, \(\sigma\le2\widetilde\nu\) and (4.1) give \((S^t)_*\sigma(C^c)\le2p\omega_K(\delta_c)+2(1-p)\). If two shadowing points are both in C and closer than the minimum separation between distinct cores, they have the same symbol. Thus each half's expected symbol-mismatch fraction is at most \(3\omega_K(\delta_c)+3\epsilon\). Choose \(\epsilon+\omega_K(\delta_c)<d_*/20000\); Markov's inequality, at the source threshold \(d_*/100\) on each half, makes the combined failure of (7.7)–(7.8) at most .03.

The source graph-exception event has \(\mu_0\)-mass \(\alpha_{i,D}\to0\). For the switched output, use \(\sigma\le2\widetilde\nu\). Let E be the graph-exception event in X and charge output outside D at the same time. On K the code is defined and the event has mass at most \(\omega_K^X(\alpha_{i,D})\), where \(\omega_K^X(s)=\sup_{\mu_0(B)\le s}\lambda_K(B)\to0\); the entire bad component has mass \(1-p\), covering both exception and coding-domain failure. Hence
\[
 \sigma(J^{-1}E\cup D^c)\le2p\,\omega_K^X(\alpha_{i,D})+2(1-p).
\]
Choose \(1-p<.002\), then a sufficiently late test so the first term is below .005; the total is below .01. Together with \(\rho(G)\ge.99\) and mismatch failure at most .03, at least .95 of the original pair law has valid coding, symbol matching, and graph relations. On that set the source recognition argument yields \(Z\ge.96\). Hence
\[
 \mathbb E_\rho Z\ge.95\cdot.96=.912>.62,
\]
contradicting (6.1).

All coding-domain failures are included: D is invariant; the main component is absolutely continuous with respect to invariant \(\mu\), so all its shifts stay in D a.s.; the input bad component has mass \(1-p\); and output bad mass is bounded by \(2(1-p)\) from \(\sigma\le2\widetilde\nu\). The system is fixed before the hypothetical model; K, bump, and all model-dependent constants are selected afterward, and source test selection absorbs them at late scales.

## 7. Significance and limit

The source's exact limitation is that it rules out smooth positive invariant densities but does not claim an obstruction for every invariant measure equivalent to volume. The modified construction above goes further: it rules out the **entire absolutely-continuous class**, including densities that vanish on positive volume. It thereby forces any smooth model, if one exists, to use a purely singular invariant probability. This is a meaningful, independently consequential boundary for the smooth-realization problem. It leaves all singular invariant measures open and is not a claimed historic resolution of arbitrary-measure smooth realization.

The theorem is stated for closed manifolds. No boundary or singular-measure extension is claimed.
