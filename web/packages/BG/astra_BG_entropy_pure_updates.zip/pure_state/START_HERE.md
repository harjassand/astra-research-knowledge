# Pure-state approximate broadcasting forces common classical reconstruction

Research record: 9 October 2026.

## Main result

Let H be any separable Hilbert space and F any nonempty family of pure states on H, including an uncountable family. Suppose one full-domain normal quantum channel B: T(H) -> T(H tensor H) reconstructs every state in F in BOTH marginal outputs with half-trace distance at most b. Then one countable-outcome measure-and-prepare channel Lambda reconstructs every state in F uniformly with error at most f(b), independently of Hilbert-space dimension, family cardinality, energy, and Holevo capacity.

For 0 <= b <= 1/4096, set

- delta = 4 sqrt(b)
- eta = (3/2) [(1-4delta)^(-1/2)-1]
- f(b) = min{1, delta+eta+sqrt(2eta)}.

For larger b set f(b)=1. The small-error bound is asymptotic to 2 sqrt(6) b^(1/4). It is not asserted to be sharp.

In physical terms: if a device can make two uniformly accurate copies of any promised pure state, a single measurement followed by state preparation can already reconstruct that whole promised family, with an explicit error tending to zero. The measurement does not depend on which state is supplied or on an ensemble prior.

The result concerns reconstruction ON THE PROMISED PURE FAMILY. It does not assert that the given broadcaster's marginal is globally entanglement breaking, that arbitrary mixed-state families satisfy the same theorem, or that a channel diamond-distance approximation follows.

## Proof mechanism

The normalized ideal-clone projections of one Stinespring isometry give a uniform vector comparison. This yields completely bounded closeness of Gram Schur maps. Multiplying by the environment Gram map produces a nearly idempotent Schur multiplier. A convergent binomial correction produces an exact Boolean Schur idempotent; an elementary three-point norm gap forces it to be an equivalence-relation mask. Its blocks are both almost distinguishable and internally close to one pure ray.

Two reconstruction proofs are preserved:

1. A finite-dimensional argument using weighted Gram matrices, Powers–Størmer, a block measurement, and minimax.
2. A separable-Hilbert-space argument using the Kretschmann–Schlingemann–Werner Stinespring-continuity theorem to construct one block measurement directly. The block set is countable by separability. This construction gives the same bound, with no energy cutoff.

The finite-ensemble corollary bounds the gap between optimal global two-copy cloning fidelity and optimal single-copy measurement-and-preparation fidelity: 1-F_EB <= min{1,64(1-F_cl)^(1/3)}. The proof explicitly removes a small prior mass of poorly cloned states before applying the uniform mechanism. No linear constant-eight inequality is proved.

## Files

- GENERAL_CB_SCHUR_PROOF.md: complete finite-dimensional analytic proof, including the physical premise and constants.
- SEPARABLE_HILBERT_EXTENSION.md: full arbitrary-index Schur and normal-channel extension, with the precise external theorem and normality/countability arguments.
- AVERAGE_FIDELITY_COROLLARY.md: finite-ensemble consequence and complete truncation proof.
- CB_CORE_AUDIT.md: separate reconstruction of the norm and algebraic core.
- BLOCK_MEASUREMENT_AUDIT.md: separate review of the measurement and minimax step.
- COMBINED_ADVERSARIAL_AUDIT.md: full-proof adversarial review including the extension and average-fidelity corollary.
- LITERATURE_ASSESSMENT.md: bounded primary-literature comparison, including exact no-broadcasting, channel-level robust no-broadcasting, and cloning/estimation antecedents.

## Verification and significance

This record contains analytic proofs with separate AI-assisted component checks. Agreement between those checks is NOT external independent verification. No proof-assistant certification, external specialist review, publication, or public repository push has occurred. The final mathematical assessment remains subject to adversarial checking.

A bounded literature scan found no prior theorem with the exact combination of arbitrary pure-state family, two outputs, uniform error, one common measure-and-prepare reconstruction, and dimension/capacity independence. That is not an established priority claim. Exact no-broadcasting, dimension-free channel-level information-disturbance, Boolean Schur rigidity, and Stinespring continuity are established ingredients and antecedents.

This is a potentially substantial structural robustness result in quantum information. It does not currently justify the programme's historic 10/10 classification. No major longstanding named conjecture is claimed resolved here.

The literature file was prepared during the proof audit and describes the candidate as pending; the proof artifacts record the subsequently completed finite and separable-Hilbert arguments. Further primary pair-cloning reference: A. E. Rastegin, Physical Review A 68, 032303 (2003), https://arxiv.org/abs/quant-ph/0301132, supplies all-channel global-fidelity bounds for two states and finite families. This does not establish the family-wide classical reconstruction conclusion.
