# Average cloning and state-estimation fidelity

9 October 2026. Analytic consequence of the CB-Schur argument; no sharp exponent or linear tradeoff is claimed.

Let {(p_i,P_i)} be a finite ensemble of pure states in a finite-dimensional Hilbert space. Define

F_cl = max_B sum_i p_i Tr[(P_i tensor P_i) B(P_i)],

where B ranges over all CPTP 1-to-2 cloners, and

F_EB = max_Lambda sum_i p_i Tr[P_i Lambda(P_i)],

where Lambda ranges over entanglement-breaking channels. These are GLOBAL two-copy fidelity and SINGLE-copy measure-and-prepare fidelity, respectively; they are different objectives.

Then, with e = 1-F_cl,

1-F_EB <= min{1, 64 e^(1/3)}.

Both maxima exist by finite-dimensional compactness. If e=0, the exact pure-family theorem on the positive-prior support gives F_EB=1. If e>=64^(-3), the asserted bound is trivial. Assume 0<e<64^(-3), choose an optimal cloner, and put t=e^(2/3). Let q_i be its individual global target fidelity. Markov's inequality gives total prior weight at most e/t=e^(1/3) to the bad indices with 1-q_i>t.

On the remaining good indices, the normalized projected Stinespring vectors satisfy

||u_i-v_i||^2 = 2(1-sqrt(q_i)) <= 2t.

Thus the CB-Schur core of GENERAL_CB_SCHUR_PROOF.md applies with delta=2 sqrt(2t), rather than 4 sqrt(b). Here delta<2 sqrt(2)/64<1/16. Write eta=(3/2)[(1-4delta)^(-1/2)-1]. The block pinching and weighted-Gram measurement construction applied to the CONDITIONAL prior on the good indices gives average wrong-class probability at most delta+eta. On a correct outcome the representative has pure-target infidelity at most 1-(1-eta)^2<=2eta. Consequently the good conditional average EB infidelity is at most delta+3eta.

For 0<=delta<=1/16, eta<=4delta: the function h(delta)=(1-4delta)^(-1/2)-1 is convex with h(0)=0, hence h(delta)/delta is nondecreasing. Its endpoint yields eta/delta<=16(sqrt(3)-3/2)<4. Therefore good conditional infidelity is at most 13delta. Use this same full-domain measure-and-prepare channel on the entire original ensemble and bound bad-state infidelity by one. Its total infidelity is at most

e/t + 13delta = (1+26sqrt(2)) e^(1/3) < 64 e^(1/3).

This proves the corollary. The proof does not convert an average premise directly into a uniform CB bound: the explicit truncation is essential. It also does not prove the speculative linear inequality with constant eight.
