# Audit: direct Gram rounding and minimax classicalization

## Assumptions

Let \(\{P_i=|\psi_i\rangle\langle\psi_i|:i\in I\}\) be a finite pure-state family on finite-dimensional \(A\), with Gram correlation matrix \(C_{ij}=\langle\psi_i|\psi_j\rangle\). Let \(Q\) be an equivalence-relation matrix for a partition of \(I\), so \(Q_{ij}=1\) inside each block and 0 across blocks. Assume

1. \(\|S_K\|_{cb}\le a\), for \(K=C-C\circ Q\) and \(S_K(X)=K\circ X\);
2. \(|C_{ij}|\ge 1-d\) for every within-block pair.

Then a single EB channel can reconstruct the whole family with worst-case half-trace error at most \(\kappa=\min\{1,a+\sqrt{2d}\}\), independent of family size and dimension.

## Fixed-prior channel

Fix a prior \(p=(p_i)\); omit zero-mass indices. Set \(u_i=\sqrt{p_i}\), \(G=DCD=S_C(|u\rangle\langle u|)\), and \(G_{blk}=G\circ Q=S_{C\circ Q}(|u\rangle\langle u|)\). The equivalence matrix \(Q\) is positive semidefinite (a direct sum of all-ones blocks), so the Schur product theorem gives \(G_{blk}\ge0\); it is block diagonal and has trace one.

For Hermitian \(K\), the trace-dual adjoint of \(S_K\) is \(S_{\bar K}\), not generally \(S_K\). Therefore

\[
\|G-G_{blk}\|_1=\|S_K(|u\rangle\langle u|)\|_1
\le \|S_K\|_{1\to1}\,\||u\rangle\langle u|\|_1
=\|S_{\bar K}\|_{\infty\to\infty}
=\|S_K\|_{\infty\to\infty}
\le\|S_K\|_{cb}\le a.
\]

The middle equality follows from entrywise conjugation: \(S_{\bar K}(X)=\overline{S_K(\bar X)}\), and conjugation preserves operator norm. Powers–Størmer now yields

\[
\|\sqrt G-\sqrt{G_{blk}}\|_2^2\le\|G-G_{blk}\|_1\le a.
\]

Let \(X\) have columns \(\sqrt{p_i}\psi_i\), so \(X^*X=G\). In the polar decomposition \(X=V\sqrt G\), \(V\) is a partial isometry from \(\operatorname{supp}G\) onto the span \(L\) of the weighted input vectors. Thus \(V^*:L\to\operatorname{supp}G\subseteq\mathbb C^{I}\) is an isometry. For each positive-prior index,

\[
\alpha_i=V^*\psi_i=\sqrt G e_i/\sqrt{p_i},\qquad
\beta_i=\sqrt{G_{blk}}e_i/\sqrt{p_i}.
\]

Both are unit vectors, and \(\beta_i\) lies in the coordinate subspace for the block containing \(i\), since \(G_{blk}\) and its square root are block diagonal. Hence

\[
\sum_i p_i\|\alpha_i-\beta_i\|^2
=\|\sqrt G-\sqrt{G_{blk}}\|_2^2\le a.
\]

Pull the block-coordinate projectors back to a POVM on \(L\) using \(V^*\), then extend this POVM to all of \(A\) by assigning the orthogonal complement \(L^\perp\) to any one outcome. For input \(i\) in block \(b\), the probability \(w_i\) of an incorrect block outcome is at most \(\|(I-\Pi_b)\alpha_i\|^2\le\|\alpha_i-\beta_i\|^2\), so \(\sum_i p_iw_i\le a\). After the measurement prepare the original representative state \(P_{r_b}\) for the reported block. This measure-and-prepare map is EB. For a correct block outcome,

\[
\tfrac12\|P_i-P_{r_b}\|_1=\sqrt{1-|C_{ir_b}|^2}\le\sqrt{2d}.
\]

Thus the prior-average half-trace error is at most \(a+\sqrt{2d}\). Representatives may be chosen from the positive-prior support of each occupied block; zero-prior indices are irrelevant to that prior.

## Uniformization

In finite dimension, the set \(\mathcal E\) of EB channels \(A\to A\) is compact and convex: via Choi matrices it is the compact convex set of separable positive operators satisfying the channel marginal constraint. Each \(e_i(E)=\tfrac12\|E(P_i)-P_i\|_1\) is continuous and convex in \(E\). Every prior \(p\) admits a channel with \(\sum_i p_i e_i(E)\le\kappa\), so \(\min_E\sum_i p_i e_i(E)\le\kappa\) for all \(p\). Sion minimax gives

\[
\min_{E\in\mathcal E}\max_i e_i(E)
=\min_E\max_{p\in\Delta}\sum_i p_i e_i(E)
=\max_{p\in\Delta}\min_E\sum_i p_i e_i(E)\le\kappa.
\]

A single EB channel therefore works uniformly for the finite family. For an infinite pure family in the same finite-dimensional \(A\), each finite subfamily has such a channel with the same bound. The closed subsets \(\{E\in\mathcal E:e_i(E)\le\kappa\}\) have the finite-intersection property, so compactness yields a channel satisfying all constraints.

## Checks

- \(\operatorname{tr}G=\sum_i p_i=1\), and both \(G,G_{blk}\) are PSD.
- No phase alignment or approximation of \(G_{blk}\) by rank-one blocks is needed; its square root is already block diagonal.
- The canonical isometry is used only on the input span. Extend the pulled-back POVM on its orthogonal complement rather than trying to extend the isometry when \(\dim A>|I|\).
- The ideal measurement space has orthogonal block subspaces, but representative states in \(A\) need not be orthogonal; the channel simply prepares each representative after measurement.
- Minimax is valid because the channel set and prior simplex are convex compact, the payoff is convex continuous in the channel and affine in the prior.
- For infinite families, fixed finite-dimensional \(A\) is essential to compactness.
