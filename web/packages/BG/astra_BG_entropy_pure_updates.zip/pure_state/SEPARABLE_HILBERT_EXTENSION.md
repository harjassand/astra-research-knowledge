# Audit: pure-family classicalization in separable infinite dimension

## Verdict

The proposed Stinespring-continuity extension is sound, conditional on the finite/algebraic core already stated: for the partition matrix \(Q\), assume

\[
\|S_C-S_{CQ}\|_{cb}\le a<1,
\qquad |C_{ij}|\ge 1-\eta\quad(i\sim_Q j).
\]

Here \(C_{ij}=\langle\psi_i,\psi_j\rangle\) is the Gram matrix of unit vectors in a separable Hilbert space \(\mathcal H\), and \(Q_{ij}=1\) within each equivalence block and \(0\) between blocks. For the constants in the stated finite proof, \(a=\delta+\eta\), \(\eta=\tfrac32[(1-4\delta)^{-1/2}-1]\), and \(\delta\le1/16\), so \(a\le \sqrt3-\tfrac{23}{16}\approx0.2946<1\).

For \(b>0\), the construction below gives a normal entanglement-breaking CPTP map \(\mathcal E_*:\mathcal T(\mathcal H)\to\mathcal T(\mathcal H)\), whose dual \(\mathcal E:B(\mathcal H)\to B(\mathcal H)\) is normal UCP, satisfying

\[
\sup_i \tfrac12\|\mathcal E_*(|\psi_i\rangle\langle\psi_i|)-|\psi_i\rangle\langle\psi_i|\|_1
\le \min\{1,\ a+\sqrt{2\eta}\}.
\]

This is at least as strong as the suggested safe estimate \(2a+\sqrt{2\eta}\). If \(b=0\), then \(a=\eta=0\) and the same argument gives exact classicalization.

## 1. The exact KSW theorem that applies

Use Kretschmann–Schlingemann–Werner, *A Continuity Theorem for Stinespring’s Dilation*, arXiv:0710.2495 (published J. Funct. Anal. 255 (2008), 1889–1904). Theorem 1 states: for completely positive maps \(T_1,T_2:A\to B(K)\), with \(A\) any C*-algebra and at least one map nonzero, their Bures/Stinespring distance satisfies the following bound. Our unital Schur channels meet the nonzero condition.

\[
\frac{\|T_1-T_2\|_{cb}}{\sqrt{\|T_1\|_{cb}}+\sqrt{\|T_2\|_{cb}}}
\le \beta(T_1,T_2)\le \sqrt{\|T_1-T_2\|_{cb}},
\]

and there is a common representation \(\pi:A\to B(L)\) and corresponding Stinespring operators \(V_1,V_2:K\to L\) attaining

\[
\|V_1-V_2\|=\beta(T_1,T_2).
\]
The theorem permits \(\pi\) to be the direct sum of the two minimal Stinespring representations. Its statement places no finite-dimensional or separability hypothesis on \(A\) or \(K\). In particular, it applies to \(A=B(\ell^2(I))\), even if the index set \(I\) is uncountable and \(\ell^2(I)\) is nonseparable.

Primary source: [Kretschmann, Schlingemann & Werner, arXiv:0710.2495](https://arxiv.org/abs/0710.2495), especially Theorem 1 and Proposition 6 in the [full text](https://arxiv.org/html/0710.2495). The exact theorem statement and the choice of a direct sum of minimal representations appear at full-text lines 87–96. The paper is also published at [J. Funct. Anal. 255 (2008), 1889–1904](https://doi.org/10.1016/j.jfa.2008.07.023).

## 2. Normal standard Schur dilations and the environment alignment

Let \(\mathcal K=\ell^2(I)\), and put

\[
\mathcal H_0=\overline{\mathrm{span}}\{\psi_i:i\in I\}.
\]

For the Schur channel \(S_C:B(\mathcal K)\to B(\mathcal K)\), the canonical Stinespring isometry and representation are

\[
V_C e_i=e_i\otimes\psi_i,\qquad \pi_C(x)=x\otimes I_{\mathcal H_0}.
\]
They implement \(S_C(x)=V_C^*(x\otimes I)V_C\). This is a normal dilation because \(x\mapsto x\otimes I\) is a normal representation. It is minimal: applying matrix units \(E_{ji}\otimes I\) to \(V_Ce_i\) generates all vectors \(e_j\otimes\psi_i\), whose span is dense in \(\mathcal K\otimes\mathcal H_0\).

For \(g=[i]_Q\), let \(u_g\) be the standard basis vector of \(\ell^2(G)\), where \(G=I/{\sim_Q}\). Define

\[
\phi_i=\psi_i\otimes u_{[i]_Q},\quad
\mathcal F=\overline{\mathrm{span}}\{\phi_i:i\in I\}.
\]
Then \(S_{CQ}\) has the canonical minimal dilation

\[
V_{CQ} e_i=e_i\otimes\phi_i,\qquad \pi_{CQ}(x)=x\otimes I_{\mathcal F}.
\]
It is normal and minimal by the same matrix-unit argument.

KSW applied to \(T_1=S_C,T_2=S_{CQ}\) yields an attaining pair in the direct-sum minimal representation. After the canonical tensor reordering, the common representation is

\[
\pi(x)=x\otimes I_{\mathcal E},\qquad \mathcal E=\mathcal H_0\oplus\mathcal F.
\]
Stinespring uniqueness gives environment isometries \(J_C:\mathcal H_0\to\mathcal E\) and \(J_D:\mathcal F\to\mathcal E\) such that the common Stinespring operators have the forms

\[
\widetilde V_C e_i=e_i\otimes J_C\psi_i,
\qquad
\widetilde V_D e_i=e_i\otimes J_D\phi_i.
\]
Indeed, an intertwiner between two standard amplifications of \(B(\mathcal K)\) is \(I_{\mathcal K}\otimes J\). Thus

\[
\sup_i\|J_C\psi_i-J_D(\psi_i\otimes u_{[i]_Q})\|
=\|\widetilde V_C-\widetilde V_D\|
\le \sqrt{\|S_C-S_{CQ}\|_{cb}}\le\sqrt a.
\]

No common Kraus rank or equal-dimensional environments are needed: the isometries land in the direct-sum environment \(\mathcal E\), so rank mismatch is handled directly. This is an isometric alignment, not a claim that a unitary between the original minimal environments exists.

The normality point is important. KSW in its abstract formulation need not preserve a chosen normal representation automatically. Here it does because both channels have explicit minimal normal standard-amplification dilations, and KSW permits the direct sum of those minimal reps as its common representation.

## 3. There are only countably many blocks

For distinct blocks \(g\ne h\), choose \(r_g\in g,r_h\in h\). Since \(Q_{r_gr_h}=0\), applying \(S_C-S_{CQ}\) to the matrix unit \(E_{r_gr_h}\) gives

\[
|\langle\psi_{r_g},\psi_{r_h}\rangle|=|C_{r_gr_h}|\le\|S_C-S_{CQ}\|_{cb}\le a<1.
\]
Consequently their projective distance (unit vectors modulo phase) obeys

\[
d_{\mathrm{proj}}([\psi_{r_g}],[\psi_{r_h}])
=\sqrt{2-2|\langle\psi_{r_g},\psi_{r_h}\rangle|}
\ge\sqrt{2(1-a)}>0.
\]
The projective unit sphere of a separable Hilbert space is separable. A uniformly separated subset of a separable metric space is countable, so \(G\) is countable. This handles an initially uncountable label set \(I\) without a compactness or finite-subcover argument.

## 4. A countable normal measure-and-prepare channel

For each block \(g\in G\), set

\[
\mathcal F_g=\overline{\mathrm{span}}\{\psi_i\otimes u_g:i\in g\}\subset\mathcal F,
\qquad
P_g=\text{projection onto }J_D\mathcal F_g.
\]
The \(P_g\) are mutually orthogonal. Let \(P_*=I_{\mathcal E}-\sum_{g\in G}P_g\), with the sum taken strongly, and fix one block \(g_0\). Pull this countable projective measurement back through \(J_C\): on \(\mathcal H_0\), use effects

\[
M_g=J_C^*P_gJ_C\ (g\ne g_0),\qquad
M_{g_0}=J_C^*(P_{g_0}+P_*)J_C.
\]
They sum to \(I_{\mathcal H_0}\). Extend the POVM to \(\mathcal H=\mathcal H_0\oplus\mathcal H_0^\perp\) by adding the complement projection to \(M_{g_0}\). For \(r_g\in g\), define

\[
\mathcal E_*(\rho)=\sum_{g\in G}\mathrm{Tr}(M_g\rho)\,|\psi_{r_g}\rangle\langle\psi_{r_g}|.
\]
This is a countable-outcome normal CPTP entanglement-breaking channel on trace class; its dual is the normal UCP map
\[
\mathcal E(X)=\sum_{g\in G}\mathrm{Tr}(|\psi_{r_g}\rangle\langle\psi_{r_g}|X)\,M_g.
\]
For \(i\in g\), the probability \(q_i\) that the (lumped) measurement does not report \(g\) obeys

\[
q_i\le\|(I-P_g)J_C\psi_i\|^2
\le\|J_C\psi_i-J_D(\psi_i\otimes u_g)\|^2\le a.
\]
The measure-and-prepare output is therefore within half-trace distance at most \(q_i\le a\) of the representative state \(|\psi_{r_g}\rangle\langle\psi_{r_g}|\). Since \(|C_{i,r_g}|\ge1-\eta\), pure-state trace distance gives

\[
\tfrac12\big\||\psi_i\rangle\langle\psi_i|-|\psi_{r_g}\rangle\langle\psi_{r_g}|\big\|_1
=\sqrt{1-|C_{i,r_g}|^2}
\le\sqrt{2\eta}.
\]
Triangle inequality yields the stated uniform error \(a+\sqrt{2\eta}\). The leftover projection \(P_*\) is harmless: it is lumped into \(g_0\), and for an input in block \(g\ne g_0\) it counts as an incorrect outcome already included in \(q_i\le a\).

For \(b=0\), use the exact case \(a=\eta=0\): same-block pure states are the same ray, and the KSW dilation vectors align exactly. The resulting channel has zero error.

## 5. Arbitrary-index CB-Schur algebra, correction, and path gap

All the Schur-algebra steps extend to arbitrary \(I\). Let \(\mathfrak S_I\) be the normal completely bounded Schur multipliers on \(B(\ell^2(I))\), equipped with the CB norm. A Gram symbol \(G_{ij}=\langle v_i,v_j\rangle\) defines a normal UCP Schur map through the standard isometry \(e_i\mapsto e_i\otimes v_i\). Composition corresponds to entrywise product of symbols. Thus whenever \(L\) is obtained as the entrywise product of the Gram symbols in the finite proof, \(T=S_L\) is normal and \(\|T\|_{cb}\le1\); the same applies to the defect map \(T^2-T\).

The broadcaster-to-Schur CB estimate is dimension-free too. If two Gram Schur channels have diagonal Stinespring isometries \(V e_i=e_i\otimes v_i\) and \(W e_i=e_i\otimes w_i\) into a common environment, then \(\|V-W\|=\sup_i\|v_i-w_i\|\), for any cardinality of \(I\). Directly from \(T(x)=V^*(x\otimes I)V\),

\[
\|S_G-S_{G'}\|_{cb}
\le(\|V\|+\|W\|)\|V-W\|
=2\sup_i\|v_i-w_i\|.
\]

This is the same uniform Stinespring-vector argument as in finite dimension, with no dimension-dependent factor; both Schur channels are normal by their standard dilation. In particular, once the broadcaster supplies the stated uniform vector estimate, \(\|S_C-S_{C^2H}\|_{cb}\le\delta\) holds on \(B(\ell^2(I))\) for arbitrary \(I\).

\(\mathfrak S_I\) is a CB-norm-closed unital Banach algebra. For closure, if normal Schur maps \(T_n\) converge in CB norm, their preadjoints on trace class converge in norm, so the limit is normal. Its action on each matrix unit \(E_{ij}\) remains diagonal, and normality plus ultraweak density of the finite-support matrix units determines the limit on all of \(B(\ell^2(I))\); hence the limit is still Schur. This argument works for nonseparable \(\ell^2(I)\) as well: finite-support vectors are dense, and finite-rank operators are ultraweakly dense.

Write \(T=S_L\) and suppose \(\|T\|_{cb}\le1\), \(\|T^2-T\|_{cb}\le\delta<1/4\), with \(L_{ii}=1\). In this Banach algebra set

\[
D=4(T^2-T),\qquad R=(\mathrm{id}+D)^{-1/2}
=\sum_{n=0}^{\infty}\binom{-1/2}{n}D^n,
\qquad
P=\tfrac12\bigl(\mathrm{id}+(2T-\mathrm{id})R\bigr).
\]

The binomial series converges in CB norm since \(\|D\|_{cb}\le4\delta<1\). It is a norm limit of normal Schur maps, so \(R\) and \(P\) remain normal Schur maps. The identity \((2T-\mathrm{id})^2=\mathrm{id}+D\) gives \(P^2=P\). Also

\[
\|P-T\|_{cb}
\le \tfrac32\bigl((1-4\delta)^{-1/2}-1\bigr)=\eta.
\]

Since \(D(E_{ii})=0\), the correction preserves \(P(E_{ii})=E_{ii}\), so its Schur symbol \(Q\) has \(Q_{ii}=1\). Idempotence gives \(Q_{ij}^2=Q_{ij}\in\{0,1\}\). The construction preserves adjoints (real series coefficients and adjoint-preserving \(T\)), so \(Q_{ji}=\overline{Q_{ij}}\); with \(0/1\) entries, \(Q\) is symmetric.

If the relation \(i\sim j\iff Q_{ij}=1\) failed transitivity, a three-index compression would be the path mask

\[
Q_0=\begin{pmatrix}1&1&0\\1&1&1\\0&1&1\end{pmatrix}.
\]

For \(u=(1,1,1)/\sqrt3\), duality between operator and trace norms gives

\[
\|S_{Q_0}\|
\ge \sup_{\|X\|\le1}|\langle u,S_{Q_0}(X)u\rangle|
=\tfrac13\|Q_0\|_1
=\frac{1+2\sqrt2}{3}\approx1.276.
\]

Compressing input and output to the three-coordinate corner is contractive, so this is also a lower bound on \(\|S_Q\|_{cb}\) for arbitrary \(I\). But \(\|S_Q\|_{cb}\le\|T\|_{cb}+\eta\le1+\eta\), and at \(\delta\le1/16\),

\[
1+\eta\le\sqrt3-\tfrac12\approx1.232<\frac{1+2\sqrt2}{3},
\]

a contradiction. Therefore \(Q\) is the clique/equivalence relation of a partition for arbitrary \(I\). This uses only a finite corner as a witness, not compactness or a finite-dimensional approximation of the global channel.

## 6. Scope caveat about “without compactness/minimax”

The extension does not use compactness of the set of normal entanglement-breaking channels, nor compactness of the pure-state family or finite-dimensional minimax to produce the measure-and-prepare channel. KSW is used as an established theorem; its published proof of the upper bound itself invokes Banach–Alaoglu weak compactness and Ky Fan’s minimax theorem (see [full text lines 214–229](https://arxiv.org/html/0710.2495)). That is compatible with the intended restriction: the extension relies on the theorem but does not repeat its proof or compactify the EB channel family.

There are no energy, entropy, or finite-rank assumptions on the pure states or the normal EB channel. Separability of the original \(\mathcal H\) is used only to show that the \(Q\)-blocks are countable, which makes the final POVM countable and its measure-and-prepare map manifestly normal.

The only inherited premise not reproved here is the broadcaster-to-Schur estimate \(\|S_C-S_{C^2H}\|_{cb}\le\delta\); once its symbols are normal Schur maps, the Banach-algebra correction and path-gap arguments above apply to arbitrary \(I\).
