# CB-Schur core: component audit

9 October 2026. Mathematical component review, not external review or proof-assistant certification. The algebraic steps below were separately reconstructed in the research session; the full physical theorem also needs the rounding/minimax lemma.

## Uniform physical premise and elementary CB estimate

Let C_ij=<psi_i,psi_j> for unit vectors psi_i. Suppose a single dilation supplies unit vectors u_i,v_i in one Hilbert space with Gram matrices C and C^{\circ 2}\circ H, respectively, where H is a correlation matrix, and sup_i ||u_i-v_i|| <= e.

Define W_u e_i=e_i tensor u_i and W_v e_i=e_i tensor v_i. These are isometries, and the corresponding Schur maps satisfy S_C(X)=W_u^*(X tensor I)W_u and S_{C^{\circ2}\circ H}(X)=W_v^*(X tensor I)W_v. Their difference telescopes at every amplification, giving

||S_{C-C^{\circ2}\circ H}||_cb <= 2 ||W_u-W_v|| = 2 sup_i ||u_i-v_i|| <= 2e.

This does not require an abstract Schur-factorization theorem.

For an actual broadcaster with both uniform marginal half-trace errors at most b on pure targets, projection onto the two target rays has probability at least 1-2b. Normalize the projected environment vector, with positive overlap phase. The resulting u_i=V psi_i and v_i=psi_i tensor psi_i tensor e_i obey ||u_i-v_i||^2=2(1-sqrt(q_i))<=4b. Hence e<=2 sqrt(b) and the CB residual is at most delta=4 sqrt(b). A fixed-prior average cloning-fidelity premise alone would not imply this uniform statement; the theorem uses the uniform marginal premise.

## Almost-idempotent correction

Put L=C\circ H and T=S_L. Correlation Schur maps are unital CP and have CB norm one. If D=C-C^{\circ2}\circ H, then L-L^{\circ2}=D\circ H. Therefore ||T^2-T||_cb<=delta.

For 4delta<1 the binomial series defines R=(I+4(T^2-T))^{-1/2}. With X=2T-I, X^2=I+4(T^2-T), all these maps commute. The map

Q=(I+XR)/2

is an idempotent Schur multiplier. Its symbol q has q_ii=1; real-coefficient functional calculus preserves Hermitian symbols, and q_ij^2=q_ij implies q_ij is 0 or 1. Thus q is reflexive and symmetric. Moreover

||Q-T||_cb <= eta(delta) := (3/2)[(1-4delta)^(-1/2)-1].

Here I means the identity Schur map, whose symbol is the all-ones matrix.

## Elementary norm gap

If a reflexive symmetric 0/1 symbol is not transitive, it contains the principal pattern

M = [[1,1,0],[1,1,1],[0,1,1]].

The input J_3/3 has trace norm one. The corresponding Schur map sends it to M/3, whose trace norm is (1+2sqrt(2))/3, since M has eigenvalues 1+sqrt(2),1,1-sqrt(2). The real Schur map is trace-self-adjoint, so the same value lower-bounds its operator norm and hence its CB norm. Principal compression cannot increase CB norm. Consequently a nontransitive q forces

||S_q||_cb >= gamma := (1+2sqrt(2))/3 > 1.276.

But ||Q||_cb<=1+eta. Whenever eta<gamma-1, q must be an equivalence relation and Q is a block pinching. For example delta<=1/16 gives eta<=sqrt(3)-3/2<1/4<gamma-1.

## The exact comparison identity

Although C-L need not be small, the needed identity is

C-C\circ q = (C-C\circ L) + C\circ(L-q) = D + C\circ(L-q).

Thus ||S_{C-C\circ q}||_cb<=delta+eta. If q_ij=1, entrywise evaluation of the CB bound gives |L_ij-1|<=eta. Since |H_ij|<=1, |C_ij|>=|L_ij|>=1-eta.

These are exactly the two hypotheses for the independently reconstructed block-measurement rounding lemma. No phase gauge, rank-one ideal Gram, or rank truncation is required in that lemma.

## Verdict

No fatal norm, algebraic, or quantifier gap was found in this core under the stated uniform pure-state premise. The result does not prove the speculative constant-eight average cloning/estimation infidelity inequality. It supplies a different dimension-free modulus via block rounding. Infinite-dimensional normal-channel extension is a separate question.
