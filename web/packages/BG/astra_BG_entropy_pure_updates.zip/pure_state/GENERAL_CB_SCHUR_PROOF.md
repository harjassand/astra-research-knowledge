# Dimension-free approximate classicalization for pure-state families

## Theorem

Let $H$ be any finite-dimensional Hilbert space, let $\mathcal F$ be an arbitrary (possibly infinite) family of pure states $P_\psi=|\psi\rangle\langle\psi|$ on $H$, and let
\[
\mathcal B:\mathcal T(H)\longrightarrow\mathcal T(H\otimes H)
\]
be a channel. Write $\mathcal B_a$ for its $a$th output marginal. Suppose, uniformly for every $P_\psi\in\mathcal F$,
\[
T(\mathcal B_a(P_\psi),P_\psi)\le b,\qquad a=1,2,
\]
where $T(\rho,\sigma)=\tfrac12\|\rho-\sigma\|_1$. Then there is an entanglement-breaking channel $\Lambda:H\to H$ such that
\[
\sup_{P\in\mathcal F}T(\Lambda(P),P)\le f(b),
\]
with the dimension- and family-independent modulus
\[
\delta=4\sqrt b,\qquad
\eta=\frac32\left((1-4\delta)^{-1/2}-1\right),
\]
\[
f(b)=
\begin{cases}
\min\{1,\delta+\eta+\sqrt{2\eta}\},&0\le b\le 1/4096,\\
1,&b>1/4096.
\end{cases}
\]
In particular, $f(0)=0$ and $f(b)=O(b^{1/4})$ as $b\downarrow0$ (indeed $f(b)\sim2\sqrt6\,b^{1/4}$). No unitality or bistochasticity assumption is made on $\mathcal B$.

The proof is uniform in $\dim H$, the cardinality of $\mathcal F$, and all priors. Finite dimensionality is used for the final compactness/minimax step.

## Proof

### 1. Uniform Stinespring-vector comparison gives a cb Schur bound

First fix an arbitrary finite list $\{P_i=|\psi_i\rangle\langle\psi_i|\}_{i=1}^n\subseteq\mathcal F$. Take a Stinespring isometry
\[
V:H\longrightarrow H\otimes H\otimes E
\]
for $\mathcal B$, and put $u_i=V\psi_i$. Since the trace distance to a pure target bounds the probability of the complementary two-outcome test,
\[
\langle u_i|(P_i\otimes I)|u_i\rangle\ge1-b,
\qquad
\langle u_i|(I\otimes P_i)|u_i\rangle\ge1-b.
\]
The two projectors commute and
\[
I-P_i\otimes P_i\le (I-P_i)\otimes I+I\otimes(I-P_i),
\]
so
\[
q_i:=\langle u_i|(P_i\otimes P_i\otimes I_E)|u_i\rangle\ge1-2b.
\]
For $b\le1/4096<1/2$, project $u_i$ onto $\psi_i\otimes\psi_i\otimes E$ and normalize the environment component to a unit vector $e_i\in E$, choosing its phase so that
\[
v_i:=\psi_i\otimes\psi_i\otimes e_i
\quad\hbox{satisfies}\quad
\langle v_i,u_i\rangle=\sqrt{q_i}\ge0.
\]
Then
\[
\|u_i-v_i\|^2=2(1-\sqrt{q_i})
\le2(1-\sqrt{1-2b})\le4b,
\]
hence $\sup_i\|u_i-v_i\|\le2\sqrt b$.

Write the input and environment correlation matrices as
\[
C_{ij}=\langle\psi_i,\psi_j\rangle,\qquad
F_{ij}=\langle e_i,e_j\rangle,\qquad L=C\circ F,
\]
where $\circ$ is entrywise product. The matrices $C,F,L$ are positive semidefinite correlation matrices; their Schur multipliers $\mathsf S_C,\mathsf S_F,\mathsf S_L$ are unital completely positive (UCP), hence have cb norm one.

For clarity, the cb estimate needed here follows directly from Stinespring form. Define isometries $W_u,W_v:\mathbb C^n\to\mathbb C^n\otimes(H\otimes H\otimes E)$ by
\[
W_u e_i=e_i\otimes u_i,\qquad W_v e_i=e_i\otimes v_i.
\]
Then
\[
\mathsf S_C(X)=W_u^*(X\otimes I)W_u,\qquad
\mathsf S_{C\circ C\circ F}(X)=W_v^*(X\otimes I)W_v.
\]
Telescoping these expressions at every matrix amplification gives
\[
\|\mathsf S_C-\mathsf S_{C\circ C\circ F}\|_{cb}
\le(\|W_u\|+\|W_v\|)\|W_u-W_v\|
=2\sup_i\|u_i-v_i\|
\le4\sqrt b=:\delta.
\]
Because $(C-C\circ C\circ F)\circ F=L-L\circ L$, composition with the UCP Schur multiplier $\mathsf S_F$ also gives
\[
\|\mathsf S_L-\mathsf S_L^2\|_{cb}\le\delta.
\]

### 2. Round the nearly idempotent Schur multiplier

Work in the finite-dimensional unital Banach algebra of Schur multipliers on $M_n$, with cb norm. Its identity $\mathsf I$ is the Schur multiplier whose symbol is the all-ones matrix. Set
\[
E_0=4(\mathsf S_L^2-\mathsf S_L),\qquad Z=2\mathsf S_L-\mathsf I.
\]
Then $Z^2=\mathsf I+E_0$, $Z$ commutes with $E_0$, $\|E_0\|_{cb}\le4\delta\le1/4$, and $\|Z\|_{cb}\le3$. The binomial series defines
\[
R=(\mathsf I+E_0)^{-1/2}
=\sum_{m\ge0}{-\tfrac12\choose m}E_0^m,
\qquad
\|R-\mathsf I\|_{cb}\le(1-4\delta)^{-1/2}-1.
\]
Define
\[
\mathsf Q=\tfrac12(\mathsf I+ZR),
\]
and let $Q$ be its Schur symbol. Since $(ZR)^2=\mathsf I$, $\mathsf Q^2=\mathsf Q$, so $Q\circ Q=Q$ entrywise. The series has real coefficients and $L$ is Hermitian, hence $Q=Q^*$; also $Q_{ii}=1$. Thus every entry of $Q$ is 0 or 1, and
\[
\|\mathsf Q-\mathsf S_L\|_{cb}
\le\tfrac32\big((1-4\delta)^{-1/2}-1\big)=:\eta.
\]
Consequently $\|\mathsf Q\|_{cb}\le1+\eta$. At the allowed endpoint $\delta=1/16$,
\[
\eta\le\sqrt3-\tfrac32<\tfrac14,\qquad
\|\mathsf Q\|_{cb}<\tfrac54.
\]

We claim that $i\sim j$ iff $Q_{ij}=1$ is an equivalence relation. It is reflexive and symmetric. If transitivity failed, some distinct $i,j,k$ would satisfy $Q_{ij}=Q_{jk}=1$ and $Q_{ik}=0$. The corresponding principal block of $Q$ would be
\[
M=\begin{pmatrix}1&1&0\\1&1&1\\0&1&1\end{pmatrix},
\]
whose eigenvalues are $1+\sqrt2,1,1-\sqrt2$. Let $X$ be the all-ones matrix on those three coordinates, divided by 3 and zero elsewhere. Then $\|X\|_1=1$, whereas
\[
\|\mathsf Q(X)\|_1=\|M/3\|_1=\frac{1+2\sqrt2}{3}>\frac54.
\]
Because $Q$ is real symmetric, the trace-class predual of $\mathsf Q$ has the same Schur symbol. Thus $\|\mathsf Q\|_{cb}\ge\|\mathsf Q\|_{1\to1}>5/4$, contradicting the bound above. Hence $Q$ is exactly the block-equivalence matrix of a partition of the indices. In particular $Q$ is a correlation matrix, and $\mathsf Q$ is the corresponding block pinching.

### 3. The weighted Gram matrix is close to its block pinching

The identity
\[
\mathsf S_C-\mathsf S_{C\circ Q}
=(\mathsf S_C-\mathsf S_{C\circ L})
+\mathsf S_C(\mathsf S_L-\mathsf Q)
\]
and $\|\mathsf S_C\|_{cb}=1$ imply
\[
\|\mathsf S_C-\mathsf S_{C\circ Q}\|_{cb}\le\delta+\eta.
\]
For any prior $p=(p_1,\ldots,p_n)$, discard zero-probability indices and put
\[
D_p=\operatorname{diag}(\sqrt{p_1},\ldots,\sqrt{p_n}),\qquad
G=D_p C D_p,\qquad G_{\rm blk}=G\circ Q.
\]
Both are density matrices; $G_{\rm blk}\succeq0$ by the Schur product theorem and is block diagonal in the equivalence classes. The trace-class predual of a Schur multiplier with symbol $A$ has symbol $A^T$; for Hermitian $A$, this is $\overline A$. Entrywise conjugation preserves cb norm. Since $G-G_{\rm blk}$ is the Schur map with symbol $C-C\circ Q$ applied to the rank-one matrix $\sqrt p\,\sqrt p^{\,*}$, whose trace norm is 1, trace duality gives
\[
a:=\|G-G_{\rm blk}\|_1
\le\|\mathsf S_{C-C\circ Q}\|_{1\to1}
\le\|\mathsf S_{C-C\circ Q}\|_{cb}
\le\delta+\eta.
\]

### 4. Measure the block label and reprepare a representative

The Powers--Størmer inequality gives
\[
\|\sqrt G-\sqrt{G_{\rm blk}}\|_2^2\le a.
\]
For each index define unit vectors in $\mathbb C^n$
\[
\alpha_i=\frac{\sqrt G\,e_i}{\sqrt{p_i}},\qquad
\beta_i=\frac{\sqrt{G_{\rm blk}}\,e_i}{\sqrt{p_i}}.
\]
The $\alpha_i$ have Gram matrix $C$, so an isometry from the span of the input vectors sends $\psi_i$ to $\alpha_i$. The $\beta_i$ are unit vectors supported in the coordinate block of $i$'s equivalence class. Moreover,
\[
\sum_i p_i\|\alpha_i-\beta_i\|^2
=\|\sqrt G-\sqrt{G_{\rm blk}}\|_2^2\le a.
\]
Pull back the orthogonal coordinate-block measurement through the isometry of the $\alpha_i$ to the input span, and extend it to a POVM on all of $H$ by adding a complementary effect on the orthogonal input subspace. For an input $\psi_i$ in block $c$, its probability of an incorrect block outcome is
\[
q_i=\|(I-\Pi_c)\alpha_i\|^2
=\|(I-\Pi_c)(\alpha_i-\beta_i)\|^2
\le\|\alpha_i-\beta_i\|^2.
\]
Thus $\sum_i p_i q_i\le a$.

Choose a representative $\psi_{r(c)}$ from each block and, on outcome $c$, prepare $P_{r(c)}$. On the complementary input-subspace outcome prepare any fixed state. If $i$ belongs to block $c$, then $Q_{i,r(c)}=1$. The entrywise bound implied by $\|\mathsf Q-\mathsf S_L\|_{cb}\le\eta$ gives
\[
|L_{i,r(c)}-1|\le\eta.
\]
As $L_{ij}=C_{ij}F_{ij}$ and $|F_{ij}|\le1$, it follows that $|C_{i,r(c)}|\ge1-\eta$, hence
\[
T(P_i,P_{r(c)})=\sqrt{1-|C_{i,r(c)}|^2}\le\sqrt{2\eta}.
\]
The resulting measure-and-prepare channel is entanglement breaking. On a correct block outcome its loss is at most $\sqrt{2\eta}$, and on an incorrect outcome it is at most 1. For this arbitrary prior,
\[
\sum_i p_i T(\Lambda_p(P_i),P_i)
\le a+\sqrt{2\eta}
\le\delta+\eta+\sqrt{2\eta}.
\]

### 5. Minimax and arbitrary families

For a finite family, the set of entanglement-breaking channels $H\to H$ is compact and convex. The loss $\Lambda\mapsto T(\Lambda(P_i),P_i)$ is continuous and convex. Since the preceding construction works for every prior, the finite minimax theorem gives one entanglement-breaking channel whose maximum loss on that family is at most $\delta+\eta+\sqrt{2\eta}$. The loss is always at most 1, so the bound can be capped at 1.

For an arbitrary family in fixed finite-dimensional $H$, each state imposes a closed constraint on the compact set of entanglement-breaking channels. Every finite collection of these constraints is satisfiable by the finite-family result, so the finite-intersection property gives one channel satisfying all constraints. For $b>1/4096$, any replacer channel has loss at most 1. This proves the theorem.

## Verification status and scope

This is an analytic proof, not a machine-checked formalization. The cb estimate is derived directly from the displayed Stinespring forms; the rounding uses the convergent binomial series; the remaining ingredients are finite-dimensional trace duality, Powers--Størmer, finite minimax, and compactness. No idempotent-stability theorem is imported, no unitality of the broadcaster is assumed, and no constant-8 cloning/estimation fidelity tradeoff is claimed. The result is dimension-free across finite-dimensional input spaces; final compactness is stated for each fixed finite-dimensional ambient space.
