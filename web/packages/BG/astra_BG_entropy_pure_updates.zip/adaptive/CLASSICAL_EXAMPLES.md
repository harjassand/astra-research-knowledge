# Classical comparisons and finite witnesses

Companion to RESULTS.md, 9 October 2026. The channel contraction formulas with quantum references are proposed consequences of its main analytical theorem. The ordinary classical bound below is proved independently.

## 1. Exact ordinary coefficient of a symmetric classical channel

Let W have k inputs/outputs, diagonal a>=0, off-diagonal b>0, a+(k-1)b=1. Put c=a-b. Its ordinary global KL contraction coefficient is

    eta_classical(W) = (a-b)^2/(a+b).

For the constant case c=0 this is immediate. Otherwise, at an interior prior p and a tangent vector v with sum_i v_i=0, the input and output KL Hessians are

    sum_i v_i^2/p_i,
    c^2 sum_i v_i^2/(b+c p_i).

It suffices to prove

    sum_i d_i v_i^2 >= 0,
    d_i = 1/p_i - (a+b)/(b+c p_i)
        = b(1-2p_i)/[p_i(b+c p_i)].

If every p_i<=1/2, this is termwise nonnegative. Otherwise exactly one coordinate, say p_0, exceeds 1/2. Let q=1-p_0<1/2. For i!=0, d_i>0, and weighted Cauchy--Schwarz gives

    sum_{i!=0} d_i v_i^2 >= v_0^2/(sum_{i!=0} 1/d_i).

Define h(t)=t(b+c t)/[b(1-2t)]. On (0,1/2), h(t)/t is increasing, because its derivative is (a+b)/[b(1-2t)^2]>0. Therefore

    sum_{i!=0} 1/d_i = sum_{i!=0} h(p_i) <= h(q).

Moreover h(q)<=-1/d_0. The latter inequality is equivalent to

    q(b+cq) <= p_0(b+c p_0),

whose right side minus left side is (2p_0-1)(b+c)=(2p_0-1)a>=0. This proves the desired quadratic inequality. Integrating the KL Hessian along the straight segment between two positive priors proves the upper contraction bound; regularization handles finite-KL boundary cases.

For the matching lower bound, use a prior supported equally on two input symbols and perturb their probabilities oppositely. The output Hessian ratio is exactly c^2/(a+b). Local KL ratios approach this value, proving equality.

In particular, for the exclusion channel a=0,b=1/(k-1),

    eta_classical(W_k)=1/(k-1).

The main theorem instead gives eta_quantum-reference(W_k)=1, because no output column is positive on all inputs.

## 2. Arbitrarily large gap without zero transition probabilities

Take k>=3, a=1/k^3, and b=(1-a)/(k-1). Every transition probability is positive. From the main theorem,

    eta_quantum = 1-k^2/[1/a+(k-1)/b] > 1-1/k.

The ordinary classical coefficient obeys

    eta_classical=(a-b)^2/(a+b) < b < 1/(k-1).

Thus eta_quantum/eta_classical grows without bound as k grows. The phenomenon is not restricted to channels with exact zero entries.

## 3. Exact finite qubit-reference conditional witness

Let W be ternary exclusion: W(y|x)=1/2 for y!=x, otherwise zero. Define qubit states

    |psi_+> = sqrt(1-s)|0> + sqrt(s)|1>,
    |psi_-> = sqrt(1-s)|0> - sqrt(s)|1>,

and the cq input

    rho_XR(p,s) = (1-p)/2 |0><0| tensor |psi_+><psi_+|
                 +(1-p)/2 |1><1| tensor |psi_-><psi_-|
                 +p |2><2| tensor |1><1|.

A uniform bit U selects p+h or p-h, with p=1/10, s=1/100, h=1/100. The reference marginals in these two branches need not be equal, so this is a conditional-information witness. The script exact_triangle_certificate.py certifies

    0.927420641599022566 < I(U;Y|R)/I(U;X|R)
                         < 0.927420641599022567.

This exceeds the ordinary coefficient 1/2. It is a finite exact inequality, not merely a limiting or floating-point claim.

## 4. Exact finite fixed-reference witness

The stronger finite example uses a three-dimensional reference R=R0 direct-sum C r, where R0 has dimension two. Put

    u_0=(1/2,0)^T, u_1=(0,1/2)^T, u_2=(-1/2,-1/2)^T,
    n=10000, p=1/(1+n^2), q=n^2/(1+n^2), t=1/10.

For U=+ or -, define subnormalized 3-by-3 reference blocks for each classical X=x by

    rho_x^+/- = [[q u_x u_x^T, +/- t sqrt(pq) u_x],
                 [+/- t sqrt(pq) u_x^T, p/3]].

Since sqrt(pq)=n/(1+n^2), every matrix entry is rational. The sum of the squared norms of the u_x is one, so the full cq state has trace one. On the support of u_x the Schur complement is p(1/3-t^2)>0; hence each block is positive. Also sum_x u_x=0, so

    sum_x rho_x^+ = sum_x rho_x^-.

Consequently I(U;R)=0 exactly, not approximately. Flipping the sign of r conjugates the + and - states, so they have the same entropy. Their average is obtained by deleting all off-diagonal blocks. Apply W to the classical X register.

The script exact_fixed_reference_certificate.py isolates the eigenvalues of these rational matrices with exact rational characteristic-polynomial intervals and uses proved rational bounds on logarithms. It certifies

    0.918490786084546654 < I(U;YR)/I(U;XR)
                         < 0.918490786084547090.

These mutual informations are also the corresponding conditional mutual informations because I(U;R)=0. The input information lies between

    0.000000005513760010993645 and 0.000000005513760010993648 nats.

The very small denominator is part of the construction, not concealed. A ratio near one does not assert a positive noiseless communication rate or a noiseless subchannel.

## 5. Certificate scope

These scripts prove the listed finite inequalities through exact arithmetic algorithms. They do not formally verify the main theorem, establish novelty, or show a 10/10 historical breakthrough. The main theorem's asymptotic sharpness is supplied by its analytical proof, separately from these certificates.
