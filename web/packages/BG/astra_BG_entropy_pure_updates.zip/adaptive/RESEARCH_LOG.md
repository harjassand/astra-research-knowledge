# Research record and failure scopes

9 October 2026. This is a mathematical provenance/status record, not an independent referee report.

## Source selection and distinct opportunities

The Astra revision was pinned to 031ce532f7f6d1c070387f6213a00204893be79d and navigation began at 00_START_HERE.txt. The OpenAI/math revision was pinned to fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb. Catalogue claims were distinguished from original proof text and formalization scope. No repository writes occurred.

The following distinct mathematical routes were investigated before concentration on entropy contraction:

1. Sidorenko counterexample to bipartite commonality. The released TeX construction contains an asymmetric sparse-density deficit. A commonality resolution also needs simultaneous control of the complementary graphon. No valid bridge controlling both colors was obtained. A counterexample to Sidorenko alone is not a counterexample to the separate commonality assertion.
2. Complete Crouzeix amplification. The complete, matrix-valued conclusion is already claimed in the pinned release. Treating that amplification as a new result would have been duplication. No independently consequential further theorem was obtained from the inspected least-metric construction.
3. Zero-secret-key and PPT-composition mechanisms. The inspected transcript/root-fidelity obstruction motivated investigation of resource stability. The underlying model-generated manuscript was not assumed fully verified, and its entire defining cone was not audited. None of its claimed theorems is a premise of the main result.
4. Classical bound information and quantum references. The less-noisy erasure/BSC construction from the primary bound-information preprint led to the question whether its information comparison remains true with arbitrary quantum side information. The binary comparison did extend, but the guessed all-classical-channel equality with the ordinary coefficient failed for ternary exclusion.
5. Exact contraction rather than an auxiliary sufficiency condition. The ternary failure led to a general harmonic formula for classical channels, then to a finite Gram problem, a Choi inverse formula for all quantum channels, and a matching coherent-reference construction.

## Main proof development and current authority

RESULTS.md is the authoritative statement and proof in this package. It supersedes the checkpoints where the same mechanism was narrower or only conjectural.

The key final strengthening was to vary an off-diagonal coherent block while keeping both diagonal blocks fixed. This preserves the reference marginal exactly. A rare reference sector makes the BKM divided difference converge to a rectangular inverse-matrix quadratic form. It replaces a longer varying-marginal entropy expansion and proves equality of fixed-reference complete and conditional coefficients, not only a formula for the latter.

The signed-lift comparison technique has a primary-literature precedent in Zhu--Wang, arXiv:2607.24693v1. The independent mathematical content claimed here is the exact finite optimization and its converse, not invention of the entire less-noisy or BKM framework.

## Failed or uncompleted extensions

- The conjecture that quantum conditioning never improves a classical channel's ordinary contraction constant is false. Exact finite ternary certificates are supplied.
- A numerical guess that fixing the reference restores the classical contraction bound was also false. The new exact fixed-reference certificate settles this for a finite example.
- The full-information comparison of an arbitrary pair of quantum channels is not characterized here by a general signed-lift SDP. A direct extension would need a common adjoint-preserving lift satisfying both weighted square inequalities. This is not asserted to follow from the one-sided quadratic comparison. No unresolved pair-comparison lemma is used in the main theorem.
- Failure of a quantum less-noisy comparator does not prove quantum activation of a bound-information source. No such activation is claimed.
- The universal-helper invariance argument in the early checkpoint concerns its specified classical secrecy source and operational key rate. It does not show that every bound-information source is inert or refute a different one-shot secret-bit-fraction statement.
- A channel with zero unassisted private/quantum capacity is not thereby an NPT-undistillable state. No NPT undistillability conclusion was obtained.
- No statement about the quantum Mrs Gerber conjecture or a universal log-Sobolev constant is claimed.

## Executed checks

Exact:
- Rational interval certificate for the qubit-reference conditional ternary example: PASS.
- Exact rational Gram/Choi/RLD certificate for qubit depolarization at lambda=1/2: PASS.
- Rational characteristic-root and logarithm intervals for a finite exactly fixed-reference ternary example: PASS.

Numerical only:
- Binary, ternary, positive/asymmetric classical, support, and quantum-depolarizing probes.
- Coherent-flag BKM ratios approaching the qubit value 3/8.
- Random nonunital qubit centers. SLSQP did not satisfy its termination tolerance in the recorded trials. The returned values are not optimum certificates and are retained with the failure flags.

The analytical proof was internally checked for quantifiers, center positivity, Stinespring and Choi conventions, support restrictions, minimax compactness/coercivity, and limit order. No independent subagent review, human review, or proof-assistant verification took place. No such capability or work is implied by the numerical checks.

## Historical conclusion

The run produced a candidate general theorem with a complete written proof and finite exact corroboration. It did not establish historical priority or a defensible verified 10/10 classification. The primary literature checks establish the surrounding framework, not the absence of an equivalent earlier theorem. The precise mathematical result should be reviewed on its own terms rather than promoted as a resolved famous conjecture.

## Final strengthening: input marginal and correlation-only witnesses

The affine coherent-flag perturbation also has zero partial trace over the reference. Therefore its two states have exactly equal input marginals, and its binary auxiliary is independent of each local subsystem separately. A further orthogonal reference flag can impose any prescribed faithful input marginal without changing the relative-entropy ratio. The input-dependent complete coefficient consequently depends only on the support of that prescribed marginal, with no statement made about comparison against a fixed product reference state.

For classical channels, dephasing the minimax state in the input alphabet preserves the matrix objective; its weighted projection and coherent-flag witness remain classical on the input. This verifies that the classical-channel formulas do not depend on allowing input coherences.
