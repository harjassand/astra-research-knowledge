# Exact conditional quantum-reference contraction of a finite classical channel

Local theorem candidate, 2026-10-09. A complete analytical proof is recorded below. This is not formal or external validation; novelty not established.

Let W(y|x) be a finite stochastic channel, k input letters, and C={y: W(y|x)>0 for every x}. Define

    beta(W) = min_{theta in Delta_k} sum_{y in C} [sum_x theta_x/W(y|x)]^(-1),

with empty sum zero. Let eta_Q(W) be the supremum of I(U;Y|R)/I(U;X|R) over all finite quantum U,R and cq inputs with classical X, positive denominator. Then

    eta_Q(W) = 1 - beta(W).

The supremum is approached with a binary classical U and dim(R)<=k. For k=1 or constant channels the coefficient is zero by convention. This also gives the conditional relative-entropy coefficient. Arbitrary quantum inputs to the measure-and-prepare version do not increase the coefficient, by dephasing before the channel.

Equivalent finite convex program when C nonempty:

    r = min_{a in Delta(C)} max_x [sum_{y in C} a_y^2/W(y|x)-1],
    eta_Q = r/(1+r),  beta=1/(1+r).

This extends the earlier binary-input result and sharpens the support criterion. Ordinary classical KL coefficient need not agree: W_k(y|x)=1[y!=x]/(k-1) has eta_classical=1/(k-1) but eta_Q=1.

## Upper proof

Convex minimax, followed by weighted Cauchy-Schwarz, gives

    1+r = max_theta min_{a in Delta(C)} sum_y a_y^2 sum_x theta_x/W(y|x)
        = max_theta 1/[sum_{y in C}(sum_x theta_x/W(y|x))^-1]
        = 1/beta.

Choose a minimizing center a, extended by zero outside C; eta=r/(1+r). Let N be input erasure with reveal probability eta. For arbitrary matrix output observables F_y set

    mu_x=sum_y W(y|x) F_y, alpha=sum_y a_y F_y,
    (J F)_e=alpha,
    (J F)_x=(mu_x-(1-eta)alpha)/eta.

Then N^*J=W^*. At each input x the weighted square defect is exactly

    sum_y W(y|x)F_y^*F_y - eta(JF)_x^*(JF)_x -(1-eta)alpha^*alpha
      = Var_{W_x}(F) - ((1-eta)/eta)(mu_x-alpha)^*(mu_x-alpha) >=0.

Operator Cauchy-Schwarz bounds the squared last difference by chi^2(a||W_x) Var <= r Var. Repeat for F_y F_y^*. For any positive cq input omega, these inequalities say J^* L_{N omega}J <= L_{W omega} and likewise for right multiplication. Transformer inequality/monotonicity of the logarithmic mean of left and right multiplication yields J^* Gamma_{N omega}J <= Gamma_{W omega}, where Gamma_sigma(H)=int_0^1 sigma^t H sigma^(1-t) dt. Variational inversion and W=J^*N imply BKM Hessian domination, then affine-segment integration gives D(W rho||W sigma)<=D(N rho||N sigma). Erasure evaluates the right side as eta D(rho||sigma)+(1-eta)D(rho_R||sigma_R). Subtract the reference relative entropy, or specialize sigma=rho_U tensor rho_RX, to get the claimed conditional bound. Regularize cq input blocks for singular states. eta=0 is the constant channel; beta=0 uses only DPI.

## Lower proof (weighted coherent frame)

Fix any theta with all entries positive, k>=2. Let d=(sqrt(theta_x))_x. Choose a real (k-1)-by-k matrix Q with QQ^*=I and Qd=0. Put

    u_x=Q e_x/sqrt(k-1),  r perpendicular unit vector,
    f_x(s)=sqrt(1-s)u_x+sqrt(s theta_x)r.

Then sum_x u_x u_x^*=I/(k-1), sum_x sqrt(theta_x)u_x=0, sum_x ||f_x(s)||^2=1. Fix tau_x>0 summing to one, q=1-p, and set cq blocks

    rho_x(p,s)=q |f_x(s)><f_x(s)|+p tau_x |r><r|.

The reference marginal is exactly

    S(p,s)=q(1-s) I_{k-1}/(k-1)+(p+q s)|r><r|.

Use binary uniform U whose two conditional input states are rho(p+h,s),rho(p-h,s). If F_V(p,s)=Tr rho_VR log rho_VR - Tr S log S = -H(V|R), then

    I(U;V|R)=[F_V(p+h,s)+F_V(p-h,s)]/2-F_V(p,s).

Thus h->0 gives ratio of second p derivatives g_Y/g_X.

For any output y of a stochastic map V applied to X (including the identity map), put

    A_y=sum_x V(y|x)u_xu_x^*,
    b_y=sum_x V(y|x)sqrt(theta_x)u_x,
    a_y=sum_x V(y|x)theta_x,
    c_y=sum_x tau_x V(y|x)>0

for nonzero output columns. The output block is

    C_y(p,s) = [[q(1-s) A_y, q sqrt(s(1-s)) b_y],
                 [q sqrt(s(1-s)) b_y^*, p c_y+q s a_y]].

Restrict to ran A_y plus r (a fixed subspace for fixed y). This is faithful at s=0 for fixed 0<p<1. Entropy is analytic and even in sqrt(s), by conjugation that changes sign on r, so the expansion and two p derivatives are valid locally:

    Tr C_y log C_y = E_y,0(p)+s E_y,1(p)+O(s^2).

If B=q A_y has positive eigenvalues lambda_j and v=q b_y components v_j, mu=p c_y, then

    E_y,1 = -Tr[B log B] + q a_y(log mu+1) -Tr B
            +sum_j |v_j|^2 (log lambda_j-log mu)/(lambda_j-mu).

Unlike the earlier normalized-simplex special case, a_y need not equal Tr A_y. The displayed +1 terms must be retained, but are affine in p and have zero second p derivative. The coefficient of log mu is

    kappa_y(p)=q a_y - sum_j |v_j|^2/(lambda_j-mu),
    kappa_y(0)=a_y-b_y^* A_y^+ b_y =: h_y.

All other terms are analytic near p=0; kappa_y(p)=h_y+O(p), with analytic coefficients. Thus

    E_y,1''(p)=-h_y/p^2 + O(1/p+|log p|).

The reference's first s coefficient is q log[p(k-1)/q], whose negative second p derivative is 1/[p^2(1-p)]. At s=0, R distinguishes the common sector and rare r sector, each with p-independent conditional X law; hence g_V(p,0)=0 for every V. Therefore

    g_V(p,s)=s[(1-sum_y h_y)/p^2 + O(1/p+|log p|)] + O_p(s^2).

The h_y values have a simple exact formula. Let D_y=diag(V(y|x)), U=Q/sqrt(k-1). A_y=U D_y U^*, b_y=U D_y d, a_y=d^*D_y d. The difference h_y is the squared projection of D_y^(1/2)d onto ker(U D_y^(1/2)).

If every V(y|x)>0, that kernel is spanned by D_y^(-1/2)d and

    h_y = 1/[sum_x theta_x/V(y|x)].

If at least one V(y|x)=0, the selected columns of U are linearly independent, since ker U is span d and all d_x are positive. Consequently h_y=0. For the identity map (k>=2), every output column has zeros, so all h_y=0. Thus g_X has leading coefficient 1/p^2, while W has coefficient 1-sum_{y in C}harmonic_y.

Take h->0 at fixed p,s, then s->0 at fixed p, then p->0. The ratio tends to 1-sum_{y in C}(sum_x theta_x/W(y|x))^-1. Strict positivity of the input denominator follows for sufficiently small p,s,h from its leading positive second derivative. Finally approach a minimizing theta by interior theta; the objective only sums common positive columns and is continuous on the entire probability simplex. This proves the lower bound and equality.

## Consequences immediately proved

1. Strict contraction iff C nonempty iff the Doeblin common mass sum_y min_x W(y|x)>0.
2. For binary input eta_Q=ordinary eta_KL via the two-row harmonic identity; all boundary cases follow by positive-output replacement regularization.
3. For the symmetric k-by-k channel with diagonal a>0 and off-diagonal b>0, a+(k-1)b=1, symmetry and convexity give uniform minimizing theta:

    eta_Q = 1-k^2/[1/a+(k-1)/b].

In particular a=3/5,b=1/5,k=3 gives eta_Q=8/35 whereas ordinary classical eta=1/5.
4. For exclusion W_k, eta_Q=1, ordinary eta=1/(k-1); the complete/reference gap is unbounded in ratio.

## Numerical replay (not proof)

harmonic_witness_probe.py implements the exact frame construction and floating-point BKM Hessians. For symmetric ternary a=.6,.01,.1,.8, the ratios at p=1e-5,s=1e-11 approach the predicted .2285714286,.9134951456,.3769230769,.5764705882 respectively. An asymmetric positive 3-input example predicted .3225094542 and produced .3225057009. Boundary-optimal theta requires nested limits; do not replace them with an asserted uniform schedule.

## Scientific status

Originality is not certified. Complete analytical argument is available locally; no independent checker or Lean formalization was run. The signed-lift-to-BKM mechanism is based on Zhu-Wang arXiv:2607.24693v1; the coefficient's framework is Hirche-George-Nuradha-Wilde arXiv:2608.27171v1. The center formula and matching coherent-frame construction require targeted primary-literature checking before claiming priority.
