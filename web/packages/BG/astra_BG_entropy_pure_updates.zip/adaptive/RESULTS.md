# Exact complete and conditional entropy contraction from the Choi matrix

**Research date:** 9 October 2026.  
**Status:** a new theorem candidate with a complete analytical argument supplied below. No independent mathematical review, proof-assistant formalization, or historical-priority certification has been obtained. The exact arithmetic certificates verify specified finite examples, not the general proof. No canonical repository was modified.

## 1. Result and scientific scope

The main result proposed here is an exact finite semidefinite program for three information-contraction coefficients of every finite-dimensional quantum channel. In particular, the complete relative-entropy coefficient, defined using pairs with the **same reference marginal**, equals the conditional relative-entropy coefficient, which permits different reference marginals and subtracts their distinguishability. Both equal conditional-mutual-information contraction.

The formula has a matching upper proof and a constructive lower proof. The latter is not numerical optimization: a coherent perturbation in one additional reference direction converts a rectangular inverse-matrix quadratic form into actual relative entropy, while keeping the reference marginal exactly fixed.

This is not a formula for the ordinary, unreferenced contraction coefficient, for contraction toward a prescribed stationary state, or for quantum capacity. It does not settle NPT bound entanglement, classical bound-information activation in full generality, or another previously stalled Astra target. Its historical importance should not be assigned a 10/10 score without independent proof and priority review.

The formulation of conditional coefficients is prior work [1]. Signed observable lifts and the left/right quadratic-to-entropy argument have precedents in [2]. The proposed new content is the exact optimization, its converse, the bounded-reference coherent construction, and the consequences derived from them. None of the main proof's premises is a model-generated theorem from Astra or OpenAI/math.

## 2. Definitions and normalization

Let \(\mathcal N:\mathcal L(A)\to\mathcal L(B)\) be completely positive and trace preserving. Write \(d=\dim A\), \(m=\dim B\), and \(\mathcal N_R=\operatorname{id}_R\otimes\mathcal N\). References are arbitrary finite-dimensional quantum systems. Logs are natural logs; the ratios are independent of their base.

For states of finite relative entropy,
\[
D(\rho\|\sigma)=\operatorname{Tr}\rho(\log\rho-\log\sigma).
\]
Define
\[
\eta_D^c(\mathcal N)
=\sup_{\substack{R,\rho,\sigma:\rho_R=\sigma_R\\0<D(\rho\|\sigma)<\infty}}
\frac{D(\mathcal N_R\rho\|\mathcal N_R\sigma)}{D(\rho\|\sigma)}, \tag{2.1}
\]
\[
\eta_D^\Delta(\mathcal N)
=\sup_{\substack{R,\rho,\sigma\\0<D(\rho\|\sigma)-D(\rho_R\|\sigma_R)<\infty}}
\frac{D(\mathcal N_R\rho\|\mathcal N_R\sigma)-D(\rho_R\|\sigma_R)}
{D(\rho\|\sigma)-D(\rho_R\|\sigma_R)}, \tag{2.2}
\]
where both relative entropies before subtraction are finite, and
\[
\eta_{\mathrm{CMI}}(\mathcal N)
=\sup_{\rho_{URA}:I(U;A|R)>0}
\frac{I(U;B|R)_{\mathcal N(\rho)}}{I(U;A|R)_\rho}. \tag{2.3}
\]
Here \(I(U;A|R)=S(UR)+S(AR)-S(R)-S(UAR)\). An empty supremum is defined as zero, covering a one-dimensional input.

Use the **unnormalized** Choi matrix
\[
J=\sum_{i,j=1}^d |i\rangle\langle j|\otimes
\mathcal N(|i\rangle\langle j|),\qquad \operatorname{Tr}_B J=I_A. \tag{2.4}
\]
All occurrences of \(J^+\) denote the Moore--Penrose inverse. A normalized Choi state cannot be substituted into the following formula without changing the scale.

## 3. Exact Choi formula

**Theorem.** Let \(M(\mathcal N)\) be the value of the following finite semidefinite program:
\[
\begin{aligned}
\text{minimize}\quad &t\\
\text{over}\quad &\sigma\succeq0,\quad\operatorname{Tr}\sigma=1,
\quad Z=Z^*,\quad t\in\mathbb R,\\
\text{subject to}\quad &
\begin{pmatrix}J&I_A\otimes\sigma\\I_A\otimes\sigma&Z\end{pmatrix}\succeq0,
\qquad\operatorname{Tr}_B Z\preceq tI_A.
\end{aligned} \tag{3.1}
\]
Set \(M=\infty\) if the program is infeasible. Then
\[
\boxed{\quad\eta_D^c(\mathcal N)=\eta_D^\Delta(\mathcal N)
=\eta_{\mathrm{CMI}}(\mathcal N)=1-\frac1{M(\mathcal N)}.\quad} \tag{3.2}
\]
When finite, \(M\ge1\). The supremum in (2.3) is approached with **binary classical** \(U\), **exactly** \(I(U;R)=I(U;A)=0\), and \(\dim R\le m^2+1\). The same reference bound suffices in (2.1).

Equivalently,
\[
M(\mathcal N)=\min_\sigma
\left\|\operatorname{Tr}_B[(I\otimes\sigma)J^+(I\otimes\sigma)]\right\|_\infty, \tag{3.3}
\]
over density matrices satisfying
\[
\operatorname{ran}(I\otimes\sigma)\subseteq\operatorname{ran}J. \tag{3.4}
\]
The range condition is essential; omitting it gives wrong answers for singular Choi matrices.

### Proof plan

A centered matrix Gram problem equals a rectangular inverse-matrix contraction problem. Stinespring factorization solves the Gram problem in terms of (3.3). Its positive optimizer gives a signed lift through an erasure channel, proving the universal upper bound. A coherent reference flag proves sharpness with an exactly fixed marginal.

## 4. The finite centered Gram problem

Put \(\Phi=\mathcal N^*\), a unital completely positive map. Choose any complex basis \(F_1,\ldots,F_n\) of \(\mathcal L(B)\), where \(n=m^2\). Let
\[
\mathbf A=\begin{pmatrix}\Phi(F_1)\\\vdots\\\Phi(F_n)\end{pmatrix},
\qquad \mathbf G=[\Phi(F_iF_j^*)]_{i,j=1}^n.
\]
Define \(\eta_G\) as the least \(\eta\) for which a scalar column \(a\in\mathbb C^n\) satisfies
\[
(\mathbf A-a\otimes I_A)(\mathbf A-a\otimes I_A)^*
\preceq\eta\mathbf G. \tag{4.1}
\]
Complete Schwarz gives feasibility at \(\eta=1,a=0\). The minimizer exists: for bounded \(\eta\), (4.1) bounds \(\|\mathbf A-a\otimes I\|\), hence bounds \(a\). Any other finite tuple of output operators is a scalar linear combination of the basis tuple, so (4.1) controls every tuple, not merely this chosen basis.

### 4.1 Rectangular quadratic forms

For \(C\succ0\) on \(R_0\otimes A\) and a block column \(B:A\to R_0\otimes A\), define
\[
q_C(B)=\operatorname{Tr}B^*C^{-1}B.
\]
Both \(\mathcal N(B)\) and \(\operatorname{Tr}_A B\) mean blockwise application. Thus \(\operatorname{Tr}_A B=0\) means that every block of the column has trace zero. Set
\[
\eta_{\mathrm{rect}}=\sup_{\substack{R_0,C\succ0,B\ne0\\\operatorname{Tr}_A B=0}}
\frac{q_{\mathcal N_{R_0}(C)}(\mathcal N(B))}{q_C(B)}. \tag{4.2}
\]
Unused output support is removed once and for all: on \(\operatorname{supp}\mathcal N(I)\), a faithful input produces a faithful output. Normalizing \(\operatorname{Tr}C=1\) does not change a ratio.

**Lemma 4.1.** \(\eta_{\mathrm{rect}}=\eta_G\), and \(\dim R_0=n\) suffices for the supremum.

**Proof.** Weighted Hilbert-space duality gives, for any block column \(F\),
\[
\sup_{\substack{B\ne0\\\operatorname{Tr}_A B=0}}
\frac{|\operatorname{Tr}B^*\Phi(F)|^2}{q_C(B)}
=\inf_a\operatorname{Tr}C(\Phi(F)-a\otimes I)(\Phi(F)-a\otimes I)^*. \tag{4.3}
\]
Indeed the annihilator of the trace-zero block columns, under the Hilbert--Schmidt pairing, consists exactly of scalar block columns \(a\otimes I\). Taking the distance to this annihilator in the dual weighted norm proves (4.3). Equivalently, it is the usual orthogonal-projection theorem applied after multiplying columns by \(C^{-1/2}\).

The dual squared norm of an unrestricted output test \(F\) is
\[
\operatorname{Tr}\mathcal N(C)FF^*=\operatorname{Tr}C\Phi(FF^*).
\]
Consequently (4.1), and its scalar compressions, imply \(\eta_{\mathrm{rect}}\le\eta_G\).

Conversely fix \(0\le\eta<\eta_G\), use the basis tuple, and let \(C\) range over density matrices on \(\mathbb C^n\otimes A\). The finite-dimensional convex minimax identity gives
\[
\begin{aligned}
&\sup_C\inf_a\operatorname{Tr}C
[(\mathbf A-aI)(\mathbf A-aI)^*-\eta\mathbf G]\\
&\qquad=\inf_a\lambda_{\max}
[(\mathbf A-aI)(\mathbf A-aI)^*-\eta\mathbf G]>0. \tag{4.4}
\end{aligned}
\]
For completeness, the minimax hypotheses are: the density matrices form a compact convex set; the function is affine and continuous in \(C\), and convex continuous in the real and imaginary parts of \(a\). The right-hand objective is coercive in \(a\), so its infimum is attained. If that minimum were nonpositive, (4.1) would be feasible at \(\eta\), a contradiction.

Some \(C\) therefore makes the infimum positive. It can be made faithful by mixing in a small positive multiple of the identity: the infimum is concave in \(C\), and is bounded below on the density matrices by \(-\eta\|\mathbf G\|\). Positivity thus persists for sufficiently small mixing.

For this faithful \(C\), (4.3) supplies a trace-zero block column \(B\) whose dual output test already gives a ratio exceeding \(\eta\). The full output norm is at least that test value. Hence \(\eta_{\mathrm{rect}}\ge\eta_G\). This construction uses \(R_0=\mathbb C^n\). \(\square\)

## 5. Solving the Gram problem by Stinespring geometry

Choose a minimal Stinespring isometry \(V:A\to B\otimes E\), so
\[
\Phi(Y)=V^*(Y\otimes I_E)V.
\]
The Gram inequality (4.1) is equivalent to the existence of a map \(K:B\otimes E\to A\), with \(\|K\|^2\le\eta\), satisfying
\[
K(Y\otimes I)V=\Phi(Y)-\alpha(Y)I_A \tag{5.1}
\]
for a scalar complex-linear functional \(\alpha\).

Here is the factorization explicitly. With \(T_i=(F_i^*\otimes I)V\), the block matrix \(\mathbf G\) is \(T^*T\), where \(T\) is the row of the \(T_i\). If \(S=\mathbf A-aI\), define \(K(Tv)=S^*v\). The inequality \(SS^*\preceq\eta T^*T\) makes this well-defined and bounded by \(\sqrt\eta\), and extension by zero on \((\operatorname{ran}T)^\perp\) gives \(K\). Its values on the adjoint basis define \(\alpha(F_i^*)=\overline{a_i}\). This is a bijective reparametrization of the scalar centers. The converse follows by taking Gram matrices.

Set \(L=V^*-K\). Equation (5.1) becomes
\[
L(Y\otimes I)V=\alpha(Y)I. \tag{5.2}
\]
If \(t=\alpha(I)=0\), then \(LV=0\) and
\(\|V^*-L\|^2=1+\|L\|^2\ge1\). If \(t\ne0\), write \(L=tS\), so \(SV=I\), and decompose
\[
S=V^*+S_\perp,\qquad S_\perp V=0.
\]
The cross terms vanish, giving
\[
\|V^*-tS\|^2=|1-t|^2+|t|^2\|S_\perp\|^2. \tag{5.3}
\]
For fixed \(r=\|S_\perp\|^2\), the minimum over \(t\in\mathbb C\) is \(r/(1+r)\), attained at \(t=1/(1+r)\). Also
\[
SS^*=I+S_\perp S_\perp^*,\qquad \|S\|^2=1+r. \tag{5.4}
\]
Thus it remains to minimize \(\|S\|^2\) over the normalized solutions of (5.2).

### 5.1 The Choi inverse and the positive center

Write a minimal Kraus representation
\[
V=\sum_jK_j\otimes|j\rangle,
\qquad S=\sum_jL_j^*\otimes\langle j|.
\]
Use \(|K\rangle\rangle=\sum_i|i\rangle\otimes K|i\rangle\). Normalized (5.2) says that, for a possibly complex \(H\) with \(\operatorname{Tr}H=1\),
\[
\sum_j|L_j\rangle\rangle\langle\langle K_j|=I_A\otimes H. \tag{5.5}
\]
With this vectorization convention the functional in (5.2) is \(Y\mapsto\operatorname{Tr}(H^*Y)\). This distinction disappears when \(H\) is positive, as it will be at the optimum.

Let \(M_K\) have columns \(|K_j\rangle\rangle\). Minimality makes the columns independent and \(J=M_KM_K^*\). Equation (5.5) has the solution
\[
M_L=(I\otimes H)J^+M_K \tag{5.6}
\]
exactly when \(\operatorname{ran}(I\otimes H^*)\subseteq\operatorname{ran}J\). It is unique for this minimal environment. Direct multiplication gives
\[
\|S\|^2=
\left\|\operatorname{Tr}_B[(I\otimes H)J^+(I\otimes H^*)]\right\|_\infty. \tag{5.7}
\]
A transpose on the remaining \(A\) factor can arise from vectorization; it leaves the operator norm unchanged.

Partial-trace cyclicity on \(B\) shows that the matrix in (5.7) depends on \(H\) only through \(H^*H\). Moreover \(\operatorname{ran}H^*=\operatorname{ran}|H|\). Replacing \(H\) by
\[
\sigma=|H|/\operatorname{Tr}|H|
\]
preserves admissibility and divides (5.7) by \((\operatorname{Tr}|H|)^2\ge|\operatorname{Tr}H|^2=1\). Hence the optimizer can be taken to be a **positive density matrix**, not merely a complex affine center.

We have proved
\[
\eta_G=1-1/M,
\]
with \(M\) given by (3.3)--(3.4). If there is no normalized solution, the only possible Gram optimum is one. When there is one, the admissible densities form a compact set and the objective is continuous, so the minimum is attained. The relation \(SV=I\) also proves \(M\ge1\).

Finally, the generalized Schur-complement criterion says
\[
\begin{pmatrix}J&A\\A&Z\end{pmatrix}\succeq0
\iff \operatorname{ran}A\subseteq\operatorname{ran}J,
\quad Z\succeq AJ^+A
\]
for \(A=I\otimes\sigma\succeq0\). Positivity of the partial trace then gives exactly (3.1).

## 6. Universal entropy upper bound

Suppose \(1<M<\infty\); the endpoints are handled below. Choose the optimal positive center \(\sigma\), its normalized \(S\), and let
\[
K=S-V^*,\quad KV=0,\quad r=\|K\|^2=M-1,
\quad\alpha(Y)=\operatorname{Tr}(\sigma Y).
\]
By (5.2),
\[
\Phi(Y)-\alpha(Y)I=-K(I-VV^*)(Y\otimes I)V.
\]
Therefore
\[
(\Phi(Y)-\alpha(Y)I)^*(\Phi(Y)-\alpha(Y)I)
\preceq r[\Phi(Y^*Y)-\Phi(Y)^*\Phi(Y)]. \tag{6.1}
\]
This holds at every reference amplification because \(K\) is tensored with the identity. Apply it to \(Y^*\) for the other multiplication order. Positivity of \(\sigma\) makes \(\alpha\) adjoint preserving.

Put \(\eta=r/(1+r)\), and let \(\mathcal E_\eta\) be the quantum erasure channel that reveals its input with probability \(\eta\). Define a generally nonpositive observable lift \(\mathcal J\) by
\[
(\mathcal JY)_{\mathrm{reveal}}
=\frac{\Phi(Y)-(1-\eta)\alpha(Y)I}{\eta},
\qquad(\mathcal JY)_{\mathrm{erase}}=\alpha(Y). \tag{6.2}
\]
It is adjoint preserving and \(\mathcal E_\eta^*\mathcal J=\Phi\). Its exact square defect is
\[
\begin{aligned}
&\Phi(Y^*Y)-\eta(\mathcal JY)_r^*(\mathcal JY)_r
 -(1-\eta)\alpha(Y)^*\alpha(Y)\\
&=\Phi(Y^*Y)-\Phi(Y)^*\Phi(Y)
 -\frac{1-\eta}{\eta}(\Phi(Y)-\alpha(Y)I)^*(\Phi(Y)-\alpha(Y)I)
\succeq0. \tag{6.3}
\end{aligned}
\]
The analogous identity holds for \(YY^*\).

### 6.1 Why the signed lift controls relative entropy

The following argument is included explicitly; no physical post-processing interpretation is being assumed for \(\mathcal J\). It is a version of the left/right-to-BKM mechanism in [2].

For a positive faithful matrix \(\omega\), define left and right multiplication \(L_\omega(X)=\omega X\), \(R_\omega(X)=X\omega\), and
\[
\mathcal A_{\omega,u}=(1-u)L_\omega+uR_\omega,\qquad0\le u\le1.
\]
Taking expectations of (6.3) and its opposite-order version in any faithful reference-input state \(\omega\) gives
\[
\mathcal J^*\mathcal A_{\mathcal E_\eta(\omega),u}\mathcal J
\preceq\mathcal A_{\mathcal N(\omega),u}. \tag{6.4}
\]
All these maps include the unchanged reference. For a positive definite operator \(A\), elementary completion of the square gives
\[
\langle z,A^{-1}z\rangle
=\sup_x\{2\Re\langle x,z\rangle-\langle x,Ax\rangle\}. \tag{6.5}
\]
Restricting the variational domain on the erasure side to \(\mathcal Jx\) in (6.5), and using (6.4), yields
\[
\langle\mathcal J^*z,\mathcal A_{\mathcal N(\omega),u}^{-1}\mathcal J^*z\rangle
\le\langle z,\mathcal A_{\mathcal E_\eta(\omega),u}^{-1}z\rangle. \tag{6.6}
\]
In an eigenbasis of \(\omega\),
\[
\int_0^1\frac{du}{(1-u)\lambda_i+u\lambda_j}
=\frac{\log\lambda_i-\log\lambda_j}{\lambda_i-\lambda_j}.
\]
Thus the integral of the quadratic form in (6.6) is exactly the Hessian \(g_\omega\) of \(\operatorname{Tr}\omega\log\omega\), also called the BKM metric. Set \(z=\mathcal E_\eta(H)\); the reconstruction identity gives \(\mathcal J^*z=\mathcal N(H)\). Hence
\[
g_{\mathcal N(\omega)}(\mathcal N(H))
\le g_{\mathcal E_\eta(\omega)}(\mathcal E_\eta(H)). \tag{6.7}
\]
Finally, for \(H=\rho-\tau\), the elementary integral remainder for this entropy potential is
\[
D(\rho\|\tau)=\int_0^1(1-s)g_{\tau+sH}(H)\,ds. \tag{6.8}
\]
Integrating (6.7) proves
\[
\boxed{
D(\mathcal N_R\rho\|\mathcal N_R\tau)
\le\eta D(\rho\|\tau)+(1-\eta)D(\rho_R\|\tau_R).
} \tag{6.9}
\]
The right side is exactly the relative entropy after erasure, since its two branches are orthogonal.

For singular states with finite input relative entropy, mix both compared states with the same faithful state. Joint convexity gives the needed upper limiting bound on relative entropy; lower semicontinuity gives the reverse one. These also apply after the channel and partial trace. Passing to the limit proves (6.9) without hidden faithfulness assumptions. If \(M=1\), (6.1) with \(r=0\) says \(\Phi(Y)=\alpha(Y)I\), so the channel is a replacer and the conclusion is immediate. If \(M=\infty\), ordinary data processing gives the upper constant one.

Subtract the reference relative entropy from (6.9) to obtain \(\eta_D^\Delta\le1-1/M\). Equal-reference pairs give \(\eta_D^c\le1-1/M\). To obtain the CMI bound, apply (6.9) with reference \(UR\), first state \(\rho_{URA}\), and second state \(\rho_U\otimes\rho_{RA}\). The two sides subtract \(I(U;R)\) and become the conditional mutual informations in (2.3).

## 7. Sharpness with an exactly unchanged quantum reference

This is the decisive converse construction. It replaces the longer varying-marginal construction retained in the earlier checkpoint.

Fix faithful \(C\) on \(R_0\otimes A\) with trace one, a nonzero block column \(B\) with \(\operatorname{Tr}_A B=0\), and a faithful state \(\tau\) on \(A\). Enlarge the reference to \(R=R_0\oplus\mathbb C r\). For \(0<p<1\), \(q=1-p\), define
\[
\omega_p=\begin{pmatrix}qC&0\\0&p\tau\end{pmatrix},
\qquad H_p=\begin{pmatrix}0&\sqrt{pq}B\\\sqrt{pq}B^*&0\end{pmatrix},
\qquad\rho_{p,t}=\omega_p+tH_p. \tag{7.1}
\]
These are states for sufficiently small \(|t|\). Indeed the Schur complement is
\[
p(\tau-t^2B^*C^{-1}B)\succeq0, \tag{7.2}
\]
which permits a nonzero interval of \(t\) **independently of \(p\)**. The trace is one, and
\[
\operatorname{Tr}_A H_p=0. \tag{7.3}
\]
Thus all states in (7.1) have exactly the same reference marginal. Moreover, the perturbation is off-diagonal in the reference decomposition, so \(\operatorname{Tr}_R H_p=0\) as well: their input marginals also agree exactly.

For each fixed \(p\), Taylor expansion at the faithful \(\omega_p\) gives
\[
D(\rho_{p,t}\|\omega_p)=\tfrac12t^2g_{\omega_p}(H_p)+O_p(t^3). \tag{7.4}
\]
Diagonalize \(C\) and \(\tau\), with eigenvalues \(\lambda_j>0\) and \(\nu_a>0\). Write \(B_{ja}\) in these eigenbases. The divided-difference formula gives the exact expression
\[
g_{\omega_p}(H_p)
=2pq\sum_{j,a}|B_{ja}|^2
\frac{\log(q\lambda_j)-\log(p\nu_a)}{q\lambda_j-p\nu_a}. \tag{7.5}
\]
The quotient is interpreted continuously if the eigenvalues coincide. Since there are only finitely many terms,
\[
\lim_{p\downarrow0}\frac{g_{\omega_p}(H_p)}{2p\log(1/p)}
=\sum_{j,a}\frac{|B_{ja}|^2}{\lambda_j}
=q_C(B). \tag{7.6}
\]
After \(\mathcal N\), the same calculation applies with
\(C'=\mathcal N_{R_0}(C)\), \(B'=\mathcal N(B)\), and \(\tau'=\mathcal N(\tau)\), all restricted to the fixed output support. It follows that
\[
\lim_{p\downarrow0}\lim_{t\to0}
\frac{D(\mathcal N_R\rho_{p,t}\|\mathcal N_R\omega_p)}{D(\rho_{p,t}\|\omega_p)}
=\frac{q_{C'}(B')}{q_C(B)}. \tag{7.7}
\]
No limits have been interchanged: take the local perturbation limit first for each \(p\), and only then send \(p\) to zero. The input quadratic form is strictly positive. Every pair used in (7.7) has exactly equal reference marginals. Therefore
\[
\eta_D^c\ge\eta_{\mathrm{rect}}=\eta_G=1-1/M. \tag{7.8}
\]
The upper bound proves equality.

For the additional CMI assertion, let uniform classical \(U\in\{-1,+1\}\) select \(\rho_{p,t}\) or \(\rho_{p,-t}\). Their average is exactly \(\omega_p\), and the two partial-trace identities give \(I(U;R)=I(U;A)=0\). Their input and output mutual informations are the averages of the two relative entropies against this common average, so (7.4)--(7.7) give the same limiting ratio. By Lemma 4.1 one needs \(\dim R_0\le m^2\), and the construction adds only one dimension.

Since equal-reference pairs are allowed in (2.2), all three coefficients have the claimed value. This completes the proposed proof. \(\square\)

## 8. Exact consequences

### 8.1 A strict-contraction criterion

Let \(P\) be the support projection of \(J\), and set
\[
B_0=\ker\operatorname{Tr}_A(I-P). \tag{8.1}
\]
For \(b\in B\),
\[
\langle b,\operatorname{Tr}_A(I-P)b\rangle
=\sum_i\|(I-P)(|i\rangle\otimes b)\|^2.
\]
Thus \(B_0\) is exactly the largest output subspace with
\(A\otimes B_0\subseteq\operatorname{supp}J\). The theorem gives
\[
\eta_D^c<1\quad\Longleftrightarrow\quad B_0\ne\{0\}. \tag{8.2}
\]
Equivalently, there is a density \(\sigma\) and \(\varepsilon>0\) with
\(J\succeq\varepsilon I\otimes\sigma\): the channel has a positive completely-positive replacer component. The connection to Doeblin minorization is prior context [3]; the equality formula determines more than that qualitative bound.

### 8.2 A matrix harmonic dual and exact products

When \(B_0\ne0\), compress \(J^+\) to \(K\succ0\) on \(A\otimes B_0\). Then
\[
\boxed{\quad
\beta(\mathcal N):=1/M(\mathcal N)
=\min_{\theta_A\text{ a state}}
\operatorname{Tr}\left[\operatorname{Tr}_A((\theta_A\otimes I)K)\right]^{-1}.
\quad} \tag{8.3}
\]
To prove it, express (3.3) as
\(\min_\sigma\max_\theta\operatorname{Tr}K(\theta\otimes\sigma^2)\).
Convex minimax exchanges the two optimizations. For
\(H_\theta=\operatorname{Tr}_A((\theta\otimes I)K)\succ0\), weighted Cauchy--Schwarz gives
\[
\min_{\sigma\succeq0,\operatorname{Tr}\sigma=1}\operatorname{Tr}H_\theta\sigma^2
=1/\operatorname{Tr}H_\theta^{-1},
\]
attained by \(\sigma=H_\theta^{-1}/\operatorname{Tr}H_\theta^{-1}\). This proves (8.3).

For two channels with finite \(M_i\), their common output subspaces multiply. Indeed, with \(S_i=\operatorname{Tr}_{A_i}P_i\), the eigenvalues of \(S_i\) are at most \(d_i\); the eigenspace of \(S_1\otimes S_2\) at \(d_1d_2\) is exactly the product of the individual top eigenspaces. Hence \(B_{0,12}=B_{0,1}\otimes B_{0,2}\).

Product choices in the primal (3.3) give \(M_{12}\le M_1M_2\). Product choices in the dual (8.3) give \(\beta_{12}\le\beta_1\beta_2\), which is the reverse inequality for \(M\). If a factor has \(\beta=0\), fixing the other input gives coefficient one for the product. Therefore
\[
\boxed{\quad\beta(\mathcal N_1\otimes\mathcal N_2)=\beta(\mathcal N_1)\beta(\mathcal N_2),\quad}
\]
\[
\boxed{\quad\eta(\mathcal N_1\otimes\mathcal N_2)
=1-(1-\eta(\mathcal N_1))(1-\eta(\mathcal N_2)).\quad} \tag{8.4}
\]
Here \(\eta\) denotes any of the three equal coefficients, not the ordinary classical coefficient or a fixed-state contraction constant.

### 8.3 All finite classical channels

Let \(W(y|x)\) be a stochastic matrix, viewed as a measure-and-prepare quantum channel. Its Choi matrix is diagonal. Averaging the center over output phases makes it diagonal without increasing the convex objective. Formula (8.3) reduces to
\[
\boxed{\quad
\eta(W)=1-\min_{\theta\in\Delta_X}
\sum_{y:\,W(y|x)>0\ \forall x}
\left(\sum_x\frac{\theta_x}{W(y|x)}\right)^{-1}.
\quad} \tag{8.5}
\]
An empty sum is zero. This is contraction with quantum side information. It is not, in general, the classical KL contraction coefficient. The formula remains sharp when the input register is required to be classical. To see this in the proof, \(\mathbf A\) and \(\mathbf G\) are block-diagonal in the input alphabet. Dephasing \(C\) in that alphabet preserves every minimax objective in (4.4). The weighted projection in (4.3) then supplies a block-diagonal \(B\). The coherent-flag states (7.1) are consequently classical on the channel input, as required.

For the exclusion channel on \(k\ge3\) symbols,
\[
W_k(y|x)=\frac{\mathbf1_{y\ne x}}{k-1},
\]
every output column has a zero, so \(\eta(W_k)=1\). In contrast, the ordinary classical KL coefficient is \(1/(k-1)\); a self-contained proof is in CLASSICAL_EXAMPLES.md. A finite rational ternary example with a qubit reference is certified in exact_triangle_certificate.py.

For a symmetric channel with diagonal \(a>0\), off-diagonal \(b>0\), and \(a+(k-1)b=1\), symmetry and convexity yield
\[
\eta(W)=1-\frac{k^2}{1/a+(k-1)/b}. \tag{8.6}
\]
For example \(k=3,a=3/5,b=1/5\) gives \(8/35\), rather than the ordinary classical value \(1/5\).

### 8.4 Depolarizing channels in every dimension

For
\[
\mathcal D_\lambda(X)=\lambda X+(1-\lambda)\operatorname{Tr}(X)I_d/d,
\qquad -1/(d^2-1)\le\lambda\le1,
\]
for \(d\ge2\), unitary covariance and convexity make \(\sigma=I_d/d\) optimal. The one-dimensional channel is a replacer and has coefficient zero. The Choi eigenvalues are
\([1+(d^2-1)\lambda]/d\) once and \((1-\lambda)/d\) with multiplicity \(d^2-1\). Substitution and simplification give
\[
\boxed{\qquad
\eta(\mathcal D_\lambda)=
\frac{(d^2-1)\lambda^2}{1+(d^2-2)\lambda}.
\qquad} \tag{8.7}
\]
The singular endpoints follow from (8.2), or directly from the displayed formula. For a qubit and \(\lambda=1/2\), the value is \(3/8\). The exact rational Gram and inverse-Choi certificates for this case are included in exact_depolarizing_certificate.py.

### 8.5 Prescribed input marginals and correlation-only encoding

Let a prescribed input state \(\omega_A\) be faithful. The value in (3.2) is unchanged even when the pairs defining the complete coefficient must satisfy **both**
\[
\rho_R=\sigma_R,\qquad \rho_A=\sigma_A=\omega_A. \tag{8.8}
\]
This includes the input-dependent complete coefficient of [3, Definition 12], which fixes only the second input marginal.

To prove the stronger claim, take any of the near-extremising pairs from Section 7. They already have equal input marginals, say \(\nu_A\). Choose \(0<\varepsilon<1\) small enough that
\[
\tau_A=\frac{\omega_A-\varepsilon\nu_A}{1-\varepsilon}\succeq0.
\]
Add one orthogonal reference flag and define
\[
\widetilde\rho=\varepsilon\rho\oplus(1-\varepsilon)\tau_A,
\qquad
\widetilde\sigma=\varepsilon\sigma\oplus(1-\varepsilon)\tau_A.
\]
Their reference marginals agree, and both input marginals are exactly \(\omega_A\). Relative entropy before and after the channel is multiplied by \(\varepsilon\), so the ratio is unchanged. Thus reference dimension at most \(m^2+2\) suffices for a prescribed faithful marginal. The same flagged construction works for the binary CMI witnesses, keeping \(I(U;A)=I(U;R)=0\).

For a nonfaithful prescribed \(\omega_A\), restrict the channel input to \(S=\operatorname{supp}\omega_A\). Finite relative entropy forces both compared states to lie in \(R\otimes S\). Applying the faithful argument on \(S\) proves that the input-dependent complete coefficient depends on \(\omega_A\) **only through its support**, and equals (3.2) for the restricted channel. A one-dimensional support gives coefficient zero.

The requirement that a pair have a prescribed marginal must not be confused with fixing its second state to the product \(\rho_R\otimes\omega_A\). The latter is a different contraction problem, and no equality with (3.2) is claimed for it.

## 9. Verification record and limits

The main proof has been checked internally for Choi normalization, adjoint/vectorization conventions, complex rather than merely Hermitian centers, positivity of the final center, complete amplification, trace-zero block columns, singular output support, and the order of limiting operations.

Three exact finite certificates were actually executed:

- exact_triangle_certificate.py uses rational interval arithmetic for square roots and logarithms, certifying a finite qubit-reference ternary ratio in (0.927420641599022566, 0.927420641599022567), above the classical bound 1/2.
- exact_fixed_reference_certificate.py checks a rational same-reference cq construction with a three-dimensional reference, certifying a ratio between 0.918490786084546654 and 0.918490786084547090 and the exact identities I(U;R)=I(U;X)=0.
- exact_depolarizing_certificate.py uses exact SymPy rationals. It checks a Gram defect with eigenvalues 0 (twice), 3/32 (four times), and 15/128 (twice), input/output rectangular forms 3/8 and 9/64, and a Choi value M=8/5. The ratio is exactly 3/8.

Floating-point searches and replay scripts are separately labeled. In particular, the random nonunital-channel SLSQP runs did NOT report successful convergence at the requested tolerance. Their approximate centers and Gram spectra are diagnostics only, not optimum certificates. No SDP solver or proof assistant was run. The general theorem is an analytical claim, not a consequence of those finite checks.

Historical novelty remains unconfirmed. The sources establish the prior coefficient framework and comparison mechanisms; they do not certify that no earlier theorem is equivalent to (3.2). Some attempted full-text fetches of [1] failed, and no claim here relies on a secondary machine review's interpretation of a numbered open problem. The proper next scientific step is independent scrutiny of Sections 4--7 and a targeted priority check of the exact coefficient formula.

## 10. Sources and pinned research capital

[1] Christoph Hirche, Ian George, Theshani Nuradha, Mark M. Wilde. *Conditional contraction coefficients and their applications to quantum networks*. arXiv:2608.27171v1, 27 August 2026. Prior definitions and conditional-relative-entropy/CMI correspondence. The primary abstract was rechecked; full-text retrieval was not consistently available later in the run.

[2] Chengkai Zhu and Xin Wang. *Quantum Incapacity beyond No-Cloning and PPT Mechanisms*. arXiv:2607.24693v1, 27 July 2026. Sections 3.2--3.3, especially the signed-lift and left/right quadratic-to-BKM arguments, were read from the primary HTML. This manuscript's claimed zero-capacity theorem is not needed for the result above.

[3] Ian George, Christoph Hirche, Theshani Nuradha, Mark M. Wilde. *Quantum Doeblin Coefficients: Interpretations and Applications*. Quantum 10, 2115 (22 May 2026); arXiv:2503.22823v3. Prior Doeblin bounds, support/minorization context, and SDP-based comparison methods. Relevant primary HTML sections were inspected, not the entire manuscript.

[4] Astra Research Knowledge, accessed revision `031ce532f7f6d1c070387f6213a00204893be79d` (9 October 2026). Navigation began at `00_START_HERE.txt`, followed by the active frontier. Source verification status was preserved; no Astra theorem is a premise of the main proof.

[5] OpenAI/math, accessed revision `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb` (8 October 2026). README/catalogue and selected original TeX constructions were read, including Sidorenko, complete Crouzeix, and zero-secret-key/PPT-composition manuscripts. Claims were treated as manuscript claims rather than wholesale formal verification. None is a premise of the main proof.

Exact URLs, retrieval scope, failed accesses, and file hashes are recorded in source_manifest.json and PACKAGE_MANIFEST.json. Source versions have been pinned where available; the package is not a complete archive of the external repositories or papers.
