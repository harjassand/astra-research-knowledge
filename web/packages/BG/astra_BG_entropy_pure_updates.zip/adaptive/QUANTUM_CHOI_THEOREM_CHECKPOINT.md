# Candidate universal Choi-radius theorem for conditional information contraction

2026-10-09. Derived after the exact classical harmonic theorem. Complete proposed proof below; independent/formal validation and historical priority are NOT established. This file supersedes the claim that the general quantum extension is only numerical.

## Statement

Let N:L(A)->L(B) be a finite-dimensional CPTP map, with unnormalized Choi matrix J_N=sum_ij |i><j| tensor N(|i><j|), so Tr_B J_N=I_A. Let eta_CMI(N) be the supremum of I(U;B|R)/I(U;A|R), with arbitrary finite quantum U,R and positive denominator. Let eta_Delta_D be the analogous ratio of D(Nrho||Nsigma)-D(rho_R||sigma_R) to D(rho||sigma)-D(rho_R||sigma_R).

Define the SDP value M(N) by minimizing t over sigma>=0, Tr sigma=1, and Hermitian Z, subject to

    [[J_N, I_A tensor sigma], [I_A tensor sigma, Z]] >= 0,
    Tr_B Z <= t I_A.

If infeasible, M=+infinity. Claim:

    eta_CMI(N) = eta_Delta_D(N) = 1 - 1/M(N).

Equivalently, minimize ||Tr_B[(I tensor sigma) J_N^+ (I tensor sigma)]||_infinity over density matrices sigma satisfying ran(I tensor sigma) subset ran J_N. M>=1 whenever finite. A binary classical U and a reference of dimension at most (dim B)^2+1 suffice to approach the supremum.

## 1. Centered matrix Gram problem

Let Phi=N^*, and take a basis F_1,...,F_n of L(B), n=(dim B)^2. Define a block column A with entries Phi(F_i), and block matrix G_ij=Phi(F_i F_j^*). G>=0 by complete positivity. Define eta_G as the least eta such that some complex vector a=(a_i) satisfies

    (A-a tensor I_A)(A-a tensor I_A)^* <= eta G.

eta=1,a=0 is feasible by the complete Schwarz inequality. Any other finite tuple of output operators is a linear compression of this basis, so one feasible a defines a common linear center for every tuple.

## 2. Rectangular RLD coefficient and exact minimax

For any positive definite C on R0 tensor A and any nonzero rectangular B:A->R0 tensor A with Tr_A B=0, define

    q_C(B)=Tr B^* C^-1 B,
    R(C,B)=q_{N_R0(C)}(N_R0(B))/q_C(B).

The channel acts blockwise on rectangular matrices. Ignore unused output support. Let eta_RLD be the supremum of these ratios, allowing any R0.

For a block column F=(F_i), the dual squared norm of the functional B -> Tr B^* Phi(F) on the subspace Tr_A B=0 is

    inf_a Tr C (Phi(F)-a tensor I)(Phi(F)-a tensor I)^*.

This is elementary weighted Hilbert-space projection: the annihilator of Tr_A B=0 is exactly the columns a tensor I. Thus a Gram inequality with constant eta bounds the rectangular RLD ratios by eta.

For the reverse direction fix eta<eta_G and the basis tuple. Put

    f(C,a)=Tr C[(A-a tensor I)(A-a tensor I)^*-eta G], Tr C=1,C>=0.

Sion minimax (compact density matrices C, convex complex a viewed as real vectors) gives

    sup_C inf_a f(C,a) = inf_a lambda_max[(A-a tensor I)(A-a tensor I)^*-eta G] > 0.

The last infimum is attained because the displayed largest eigenvalue is coercive in a. Strict positivity follows from eta<eta_G. Hence some C gives positive infimum. It can be made faithful by mixing with the identity: inf_a f is concave in C and bounded below. For this C, the weighted-projection duality produces a B with Tr_A B=0 for which the output RLD ratio exceeds eta. The output norm uses the chosen F as a test, so equality of that test with the whole output norm is unnecessary. Therefore

    eta_RLD=eta_G,

and R0 of dimension n is sufficient for the supremum.

## 3. Gram coefficient equals the inverse-Choi radius

Take a minimal Stinespring isometry V:A->B tensor E. Let T_i=(F_i^* tensor I_E)V, so G_ij=T_i^*T_j. The Gram inequality is equivalent, by the elementary Douglas factorization, to a contraction K:B tensor E->A with ||K||^2<=eta and

    K(Y tensor I_E)V=Phi(Y)-alpha(Y) I_A

for a complex linear functional alpha. Set L=V^*-K. Then L(Y tensor I)V=alpha(Y)I. Conversely every such L gives a feasible coefficient ||V^*-L||^2.

If t=alpha(I)=LV is zero, this squared norm is >=1. For t!=0 write L=t S, SV=I, and S=V^*+S_perp with S_perp V=0. Then

    ||V^*-t S||^2=|1-t|^2+|t|^2 ||S_perp||^2.

Optimizing t gives r/(1+r), where r is the least ||S_perp||^2 among normalized solutions. Since SS^*=I+S_perp S_perp^*, 1+r is the least ||S||^2.

Write V=sum_j K_j tensor |j> and S=sum_j L_j^* tensor <j|. A normalized solution is characterized by a matrix H with Tr H=1 such that

    sum_j |L_j>><<K_j| = I_A tensor H.

The K_j are a minimal Kraus list. Let M_K have columns |K_j>> and M_L columns |L_j>>. Since J=M_K M_K^*, the solution is

    M_L=(I tensor H) J^+ M_K,

and it exists exactly when ran(I tensor H^*) subset ran J. Moreover

    ||S||^2 = ||Tr_B[(I tensor H) J^+ (I tensor H^*)]||_infinity.

The possible transpose on A from vectorization does not change the norm. Partial-trace cyclicity makes the last expression depend only on H^*H. Replacing H by |H|/Tr|H| preserves the support condition and weakly decreases the value, since Tr|H|>=|Tr H|=1. Therefore H may be taken to be a density matrix sigma. This proves

    eta_G=1-1/M(N).

If there is no normalized solution, the Gram optimum is exactly 1. The block SDP is equivalent to the inverse formula by the generalized Schur complement, including the support condition.

## 4. Upper bound for conditional relative entropy

Choose an optimal normalized positive center sigma, Stinespring solution S, and r=||S-V^*||^2=M-1. Put K=S-V^*, KV=0. For every output observable Y,

    Phi(Y)-Tr(sigma Y) I = -K (I-VV^*) (Y tensor I)V.

Consequently, at every reference amplification,

    (Phi(Y)-alpha(Y)I)^*(Phi(Y)-alpha(Y)I)
        <= r[Phi(Y^*Y)-Phi(Y)^*Phi(Y)].

The adjoint equation gives the opposite multiplication order too; sigma is positive/Hermitian so the center is adjoint-preserving. Let eta=r/(1+r) and let E_eta reveal the quantum input with probability eta and output an orthogonal erasure flag otherwise. Define the signed observable lift

    (Jlift Y)_reveal=[Phi(Y)-(1-eta)alpha(Y)I]/eta,
    (Jlift Y)_erase=alpha(Y).

Then E_eta^* Jlift=Phi. Its weighted left/right square defects are nonnegative by the preceding variance inequality. The logarithmic-mean transformer inequality implies BKM-Hessian domination; variational inversion and affine-segment integration give

    D(N_R rho||N_R sigma') <= D(E_eta,R rho||E_eta,R sigma')
       = eta D(rho||sigma')+(1-eta)D(rho_R||sigma'_R).

This bounds eta_Delta_D and eta_CMI by eta_G. Endpoint eta=0 is a replacer; eta=1 uses DPI. Common faithful regularization extends finite-relative-entropy inputs to singular states.

## 5. Lower bound: convert rectangular RLD into conditional relative entropy

Fix faithful C on R0 tensor A, Tr C=1, and rectangular B with Tr_A B=0, normalized so D=B^*C^-1B has trace one. Let tau_A be faithful, p in (0,1), q=1-p, s in (0,1), and enlarge R by one orthogonal direction r. Define

    rho(p,s)=q [[(1-s)C, sqrt(s(1-s))B],
                [sqrt(s(1-s))B^*, sD]] + p |r><r| tensor tau_A.

The first block matrix is positive because D is its exact Schur complement completion. Its trace is one. The reference marginal is

    rho_R(p,s)=q(1-s) C_R0 + (p+qs)|r><r|.

For binary uniform U, use rho(p+h,s) and rho(p-h,s). CMI is the central second difference of F(p,s)=-H(A|R), respectively -H(B_out|R). At s=0 all p-information is in the orthogonal reference sectors, so these second p derivatives vanish.

For fixed p>0, entropy has an expansion in s: conjugating the r block changes sqrt(s) to -sqrt(s), so the expansion is even and analytic on the fixed support. Let A0,B0,D0 be the common, off-diagonal and rare-s blocks before or after the channel. The coefficient of log p in the first-s entropy term tends, as p->0, to

    h=Tr D0-Tr B0^* A0^-1 B0.

This follows by diagonalizing A0 and tau_out and using the divided difference (log(q lambda)-log(p nu))/(q lambda-p nu). Explicitly, the coefficient is

    kappa(p)=q Tr D0 - sum_{j,a} q^2 |(B0)_{ja}|^2/(q lambda_j-p nu_a),
    kappa(0)=h.

All other terms are analytic near p=0 apart from kappa(p)log p. Hence the second p derivative of the first-s entropy coefficient is -h/p^2+O(1/p+|log p|). The reference contributes +1/[p^2(1-p)] to the negative entropy difference; its extra spectral constants have zero second p derivative.

For the input h=0. For the output, h=1-R(C,B). Thus, first taking h->0 (the binary perturbation), then s->0 at fixed p, then p->0, the CMI ratio approaches R(C,B). No limits are interchanged. Input CMI is strictly positive for sufficiently small parameters. Taking the supremum proves eta_CMI>=eta_RLD=eta_G. Together with the upper bound, this completes the proposed theorem.

## Matrix harmonic dual and tensor products

Let B0=ker Tr_A P_{ker J}; it is precisely the largest output subspace with A tensor B0 subset supp J. If B0=0, eta=1. Otherwise compress J^+ to K on A tensor B0. Convex minimax gives

    beta(N):=1/M(N)=min_{tau_A density} Tr[(Tr_A[(tau_A tensor I)K])^-1].

For a fixed tau, the minimizing output density is the normalized inverse of H_tau=Tr_A[(tau tensor I)K]; this is weighted Hilbert-Schmidt Cauchy-Schwarz. Product primal centers give M(N1 tensor N2)<=M(N1)M(N2). Product dual tau gives the reverse inequality for M, since H and its inverse tensorize. The common output subspace of the product is B01 tensor B02 (verify via partial trace of I-P1 tensor P2). Therefore

    beta(N1 tensor N2)=beta(N1)beta(N2),
    eta(N1 tensor N2)=1-(1-eta(N1))(1-eta(N2)).

When one beta vanishes, the tensor-product eta is one by fixing the other input, so no singular dual is needed.

## Depolarizing channel exact formula

For D_lambda(rho)=lambda rho+(1-lambda)Tr(rho)I_d/d, CP range -1/(d^2-1)<=lambda<=1, covariance makes sigma=I_d/d optimal. The Choi eigenvalues are [1+(d^2-1)lambda]/d (once) and (1-lambda)/d (d^2-1 times). Thus

    eta_CMI(D_lambda)=(d^2-1)lambda^2/[1+(d^2-2)lambda].

For d=2, lambda=1/2 this is 3/8. The endpoints follow by the support criterion or the displayed formula. At lambda=-1/(d^2-1), eta=1 although the channel is entanglement-breaking.

## Numerical adversarial check actually run

quantum_choi_formula_probe.py constructs the 8-by-8 Gram problem for qubit depolarizing lambda=.5. Its exact predicted eta is .375. Floating-point defect eigenvalues had two zero eigenvalues and six positive eigenvalues (four .09375, two .1171875). The kernel projector gives a rectangular B with partial trace norm 2e-16 and RLD ratio .37499999999999983. The entropy construction produced conditional BKM ratios .37310248, .37479314, .37497891 at (p,s)=(1e-2,1e-5),(1e-3,1e-7),(1e-4,1e-9). This is corroboration, not proof or independent verification.
