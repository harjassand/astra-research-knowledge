# Adaptive foundational research — 9 October 2026

## Start here

**RESULTS.md** contains the strongest theorem and complete current proof: an exact Choi-matrix SDP for complete fixed-reference relative-entropy contraction, conditional relative-entropy contraction, and conditional-mutual-information contraction of every finite quantum channel.

**Scientific status:** internally checked analytical theorem candidate. No independent review, formal verification, or historical-priority certification. This package is not a verified 10/10 breakthrough claim.

The extremising bit can be independent of each local subsystem separately. Section 8.5 also treats prescribed input marginals; it does not concern contraction toward a fixed product reference state.

CLASSICAL_EXAMPLES.md contains self-contained classical comparison proofs and explicit finite witnesses. RESEARCH_LOG.md records the explored routes and exact failure scopes. source_manifest.json pins sources and states retrieval limits; PACKAGE_MANIFEST.json records local file hashes.

## Replay the exact finite checks

From this directory, run:

```sh
python exact_triangle_certificate.py
python exact_depolarizing_certificate.py
python exact_fixed_reference_certificate.py
```

The first uses only the Python standard library. The latter two also require SymPy. The JSON files record the outputs from checks actually executed in this run. Their exact arithmetic verifies these finite examples, not the universal theorem or its novelty.

Numerical diagnostics require NumPy, SciPy, and in some cases mpmath. requirements-replay.txt records the installed versions used. The random-channel optimization trials are explicitly unsuccessful at the requested solver tolerance and are not exact certificates.

## Earlier checkpoints

CHECKPOINT.md, HARMONIC_THEOREM_CHECKPOINT.md, QUANTUM_CHOI_THEOREM_CHECKPOINT.md, and FIXED_REFERENCE_STRENGTHENING.md preserve earlier derivations. Some status statements and proof routes in those files are superseded by RESULTS.md. In particular, its simple fixed-reference coherent-flag proof replaces the longer varying-marginal lower-bound construction. Do not combine older statements indiscriminately with the final theorem.

The package contains local mathematical notes and computation, not full copies of the external repositories or papers. No canonical repository, user library, or public research archive was changed.
