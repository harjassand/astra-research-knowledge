# Fixed-reference strengthening and simpler sharpness proof

2026-10-09. This supersedes the two-parameter conditional-entropy expansion in Section 5 of QUANTUM_CHOI_THEOREM_CHECKPOINT.md. The new lower construction proves a stronger statement with a shorter argument. It has been analytically derived and numerically probed, not externally reviewed or formally verified.

## Stronger theorem

In addition to the conditional coefficients, define the complete fixed-reference coefficient

    eta_D^c(N) = sup_{finite R, rho_R=sigma_R, 0<D(rho||sigma)<infinity}
                    D(N_R rho||N_R sigma)/D(rho||sigma).

The proposed theorem strengthens to

    eta_D^c(N) = eta_D^Delta(N) = eta_CMI(N) = 1 - 1/M(N),

with the same Choi SDP and its exact tensor-product formula. A binary classical U independent of R suffices to approach eta_CMI, with dim R <= (dim B)^2+1. For eta_D^c the pair can have the same R marginal EXACTLY, not approximately.

## Simple coherent-flag lemma

Fix C>0 on R0 tensor A, Tr C=1, a nonzero block column B:A->R0 tensor A with Tr_A B=0, and a faithful density tau on A. For 0<p<1 put q=1-p and

    omega_p = [[q C, 0], [0, p tau]],
    H_p     = [[0, sqrt(pq) B], [sqrt(pq) B^*, 0]],

on (R0 direct-sum C r) tensor A. For |t| sufficiently small,

    rho_{p,t} = omega_p + t H_p

is a state. Indeed its Schur complement is p(tau-t^2 B^* C^-1 B), so t can be chosen independently of p. Both the trace and the reference marginal are independent of t; specifically Tr_A H_p=0.

For fixed p, standard second differentiation of Tr X log X gives

    D(rho_{p,t} || omega_p) = (t^2/2) g_{omega_p}(H_p)+O_p(t^3).

If C has eigenvalues lambda_j>0, tau has eigenvalues nu_a>0, and B has components B_ja in these eigenbases, then

    g_{omega_p}(H_p)
      = 2pq sum_ja |B_ja|^2
          [log(q lambda_j)-log(p nu_a)]/[q lambda_j-p nu_a].

As p->0, with C,B,tau fixed,

    g_{omega_p}(H_p) / [2p log(1/p)] -> Tr B^* C^-1 B.

Apply the same calculation after N. C'=(id_R0 tensor N)(C) and tau'=N(tau) are faithful on the fixed support of N(I); B'=N(B) is supported there. Therefore

    lim_{p->0} lim_{t->0}
       D(N rho_{p,t} || N omega_p)/D(rho_{p,t} || omega_p)
      = Tr B'^* C'^-1 B' / Tr B^* C^-1 B.

The marginal equality holds for every p,t. Thus eta_D^c is at least every rectangular RLD ratio. The upper bound previously proved for eta_D^Delta applies to fixed-reference pairs, proving equality of all three coefficients with the Gram and Choi values.

Alternatively take binary uniform U selecting rho_{p,t} and rho_{p,-t}. Their average is exactly omega_p and their reference marginals are identical. Hence I(U;R)=0 EXACTLY. Its input/output mutual information has the same limiting BKM ratio, giving sharpness for CMI even with binary classical U independent of R.

## Audited details

- No limit interchange: take t->0 for each fixed p, then p->0, then take the RLD supremum.
- Positivity is an explicit Schur-complement inequality.
- C and tau are normalized; H has zero trace.
- Tr_A B=0 is crucial for the exactly fixed reference. This is the same subspace used in the Gram minimax proof.
- Output faithfulness is only needed on supp N(I), to which all outputs can be restricted once and for all.
- B may be complex and rectangular; channel action and partial trace are blockwise.
- The logarithmic divergence is common to input and output; finite dimension makes the limit termwise.
- This is not the unreferenced relative-entropy contraction coefficient and does not make an assertion about contraction toward a prescribed stationary state.

## Numerical check

fixed_reference_coherence_probe.py tests the qubit depolarizing lambda=1/2 instance. Fixed-reference BKM ratios at p=1e-2,1e-5,1e-10,1e-20,1e-40,1e-80 are approximately .3436641, .3617950, .3683966, .3716983, .3733491, .3741746, tending to the predicted 3/8. These are diagnostics, not certification.

## Historical status

The definitions are drawn from the established literature. A recent primary abstract, Hirche--George--Nuradha--Wilde arXiv:2608.27171, distinguishes fixed-reference complete coefficients from the newly introduced conditional ones and proves equality of the conditional relative-entropy and CMI coefficients. Its detailed full text was accessed earlier in this run, but repeated subsequent retrieval attempts failed. Do not claim the exact wording of a numbered open problem or a verified priority claim from a secondary machine review. The equality above and the finite Choi formula need independent mathematical and priority review before any historic-scale claim.
