# Adaptive mathematical discovery — exact working checkpoint

Date: 2026-10-09. This is a local research artifact, not publication or external validation.

## Revisions actually accessed

- Astra: `031ce532f7f6d1c070387f6213a00204893be79d`.
- OpenAI/math: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

No canonical repository was modified. No subagent or formal proof checker was used.

## Current theorem candidates and status

1. **Classical universal inertness.** If a source P(X,Y,Z) has a virtual Eve channel J from T=(X,Y) which is less informative than Z in the all-prior less-noisy order and X is conditionally independent of Y given J, then adjoining any number of independent P copies cannot increase the asymptotic secret-key rate of any independent classical source Q. Proof: tensorize the channel comparison, condition on the public transcript, and publicly simulate the Markov source. This is proved here; historical novelty not certified.
2. **Complete conditional BSC contraction.** For a classical bit L, arbitrary finite quantum systems U,R, and J=BSC_delta(L), I(U;J|R) <= (1-2 delta)^2 I(U;L|R). Sharp. An explicit signed observable reconstruction gives the full matrix proof below. Not machine formalized.
3. **Binary-input channel extension.** Every finite binary-input classical channel with strictly positive transition probabilities has the same optimal conditional relative-entropy/conditional mutual-information contraction coefficient in the presence of arbitrary quantum references as its ordinary classical KL coefficient. Proof via a reverse-chi-square center and signed observable reconstruction. Boundary extensions are being checked.
4. **Quantum-helper inertness.** Items 1 and 2 imply that the erasure/flip bound-information family of Pauwels–Gisin–Renner (arXiv:2607.25838v2) cannot enhance secret-key distillation from *any independent tripartite quantum source*. The Eve system of P remains its specified classical Z, not a purification of the honest-party marginal. This does not construct entangled bound-key states, settle unrestricted activation, or decide Masanes–Winter's one-shot secret-bit-fraction question.

## Exact matrix argument for item 2

Write c=1-2 delta and take eta >= c^2, eta>0. Let N be binary erasure with reveal probability eta and M=BSC_delta. Both act only on a classical input register. For output observables Y_0,Y_1 (arbitrary matrices on an untouched reference), put Y=(Y_0+Y_1)/2, V=(Y_0-Y_1)/2 and

J(Y_0,Y_1)=(Y+(c/eta)V, Y-(c/eta)V, Y).

J is a linear, adjoint-preserving reconstruction on observables, not generally positive. N^* J=M^*. For positive input blocks A,B, put S=A+B. Direct expansion gives the exact weighted-square identity

sum_j Tr[(M(A,B))_j Y_j^*Y_j] - sum_z Tr[(N(A,B))_z (JY)_z^*(JY)_z]
= (1-c^2/eta) Tr[S V^*V] >= 0.

The identity applied to adjoints gives the opposite multiplication order too. Thus, on Hilbert–Schmidt spaces,
J^* L_{N omega} J <= L_{M omega}, and J^* R_{N omega} J <= R_{M omega}.

For positive definite sigma define
Gamma_sigma(X)= integral_0^1 sigma^s X sigma^(1-s) ds.
It is the logarithmic operator mean of L_sigma and R_sigma. The transformer inequality and monotonicity of operator geometric means, followed by integration over s, give
J^* Gamma_{N omega} J <= Gamma_{M omega}.

The variational identity <X,Gamma^-1 X> = sup_Y [2 Re<X,Y>-<Y,Gamma Y>] and M X=J^* N X imply
<MX,Gamma_{M omega}^-1 MX> <= <NX,Gamma_{N omega}^-1 NX>.

Integrating along the affine segment from sigma to rho (the Hessian identity for Tr rho log rho) proves
D(M rho||M sigma) <= D(N rho||N sigma).

The direct-sum erasure formula is
D(N rho||N sigma) = eta D(rho||sigma)+(1-eta)D(rho_R||sigma_R).
Take eta=c^2. Taking rho=rho_ULR and sigma=rho_U tensor rho_LR yields the conditional mutual-information claim after subtracting I(U;R). Faithful regularization handles singular states. The sharpness lower bound uses ordinary binary distributions near the uniform distribution.

## Exact general binary-input argument (strictly positive channel)

Let W have probability rows w_0,w_1. Define
k(q)=q(1-q) sum_y (w_0(y)-w_1(y))^2/[q w_0(y)+(1-q)w_1(y)],
eta=max_{0<=q<=1} k(q).
The usual scalar entropy-Hessian argument establishes that eta is the ordinary KL contraction coefficient.

Let
r=min_{a probability distribution} max_{x=0,1} chi^2(a||w_x),
chi^2(a||w)=sum_y a_y^2/w_y-1.
Convex minimax gives
r=max_lambda [1/Z(lambda)-1],
Z(lambda)=sum_y w_0(y)w_1(y)/[(1-lambda)w_0(y)+lambda w_1(y)].
The elementary identity Z(lambda)=1-k(1-lambda) gives r=eta/(1-eta).

Choose a minimizing center a. Let N reveal x with probability eta and erase otherwise. For output observable matrices F_y, put mu_x=sum_y w_x(y)F_y and alpha=sum_y a_y F_y. Set
(JF)_e=alpha,
(JF)_x=[mu_x-(1-eta)alpha]/eta.
Then N^*J=W^*. At each input x,
E_wx[F^*F]-eta (JF)_x^*(JF)_x-(1-eta)alpha^*alpha
= Var_wx(F)-((1-eta)/eta)(mu_x-alpha)^*(mu_x-alpha) >=0,
by operator Cauchy–Schwarz and chi^2(a||w_x)<=eta/(1-eta).
The same holds in the reverse multiplication order. Applying the preceding logarithmic-mean/BKM argument gives the sharp quantum conditional contraction coefficient eta. Thus arbitrary quantum side information gives no increase for any strictly positive binary-input classical channel.

## Exact protocol implication and conventions

For independent classical source P=(X,Y,Z) and arbitrary quantum helper omega_ABE, suppose the channel T=(X,Y)->Z dominates T->J in *conditional* mutual information for every finite quantum reference, and P(X,Y|J)=P(X|J)P(Y|J). At a fixed finite public transcript F and after arbitrary joint local quantum processing of honest systems, the Eve states retain the fixed channel T->Z or T->J. Hybrid replacement over all P copies therefore gives
I(K_A;J^m E|F) <= I(K_A;Z^m E|F).
Honest key distributions and error are identical. A public sampler generates J, followed by independent local samplers X|J and Y|J, so the J-comparison protocol can be implemented from omega alone.

To avoid confusing vanishing trace distance with vanishing absolute mutual information, use entropy defect Delta=log M-H(K_A|E,F), error e, and repeat a finite protocol iid. Information reconciliation and privacy amplification give a rate at least
log M-Delta-h_2(e)-e log(M-1)
per repetition. This proves the usual asymptotic rate inequality, with conditional-entropy continuity for trace-distance-secure keys; arbitrary finite m(n) auxiliary copies are allowed. The reverse inequality is obtained by discarding P.

## Primary-source inputs (attribution, not new discoveries)

- Pauwels–Gisin–Renner, Bipartite Bound Information Exists, arXiv:2607.25838v2. Their rational example has Z slices (1/36)[[5,2],[2,0]], (1/36)[[0,2],[2,5]], (1/36)[[5,4],[4,5]]. Virtual L given (X,Y) has P(L=1|XY)=[[0,1/2],[1/2,1]]. Z=BEC_(1/2)(L); J=BSC_(1/5)(L); X independent Y given J. They prove positive formation cost and zero distillable key. Their full family has 2 delta<epsilon<=4 delta(1-delta).
- Hirche–George–Nuradha–Wilde, Conditional contraction coefficients and their applications to quantum networks, arXiv:2608.27171v1. Defines conditional relative-entropy contraction and its erasure-comparison characterization. Their BSC discussion located so far concerns hockey-stick divergence, not the sharp relative-entropy formula proved above.
- Zhu–Wang, Quantum Incapacity beyond No-Cloning and PPT Mechanisms, arXiv:2607.24693v1. Signed-lift weighted-defect method motivated the matrix bridge. Their qutrit construction is one-copy two-way distillable and is not a candidate NPT bound-entangled state.
- Ordentlich–Polyanskiy, Strong data processing constant is achieved by binary inputs, arXiv:2010.01987. The ordinary classical constant of a many-input channel equals the best binary-input subchannel constant. This does NOT by itself give a binary reduction with quantum side information.
- Masanes–Winter, A non-distillability criterion for secret correlations, arXiv:0804.4523v2. Earlier nonactivation certificates exist. Equality of asymptotic key capacity does not decide their stronger one-shot secret-bit-fraction question for helpers of positive capacity.

## Research branches not resolved

- Sidorenko-to-bipartite-commonality transfer: a sparse deficit does not control the complementary graphon. No counterexample to two-color commonality obtained.
- Crouzeix-to-multivariable transfer: released single-operator complete theorem already encompasses the obvious target; no foundational amplification obtained.
- Arbitrary-alphabet classical channels with quantum references: binary proof uses a two-row chi-square minimax identity. Whether this gives a universal theorem or fails at three inputs is being tested.
- Unrestricted activation of zero-key sources and quantum entangled bound-key activation remain undecided.

## Numerical evidence

bsc_quantum_probe.py uses floating-point BKM Hessians for qubit references. 12000 random trials gave maximum 0.3599998689985381 against the proven c^2=0.36 threshold. This is not proof, formal verification, or independent review.
