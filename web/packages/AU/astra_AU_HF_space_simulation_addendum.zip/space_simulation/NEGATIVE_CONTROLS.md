# Falsification controls for the space compiler

All examples concern proof boundaries. They do not contradict the positive theorem with its stated invariants.

## 1. Preserving the historical domain really can cost exponential space

Take `n` atoms supplied with a binary linear order. Store the current subset `B` as an `n`-bit counter, with the least atom the least significant bit. Encode the native state by a fixed tagged tuple so that `B=Empty` is not confused with the Boolean halt value.

If `B` is not all atoms, bounded comprehension defines the missing atoms `M=Atoms\B`, and then the singleton set containing its least element `p`. `TheUnique` returns `p`, and a further comprehension defines

`B' = {p} union {a in B : p<a}`.

Both uniqueness and minimum are definable from the binary input order using only bounded comprehension and Boolean tests. For example, absence of a smaller missing atom is the negation of the test that `Empty` belongs to `{Empty : b in M : b<a}`. Initialize the counter at the empty subset; halt after reaching all atoms. One fixed BGS term, with finite tags, implements this program on every ordered input.

There are `2^n` different subset values. Every native state, including its fixed wrapper, has hereditary size `O(n)`. A simulator that retains all old subset objects has at least `2^n` objects. This establishes that a runtime factor is a real defect in the history-preserving simulation argument and cannot simply be dropped from its estimate.

The finite tests visit all subsets without implementing the fixed syntax or wrappers. At `n=10` the historical representation has 1,035 objects and the GC representation has peak 15. These numbers are for the unwrapped representation mechanism, not a claimed optimized compiled program.

## 2. Nontransitive garbage collection breaks stored reachability

Let `z=Empty`, `a={z}` and `b={a}`. In the full membership graph, `C(z,b)` holds. Retain only `{z,b}` and delete `a`. The restricted membership graph has no edge, but the restriction of the old closure still contains `(z,b)`. Thus closure can be restricted without recomputation only when the retained family is transitive (or another explicitly proved path-preserving condition holds).

The simulator retains input constants, the complete ordinal reserve and the complete inclusive current-state closure, so it satisfies the stronger condition.

## 3. Bare extensionality conflates atoms with Empty

An atom and `Empty` both have empty membership rows, but they are different HF objects. A merge relation comparing rows without checking atom/set status is wrong even on the smallest input. The constructor compares a new set with an old object only under `Set(old)`.

## 4. Counting descriptors is not counting objects

Several permitted environments can give the same set value; all raw descriptors then represent one HF object. Cardinalities of descriptor sets can differ arbitrarily from cardinalities of the quotient. A Härtig test before the semantic merge is therefore unsound.

In the main construction, Härtig is evaluated only on the merged, unique-object domain. In the binary compiler, Härtig additionally quantifies only over the distinguished logical-object sort, excluding tuple representatives, incidence vertices and control markers.

## 5. Reserve size is not linearly bounded by native-state size

A fixed term may first form all ordered pairs of input atoms, apply `Card`, and use the result only in a Boolean comparison. For `n` input atoms, the argument contains `n^2` pairs, while the final native state may be just `true`, of inclusive hereditary size two. Hence a reserve up to `n^2` may be needed even though the only native-state hereditary bound apart from the input is constant.

The exact construction has a polynomial bound from fixed syntax; it does not require a linear one. Iterating a polynomial of `(native size + old reserve)` would not prove this: reserve elements must be excluded from the semantic argument pool unless selected by the term's actual value tables.

## 6. Simultaneous binary/two-dimensional initialization is not free

On `n` input objects, one two-dimensional interpretation can produce at most `n^2` output vertices. A fixed binary output vocabulary can encode only `O(n^4)` bits on these vertices. An unrestricted relation of arity `r>=5` has `Theta(n^r)` bits. Up to the harmless `n!` labeled-to-unlabeled factor, this rules out a lossless state-faithful binary encoding of every such input in one two-dimensional initialization.

This is an information obstruction to a universal state encoding, not a separation theorem for every Boolean query. The main theorem assumes unary/binary input, exactly as in the target lower-bound family.

## 7. Tiny universes cannot supply arbitrary fresh tags

For a universe of size zero or one, every fixed positive-dimensional tuple power has size at most one. Quotients cannot increase this size. The generic fresh-tag construction cannot start there. The main theorem is stated for inputs of size at least two and thereafter retains fixed control markers, so logical empty/singleton states during the run are allowed.

For any fixed total BGS decision term there are only finitely many smaller input isomorphism types, and its output on each can be hardcoded after running it to completion. A generic effective translator for partial BGS programs must not silently rely on deciding their halting behavior on those inputs.

## 8. A powerset primitive would change the theorem

If the syntax added a primitive sending the input atom set to its full powerset in one term evaluation, the semantic footprint could have `2^n` objects despite a linear-size argument closure. The polynomial footprint lemma uses precisely the fixed powerset-free bounded-comprehension BGS syntax. A claim about a broader instruction set would require another argument.
