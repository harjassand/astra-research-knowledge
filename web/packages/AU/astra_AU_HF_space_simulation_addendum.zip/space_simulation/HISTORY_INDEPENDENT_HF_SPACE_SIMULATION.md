# History-independent simulation of fixed HF term programs

Research proof record, 2026-10-08. This is a newly reconstructed quantitative simulation, not a claim that the published characterization states this bound. An independent blind reconstruction and end-to-end mathematical audit accept the theorem and its companion binary/two-dimensional compiler within the explicit scope below. The prior space-simulation gate is internally closed for this specified model. The result is not formally certified or externally expert-reviewed, and historical novelty is not established.

## 1. Exact theorem and scope

Fix a finite unary/binary relational input vocabulary and one BGS step term `t(x)` in the Rossman-style syntax specified in GKPS15, Section II: variables, `Atoms`, `Empty`, Boolean tests, `Pair`, `Union`, `TheUnique`, `Card`, and bounded set comprehension. Allow any finite number of iterations. There is one fixed, parameter-free, finite-control interpretation program over FO plus the unary Härtig quantifier that simulates its run on every input `A` with `|A| >= 2`.

For a finite run or prefix `a_0,...,a_h`, ending its simulation at the checkpoint representing `a_h` rather than after an extra evaluation, write `cl(X)` for the smallest family containing the objects in `X` and all their recursive members, and put

`W = |A| + 4 + max_i |cl({a_i})|`.

The simulator has maximum state-universe size at most `C_t W^{d_t}`, for constants depending only on the fixed syntax. This estimate includes every auxiliary simulation phase and is independent of `h`. A further fixed binary-vocabulary, two-dimensional compilation has polynomial maximum-state overhead, so changes only these constants. No input polynomial or runtime bound needs to be supplied to the simulator.

For a set-valued state, `|cl({a_i})| = 1 + |tc(a_i)|` under GKPS's convention for transitive closure. Counting an atom state as one object removes an irrelevant convention at atomic roots. A fixed finite collection of registers can be encoded by a fixed tuple term, changing this measure only by a constant factor/additive constant. For arbitrary fixed higher-arity input vocabulary, the proof gives the fixed-dimensional simulation; simultaneous binary/two-dimensional initialization additionally requires a pre-encoded binary input or a separate initialization allowance. An `n`-element input can produce at most `n^2` vertices in one two-dimensional step, which cannot losslessly carry arbitrary relations of arity greater than four in a fixed binary vocabulary. The intended lower-bound input is already binary. This proof does not automatically cover other machine formalisms with dynamic functions, unrestricted primitive powerset, succinct integer primitives, or choice operations.

The small-input restriction matters: an ordinary parameter-free positive-dimensional tuple interpretation cannot grow a universe of size zero or one. For a fixed total decision program, there are finitely many input structures of those sizes and their answers can be hardcoded as immediate halts. The exponential lower-bound applications use arbitrarily large inputs and need no small-input extension.

## 2. What is imported, and what is repaired

Primary source: [Grädel, Kaiser, Pakusa, Schalthöfer, Characterising Choiceless Polynomial Time with First-Order Interpretations, LICS 2015](https://www.logic.rwth-aachen.de/pub/schalthoefer/GKPS15.pdf), DOI 10.1109/LICS.2015.68.

The model is its Section II. Its Section IV replaces numerical cardinality with equicardinality by prebuilding an input-polynomial ordinal reserve. Its Section VI constructs relational representations of HF values and simulated term tables, preserving the prior representation domain; its final size estimate uses the polynomial runtime. Its Section VII states the fixed-dimension reduction to dimension two.

The additional quantitative arguments below are our own:

1. A term-footprint bound in terms of the current arguments, independent of previously retained reserve objects.
2. A direct dynamically extended ordinal reserve, requiring neither an input polynomial nor elapsed-time storage.
3. An exact transitive representation invariant, with atom-safe extensional merging.
4. Garbage collection after every completed native step.
5. A resettable fixed-dimensional-to-binary-two-dimensional compiler with bounds on all intermediate states.

We do not rely on the strongest reading of GKPS Definition 9 for arbitrary nontransitive represented domains. All domains used here satisfy the stronger invariant below. We also do not use bare extensionality to identify atoms with empty sets.

## 3. Polynomial semantic footprint of one fixed term

### Lemma

For each fixed term `s(v_1,...,v_k)`, there is a nondecreasing polynomial `q_s` such that the following holds. Start with input atoms, `Atoms`, `Empty`, `true={Empty}`, and the inclusive hereditary closures of its arguments, in a family of total size at most `m >= 2`. The union of the hereditary closures of all values needed to evaluate `s`, including every instance of a subterm under a comprehension assignment, contains at most `q_s(m)` objects. Both the comprehension value and guard may be evaluated eagerly, even for assignments whose guard is false.

### Proof

Induct on the fixed syntax. A variable or constant introduces no non-base objects. Boolean operations add at most the already present `Empty` and `true`; combine the operand bounds by addition. `Pair` and `Union` add at most one new set once their operands and their hereditary members are present. `TheUnique` selects an existing member when its argument is a singleton, and otherwise returns `Empty`.

For `Card(r)`, the argument value has at most `q_r(m)` distinct members. Its von Neumann cardinal and all predecessors therefore require at most `q_r(m)+1` pure objects. The atom case returns `Empty` and obeys the same bound.

For `{s(v,y): y in r(v): phi(v,y)}`, first evaluate `r`; put `R=q_r(m)`. There are at most `R` possible values of `y`, and the hereditary closure of each is contained in that of the range. The augmented argument family has size at most `m+R`. Evaluating both `s` and `phi` for every such `y` therefore introduces at most

`R [q_s(m+R) + q_phi(m+R)]`

objects, in addition to the range footprint, the original family and the resulting comprehension set. Their sum, plus one, is again a polynomial in `m`. All recurrences have fixed finite depth. This proves the claim.

The same induction bounds the number of evaluation instances by a polynomial if needed. Alternatively, at any fixed syntactic occurrence there are only a fixed number of bound variables, so its table has at most a fixed power of the footprint size.

### Crucial independence

The argument family here contains the native current state and input constants. It does not contain the simulator's entire ordinal reserve. Values in that reserve never become comprehension parameters merely because they are present in the representation. Thus the bound for each native step is `q_t(W)`, rather than a recurrence of the form `R_{i+1} <= q_t(W+R_i)`.

## 4. Exact relational representation

At each semantic checkpoint the simulator has a finite domain `U` bijective with a transitive family of actual objects in `HF(A)`. The family contains all input atoms, the set `A`, `Empty`, `true`, the native current state and its recursive members, and a reserve of ordinals.

Stored relations include:

- a unary predicate for input atoms and the input relations, false on nonatoms;
- unary constant markers for `Atoms`, `Empty`, `true`;
- exact membership `E(x,y)` and its reflexive-transitive closure `C(x,y)`;
- singleton current-state marker `Cur`;
- unary `Ord`, marking precisely `[0],...,[R]`, and singleton `Top`, marking `[R]`;
- fixed-arity argument/value tables for the finitely many syntactic subterm occurrences;
- finite control predicates.

Each actual HF object has exactly one domain element. No order or choice on the atoms is introduced. `Set(x)` is the complement of the input-atom predicate because the only urelements are the original input atoms.

All semantic tests, including Härtig tests, are made only at checkpoints with unique object representatives. Representational duplicates inside a tuple construction are never counted as distinct HF objects.

### Initialization without choosing atoms

For `n>=2`, a fixed three-dimensional interpretation creates `n+3` objects. Tuples `(a,a,a)` represent the original atom `a`; the equality-pattern classes `x=y != z`, `x=z != y`, and `y=z != x` each represent one of `Empty`, `true`, and `Atoms`, respectively. Quotient each of these latter pattern classes to one object. All classes exist for `n>=2`. Define their membership directly: each atom belongs to `Atoms`, and `Empty` belongs to `true`. Initialize the exact closure and the reserve `[0],[1]`, with top `[1]`.

The initial native state is `Empty`, but this does not cause immediate halting: a finite first-step control flag suppresses the halt test until the first native step is evaluated. Halt/out are then read according to the native convention.

## 5. A uniform fresh-set constructor

Suppose `U` is a semantic checkpoint. Let `V(v)` be a fixed-arity relation of parameter tuples from `U`, and let `theta(v,u)` be a fixed FO+H formula over `U`. We can, with a fixed-dimensional interpretation, adjoin all actual sets

`b_v = {u in U : theta(v,u)}` for `v in V`,

merge every duplicate with other new or old sets, and preserve the exact representation invariant. The result has at most `|U|+|V|` elements.

Here is a full semantic specification of interpretation formulas. Use descriptors `old(u)` and `new(v)`. For a k-coordinate environment choose fixed length `L>=max(3,k+2)`. Equal final coordinates signal an old descriptor whose object is the first coordinate; unequal final coordinates signal a new descriptor whose environment is the first k coordinates. Other padding coordinates are ignored by equality. For zero-arity environments ignore the payload. At least two elements are available, so both tag patterns have representatives without choosing any atom.

Define descriptor equivalence by:

- `old(u) ~ old(w)` exactly when `u=w`;
- `new(v) ~ new(w)` exactly when `forall z (theta(v,z) iff theta(w,z))`;
- `new(v) ~ old(u)` exactly when `Set(u)` and `forall z (theta(v,z) iff E(z,u))`.

Because `U` is transitive, old-set membership rows are complete. The relation above is exactly equality of the denoted HF objects; in particular it is an actual equivalence relation. The `Set(u)` clause is essential.

Raw membership is inherited on old descriptors, and relates `old(z)` to `new(v)` precisely when `theta(v,z)`. Saturate this relation under descriptor equivalence on both coordinates. Likewise lift each retained old relation and each new table, saturating all coordinates under equivalence. These formulas are FO-definable because descriptor lengths are fixed. They give congruence-respecting quotient relations even when a new set coincides with an old one. No representative is chosen.

For closure, start with raw old closure, equality of descriptors, and the rule

`old(x) C new(v)` iff `exists z (C_old(x,z) and theta(v,z))`.

Again saturate under descriptor equivalence. This is the exact reflexive-transitive closure of the new membership. Every newly adjoined set has only old elements; any downward nontrivial path from it enters the old transitive family on its first edge. A new descriptor may coincide with an old object, but saturation accounts for that case. No general reachability computation is being smuggled into FO.

The source model used by the exponential-state theorem additionally permits generated equality and existential representative relation semantics. Our construction already uses a genuine equivalence and saturated relations, so it lies within that model as a special case.

## 6. Fixed-control term evaluator

Give every syntactic occurrence of a subterm its own fixed-arity permitted-environment relation and value table. The outer permitted environment is only the current state. For ordinary operands, pass the same environment or its relevant projection. For a comprehension, evaluate its range first, then extend each permitted environment by exactly the members of its actual range value. Evaluate the guard and body on these permitted environments and adjoin the resulting set using the fresh-set constructor. Duplicate environment tuples are harmless because term evaluation is functional.

Variables, constants, Boolean tests and `TheUnique` need only FO table updates. `Pair`, `Union`, and comprehension are instances of the fresh-set constructor. For example, the body of a union constructor is `exists z (E(u,z) and E(z,arg))`. The body of a comprehension constructor uses the already computed body/guard value tables and the range membership relation. Equality tests use actual domain identity. Input tests are restricted to the preserved input relations.

A depth-first traversal of the fixed syntax is a finite list of control phases. Although range evaluation precedes the body/guard, the depth is fixed and can be compiled into finite control rather than an unbounded stack. Subterm tables are retained for the duration of the step and cleared when the next native state is installed. The only unbounded phase loop in this core is the ordinal-reserve extension described next. To combine the finitely many local instructions into one step interpretation, pad their fixed dimensions to a common dimension by repeating a tuple coordinate, guard each local formula by its finite phase condition, and take the finite disjunction. The semantic domains are nonempty, so this introduces no exceptional padding case. The final binary/2D compiler separately implements the same finite-control combination.

All environment elements and term values belong to the semantic footprint in Section 3. In particular, unrelated reserve elements cannot enter an evaluation table.

## 7. Dynamic Card without elapsed-time storage

At a `Card(s)` phase, all argument values have already been computed and their tables are frozen. For each permitted environment, search only `Ord` for a value `o` satisfying

`H_xy (E(x,arg), E(y,o))`.

This is a legal unary Härtig comparison. Both sets are actual sets of unique domain objects. Transitivity of `U` ensures that all members of the argument and the ordinal are present. For an atom argument the first set is empty, correctly giving `[0]`.

If every permitted environment has a matching ordinal, store these unique matches as the `Card` value table and advance. The matches are unique because `Ord` contains consecutive actual finite ordinals, which have distinct cardinalities.

Otherwise adjoin one new set with member predicate `Ord(u)`. Its value is `[R+1]`. Mark it as the new top and extend `Ord` by it, then repeat the same phase. Extensional merging permits reuse if this actual ordinal was already represented for another reason. The construction never chooses an atom or a parameter tuple, and handles all permitted environments in parallel.

Let `K` be the greatest cardinality of any frozen argument in that phase. This loop terminates after at most `max(0,K-R)` extensions and ends at top `max(R,K)`. It never overshoots. A phase with no permitted environments exits immediately.

Over the entire native run,

`R <= max(1, greatest cardinality of any actual Card argument evaluated so far) <= q_t(W)`.

The final inequality uses the fixed-term footprint bound. The retained reserve has at most `q_t(W)+1` objects. Runtime may be arbitrarily large; it does not index the reserve. Here history-independent means polynomial overhead in the native run's peak live hereditary size, not a bound in the possibly smaller current state alone: retaining the largest needed reserve is allowed, and is bounded by the peak.

The reserve need not be bounded linearly by peak native-state hereditary size: an intermediate comprehension may be much larger than the state ultimately returned. The polynomial footprint bound is the correct statement.

## 8. Exact garbage collection

After the full step has produced its unique next-state value, update `Cur` and keep exactly the domain defined by

`Atom(x) or Atoms(x) or Empty(x) or True(x) or Ord(x) or exists y (Cur(y) and C(x,y))`.

This is a one-dimensional FO interpretation. Restrict input relations, membership, closure and the permanent markers; erase all scratch term tables and reset finite control. The retained family is transitive: input atoms have no members; the set `Atoms` has precisely the retained input atoms; the Boolean constants are closed; the ordinal reserve is transitive; and the current-state part is an inclusive hereditary closure.

Therefore restricting `C` preserves its exact meaning. If `C_U(x,y)` holds for retained endpoints, every intermediate object of a membership path to `y` is a descendant of the retained object `y`, and hence is retained. The converse follows by inclusion of the restricted graph. No stale reachability edges remain.

Every next-step parameter and every old-set member needed for a future extensional comparison is present. Nothing about an HF object's value depends on when it was previously created. Recreating a discarded set later is semantically harmless: if it still occurs recursively in any live root, it was not discarded; otherwise its earlier representative is irrelevant.

## 9. History-independent bound before low-dimensional compilation

Choose a polynomial `Q` dominating all fixed-term footprint bounds for the step and its subterms and take it large enough that `Q(W)>=W+2`.

At the beginning of each native step, the semantic domain contains only input constants/atoms, the current-state closure, and the reserve. Its size is at most `W+Q(W)+1`. During the step, all nonreserve HF values introduced belong to that step's footprint of size at most `Q(W)`; prior noncurrent values were erased. The reserve top never exceeds `Q(W)`. Hence every semantic checkpoint has size at most

`W+2Q(W)+1`.

Each fresh-set interpretation has fixed dimension and at most polynomially many raw descriptors. It can either be applied atomically or decomposed using the companion compiler. The number and arities of stored relations and control phases are fixed. After each completed native step the same invariant is restored. There is no multiplicative factor in the number of native or microsteps.

The companion `DIMENSION_AND_BINARY_COMPILER_AUDIT.md` constructs the required compiler without an appeal to qualitative polynomial-time equivalence. If `K` is the largest dimension of one source microinstruction and `r>=2` its greatest intermediate relation arity, it bounds every target universe by

`C_t [1 + W + 2Q(W) + 1]^(K r)`.

This is a fixed polynomial in `W`. The input is binary and retains the same `N`; startup uses an off-diagonal equivalence class for a distinguished marker and then fixed tagged copies, so it already obeys the two-dimensional binary restriction. At each source-microinstruction boundary the compiler has exactly one distinguished vertex per source object and one incidence vertex per true source-relation tuple. It discards all work tuples and duplicate incidences before the next expansion. Härtig tests are restricted to the distinguished source-object sort. Thus neither representation multiplicity nor repeated exponentiation across time enters the bound. Unary predicates and finite flags are encoded by binary diagonals, matching the precise fixed-binary-vocabulary model of the prior explicit-model theorem. This completes the fixed binary/two-dimensional part of the stated simulation theorem.

## 10. Consequence for the current lower-bound programme

Assume the independently audited explicit-model exponential maximum-state lower bound: each fixed binary two-dimensional interpretation program distinguishing the specified opposite-answer family, on arbitrarily large inputs of atom size `N`, has a run with maximum universe size at least `exp(c_I N)` for some `c_I>0`.

For a fixed BGS term program, apply the present compiler. If its two native runs have common maximum hereditary size `S`, the interpretation runs have size at most `C(N+S+4)^d`. Consequently

`C(N+S+4)^d >= exp(c_I N)`.

Thus `N+S+4 >= C^{-1/d} exp(c_I N/d)`, and, for sufficiently large inputs, `S >= exp(c_P N)` for any sufficiently small fixed positive `c_P`. The constants depend on the fixed program. This transfers the exponential maximum-state obstruction to the specific standard Rossman/GKPS BGS term formalism, including `Card`, with unrestricted finite runtime.

This conclusion remains conditional on the base/support/expander lower-bound inputs. The present reconstruction and the low-dimensional compiler have both passed the independent mathematical audit in `../space_simulation_audit/INDEPENDENT_AUDIT.md`; this is not formal certification or external expert validation. It is not an unrestricted algorithmic-space lower bound, a P-versus-NP claim, or a claim about all formalisms merely known to be polynomial-time equivalent to CPT.

## 11. Negative controls and audit obligations

- Without top-level GC, an ordered-input binary counter can visit all `2^n` subsets of `n` input atoms while each current subset has inclusive hereditary size at most `n+1`. A fixed bounded-comprehension term implements the counter, using the binary input order and a fixed state wrapper to distinguish control from Boolean halt values. Retaining every prior subset requires exponentially many objects; current-only GC requires only linearly many. The exact finite check exercises the sequence of subset values (without implementing the entire syntactic counter). The proof must reset the old domain, not merely reset `Cur`.
- Restricting a stored closure relation to a nontransitive subdomain can leave false reachability edges. For example keep `Empty` and `{{Empty}}` but remove `{Empty}`.
- Extensional merging without the `Set` guard identifies every input atom with `Empty`.
- Cardinalities of descriptor representatives are not cardinalities of HF values. Härtig is evaluated only after quotienting, with the intended logical sort guarded in the binary encoding.
- Keeping only the top ordinal marker but deleting its predecessors breaks the representation and changes cardinality. Keep its full closure, equivalently the entire consecutive reserve.
- A reserve indexed by elapsed time would destroy the theorem. Here its top is indexed only by actual cardinalities of evaluated term arguments.
- A bound based on `Q(W+old reserve size)` is not the argument: explicitly use the semantic footprint independent of reserve.
- Initialization at `Empty` is a start condition, not an immediate native halt.
- A powerset primitive would invalidate the polynomial fixed-term footprint lemma. No such primitive is present in the specified syntax.

Companion exact finite checks and the separate compiler audit must be read for executed outcomes. Finite examples can falsify mechanisms but cannot certify this asymptotic proof.

## 12. Executed finite checks

`check_space_simulation.py` completed successfully. It checked 303 fresh-set batches, 117,448 descriptor-equality pairs, 1,318 transitive garbage-collection cases, and 6,000 dynamic-reserve phases. Long traces through all subsets of up to ten atoms show the expected history/current separation: 1,024 subset states produce a history-retaining representation of 1,035 objects, while the current-only simulation peak is 15 objects. All four deliberate negative controls were detected. Exact output is in `space_simulation_test_results.json`. These tests check the semantic mechanisms, not generation or execution of the compiled FO formulas.

The independent audit additionally passed 1,171,875 comparisons of actual four-coordinate descriptor tuples, saturated relation/closure checks, and nine existing-ordinal collision cases. Its proof assessment, blind reconstruction, independent script and exact output are retained in `../space_simulation_audit/`.
