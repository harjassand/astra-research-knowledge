# History-independent dimension and binary-vocabulary compiler

Audit and explicit construction, 2026-10-08.

## Verdict

**The quantitative compiler is proved for programs on binary relational inputs of size at least two, with arbitrary fixed relational intermediate vocabularies and arbitrary fixed interpretation dimensions.** It also applies when an arbitrary-vocabulary input has already been supplied in the binary incidence representation defined below. Every simulated source state is represented canonically, with precisely one distinguished vertex per logical element. The maximum target universe is polynomial in the maximum source universe, independently of the number of simulated steps.

There is an important scope qualification. If an unencoded input has arbitrary high arity, and the very first output must already be binary and have a two-dimensional universe, one cannot in general construct a lossless representation of that input. For arity at least five this follows from an elementary information bound. Thus do not combine the separate dimension-reduction and vocabulary-reduction observations without checking initialization. The positive binary-input result is sufficient for the proposed exponential lower bound, whose input vocabulary is already binary.

Here “binary vocabulary” means a fixed finite vocabulary whose relation symbols have arity at most two. Unary predicates and finite-control flags can instead be represented using additional binary diagonal predicates, so the final vocabulary may have every symbol of arity exactly two. No claim that the final vocabulary consists of a *single* binary symbol is needed or proved here.

## 1. Precise theorem

Let P be a fixed parameter-free interpretation program with finite control. Its input vocabulary has arity at most two; its finitely many state vocabularies are arbitrary fixed relational vocabularies. Every interpretation has dimension between one and a fixed K. All defining formulas, transition tests, halt tests and output tests are FO with the ordinary, one-variable-on-each-side Härtig quantifier.

Use the following quotient convention, which is the convention of the prior explicit-model candidate: the equality formula generates its least equivalence closure on the interpreted domain, and output relations have existential-representative semantics. Standard interpretations with an already-definable equivalence relation and congruent output relations are special cases.

Put

    r = max(2, all arities appearing in P),
    S = max(size of the original input, sizes of all source states).

There are a fixed binary-vocabulary, parameter-free two-dimensional interpretation program Q and a constant C_P such that:

1. On every input A with |A| at least two, Q simulates P, including its halt/output behavior. If P does not halt, neither does Q.
2. Each source transition is simulated by a bounded number of target transitions, with the bound depending only on P, under the specified quotient convention.
3. Every target state in a simulation of a finite source run has at most

       C_P (1 + S)^(K r)

   vertices. This bound does not involve the runtime or prior discarded states.
4. At each simulation boundary the target is a fresh canonical incidence representation of the current source state, plus a fixed finite set of markers and finite-control flags.
5. All formulas of Q have fixed finite width independent of the runtime and of S.

The same construction can be used in a target formalism requiring equivalence/congruence rather than automatic equivalence closure and existential relations. Section 8 adds a finite FO closure loop. Its runtime need not be constant per simulated transition, but the same state-space bound holds.

The exponent K r is a convenient uniform upper bound, not an optimization. Constants absorb the number of symbols, coordinates, phases and markers.

## 2. What the primary literature says, and what is supplied here

GKPS15 defines FO+H and interpretation programs in §III. Its Remark 2 observes binary-vocabulary sufficiency. Theorem 16 states two-dimensional PIL sufficiency, with a short proof that factors fixed-dimensional interpretations into sequences of two-dimensional interpretations. Those statements do not themselves provide the particular history-independent bound needed here. The construction below supplies that bound and deals explicitly with singleton tags, counting, quotient relations, and cleanup.

Primary source: [Grädel–Kaiser–Pakusa–Schalthöfer, *Characterising Choiceless Polynomial Time with First-Order Interpretations*](https://www.logic.rwth-aachen.de/pub/schalthoefer/GKPS15.pdf), §III, Remark 2 and Theorem 16.

GKPS15's §III interpretation definition uses congruence-style semantics; the prior explicit-model candidate deliberately uses the more permissive closure/existential convention. Section 8 makes the compatibility issue explicit rather than conflating the two.

The rest of this note is an independent explicit construction, not a quotation of or claim about details proved in that paper.

## 3. Canonical binary representation and exact counting

For a finite σ-structure B with m logical elements, define Enc(B) as follows.

- D is a unary sort containing exactly one vertex v_b for each b in B.
- For each positive-arity symbol R of arity a, I_R contains exactly one vertex i_(R,b1,...,ba) for each tuple (b1,...,ba) in R^B.
- For each R and coordinate j, a binary predicate P_(R,j) links that incidence vertex to v_bj.
- There are q fixed marker vertices μ_1,...,μ_q, distinguished by singleton predicates M_1,...,M_q. They are disjoint from D and all incidence sorts.
- A nullary source relation R is represented by a unary flag on μ_1, equivalently by a binary loop at μ_1. Finite control is represented in the same way.

Here q is fixed, sufficiently large for all compiler tags, and may be chosen at least two. The marker set is retained even when the logical domain becomes empty.

The size bound is

    |Enc(B)| = q + m + sum_(R of positive arity) |R^B|
             <= C_σ (1+m)^r.

FO+H formulas on B translate exactly to Enc(B):

- Equality of source elements remains equality of D vertices.
- R(x1,...,xa) becomes the existence of an I_R vertex with P_(R,j) edges to xj for every coordinate.
- Existential quantifiers are restricted to D; universal quantifiers are relativized to D.
- The counting clause is

      H x y (φ(x,z), ψ(y,z))
        -> H x y (D(x) and φ*(x,z), D(y) and ψ*(y,z)).

A straightforward induction proves truth preservation, with any free source variables assigned to D. The clause is exact because D contains precisely one vertex per logical element, including after a quotient. Incidence vertices, tuple vertices, markers and multiple representatives are never counted as source elements.

In particular, there is no use of a tuple Härtig quantifier, no attempt to replace one counted source variable by k separately counted variables, and no assertion that FO+H is closed under arbitrary quotient interpretation by naive syntactic substitution.

One may retain the input's own unary/binary predicates directly on D during initialization instead of constructing its incidence encoding. Source input formulas are then translated by restricting quantifiers to D and reading these direct predicates. This avoids any non-binary intermediate vocabulary on binary inputs.

## 4. Uniform two-dimensional building blocks

Every operation below is a genuine parameter-free 2D interpretation. A 1D operation is padded by using only diagonal pairs (x,x). All sorts and markers are named by fixed predicates, not chosen atoms.

### 4.1 Preserve the current universe

Represent an old vertex x by the pair (x,x). Existing unary and binary relations are pulled back along this diagonal embedding. Equality of diagonal pairs is equality of their old vertices.

### 4.2 Create the first marker without choosing an atom

On the original input A, |A| >= 2, use all pairs A². Keep every diagonal pair as a separate class. Collapse **all** off-diagonal pairs into one class μ_1. Thus the equality relation is

    ((x=y) and (u=v) and x=u)
       or
    ((x != y) and (u != v)).

The output universe has |A|+1 elements. D consists of the diagonal classes; M_1 consists of the one off-diagonal class. Copy every input relation only onto D. The construction is invariant under every automorphism of A and selects no input atom.

### 4.3 Create finitely many further markers

Assume μ_1 is already uniquely defined and the total current universe has at least two elements. Keep all old diagonal pairs. Add the pairs (μ_1,x) with x != μ_1, and identify all these new pairs into one class. Label the resulting unique new class M_j. This adds exactly one marker and preserves all old vertices and relations. Repeat a fixed number of times.

All later states retain these q markers. No further atom choice or fresh-marker construction is needed.

### 4.4 Make a tagged copy of a sort

If S is a sort disjoint from a marker μ, use old diagonals together with all pairs (s,μ), s in S. The latter are automatically off-diagonal. Give these pairs a new sort label and a binary copy/projection edge to the diagonal image of s. Use identity equality on the new pairs.

This creates one new vertex per s, with no multiplicity and no chosen representative. Copies with different tags can be made simultaneously using distinct markers, or sequentially using one marker and distinct phase/sort labels.

### 4.5 Form the product of disjoint sorts

If U and V are disjoint sorts, keep all old diagonals and add pairs (u,v), u in U, v in V. New pairs cannot collide with the old diagonal representation. They have identity equality and binary projections to the old copies of u and v. Each vertex of U×V occurs exactly once.

A coordinate predicate on U can be inherited by the product: if C_i(u,a), then C'_i((u,v),(a,a)); append v as the last coordinate. These are ordinary FO definitions with binary output relations.

### 4.6 Filter, relabel, quotient, and discard

A 1D operation, padded diagonally, can restrict to any definable union of sorts, relabel its unary predicates, and replace its binary predicates by fixed FO+H formulas. It may also quotient by a definable equality seed under the stipulated target semantics. Old sorts omitted from its domain are actually discarded, not merely hidden.

These primitives are sufficient for the compiler; none treats the whole accumulated target universe as the next logical domain.

## 5. One source k-dimensional transition

Suppose the current source state is B, |B|=m. The target boundary is Enc(B). Let I be one of P's k-dimensional transitions, k <= K, with domain formula δ, equality seed η, and relation formulas ρ_R. Let B'=I(B).

### Phase A: make tuple representatives over the logical domain

Create a tagged copy T_1 of D. For j=2,...,k, form

    T_j = T_(j-1) × D.

The factors are disjoint sorts. Give each T_j vertex j binary coordinate maps to D. Thus T_j is in a bijection with B^j. Intermediate tuples and the old representation are retained for this macrostep only.

Use the relativized translation of δ to designate

    V = { t in T_k : B satisfies δ(coords(t)) }.

For t,u in V, define a binary seed F(t,u) by evaluating η on their k+k coordinates in D. This uses the translation from Section 3, with a fixed existential block retrieving the coordinate vertices. Every Härtig quantifier inside η still counts D, not V.

The source's new logical elements are the equivalence classes of V under the equivalence closure of F.

### Phase B: materialize relation candidates

Build sorts W_1,...,W_a for a up to the maximum positive relation arity, where W_1 is a tagged copy of V and

    W_j = W_(j-1) × V.

They have binary coordinate maps to V. There is one W_j vertex per ordered j-tuple of domain representatives. Coordinate maps from V to D permit evaluation of each ρ_R on its a blocks of k source coordinates.

For each positive-arity symbol R of arity a, make a tagged copy J_R of the W_a vertices satisfying ρ_R. Record its a binary incidence edges to the corresponding V coordinates. These are candidate incidence vertices. The copy for each R has its own sort, even when two relation symbols are true of the same tuple.

There are no more than |V|^a <= m^(ka) candidates for R. Duplicate logical relation tuples caused by the upcoming quotient are harmless at this stage and are deliberately cleaned up later.

Nullary source relations need no candidate vertices: evaluate their defining sentences and store their truth values on a fixed marker.

### Phase C: quotient the logical domain and drop the old state

Perform a diagonal/1D interpretation whose domain consists **only** of

    V, the candidate sorts J_R, and the q markers.

On V, use F as the equality seed. On candidate vertices and markers, use equality only. There are no cross-sort equality links.

The result has one D' vertex per actual source element of B', one distinct vertex per candidate incidence, and the q markers. Retain each incidence edge from a candidate to its original V coordinate, using existential-representative semantics. After quotienting, it points to the unique D' class of that coordinate.

This is exact even if η was not itself an equivalence relation or ρ_R was not constant on the generated classes. A tuple of quotient classes belongs to R in B' exactly when at least one candidate incidence witnesses it. All old D elements, old incidences, intermediate tuple sorts and work products have been discarded.

This phase is where actual quotienting occurs. It is not simulated by retaining unequal representatives and pretending they are one element when counting.

### Phase D: quotient duplicate incidence vertices

The structure now has precisely one D' vertex per logical output element. Define, within each candidate sort J_R,

    j ~_R j' iff, for every coordinate l,
                   j and j' have the same P_(R,l) target in D'.

This is FO-definable because each coordinate edge has exactly one target. For example use, for each l, an existential D' vertex linked from both candidates. Keep D' and markers equal only to themselves. Quotient by the disjoint union of these equivalence relations.

The output has exactly one incidence vertex for each R-tuple in B'. Its coordinate maps are unchanged. Rename D' to D, erase all work predicates, and set the correct boundary/control phase. The result is exactly Enc(B'), up to the unique role-preserving isomorphism on its marker and incidence representation.

A subsequent source Härtig test now counts D', so it counts output quotient classes exactly once.

## 6. Space calculation and absence of exponent compounding

At the start of the macrostep, the clean representation has at most C(1+m)^r vertices. During tuple construction the additional vertices are bounded by

    sum_(j=1)^k m^j.

During relation-candidate construction they are bounded by a constant multiple of

    sum_(j=1)^r |V|^j <= sum_(j=1)^r m^(kj).

The finitely many tagged copies contribute only another fixed multiple of these quantities. Therefore every state before the two cleanup quotients has size at most

    C_P (1+m)^(k r) <= C_P (1+S)^(K r).

Quotients and filters cannot increase the universe. At the next boundary, the much stronger bound is

    |Enc(B')| <= C_P (1+|B'|)^r.

That boundary invariant is restored **at every source step**, even when B' has a tiny universe and there were many representatives or relation candidates during its construction. In particular, if one enormous quotient shrinks the source state back to size one, all candidate multiplicity is removed before the next expansion.

The next macrostep builds products only from the new distinguished D sort, not from Enc(B') as a whole and certainly not from a previous scratch universe. Thus the recurrence is not an iteration of S -> S^c on previous compiler states. It is a fresh local estimate in the current source size m, plus a canonical representation of that same source state.

No discarded vertex or historical stage counter is retained. A fixed finite phase/control value suffices. Actual set-theoretic codes of target vertices may still have unbounded rank over a long run; this does not affect the number of vertices in a target state and is compatible with the prior explicit-model candidate's rank-independent hereditary-support argument.

## 7. Assemble one initialization and one step interpretation

Use a fixed finite collection of phase predicates, encoded on μ_1. Each microoperation above has a 2D interpretation formula. For each output domain/equality/relation formula of a single global step interpretation, take the disjunction of the appropriate local formula guarded by its phase sentence. Exactly one phase is active on every reachable state.

The first initialization interpretation creates μ_1 and the diagonal copy of the binary input. Its binary input relations are copied directly to that distinguished D sort. The finitely many marker-creation phases follow, then the compiled original initialization is run using these direct input relations. Its first cleanup produces Enc(A_1), after which the main simulation loops.

Halt and output tests are enabled only at clean source-state boundaries. They are the source FO+H tests translated relative to D. In intermediate microphases the target halt test is false. Finite-control source branching is handled by guarded phase choices; all branches belong to a fixed finite instruction set.

All unary sorts and flags can be replaced uniformly by additional binary diagonal predicates:

    Q(x) is read as Q_diag(x,x),
    Q_diag(x,y) is defined only when x=y.

A source nullary truth value or a phase flag is a diagonal predicate on the unique marker μ_1. Thus this construction can use a vocabulary consisting exclusively of binary relation symbols, without nullaries, constants, or parameters.

The source program and all its schemas are fixed. Every translated formula therefore has a fixed number of variable names. The number of macrosteps does not occur in any formula. The compiler never expands a time-indexed formula at runtime.

## 8. Optional strict congruence-compatible implementation

Phase C above uses exactly the closure/existential quotient semantics of the prior explicit-model candidate. For a target restricted to the conventional congruence definition, replace it as follows.

Before quotienting V, maintain a binary relation C on V. Initially let it contain identity, F and the converse of F. Repeatedly apply the domain-preserving FO update

    C_new(x,y) := C(x,y) or exists z (V(z) and C(x,z) and C(z,y)).

A phase test says whether this update would add any pair. Once no pair can be added, C is precisely the generated equivalence relation. The finite loop adds no vertices, terminates on every finite state, and uses a fixed relation vocabulary and fixed FO formulas. Reflexive symmetric transitive closure is reached after finitely many rounds, for example at most ceil(log2(max(1,|V|))) rounds after initialization when one interprets the usual path-length-doubling bound.

Replace each candidate-to-V coordinate edge by its C-saturation: an incidence with raw coordinate v links to every x with C(v,x). This binary predicate is congruent on V. Quotient V by the already-computed equivalence C and keep candidates/markers distinct. Coordinate edges are now well-defined under strict congruence semantics and become unique after quotienting. Phase D is already a genuine equivalence quotient with congruent coordinate relations.

Thus the compiler is also valid in the strict target model. The only added cost is a finite number of domain-preserving phases, which is immaterial to an unrestricted-finite-runtime theorem. There is no new state-universe cost, and no dependence on prior history.

If the source itself uses conventional congruent interpretations, the same construction remains valid; its output agrees with the source. The closure loop is about the target implementation of the intermediate edge representation, not an assumption that arbitrary quotient-class counting is FO-definable.

## 9. Small inputs and the initialization obstruction

### 9.1 Why |A| >= 2 is stated

An ordinary parameter-free k-dimensional interpretation on a singleton has at most one output element. Iterating such interpretations cannot create two marker elements. The first-marker construction genuinely requires an off-diagonal pair.

For the asymptotic lower-bound application this is harmless: the hard-input family has unbounded size, and the theorem can simply be stated for |A| >= 2. Once the fixed marker set has been created, source logical domains may become empty or singleton without causing a problem; markers keep the target's administrative universe available.

If a total Boolean equivalence on all binary inputs is required, singleton input types can be handled separately. For a fixed source vocabulary and a universe of size at most one, there are only finitely many possible source states, and every positive-dimensional interpretation stays within that size. Halting, nonhalting cycles and output on each such input type can therefore be determined by a finite exhaustive simulation and hard-coded in a small-input branch. Singleton acceptance/rejection/control can be encoded by loops on its one target vertex.

Empty inputs require a convention check. When the binary input vocabulary has no nullary symbols, there is only one empty input isomorphism type; its behavior can be hard-coded by the target halt/output sentences on the empty universe. If arbitrary input nullaries are allowed but the output vocabulary is strictly binary, different empty input structures cannot in general be distinguished after initialization, since there is only one empty structure in that target vocabulary. Either retain nullary control, exclude those inputs, or explicitly pad the input. This does not affect the positive theorem on |A| >= 2.

### 9.2 Why arbitrary unencoded input arity cannot be silently ignored

Suppose an input has one r-ary relation, and the first interpretation is two-dimensional with output in a fixed binary vocabulary containing b binary and u unary symbols. On an n-element input it has at most n² output vertices. The total number of possible output isomorphism types is no greater than the number of labeled structures on at most n² vertices, namely at most

    (n²+1) 2^(b n^4 + u n² + O(1)).

The number of input isomorphism types with one r-ary relation is at least

    2^(n^r) / n!.

For r >= 5 and sufficiently large n the latter is larger. Thus no such first interpretation can be lossless on all inputs. In particular, it cannot generally produce a representation from which the original arbitrary-vocabulary state can be decoded.

This is an obstruction to a state-faithful initialization compiler. It is not, by itself, a separation theorem for every possible query-specific Boolean optimization, and no such separation is asserted here.

There are three legitimate variants:

1. **Binary input, arbitrary intermediate vocabulary:** the full theorem in this note, retaining input size n unchanged. This is the variant needed for the prior explicit-model lower bound.
2. **Arbitrary input supplied already as Enc(A):** the same internal compiler applies. The input universe may now be O((1+|A|)^r), so any quantitative lower bound stated in the encoded input size must account for that change. Do not infer an identical exp(Ω(N)) bound after a polynomial input blowup.
3. **Arbitrary raw input with temporary high-arity preprocessing:** diagonal-copy the original relations while creating all fixed-arity tuple/incidence vertices, then discard the raw high-arity relations. This is history-independent polynomial-space preprocessing by 2D interpretations, but its early state vocabularies are not binary. It does not meet a requirement that every post-initial state already be binary.

Allowing a higher-dimensional initial interpretation is another valid modification, but it also changes the exact target model. The separate vocabulary/dimension observations in GKPS15 should not be cited as having settled this simultaneous initialization point.

## 10. Consequence for the proposed maximum-state lower bound

Assume the prior explicit-model candidate theorem for every fixed binary-vocabulary 2D FO+H interpretation program Q on its fixed binary hard inputs of size N:

    max target state size >= exp(c_Q N)

on at least one input in each sufficiently large opposite-answer hard pair, for a constant c_Q>0.

Let P instead use any fixed finite control, fixed relational intermediate vocabulary, and fixed finite dimensions, on these same binary inputs. The compiler produces Q with

    max target state size <= C_P (1+S_P)^(K r).

Consequently

    C_P (1+S_P)^(K r) >= exp(c_Q N),

and hence

    S_P >= exp(Ω_P(N)).

The constant can deteriorate with P, including its maximum dimension, maximum relation arity and compiled formula width. It remains a positive constant for each fixed P. The input size is unchanged, so no exponent in N is lost. No runtime bound is used.

This closes only the dimension/binary-vocabulary stage of a possible HF-program transfer. A history-independent compiler from live HF states and their operations to a fixed-dimensional relational interpretation program is a separate prerequisite. The present note neither assumes a polynomial total trace nor proves that missing HF-to-interpretation stage.

## 11. Audit checklist

- One actual vertex per source logical element at every boundary: yes.
- Source Härtig counts source elements rather than representatives/tuples: yes, by D-relativization.
- Generated equivalence closure supported: yes, directly in the specified model; optionally by a domain-preserving FO loop.
- Existential representative relation semantics supported: yes, via candidate incidence witnesses.
- Duplicate relation incidences removed after quotients: yes, Phase D.
- All products use designated source-derived sorts rather than historical ambient universes: yes.
- Fixed tags obtained without chosen atoms: yes, off-diagonal quotient plus fixed marker additions.
- Binary input preserved throughout initialization: yes, by diagonal copies of its direct binary relations.
- Arbitrary high-arity raw input initialization addressed: caveated, with an explicit information obstruction to lossless 2D binary initialization.
- Source logical empty/singleton states after startup: supported.
- Original input size below two: explicitly isolated.
- Fixed finite control and fixed-width formulas: yes.
- State bound independent of runtime and discarded history: yes.
- Single-edge graph vocabulary: not required, not claimed.
- Polynomial-time equivalence alone treated as space-preservation proof: no.

## Status

This is a mathematical construction/audit, not a machine-checked formalization. Its central boundary invariant and every universe-creating operation are specified above. No unresolved gap has been identified in the stated binary-input theorem. The arbitrary-raw-vocabulary simultaneous-initialization scope must not be silently enlarged.

## 12. Executed exact finite controls

`check_dimension_binary_compiler.py` passed **262,405** exhaustive cases: representative universes of sizes 0 through 3, every directed equality-seed relation (including loops), and every possible binary relation-candidate subset, with no congruence assumption on the candidate relation. A generic existential-representative quotient is applied in Phase C and then again with the FO coordinate-equality relation in Phase D. The result is checked against an independent reachability calculation and the source existential quotient semantics.

The checks verify exact output relations, one incidence vertex per quotient tuple, one logical vertex per quotient class, and two preserved permanent controls disjoint from the logical domain. All possible logical output sizes 0, 1, 2 and 3 occur. The explicit path seed 0→1→2 with all nine relation candidates collapses from 12 vertices after Phase C to four after Phase D: one logical element, one incidence, and two controls. Six additional tagged-product checks include empty products and repeated coordinates, verifying that a tagged T1 copy avoids collision with old diagonal representations.

Machine-readable output: `dimension_binary_compiler_test_results.json`. These are exact semantic examples, not a generated-formula execution or formal certification of the asymptotic theorem.
