# Space-simulation proof gate

## Result

A fixed Rossman/GKPS BGS term program, including `Card`, on unary/binary inputs of size at least two has a fixed binary-vocabulary two-dimensional FO+H interpretation simulator whose maximum universe is polynomial in input size plus peak native hereditary-closure size. The polynomial and simulator depend only on the fixed term. There is no factor in finite runtime or discarded history.

The construction supplies transitive current-state garbage collection, an actual-cardinality-bounded dynamic ordinal reserve, atom-safe extensional quotients, and a resettable tuple/incidence compiler. The standard-model exponential hereditary-space corollary follows conditionally from the already audited explicit-model lower bound.

## Read in this order

1. `HISTORY_INDEPENDENT_HF_SPACE_SIMULATION.md`: complete HF evaluator, resource proof and conditional lower-bound transfer.
2. `DIMENSION_AND_BINARY_COMPILER_AUDIT.md`: explicit fixed-arity/fixed-dimension to binary/two-dimensional compiler with all-phase bounds.
3. `NEGATIVE_CONTROLS.md`: important boundaries, including real exponential history retention at linear native space.
4. `space_simulation_test_results.json` and `dimension_binary_compiler_test_results.json`: executed exact finite semantic checks.

## Executed checks

- HF constructors: 303 batches, 117,448 descriptor equality pairs.
- Transitive garbage collection: 1,318 cases.
- Dynamic ordinal reserve: 6,000 phases.
- Quotient/incidence compiler: 262,405 exhaustive cases and six tagged-product cases.
- Independent raw-tuple audit: 1,171,875 descriptor pairs and nine existing-ordinal collision cases.
- No failed final checks.

The compiler author independently reviewed the HF core and found no substantive defect. The separate independent blind/core audit also accepts the theorem and full compiler; its written assessment is in `../space_simulation_audit/INDEPENDENT_AUDIT.md`. The prior space-simulation gate is now internally closed only for the explicit model above. These are mathematical reconstruction and AI audit results, not a Lean/formal certificate or external expert review.

## Scope that must travel with the result

- Exact syntax: fixed, powerset-free, bounded-comprehension Rossman/GKPS BGS terms; ordinary HF `Card` is allowed.
- Final simultaneous binary/2D theorem: unary/binary original input of size at least two. The target lower-bound family has exactly that form.
- Metric: peak live inclusive hereditary closure, together with input size; retaining the largest required ordinal reserve costs only a polynomial in this peak.
- No claim about every polynomial-time-equivalent formalism, unrestricted Turing-machine space, general choice algorithms, or P versus NP.
- Novelty and the imported algebraic/base-logic lower-bound inputs remain separate questions.

The previously assembled first research packet is not changed by this new proof gate.

Historical novelty is not established. This addendum is a scientific follow-on record; it leaves the first research ZIP unchanged.
