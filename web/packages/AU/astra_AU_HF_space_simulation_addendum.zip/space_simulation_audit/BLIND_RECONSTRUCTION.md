# Blind reconstruction (recorded before reading the proposed proof)

Date: 2026-10-08. Assignment: audit a history-independent interpretation-program simulation of a fixed BGS/Rossman term program. At the time of writing this file I have not opened HISTORY_INDEPENDENT_HF_SPACE_SIMULATION.md or related local proof files. I did locate the primary GKPS15 paper publicly to verify the model family; the construction below is independent.

## Provisional conclusion

The claim appears plausible under explicit assumptions: interpretations permit definable congruence quotients; native values and their descendants are represented explicitly; only a fixed finite term/program syntax is present; Card outputs a von Neumann ordinal; input relations have bounded fixed arity (and unary/binary input is the stated normalization target). The original polynomial-time theorem cannot alone justify the claim because its construction may use a supplied polynomial reserve or retain history. The following replacement should avoid both.

## Boundary representation

Represent all input atoms, the inclusive hereditary closures of the currently live native registers, and a fixed set of distinguished HF objects by an acyclic membership graph. Atoms are a separate sort, and different atoms remain different. Set nodes are extensional. Registers are fixed unary root predicates (or a fixed tuple relation). Keep the input structure on the atom sort. Empty, true, and Atoms can be permanently retained; their combined extra closure is O(|A|). With a fixed number of registers, the clean boundary domain is O(W).

The distinction between this one-step bound and a global bound matters: use the current boundary size as the input to each fixed term evaluation, then collect all unreachable objects before the next native iteration. Do not start an evaluation with all previous scratch objects retained.

## Fixed term footprint

By structural induction on the fixed term syntax, all object nodes needed for evaluation over any fixed-arity family of environments have total size polynomial in the input boundary size. Pair/Union/Boolean construction adds only a bounded number of root candidates per environment; descendants are already present. Variables and TheUnique reuse nodes. A comprehension has at most as many bindings as there are members of its already-built range, so its body/guard families and their union of descendants grow by a fixed polynomial factor. Nesting depth and variable count are fixed by the program. Constructing every subset is not licensed by bounded comprehension, and there is no powerset primitive.

The important induction is on the union of all subterm/binding footprints, not merely the size of the final term value: a large rejected guard/body family can otherwise be hidden by a small output. Intermediate Card outputs also belong in this footprint.

Evaluation can run bottom-up by syntax occurrence and in parallel over all currently active environments. Environment and result data are relations of fixed arity. Alternatively they can be explicitly tuple-coded, with only another fixed polynomial blowup. Constructed object duplicates must be merged before cardinality is measured.

## Extensional equality

For a finite acyclic, possibly non-extensional object DAG, compute equality bottom-up. Start with diagonal equality (atoms only equal themselves). Repeatedly declare two set nodes equal when each member of either has an already-equal member in the other; retain atom identity and never identify an atom with a set. The finite relation reaches a fixed point and equals semantic HF equality by induction on rank. The approximants can be taken to be equivalence relations. Before quotienting, saturate every relation under the final equality in all object coordinates. In particular membership cannot be passed to the quotient as a raw unsaturated relation. Distinguished pointers and environment/result relations must be handled compatibly. Actual quotienting, rather than counting representatives, is essential.

The equality loop stores fixed-arity relations on the same domain, so does not require a history of rounds or a rank counter.

## Card without a reserve

For a batch of canonical object arguments, grow a shared ordinal prefix one step at a time, starting from zero. The order of these new ordinal nodes is intrinsic to their successive construction; no ordering of input atoms is chosen. At each stage compare the unary set of members of an argument with the unary prefix below the current ordinal using the unary Härtig quantifier. Mark arguments whose counts match. Stop when every argument has matched; no supplied maximum is needed.

The largest needed ordinal is at most the number of canonical object nodes currently present. Hence at most O(N) counter nodes are needed for a batch over an N-node object universe. The stop condition must avoid an extra successor after all arguments are done. Existing object ordinals may coincide with the counter ordinals, so either keep counters in a disjoint administrative sort and copy their explicit ordinal graph as object candidates followed by equality normalization, or merge carefully while preserving the counter meaning. Count only canonical member-object nodes, never raw candidate records or administrative nodes.

## Garbage collection and finite control

Once new registers are computed, retain input atoms, permanent constants, new roots, and the downward membership closure of these roots. The downward closure is computed by a monotone unary reachability relation on the existing universe, detected by a first-order stability test. Restrict the universe to the live nodes and clear all scratch predicates. This yields a fresh O(W) boundary regardless of the number of earlier iterations.

All term occurrences, phase labels, register labels, and return points are finite because the source program is fixed. Their loops are equality fixed point, live closure, and Card growth, not an unbounded history stack. Control may be encoded by nullary relations or finitely many distinguished tags. Parameter-free tags can be obtained from tuple equality patterns when |A| >= 2; no atom is selected. A proper proof must spell out that initialization and tag creation themselves do not assume an ordering or extra named elements.

## Remaining audit pressure points

1. Verify actual GKPS grammar, defaults on atoms/non-singletons, Boolean semantics, and iteration/halt semantics.
2. Prove the footprint induction for all guard and body assignments, including intermediate results discarded from the native value.
3. State that all interpretation relations become congruence-invariant before quotienting; distinguish semantic object equality from administrative-record equality.
4. Check Card on atoms and zero, repeated values, quotient multiplicities, existing ordinal objects, and empty parameter families.
5. Check explicit native membership closure after union/comprehension and after quotient/GC.
6. Account for every equality, Card, phase-control, initialization, closure, and cleanup intermediate domain.
7. Obtain a separate fixed binary/2D compiler with a history-independent bound on each encoded state, not only its final state. Encoding high-arity input by incidence nodes costs |A|^r and must not silently be called linear; the unary/binary input restriction must remain explicit.

Primary source located: https://www.logic.rwth-aachen.de/pub/schalthoefer/GKPS15.pdf . The proof construction above is my independent proposed argument, not a claim quoted from that paper.
