# Independent audit of the history-independent HF simulation

Date: 2026-10-08.

## Verdict

**No fatal flaw found. The stated simulation theorem is valid with its explicit scope.** A fixed GKPS/Rossman HF term program on unary/binary finite input, with at least two input atoms, admits one fixed parameter-free FO+unary-Härtig interpretation simulation whose maximum universe is polynomial in the maximum inclusive hereditary size of the native states plus the input size. The polynomial is independent of the number of native iterations. The companion resettable binary/two-dimensional compiler preserves this conclusion.

This is an independent mathematical audit, supplemented by exact finite tests. It is not a machine-checked formal proof, and it does not independently establish the lower-bound theorem to which the simulation might be applied.

I recorded `BLIND_RECONSTRUCTION.md` before opening the proposed proof. The blind argument independently found the semantic-footprint, canonical-quotient, on-demand-counting, and garbage-collection route. It used a more general iterative extensional-equality mechanism; the submitted proof's one-layer constructor is simpler and sufficient.

## Documents and primary-source check

Audited local documents:

- `../space_simulation/HISTORY_INDEPENDENT_HF_SPACE_SIMULATION.md`
- `../space_simulation/DIMENSION_AND_BINARY_COMPILER_AUDIT.md`
- `../space_simulation/check_space_simulation.py`

Primary source: [Grädel, Kaiser, Pakusa, Schalthöfer, Characterising Choiceless Polynomial Time with First-Order Interpretations, LICS 2015](https://www.logic.rwth-aachen.de/pub/schalthoefer/GKPS15.pdf).

The source-model check uses Sections II–III: HF atoms and sets are distinct; Card returns a von Neumann ordinal and returns zero on atoms; TheUnique defaults to the empty set; comprehension has a bounded range and Boolean guard; iteration begins with the empty state and halts on the first positive-step Boolean result. The interpretation definition admits definable equivalence quotients with congruent relation formulas. The source also uses ordinary unary Härtig. The history-independent construction audited below is a new argument, rather than something inferred merely from the published polynomial-time equivalence.

## 1. Exact quantitative statement

For a finite native run or prefix `a_0,...,a_h`, let

`W = n + 4 + max_{0 <= i <= h} |cl({a_i})|`,

where `cl` is inclusive hereditary closure. The corresponding simulated prefix is understood to end at the checkpoint representing `a_h`, not after evaluating an additional native step. There are constants `C,d`, depending only on the fixed program, with simulated maximum universe at most `C W^d`.

This is a peak-over-the-run bound. It is not a pointwise bound in the instantaneous current value alone. In particular, retaining a reserve required by an earlier large intermediate term is permitted because the reserve remains polynomial in the peak native measure. No time bound, input polynomial, or advance estimate of W is an input to the simulator.

The initial family of all atoms, Atoms, Empty, true, and the current state's closure has size at most `n+3+|cl({a_i})| <= W`. The additive constants and any fixed register-tuple encoding are harmless.

## 2. Full term footprint: accepted

The required induction controls the union of all evaluation footprints, not just the final output. For each fixed syntax occurrence `s`, choose nondecreasing polynomials `F_s` and `J_s` bounding respectively the object footprint and the number of evaluation instances for a single environment whose full argument closure, together with the input base, has size at most m.

- Variables/constants need only the base.
- Boolean tests retain their operands' footprints and produce one of the existing Boolean objects.
- Pair and Union add at most one object beyond the union of operand footprints. Their members and all descendants already occur there.
- TheUnique produces an existing member, or Empty. The atom and non-singleton cases are covered.
- Card of a value with at most `F_r(m)` members introduces at most `F_r(m)+1` ordinal objects, including all predecessors.
- For comprehension with range r and body/guard s and phi, set `R=F_r(m)`. There are at most R bindings. Every binding object's closure lies in the range footprint. Thus a valid bound is

  `m + R + R(F_s(m+R)+F_phi(m+R)) + 1`.

  This explicitly permits eager body evaluation when the guard is false. The corresponding instance-count bound is

  `1 + J_r(m) + R(J_s(m+R)+J_phi(m+R))`.

All recurrences have fixed syntax depth, hence remain polynomial. Atomic input tests have fixed arity and introduce no new objects. A range that is an atom has no members, so the comprehension is empty and the estimate remains valid.

The proposed implementation restricts environments to actual native evaluation bindings. It never replaces a bounded range by the ambient simulator universe. This is the decisive reason an old ordinal reserve does not get recursively fed into the next step's semantic bound.

At any occurrence, argument/value tables have fixed arity. Even if their tuple counts are larger than the number of distinct semantic objects, they have at most a fixed power of that number. In the binary compiler those tuples become incidence vertices, again with fixed polynomial cost.

## 3. Fresh-set constructor and equality: accepted

Assume U is a transitive family with one node per actual HF object. For each allowed parameter tuple v, the constructor adjoins

`b_v = {u in U : theta(v,u)}`.

All members of every new candidate are old objects. Direct comparison of complete old membership rows therefore suffices; no hidden rank recursion is required.

The descriptor equality is precisely equality of denotation:

- old objects are equal exactly when their U-nodes are equal;
- two new candidates are equal exactly when their theta-rows agree;
- a new candidate equals an old object exactly when the old object is a set and the rows agree.

The Set guard prevents every urelement from collapsing to Empty. Since equality of denotation is an equivalence, the construction satisfies the stricter conventional quotient definition as well as the root project's generated-equivalence convention.

Every retained relation and new table must be saturated under descriptor equality in every coordinate. The proposed proof explicitly does so. Hence it is not relying on an invalid quotient of noncongruent raw relations. Reusing an old set does not create duplicated logical elements, and repeated parameter tuples or extensionally equal candidate rows do not inflate later counts.

A fully explicit tuple implementation exists. For a k-coordinate parameter tuple, use a fixed length L at least `k+2` and at least 3. Reserve the final two coordinates as equality-pattern tags. Equal final coordinates denote an old object, carried in the first coordinate; unequal final coordinates denote a new parameter tuple, carried in the first k coordinates. Ignore other padding coordinates in the descriptor equivalence. For zero-arity parameter families use the same pattern and ignore all payload coordinates. Nonempty old/new tag classes exist because U has at least two elements. This defines objects by equality patterns, without choosing atoms.

## 4. Stored hereditary closure: accepted

Let `C(x,y)` mean that x is y or a recursive member of y. The constructor starts with old closure, descriptor identity, and

`old(x) C new(v) iff exists z (C_old(x,z) and theta(v,z))`,

then saturates under descriptor equality.

For a genuinely new object, every nontrivial downward membership path starts with an old member and thereafter stays in old U, because U is transitive. Such a new object cannot itself be an element of an old object: transitivity would already have put it in U. Nor can two genuinely new candidates be members of one another, since every candidate has only old members. These facts exhaust the possible new paths. If a candidate instead equals an old object, saturation transports the already correct old closure. Consequently the update is exact and does not hide a transitive-closure operator inside FO.

This one-layer invariant is stronger than merely saying the graph represents some HF values. The proposed proof consistently restores it after every constructor.

## 5. Card and reserve growth: accepted

At a Card phase, all argument tables are frozen and the domain already contains unique object representatives. A reserve predicate marks precisely the actual ordinals `[0],...,[R]`.

The comparison

`H_xy(E(x,arg), E(y,o))`

counts actual members, once each. It does not count tuple descriptors, evaluation environments, incidence vertices, or quotient representatives. Atom arguments have no members and correctly match zero. Distinct reserve ordinals have distinct member counts, giving a unique result for each argument.

If some argument has no match, constructing the set of all reserve objects yields exactly `[R+1]`. Updating Ord by this object and replacing Top are definable table/marker updates. If this ordinal already exists outside the reserve, the fresh-set constructor merges with that existing object, preserving both counting and representation. No fresh atom, chosen representative, or externally supplied arithmetic is needed.

With maximum frozen argument cardinality K, the phase stops with top `max(R,K)`. It makes no extra extension after all environments match. An empty environment family exits vacuously. Across a run, reserve size is bounded by one plus the maximum actual argument cardinality ever evaluated, hence by the full-term polynomial in W. The reserve is monotone in necessary cardinality, not in elapsed time.

The term syntax contains no primitive powerset or succinct integer manipulation capable of defeating this footprint bound.

## 6. Garbage collection: accepted

After installing the newly computed root, retain precisely the input atoms, permanent constants, all reserve ordinals, and the root's inclusive downward membership closure. This is first-order definable using the exact stored C relation.

The retained family is transitive. Therefore the restriction of E is the intended membership relation, and restricting C retains exactly the closure of that restricted membership graph. Every path ending at a retained object lies entirely among its retained descendants. This proves that no stale reachability pair remains after collection.

Scratch argument tables are erased, not carried into the next native step. Old values not reachable from any permanent/live root are genuinely removed from the domain. Recreating such a value later is harmless; if it had remained a member of a live object, collection could not have removed it.

Thus no number of repeated native steps can accumulate previously discarded objects. The submitted ordered-subset counter negative control correctly identifies why retaining history would break the theorem.

## 7. Initialization and finite control: accepted

For n at least two, the three-dimensional initializer uses diagonal triples for original atoms and the three exactly-two-equal patterns for Empty, true, and Atoms. Each pattern is nonempty already at n=2. Quotienting a pattern to one class is parameter-free. These three sets are distinct from the atoms and from one another. Membership and reflexive closure are directly definable. Ord initially marks Empty and true.

The initial Empty state must not trigger halting before the first native step. The proposed initial phase flag handles this. Later halting/output tests are performed at completed native-state boundaries, so intermediate Boolean subterm values cannot accidentally halt the program.

Evaluation control is finite: use one phase for each fixed syntax traversal point, plus reserve-loop and boundary phases. Comprehension instances run in parallel tables; they do not need a runtime-dependent recursion stack. All unbounded auxiliary looping is reserve extension, plus an optional congruence-closure loop in the strict binary compiler. Both use fixed relation vocabularies.

Different fixed interpretation dimensions can be padded to one fixed dimension without choosing an element: repeat a selected tuple coordinate in each extra position. The relevant source universes never become empty in the HF core. Guard each local formula by its finite phase condition and take a finite disjunction. This yields one fixed step interpretation rather than a changing instruction set.

## 8. Every auxiliary phase and its space bound

Let Q dominate all full-term bounds and satisfy `Q(W) >= W+2`. At the beginning of a native step, only the base/current closure and reserve remain. Throughout that step:

- Base and current root closure: at most W objects.
- Current step's nonreserve semantic footprint: at most Q(W).
- Retained/growing reserve: at most Q(W)+1 objects.
- Formula/table/control updates: no additional universe elements in the core.
- Constructor semantic output: already included in the footprint/reserve bound.
- Raw tuple descriptors of a fixed-dimensional constructor: at most a fixed power of the current semantic domain; relevant if materialized by the compiler.
- Root installation and garbage collection: domain-preserving or domain-reducing.

Therefore every semantic checkpoint is bounded by `W+2Q(W)+1`. This is a direct local invariant, not a repeated composition of the previous checkpoint's polynomial bound. No factor involving the number of native or reserve-loop steps appears.

Relations may have polynomially many tuples, but their arities and number are fixed. The later binary encoding explicitly pays for those tuples rather than treating them as free storage.

## 9. Binary/two-dimensional compiler: checked, accepted

I read the complete companion compiler, in addition to the separate compiler specialist's audit. Its critical invariant is a fresh incidence representation with one D-vertex per source object, one incidence vertex per relation tuple, and finitely many administrative markers.

The following points are correct:

1. The first marker is the quotient of all off-diagonal input pairs, preserving each diagonal atom. Additional markers are created similarly. This handles binary inputs of size two without pretending a 2D initializer can create n+3 objects in its first step.
2. Tagged copies make the factors of all products disjoint, preventing a new product tuple from colliding with an old diagonal copy.
3. Source tuples and relation-candidate tuples are formed only from designated logical-domain-derived sorts. They are not products of the full accumulated encoded universe.
4. Every source Härtig quantifier is relativized to D, which has exactly one vertex per logical element. This avoids invalid naive substitution of tuple-valued variables into unary Härtig.
5. Source equality is imposed by an actual quotient. Candidate-to-domain incidence edges are saturated when strict congruence semantics require it.
6. A second quotient deduplicates relation incidences after the logical quotient. This cleanup is necessary and is present.
7. All old logical vertices, old incidences, tuple products, and unused scratch sorts are discarded. The next boundary represents only the new source state.
8. Optional equivalence closure is a domain-preserving FO loop and cannot increase the maximum universe.
9. Finite source/control phases can be combined into one fixed 2D transition; unary/zero-arity administrative data can be encoded with binary diagonal predicates on permanent markers.

For maximum source universe S, source dimension bound K, and maximum source arity r at least two, each macrostep has at most `C(1+S)^(Kr)` vertices. At its end the stronger canonical boundary bound depends only on the new source domain. Thus no exponent compounds with runtime. Composing this estimate with the HF bound gives the desired `C_P W^(d_P)`.

## 10. Scope restrictions that must stay visible

- The source is the fixed Rossman/GKPS term model, not an arbitrary machine formalism merely equivalent to CPT in polynomial time.
- No primitive powerset, choice, or succinct integer operation is included.
- Raw input is unary/binary for the simultaneous binary-state/2D-initialization theorem. A high-arity relation can contain too much information to survive a lossless first binary 2D state; pre-encoding changes input size and must be accounted for.
- Input size at least two is needed for parameter-free marker creation. Subsequent source logical domains may be empty or singleton because markers persist in the compiled target.
- The proof controls maximum universe, and after fixed-arity incidence encoding also polynomially related explicit relational storage. It is not a general Turing-space theorem.
- The lower-bound transfer is conditional on the separate interpretation-program lower bound. This audit does not establish that bound or its support/expander ingredients.

## 11. Independent exact tests executed

`check_raw_descriptors.py` uses actual 4-coordinate descriptor tuples over a five-object base with two atoms. It does not begin with one already-canonical descriptor per object. Across three batches it checked:

- 1,875 raw descriptors;
- 1,171,875 descriptor-equality pairs against independent HF denotations;
- quotient images and saturated invariance of membership and inclusive closure;
- garbage collection for every resulting root;
- preservation of old relation data and well-defined new result tables;
- nine Card cases where every newly requested ordinal already exists outside Ord, so extension must reuse old nodes;
- the n=2 initializer's five intended quotient classes.

All checks passed. Exact output is in `raw_descriptor_test_results.json`. These tests evaluate the semantic formulas as finite Python predicates; they do not constitute generated FO syntax execution or an asymptotic certificate.

## Final assessment

The core theorem and its resettable binary/2D normalization can be used as proved mathematical reductions under the stated hypotheses. No corrective change is required for validity. The most useful editorial additions are the explicit peak-versus-instantaneous distinction, a precise prefix endpoint convention, and the finite phase/padding explanation supplied above. The high-arity and small-input qualifications must not be dropped in downstream claims.
