# Source and prior-art notes

## Primary biological source

Shalini Dimri-Wagh et al., “Aged differentiated cells reverse into native stemness-like state by niche cytokines to sustain lifelong homeostasis and tissue repair,” *Nature Communications* 17, 5743 (2026), [DOI 10.1038/s41467-026-72331-w](https://doi.org/10.1038/s41467-026-72331-w), [publisher article](https://www.nature.com/articles/s41467-026-72331-w). Source-data workbook: `work/agents/c12_cellstate_control/sources/41467_2026_72331_MOESM11_ESM.xlsx`, SHA-256 `e74d84dea486e151c31c55ecdab34533d34e597d366289cace5e79c533601adc`.

Relevant publisher text: Fig. 5 caption says rescue treatment used CCL2+IGF1, CXCL10+CXCL16, or all four factors at day 25, with (n=4) biological replicates and two-tailed unpaired Student t tests ([publisher Fig. 5 caption and results](https://www.nature.com/articles/s41467-026-72331-w#Fig5)). Methods say each factor is 100 ng except IGF1 5 ng, combinations halve the factor concentrations, injections continue every other day through day 10, and eyes are collected at day 25 ([publisher methods](https://www.nature.com/articles/s41467-026-72331-w#Sec23)). The discussion specifically proposes that CCL2 may amplify repair by recruiting additional monocytic cells ([publisher discussion](https://www.nature.com/articles/s41467-026-72331-w#Sec21)). The natural-regeneration lineage tracing, up-to-six-month homeostasis, and repeat-injury tests are reported separately from the cytokine rescue arm.

The exact Fig. 5p workbook range is `Figure 5!C55:G63`; observations are columns C:F and the stored p-value is in G. The workbook provides no individual mouse/eye IDs or batch fields. The independent read-only extractor and calculations are `../code/hostile_audit.py` and `../hostile_audit_results.json`.

## Interaction-model prior art

1. Lederer, Dijkstra, and Heskes, “Additive Dose Response Models: Defining Synergy,” *Frontiers in Pharmacology* 10:1384 (2019), [DOI 10.3389/fphar.2019.01384](https://doi.org/10.3389/fphar.2019.01384), [full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC6901947/). This primary methodological article states that non-interaction requires a selected null reference, describes Bliss as statistical independence and expresses the usual formula on a bounded increasing effect scale. It contrasts Bliss with Loewe additivity and other null-surface models. The present single-dose/one-combination design does not identify a response surface.

2. Demidenko and Miller, “Statistical determination of synergy based on Bliss definition of drugs independence,” *PLOS ONE* 14(11):e0224137 (2019), [DOI 10.1371/journal.pone.0224137](https://doi.org/10.1371/journal.pone.0224137), [full text](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0224137). This primary method paper gives the probabilistic interpretation of Bliss using cell/organism survival fractions, extends it to replicate data, and emphasizes dose-response information and uncertainty. It supports describing the current score as a conditional assay-scale Bliss calculation, not as a direct probability of a cell becoming a stem cell.

## Evidence classification

- Primary-source facts and raw values: source-reported.
- Row extraction, means, dose-ceiling algebra, transformation examples, uncertainty propagation, and additive-MFI construction: internally reconstructed in this audit.
- Monotone dose response, correct biological MFI effect scale, independence mechanism, and distinct replicate units: not verified.
- Formal synergy, mechanism, cell-state conversion by the rescue regimen, functional stemness, novelty, and external validation: not established.
