# Restart note

## Task and boundary

Independently attack the C12 quantitative IGF1+CCL2 marker interaction. The claim concerns Fig. 5p day-25 K15-GFP MFI only. No parent files were edited. The official source workbook was opened read-only, SHA-256 verified against the parent note, and source rows C55:G63 extracted. No wet-lab action, clinical recommendation, or external message was made.

## Highest-value conclusion

The exact source sample means exceed the declared linear-gap full-dose Bliss ceiling by 269,188.98 MFI. A covariance-aware delta contrast gives conditional evidence under an independent normal biological-replicate model (SE 60,797; df 5.09; approximate p=.00655; 95% t interval [113,755,424,623]). The result is not model-free. It depends on treating continuous MFI gap recovery as a bounded effect and the control mean as a maximum. A strictly monotone bounded exponential response score with a different, unmeasured asymptote reverses the sign. A monotone additive-MFI model with unobserved half-dose singles reproduces the combo mean exactly.

## Exact source and artifacts

- Source workbook: `../c12_cellstate_control/sources/41467_2026_72331_MOESM11_ESM.xlsx`
- Source cells: `Figure 5!C55:F63` (four values per arm), p-value column G, no sample IDs.
- Hash: `e74d84dea486e151c31c55ecdab34533d34e597d366289cace5e79c533601adc`.
- Reproducer: `code/hostile_audit.py`; outputs `hostile_audit_results.json`.
- Full derivation and limitations: `proofs/interaction_attacks.md`.
- Source/prior-art ledger: `sources/NOTES.md`.
- Claims ledger: `CLAIMS.json`.
- Worker verdict: `FINAL_REPORT.md`.

## Remaining gate

Do not escalate to cell-state conversion, mechanism, or functional stemness. If the parent retains the interaction line, preserve the exact phrase “conditional supra-Bliss excess on the linear K15-GFP MFI-gap scale,” note n=4 and unverified biological-unit independence, and state the exact half-dose Bliss prediction. Same-dose monotherapy values are missing, so the present full-dose calculation is only an upper-bound test under monotonicity.

## Failure log

- The bundled Python environment does not include SciPy. The main extractor, delta propagation, and bootstrap use the bundled Python plus the `openpyxl` read-only reader. R base was used for the Student-t critical value and to confirm the workbook's pooled two-group p-values. No data changed as a result.
- A first R command that wrapped vectors in a nested list failed because R flattened the list; it was corrected to use explicit vectors. The corrected outputs were checked against the source cells; no scientific result relies on the failed command.
- The system Python lacked `openpyxl`; the required bundled Python runtime reran the read-only extractor successfully. `code/r_t_checks.R` then independently reproduced the delta-method intervals and seven source-vs-clodronate p-values (maximum absolute discrepancy 8.7e-19). No workbook or parent artifact was modified.
