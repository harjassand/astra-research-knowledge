# Hostile audit: the Fig. 5p IGF1–CCL2 interaction score

## Frozen interface and source extraction

The question is whether the half-dose IGF1+CCL2 group in Dimri-Wagh et al. exceeds a defined non-interaction prediction for day-25 K15-GFP mean fluorescence intensity (MFI). It is not a test of lineage conversion or stem-cell function.

The official source-data workbook is `work/agents/c12_cellstate_control/sources/41467_2026_72331_MOESM11_ESM.xlsx`, SHA-256 `e74d84dea486e151c31c55ecdab34533d34e597d366289cace5e79c533601adc`. `Figure 5` rows 55–63 contain Fig. 5p; columns C:F are four values per arm and G contains the source p-value. In particular:

| Arm | Source cells | Four source values | Mean MFI |
|---|---|---|---:|
| Vehicle control, (U) | C55:F55 | 5,090,507; 4,984,949; 5,184,033; 5,051,615 | 5,077,776.00 |
| Clodronate, (L) | C56:F56 | 2,372,806; 2,428,438; 2,020,320; 2,135,245 | 2,239,202.25 |
| IGF1 full dose, (I) | C60:F60 | 4,341,047; 4,180,586; 4,233,750; 4,115,784 | 4,217,791.75 |
| CCL2 full dose, (C) | C61:F61 | 4,476,359; 4,413,795; 4,315,991; 4,567,152 | 4,443,324.25 |
| IGF1+CCL2 half dose, (M) | C62:F62 | 5,162,374; 5,018,172; 5,275,341; 5,163,110 | 5,154,749.25 |

The article specifies (n=4) biological replicates and says the Fig. 5 measurements used two-tailed unpaired Student t tests. The workbook has no mouse, eye, litter, batch, or replicate IDs. Thus, the independent-animal unit and any within-mouse clustering cannot be checked from the supplied table. The source p-value in G62 is (1.9235021\times10^{-7}). Recomputing pooled unpaired t tests of every treatment arm against clodronate reproduces all seven stored Fig. 5p p-values; G62 therefore supports combo-versus-clodronate recovery, not combo-versus-Bliss interaction. The figure caption does not label a p-value as an interaction test.

The paper reports the individual doses as IGF1 5 ng and CCL2 100 ng per eye, with every factor halved in a combination; the rescue endpoint is collected on day 25. It also says CCL2 may recruit additional monocytes. That supplies a plausible mediated pathway and weakens any interpretation of the two factors as independent cell-autonomous actions. The paper's lineage-tracing, six-month maintenance, and repeated-wound evidence belongs to a separate natural-regeneration arm, not this cytokine-rescue group.

## Exact linear-gap Bliss algebra

Let (D=U-L=2{,}838{,}573.75), and define the stated gap-recovery score (e(y)=(y-L)/D). From the five means above,

\[
e_I=0.69703650,\qquad e_C=0.77648925,\qquad e_M=1.02711688.
\]

The full-dose Bliss prediction is

\[
B_I=1-(1-e_I)(1-e_C)=0.93228440.
\]

If half-dose single-agent effects are nondecreasing and lie in ([0,1]), then (e_{I,1/2}\le e_I) and (e_{C,1/2}\le e_C); because (B(a,b)) is increasing on this square, the half-dose independent-action response cannot exceed (B_I). On the declared linear gap scale this gives the raw-MFI ceiling

\[
Y^* = L+D B_I
    = U-\frac{(U-I)(U-C)}{U-L}
    = 4{,}885{,}560.27.
\]

The observed pair mean is 5,154,749.25, or 269,188.98 MFI above (Y^*). Its uncapped excess is (0.0948325) of the control–clodronate gap. If the pair score is forcibly capped at 1, the displayed surplus is (1-B_I=0.0677156), or 6.77 percentage points. The cap removes the observed 77,000-MFI overshoot of the vehicle-control mean; the vehicle-control mean is a reference, not a demonstrated physical maximum.

This is a valid conditional inequality on the declared scale. It requires monotonicity of the underlying single-agent mean dose responses, population quantities represented by these small sample means, and a linear control-minus-clodronate MFI gap as the effect variable. It does not follow from the measured source data alone that those assumptions describe biology.

## Scale and gauge attacks

**Affine MFI gauge.** For one common positive gain and offset, (Y'=aY+b) with (a>0), the normalized score is unchanged:

\[
\frac{aY+b-(aL+b)}{aU+b-(aL+b)}=\frac{Y-L}{U-L}.
\]

Thus, a global instrument gain or offset is not the vulnerability. Nonlinear detector response, group-specific acquisition differences, the chosen response scale, and the fact that the sample estimates do not identify the biological ceiling remain vulnerabilities.

**Fixed-control-endpoint invariance.** For any strictly increasing transformation (g), if one transforms the group means and then renormalizes using the same two endpoints, (e_g(Y)=[g(Y)-g(L)]/[g(U)-g(L)]), the sample combo still has (e_g(M)>1), because (M>U). The two full-dose singles have scores below 1, so their Bliss ceiling is below 1. Capping (e_g(M)) at 1 still leaves a positive point-estimate surplus. Consequently, no monotone transformation can reverse the *sign* while the observed control is fixed as the response maximum and the pair mean remains above it. It can change the margin substantially.

For example, applying the transformation to each replicate before averaging gives capped surplus 0.06772 on the linear scale, 0.03675 on the log-MFI scale, and 0.05058 on the square-root scale. The sign survives this source sample because all four combo replicate values exceed the corresponding sorted control values. These are sensitivity calculations, not evidence that one of these scales is biologically correct.

**Exact monotone scale counterexample when the control is not declared the maximum.** Define the bounded increasing score

\[
h(y)=1-\exp\!\left(-\frac{y-L}{U-L}\right),\qquad y\ge L.
\]

It maps the clodronate mean to 0 and has a response asymptote of 1, but maps the observed control to (h(U)=0.63212). Using transformed group means gives (h(I)=0.50194), (h(C)=0.53998), and (h(M)=0.64196). Its full-dose Bliss ceiling is (1-(1-h(I))(1-h(C))=0.77088), so the observed combo is **0.12892 below** the ceiling. This is an exact sign reversal under a monotone bounded response gauge. Its limitation is decisive: the asymptotic response ceiling is unmeasured and the transform is not an empirically justified mapping from fluorescence to a biological event. If the transform is rescaled so that (h(U)=1), then (h(M)>1) and the positive capped sign returns. The example therefore disproves scale-free synergy, not the specific linear-gap calculation.

The sign-reversing result is not an isolated choice of a mathematical null either. On raw MFI, an additive-increment no-interaction model can match the observed pair exactly with monotone, unobserved half-dose responses. Assign a half-dose IGF1 increment of 1,000,000 MFI and a half-dose CCL2 increment of 1,915,547 MFI above clodronate. Both are below their observed full-dose increments (1,978,589.5 and 2,204,122 MFI), and

\[
L+1{,}000{,}000+1{,}915{,}547=5{,}154{,}749.25=M.
\]

Piecewise-linear nondecreasing single-agent dose curves can pass through these half- and full-dose values. Thus, the same observed means are exactly non-interactive under additive MFI increments. The unmeasured half-dose single-agent means are what distinguish this model from an actual factorial interaction contrast.

The transformation counterexample is deliberately not presented as the right response scale. It establishes that MFI alone does not choose a probability or a natural upper bound. Bliss's usual product rule has its direct event-independence interpretation when the effect is a fractional probability-like event or survival fraction. K15-GFP MFI is a continuous signal that can change through expression per cell, cell number, fluorescence acquisition, or mixtures of cells. Treating (e) as a bounded event probability is an additional model, not a consequence of the assay.

## Covariance-aware finite-sample calculation

To avoid treating normalized estimates as independent, define the raw-MFI contrast against the full-dose upper bound directly:

\[
R=M-U+\frac{(U-I)(U-C)}{U-L}.
\]

This is exactly (M-Y^*), so it accounts for the shared (U) and (L) estimates once rather than comparing separate normalized values while ignoring their covariance. At the source means (R=269{,}188.98) MFI. The delta-method gradient in the order ((M,U,L,I,C)) is

\[
\left(1,
-1+\frac{2U-I-C}{D}-\frac{(U-I)(U-C)}{D^2},
\frac{(U-I)(U-C)}{D^2},
-\frac{U-C}{D},
-\frac{U-I}{D}\right).
\]

Using the five observed sample variances, (n=4) for each unpaired arm, and independent approximately normal arm means gives (SE(R)=60{,}797), Satterthwaite (df=5.09), (t=4.43), and approximate two-sided (p=0.00655). The corresponding (t)-interval is about [113,755, 424,623] MFI. A 300,000-draw, group-wise empirical bootstrap gives [164,641, 369,839] MFI at its 2.5% and 97.5% empirical quantiles. Because there are only four values per arm, this bootstrap resamples the observed four-point support and cannot certify tail behavior or independence of biological units. Both intervals are conditional on treating the four rows per arm as independent biological replicates. The raw pair-minus-control contrast alone is 76,973 MFI with a pooled two-sample (p=0.295); the pair's mean being above control is not separately established.

The uncertainty calculation supports a real *sample-scale excess over this specified linear-gap full-dose Bliss ceiling under the stated group model*. It does not cure the response-scale problem or prove a cell-state interaction. Source p-values are tests against clodronate, not tests of (R=0).

## Pair specificity and all-four arm

On the same untransformed gap scale, CXCL16+CXCL10 is 0.33063 against its full-dose ceiling 0.34673, an excess of (-0.01610). The IGF1+CCL2 and CXCL16+CXCL10 excesses differ by 0.11093, but a covariance-aware first-order comparison using all shared controls and arm variances has (SE=0.05583), (t=1.99), Welch–Satterthwaite (df\approx9.92), and two-sided (p\approx0.075). Thus, “one pair positive and one pair not positive” is a descriptive contrast; the data do not establish statistically different pair interaction effects. The all-four arm shares the same half doses of IGF1 and CCL2 but has a mean 132,806 MFI below the two-factor pair (SE 68,208, pooled (t=1.95)); it is an informative point estimate about adding the other two factors, not a half-dose single-agent control and not evidence of pair specificity.

## Decisive remaining prediction and evidence boundary

Under the specific linear-gap Bliss null and monotone single-agent dose curves, a true population combination mean must be no greater than 4,885,560 MFI at the studied half doses. The source sample estimate is 5,154,749. A paired-doses dataset that measured both individual factors at exactly the half doses would replace the conservative full-dose ceiling with the actual same-dose Bliss prediction. The decisive statistical quantity would be the treatment-arm mean contrast to that same-dose prediction, with its shared baseline and replicate-level uncertainty propagated. This states a falsifier; it is not an experiment performed here or an operational wet-lab recommendation.

Even a reproducible positive contrast would remain a scale- and null-specific marker interaction. The current data do not identify whether CCL2 recruits myeloid cells, acts on epithelium, or influences another niche component, and the K15-GFP rescue group has no lineage-resolved long-term function result. No novelty, mechanism, or stem-cell-function claim is supported by this audit.
