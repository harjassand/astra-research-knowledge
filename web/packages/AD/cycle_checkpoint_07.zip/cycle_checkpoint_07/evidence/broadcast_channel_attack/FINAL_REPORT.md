# Bounded-Holevo broadcasting: independent channel attack

## Verdict

I found no growing family with bounded total Holevo information, vanishing two-output marginal broadcast error, and EB reconstruction error bounded below. I also found no counterexample to a dimension-free Dirichlet lift. The unrestricted implication remains **open** after the current N93 reductions.

The most useful exact calibration is the universal (1\to2) qudit cloner. Its self-compatible, tracial, positive self-adjoint marginal Φ has an explicit Haar measure-and-prepare EB comparison Ψ with

\[
I-\Psi=2(I-\Phi)
\]

on the full operator space. Twirling shows no EB comparison can use a constant below 2. Thus the proposed factor 2 is sharp on a growing-dimensional family; this does **not** establish it for arbitrary self-compatible maps.

I independently reconstructed the dimension-free power-range estimate that is weaker than the proposed lift but follows directly from self-compatibility: all operators in the range of \(\Phi^m\) have pairwise normalized-Hilbert-Schmidt commutators at most

\[
\frac{2}{\sqrt{m+1}}+\frac{4}{m+1}.
\]

This does not yet give one EB map close to \(\Phi^m\) on the entire unit ball. That uniform EB rounding step is the remaining load-bearing gap.

## Exact interface and the reduction that remains

The source target uses one full-domain CPTP broadcaster \(B_n:\mathcal B(H_n)\to\mathcal B(H_n\otimes H_n)\) for all states in an experiment \(E_n\). Both marginal half-trace errors enter \(b_2(E_n)\); \(e_{EB}(E_n)\) optimizes over one full-domain EB channel. The capacity is

\[
C(E_n)=\sup_{\text{finite priors }p}\chi(p;E_n),
\]

in nats, counting the complete state ensemble and every input-dependent retained register. Small pairwise fidelity gaps or low accessible information do not substitute for this total Holevo bound.

N93 reduces bounded capacity to a faithful reference and then to a tracial problem. For \(C(E)\le C\), an information center \(\sigma\) can be chosen with \(D(\rho\|\sigma)\le C\) for every promised state and \(\sigma\) included. The imported substate theorem uses

\[
M_{sub}=(1-\eta)^{-1}\exp((C+\ln2)/\eta).
\]

With \(\eta=\epsilon^2/8\), the common convex smoother has, after normalization, likelihood bound \(\widehat\rho\le 2M_{sub}\sigma\), is within \(\epsilon\) in half trace distance, and fixes \(\sigma\) exactly. For \(U=2M_{sub}\), dilution by \(a=\theta/(U-1)\) makes

\[
(1-\theta)\sigma\le (1-a)\sigma+a\widehat\rho\le(1+\theta)\sigma.
\]

At \(\theta=1/2\), this has the requested \([\sigma/2,3\sigma/2]\) sandwich. The information cost is a bound on the **whole** ensemble, not one state at a time. The constants are expensive: \(M_{sub}\) grows exponentially in \((C+\ln2)/\epsilon^2\), so the reduction is qualitative unless its smoothing error is fixed first.

The compatible-smoothing transport bound and finite flagged log-bin construction preserve one common decoder and exact reference normalization. In the latter, put \(S_0=\sqrt{\sigma}\), let \(C_0\) satisfy \(\rho\le C_0\sigma\) for every promised state, set \(M_{cent}=\sqrt{C_0}\), and define

\[
X_\rho=\sigma^{-1/2}(\sqrt\sigma\,\rho\,\sqrt\sigma)^{1/2}\sigma^{-1/2},
\qquad \Xi=\sup_{\rho\in E}\|[X_\rho,S_0]\|_2.
\]

The polar estimate gives \(\Xi\le2\sqrt{2M_{cent}\sup_\rho\Delta(\sigma,\rho)}\), where \(\Delta(\sigma,\rho)=\|\sqrt\sigma\sqrt\rho\|_1-\operatorname{Tr}(\sqrt\sigma\sqrt\rho)\). The N46 two-state broadcasting-to-affinity-gap bound makes this \(\Xi\to0\) when the broadcast error tends to zero. The finite flagged encoder/decoder has at most \(d+1\) flags, but exact reference spectra, eigenvalue ordering, preparations, and finite-bit evaluation are still supplied/charged data. Its centralization error is

\[
\epsilon(t,\Xi)=4\sqrt{3M_{cent}\Xi/t}+8t,
\]

so \(t=\Xi^{1/3}\) gives \((4\sqrt{3M_{cent}}+8)\Xi^{1/3}\). Combining the imported N46 modulus of order \(\sqrt{b\log(1/b)}\) yields the reported reduction rate \(O((b\log(1/b))^{1/12})\) for fixed \(C_0\), with constants depending on the smoothing. This is a reduction, not an efficient apparatus construction or an EB reconstruction theorem.

After these steps the unresolved interface is: finite tracial algebras \((A_n,\tau_n)\), with \(\Phi_n\) UCP, trace preserving, positive self-adjoint on \(L^2(\tau_n)\), and self-compatible via a joint UCP map \(J_n\) with both marginals \(\Phi_n\); a promised set of states \(\rho_H=I+H\), \(H=H^*\), \(\tau(H)=0\), \(\|H\|_\infty\le1/2\), includes \(I\), and

\[
r_n=\sup_H\|\Phi_n(H)-H\|_{1,\tau_n}\to0.
\]

The question is whether one EB map reconstructs all promised states uniformly, independent of dimension and family size. The proposed sufficient lift is to find a single canonical measurement map \(\Psi\) such that \(I-\Psi\preceq c(I-\Phi)\) with universal finite \(c\). N93 shows that failure of the specific \(c=2\) statement would not by itself refute the weaker qualitative target.

For this family, the exact collective witness is

\[
q(E)=\inf_M\sup_H\langle H,(I-\Psi_M)H\rangle_\tau,
\]

which equals a max-prior convex roof of **joint** pure-state variances with one common POVM. The transfer bounds are \(e_{EB}(E)\le\tfrac12\sqrt{q(E)}\) and, for the sandwich, \(q(E)\le 8\theta e+6\theta^2\sqrt{2e}\). Thus a dimension-free \(q(E)\to0\) bound is enough and has a converse. Separate measurements optimized for each \(H\) do not give this common-measurement statement.

## High-dimensional exact channel calibration

Let \(P_+=(I+F)/2\) project onto the symmetric subspace of \(\mathbb C^d\otimes\mathbb C^d\), and set

\[
\mathcal B_d(\rho)=\frac{2}{d+1}P_+(\rho\otimes I)P_+.
\]

This is a CPTP, swap-symmetric channel. Expanding \(P_+\) and tracing either output gives

\[
\Phi_d(\rho)=\frac{(d+2)\rho+\operatorname{Tr}(\rho)I}{2(d+1)}
=\lambda_d\rho+(1-\lambda_d)\frac{I}{d},\qquad
\lambda_d=\frac{d+2}{2(d+1)}.
\]

For normalized trace \(\tau=\operatorname{Tr}/d\), its Heisenberg action is the same formula; it is UCP, trace preserving, positive self-adjoint on \(L^2(\tau)\), and self-compatible by \(\mathcal B_d\).

The covariant Haar measurement \(d|\psi\rangle\langle\psi|\,d\psi\), followed by preparation of \(|\psi\rangle\langle\psi|\), gives

\[
\Psi_d(X)=\frac{X+\operatorname{Tr}(X)I}{d+1},\qquad
\mu_d=\frac1{d+1}\quad\text{on traceless }X.
\]

Therefore on the identity sector both Dirichlet operators vanish, and on every traceless direction

\[
I-\Psi_d=\frac{d}{d+1}I,
\quad I-\Phi_d=\frac{d}{2(d+1)}I,
\quad\frac{I-\Psi_d}{I-\Phi_d}=2.
\]

For the lower bound against any EB map admissible in the proposed Loewner comparison, average it over unitary conjugations. EB and the Loewner inequality are preserved because \(\Phi_d\) is depolarizing. The twirled channel has one traceless eigenvalue \(\mu\). Its normalized Choi state is isotropic; separability implies overlap with a maximally entangled vector at most \(1/d\), hence \(\mu+(1-\mu)/d^2\le1/d\), or \(\mu\le1/(d+1)\). Testing a traceless direction then forces \(c\ge2\). The primary universal-cloning theorem independently supplies the optimal shrink factor \(\lambda_d\) [Keyl–Werner, Sec. II, Eq. (3) and the one-site factor/Eq. (Theorem 1)](https://arxiv.org/html/quant-ph/9807010v1).

This family also separates capacity from the broadcasting premise. For the entire bounded likelihood ball \(\rho_H=(I+H)/d\), \(\|H\|_\infty\le\theta<1\), \(\tau(H)=0\), the reference is \(I/d\) and

\[
D(\rho_H\|I/d)=\tau[(I+H)\ln(I+H)]\le\ln(1+\theta).
\]

Thus \(C(E)\le\ln(1+\theta)\), uniformly in \(d\). But twirling any proposed broadcaster for this full ball gives a depolarizing marginal. Keyl–Werner's optimality forces its traceless shrinkage to be at most \(\lambda_d\); a balanced-sign \(H\) has \(\|H\|_1/d=\theta\) for even \(d\). Consequently

\[
b_2(E)=\frac{\theta}{2}(1-\lambda_d)=\frac{\theta d}{4(d+1)}\longrightarrow\frac\theta4,
\qquad
e_{EB}(E)=\frac{\theta}{2}\left(1-\frac1{d+1}\right)\longrightarrow\frac\theta2.
\]

So bounded Holevo alone is insufficient, while this valid self-compatible channel does not meet \(b_2\to0\). The exact rational calibration for dimensions 2 through 64 is in [cloner_calibration.json](cloner_calibration.json); it checks the formulas, not the theorem.

## Independent operator route and its limit

Assume the tracial interface above and write \(\Phi\) for the self-adjoint positive UCP map. If a promised likelihood is \(I+\theta A\), with \(A=A^*\), \(\|A\|_\infty\le1\), the physical full trace residual \(r_A=\|\Phi(I+\theta A)-(I+\theta A)\|_{1,\tau}\) obeys

\[
\langle A,(I-\Phi)A\rangle_\tau\le r_A/\theta,
\qquad
\|(I-\Phi)A\|_{2,\tau}^2\le\langle A,(I-\Phi)A\rangle_\tau.
\]

The second inequality is spectral calculus using \(0\le\Phi\le I\): \((1-\lambda)^2\le1-\lambda\). Kadison's inequality gives the state-weighted Schwarz defect

\[
\tau(\Phi(A^2)-\Phi(A)^2)
=\langle A,(I-\Phi^2)A\rangle_\tau
\le 2r_A/\theta.
\]

Let \(J:A\otimes A\to A\) be the joint UCP map and use a Stinespring isometry. The receiver embeddings \(A\otimes I\) and \(I\otimes C\) commute. Inserting \(I-VV^*\) between them bounds the commutator of their images by the square roots of their Schwarz defects. Replacing \(\Phi(A),\Phi(C)\) by \(A,C\), each at \(L^2\) displacement at most \(\sqrt{r/\theta}\), yields

\[
\|[A,C]\|_{2,\tau}\le(4+2\sqrt2)\sqrt{r/\theta}.
\]

The estimate is independent of dimension and applies to every pair in the promised family. Its limitation is that it is pairwise: it does not construct one measurement serving a growing set of observables.

There is a stronger all-range version for powers. Set \(A_m=\Phi^m(A)\). The spectrum of \(\Phi\) lies in \([0,1]\), so

\[
d_m:=\max_{0\le\lambda\le1}(1-\lambda)\lambda^m
=\max_{0\le\lambda\le1}(1-\lambda^2)\lambda^{2m}
=\frac{m^m}{(m+1)^{m+1}}\le\frac1{m+1}.
\]

The first maximum controls \(\|\Phi(A_m)-A_m\|_2\); the second controls \(\tau(\Phi(A_m^2)-\Phi(A_m)^2)\). Applying the same joint-map/Stinespring estimate to \(A_m\otimes I\) and \(I\otimes C_m\), then paying at most \(4d_m\) to replace their images, proves

\[
\sup_{\|A\|_\infty,\|C\|_\infty\le1}
\|[\Phi^m(A),\Phi^m(C)]\|_{2,\tau}
\le2\sqrt{d_m}+4d_m
\le\frac2{\sqrt{m+1}}+\frac4{m+1}.
\]

This is the useful weaker squared-displacement/commutator consequence. The copy tree makes \(\Phi^m\) compatible with \(2^m\) receivers and telescoping gives residual at most \(mr\). To finish, one still needs a uniform rounding statement such as

\[
\beta_m:=\sup_{A,\tau,\Phi}\inf_{E\in EB_\tau}
\sup_{\|X\|_\infty\le1}\|E(X)-\Phi^m(X)\|_{1,\tau}\longrightarrow0.
\]

No such theorem is established here. Pairwise approximate commutation, finite-set approximation in an abelian ultraproduct, or fixed-point projection is not the missing uniform unit-ball bound. The known slow-classical-mode counterexamples specifically rule out replacing \(\Phi\) by its exact fixed-point projection without a gap; the instrument/POVM constructions avoid this by building \(\Psi\) to retain those modes.

## N92/N93 blocker and the copy-ladder information cost

N92 proves a dimension-free factor-2 reconstruction when an instrument representation is actually supplied. For bistochastic Kraus operators \(K_y\), set \(L(A)=\sum_yK_yAK_y^*\), \(M_y=K_y^*K_y\), and let \(\Psi_M\) be the canonical measure-and-prepare channel. The instrument-append joint map, symmetrized over its two outputs, has marginal \(C=(L+\Psi_M)/2\). Petz recovery on **both** outputs gives \(\Phi=C^*C\), and the exact identity

\[
2(I-\Phi)-(I-\Psi_M)
=(I-L^*L)+(\Psi_M-\Psi_M^2)+\tfrac12(L-\Psi_M)^*(L-\Psi_M)\succeq0
\]

is valid without assuming \(L\) self-adjoint or \(\Psi_M\preceq\Phi\). This is an internally reconstructed, all-dimension class result; it is not a representation theorem for every self-compatible \(\Phi\). The N92 POVM/Lüders subcase and the qubit Pauli classes likewise do not close the unrestricted tracial problem. The recovery inequality used in Petz correction is established prior art: [Gao–Li–Marvian–Rouzé, Theorem 1.5 and Theorem 4.10](https://arxiv.org/html/2302.02341v1#S1.SS5.p1) give the \(\chi^2_{1/2}\)-loss lower bound by squared trace recovery error. No novelty is assigned to that inequality.

The old pure dyadic copy ladder is not a bounded-Holevo counterexample. For \(m=2^{L-1}\), \(H=\bigoplus_{j=0}^{L-1}\mathrm{Sym}^{2^j}(\mathbb C^d)\), and \(\rho_\psi=L^{-1}\bigoplus_j |\psi\rangle\langle\psi|^{\otimes2^j}\), the Haar mean has the maximally mixed state in each sector. Its Holevo information is

\[
\chi_{Haar}=\frac1L\sum_{j=0}^{L-1}\ln {d+2^j-1\choose 2^j}.
\]

Every state in the orbit has entropy \(\ln L\), and the Haar mean is maximally mixed within each symmetric sector. Since that mean lies in the finite-dimensional convex hull of the orbit, Carathéodory gives a finite prior with the same Holevo value. At the ladder's dimension choice \(d=Lm\), the top term alone gives \(\chi_{Haar}\ge(m/L)\ln L\), which diverges rapidly. This is a total-information failure even though its two-output marginal error is \(1/L\), its EB error tends to one, and its \(K_L\)-receiver marginal error tends to zero when \(\log K_L=o(L)\).

The later capacity-restricted analyses close those particular constructions: N67 gives the receiver law \(b_K=\min(\log_2K/L,1)+o(1)\), while N69 shows bounded-capacity pure ladders have \(e_{EB}=O(((C+1)/L)^{1/4})\); the mixed bosonic-cloner ladder has \(e_{EB}=O(\sqrt{C/L})\). Those are scoped theorem candidates in the supplied Astra package, not an unrestricted result.

## Evidence and remaining gate

Primary-source interfaces checked: Keyl–Werner establish the universal cloner action and optimum [full text, Sec. II](https://arxiv.org/html/quant-ph/9807010v1); Gao–Li–Marvian–Rouzé establish the Petz \(\chi^2_{1/2}\) recovery inequality above. The older exact no-broadcasting result only characterizes exact broadcastable families as commuting and supplies no dimension-free approximate modulus [Barnum et al.](https://arxiv.org/abs/quant-ph/9511010).

Internal source paths read:

- [N92 instrument-channel card](../measurement_inverse/astra/cards/N92-instrument-channel-classicalization.txt)
- [N93 bounded-Holevo gates card](../measurement_inverse/astra/cards/N93-bounded-holevo-gates.txt)
- [N61 copy-ladder card](../quantum_physics/sources/N61-broadcast-copy-ladder.txt)
- [N67 receiver-growth card](../quantum_physics/sources/N67-receiver-growth-classicality.txt)
- [N69 capacity-boundary card](../quantum_physics/sources/N69-capacity-classicality-boundaries.txt)
- [N93 cycle-4 collective-variance and factor-2 proof](sources/detailed_balance_broadcast_attack.txt)
- [N93 compatible-smoothing audit](../quantum_physics/sources/d-b4ddaa96b233287d.html)
- [N92/N93 concise source summaries](../quantum_physics/sources/N93-bounded-holevo-gates.txt)

The next decisive theorem is \(\beta_m\to0\) above, or a weaker channel-rounding estimate sufficient for one common EB map on the entire bounded likelihood family. The decisive counterexample would instead be a sequence of tracial positive self-adjoint self-compatible maps and likelihood families with bounded \(C(E_n)\), \(r_n\to0\), and \(\liminf e_{EB}(E_n)>0\). A failure of the specific factor-2 inequality is not enough.

All exact channels here are finite-dimensional mathematical constructions. The smoothing route requires the exact center/reference spectrum and normalizations; the N92 map requires the supplied Kraus/POVM representation; the general \(\beta_m\) decoder or efficient apparatus remains unconstructed. Formula checks do not establish external proof review or novelty.
