# Adversarial audit of the finite-family Holevo bridge

## Verdict

I find no mathematical defect in the finite-family theorem in `work/agents/broadcast_information_attack/CYCLE2_REPORT.md`. The replacement of the Brandão–Harrow output-entropy cap by the actual output Holevo information is valid for the singleton HJW measurement. The same-reference-marginal restriction, the one randomized Helstrom POVM, the EB minimax step, and full-domain Choi completion all check out. The stated error

\[
\max_x \tfrac12\|T(\rho_x)-\Psi(\rho_x)\|_1
\le \frac N2\sqrt{\frac{2C}{K}}
\]

has the claimed constants under the report's finite-dimensional and permutation-invariant-extension assumptions. It remains an N-dependent result; minimax does not remove N.

## Proof audit

Fix a prior \(p\), set \(\bar\rho=\sum_xp_x\rho_x\), and purify \(\bar\rho\) canonically on \(R\otimes A\). Apply the K-output broadcaster to A. The reference marginal is \(\omega_R=\bar\rho^T\), and the HJW POVM

\[
F_x=p_x(\bar\rho^{-1/2}\rho_x\bar\rho^{-1/2})^T
\]

on \(\operatorname{supp}\bar\rho^T\) produces the classical-quantum state

\[
\omega_{XB^K}=\sum_xp_x|x\rangle\!\langle x|\otimes\mathcal B_K(\rho_x).
\]

Thus \(I(X:B^K)_\omega=\chi(\{p_x,\mathcal B_K(\rho_x)\})\le\chi(\{p_x,\rho_x\})\le C\), by data processing for the physical channel \(\mathcal B_K\). No Choi reference is an extra output or charged register.

In the Brandão–Harrow chain proof, use their local operation \(\mathcal M_F:R\to X\) as the singleton operation and use arbitrary local POVMs \(\Lambda_1,\ldots,\Lambda_K\) on the receivers. Their Eq. (59) is

\[
\frac K2\inf_{\sigma\in\mathrm{Sep}(R:B)}\sup_{\Lambda}
\mathbb E_m\| (\mathcal E_m\otimes\Lambda)(\omega_{RB}-\sigma)\|_1^2
\le \sup_{\Lambda_1,\dots,\Lambda_K}I(\widetilde A:B_1\cdots B_K\mid M).
\]

For a singleton \(m\), \(\widetilde A=X\) is classical. Every comparison state constructed in the proof is

\[
\sigma_{RB}=\sum_iq_i\,\omega_R^{(i)}\otimes\omega_B^{(i)},
\]

where \(i\) is the outcome of measurements on the other receivers. Averaging over \(i\) recovers the unconditioned \(RB\) marginal, so the candidate is separable and satisfies both \(\sigma_R=\omega_R\) and \(\sigma_B=\omega_B\). Hence restricting the infimum to separable states with the fixed reference marginal is legitimate: at every chain step the proof supplies a candidate in that restricted set. Data processing gives \(I(X:Y_1\cdots Y_K)\le I(X:B^K)\le C\). Taking square roots yields one separable \(\sigma\) for which every single common receiver POVM has classical \(L^1\) discrepancy at most \(\epsilon=\sqrt{2C/K}\).

For this prior's corresponding EB channel \(\Psi_p\), write \(\Delta_x=T(\rho_x)-\Psi_p(\rho_x)\). Each \(\Delta_x\) is Hermitian and traceless. Choose a binary Helstrom POVM \(\{Q_{x,+},Q_{x,-}\}\), so \(\sum_z|\operatorname{Tr}(Q_{x,z}\Delta_x)|=\|\Delta_x\|_1\). The POVM

\[
\left\{Q_{j,z}/N : j\in[N],\ z\in\{+,-\}\right\}
\]

is one fixed measurement on B, chosen independently of the reference outcome x. The joint classical \(L^1\) discrepancy contains the nonnegative diagonal terms \(j=x\), and therefore

\[
\epsilon\ge \frac1N\sum_xp_x\|\Delta_x\|_1.
\]

This proves the Bayes half-trace bound \(\inf_{\Psi\in EB}\sum_xp_x\ell_x(\Psi)\le N\epsilon/2\). It does not reverse the output-label/test quantifiers for free; the factor N is exactly the cost of embedding N possibly different Helstrom tests into one common receiver POVM.

The Choi inversion is also sound. If \(\sigma=\sum_iq_i\alpha_i^R\otimes\tau_i^B\) and \(\sigma_R=\bar\rho^T\), define

\[
E_i=q_i(\bar\rho^{-1/2}\alpha_i\bar\rho^{-1/2})^T,
\qquad \Psi_p(X)=\sum_i\operatorname{Tr}(E_iX)\tau_i.
\]

Then \(E_i\ge0\), \(\sum_iE_i=P_{\operatorname{supp}\bar\rho}\), and the normalized Choi block satisfies
\[
\operatorname{Tr}_R[(F_x\otimes I)\sigma]=p_x\Psi_p(\rho_x).
\]
For every positive-prior x, \(\rho_x\) is supported on \(\operatorname{supp}\bar\rho\), because \(\bar\rho\ge p_x\rho_x\). Add the complementary effect \(I-P_{\operatorname{supp}\bar\rho}\) and any fixed output state to make a full-domain EB CPTP map. Zero-prior states need not be controlled by this particular \(\Psi_p\), since they do not contribute to Bayes loss.

Finally, \(EB(A:B)\) is compact and convex in finite dimension, and \(\ell_x(\Psi)=\tfrac12\|T(\rho_x)-\Psi(\rho_x)\|_1\) is continuous and convex in \(\Psi\), affine in the prior. Sion's minimax theorem gives

\[
\inf_{\Psi\in EB}\max_x\ell_x(\Psi)
=\sup_{p\in\Delta_N}\inf_{\Psi\in EB}\sum_xp_x\ell_x(\Psi)
\le \frac N2\sqrt{\frac{2C}{K}}.
\]

The optimizing channel is one full-domain EB map and controls every family member, including labels assigned zero mass by the least-favorable prior. This minimax step is valid but retains the factor N.

The recursive application is consistent as well: a symmetrized two-output broadcaster with common marginal T can be applied to each leaf, then the K outputs permuted uniformly. Every leaf marginal is \(T^t\); there are \(2^t-1\) channel invocations. Trace-norm contraction gives \(\tfrac12\|T^t(\rho_x)-\rho_x\|_1\le tb\), while Holevo data processing retains capacity at most C. Triangle inequality then gives the report's \(tb+(N/2)\sqrt{2C/2^t}\).

## Noncommuting bounded-capacity control

Capacity cannot bound the number of separated noncommuting states either. Let \(d=2^n\), take all signed nonidentity Hermitian Pauli operators \(P\) (so \(P^2=I\), \(\operatorname{Tr}P=0\)), and fix \(0<a<1\). Include \(I/d\) and set

\[
\rho_P=(I+aP)/d.
\]

For every finite prior, using \(I/d\) as a comparison reference gives

\[
\chi(\{p_P,\rho_P\})
=\sum_Pp_PD(\rho_P\|I/d)-D(\bar\rho\|I/d)
\le c(a):=\tfrac12[(1+a)\ln(1+a)+(1-a)\ln(1-a)].
\]

The family has \(N=2(d^2-1)+1\) states. Distinct Pauli perturbations are uniformly trace-separated: for distinct P,Q, \(\tfrac12\|\rho_P-\rho_Q\|_1\ge a/2\). Many pairs anticommute; for such a pair the distance is exactly \(a/\sqrt2\). Thus bounded Holevo does not control cardinality, packing, or the raw number of incompatible tests.

This example has an exact positive EB obstruction but is **not** a counterexample to the broadcasting implication. The finite Clifford group permutes signed nonidentity Paulis and is a unitary 2-design. Twirling any candidate EB channel over it cannot increase worst-family error and gives a depolarizing channel. The normalized isotropic Choi separability condition forces its traceless shrink factor to satisfy \(\lambda\le1/(d+1)\). Haar measure-and-prepare attains equality. Therefore

\[
e_{EB}(\{I/d,\rho_P\})=\frac a2\left(1-\frac1{d+1}\right)\longrightarrow a/2.
\]

Likewise twirling any two-output broadcaster gives a universal covariant cloner marginal. Keyl–Werner's 1-to-2 optimum is \(\lambda\le(d+2)/(2(d+1))\), attained by the universal cloner. Hence the exact best two-marginal broadcast error for this family is

\[
b_2(\{I/d,\rho_P\})=\frac a2\left(1-\frac{d+2}{2(d+1)}\right)
=\frac{ad}{4(d+1)}\longrightarrow a/4.
\]

This is a useful adversarial control: a dimension-free capacity-only packing bound is impossible even for a large noncommuting family; the broadcaster premise excludes this family because its error stays constant. The example supplies no way to replace N by a function of C and b that vanishes with b.

## Stronger route attempted and remaining obstruction

The exact algebra above identifies the necessary stronger step: control the average of state-dependent trace norms \(\sum_xp_x\|\Delta_x\|_1\), rather than the best common-measurement norm \(\sup_\Lambda\sum_xp_x\|\Lambda(\Delta_x)\|_1\). The former permits a different Helstrom measurement per label; the latter is what the local-measurement de Finetti chain bounds. In general their quantifiers differ. The balanced-sign family shows that bounded Holevo cannot replace N by a cardinality estimate, and the Pauli family shows even noncommuting trace packing may be exponentially large at fixed C. In both examples the broadcast premise behaves differently: the former is exactly EB, while the latter has a constant cloning error.

I did not derive a capacity-only modulus from a noncommuting-complexity parameter. A viable parameter would have to be small for the exactly commuting balanced-sign family, yet also control the incompatibility of all the label-specific Helstrom effects under the same K-output extension. Pairwise packing or the count of noncommuting pairs alone does not do this. The proposed stronger route remains **open**.

## Source checks and evidence boundary

- Brandão–Harrow, Theorem 1 proof, Eqs. (49)–(60), especially the fixed conditional-product comparison and final information cap: [primary text](https://arxiv.org/html/1210.6367), lines 481–527 in the current HTML rendering. The paper's Conjecture 5 explicitly reverses the measurement/expectation order; no such strengthening is used here.
- Barnum–Caves–Fuchs–Jozsa–Schumacher, two-state broadcasting theorem: [primary text](https://arxiv.org/html/quant-ph/9511010), lines 39–47.
- Keyl–Werner, optimal universal 1-to-2 cloning: [primary text](https://arxiv.org/html/quant-ph/9807010v1).
- The finite-family proof remains an internal reconstruction, not an external proof review. The Pauli-family equalities use the standard unitary-2-design twirl, isotropic-Choi separability criterion, and universal-cloning optimum; their role is an exact control, not a bounded-Holevo counterexample.
