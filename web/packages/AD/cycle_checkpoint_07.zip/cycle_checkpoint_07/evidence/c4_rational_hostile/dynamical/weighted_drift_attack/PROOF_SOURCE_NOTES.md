# Proof and source notes

## Primary source inspected

- `work/agents/permanence_hostile/endotactic_permanence.tex`, lines 51–78: finite labelled edge interface and essential-source endotacticity definition.
- Same file, lines 399–459: finite comparison set `D`, pointwise tolerance `E`, active family, box parameterization, uniform sign margin `H`, source-ratio estimate, and constants `L,M`.
- Same file, lines 461–508: weighted essential-source drift lemma and proof.
- Same file, immediately preceding the flux section: Lemma “Affine approximation” and Corollary “Uniform activity at a fixed finite family.” This corollary supplies one scale cutoff for all box points and all weakly active labels.

## Source convention and Lean predicates

For every direction `q`, `R_q` consists of edges with `q·ν_e ≠ 0`. An “essential reaction” means an edge in `R_q`. The “essential support” is the set of sources maximizing `q·y_e` among edges in `R_q`. All-endotacticity requires the negative sign only for essential reactions whose source belongs to this support; every tied maximizing source is included.

In `WeightedDrift.lean`, `InR D q e` is precisely essential-reaction membership. `EssentialEdge D q e` requires both `InR` and source maximality over all members of `R_q`; `AllEndotactic` applies the sign condition to every edge satisfying this combined predicate. This matches the source quantifiers while keeping edge labels separate. No tie is broken or suppressed.

## Reconstructed drift steps

1. **Finite margins.** The comparison index contains coordinate vectors, all labelled reaction vectors, and every ordered pair of source differences. `pointTolerance` is positive and no greater than `|r·v|/(2||v||₁)` for every comparison vector with nonzero `r·v`. `slopeMargin` is a positive finite reciprocal-sum margin no greater than `|r_j·v|/2` for every nonzero active-slope comparison.

2. **Uniform activity and sign control.** The `ActivityMargin` predicate explicitly quantifies over every scale below `hAct`, every exponent-box point, every active label, every comparison vector, and every nonzero slope product. `exists_activity_margin` derives it from caller-supplied `FullApproximation` by calling `N33Affine.exists_uniform_activity_cutoff`, then converting coordinatewise error to a finite dot-product bound. The active-slope sign and magnitude control therefore uses a uniform-in-`h` premise, made explicit and constructed by the exported conditional lemma.

3. **Minimum tier and ties.** Outside `StoichPerp`, some reaction has nonzero `r`-projection. Choose any minimum-source member of this finite set. Viewed in direction `−r`, it is on the essential support; all-endotacticity applies to every tied essential reaction there and forces positive `r·ν`. The chosen edge therefore has `r·ν ≥ 2H`.

4. **Negative reactions lie strictly above the minimum.** Every `r·ν_e<0` edge belongs to `R_{−r}` (it is an essential reaction). It cannot lie at a tied minimum `r`-source, because every essential reaction on that support has positive `r·ν`. Hence its source is strictly above the selected minimum tier. The active source-difference margin yields the monomial ratio bound `x^{y_e} ≤ h^H x^{y_*}`.

5. **Pointwise rates and finite loss budget.** The selected positive reaction contributes at least `κ x^{y_*}(2H)`. Every negative reaction is bounded in magnitude by `K ||ν_e||₁ h^H x^{y_*}` using `κ ≤ k_e ≤ K`; other positive terms are retained as nonnegative or discarded. Summing gives `x^{y_*}(2κH-KLh^H) ≥ κH x^{y_*}` under the explicit scale hypothesis `KLh^H≤κH`.

6. **Real and negative exponents.** On the positive domain, `x_i=h^{p_i}` gives `x^y=h^{p·y}` for every real vector `y`. The source budget is `M=∑_e ||y_e||₁`, so `p·y_*≤M`; since `0<h<1`, `x^{y_*}≥h^M`. No nonnegativity assumption on source exponents is used.

7. **Perpendicular case.** If every reaction vector is orthogonal to `r`, each summand in the projected field is zero, and the module proves exact zero followed by nonnegativity.

## Formalization boundary and open items

- The compiled file is `work/agents/c4_rational_hostile/formalization/dynamics/WeightedDrift.lean`. The exact source SHA-256 and compiler command/result are recorded in `REPORT.md`; signatures and `#print axioms` output are recorded in `WeightedDrift.kernel-audit.log`.
- `exists_activity_margin` assumes the caller provides `FullApproximation`; this module does not call a theorem constructing the full affine family. `weighted_drift_strict` assumes `ActivityMargin` and the explicit scale condition `K L h^H≤κH`.
- The module defines conservative finite budgets rather than using the manuscript's exact numerical minima/maxima: `H` and point tolerance come from reciprocal sums; `L` is the sum of reaction-vector norms; `M` is the sum of source norms. The needed comparison and floor inequalities are proved for these choices.
- No separate theorem choosing one scale threshold that guarantees `K L h^H≤κH` is exported. This is a remaining scale-selection bridge, not a hidden premise.
- The proof concerns the local drift inequality only. It does not establish trajectory, plateau, absorption, permanence, external validation, or priority claims.
