# Source notes

The audited source is `work/agents/permanence_hostile/endotactic_permanence.tex`, section “Compact plateaux and absolutely continuous trajectories,” lines 519–676. Its source hash is:

`bbecea61cd373a787920bb4484494114b7d616d5f20ee096cae3831487707e9c`

The two other repository copies checked were `work/agents/systems_metabolism/stochastic_safety/evidence/endotactic_permanence.tex` and `work/superseded_unfiltered_cycle_checkpoint_02/evidence/permanence_hostile/endotactic_permanence.tex`; all three had the same SHA-256 at the time of this audit.

Relevant cross-references in the source:

- Lines 51–64 define the finite diagram, positive class, and real-exponent positive-domain interface; lines 88–101 give the bounded measurable rates, Carathéodory solution notion, and local regularity assertion.
- Lines 336–456 contain the active-slope comparison and weighted endotactic drift lemma used by this section; they were treated as premises here, not re-proved.
- Lines 519–571 prove plateau compactness/interior containment.
- Lines 573–583 exclude neutral active slopes below the plateau within a class.
- Lines 585–616 state and prove the finite-minimum chain rule.
- Lines 618–676 state and prove monotonicity, strict growth, invariance, continuation, and conditional finite entry.

The chain-rule proof can be sharpened with “uniform over the finite active set” for the `o(v)` terms and an explicit restriction to interior times. The finite-entry proof can be sharpened by taking a limit from times strictly below the proposed endpoint. Neither clarification changes the conclusion.

## Prior-work memory used only as scope guidance

The memory registry states that the all-endotactic candidate uses finite systems and measurable rates in a fixed interval `κ≤k_e(t)≤K`, and warns that finite supplied-region certificates do not prove classwide absorption. This attack independently checked the local section but did not upgrade the full permanence status. See the cited memory entries appended in the parent-facing handoff if a memory citation is needed.
