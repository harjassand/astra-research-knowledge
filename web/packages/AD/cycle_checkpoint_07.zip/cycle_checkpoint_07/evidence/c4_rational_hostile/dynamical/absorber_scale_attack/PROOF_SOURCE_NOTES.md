# Proof and source notes

## Audited source

- Primary working source: work/agents/permanence_hostile/endotactic_permanence.tex.
- Scale-lift theorem proof: lines 681–737.
- Plateau construction and inner-box result: lines 524–571; especially K_h ⊂ int(B_sqrt(h)) at lines 537–569.
- Uniform increase, invariance, and finite-entry proposition: lines 618–676; especially the global-solution hypothesis on its finite-entry item (lines 634–639) and continuation/invariance argument (lines 649–675).
- Box/activity setup: lines 398–445; B_h = [h,h⁻¹]^d, exponent coordinates in [-1,1]^d, and coordinate sign threshold H.

## Dependency graph for this audit

1. A fixed positive representative and finite affine family give H > 0, a common small-scale cutoff, and h_P < 1.
2. The predecessor plateau proposition supplies compact convex K_h, c in K_h, and inner-box containment.
3. The predecessor entry proposition supplies global invariance from K_h, and finite entry for any global solution that remains in B_h.
4. The scale proof places each arbitrary initial state in its own initial plateau, then transports it through boxes to the fixed scale h_P.
5. Intersecting the fixed final plateau with c + S yields the classwise set, conditional on the affine-class invariance premise.

The only geometric fact needed between scales is B_b ⊂ B_a for 0 < a ≤ b < 1. Plateaux at different scales need not contain each other.

## Exact time and dependency ledger

- h_P: fixed before choosing x⁰ or the rate path; depends on the diagram/family, supplied rate interval, representative c, and the common predecessor cutoffs.
- h₀: chosen after x⁰; may be any 0 < h₀ ≤ h_P with |log h₀| > ||log x⁰||∞/H. It is not a rate-path choice.
- N: zero if h₀ = h_P; otherwise the stated dyadic ceiling. It can grow with x⁰; no uniform-in-class time is claimed.
- W_h: the manuscript's exact conservative bound (M_h - min over B_h of F_h)/(κ H h^M). It depends on the fixed scale and construction and supplied constants, but not the realized rate functions.
- Total: sum from j = 1 to N of W_hⱼ, with hⱼ = min(h₀^(1/2ʲ), h_P) for the corresponding capped recurrence. This is a finite sum of finite nonnegative terms.

## Scope caution

All conclusions above are conditional on the cited predecessor propositions and their hypotheses. This audit does not certify those propositions, the affine approximation lemma, external acceptance, or novelty.
