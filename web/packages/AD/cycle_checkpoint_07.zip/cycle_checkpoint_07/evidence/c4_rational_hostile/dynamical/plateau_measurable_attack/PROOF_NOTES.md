# Proof notes

Fix a scale `h` for which the prior activity and drift statements hold, and freeze all offsets at that scale. Write `g(u)=F_h(x(u))` and `A(u)=A_h(x(u))`.

## Finite-minimum chain rule

Each `g_lambda(u)=r_lambda·x(u)+b_lambda(h)` is absolutely continuous. A finite minimum of absolutely continuous scalar functions is absolutely continuous (iterating `min(a,b)=(a+b-|a-b|)/2`). At an interior time `u` where `x` is differentiable, each inactive label has a strictly positive gap at `u`; finiteness and continuity keep it inactive for all sufficiently small positive increments. For active labels, since the active set is finite,

`L_lambda(x(u+v)) = g(u) + v (r_lambda·x_dot(u)) + o(v)` as `v↓0`,

with the remainders uniform over active labels. Taking a finite minimum gives the right derivative

`D_+ g(u) = min_{lambda in A(u)} r_lambda·x_dot(u)`.

The AC scalar function `g` is differentiable a.e.; `x` is differentiable a.e. Intersect these full-measure sets. There, the right derivative equals `g'(u)`, proving the stated formula. At a tie, the left directional derivative is the maximum of the same active directional slopes and the right one is their minimum. If they differ, `g` is not differentiable at that time; this is consistent with, and explains, the a.e. qualification. At endpoints of the closed interval use only the available one-sided increment; endpoints have measure zero.

For example, `F(z)=min(z,-z)=-|z|` along `z(u)=u` has a tie at zero with active directional slopes `1` and `-1`. The right derivative is `-1`, the left derivative is `1`, and the ordinary derivative does not exist at zero. This is exactly the excluded null-time behavior, not a failure of the a.e. statement.

## Plateau geometry

Put `p(c)=log(c)/log(h)`. Since `||p(c)||_∞<H`, if an active slope at `c` had `r_i != 0`, the prior sign-margin statement for `v=e_i` would give `|p_i(c)|>=H`, a contradiction. An active slope is therefore zero. Its affine label is the constant `M_h=F_h(c)`, so `F_h(x)<=M_h` for every `x∈R^d`. Therefore

`K_h={F_h=M_h}= intersection_lambda {L_lambda,h>=M_h}`,

a closed convex set containing `c`. The fixed zero-slope label with value `M_h` is active at every point of `K_h`. If `x=X_h(p)∈K_h∩B_h`, the prior activity bound for this label gives `||p||∞<E(0)=1/2`, which is exactly `x∈int B_sqrt(h)`. Thus `K_h` misses `∂B_h`. If any `z∈K_h` were outside `B_h`, the segment `[c,z]⊂K_h` would meet `∂B_h`, because `c∈int B_h`; contradiction. So `K_h⊂int B_sqrt(h)`, hence bounded. It is already closed, therefore compact.

## Drift along an AC solution

At almost every time along a solution, all of the following hold simultaneously: `x_dot` exists; `g'` exists; the ODE holds; the measurable rates lie in `[κ,K]`. For each active label, the weighted drift lemma gives `r_lambda·f(t,x(t))>=0`. The chain rule takes the minimum over the active labels, so `g'≥0`. If the path is in `P\\K_h`, the no-neutral-active-slope lemma says each active `r_lambda` is outside `S^perp`; the same drift lemma then gives `r_lambda·f>=δ_h` for every active label, hence `g'≥δ_h`. Integrating gives monotonicity and strict growth. This argument uses only a.e. statements, as required for measurable schedules.

## Invariance and continuation

Start at `x(t0)∈K_h⊂int B_h`. Local existence gives an initial interval inside `B_h`. Up to any first boundary hit `T`, monotonicity gives `F_h(x(T))>=F_h(x(t0))=M_h`, while the zero-slope label gives `F_h<=M_h`; hence `x(T)∈K_h`, impossible because `K_h∩∂B_h=∅`. Thus the path stays in `K_h` during its maximal positive interval.

For any compact state box `Q⊂R^d_{>0}`, the monomials `x^{y_e}` and their gradients are bounded on `Q`. Because `R` is finite and `k_e(t)∈[κ,K]`, there are constants `C_Q,L_Q<∞` such that `|f(t,x)|<=C_Q` and `|f(t,x)-f(t,z)|<=L_Q|x-z|` for `x,z∈Q` and a.e. `t`. Also `f(·,x)` is measurable. These are the Carathéodory local existence/uniqueness hypotheses. Choose such a `Q` containing compact `K_h` in its interior. The speed bound makes a trajectory in `K_h` Lipschitz; if the maximal endpoint `β<∞`, it has a limit as `t↑β`. Continuity of `F_h` and closedness of `K_h` put the limit in `K_h`. Apply Carathéodory existence at time `β` and that limit, and concatenate. Uniqueness follows from the local Lipschitz bound. This contradicts finite maximality and proves global continuation. Since `K_h⊂R^d_{>0}`, the path stays positive. Since `f(t,x)∈S` a.e., integration also keeps `x(t)-c∈S`.

## Finite entry

Continuity of `F_h` and compactness of `B_h` give `m_h=min_{B_h}F_h`. As `c∈B_h`, `m_h<=M_h`, so `W_h=(M_h-m_h)/δ_h` is finite and nonnegative. If `W_h=0`, then `m_h=M_h` and `F_h<=M_h` everywhere, so `F_h=M_h` throughout `B_h`; there is nothing to prove. If `W_h>0`, either entry occurs before `t0+W_h`, or the path is outside `K_h` on `[t0,t0+W_h)`. For every `s<t0+W_h`, strict-growth integration gives `F_h(x(s))>=F_h(x(t0))+δ_h(s-t0)>=m_h+δ_h(s-t0)`. Let `s↑t0+W_h`; continuity gives `F_h(x(t0+W_h))>=m_h+δ_hW_h=M_h`. The global upper bound forces equality, so the endpoint is in `K_h`. This explicitly handles entry at the endpoint, where the closed-segment hypothesis of the strict-growth item may not apply.
