# Hostile audit: scale lift for the common absorber

## Verdict and scope

The scale-transition argument in the audited passage has no counterexample under the hypotheses of the stated plateau and entry propositions. Conditional on those predecessor results, the initial-scale choice, capped square-root induction, finite transition count, and waiting-time sum are valid. The induction does not need the plateaux to be nested; it needs only the stated plateau-to-next-box containment.

This report audits only the classwise scale lift in work/agents/permanence_hostile/endotactic_permanence.tex, especially lines 681–737. It does not independently validate the affine construction, weighted drift, plateau proposition, entry proposition, full permanence theorem, or novelty/prior art. Predecessor claims remain conditional.

## Reconstructed induction

Write B_h = [h,h⁻¹]^d, so x = X_h(p) lies in B_h exactly when p lies in [-1,1]^d. The scale construction has 0 < H ≤ 1 by equation (H), and the active-coordinate comparison says that for an active slope r, any nonzero coordinate r_i forces |p_i| ≥ H.

For arbitrary x⁰ > 0, let q = ||log x⁰||∞. As h ↓ 0, q/|log h| → 0. Thus choose 0 < h₀ ≤ h_P with |log h₀| > q/H (if q = 0, any sufficiently small h₀ ≤ h_P works). Then p⁰ = log x⁰/log h₀ has ||p⁰||∞ < H ≤ 1, so x⁰ lies in B_h₀. If any active slope at x⁰ had r_i ≠ 0, the coordinate comparison would give |p_i⁰| ≥ H, a contradiction. All active labels therefore have zero slope. Their common active value is a constant-label value; since M_h₀ is the least constant-label value and F_h₀ ≤ M_h₀ everywhere, this value equals M_h₀. Hence x⁰ lies in K_h₀. The predecessor invariance/continuation result now supplies global positivity and invariance from time zero, rather than presupposing global existence for an arbitrary starting point.

Suppose the solution stays in K_hⱼ. The plateau proposition gives K_hⱼ ⊂ int(B_sqrt(hⱼ)). With hⱼ₊₁ = min(sqrt(hⱼ), h_P), one has hⱼ₊₁ ≤ sqrt(hⱼ). For 0 < a ≤ b < 1, B_b ⊂ B_a coordinatewise; therefore B_sqrt(hⱼ) ⊂ B_hⱼ₊₁, including when the cap is active. The trajectory is already global and in its positive class, so the entry proposition at scale hⱼ₊₁ applies from the current time and gives entry into K_hⱼ₊₁ within W_hⱼ₊₁. Invariance at that scale then continues the induction. No inclusion K_hⱼ ⊂ K_hⱼ₊₁ is asserted or needed.

For the transition count put aⱼ = -log hⱼ > 0 and a_P = -log h_P > 0. The capped recurrence is exactly aⱼ₊₁ = max(aⱼ/2, a_P). For h₀ < h_P, the first N = ceil(log₂(a₀/a_P)) steps reach the cap: for n < N, a₀/2ⁿ > a_P, while a₀/2ᴺ ≤ a_P. If h₀ = h_P, N = 0. This verifies the manuscript’s formula, including equality at a dyadic threshold.

Let t₀ = 0. Inductively, entry into K_hⱼ occurs no later than tⱼ₋₁ + W_hⱼ; thus the final common plateau is reached by
t_N ≤ sum from j=1 to N of W_hⱼ,
where W_h = (M_h - min over x in B_h of F_h(x)) / (κ H h^M).
For each fixed h ≤ h_P, the numerator is finite because F_h is a finite minimum of affine functions on compact B_h; it is nonnegative because c lies in B_h and F_h(c) = M_h. The denominator is positive. If the actual start at a stage has a larger F_h-value than the minimum, the stated W_h is conservative. If the trajectory reaches the plateau sooner, invariance makes subsequent time bounds valid. For N = 0, it starts in the final plateau and the sum is empty, hence zero.

The selected h₀, N, and scales hⱼ depend on x⁰ (and on the fixed h_P); each W_hⱼ depends on the fixed affine family/offsets, hⱼ, and the supplied constants such as κ, H, and M. They do not depend on the realized measurable rate path. The argument yields a finite path-independent bound separately for each x⁰, not a uniform entry-time bound over an unbounded class. The final plateau K_hP intersect (c + S) itself is common to the class and rate paths, conditional on the predecessor invariance and class-preservation claims.

## Hostile checks and hidden premises

- **No missing initial-scale obstruction:** every fixed positive x⁰ has finite q = ||log x⁰||∞, while |log h| is unbounded as h ↓ 0. The interval condition h₀ ≤ h_P and common offset-definition interval is preserved by choosing smaller h₀.
- **No box-containment reversal:** the order reverses with scale: smaller h gives the larger box B_h. Thus capping at h_P ≤ sqrt(hⱼ) enlarges the target box relative to B_sqrt(hⱼ).
- **No circular global-existence use:** the finite-entry clause is stated for a global solution, but the starting point is first placed in K_h₀; predecessor item 3 supplies global existence. The same globally continued trajectory is used at every later stage.
- **No need for plateau nesting:** only each K_hⱼ's containment in the next box is used. The separate entry proposition creates the next plateau membership.
- **Classwise set facts:** K_hP is compact/convex and contains c; intersecting with the closed affine class c + S preserves compactness and convexity and remains nonempty. Positivity follows from the inner-box containment. Class preservation requires ẋ(t) in S almost everywhere; plateau invariance is inherited from the entry proposition.
- **Dependencies to retain as conditional:** this lift assumes a single fixed finite affine family, H > 0, a scale h_P < 1 for which all predecessor estimates hold at every h ≤ h_P, the compact positive plateau and its invariance, the measurable-rate strict increase/finite-entry proposition, and the class-preservation assertion. In particular it does not repair any upstream error in weighted drift or plateau construction.

No counterexample was found to the audited scale lift under those premises. This is a scoped internal proof reconstruction only.
