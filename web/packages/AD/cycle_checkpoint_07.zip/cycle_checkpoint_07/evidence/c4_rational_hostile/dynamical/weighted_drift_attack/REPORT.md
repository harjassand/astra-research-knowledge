# Weighted essential-source drift: proof audit and Lean formalization

## Result

The finite weighted-drift argument is now kernel-checked in Lean 4.28 in [`WeightedDrift.lean`](../../formalization/dynamics/WeightedDrift.lean). The strict theorem is `WeightedDrift.weighted_drift_strict`; the perpendicular case is separately stated as exact zero and hence nonnegative. The independent signature and axiom output is in [`WeightedDrift.kernel-audit.log`](WeightedDrift.kernel-audit.log).

The strict theorem keeps the source’s essential-source convention. A finite labelled diagram has arbitrary real source and target vectors. `InR D q e` means `q·νₑ ≠ 0`; `EssentialEdge D q e` requires `e ∈ R_q` and that its source maximizes `q·y` over every source in `R_q`. The universal comparison retains every source tie, and `AllEndotactic` applies to every direction and every edge at every tied essential source. The theorem chooses a minimum `r`-source edge from `R_r`; all-endotacticity in direction `−r` proves its projected reaction is positive. Every negative-projection edge is strictly above that minimum source tier, which supplies the monomial ratio bound.

For an active affine label with slope `r` outside `StoichPerp`, the exported inequality is exactly

```text
κ * H * h^(M) ≤ r · ∑ₑ kₑ x^(yₑ) νₑ,
```

where `H = slopeMargin D F`, `L = reactionBudget D`, `M = sourceBudget D`, and `xᵢ = h^(pᵢ)`. The hypotheses include `0 < κ ≤ K`, pointwise `κ ≤ kₑ ≤ K`, `0 < h < hAct < 1`, active label `j`, `ActivityMargin D F hAct`, and the explicit scale condition `K * L * h^H ≤ κ * H`. No measurability or cross-edge relation on the rates is assumed. Arbitrary real exponents, including negative source coordinates, are retained.

The `H`, `L`, and `M` definitions are finite conservative budgets. `L` is the sum of reaction-vector `l1` norms. `M` is the sum of all source `l1` norms (rather than the source text’s maximum), so it still bounds each individual source norm and handles an empty edge set directly. `H` and the pointwise tolerance use reciprocals of finite sums of nonnegative comparison terms, rather than the source’s finite minima; the proved bounds are the ones the drift proof needs. These are definition choices, not additional analytic assumptions.

## Activity input and formalization boundary

The active-slope signs are not hidden in `weighted_drift_strict`: that theorem takes `ActivityMargin D F hAct` explicitly. The exported constructor `exists_activity_margin` proves this interface from caller-supplied `N33Affine.FullApproximation (-1) 1 (pointTolerance D) F.family`. Its proof calls `N33Affine.exists_uniform_activity_cutoff` and converts coordinatewise affine error to dot-product error using the finite pointwise tolerance.

This module does **not** export an unconditional setup theorem that constructs `F` and `hAct` from an affine-family existence theorem. In particular, `FullApproximation` remains an input to `exists_activity_margin`; the module does not call `N33Affine.exists_full_affine_family`. The strict drift theorem also takes the displayed scale inequality as a premise. Thus the checked result is the exact conditional drift estimate, while construction of a full family and a common numeric/sufficiently-small scale threshold are separate bridge obligations.

## Hostile source audit

No counterexample to the drift inequality was found under the exact finite all-endotactic hypotheses. The initial terminology concern is retracted after an independent primary-source/API recheck. The TeX sentence “Every edge with `r·νₑ < 0` is essential” is correct: for direction `−r` such an edge has nonzero projected vector and hence belongs to `R_{−r}`. Essential support is a separate set of maximal sources, and the endotactic sign condition applies to essential reactions whose source lies in that support. The next sentence’s strict-above-minimum conclusion is also correct.

The one-dimensional reversible pair `0 → 1`, `1 → 0`, with `r = 1`, is a confirming example, not a counterexample: `1 → 0` is an essential reaction in `R_{−r}` and its source is strictly above the minimum `r`-source support. In the Lean file, `InR` models essential-reaction membership; `EssentialEdge` combines this with the essential-support source condition used in `AllEndotactic`.

The activity premise is genuinely uniform in `h`, `p`, and active labels: `ActivityMargin` quantifies over every `h` below the supplied cutoff, every exponent-box point, every active label, and every comparison vector. The Lean constructor derives it from the imported uniform-cutoff theorem; the main drift theorem does not infer uniformity from pointwise affine approximation alone.

## Kernel evidence

The source compiled successfully with Lean 4.28 (exit code 0). The compile emitted only linter warnings about unused variables/tactics; it reported no proof errors. The subsequent `#check` and `#print axioms` run also exited 0. The checked strict, perpendicular, and activity-margin declarations depend on Lean’s standard `propext`, `Classical.choice`, and `Quot.sound` axioms. No custom axiom declaration, `sorry`, or `admit` occurs in `WeightedDrift.lean`.

SHA-256 of the compiled source:

```text
874d92c9e2454a08ad57e21b032d400c563f72480895ec6d1e47be859afab152  work/agents/c4_rational_hostile/formalization/dynamics/WeightedDrift.lean
```

This verifies only the local weighted-drift module and its listed conditional interfaces. It is not a proof of the broader permanence theorem, trajectory or plateau claims, global absorption, or an external novelty claim.
