# Kernel check of the all-dimensional affine approximation lemma

## Result

The original arbitrary-tolerance affine approximation lemma is now proved in Lean 4.28 in `project/N33Affine/GlobalAffineComposition.lean`, declaration `N33Affine.exists_full_affine_family`. It is a kernel-checked theorem, not only a feasibility result or a collection of helper lemmas.

Its interface says: for every finite dimension `m`, reals `a ≤ b`, and arbitrary function `E : (Fin m → ℝ) → ℝ` that is positive at every point of the cube `[a,b]^m`, there exists a finite nonempty family with slopes in `[a,b]^m`, whose offsets are `LittleO a`, such that every label that is eventually a weak minimizer along `hₙ → 0+`, `pₙ → p ∈ [a,b]^m` satisfies the strict coordinatewise conclusion `|p_i − slope_i| < E(slope)`. The approximants `pₙ` are unrestricted outside the cube; the tolerance need not be continuous; and weak activity includes every tied minimizer.

This matches and strengthens the source lemma at `work/agents/permanence_hostile/endotactic_permanence.tex:161`: the source assumes `m ≥ 1`, `a < b`, and activity at every sequence index. The Lean theorem also covers `m = 0` and `a = b`, and only assumes eventual activity, so its activity premise is weaker. `LittleO a` encodes the source's `bump(h)=o(h^a)` as `h→0+`.

## What the proof composes

The induction derives each lower-dimensional slice input from the same theorem at smaller dimension, using the exact arbitrary tolerance `s ↦ E(liftPoint t e s)`. It constructs the raised-coordinate finite family and terminal archive, proves the local-slice estimate for every label, and turns exact-slice success into a minimum-coordinate neighborhood by closed active-limit sets and a compact bad set.

The outer step extracts a finite open-interval cover of `[a,b]`, selects a minimum-cardinality subcover to remove contained intervals, orders its centers, and invokes the checked cut construction. The finite tagged union uses the common prefix shifts. The separate slab-placement proof forces a globally active label's limiting minimum into its tag's slab; weak activity then restricts to the corresponding local family. Finally, finite sums of little-o offsets give the global `o(h^a)` bound. The full public theorem therefore composes the formerly separate slice and gluing components without assuming a local approximation property as an oracle.

## Verification and interface repair

`GlobalAffineComposition.compile.log` is empty and the Lean 4.28 compiler exited 0. `GlobalAffineAudit.log` contains `#print`, `#check`, and axiom outputs for the public theorem and its principal constructors. The theorem depends only on `[propext, Classical.choice, Quot.sound]`; there is no `sorryAx`, custom axiom, or admitted theorem. The result is noncomputable: compactness, finite choices, and arbitrary lower-dimensional existence are used, and no family-size or effective-construction bound is proved.

During the public-signature audit, I found that the first `SliceInput.approx` version had elaborated an unqualified `atTop` into an unintended implicit `{atTop : Filter ℕ}`. That declaration was kernel accepted but did not encode the intended sequence interface. The exact pre-repair source is preserved with its SHA-256 in `repair/FILTER_ATTOP_REPAIR.md`; its API audit reproduces the hidden binder. The repaired source explicitly uses `Filter.atTop`, all task-local dependents were rebuilt, the authoritative B1 worker source was corrected, and the repaired `#print` has no arbitrary-filter parameter. `repair/verify_filter_atTop_repair.sh` reproduces both signatures and rebuilds the local dependencies.

`verify_full_affine.sh` is the one-command replay for the authoritative and task-local API repair, the dependent rebuild, and the final affine theorem audit.

## Sequential-to-uniform activity corollary

The finite-family corollary at `endotactic_permanence.tex:369–385` is also formalized in `project/N33Affine/UniformActivity.lean` as `N33Affine.exists_uniform_activity_cutoff`. Given any `BoxFamily` satisfying the full sequential approximation property, it produces one `hAct ∈ (0,1)` that works for every cube point, every family label, and every active label at every `0<h<hAct`. It allows arbitrary tolerance data, does not require continuity of `E`, and includes weak ties. The compactness contradiction fixes both a label and coordinate before passing the violating inequality to the limit, so `E` is used only at one fixed slope.

The public Lean interface was printed and audited, with the exact sequence filter inherited from the repaired affine theorem. Lean 4.28 compilation and `#print axioms` succeed; the theorem depends only on `[propext, Classical.choice, Quot.sound]`, with no `sorryAx`. Reproduce this check with `verify_uniform_activity.sh`; its output is recorded in `project/UniformActivityAudit.log`, and the source SHA-256 is `1eea4ee995a4ceb3c33ffb2ef5e6b7ddb07ae9fd2d643abee0ec5b172bc9e052`.

This is a formal corollary of the affine family property, not a separate construction of a family or a useful numerical cutoff. The family and `hAct` remain non-effective. It closes only the fixed-family compactness corollary needed by the manuscript; weighted drift, Carathéodory dynamics, plateau entry, and rational physical-time continuation remain separate gates.

## Pointwise finite-minimum derivative identity

`dynamics/FiniteMinimum.lean` formalizes the all-ties derivative identity used inside the source's finite-minimum chain rule (`endotactic_permanence.tex:585–616`). At any point where a nonempty finite minimum and its branches are differentiable, every active branch has the same derivative as the minimum. The proof uses Fermat's theorem on the nonnegative difference between an active branch and the lower envelope. The exact declarations and source/verification limits are recorded in `dynamics/FINITE_MINIMUM_REPORT.md`; `verify_finite_minimum.sh` passes and the declarations use only `[propext, Classical.choice, Quot.sound]`.

This does not yet prove the full chain rule for Carathéodory trajectories. Absolute continuity of the finite minimum, almost-everywhere differentiability of the branch and minimum functions, and the trajectory's differential inclusion remain outside this component.

## Scalar plateau and finite-entry calculus

`dynamics/PlateauPrinciples.lean` supplies three kernel-checked AC scalar results used after the reaction drift estimate: an a.e. derivative lower bound integrates to endpoint growth; a nonnegative derivative makes a superlevel barrier forward-invariant; and a derivative bounded below by `δ>0` whenever the barrier is below `M` forces a hit in time strictly greater than `(M-F(a))/δ`. The exact hypotheses and proof boundary are recorded in `dynamics/PLATEAU_PRINCIPLES_REPORT.md`. `verify_plateau_principles.sh` passed Lean 4.28 compilation and API/axiom audit, with only `[propext, Classical.choice, Quot.sound]`.

These scalar results do not produce the trajectory or its derivative estimates. Their use in N33 still depends on the separate measurable ODE solution, finite-minimum a.e. bridge, weighted strict drift, and box/scale iteration.

## Conditional finite-scale absorber integration

`dynamics/AbsorberScale.lean` proves the capped square-root schedule in closed form, its finite arrival at the common cap `hP`, the scale order for the logarithmic boxes, and a finite transition-time sum for nonnested plateaux. The composition theorem `N33Dynamics.permanenceScale_absorber_entry` says that if the initial state is in the `h₀` plateau and each scale-`n` plateau entry yields entry into the next one within a supplied bound `W n`, then the common `hP` plateau is reached within `sum_{n<N} W n` for a finite `N` with `h_N=hP`. `plateau_subset_nextScaleBox` separately proves the source's box-containment step.

`verify_absorber_scale.sh` passed Lean 4.28 compilation and API/axiom audit. All audited declarations depend only on `[propext, Classical.choice, Quot.sound]`; there is no `sorryAx` or implicit arbitrary `Filter` binder. The source hash is `5d2378a2a6e4afea6ee3529969f0e9914e91b6320a550d6769f085fd19379660`.

This remains conditional. The transition premise is not proved from network dynamics here: it still requires global existence and positivity, plateau invariance, trajectory containment in each box, and the strict-drift finite-entry estimate. The theorem derives no bound uniform over initial states in an unbounded class.

Source hashes:

- `project/N33Affine/GlobalAffineComposition.lean`: `188e86466b02d646f82f4b25fd0a1bd4b47b4b4e9bc0c6af0d07da670130f5c8`
- `project/N33Affine/AffineInduction.lean`: `60a4da94d3e4cd641178f9bcd3c86234715fbbee760fa6ddd95634d62936c113`
- repaired `project/N33Affine/SliceFamily.lean`: `a83b29533ebf4309816592e84d7455f32975e45d21c3f11de4ed410eef539029`

## Claim boundary and remaining gates

The lemma is an internal reconstruction of the affine argument attributed in the source to OpenAI release 149; this formal proof is not a novelty or priority claim. The formal artifacts verify the affine lemma, its fixed-family uniform-activity corollary, pointwise and a.e. finite-minimum calculus components, scalar AC barrier/entry principles, and conditional capped-scale/entry-time composition. They do not by themselves certify the complete all-dimensional permanence candidate in the larger TeX manuscript. The remaining formal gates include the actual measurable-rate weighted drift construction/replay, deriving the transition premise from the network vector field, global Carathéodory continuation/positivity, and the physical-time change for rational rates. That candidate remains distinct from the source-reported two-species result and established stronger-endotactic multidimensional results; independent external review and post-2014 priority audit remain open.

The new formal theorem also gives no practical algorithm when `E` is an opaque positive function. Its existence proof uses classical choices and has no useful bound on the number of labels, thresholds, cover size, or numerical cutoff. The `dynamic_clock/DYNAMIC_CLOCK_AUDIT.md` and `prior_art/endotactic_permanence_prior_art.md` record the separate rate-clock and literature gates.
