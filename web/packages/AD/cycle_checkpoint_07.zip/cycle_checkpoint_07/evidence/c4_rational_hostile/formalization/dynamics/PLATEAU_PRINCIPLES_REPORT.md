# Absolutely continuous barrier and entry principles

## Checked results

`PlateauPrinciples.lean` proves three generic scalar statements for an absolutely continuous function on a closed time interval:

- `absolutelyContinuous_increment_ge`: if the derivative is at least `δ` almost everywhere on `[a,b]`, then `f(b)-f(a) ≥ δ(b-a)`.
- `absolutelyContinuous_superlevel_forward_invariant`: if the derivative is nonnegative almost everywhere on `[a,b]`, then a superlevel condition `f(a) ≥ M` implies `f(b) ≥ M`.
- `absolutelyContinuous_hits_level`: if `f' ≥ δ > 0` almost everywhere whenever `f<M`, then `f` reaches level `M` on `[a,b]` whenever `b-a > (M-f(a))/δ`.

The proof converts an almost-everywhere bound on the interval into a restricted-measure bound, applies the interval-integral comparison theorem, and uses the fundamental theorem for absolutely continuous functions. The hit-time theorem handles the no-hit case by deriving the derivative bound on the whole interval and contradicting the assumed duration.

## Relation to the permanence proof

These results isolate the integral and scalar barrier steps in the manuscript's plateau/finite-entry argument. The entry theorem assumes the trajectory segment is already represented by an absolutely continuous scalar barrier and that its derivative has the stated bound while below the plateau level. It does not prove that the reaction trajectory stays in the box, that its finite minimum is absolutely continuous, that the weighted drift supplies the a.e. derivative hypotheses, or that the scale-dependent boxes produce a uniform absorber.

## Verification

`verify_plateau_principles.sh` compiled the source with Lean 4.28 and audited all three public declarations. Each axiom report is `[propext, Classical.choice, Quot.sound]`; no `sorryAx` or unexpected implicit `Filter` parameter appears. The command ended with `PASS`. The source SHA-256 is `8409f8a2e25988bdbae7936b990ccf2eb199ff4dbad9ef35f143de32ca7b1c14` and is stored in the main `CLAIMS.json`.
