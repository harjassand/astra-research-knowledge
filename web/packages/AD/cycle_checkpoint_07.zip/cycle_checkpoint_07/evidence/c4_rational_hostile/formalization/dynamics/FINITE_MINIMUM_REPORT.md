# Finite-minimum derivative component

## Result

`FiniteMinimum.lean` proves the pointwise derivative identity needed at the core of the manuscript's finite-minimum chain rule (`endotactic_permanence.tex:585–616`). For a nonempty finite family of differentiable real functions, if their pointwise minimum is differentiable at `x`, every branch attaining that minimum has the same derivative as the minimum. The declaration `N33Dynamics.finite_minimum_active_derivative_eq` gives the all-active statement; `N33Dynamics.finite_minimum_has_active_derivative` also proves attainment and returns an active branch carrying the minimum's derivative.

The proof is exact and short: for any active branch `f i`, the function `f i - g` is globally nonnegative and vanishes at `x`. It has a local minimum there. Fermat's theorem applied to its derivative yields `d_i - d_g = 0`. This handles every tied minimizer, including ties with different candidate branch derivatives; such a tie cannot occur at a point where the lower envelope is two-sided differentiable.

## Scope limit

This is a pointwise calculus component. It assumes that the branch functions and their finite minimum are differentiable at the selected time. It does not prove that affine compositions with an absolutely continuous trajectory are absolutely continuous, that their finite minimum is absolutely continuous, that those functions are differentiable almost everywhere, or the full a.e. identity with `min` of active directional derivatives in the source lemma. Those measure-theoretic/trajectory steps remain necessary before invoking this declaration on a Carathéodory solution.

## Verification

`verify_finite_minimum.sh` compiled the module with the pinned Lean 4.28 toolchain and audited all four declarations using `#check`, `#print`, and `#print axioms`. Each reports only `[propext, Classical.choice, Quot.sound]`, with no `sorryAx` and no implicit arbitrary `Filter` parameter. The replay ended with `PASS`. `FiniteMinimum.compile.log` is empty. Source SHA-256 is `d7def4d2492fcb54efd484c14c70a2f341bf76023a7841a08febef98942fd576` and is recorded in the main `CLAIMS.json`.
