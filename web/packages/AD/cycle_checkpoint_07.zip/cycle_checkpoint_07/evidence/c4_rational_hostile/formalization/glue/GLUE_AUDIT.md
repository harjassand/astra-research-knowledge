# Hostile audit of the finite interval gluing

## Finding

I found no counterexample to the finite interval-cover/order/cut argument in
`endotactic_permanence.tex` (the finite-gluing subsection of the affine
approximation proof). It is valid with the hypotheses already established
there: the finite intervals are symmetric neighborhoods centered at points
of `[a,b]`, they cover `[a,b]`, and after pruning no retained interval is
contained in another (with duplicate equal intervals reduced to one).

## Proof checks

Write `L_j=t_j-rho_j` and `R_j=t_j+rho_j`, with `rho_j>0`, and order the
retained, distinct centers increasingly. If `t_i<t_j` but `L_j<=L_i`, then
`R_j-R_i=2(t_j-t_i)+(L_i-L_j)>0`, so interval `i` is contained in interval
`j`, contrary to pruning. Thus `L_i<L_j`. The symmetric argument from
`R_j<=R_i` gives `L_j>L_i` and containment of `j` in `i`; hence `R_i<R_j`.
The endpoint lists are therefore strictly increasing.

The first interval contains `a`: some covering interval has `L_k<a<R_k`, so
`L_1<=L_k<a`, while `R_1>t_1>=a`. The last interval contains `b` by the
dual argument. For consecutive intervals, if `R_j<=L_{j+1}`, then
`t_j<R_j<=L_{j+1}<t_{j+1}` and `t_j,t_{j+1}` lie in `[a,b]`, so
`R_j` lies in `[a,b]`. Earlier intervals end strictly before `R_j`; later
ones start strictly after it; and the two adjacent open intervals omit their
shared boundary. This contradicts the cover. Thus `L_{j+1}<R_j`.

The cut interval is nonempty: each of
`t_j<t_{j+1}`, `t_j<R_j`, `L_{j+1}<t_{j+1}`, and `L_{j+1}<R_j` holds, so
`max(t_j,L_{j+1})<min(t_{j+1},R_j)`. Its selected cut belongs to both open
intervals. Together with `a` in the first and `b` in the last, these cuts
give `[q_{j-1},q_j] subset I_{t_j}`. This also covers `N=1` using the outer
endpoint inclusions and requires no internal cut.

The tagged-family shift has the correct signs. If
`S_j(h)=sum_{ell<j} h^{q_ell}`, a label in family `j` has global value
`V_j-S_j`; the next family's zero-offset baseline has value
`t_{j+1} one dot X-S_j-h^{q_j}`. Their difference is
`(r-t_{j+1}one) dot X+c+h^{q_j}`. The previous-family baseline instead
gives `(r-t_{j-1}one) dot X+c-h^{q_{j-1}}`. These are exactly the upper and
lower comparisons in the source. The shared shift cancels in every
within-family comparison, so global weak activity implies local weak
activity. The strict eventual sign contradictions remain valid at ties,
because activity is defined with `<=` against every label.

The asymptotic exponents also have the required strict gaps. Every internal
`q_j>t_j>=a`, so each shift is `o(h^a)`. For a label in family `j`,
`c=o(h^{t_j+rho_j})`; since `q_j<t_j+rho_j` and, when present,
`q_{j-1}<t_j<t_j+rho_j`, its offset is little-o at either comparison
scale. In the upper contradiction every limiting coordinate exponent is
greater than `q_j`; in the lower contradiction all slope coefficients are
at least `t_j-t_{j-1}>0` and at least one limiting exponent is below
`q_{j-1}`. The sequence points themselves need not remain in the cube.

## Formalization boundary

The interval argument uses the fact that each center is in `[a,b]`; this is
what places a hypothetical gap boundary `R_j` inside `[a,b]`. A Lean helper
should state this explicitly, together with the finite cover and the
post-pruning noncontainment property. The proof need not re-prove compactness
or the construction of a minimal subcover if its input is the already
pruned, center-ordered finite subcover. The shifted-family theorem should
retain the tagged union, a zero-offset baseline in every family, and the
fixed-label, non-strict activity predicate. These are explicit structural
inputs, not additional mathematical defects in the source argument.
