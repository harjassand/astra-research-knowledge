# Filter.atTop contract repair

Date: 2026-10-08

The pre-repair authoritative worker source is preserved verbatim as `SliceFamily.before_Filter_atTop.lean` (SHA-256 `15a9815a3236dd496bd05fac288519c1a3c299ef39c319b30ff5d20455a40e35`). In `SliceInput.approx`, its activity premise used `(∀ᶠ n in atTop, ...)` without opening `Filter`; Lean accepted this by introducing an unintended implicit filter parameter named `atTop`. Consequently the compiled record was quantified over arbitrary filters on `ℕ`, not specifically `Filter.atTop`. Kernel acceptance alone therefore did not establish the intended source contract.

The task-local repaired source is `../project/N33Affine/SliceFamily.lean` (SHA-256 `a83b29533ebf4309816592e84d7455f32975e45d21c3f11de4ed410eef539029`). The exact change makes the activity premise `(∀ᶠ n in Filter.atTop, ...)`. The repaired module and dependents were rebuilt under Lean 4.28 / cached Mathlib. `API_AUDIT.md` records the public-signature audit. The independent worker copy `work/agents/c4_lean_slice_family/SliceFamily.lean` had the same defect at the time of preservation; it was reported to its owner with the exact patch for correction.

Scope: this repairs and checks the formal interface for the slice-family component and dependent local construction. It does not prove the full affine permanence lemma or the all-dimensional permanence theorem.
