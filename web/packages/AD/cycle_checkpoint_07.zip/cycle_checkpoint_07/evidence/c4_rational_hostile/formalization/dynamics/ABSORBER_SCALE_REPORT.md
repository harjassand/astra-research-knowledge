# Conditional common-absorber scale integration

## Kernel-checked result

`AbsorberScale.lean` proves the scale arithmetic and the finite entry-time composition used in the last section of `endotactic_permanence.tex`. Write

\[
A=-\log h_0,\qquad P=-\log h_P,\qquad
h_n=\exp\!\left(-\max\{A/2^n,P\}\right).
\]

For `0 < h₀ ≤ hP < 1`, `permanenceScale_zero` gives `h₀`, `permanenceScale_succ` proves the exact recurrence
\[
h_{n+1}=\min\{\sqrt{h_n},h_P\},
\]
and `permanenceScale_cap` proves that some finite `N` has `h_N=hP`. The finite cap hit follows from `2^n → ∞`; it does not rely on an informal limit argument about repeated square roots.

`scaleBox_mono` proves the order reversal for the boxes `[h,h^{-1}]^d`: if `hSmall ≤ hBig`, the `hBig` box lies inside the `hSmall` box. Consequently `plateau_subset_nextScaleBox` transfers a plateau inside the old square-root box into the next-scale box whenever `hNext ≤ sqrt h`.

`finite_absorber_chain` composes per-stage entry times by summing their waiting bounds and does not assume the intermediate plateaux are nested. `permanenceScale_absorber_entry` combines it with the finite scale cap: if a state starts in the scale-`h₀` plateau and each scale-`n` plateau membership yields membership in the next plateau within `W n`, then it reaches the common `hP` plateau by `sum_{n<N} W n`.

## Verification

`verify_absorber_scale.sh` compiles and audits the module with Lean 4.28.0. It exits `0`; `AbsorberScale.compile.log` has no diagnostics and `AbsorberScaleAudit.log` records the exact public signatures and `#print axioms` output. Every audited theorem uses only `[propext, Classical.choice, Quot.sound]`. The audit found no `sorryAx` or unexpected implicit `Filter` parameter. The source SHA-256 is recorded in the formalization claim ledger.

## Exact boundary

This is a conditional scale/entry composition, not a proof of the reaction-network dynamics. The main theorem `permanenceScale_absorber_entry` assumes `hstep`: for every time in a scale-`n` plateau, there is a later time within `W n` in the next plateau. The manuscript derives that premise from plateau invariance, box containment, the strict-drift finite-entry estimate, and global existence/positivity. This file proves the box-order and scale arithmetic substeps, but does not derive `hstep`, show a trajectory exists or remains in its box, prove the finite-entry estimate for the network, or prove Carathéodory continuation. The scale/time composition remains rate-path-independent only when the supplied `W n` bounds are.

The scale schedule follows the source's initial-point-dependent `h₀` and common cap `hP`. It yields a finite entry bound for each chosen initial scale, not a bound uniform over an unbounded class. No nesting of plateaux is asserted or needed.
