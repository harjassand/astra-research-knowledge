# Dynamic audit of the rational-rate denominator clock

## Verdict

Under the stated interface, denominator clearing is a valid orbit time change, including for exogenous measurable rate schedules that vary along the trajectory. The possible clock failures before the transformed solution enters a compact positive set are ruled out by a continuation argument using the global permanence theorem for the cleared system. Once that theorem applies, the clock also runs for infinite original time. Thus there is no dynamics-side counterexample within the stated assumptions.

The claim is conditional on the lifted exponent-arrow diagram satisfying the essential-source endotactic test and on the applicable all-endotactic power-law permanence theorem. In two species, the cited established theorem is the intended base result, subject to exact interface matching. In dimension three and above, this clock argument does not validate the internally reconstructed all-endotactic theorem; that theorem remains the decisive mathematical gate.

## Exact setup

If $E=\varnothing$, then $\dot x=0$ and the dynamics claim is trivial; assume below that $E$ is nonempty. Let the finite channel set be $E$, with
\[
 \rho_e(x)=P_e(x)/Q_e(x),\qquad
 P_e(x)=\sum_{\alpha\in A_e}p_{e\alpha}x^\alpha,\qquad
 Q_e(x)=\sum_{\beta\in B_e}q_{e\beta}x^\beta,
\]
where $A_e,B_e\subset\mathbb Q^d$ are finite nonempty supports and all coefficients are positive. Exponents may be negative. Let $\nu_e\in\mathbb R^d$ (rational vectors suffice for the exact graph test), and let $k_e:[0,\infty)\to[\kappa,K]$, $0<\kappa\le K<\infty$, be exogenous Lebesgue-measurable schedules. The original system is

\[
 \dot x(t)=f(t,x(t))=\sum_{e\in E}k_e(t)\frac{P_e(x(t))}{Q_e(x(t))}\nu_e,
 \qquad x(0)=x_0\in\mathbb R^d_{>0}.
 \tag{1}
\]
Put $D(x)=\prod_{e\in E}Q_e(x)>0$ on the positive orthant and
\[
 \widetilde P_e(x)=P_e(x)\prod_{j\ne e}Q_j(x).
\]
Then $D f=\sum_e k_e(t)\widetilde P_e\nu_e$. Expanding each product gives finitely many arrows
\[
 \gamma\longrightarrow\gamma+\nu_e,
 \quad \gamma=\alpha_e+\sum_{j\ne e}\beta_j,
 \quad c=p_{e\alpha_e}\prod_{j\ne e}q_{j\beta_j}>0,
 \tag{2}
\]
with coefficient $c k_e(t)$. Aggregate duplicate $(e,\gamma)$ terms by summing their positive $c$'s. Let $c_->0$ and $c_+<\infty$ be the minimum and maximum of the resulting finite set of channel coefficients. The transformed edge rates all lie in the *common* box
\[
 [\widetilde\kappa,\widetilde K]=[c_-\kappa,c_+K].
 \tag{3}
\]
They need not vary independently; the power-law theorem permits arbitrary measurable edge rates in this box, so these correlated schedules are included. If the cited source formulates its box as an open interval $(\eta,1/\eta)$, choose $\eta>0$ small enough that $[c_-\kappa,c_+K]\subset(\eta,1/\eta)$.

## Tropical and tie semantics needed by the dynamics theorem

For a direction $w$, write
\[
 \tau_e(w)=h_{A_e}(w)-h_{B_e}(w),\qquad
 h_A(w)=\max_{a\in A}a\cdot w.
\]
The lifted source support for channel $e$ is $A_e+\sum_{j\ne e}B_j$; hence its maximum height is
\[
 h_{\widetilde P_e}(w)=h_D(w)+\tau_e(w),\qquad
 h_D(w)=\sum_jh_{B_j}(w).
 \tag{4}
\]
The offset is common across channels, so active-channel maxima and exact ties are unchanged. Define the essential set before maximizing:
\[
 E(w)=\{e:\nu_e\cdot w\ne0\}.
\]
The relevant condition is vacuous if $E(w)=\varnothing$; otherwise **every** channel attaining \(\max_{e\in E(w)}\tau_e(w)\) must satisfy \(\nu_e\cdot w<0\). Neutral channels are excluded even if their order is higher. If active channels tie at the top, one outward tied channel refutes the condition; one may not select a favorable tied edge or replace the test with a net-flux cancellation. Every maximizing tuple in (2) for a top active channel has that same top height among essential lifted arrows; a neutral channel can have a higher absolute height but remains excluded before maximization. Positive coefficients prevent cancellation within each channel's expanded support on a tie face; they do not rule out net cancellation between different channels, which the endotactic criterion does not use. This is precisely the source-arrow convention required by the power-law theorem.

The vectors of all lifted arrows are still the original \(\nu_e\), so their stoichiometric span is $S=\operatorname{span}\{\nu_e\}$. The positive class $(x_0+S)\cap\mathbb R^d_{>0}$ is unchanged. The lifted exponent diagram need not retain a chemical-complex or weak-reversibility interpretation; neither is needed for the endotactic power-law result.

## Clock and continuation proof

Assume the finite lifted diagram (2) is endotactic under the essential-source, all-top-ties rule, and assume the applicable power-law theorem says that every measurable edge-rate path in a fixed positive compact interval yields a unique global positive solution and a common compact positive absorber in each positive class. Let $x(t)$ be the maximal positive Carath\'eodory solution of (1), on $0\le t<T_\max$. The original vector field is measurable in time and locally Lipschitz in $x$ on the positive orthant: positive finite generalized polynomials and their positive denominators are smooth there. Thus the usual local existence and uniqueness theorem applies.

Define its accumulated lifted time by
\[
 s(t)=\int_0^t\frac{du}{D(x(u))}.
 \tag{5}
\]
On every compact subinterval of $[0,T_\max)$, $x$ has compact positive image and $D(x)$ is continuous and bounded above and bounded away from zero. Consequently $s(t)$ is strictly increasing with a locally Lipschitz inverse $t=t(s)$. Set $S_\max=\lim_{t\uparrow T_\max}s(t)\in(0,\infty]$, and $z(s)=x(t(s))$ for $s<S_\max$. The chain rule gives, almost everywhere,
\[
 z'(s)=D(z(s))f(t(s),z(s))
      =\sum_e k_e(t(s))\widetilde P_e(z(s))\nu_e,
 \qquad t'(s)=D(z(s)).
 \tag{6}
\]

The composed schedule $s\mapsto k_e(t(s))$ is Lebesgue measurable on $[0,S_\max)$. Indeed, on every compact subinterval before $S_\max$, $t(s)$ and its inverse are locally Lipschitz, so the inverse image under $t$ of a null set is null. Extend each composed schedule past $S_\max$, if $S_\max<\infty$, by any constant in $[\kappa,K]$. By (3), this defines an admissible measurable rate path for the lifted system on all $s\ge0$. The power-law theorem supplies its global positive solution $Z(s)$. Local uniqueness implies $Z(s)=z(s)$ for every $s<S_\max$.

This rules out a finite lifted-time endpoint. If $S_\max<\infty$, global continuity and positivity of $Z$ give a finite positive limit $Z(S_\max)$. Since $Z=z$ before $S_\max$,
\[
 t(s)=\int_0^s D(Z(u))\,du
\]
has a finite limit $T_*$ there. Since $t(s)$ is the inverse of $s(t)$, this forces $T_*=T_\max<\infty$. Also $x(t)\to x_*:=Z(S_\max)\in\mathbb R^d_{>0}$ as $t\uparrow T_\max$. The original schedule $k_e(t)$ is supplied beyond $T_\max$, and the original vector field is locally bounded and locally Lipschitz in $x$ near $x_*$ uniformly over its rate box. Carath\'eodory local existence therefore continues (1) from $(T_\max,x_*)$, contradicting maximality. Hence $S_\max=\infty$.

Let $\Omega$ be the compact positive absorber for the lifted class, and take $s_0<\infty$ such that $Z(s)\in\Omega$ for all $s\ge s_0$. Continuity and strict positivity of $D$ imply
\[
 d_0:=\min_{x\inΩ}D(x)>0,
 \qquad
 t(s)=\int_0^sD(Z(u))\,du\ge t(s_0)+d_0(s-s_0)\longrightarrow\infty.
 \tag{7}
\]
Therefore $t(s)$ covers all original times $[0,\infty)$; its inverse gives a global positive solution of (1), and $x(t)\in\Omega$ for all $t\ge t(s_0)$. This transfers permanence. The same argument also shows why a possible very slow clock near the boundary before absorber entry is harmless: absorber entry occurs at finite $s_0$, and $t(s_0)<\infty$ because $Z$ is positive and continuous on the compact interval $[0,s_0]$.

## Measurable schedules in the two-species base theorem

The cited CNP paper defines its $\kappa$-variable rates as piecewise differentiable (Definition 6), so Theorem 19 does not literally state the full measurable-rate interface. Its proof gives the needed extension with standard Carath\'eodory/viability tools:

1. On each face of the constructed polygon, the proof establishes the inward-normal inequality uniformly over the full compact rate box. In fact, Remark 6.1 states the boundary inequality pointwise for any rate vector in the box at that time. For measurable schedules the trajectory is absolutely continuous and satisfies the differential equation almost everywhere; the polygon is still invariant by the finite-facet Nagumo viability criterion, since the inequality holds for every allowed instantaneous rate vector.
2. In the annular entry argument, the scalar gauge $\Phi$ is locally Lipschitz and piecewise $C^1$ on a compact subset of the positive orthant. The proof's branchwise estimate supplies a common $\zeta>0$ such that $\nabla\Phi_j(x)\cdot f(x,k)\ge\zeta$ for every active smooth branch $j$, every point in that compact annulus, and every rate vector $k$ in the box. If $x(t)$ is a Carath\'eodory solution, $\Phi(x(t))$ is absolutely continuous. At almost every time the ordinary chain rule applies where $\Phi$ is differentiable; at branch ties the Clarke chain rule gives a convex combination of the active branch directional derivatives. Thus $(\Phi\circ x)'(t)\ge\zeta$ almost everywhere while the trajectory remains in the annulus. Integration forces entry into the inner invariant polygon in finite time.

This removes the rate-smoothness dependence from the two-species argument; it does not supply an alternative permanence theorem or alter the graph hypothesis. The source's Section 8.2 explicitly extends the argument to arbitrary real exponents, including negative exponents. At every stage polygons and the entry annulus lie in the positive orthant, where these vector fields are locally smooth; the boundary is handled by the positive invariant polygon, not by evaluating negative powers at zero.

## Failure modes outside the interface

- If some $Q_e$ has a zero in the positive orthant, then $D$ need not stay positive and the time change can stop or change orientation; denominator clearing is not justified.
- If a numerator has signed coefficients, leading terms can cancel on a tie face; (4) still gives a support upper bound but no longer certifies the actual leading asymptotic or the lifted graph test.
- If the original rates lack a uniform lower bound, the lifted edge rates may approach zero and the cited variable-rate permanence theorem does not apply. If they lack a finite upper bound, it likewise does not apply.
- If rates are arbitrary state-feedback laws rather than the specified exogenous measurable functions of original time, the composition and Carath\'eodory well-posedness need a separate formulation. The proof here makes no feedback claim.
- The change preserves each positive stoichiometric class, not weak reversibility or chemical complexes. Testing an unrelated stoichiometric graph in place of the lifted exponent-arrow graph is invalid.
- It does not identify trajectories at equal clock readings: $s$ and $t$ differ by (5), and a variable schedule is composed with this clock.

## Exact remaining gate

1. **Two species:** denominator clearing matches the real-exponent power-law interface in CNP Section 8.2: it explicitly allows any real source exponents and says Theorem 19 still applies. CNP Definition 6 states piecewise-differentiable rates, so cite the measurable extension through the explicit viability and absolutely-continuous gauge argument above, not as the theorem's literal original regularity statement. No additional clock gate remains in two species.
2. **Three or more species:** no new dynamics obstruction appears, but denominator clearing supplies only an equivalent finite power-law graph. Classwise rational-rate permanence follows only if the all-dimensional measurable-rate endotactic permanence candidate in work/agents/permanence_hostile/endotactic_permanence.tex is accepted or independently proved for this lifted class. The current status in that manuscript is internally reconstructed and externally unverified, so the rational-rate conclusion remains conditional there.
3. **Graph decision:** an exact finite test of the lifted-source tie rule (or its no-expansion support-function equivalent) is a separate input task. A tropical/endotactic pass is a graph property; it alone is not a permanence proof. A non-endotactic result, such as the one-species $\dot X=X^2-1$ example already recorded in the rational-lift note, has finite-time blow-up and confirms that the graph hypothesis cannot simply be dropped.

This audit finds no denominator-clock counterexample under the positive-coefficient rational interface and common two-sided measurable rate box. It repairs the compressed augmented-clock argument by first transforming a maximal original solution and then using the lifted theorem to prove continuation.
