# Prior-art audit and consequence analysis for the quantum tree comparator

## Verdict

The tree candidate occupies a distinct quantitative interface from the primary results located in this bounded review. Channel compatibility and incompatibility-breaking papers characterize when joint channels or joint measurements exist. Finite-copy de Finetti and approximate-broadcasting results give absolute trace/diamond approximation to measure-and-prepare channels. None of the inspected primary sources states the candidate's relative operator-order conclusion: for one unital, trace-preserving, Hilbert–Schmidt-selfadjoint, self-compatible channel Φ, find one EB map Ψ with

\[
I-\Psi\preceq 2\lceil\log_2(d^2-1)\rceil(I-\Phi)
\]

on the full Hermitian Hilbert–Schmidt space. The prior-art search is bounded, so the right status remains **internal proof candidate; novelty and independent validation open**.

The candidate proof's key interfaces survive this audit: a supplied two-output extension of Φ is iterated to 2^m leaves for Φ^m; one spectral PVM per tested Hermitian direction is pulled back to the input; a weighted-score inequality is established for the resulting POVM; and cone separation turns every positive-frame support inequality into one common canonical EB map. This extends the target from the N93-unproved unrestricted factor-c Dirichlet comparison to an explicit logarithmic dimension factor, under the stated finite-dimensional exact-channel assumptions. It does **not** close N93's bounded-Holevo plus vanishing-two-marginal-error implication.

## What the primary literature already gives

Self-compatibility is 2-self-extendibility of a channel and is equivalent to antidegradability. It is much weaker than entanglement breaking: a channel that has extensions to every output count is EB, but one two-output extension does not give an EB representation. This pins down why the binary-tree hypothesis is substantive and why it cannot be paraphrased as “the channel is already classical.”

The incompatibility-breaking literature is the closest conceptual neighbor. If a channel has a K-output extension, the images of any selected K output POVMs can be jointly measured by measuring one POVM on each output and pulling the product measurement back. That is a finite-wise compatibility statement. The literature explicitly separates finite-n incompatibility breaking from full incompatibility breaking and shows strict levels; EB is strictly stronger than incompatibility breaking. Thus the tree's measurement compatibility is a proof ingredient, not the conclusion.

Xie–Fang–Wang–Duan give an approximate-broadcasting result at channel level: for an arbitrary n-output CPTP map, one common input POVM yields EB approximations to most marginal channels in diamond norm, with error at most

\[
3\left(\frac{(\ln 2)d^6\log_2 d}{n\delta^3}\right)^{1/3}
\]

for at least n(1-δ) marginals. That is absolute channel distance, while the tree candidate controls the Dirichlet form of one EB map relative to I-Φ. At n around d², the displayed dimension dependence does not provide a small diamond error. Conversely, the tree theorem does not assert diamond closeness, preservation of ancillas, or a channel-capacity bound.

N92 and earlier C4 records contain stronger factor-2 comparisons on concrete supplied classes: bistochastic instrument/Kraus channels after a Petz correction, Lüders channels, and qubit channels, alongside scoped Weyl constructions. Those results depend on structure not present in the unrestricted self-compatible interface. The N93 source record explicitly left the general EB Dirichlet lift open and explains why simple pair-gap or finite-copy arguments do not settle it.

## Direct consequences and stronger restricted bounds

### Low-dimensional test families

The frame step works in any fixed real test subspace V of Hermitian matrices of dimension s. For every positive quadratic witness Q supported on V, rank(Q) is at most s, so the construction uses

\[
m=\lceil\log_2 s\rceil,\qquad K=2^m<2s
\]

leaves (with K=1 when s=1). Restricted cone separation gives one canonical EB map Ψ_V satisfying

\[
\langle A,(I-\Psi_V)A\rangle_\tau\le 2m\,\langle A,(I-\Phi)A\rangle_\tau
\quad\text{for every }A\in V.
\]

For a family \(\mathcal H\subset V\) with \(\|H\|_\infty\le\theta<1\) and residual \(r_V=\sup_{H\in\mathcal H}\|\Phi(H)-H\|_{1,\tau}\), this gives the archive-style bound

\[
\sup_{H\in\mathcal H}\frac12\|\Psi_V((I+H)/d)-(I+H)/d\|_1
\le \frac12\sqrt{2\lceil\log_2s\rceil\,\theta r_V}.
\]

So, once the EB channel is available, its outcome label is a classical memory that reconstructs every state in the specified family to this trace-distance tolerance. This is a model-level sufficiency statement, not a sample-complexity guarantee. If V is contained in a commutative algebra, its common spectral measurement gives an EB pinching map that fixes every member of V exactly (c=0), with no broadcaster calls. For a finite family of N perturbations, s is at most N; for a p-parameter linear model, s is at most p.

For the full channel order, the identity direction can be removed: both I-Φ and I-Ψ annihilate I, and self-adjointness kills the cross terms. Hence it suffices to use the traceless space, s=d²−1, giving the stated 2ceil(log₂(d²−1)) factor. A frame of mutually commuting observables can be grouped onto one receiver per common eigenbasis; if q commuting classes cover the frame, the same proof replaces s by q. This is an internal refinement of the tree construction, and q can be far below frame rank in structured problems.

There is also an exact finite-outcome compression of any canonical comparator produced by the compact-convex argument. Set n=d², and for each POVM effect M_z with p_z=τ(M_z)>0 write S_z=M_z/p_z. Then τ(S_z)=1, sum_z p_z S_z=I, and

\[
\Psi_M=\sum_z p_z\,|S_z\rangle\langle S_z|.
\]

Here \(|S_z\rangle\langle S_z|\) denotes the rank-one superoperator on the real Hermitian Hilbert–Schmidt space. The map is determined by the first and second moments of S_z. The lifted moment vector lies in a real space of dimension h+h(h+1)/2 with h=d², so Caratheodory gives an exact representative with at most

\[
\frac{d^4+3d^2}{2}+1
\]

POVM outcomes. This improves the bare statement “a finite-outcome representative exists.” It is a size bound only; the separating argument does not provide an efficient construction or optimizer.

### Spectral-gap / quantum-expander case

If Φ has a Hilbert–Schmidt spectral gap \(\gamma>0\) on traceless operators, there is a simpler dimension-free comparator. Let \(\Delta(X)=\tau(X)I\), the depolarizing EB map. On the identity direction, both Dirichlet operators vanish; on the traceless subspace, \(I-\Delta\) is the identity and \(I-\Phi\succeq\gamma I\). Therefore

\[
I-\Delta\preceq\gamma^{-1}(I-\Phi).
\]

This requires no compatibility assumption and can improve the tree factor whenever \(\gamma^{-1}<2\lceil\log_2(d^2-1)\rceil\). It is just the usual spectral-gap inequality with an EB comparator. It does not help when slow nontrivial modes make \(\gamma\to0\); those are precisely where the tree's dimension factor is relevant.

For a target subspace V it is enough to have a restricted gap \(\gamma_V\) there. The same Δ gives \(\langle A,(I-\Delta)A\rangle\le\gamma_V^{-1}\langle A,(I-\Phi)A\rangle\) for A in V. Thus, for a family-specific claim, an available bound is the smaller of the tree factor and \(\gamma_V^{-1}\).

### Finite entanglement-breaking index

If an HS-selfadjoint unital/trace-preserving channel has a finite EB index n, then \(\Psi=\Phi^n\) is an EB comparator. Since spec(Φ)\subset[-1,1] and

\[
\frac{1-\lambda^n}{1-\lambda}=\sum_{j=0}^{n-1}\lambda^j\le n,
\]

functional calculus gives \(I-\Phi^n\preceq n(I-\Phi)\). The comparator here is a general EB map; this argument does not establish that \(\Phi^n\) belongs to the candidate's narrower canonical measurement class. The 2026 Park preprint proves all PPT maps have finite EB index and gives n\le3 on its DSP₂ PPT subclass, which yields c\le3 for channels there. This is a stronger bound on a sharply restricted class, not a collision with the all-self-compatible theorem.

## Quantitative application: metastable observable families

Suppose \(\Phi\) has an invariant s-dimensional real subspace V of traceless Hermitian observables and all eigenvalues on V lie in [1-η,1]. The tree comparator satisfies, for every A in V,

\[
\langle A,(I-\Psi_V)A\rangle_\tau\le 2\lceil\log_2s\rceil\,\eta\,\|A\|_{2,\tau}^2.
\]

Because \(0\preceq I-\Psi_V\preceq I\), its square is below itself. Thus

\[
\|(I-\Psi_V)A\|_{2,\tau}\le\sqrt{2\lceil\log_2s\rceil\,\eta}\,\|A\|_{2,\tau}.
\]

For bounded tracial likelihood states \(\rho_A=(I+A)/d\) with \(\|A\|_\infty\le\theta\), one EB map therefore reconstructs the whole family with

\[
\sup_A\frac12\|\Psi_V(\rho_A)-\rho_A\|_1
\le \frac{\theta}{2}\sqrt{2\lceil\log_2s\rceil\,\eta}.
\]

This is a static state-family result: slow modes of a self-compatible reversible channel can be archived classically to the stated precision. It does not show that a classical controller reproduces transitions under interventions, that correlated inputs are preserved, or that a quantum reference/ancilla is reconstructed. The same theorem applies to state acquisition only after an EB map is actually constructed and the number of independent preparations used to estimate its outcomes is charged; no such finite-sample protocol is supplied here.

## Costs, assumptions, and limits

The theorem inherits an exact supplied two-output broadcaster \(\mathcal B\). For a subspace of dimension s, the explicit frame construction has K<2s output receivers and K−1 uses of \(\mathcal B\), each acting on a d-dimensional register. Its raw product POVM may have d^K outcomes. The universal comparator comes from cone separation across all positive witnesses and is existential; although an exact O(d⁴)-outcome canonical POVM exists, no polynomial-time method to find it, finite-precision stability bound, device calibration procedure, or acquisition protocol is proved.

No physical samples or channel tomography are charged by the algebraic theorem because \(\Phi\) and \(\mathcal B\) are supplied exactly. In an experiment, learning/checking those channels, implementing the tree at K≈d² (or K≈s), detector precision, and repeated preparations all add cost. Error in the supplied channels is not covered. The likelihood corollary applies to a bounded tracial perturbation family; it is not uniform over arbitrary states, entangled references, or arbitrary correlated sequences.

## Decision

The most defensible novelty boundary is a candidate theorem for a universal logarithmic-dimensional EB Dirichlet comparator, based on an iterated broadcaster and finite-frame cone separation. Prior results settle the vocabulary and concrete subfamilies, but the inspected sources do not state this operator-order theorem. The clearest next mathematical target is to replace frame rank by a dimension-free common measurement/rounding lemma or construct a self-compatible channel and dual frame forcing growth of the best comparator constant. The clearest useful restricted theorem is the gap bound above, with the tree used only on slow subspaces. No claim of external review, proof certification, or historical priority is made.

## Weighted-tree audit update

The separate variable-depth candidate in [`WEIGHTED_AUDIT.md`](WEIGHTED_AUDIT.md) passed an internal audit of its all-PSD transform, Jensen direction, prefix-tree score inequality, separation, and singular fixed-point limit. It yields the spectral profile C4-Q3, but an explicit dephasing/cloner mixture shows that this profile does not uniformly dominate the earlier equal-depth bound. Pruning dummy leaves gives a full tree with exactly one broadcaster call per internal node, so a rank-r dual witness can be handled with r−1 calls. Restricting separation to the compact convex hull of those tree PVM maps also gives a finite randomized tree realization of the common comparator, still nonconstructive.

The same audit derives a prior-covariance Huffman bound and, by minimax over convex squared reconstruction loss, a finite-family uniform EB criterion controlled by the worst-prior energy-weighted effective entropy. It is dimension-free when that statistic is bounded, but no bounded-Holevo argument currently controls it. Exact commuting-context reuse is another restricted acquisition result; approximate joint rounding remains a possible route with tuple-size and positivity assumptions explicitly charged.
