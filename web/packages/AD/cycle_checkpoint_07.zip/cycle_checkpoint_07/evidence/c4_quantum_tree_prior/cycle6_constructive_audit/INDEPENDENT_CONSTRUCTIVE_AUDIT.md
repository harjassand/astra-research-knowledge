# Independent audit: residual-completion compiler

Date: 2026-10-08. Target: `work/agents/c4_quantum_lift/cycle6_constructive_comparator/CONSTRUCTIVE_COMPILER.md` and its residual-completion claim. This is an internal audit; it is neither external proof review nor a priority determination.

## Verdict

The residual-completion step is correct and materially improves the construction: it converts sampled tree states into an **explicit, polynomial-outcome canonical EB channel**, rather than leaving the comparator as an exponentially-outcome tree protocol. The normalization, positivity, unitality, trace preservation, HS self-adjointness, and Loewner lower bound all check out. The exact recursive sampler and matrix concentration bounds also fit the stated rational dense-input model.

I find no obstruction to the finite-bit compiler, provided its implementation contract is stated as follows: rational/algebraic finite input with exact validity checks; high-probability success (with an explicit failure/default-output branch); polynomial-precision eigensolver and matrix-exponential routines; exact rational PVM effects; and all accumulated numerical errors charged to the requested slack. The report has a small missing-plus-sign typo in its MMW display (17). The novelty boundary is the combined tree support oracle plus exact residual POVM completion plus common finite mixture, not matrix concentration or matrix MW themselves.

## Residual completion, including all normalizations

Let (E_z) be the full tree pullback effects, (p_z=\tau(E_z)=\operatorname{Tr}(E_z)/d), and (\rho_z=E_z/\operatorname{Tr}(E_z)). Since (\sum_zE_z=I),

\[
\mathbb E_p\rho_z=\sum_z\frac{\operatorname{Tr}E_z}{d}\frac{E_z}{\operatorname{Tr}E_z}=I/d.
\]

For (v_z=\rho_z-I/d), the canonical tree map restricted to the traceless Hermitian space is

\[
\Psi_{Q,0}=d^2\,\mathbb E_p[|v_z\rangle\langle v_z|_\tau].
\]

This follows directly from (\Psi_Q(X)=\sum_z\operatorname{Tr}(E_zX)\rho_z\), using (\operatorname{Tr}(\rho_zX)=d\tau(\rho_zX)) and (\tau(X)=0). Thus the empirical matrix

\[
\widehat C=\frac{d^2}{N}\sum_{i=1}^N|v_i\rangle\langle v_i|_\tau
\]
is an unbiased estimate of (\Psi_{Q,0}). Its summands (Y_i=d^2|v_i\rangle\langle v_i|_\tau\) are PSD and

\[
\|Y_i\|=d^2\tau(v_i^2)=d\operatorname{Tr}(\rho_i^2)-1\le d-1,
\qquad Y_i^2\preceq(d-1)Y_i.
\]

The variance proxy is at most (d I), since (\Psi_{Q,0}\preceq I). Tropp matrix Bernstein therefore yields an operator-norm error (\varepsilon) with (N=O(d\varepsilon^{-2}\log(nT/\eta))); the displayed tail denominator (2d+(2/3)d\varepsilon) is consistent with the centered summand norm and variance bound.

Now write (S=N^{-1}\sum_i\rho_i). Matrix Chernoff applied to (0\preceq\rho_i\preceq I), with expectation (I/d), gives

\[
\Pr\{dS\npreceq(1+\alpha)I\}\le d\exp[-N\alpha^2/(3d)]\quad(0<\alpha\le1).
\]

On this event's complement, set (c=(1+\alpha)^{-1}) and

\[
M_i=\frac{cd}{N}\rho_i,\qquad M_0=I-cdS.
\]

Then (M_i\succeq0), (M_0\succeq0), and (\sum_{i=0}^NM_i=I). For (i\ge1), (\operatorname{Tr}M_i=cd/N), so the canonical preparation state (M_i/\operatorname{Tr}M_i) is exactly (\rho_i). Also (\operatorname{Tr}M_0=d(1-c)>0) for α>0, and the residual state is (\rho_0=M_0/[d(1-c)]).

The canonical channel

\[
\widehat\Psi_Q(X)=\sum_{i=0}^N\operatorname{Tr}(M_iX)\frac{M_i}{\operatorname{Tr}M_i}
\]

is EB and TP because the effects sum to (I), unital because (\sum_i\operatorname{Tr}(M_i)M_i/\operatorname{Tr}(M_i)=I), and HS-self-adjoint/HS-positive because each summand is a positive rank-one quadratic form. On the traceless space its first (N) outcomes give (c\widehat C), while the residual gives

\[
\frac{d}{\operatorname{Tr}M_0}|P_0M_0\rangle\langle P_0M_0|_\tau\succeq0.
\]

Therefore (\widehat\Psi_{Q,0}\succeq c\widehat C). If (\|\widehat C-\Psi_{Q,0}\|\le\varepsilon) and the noisy/approximate-tree support loss is (\xi_{\rm tree}), then for any density witness (Q\succeq0\), (\operatorname{Tr}Q=1),

\[
\begin{aligned}
\operatorname{Tr}Q(\widehat\Psi_{Q,0}-J)
&\ge c\operatorname{Tr}Q(\Psi_{Q,0}-J)-(1-c)\operatorname{Tr}(QJ)-c\varepsilon\\
&\ge-\xi_{\rm tree}-(1-c)-\varepsilon,
\end{aligned}
\]

because (\lambda_{\max}(J)\le1). This verifies the critical direction: residual completion can only add a PSD operator, and scaling the empirical main part costs at most (1-c\le\alpha). No whitening, matrix inverse square root, or conditioning assumption on (S) is needed.

An exact PSD postcheck of (M_0) is appropriate. On failed postcheck, the compiler must discard that response batch and resample or return a fixed valid EB fallback while counting the event against its failure probability; it must not emit a non-POVM. All response randomness is fresh conditional on the current MW query, so Bernstein and Chernoff tails union-bound over adaptive rounds.

## Tree sampler, dependence, and operation counts

The recursive conditional-state sampler is correct. At a node, form (Y=\mathcal B(X)), recurse on (X_L=\operatorname{Tr}_R Y), and, after the selected left effect (E_L), recurse on the unnormalized positive state (X_R=\operatorname{Tr}_L[(E_L\otimes I)Y]). The product of the left probability and the conditional right probability is

\[
\frac{\operatorname{Tr}[(E_L\otimes E_R)Y]}{\operatorname{Tr}X}
=\frac{\operatorname{Tr}[X\mathcal B^*(E_L\otimes E_R)]}{\operatorname{Tr}X},
\]

which proves the joint law by induction and retains sibling correlations. For (X=I/d) the law is exactly (p_z=\tau(E_z)). Unnormalized conditional states avoid inverse-small-probability matrix normalization.

For an equal-depth tree, (K=2^m<2(d^2-1)). A returned sample and its root effect need (O(K)) forward and adjoint dense contractions; each dense contraction costs (O(d^6)), so one sample costs (O(d^8)) arithmetic operations. The final exact rational effect/state for a sample has polynomial bit length in (K) and the input bit length (L). Exact rational categorical sampling has expected polynomial bit cost independent of (p_{\min}); capping rejection loops at (O(\log(TNK/\eta))) attempts makes runtime worst-case polynomial and spends a separately budgeted failure probability.

With (T=O(m^2\log n/\delta^2)) MW rounds and (N=O(d\delta^{-2}\log(dTn/\eta))) samples per round, the conservative leading dense-arithmetic count is

\[
O(TNKd^6)=O(d^9m^2\log n\,\delta^{-4}\log(dTn/\eta)),
\]

in addition to polynomial-bit matrix exponentials, local diagonalizers, and exact rational arithmetic. The broadcaster input itself has (\Theta(d^6)) entries. The final union POVM has (D=T(N+1)=O(d\,m^2\log n\,\delta^{-4}\log(dTn/\eta))) outcomes and (O(Dd^2)) listed effect/state entries. After compilation it is an ordinary finite measurement-and-preparation channel; running the output channel need not call the broadcaster. The result assumes a dense classical description of (\mathcal B), not a device-only black box.

## Finite-bit implementation obligations

These details make the stated rational-input algorithm plausible without introducing algebraic-eigenvalue or rare-event blowups:

1. **Exact local PVMs.** For each rational Hermitian frame observable (A_i), obtain an approximate diagonalizer (U_i) with Frobenius residual (\|A_i-U_i\operatorname{diag}(U_i^*A_iU_i)U_i^*\|_2\le\zeta\|A_i\|_2). This is a backward-stable Hermitian eigensolver task and needs no eigenvalue-gap bound: near-degenerate rotations have small observable error. Approximate the resulting unitary by a product of exactly unitary rational two-level gates (rational points are dense in the two-level unitary groups); the projectors (P_y=U|y\rangle\langle y|U^*\) are then rational, exactly orthogonal, and sum exactly to (I). Quantize the gate factors so the extra diagonalization residual is within the same (\zeta) budget. Smoothing (F_y=(1-\gamma)P_y+\gamma I/d) preserves an exact rational POVM and gives the stated probability floor.

2. **Exact PSD MW queries.** Use a fixed rational Hermitian basis of (\mathcal H_0) with rational positive Gram matrix (S); for example, off-diagonal (E_{ij}+E_{ji}), (i(E_{ij}-E_{ji})), and diagonal (D_k=\sum_{j=1}^kE_{jj}-kE_{k+1,k+1}) are mutually orthogonal with rational (\tau)-norms. In coordinates, an HS-self-adjoint loss matrix (H_t=\sum_{s<t}D_s) obeys (S H_t=H_t^T S), so (S\exp(\eta H_t)) is symmetric positive. Approximate its shifted square root by a rational matrix (W_t), then set

   \[
   \widetilde Q_t=\frac{S^{-1}W_tW_t^T}{\operatorname{Tr}(S^{-1}W_tW_t^T)}.
   \]

   This is an exactly rational positive, HS-self-adjoint trace-one query. If (w_j) are the columns of (W_t), then (Q_t=z^{-1}\sum_j|S^{-1}w_j\rangle\langle S^{-1}w_j|\); this weighted Gram frame can either be carried with rational weight (z^{-1}), or converted to the unweighted factor by multiplying columns by the one quadratic algebraic scalar (z^{-1/2}). Recompute from the exact cumulative losses each round rather than recursively propagating rounded exponentials. Shift the exponent by an approximate largest eigenvalue before evaluation; its spectral range is (O(\eta TR)=O(R\log n/\delta)), so the necessary fixed precision is polynomial in (d,1/\delta,L,\log(1/\eta)). Charge the query trace-norm error (\theta_Q) as (R\theta_Q) in the support score.

3. **MW sign and display.** For losses (D_t=J-\widehat\Psi_{t,0}), use the maximizing update (Q_t\propto\exp(+\eta\sum_{s<t}D_s)). The plus sign is essential: the regret controls the largest eigenvalue of average loss. The report's (17) is missing a plus between (T^{-1}\sum_t\operatorname{Tr}(Q_tD_t)) and (\log n/(\eta T)+\eta R^2); the surrounding text and choice (\eta=\delta/(4R^2)), (T\ge16R^2\log n/\delta^2) use the intended bound. Compute each query from the exact cumulative, already-computed (D_s), then approximate it to trace-norm (\theta_Q\); this avoids uncontrolled round-to-round drift. Set all local PVM, response, and query errors so their sum is at most the support-error budget (for example (\delta/4)); the regret and support terms then fit within additive (\delta).

4. **Exact validity and failure handling.** Rational Choi PSD, trace-preservation, swap symmetry, and marginal equalities admit exact polynomial-time verification. For every completed response, rational symmetric LDL/Schur-complement checks certify (M_0\succeq0); verify the POVM sum exactly. If a certificate fails, retry a bounded number of times or return a fixed valid EB fallback and count the branch as compiler failure. The Chernoff event makes such retries rare, and the union bound includes them. A valid fallback means the routine always emits a valid channel, while the comparator inequality is guaranteed on the stated high-probability event.

These are constructive bit-model details, not an implemented code artifact or hardware test. In particular, if input entries are arbitrary exact reals without a finite representation, the polynomial-bit claim is undefined; if the broadcaster is only an experimental device, dense contractions and postchecks require a separate learned/certified channel model.

## Matrix-weights and adaptive concentration check

The source report uses (\eta) for both the requested failure probability and the MW learning rate. These should be renamed separately (for example, (\eta_{\rm fail}) and (\mu)) throughout the theorem statement and pseudocode; this is notation only, not a mathematical defect.

Write (J=I-2mG), (D_t=J-\widehat\Psi_{t,0}), and (Q_t\propto e^{+\eta\sum_{s<t}D_s}). The exact tree response to (Q_t) has payoff (\operatorname{Tr}Q_t(\widehat\Psi_{t,0}-J)\ge-e\), equivalently (\operatorname{Tr}(Q_tD_t)\le e). With (\|D_t\|\le R=4m+1), standard matrix exponential-weights regret gives

\[
\lambda_{\max}\!\left(\frac1T\sum_tD_t\right)
\le \frac1T\sum_t\operatorname{Tr}(Q_tD_t)
+\frac{\log n}{\eta T}+\eta R^2.
\]

Thus (e\le\delta/4), (\eta=\delta/(4R^2)), and (T\ge16R^2\log n/\delta^2) are sufficient up to harmless conservative constants. Since each round draws fresh samples and the concentration inequalities hold conditional on the full past, union-bounding over (T) adaptive rounds is valid. The finite channels in the losses are known exactly after their rational samples are drawn; the outer compiler does not need to treat their covariance matrices as unknown after construction.

## Prior-art boundary (primary sources checked)

* Heinosaari–Miyadera, [*Incompatibility of quantum channels*](https://arxiv.org/abs/1608.01794), frames compatibility as existence of a joint broadcasting channel and gives antidegradability/compatibility characterizations. Heinosaari–Kiukas–Reitzner–Schultz, [*Incompatibility breaking quantum channels*](https://arxiv.org/abs/1504.05768), studies joint measurability after a channel and distinguishes finite incompatibility breaking from EB. These are the right interface vocabulary, but neither gives a common EB Loewner comparator from only 2-self-compatibility.
* Xie–Fang–Wang–Duan, [*Approximate broadcasting of quantum correlations*](https://arxiv.org/abs/1705.06071), Lemma 3, gives absolute diamond-norm closeness of most marginals of an (n)-output channel to EB channels, with dimension/copy dependence. Chiribella, [*On quantum estimation, quantum cloning and finite quantum de Finetti theorems*](https://arxiv.org/abs/1010.1875), Theorem 2.2, gives a finite de Finetti/measure-and-prepare approximation for many-output symmetric broadcast channels, with an error that shrinks with output count. Neither applies to the binary iterates as an (M)-output extension of the same (\Phi): every depth-(m) leaf has marginal (\Phi^m), not (\Phi). The candidate's relative Dirichlet order, two-output premise, and explicit rational finite response are different.
* A very recent preprint, Ye–Bergh–Datta, [*Quantum de Finetti theorems for states and channels in any distance measure*](https://arxiv.org/abs/2609.40343) (submitted 2026-09-30), proves channel de Finetti statements for permutation-covariant maps (A^{\otimes n}\to B^{\otimes n}) and CP-order approximations of reduced channels. That input/output interface differs from a single-input self-broadcaster, so it is not a collision; it should be retained in any future priority search.
* Tropp, [*User-Friendly Tail Bounds for Sums of Random Matrices*](https://arxiv.org/abs/1004.4389), supplies the standard matrix Bernstein/Chernoff tools used here. Arora–Hazan–Kale, [*The Multiplicative Weights Update Method: a Meta-Algorithm and Applications*](https://theoryofcomputing.org/articles/v008a006/v008a006.pdf), supplies the standard matrix-MW/SDP-feasibility layer. The new seam is how a tree support response is sampled, made into an exact canonical finite channel by rational completion, and combined into one common comparator; no novelty claim is made for these standard tools.

This source search is bounded. It identifies no exact collision with the constructive theorem; it does not establish historical priority.

## Consequential capability that survives

The explicit comparator is useful as a **static EB acquisition proxy for slow observable modes**. Because each canonical map is a sum of positive HS rank-one forms, (0\preceq\widehat\Psi\preceq I), hence ((I-\widehat\Psi)^2\preceq I-\widehat\Psi). For a traceless Hermitian (H) with (\|H\|_\infty\le\theta), ρ_H=(I+H)/d\succeq0, and (\|\Phi(H)-H\|_{1,\tau}\le r), the common-channel guarantee implies

\[
\frac12\|\widehat\Psi(\rho_H)-\rho_H\|_1
\le\frac12\sqrt{\langle H,(I-\widehat\Psi)H\rangle_\tau}
\le\frac12\sqrt{2m\,\theta r+\delta\theta^2}.
\]

The first inequality uses normalized Schatten monotonicity and the spectral inequality above; the second uses (\langle H,(I-\Phi)H\rangle_\tau\le\|H\|_\infty\|\Phi(H)-H\|_{1,\tau}). Thus a single explicit measure-and-prepare channel reconstructs every specified bounded tracial likelihood along a slow sector, with an error that scales like (\sqrt{\log d\,\theta r+\delta\theta^2}). This is a static acquisition/readout statement. It does not simulate multi-time controlled dynamics, preserve entanglement with a reference, infer the broadcaster from experimental data, or follow from bounded Holevo information alone. Costs are the (\widetilde O(d^9\delta^{-4})) offline dense arithmetic compiler, (\Theta(d^6)) input coefficients, and (D=T(N+1)) deployed outcomes; a device-only channel requires tomography/certification not included here.

## Claim boundary

**Internally audited candidate:** for rational dense (\mathcal B), the tree support proof and residual-completion/MW construction give, with probability (1-\eta), an explicitly listed canonical EB channel with (D=T(N+1)) outcomes satisfying

\[
I-\widehat\Psi\preceq 2\lceil\log_2(d^2-1)\rceil(I-\Phi)+\delta I.
\]

**Not established:** external verification, priority, an improved uniform coefficient over (2\lceil\log_2(d^2-1)\rceil), a dimension-free bounded-Holevo lift, an efficient compiler from a physical black box, or experimental validation. The stated cost is for a finite dense classical description and a classical output list.
