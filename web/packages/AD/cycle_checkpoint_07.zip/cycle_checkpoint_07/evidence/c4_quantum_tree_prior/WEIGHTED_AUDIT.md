# Independent audit of C4-Q3 weighted tree

## Verdict

I find no mathematical defect in the weighted-tree comparison as stated in `work/agents/c4_quantum_lift/WEIGHTED_TREE.md`. The all-PSD congruence, the sign of the logarithmic Jensen step, the Kraft construction, the score refinement, compact-convex separation, and the singular ε-limit are valid under the stated finite-dimensional, unital, trace-preserving, HS-selfadjoint, two-output-broadcast assumptions. This is an internal second-pass check, not external proof review or novelty clearance.

The advertised profile

\[
I-\Psi\preceq 2G\bigl[I+\log_2(T/G)\bigr],\qquad
G=I-\Phi,\quad T=\operatorname{Tr}_{HS,\mathcal H_0}G,
\]

is a valid common-canonical-EB bound on the traceless Hermitian space, with the scalar right side set to zero at a zero gap. It is a Pareto/spectral-allocation guarantee, not a uniform improvement over the equal-depth result: its relative coefficient diverges on sufficiently small nonzero gaps. No inspected primary source states this exact relative operator-order theorem. The bounded-Holevo lift in N93 remains open.

## Proof audit

**Positivity and regularization.** Unital complete positivity and trace preservation imply the normalized-HS contraction inequality by Kadison–Schwarz and trace preservation. HS selfadjointness therefore puts every eigenvalue of \(\Phi\) in \([-1,1]\), so \(G=I-\Phi\succeq0\). If \(G=0\) on \(\mathcal H_0\), then \(\Phi=I\) on the full Hermitian space, contradicting no-broadcasting for \(d\ge2\). Thus \(T>0\). For \(K=G+\varepsilon I\), \(K\) is positive definite and commutes with \(G\); \(\omega=K/\operatorname{Tr}K\) is a full-rank density operator on \(\mathcal H_0\).

**All-PSD transformation and energy weights.** For arbitrary \(Q\succeq0\), not just a diagonal or rank-one test, set \(R=K^{1/2}QK^{1/2}=\sum_i r_i|u_i\rangle\langle u_i|\) over its positive eigenvalues and \(A_i=K^{-1/2}u_i\). Then

\[
Q=\sum_i r_i|A_i\rangle\langle A_i|,\quad
\langle A_i,KA_i\rangle=1,\quad
e_i:=\langle A_i,GA_i\rangle\in[0,1].
\]

The last inequality is exactly \(0\preceq G\preceq K\); no commutation between \(Q\) and \(G\) is needed. This is the key congruence that turns a general positive dual witness into a frame whose members have unit regularized energy.

**Score and spectral inequality.** For a spectral PVM \(A=\sum_y a_yP_y\), the one-leaf pullback \(E_y=\Phi^\ell(P_y)\) has \(p_y=\tau(E_y)=\tau(P_y)>0\) for each nonzero projection. HS selfadjointness gives the exact identity

\[
\sum_y\frac{\tau(E_yA)^2}{p_y}
-2\langle A,\Phi^\ell(A)\rangle_\tau+\|A\|_{2,\tau}^2
=\sum_y\frac{(\tau(E_yA)-a_yp_y)^2}{p_y}\ge0.
\]

The joint tree POVM refines this marginal PVM; weighted Cauchy–Schwarz says its canonical score is no smaller. The scalar estimate \(\lambda^\ell\ge1-\ell(1-\lambda)\) holds for every integer \(\ell\ge0\) and \(\lambda\in[-1,1]\): Bernoulli proves the nonnegative case, and for \(\lambda<0\) the right side is at most \(\lambda\) at \(\ell=1\) and at most \(-1\) for \(\ell\ge2\). Hence

\[
\langle A,\Psi_M A\rangle_\tau\ge
\|A\|_{2,\tau}^2-2\ell\langle A,GA\rangle_\tau.
\]

Summing against \(r_i\) gives \(\operatorname{Tr}_{HS}(Q\Psi_M)\ge\operatorname{Tr}_{HS}Q-2\sum_i r_i\ell_i e_i\ge\operatorname{Tr}_{HS}Q-2\sum_i r_i\ell_i\). Thus the replacement of each frame energy \(e_i\) by 1 has the correct direction.

**Log/Jensen and Kraft direction.** With \(q_i=\langle u_i,\omega u_i\rangle>0\), \(\sum_iq_i\le1\). Since the scalar logarithm is concave,

\[
\log\langle u_i,\omega u_i\rangle\ge
\langle u_i,(\log\omega)u_i\rangle,
\quad\text{so}\quad
-\log q_i\le\langle u_i,(-\log\omega)u_i\rangle.
\]

The sign in the manuscript is correct. Lengths \(\ell_i=\lceil-\log_2q_i\rceil\) obey \(2^{-\ell_i}\le q_i\), hence Kraft. The ceiling contributes the positive additive \(\sum_i r_i=\operatorname{Tr}R\). As \(R\)'s eigenvectors diagonalize the trace pairing,

\[
\sum_i r_i\ell_i\le \operatorname{Tr}_{HS}(QK)
+\operatorname{Tr}_{HS}\!\left(QK^{1/2}\log_2\!\frac{\operatorname{Tr}_{HS}K}{K}K^{1/2}\right).
\]

The matrix expression is well-defined because \(\omega\) is a scalar multiple of \(K\). No illegitimate cyclic rearrangement of noncommuting factors occurs.

**Tree leaves and total channel-use cost.** Completing the Kraft code with dummy leaves is valid: its prefix trie is finite, each leaf at depth \(\ell_i\) has marginal \(\Phi^{\ell_i}\), and the dummy outputs are measured trivially. There is a useful cost tightening. Delete dummy leaves and suppress every resulting unary vertex. The remaining tree is full, has exactly \(r=\operatorname{rank}R=\operatorname{rank}Q\) real leaves, and each real-leaf depth can only decrease. It therefore preserves every score lower bound, uses exactly \(r-1\) broadcaster invocations, and outputs only \(r\) receiver systems. The raw product PVM has at most \(d^r\) outcomes. The weighted mean depth controls the proof's *Dirichlet score penalty*; it is not the total number of broadcaster invocations. For a fixed dual witness the latter is linear in frame rank, independent of how uneven the lengths are.

**Common map by separation.** Let \(\mathcal S_0\) be the set of canonical maps produced by product PVMs on any full binary tree with at most \(n=d^2-1\) real receiver leaves, each tree node using the supplied symmetrized broadcaster. There are finitely many tree shapes for this leaf bound. Each local PVM has at most \(d\) outcomes and varies over a compact set; pulling back through the fixed tree and forming the canonical map is continuous (terms for zero effects extend continuously by zero). Thus \(\mathcal S_0\) is compact. Its convex hull \(\mathcal S\) is compact and consists of canonical maps, with a random strategy label retained as an outcome.

For every \(Q\succeq0\), the frame construction above supplies a witness in \(\mathcal S_0\). Hence its support function over \(\mathcal S\) satisfies the dual inequality. If \(\mathcal S\) missed the closed translate \(A_\varepsilon+\mathrm{PSD}\), strict separation of a compact set and a disjoint closed convex set would yield a positive-semidefinite separator \(Q\) violating that support inequality. This yields one \(\Psi_\varepsilon\in\mathcal S\), not just a different comparator for each \(Q\).

This also sharpens implementation accounting relative to the loose raw tree description: by Caratheodory, \(\Psi_\varepsilon\) can be expressed as a finite mixture of at most \(D+1\) tree strategies, where \(D\le d^2(d^2+1)/2\) is a safe ambient dimension for selfadjoint superoperators. Each run chooses one strategy and uses at most \(n-1=d^2-2\) broadcaster calls and at most \(n\) receivers; it need not run every mixture component. The strategy mixture is still nonconstructive, and its raw classical outcome count can be enormous. This is an existential finite realization, not an efficient circuit compiler.

**\(\varepsilon\downarrow0\).** On an eigenvector of \(G\) with gap \(g\), the right side of the regularized bound has eigenvalue

\[
f_\varepsilon(g)=2(g+\varepsilon)\left[1+\log_2\frac{T+n\varepsilon}{g+\varepsilon}\right].
\]

For \(g>0\) it converges to \(2g[1+\log_2(T/g)]\). For \(g=0\), it tends to zero because \(\varepsilon\log(1/\varepsilon)\to0\). The convergence is uniform over this finite spectrum; compactness of \(\mathcal S\) gives a convergent subsequence of \(\Psi_\varepsilon\), and the closed PSD order passes to the limit. Therefore the limit comparator lies in \(\mathcal S\) as well. Since canonical \(\Psi\) and \(\Phi\) fix \(I\) and are HS-selfadjoint, both preserve \(\mathcal H_0\); defining the profile as zero on the identity direction extends the inequality to the full Hermitian space.

The zero-gap conclusion is exact: since \(I-\Psi\succeq0\), a zero RHS in WT forces \(\Psi A=A\) for every \(A\in\ker G\). For a unital trace-preserving CP map, its fixed points form a \(*\)-subalgebra (Kadison equality plus faithful-trace preservation puts fixed points in the multiplicative domain); self-compatibility and no-broadcasting make this algebra commutative. This matches the known classical nature of exactly broadcastable fixed observables. For a normalized eigenmode with gap \(g>0\), WT also gives \(\|(I-\Psi)A\|_{2,\tau}^2\le2g[1+\log_2(T/g)]\|A\|_{2,\tau}^2\), a static slow-mode reconstruction bound. Its relative coefficient may diverge as \(g\to0\), although the absolute bound tends to zero.

## The profile is not a uniform strengthening

Let \(\Delta\) be computational-basis dephasing and \(C_d\) the universal qudit 1-to-2 cloner marginal. Both have symmetric broadcasters; \(\Delta\) is canonical EB and \(C_d\) is depolarizing with traceless eigenvalue \(\lambda_d=(d+2)/(2(d+1))\). For

\[
\Phi_t=t\Delta+(1-t)C_d,
\]

mixing their broadcasters makes \(\Phi_t\) self-compatible. On the diagonal traceless subspace its gap is \(g_D=(1-t)(1-\lambda_d)\), while on off-diagonal modes it is \(g_O=1-(1-t)\lambda_d\). As \(t\uparrow1\), \(g_D\downarrow0\) but \(T=(d-1)g_D+(d^2-d)g_O\to d^2-d>0\). Therefore the profile coefficient \(2[1+\log_2(T/g_D)]\) on those diagonal modes diverges, whereas the equal-depth coefficient \(2\lceil\log_2(d^2-1)\rceil\) remains fixed. WT does not Loewner-dominate the earlier equal-depth bound.

This is a failure of uniform dominance of the *stated right sides*, not a counterexample to a stronger comparator. In fact the cloner has a canonical Haar EB comparator \(\Psi_C\) with \(I-\Psi_C=2(I-C_d)\), and \(\Psi_t=t\Delta+(1-t)\Psi_C\) obeys \(I-\Psi_t\preceq2(I-\Phi_t)\) by convexity. The example sharply separates the utility of the spectral profile from the unknown best comparator constant.

## Stronger surviving consequence: a prior-adapted EB acquisition bound

The Q-dependent support statement in `WEIGHTED_TREE.md` has a direct Bayes-risk interpretation. Let \(Q\succeq0\), \(E=\operatorname{Tr}_{HS}(QG)\), and, when \(E>0\), \(R=G^{1/2}QG^{1/2}\), \(\sigma_R=R/E\). If \(G\succ0\), diagonalize \(R\) and set \(p_i=r_i/E\). A Huffman tree for \((p_i)\) has mean depth at most \(1+H_2(p)=1+S_2(\sigma_R)\); a pruned near-balanced tree caps this by \(\lceil\log_2\operatorname{rank}Q\rceil\). Measure the spectral PVM of each frame vector at its assigned leaf. The resulting *single physical input POVM* and its canonical EB channel satisfy

\[
\operatorname{Tr}_{HS}[Q(I-\Psi_Q)]
\le 2E\min\{\lceil\log_2\operatorname{rank}Q\rceil,\ 1+S_2(\sigma_R)\}.
\tag{A}
\]

The prefix-code entropy lower bound in `WEIGHTED_TREE.md` applies only to the leaf-private prefix-tree architecture. It does not rule out measurement reuse. Here the tree is operational and has exactly \(\operatorname{rank}Q-1\) broadcaster calls after pruning; entropy improves the *average Dirichlet penalty*, not total invocation count. A full-dimensional common comparator then follows by the separate compact-convex argument above.

For a finite prior \(p\) over bounded tracial likelihoods \(\rho_x=(I+H_x)/d\), put \(Q_p=\sum_xp_x|H_x\rangle\langle H_x|\), \(E_p=\operatorname{Tr}(Q_pG)\), and \(R_p=G^{1/2}Q_pG^{1/2}\). The canonical map in (A) satisfies, with \(L_p=\min\{\lceil\log_2\operatorname{rank}Q_p\rceil,1+S_2(R_p/E_p)\}\),

\[
\mathbb E_p\left[\left(\tfrac12\|\Psi_Q(\rho_x)-\rho_x\|_1\right)^2\right]
\le \tfrac12 E_p L_p.
\tag{B}
\]

Indeed \(\Psi_Q\) is positive as an HS operator and contractive, hence \(0\preceq\Psi_Q\preceq I\) and \((I-\Psi_Q)^2\preceq I-\Psi_Q\); normalized Schatten monotonicity converts its HS reconstruction risk to physical half-trace risk. If \(\|H_x\|_\infty\le\theta\) and \(\max_x\|\Phi(H_x)-H_x\|_{1,\tau}\le r\), then \(E_p\le\theta r\). Thus one prior-adapted EB channel has Bayes RMS half-trace error at most \(\sqrt{\theta rL_p/2}\).

For a finite family, the squared HS loss \(\ell_x(\Psi)=\|(I-\Psi)H_x\|_{2,\tau}^2\) is convex in \(\Psi\), and the canonical-map set is compact convex. Sion's minimax theorem therefore promotes prior-specific maps to one common map with

\[
\max_x\frac12\|\Psi(\rho_x)-\rho_x\|_1
\le \sqrt{\frac12\sup_{p} E_pL_p}
\le \sqrt{\frac{\theta r}{2}\sup_p L_p}.
\tag{C}
\]

This is a genuine uniform EB reconstruction condition for a finite family: it is dimension-free when the **worst-prior energy-weighted effective entropy** \(\sup_p L_p\) is bounded. It does not follow from bounded Holevo information alone, does not make \(\sup_pL_p\) automatically small, and is an internal corollary rather than an external theorem. No state samples, tomography, finite-precision channel learning, or circuit compilation are included. A finite comparator can be represented as a mixture of at most \(D+1\) rank-at-most-\(n\) tree strategies; each component costs at most \(n-1\) broadcaster calls and at most \(d^n\) raw PVM outcomes.

An exact measurement-reuse corollary is also immediate. If a fixed finite family \(H_x\) is covered by \(q\) commuting contexts, put each context's common spectral PVM on one leaf of a balanced full binary tree of height \(\lceil\log_2q\rceil\). Its product POVM refines each member's PVM and yields one canonical EB map satisfying the direction-wise score bound with factor \(2\lceil\log_2q\rceil\), regardless of how many observables lie in each context. The tree has \(q-1\) broadcaster calls, \(q\) outputs, and at most \(d^q\) raw outcomes. For one commuting context, direct dephasing fixes every family state exactly and uses no broadcaster. This is a model-level acquisition capability; statistical sample cost is separate.

## Prior-art collision search and theorem boundary

The primary-source search remained bounded but was widened to compatibility/incompatibility, finite-copy broadcasting/de Finetti, quantum expanders and noncommutative Poincare inequalities, quantum Markov cotype, and approximate joint rounding.

* Heinosaari–Kiukas–Reitzner–Schultz, [*Incompatibility breaking quantum channels*](https://arxiv.org/abs/1504.05768), studies finite- versus all-family joint measurability after a channel and explicitly distinguishes incompatibility breaking from EB. It does not provide this all-PSD Hilbert–Schmidt Dirichlet comparison.
* Heinosaari–Miyadera, [*Incompatibility of quantum channels*](https://arxiv.org/abs/1608.01794), identifies channel compatibility with a joint channel and self-compatibility with antidegradability; compatibility at every output count characterizes EB. A two-output extension remains a strictly weaker premise.
* Xie–Fang–Wang–Duan, [*Approximate broadcasting of quantum correlations*](https://arxiv.org/abs/1705.06071), Lemma 3, gives a dimension-dependent absolute diamond approximation to EB channels for most marginals of a many-output channel. Its metric, output-count premise, and dependence on input dimension differ from WT.
* Chiribella's [finite de Finetti theorem for quantum channels](https://arxiv.org/abs/1010.1875) and Piani's [discord/de Finetti analysis](https://arxiv.org/abs/1501.06855) also charge input/output dimension against the number of symmetric outputs; they do not give a relative (I-\Psi\preceq f(I-\Phi)) bound from 2-compatibility.
* Junge–Wang, [*Generalized Poincare inequality for quantum Markov semigroups*](https://arxiv.org/abs/2601.06005), assumes a spectral gap and proves noncommutative Poincare estimates. On that subcase a depolarizing EB comparator already gives (I-\Delta\preceq\gamma^{-1}(I-\Phi)); slow modes remain outside its hypothesis.
* Mendel–Naor's [metric Markov cotype/spectral-calculus work](https://arxiv.org/abs/1301.3963) concerns metric-valued reversible chains, not quantum EB channels. Bansil–Kachkovskiy's [2026 normalized-HS almost-commuting theorem](https://arxiv.org/abs/2608.31000), Theorems 1.1, 1.3 and Corollary 1.4, supplies dimension-free pairwise and fixed-tuple commuting approximants with explicit — though rapidly degrading in tuple size — exponents. It is a promising approximate-context route under additional near-fixed/positive-HS assumptions, but it does not itself supply the WT comparator or settle growing-family N93.

The exact collision tested was one common canonical EB channel with a relative positive-operator-order profile controlled by \(G\), for arbitrary unital TP HS-selfadjoint two-self-compatible \(\Phi\), with zero-gap continuity. The bounded primary search found no such source statement. This is not an exhaustive novelty search, and C4-Q3 remains an internally reconstructed candidate theorem pending independent expert review.

## Claim and status changes

1. C4-Q3's proof status can be upgraded from “hostile review pending” to “independent internal audit passed the listed algebraic/convex steps; external review remains open.”
2. Its operator profile cannot be advertised as uniformly stronger than C4-Q1. The cloner/dephasing mixture above is an explicit counterexample to domination of the equal-depth right side.
3. The per-prior entropy support inequality plus convex minimax yields the additional worst-case finite-family criterion (C), with effective entropy and explicit broadcaster/outcome costs as above.
4. Neither this criterion nor C4-Q3 resolves bounded Holevo plus vanishing two-copy marginal error without an additional bound on the energy-weighted effective entropy or another measurement-reuse theorem.
