# c13 measurement principle: spatially continuous optical-clock interrogation

## Verdict

The strongest distinct measurement lead is the August 2026 spatially defined Rabi spectroscopy experiment with continuously transported ultracold `88Sr`. It moves atoms at 16 mm/s through a 12 mm clock-interaction region and reports a 1.2 Hz-wide resonance. This is an important spectroscopy and continuous-delivery demonstration, but the inspected source does not report a stabilized optical clock, atom-flux/arrival statistics, LO-noise transfer function, or clock Allan deviation.

The partial theorem here draws a precise boundary: for ideal rectangular per-atom phase averaging, uniform atom delivery yields a flat aggregate LO sensitivity only in the interior of a finite record, while each atom has exact temporal response zeros at `f=k/tau`. Under Poisson delivery, the mean flux also leaves finite probabilities of sensitivity gaps and local occupancy fluctuations. Against an equally resourced gapless interleaved two-ensemble clock, the ideal quantum-projection/readout floor is identical. Thus continuous transport can remove handling gaps in a tested architecture, but it does not by itself establish alias-free sensing or a precision gain.

This is **an internally derived model result plus source-reported experimental context**. The rectangular-kernel calculations are not the actual Rabi response; no new physical capability, novelty, or priority claim is made.

## Source and distinctness

Nishida et al., [“Spatially defined Rabi spectroscopy for uninterrupted optical clock interrogation,” Nature Communications 17, 7662 (2026)](https://www.nature.com/articles/s41467-026-76017-1), report continuous transport of `88Sr` in a moving lattice, localized clock excitation using a transverse magnetic mixing field, velocity 16 mm/s, an interaction region 12 mm long, and a 1.2 Hz-wide spectrum near the transit-time limit. The implied nominal interaction time is `tau = 0.012 m / 0.016 m s^-1 = 0.75 s`.

The distinct mechanism is spatial separation of preparation, coherent clock excitation, and detection, so those operations can pipeline while atoms traverse the interaction zone. This differs from c11 gas-dispersion barometry, nanoscale calorimetry, and SThM calibration design. However, zero-dead-time temporal interleaving is established prior art. A 2026 `87Sr` interleaved clock reports 2.9e-19 at 20,000 s and estimated 2.5e-19 at one day ([source record](https://pubmed.ncbi.nlm.nih.gov/41557413/), DOI 10.1103/zbpb-6qxb). It is a strong architecture comparator but not a same-isotope, same-device equal-resource test.

## Exact model result

For an atom entering at time `t`, assume a linearized rectangular sensitivity kernel of duration `tau`, so its LO-frequency contribution is `z_t = tau^-1 integral_t^(t+tau) y(s) ds`. Uniformly averaging arrivals over `t` in `[0,T-tau]` gives

`k_T(s) = |[0,T-tau] intersect [s-tau,s]| / [tau(T-tau)]`.

This aggregate kernel ramps over the first and last `tau` seconds of the record and is constant on the interior. The per-atom Fourier response is `G(f) = exp(i pi f tau) sinc(pi f tau)`, so every nonzero `f=k/tau` is an exact zero. For `tau=0.75 s`, the first zero is 1.33 Hz. Continuous atom delivery therefore does not provide a broadband record of LO noise; the real Rabi sensitivity function and its conditioning must be measured. The full derivation and scope are in [kernel_resource.md](proofs/kernel_resource.md).

If atom arrivals are a stationary Poisson process of rate `r`, the number in the interaction region at a fixed time is Poisson with mean `r tau`: the empty-zone probability is `exp(-r tau)`, while relative pointwise occupancy variation is `1/sqrt(r tau)`. The expected number of interarrival gaps longer than `tau` over a long interval `T` is approximately `r T exp(-r tau)`. This is an illustrative arrival model, not an assertion about the ordered moving-lattice stream; the source's actual occupancy trace is needed.

## Equal-resource precision control

In an ideal independent-atom mid-fringe phase readout with contrast `C`, interrogation time `tau`, and `N` detected atoms, the frequency Fisher information is `4 pi^2 C^2 tau^2 N`, giving

`sd(nu_hat) >= 1 / (2 pi C tau sqrt(N))`.

A gapless two-ensemble interleaved clock with the same total atom count, per-atom response, interrogation time, contrast, LO, and readout has the same ideal QPN/readout floor. The spatial geometry may improve throughput, synchronization, or infrastructure cost, but those gains require measurements. To claim a metrological gain, the experiment must compare with the interleaved control while matching total atom flux and measured LO spectrum.

The reproducible illustrative fixture uses `tau=0.75 s`, `r=24 atoms/s`, one day, and `C=1`. It gives 18 atoms in-zone on average, a 0.032 expected long-gap count scale per day, 24% pointwise occupancy CV, 2,073,600 atoms total, and 0.147 mHz ideal mid-fringe frequency SD. These numbers are a transparent model calculation, not device data; the script is [resource_fixture.py](code/resource_fixture.py).

## Decisive physical comparison

Use the same isotope, local oscillator, atom flux, total detected atoms, clock-pulse area, averaging time, and readout to compare (i) spatially gated continuous transport against (ii) two temporally interleaved ensembles. Time-tag atoms and measure the empirical sensitivity function by injecting weak LO-frequency tones across the clock's relevant noise band. Record the transfer function, its zeros and conditioning, occupancy gaps, contrast, atom preparation/readout photons, transport and magnetic-field power, and Allan deviation under a matched injected LO-noise spectrum.

The actual moving-lattice arrival process may be regular rather than Poisson; measuring that trace changes the gap calculation. The largest physical evidence gap is that the paper demonstrates a spectrum, not a clock lock. If the empirical response has an operationally relevant null, or the measured Allan deviation does not beat the matched interleaved control after charging atom flux and overhead, the broad alias-free/precision-advantage interpretation fails. A measured advantage would support a narrower hardware-efficiency result.

## Evidence and remaining gates

- Source-reported: spatial apparatus parameters and 1.2 Hz spectrum in the 2026 paper.
- Internally derived: aggregate rectangular kernel, its Fourier zeros, Poisson occupancy identities, and ideal equal-resource QPN comparison.
- Finite calculation: the illustrative fixture in `code/resource_fixture.py`; output checked in this turn.
- Unknown: actual Rabi kernel, atom flux and arrival statistics, LO-noise PSD, drive/readout energy, calibration covariance, stabilized clock behavior, same-platform interleaved comparison, and priority.

The claim ledger is [CLAIMS.json](CLAIMS.json). No external validation or expert review was obtained.
