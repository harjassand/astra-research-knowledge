# Spatial clock kernel and atom-resource bound

## Scope

This note analyzes an ideal phase-averaging model suggested by spatially defined Rabi spectroscopy. It is not the Rabi sensitivity function of the apparatus. For an atom entering a field-defined interaction zone at time `t`, take its normalized response to local-oscillator (LO) frequency noise `y` to be

\[
z_t=\frac1\tau\int_t^{t+\tau}y(s)\,ds+\epsilon_t,
\]

where `tau=L/v` is the transit time and `epsilon_t` is independent atom/readout noise. The exact apparatus response must be measured and substituted for the rectangular kernel below.

## Aggregate kernel under uniform delivery

For a continuous uniform arrival density on `[0,T-tau]`, average all atom records with equal weights. Fubini gives

\[
\bar z=\int_0^T k_T(s)y(s)\,ds+\bar\epsilon,
\qquad
k_T(s)=\frac{|[0,T-\tau]\cap[s-\tau,s]|}{\tau(T-\tau)}.
\]

Thus `k_T(s)=s/[tau(T-tau)]` on `[0,tau]`, `1/(T-tau)` on `[tau,T-tau]`, and `(T-s)/[tau(T-tau)]` on `[T-tau,T]`. It integrates to one and is flat only in the interior; the two record boundaries have width `tau`. A steady, uniformly occupied conveyor therefore removes interior temporal gaps in this model, while finite-record edge effects remain.

For a stationary Poisson arrival process of rate `r`, the number of atoms simultaneously in the zone at a fixed interior time is Poisson with mean `r tau`. Consequently

\[
\Pr\{\text{no atom in zone at a fixed time}\}=e^{-r\tau},
\qquad
\frac{\operatorname{sd}(N_{\rm zone})}{\mathbb E N_{\rm zone}}=(r\tau)^{-1/2}.
\]

Interarrival gaps longer than `tau` create uncovered time intervals. Their expected count over duration `T` is approximately `r T e^{-r tau}` (up to start/end effects); Markov's inequality bounds the probability of at least one such gap by the same expression. This is only a continuity bound. It does not make the instantaneous sensitivity flat: at mean occupancy 18 the pointwise relative occupancy fluctuation is about 24%. A regular conveyor can have much smaller occupancy fluctuations, but its measured arrival/occupancy record, rather than its mean flux alone, is the relevant input.

## Per-atom temporal bandwidth

The Fourier response of the rectangular phase average is

\[
G(f)=\frac1\tau\int_0^\tau e^{2\pi i f u}\,du
 =e^{\pi i f\tau}\,\mathrm{sinc}(\pi f\tau),
\]

where `sinc(x)=sin(x)/x`. At every nonzero `f=k/tau`, `G(f)=0`. Hence an LO-frequency perturbation `y(s)=A cos(2 pi k s/tau + phi)` contributes zero to every per-atom phase readout in this linear phase-averaging model, whatever the atom arrival times. Continuous delivery removes a duty-cycle hole; it does not make the sensor a broadband, alias-free record of LO noise. At `tau=0.75 s`, the first zero is `1/tau=1.33 Hz`, consistent in scale with a roughly 1-Hz transit-limited line. For real Rabi spectroscopy the measured sensitivity function replaces this rectangular `G`; the zeros and their conditioning must be measured rather than assumed.

## Information and equal-resource control

In an ideal mid-fringe phase readout with contrast `C`, `N` independent atoms and interrogation time `tau` provide frequency Fisher information `F=4 pi^2 C^2 tau^2 N`. Thus

\[
\operatorname{sd}(\hat\nu)\geq(2\pi C\tau\sqrt N)^{-1}.
\]

With continuous flux `r`, `N approximately rT`, so this model gives the quantum-projection/readout floor `(2 pi C tau sqrt(rT))^{-1}`. A two-ensemble interleaved zero-dead-time clock with the same total detected atom count, the same `tau`, contrast, readout noise, and aggregate sensitivity kernel has the same floor. Spatial transport can reduce apparatus-specific handling/synchronization overhead, but no precision gain follows from continuous delivery alone. Any comparison with an ordinary single-ensemble clock must count atoms discarded during dead time; the strongest control is an actually gapless interleaved clock with equal total atom flux and LO.

As a resource illustration only, set `tau=0.75 s`, `C=1`, `T=86400 s`, and Poisson arrival rate `r=24 s^-1`. Then the expected number of uncovered gaps is bounded at approximately `r T exp(-r tau)=0.032` per day, while the ideal white/readout-noise frequency floor is `0.15 mHz`. This bound permits about 18 atoms in the zone on average, whose pointwise occupancy coefficient of variation is still `24%`. None of these flux or uncertainty values is reported for the cited spatial-clock apparatus; they are a transparent design calculation, not a performance claim.

## Physical decision gate

For the same Sr isotope, LO, clock-pulse area, atom throughput, total detected atoms, and averaging time, record the atom arrival times and measure the complex response to weak frequency-modulation tones across the target LO-noise band. Compare (i) spatially gated continuous transport and (ii) two interleaved temporal ensembles. Report the empirical sensitivity function, its Fourier zeros/condition number, coverage-gap fraction, atom flux and in-zone occupancy, contrast, state-preparation/readout photons and energy, transport and magnetic-field power, and Allan deviation under the same injected LO-noise spectrum. A reproducible sensitivity null at a practically relevant LO-noise frequency, or an Allan deviation no better than the matched interleaved control after resource matching, rejects a broader alias-free or precision-advantage claim. A measured improvement after equal-resource matching would support a narrower hardware-efficiency claim.
