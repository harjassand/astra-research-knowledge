# Cross-sectional macrophage training data: candidate interface, not a theorem

## Source-reported observation

The 2026 single-cell paper reports RNA-FISH spot counts from distinct cells at a set of restimulation times. For each measured cell, the released table is intended to carry donor, training condition, challenge, time, field/XY, morphology, and probe-specific spot count. The public data README states that the longer time course spans 0–8 h but includes only two donor identifiers. Source summary: trained cells show higher early output and the untrained population later catches up. These are claims of the paper, not C13 results.

## Candidate model contrast

Let `Y[g,d,c,t]` denote the cross-sectional single-cell count for gene `g`, donor `d`, training condition `c`, at time `t`; let `F[g,d,c,t]` be its empirical distribution. Candidate `H_clock` asks whether one donor-specific monotone time map `phi_d` can approximately satisfy

`F[g,d,trained,t] = F[g,d,untrained,phi_d(t)]`

across multiple genes, not just match mean counts at selected times. Competing models must include gene-specific time maps, explicit changes in the fraction of zero/nonzero cells and positive-count distribution, and a donor/date/morphology/density mixture. A held-out time or donor prediction is the capability target; endpoint separation or training-set fit is not.

This framing is only a prospective measurement contract. The released-cell data, exact donor/time replication, stimulus factorial, plate structure, and censoring/probe failures remain uninspected. RNA-FISH is destructive: marginal distributions across times do not reveal cell trajectories or prove a same-cell acceleration mechanism. Any result would be population-level and conditional on measured covariates.

## What would be needed

1. Acquire and hash-check the Dryad processed FISH data and plotting/extraction scripts.
2. Reconstruct the experimental sample unit and independent replication from source tables; fields/cells are nested subsamples, not donor replicates.
3. Fit and compare the common-clock, gene-specific, mixture/activation-probability, and static-baseline models under donor-blocked holdout; prevent cells from the same donor/plate leaking between train and test.
4. Report held-out predictive log score/calibration for full cell-count distributions, not only means; bootstrap or hierarchical uncertainty at the donor/sample level.
5. Show the prediction survives measured density, cell area/shape, imaging field, batch/date, and probe availability. Compare same donor and same acquisition doses.
6. Charge cell counts, probes, imaging, data processing, calibration, and elapsed-time cost. State failure criteria before fit: no donor-blocked predictive gain, a gain erased by mixture/morphology adjustment, or no reproducible kinetic coverage beyond two donors.

No fit, quantitative prediction, theorem, or empirical C13 claim has yet been made.
