# C13 failures and unresolved gates

- Dryad anonymous API serves source metadata and a four-file manifest, but downloadable file-byte endpoints returned HTTP 401 and the file-stream URL returned HTTP 403. Therefore no numerical Dryad tables or associated scripts were analyzed.
- The supplied Dropbox shared folder offers a whole-folder ZIP with a reported content length of 4,214,604,775 bytes. Only response headers and the first ZIP bytes were probed; no multi-gigabyte download was attempted. No verified per-file link was extracted.
- Both 2026 Cell Systems publisher full-text fetches returned HTTP 403. Publicly indexed article text and the Dryad README were used for the described design/claims; methods-level reconstruction is incomplete.
- The 2026 T-cell ERK paper is abstract-only in this pass. Do not treat frequency/amplitude roles or signaling condensates as a reconstructed quantitative mechanism.
- Time-course coverage appears restricted to two donors per Dryad README. Population-level precision from many cells does not substitute for independent human-donor/experiment replication.
- Cross-sectional destructive FISH does not track the same cell over time. A marginal distribution shift cannot by itself identify a within-cell dynamic law or exclude latent mixture, donor/date, density, and morphology effects.
- The phrase “faster rather than stronger” is a paper interpretation suggested by early/late contrasts. No full-trajectory area, common time-warp, equality-of-cumulative-output, or dynamic prediction analysis was independently performed here.
- No novelty/priority clearance beyond scoped primary sources, no new theorem, and no new empirical/capability result.
