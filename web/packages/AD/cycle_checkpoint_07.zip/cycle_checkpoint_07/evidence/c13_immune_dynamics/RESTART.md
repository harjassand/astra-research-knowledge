# C13 immune dynamics: compact restart state

## Mandate and scope

Continue the immune-dynamics lane beyond C12's audit. The live candidate is a quantitative dynamics capability or decisive theorem grounded in fresh primary immunology, with a measured interface, explicit lineage/donor/environment assumptions, equally informed control, and costs. Do not reopen B-cell force/Fmax, the nutrient T-cell combination, or the restricted RNA kinetic-barcode line. No external messages, publishing, wet-lab actions, or medical recommendations. C12 remains preserved under `../c12_immune_dynamics/`.

## Fresh candidate, not a result

The best current lead is the paired 2026 Cell Systems trained-immunity work by O'Farrell and Raj. One paper reports stimulus-specific macrophage recall; its companion reports 90,857 single-molecule RNA-FISH cell measurements across 26 human donors, gene-specific population response modes, early trained excess at 2 h, later untrained catch-up at 6 h, and maintained within-cell cross-gene relationships. This is an existing source claim, not a C13 discovery. The opportunity is to test, with donor-blocked data, whether the trained advantage has a quantitative dynamical representation (e.g., a response-time map versus gene-specific amplitude/activation-probability changes) that predicts a held-out time/condition better than equally informed static-baseline or mixture controls.

## Actual interface acquired so far

- Primary article abstracts and extensive article text snippets were inspected via the publisher index. Full publisher pages returned 403.
- The Dryad landing page and anonymous metadata API were acquired. Current dataset version `448862` exposes four files: `Data.zip` 97,323,683 bytes (SHA-256 `a34e094ecc9ac2d63f8baa5b6b2bdc94ba85de2cf1b82d1c04a80588ba75eb01`); `Extraction_Scripts.zip` 31,090 bytes (SHA-256 `398d528943b6ddacfe8461ffa4ffb1067c51429af229fcdd390d61c107d5ceb6`); `Plot_Scripts.zip` 75,749 bytes (SHA-256 `e735a4b66a7b53fb396c160aa3b64ddc089968487b1cc5b5872b03281c1ad325`); and a README of 19,962 bytes.
- Metadata says FISH tables are processed cell-level rows with donor, condition, time, stimulus, XY field, morphology, and gene spot counts (TNF, IL6, IL1b, CXCL10); NA means unmeasured probe, zero means measured with no spots. Time-course merged tables cover 0–8 h for two donors. Data package also includes imaging, ATAC-seq-derived data, and code.
- The landing page's linked Dropbox folder responds with a 4.214 GB whole-folder ZIP. It was only probed for response metadata and first bytes; the large archive was not downloaded.
- Dryad anonymous metadata/API is readable, but file-byte API endpoints returned 401 and the page download returned 403. Thus **numeric cell data and analysis scripts have not been acquired or analyzed**. Keep this distinction explicit.

## Partial quantitative framing (unverified against cell rows)

For gene `g`, donor `d`, training condition `c`, and restimulation time `t`, the measured cross-sectional marginal is `P(Y_g(t) | d,c,t)` for single-cell spot count `Y`. A candidate common-clock null would require a monotone `phi_d(t)` that maps untrained response distributions to trained distributions across time, with explicit gene-specific alternative models. A mean-level special case is `mu_T,g,d(t) = mu_U,g,d(phi_d(t))`. Two positive/negative endpoint contrasts alone do not identify a response trajectory, a same-cell path, or a common clock. The source's 2 h and 6 h summaries therefore motivate a test but do not establish speed-up, equal cumulative output, or a within-cell mechanism.

Required controls include donor-blocked train/untrained pairs, training and challenge identity, plate/date, measured cell density and morphology, an explicit responder-mixture model, and equal-data held-out donor/time evaluation. Because RNA-FISH is destructive/cross-sectional, no individual-cell transition or lineage is observed. A decisive capability would need held-out distribution prediction (not merely refitting endpoints), uncertainty by donor, acquisition/probe/cell costs, and comparisons to gene-specific and mixture baselines. No model fit, power estimate, or capability claim exists yet.

## Stop / next gate

Per parent steering, freeze this C13 round here; do not start another cycle or download the whole Dropbox archive. On authorized continuation, obtain the processed ~97 MB Dryad data and scripts through a valid public route or with legitimate access, verify hashes, inspect exact assay units/design, preregister a donor-held-out dynamical-vs-mixture test, then only analyze if donor/time replication supports it. First falsify with donor/date and density/morphology adjustments. If data stay inaccessible or only two donors have kinetic coverage, report that the trained-dynamics lead cannot support a general model/capability.

## Parent handoff

C12 work and its claim status are not modified. C13 presently has a fresh primary-literature lead and a source metadata/interface inventory, but no raw/processed measurements, reconstruction, theorem, or new scientific advance. See `SOURCES.md`, `FAILURES.md`, `proof/partial_dynamical_interface.md`, `CLAIMS.json`, and `FINAL_REPORT.md`.
