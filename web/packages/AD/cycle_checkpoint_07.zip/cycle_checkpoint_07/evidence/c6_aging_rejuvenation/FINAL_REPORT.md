# 2C-like ESC damage segregation: an open assay boundary, not a new result

## Decision

**Reject this candidate as a demonstrated scientific advance.** The broad mechanism—2C-like embryonic stem cells divide asymmetrically in damage-associated signals, with different daughter fates—is already reported by Wang et al. (2026). Their study already follows live 53BP1-Tudor-mVenus foci in sister lineages, stains tracked sister pairs for γH2AX at the end of a 32-hour movie, relates damage signal to daughter fate, and assays damage in sorted populations by comet. More generally, Ferrand et al. (2025) directly measured physical CPD asymmetry on sister chromatids and in early-G1 daughter pairs, with negligible repair during the first hours. The log-ratio calculation below is elementary and does not create priority over these studies.

The narrow unresolved mechanistic question is: **in spontaneous 2C-like mouse ESC divisions, is a named physical DNA-lesion burden already asymmetric at the division boundary and predictive of later lineage fate, or does the measured asymmetry emerge through postmitotic repair, lesion production, cell-cycle-dependent signaling, or reporter organization?** This is a plausible experimental gap, not a result established by the currently public data. The focal study’s γH2AX, 53BP1, and comet measurements are important and mutually informative; neither the paired markers nor the group-level comet assay is a same-pair, lesion-specific physical trajectory across cytokinesis.

The strongest defensible contribution from this audit is a conditional identifiability check and an accurate data/prior-art boundary. Do not present it as a novel theorem or as evidence that the published rejuvenation interpretation is wrong.

## What the source data establish

Wang et al. (2026), *Cell Research* 36:219–232, DOI [10.1038/s41422-026-01221-z](https://doi.org/10.1038/s41422-026-01221-z), report that MERVL/Zscan4 2C-like entry is associated with asymmetric ESC daughter fates. Figure 3 and Supplementary Fig. S3 show the following:

- Live 53BP1-Tudor-mVenus imaging reports foci asymmetry in paired daughter lineages; the supplementary caption reports 54 pairs for the relevant live distribution. Asymmetry precedes divergence in the MERVL reporter in 32 pairs, and the foci-rich branch is more often the 2C-death branch.
- In a separate endpoint experiment, tracked sister pairs were fixed and stained for γH2AX after a 32-hour movie. Figure 3 compares the sister-pair γH2AX intensity fraction distributions for MERVL-negative and 2C-entering lineages; the independent prior-art audit reports 97 pairs per group.
- The study includes endogenous 53BP1/γH2AX comparisons and perturbations of ATM, ATR, CHEK1/2, and PARP. The supplement’s Figure S3 caption gives the knockdown and inhibitor details and sample counts.
- The study also reports comet-assay damage in sorted MERVL-positive cells and subsequent fate/function differences. The highlight summarizes lower damage in the recently 2C-exited lineage, improved pluripotency-associated measures, and improved chimeric contribution. The comet readout is destructive and group-level; it does not quantify lesion burden in each tracked sister at the cytokinesis boundary.

The focal GEO release, [GSE289323](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE289323), contains two pooled sorted conditions—MERVL::GFP-positive and negative—with single-cell RNA count matrices and cell barcodes. It does not include parent/sister identifiers, division timestamps, or paired damage trajectories. The accessible public supplementary movies are illustrative, not a numerical time-resolved lineage table.

For direct review, the publisher’s Fig. 3 image and Supplementary Fig. S3 are preserved at [wang_2026_figure3.png](data/wang_2026_figure3.png) and [wang_2026_supplementary_fig3.pdf](data/wang_2026_supplementary_fig3.pdf); their source URLs and hashes are in [SOURCE_NOTES.md](SOURCE_NOTES.md).

A second public-data route was audited. Panagopoulos et al. (2025), [“Multigenerational cell tracking of DNA replication and heritable DNA damage”](https://doi.org/10.1038/s41586-025-08986-0), make the underlying live imaging and Live+QIBC data available on request. [GSE288485](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE288485) is six bulk U-2 OS RNA-seq samples, not microscopy. The public Nature source-data workbook preserves a three-category sister-heterogeneity table but no pair IDs, continuous sister values, event times, or loss records. Reanalysis reproduced the released contrast (Pearson χ²(2, N=86)=9.468, p=0.008791, Cramér’s V=0.332); this confirms that categorical contrast only. Details are in [time_lapse_data_audit.md](time_lapse_data_audit.md), with the 957-KiB workbook at [panagopoulos_2025_source_data.xlsx](data/panagopoulos_2025_source_data.xlsx).

## Conditional partition–repair identity

This identity is retained as a way to state the missing measurement precisely. It is standard algebra; no mathematical novelty or biological fit is claimed.

Let a mother divide at time zero. For one prespecified lesion class, suppose the daughters’ physical burdens obey

\[
D_1(t)=pD_*e^{-k_1t},\qquad D_2(t)=(1-p)D_*e^{-k_2t},
\]

with \(D_*>0\), \(p\in(0,1)\), and constant nonnegative repair rates \(k_1,k_2\) over the short window. A physical assay gives \(P_i(t)=g_P(t)D_i(t)\), with a positive shared multiplicative gain and calibrated/subtracted additive background. Then

\[
\log\frac{P_1(t)}{P_2(t)}=\log\frac{p}{1-p}+(k_2-k_1)t.
\]

Under those assumptions, two distinct times identify the log-odds of the operational post-division partition and the differential repair rate. A third time or held-out data is still needed to test the constant-rate law: any two positive points fit a line exactly. For a focus readout \(F_i(t)=g_F(t)\eta_i(t)D_i(t)\), the observed log-ratio contains the additional term \(\log(\eta_1(t)/\eta_2(t))\); a reporter trace alone identifies physical partition only if its sister-specific efficiencies are independently controlled.

At one delayed time \(t=\delta>0\), partition and differential repair alias exactly: for an observed log-ratio \(L\), every rate difference \(\Delta k\) can be matched by \(\operatorname{logit}(p)=L-\Delta k\delta\). If external calibration establishes \(|\Delta k|\le K\), the error from interpreting the delayed ratio as the immediate partition obeys \(|\hat p-p|\le\tanh(K\delta/4)\le K\delta/4\). Without a rate bound or early measurement, no partition estimate follows from that endpoint alone.

A finite arithmetic check is in [paired_damage_invariant.py](paired_damage_invariant.py) and [CHECK_RUN.json](CHECK_RUN.json). It validates the algebra with synthetic values only; it is not a fit to biological data.

## Decisive experiment and control

The missing quantity must be made operational before data collection: name the physical lesion class, specify the daughter-label rule before looking at signal, and distinguish inherited pre-existing lesions from lesions generated during/after replication or cytokinesis. “DNA damage” as a pooled label is not a single conserved species.

A discriminating mouse-ESC study would track spontaneous MERVL/Zscan4 transitions through division while preserving both sister identities and all outcomes. It would collect the earliest feasible post-cytokinesis physical-lesion read and at least two later short-window reads, record exact cytokinesis time, cell-cycle/DNA-content state, MERVL/Zscan4 trajectory, and both fates, and retain apoptosis, field exit, and tracking failure in the denominator. Live 53BP1 can be retained as a reporter channel, but it cannot stand in for the physical assay without a validated signal map.

The most accessible physical channel is a pair-indexed comet readout, because the focal study already uses comet measurements. Its estimand must be named narrowly as comet-detectable DNA breakage/alkali-labile damage; it is not a census of every lesion type. A microfluidic or equivalent lineage-retaining setup could send both sisters from a tracked division into separate indexed assay wells at the earliest feasible delay. Repeating this over sacrificial cohorts at prespecified delays tests whether population-level physical sister asymmetry is present immediately or develops later. It does not provide a per-pair slope, and lysis prevents following those same daughters to their later fate. A parallel live-fate cohort can check population-level consistency, but the same-pair physical-burden-to-fate relation remains unmeasured until a validated non-destructive physical assay or a fate-preserving assay design exists.

The strongest equally informed control is a matched MERVL-negative division cohort, matched on pre-division lesion burden, cell-cycle state, culture batch, imaging schedule, and assay handling. Both groups must receive identical information and acquisition effort. Fit partition-only, repair-only, joint partition-plus-repair, and reporter-only explanations against the same observations, with a prespecified held-out time or orthogonal endpoint. A label-permutation/symmetry control should preserve the full observation process.

If the physical read is destructive, the same pair cannot be measured repeatedly. Separate, pair-indexed sacrificial cohorts at matched delays can estimate a population trajectory only under an explicit exchangeability/random-effects model; they do not identify a per-pair repair slope. A physical signal that can be repeatedly measured live would be needed for per-pair decomposition. If a destructive readout is used, lineage outcome must be linked through a separate non-destructive measurement or a design that preserves the pair’s fate information; otherwise the physical burden-to-fate link remains unmeasured.

The partition interpretation is falsified if the prespecified physical lesion measure shows no early daughter asymmetry at the experiment’s resolution while reporter asymmetry appears later; if a fitted repair/formation model predicts the late signal without an early partition; if the effect is equally present in matched MERVL-negative divisions; or if the claimed lower-burden advantage disappears when both branches, death, and tracking losses are included. The expected result is not an epigenetic-clock change: it is an early, physically measured lesion fraction that predicts branch fate/function beyond cell-cycle and reporter state.

## Observation and resource costs

For a pair-level asymmetry score \(A=(P_1-P_2)/(P_1+P_2)\in[-1,1]\), if \(n\) independent informative divisions are collected per arm and the target mean contrast is at least \(\Delta\), Hoeffding’s inequality gives the conservative error bound \(2e^{-n\Delta^2/4}\). At two-sided \(\alpha=0.05\), \(\Delta=0.20\) requires 369 informative pairs per arm. This is a bound under independent-pair sampling, not a fitted effect or a realistic power calculation; culture clustering, calibration error, and informative tracking/death loss increase the required number.

A useful-pair yield \(q_{div}=0.006\) would imply about 61,500 screened divisions per arm in expectation. That value is illustrative only. The study highlight’s approximate 1% instantaneous 2C-like prevalence and 60% asymmetric-division fraction do not identify event yield: state dwell time and division hazard are required. Required acquired quantities include cytokinesis-to-first-read delay, pair and lineage loss, lesion-assay repeatability/background, sister-specific reporter gain, short-window repair/production kinetics, state-entry/division hazards, clustering, and imaging/assay throughput. Money and experiment duration are therefore UNKNOWN from the current source material.

The direct physical assay, repeated imaging, sister-pair tracking, cell-cycle staging, and outcome capture each consume measurement capacity. If only fixed cohorts are feasible, state clearly that the inference is cohort-level and include its exchangeability assumptions. Do not translate the illustrative sample count into a clinical or intervention recommendation.

## Prior-art and claim boundary

- **Wang et al. (2026), primary focal study:** paired-sister live 53BP1-Tudor reporter asymmetry; endpoint γH2AX in tracked pairs; damage/fate association; sorted-cell comet assay; DDR perturbations. This preempts the broad candidate claim.
- **Ferrand et al. (2025), [primary study](https://doi.org/10.1038/s41467-025-56090-8):** measures CPDs on metaphase sister chromatids and in identified early-G1 sister pairs after local UV damage; reports about 15% mean daughter CPD bias and negligible early CPD repair. This preempts the general idea that physical lesions may segregate asymmetrically or that immediate-vs-repair timing matters.
- **Lezaja et al. (2021), [primary study](https://doi.org/10.1038/s41467-021-23806-5):** live imaging shows postmitotic RPA foci precede and persist longer than 53BP1 foci and mark largely distinct inherited lesions, supporting the need to name the measured lesion/readout class.
- **Panagopoulos et al. (2025), [primary study](https://doi.org/10.1038/s41586-025-08986-0):** multigenerational 53BP1/PCNA tracking shows cell-cycle-gated inherited damage structures and sister heterogeneity; the public processed workbook does not contain continuous sister trajectories.

The only narrow gap that survives these precedents is a direct, lesion-class-specific, fate-linked physical burden measurement at the division boundary in spontaneous 2C-like mouse ESCs. Its novelty and biological importance remain unverified. The realistic next gate is obtaining raw sister-resolved movies/source data from the Wang study or performing a calibrated new measurement; until then this is an unresolved experimental question, not a scientific advance. The available public RNA matrices and U-2 OS summary tables cannot resolve it.

## Local prior-work boundary and artifacts

The task-local prior reports already cover washout observability, hidden jump-memory, branching clone outcomes, and ordinary pulse timing. This report avoids reusing those arguments. The source/data record is in [SOURCE_NOTES.md](SOURCE_NOTES.md); the claim ledger is in [CLAIMS.json](CLAIMS.json); the independent assay and prior-art attacks are in [independent_identifiability_attack.md](independent_identifiability_attack.md) and [independent_prior_art_attack.md](independent_prior_art_attack.md).
