# C7 functional-analytic / Markov-form attack

**Status.** Exact structural lemmas below are internally proved under the supplied finite-dimensional interface. They do not prove or refute the universal EB comparison. They isolate why the tempting fixed-algebra/conditional-expectation route is insufficient, and give the remaining all-frame gate. No external proof review or novelty claim is made.

## Interface

Let $\Phi:M_d\to M_d$ be CPTP, unital, Hilbert--Schmidt self-adjoint, positive as an operator on the real Hermitian Hilbert space, and self-compatible through a supplied CPTP map $\mathcal B:M_d\to M_d\otimes M_d$ with both marginals $\Phi$. Use $\tau=\operatorname{Tr}/d$ and $\langle A,B\rangle_\tau=\tau(AB)$. The target is one full-domain EB channel $\Psi$ with

\[
 I-\Psi\preceq2(I-\Phi).
\tag{T}
\]

I read the root mandate and workflow first, then the exact C4 tree/weighted-tree and hostile-audit proofs, the C5 low-energy proof and sharp-cloner/tensor proofs, and the C7 product-family result. Their statuses remain internal/source-derived, not externally validated. This note takes the multiplicative-domain/Dirichlet route only; it does not repeat the tree or product arguments.

## Hermitian-Kraus Markov representation

There are Hermitian Kraus operators $H_1,\dots,H_s$ such that

\[
 \Phi(A)=\sum_j H_j A H_j,\qquad \sum_jH_j^2=I.
\tag{1}
\]

Proof: start from any Kraus family $K_j$. Since $\Phi=\Phi^*$,

\[
 \Phi(A)=\frac12\sum_j(K_jAK_j^*+K_j^*AK_j).
\]

For each $j$, replace the Kraus pair $K_j/\sqrt2,K_j^*/\sqrt2$ by its unitary mixing

\[
 H_{j,+}=\frac{K_j+K_j^*}{2},\qquad
 H_{j,-}=\frac{i(K_j-K_j^*)}{2}.
\]

Both are Hermitian and direct expansion gives
$H_{j,+}AH_{j,+}+H_{j,-}AH_{j,-}=(K_jAK_j^*+K_j^*AK_j)/2$.
This proves (1) without a choice of Choi eigenbasis. Unitality gives $\sum H_j^2=I$; because $H_j=H_j^*$, this is also the trace-preserving Kraus identity.

For every Hermitian $A$, cyclicity of $\tau$ gives the exact Dirichlet form

\[
 \mathcal E_\Phi(A):=\langle A,(I-\Phi)A\rangle_\tau
 =\frac12\sum_j\|[H_j,A]\|_{2,\tau}^2.
\tag{2}
\]

Indeed, for one Hermitian $H$, $\|[H,A]\|_2^2=2\tau(A^2H^2)-2\tau(AHAH)$; summing and using $\sum H_j^2=I$ proves (2). This is an exact noncommutative Markov/Dirichlet representation, not an approximation or a stochastic interpretation. The Hilbert--Schmidt positivity assumption in the task further restricts the spectrum to $[0,1]$; the commutator identity itself already proves $I-\Phi\succeq0$ without that extra spectral-positivity assumption.

The Hilbert--Schmidt fixed algebra is therefore

\[
 \mathcal F=\ker(I-\Phi)=\{H_1,\ldots,H_s\}' .
\tag{3}
\]

Here positive spectrum ensures $I-\Phi\succeq0$; alternatively (2) directly identifies the zero-energy vectors. The commutant is a unital $*$-subalgebra.

## Exact self-compatibility forces the fixed algebra to be abelian

Let $\mathcal B^*:M_d\otimes M_d\to M_d$ be the unital CP Heisenberg adjoint. For $a\in\mathcal F$, the two marginal identities give

\[
 \mathcal B^*(a\otimes I)=a=\mathcal B^*(I\otimes a).
\]

Also $a^*a\in\mathcal F$, so

\[
 \mathcal B^*((a\otimes I)^*(a\otimes I))=a^*a
 =\mathcal B^*(a\otimes I)^*\mathcal B^*(a\otimes I),
\]

and the analogous equality holds for $I\otimes a$. Equality in Kadison--Schwarz puts both copies in the multiplicative domain of $\mathcal B^*$. For $a,b\in\mathcal F$, the commuting tensors $a\otimes I$ and $I\otimes b$ then have commuting images, while multiplicativity says those images are $ab$ and $ba$. Thus $ab=ba$. This proves $\mathcal F$ is abelian.

Consequently the trace-preserving conditional expectation $E_\mathcal F$ exists and is EB: if $P_1,\dots,P_r$ are its minimal projections, then

\[
 E_\mathcal F(A)=\sum_{k=1}^r\frac{\tau(P_kA)}{\tau(P_k)}P_k.
\]

This is a real structural consequence of exact positivity/Markov form plus compatibility: all exactly zero-energy directions lie in a commutative algebra. It does **not** give (T) without more information. If every nonfixed eigenvalue of $\Phi$ is at most $1/2$, then $I-\Phi\succeq\tfrac12(I-E_\mathcal F)$ and $\Psi=E_\mathcal F$ satisfies (T). More generally, the exact projection comparison constant is the inverse spectral gap $\gamma^{-1}$, where $\gamma=\min_{\lambda<1}(1-\lambda)$; compatible channels may have arbitrarily small $\gamma$ on classical modes.

## Two exact obstructions to projection-only strategies

### Fixed-algebra expectation can lose arbitrarily slow classical modes

For $d\ge5$, let $R_d$ be the symmetric nearest-neighbor walk on the cycle, with transition eigenvalues $\cos(2\pi k/d)$, and put $P_d=(I+R_d)/2$. Its eigenvalues are $\lambda_k=\cos^2(\pi k/d)\in[0,1]$. Define

\[
 \Phi_d(A)=\sum_{i,j}(P_d)_{ij}\langle j|A|j\rangle |i\rangle\langle i|.
\tag{4}
\]

This is a symmetric bistochastic classical Markov channel preceded/followed by dephasing. It is CPTP, unital, trace-preserving, HS self-adjoint and HS-positive. It is EB, hence self-compatible by copying its classical output. Irreducibility of the cycle gives $\mathcal F=\mathbb CI$, so $E_\mathcal F(A)=\tau(A)I$. On the traceless real cosine mode $A_j=\cos(2\pi j/d)|j\rangle\langle j|$ (normalized in $L^2(\tau)$), $\Phi_d(A)=\lambda_1A$ and $E_\mathcal F(A)=0$. Hence

\[
 \langle A,(I-E_\mathcal F)A\rangle_\tau=1,
 \qquad 2\mathcal E_{\Phi_d}(A)=2(1-\lambda_1)=2\sin^2(\pi/d)<1
\]

for $d\ge5$, with the right side tending to zero. Thus the exact fixed-algebra expectation cannot be a factor-two comparator. This is not a counterexample to (T): $\Phi_d$ itself is EB and gives $I-\Phi_d\preceq2(I-\Phi_d)$ (indeed constant one).

### No abelian conditional expectation can be the universal factor-two witness

Use the exact universal $1\to2$ qubit cloner marginal from the C5 sharpness proof,

\[
 \Phi(X)=\tfrac23X+\tfrac13\tau(X)I.
\tag{5}
\]

It satisfies every target assumption and is self-compatible. Let $E_D$ be any trace-preserving conditional expectation onto an abelian $*$-subalgebra $D\subset M_2$. On the traceless Hermitian space (real dimension $3$), $D\cap\{I\}^{\perp}$ has dimension at most $1$, so choose a unit traceless Hermitian $A\perp D$. Since $E_D$ is the $L^2(\tau)$ orthogonal projection, $E_D(A)=0$. Equation (5) gives

\[
 \langle A,(I-E_D)A\rangle_\tau=1
 \quad\text{but}\quad
 2\langle A,(I-\Phi)A\rangle_\tau=\tfrac23.
\]

Therefore no conditional expectation onto any abelian algebra satisfies (T), even for the qubit universal cloner. Yet the covariant coherent-state EB comparator from the C5 exact proof has traceless eigenvalue $1/3$ and satisfies equality $I-\Psi=2(I-\Phi)$. The sought object must allow a genuinely non-idempotent EB map; conditional expectation is a strictly too-narrow target.

## Any successful EB comparator can be symmetrized

Suppose a CPTP EB map $\Psi$ satisfies (T), with the operator order interpreted on Hermitian Hilbert--Schmidt space. Let $D=2(I-\Phi)-(I-\Psi)\succeq0$. Since $\Phi(I)=I$ and $\Psi$ is trace-preserving, $\langle I,DI\rangle_\tau=0$. Positivity forces $DI=0$, hence $\Psi(I)=I$. Thus any successful comparator is automatically unital. Its Hilbert--Schmidt adjoint is also a bistochastic EB map: from a measure-and-prepare form $\Psi(X)=\sum_y\operatorname{Tr}(M_yX)\sigma_y$, unitality says $\sum_y\operatorname{Tr}(M_y)\sigma_y=I$, and

\[
 \Psi^*(A)=\sum_y\operatorname{Tr}(\sigma_yA)M_y
\]

is measure-and-prepare with effects $\operatorname{Tr}(M_y)\sigma_y$ and prepared states $M_y/\operatorname{Tr}(M_y)$. Since $\Phi=\Phi^*$, taking adjoints preserves the comparison. Averaging $\Psi$ and $\Psi^*$ therefore gives a self-adjoint bistochastic EB comparator whenever any EB comparator exists. This narrows the full-EB search, but does not show that every such symmetric EB map is a canonical same-effect/same-preparation map $\Psi_M$.

## Exact remaining gate in the Dirichlet representation

For any POVM $M=(M_y)$, its canonical self-adjoint EB map is

\[
 \Psi_M(A)=\sum_y\frac{\tau(M_yA)}{\tau(M_y)}M_y,
 \qquad
 \langle A,\Psi_MA\rangle_\tau
 =\sum_y\frac{\tau(M_yA)^2}{\tau(M_y)}.
\]

By (2), the desired inequality for this map is exactly

\[
 \sum_y\frac{\tau(M_yA)^2}{\tau(M_y)}
 \ge \|A\|_{2,\tau}^2-\sum_j\|[H_j,A]\|_{2,\tau}^2
 \quad\text{for every Hermitian }A.
\tag{6}
\]

One POVM must make (6) hold for the *entire* Hermitian unit ball. Equivalently, for every positive Hilbert--Schmidt operator $Q$ on that real space, one must prove the support-function gate

\[
 \sup_{M\ \mathrm{POVM}}\operatorname{Tr}_{HS}(Q\Psi_M)
 \ge \operatorname{Tr}_{HS}\!\left(Q(2\Phi-I)\right).
\tag{7}
\]

Finite-dimensional positive-cone separation then gives one common $\Psi_M$ if and only if (7) holds for every $Q\succeq0$. A rank-one $Q$ is settled by measuring its single observable on one broadcaster output; rank-two $Q$ is settled by measuring its two spectral observables on the two outputs. This is the exact depth-one consequence of the C4 score identity. For general rank, the known argument assigns frame directions to distinct leaves, and its cost is $\lceil\log_2\operatorname{rank}Q\rceil$ broadcast levels. The dimension-free factor-two conjecture is precisely whether the rank-independent one-POVM support gate (7) follows from the stated compatibility and Markov assumptions, or whether an admissible $Q$ violates it.

This gate is stronger than merely showing that low-energy observables commute pairwise: it asks for one POVM to capture the whole covariance ellipsoid $2\Phi-I$. The C5 commutator estimate and random-bin pinching control only pairwise/cross-bin leakage and do not establish (7). Conversely the Pauli-frame obstruction to a commutator-only average does not violate (7), because the channel-energy profile is retained in its right side.

There is a separate factorization gate suggested by the exact N92 instrument identity. That identity applies when a bistochastic instrument $L(A)=\sum_yK_yAK_y^*$, its effects $M_y=K_y^*K_y$, and the associated canonical EB map $\Psi_M$ produce

\[
 C=(L+\Psi_M)/2,\qquad \Phi=C^*C.
\]

Then $2(I-\Phi)-(I-\Psi_M)=(I-L^*L)+(\Psi_M-\Psi_M^2)+(L-\Psi_M)^*(L-\Psi_M)/2\succeq0$. The Markov representation (1) supplies a bistochastic instrument $L=\Phi$ using its Hermitian Kraus operators, but does not identify the original $\Phi$ as $C^*C$ for the corresponding measurement, nor produce another instrument with that property. Establishing that every admissible symmetric extension admits such an instrument/Petz factorization would settle (T); a counterexample to that representation alone would only close this proof route, not refute (T). The exact N92 report explicitly records this representation gap.

## Scope, costs, and next falsifier

All objects are exact finite-dimensional channels and matrices supplied as mathematical data. The Hermitian-Kraus representation and Dirichlet identities have no dimension/runtime cost claim. Equations (4) and (5) are exact analytic fixtures; no floating-point computation is used. The cycle example and cloner only falsify the fixed-expectation and arbitrary-projection proof strategies, not the unrestricted EB theorem. No bounded-Holevo family counterexample is supplied.

The decisive next result is either a proof of (7) for all $Q\succeq0$, preferably by a measurement/Stein-factorization derived from the two-output extension, or one exact self-compatible channel and positive $Q$ with

\[
 \operatorname{Tr}Q(2\Phi-I)>\sup_{M\ \mathrm{POVM}}\operatorname{Tr}(Q\Psi_M).
\]

The canonical-majorant lemma proved later in this cycle closes this subclass boundary for the stated order: every feasible trace-preserving EB comparator is bistochastic, and its symmetrized Holevo form is Loewner-dominated by the average of two canonical maps, itself canonical for the union POVM. See [CANONICAL_DOMINATION.md](../CANONICAL_DOMINATION.md). Therefore an exact deficit in canonical support is sufficient to refute factor two against all EB maps, provided it includes a legal broadcaster and a rigorous global moment-dual certificate. No such legal tuple was found here.

## Provenance and boundaries read

- `outputs/research/cycle_checkpoint_03/ROOT_MANDATE.txt` and `work/astra_prior/{00_START_HERE.txt,01_CORE.txt,RESEARCH_WORKFLOW.txt,AGENTS.md}`: user objective, exact-status and retrieval/cost rules.
- `outputs/research/cycle_checkpoint_03/evidence/c4_quantum_lift/WEIGHTED_TREE.md`: exact prefix-tree score and weighted operator profile; rank/entropy charge is retained.
- `outputs/research/cycle_checkpoint_03/evidence/c4_quantum_tree_hostile/FINAL_REPORT.md`: compact-convex separation repair and status audit.
- `work/agents/c5_quantum_almost_abelian/proofs/low_energy_commutator_and_gate.md`: pairwise Dirichlet commutator estimate and precise common-measurement gate.
- `outputs/research/cycle_checkpoint_03/evidence/c5_quantum_dimension_obstruction/proofs/UNIVERSAL_CLONER_SHARPNESS.md`: exact qudit cloner lower bound and equality witness.
- `outputs/research/cycle_checkpoint_03/evidence/c5_quantum_dimension_obstruction/proofs/TENSOR_STABILITY.md`: tensor stability proof; not used as a premise here.
- `work/agents/c4_quantum_lift/cycle7_replay/FINAL_REPORT.md`: exact repeated-product comparator, distinct structured class.
- `work/agents/quantum_physics/sources/N93-bounded-holevo-gates.txt` and `work/agents/broadcast_information_attack/d-48ed31af9b1d38fd.txt`: fixed-point slow-classical-mode warning, N92 exact instrument-class SOS, and general representation gap.
