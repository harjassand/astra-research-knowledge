# C7 Markov-form source and retrieval notes

Date: 2026-10-08. Retrieval was task-first and selective. The root mandate and workflow were read before mathematical work; exact C4/C5 proofs were read before this attack. The relevant N92/N93 source card paths in the Astra route are indexed, but those particular card files are absent from this static checkout. I used the preserved detailed N93 source extraction and local proof artifacts listed below. Status remains internal/source-derived, not externally reviewed.

## Primary literature checked

1. Michael M. Wolf, *Quantum Channels & Operations: Guided Tour* (2012 lecture notes), Proposition 2.6, PDF pp. 42–43 / extracted browser lines 2097–2131: a CP map is Hilbert–Schmidt self-adjoint iff it has a Hermitian Kraus representation. The proof symmetrizes the Kraus family with its adjoints and unitary-mixes each pair. This supports the standard representation fact; the local note also gives the direct algebra. Source: https://mediatum.ub.tum.de/download/1701036/%25201701036.pdf . The note describes itself as unfinished in its front matter, so it is used only for this elementary stated proposition, not as independent validation of the new argument.
2. H. Barnum, C. Caves, C. Fuchs, R. Jozsa, B. Schumacher, *Noncommuting mixed states cannot be broadcast*, arXiv:quant-ph/9511010 (1995), HTML lines 35–48 and 90–120: exact broadcasting of a pair of states is possible iff they commute. This is qualitative background only; the fixed-algebra proof in MARKOV_FORM_GATE.md is derived directly by the multiplicative domain.
3. M. Keyl and R. F. Werner, *Optimal Cloning of Pure States, Judging Single Clones*, arXiv:quant-ph/9807010 (1998), journal reference J. Math. Phys. 40 (1999) 3283–3299. The exact qudit cloner marginal and factor-two EB equality used in the projection obstruction are already derived in the local C5 sharpness proof; this source is cited there as the cloner construction provenance.

## Local decisive proof ranges read

- `outputs/research/cycle_checkpoint_03/ROOT_MANDATE.txt`: full mandate.
- `work/astra_prior/00_START_HERE.txt`, `01_CORE.txt`, `RESEARCH_WORKFLOW.txt`, `AGENTS.md`: retrieval, status and record rules.
- `outputs/research/cycle_checkpoint_03/evidence/c4_quantum_lift/WEIGHTED_TREE.md`, especially lines 21–58 and 78–95: one-output score, weighted depth assignment, separation and rank/entropy cost.
- `outputs/research/cycle_checkpoint_03/evidence/c4_quantum_tree_hostile/FINAL_REPORT.md`, especially its compactness/separation section: canonical-map compactness repair and proof scope.
- `outputs/research/cycle_checkpoint_03/evidence/c5_quantum_dimension_obstruction/proofs/UNIVERSAL_CLONER_SHARPNESS.md`, lines 3–44: exact cloner marginal, EB covariant equality witness.
- `outputs/research/cycle_checkpoint_03/evidence/c5_quantum_dimension_obstruction/proofs/TENSOR_STABILITY.md`: tensor comparator scope; not used as a premise.
- `work/agents/c5_quantum_almost_abelian/proofs/low_energy_commutator_and_gate.md`: pairwise Dirichlet commutator bound, Pauli frame boundary and random-bin gate.
- `work/agents/c4_quantum_lift/cycle7_replay/FINAL_REPORT.md`: exact repeated-product comparator and its structural scope.
- `work/agents/quantum_physics/sources/N93-bounded-holevo-gates.txt`, lines 1–18: general EB lift remains open; exact fixed-point projection loses slow classical modes; N92 only proves explicit classes.
- `work/agents/broadcast_information_attack/d-48ed31af9b1d38fd.txt`, lines 208–265 and 267–320: exact POVM/Lüders and instrument/Petz factor-two identities, followed by the explicit statement that no representation theorem covers every self-compatible marginal.

## Hashes of local inputs

SHA-256 at time of retrieval:

- ROOT mandate: `085becba25e31939f5c94affe45b8e303516bbc606b442b96b2db289ef600cb6`
- Astra start: `942f14761e72a88fbedacb268cf48272662a0f8e6005a6bdf1dd24c75374a77b`
- Astra core: `d7a4c6b7c339aca36241a706d5d8f87620985c7684ec7c42f230806e973adbd4`
- Workflow: `2fad297cb3c879f47e33547c0aa6dd3307667c2aa6127e7aee98cce5b1f0a2b6`
- Astra AGENTS: `03e125802387eb134a5d5e1426d71ca0ae7caef7dcb6c1a224454a3aa9d9a0fe`
- C4 weighted tree: `02d3eea6507b6c5d8d10f4872bf75753c6d9cbc84ca33b20bc128bd8a8594f64`
- C4 lift report: `50dca8b201e11166fc1c403f24b83ee639d706923fc78ef470314d5ec8db9c2c`
- C4 hostile report: `f8560f414d0818571c1c31322a503635a545e732d0cd69c76603047c33282557`
- C5 cloner proof: `37ab5e32f513c139bf123eefaa0cb7b20d3a92afd6c19523be5e0ac665d5c05f`
- C5 tensor proof: `dc78a47e3e91874a87a44514486b853090ec1f5af46220b4e326a5187fb3b8c5`
- C5 almost-commutator proof: `3647ae0a132a25020425c5a73e85a1467ec1a49a789c2f962723939de5dc4f64`
- N93 source extraction: `353744f1fd70543f1564543f54de5ab63cb61a8ce34ff7e5f5dcdca0eb301cd2`
- N92/N93 detailed extraction: `c4ee85455f441e5c3ce44ba8bbf4fd329f3fed1f53c33ad5c8cc0d5e2e44d9de`
- C7 product report: `cc57bcd85862975db007668fb7e102646dd1bfca824602216fb268d4974c6a6c`

The derivations in MARKOV_FORM_GATE.md use no downloaded proof files or numerical outputs. The cloner is an imported established construction; the local C5 proof carries its exact marginal and comparison calculation.
