# C7 canonical-EB moment cone: exact dual and route obstruction

## Verdict

The universal factor-two channel-to-canonical-EB comparison remains **UNKNOWN**. This branch produced no legal channel/dual violation and no proof for arbitrary finite-dimensional self-compatible channels. It does make the all-positive-dual gate exact as a compact moment-cone support problem and identifies two concrete invalid shortcuts: replacing the POVM moment problem by a pure-state maximum, and using the unconstrained top eigenvalue of the three-party star Hamiltonian for a noninvariant dual.

## Exact canonical-POVM moment cone

Let \(\tau=\operatorname{Tr}/d\), let \(\mathcal H_0\) be the real Hilbert space of traceless Hermitian matrices with inner product \(\langle A,B\rangle_\tau=\tau(AB)\), and let \(Q\succeq0\) act on \(\mathcal H_0\). Write a spectral decomposition

\[
Q=\sum_i w_i |A_i\rangle\!\rangle\langle\!\langle A_i|,
\qquad w_i\ge0,
\]

with \(\tau(A_i^2)=1\). A canonical POVM map is

\[
\Psi_M(X)=\sum_z\frac{\tau(M_zX)}{\tau(M_z)}M_z.
\]

Refining every effect into rank-one pieces cannot decrease \(\operatorname{Tr}_{HS}(Q\Psi_M)\): for each \(A_i\), this is the weighted Cauchy--Schwarz inequality applied to the refined outcomes. Thus support maximization may be restricted to rank-one POVMs \(M_z=d p_zP_z\), where \(P_z\) are pure projectors and \(\sum_zp_zP_z=I/d\). For these maps,

\[
\operatorname{Tr}_{HS}(Q\Psi_M)
=\sum_zp_z f_Q(P_z),\qquad
f_Q(P)=\sum_iw_i\bigl(\operatorname{Tr}(P A_i)\bigr)^2.
\]

Consequently the canonical support is the finite-dimensional moment problem

\[
S_d(Q)=\max_{\substack{\mu\in\mathcal P(\mathbb P(\mathbb C^d))\\
                         \int P\,d\mu(P)=I/d}}
          \int f_Q(P)\,d\mu(P).
\tag{1}
\]

This is an exact representation, not a relaxation. The constraint says the pure-state ensemble is a POVM 1-design; it is the part lost by maximizing \(f_Q\) over one unconstrained pure state.

There is a simple universal feasible point in (2): \(Z_Q=\sum_iw_iA_i^2\). For each pure \(P\), scalar variance gives \(f_Q(P)\le\operatorname{Tr}(Z_QP)\), and \(\tau(Z_Q)=\operatorname{Tr}_{HS}Q\). Hence \(S_d(Q)\le\operatorname{Tr}_{HS}Q\), with equality whenever the frame has a common eigenbasis. This upper bound alone does not prove the factor-two gate, which needs a matching lower bound tied to the compatible channel.

The corresponding exact linear-program dual is

\[
S_d(Q)=\inf_{Z=Z^*}
 \left\{\tau(Z):\ \operatorname{Tr}(ZP)\ge f_Q(P)
                  \text{ for every rank-one }P\right\}.
\tag{2}
\]

Indeed, every feasible \(Z\) upper-bounds (1) after integration against a measure of barycenter \(I/d\). Equality follows from finite-dimensional linear-program duality for measures on the compact pure-state space; equivalently, take the compact convex hull of \((P,f_Q(P))\) and separate its optimal-height point from the prescribed barycenter fiber. A feasible \(Z\) is therefore a directly checkable upper certificate for \(S_d(Q)\).

## Why pure-seed maximization is not the support

In dimension three take

\[
A=\operatorname{diag}(\sqrt2,-1/\sqrt2,-1/\sqrt2),\qquad Q=|A\rangle\!\rangle\langle\!\langle A|.
\]

Then \(\tau(A)=0\) and \(\tau(A^2)=1\), so \(\operatorname{Tr}_{HS}Q=1\). The unconstrained pure-state maximum is \(\max_P(\operatorname{Tr}(PA))^2=2\), attained by the top eigenvector. But (1) gives exactly \(S_3(Q)=1\): for every pure \(P\), variance nonnegativity gives \((\operatorname{Tr}PA)^2\le\operatorname{Tr}(PA^2)\), so each admissible ensemble scores at most \(\operatorname{Tr}(A^2)/3=1\); the eigenbasis PVM, with three weights \(1/3\), attains 1. In (2), \(Z=A^2\) is the matching exact dual certificate, with \(\tau(Z)=1\).

Thus the invariant-spin shortcut “twirl one maximizing seed without changing the score” has no noninvariant analogue: an optimizing seed need not itself provide the required barycenter, and averaging it to repair the barycenter can lower its score.

## Mixed duals are the simultaneous-measurement gate

The support is a sublinear function of \(Q\), and it can be strictly subadditive. For a qubit, let \(X,Z\) be the usual Pauli matrices, orthonormal in normalized-trace Hilbert--Schmidt norm, and put \(Q_X=|X\rangle\!\rangle\langle\!\langle X|\), \(Q_Z=|Z\rangle\!\rangle\langle\!\langle Z|\). Measuring the eigenbasis of either observable proves \(S_2(Q_X)=S_2(Q_Z)=1\). For \(Q_X+Q_Z\), a pure state has Bloch vector \(r\) with \(r_x^2+r_z^2\le1\); an equatorial X-basis ensemble attains 1, hence

\[
S_2(Q_X+Q_Z)=1<2=S_2(Q_X)+S_2(Q_Z).
\]

Therefore separate exact tests on rank-one duals or symmetry-sector axes do not imply the required inequality on their positive sums. This is an internal moment-cone obstruction, not a channel counterexample: channel feasibility may impose exactly the extra mixed-frame restriction needed for factor two.

## Compactness and exact common-map extraction criterion

The set of **all** canonical maps is compact and convex, but its compactness should not be justified by identifying it with rank-one POVM maps. For an arbitrary POVM, put \(p_y=\operatorname{Tr}(M_y)/d\) and \(\rho_y=M_y/\operatorname{Tr}(M_y)\), omitting zero effects. Then \(\sum_y p_y\rho_y=I/d\) and its canonical channel is
\[
  \Psi_\mu(X)=d\int_{\mathcal D_d}\operatorname{Tr}(\rho X)\rho\,d\mu(\rho),
\]
where \(\mathcal D_d\) is the compact density-matrix space and \(\mu=\sum_y p_y\delta_{\rho_y}\). Conversely, every finite-support probability measure on \(\mathcal D_d\) with barycenter \(I/d\) defines a POVM by \(M_y=dp_y\rho_y\). The set of all probability measures with this barycenter is compact and convex in the weak topology; the displayed second-moment map is continuous and finite-dimensional. Every point of its image has a finite-support representative: apply Carathéodory to the combined barycenter and second-moment coordinates. Thus this image is exactly the full canonical-map set and every map in it has a finite POVM realization.

Rank-one refinement is a distinct useful fact, not equality of sets. Spectrally refining any effect into rank-one pieces PSD-dominates its canonical map by weighted Cauchy--Schwarz. Hence for every \(Q\succeq0\), the support supremum is attained among rank-one POVMs; likewise, if a canonical map dominates a target, a rank-one-refined canonical map still dominates it. Consequently one may use the compact rank-one-map subset for the support/separation gate and then extract a finite POVM, while retaining that arbitrary canonical maps need not be rank-one maps (for example, the one-effect POVM \(\{I\}\) gives the depolarizing map).

Let \(\mathcal C_d\) be the set of all canonical maps restricted to \(\mathcal H_0\). It is compact and convex by the density-matrix measure argument above. Mixing measures retains the classical coin in the outcome and realizes convex combinations as canonical POVMs.

For any fixed unital, trace-preserving, self-adjoint channel \(\Phi\), set \(T=2\Phi-I\) on \(\mathcal H_0\). Positive-cone separation gives the exact equivalence

\[
\exists\Psi\in\mathcal C_d:\ \Psi\succeq T
\quad\Longleftrightarrow\quad
S_d(Q)\ge 2\operatorname{Tr}_{HS}(Q\Phi)-\operatorname{Tr}_{HS}Q
\quad\text{for every }Q\succeq0.
\tag{3}
\]

The forward implication is immediate. If no common \(\Psi\) exists, the compact convex set \(\mathcal C_d\) and the closed cone \(T+\{R:R\succeq0\}\) are strongly separable. The separating functional must be a positive \(Q\) (otherwise its infimum over the translated PSD cone is \(-\infty\)); it gives a strict failure of the support inequality in (3). Conversely, if (3) holds for every \(Q\), separation is impossible, so one canonical \(\Psi\) dominates \(2\Phi-I\). Carathéodory then supplies a finite-outcome POVM for that *same* \(\Psi\). This is precisely where a family of Q-dependent witnesses becomes one common full-domain measurement; checking finitely many frames does not perform this step. The identity-slack reduction from unrestricted EB comparators to canonical maps is valid only when the quadratic-form inequality is imposed on **all Hermitian inputs** and K(I)=I. For an H0-only premise the argument does not force unitality; no such extension is asserted here.

Combining (2) and (3), a fully explicit exact obstruction certificate for any proposed counterexample consists of: (i) a legal symmetric broadcaster Choi state \(\Omega_{RAB}\succeq0\) with \(\operatorname{Tr}_{AB}\Omega=I_R/d\), output-swap invariance \(S_{AB}\Omega S_{AB}=\Omega\), equal bipartite marginals \(\operatorname{Tr}_A\Omega=\operatorname{Tr}_B\Omega=J_\Phi\), output marginals \(I/d\), and a self-adjoint marginal channel; (ii) a positive \(Q\); and (iii) a Hermitian \(Z\) satisfying \(\operatorname{Tr}(ZP)\ge f_Q(P)\) for every pure \(P\), but

\[
\tau(Z)<2\operatorname{Tr}_{HS}(Q\Phi)-\operatorname{Tr}_{HS}Q.
\tag{4}
\]

Such a \(Z\) certifies the moment-cone upper bound, while the feasible \(\Omega\) certifies the channel lower bound. No such triple was found in this pass.

## Precise obstruction to the unconstrained star route

For \(Q=|A\rangle\!\rangle\langle\!\langle A|\), the three-party star operator is

\[
H_Q=A^T\otimes(A\otimes I+I\otimes A).
\]

With the qutrit \(A\) above, its largest eigenvalue is \(2(\sqrt2)^2=4\), whereas \(\operatorname{Tr}_{HS}Q+S_3(Q)=2\). Its unique top eigenspace is spanned by \(|1\rangle_R|1\rangle_A|1\rangle_B\), which is not a legal broadcaster Choi state: it fails the fixed reference and output marginals. Indeed any legal channel marginal is a Hilbert--Schmidt contraction, so this rank-one dual has \(2\operatorname{Tr}_{HS}(Q\Phi)\le2\), showing the unconstrained star maximum 4 is strictly loose. In the C6 spin proof, group twirling a top eigenstate repairs the marginals *because the test Q is invariant and its star Hamiltonian commutes with that group*. For general Q, this operation changes the objective; the invariant-star equality is not a valid arbitrary-Q upper bound.

This closes no theorem. It identifies why the exact spin-star method cannot simply be applied to an arbitrary dual and why an actual counterexample needs the marginal constraints, rather than just a large eigenvalue of \(H_Q\).

## Next decisive calculation

For a proof, it is sufficient to show for every legal extension and every \(Q\succeq0\) that

\[
2\operatorname{Tr}_{HS}(Q\Phi)-\operatorname{Tr}_{HS}Q
\le \inf_{Z:\,\operatorname{Tr}(ZP)\ge f_Q(P)\ \forall P}\tau(Z).
\]

For a counterexample, (4) must be verified against all pure projectors, not a finite state grid, unless the grid is accompanied by a rigorous global envelope. The principal unresolved step is therefore a mixed-Q inequality coupling the broadcaster's *marginal-feasible* two-body correlations to a quadratic pure-state envelope with the POVM barycenter constraint retained.

## Inputs read

I read `work/ROOT_MANDATE.txt`, the Astra start/core/workflow files, `work/agents/c5_quantum_almost_abelian/FINAL_REPORT.md` and its detailed proof, the C4 `FINAL_REPORT.md` and `WEIGHTED_TREE.md`, and the C5/C6 spin-star exact proofs (`GENERAL_SPIN_REDUCTION.md`, `STAR_HAMILTONIAN.md`, `CLIFFORD_VECTOR_DUAL.md`, and the higher-spin report). This note uses the prior proofs only to set their precise boundary; it does not repeat the Markov/conditional-expectation or tree-coding arguments.

For the external compatibility boundary, I checked Haapasalo--Kraft--Miklin--Uola, [*Quantum Marginal Problem and Incompatibility*](https://arxiv.org/abs/1909.02941), especially its channel-compatibility/Choi-marginal correspondence (Theorem 1) and channel-compatibility setup (§3). It supplies the standard feasibility representation used in the proposed certificate, not the canonical-EB Loewner inequality (3). This was a scoped prior-art check, not an exhaustive novelty review.
