# C7 source notes: almost commutation and EB form

Checked 2026-10-08 using primary arXiv versions. Browsing is a scoped prior-art/interface check, not exhaustive novelty clearance.

## Almost-commuting normalized-HS results

Mohit Bansil and Ilya Kachkovskiy, [*On almost commuting matrices with respect to the normalized Hilbert--Schmidt norm*](https://arxiv.org/abs/2608.31000), v1 dated 31 Aug 2026.

- Definition (1.2) uses ∥X∥_{2,d}=d^{-1/2}∥X∥_2, the normalized tracial L2 norm.
- Theorem 1.1 proves for two self-adjoint contractions commuting self-adjoint approximants, with ∥X-X' ∥²_{2,d}+∥Y-Y' ∥²_{2,d} ≤ 24∥[X,Y]∥^{2/3}_{2,d}; its abstract states the rounded sum-of-errors bound 5∥[X,Y]∥^{1/3}_{2,d}.
- Theorem 1.3 has one anchor and N further matrices and an explicit 24√N factor multiplying the cube root of the sum of squared commutators. Corollary 1.4 gives an all-pair commuting approximation with a constant C(N) and exponent 2/3^{N-1}. These results are dimension-independent at each fixed N, not uniform as N grows with d.
- The authors explicitly note that Theorem 1.1 cannot be directly iterated, and the modified route reintroduces N dependence. It does not directly provide one POVM for a channel’s entire growing operator range.

Lev Glebsky, [*Almost commuting matrices with respect to normalized Hilbert--Schmidt norm*](https://arxiv.org/abs/1002.3082), v1 dated 16 Feb 2010.

- Theorem 4 states for each fixed k there is a dimension-independent modulus δ(ε,k) for a k-tuple of self-adjoint contractions with pairwise normalized trace-norm commutators at most ε.
- The quantifier fixes k before ε tends to zero. It does not state a modulus uniform in k and does not control an entire channel-range unit ball with one coordinatewise measurement.

## Entanglement-breaking channel representation

Michael Horodecki, Peter W. Shor, and Mary Beth Ruskai, [*General Entanglement Breaking Channels*](https://arxiv.org/abs/quant-ph/0302031), v2.

- Theorem 2 states that an EB channel has Holevo measure-and-prepare form and that the measurement operators form a POVM exactly when the map is trace-preserving.
- The same source records convexity of the EB trace-preserving maps. It supplies the standard finite-dimensional representation used in `CANONICAL_DOMINATION.md`; it does not state the PSD canonical-majorant identity proved there.

## Local evidence and open boundary

- `work/agents/c5_quantum_almost_abelian/proofs/low_energy_commutator_and_gate.md`: internal tree-derived pairwise Dirichlet commutator estimate, Pauli-family shortcut counterexample, bin-pinching identity, and all-family uniform-range gate.
- `work/agents/c4_quantum_lift/FINAL_REPORT.md` and `WEIGHTED_TREE.md`: internal logarithmic-rank and spectral-profile EB comparisons; they do not establish the universal c=2 inequality.
- `work/agents/c5_quantum_dimension_obstruction/cycle6_dual_star/proofs/STAR_HAMILTONIAN.md`: internal spin-1 factor-two proof and its invariant-dual scope.
- `work/agents/c5_quantum_almost_abelian/cycle7_all_Q/eb_moments/REPORT.md`: exact canonical support moment primal/dual; qutrit pure-seed and unconstrained-star obstructions; no legal channel counterexample.
- `work/agents/c5_quantum_almost_abelian/cycle7_all_Q/markov_form/MARKOV_FORM_GATE.md`: exact Hermitian-Kraus Dirichlet form and abelian fixed algebra; projection routes fail on slow modes and on the qubit cloner.
- `work/agents/quantum_physics/sources/N93-bounded-holevo-gates.txt`: bounded-Holevo plus vanishing two-output error to uniform EB reconstruction remains open. It identifies the max-prior joint-variance convex roof and one-common-measurement quantifier.

All local proof reports are internally reconstructed worker artifacts, not external validation. No solver feasibility, finite numerical example, or selected-family estimate upgrades the unknown all-Q theorem.
