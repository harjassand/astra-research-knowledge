# C7 Markov-form subtask report

## Verdict

No proof or counterexample to the unrestricted factor-two EB comparison was obtained. The functional-analytic attack gives an exact Hermitian-Kraus/Dirichlet representation and proves that the fixed algebra is abelian under exact self-compatibility. It also shows two distinct limitations of projection strategies:

- The conditional expectation onto the exact fixed algebra fails on arbitrarily slow classical modes, even when the channel is already EB.
- No conditional expectation onto any abelian algebra can attain factor two for the qubit universal cloner, although a non-idempotent coherent-state EB map attains equality.

So “replace the channel by its fixed-point conditional expectation” cannot solve the problem, and conditional expectations are too narrow even when an EB comparator exists. Any universal construction must allow non-idempotent common EB maps.

## New exact structural result

A finite-dimensional CP Hilbert--Schmidt-selfadjoint map has Hermitian Kraus operators (H_j). For a unital map, Σ_j H_j²=I and

\[
\langle A,(I-\Phi)A\rangle_\tau=\tfrac12\sum_j\|[H_j,A]\|_{2,\tau}^2.
\]

Thus Φ is a symmetric noncommutative Markov operator with an exact commutator Dirichlet form, and its zero-energy algebra is the Kraus commutant. If Φ has a two-output broadcaster, the multiplicative-domain equality for both marginal copies forces that commutant to be abelian.

This is an exact description of the zero-energy directions. If the nonfixed spectrum is at most (1/2), its conditional expectation gives the factor-two comparison; in general the fixed-projection constant is the inverse spectral gap. The exact representation provides no gap bound and no control of a growing approximate-fixed space.

## Precise next gate

Any EB comparator satisfying the order is automatically unital, and averaging it with its Hilbert--Schmidt adjoint gives a self-adjoint bistochastic EB comparator. It need not be canonical. Within canonical POVM maps Ψ_M, existence of a comparator is equivalent to the rank-independent support condition

\[
\sup_M\operatorname{Tr}_{HS}(Q\Psi_M)\ge
\operatorname{Tr}_{HS}(Q(2\Phi-I))\quad\forall Q\succeq0.
\]

Equivalently, one POVM must capture the full covariance ellipsoid of (2\Phi-I). A rank-one witness is handled by measuring one output; rank two by measuring the two outputs. The known tree proof handles arbitrary rank but pays ⌈log₂ rank(Q)⌉ broadcast levels. Removing that rank cost is the exact unresolved gate for the canonical subclass.

A second sufficient route would be to represent every admissible Φ as the Petz-corrected square (C^*C) of an instrument-append marginal (C=(L+\Psi_M)/2). The exact N92 SOS then gives factor two. The Hermitian-Kraus Markov form supplies an instrument (L=\Phi), but does not establish this square factorization. Failure of this representation would close only that proof route, not the EB theorem.

## Evidence and status

The complete derivations, exact classical-cycle and cloner obstructions, and seven scoped claims are in [MARKOV_FORM_GATE.md](MARKOV_FORM_GATE.md) and [CLAIMS.json](CLAIMS.json). Primary-source retrieval and local file hashes are in [SOURCE_NOTES.md](SOURCE_NOTES.md). No computation was needed. All mathematical results here are internal derivations; the unrestricted comparison remains UNKNOWN, and no external proof review or priority claim is made.
