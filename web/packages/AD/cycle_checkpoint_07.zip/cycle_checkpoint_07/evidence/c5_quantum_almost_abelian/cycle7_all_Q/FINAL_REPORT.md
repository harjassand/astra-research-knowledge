# C7 all-Q quantum-to-EB comparison: canonical reduction and remaining gate

## Verdict

The unrestricted, dimension-free factor-two comparison remains **UNKNOWN**: no proof and no legal broadcaster/dual counterexample were found. This cycle did obtain an exact reduction that strengthens the all-Q attack: for the stated unital, trace-preserving, self-adjoint target (K=2\Phi-I), existence of *any* trace-preserving EB comparator in the quadratic-form sense is equivalent to existence of one canonical same-effect/same-preparation POVM channel. A canonical support deficit is therefore a decisive full-EB obstruction once witnessed by an exact legal example; it cannot be repaired by choosing a noncanonical EB comparator. The reduction assumes quadratic-form domination on **all Hermitian inputs** and K(I)=I; it does not force unitality from an H0-only premise.

The strongest remaining theorem gate is still mixed-frame support. One must show for every positive Hilbert--Schmidt dual (Q)

\[
 S_d(Q):=\sup_{M\text{ POVM}}\operatorname{Tr}_{HS}(Q\Psi_M)
 \ \ge\ 2\operatorname{Tr}_{HS}(Q\Phi)-\operatorname{Tr}_{HS}Q,
\tag{1}
\]

using a **marginal-feasible** symmetric broadcaster. The unconstrained top eigenvalue of the star Hamiltonian is not a valid relaxation when its top state violates Choi marginals. The generic iterated-tree proof remains (2\lceil\log_2(d^2-1)\rceil); the compiler and weighted prefix refinements do not remove the rank/commuting-cover loss.

## Exact full-EB to canonical-POVM reduction

The proof is in [CANONICAL_DOMINATION.md](CANONICAL_DOMINATION.md). If an EB CPTP map Λ satisfies the comparison, test the positive slack on (I). Since Φ is unital and Λ is trace-preserving, the slack has zero quadratic form at (I). Positivity forces its symmetric part (T=(\Lambda+\Lambda^*)/2) to fix (I). Trace preservation already gives Λ*(I)=I, so (T(I)=I) implies Λ(I)=I). Thus every feasible comparator is bistochastic, and its adjoint is also an EB channel.

Write its finite Holevo form as Λ(X)=Σ Tr(M_yX)σ_y, with ΣM_y=I and ΣTr(M_y)σ_y=I. Put (p_y=Tr(M_y)/d), ρ_y=M_y/Tr(M_y), and (N_y=d p_yσ_y). Both (M) and (N) are POVMs. In normalized tracial Hilbert--Schmidt space, set (u_y=d\sqrt{p_y}\rho_y), (v_y=d\sqrt{p_y}\sigma_y). Then

\[
 \Lambda=\sum_y|v_y\rangle\langle u_y|,\qquad
 \Lambda^*=\sum_y|u_y\rangle\langle v_y|,
\]

while the canonical maps from (M,N) are Ψ_M=Σ|u_y><u_y| and Ψ_N=Σ|v_y><v_y|. Hence

\[
 \frac{\Psi_M+\Psi_N}{2}-\frac{\Lambda+\Lambda^*}{2}
 =\frac12\sum_y|u_y-v_y\rangle\langle u_y-v_y|\succeq0.
\tag{2}
\]

The average on the left is itself canonical: use the single union POVM {M_y/2}∪{N_y/2} and keep the coin in the outcome. So it dominates the quadratic form of the original comparator over the whole operator domain and retains the exact factor. If an inequality is stated as Loewner order, it already forces self-adjointness; the proof also covers the weaker convention that only quadratic-form domination is required.

This is exact for each finite dimension. From an (r)-outcome Holevo representation it gives at most (2r) canonical outcomes. A finite Choi/Carathéodory representation gives a finite POVM in any finite dimension, but no efficient optimizer, acquisition or finite-precision compiler is claimed here. The standard finite Holevo form is prior art; the PSD domination identity (2) is the internal derivation.

## Markov-form representation and the projection boundary

For CP Hilbert--Schmidt-self-adjoint Φ, the symmetrized Kraus family gives Hermitian (H_j) with Φ(A)=ΣH_jAH_j and ΣH_j^2=I. Its Dirichlet form is exactly

\[
 \langle A,(I-\Phi)A\rangle_\tau
 =\frac12\sum_j\|[H_j,A]\|_{2,\tau}^2.
\]

The fixed algebra is the commutant of these Kraus operators. Exact self-compatibility and equality in Kadison--Schwarz put (a\otimes I) and (I\otimes a) in the broadcaster's multiplicative domain for each fixed observable (a); applying multiplicativity to the commuting cross-copy tensors forces any two fixed observables to commute. Thus the fixed algebra is abelian and its trace-preserving expectation is EB.

That expectation alone cannot be the universal comparator. A lazy reversible cycle channel is already EB but has arbitrarily slow nonconstant classical modes, while its fixed algebra is only scalars. Also, no abelian conditional expectation on (M_2) satisfies factor two for the universal qubit cloner, even though its non-idempotent coherent-state EB channel attains equality. A successful construction must preserve slow classical modes and may need a genuinely non-idempotent EB map. The full Markov derivation and exact examples are in [markov_form/MARKOV_FORM_GATE.md](markov_form/MARKOV_FORM_GATE.md).

## What normalized-HS almost-commuting results do and do not provide

The primary literature gives strong dimension-independent **fixed-tuple** results. Bansil--Kachkovskiy prove for two self-adjoint contractions commuting approximants with total normalized-HS error at most (5\|[X,Y]\|_{2,d}^{1/3}); their multi-matrix theorem and corollary retain explicit dependence on family size (N), with a (\sqrt N) factor in the one-versus-(N) step and (C(N)) for all-pair iteration. Glebsky proves that for each fixed (k), sufficiently small normalized-HS commutators imply a commuting (k)-tuple with a dimension-independent modulus δ(ε,k). Neither is uniform as the frame rank grows to (d^2-1), and neither outputs one POVM with the required **channel-energy-weighted all-frame** score.

The earlier channel derivation shows all powers Φ^m(•) have uniformly small pairwise normalized-L2 commutators, while low Dirichlet energy also controls the displacement from these powers. Pairwise estimates alone do not control a shared measurement: for uniformly weighted {X_i,Z_i} on n qubits, mean squared pairwise commutator is (2/n\to0), but every common POVM incurs mean pure-state variance at least (1/2). This frame is not a legal channel counterexample because the channel-energy profile is absent and compatibility forces nonvanishing energy on the conflicting pairs.

The exact missing gate remains a dimension- and frame-size-independent bound for a single common POVM, either the factor-two support inequality (1) or the weaker bounded-Holevo joint-variance modulus from N93. A pointwise or fixed-countable-sequence ultraproduct argument is insufficient: the desired finite comparator must control the supremum over the entire growing operator/test frame at each coordinate. The all-family gate and the random-bin within-block obstruction are retained in [proofs/low_energy_commutator_and_gate.md](../proofs/low_energy_commutator_and_gate.md).

## All-Q moment dual and failed routes

The canonical support is an exact pure-state ensemble moment problem with barycenter (I/d), not an unconstrained pure-state maximum. For compactness of the full canonical-map set use arbitrary density-matrix probability measures with barycenter I/d. Rank-one refinement only shows that positive-dual support and existence of a canonical dominator may be restricted to rank-one maps; the sets are not equal (the one-effect POVM {I} yields the depolarizing map). Its exact LP dual is in [eb_moments/REPORT.md](eb_moments/REPORT.md). A qutrit rank-one example has unconstrained pure-seed maximum 2 but true canonical support 1. This is a warning against replacing POVM ensembles by a single top eigenvector, not a legal channel obstruction. Likewise, the unconstrained star Hamiltonian can have top eigenvalue 4 against support threshold 2 because its top vector is not a valid broadcaster Choi state.

The decisive counterexample format is now exact: give a feasible symmetric broadcaster Choi state with correct reference/output marginals, a positive dual (Q), and a global pure-state moment-dual envelope (Z) whose normalized trace lies below the right side of (1). By (2), that would rule out every EB comparator. No such legal tuple was found. Conversely, a proof of (1) for all (Q\succeq0) yields one canonical EB map by compact-convex separation and hence a full-domain EB factor-two comparator.

## Status and next mathematical gate

- **Internally proved:** canonical-majorant reduction (2); Hermitian-Kraus Dirichlet formula; exact fixed-point abelianness; exact projection-route obstructions; canonical POVM moment primal/dual and common-map separation.
- **External prior:** fixed-pair normalized-HS almost-commuting estimates and fixed-size tuple results; standard finite-dimensional Holevo form for EB channels.
- **Unknown:** universal all-(Q) mixed support inequality; dimension-free bounded-Holevo-to-EB reconstruction under only the supplied broadcaster interface.
- **Not claimed:** external proof validation, novelty priority, polynomial construction, or a qualifying counterexample.

Next attack should work on the marginal-constrained moment inequality itself or identify a structural consequence of self-compatibility that yields one POVM's covariance ellipsoid. Pairwise commutator improvement, a better tree compiler, fixed-algebra projection, or unconstrained star eigenvalues do not pass this gate.

## Files and provenance

- New exact reduction: [CANONICAL_DOMINATION.md](CANONICAL_DOMINATION.md).
- Canonical moment cone, dual, qutrit and star route obstructions: [eb_moments/REPORT.md](eb_moments/REPORT.md), with [claims](eb_moments/CLAIMS.json).
- Markov, fixed algebra, and projection obstructions: [markov_form/REPORT.md](markov_form/REPORT.md), [gate details](markov_form/MARKOV_FORM_GATE.md), [claims](markov_form/CLAIMS.json), and [source notes](markov_form/SOURCE_NOTES.md).
- Prior exact channel commutator and uniform-range gate: [low_energy_commutator_and_gate.md](../proofs/low_energy_commutator_and_gate.md), [earlier claims](../CLAIMS.json), and [primary source notes](../sources/primary_sources.md).
- Channel/classicality target and open gates: [N93 bounded-Holevo card](../../quantum_physics/sources/N93-bounded-holevo-gates.txt) and [detailed-balance source reconstruction](../../broadcast_channel_attack/sources/detailed_balance_broadcast_attack.txt).
