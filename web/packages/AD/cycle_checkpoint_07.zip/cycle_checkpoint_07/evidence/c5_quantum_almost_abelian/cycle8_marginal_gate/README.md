# Cycle 8: marginal-feasible all-Q gate

## Current target

For every finite dimension and every supplied unital, trace-preserving, CPTP, Hilbert--Schmidt-self-adjoint, self-compatible channel `Phi`, decide/prove the full-Hermitian-domain factor-two statement

`exists one canonical POVM/prepare EB map Gamma: Gamma >= 2 Phi - I`.

By the corrected full-domain reduction in `../cycle7_all_Q/CANONICAL_DOMINATION.md`, this is equivalent to the all-positive-dual support gate. The unrestricted-EB reduction uses identity slack and is **not** licensed from an H0-only premise. The full canonical-map compactness argument uses probability measures on density matrices with barycenter `I/d`; rank-one refinement PSD-dominates, but does not equal, the full map set.

For `Q >= 0` on traceless Hermitians, write

`S_d(Q) = max_{mu: integral rho dmu=I/d} integral sum_i w_i (Tr(rho A_i))^2 dmu(rho)`,

with `Q=sum_i w_i |A_i><A_i|` and `tau(A_i^2)=1`. A symmetric broadcaster Choi state `Omega_RAB` provides `2 Tr_HS(Q Phi) = Tr(Omega H_Q)` for the star observable `H_Q=sum_i w_i A_i^T tensor (A_i tensor I + I tensor A_i)`, subject to the exact reference/output marginals and swap symmetry. The surviving gate is

`Tr(Omega H_Q) - Tr_HS(Q) <= S_d(Q)`

for every legal `Omega,Q`, or an exact violating tuple with a global pure-state dual envelope.

## Parallel work

- `legal_sdp/`: legal finite-dimensional `d=3,4` broadcaster/moment-cone search; all Choi marginals enforced, no unconstrained star relaxation.
- `markov_proof/`: independent operator-system / conditional-expectation / Dirichlet-form attempt at a universal proof or a stronger theorem.

These are route-diverse attempts. Their results remain internal until audited; finite numerics do not establish the all-dimension statement.
