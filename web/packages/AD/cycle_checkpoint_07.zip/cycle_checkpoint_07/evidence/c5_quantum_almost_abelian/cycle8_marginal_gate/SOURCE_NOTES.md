# Cycle 8 source and provenance notes

Date: 2026-10-08. This is a scoped proof/prior audit, not an exhaustive literature review. The universal all-Q claim remains open in this work package; no novelty or priority claim is made.

## Almost-commuting normalized-HS results

- Bansil and Kachkovskiy, [*On almost commuting matrices with respect to the normalized Hilbert--Schmidt norm*, arXiv:2608.31000v1](https://arxiv.org/abs/2608.31000), Theorems 1.1 and 1.3 and Corollary 1.4. Their pair theorem has a dimension-free modulus. The many-observable estimates retain explicit tuple-size dependence (including a \(\sqrt N\) term and an all-N modulus whose exponent deteriorates with N). This does not furnish a modulus uniform for a channel image with up to \(d^2-1\) directions.
- Glebsky, [*Almost commuting matrices with respect to normalized Hilbert--Schmidt norm*, arXiv:1002.3082](https://arxiv.org/abs/1002.3082), Theorem 4. It gives stability for each fixed finite self-adjoint tuple size; the recursively defined modulus depends on that size.
- Houdayer and Ioana, [tracial-ultraproduct lifting result, arXiv:2309.15029](https://arxiv.org/abs/2309.15029), Theorem 5.1. The stated lifting concerns separable abelian subalgebras in a 2-independent pair. It is not a uniform finite-coordinate measurement for a growing, potentially nonseparable channel range.

These are positive fixed-family results. Their stated scopes neither prove nor disprove a stronger uniform-range theorem tailored to channels. The missing step is explicitly a quantitative finite reconstruction controlling the *whole* relevant range or every whole weighted frame with one POVM.

## Quantum channel / EB representation sources

- Horodecki, Shor, and Ruskai, [*Entanglement Breaking Channels*, arXiv:quant-ph/0302031](https://arxiv.org/abs/quant-ph/0302031). Standard Holevo measure-and-prepare and separable-Choi representations are used in the C7 full-domain canonical reduction. The present PSD Gram identity and identity-slack unitalization are internally derived; this source is not cited as proving those order steps.
- Haapasalo, [*Compatibility of covariant quantum channels with emphasis on Weyl symmetry*, arXiv:1901.06113](https://arxiv.org/abs/1901.06113), finite-phase-space Corollary 2 and Eq. (22). Supplies the Weyl-channel compatibility-kernel criterion used by the already-known exact d=5 compatible channel. It does not establish the EB domination target.
- Chen, Ji, Kribs, Lütkenhaus, and Zeng, [*Symmetric extension of two-qubit states*, arXiv:1310.3530](https://arxiv.org/abs/1310.3530). Context for symmetric-extension tests. No solver relaxation of their state criteria is treated here as an all-EB theorem.
- Keyl and Werner, [*Optimal cloning of pure states, judging single clones*, arXiv:quant-ph/9807010](https://arxiv.org/abs/quant-ph/9807010). Source context for the universal cloner and the four-MUB depolarizing comparator boundary; the current qutrit inequalities are checked directly.

## Internal proof inputs and route boundaries

- `work/ROOT_MANDATE.txt`, `work/astra_prior/00_START_HERE.txt`, and `work/astra_prior/01_CORE.txt`: task interface, claim discipline, N93 context, and branch scope.
- `work/agents/quantum_physics/sources/N93-bounded-holevo-gates.txt`: the original bounded-Holevo question, reductions, and explicit status of the one-common-EB reconstruction gate.
- `work/agents/broadcast_channel_attack/sources/detailed_balance_broadcast_attack.txt`: dimension-free broadcaster-tree commutator estimate and established CP/Petz subroutes; these are internal reconstructions, not external primary literature.
- `work/agents/c5_quantum_almost_abelian/proofs/low_energy_commutator_and_gate.md` and `sources/primary_sources.md`: low-energy commutator estimates, random-bin pinching limit, and the exact missing uniform-range step.
- `work/agents/c4_quantum_lift/WEIGHTED_TREE.md` and `FINAL_REPORT.md`: existing logarithmic frame/rank comparator and weighted commuting-cover dependency. Cycle 8 makes no improvement to that theorem.
- `work/agents/c5_quantum_almost_abelian/cycle7_all_Q/CANONICAL_DOMINATION.md`, `eb_moments/REPORT.md`, and `work/agents/c7_canonical_reduction_audit/REPORT.md`: exact full-Hermitian-domain EB-to-canonical reduction and the correction that general canonical maps require density-matrix measures for compactness; rank-one refinement is PSD domination, not equality.
- `cycle8_marginal_gate/markov_proof/PROOF_AND_GATE.md`: exact qubit obstruction to representing every admissible marginal as a bistochastic CP square. This excludes one proof route only.
- `cycle8_marginal_gate/legal_sdp/CUBIC_PHASE_CONTROL.md`: exact qutrit Choi construction and the common MUB EB comparator for the squared channel.
- `work/agents/quantum_physics/proofs/weyl_line_comparator.md` and `work/agents/quantum_physics/broadcast_lift/D5_AUDIT.md`: prior prime-d line-constant result and the known exact d=5 non-line-constant safe channel. The new d=3 Weyl subset derivation is not counted as new; the d=5 star scan is only a failed shortcut test.
- `cycle8_marginal_gate/legal_sdp/STAR_TWIRL_VERIFICATION.md`: internal odd-prime Weyl/parity/output-swap star-twirl proof. It gives exact marginal feasibility and HS self-adjointness but explicitly does not infer HS positivity; the d=5 residual/gap certificate is an additional scoped check.
- `cycle8_marginal_gate/legal_sdp/D5_NONUNIFORM_WEIGHT_CONTROL.md`: exact full-support d=5 dual with scalar pure-state envelope (Z=3I), a matching Weyl-orbit 1-design, and exact star spectrum. This is a safe single-Q support test, not a universal theorem.

## Verification boundary

`legal_sdp/cubic_phase_exact_check.py` uses exact SymPy algebra to verify the Choi marginals, real transfer matrix, spectra, and strict comparator gap. `nonline_modes/d5_selected_charpoly.py` and `legal_sdp/d5_nonuniform_weight_exact.py` use exact algebraic entries to verify their respective 25-dimensional star-block characteristic polynomials. `legal_sdp/d5_twirl_top_positivity_certificate.py` uses rational intervals, a residual/gap eigenvector bound, and norm-one Choi correlations to certify positive transfer coefficients for one exact top-twirled d=5 star maximizer. `d5_mode_subset_scan.py` and `legal_sdp/pauli_search.py` use floating-point optimization/search and remain diagnostics. No external proof review, formal kernel proof, or full-dimensional SDP certificate was obtained.
