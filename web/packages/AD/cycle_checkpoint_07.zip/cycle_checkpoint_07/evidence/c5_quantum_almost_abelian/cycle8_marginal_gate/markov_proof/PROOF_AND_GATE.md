# Cycle 8 Markov-form result: a CP-square obstruction and the surviving gate

## Exact theorem interface

For each finite (d\ge2), let \(\Phi:M_d\to M_d\) be CPTP in the Schrödinger/Heisenberg-adjoint convention, unital, trace-preserving, Hilbert--Schmidt self-adjoint and positive on the real Hilbert space of Hermitian matrices. Assume a supplied CPTP map \(\mathcal B:M_d\to M_d\otimes M_d\) has both marginals equal to \(\Phi\). Put \(\tau=\operatorname{Tr}/d\), \(\langle A,B\rangle_\tau=\tau(AB)\), and \(\mathcal H_0=\{A=A^*: \tau(A)=0\}\).

The universal target is: for every such \((d,\Phi,\mathcal B)\), there exists one finite POVM \(M=(M_y)_y\), allowed to depend on the supplied channel and broadcaster but not on a test observable or frame, such that its canonical channel

\[
 \Psi_M(A)=\sum_{y:\,\tau(M_y)>0}
       \frac{\tau(M_yA)}{\tau(M_y)}M_y
\]

satisfies \(I-\Psi_M\preceq2(I-\Phi)\) on the *entire* Hermitian space. This is equivalent to \(\Psi_M\succeq2\Phi-I\). The available C7 canonical-majorant lemma makes this target equivalent, under these full-domain hypotheses, to allowing any trace-preserving EB comparator.

For a positive Hilbert--Schmidt operator \(Q\succeq0\) on \(\mathcal H_0\), existence of one common comparator is equivalent by finite-dimensional convex separation to the all-positive-dual support gate

\[
 \sup_{M\ \mathrm{POVM}}\operatorname{Tr}_{HS}(Q\Psi_M)
 \ \ge\ \operatorname{Tr}_{HS}\bigl(Q(2\Phi-I)\bigr)
 \qquad\text{for every }Q\succeq0.
 \tag{G}
\]

Writing \(Q=\sum_i w_i|A_i\rangle\langle A_i|\), with \(w_i\ge0\), makes the frame quantifier explicit: for each *whole finite weighted frame* there must be one POVM selected after seeing the frame, and it must control the sum

\[
 \sum_y\frac{\sum_i w_i\,\tau(M_yA_i)^2}{\tau(M_y)}
 \ \ge\ \sum_iw_i\bigl(2\langle A_i,\Phi A_i\rangle_\tau-\|A_i\|_{2,\tau}^2\bigr).
 \tag{G-frame}
\]

The pointwise choice of \(M\) may depend on \(Q\) in (G-frame). Only after (G) is proved for every \(Q\) does compact convex separation give a single \(M\) that works for every Hermitian input simultaneously. This distinction is essential; independent measurements for individual \(A_i\) or individual \(Q\)'s do not prove the target.

## Markov form and why a CP square is a stronger claim

Self-adjoint complete positivity gives Hermitian Kraus operators \(H_j\) with

\[
 \Phi(A)=\sum_jH_jAH_j,\qquad \sum_jH_j^2=I,
 \qquad \langle A,(I-\Phi)A\rangle_\tau
 =\frac12\sum_j\|[H_j,A]\|_{2,\tau}^2.
 \tag{D}
\]

Thus the target becomes the covariance/measurement inequality

\[
 \sup_M\sum_y\frac{\sum_iw_i\tau(M_yA_i)^2}{\tau(M_y)}
 \ \ge\ \sum_iw_i\left(\|A_i\|_{2,\tau}^2-
              \sum_j\|[H_j,A_i]\|_{2,\tau}^2\right).
 \tag{D-G}
\]

The RHS retains each slow mode through its actual Dirichlet energy. An inverse-gap or fixed-point projection argument cannot replace it uniformly, and pairwise commutator smallness alone does not supply the one-POVM quantifier; those boundaries are established in the C7/C5 notes linked below. The Cycle 8 result here attacks a different sufficient route: the N92 instrument identity.

That identity takes a bistochastic instrument \(L(A)=\sum_yK_yAK_y^*\), effects \(M_y=K_y^*K_y\), and \(\Psi_M\), then sets \(C=(L+\Psi_M)/2\), \(\Phi=C^*C\). It proves

\[
 2(I-\Phi)-(I-\Psi_M)
 =(I-L^*L)+(\Psi_M-\Psi_M^2)
       +\tfrac12(L-\Psi_M)^*(L-\Psi_M)\succeq0.
 \tag{N92}
\]

The crucial representation demand is stronger than (G): the supplied marginal must be a Hilbert--Schmidt CP square \(C^*C\), with \(C\) bistochastic. The next exact fixture shows this representation is not available for every admissible channel, even when (G) is trivial with equality at a canonical EB map.

## Exact qubit obstruction to every bistochastic CP-square representation

Fix any \(0<\varepsilon<1\). On \(M_2\), let \(X,Y,Z\) be Pauli matrices and \(P_{a,\pm}=(I\pm a)/2\) for \(a\in\{X,Z\}\). Define four effects

\[
 M_{x,\pm}=\varepsilon P_{x,\pm},\qquad
 M_{z,\pm}=(1-\varepsilon)P_{z,\pm}.
 \tag{1}
\]

They sum to \(I\). Their canonical map is

\[
 \Phi_\varepsilon(a_0I+a_xX+a_yY+a_zZ)
 =a_0I+\varepsilon a_xX+(1-\varepsilon)a_zZ,
 \qquad T_{\Phi_\varepsilon}=\operatorname{diag}(\varepsilon,0,1-\varepsilon).
 \tag{2}
\]

This is directly a canonical EB channel. Its Schrödinger dual measures the POVM (1) and prepares the corresponding \(P_{a,\pm}\). A supplied symmetric broadcaster is

\[
 \mathcal B_*(\rho)=\sum_{a\in\{x,z\},s\in\{\pm\}}
            \operatorname{Tr}(M_{a,s}\rho)\,P_{a,s}\otimes P_{a,s};
 \tag{3}
\]

it is CPTP and each marginal is \(\Phi_{\varepsilon,*}\). The Heisenberg map is unital and trace-preserving, self-adjoint, and positive as an HS operator, since its transfer eigenvalues are \(1,\varepsilon,0,1-\varepsilon\). It also has Hermitian Kraus operators

\[
 H_I=I/\sqrt2,\qquad H_X=\sqrt{\varepsilon/2}\,X,
 \qquad H_Z=\sqrt{(1-\varepsilon)/2}\,Z,
\]

which satisfy (D). The supplied assumptions are therefore all met. Moreover \(\Psi_M=\Phi_\varepsilon\) itself, so \(I-\Psi_M\preceq2(I-\Phi_\varepsilon)\) holds with the stronger constant \(1\).

Nevertheless, there is no bistochastic CP map \(C:M_2\to M_2\) such that

\[
 \Phi_\varepsilon=C^*C,
 \tag{4}
\]

where \(C^*\) is the HS adjoint. To prove this, suppose such \(C\) exists. Since \(C\) is unital and trace-preserving, its restriction to traceless Hermitian matrices is a real matrix \(T\), and the restriction of \(C^*C\) is \(T^TT\). Thus the singular values of \(T\) must be

\[
 \sqrt{1-\varepsilon},\quad \sqrt{\varepsilon},\quad 0.
 \tag{5}
\]

The real signed singular-value decomposition gives \(T=R_1DR_2\), where \(R_1,R_2\in SO(3)\) and \(D\) is diagonal with entries equal in absolute value to the singular values. One way to see the orientation point is to start from ordinary \(O(3)\) SVD, multiply the orthogonal factors by diagonal sign matrices to make both determinants \(+1\), and absorb those signs into \(D\); the zero singular direction permits either sign. The rotations are implemented by qubit unitary conjugations. Consequently pre- and post-unitary conjugation of \(C\) preserves complete positivity and bistochasticity and yields a unital qubit channel with diagonal Bloch transfer \(\operatorname{diag}(\lambda_1,\lambda_2,\lambda_3)\), where \(|\lambda_1|,|\lambda_2|,|\lambda_3|\) are (5). Put the zero singular value in the third slot. The four Bell-basis Choi eigenvalues, up to order, are

\[
 \tfrac14(1+\lambda_1+\lambda_2+\lambda_3),\quad
 \tfrac14(1+\lambda_1-\lambda_2-\lambda_3),\quad
 \tfrac14(1-\lambda_1+\lambda_2-\lambda_3),\quad
 \tfrac14(1-\lambda_1-\lambda_2+\lambda_3).
\]

Their nonnegativity is equivalent to the familiar pair of inequalities for this diagonal unital qubit channel:

\[
 1+\lambda_3\ge|\lambda_1+\lambda_2|,
 \qquad 1-\lambda_3\ge|\lambda_1-\lambda_2|.
 \tag{6}
\]

At \(\lambda_3=0\), these imply

\[
 |\lambda_1|+|\lambda_2|
 =\max\{|\lambda_1+\lambda_2|,|\lambda_1-\lambda_2|\}
 \le1.
\]

But (5) gives \(\sqrt{1-\varepsilon}+\sqrt{\varepsilon}>1\), a contradiction. This proves the nonexistence for every \(0<\varepsilon<1\). No numerical optimization or approximate test is involved.

## Consequence and precise unresolved lemma

The qubit family (1)--(3) refutes the representation assertion

> Every unital, trace-preserving, self-adjoint, positive, self-compatible finite-dimensional CP map is \(C^*C\) for a bistochastic CP map \(C\).

It therefore rules out universality of the N92 factorization route, including variants that choose a different bistochastic instrument before taking its canonical average. It does **not** refute the factor-two EB comparison: these channels already have a canonical comparator with constant one. It also does not exclude a more general conditional-expectation, operator-system, noncommutative Grothendieck, or Petz construction that does not force a bistochastic CP square.

The decisive remaining lemma for the target is exactly (G), equivalently (D-G), with the following quantifiers: for every finite \(d\), every supplied \((\Phi,\mathcal B)\) satisfying the interface above, and every positive HS test operator \(Q\) (equivalently every finite positive weighted Hermitian frame), prove the displayed support bound by optimizing over one POVM common to the entire test frame. Compact convex separation must then yield one POVM independent of all \(Q\)'s. Alternatively, an exact refutation requires one admissible \((d,\Phi,\mathcal B,Q)\) with a rigorous *global* moment envelope proving strict failure of (G); the square-root obstruction is not such a witness.

This subtask supplies an exact obstruction to one sufficient representation, not a stronger-than-logarithmic universal bound. The unrestricted target remains UNKNOWN on this route.

## Evidence, costs, and status

Everything above is finite-dimensional and exact. The Pauli channel, POVM, broadcaster, transfer spectrum, Hermitian Kraus family, and nonexistence proof are explicit; no solver or finite-precision computation is used. There is no channel-acquisition or algorithmic-efficiency claim. The research result is an internally derived exact route obstruction, not an externally validated theorem about the unrestricted EB comparison and not a novelty/priority claim.

Relevant exact prior arguments are in `../../cycle7_all_Q/CANONICAL_DOMINATION.md` (full-EB to canonical reduction and all-Q equivalence), `../../cycle7_all_Q/markov_form/MARKOV_FORM_GATE.md` (Hermitian-Kraus Dirichlet form and fixed-algebra facts), `../../proofs/low_energy_commutator_and_gate.md` (common-frame gate boundary), `../../cycle7_all_Q/eb_moments/REPORT.md` (marginal-feasible all-Q formulation), and `../../../broadcast_information_attack/d-48ed31af9b1d38fd.txt` (N92 identity and explicit representation gap).
