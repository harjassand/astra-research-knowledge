# Exact full-support nonuniform d=5 CP-extension control

## Result

This is a second, genuinely different Weyl-invariant dual from the six-mode subset in [D5_MARGINAL_GATE.md](D5_MARGINAL_GATE.md). It has full support and nonconstant weights across all 12 real Weyl mode-pairs. Its canonical-POVM support is exactly 3, and an exact legal self-compatible unital channel extension attains star value r in (15,16). Since Tr_HS(Q)=13, the factor-two target is r-13 in (2,3). This test is safe; it is not a counterexample. The channel is CP, TP, unital, and parity-symmetric, so its Weyl transfer coefficients are real. Their signs were not certified; this is only a support-safe CP-extension test if the target class additionally requires Hilbert--Schmidt positivity.

## Dual and exact moment support

Let P_(1,0) denote the Hilbert--Schmidt projector onto the two real Weyl observables A_(1,0), B_(1,0), and let I_H0 be the identity on the 24-dimensional traceless Hermitian space. Define

    Q = (1/2) I_H0 + (1/2) P_(1,0).

Thus the pair (1,0) has weight 1 and each of the other 11 Weyl pairs has weight 1/2; Tr_HS(Q)=12+1=13. This is Weyl-invariant and non-line-constant.

For any pure projector P, Parseval on the traceless Hermitian space gives f_I_H0(P)=4. For the one-pair projector,

    f_P_(1,0)(P) = 2 |Tr(P W_(1,0))|² ≤ 2,

with equality at any eigenprojector of W_(1,0)=X. Hence f_Q(P)=(1/2)f_I_H0(P)+(1/2)f_P_(1,0)(P)≤3. The scalar Z=3I_5 is an exact moment-dual certificate: Tr(ZP)=3≥f_Q(P) for every pure P, and τ(Z)=3. An X-eigenprojector and its 25-element Weyl orbit form a rank-one POVM 1-design, with score 3 throughout the orbit. Therefore

    S_5(Q) = 3.

This is a global quartic envelope, not a grid or numerical fit.

## Exact star spectrum

Use the same Weyl convention as D5_MARGINAL_GATE.md, W_(a,b)=ω^(3ab)X^aZ^b, and build H_Q by assigning weight 1 to pair (1,0) and weight 1/2 to each other Weyl pair. Its exact charge-block computation is in [d5_nonuniform_weight_exact.py](d5_nonuniform_weight_exact.py). The operator commutes with U_(0,1)=conjugate(Z)⊗Z⊗Z and U_(1,0)=conjugate(X)⊗X⊗X; the first decomposes the space into five 25-dimensional charges and the second cycles them, so their block characteristic polynomials agree. Exact arithmetic in Q(ζ_5) gives

    p_25(x) = (x+3/2)^8 ×
      (x+(1+√5)/4)^2 ×
      (x-7+9(1+√5)/4) ×
      (x-(19+9√5)/4) ×
      (x+(1-√5)/4)^2 ×
      (x+(3+√5)/2)^4 ×
      (x+(3-√5)/2)^4 ×
      (x^3-(31/2)x^2+(17/4)x+4).

The full 125-by-125 characteristic polynomial is p_25(x)^5. The cubic p(x)=x^3-(31/2)x^2+(17/4)x+4 has p(15)=-179/4, p(16)=200, and p'(15)=857/4>0. Also p''(x)=6x-31>0 for x≥15. Its unique root r in (15,16) is the largest root of the full polynomial; every other factor has all roots below 10. Thus

    λmax(H_Q)=r in (15,16),
    λmax(H_Q)-Tr_HS(Q)=r-13 in (2,3).

For every legal symmetric extension with this target normalization, Tr(Ω H_Q)=2 Tr_HS(Q Φ)≤r. Therefore every CP-compatible channel obeys

    2 Tr_HS(Q Φ)-Tr_HS(Q) ≤ r-13 < 3 = S_5(Q).

This extension-independent support-safety bound does not depend on the transfer-coefficient signs of the top-projector channel below.

## Exact legal extension and marginal checks

Here the unconstrained star maximum can be made legal because Q is Weyl-invariant. The Hamiltonian commutes with U_h=conjugate(W_h)⊗W_h⊗W_h, global parity P⊗P⊗P, and output swap S_AB, where P|j⟩=|-j⟩. The root r occurs once in each of the five charge blocks, so its spectral projector Π_r has rank 5 and inherits these symmetries. Define the normalized Choi state

    Ω_RAB = Π_r/5.

Then Ω is positive and Tr(Ω)=1. Output swap invariance gives equal RA and RB Choi marginals. Weyl invariance and irreducibility imply

    Tr_AB(Ω) = I_R/5,
    Tr_RB(Ω) = Tr_RA(Ω) = I/5.

The first equality is the trace-preserving Choi marginal; the latter two also give unital output marginals. Hence Ω is an exact symmetric extension of a bistochastic channel Φ. Global parity maps Weyl label m to -m, so the Bell weights of the marginal channel satisfy q_m=q_-m and its Weyl multipliers are real. Their signs are not certified here, so no Hilbert--Schmidt-positivity claim is made. Finally,

    Tr(Ω H_Q)=r=2 Tr_HS(Q Φ),

so this legal channel's target is exactly r-13<3=S_5(Q). The extension formula is an exact algebraic spectral-projector construction; the scalar and charge-block checks are reproducible from the 25-dimensional block script.

## Boundary

This supplies a certified upper envelope and an exact legal CP extension for one nonuniform full-support d=5 Weyl weight vector, and proves that this vector passes the support gate even over the larger CP-compatible class. The available d5_twirl_top_positivity_certificate.py concerns a different six-mode Q and was not reused; this report does not certify that the present marginal channel belongs to the HS-positive subclass. It also does not prove the gate for every Weyl-invariant weight vector or close the universal problem. The earlier 64-start optimizer and its conjectured (13+√5)/4 value belong to the separate six-mode projector in D5_MARGINAL_GATE.md; they are unrelated diagnostics and are not used here.
