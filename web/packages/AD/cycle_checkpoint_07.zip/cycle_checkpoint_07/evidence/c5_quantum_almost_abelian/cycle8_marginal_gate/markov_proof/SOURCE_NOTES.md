# Cycle 8 Markov-form source notes

Date: 2026-10-08. The ROOT mandate, Astra retrieval/workflow notes, C4 weighted-tree proof, C5 low-energy commutator gate and cloner sharpness proof, C7 canonical-domination lemma, and the N92/N93 source extraction were read selectively before writing this note. Source-based status remains separate from the exact local derivation.

## Source and retrieval boundaries

- `outputs/research/cycle_checkpoint_03/ROOT_MANDATE.txt` supplies the exact-status, costs, proof-path, and all-family accounting rules. `work/astra_prior/00_START_HERE.txt`, `01_CORE.txt`, and `RESEARCH_WORKFLOW.txt` supplied the retrieval and proof-record workflow. The broad Astra core is background only and is not used as a theorem premise.
- `outputs/research/cycle_checkpoint_03/evidence/c4_quantum_lift/WEIGHTED_TREE.md`, lines 21--57 and 84--103 (SHA-256 `02d3eea6507b6c5d8d10f4872bf75753c6d9cbc84ca33b20bc128bd8a8594f64`), gives the exact common-POVM support method and its logarithmic frame-rank/depth cost. It is used as a boundary, not as a premise in the qubit obstruction.
- `work/agents/c5_quantum_almost_abelian/proofs/low_energy_commutator_and_gate.md`, lines 7--44 and 117--161 (SHA-256 `3647ae0a132a25020425c5a73e85a1467ec1a49a789c2f962723939de5dc4f64`), records the low-Dirichlet almost-commutation estimates and explains why they do not imply a one-POVM all-frame bound. No pairwise-commutator shortcut is used here.
- `work/agents/c5_quantum_almost_abelian/cycle7_all_Q/CANONICAL_DOMINATION.md`, lines 5--15 and 94--107 (SHA-256 `f90afd31c87c9096b1d9c3335524692e6e1fa606e020ee0e049e55fa77efec90`), proves the exact full-Hermitian-domain reduction from any TP EB comparator to one canonical POVM comparator and states the all-Q separation gate.
- `work/agents/c5_quantum_almost_abelian/cycle7_all_Q/markov_form/MARKOV_FORM_GATE.md`, lines 16--65 and 157--177, proves the Hermitian-Kraus Dirichlet representation and exact fixed-algebra result; it also records the scope of the N92 factorization route. The present qubit fixture is an additional exact obstruction to that route.
- `work/agents/broadcast_information_attack/d-48ed31af9b1d38fd.txt`, lines 267--320 (SHA-256 `c4ee85455f441e5c3ce44ba8bbf4fd329f3fed1f53c33ad5c8cc0d5e2e44d9de`), contains the N92 identity, its bistochastic instrument interface, and the explicit absence of a general representation theorem. The square-root obstruction here is derived directly and does not rely on the source claim of a gap.
- `work/agents/c5_quantum_almost_abelian/cycle8_marginal_gate/README.md` states the marginal-feasible all-Q task and separates the legal SDP search from this functional-analytic route.

## Direct derivation and literature boundary

The Pauli POVM, broadcaster, Kraus operators, transfer spectrum, and CP-square contradiction are calculated explicitly in `PROOF_AND_GATE.md`; no imported theorem about the universal comparison is used. The only structural fact in the contradiction is that qubit unitary conjugations implement rotations in (SO(3)), which follows directly from the Pauli commutation relations. The diagonal-channel Choi inequalities are computed from its four Bell-basis Choi eigenvalues.

The C7 canonical-domination note cites the standard finite Holevo/EB representation in Horodecki--Shor--Ruskai, *General Entanglement Breaking Channels*, [arXiv:quant-ph/0302031](https://arxiv.org/abs/quant-ph/0302031). That source supports the prior canonical-reduction context, not the new CP-square obstruction. No external novelty search or independent proof review was performed.

## Costs and falsification boundary

All data are exact and two-dimensional. No software solver, approximation, acquisition protocol, or runtime assumption is involved. The route obstruction can be falsified by finding a bistochastic CP square root for the displayed transfer matrix or locating an error in the signed SVD/Choi argument. A target counterexample needs additional data: an admissible broadcaster and a strict, rigorous violation of the all-Q support gate. The present example has a canonical EB comparator and cannot serve as such a counterexample.
