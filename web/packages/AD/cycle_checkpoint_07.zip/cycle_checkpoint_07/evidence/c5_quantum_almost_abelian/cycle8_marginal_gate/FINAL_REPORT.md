# Cycle 8: marginal-feasible all-Q gate

## Verdict

The universal dimension-free factor-two EB comparison remains **UNKNOWN**. This cycle produced neither a proof for every finite-dimensional admissible channel nor a legal full-EB counterexample. It did correct the compactness/domain boundary in the canonical reduction, eliminate a universal CP-square proof route, and add an exact non-Weyl qutrit control. A d=5 exact spectral certificate also shows that one tempting MUB-line proof shortcut fails; it does not violate the actual support inequality.

The exact target is: for every finite $d$, every supplied unital, trace-preserving, CPTP, Hilbert--Schmidt-self-adjoint and Hilbert--Schmidt-positive channel $\Phi:M_d\to M_d$, and every supplied symmetric CPTP broadcaster $\mathcal B:M_d\to M_d\otimes M_d$ with both marginals $\Phi$, find one finite POVM $M$ (allowed to depend on the supplied pair, but not on an input or a test frame) whose canonical map obeys

\[
  \Psi_M\succeq2\Phi-I
\quad\text{on the entire real Hermitian space.}
\tag{T}
\]

Equivalently, $I-\Psi_M\preceq2(I-\Phi)$. All dimensions and all positive Hilbert--Schmidt duals $Q$ are quantified; a finite frame test, a $Q$-dependent family of different measurements, or an unconstrained Choi-star eigenvalue does not settle (T).

## Exact support gate and compactness repair

Write $\tau=\operatorname{Tr}/d$, let $Q\succeq0$ act on traceless Hermitians, and choose $Q=\sum_iw_i|A_i\rangle\langle A_i|$ with $w_i\ge0$, $\tau(A_i^2)=1$. For a probability measure $\mu$ on density matrices with barycenter $I/d$, the canonical map is

\[
  \Psi_\mu(X)=d\int\operatorname{Tr}(\rho X)\rho\,d\mu(\rho).
\]

Consequently the canonical POVM support is

\[
 S_d(Q)=\max_{\substack{\mu\in\mathcal P(\mathcal D_d)\\
                      \int\rho\,d\mu=I/d}}
      \int\sum_iw_i(\operatorname{Tr}(\rho A_i))^2\,d\mu(\rho).
\tag{1}
\]

There is **no extra factor $d$** in (1): the $d$ in $\Psi_\mu$ cancels against normalized-trace HS pairing. Rank-one refinement PSD-dominates a canonical map and therefore suffices for the support and domination questions, but arbitrary canonical maps are not all rank-one POVM maps. The one-effect POVM \(\{I\}\) gives the depolarizing canonical map. Compactness of the full set is instead obtained from probability measures on the compact density-matrix space with barycenter $I/d$; the continuous second-moment image is compact, and finite-dimensional Carathéodory applied to joint barycenter/moment coordinates extracts finite support.

The full-Hermitian-domain reduction from arbitrary trace-preserving EB comparators to canonical POVM maps also passes, with its domain condition: since $K=2\Phi-I$ satisfies $K(I)=I$, a full-domain positive slack tested at $I$ forces an EB comparator to be unital. Its Holevo form then gives two POVMs, whose union canonical map PSD-dominates the symmetrized comparator. This argument does not follow from an $H_0$-only premise. Under the full-domain target, compact convex separation makes (T) equivalent to one support inequality for every $Q\succeq0$:

\[
 S_d(Q)\ge 2\operatorname{Tr}_{HS}(Q\Phi)
                   -\operatorname{Tr}_{HS}(Q).
\tag{2}
\]

With a normalized symmetric extension state $\Omega_{RAB}$, put

\[
 H_Q=\sum_iw_i A_i^T\otimes(A_i\otimes I+I\otimes A_i).
\]

The exact marginal identity is \(\operatorname{Tr}(\Omega H_Q)=2\operatorname{Tr}_{HS}(Q\Phi)\), and \(\operatorname{Tr}_{HS}Q=\sum_iw_i\). Thus the surviving marginal-feasible gate is

\[
 \operatorname{Tr}(\Omega H_Q)-\operatorname{Tr}_{HS}Q\ \le\ S_d(Q)
 \quad\text{for every legal }(d,\Phi,\mathcal B,Q).
\tag{G}
\]

The full support includes the barycenter constraint. The unconstrained maximum over one pure state is generally not a valid replacement, and the top eigenvalue of $H_Q$ is not a valid replacement for optimizing over Choi states with the broadcaster marginals.

## Cycle results

**The CP-square route is not universal.** The Markov-form branch gives an exact family of qubit channels that are already canonical EB and satisfy the comparison with constant one, but cannot be written $C^*C$ for any bistochastic CP map $C$. This blocks the universal N92 instrument-square/Petz representation as a proof of (T); it is neither an all-EB counterexample nor a stronger factor-two theorem. See [`markov_proof/PROOF_AND_GATE.md`](markov_proof/PROOF_AND_GATE.md).

**An exact legal qutrit control passes the all-Q test.** A permutation-symmetric cubic-phase three-qutrit state supplies a marginal channel \(\Phi\) with real transfer spectrum \(\{\pm(3+\sqrt3)/6,\pm(3-\sqrt3)/6,0^{(4)}\}\). Although \(\Phi\) itself is not HS-positive, \(\Phi^2\) is. Applying \(\Phi\) locally to both outputs of the supplied extension gives a legal broadcaster for \(\Phi^2\). Its top transfer eigenvalue is \((2+\sqrt3)/6\). The 12-outcome POVM formed by equally mixing the four qutrit Weyl MUB PVMs has canonical EB map $I/4$ on the traceless space and satisfies

\[
 \frac14-(2\lambda_{\max}(\Phi^2)-1)
 =\frac{7-4\sqrt3}{12}>0
\]

with the strict comparison reducing to $49>48$. This is one full-domain comparator for the whole qutrit example, not just rank-one $Q$'s. The exact construction/check is in [`legal_sdp/CUBIC_PHASE_CONTROL.md`](legal_sdp/CUBIC_PHASE_CONTROL.md) and [`legal_sdp/cubic_phase_exact_check.py`](legal_sdp/cubic_phase_exact_check.py). This is a scoped control, not a result for every qutrit broadcaster.

**A d=5 line-only star envelope fails exactly.** For six selected real Weyl mode pairs, one from each of the six projective lines, the dual has \(\operatorname{Tr}_{HS}Q=12\). A 25-dimensional principal compression of its Hermitian star operator has an exact characteristic polynomial with value

\[
 -1{,}142{,}640{,}210{,}879{,}492{,}187{,}500{,}000{,}000
 -386{,}433{,}515{,}975{,}976{,}562{,}500{,}000{,}000\sqrt5<0
\]

at $x=14$; since the compression is Hermitian, it has an eigenvalue above 14, and Rayleigh--Ritz gives \(\lambda_{\max}(H_Q)>14=\operatorname{Tr}_{HS}Q+2\max_L|S\cap L|\). The exact algebraic computation is in [`nonline_modes/d5_selected_charpoly.py`](nonline_modes/d5_selected_charpoly.py); the 2^12 support scan is in [`nonline_modes/d5_mode_subset_scan.py`](nonline_modes/d5_mode_subset_scan.py).

This only invalidates that **line-PVM spectral shortcut**. The desired term is $S_5(Q)$, the global POVM moment support, not the score of the best one-line MUB measurement. A numerical multi-start found pure-state scores around 3.809 for this $Q$, already suggesting why the line-only shortcut misses support, but this value has no global certificate and remains diagnostic. No legal channel counterexample follows. The known exact non-line-constant d=5 compatible channel is itself safe under its one six-state EB comparator in [`work/agents/quantum_physics/broadcast_lift/D5_AUDIT.md`](../../quantum_physics/broadcast_lift/D5_AUDIT.md), so it is only prior/control context.

**Weyl/parity star twirl closes the marginal-feasibility gap, with a separate positivity gate.** For odd-prime d and Weyl-invariant positive $Q$, the star Hamiltonian commutes with $\bar W_R\otimes W_A\otimes W_B$. Twirling any top eigenstate makes all three one-system marginals $I/d$; parity and output-swap averaging preserve the score and yield a symmetric extension whose channel is Weyl-covariant and Hilbert--Schmidt self-adjoint. The proof and complex-conjugation audit are in [`legal_sdp/STAR_TWIRL_VERIFICATION.md`](legal_sdp/STAR_TWIRL_VERIFICATION.md). This alone gives real transfer coefficients, not HS positivity: an explicit qubit EB measure-prepare universal-NOT channel has all three transfers $-1/3$. For the six-mode d=5 $Q$ above, however, the rational-interval eigenvector residual/gap certificate [`legal_sdp/d5_twirl_top_positivity_certificate.py`](legal_sdp/d5_twirl_top_positivity_certificate.py) proves the exact top-twirled channel has every nonidentity multiplier $>0.472038$. Thus this one star maximum is attained inside the full target class. Its support gate still passes with strict slack $S_5(Q)>3>\lambda_{\max}(H_Q)-12$; this is one exact test point, not an all-$Q$ result.

**A second d=5 mixed dual has an exact global quartic envelope.** For full-support nonuniform weights $Q=\tfrac12 I_{H_0}+\tfrac12P_{(1,0)}$, the pointwise pure-state score is at most $3$: the identity part contributes exactly $2$, while the selected Weyl pair contributes at most $1$. An eigenprojector of $X$ and its 25-element Weyl orbit attain the bound, so $S_5(Q)=3$. The exact star polynomial has top root $r\in(15,16)$ and $\operatorname{Tr}_{HS}Q=13$, hence every symmetric compatible extension obeys $2\operatorname{Tr}_{HS}(Q\Phi)-\operatorname{Tr}_{HS}Q\le r-13<3=S_5(Q)$. This is safe even without checking whether the maximizing top-projector channel is HS-positive, because the star maximum upper-bounds the target class. The exact calculation is in [`legal_sdp/D5_NONUNIFORM_WEIGHT_CONTROL.md`](legal_sdp/D5_NONUNIFORM_WEIGHT_CONTROL.md) and [`legal_sdp/d5_nonuniform_weight_exact.py`](legal_sdp/d5_nonuniform_weight_exact.py). It is a finite exact control, not a universal support inequality.

**A direct common-measurement theorem holds under an exact Weyl-line budget.** For odd-prime Weyl-covariant channels with real nonnegative transfer coefficients (0\le\lambda_g\le1), let (r_L=\max_{g\in L}(2\lambda_g-1)_+) over each projective line. If (\sum_Lr_L\le1), the single EB channel (\Psi= (1-\sum_Lr_L)D+\sum_Lr_L\mathcal E_L), with (\mathcal E_L) dephasing in the line eigenbasis, satisfies (\Psi\succeq2\Phi-I) on every Hermitian input. This retains arbitrary slow line modes and does not require a gap. The receiver-pulled conditional-expectation version is more restrictive. The exact known d=5 channel violates this *construction's* budget (≈1.33694) yet has a six-state common EB comparator, so the failure is method-specific. Full derivation and exact boundary are in [`markov_proof/next_gate/MARKOV_LINE_CE_GATE.md`](markov_proof/next_gate/MARKOV_LINE_CE_GATE.md); no universal line-budget necessity is claimed.

**The qutrit star reproof is not new.** Any cycle-8 $d=3$ Weyl-covariant self-adjoint channel is line-constant because each projective line has one nonzero mode pair up to sign. The prime-$d$ line-constant theorem in [`work/agents/quantum_physics/proofs/weyl_line_comparator.md`](../../quantum_physics/proofs/weyl_line_comparator.md) already covers it. That search was stopped and redirected; its qutrit subset formulas are not counted as new evidence.

**No d=4 legal violation was found.** The two-qubit Pauli-invariant numerical search sampled 180 positive duals and 5,000 pure states, then used local ascent. Its largest candidate gap was numerical zero (about $3.7\times10^{-12}$). The star support construction is legal after Pauli twirling for those invariant duals, but the pure-state search is only a lower bound on $S_4(Q)$; therefore this is a finite diagnostic, not a proof of safety or a refutation. See [`legal_sdp/pauli_search.py`](legal_sdp/pauli_search.py).

## Remaining gate and relation to almost-abelian work

The earlier Dirichlet calculation controls pairwise commutators of the full image unit ball under powers by $O(m^{-1/2})$. It still does not yield a dimension-free common measurement. In particular, an abelian tracial ultraproduct limit does not by itself provide a finite-dimensional uniform modulus, one canonical POVM, or the order inequality on the entire Hermitian unit ball. The needed gate is an all-family statement: every finite $d$, every supplied admissible $(\Phi,\mathcal B)$, and every positive $Q$ must satisfy (G), or one legal tuple must be accompanied by a global dual envelope $Z$ proving $\operatorname{Tr}(ZP)\ge f_Q(P)$ for all pure $P$ and a strict deficit. No such uniform-range theorem or legal violation was found.

The generic tree comparison still pays logarithmically in the frame rank (the weighted-tree improvement depends on a commuting cover of slow modes). The cycle-8 work does not improve that bound and does not prove bounded-Holevo approximate broadcasting implies one EB approximation. Accordingly, the original N93 bounded-capacity consequence remains open at this gate.

## Verification, costs, and claim boundary

The qutrit control is exact over \(\mathbb Q(i\sqrt3)\); the d=5 selected compression is exact over \(\mathbb Q(\sqrt5)\). The `d5_mode_subset_scan.py` and two-qubit Pauli search are floating-point exploratory scripts, explicitly not certificates. No algorithm with dimension-independent query, time, or outcome cost is established. The exact d=3 comparator has 12 outcomes; the qubit CP-square obstruction is finite exact algebra; the d=5 shortcut test uses a 25-by-25 exact characteristic polynomial.

Status: **the universal all-Q common-EB theorem and its legal counterexample are both UNKNOWN**. No novelty or priority claim is made. All reductions and finite results are internal and require independent mathematical review.
