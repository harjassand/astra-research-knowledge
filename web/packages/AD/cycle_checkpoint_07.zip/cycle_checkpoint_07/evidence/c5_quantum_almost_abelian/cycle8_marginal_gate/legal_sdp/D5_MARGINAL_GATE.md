# d=5 Weyl-mode moment gate: exact safe test and shortcut failure

## Verdict and scope

The universal channel-to-EB factor-two question remains **UNKNOWN**. This branch found neither a legal counterexample nor a proof for arbitrary positive duals. It gives one exact d=5 dual Q for which the canonical support inequality is safe for every self-compatible channel, and an exact spectral counterexample to a proposed MUB-line-PVM shortcut. The latter is only a failure of that shortcut; it is not an all-Q support deficit.

The starting d=5 channel is the exact, non-line-constant Weyl-covariant self-compatible channel already recorded in [D5_AUDIT.md](../../../quantum_physics/broadcast_lift/D5_AUDIT.md). That audit also constructs a single common EB comparator satisfying all 24 mode inequalities for this channel. Thus it was not a counterexample before this pass. The C7 canonical-moment report already gives the exact POVM moment primal/dual and the separation criterion; this pass does not repeat its Markov/conditional-expectation route. The C8 d=3 scripts are retained only as duplicated controls, since the parent redirected this branch beyond the prime-d line-constant theorem.

## Exact dual and star operator

Set d=5, ω=exp(2πi/5), X|j⟩=|j+1⟩, Z|j⟩=ωʲ|j⟩, and use the symmetrized Weyl convention

    W_(a,b) = ω^(3ab) X^a Z^b,
    W_g W_h = ω^(-S(g,h)/2) W_(g+h),
    S((a,b),(c,d)) = ad - bc,

where 3 is 2⁻¹ modulo 5. Let

    S = ((1,0), (1,1), (2,4), (2,1), (1,4), (0,1)).

This chooses one of the two real Weyl mode-pairs on each of the six projective lines. For g in S, define

    A_g = (W_g + W_g*)/√2,
    B_g = (W_g - W_g*)/(i√2),
    Q = sum_g ( |A_g⟩⟩⟨⟨A_g| + |B_g⟩⟩⟨⟨B_g| ),

with normalized Hilbert--Schmidt inner product τ(CD)=Tr(CD)/5. The 12 observables are orthonormal and traceless, so Q is positive and Tr_HS(Q)=12.

The three-party star operator on reference R and outputs A,B is

    H_S = sum_(g in S) sum_(C in {A_g,B_g})
          Cᵀ_R ⊗ (C_A ⊗ I_B + I_A ⊗ C_B).                 (1)

For the normalized Choi state Ω_RAB of any symmetric two-output extension of a channel Φ, the two bipartite marginals both induce Φ, and

    Tr(Ω H_S) = 2 Tr_HS(Q Φ).                                (2)

Thus every legal self-compatible channel obeys

    2 Tr_HS(Q Φ) - Tr_HS(Q) ≤ λmax(H_S) - 12.                (3)

## Exact full-spectrum calculation

The operator (1) commutes with U_h = conjugate(W_h) ⊗ W_h ⊗ W_h. Conjugation by W_h rotates each real pair (A_g,B_g) by a two-dimensional orthogonal matrix, leaving its paired sum in (1) invariant. In the computational basis, U_(0,1)=conjugate(Z) ⊗ Z ⊗ Z has charge a+b-r modulo 5 on |r,a,b⟩; each charge block has dimension 25. The commuting unitary U_(1,0)=conjugate(X) ⊗ X ⊗ X shifts this charge by one. Hence all five restrictions are unitarily conjugate and

    det(x I_125 - H_S) = p_25(x)^5,

where exact arithmetic in Q(ζ₅) gives

    p_25(x) =
      (x+1)^8 (x+1+√5)^4 (x+1-√5)^4
      (x²-8x+(-33+5√5)/2)
      (x²+2x-(63+5√5)/2)^2
      (x³-12x²+(-169+5√5)x/2+716-60√5).

Call the cubic factor c(x). It satisfies c(14)=-75-25√5<0 and c(15)=(247-45√5)/2>0. Also c′(14)=(335+5√5)/2>0 and c″(x)=6x-24>0 for x≥14. Therefore the cubic has exactly one root r in (14,15). The two quadratic factors are increasing and positive for x≥14, and the linear-factor roots are below 14. Consequently

    λmax(H_S)=r in (14,15),
    λmax(H_S)-12<3.                                         (4)

This exact root calculation disproves the proposed MUB-line-PVM operator estimate for this subset. Every line PVM has canonical score 2 against Q, and the maximum selected-pair occupancy of a projective line is one. The attempted star estimate would therefore be λmax(H_S)≤Tr_HS(Q)+2=14, contradicted by r>14. This says only that these six line-PVM scores do not upper-bound this star spectrum. Equations (4) and (5) below show that this Q is safe.

The reproducible calculation is [d5_star_subset_exact.py](d5_star_subset_exact.py). It forms the exact charge block and checks its 25-dimensional characteristic polynomial against the displayed factorization. Run from the repository root with SymPy 1.14 or compatible.

## Exact finite-POVM lower certificate

Take the rational unit vector

    |ψ⟩ = (1,-1,0,1,-1)ᵀ/2,    P=|ψ⟩⟨ψ|.

Its 25-element Weyl orbit defines the POVM M_h=(1/5) W_h P W_h*, because sum_h W_h P W_h*=5I. Each outcome has probability weight 1/25 in the canonical support formula. The score

    f_Q(P) = sum_g [ (Tr(P A_g))² + (Tr(P B_g))² ]
           = 2 sum_g |Tr(P W_g)|²
           = (5+√5)/2 > 3

is exactly algebraic. The Weyl orbit changes each W_g only by a phase, so f_Q(W_h P W_h*)=f_Q(P) for all 25 outcomes. Therefore this single explicit rank-one POVM proves

    S_5(Q) ≥ (5+√5)/2 > 3.                                 (5)

Together (3)--(5), for every legal marginal-feasible symmetric extension,

    S_5(Q) > 3 > 2 Tr_HS(Q Φ) - Tr_HS(Q).

This is an exact positive result for this one mixed dual, not a universal support theorem.

For the specific prior D5 channel, the exact mode table in D5_AUDIT.md gives

    2 Tr_HS(Q Φ)-12
      = (2141157-1753216√5)/3151721
      ≈ -0.5645021102.

That channel is even farther from a support violation. The exact finite-POVM certificate is in [d5_povm_support_certificate.py](d5_povm_support_certificate.py).

## Numerical optimizer, failed extension attempt, and boundary

A deterministic 64-start local search in the support script returns score 3.809016994374948, with a normalized approximate state

    (-0.241666871360-0.175581268806i,
     -0.069578241698+0.050551537990i,
     -0.135310238663-0.416442105829i,
      0.622490201831,
     -0.175934876149+0.541471819585i)ᵀ.

The multistart optimizer is diagnostic only; neither the global optimum nor the conjectured value (13+√5)/4 is certified. The rational seed in (5), not this numerical fit, is the proof-grade lower certificate.

An attempted explicit regular-representation Stinespring extension was rejected: the tested projective-representation and first-marginal formulas passed numerically, but the second marginal failed by order one. It is preserved as [d5_explicit_extension_attempt_FAILED.py](d5_explicit_extension_attempt_FAILED.py) and is not used as a witness. The prior D5 compatibility claim instead rests on the exact positive compatibility kernel X=vvᵀ/||v||² and the Weyl-covariant compatibility criterion documented in D5_AUDIT.md; this branch does not claim to have materialized its Choi extension.

The exact certificates quantify over the fixed d=5 Q and, through (2)--(4), every normalized symmetric two-output extension with those equal channel marginals. They do not bound all positive Q, all dimensions, or non-symmetric extensions. Exact work uses one 25×25 cyclotomic star block and one rational seed with a 25-outcome POVM; the local optimizer is optional numerical exploration. No data acquisition or hardware measurement is involved. The global gate remains: prove the mixed-Q inequality for all dimensions, or find a legal marginal-feasible extension and a rigorous global moment-dual upper envelope that violates it.
