# Cycle 8 Markov-form report

## Verdict

The unrestricted factor-two channel-to-EB statement remains **UNKNOWN**. This branch found a rigorous obstruction to one proposed universal proof mechanism: not every admissible compatible, positive, tracially self-adjoint channel is the Hilbert--Schmidt square \(C^*C\) of a bistochastic CP map. The obstruction is an exact one-parameter family of qubit channels.

The example is not a counterexample to the target. It is itself a canonical entanglement-breaking channel, so it satisfies the comparison with constant one. It shows that the N92 instrument/Petz sum-of-squares factorization cannot cover all admissible channels, even if the instrument is allowed to be chosen freely. The full proof and the unresolved all-Q lemma are in [PROOF_AND_GATE.md](PROOF_AND_GATE.md).

## Mechanism

For \(0<\varepsilon<1\), the POVM \(\{\varepsilon P_{x,\pm},(1-\varepsilon)P_{z,\pm}\}\) produces the Pauli transfer matrix \(\operatorname{diag}(\varepsilon,0,1-\varepsilon)\). Its rank-two Bloch transfer has square-root singular values \(\sqrt{\varepsilon}\) and \(\sqrt{1-\varepsilon}\), whose sum exceeds one. If it were \(C^*C\) for bistochastic CP qubit \(C\), those would be the singular values of \(C\)'s Bloch matrix. Unitary input/output rotations reduce that matrix to diagonal form; complete positivity with its third singular value zero instead requires the two remaining absolute entries to sum to at most one. Contradiction.

The supplied EB measurement also defines an explicit two-output broadcaster by preparing two copies of each measured eigenstate. The channel has an exact Hermitian-Kraus Dirichlet representation; hence the fixture lies inside the target's Markov and compatibility assumptions.

## Decisive remaining gate

For every finite \(d\), every admissible supplied pair \((\Phi,\mathcal B)\), and every positive HS test operator \(Q\), prove

\[
\sup_{M\ \mathrm{POVM}}\operatorname{Tr}_{HS}(Q\Psi_M)
\ge \operatorname{Tr}_{HS}(Q(2\Phi-I)).
\]

The optimizing POVM here must see and jointly handle the whole positive frame encoded by \(Q\). Proving this for every \(Q\) yields a single full-domain canonical EB comparator by convex separation. Conversely, a strict failure requires one legal broadcaster and a rigorous global support/moment certificate. The CP-square obstruction proves neither direction.

No dimension-free all-frame proof, stronger-than-log-d bound, or legal support deficit was obtained. This is an exact representation-route obstruction, internally reconstructed; there was no numerical computation, external proof review, or priority assessment.
