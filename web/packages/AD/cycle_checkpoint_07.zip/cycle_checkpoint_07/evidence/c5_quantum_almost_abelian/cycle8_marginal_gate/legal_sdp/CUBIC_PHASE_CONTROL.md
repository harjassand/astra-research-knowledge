# Exact qutrit control: a nontrivial legal positive channel with one EB comparator

This is a scoped all-(Q) control instance for the marginal-feasible gate. It is not a proof of the arbitrary-dimension theorem, and it is not a counterexample. Unlike the earlier Weyl-line-constant qutrit test, the channel below is obtained from a permutation-symmetric cubic-phase extension; after squaring it satisfies the required Hilbert--Schmidt positivity.

## Exact supplied extension

Let (omega=e^{2pi i/3}=(-1+isqrt3)/2), and index the three systems by (R,A,B). Define

\[
 |p\rangle=\frac13\sum_{i,a\in\mathbb Z_3}
       \omega^{,ia(-i-a)}|i,a,-i-a\rangle,
 \qquad |q\rangle=\overline{|p\rangle},
 \qquad \Omega=\tfrac12(|p\rangle\langle p|+|q\rangle\langle q|).
\tag{1}
\]

Each vector has nine nonzero entries of modulus (1/3), hence unit norm. The support condition (i+a+b=0) and phase (iab) are invariant under all permutations of the three indices. Thus (Omega) is a positive, normalized, fully permutation-symmetric state; direct exact partial traces give every one-system marginal (I/3). Regard (R) as the normalized Choi reference. Since (Omega_R=I/3), Choi inversion defines a CPTP map (mathcal B:M_3\to M_3\otimes M_3), and its two equal marginals are one unital CPTP channel (Phi). The one-system output marginal (I/3) gives unitality; the exact transfer matrix below confirms Hilbert--Schmidt self-adjointness.

In the ordered normalized-trace-orthonormal Gell--Mann basis, the exact real transfer matrix of (Phi) on traceless Hermitians is

\[
T=\begin{pmatrix}
1/3&0&1/3&0&-1/6&0&0&0\\
0&-1/3&0&1/3&0&1/6&0&0\\
1/3&0&1/3&0&-1/6&0&0&0\\
0&1/3&0&-1/3&0&-1/6&0&0\\
-1/6&0&-1/6&0&1/3&0&0&0\\
0&1/6&0&-1/6&0&-1/3&0&0\\
0&0&0&0&0&0&0&0\\
0&0&0&0&0&0&0&0
\end{pmatrix}.
\tag{2}
\]

It is symmetric, with spectrum

\[
\operatorname{spec}(T)=\left\{\pm\frac{3+\sqrt3}{6},\ 
                           \pm\frac{3-\sqrt3}{6},\ 0^{(4)}\right\}.
\tag{3}
\]

The original marginal (Phi) is therefore not a positive operator on the real Hilbert--Schmidt space. Define instead (Phi_2=Phi^2). Apply (Phi) to each receiver output of (mathcal B):

\[
\mathcal B_2=(\Phi\otimes\Phi)\circ\mathcal B.
\tag{4}
\]

Complete positivity, trace preservation, output swap symmetry, and the maximally mixed marginals are preserved. Because (Phi) is unital and trace preserving, each marginal of (mathcal B_2) is (Phi\circPhi=Phi_2). Hence the supplied pair ((Phi_2,mathcal B_2)) meets the full interface, and (Phi_2) is Hilbert--Schmidt positive. Its traceless spectrum is

\[
\operatorname{spec}(T^2)=\left\{\frac{2+\sqrt3}{6}^{(2)},\ 
                           \frac{2-\sqrt3}{6}^{(2)},\ 0^{(4)}\right\}.
\tag{5}
\]

## One finite canonical EB comparator

Take the four standard qutrit Weyl mutually unbiased bases, with dephasing channels (Delta_L), and set

\[
\Psi=\frac14\sum_{L}\Delta_L.
\tag{6}
\]

The 12 effects (M_{L,j}=P_{L,j}/4) form one POVM. It is entanglement breaking and its canonical map is (6). The four Weyl-line traceless subspaces are an orthogonal decomposition of the 8-dimensional traceless space, so (Psi=I/4) there and (Psi(I)=I).

The largest eigenvalue of (Phi_2) is (lambda_+=(2+\sqrt3)/6). Therefore on its top eigenspace,

\[
\frac14-(2\lambda_+-1)
 =\frac{7-4\sqrt3}{12}>0,
\tag{7}
\]

where strictness is the exact integer inequality (49>48). The second eigenvalue in (5) is less than (1/2), and the remaining eigenvalues are zero, so (2T^2-I) is negative on all those spaces. On the identity, both (Psi) and (Phi_2) fix (I). Thus, on the entire Hermitian space,

\[
\Psi\succeq 2\Phi_2-I,
\qquad I-\Psi\preceq2(I-\Phi_2).
\tag{8}
\]

The top-space slack is exactly ((7-4\sqrt3)/12\approx 0.005983). The argument handles every positive dual (Q) for this one supplied qutrit channel, because (8) is an operator inequality with one fixed POVM. It does not address other channels or dimensions.

## Verification and limits

`cubic_phase_exact_check.py` constructs (1) over (mathbb Q(i\sqrt3)), checks exact normalization, permutation symmetry, one- and two-system marginals, and reproduces (2)--(7) symbolically. The positive-extension statement for (4) follows directly by applying a CPTP map locally to the two outputs; no numerical SDP relaxation is used. A complete set of four qutrit Weyl MUBs supplies the stated 12-outcome comparator.

This channel is a legal qutrit control for the all-(Q) marginal gate, but the certificate is intentionally easy after squaring: its largest eigenvalue lies just below the qutrit universal-cloning value (5/8), while the MUB-average EB channel supplies (1/4) on every traceless direction. It gives no evidence that an arbitrary self-compatible positive channel has a similarly simple spectral bound or comparator.
