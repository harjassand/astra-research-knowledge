# Weyl/parity star twirl: exact marginal feasibility and the positivity caveat

## General finite-dimensional lemma

Let (d) be an odd prime, let (Q\succeq0) be a self-adjoint operator on the real traceless-Hermitian space, and assume (Q) is invariant under the adjoint Weyl action. Write

\[
Q=\sum_i w_i|A_i\rangle\langle A_i|,
\qquad
H_Q=\sum_iw_i A_i^T{}_R\otimes(A_i{}_A\otimes I_B+I_A\otimes A_i{}_B).
\]

The real adjoint representation of the Weyl group decomposes into the two-dimensional mode planes indexed by pairs \(\{g,-g\}\), \(g\ne0\). These planes are inequivalent. On one such plane the commutant consists of \(aI+bJ\); self-adjointness removes \(bJ\). Therefore an invariant self-adjoint (Q) is scalar on each plane. Phase-space parity (P|j\rangle=|-j\rangle) sends (g\mapsto-g), so it commutes with (Q) and (H_Q).

The star operator also commutes with

\[
U_W=\overline W_R\otimes W_A\otimes W_B.
\]

Indeed, (A\mapsto WAW^*\) is an orthogonal transformation on each real mode plane; invariance of (Q) makes the paired sum defining (H_Q) invariant. If \(|\psi\rangle\) is a top eigenvector, define

\[
\Omega_0=\frac1{d^2}\sum_{W\in\mathsf W_d}U_W|\psi\rangle\langle\psi|U_W^*.
\]

This is a density matrix supported on the top eigenspace and retains score \(\lambda_{\max}(H_Q)\). Every one-body marginal commutes with the corresponding irreducible Weyl representation, so each equals (I/d). Average further under \(\overline P_R\otimes P_A\otimes P_B\) and output swap (A\leftrightarrow B). Both unitaries commute with (H_Q); the resulting Ω retains the score, has all three marginals (I/d), and is output-swap symmetric.

Its normalized Choi inverse is consequently a unital, trace-preserving CP channel with a symmetric two-output CPTP extension. Weyl covariance diagonalizes the channel: \(\Phi(W_g)=\lambda_gW_g\). Hermiticity preservation gives \(\lambda_{-g}=\overline{\lambda_g}\); parity covariance gives \(\lambda_{-g}=\lambda_g\). Hence the transfer coefficients are real and the channel is Hilbert--Schmidt self-adjoint. Thus, **without an additional Hilbert--Schmidt-positivity premise**, the unrestricted star maximum is exactly attainable by a symmetric CP broadcaster with a unital HS-self-adjoint marginal.

## What this lemma does not give

The twirl does not force \(\lambda_g\ge0\). A concrete warning is the qubit measure-and-prepare channel obtained by measuring the covariant POVM (M(dn)=(I+n\cdot\sigma)d\mu(n)) on the Bloch sphere and preparing ρ\(_{-n}=(I-n\cdot\sigma)/2\). Direct integration gives Bloch transfer \(\lambda_X=\lambda_Y=\lambda_Z=-1/3\). It is EB and has a symmetric extension (prepare \(\rho_{-n}^{\otimes2}\)), is unital, TP and HS-self-adjoint, but is not positive as an HS operator. Therefore the star top eigenvalue is an upper bound for the target class requiring \(\Phi\succeq0\) on HS, and its twirled optimizer is a legal target-class witness only after checking all transfer coefficients.

## Exact check for one d=5 star maximizer

For the six-mode (d=5) dual in [`../nonline_modes/D5_STAR_TWIRL_AND_SUPPORT.md`](../nonline_modes/D5_STAR_TWIRL_AND_SUPPORT.md), the exact charge-block polynomial gives a simple top root

\[
\alpha\in[14.67541651249,14.67541651250],
\]

and every other eigenvalue of the charge-zero block is at most (14). The checker [`d5_twirl_top_positivity_certificate.py`](d5_twirl_top_positivity_certificate.py) uses a normalized rational Gaussian vector (q) rounded to (10^{-9}) from the block eigenvector. Rational intervals for fifth roots of unity certify

\[
\|(H_Q-\alpha I)q\|_2<1.714\times10^{-5},\qquad
\alpha-\lambda_2>0.67541651249.
\]

The spectral-gap estimate bounds the trace distance between the exact top eigenprojector and \(|q\rangle\langle q|\) by (5.074\times10^{-5}). Weyl, parity and swap twirls and partial trace are trace-norm contractions. Every transfer coefficient is the expectation of a norm-one Choi correlation, so its change is at most this same amount. Exact interval arithmetic gives the approximate all-mode range

\[
0.4720887868\ldots\le\widetilde\lambda_g\le0.7197368740\ldots,
\]

and hence the exact top-twirled channel satisfies \(\lambda_g>0.472038\) on all 24 nonidentity modes. Its HS superoperator is therefore positive. For this one (Q), the star maximum is attained within the full target class, not only the larger CP-self-adjoint class. The exact certificate depends on the already checked charge-block characteristic polynomial and is not an all-(Q) positivity theorem.

The second full-support nonuniform dual \(Q=\tfrac12 I_{H_0}+\tfrac12P_{(1,0)}\) in [`D5_NONUNIFORM_WEIGHT_CONTROL.md`](D5_NONUNIFORM_WEIGHT_CONTROL.md) also passes the HS-positivity gate exactly. Its root bracket is \([15.20314675649,15.20314675650]\); all other charge-block eigenvalues are below (10). The checker [`d5_nonuniform_top_positivity_certificate.py`](d5_nonuniform_top_positivity_certificate.py) gives residual (<1.744\cdot10^{-5}), transfer-moment error (<6.703\cdot10^{-6}), and a lower bound (>0.570171) on all 24 nonidentity multipliers. This strengthens that full-support example from a safe support upper bound to an exact legal star maximizer. It remains one dual, not a general positivity theorem.

## Consequence and status

For Weyl-invariant (Q), the star relaxation is no longer merely an unbalanced Choi-state upper bound: the top score is attained by a balanced, symmetric, self-adjoint extension. In the selected d=5 fixture it also passes the extra HS-positivity gate exactly. This makes the actual obstruction test particularly sharp there: the fixture's exact moment lower bound (S_5(Q)>3) exceeds \(\lambda_{\max}(H_Q)-\operatorname{Tr}_{HS}Q<3\), so it is safe. No all-(Q) theorem or legal counterexample follows.
