# Cycle 9: Weyl-star feasibility and exact quartic support

## Status

The universal all-dimensional common-entanglement-breaking (EB) comparison remains **UNKNOWN**. This note closes the marginal-feasibility audit for a Weyl-invariant star dual, identifies the remaining Hilbert--Schmidt positivity gate, and proves an exact all-dimension support inequality for a nontrivial family of Weyl-invariant duals. It does not prove the full Weyl-invariant inequality or the unrestricted channel theorem, and it gives no counterexample.

## Exact pure-state formula for the canonical-EB support

Let (d) be an odd prime, let (W_g), (g\in\mathbb Z_d^2), be a Weyl system, and let (\mathcal H_0) be the real traceless-Hermitian space with normalized-trace inner product (\tau(A B)=\operatorname{Tr}(AB)/d). The real Weyl mode plane for ([g]=\{g,-g\}), (g\ne0), is

\[
\mathcal V_{[g]}=\operatorname{span}_{\mathbb R}\{A_g,B_g\},\quad
A_g=(W_g+W_g^*)/\sqrt2,\quad
B_g=(W_g-W_g^*)/(i\sqrt2).
\]

Let (Q\succeq0) be self-adjoint and invariant under Weyl conjugation. The real Weyl representation splits into inequivalent two-dimensional mode planes, so (Q=\sum_{[g]}q_{[g]}P_{[g]}), with (q_{[g]}\ge0) and (P_{[g]}) the orthogonal projector onto \(\mathcal V_{[g]}\). For a density matrix \(\rho\), write

\[
f_Q(\rho)=\sum_i w_i(\operatorname{Tr}(\rho A_i))^2,
\qquad Q=\sum_iw_i|A_i\rangle\langle A_i|.
\]

Then the full barycenter-constrained canonical support is exactly

\[
S_d(Q)=\max_{\substack{\mu\in\mathcal P(\mathcal D_d)\\\int\rho\,d\mu=I/d}}
  \int f_Q(\rho)\,d\mu(\rho)
=\max_{\|\psi\|=1} f_Q(|\psi\rangle\langle\psi|)
=\max_{\|\psi\|=1}2\sum_{[g]}q_{[g]}|\langle\psi,W_g\psi\rangle|^2.
\tag{1}
\]

For the upper bound, (f_Q) is convex: each term is a nonnegative multiple of the square of a real affine functional. A spectral decomposition of every mixed \(\rho\) therefore gives \(f_Q(\rho)\le\max_\psi f_Q(P_\psi)\). For the reverse bound, the Weyl orbit \(\{W_hP_\psi W_h^*:h\in\mathbb Z_d^2\}\) has barycenter (I/d) by irreducibility, and Weyl invariance of (Q) makes all orbit scores equal to (f_Q(P_\psi)). A maximizing orbit gives a finite rank-one POVM with (d^2) outcomes. Thus (1) includes the full barycenter constraint; it is not only a pure-state lower bound.

The last equality follows from \(\operatorname{Tr}(P A_g)^2+\operatorname{Tr}(P B_g)^2=2|\langle\psi,W_g\psi\rangle|^2\). Also \(\sum_{[g]}2|\langle\psi,W_g\psi\rangle|^2=d-1\) for every pure state, by Parseval in the normalized-trace-orthonormal traceless Weyl basis. Consequently the rigorous general upper bound

\[
S_d(Q)\le(d-1)\max_{[g]}q_{[g]}
\tag{2}
\]

holds. It can be strict; the proof does not replace the quartic maximization by (2) when that loses needed slack.

## Star twirl: exact CP/self-adjoint feasibility, separate positivity gate

For the star operator

\[
H_Q=\sum_iw_i A_i^T{}_R\otimes(A_i{}_A\otimes I_B+I_A\otimes A_i{}_B),
\]

the simultaneous Weyl representation \(\overline W_R\otimes W_A\otimes W_B\) commutes with (H_Q). Twirling a top eigenprojector over this representation makes all one-system marginals (I/d) by irreducibility without changing the top score. The global parity \(P|j\rangle=|-j\rangle\) commutes with (H_Q): Weyl-invariant self-adjoint (Q) is scalar on each real mode plane, and parity preserves each plane. Averaging by \(\overline P_R\otimes P_A\otimes P_B\) and output swap preserves the score and yields a symmetric normalized Choi state. Its marginal is a unital, TP, CP Weyl-covariant channel. Hermiticity preservation gives \(\lambda_{-g}=\overline{\lambda_g}\); parity covariance gives \(\lambda_{-g}=\lambda_g\), so the marginal is Hilbert--Schmidt self-adjoint.

Therefore the star top is exactly attained over symmetric CP broadcasters with unital HS-self-adjoint marginal. This does **not** make every twirled top marginal Hilbert--Schmidt-positive: real Weyl multipliers can be negative. The qubit covariant universal-NOT EB channel in [`../cycle8_marginal_gate/legal_sdp/STAR_TWIRL_VERIFICATION.md`](../cycle8_marginal_gate/legal_sdp/STAR_TWIRL_VERIFICATION.md) is an explicit warning. For use as a target-class witness requiring \(\Phi\succeq0\) on Hilbert--Schmidt space, certify every transfer multiplier separately. The two d=5 star tops already certified in cycle 8 pass this positivity gate; that is fixture-specific.

The valid general star/moment reduction is consequently

\[
\text{for Weyl-invariant }Q:\quad
\lambda_{\max}(H_Q)-\operatorname{Tr}_{HS}Q\le S_d(Q)
\tag{3}
\]

as a sufficient support inequality for all compatible channels (because it bounds every extension), with the twirl making any strict star violation a legal CP/HS-self-adjoint witness. A strict violation is a counterexample to the target only if the twirled marginal also passes the HS-positivity gate.

## Exact all-dimension support family

Fix one projective Weyl line (L\subset\mathbb Z_d^2\setminus\{0\}\), and arbitrary nonnegative weights \(\beta_{[g]}\) on its real mode planes. Let

\[
Q=\alpha I_{\mathcal H_0}+\sum_{[g]\subset L}\beta_{[g]}P_{[g]},
\qquad \alpha\ge0,\quad\beta_{[g]}\ge0.
\tag{4}
\]

The canonical support is exactly

\[
S_d(Q)=\alpha(d-1)+2\sum_{[g]\subset L}\beta_{[g]}.
\tag{5}
\]

Indeed the identity component scores \(d-1\) on every pure state; each mode score is at most 2; and any eigenvector of a generator of the commuting line (L) has \(|\langle W_g\rangle|=1\) for every \([g]\subset L\), simultaneously attaining all terms.

The star summands obey

\[
\lambda_{\max}(H_{I_{\mathcal H_0}})=d^2+d-2,
\qquad
\lambda_{\max}(H_{P_{[g]}})=4.
\tag{6}
\]

For the first identity, normalized-trace completeness gives
\(\sum_{i\,\mathrm{traceless}} A_i^T\otimes A_i=d^2|\Omega\rangle\langle\Omega|-I\), where \(|\Omega\rangle=d^{-1/2}\sum_j|jj\rangle\). Thus
\(H_I=d^2(P_{RA}+P_{RB})-2I\). For arbitrary \(|v\rangle_B\), direct contraction gives
\(P_{RB}(|\Omega\rangle_{RA}\otimes|v\rangle_B)=d^{-1}|\Omega\rangle_{RB}\otimes|v\rangle_A\), and hence \(P_{RA}P_{RB}P_{RA}=d^{-2}P_{RA}\). The ranges have no intersection and every principal cosine is (1/d), so \(\lambda_{\max}(P_{RA}+P_{RB})=1+1/d\), proving the first formula. For one Weyl mode, its paired operator is
\(W_g^T\otimes W_g^*+W_g^{*T}\otimes W_g\), with eigenvalues \(2\cos(\theta_r-\theta_a)\). The two output couplings commute and each is at most 2, with equality when all three Weyl eigenphases agree; hence the second formula. All modes on a single projective line are powers of the same Weyl generator, so their star terms are simultaneously diagonal and

\[
\lambda_{\max}\!\left(H_{\sum_{[g]\subset L}\beta_{[g]}P_{[g]}}\right)
=4\sum_{[g]\subset L}\beta_{[g]}.
\tag{7}
\]

Since (\lambda_{\max}) is subadditive on Hermitian sums for nonnegative coefficients,

\[
\begin{aligned}
\lambda_{\max}(H_Q)-\operatorname{Tr}_{HS}Q
&\le \alpha(d^2+d-2)+4\sum_L\beta_{[g]}
  -\left(\alpha(d^2-1)+2\sum_L\beta_{[g]}\right)\\
&=\alpha(d-1)+2\sum_L\beta_{[g]}=S_d(Q).
\end{aligned}
\tag{8}
\]

This is an exact support-gate proof for all odd primes (d), all nonnegative coefficients in (4), and every compatible symmetric CP extension; it makes no covariance or HS-positivity assumption on the channel being bounded. It includes the line-supported case and the full-support one-mode perturbation (Q=\alpha I+\beta P_{[g]}). The exact d=5 dual \(\tfrac12I+\tfrac12P_{(1,0)}\) from cycle 8 is a special case: (5) gives (S_5(Q)=3), while (8) gives (\lambda_{\max}(H_Q)-13\le3). Its separately computed root (15.2031\ldots<16) supplies extra slack but is unnecessary to establish safety for this family.

## What remains open

For a general Weyl-invariant dual, the exact unresolved inequality is the weighted pure quartic comparison

\[
\lambda_{\max}(H_Q)-\operatorname{Tr}_{HS}Q
\stackrel{?}{\le}
\max_{\|\psi\|=1}2\sum_{[g]}q_{[g]}|\langle\psi,W_g\psi\rangle|^2.
\tag{9}
\]

The finite d=5 six-mode dual is safe by its certified finite-orbit lower bound (S_5(Q)>3), while its star excess is (<3); the full-support nonuniform dual is safe by (4)--(8). These controls do not settle (9). A real violation still needs a positive-weight dual with a **global** quartic upper certificate below the star excess and, for a target-class counterexample, an exact nonnegative transfer-spectrum certificate for the twirled top marginal. A numerical quartic optimizer or a negative/uncertified channel multiplier is not sufficient.

The theorem does not yield a dimension-free approximation algorithm: for the displayed Weyl-orbit POVM, finding a maximizing seed remains an optimization over a complex sphere of dimension (d-1), and the construction has (d^2) outcomes. Its value is an existence/support statement with exact all-family quantifiers, not a uniform-time or uniform-outcome compiler.
