# Source and scope notes: cycle 9 Weyl moment gate

## Primary external prior checked

Erkka Haapasalo, “Compatibility of covariant quantum channels with emphasis on Weyl symmetry,” arXiv:1901.06113v1, <https://arxiv.org/abs/1901.06113>.

- The finite phase-space case defines a positive kernel \(\beta\) on \(\mathbb Z_d^2\times\mathbb Z_d^2\). Corollary 2 gives a necessary and sufficient condition for compatibility of two Weyl-covariant channels in terms of a PSD kernel with unit diagonal and the marginal Fourier formula (paper pp. 18–19; PDF lines 2011–2043 in the browser-rendered source).
- This source supplies the correct finite-Weyl compatibility interface and confirms that covariance reduces the search to structured joint channels. It does **not** state the factor-two common-EB support inequality, does not identify the canonical support with a pure quartic maximum, and does not make real Weyl multipliers nonnegative.
- The star-twirl proof here is a finite-dimensional Schur-lemma argument. Haapasalo’s compatibility theorem is context/prior, not a premise of the proof.

## Local inherited interfaces

- `../cycle8_marginal_gate/FINAL_REPORT.md` states the exact full-Hermitian-domain canonical support gate and its corrected compactness construction (measures on the compact density-matrix space with barycenter I/d; finite support by Caratheodory). This cycle uses that formula and specializes it to Weyl-invariant Q.
- `../cycle8_marginal_gate/legal_sdp/STAR_TWIRL_VERIFICATION.md` records the parity/complex-conjugation proof and the qubit universal-NOT caveat. This cycle reuses that proven argument rather than silently inferring positivity from a real spectrum.
- `../cycle8_marginal_gate/legal_sdp/D5_NONUNIFORM_WEIGHT_CONTROL.md` gives the exact d=5 instance Q=1/2 I+1/2 P_(1,0), with S_5(Q)=3. The family proof in this cycle yields its support gate without needing the exact star root; the old charpoly is an additional scoped check.
- `../cycle8_marginal_gate/nonline_modes/D5_STAR_TWIRL_AND_SUPPORT.md` gives the six-mode d=5 fixture and its exact finite-orbit support lower certificate. The present cycle does not claim a global quartic maximum for that fixture.
- `../cycle8_marginal_gate/markov_proof/next_gate/MARKOV_LINE_CE_GATE.md` proves a separate channel-side construction under a line-energy budget. It is not the proof of the dual family (4).
- `../../quantum_physics/sources/N93-bounded-holevo-gates.txt` and `../../broadcast_channel_attack/sources/detailed_balance_broadcast_attack.txt` retain the broader N93 all-family common-measurement/EB lift and its exact missing uniform-range gate. The Weyl slice does not close that result.

## Evidence and provenance boundary

All new arguments in `REPORT.md` are internally reconstructed exact finite-dimensional proofs. The only numerical or exact-algebraic d=5 star checks cited are scoped to their displayed fixtures. No external specialist audit, publication-priority search, dimension-uniform algorithmic implementation, or proof of the unrestricted theorem is claimed.
