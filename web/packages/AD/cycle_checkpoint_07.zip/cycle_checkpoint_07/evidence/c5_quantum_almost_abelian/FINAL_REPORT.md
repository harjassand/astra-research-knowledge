# C5: low-energy almost-abelian range to one EB map

## Verdict

The requested dimension-free common-measurement/EB gate remains **UNKNOWN**. I found no qualifying channel counterexample and no proof that closes it. The strongest valid contribution here is a dimension-free *pairwise* low-Dirichlet-energy commutator estimate, a precise counterexample showing why averaged pairwise commutators alone cannot imply joint measurability, and an exact random-bin estimate locating the remaining refinement step. This does not advance N93 to a theorem.

## What is established within this pass

For a supplied unital, trace-preserving, CPTP, Hilbert–Schmidt-selfadjoint and Hilbert–Schmidt-positive self-compatible channel \(\Phi\), let \(G=I-\Phi\) and \(e(A)=\langle A,GA\rangle_{\tau}\). Combining the already derived broadcast-tree estimate for \(\Phi^\ell\) with positive-spectrum functional calculus gives, for every pair of Hermitian contractions,

\[
\|[A,B]\|_{2,\tau}\le 10\bigl(e(A)+e(B)\bigr)^{1/4}.
\]

The derivation is explicit: \(\|A-\Phi^\ell(A)\|_2^2\le\ell e(A)\), while the broadcaster tree gives \(\|[\Phi^\ell(A),\Phi^\ell(B)]\|_2\le2/\sqrt{\ell+1}+4/(\ell+1)\); balance at \(\ell\asymp(e(A)+e(B))^{-1/2}\). For a weighted frame this implies

\[
\mathbb E_{i,j}\|[A_i,A_j]\|_{2,\tau}^{2}
\le100\sqrt{2\,\mathbb E_i e(A_i)}.
\]

These are normalized-trace estimates with no dimension or frame-size factor. They say low-energy modes almost commute pairwise; they do not select one measurement for all of them.

The converse shortcut based only on mean pairwise commutator is false. For the uniform frame of the \(2n\) Pauli observables \(X_i,Z_i\) on \(n\) qubits, the mean squared normalized-HS commutator is \(2/n\to0\). Nevertheless every common POVM has average joint pure-state variance at least \(1/2\), because each qubit obeys \(\operatorname{Var}(X_i)+\operatorname{Var}(Z_i)\ge1\) in every pure state. This is not a counterexample to N93’s channel-energy gate: by the preceding pairwise estimate, each anti-commuting pair requires nonvanishing energy at its endpoints. It is a direct warning that commutator averages cannot replace the per-mode energy profile.

For one pivot observable \(X\), random spectral bins give an exact useful first step:

\[
\mathbb E_u\|Y-\mathcal E_{X,h,u}(Y)\|_{2,\tau}^{2}
\le h^{-1}\|[X,Y]\|_{2,\tau}\|Y\|_{2,\tau}.
\]

Here \(\mathcal E_{X,h,u}\) pinches across bins of width \(h\) with random offset \(u\). The pinching range is block-diagonal and generally noncommutative. Commutators control cross-bin leakage but do not control noncommutativity inside the bins. This is the local technical point at which a standard spectral-binning argument stops short of one abelian measurement for a growing frame.

## Prior-art boundary and all-family quantifier

Primary normalized-HS almost-commuting results settle every *fixed finite tuple*. Glebsky’s theorem has a modulus depending on tuple size. The recent Bansil–Kachkovskiy v1 gives a sharp pair estimate and improves quantitative fixed-tuple bounds, but its all-\(N\) corollary retains a size-dependent constant and exponent \(2/3^{N-1}\). The channel dual frame may have rank up to \(d^2\); setting \(N\) equal to that rank does not produce a dimension-free modulus.

Likewise, if a sequence of power ranges has vanishing commutators, the associated tracial-ultraproduct range is abelian. This is a pointwise algebraic conclusion. A finite EB reconstruction in normalized \(\infty\to1\) needs one finite-coordinate POVM controlling the supremum over the whole operator unit ball or, in N93’s weaker dual form, one POVM for each entire weighted frame with a uniform modulus. Choosing a measurement after each finite subfamily, or lifting a preselected separable subalgebra, leaves the growing-frame supremum unresolved. Houdayer–Ioana’s relevant ultraproduct lifting theorem is explicitly for separable abelian subalgebras (in a 2-independent pair); it is not an all-family uniform lift.

The exact target is the weighted joint-variance gate: for every finite weighted Hermitian frame from the relevant low-energy range, produce one POVM with joint variance \(q((A_i,p_i))\le\omega(\sum_i p_i e(A_i))\), where \(\omega(t)\to0\) independently of dimension and frame size. A full-ball version would suffice directly: if one masa \(D\) satisfies \(\sup_{\|A\|_\infty\le1}\|T(A)-E_D(T(A))\|_{2,\tau}\le\epsilon\), then \(E_D\circ T\) is EB and is within \(\epsilon\) of \(T\) in normalized \(\infty\to1\), since normalized \(L^1\le L^2\). The supremum over the full ball is essential to that conversion.

Parent’s separate c4 tree branch owns the weighted prefix/commuting-cover result. This report does not repeat that argument. Its conditional one-measurement gain still requires a dimension-free weighted commuting cover or approximate joint measurement of the slow modes; C5 did not find one.

## Costs, scope, and next decisive observation

The input channel and broadcaster are treated as exact supplied finite-dimensional maps. The commutator derivation itself has no dependence on dimension and makes no spectral-gap assumption. It is not an algorithm: tree receiver counts, POVM outcome counts, optimizer access, and precision are not made dimension-free by these estimates. The finite-dimensional tree comparator still pays logarithmic rank/dimension as recorded by c4.

The decisive next observation is either (i) a proof of the weighted all-frame joint-variance estimate retaining the individual \(e(A_i)\) profile and using one common POVM, or (ii) an admissible sequence \((\Phi_d,Q_d)\) with mean dual-frame energy tending to zero while every POVM leaves joint variance bounded below. The Pauli frame only refutes the commutator-only relaxation and does not meet (ii).

## Files and evidence

- Detailed derivations and the scoped Pauli counterexample: `work/agents/c5_quantum_almost_abelian/proofs/low_energy_commutator_and_gate.md`.
- Exact claim ledger, including status, assumptions, costs, falsifier, and next gate: `work/agents/c5_quantum_almost_abelian/CLAIMS.json`.
- Primary-source audit and versioned theorem pointers: `work/agents/c5_quantum_almost_abelian/sources/primary_sources.md`.
- N93 and broadcast-tree internal interfaces: `work/agents/quantum_physics/sources/N93-bounded-holevo-gates.txt`, `work/agents/broadcast_channel_attack/sources/detailed_balance_broadcast_attack.txt`, and `work/agents/c4_quantum_lift/FINAL_REPORT.md`.

Primary external references: [Bansil–Kachkovskiy, arXiv:2608.31000](https://arxiv.org/abs/2608.31000), [Glebsky, arXiv:1002.3082](https://arxiv.org/abs/1002.3082), and [Houdayer–Ioana, arXiv:2309.15029](https://arxiv.org/abs/2309.15029). Their results support the stated fixed-family/separable scopes; none supplies the desired all-family channel gate.

## Cycle 9 Weyl-invariant support slice

For Weyl-invariant positive duals in odd prime dimension, the full canonical-EB support is exactly the maximum pure-state Weyl quartic, because convexity bounds every mixed seed and a Weyl orbit of a maximizing pure seed has barycenter (I/d). The star/parity twirl makes the unrestricted top score a symmetric CP broadcaster with a unital HS-self-adjoint marginal; nonnegative HS transfer eigenvalues remain a separate gate. An exact all-dimension support inequality is now proved for (Q=\alpha I_{H_0}+\sum_{[g]\subset L}\beta_{[g]}P_{[g]}) on one commuting Weyl line, including the full-support one-mode perturbation. The general nonline weighted quartic comparison and N93 gate remain open; details are in [`cycle9_weyl_moment_gate/REPORT.md`](cycle9_weyl_moment_gate/REPORT.md).
