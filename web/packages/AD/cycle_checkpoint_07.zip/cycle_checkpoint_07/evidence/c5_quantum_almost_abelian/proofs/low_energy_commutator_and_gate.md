# Low-energy almost commutation and the missing common-measurement gate

**Status:** internal derivations and a scoped counterexample to a weaker shortcut; the requested dimension-free channel theorem remains UNKNOWN. All norms below use normalized trace unless marked otherwise.

## Interface

Let \(\Phi:M_d\to M_d\) be supplied exactly, unital, trace preserving, CPTP, Hilbert--Schmidt self-adjoint and positive as an operator on the real Hermitian Hilbert space, and self-compatible (a supplied CPTP two-output broadcaster has both marginals \(\Phi\)). Set \(G=I-\Phi\succeq0\), \(\tau=\operatorname{Tr}/d\), and

\[
e_\Phi(A)=\langle A,GA\rangle_\tau.
\]

The measurement target for a finite weighted Hermitian frame \((A_i,p_i)\), \(p_i\ge0,\sum_i p_i=1,\|A_i\|_\infty\le1\), is one POVM \(M\), hence one canonical EB map

\[
\Psi_M(X)=\sum_y \frac{\tau(M_yX)}{\tau(M_y)}M_y,
\]

whose *same* outcome space controls the whole frame. The relevant dual loss is

\[
q((A_i,p_i))=\inf_M\sum_i p_i\langle A_i,(I-\Psi_M)A_i\rangle_\tau.
\]

For the bounded-Holevo route this is the fixed-prior component of the max-prior joint-variance convex roof in N93; it is not the same as separately selecting an eigenbasis for each \(A_i\).

## Derivation: low Dirichlet energy forces pairwise near commutation

The supplied two-output broadcaster can be iterated on a full binary tree. The existing broadcast-tree calculation (see `work/agents/c4_quantum_lift/FINAL_REPORT.md`) gives, for Hermitian contractions \(A,B\) and every integer \(\ell\ge0\),

\[
\|[\Phi^\ell(A),\Phi^\ell(B)]\|_{2,\tau}
\le c_\ell:=\frac{2}{\sqrt{\ell+1}}+\frac{4}{\ell+1}.
\tag{1}
\]

Because \(\Phi\) is positive and self-adjoint on Hilbert--Schmidt space, its spectrum is in \([0,1]\). For an eigenvalue \(\lambda\in[0,1]\),

\[
(1-\lambda^\ell)^2\le 1-\lambda^\ell\le \ell(1-\lambda).
\]

Functional calculus therefore gives the actual displacement estimate

\[
\|A-\Phi^\ell(A)\|_{2,\tau}^2\le \ell e_\Phi(A).
\tag{2}
\]

Unital positivity makes \(\Phi^\ell\) an operator-norm contraction. With \(A_\ell=\Phi^\ell(A)\), \(B_\ell=\Phi^\ell(B)\), the identity

\[
[A,B]-[A_\ell,B_\ell]=[A-A_\ell,B]+[A_\ell,B-B_\ell]
\]

and \(\|[X,Y]\|_{2,\tau}\le2\|X\|_{2,\tau}\|Y\|_\infty\) yield

\[
\|[A,B]\|_{2,\tau}
\le c_\ell+2\sqrt{\ell e_\Phi(A)}+2\sqrt{\ell e_\Phi(B)}.
\tag{3}
\]

Write \(s=e_\Phi(A)+e_\Phi(B)\). If \(0<s\le1\), choose \(\ell=\lceil s^{-1/2}\rceil\). Then \(\ell\le2s^{-1/2}\), \(\ell^{-1/2}\le s^{1/4}\), and (3) gives the safe bound

\[
\|[A,B]\|_{2,\tau}\le 10s^{1/4}.
\tag{4}
\]

For \(s>1\), \(\|[A,B]\|_{2,\tau}\le2\le10s^{1/4}\). For \(s=0\), both matrices are fixed by \(\Phi\), and letting \(\ell\to\infty\) in (1) proves that they commute. Thus (4), including the zero case, is dimension-free.

For a weighted frame with mean energy \(\bar e=\sum_i p_i e_\Phi(A_i)\), Jensen gives the useful but weaker aggregate statement

\[
\sum_{i,j}p_ip_j\|[A_i,A_j]\|_{2,\tau}^{2}
\le100\sum_{i,j}p_ip_j(e_i+e_j)^{1/2}
\le100\sqrt{2\bar e}.
\tag{5}
\]

Equation (4) is stronger than (5) pair-by-pair. Neither is yet the sought one-measurement theorem.

## Counterexample to the commutator-only shortcut

Let \(H=(\mathbb C^2)^{\otimes n}\), \(d=2^n\), and take the \(2n\) Hermitian contractions

\[
\mathcal A_n=\{X_1,Z_1,\ldots,X_n,Z_n\},
\]

where \(X_i,Z_i\) are Pauli \(x,z\) on the \(i\)-th tensor factor and identity elsewhere. Put uniform prior \(p=1/(2n)\).

Only the ordered pairs \((X_i,Z_i),(Z_i,X_i)\) have nonzero commutator. Each has normalized-HS commutator norm 2. Consequently

\[
\sum_{a,b}p_ap_b\|[A_a,A_b]\|_{2,\tau}^2=\frac{2}{n}\longrightarrow0.
\tag{6}
\]

But every rank-one POVM is a pure-state ensemble of \(I/d\). For every pure state \(\psi\), the reduced state on qubit \(i\) has Bloch vector of norm at most one, so

\[
\operatorname{Var}_\psi(X_i)+\operatorname{Var}_\psi(Z_i)
=2-\langle X_i\rangle_\psi^2-\langle Z_i\rangle_\psi^2\ge1.
\]

Summing over \(i\), then averaging over any ensemble and dividing by \(2n\), shows

\[
q(\mathcal A_n,p)\ge\frac12.
\tag{7}
\]

Rank-one refinement can only improve the score, so (7) applies to the infimum over all POVMs. Thus no dimension-free modulus \(q\le f(\mathbb E_{i,j}\|[A_i,A_j]\|_{2,\tau})\), with \(f(t)\to0\), can hold for arbitrary weighted frames. This is **not** a counterexample to the channel target: the anti-commuting pairs force their endpoints to have nonvanishing Dirichlet energy under (4), and the mean channel energy cannot tend to zero in this example. It does show why replacing the channel-weighted all-frame problem by a bound on mean pairwise commutators is invalid.

## Exact random-bin calculation and its boundary

Fix Hermitian \(X\) with spectral decomposition \(X=\sum_a x_aP_a\). For width \(h>0\) and random offset \(u\sim\mathrm{Unif}[0,h)\), partition the real line into intervals \([u+kh,u+(k+1)h)\), and let \(\mathcal E_{X,h,u}\) be pinching onto the sum of spectral subspaces whose eigenvalues lie in each interval. In an eigenbasis of \(X\),

\[
\mathbb E_u\|Y-\mathcal E_{X,h,u}(Y)\|_{2,\tau}^{2}
=\sum_{a,b}\min\!\left(1,\frac{|x_a-x_b|}{h}\right)|Y_{ab}|^2
\le \frac{1}{h}\|[X,Y]\|_{2,\tau}\|Y\|_{2,\tau}.
\tag{8}
\]

The equality is the probability that a random bin boundary separates the two eigenvalues; the inequality is Cauchy--Schwarz applied to \(\sum |x_a-x_b||Y_{ab}|^2\). For a finite weighted frame, (8) gives one offset with small **weighted average block leakage**. If \(X\) itself is sampled from the frame, a second average and Cauchy--Schwarz yield a dimension-free bound in terms of its mean squared commutator.

The pinching range is the block-diagonal algebra \(\bigoplus_k B(P_kH)\), generally noncommutative. Refining the bins to rank-one projections inside each block is not controlled by (8): the residual commutator only controls cross-bin matrix elements, not within-bin noncommutativity. Iterating pinching can also make the observable/frame change and accumulate loss. This is the precise point where the standard random-bin proof for a fixed pair fails to produce one abelian measurement for the full growing frame.

## Actual uniform-range gate

The missing assertion can be isolated as a weighted one. Given any finite frame \((A_i,p_i)\) from the relevant low-energy range (or its power range) and energies \(e_i=e_\Phi(A_i)\), prove a dimension-free estimate

\[
q((A_i,p_i))\le \omega\!\left(\sum_i p_i e_i\right),
\qquad \omega(t)\xrightarrow[t\downarrow0]{}0,
\tag{9}
\]

with no dependence on \(d\), frame size, outcome count, or a minimum positive spectral gap. Stronger still, an operator-order comparator would give \(q\le c\bar e\), but (9) is the weaker experiment-specific gate. The dual quantifier is: for each frame and prior, choose one common POVM after seeing the entire frame; the desired bound is uniform over *all* frame sizes in a dimension and then over all dimensions/channels. Separate pairwise commuting approximants do not satisfy this quantifier.

Known fixed-tuple results do not yield (9) by netting the whole operator ball: a norm net has cardinality exponential in \(d^2\). Nor can one simply appeal to a commuting tracial-ultraproduct range. For any *fixed countable* family, an ultraproduct argument can show its selected elements commute, and separable subalgebra lifting results are scoped to separable subalgebras. The full coordinatewise range unit balls, tested with \(A_d\) chosen adversarially at every dimension, are an all-family/supremum quantifier. Pointwise lifting for every preselected sequence does not provide one sequence of coordinate POVMs with a uniform supremum bound.

The random-bin estimate (8), the pairwise channel estimate (4), and the tree comparison are compatible ingredients for a proof of (9); none alone controls the within-bin recursively generated frame or its one-measurement minimax. Parent's separate `c4_quantum_tree_prior` branch owns the weighted prefix/commuting-cover construction, so this note does not repeat it.

There is a direct conversion once the missing range approximation is available. If a masa \(D\subset M_d\) and its trace-preserving conditional expectation \(E_D\) satisfy

\[
\sup_{\|A\|_\infty\le1}\|T(A)-E_D(T(A))\|_{2,\tau}\le\varepsilon,
\tag{10}
\]

then \(S=E_D\circ T\) has commutative Heisenberg range, so its Schrödinger dual is measure-and-prepare (measure the minimal projections of \(D\), then prepare the corresponding states \(T_*(P_j)\)). Hence \(S\) is EB and

\[
\|T-S\|_{\infty\to1,\tau}\le\varepsilon,
\]

by \(\|Z\|_{1,\tau}\le\|Z\|_{2,\tau}\). This conversion charges no dimension factor but assumes the **supremum over the entire input operator unit ball** in (10). Controlling only a weighted average frame or only each preselected sequence does not establish (10).

## Source status and costs

All channel assumptions above are supplied mathematical objects. The finite-dimensional tree implementation assumes exact broadcaster calls; its receiver/outcome and precision costs are not made dimension-free by (4), (8), or the ultraproduct argument. The requested result is a mathematical existence/modulus statement in normalized trace norms, not an efficient algorithm claim. A solver or net certificate has no dimension-free value unless its frame-size dependence is explicit.

The conclusion of this file is a scoped rejection of the shortcut “small mean pairwise commutator implies small joint-measurement loss,” plus an internally derived slow-mode commutator estimate. The actual dimension-free EB conclusion remains UNKNOWN; no qualifying channel counterexample was found.
