# Robust generative biomolecular design under off-targets and uncertainty

**Research note for the biomolecular-design investigation**  
**Scope:** structure-conditioned protein-binder design; emphasis on a wet-lab discriminator and what finite evidence can guarantee. Literature checked 2026-10-08. The central recent example below is a September 2026 bioRxiv preprint, so its claims are primary evidence but not peer-reviewed evidence.

## Finding

Explicitly optimizing a binder against a named on-target and named off-targets can improve the chance of obtaining a desired interaction profile. It cannot, by itself, certify absence of unlisted off-target binding. A defensible guarantee is either (i) finite and assay-scoped—this candidate passed these named constructs, constructs, matrix, and concentration conditions—or (ii) distributional, conditional on a stated sampling distribution over off-target contexts, exchangeability, and a lower bound on assay sensitivity. Without one of those scope assumptions, a universal “no off-targets” claim is unidentifiable from finite assays.

A practical discriminator is therefore a **paired challenge-panel assay**: measure expression-normalized binding to the intended target and a prespecified panel of plausible competitors in the same assay format; confirm surviving leads with purified-protein, concentration-series BLI/SPR (or an appropriate cell-surface functional assay). Report the tested panel and detection limit, and preserve “unknown outside panel” as a separate status. Structure predictors can prioritize and optimize the panel, but are not the discriminator.

## Formal finite-panel no-go and conditional guarantee

Let \(U\) be the universe of possible off-target contexts and let a wet assay query a finite panel \(P=\{o_1,\dots,o_m\}\subset U\). Assume no certified rule relates binding to unqueried contexts to binding on \(P\). An experiment returns a finite transcript \(z\) of results on \(P\). For any transcript in which a candidate appears specific, there are two binding worlds consistent with \(z\): one in which it binds no member of \(U\setminus P\), and one in which it binds some unqueried \(o^*\in U\setminus P\) above the failure threshold. These worlds are observationally identical on all queried assays. Consequently, no nontrivial distribution-free procedure can infer universal specificity from those finite data. It can soundly certify only the tested panel (under assay validity), or a broader claim after adding assumptions that constrain or sample the untested universe.

A useful broader statement is possible under a declared random-off-target model. Let \(Q\) be a fixed distribution over the biologically relevant off-target contexts; let \(p\) be the probability under \(Q\) that a random context truly crosses a prespecified binding threshold; draw \(n\) independent contexts from \(Q\); and suppose a true cross-binder is detected with probability at least \(s\) in the specified assay. If no hits are detected, then

\[
\Pr(0\text{ detected}\mid p)\le (1-sp)^n,
\qquad
p_{U}(1-\alpha)=\min\!\left(1,\frac{1-\alpha^{1/n}}{s}\right).
\]

Thus, with one-sided confidence \(1-\alpha\), \(p\le p_U\), conditional on iid/exchangeable sampling and the sensitivity floor. At 95% confidence and \(s=0.9\):

| Random off-target contexts tested, all negative | Upper bound on cross-binding prevalence under Q |
|---:|---:|
| 20 | 15.46% |
| 100 | 3.28% |
| 332 | 1.00% |

The count is **distinct sampled off-target contexts**, not replicate wells or candidate binders. With perfect sensitivity, 299 iid negative contexts are needed for a 1% upper bound at 95% confidence. If the panel is deliberately enriched for homologs or selected by experts, it is a challenge panel rather than an iid sample from \(Q\); this prevalence calculation does not apply. In that case report individual panel outcomes only. If sensitivity varies with the target construct or assay format, a single \(s\) is not justified until calibrated against known binders near the threshold.

### Exact finite-panel statement

For a fixed panel and defined endpoint, let \(B_j(c)\) be assay binding signal for off-target \(o_j\) at concentration \(c\), and let \(\tau_j\) be a prespecified failure threshold. A panel pass can be stated as:

- on-target: lower simultaneous confidence bound exceeds its minimum functional/binding threshold;
- for each \(j\le m\): upper simultaneous confidence bound for \(B_j(c_{max})\) is below \(\tau_j\), or, when a titration is performed, lower bound for \(K_{D,j}/K_{D,on}\) exceeds a prespecified selectivity ratio;
- controls show the assay detects known binding at the relevant boundary and controls for display/expression, tag, matrix, and nonspecific adhesion.

Simultaneous coverage matters: to retain familywise error at \(\alpha\) over \(m\) off-target decisions, one simple conservative approach uses per-target one-sided error \(\alpha/m\) (adjust also for the on-target decision). A one-concentration negative screen certifies the operational statement “below this assay’s detection threshold at this concentration” only; converting that result to a \(K_D\) lower bound needs a validated binding model and a titration. The assay should keep the endpoint, uncertainty, construct identity, and concentration attached to the result.

## A primary-source stress test: specificity and cross-reactivity in Odin-Multi

The recent Odin-Multi preprint optimizes one shared binder sequence using attractive objectives for on-target contexts and repulsive objectives for specified off-targets. The design contexts are predicted independently, then their gradients are combined; this is a candidate-generation objective, not a statistical binding guarantee.

- **pMHC specificity benchmark:** on-target NY-ESO-1 SLLMWITQC/HLA-A*02:01 and near-neighbor off-target SLLAWITQC/HLA-A*02:01 (M4A), differing at one peptide residue (reported 99.6% overall sequence identity; complex Cα RMSD 0.23 Å). At an illustrative target-qualified iPTM ratio cutoff 2.5, 57/400 (14.2%) counter-selected designs versus 24/400 (6.0%) target-only designs passed. The cutoff was post hoc; the prespecified comparison of the full yield curves had Holm-adjusted global permutation \(P=0.00070\). On independent AF3 re-evaluation, the analogous 2.5-cutoff rates were 59/400 (14.8%) versus 38/400 (9.5%); the whole-curve adjusted result was \(P=0.0612\), so the second-model separation was not conventionally significant at 0.05.
- **Wet discriminator:** a pooled set of 500 designs (166 target-only, 167 CMV-counter-selected, 167 M4A-counter-selected) was displayed on CD3-knockout Jurkat cells. Cells were stained with pMHC tetramers and sorted into positive/negative bins; sequencing enrichment chose 20 individual clones for follow-up. The clones were checked for target and off-target tetramer staining; S2 from the M4A-counter-selected group showed greater target/M4A discrimination than the NY1-B04 prototype under the same tetramer-staining assay. The other two M4A-group follow-up clones had only modest discrimination. This is evidence of one successful lead and a useful challenge assay, not a calibrated general success rate: only the top 20 were individually characterized, and the M4A condition supplied three of those.
- **Scope limitation:** the named M4A variant is a stringent near-neighbor; CMV pMHC adds a dissimilar peptide control. These tests do not span the human immunopeptidome, all HLA contexts, or cell killing against healthy tissues. Tetramer MFI is an avidity/display endpoint, not monomeric solution \(K_D\), receptor occupancy in vivo, or functional safety. The paper's structure-based explanation for S2 is a hypothesis based on the target-bound predicted structure; it does not establish the M4A complex geometry.
- **Cross-reactive toxin case:** the same preprint reports a dual short-chain three-finger-toxin minibinder. The intended targets shared 68.9% sequence identity. Joint optimization raised the in-silico fraction exceeding iPTM 0.5 for both targets from 3/400 (0.8%) to 37/400 (9.2%). Thirty AF3-filtered designs were cloned, expressed, and purified; 24 expressed above empty-vector negative-control yield. DELFIA at 200 nM compared Erabutoxin A, Naja pallida short neurotoxin 1, Naja kaouthia whole venom, and a block-only control. One lead (Poly_5) showed target-associated signal; another (Poly_30) bound even the block control, exposing nonspecific stickiness. Purified NK-shNTx had become unavailable, so the experiment substituted the 85.2%-identical Naja pallida homolog and a candidate Naja kaouthia venom fraction. BLI then tested six twofold concentrations (12.5–400 nM) against Erabutoxin A and the candidate fraction; the two-component fits gave higher-affinity components of 11.95 and 34.43 nM. Because fraction 3 was not sequence-confirmed as pure NK-shNTx, the result is binding to a toxin-containing fraction, not a clean direct affinity measurement to the exact design off-target.
- **Important implication:** both cases show that explicit negative design can surface a specific desired profile, but they also show why the assay’s molecular identity and panel scope must be stated. The computation is context-specific; hidden contexts remain unknown.

## Cost and resource accounting from the primary methods

### Computation (Odin-Multi pMHC campaign)

The preprint reports median trajectory times on matched V100 hardware: 20.2 minutes for one context and 59.3–61.5 minutes for three contexts. Three contexts therefore cost about 2.94–3.04 times more per trajectory, consistent with near-additive context evaluation. On T4 hardware, three-context trajectories took 158.1–158.7 minutes, about 2.6 times the V100 time.

The M4A counter-selected campaign required 1,700 trajectories to assemble its screened candidate set, compared with 203 target-only trajectories. Multiplying reported counts by median V100 times gives rough design-stage compute of **about 1,680 V100 GPU-hours** (1,700 × 59.3 min) versus **68 V100 GPU-hours** (203 × 20.2 min), a roughly **24.6× total compute** increase for this campaign. This estimate covers only those reported trajectory runtimes; it excludes AF3 post-evaluation, filtering, orchestration, and failed infrastructure runs. It is a real yield cost as well as a per-trajectory cost: only 3 designs from the M4A-counter-selected set appeared among the 20 pooled-screen follow-ups, versus 11 target-only designs, although the experiments do not establish that this difference is caused solely by specificity optimization.

### Wet lab

The pMHC case used an oligo pool for 500 designed binders, lentiviral mammalian display in a 2 × 10^6 CD3-knockout Jurkat-cell input, pooled tetramer staining/FACS plus sequencing, then individual characterization of 20 clones. Per-clone specificity checks covered the target, M4A, and CMV pMHCs; matched controls included transduction/expression marker, live-cell gating, fluorescence-minus-one controls, and untransduced cells. Reported costs are in constructs, cells, sorting conditions, and clone follow-ups; the paper does not report monetary cost.

The toxin case scaled more expensively per hit: 30 designs were cloned, expressed, and purified for individual DELFIA screens; a lead was then purified at larger scale and assessed by SEC and BLI. The BLI panel itself used six concentrations over a twofold series for each of two ligand preparations, plus buffer subtraction. These numbers provide a concrete staged-cost pattern: use pooled display to shortlist, then pay for purified material and kinetic curves only for a few survivors.

An earlier parallel yeast-display study supplies throughput costs for a broad panel screen. It evaluated a 615-protein design pool against multiple targets; the protein-interaction panel included seven unrelated proteins. Its method used a 5 × 10^6-cell yeast library, screened at least 200× library size for coverage (at least 10^9 cell observations per selection by direct multiplication), and found that 20–30 sequencing reads per library member were needed to stabilize enrichment estimates. This demonstrates feasible panelized screening, but it also makes clear that assay/sequence resources scale with library size, target conditions, and coverage; hundreds of constructs are not equivalent to exhaustive proteome coverage.

No source examined reports a universal dollar cost for this workflow. Avoid inventing one. A useful accounting vector is: design trajectories × contexts × GPU-time; library size and synthesis/cloning; cells or phage screened × target conditions; sequencing depth; number of purified survivors × off-targets × concentration points × replicates; and the cost of acquiring correctly folded, relevant off-target constructs.

## Proposed decision rule for a research claim

1. **Name the claim before optimization.** Choose an explicit threshold such as target binding and at least 100-fold weaker binding to each named high-risk paralog, or assay signal below a validated threshold at a physiologically justified concentration. For therapeutic claims, separate affinity specificity from cellular functional selectivity.
2. **Choose the panel as a challenge set.** Include the nearest sequence/structure homologs and known pathway competitors, plus representative abundant/matrix or “sticky” controls. For peptide-MHC binders, add motif-neighbor peptides and relevant naturally presented candidate peptides. Document how the panel was chosen; do not call it representative unless a sampling frame supports that claim.
3. **Use uncertainty to select experiments.** Rank designs using on/off-target multi-context scores and model disagreements, but expose candidates where predictors disagree. Wet-test those high-uncertainty cases along with top-scoring candidates and controls. This uses computation to prioritize uncertainty rather than treating a high score as confidence.
4. **Use a staged discriminator.** First use expression-normalized pooled display with target and each off-target condition, recording full enrichment and negative-control distributions. Then test a small set of individually expressed/purified candidates by BLI/SPR across a concentration series (or cell-surface functional assay for pMHC/receptors). Confirm construct sequence, folding, and assay sensitivity near the decision threshold.
5. **Make the output three-valued.** `PASS(panel, assay, threshold)`; `FAIL(panel, assay, threshold)`; `UNKNOWN(outside panel / assay sensitivity / construct mismatch)`. A clean panel pass is not `no off-targets`.

The scientific opportunity is to measure whether multi-context generative optimization improves the rate of **assay-confirmed** specificity at a fixed total experimental budget, against an equally informed target-only baseline with the same candidate synthesis and discriminator panel. The result should be a yield-vs-compute-and-assay-cost curve, with independent targets and a held-out challenge panel; the guarantee above supplies the appropriate claim endpoint.

## Claim ledger

| Claim | Status | Evidence / limit |
|---|---|---|
| Multi-context design can increase the number of computational candidates scoring for a desired target/off-target profile. | Source-reported and computationally tested | Odin-Multi reported this for toxin, GPCR, and pMHC cases; metric thresholds and predictors are not wet binding. |
| Explicit off-target optimization can produce at least one experimentally discriminating pMHC binder. | Experimentally demonstrated in one campaign | S2 compared with NY1-B04 by tetramer staining; one lead, bounded named panel. |
| A specific candidate has no relevant off-target binding throughout a proteome or organism. | Not established; distribution-free finite-assay guarantee is impossible | Requires a complete fixed universe, certified structural coverage assumption, or explicit Q/sampling/sensitivity assumptions. |
| Zero cross-hits in n iid assays bounds prevalence under Q. | Derived conditional guarantee | Bound is \((1-\alpha^{1/n})/s\), capped at 1; only if Q, exchangeability, and sensitivity lower bound hold. |
| The toxin Poly_5 has measured 11.95/34.43 nM KD to both pure intended toxins. | Not supported as written | Reported BLI uses Erabutoxin A and a candidate mixed venom fraction, with two-component 2:1 fits; exact NK-shNTx identity was unavailable. |

## Primary sources

1. Brasas et al., **“Specificity-driven protein binder design with Odin-Multi,”** bioRxiv preprint posted 2026-09-09, DOI [10.64898/2026.09.08.749745](https://doi.org/10.64898/2026.09.08.749745). Full primary source: [bioRxiv](https://www.biorxiv.org/content/10.64898/2026.09.08.749745v1.full).
2. Lourenço et al., **“Protein CREATE enables closed-loop design of de novo synthetic protein binders,”** primary article in PMC, [PMC11722223](https://pmc.ncbi.nlm.nih.gov/articles/PMC11722223/); preprint DOI [10.1101/2024.12.20.629847](https://doi.org/10.1101/2024.12.20.629847). Demonstrates phage-display/NGS quantitative screens over thousands of candidates, parallel positive/negative selections, and imperfect iPTM prediction.
3. Dou et al., **“Parallelized identification of on- and off-target protein interactions,”** *Molecular Systems Design & Engineering* (2020), DOI [10.1039/C9ME00118B](https://doi.org/10.1039/C9ME00118B); full text [PMC8903191](https://pmc.ncbi.nlm.nih.gov/articles/PMC8903191/). Methods and results for yeast-display multiplex panels, expression normalization, sequencing coverage, and discovery of unintended binding.
4. Saksena et al., **“Computational counterselection identifies nonspecific therapeutic biologic candidates,”** *Cell Reports Methods* 2(7), 100254 (2022), DOI [10.1016/j.crmeth.2022.100254](https://doi.org/10.1016/j.crmeth.2022.100254); full text [PMC9308162](https://pmc.ncbi.nlm.nih.gov/articles/PMC9308162/). Computational polyspecificity screening and validation using cross-target selection and individual Octet binding assays.
5. Householder et al., **“De novo design and structure of a peptide-centric TCR mimic binding module,”** primary source [PMC11702606](https://pmc.ncbi.nlm.nih.gov/articles/PMC11702606/). Useful independent experimental context: 9.5 nM NY-ESO-1/HLA-A*02 affinity by SPR, no detectable affinity to MART-1/HLA-A*02 in the tested assay, and subsequent structure-guided candidate off-target-peptide probing. Its tested peptide set remains distinct from a proteome-wide absence claim.

## Web research pointers used in preparing this note

- Odin-Multi primary text and figures surfaced through bioRxiv searches: the pMHC target/off-target benchmark, candidate counts, AF3 re-evaluation, BLI/DELFIA methods, runtime/campaign totals, and limitations.
- Protein CREATE source gave the phage sequencing readout, target/off-target screens, pseudo-Kd, and orthogonal Bioplex/SPR follow-up.
- Dou et al. source gave the yeast-display panel, library size/oversampling, sequencing coverage, and the case where a design's off-target interactions would have been missed by target-only screening.
