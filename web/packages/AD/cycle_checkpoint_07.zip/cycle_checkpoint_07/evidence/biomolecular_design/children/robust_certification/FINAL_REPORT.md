# Robust biomolecular design: RNA sensor under sequence, structure, and assay shift

## Recommendation

Use a **pan-Dengue translational RNA sensor** as the test case, but do not claim novelty for sequence breadth by itself. A 2026 primary study already reports three toehold sensors whose trigger sequences cover about 99.4% of the Dengue virus (DENV) genomes in its sequence collection, across all four serotypes. The defensible gap is whether one frozen sensor still works when its target is embedded in native genomic RNA and the reaction environment moves over a declared range. The new claim should be an experimentally scoped robustness certificate over a held-out genotype/context distribution, with long-range native RNA and direct kinetic output as stress tests.

This is a candidate experiment, not a result. The most important novelty gate is whether the finite-panel certificate adds enough to the existing 2026 pan-DENV paper to merit a new scientific claim. The likely advance is an operational robustness certificate and a mechanism test, not a new general principle of RNA folding.

## Exact candidate claim

Freeze a single toehold/riboregulator sequence S before generating the test panel. Let D be a pre-registered, equal-serotype mixture over phylogenetic clusters of public DENV-1–4 genomes, with the sequence corpus and cluster frame frozen by date. A draw from D supplies a 36-nt trigger haplotype and its native 150-nt upstream and downstream sequence context. Use disjoint cluster sets for candidate development and blind evaluation. The challenge panel consists of 59 independent draws with replacement from the held-out cluster distribution D, plus four full-length genome RNA sentinels (one per serotype).

Test the same sensor/target constructs in a crossed 3-temperature by 3-magnesium cell-free transcription/translation grid. Set the magnesium levels as 0.8, 1.0, and 1.2 times the standard reaction level in a pilot; use 30, 37, and 42 °C. Use six independent reaction-preparation days as the initial replication plan, revising that count upward before unblinding if pilot variance says it is needed. Supply the same post-amplification-equivalent target copy count to every reaction, initially (10^{13}) copies per reaction to match the published DENV sensor challenge scale.

The frozen sensor passes a sequence-context draw only if, in **every one of the nine conditions**, a pre-registered simultaneous one-sided 95% confidence analysis supports all three requirements at the 60-minute readout:

1. (F_{ON}/F_{OFF} \ge 10).
2. (F_{ON} \ge 0.25F_{constitutive}).
3. (F_{OFF} \le 0.05F_{constitutive}).

Here fluorescence is blank-corrected; the OFF denominator uses a pre-specified assay floor if it is below quantification. Report the entire 0–120 minute trace, including time-to-half-max, because endpoint-only ratios can hide transient activation or delayed leakage. Each of the four full-length serotype RNA sentinels must pass the same function criteria in all nine conditions.

If all 59 independently sampled sequence-context draws pass, the exact zero-failure binomial bound gives a one-sided 95% upper confidence limit of (1-0.05^{1/59}=4.95\%\) on the failure probability **under this declared distribution (D)**. This is the uncertainty guarantee. It says nothing about arbitrary future Dengue evolution, sample-preparation variation outside the tested grid, clinical sensitivity, or other viruses.

The test concentration is deliberately matched to the published trigger assay. It isolates folding and switching robustness; it does not establish a low limit of detection. Sensitivity and clinical matrix validation are separate gates.

## Why this is the right stress test

The latest direct prior art found 61 trigger pools present in more than 96% of genomes of each DENV serotype and tested 21 candidate sensors. Three chosen sensors each covered nearly 99.4% of genomes by sequence and tested representative synthetic triggers with up to three mismatches. But the experiment tests trigger fragments, generally at (10^{13}) copies; it does not certify function across native full-genome contexts or reaction-condition uncertainty. The paper itself states that the target region falls inside a known 5′–3′ long-range genomic RNA interaction, that no single NASBA primer pair covers the diversity, and that patient-sample efficacy and the true sensor limit of detection remain untested.

This makes the core physical risk unusually clear: sequence mismatch tolerance does not imply target accessibility. A target that is accessible as an isolated 36-mer can be sequestered by the rest of the genomic RNA. The functional test should therefore compare each short trigger with its flanked context, and compare those contexts with full-length genomic RNA from all four serotypes.

Current toehold work also makes equilibrium-only design an insufficient certificate. The 2026 Toehold-VISTA study reports reduced activation with full-length versus truncated target RNA and shows that flanking target context changes the observed separation of sensor outputs. A separate 2026 riboregulator study tested 100 designs in one fixed reporter/linker/cell-free context and reports that folding kinetics and RBS accessibility matter alongside thermodynamic stability. Accordingly, partition-function calculations should help select candidates, but only the held-out TX-TL measurements certify this claim.

## Design and certificate procedure

1. **Acquire the sequence frame.** Download public DENV genome sequences available at a frozen date; cluster by phylogeny; retain a documented list and hash. Define D as equal weight across serotypes and then equal weight across clusters in the held-out frame. Use a disjoint development frame to design and select S. After the candidate is frozen, draw 59 independent samples with replacement from the held-out D frame.
2. **Design against physical margins.** Screen 96 candidate sequences around a chosen riboregulator scaffold. Use partition functions to score (i) RBS sequestration without target and (ii) target-bound RBS accessibility over the 3×3 environmental grid and the development contexts. Use co-transcriptional kinetic simulation as a secondary filter. Do not treat either simulation as experimental proof. Pilot the environmental grid on constitutive controls before candidate selection; lock it before seeing candidate results, and require constitutive output to remain measurable in every condition.
3. **Freeze before challenge.** Publish the selected sequence, analysis code, condition grid, target distribution, reporter, target concentration, fluorescence thresholds, and confidence procedure before revealing the 59 test contexts.
4. **Run functional assays.** Measure ON, OFF, constitutive, no-sensor, and unrelated-target controls in independently prepared cell-free batches. Include the published sensor 3 as the matched positive control and a canonical VISTA/NUPACK toehold design as an equally informed design baseline where sequence/target compatibility permits.
5. **Map the mechanism on sentinels.** For a small prespecified subset (e.g. two contexts per serotype plus the four full-length sentinels), perform DMS-MaPseq or SHAPE-MaP with and without sensor at the nominal and worst-performing condition. This checks whether low activation follows target occlusion or an unexpected translation effect; it is diagnostic, not part of the 95/95 guarantee.
6. **Decide without reuse leakage.** If any test draw misses a functional threshold, report the certificate as failed. Any redesign gets a new sequence freeze and a newly sampled challenge panel; do not reuse the failed held-out set as the next acceptance set.

### Falsifier

The decisive falsifier is a blinded native-context challenge. If the 36-nt synthetic trigger passes but its 300-nt flanked version or full-length serotype genome drops below 10-fold induction in even one environmental condition, the frozen robustness claim fails. The most informative first experiment is the paired short-trigger/full-length comparison for DENV-2 and DENV-3 at the low-magnesium/high-structure corner, because the published target lies in the 5′–3′ long-range interaction and the existing work did not test patient samples or full genomic RNA.

Also run unrelated human, SARS-CoV-2, and Zika RNA as false-trigger controls, and test the existing pan-DENV sensor 3 on exactly the same blinded panel. If sensor 3 passes the same condition/context certificate, the proposed new design has not improved on prior art even if it works.

## Cost and acquired information

The following are planning counts, not vendor quotes.

- **Sequence acquisition:** public DENV sequences and nearest-neighbor RNA-folding software; no paid data oracle. Inputs that must be acquired are the actual sequence corpus, cluster assignments, and target-context panel. Keep a date-stamped manifest and do not imply that sequence coverage alone is a functional certificate.
- **Design computation:** 96 candidate sequences × 59 development-frame contexts × 9 condition points is 50,976 partition-function evaluations at approximately 300 nt per construct. A secondary kinetic screen of the top 8 sequences over 12 representative development contexts, 3 condition points, and 100 trajectories is about 28,800 folding trajectories. These are bounded CPU workloads; actual runtime depends on software/version and hardware and should be recorded on execution. The 59 held-out validation draws must not be used for selection.
- **Candidate down-select:** screen 96 candidate switches against one development-frame 36-nt trigger at nominal temperature and magnesium, with target/no-target states in three independent preparations: 576 TX-TL wells, plus controls. This is an explicit screen budget, not evidence that 96 designs suffice.
- **Primary functional panel:** 59 blind sequence-context draws × 9 condition points × 2 states (target/no target) × 6 independent reaction preparations = 6,372 TX-TL wells. Four full-length serotype sentinels add 432 wells. At 5 µL per well this is 34 mL before controls. Budget roughly 15% additional wells for controls and failed wells, giving about 7,825 wells (about 39 mL; roughly 21 384-well plates). Add the 576-well candidate screen for an initial total of about 8,401 wells (42 mL; about 22 plates), excluding structure-mapping libraries. If the pilot variance requires more than six preparations, scale the certificate panel linearly.
- **Sequence constructs:** 96 candidate sensor templates; 59 held-out 336-nt target contexts (about 19,800 target nucleotides total); one 36-nt development trigger for candidate screening; and four full-length genomic RNA sentinels. Use in vitro transcription from verified DNA templates where possible, and budget genome-RNA preparation as a distinct acquisition rather than including it in the short-construct count.
- **Readout:** 60-minute threshold plus 0–120-minute time course; at 30-second sampling the 6,804 primary and sentinel wells produce about 1.64 million fluorescence/time observations before controls, and approximately 1.89 million including the 15% control allowance. This is modest data volume; raw traces and plate/batch metadata matter more than compute.
- **Mechanism subset:** 12 flanked contexts plus four full-length sentinels × 2 probe states × 2 condition points × 3 replicates = 192 structure-probing reactions/libraries. Targeted sequencing cost is run-dependent and should be reported as library count and reads per construct, not guessed here.
- **Replication planning:** six independent reaction preparations is only a starting point. Estimate the SD of log fold-change in an initial blinded pilot, then choose (r) from a pre-registered power calculation for the simultaneous condition-wise margin. Do not count repeated fluorescence time points or repeated wells from one preparation as independent biological replicates.

## Strongest prior-art attack and novelty boundary

### Direct pan-DENV predecessor

Nandakumar et al. (2026), *Genomic diversity analysis enables development of pan-Dengue Toehold RNA sensors*, is the load-bearing prior-art attack. It directly demonstrates broad sequence recognition across four serotypes; it tested 13 triggers for sensor 3 and 16 triggers for sensors 6 and 7, and used genome frequency to estimate approximately 99.4% coverage. It also reports the real limitations that motivate this proposal: the chosen trigger is in a 5′–3′ interaction region, the sensor itself has a high direct-input requirement (about (10^{12})–(10^{13}) copies), amplification requires multiple primer pairs, and patient samples/true LOD are still open. Therefore, **“pan-DENV sensor,” “tolerates up to three mismatches,” and “covers 99% of strains” are not novelty claims available to us.**

### Context and kinetics predecessors

Robson & Green (2026), *Toehold-VISTA*, provides the closest context-aware computational comparator. It experimentally tested roughly 200 sensors tiled along a structured mCherry RNA, compared truncated target segments with full-length RNA, and found reduced activation for the full target. It uses physical sequence/structure features plus a predictive model. This preempts the claim that target RNA folding context was ignored in the field. It does not supply a worst-case finite-panel certificate over native viral contexts and condition shifts.

Robson, Moussas, Francis & Green (2026 preprint), *Crowdsourced riboregulators reveal design principles for programmable RNA switching*, provides a strong kinetic/mechanistic comparator: 100 diverse designs, 3 biological replicates per design, up to 80-fold activation, and analysis of RNA folding kinetics and RBS accessibility. Tests used a fixed reporter/linker and 37 °C. This preempts novelty based on “kinetics matter” or “noncanonical structures can work.” Because the retrieved record is a bioRxiv preprint, its findings remain source-reported rather than peer-reviewed evidence.

The original Green et al. (2014) toehold-switch paper remains a required baseline: 26 orthogonal switches and average dynamic range above 400-fold under its tested design/culture conditions. This makes it inappropriate to sell a high fold-change alone as an advance.

### What remains potentially new

The combined **pre-registered, joint sequence-context × reaction-condition certificate**, with (i) a stated failure-probability bound under a frozen genotype/context distribution, (ii) measured response rather than predicted fold, and (iii) native full-length genome sentinels, is not shown in the primary studies reviewed here. That statement is a scoped gap assessment, not proof of priority. The first expert search should specifically check for later DENV sensor work with full-genome/clinical testing and for robust-condition certificates in RNA diagnostics before any priority claim.

## Evidence status and unresolved points

- **Established external:** 2026 papers report broad pan-DENV sequence coverage, structure/context effects, and kinetic effects as cited below.
- **Candidate:** the exact 95/95 operational claim above has not been tested.
- **Main unresolved mechanism:** whether accessibility loss is dominated by stable long-range DENV folds, transient cotranscriptional traps, or TX-TL translation chemistry. The paired short-trigger/flanked/full-genome assay plus structure probing distinguishes these explanations.
- **Scope boundary:** even a passing certificate applies only to the declared DENV sequence distribution, 9 cell-free conditions, reporter, and input copy count. It is not a clinical validation, does not bound arbitrary future variants, and does not establish diagnostic sensitivity.
- **Priority:** unverified. It is important that a 2026 protein route aimed just at SARS-CoV-2 KP.3/Q493E is already preempted by structure-guided nanobody evolution, so the RNA/context route is the stronger candidate from this search.

## Primary sources

1. Nandakumar et al., “Genomic diversity analysis enables development of pan-Dengue Toehold RNA sensors,” *PLOS Neglected Tropical Diseases* (2026), [article](https://doi.org/10.1371/journal.pntd.0014173). Primary evidence for 99.4% genome-sequence coverage, mismatch tolerance, 21→3 sensor screen, high direct-input requirement, long-range target context, primer-pair challenge, and absent patient-sample/true-LOD validation.
2. Robson & Green, “Toehold-VISTA: a machine learning approach to decipher programmable RNA sensor-target interactions,” *Nucleic Acids Research* (2026), [article](https://doi.org/10.1093/nar/gkag097). Primary evidence that target structure/context changes activation and is included in current sequence/structure-aware design.
3. Robson, Moussas, Francis & Green, “Crowdsourced riboregulators reveal design principles for programmable RNA switching,” bioRxiv preprint (2026), [preprint](https://doi.org/10.64898/2026.07.08.737257) and [PMC record](https://pmc.ncbi.nlm.nih.gov/articles/PMC13370501/). Source-reported evidence for diverse riboregulator structures, up to 80-fold activation, and kinetic effects under a fixed cell-free context; not peer reviewed as of this retrieval.
4. Green et al., “Toehold switches: de-novo-designed regulators of gene expression,” *Cell* (2014), [article](https://doi.org/10.1016/j.cell.2014.10.002). Primary baseline for orthogonality and high dynamic range.
5. Bu et al., “Update and reuse: Structure-guided nanobody evolution against SARS-CoV-2 escape,” *PLOS Pathogens* (2026), [article](https://doi.org/10.1371/journal.ppat.1014223). Used only to reject the stale alternative that would claim novelty from repairing the KP.3/Q493E gap in a coronavirus binder.
