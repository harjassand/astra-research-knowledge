# Folding-landscape result: single-decoy gaps cannot certify specificity

**Claim status.** Exact theorem under a Boltzmann ensemble; the no-go is a direct indistinguishability construction. This is a principled, scoped result, not a novelty claim: the free-energy identity is standard statistical mechanics, and prior protein-design work already motivates landscape-aware/negative design. The contribution here is to make the certification requirement and its missing-state failure explicit for inverse folding.

## Exact statement

Fix a sequence, environment, and temperature. Partition its conformations into a desired target basin `A` and all off-target states `B`. Let

`Z_A = sum_{x in A} exp(-E(x)/kBT)`, `Z_B = sum_{x in B} exp(-E(x)/kBT)`, and `DeltaF = F_B - F_A = -kBT log(Z_B/Z_A)`.

Then the equilibrium target-basin occupancy is exactly

`p(A) = 1 / (1 + exp(-DeltaF/kBT))`.

Consequently, `p(A) >= 1-delta` **iff** `DeltaF >= kBT log((1-delta)/delta)`. If an estimated free-energy gap `DeltaF_hat` has a certified absolute error at most `2 epsilon` (for example, each basin's free energy is individually within `epsilon`), the sufficient robust condition is `DeltaF_hat >= 2 epsilon + kBT log((1-delta)/delta)`.

This exposes what a target-vs-one-decoy minimum-energy gap omits. If there are `K_A` target microstates and `K_B` off-target microstates at respective energies `E_A` and `E_B`, then

`p(A) = 1 / (1 + (K_B/K_A) exp(-(E_B-E_A)/kBT))`.

Thus for 95% target occupancy at 298 K, the free-energy margin must be at least `kBT log(19) ~= 1.74 kcal/mol`. With one target microstate and 100 equal-energy off-target microstates, the *per-state* target energy advantage must instead be at least `kBT log(1900) ~= 4.46 kcal/mol` (about 7.5 `kBT`). With a certified 1 kcal/mol error per basin, the corresponding sufficient predicted gap is 6.46 kcal/mol.

## Scoped no-go

Any method that observes a target and finitely many decoys but has no upper bound on unobserved Boltzmann mass cannot certify a positive lower bound on target occupancy from those observations alone. Proof: it suffices to take a one-conformation target with energy zero, keep every queried conformation and score fixed, then add `L` unqueried off-target conformations at energy `g`. Write `C` for the fixed finite partition mass of the target plus all already represented off-targets; the method receives the same transcript, while target occupancy becomes `1/(C + L exp(-g/kBT))`, which tends to zero as `L` grows. A minimum-decoy gap, structural confidence score, or finite decoy search therefore is not a certificate unless paired with a completeness/tail-mass bound, a partition-function/free-energy bound, or an explicit model assumption controlling the omitted states. This is not a no-go for design; it is a no-go for such finite evidence implying an ensemble guarantee.

## Primary evidence and its scope

- Norn et al. analyzed 4,204 Foldit designs with tens of thousands of ab-initio decoys per sequence. Their `P_near` is explicitly a Boltzmann-weighted target-nearness statistic (with fuzzy nativeness cutoff). trRosetta classified high- versus low-`P_near` designs at AUC 0.81 versus Rosetta target-energy AUC 0.65, and the authors report that target probability is diluted when multiple low-energy minima exist. The analysis is still based on biased, nonexhaustive sampling and an imperfect energy function, as the paper says; it supports the mechanism, not a rigorous physical occupancy certificate. DOI: [10.1073/pnas.2017228118](https://doi.org/10.1073/pnas.2017228118), [full paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC7980421/).
- The same study used a high-throughput protease-resistance assay on 16,174 prior miniproteins plus 13,985 new beta-sheet designs (30,159 total) and found predicted target probability separated stable from unstable designs. This is stability evidence, not a direct measurement of equilibrium population over every conformational basin.
- The Top7 follow-up combined stopped-flow kinetics, CD, and NMR and found at least three kinetic phases, an equilibrium-stable nonnative conformation, and stable isolated fragments. Top7 was originally designed around the target structure and achieved a crystal structure within 1.2 Å RMSD, illustrating why structural success and smooth/unique landscapes are distinct claims. Sources: [Cell 2007, DOI 10.1016/j.cell.2006.12.042](https://doi.org/10.1016/j.cell.2006.12.042); [Science 2003, DOI 10.1126/science.1089427](https://doi.org/10.1126/science.1089427).
- In SspB dimer redesign, positive-only optimization yielded a more stable design that formed both homodimer and heterodimer, while explicit negative design yielded an almost homogeneous heterodimer at lower stability. That is direct experimental evidence that target stability and specificity are distinct objectives when competing states are structurally close. [Bolon et al., PNAS 2005, DOI 10.1073/pnas.0506124102](https://doi.org/10.1073/pnas.0506124102).

## Decisive next test and accounting

Use the public Norn/Rocklin design records to select a preregistered, topology-blocked holdout of matched sequences with similar target-only Rosetta energy and similar minimum-decoy gap but different estimated alternative-basin multiplicity/effective partition mass. Compare (i) target-only score, (ii) minimum-decoy gap, and (iii) ensemble free-energy estimate against the existing protease-resistance readout; retain topology and expression/aggregation covariates, and bootstrap by backbone cluster. A prospective follow-up would synthesize a small matched panel and directly resolve target versus alternative conformational populations by solution NMR, with CD/thermal stability and SEC as controls. Prediction: after matching target minimum and best-decoy energy, designs with larger `Z_B/Z_A` have lower target occupancy; the log-odds should obey `log(p/(1-p)) = DeltaF/kBT` within measurement/model error. The 95% occupancy cutoff is the 1.74 kcal/mol free-energy threshold above.

**Costs charged:** no raw data downloaded, no sequence synthesized, no simulations or tests run here; this memo is an analytic derivation plus primary-source review. Norn et al. report ~10^4 decoys per sequence and thousands of CPU-hours for Rosetta ab-initio landscape characterization, versus seconds on standard GPUs for their trRosetta calculation. Recomputing full landscapes is therefore not budget-neutral. The proposed first test reuses published design/assay records and costs curation/reanalysis; actual compute/runtime is not reported in the source and should be measured rather than guessed. The NMR follow-up requires new synthesis and wet-lab effort and is proposed, not performed.

## Limits

The theorem is exact only for a specified equilibrium ensemble, solvent/ligand/oligomer conditions, and target-basin definition. The `epsilon` guarantee is conditional: current force-field error is not known to satisfy it. Norn's `P_near` uses a finite decoy ensemble and is not a formal partition function. Kinetics, aggregation, expression, and cellular partners can change observed populations or apparent success. No external novelty or priority claim is made.
