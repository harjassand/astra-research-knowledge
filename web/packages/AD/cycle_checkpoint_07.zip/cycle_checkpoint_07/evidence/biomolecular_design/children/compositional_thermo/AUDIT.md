# Compositional thermodynamics in protein and RNA design

**Finding.** Local free-energy margins and modular sequence/structure scores do not, in general, guarantee global target occupancy or specificity. They compose only when the conformational state space factorizes and the full Hamiltonian (including solvent, ions, ligands, oligomerization, and linker effects at the stated conditions) is additive across modules. Even then, the useful local quantities are ensemble probabilities or partition-function ratios, not just a gap to the single best local alternative. Unbounded or unmeasured intermodule terms make any universal global guarantee impossible.

## Exact composition result and a robust extension

Let the equilibrium states be a Cartesian product, \(\Omega=\prod_{i=1}^n\Omega_i\), with dimensionless inverse temperature \(\beta=(k_BT)^{-1}\). Let \(T_i\subseteq\Omega_i\) be the target basin for module \(i\), and suppose the full energy is additive, \(H_0(x)=\sum_i h_i(x_i)\). Then the full target is \(T=\prod_iT_i\), and its equilibrium occupancy factorizes:

\[
P_0(T)=\frac{Z_T^0}{Z^0}=\prod_{i=1}^n\frac{Z_{T_i}}{Z_i}=\prod_i p_i.
\]

Thus, if each isolated module has target occupancy at least \(1-\epsilon_i\), the joint target occupancy is at least \(\prod_i(1-\epsilon_i)\ge 1-\sum_i\epsilon_i\). This is an exact result under the stated assumptions. It is a statement about the *full modeled ensemble*: in RNA, an appropriate nearest-neighbor secondary-structure partition function can account for local loop/stack alternatives, but it does not thereby include arbitrary tertiary contacts, pseudoknots, proteins, ligand/ion linkage, or transcriptional history. McCaskill's partition-function recursion explicitly computes ensemble probabilities in the pseudoknot-free secondary-structure model in \(O(n^3)\) time ([McCaskill 1990](https://doi.org/10.1002/bip.360290621)); a minimum-free-energy structure alone omits the multiplicity of competing states.

Here is a robust version when the additive model \(H_0\) omits an interaction term \(V(x)\). Let \(Z_T^0,Z_O^0\) be the target and all-off-target partition functions under \(H_0\), with \(O=\Omega\setminus T\), and set \(R_0=Z_T^0/Z_O^0\). Under \(H=H_0+V\),

\[
R=\frac{Z_T}{Z_O}=R_0\,\frac{\mathbb E_{0}[e^{-\beta V}\mid T]}{\mathbb E_{0}[e^{-\beta V}\mid O]}.
\]

If the *net free-energy* interaction is bounded over the modeled state space by \(\operatorname{osc}(V)=\sup V-\inf V\le W\), then the ratio of conditional expectations is at least \(e^{-\beta W}\). Therefore

\[
P(T)\ge \frac{R_0e^{-\beta W}}{1+R_0e^{-\beta W}}.
\]

This worst-case bound is sharp: an interaction can take its maximum on every target state and its minimum on every off-target state. To guarantee occupancy \(q\), one needs \(\log R_0-\beta W\ge\log(q/(1-q))\). If no upper bound on omitted interactions is known, no finite local margin certifies any nontrivial global occupancy floor. For a chosen target basin, occupancy is \(Z_T/(Z_T+Z_O)\); structural specificity is the same calculation with all competing basins in \(Z_O\). A lowest-energy gap alone also fails when the off-target basin has high conformational degeneracy: for \(K\) off-target states each \(\delta\) above one target state, \(P_T=[1+K e^{-\beta\delta}]^{-1}\).

## Minimal counterexample with explicit hidden term

Take two binary modules, \(x_i=1\) for its intended local fold and \(x_i=0\) for a locally non-target fold. At \(37^\circ\mathrm C\), set

\[
H_0(x_1,x_2)=2(1-x_1)+2(1-x_2)\quad\text{kcal/mol},
\qquad
V(x_1,x_2)=-4(1-x_1)(1-x_2)\quad\text{kcal/mol}.
\]

The term \(V\) represents one joint off-target interface—e.g. an interdomain packing contact or an RNA helix/tertiary docking arrangement—that exists only when both local domains leave their intended folds. It is absent from each module's isolated score and from the single-module deviations. The net coupling is a *free-energy* term after loop/linker closure, solvent and ion effects; \(-4\) is a concrete coarse-grained prediction, not a sequence-derived estimate.

Using \(k_BT\simeq0.616\) kcal/mol, an isolated module is in its intended fold with probability \(p=[1+e^{-2/0.616}]^{-1}\simeq0.962\), so the independent-module prediction is \(p^2\simeq0.927\). The four full-system state energies are \(H(1,1)=0\), \(H(1,0)=H(0,1)=2\), and \(H(0,0)=0\) kcal/mol. Hence

\[
P(1,1)=\frac{1}{2+2e^{-2/0.616}}\simeq0.481.
\]

The intended global fold falls from a nominal 92.7% to 48.1%, although either module tested alone is 96.2% intended. The joint cycle free energy is
\(\Delta G_{\rm int}=G_{00}-G_{01}-G_{10}+G_{11}=-4\) kcal/mol. Equivalently,
\(p_{11}p_{00}/(p_{10}p_{01})=e^{-\beta\Delta G_{\rm int}}\simeq6.6\times10^2\), a directly testable signature of the hidden coupling. Larger \(|V|\) drives the target occupancy arbitrarily close to zero without changing either isolated module's score, establishing the no-go independent of this particular numerical example.

This term has physical precedents, but the numerical value above should not be overread. In a 195-nt Azoarcus group-I ribozyme, the paper summarizes disruption of a tetraloop/receptor contact as destabilizing tertiary interactions throughout by 2–3 kcal/mol. Its contact-resolved fits report perturbations of 1.4–2.2 kcal/mol at individual remote contacts, comparable to the 1.2-kcal/mol global native-state destabilization estimated from catalytic activity. Such terms arise because the contact network, RNA compaction, and Mg\(^{2+}\) linkage change together ([Chauhan & Woodson 2008](https://doi.org/10.1021/ja076166i)). For proteins, an exhaustive scan of 559 residue pairs across 190 natural and designed domains found typical pair couplings of 0.5–1 kcal/mol and some above 2 kcal/mol; it also found third-residue-mediated coupling ([Tsuboyama et al. 2023](https://doi.org/10.1038/s41586-023-06328-6)). A few such contacts can accumulate to multi-kcal/mol scale. These data support the *existence and scale* of omitted interactions; they do not validate the toy construct's exact \(-4\) value.

## Which interactions are hidden by a modular score?

- **RNA:** intermodule base pairing; pseudoknots; coaxial stacking at junctions; tetraloop–receptor and other tertiary contacts; Mg\(^{2+}\)/monovalent-ion uptake; ligand binding; protein binding; and concentration-dependent strand association. Some nearest-neighbor models include selected coaxial-stacking terms (for example, the 2004 RNAstructure parameterization), but their additive loop decomposition does not make tertiary or kinetic effects disappear ([Mathews et al. 2004](https://doi.org/10.1073/pnas.0401799101)).
- **Proteins:** residue-pair packing and hydrogen-bond networks across a proposed domain boundary; solvent exposure/desolvation; electrostatics and ionization; linker conformational entropy; oligomerization; and mutation-dependent unfolded-state interactions. The protein deep-mutational study measured long-range or structurally unexpected couplings and a three-residue network, so a contact list limited to a visible local interface is not sufficient evidence of independence ([Tsuboyama et al. 2023](https://doi.org/10.1038/s41586-023-06328-6)).
- **Both:** state degeneracy, shared strain or steric constraints, and assay conditions. The free-energy quantity to add is \(\Delta G=\Delta H-T\Delta S\) at specified temperature, salt, pH, ligand activity and concentration. Counting only favorable contacts while omitting the conformational-entropy cost of bringing them together can reverse the design ranking.

Sequence compatibility or objective-score modularity is weaker still: a score can be syntactically a sum while the molecule's actual state space is not a product. A local score proves occupancy only after calibration to an ensemble at the same context and conditions and after all cross-boundary energies are included or bounded.

## Equilibrium prediction versus kinetic outcome

At thermodynamic equilibrium with fixed environmental chemical potentials, barriers affect how long equilibration takes, not the Boltzmann occupancy; transition rates obey detailed balance. A correct equilibrium energy model can still miss the observed population at a finite time. Cotranscription, cotranslation, ATP-driven chaperoning, active transport, and time-varying ligand pulses are driven interfaces: the result depends on transition rates, the order in which sequence segments appear, pausing, and the observation window. One cannot infer those rates from equilibrium margins.

The kinetic separation has direct experimental examples. In the Azoarcus ribozyme, wild type reached its native tertiary state in about 5–20 ms, while a tetraloop mutant had a slow component of 30–200 s through non-native intermediates; certain remote contacts formed roughly 10,000-fold more slowly ([Chauhan & Woodson 2008](https://doi.org/10.1021/ja076166i)). In the pbuE adenine riboswitch, single-molecule transcription at about 20 nt/s showed that the aptamer formed once or not at all in an approximately 2-s decision window, while the ligand-bound conformation lasted about 10 s; the gene-regulatory outcome was kinetically controlled ([Frieda & Block 2012](https://doi.org/10.1126/science.1225722)). Those are not failures of equilibrium statistical mechanics; they are measurements of a different interface.

For a simple kinetic two-state illustration, let a misfolded state \(M\) convert to the target \(T\) at rate \(k_{M\to T}\). Starting in \(M\), if reverse conversion is negligible on the decision window \(\tau\), then \(P_T(\tau)=1-e^{-k_{M\to T}\tau}\), regardless of how favorable \(T\) is at equilibrium. A barrier high enough that \(k_{M\to T}\tau\ll1\) defeats an excellent equilibrium margin on that timescale. Under genuine equilibrium, detailed balance instead requires \(\pi_Mk_{M\to T}=\pi_Tk_{T\to M}\); changing rates while preserving this ratio changes relaxation time but not \(\pi_T\).

## Discriminating measurement and quantitative prediction

For a concrete two-module construct, report both the four-state equilibrium distribution and the time-dependent distribution, rather than only local minimum energies or separate-module folding yields.

1. Measure the intended and alternative state of **both modules simultaneously** (for example, two orthogonal single-molecule distance reporters or validated multi-site chemical-probing state classifiers) in the joined molecule. Repeat each module alone and under matched temperature, pH, salt, Mg\(^{2+}\), ligand activity and concentration. Allow reversible exchange and check that the inferred endpoint is independent of folding history.
2. Make a 2-by-2 perturbation cycle for the proposed cross-interface: disrupt module-A contact, disrupt module-B contact, then make the compensatory double mutation that restores the cross-interface while preserving the local folds. Estimate \(\Delta G_{\rm int}=G_{00}-G_{01}-G_{10}+G_{11}\) from equilibrium populations (or binding/folding free energies). A single-population assay that measures only the two marginals cannot distinguish the independent prediction from correlated states.
3. Separately start from denatured, separately pre-folded and cotranscriptionally/cotranslationally produced material. Measure state populations versus time and vary transcription/translation rate or pause placement. If the system is ergodic on the assay timescale, equilibrium composition predicts the same long-time distribution after these histories; a persistent rate/history dependence identifies kinetic control or a driven process.

For the numerical counterexample above, the testable equilibrium prediction is \(P_{11}=0.481\), the independent prediction is 0.927, and the cycle coupling is \(-4.0\) kcal/mol at 37°C. Scrambling the cross-interface while preserving local folds should remove this coupling and restore the product prediction; a compensatory double mutation should restore the coupled distribution. If the long-time equilibrium does not show the predicted change but early or cotranscriptional states do, the proposed \(-4\)-kcal equilibrium interaction is falsified and the discrepancy is kinetic or due to a missing condition-dependent term. This is a discriminating, falsifiable test, not a literature-derived prediction for a named biomolecule.

## Resource cost and practical scope

For pseudoknot-free RNA secondary structures under a specified nearest-neighbor model, partition functions are tractable at \(O(n^3)\) ([McCaskill 1990](https://doi.org/10.1002/bip.360290621)). This is useful for removing minimum-energy/degeneracy errors at low cost, but the cubic calculation does not certify omitted tertiary, multistrand or kinetic physics. Full joint state measurement costs more than separate local assays: the minimum coupling experiment requires a four-state joint readout plus the relevant single/double perturbations and matched condition controls. Protein exhaustive 20-by-20 scans contain 400 sequence variants per residue pair; Tsuboyama et al. report 210,118 double-mutant measurements for 559 selected pairs. Their cDNA-display campaign could assay up to 900,000 sequences in a one-week experiment with about US$2,000 in reagents per library, excluding DNA synthesis and sequencing ([Tsuboyama et al. 2023](https://doi.org/10.1038/s41586-023-06328-6)). That provides a scale reference, not a direct quote for every lab or experiment.

The largest unresolved practical issue is not whether coupling exists, but whether a proposed model measures or bounds the *aggregate* coupling and state multiplicity for the chosen construct under the actual operating conditions. Without that, modular optimization is a hypothesis generator, not an occupancy certificate.

## Primary sources

- McCaskill, J. S. (1990). “The equilibrium partition function and base pair binding probabilities for RNA secondary structure.” *Biopolymers* 29, 1105–1119. [DOI](https://doi.org/10.1002/bip.360290621)
- Mathews, D. H. et al. (2004). “Incorporating chemical modification constraints into a dynamic programming algorithm for prediction of RNA secondary structure.” *PNAS* 101, 7287–7292. [DOI](https://doi.org/10.1073/pnas.0401799101)
- Chauhan, S. & Woodson, S. A. (2008). “Tertiary interactions determine the accuracy of RNA folding.” *J. Am. Chem. Soc.* 130, 1296–1303. [DOI](https://doi.org/10.1021/ja076166i)
- Frieda, K. L. & Block, S. M. (2012). “Direct observation of cotranscriptional folding in an adenine riboswitch.” *Science* 338, 397–400. [DOI](https://doi.org/10.1126/science.1225722)
- Tsuboyama, K. et al. (2023). “Mega-scale experimental analysis of protein folding stability in biology and design.” *Nature* 620, 434–444. [DOI](https://doi.org/10.1038/s41586-023-06328-6)
