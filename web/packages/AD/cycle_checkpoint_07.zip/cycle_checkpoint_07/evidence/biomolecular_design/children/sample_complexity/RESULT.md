# Sequence–function sample complexity: exact no-go and a local factorial experiment

**Status.** The two bounds below are elementary, exact results reconstructed here; they are not a novelty or priority claim. The first is a distribution-free no-go for assay-guided design. The second is a rank bound for an explicitly restricted low-order epistasis model. Primary studies show why the distinction matters: useful small-label design imports strong sequence priors, while complete local maps reveal substantial context dependence. No wet-lab work was performed.

## Interface and accounting

Fix an assay context $c$: construct, expression host, substrate/ligand, environment, selection protocol, and one scalar target phenotype. The design domain is a finite candidate set $X$, $|X|=N$. One query is one distinct sequence $x\in X$ receiving its assay outcome $f_c(x)$. Replicate measurements of the same sequence improve precision but do not add a new sequence to the coverage budget. A read count, sequencing read, or pooled selection observation is not automatically one independent label per read; the phenotype is inferred at the genotype level. A different condition (c') defines a different function and requires its own coverage/precision accounting.

This is a deliberately favorable oracle model: labels are exact and noiseless. Real assays add synthesis dropout, expression/measurement noise, batch effects, and finite read depth, so this bound does not charge those costs. It counts unique genotypes only.

## Theorem 1: exact minimax no-go without a sequence prior

Let $X$ have $N\ge 2$ candidates. For every hidden $z\in X$, define an assay landscape

\[
f_z(x)=\mathbf 1\{x=z\}.
\]

An adaptive randomized algorithm may query at most $B<N$ distinct sequences and then recommend one sequence. Against the class \(\mathcal F=\{f_z:z\in X\}\), its exact minimax probability of recommending the unique active sequence is

\[
\sup_{A:\,B\text{ queries}}\;\inf_{z\in X}\Pr_A[\hat x=z]
=\frac{B+1}{N}.
\]

Equivalently, the exact minimax simple regret under this unit-height hidden-hit class is $1-(B+1)/N$. To guarantee success probability at least $1-\delta$, one needs $B\ge (1-\delta)N-1$ unique assays (rounded up).

**Proof.** Choose $z$ uniformly from $X$. The algorithm finds it during its $B$ queries with probability at most $B/N$. Conditional on missing it, every unqueried candidate is still equally consistent with the all-zero transcript, so its one final recommendation succeeds with probability at most $1/(N-B)$. Thus average success is at most

\[
\frac BN+\frac{N-B}{N}\frac{1}{N-B}=\frac{B+1}{N}.
\]

The worst-case $z$ success of any algorithm is at most its average over uniform $z$. Equality is attained by uniformly choosing $B$ distinct candidates to query, then uniformly recommending one unqueried candidate if all labels are zero. This randomized policy has success $(B+1)/N$ for every $z$. \(\square\)

This is a theorem about a fixed scalar assay objective and a sequence-query interface. It does **not** say that real landscapes contain isolated active sequences, or that ML design is ineffective. It says that no finite label count alone gives a distribution-free design guarantee: successful low-$N$ work must get information from a restricted landscape class, homologous sequences, structures, physical models, pretrained sequence models, or other stated prior information.

For a concrete local search domain of $K=20$ nominated binary edits, $N=2^{20}=1{,}048{,}576$. With 1,000 sequence assays, even this idealized guarantee is at most $1001/1{,}048{,}576\approx0.0955\%$. A 95% guarantee requires 996,147 unique queries. For 24 labels over ten million candidates, the upper bound is $25/10^7=2.5\times10^{-6}$. These calculations do not contradict reported low-label successes: those methods add informative priors and restrict the effective hypothesis class.

## Theorem 2: exact sample count for identifying a $d$-site epistasis model

Now make the structural assumption explicit. At each of $K$ sites, choose one reference residue/base and $q_i-1$ alternative states. Write a genotype as indicators for which nonreference state appears at each site. Suppose the assay landscape has no interactions involving more than $d$ distinct sites:

\[
f(x)=\sum_{S\subseteq[K],\,|S|\le d}\theta_S(x_S),
\]

where each θ term is an arbitrary function of the states at the sites in $S$, represented in a reference-coded contrast basis. The number of independent scalar coefficients is

\[
D_d=\sum_{S\subseteq[K],\,|S|\le d}\prod_{i\in S}(q_i-1).
\]

For a noiseless scalar assay, $D_d$ distinct genotype queries are necessary and sufficient to identify every landscape in this class. Write each queried outcome as one row of a feature matrix $A\in\mathbb R^{B\times D_d}$. If $B<D_d$, then $\ker A$ contains a nonzero $h$; coefficient vectors $\theta$ and $\theta+\lambda h$ give the same transcript on all queried points but a different landscape somewhere, because the contrast features are linearly independent. This also applies to adaptive queries: the two coefficient vectors produce the same observed values along the transcript, so the algorithm makes the same next-query choices. If the assay scale is restricted to $[0,1]$, scale $\lambda$ small enough and center both landscapes at $1/2$. Thus no algorithm can identify every member of the class with fewer than $D_d$ labels. Sufficiency is attained by assaying the reference plus every genotype that changes at most $d$ sites: inclusion-exclusion / Möbius inversion successively recovers the main effects and all interactions through order $d$.

For equal alphabet size $q$, this is $D_d=\sum_{j=0}^d {K\choose j}(q-1)^j$. For binary edit toggles, it is $\sum_{j=0}^d {K\choose j}$. For four protein sites with 20 amino-acid states, an exact pairwise model has $1+4(19)+{4\choose2}(19^2)=2{,}243$ coefficients, compared with the full $20^4=160{,}000$ landscape. Examples:

| Local landscape | Full candidate count | Labels to identify exact pairwise model | Labels through order 3 |
|---|---:|---:|---:|
| 20 binary nominated edits | $2^{20}=1{,}048{,}576$ | $1+20+{20\choose2}=211$ | $1+20+190+1{,}140=1{,}351$ |
| 8 RNA sites, four bases/site | $4^8=65{,}536$ | $1+8(3)+{8\choose2}(9)=277$ | $1+24+252+1{,}512=1{,}789$ |
| 8 binary nominated edits | $2^8=256$ | $1+8+28=37$ | $1+8+28+56=93$ |

This is **identification of the assumed low-order model**, not a guarantee that real sequence–function maps stop at order $d$, and not a general lower bound for measuring a single already-specified candidate. For candidate ranking after fitting, omitted higher-order terms and assay noise remain the uncertainty. With an explicit coefficient-radius assumption one can also write exact design-specific uncertainty: if $f(x)=\phi(x)^T\theta$, \(\|\theta\|_2\le R\), and the observed transcript is zero, then the minimax absolute prediction error at $x_\star$ is

\[
R\,\|P_{\ker A}\phi(x_\star)\|_2,
\]

where $A$ is the query design matrix. This follows by maximizing the target functional over indistinguishable coefficients $\theta\in\ker A$; it is zero exactly when the target feature lies in the query-row span. The radius $R$ is an added modeling premise, not a quantity supplied by the assay.

## What primary experiments establish

- **Protein active site, full 4-site amino-acid library.** Johnston et al. mapped all $20^4=160{,}000$ amino-acid combinations at four TrpB positions near the catalytic core. Their outcome was pooled growth enrichment in a tryptophan-auxotrophic *E. coli* strain expressing TrpB with exogenous indole, sampled over 36–44 h in duplicate flasks and read by deep sequencing. 159,129 amino-acid variants (99.45%) had enough coverage in both replicates; 871 values were imputed. The study sampled nearly one million codon combinations before collapsing synonymous codons to amino-acid sequences. The landscape had many optima and sign epistasis; a rare natural substitution was strongly beneficial only in the right background. This supports the need to assay interactions in the assay context; it does not validate a universal sequence-learning model. [Johnston et al., PNAS 2024](https://doi.org/10.1073/pnas.2400439121), [full text](https://www.pnas.org/doi/10.1073/pnas.2400439121).
- **RNA dynamic intron, full 8-site library.** Soo et al. randomized two four-base regions of a Tetrahymena group-I intron derivative, creating $4^8=65{,}536$ genotypes. The assay coupled in-vivo splicing to kanamycin resistance in *E. coli*, at 30°C and 37°C. They estimated about 550,000 transformants (at least 8-fold library oversampling); for the nonselective 30°C pool, six biological replicates and 31,269,777 reads recovered 65,533/65,536 genotypes. This explicitly charges library construction, selection context, biological replication, and sequencing rather than treating “65k labels” as 65k independent wells. The paper reports positive epistasis from both compensatory pairing and avoiding overstable helices, and shows that effects change with genetic background. [Soo et al., PLOS Genetics 2021](https://doi.org/10.1371/journal.pgen.1009353), [full text and methods](https://journals.plos.org/plosgenetics/article?id=10.1371/journal.pgen.1009353).
- **RNA higher-order prediction from pairwise training.** Beck et al. measured the CPEB3 self-cleaving ribozyme by in-vitro cotranscriptional cleavage, with fraction-cleaved per genotype estimated from sequencing reads. The training set covered all 207 single and 21,114 double mutants (about 170 reads per double mutant on average). Models trained only on up-to-double mutants reached Pearson $r<0.7$ for sequences at seven or more mutations from the reference; adding three-or-more-mutation genotypes improved high-distance prediction. Their phylogenetic higher-order data were confined to 13 variable positions, so this is scoped evidence, not a universal sample-complexity curve. [Beck et al., Frontiers in Molecular Biosciences 2022](https://doi.org/10.3389/fmolb.2022.893864), [full text](https://www.frontiersin.org/journals/molecular-biosciences/articles/10.3389/fmolb.2022.893864/full).
- **Low-label protein design uses extra information.** Biswas et al. report using as few as 24 functionally assayed mutants for avGFP and TEM-1, then computationally screening ten million candidates. Their method also uses natural protein sequence landscapes to learn a latent prior. The 24-label claim is therefore not a label-only guarantee on a ten-million-element arbitrary class; it is evidence that substantial supplied sequence information can reduce the effective search problem in those two tasks. [Biswas et al., Nature Methods 2021](https://doi.org/10.1038/s41592-021-01100-y), [PubMed record](https://pubmed.ncbi.nlm.nih.gov/33828272/).

## A decision-changing experiment implied by the bounds

Run a **local interaction audit**, fixed to one parent sequence, one assay context, and one scalar goal. This tests the precise premise that turns the no-go into a sample-efficient design problem.

1. Freeze $K=8$ nominated edits (one alternative per site), the assay endpoint, the success threshold, and the reference sequence before collecting labels.
2. Assay the 93 genotypes at Hamming weight 0–3: 1 parent, 8 singles, 28 doubles, and 56 triples. This exactly identifies the full cubic (through third-order) landscape on the 8-edit cube. Fit additive, pairwise, and cubic predictors on the same 93 labels so model-order comparisons use identical information. For this binary-edit panel, this is 93 unique sequence constructs; with two independent biological replicates it is 186 genotype-by-replicate outcomes per condition, plus assay controls.
3. Before observing outcomes, reserve 16 distinct 4–8-edit genotypes as a blind higher-order challenge set. Include the eight highest cubic-model designs and eight distance-matched randomly chosen controls, with matching done before assay outcomes. This makes 109 unique genotypes (218 genotype-by-replicate outcomes per condition under two replicates). Compare hit rate above the frozen threshold and mean activity for model-selected versus matched-random controls; also report prediction error/rank correlation for the blind panel.

The 16-member challenge set is an explicit pilot choice, **not** a theorem-derived power guarantee. Final panel size requires a power calculation from the assay's replicate variance and the smallest worthwhile hit-rate difference. The theorem-derived count is 93 labels to identify the cubic local model. The proposed falsification test adds an explicitly chosen 16 blind sequences; that number is a pilot design choice. If the assay is pooled DMS, count 109 unique sequence inserts, independent transformations/selections, timepoints, and per-genotype read depth separately; if it is individual measurement, count the 218 independent replicate units plus controls. None of synthesis cost, sequencing budget, or suitable assay variance was supplied, so monetary and total-read costs remain unknown.

**Decision rule.** If the cubic model predicts the blind 4–8-edit panel materially better than additive/pairwise models and improves top-hit rate over matched-random at the same unique-sequence budget, keep the corresponding low-order prior for the next round and prospectively validate its top designs. If not, do not call extrapolation uncertainty “confidence”: expand the interaction order, use a better physical/evolutionary prior, or spend labels closer to the intended design distribution. A successful pilot establishes performance only for this sequence family, assay, edit set, and tested distance range.

## Limits and unresolved items

- The hidden-spike class is an adversarial witness. Real proteins/RNAs may have smoothness, conservation, sparse contacts, physical constraints, or pretrained-model structure; none is automatic from a small labeled set.
- The low-order model theorem counts unique genotype labels, assumes exact labels and a fixed assay context, and applies to identifying every coefficient. Experimental noise, codon effects, library bias, genotype dropout, cellular background, and multiple objectives add costs.
- The proposed panel tests a model class and an assay-specific design claim; finite holdout performance does not prove absence of higher-order interactions or global design success.
- Monetary costs, target-specific variance, and synthesis/sequencing feasibility are not specified. Literature examples establish that panels of $10^4$–$10^5$ genotypes have been assayed for constrained local libraries, not that such scale is available in the current laboratory.
- No repository experiment, code replay, wet-lab assay, external review, novelty search, or priority check was performed. The bounds are standard finite-query/rank arguments; source reports above are primary-literature facts, not independent data reanalysis.
