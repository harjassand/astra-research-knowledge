# Cycle 2: reversible three-state kinetic ranking

## Result

For the homogeneous birth-death chain `U <-> C <-> B`, componentwise favorable rates certify a true all-time, all-concentration sequence order. With both candidates starting in `U`, sequence A dominates B whenever

`alpha_A >= alpha_B`, `beta_A <= beta_B`, `kon_A >= kon_B`, and `koff_A <= koff_B`.

Here `alpha` is U-to-C folding, `beta` is C-to-U unfolding, `kon*c` is C-to-B binding, and `koff` is B-to-C dissociation. A monotone coupling proves `P_A(B at t) >= P_B(B at t)` for every `c >= 0` and `t >= 0`. This is a useful partial-order certificate, not a total ranking: a higher on-rate traded against a higher off-rate can produce a crossing.

The result is a specialization of standard birth-death stochastic monotonicity. Riboswitch CTMCs with folding, ligand association/dissociation, and transcription/termination already exist in primary literature, so no priority claim is made for the model ingredients or general mathematical device.

## Exact solution

Write `gamma=c*kon`, `delta=koff`, and use row-generator

```
Q = [ [-alpha,       alpha,             0],
      [ beta, -(beta+gamma),         gamma],
      [    0,       delta,           -delta] ].
```

Assume positive `alpha,beta,kon,koff`, fixed `c`, and initial state U. Let

`S = alpha + beta + gamma + delta`,
`D = alpha*gamma + alpha*delta + beta*delta`,
`r_plus/minus = (S +/- sqrt(S^2-4D))/2`,
`pi_B = alpha*gamma/D`.

For distinct roots,

`P_B(t) = pi_B * [1 - (r_plus*exp(-r_minus*t)-r_minus*exp(-r_plus*t))/(r_plus-r_minus)]`.

At a repeated root `r_plus=r_minus=r`, use the continuous limit

`P_B(t) = pi_B * [1-(1+r*t)*exp(-r*t)]`.

At `c=0`, `gamma=0` and `P_B(t)=0`. Useful boundary checks are

`P_B(t) = alpha*gamma*t^2/2 + O(t^3)` as `t` tends to zero, and

`lim_(t->infinity) P_B(t) = pi_B = alpha*kon*c / (alpha*kon*c + koff*(alpha+beta))`.

The early-time expansion reflects the two jumps required to enter B; `beta` and `koff` first affect higher-order terms.

## All-time dominance proof

Treat `U<C<B` as the state order. The upward rates of A are `lambda_A(U)=alpha_A` and `lambda_A(C)=c*kon_A`; its downward rates are `mu_A(C)=beta_A` and `mu_A(B)=koff_A`. The four stated inequalities give `lambda_A(i)>=lambda_B(i)` at each upward edge and `mu_A(i)<=mu_B(i)` at each downward edge, for every `c>=0`.

Couple the two chains on ordered pairs. When they occupy the same state, run common upward jumps at B's upward rate and let A make the residual upward jumps; run common downward jumps at A's downward rate and let B make the residual downward jumps. Every unmatched jump moves A above B. When states differ, they are nearest-neighbor chains: one jump can close a one-state gap but cannot cross it. When they meet, resume the equal-state coupling. Starting together in U, this constructs `X_A(t)>=X_B(t)` pathwise for all t. Since B is the top state, its indicator is increasing, hence the desired probability inequality follows by expectation.

The same coupling proves coordinatewise monotonicity of `P_B(c,t)` in `alpha` and `kon`, and antitonicity in `beta` and `koff`. Thus simultaneous parameter confidence intervals immediately give a simultaneous dose-time band:

```
P_low(c,t)  = Phi(alpha_low, beta_high, kon_low, koff_high; c,t)
P_high(c,t) = Phi(alpha_high, beta_low, kon_high, koff_low; c,t)
```

where `Phi` is the closed form above. On the joint rate-coverage event, this encloses the true response for all `c>=0,t>=0` at once.

## Incomparable-rate crossing

Let both sequences have `alpha=beta=1 s^-1`. At `c=1 micromolar`, take

- A: `kon=2 micromolar^-1 s^-1`, `koff=10 s^-1`;
- B: `kon=1 micromolar^-1 s^-1`, `koff=1 s^-1`.

The early-time expansions are `P_A(B_t)=1*t^2+O(t^3)` and `P_B(B_t)=0.5*t^2+O(t^3)`, so A is initially higher. Their stationary probabilities are `pi_A=2/(2+20)=1/11` and `pi_B=1/(1+2)=1/3`, so A is eventually lower. Continuity forces at least one crossing. Substitution into the exact solution gives a crossing near `t=0.2732 s` (for example, at `0.1 s`, A≈0.00649 and B≈0.00438; at `0.3 s`, A≈0.02921 and B≈0.03069). These parameter vectors are incomparable under the favorable order, as expected.

## Rate acquisition and robust ranking

### Assay and estimands

Use a fixed, calibrated ligand concentration `c_star>0` and the same RNA sequence context, buffer, magnesium, temperature, and polymerase protocol for every candidate. Resolve the three states by calibrated single-molecule FRET (or another validated state-resolving assay), and record complete dwell intervals and their exit destinations. The assumed time-homogeneous model is

- U sojourns: `Exp(alpha)`, with every exit U-to-C;
- C sojourns: `Exp(rho)`, `rho=beta+c_star*kon`; exit C-to-B with probability `r=(c_star*kon)/rho`, otherwise C-to-U;
- B sojourns: `Exp(koff)`, with every exit B-to-C.

The C dwell duration and its exit label are independent under competing exponential hazards. One positive concentration therefore identifies both `beta` and `kon` within the model; a second concentration is a valuable model check of the predicted linear C-to-B hazard. Rates are sequence-specific unless a common rate is externally established. Concentration calibration error must be propagated when converting `gamma` to `kon=gamma/c_star`.

### Exact fixed-look confidence intervals

For one sequence, collect `m_U`, `m_C`, and `m_B` independent completed dwell episodes. Let `S_U`, `S_C`, and `S_B` be the sums of their durations; let `x` of the `m_C` C episodes exit to B. Given a two-sided miscoverage allocation `eta`:

- An exponential rate `q` from `m` complete dwell times with sum `S` has exact interval `[chi2_(2m,eta/2)/(2S), chi2_(2m,1-eta/2)/(2S)]`.
- The exact Clopper-Pearson interval for `r` uses lower `0` if `x=0`, otherwise `BetaQuantile(eta/2; x,m_C-x+1)`; upper `1` if `x=m_C`, otherwise `BetaQuantile(1-eta/2; x+1,m_C-x)`.
- Apply the exponential interval to `alpha` using `(m_U,S_U)`, to `rho` using `(m_C,S_C)`, and to `koff` using `(m_B,S_B)`.
- If `rho in [rho_L,rho_U]` and `r in [r_L,r_U]`, then `gamma=c_star*kon` lies in `[rho_L*r_L,rho_U*r_U]`, `beta` lies in `[rho_L*(1-r_U),rho_U*(1-r_L)]`, and `kon` lies in the gamma interval divided by `c_star`.

For `K` prespecified sequences, take `eta=delta/(4K)` for each of the four primitive intervals (`alpha`, `rho`, `r`, `koff`). A union bound gives all transformed rate intervals simultaneous coverage at least `1-delta`; no independence across sequences is needed. For fixed-look data, certify A over B only if

`alpha_L(A)>=alpha_U(B)`, `beta_U(A)<=beta_L(B)`, `kon_L(A)>=kon_U(B)`, and `koff_U(A)<=koff_L(B)`.

This proves the complete-surface dominance result at confidence at least `1-delta`. Otherwise report the pair as unresolved/incomparable. For a particular `(c,t)`, the transformed rate-rectangle response bands can sometimes order sequences even when the componentwise certificate cannot.

If data are reviewed at multiple looks, ordinary fixed-sample intervals do not retain coverage under optional stopping. Predefine cumulative episode counts `m_l` and use miscoverage `eta_l=delta/[4K*l*(l+1)]` for each primitive interval at look `l`; the sum over looks is `delta/(4K)` per primitive interval. These exact intervals are then simultaneous over all planned looks, permitting a valid stop when the dominance inequalities first separate.

### Exact trajectory and dwell cost

At a fixed look with `m_U=m_C=m_B=m`, the exact observed-data cost is `3Km` completed state-dwell episodes. If each episode is restarted from its target state, this is also `3Km` trajectory segments; a continuous trajectory can supply multiple episodes, so episode count is the safer cost measure. At concentration `c_star`, expected dwell time per sequence is

`m/alpha + m/(beta+c_star*kon) + m/koff`.

Across K candidates, sum this expression over sequences. The realized dwell-time cost is exactly the sum of observed episode durations `S_U+S_C+S_B` for each sequence. This excludes state preparation, immobilization, photobleaching losses, sequence synthesis/QC, instrument overhead, and any discarded/censored paths; those must be separately charged. Increasing looks reuse earlier episodes, so at look l the cumulative episode cap is `3K*m_l`, with `3K*(m_l-m_(l-1))` new episodes since the prior look.

A state-resolving assay must test exponential dwell survival and the concentration linearity of C-to-B rates. Hidden substates, state-dependent photobleaching, transcription pauses that change the rates, and a nonconstant transcription decision time can invalidate the fitted three-state homogeneous chain. In those cases, expand the state space or rank with an experimentally validated larger model; do not use the three-rate certificate as if it covered them.

## Primary prior art and novelty boundary

- Lin & Thirumalai, “Gene regulation by riboswitches with and without negative feedback loop,” *Biophysical Journal* (2012), [DOI 10.1016/j.bpj.2012.10.026](https://doi.org/10.1016/j.bpj.2012.10.026): a primary kinetic network model explicitly includes aptamer folding/unfolding, metabolite association/dissociation, transcription stages, termination/readthrough, and feedback; it predicts response across kinetic parameters. This establishes that reversible kinetic-network modeling is prior art. The U-C-B chain here is a smaller model without transcription-state expansion.
- Frieda & Block, “Direct Observation of Cotranscriptional Folding in an Adenine Riboswitch,” *Science* (2012), [DOI 10.1126/science.1225722](https://doi.org/10.1126/science.1225722): direct pbuE nascent-RNA trajectories and termination measurements support kinetic commitment.
- Bushhouse et al., “Real-time monitoring of single ZTP riboswitches reveals a complex and kinetically controlled decision landscape,” *Nature Communications* (2020), [DOI 10.1038/s41467-020-18283-1](https://doi.org/10.1038/s41467-020-18283-1): real-time single-molecule ZTP folding paths and kinetic perturbations; evidence that multiple states and barriers matter.
- Bushhouse et al., “RNA folding kinetics control riboswitch sensitivity in vivo,” *Nature Communications* (2025), [DOI 10.1038/s41467-024-55601-3](https://doi.org/10.1038/s41467-024-55601-3): expression-platform kinetic barrier engineering changes sensitivity/dynamic range across switches, while some variants retain large EC50/KD gaps.

The exact three-state solution, rate-CI construction, and dominance coupling are internal derivations from a finite birth-death CTMC. The coupling is standard stochastic-order reasoning. Primary literature already uses richer reversible riboswitch CTMCs; the bounded review did not establish whether any paper states this exact sequence-ranking certificate. No priority claim is made.

## Decisive next test

For a small prespecified candidate panel, measure the four rates with a state-resolved single-molecule assay, check dwell exponentiality and concentration scaling, and construct simultaneous rate intervals before ranking. Test predicted `P_B(c,t)` at a held-out positive concentration and transcription-decision time against direct termination/readthrough fractions. The test falsifier is a held-out response outside the full rate-interval band under a verified three-state assay; such failure calls for hidden states or time-dependent transcription, not an adjustment to the partial-order theorem.
