# Allostery and sequence–function design: scoped result and experiment

**Assessment (8 October 2026).** The most defensible result here is an identifiability boundary, not a new universal law of allostery. Equilibrium sequence–function data can identify an energetic coupling for a stated protein construct, ligand, and assay. Those same endpoint measurements do not identify the microscopic route that produced the coupling. A useful experimental anchor is PSD-95 PDZ3, where recent public mutation maps show that the energetic effect of a core sequence depends on terminal extensions, while older NMR and peptide-binding studies disagree on whether the C-terminal helix acts through distributed dynamics, direct contacts to extended ligand, or both.

The Astra static bootstrap in this workspace has no biomedical/allostery route or supporting card; the result below comes from primary papers and their deposited data/code, not from repository navigation.

## Exact claim and no-go

Fix the complete assay interface: protein core sequence, extension/context, ligand sequence, solution conditions, and the measured equilibrium phenotype. For an extension-deletion experiment, write the binding energy of variant m in context c as G_b(m,c). The mutation–extension coupling is the thermodynamic cycle

\[
\eta_m = [G_b(m,1)-G_b(\mathrm{WT},1)]-[G_b(m,0)-G_b(\mathrm{WT},0)] .
\]

If the measurements are dissociation constants, G_b(m,c) − G_b(WT,c) = RT ln[K_d(m,c)/K_d(WT,c)]. Thus

\[
\eta_m=RT\ln\!\left(\frac{K_d(m,1)/K_d(\mathrm{WT},1)}{K_d(m,0)/K_d(\mathrm{WT},0)}\right).
\]

This is an exact, interpretable observable. It establishes context-dependent energetic coupling for that mutation and ligand. It does **not** by itself identify a residue-by-residue path, direct-contact mechanism, or population-shift versus fast-dynamics mechanism.

The mechanism limit has a simple exact proof for a binary cycle. Let a,b ∈ {0,1} denote two perturbations and let W_ab = exp[−G_ab/(RT)] > 0 be their observed equilibrium weights. The effective coupling is

\[
J_{\rm eff}=G_{11}-G_{10}-G_{01}+G_{00}
=-RT\ln\frac{W_{11}W_{00}}{W_{10}W_{01}}.
\]

One model assigns these four weights to a single-state system with a direct a–b interaction. An observationally identical model introduces an unobserved binary conformation q and uses conditionally separate energies for a and b:

\[
W_{ab}=\sum_{q=0}^{1}u_q(a)v_q(b),\qquad u_q(a),v_q(b)\ge 0.
\]

Every nonnegative 2×2 matrix has nonnegative rank at most two, so such a factorization exists. The hidden-state model has no direct a–b energy term, yet summing over q reproduces the same four measurements and J_eff. Therefore no estimator using only that equilibrium table can distinguish direct energetic contact from a latent conformational mediator. The conclusion is scoped to equilibrium endpoints for one binary cycle; it does not say that energetic coupling is unmeasurable or that dynamics are untestable. A state-resolving or time-resolved observation is needed to distinguish explicit mechanisms.

A separate representation no-go is also exact. If a model sees only the conserved PDZ core and omits an extension, it receives the same input for two constructs whose binding free energies differ by δ. Its worst-context absolute error is at least |δ|/2; with equal weighting of the two contexts, its minimum RMSE is also |δ|/2. In the 2026 PSD-95 PDZ3 map, deletion of the C-terminal αC extension changes the inferred wild-type binding energy by +0.97 kcal/mol. At 298 K, RT ≈ 0.592 kcal/mol, so this corresponds to a 5.2-fold change in K_d under that study’s thermodynamic model and gives a core-only representation an irreducible 0.485 kcal/mol worst-context error on that absolute target. This bound does not apply to predictors that receive the extension/context, and it is not a bound on every mutation’s context interaction.

## Mechanistic anchor and quantitative evidence

PSD-95 PDZ3 is a small peptide-binding domain with an N-terminal extension and a C-terminal αC helix. The 2026 extension study measured abundance and CRIPT-peptide binding for libraries in four constructs: full domain, minus N extension, minus αC, and minus both. Each construct’s designed library covered 66 core residues, with 53,144 designed amino-acid genotypes (51,984 doubles and 1,159 singles). Across the four contexts, the authors report 188,624 abundance and 196,058 binding measurements and infer 6,948 energetic couplings. Deleting αC shifts the wild-type binding energy by +0.97 kcal/mol and folding stability by +1.41 kcal/mol; deleting the N extension shifts binding by +0.27 and folding by +0.78 kcal/mol. These are assay- and model-derived free energies from yeast protein-complementation selections, not direct solution K_d measurements for every variant.

For mutation effects, the map reports context-specific hotspots. Deleting αC strengthens effects at five allosteric sites, makes R312, D357, and A375 additional hotspots, strengthens I336 and I341, and removes F337 as a hotspot. I341 is the useful surface-site test: it is the only full-length hotspot reported as relatively solvent-accessible in all four contexts (rSASA 0.239), and its per-substitution binding-energy distribution changes with αC deletion (paired test p = 0.000248). The paper’s main text does not give a mutation-specific numerical η for I341; lock the exact substitution and predicted value from Supplementary Data 3 before any prospective test rather than inventing one.

Two older primary results make the mechanism comparison unusually sharp. Petit et al. measured K_d = 1.2 ± 0.1 μM for full PSD-95 PDZ3 binding a 9-residue CRIPT peptide and 25.7 ± 3.6 μM after deleting residues 396–402, an approximately 21-fold affinity loss; their relaxation data supported an entropic, distributed side-chain-dynamics contribution. Separately, NMR, mutagenesis, and ITC work on PDZ3 found contacts between α3 and residues extending well beyond the canonical four-residue PDZ groove in CRIPT, with up to eight peptide residues interacting. These findings permit a mixed mechanism and warn against calling every extension effect “remote allostery” without specifying the ligand boundary. The 2026 0.97-kcal/mol estimate and the older ~21-fold result concern different constructs and assay protocols; treat them as separate calibration targets, not values to average.

## Decisive experiment

Use the context-dependent I341 mutation as the distal test, F337 as the αC-contact positive control, and a surface substitution with near-zero DMS energy as a negative control. First select and freeze the exact I341 amino-acid substitution from the public map. Measure the WT and these variants in the αC-present and αC-deleted constructs against both (i) the canonical terminal tetrapeptide QTSV and (ii) the 9-mer CRIPT peptide Ac-TKNYKQTSV-COOH. The four-way protein/context/ligand design separates a short-groove ligand from the longer peptide that can contact surfaces outside the canonical groove.

For all 16 construct–ligand combinations, measure K_d, ΔH, and ΔG_b by ITC (or use fluorescence anisotropy for K_d alongside ITC for ΔH), with an independent fold/stability check (CD or chemical-denaturation curve). Calculate η from the four matched equilibrium measurements for each mutation. For WT and the selected I341 variant in both extension contexts, add backbone and side-chain methyl NMR relaxation in apo and ligand-bound states. A broad distal dynamics response that covaries with measured η, especially with the short peptide that lacks the extra ligand-contact surface, supports ensemble-mediated coupling. An effect restricted to the long peptide and the F337/extension contact, with no distal relaxation change, supports a direct extended-interface explanation. A stability loss that tracks abundance or unfolding explains a different component and must not be counted as binding allostery.

This experiment distinguishes the explicit direct-contact and ensemble models above; NMR plus ITC still cannot prove a unique atom-by-atom pathway among all possible hidden-state models. That residual non-identifiability is the theorem's scope, not a reason to overclaim from the proposed measurements.

## Baselines and fair prediction task

The claim worth testing is **context-conditioned prediction of binding-energy effects**, not generic hotspot detection or recovery of an alleged unique pathway.

- **Strongest assay-informed baseline:** fit the published thermodynamic model (MoCHI) using the same abundance and binding data. The 2026 extension study reports 10-fold cross-validated R² = 0.73 for folding and R² = 0.75 for binding; the comparative five-domain/seven-interaction maps use a three-state thermodynamic model. A proposed model must beat this on a grouped holdout, not a random variant split.
- **Best sequence-first baselines:** DCA/SCA or a Potts model from the same homolog alignment; ESM-1v variant score; ESM-1v residualized against ThermoMPNN predicted folding stability. The June 2026 study uses the latter and reports that measured binding-energy changes explain 30.2% of ESM-1v variance in PSD-95 PDZ3 and 4.5% in GRB2-SH3. This is a pathogenicity/stability baseline, not a direct mechanistic predictor.
- **Structural controls:** distance-to-ligand exponential decay, solvent exposure, local contact/interface indicators, and a stability-only model. Distance decay is already reported in the 2026 comparative maps and the June 2026 study, so rediscovering it is not a new result.
- **Split and score:** for transfer, hold out the complete extension context, ligand, homolog, or mutation position/pair. Score held-out ΔΔG_b and η with RMSE/calibration and sign accuracy; for design, rank the top distal substitutions subject to a folding-energy ceiling. Give each model the same protein context, ligand sequence, sequence family/alignment, structure input, and assay training labels for the claim being compared. Include ligand/context in the input; otherwise the representation no-go above applies.

The 2026 comparative resource already spans five homologous human PDZ domains and seven interactions, with 21,802 inferred free-energy changes from >424k abundance and >619k binding nucleotide-variant counts. Its results show a conserved distance-decay trend but fast-evolving surface hotspots. A new sequence-to-function model should therefore be evaluated by leave-one-domain/ligand/context-out transfer and should report per-context errors; pooled random splits overstate evidence for transfer.

## Resource and cost ledger

- **Existing measurements:** reuse public sequencing, processed energy maps, Supplementary Data, and released MoCHI code first. The extension map reports ~53k designed genotypes per context across four contexts; repeating that screen is unnecessary for the mechanism check. Do not treat each nucleotide count or sequencing replicate as an independent protein genotype.
- **New wet-lab work:** a focused orthogonal panel of WT, I341 test, F337 control, and neutral control in two extension contexts and two peptide lengths is on the order of 16 binding conditions before replicates, plus stability checks. NMR adds a higher cost for isotope-labelled samples; restrict it to WT and I341 across the two extension contexts and apo/bound states. Dollar cost is lab-dependent and is not estimated here.
- **Representation:** preserve full construct sequence, extension state, ligand sequence/length, mutation identity, binding versus abundance, and assay condition. Sequence-only core embeddings, one-hot mutations, family coevolution, structural contacts, and stability predictions are distinct input channels; disclose them separately.
- **Local computation:** processed public maps plus sparse thermodynamic, PLM-score, DCA, and distance baselines are modest compared with molecular dynamics or large-model training. On a 16-GB M4-class Mac, prefer deposited ESM/ThermoMPNN scores or a small PLM and avoid rerunning large PLM training. No atomistic MD is required for the exact no-go or the predictive benchmark. Any MD added to propose a path should be charged separately and validated against NMR kinetics/populations.

## Claim ledger

| Claim | Status | Boundary |
|---|---|---|
| η_m is an exactly identifiable mutation–extension thermodynamic coupling for a fixed ligand and assay | Established identity | Requires comparable equilibrium energies in all four matched states |
| Endpoint coupling alone identifies the microscopic allosteric path | Refuted by constructive non-identifiability | Binary equilibrium cycle only; additional state-resolving data change the interface |
| A core-only predictor can recover effects that vary across extension contexts | No-go when targets differ | Context must be supplied to the model |
| PSD-95 PDZ3 allosteric mutational effects are extension-context dependent | Experimentally mapped, model-inferred energy | Yeast PCA/MoCHI; selected orthogonal solution measurements remain useful |
| A distal I341 substitution has a known numerical context-coupling magnitude | Unknown from main-text values | Read the deposited supplementary mutation-level table before freezing the target |
| NMR/ITC will establish a unique pathway | Not claimed | They discriminate specified models but cannot exclude every latent-state decomposition |

## Primary sources

- Hidalgo-Carcedo et al., 2026, [Allosteric and energetic remodeling of a PDZ domain by protein domain extensions](https://doi.org/10.1038/s41467-026-69673-w); processed data [Zenodo 16411462](https://zenodo.org/records/16411462), code [lehner-lab/pdzext](https://github.com/lehner-lab/pdzext).
- Martí-Aranda & Lehner, 2026, [Seven complete comparative maps of allosteric mutations in a protein family](https://doi.org/10.1038/s41467-026-71005-x).
- Liao & Lehner, 2026, [Allostery is a widespread cause of loss-of-function variant pathogenicity](https://www.nature.com/articles/s41467-026-74517-8). The authors explicitly state that their activity/stability and experimental map analyses do not identify the underlying causal molecular mechanism.
- Faure et al., 2022, [Mapping the energetic and allosteric landscapes of protein binding domains](https://doi.org/10.1038/s41586-022-04586-4), plus the [reproduction code](https://github.com/lehner-lab/doubledeepms).
- Petit et al., 2009, [Hidden dynamic allostery in a PDZ domain](https://pmc.ncbi.nlm.nih.gov/articles/PMC2775317/).
- Saro et al., 2012, [Interactions outside the boundaries of the canonical binding groove of a PDZ domain influence ligand binding](https://pubmed.ncbi.nlm.nih.gov/23046383/).
- Salinas & Ranganathan, 2018, [Coevolution-based inference of amino acid interactions underlying protein function](https://elifesciences.org/articles/34300).
