# RNA cotranscriptional switching: kinetic non-identifiability and a path-exposure estimator

## Verdict

There is a clean exact model result and a useful experiment, but neither should be presented as a new biological mechanism. Equilibrium free energies do not identify a finite-time switch response: reversible kinetics with the same Boltzmann distribution can be arbitrarily slow or fast. Under a narrower and testable first-capture model, single-molecule ligand-free traces yield the complete dose-response curve through a Laplace transform of binding-competent exposure. The empirical curve has a distribution-free, finite-sample band simultaneous over every ligand concentration and a prespecified finite sequence screen.

The exact band does not cover errors in classifying conformations, incomplete trajectories, uncertain association rates, ligand-dependent pre-capture folding, or reversible binding after capture. Existing ZTP work has single-molecule traces and recent expression-platform engineering, but the papers located do not report this path-exposure/Laplace prediction. The method is an internal conditional derivation; novelty/priority is unverified.

## Interface and model

For a fixed sequence `j`, condition set, transcript start state, and actual RNA-polymerase decision time `T`, let `S_t` be the ligand-free cotranscriptional RNA state path. Define `Y_t=1` exactly while the unbound transcript is in a state that can associate with ligand, and `0` otherwise. Its exposure is

`A_j = integral_0^T Y_t dt`, with `0 <= A_j <= T`.

Assume ligand concentration `c` is constant, each competent unbound molecule has a constant association hazard `k_on*c`, and binding is the first event of interest. Up to the first capture, ligand does not alter the ligand-free conformation path; capture is an absorbing commitment for the output being predicted. Conditional on an entire ligand-free path,

`P(no capture by T | S) = exp(-k_on*c*A_j)`.

Thus the first-capture dose response is exactly

`p_j(c) = 1 - E[exp(-k_on*c*A_j)]`.

No Markov assumption on `S_t` is needed for this identity. If association varies across competent states with known rate `k_s`, replace `k_on*A_j` by the weighted exposure `integral_0^T k_{S_t}Y_t dt`; if the rates are unknown they must be acquired. If the ligand concentration varies with time, replace `c*A_j` by `integral_0^T c(t)Y_t dt`.

This is a capture probability. It equals a gene-regulatory output probability only if capture commits the output through the decision. It is not generally the probability of being ligand-bound or in the active conformation at `T` when dissociation and post-binding rearrangements matter.

## Equilibrium-energy no-go

Let the two macrostates be unbound `U` and ligand-bound `B`, with equilibrium bound fraction `p` at the chosen ligand concentration. For every `a>0`, set

`q_a(U,B)=a p`, `q_a(B,U)=a(1-p)`.

Every generator is reversible with the same stationary distribution `(1-p,p)`, hence the same equilibrium free-energy difference `G_B-G_U=-k_B T log(p/(1-p))`. Starting in `U`, the exact finite-time occupancy is

`P_a(B at T)=p(1-exp(-aT))`.

As `a` tends to zero this tends to zero; as `a` tends to infinity it tends to the equilibrium value `p`. Therefore no finite-time response bound based only on equilibrium state energies or equilibrium occupancy can be nontrivial uniformly over these dynamics. In transition-state language, raising the common transition barrier multiplies both forward and reverse rates by the same factor, preserves detailed balance and the energy difference, and changes the response time.

The ligand-binding version fixes `K_D=k_off/k_on` and scales both `k_on` and `k_off` by `a`; at constant ligand concentration `c`,

`p_a(T;c) = c/(c+K_D) * (1-exp(-a*k_on*(c+K_D)*T))`

from an initially unbound aptamer. It has the same equilibrium occupancy `c/(c+K_D)` for every `a`, with arbitrarily different decision-time occupancy. This is the strongest simple counterexample to equilibrium-only design scoring.

As a source-grounded illustration, the pbuE adenine aptamer association/dissociation rates used in the riboswitch literature are `k_on=2.6e5 M^-1 s^-1`, `k_off=0.15 s^-1` at 35 C; Frieda and Block estimate a roughly `2 s` cotranscriptional folding/binding window before the pbuE decision. At `c=K_D`, starting unbound and assuming the site is competent for that entire window, the two-state model gives `p(T)=0.5*(1-exp(-0.6)) ~= 0.226`, against equilibrium occupancy `0.5`. This is a model calculation, not a measured pbuE termination probability; actual folding can shorten or alter the competent exposure.

## Finite-n simultaneous dose-response band

For each of `K` prespecified sequences, collect `n` independent complete ligand-free trajectories under the same transcription, buffer, temperature, and initial-state protocol. Compute their exposures `A_ji`, and for known `k_on,j` form

`p_hat_j(c) = 1 - (1/n) sum_i exp(-k_on,j*c*A_ji)`.

For each sequence, the empirical CDF `Fhat_j` of the exposures obeys the Dvoretzky-Kiefer-Wolfowitz/Massart inequality

`P(sup_a |Fhat_j(a)-F_j(a)| > eps) <= 2 exp(-2 n eps^2)`.

For every `c>=0`, `a -> exp(-k_on,j*c*a)` is monotone and ranges within `[0,1]`. Its empirical-average error is bounded by the same sup-CDF error (write the monotone function as an integral of threshold indicators). Therefore

`P(sup_{c>=0}|p_hat_j(c)-p_j(c)| > eps) <= 2 exp(-2 n eps^2)`.

A union bound over the prespecified `K` sequences gives simultaneous coverage at least `1-delta` for all `j` and all concentrations `c>=0` using

`eps = sqrt(log(2K/delta)/(2n))`.

The clipped bands are `[max(0,p_hat_j(c)-eps), min(1,p_hat_j(c)+eps)]`. To guarantee absolute half-width `eps`, the exact integer design from this bound is

`n = ceil(log(2K/delta)/(2 eps^2))` complete traces per sequence,
`N_complete = K*n` total complete traces.

This bound is conservative but distribution-free and does not require a concentration grid. For example, a prespecified `K=10` screen at 95% simultaneous coverage and absolute half-width `0.10` needs `n=300` complete traces per sequence, `3,000` complete traces total. If a sequence is selected separately at each concentration by maximizing `p_hat_j(c)`, its true response regret is at most `2 eps` simultaneously at every concentration.

This trace count is for exposure sampling only. Add `K` physical constructs and sequence verification; a same-buffer `k_on,j` measurement for each sequence unless a validated common rate is supplied; conformational-state calibration; and `K*n*ceil(T/dt)` camera frames for frame interval `dt` and deterministic horizon `T` (plus setup/readout overhead). If actual decision times vary, record each full path through its own decision event; its resulting `A` is the sample. The candidate sequences are assumed prespecified; if sequence choice adapts to these data or new sequences are added, new confidence accounting is required.

If `k_on` is uncertain but has a confidence interval `[k_-,k_+]`, dose response is monotone in `k`. On a simultaneous event for the exposure bands and the rate interval, use a lower band from `p_hat(c;k_-)-eps` and upper band from `p_hat(c;k_+)+eps`; split the failure budget between rate and exposure acquisition. If no rate is acquired, exposures alone identify the curve only in the rescaled dose `z=k_on*c`, not at physical ligand concentrations.

## Censoring and temporal resolution

A trace stopped by photobleaching, tether loss, or instrument shutdown before the transcription decision records only `A_obs<=A`. The complete-case DKW band is valid if censoring is independent of the RNA path and the retained complete traces are sampled under a common protocol; state-dependent censoring can bias the exposure distribution. With known censoring survival and additional assumptions, one can use a survival-analysis model, but it is not covered by the bound above. Without a bound or model for unobserved exposure after censoring, the full-horizon dose curve is only lower-bounded by `1-E exp(-k_on*c*A_obs)`; the upper bound can be 1.

Discrete-frame FRET also does not directly observe dwell time. Two or more state transitions can occur between frames without appearing in sampled endpoints. If a certified per-trace exposure error `|Ahat-A|<=eta_A` is available, then over a finite concentration range `[0,Cmax]` the dose prediction incurs at most an additional `min(1,k_on*Cmax*eta_A)` absolute error. A uniform bound over all `c>=0` requires relative exposure-error control (and matching zeros); if `|Ahat-A|<=rA` for `0<=r<1`, the extra error is at most `r/(e*(1-r))`. Without such an error certificate or a calibrated hidden-state/transition-rate model, temporal discretization leaves the all-concentration band unverified.

## Strongest counterexample to exposure-only output prediction

Equal integrated exposure does not imply equal endpoint occupancy when binding is reversible. Set the competent interval to `[0,T/2]` for one path class and `[T/2,T]` for another; both have `A=T/2`. Let capture rate while competent be `lambda=k_on*c`, and let bound ligand dissociate at rate `mu>0`; after the competent interval, assume no rebinding is possible. The probability of still being bound at decision is

`P_early = integral_0^(T/2) lambda*exp(-lambda*s)*exp(-mu*(T-s)) ds`,

`P_late  = integral_(T/2)^T lambda*exp(-lambda*(s-T/2))*exp(-mu*(T-s)) ds`.

Direct evaluation gives `P_late=exp(mu*T/2)*P_early > P_early`, despite identical `A`. The Laplace estimator remains exact for ever-captured-before-decision probability, but not for the bound-at-decision regulatory output. The source-reported pbuE `k_off=0.15 s^-1` makes irreversibility a testable approximation rather than an automatic assumption. For multi-step partial ligand contacts, a one-state competent indicator and one `k_on` can also be inadequate; the 2025 engineering paper explicitly discusses partial cotranscriptional contacts as a possible source of the residual EC50/KD gap.

A decisive validation therefore measures (i) ligand-free competent-state exposure to the actual transcription decision, (ii) association and dissociation rates in the same condition, and (iii) direct transcript termination/readthrough at held-out concentrations. Compare the exposure-Laplace curve against the equilibrium `KD` curve and a full multistate CTMC fit using the same sequence, buffer, and kinetic data. Failure is a reproducible held-out dose response outside the exposure band, after accounting for rate and exposure-measurement error; this would reject the absorbing one-rate capture model and motivate state-specific binding or post-capture transitions.

## Primary literature boundary

- Wickiser et al., “The Kinetics of Ligand Binding by an Adenine-Sensing Riboswitch,” *Biochemistry* (2005), [DOI 10.1021/bi051008u](https://doi.org/10.1021/bi051008u): measured equilibrium and kinetic constants for pbuE aptamer/ligands and modeled switching between kinetic and equilibrium control. This directly supports the need for absolute rates in addition to affinity.
- Frieda & Block, “Direct Observation of Cotranscriptional Folding in an Adenine Riboswitch,” *Science* (2012), [DOI 10.1126/science.1225722](https://doi.org/10.1126/science.1225722): optical-trap observations of nascent pbuE RNA and transcription termination support kinetic commitment during the brief transcription window.
- Bushhouse et al., “Real-time monitoring of single ZTP riboswitches reveals a complex and kinetically controlled decision landscape,” *Nature Communications* (2020), [DOI 10.1038/s41467-020-18283-1](https://doi.org/10.1038/s41467-020-18283-1): the nearest single-molecule precedent. It uses 75-ms-resolution FRET trajectories in a helicase-based vectorial-folding assay, reports intermediate/endpoint populations under ligand conditions, and relates faster/slower unwinding and pauses to switching. It does not report integrating ligand-free binding-competent dwell time `A` and predicting a full concentration curve through its Laplace transform. Raw data are available from the authors on request, not as a ready public trajectory table.
- Bushhouse et al., “Tuning strand displacement kinetics enables programmable ZTP riboswitch dynamic range in vivo,” *Nucleic Acids Research* (2023), [DOI 10.1093/nar/gkad110](https://doi.org/10.1093/nar/gkad110): sequence/structure modifications tune internal strand-displacement kinetics and dynamic range; it is functional design evidence, not an exposure-Laplace predictor.
- Bushhouse et al., “RNA folding kinetics control riboswitch sensitivity in vivo,” *Nature Communications* (2025), [DOI 10.1038/s41467-024-55601-3](https://doi.org/10.1038/s41467-024-55601-3): EP loop/remote-toehold engineering alters sensitivity and dynamic range across riboswitches; selected variants are measured with reporter dose responses and IVT, and a FACS-seq screen characterizes 3,289 loop sequences. It does not collect per-molecule ligand-free exposure paths or make the all-dose Laplace prediction. It reports that engineered EC50 values can remain 2–200-fold above aptamer KD and discusses partially bound cotranscriptional states as one possible explanation, a warning against assuming one irreversible full-aptamer state.
- As closely related but not equivalent evidence, the 2025 “Sequential structure probing of cotranscriptional RNA folding intermediates,” *Nature Communications*, [DOI 10.1038/s41467-025-60425-w](https://doi.org/10.1038/s41467-025-60425-w), positions RNAP at multiple transcript lengths and chemically probes ensemble structural rearrangements including Cbe pfl ZTP. Separate ensemble snapshots do not by themselves provide same-molecule accumulated competent exposure or its distribution.

The elementary two-state finite-time formula and explicit kinetic-network models predate this note. The DKW/Laplace concentration band is an internally derived statistical consequence of the path-hazard model; this bounded search did not find it implemented as a riboswitch dose-response predictor, but no priority claim is made.

## Evidence status and next gate

- Internal exact result: equilibrium energies alone do not identify finite-time switching under detailed balance; two-state rate-scaling counterexample proves it.
- Conditional theorem: path-exposure/Laplace identity and simultaneous DKW bands hold under the explicit constant-hazard, complete-path and i.i.d.-trace assumptions.
- Source-reported experimental support: pbuE and ZTP switches are kinetically controlled, and slowing expression-platform nucleation can tune sensitivity/dynamic range.
- Not established: that the one-state irreversible-capture model predicts a specific riboswitch's regulatory output, that trajectory classification gives certified `A`, or novelty/priority.
- Decisive next gate: for a fixed small prespecified K panel, directly acquire complete ligand-free smFRET paths, independently measure `k_on`/`k_off`, compute simultaneous bands before seeing held-out ligand outcomes, and test termination/readthrough at preregistered concentrations against both KD-only and full CTMC controls.
