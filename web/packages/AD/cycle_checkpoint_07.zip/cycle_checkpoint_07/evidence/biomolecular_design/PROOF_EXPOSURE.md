# Riboswitch exposure-law result: proof and limits

## Interface

Fix one RNA sequence, ionic/temperature conditions, a cotranscriptional decision window `[0,T]`, and a ligand concentration `c`. Before its first cognate-ligand binding event, each transcript follows a ligand-free conformational path `X(t)`. Let `r(X(t))` be the pseudo-first-order binding rate per unit ligand concentration in the currently occupied conformation. The special case is `r(X)=k_on 1{X is binding competent}`. Assume binding events are conditionally Poisson with hazard `c r(X(t))`, no binding event dissociates before the decision, and successful binding commits the same regulatory output. This model predicts ligand capture, and predicts the regulatory output only when the commitment assumption is experimentally warranted.

Define the cumulative exposure

`A_T = integral_0^T r(X(t)) dt`.

If `0 <= r <= r_max`, then `A_T` lies in `[0,r_max T]`. Conditional on the entire ligand-free trajectory, the probability of no capture is `exp(-c A_T)`. Thus the population capture curve is

`R(c) = 1 - E[exp(-c A_T)]`.

All conformational microstates matter to this interface only through the probability law `G` of `A_T`. Distinct folding networks with the same `G` have exactly the same capture curve at every ligand concentration.

Moreover, on the bounded interval `[0,r_max T]`, `G` is the unique probability law producing a given *entire* exact dose-response curve. If two laws have the same `R(c)` for every `c>=0`, their Laplace transforms agree. Bounded support makes the transform entire, so derivatives at zero give equality of all moments; the Hausdorff moment problem on a compact interval is determinate, hence the laws coincide. Thus `G` is both sufficient and necessary for predicting the complete curve under this interface, even though it does not identify the underlying folding microstates or rates.

## Finite-dose non-identifiability

Let a fixed assay panel use `m` distinct positive concentrations `c_1,...,c_m`, and choose any additional positive concentration `c_*` outside that panel. For every `T r_max > 0`, there exist two distinct probability distributions `G_+` and `G_-` supported on `[0,r_max T]` such that

`integral exp(-c_j a) dG_+(a) = integral exp(-c_j a) dG_-(a)` for every `j=1,...,m`,

while the two integrals differ at `c_*`. Therefore exact readout at finitely many doses does not identify, and cannot distribution-freely certify, the dose-response curve away from the assayed doses.

**Proof.** Put `q=m+2`, select `q` distinct exposure values `a_1,...,a_q` in the allowed interval, and form the `(m+1) x q` matrix whose rows are the constant function `1` and the functions `exp(-c_j a_l)`. Its nullspace has positive dimension. The `m+2` functions `1,exp(-c_1 a),...,exp(-c_m a),exp(-c_* a)` form a Chebyshev system on an interval: a nonzero linear combination of `q` distinct real exponentials has at most `q-1` zeros, by induction using Rolle's theorem after factoring out the smallest exponent. Hence, for distinct `a_l`, their square evaluation matrix is nonsingular. A nonzero null vector `h` of the first matrix consequently satisfies `sum_l h_l exp(-c_* a_l) != 0`; also `sum_l h_l=0`. Start from uniform positive weights `w_l=1/q` and choose `s>0` small enough that `w_l +/- s h_l >= 0` for all `l`. These are probability weights because `sum h_l=0`; they match all `m` observed Laplace values because the first `m` exponential rows annihilate `h`, but disagree at `c_*`. ∎

This is an information limit, not a statement that a Hill or CTMC fit fails on every real riboswitch. Parametric assumptions, known transitions, or direct path data can resolve the ambiguity.

The mean-exposure bounds have a concrete kinetic interpretation. Let the mean competent occupancy be `p=1/2` throughout the window and let `c k_on T=2`. A slow, trapped population with half the transcripts competent for the whole window and half never competent has `R=0.5(1-exp(-2))=0.4323`. A rapidly mixing population with the same one-time competent fraction has cumulative exposure concentrating at `T/2`, hence `R -> 1-exp(-1)=0.6321` as its switching rate grows. Both populations have the same ensemble competent fraction at every time; their capture outputs differ by about 0.20. These are the sharp chord/Jensen endpoints and can be approached by slow- and fast-switching two-state processes with the same stationary occupancy.

## Trajectory-based uniform certificate

Suppose instead that `A_1,...,A_n` are independent, complete single-transcript exposure measurements from the same sequence and decision window. Define

`R_hat_n(c) = 1 - (1/n) sum_i exp(-c A_i)`.

By the Dvoretzky-Kiefer-Wolfowitz inequality, with probability at least `1-delta`,

`sup_{c >= 0} |R_hat_n(c)-R(c)| <= sqrt(log(2/delta)/(2n))`.

The reason the CDF bound controls all concentrations is that `g_c(a)=1-exp(-c a)` is monotone from `[0,r_max T]` into `[0,1]`; integration by parts gives `|E_G g_c-E_Ghat g_c| <= sup_a|F(a)-Fhat(a)| * integral_0^(r_max T) g'_c(a) da <= sup_a|F(a)-Fhat(a)|`, uniformly in `c`.

For `K` candidate sequences, a union bound gives the simultaneous guarantee

`Pr( for every sequence k, sup_{c>=0}|R_hat_k(c)-R_k(c)| <= eps ) >= 1-delta`

when each sequence has

`n >= ceil(log(2K/delta)/(2 eps^2))`

independent complete trajectories. If the design score is capture at a specified dose or the worst capture over a prespecified set of doses, selecting the candidate with maximum empirical score loses at most `2 eps` relative to the best candidate in the panel. The same result holds across `J` prespecified environments by replacing `K` with `KJ`; a max-min-across-environments selector also loses at most `2 eps`.

### Assay-facing costs and error

This is a trajectory acquisition cost, separate from sequence construction and the independent reporter validation needed to establish that capture commits the regulatory output. For example, with `K=16`, `delta=0.05`, and `eps=0.1`, the bound requires 324 complete trajectories per candidate (5,184 total) in each condition/window; at `eps=0.05`, it requires 1,293 per candidate (20,688 total). These are conservative DKW sufficient counts, not a claim of optimality. Candidate sequences sharing an aptamer but differing only in their expression platform are the cleanest matched panel because the binding-hazard calibration can be shared.

If exposure estimates have a deterministic uniform error `|Ahat_i-A_i| <= eta_A` and one predicts only `c <= c_max`, then the curve error increases by at most `c_max eta_A`, since `|g'_c(a)| <= c`. Ligand concentration / association-rate uncertainty must be added separately. Photobleached or otherwise incomplete trajectories do not satisfy the theorem; handling censoring requires a stated survival/interval-censoring model. A reporter curve also includes RNA synthesis, termination, and downstream expression variability, so an independent output assay is required before transferring the capture certificate to cellular expression.

## Prior-art boundary and status

The exponential survival formula is a standard conditional-hazard identity; DKW and exponential Chebyshev-system arguments are standard mathematics. This note claims no priority for those ingredients. The application-specific contribution is the exact reduction from hidden cotranscriptional folding to the law of cumulative ligand-competent exposure, paired with (a) a finite-dose distribution-free non-identifiability construction and (b) an all-dose finite-sample acquisition certificate. A bounded primary-source search found established CTMC/kinetic models, ligand-window manipulation, and single-molecule RNA dynamics, but did not establish that these exact distribution-free statements are absent from the literature. Novelty remains unresolved.

Useful primary anchors:

- Wickiser et al., adenine riboswitch association/dissociation and kinetic/equilibrium control, *Biochemistry* (2005), DOI `10.1021/bi051008u`.
- Frieda & Block, direct observation of cotranscriptional folding and one-shot pbuE switching, *Science* (2012), DOI `10.1126/science.1225722`.
- Beisel & Smolke, kinetic rate model and riboswitch response descriptors, *PLoS Computational Biology* (2009), DOI `10.1371/journal.pcbi.1000363`.
- Sun, Zhao & Chen, stochastic cotranscriptional folding kinetics model, *J. Phys. Chem. B* (2018), DOI `10.1021/acs.jpcb.8b04249`.
- Bushhouse, Fu & Lucks, expression-platform kinetic tuning of sensitivity and dynamic range, *Nature Communications* (2025), DOI `10.1038/s41467-024-55601-3`.
- Liao et al., single-molecule cotranscriptional folding heterogeneity in the SAM/SAH riboswitch, *Nucleic Acids Research* (2023), DOI `10.1093/nar/gkad633`.

The next discriminating experiment is a matched sequence panel with the same aptamer and measured equal mean exposure but different dwell-time correlation (e.g. expression-platform loop/toehold variants); collect complete cotranscriptional single-molecule trajectories, predict the dose curves without fitting a Hill curve, and independently measure termination/readthrough over the same ligand titration. A failure of `R(c)=1-E exp(-cA_T)` after calibrated binding/commitment would refute the model contract; a successful curve prediction would establish only that panel, assay, and condition.
