# Cycle 2: reversible RNA switching with robust sequence ranking

## Result and evidence status

The stronger design interface is a three-state reversible capture model. It replaces the first-cycle Laplace/exposure result, which predicts *ever-capture* only when binding is absorbing, with a testable model for *bound occupancy at the decision time* under association and dissociation. Its exact solution gives the concentration/time response surface. More usefully, a favorable partial order on four measured transition rates certifies that one sequence has at least as much bound-state output as another for every nonnegative ligand concentration and every decision time. Rate confidence intervals turn that condition into a prespecified, finite-data ranking algorithm.

This is a conditional result about a homogeneous three-state CTMC. The CTMC and stochastic-order ingredients are standard, and prior riboswitch papers already model reversible ligand binding with folding and transcription states. I found no defensible novelty or priority claim. The useful consequence is an operational one: after acquiring state-resolved rates, one can certify an all-dose/all-time pairwise design ranking without collecting a reporter dose-by-time grid, provided the three-state model passes its diagnostics. When rates trade off, the correct result is `UNKNOWN` for universal ranking; a dose/time-specific response interval can still support a narrower choice.

## Measurable interface

For each sequence at a fixed buffer, temperature, polymerase protocol, and initial condition, classify the transcript into three states:

- `U`: unbound and ligand-incompetent;
- `C`: unbound and ligand-competent;
- `B`: ligand-bound.

The model has transitions `U -> C` at rate `alpha`, `C -> U` at rate `beta`, `C -> B` at rate `c k_on`, and `B -> C` at rate `k_off`. Here `c` is the controlled ligand concentration. The measured design outcome is `P(B at t)` at the polymerase decision time `t`. A separate calibration is required before interpreting this bound-state probability as readthrough, termination, or cellular expression.

The model contract is narrow and falsifiable: state labels are resolved; each dwell time is exponential; the `C -> B` hazard is linear in `c`; the rates do not vary during the decision window; and no unmodeled bound intermediate or transcription-stage-dependent exit changes the order. Three-state dwell fits, a second ligand concentration, and held-out transcription/readthrough assays are explicit adequacy checks. If they fail, expand the state graph; do not retain the ranking certificate by relabeling hidden states.

## Exact response surface

Use the row generator

\[
Q(c)=\begin{pmatrix}
-\alpha&\alpha&0\\
\beta&-(\beta+\gamma)&\gamma\\
0&\delta&-\delta
\end{pmatrix},\qquad \gamma=c k_{\rm on},\quad \delta=k_{\rm off},
\]

and initialize in `U`. Put

\[
S=\alpha+\beta+\gamma+\delta,\quad
D=\alpha\gamma+\alpha\delta+\beta\delta,\quad
r_\pm=(S\pm\sqrt{S^2-4D})/2,\quad
\pi_B=\alpha\gamma/D.
\]

For `c>0` and distinct roots, direct inversion of the state-2 Laplace transform
\[
\widehat p_B(s)=\frac{\alpha\gamma}{s(s^2+Ss+D)}
\]
gives
\[
p_B(c,t)=\pi_B\left[1-\frac{r_+e^{-r_-t}-r_-e^{-r_+t}}{r_+-r_-}\right].
\]
At a repeated root `r_+=r_-=r`, use the continuous limit `p_B=pi_B[1-(1+rt)e^{-rt}]`; at `c=0`, `p_B=0`. The boundary checks are
\[
p_B(c,t)=\tfrac12\alpha c k_{\rm on}t^2+O(t^3),\qquad
\lim_{t\to\infty}p_B(c,t)=
\frac{\alpha k_{\rm on}c}{\alpha k_{\rm on}c+k_{\rm off}(\alpha+\beta)}.
\]
This makes the decision-time response computable from acquired rates rather than inferred from equilibrium affinity alone.

## All-concentration/all-time ranking theorem

Order states `U < C < B`. For two candidate sequences `A` and `B` initialized in `U`, assume
\[
\alpha_A\ge\alpha_B,\qquad
\beta_A\le\beta_B,\qquad
k_{{\rm on},A}\ge k_{{\rm on},B},\qquad
k_{{\rm off},A}\le k_{{\rm off},B}.
\]
Then, for every common `c>=0` and every `t>=0`,
\[
\Pr_A(X_t=B)\ge\Pr_B(X_t=B).
\]

**Proof.** These inequalities order each upward rate in the favorable direction and each downward rate in the favorable direction. Couple both chains when they occupy the same state by sharing the smaller upward rate and assigning the residual upward jumps to A; share the smaller downward rate and assign residual downward jumps to B. Every unmatched jump separates the chains in the favorable order. When their states differ, nearest-neighbor jumps can close a gap but cannot cross it; after they meet, resume the common-state coupling. Starting from the same state therefore gives `X_A(t)>=X_B(t)` pathwise for all `t`. The indicator of state `B` is increasing, so taking expectations proves the claim. The same coupling works at every `c>=0`. It also works for a shared time-varying ligand input `c(t)>=0`, since the upward binding-rate order holds pointwise in time. This is the standard birth-death monotonicity argument specialized to the riboswitch state order.

The theorem gives a **partial** order. It does not claim that more affinity, more accessibility, or a better value at one dose produces a universal ranking when other rates trade off. For example, set `alpha=beta=1 s^-1` for both sequences and `c=1 micromolar`. Candidate A with `(k_on,k_off)=(2 micromolar^-1 s^-1,10 s^-1)` starts with `p_A(t)=t^2+O(t^3)`, while B with `(1 micromolar^-1 s^-1,1 s^-1)` has `p_B(t)=t^2/2+O(t^3)`. A is initially ahead, but their stationary bound probabilities are `1/11` and `1/3`, respectively. The exact curves cross at `t=0.273165... s` (A≈0.00649 versus B≈0.00438 at 0.1 s, and A≈0.02921 versus B≈0.03069 at 0.3 s). A robust ranking procedure must preserve such pairs as incomparable unless a specific operating point is selected.

## Finite-data rate acquisition and algorithm

For each prespecified construct, collect state-resolved complete dwell intervals at one calibrated concentration `c_star>0`. In the model:

- `U` dwells are exponential with rate `alpha`;
- `C` dwells are exponential with total exit rate `rho=beta+c_star*k_on`; the exit is `B` with probability `r=c_star*k_on/rho` and `U` otherwise, independently of the dwell duration;
- `B` dwells are exponential with rate `k_off`.

Thus one positive concentration identifies the four rates in the model. A second concentration checks the assumed linear binding hazard. For `m` independent complete dwell episodes with total duration `S_q`, an exponential rate `q` has the exact two-sided `1-eta` interval
\[
\left[\frac{\chi^2_{2m,\eta/2}}{2S_q},
      \frac{\chi^2_{2m,1-\eta/2}}{2S_q}\right].
\]
For the `m_C` competent-state episodes with `x` exits to `B`, use the exact Clopper-Pearson interval for `r`. If `rho in [rho_L,rho_U]` and `r in [r_L,r_U]`, transform conservatively:
\[
\begin{aligned}
 c_\star k_{\rm on}&\in[\rho_Lr_L,\rho_Ur_U],\\
 \beta&\in[\rho_L(1-r_U),\rho_U(1-r_L)].
\end{aligned}
\]
Divide the first interval by `c_star` for `k_on`. Use exponential intervals for `alpha` and `k_off`.

For `K` frozen sequences, allocate `eta=delta/(4K)` to each of the four primitive intervals per sequence. A union bound gives simultaneous `1-delta` coverage of every transformed rate interval. Certify `A` over `B` only when
\[
\alpha_L(A)\ge\alpha_U(B),\quad
\beta_U(A)\le\beta_L(B),\quad
k_{{\rm on},L}(A)\ge k_{{\rm on},U}(B),\quad
k_{{\rm off},U}(A)\le k_{{\rm off},L}(B).
\]
The theorem then certifies their ordering over the full continuum `c>=0,t>=0` with confidence at least `1-delta`. Otherwise report `UNKNOWN` for global ranking. At a specified `(c,t)` or compact operating window, evaluate the exact formula on the parameter-rectangle corners to obtain a conservative response band; the corners are valid because the response is monotone increasing in `alpha,k_on` and decreasing in `beta,k_off`.

If outcomes are inspected repeatedly, fixed-look intervals no longer retain their nominal coverage. One simple planned-look correction uses `eta_l=delta/[4K l(l+1)]` for look `l`; summing over looks and four parameters per sequence spends at most `delta` in total. More efficient confidence sequences are possible but are not needed for this certificate.

## Quantitative design prediction and discriminating experiment

Use the pbuE aptamer association/dissociation rates reported at 35 °C, `k_on=2.6e5 M^-1 s^-1` and `k_off=0.15 s^-1` ([Wickiser et al.](https://doi.org/10.1021/bi051008u)), as a source-grounded kinetic calibration. For a **hypothetical, not measured** expression-platform pair sharing those aptamer rates, let A have `alpha=2 s^-1, beta=0.5 s^-1` and B have `alpha=0.5 s^-1, beta=2 s^-1`. They satisfy the favorable rate order. At `c=10 micromolar` and `t=2 s`, the exact model predicts
\[
p_A(B_t)=0.853260,\qquad p_B(B_t)=0.354588,
\]
an absolute separation of about `0.499`. The theorem predicts A remains at least as responsive at all other concentrations and decision times, including any nonnegative ligand pulse schedule, as long as the rate order and model contract continue to hold. These `alpha,beta` values are a concrete falsifiable target for a synthetic panel, not reported biology.

Make two to four expression-platform loop/toehold variants while keeping the same aptamer sequence. First collect complete three-state single-molecule FRET trajectories in the same transcription/buffer/temperature condition at `c_star`; measure at a second concentration to check `c*k_on` scaling and confirm the fitted state graph. Freeze simultaneous rate intervals and the pairwise ranking before collecting validation outcomes. Then test direct bound occupancy or termination/readthrough at a withheld concentration and decision time, and at one altered polymerase pause condition. Compare against an equilibrium-`K_D` ranking and a Hill fit given the same reporter dose grid; a richer CTMC control may use the same trajectories but must pay for each additional state and transition. A reproducible validation response outside the predicted parameter band, non-exponential dwell survival, concentration-dependent nonlinearity, or loss of rate order under the pause perturbation falsifies the certificate for that construct/context.

The minimum measured kinetic data are three state-specific dwell samples per construct family: U, C, and B. With `m_U=m_C=m_B=m` complete episodes and `K` sequences, the fixed-look core-data count is exactly `3Km` completed dwell episodes. If each episode is separately prepared in its source state, the expected sum of the planned dwell durations for sequence `j` is `m/alpha_j + m/(beta_j+c_star*k_on,j) + m/k_off,j`; this excludes state preparation. If an uninterrupted trajectory is used, extra episodes accrued while waiting for the slowest state count as overshoot and must be included in the observed cost. Checking concentration linearity at a second dose adds a separate set of C-state episodes; it is a model diagnostic, not part of the minimal four-rate identification count. Additional costs are `K` construct syntheses and QC, calibrated FRET state assignment, ligand concentration calibration, camera frames (trajectory duration divided by frame interval), state-preparation failures, censoring/photobleaching losses, and the held-out transcript assays. No dollar figure is asserted because it depends on platform and lab. Constant-size formula evaluation per requested `(c,t)` is negligible; fitting/validating the CTMC and acquiring labeled dwell events dominate.

## Prior art, limits, and verdict

Beisel and Smolke already model reversible folding, ligand association/dissociation, transcription stages, and response curves for riboswitches ([primary paper](https://doi.org/10.1371/journal.pcbi.1000363)). Lin and Thirumalai give a richer kinetic riboswitch network with folding, reversible ligand binding, and transcription/termination ([primary paper](https://doi.org/10.1016/j.bpj.2012.10.026)). Frieda and Block directly measured cotranscriptional pbuE trajectories and kinetic commitment ([primary paper](https://doi.org/10.1126/science.1225722)). Bushhouse et al. measured single-molecule ZTP trajectories and a kinetically controlled decision landscape ([primary paper](https://doi.org/10.1038/s41467-020-18283-1)) and later tuned sensitivity/dynamic range by expression-platform kinetics ([primary paper](https://doi.org/10.1038/s41467-024-55601-3)). Reining et al. identified three stable conformations in the `add` adenine riboswitch, illustrating why the proposed `U,C,B` coarse graining must be tested for each construct ([primary paper](https://doi.org/10.1038/nature12378)). Keilson and Kester established monotonicity of birth-death Markov processes ([primary paper](https://doi.org/10.1016/0304-4149(77)90033-3)). These sources preempt novelty claims for kinetic riboswitch models and monotone-chain arguments. The bounded search did not establish whether this exact confidence-certified all-dose/all-time sequence-ranking protocol has been published; priority remains unresolved.

The main biological risk is model adequacy: current riboswitch work reports multiple stable conformations, hidden intermediates, partially bound states, transcription pauses, and ligand-dependent folding. A fitted three-state generator may therefore be only a low-resolution approximation. The theorem is exact for the stated generator and says nothing about nature until its state/dwell/rate assumptions pass. No sequence was synthesized, no trajectory acquired, no predictor benchmarked, and no external proof or novelty review performed. The deliverable is an internally reconstructed conditional design certificate and a decisive experiment, not a validated biomolecular advance.
