# C13 driven chemistry screen: bounded rejection and next gate

## Status

This round is frozen at an informed screen. It establishes no new chemistry theorem, catalyst design, harvested-flux capability, or validated experimental prediction. C12’s conservation and volume audit remains unchanged in `work/agents/c12_driven_chemistry/`.

## C13 target selection

The first candidate—compile detailed balance and driven control into a selectivity/energy design rule for catalytic networks—has two close 2026 preemptions. Yang and Dill’s Caliber Force Theory (CFT) work already gives nonequilibrium flow coordinates and inverse/forward design, including kinetic proofreading and enzyme inhibition. Liang, De Los Rios, and Busiello’s “Thermodynamic Space” work already bounds stationary reaction affinities and concentration ratios from cycle affinities/EFMs, and ships TACOS for small-to-medium networks. A generic cycle-current, affinity, or concentration compiler would therefore be duplicate territory. Neither paper, in the portions screened, gives a tested bridge from a heterogeneous-catalysis microkinetic network to *physically harvested* product selectivity under experimentally bounded rates and extraction costs; that is a possible gap, not a result.

The fresh application screen was Morandi et al.’s CARE framework for heterogeneous catalysis. Its paper itself says rate/selectivity-control functions and robust pruning of very large networks remain future work. The source reports a CHO network generator, GAME-Net-UQ energy/transition-state predictions, thermodynamically consistent reverse rates, and plug-flow microkinetics. Its Fischer–Tropsch calculation simulates a 4,203-species/36,843-reaction linear-product subnetwork; the authors flag 0.3–0.8 eV activation-energy uncertainty, 83% valid transition-state ordering, and an artificial C6+ accumulation caused by the C6 cutoff. This is a credible, distinct application interface, but the screen did not download or rerun CARE, reconstruct its full rates, or demonstrate an improved catalyst design.

## Conditional quantitative diagnostic

At CARE’s stated Fischer–Tropsch temperature, 523.15 K, (k_BT=0.04508) eV. If the reported 0.3–0.8 eV uncertainty is treated as a one-sided error in a single activation barrier with transition-state-theory prefactor fixed, the corresponding rate multiplier is 

\[
\exp(\delta E/k_BT) \in [7.76\times10^2,\;5.09\times10^7].
\]

This is a conditional scale calculation, not an uncertainty interval on any specific product rate: the paper’s parameter correlations, uncertainty calibration for each reaction, and nonlinear network propagation must be respected before drawing that conclusion. It does show why a selectivity claim needs a rate- and network-level uncertainty calculation rather than a barrier MAE alone.

## Candidate next advance (unverified)

The strongest fresh gate is an experimentally grounded, uncertainty-aware control layer for CARE: take a fixed reaction-network blueprint, measured feed/temperature/potential/flow, calibrated output collection, and interval or correlated uncertainty on transition-state energies; then return a certified attainable region for target and side-product *harvest rates* versus chemical/electrical input and collection work. A useful method would need to prove soundness and completeness on a declared network class, emit a constructive rate/control design or a dual impossibility certificate, and identify which DFT or kinetic measurement most narrows the target-vs-side-product decision. This must account for feed pumping, reactor heat, electrical drive, separation/quench, enzyme/site loading or surface coverage, and the cost/precision of acquired measurements. No part of that algorithm was implemented here.

The immediate falsifier for any future candidate is to replay the frozen CARE v0.1.3 methanol or C3 electrochemical case from its public archive, fit its observable rates on a training subset, and evaluate a held-out catalyst/condition at matched conversion and elapsed time. Compare against a baseline with the same kinetic information and the same output-recovery protocol. A proposed design fails if its predicted selectivity gain vanishes under the published parameter uncertainty, if a matched-throughput baseline explains it, or if extraction/actuation work erases the advantage.

## Evidence boundary

The source scan is primary-source informed but bounded. “CARE authors identify this as future work” is source-reported; the Arrhenius multiplier is internally calculated under the stated conditional assumption; a robust control/compiler is only a research target. No claim about chemical reality, novelty priority, or performance in nature is made.
