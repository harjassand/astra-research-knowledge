# Correction record — 2026-10-08

The prior draft of `FINAL_REPORT.md` said that the unrestricted all-n star
bound and the separation argument “would imply feasibility” of the LP over
the finite family \(\psi_0,\ldots,\psi_n\) for every self-compatible
channel. This conflated continuous-support feasibility with feasibility in a
restricted finite seed hull. That implication was too strong and is withdrawn.

The corrected status distinguishes:

1. The unrestricted all-n continuous-support star inequality, which remains
   **UNKNOWN**.
2. The strictly stronger support inequality restricted to the moment vectors
   of \(\psi_0,\ldots,\psi_n\), sufficient for the finite LP. Per the parent
   checkpoint, its finite Spin(15) test fails. This only blocks that sufficient
   argument; it does not prove infeasibility of the LP for any particular
   legal transfer vector.
3. Direct exact LP feasibility for supplied rational transfers. A feasible
   solution produces the stated comparator; infeasibility rules out only
   this finite seed family for those transfers.

The all-n exact signed-permutation seed-channel compiler theorem is unchanged.
There is no all-n mixture compiler guarantee. No research, numerical test, or
new computation was performed for this correction; the Spin(15) status above
is recorded from the parent checkpoint instruction.
