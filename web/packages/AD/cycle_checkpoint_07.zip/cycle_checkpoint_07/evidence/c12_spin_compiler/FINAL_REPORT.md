# C12 Spin compiler: exact finite readout and conditional all-n compiler

## Result and status

There is an exact, polynomial-resource randomized-basis compiler for every
odd-dimensional spinor model \(\mathrm{Spin}(2n+1)\), conditional only on
being given a stabilizer seed (or the explicit family below). Uniform even
coordinate permutations, together with the even-sign Pauli subgroup, reproduce
the complete Haar-covariant measure-and-prepare channel of that seed on the
whole operator algebra. They do not require a factorial orbit table. The
explicit seed family \(\psi_h\) has exact stabilizer preparation circuits
and rational grade transfers.

The compiler for the canonical channel is proved. The use of a common seed
mixture as a comparator for every self-compatible covariant channel remains
**conditional** on additional support/feasibility conditions. The unrestricted
all-n continuous-support star inequality remains **UNKNOWN**, and even if it
holds it does not by itself imply feasibility of the LP over the restricted
finite seed family \(\psi_0,\ldots,\psi_n\). No all-n mixture guarantee is
proved. A q-mixture solver can return a comparator only when the supplied
transfers satisfy that finite family's inequalities. No channel-transfer
acquisition protocol, hardware experiment, formal proof assistant run,
external proof review, novelty result, or priority claim is asserted.

The sibling n=7 r=0 finite-seed probes are lower-support artifacts; they are
neither an all-n star proof nor a channel counterexample.

For Spin(9), I independently rebuilt the exact 9/63/72 partitions into
16-outcome bases, directly recomputed the three Clifford-moment vectors, replayed
the listed JW stabilizer readouts, and synthesized the real-spinor/JW
intertwiner. The old generic Naimark cost is unnecessary for these finite
POVMs. The JW circuits have explicit gates. The coordinate intertwiner is not
a JW Pauli Clifford, but it has an exact four-qubit Clifford+T synthesis.

## Finite Spin(9) audit

Use the certificate convention (q_0) least significant and JW words ordered
(q_0,q_1,q_2,q_3):

\[
 (\Gamma_1,\ldots,\Gamma_9)=
 (XIII,YIII,ZXII,ZYII,ZZXI,ZZYI,ZZZX,ZZZY,ZZZZ).
\]

The group is \(D^+\rtimes\mathrm{PGL}_2(8)\), where \(D^+\) is the
256-element even-coordinate-sign subgroup and PGL has order 504. The complete
JW calculation reconstructs one orbit on every k-subset layer (k=1,2,3,4),
with sizes (9,36,84,126). It reconstructs the exact basis stabilizers and
disjoint ray partitions:

| seed | projectors (N) | bases (M=N/16) | effect per projector | moments ((s_1,s_2,s_3,s_4)) |
|---|---:|---:|---:|---|
| (v_R) | 144 | 9 | (1/9=16/144) | ((1,0,0,14)) |
| (v_V) | 1008 | 63 | (1/63=16/1008) | ((1,4,4,6)) |
| (v_H) | 1152 | 72 | (1/72=16/1152) | ((0,1,7,7)) |

For each seed, each block contains 16 unit vectors with every pair exactly
orthogonal; the blocks are pairwise disjoint and their union is the complete
projector orbit. Thus every block is a PVM and the orbit POVM effect is

\[
 E_{p,j}=M^{-1}|b_{p,j}\rangle\langle b_{p,j}|
       =(16/N)|b_{p,j}\rangle\langle b_{p,j}|.
\]

Summing over the 16 outcomes of each basis gives (I_{16}), so averaging the
bases gives an exact normalized POVM. The measure-and-prepare channel has

\[
 \Psi_i(T_A)=\frac{s_{i,k}}{\binom{9}{k}}T_A,
 \qquad |A|=k,\quad 1\leq k\leq4,
\]

and \(\Psi_i(I)=I\). This identity holds on the complete 256-element
Hermitian JW Clifford basis, hence for every input matrix, with no covariance,
parity, Gaussianity, or state-preparation assumption on the input. Its
Spin(9)-covariance follows because the grade transfers are scalar. Exact
finite-group character cancellation plus PGL subset transitivity gives the
same identity as the Spin(9) Haar-orbit channel, not only agreement on selected
states.

The certificate's JW seed readouts replay exactly, including the full 16-ray
stabilizer groups. These are the chronological preparation circuits from
|0000⟩; measure in the transformed basis by applying the inverse circuit
before Z measurement:

| seed | preparation (C_i) | readout diagonalizer (C_i^\dagger) |
|---|---|---|
| (v_R) | X0, H0, X1, CNOT(0→1), CNOT(0→3), CNOT(1→2) | reverse sequence |
| (v_V) | X0, X3 | X3, X0 |
| (v_H) | H0, S0, X1, H1, X3, CNOT(1→2), CNOT(1→3), CNOT(3→0) | reverse sequence with S0 replaced by S0† |

The order of the seed labels and the (v_R,v_V,v_H) names is the one in
`STABILIZER_READOUT_CERTIFICATE.json`. A basis for permutation lift (U_p) is
{(U_p C_i|j\rangle:j\in\{0,1\}^4)}. Readout applies (C_i^\dagger U_p^\dagger)
then measures four Z bits. Measure-and-prepare additionally prepares the
observed label and applies (U_p C_i). In the certified JW gate model, a
selected PGL readout costs at most 48 CNOTs and 8 exact Pauli quarter-turns,
plus at most 3 seed CNOTs. Preparing the output doubles the permutation cost
and adds the second seed circuit and at most 4 X gates: at most 96 permutation
CNOTs and 6 seed-basis CNOTs total. The Pauli quarter-turns use
Rz(±π/2), a Clifford gate. These are all-to-all, exact-gate upper bounds;
connectivity, noise, and calibration are unmeasured.

Uniformly choosing one of the 9, 63, or 72 stored coset bases by rejection
sampling takes, respectively, (64/9), (128/21), or (112/9) expected fair
bits. The table is finite and small. Unlike the generic all-n sampler below,
it avoids sampling all of A9 for these three special POVMs.

## Exact octonionic-to-JW conversion

The certificate's Gaussian-integer matrix (W) has 32 nonzero entries and
obeys (W^*W=2I_{16}) and

\[
 W\Gamma_a^{\rm oct}=\Gamma_a^{\rm JW}W,\qquad
 U:=W/\sqrt2\ \text{unitary}.
\]

The direct matrix check finds

\[
 UX_0U^*=\tfrac12(XXXY-XXYX+XYXX-XYYY),
\]

so (U) is **not** a JW Pauli Clifford. An exact Clifford+T circuit was
constructed and replayed against all 256 entries of the full 16×16 unitary,
with equality (U=PQ), including its global phase:

* (Q=(-i Z_2 CZ_{12})(Z_0 CZ_{10})H_0S_0^\dagger CCZ_{q_1=q_2=0,q_0}).
  Chronological application is: X1, X2; CCZ(q1,q2 controls, q0 target); X2,
  X1; S0†; H0; CZ(1,0); Z0; CZ(1,2); Z2; global phase (-i).
* The negative-control CCZ is exact: toggle X1,X2, apply CCZ, then untoggle.
  The CCZ parity-phase identity
  (4abc=a+b+c-(a\oplus b)-(a\oplus c)-(b\oplus c)+(a\oplus b\oplus c))
  gives an ancilla-free decomposition with 10 CNOT and 7 T/T† gates.
  Chronologically its gates are T1,T2,T0; CNOT(1→2),T†2,CNOT(1→2);
  CNOT(1→0),T†0,CNOT(1→0); CNOT(2→0),T†0,CNOT(2→0);
  CNOT(1→0),CNOT(2→0),T0,CNOT(2→0),CNOT(1→0). Each pair parity is
  computed/uncomputed with one CNOT each; the triple parity uses two CNOTs
  each way. The exact diagonal matrix was checked.
* (P) is the chronological affine circuit
  CNOT(0→1), CNOT(0→2), CNOT(1→3), CNOT(2→3), CNOT(3→0), CNOT(0→3),
  X1, X2. It maps input bits to
  (y_0=q_0\oplus q_1\oplus q_2\oplus q_3,
    y_1=1\oplus q_0\oplus q_1,
    y_2=1\oplus q_0\oplus q_2,
    y_3=q_0).

With CZ decomposed as CNOT plus two H gates, one (U) costs 18 CNOT, 7 T/T†,
6 X, 5 H, one S†, two Z, and no ancilla; the global phase is physically
irrelevant. (U^\dagger) has the same counts. This is an exact synthesis,
not a hardware calibration claim.

The runtime compiler below is defined directly in JW computational
coordinates; this mathematical representation change costs no gate in that
interface. If an external device instead supplies/requests states in the
octonionic coordinate frame, converting into and back out of the JW frame
costs one (U) and one (U^\dagger) per measure-and-prepare use under this
separate-conversion implementation: 36 CNOT, 14 T/T†, zero ancillas, in
addition to the JW circuit. A measurement-only call needs one conversion.
No physical octonionic encoding was supplied, and no optimization that merges
these conversions into a device-specific gate set is claimed.

## All-n compiler and channel proof

Let (m=2n+1), (d=2^n), and use Hermitian Clifford words

In zero-based JW coordinates, use
\(\Gamma_{2j+1}=Z_0\cdots Z_{j-1}X_j\) and
\(\Gamma_{2j+2}=Z_0\cdots Z_{j-1}Y_j\), for (0\le j<n), with
\(\Gamma_{2n+1}=Z_0\cdots Z_{n-1}\). The final axis is the physical
fermion-parity string up to the convention's phase.

\[
 T_A=i^{k(k-1)/2}\prod_{a\in A}\Gamma_a,
 \quad A\subseteq[m],\ |A|=k\leq n.
\]

They form an orthogonal Hermitian basis of (M_d), with

\[
 d_k=\binom{2n+1}{k},\qquad
 |A|\leq n\Longrightarrow |A\triangle B|\leq 2n<m.
\]

The even sign subgroup (D^+=\{\epsilon\in\{\pm1\}^m:\prod_a\epsilon_a=1\})
has order (2^{m-1}=d^2). Its spin lifts act projectively as every n-qubit
Pauli exactly once: the action on the (m) gamma axes is faithful modulo the
spin center, and the projective Pauli group also has order (d^2). On (T_A)
the action is the character \(\chi_A(\epsilon)=\prod_{a\in A}\epsilon_a\).
On (D^+), two characters agree only if (A\triangle B=\varnothing) or
([m]); the latter is impossible for these (A,B). Thus the (D^+) average
annihilates every off-diagonal Clifford coefficient.

For a group orbit projector (P_g=U_g|\psi\rangle\langle\psi|U_g^\dagger),
the even-sign average of (P_g) is (I/d): its non-scalar Clifford
coefficients have nontrivial characters. Hence the finite ray orbit gives
the normalized canonical effects (dP/N). The measure-and-prepare map is

\[
 \Xi_\psi(X)=\frac{d}{|D^+||A_m|}
 \sum_{\epsilon\in D^+,\,\pi\in A_m}
 \operatorname{tr}(P_{\epsilon,\pi}X)P_{\epsilon,\pi}.
\]

Expanding (P_\psi=d^{-1}\sum_A r_A T_A), the sign sum in
\(\Xi_\psi(T_B)\) leaves only the term (A=B); the permutation sum then
averages (r_A^2) over the (d_k) grade-k subsets. Its value is
\(s_k(\psi)/d_k\).

Every π in (A_m) has a Spin lift. It conjugates each gamma generator to
the permuted generator and therefore normalizes the Pauli group, so its JW
spinor action is Clifford. (A_m) is k-homogeneous for all (k\leq n): start
with any permutation mapping a k-set to another; if it is odd, compose it with
a transposition inside the target set's complement, whose size is
(m-k\geq n+1\geq2), preserving the set and correcting parity. This proves
homogeneity, not k-transitivity. Averaging over (A_m) equalizes the surviving
diagonal coefficients within each grade.

For any unit spinor ψ, write (r_A=\langle\psi|T_A|\psi\rangle) and
(s_k(\psi)=\sum_{|A|=k}|r_A|^2). Pauli-character cancellation followed by
the grade transitivity gives the complete channel identity

\[
 \Xi_\psi(T_A)=\eta_k(\psi)T_A,
 \qquad \eta_k(\psi)=\frac{s_k(\psi)}{\binom{2n+1}{k}}.
\tag{1}
\]

This is proved for each basis operator (T_A), hence for every operator
(X\in M_d), not merely inputs invariant under the group. Schur
multiplicity-freeness of (M_d\cong\bigoplus_{k=0}^n\Lambda^k\mathbb C^m)
then identifies (1) with the Spin Haar seed-orbit channel. Irreducibility gives
the normalized canonical Haar POVM (d\,|g\psi\rangle\langle g\psi|,dg).
For the Haar map, its Hilbert--Schmidt trace on grade k is
\(\sum_{|A|=k}\int r_A(g)^2dg=s_k(\psi)\), since Spin rotates the grade-k
coefficient vector orthogonally. Multiplicity-freeness makes its scalar
transfer (s_k/d_k), so the finite and Haar maps coincide exactly. This
argument includes all
first/second seed moments relevant to this measure-and-prepare channel; no
finite group 3-design or higher moment assertion is used.

For the readout implementation, additionally require ψ to be a stabilizer
state. A stabilizer state's Pauli translates form exactly one orthonormal
basis: two translates have nonzero overlap only when their Pauli quotient is
in the ray stabilizer, which has size (d); the quotient has (d) cosets.
Let that basis be (C_\psi|j\rangle), (j\in\{0,1\}^n). Since every
(U_\pi) normalizes the Paulis,

\[
 B_\pi=\{U_\pi C_\psi|j\rangle:j\in\{0,1\}^n\}
\]

is another PVM basis. Two such bases sharing a ray are equal because each is
the complete (D^+) ray orbit; otherwise they are disjoint. Consequently the
unique rays form (N=dM) outcomes in (M) bases, each ray occurs equally
often among permutation labels, and after duplicate labels are merged the
effect is (M^{-1}P=(d/N)P). This proves the exact finite canonical POVM and
the channel (1). The circuit measures by (C_\psi^\dagger U_\pi^\dagger), then
Z, and prepares the observed label by (U_\pi C_\psi|j\rangle). The input
state is arbitrary.

### Explicit n+1 stabilizer seeds

Use

\[
 \psi_0=|0^n\rangle,\qquad
 \psi_h=2^{-1/2}(|0^n\rangle+|1^h0^{n-h}\rangle),
 \quad 1\le h\le n.
\]

To prepare \(\psi_h\), apply H to q0 and CNOT(q0→qj) for
(j=1,\ldots,h-1); \(\psi_0\) needs no gates. The moments are exact:

\[
 s_k(\psi_0)=\binom{n}{\lfloor k/2\rfloor},
\]

and for (h\ge1), (z=k\bmod2),

\[
 s_k(\psi_h)=
 \sum_{\substack{0\le q\le h\\q\equiv hz\pmod 2}}
 \binom hq\binom{n-h}{\lfloor k/2\rfloor-q}
 +\mathbf1_{k\ge h}2^{h-1}
 \binom{n-h}{\lfloor(k-h)/2\rfloor}.
\tag{2}
\]

Out-of-range binomials are zero. For \(\psi_0\), the nonzero expectations
are exactly the Clifford words with each JW site contributing either zero or
both local generators, with the final parity generator optional, yielding the
first formula. For \(\psi_h\), diagonal terms count (q) paired sites among
the h flipped bits and \(\lfloor k/2\rfloor-q\) pairs elsewhere; the
two branch phases agree iff (q\equiv h(k\bmod2)\pmod2). Off-diagonal terms
must flip exactly the first h bits. For each external paired subset, exactly
(2^{h-1}) choices on those h sites yield a real transition, which is possible
only for (k\ge h). Each surviving expectation has squared magnitude one,
giving (2). These values are integers, so each transfer in (1) is rational.

At n=4, the moment vectors for h=0,3,4 match (respectively) the existing
v_V, v_H, v_R vectors. The equality here is of complete moment/channel
vectors; it does not assert that their particular seed rays coincide.

## Sampling and cost

To sample π uniformly from (A_m) without an (m!\)-element table:

1. Run Fisher–Yates on (S_m), drawing (J_k\) uniformly from
   ({0,\ldots,k-1}), for (k=m,m-1,\ldots,2).
2. If the resulting permutation is odd, left-compose a fixed transposition
   ((0\ 1)); otherwise leave it unchanged.

Fisher–Yates is uniform on (S_m). This correction has exactly two
preimages per even permutation (itself and the fixed-transposition product),
so its output is uniform on (A_m). To generate each (J_k), use
(L_k=\lceil\log_2 k\rceil) fair bits and reject integers ≥k. The expected
fair-bit cost is exactly

\[
 B_m=\sum_{k=2}^{m}L_k\frac{2^{L_k}}{k}
 <2\sum_{k=2}^{m}L_k
 \le 2(m-1)\lceil\log_2m\rceil=O(n\log n).
\]

It terminates almost surely; rejection has no finite worst-case bit bound. At
(m=9), (B_9=8822/315\approx28.00635). Storing a permutation as a fixed-width
array takes (m\lceil\log_2m\rceil=O(n\log n)) bits; its deterministic
cycle decomposition into at most (m-1=2n) transpositions is polynomial time.
The measured outcome is n bits and does not require a second random label.
No separate even-sign/Pauli sample is needed: its d ray labels are exactly
the PVM outcome j.

In the JW model, each transposition reflection is

\[
 R_{ab}=\frac{\Gamma_a-\Gamma_b}{\sqrt2}
       =\Gamma_a\exp(i\pi P_{ab}/4),\qquad
 P_{ab}=i\Gamma_a\Gamma_b,
\]

where \(P_{ab}\) is a Hermitian JW Pauli word of weight at most n and
\(\Gamma_a\) is a Pauli word (one-qubit gates only). In the ordinary
conjugation action, one \(R_{ab}\) gives the negative coordinate transposition
\(- (a\ b)\); an even transposition factorization has even length, so these
minus signs cancel and the product implements the requested permutation
exactly while lying in Spin. A weight-w Pauli
quarter-turn uses at most (2(w-1)) CNOT, one exact Rz(±π/2), and local
Cliffords. A permutation has at most 2n transpositions, so one (U_\pi) or
(U_\pi^\dagger) costs at most (4n(n-1)) CNOT and 2n quarter-turns, plus
(O(n^2)) one-qubit gates. Including the seed readout, one measurement costs
(4n(n-1)+(h-1)) CNOT, at most 2n quarter-turns, and n measured bits. A
measure-and-prepare use costs at most (8n(n-1)+2(h-1)) CNOT, at most 4n
quarter-turns, plus at most n output X gates and local gates. It uses no
Naimark ancilla. These are exact all-to-all bounds in the declared CNOT/local
Clifford model; routing, hardware costs, noise, and runtime calibration are
not included.

For a rational seed mixture (q_0,\ldots,q_n), let (Q) be a common
denominator. Draw a uniform integer in \(0,\ldots,Q-1\) by rejection and
assign intervals of lengths (Qq_h). This samples h exactly with expected
fair-bit cost (L_Q2^{L_Q}/Q<2L_Q), (L_Q=\lceil\log_2Q\rceil). Then sample
π independently as above. The seed tag takes (\lceil\log_2(n+1)\rceil)
fixed-width storage bits. Arbitrary real q values do not admit finite exact
sampling without an effective representation; rational q or a specified
approximation and error budget is required.

## Conditional common-mixture acquisition

For supplied rational grade transfers \(\lambda_1,\ldots,\lambda_n\),
directly test the exact rational LP over the restricted explicit seed family
\(\psi_0,\ldots,\psi_n\):

\[
 q_h\ge0,\quad \sum_{h=0}^n q_h=1,\quad
 \sum_{h=0}^n q_h\frac{s_k(\psi_h)}{\binom{2n+1}{k}}
 \ge 2\lambda_k-1\quad(k=1,\ldots,n).
\tag{3}
\]

Three statements must be kept distinct. (A) The unrestricted global star
inequality concerns continuous support and remains **UNKNOWN**. (B) A star
support inequality restricted to the finite moment vectors of
\(\psi_0,\ldots,\psi_n\) is a strictly stronger sufficient condition for
feasibility of (3). The finite Spin(15) test for this restricted family fails,
so that sufficient proof route is unavailable there. This failure does not
show that (3) is infeasible for any particular legal transfer vector. (C) For
each supplied transfer vector, exact solution of (3) decides whether this
particular finite seed family yields a comparator: feasibility gives a
certificate q; infeasibility rules out only this family for that vector.
Neither (A) alone nor failure of (B) establishes (C).

If a feasible q is returned, the compiler uses that same q on every input and
defines one canonical EB channel; its transfers dominate
(2\lambda_k-1) on each complete grade, hence
(\Psi-(2\Phi-\mathrm{id})\succeq0\) on Hermitian inputs. The q choice
does not depend on the unknown state being measured.

Here \(\succeq0\) means positive semidefinite as a Hilbert--Schmidt
superoperator on the real Hermitian operator space, because every grade
eigenvalue of the difference is nonnegative; it is not a claim that the
difference is itself a positive or completely positive map.

The LP has n+1 variables and O(n) rational constraints. Formula (2) and the
binomial denominators have O(n)-bit entries; a standard exact rational LP
algorithm therefore has polynomial bit complexity in n and the supplied
transfer bit length. This is a complexity bound for the specified conditional
input interface, not an executed q-solver or an all-n acquisition theorem. If
transfers come from measurement, their estimation precision/sample cost is
separate. With estimates \(\widehat\lambda_k\) known within ε, a robust
LP must replace the right side by (2(\widehat\lambda_k+\epsilon)-1); it can
be infeasible without margin. No finite exact q sampler is claimed for an
unknown real vector.

## Matchgate-shadow comparison and prior boundary

Fermionic matchgate shadows are a close primary prior, not something to
ignore. Wan et al. derive the measurement channel

\[
 \mathcal M_{\rm MG}=
 \sum_{\ell=0}^{n}
 \frac{\binom n\ell}{\binom{2n}{2\ell}}\,\mathcal P_{2\ell},
\]

with image only the even-operator subspace. They also report that Zhao et al.'s
discrete (A(2n)) matchgate ensemble has this same measurement channel,
although its higher twirls differ from the full Clifford-matchgate ensemble.
For our explicit \(\psi_0\) seed,

\[
 \eta_k(\psi_0)=
 \frac{\binom n{\lfloor k/2\rfloor}}
      {\binom{2n+1}{k}},\qquad k=1,\ldots,n,
\]

which is nonzero on every grade, including odd grades. On common even grades
2ℓ≤n, its denominator \(\binom{2n+1}{2\ell}\) differs from the matchgate
denominator \(\binom{2n}{2\ell}\). Thus these are not the same operator
channel. The difference is direct in the shared JW Fock-space model:
\(\Gamma_1\) is parity-odd, so matchgate shadows annihilate it, while the
\(\psi_0\) Spin channel sends \(\Gamma_1\) to
\(\Gamma_1/(2n+1)\). For n≥2, the common bilinear
\(i\Gamma_1\Gamma_2\) has Spin(2n+1) transfer \(1/(2n+1)\), while Eq. (30)
gives \(1/(2n-1)\). The Spin(2n+1) compiler uses the additional
Majorana/parity axis and produces a full-algebra measure-and-prepare map; it
is not an implementation of the
parity-preserving Spin(2n) matchgate shadow channel. The use of finite
alternating groups, character cancellation, and homogeneous subset actions is
standard in spirit; this report makes no general novelty or priority claim.
The comparison is scoped to these channels and the cited prior papers, not an
exhaustive literature search. The static Astra topic route pointed to the
missing `work/astra_prior/agent/topics/quantum.tsv`, so no topic-card proof or
prior claim was used from that route; its absence is not evidence of novelty.

Primary references:

* Kianna Wan et al., “Matchgate Shadows for Fermionic Quantum Simulation,”
  *Communications in Mathematical Physics* 404, 629–700 (2023), especially
  measurement channel Eq. (30) and comparison §3.4.1:
  [Springer article](https://link.springer.com/article/10.1007/s00220-023-04844-0).
* Andrew Zhao, Nicholas C. Rubin, and Akimasa Miyake,
  “Fermionic Partial Tomography via Classical Shadows,” *Physical Review
  Letters* 127, 110504 (2021):
  [arXiv:2010.16094](https://arxiv.org/abs/2010.16094).

## Reproducibility and limits

Run from the workspace root:

```sh
python3 work/agents/c12_spin_compiler/verify_compiler.py
```

The script uses exact SymPy matrices to verify the two Cl9 models and
(W^*W=2I), the explicit non-Clifford witness, all three seed prep/readout
tableaux, all 9/63/72 disjoint PGL coset partitions and their orthonormality,
the direct grade-moment sums, the full 16×16 Clifford+T conversion circuit,
and exact small-m finite sampler preimage counts. Its machine-readable output
is `VERIFICATION.json`. It imports the existing exact GF(8)/spin-lift routines
for the finite PGL construction; the circuit, moment, partition, and
conversion checks are rebuilt in this worker's verifier. These are internal
exact checks, not proof-assistant verification or external audit.

The generic compiler result is an algebraic proof, not an all-n star theorem.
The extension from exact n=4,5 star checks to all n, transfer acquisition from
an unknown channel, hardware execution/noise, and a full external priority
search remain **UNKNOWN**.
