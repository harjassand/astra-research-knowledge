# Source and prior notes

The only new external source pass here targeted the closest primary prior,
not the broader mathematical program.

1. Kianna Wan, William J. Huggins, Joonho Lee, and Ryan Babbush,
   “Matchgate Shadows for Fermionic Quantum Simulation,”
   *Communications in Mathematical Physics* 404, 629–700 (published 31 Oct
   2023), DOI [10.1007/s00220-023-04844-0](https://doi.org/10.1007/s00220-023-04844-0).
   Section 3.2, Eq. (30), gives the measurement channel
   \(\mathcal M=\sum_{\ell=0}^n {\binom n\ell}/{\binom{2n}{2\ell}}\,
   \mathcal P_{2\ell}\), with image the even-operator subspace. Section
   3.4.1 states that Zhao et al.'s discrete A(2n) ensemble has the same
   measurement channel, although its higher twirls differ. This paper supplies
   the exact channel comparison used in `FINAL_REPORT.md`.

2. Andrew Zhao, Nicholas C. Rubin, and Akimasa Miyake,
   “Fermionic Partial Tomography via Classical Shadows,”
   *Physical Review Letters* 127, 110504 (2021),
   [arXiv:2010.16094](https://arxiv.org/abs/2010.16094).
   This is the cited primary source for the earlier alternating-group
   fermionic Gaussian measurement ensemble; the exact comparison above is
   reported and algebraically stated in Wan et al.

The direct channel comparison is as follows. In the common JW Fock-space
realization, a physical Majorana \(\Gamma_1\) is odd under fermion parity, so
the matchgate channel annihilates it. The all-n \(\psi_0\) Spin(2n+1) channel
has
\(\Xi_{\psi_0}(\Gamma_1)=\eta_1\Gamma_1=\Gamma_1/(2n+1)\), hence differs for
every n. For n≥2 the common bilinear \(i\Gamma_1\Gamma_2\) also separates
the channels: the Spin(2n+1) coefficient is
\(\eta_2=n/\binom{2n+1}{2}=1/(2n+1)\), while Eq. (30) gives the matchgate
coefficient \(n/\binom{2n}{2}=1/(2n-1)\). No extrapolation from this scoped
comparison to a novelty or priority statement is made.

The workspace's static Astra quantum topic route pointed to the absent file
`work/astra_prior/agent/topics/quantum.tsv`. No source-card proof or claim from
that route was used. The primary-paper comparison above is not an exhaustive
prior search.
