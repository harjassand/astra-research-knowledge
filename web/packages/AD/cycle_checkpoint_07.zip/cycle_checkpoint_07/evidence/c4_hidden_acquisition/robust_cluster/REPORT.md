# Robust clustering certificate for unknown emission columns

## Verdict and scope

Let each block-frequency observation be a point `x_n` in the probability simplex. There are `K` hidden states with unknown emission columns `e_1,...,e_K`; each uncontaminated row has a latent state `z_n` and obeys `||x_n-e_{z_n}||_2 <= r`. Write `d=min_{i!=j}||e_i-e_j||_2`, and suppose the model supplies only the lower bound `d >= sqrt(2) kappa`. At most `b` of the `N` rows are arbitrary contaminants. The conclusions below concern this mathematical bounded-radius model; they do not establish that any physical slow-read block obeys it.

Three targets must be kept separate:

1. **Partition of a fixed clean sample, no contaminants.** For arbitrary unknown mixture weights and nonempty clusters, the universal deterministic identifiability boundary is `d>4r`. The threshold is sharp when mixture weights have slack (`p_*<1/K`) and the observation simplex has enough room for the construction below. The proof is an overlap-graph argument; the equality counterexample also gives identical iid observable laws.
2. **Unknown arbitrary contaminants.** The identities of contaminants are not generally identifiable: an arbitrary vector may lie inside a clean cluster. A conservative observable certificate can recover state-pure *good subsets* and abstain on unresolved rows. Full outlier provenance needs an additional separation/contamination assumption. The exhaustive strict-gap certificate below returns the exact outlier set only when its observable witness is unique.
3. **Exact emission-column recovery.** Bounded-radius observations do not identify `E` exactly for any `r>0`, even if labels and the uncontaminated set are revealed. Means of known-good clusters are only within `r` of their columns. Exact E recovery needs a stronger assumption such as a known conditional mean/centered-noise model or `r=0`.

If `p_*=1/K`, the lower-mass condition forces known uniform mixture weights. Then the slack-weight sharpness construction is unavailable. A regular-polygon example gives ambiguity up to `d=4r cos(pi/(2K))`; the exact uniform-weight threshold in the interval from that value through `4r` is UNKNOWN here. This is a real qualification: the scalar assumptions alone plus a mass lower bound do not justify claiming a fixed-`K`, uniform-weight sharp cutoff of `4r`.

## Exact partition boundary without contamination

Suppose a finite observed sample has two candidate `K`-partitions, with each row assigned exactly once in each partition, and each candidate partition is compatible with some center set whose distinct centers are at least `d` apart and whose assigned rows lie within radius `r` of their centers. Form the bipartite graph whose left nodes are the first partition's clusters and whose right nodes are the second partition's clusters; connect two nodes when at least one observed row belongs to both clusters in the two explanations.

Every node has degree at least one. If every node has degree one, the graph is a perfect matching and the two partitions agree up to a permutation of cluster names. Otherwise some cluster in one explanation shares rows with two clusters in the other. Let those rows be `x,y`, and let their common-side center be `a`, with opposite-side centers `f,g`. Then

`||f-g|| <= ||f-x|| + ||x-a|| + ||a-y|| + ||y-g|| <= 4r`.

Therefore `d>4r` forces the partition to be unique up to permutation. The argument does not depend on the number of states or feature dimension.

The constant is attained. On a line, take observations `(-r, +r, 3r)`. One explanation has centers `0,4r` and clusters `{-r,+r}`, `{3r}`. A second has centers `-2r,2r` and clusters `{-r}`, `{+r,3r}`. Every assigned point is within `r` of its center and each explanation has minimum center separation exactly `4r`. Thus at `d=4r` the finite partition need not be identifiable; the same construction satisfies any asserted lower bound `d<=4r`.

It also produces a statistical counterexample when mixture weights are unknown with strict slack. Give the three observed values probabilities `w_1,w_2,w_3>0`. In the first model the mixture weights are `(w_1+w_2,w_3)`; in the second they are `(w_1,w_2+w_3)`. Put the first model's first-state emission mass on `-r,+r`, and the second model's second-state mass on `+r,3r`, with the conditional probabilities chosen to produce the same `w_j`. Both models then induce exactly the same iid observable distribution while their centers and state partitions differ. For any `p_*<1/K`, choose `w_1=w_3=p_*`, `w_2=1-Kp_*>0`, and give each of the remaining `K-2` states mass `p_*` at a well-separated atom. Then the first model has weights `(1-(K-1)p_*,p_*,p_*,...)`, while the second has `(p_*,1-(K-1)p_*,p_*,...)`; both obey the lower bound and induce the same observable law. The construction requires enough simplex dimension/diameter to place the extra atoms. Hence a universal claim beyond `4r` fails for the model class with unknown masses and strict slack. At the endpoint `p_*=1/K`, all mixture weights are fixed uniform and this particular counterexample cannot keep `w_2>0`.

For that endpoint, let `v_0,...,v_{2K-1}` be a regular `2K`-gon of circumradius `R` embedded in a small affine plane inside the simplex, let `m_j=(v_j+v_{j+1})/2` be its edge midpoints, and put `r=R sin(pi/(2K))`. One model uses the even vertices as centers and groups midpoint pairs `(m_{2i-1},m_{2i})`; the other uses odd vertices and pairs `(m_{2i},m_{2i+1})`. Each model gives every state mass `1/K`, both induce the uniform law on the same `2K` midpoints, and the center separation is `2R sin(pi/K)=4r cos(pi/(2K))`. This establishes an ambiguity lower bound, not the exact uniform-weight minimax threshold.

## A finite no-label/no-E/no-kappa certificate

The script `robust_cluster_certificate.py` implements a conservative exhaustive witness test. Its inputs are only the observed rows, known `K`, and a calibrated integer contamination cap `b`; it takes no labels, `E`, `r`, or `kappa` oracle.

It enumerates every dropped set `O` with `|O|<=b` and every unordered `K`-partition of the retained rows with each block larger than `b`. For a partition `C_1,...,C_K`, set

- `D_in = max ||x_a-x_b||` over within-block pairs;
- `D_out = min ||x_a-x_b||` over cross-block pairs.

Keep a witness only when `D_in < D_out`. Return `CERTIFIED` only if exactly one distinct `(O,partition)` passes; otherwise return `UNKNOWN`, including when there is no witness. The comparisons use exact rational arithmetic for JSON decimal input. Runtime is exponential, by design; it is a transparent finite certificate, not a scalable clustering method.

**Soundness.** If the bounded-radius model holds, each true same-state pair is at distance at most `2r`, and each true cross-state pair is at least `d-2r`. Hence if `d>4r`, the true uncontaminated partition has a strict gap. If every true class contains more than `b` clean rows, it is among the enumerated candidates. A unique exhaustive witness must therefore equal that valid decomposition, up to the arbitrary cluster naming. The returned block mean is in the simplex and within `r` of the associated `e_i` by convexity.

**Completeness limit.** This is a one-sided certificate. Even when `d>4r`, it returns `UNKNOWN` if contaminants create a second strict-gap explanation or if their provenance is observationally interchangeable with clean rows. The unique-witness condition is observable and sufficient, not necessary for the partition to be identifiable under a richer model.

The distance-gap condition itself uses `d>4r`: within distances are at most `2r`, while cross distances are at least `d-2r`; at equality they can tie. If a lower bound alone is used to guarantee the premise, require `sqrt(2) kappa>4r`, i.e. `kappa>2 sqrt(2) r`. The executable does not need that inequality as an input.

## Alternative finite coverage certificate using a known radius bound

There is a second, more permissive finite protocol if a valid radius bound `r` is available. It does not require `E`, labels, or `kappa`. Enumerate `K`-tuples of observed rows as candidate centers. For each tuple form closed balls of radius `2r`. Retain tuples with (a) pairwise center distances strictly larger than `8r`, and (b) more than `b` observed rows in every ball. Among retained tuples choose one maximizing the number of covered rows; report the disjoint ball memberships, the uncovered rows, the objective value, and the margins to both thresholds. If no tuple passes, return `UNKNOWN`. The balls are disjoint because their centers are more than `8r` apart.

**Soundness of the good-row labels.** Each qualifying ball has more than `b` rows, so contains a good witness `x_i`; if its state is `z_i`, its center `c_i` satisfies `||c_i-e_{z_i}||<=3r`. Two centers witnessed by the same state could be at most `6r` apart, contrary to the `8r` threshold. Thus the `K` witnesses give a bijection to the `K` hidden states. If another good row `y` in ball `i` belonged to state `z_j != z_i`, then `||c_i-e_{z_j}||<=3r`; the center `c_j` witnessed by `z_j` is also within `3r` of `e_{z_j}`, so `||c_i-c_j||<=6r`, again a contradiction. Every covered good row in a ball therefore has one common state label. Contaminants inside the same balls are not labeled as good by this certificate.

**Completeness for the finite observed-center protocol.** If every state has `g_i>b` clean rows and `d>10r`, choose one clean observed row `c_i` from each state. It covers every clean row of that state because `||x-c_i||<=2r`; each ball has at least `g_i>b` rows; and distinct chosen centers are at least `d-2r>8r` apart. Thus a qualifying tuple exists and covers all `G` good rows. A maximizing qualifying tuple covers at least `G` rows, so it omits at most `b` good rows in total (there are at most `b` contaminants). Its balls are soundly state-pure on good rows and each state is represented. It may still mix in arbitrary contaminants, and a rare class with `g_i` only slightly above `b` may contribute just one covered good row. For downstream center estimation, an additional per-class sample margin and a robust estimator are needed; this certificate alone does not make contaminants harmless.

If instead centers are allowed at arbitrary locations and one simply takes an unconstrained coverage maximizer before checking the `8r` condition, the conservative completeness argument is `d>14r`: any ball containing a good row has its center within `3r` of that state's column, so distinct-state centers are separated by at least `d-6r`. The `14r` condition forces this gap above `8r`. This is weaker than enumerating observed-row centers, for which `d>10r` suffices. Both are finite in principle. The continuous-center version can enumerate the finitely many covered-row subsets and decide the resulting radius and inter-center inequalities as a finite geometric feasibility problem; the observed-row-center version is simply `N choose K` tuple enumeration.

The coverage protocol does use a calibrated `r`; it is not a no-radius-oracle replacement for the strict-gap witness test. Neither certificate assumes a uniform physical slowdown or certifies the validity of a slow-read contamination budget.

## Finite mixture counts and the contamination boundary

For a fixed realized dataset the relevant visibility condition is `g_i>b` for every state: otherwise the entire observed support of a rare state can be removed within the contamination budget, subject to the alternate columns fitting in the simplex. This is a count condition, separate from geometric identifiability.

If the number of good founders is at least `n=N-b` and their state labels are iid with `pi_i>=p_*`, then `mu=n p_*` is a lower bound on each state's mean count. For `b<mu`, a union bound and the multiplicative lower-tail Chernoff bound give

`P(min_i g_i <= b) <= K exp(-(mu-b)^2/(2 mu))`.

For `b approximately epsilon N`, the positive-margin condition is `(1-epsilon) p_*>epsilon`, or `epsilon<p_*/(1+p_*)`. This ensures visibility with high probability as `N` grows; it is not a deterministic guarantee for every finite sample and is not itself an exact minimax threshold for center recovery.

## Exact E recovery and abstention examples

Uniformly over this model class, even with the clean partition revealed, if `r>0` and there is slack in the simplex/separation constraints, a sample consisting of repetitions of one interior row `x` is compatible with a continuum of centers in the radius-`r` ball around `x`. Thus no algorithm can guarantee exact `E` from the bounded-radius condition alone. The block mean obeys `||mean_i-e_i||<=r`, but the reverse inequality is not identified.

If the centers are known, a single point may be compatible with two states whenever their radius-`r` balls intersect; the exact pairwise no-overlap threshold is `d>2r`. For unknown centers and a full partition, the universal threshold is instead `d>4r` as proved above.

Arbitrary bad rows can bridge separated clouds, form a second dense-looking group, or lie directly inside a clean cloud. Single-linkage, a heuristic nearest-center assignment, and a first-found partition are therefore not sound stopping rules under this contamination model. The two algorithms above either produce an explicit uniqueness/separation certificate or abstain.

## Verification

The exact-rational script passed its built-in self-test:

`python3 work/agents/c4_hidden_acquisition/robust_cluster/robust_cluster_certificate.py --self-test`

It certifies the two tight clusters plus one isolated contaminant example and returns `UNKNOWN` on a four-point example with no strict-gap witness. These finite tests validate only the implementation examples; they do not establish physical calibration or replace the proofs above.
