# Robust repeated-block acquisition with unknown emissions

## Claim and status

This is a conditional finite-sample theorem for a fixed pair of known controlled transition matrices. The tester receives no state labels, no reset, no emission matrix \(E\), no singular-value oracle, and no zero-time observation. It uses pre-read blocks from its transition cohort to cluster the unknown shared emission columns up to the proved finite radius and a common permutation, then tests which action kernel generated paired pre/post observations.

The theorem replaces the earlier sufficient requirement that no read block jump, with per-block budget \(\alpha/(4B)\), by a robust count condition. A uniform history- and state-conditional physical jump bound need only satisfy
\[
q_{\rm phys}\le \frac{p_*\,\bar\Gamma}{768},
\qquad \bar\Gamma=\min(1,\Gamma),
\]
where \(p_*\) is the initial-state floor and \(\Gamma\) is the permutation-orbit gap of the probe matrices. This bound is independent of total block count \(B\). Corrupted pre-labels and post-endpoints are both included; a global bad-block count causes row error proportional to \(q/p_*\), not \(q\).

The result remains conditional on a calibrated uniform disturbance envelope. It does not establish that NV, force-smFRET, cryo-arrest, or another real platform meets it. It gives no advantage over the optimal full-data likelihood on the same active observations. Its resource illustration is still about 97.8 years of held-read wall time for the mathematical witness at \(\kappa=0.1\), before ramps, preparation, calibration, and recovery costs.

## Legal interface

There are \(K\ge2\) hidden states and \(K\) categorical symbols. Under one of two supplied hypotheses \(b\in\{0,1\}\), a fixed action word has row-stochastic transition matrix \(P_b\), including nominal pulses and action ramps. Their orbit gap is
\[
\Gamma=\min_{S\in\mathfrak S_K}\|P_0-S^{-1}P_1S\|_F>0.
\]
Independent native founders have unknown common law \(\pi\), with a supplied or separately certified bound \(\pi_i\ge p_*>0\). Each read returns a categorical output from one unknown shared column-stochastic matrix \(E\), with \(\kappa=\sigma_{\min}(E)>0\); \(E\) is common across pre/post blocks and both hypotheses. If the hidden state is unchanged, block reads are conditionally independent, each with positive measured duration \(\Delta\).

Each episode uses one slow pre-read block, the supplied action word, and one slow post-read block. The pre blocks also calibrate the reporter; there is no extra calibration cohort. A block is physically bad if the hidden state changes during any read interval or entry/exit ramp. For every attempted block, history \(h\), and starting state \(i\), assume
\[
\Pr(C_{\rm jump}=1\mid h,X_{\rm block,start}=i,\text{command})\le q_{\rm phys}.
\tag{1}
\]
The bound must include all commanded ramps and read-induced disturbance. Reporter drift, action-dependent emissions, or path-integrated exposures are outside the model unless counted as bad blocks and covered by (1).
The theorem conditions on valid supplied one-sided certificates for \(p_*\) and \(q_{\rm phys}\). If either is estimated in a pilot, allocate its failure probability separately inside total \(\alpha\) and charge all calibration founders, readouts, ramps, and analysis. No such certificate is supplied by this report.

For a scalar slow mode \(Q^\rho=\rho Q\), \(\rho>0\), maximum exit rate \(\Lambda\), and \(R_J\) frames at the maximum epoch, a sufficient physical calibration is
\[
q_{\rm phys}\le q_{\rm ramp}+\rho\Lambda R_J\Delta.
\tag{2}
\]
Ramps take finite measured time and are included in \(q_{\rm ramp}\); the fixed transition action and its ramps belong in \(P_b\). The experiment declares one positive \(\rho\) and one finite maximum measurement cap. Equation (2) is a paid physical premise, not an unchanged-time freeze.

## Robust block clustering certificate

Let \(d_E=\min_{i\ne j}\|E_{\cdot i}-E_{\cdot j}\|_2\). Since \(E\) is square, \(d_E\ge\sqrt2\kappa\). At doubling epoch \(R_j=2^j\), compute each block's empirical frequency vector. For a no-jump block from state \(i\), the one-hot variance bound and McDiarmid's inequality give
\[
\Pr\{\|\widehat e-e_i\|_2>r_j\mid\text{no jump},h,i\}\le\delta_j,
\qquad
r_j=\frac{1+\sqrt{\log(1/\delta_j)}}{\sqrt{R_j}}.
\tag{3}
\]
Set
\[
\epsilon=\frac{p_*\bar\Gamma}{192},\qquad
\delta_j=\frac{\epsilon}{4(j+1)(j+2)},\qquad j=0,\ldots,J.
\tag{4}
\]
Prefix failure probabilities sum to at most \(\epsilon/4\). With \(q_{\rm phys}\le\epsilon/4\), a block is bad at any inspected epoch with conditional probability at most \(\epsilon/2\), for every history and starting state. Dependence between blocks is allowed.

At epoch \(j\), enumerate tuples of \(K\) observed pre-block means. A tuple qualifies if each closed radius-\(2r_j\) ball contains more than \(b=\lfloor\epsilon N_t\rfloor\) pre means and its centers are pairwise more than \(8r_j\) apart. Return the first qualifying tuple in a fixed order; otherwise continue doubling and return UNKNOWN at the declared cap. The test uses only observed frequencies, \(K,\epsilon,N_t,r_j\), not \(E,\kappa\), labels, or hidden occupancy counts. It certifies approximate state-pure clusters; the bounded-radius model does not identify the exact emission columns. Direct enumeration costs \(O(\binom{N_t}{K}N_tK)\), so this is a finite certificate, not a scalable clustering claim.
The candidate orbit gap is computed from supplied matrices in \(O(K!K^2)\) arithmetic; those fixed-pair inputs are part of the declared model, not a hidden-matrix oracle.

**Soundness.** At most \(b\) pre blocks are bad on the count event. Each qualifying ball has more than \(b\) points, hence contains a good witness within \(r_j\) of some emission column. Its center is within \(3r_j\) of that column. Two centers cannot correspond to one state, since they would be at most \(6r_j\) apart; thus \(K\) centers represent all states. Any good endpoint \(y\) from state \(i\) is within \(4r_j\) of its representative center \(c_i\), because \(c_i\) is within \(3r_j\) of the column and \(y\) is within \(r_j\). Every other center is more than \(8r_j\) from \(c_i\), hence more than \(4r_j\) from \(y\). Nearest-center decoding is therefore correct for every good endpoint. Bad endpoints need not decode correctly and are charged to the corruption count.

**Completeness.** If each state has more than \(b\) good pre blocks and \(d_E>10r_j\), choosing one observed good mean per state gives centers more than \(8r_j\) apart, and each radius-\(2r_j\) ball contains that state's good means. A maximum epoch with \(r_J\le d_E/16\) is sufficient. This is an analysis coverage condition; the algorithm is not given \(\kappa\) and returns UNKNOWN unless its observable certificate passes.

## Conditional bad-block count

Fix one \(N_t\)-block group, either pre or post, and let \(Z_m\) indicate whether episode \(m\)'s block is physically or statistically bad at any inspected epoch. Equations (1)–(4) give
\[
\Pr(Z_m=1\mid\mathcal F_{m-1})\le\epsilon/2.
\]
The exponential-supermartingale Chernoff bound yields
\[
\Pr\left\{\sum_{m=1}^{N_t}Z_m>\epsilon N_t\right\}
\le \exp[-N_tD(\epsilon\|\epsilon/2)]
\le e^{-N_t\epsilon/8},
\tag{5}
\]
where \(D\) is binary relative entropy. Thus \(N_t\ge(8/\epsilon)\log(8/\alpha)\) gives both pre and post count caps with total failure probability at most \(\alpha/4\). This history-uniform envelope—not an iid fit, average fitted rate, or one-run frequency—is what permits the count result under correlated ramps.

## Transition-row error and the rare-state penalty

Let \(n_i\) count episodes whose hidden state at the action boundary is \(i\). Let \(c_i\) count touched records originating in row \(i\), and \(a_i\) count touched records assigned to observed row \(i\). If each pre/post group has at most \(\epsilon N_t\) bad blocks, the touched-pair count \(C\) obeys
\[
\sum_i c_i=C\le2\epsilon N_t,\qquad \sum_i a_i\le C.
\tag{6}
\]
For \(n_i\ge p_aN_t/2\), where \(p_a\) lower-bounds action-boundary occupancy, the retained good count \(m_i=n_i-c_i\ge p_aN_t/4\) whenever \(\epsilon\le p_a/16\). Let \(P_{i,\rm emp}\) be the empirical endpoint law from all true source-\(i\) transitions, \(Q_i\) the law after deleting \(c_i\) bad pairs, and \(\widehat P_i\) the observed row after arbitrary bad records assigned to it are added. Deleting \(c_i\) observations changes a categorical empirical law in \(L^1\) by at most \(2c_i/n_i\); adding \(a_i\) arbitrary observations changes it by at most \(2a_i/m_i\). Hence
\[
\|\widehat P_i-P_{i,\rm emp}\|_2
\le\|\widehat P_i-P_{i,\rm emp}\|_1
\le\frac{4c_i+8a_i}{p_aN_t}.
\tag{7}
\]
Stacking rows and using \(\|(c_i)_i\|_2,\|(a_i)_i\|_2\le C\),
\[
\|\widehat P-P_{\rm emp}\|_F
\le\frac{12C}{p_aN_t}
\le\frac{24\epsilon}{p_a}.
\tag{8}
\]
This is the rare-row correction: a global endpoint-block fraction \(q\) incurs row error of order \(q/p_a\).

Each founder starts with \(\pi_i\ge p_*\). Since the pre block changes state with conditional probability at most \(q_{\rm phys}\le\epsilon/4\), the action-boundary law has
\[
p_a\ge p_*(1-q_{\rm phys})\ge p_*(1-\epsilon/4).
\tag{9}
\]
Because \(\bar\Gamma\le1\), \(\epsilon\le p_*/192\), so \(p_a\ge p_*/2\) and \(\epsilon\le p_a/16\). The bound in (8) is at most \(\bar\Gamma/4\).

Also \(p_a\ge p_*/2\ge96\epsilon\). On the occupancy and pre-count events, each state's good pre-block count is at least \((p_a/2-\epsilon)N_t>\epsilon N_t\ge b\), which supplies the observed-center certificate's class-visibility premise.

For clean transitions, vector one-hot concentration gives each empirical row Euclidean error at most
\[
\frac{1+\sqrt{\log(4K/\alpha)}}{\sqrt m}
\]
with failure probability \(\alpha/(4K)\). It suffices to take
\[
m=\left\lceil\frac{64K}{\Gamma^2}
\left(1+\sqrt{\log\frac{4K}{\alpha}}\right)^2\right\rceil.
\tag{10}
\]
Then the clean empirical transition matrix has Frobenius error at most \(\Gamma/8\), with failure at most \(\alpha/4\).

## Sample budget and decision

Set \(q_{\max}=\epsilon/4\) and \(p_a=p_*(1-q_{\max})\). It suffices to choose
\[
N_t\ge\max\left\{
\frac{2m}{p_a},\
\frac8{p_a}\log\frac{8K}{\alpha},\
\frac8\epsilon\log\frac8\alpha
\right\},
\tag{11}
\]
rounded upward. The first two terms provide \(m\) source-\(i\) transitions and the occupancy event \(n_i\ge p_aN_t/2\); the last provides both endpoint count caps. With probability at least \(1-\alpha\), every source class has more than \(b=\lfloor\epsilon N_t\rfloor\) good pre blocks, clustering completes at a covered epoch, and
\[
\min_{S\in\mathfrak S_K}\|\widehat P-S^{-1}P_bS\|_F
\le\frac{\bar\Gamma}{4}+\frac{\Gamma}{8}
\le\frac{3\Gamma}{8}<\frac{\Gamma}{2}.
\tag{12}
\]
Nearest-orbit testing returns the correct fixed-pair member. Failure of a physical or observable certificate results in UNKNOWN.

At fixed \(K,p_*,\Gamma,\alpha\),
\[
N_t=O\left(\frac{K}{p_*\Gamma^2}\log\frac K\alpha+
\frac{1}{p_*\bar\Gamma}\log\frac1\alpha\right).
\]
Since \(R_J=O(\kappa^{-2}[\log(1/(p_*\bar\Gamma\alpha))+\log\log(1/\kappa)])\) at a covered maximum epoch, the read-frame cap \(2N_tR_J\) is \(O(\kappa^{-2})\) up to fixed-pair factors and logarithms. The theorem does not beat an optimal likelihood on the same modeled categorical records: that likelihood can implement this summary test. If a platform also supplies informative photon timestamps or analog waveforms, those are additional observations outside this categorical interface; the model theorem does not bound them.

## Exact overlap thresholds and corruption conventions

These thresholds are information-theoretic and depend on the corruption interface.

1. **Whole paired-record replacement.** For clean transcript laws \(F_0,F_1\), total-variation balls of radius \(\varepsilon_{\rm pair}\) intersect exactly when
   \[
   \operatorname{TV}(F_0,F_1)\le2\varepsilon_{\rm pair}.
   \tag{13}
   \]
   If they intersect, no estimator can uniformly distinguish the pair under those budgets, even with infinitely many records. If clean laws share the pre-record marginal and the post law differs by conditional TV \(\tau\) on a row of mass \(\pi_i\), then \(\operatorname{TV}(F_0,F_1)=\pi_i\tau\); the exact whole-pair threshold is \(\varepsilon_{\rm pair}\ge\pi_i\tau/2\).

2. **Separate post-block replacement.** In the same shared-pre construction, a post-only replacement budget among \(N_t\) post blocks has exact two-world overlap threshold \(\varepsilon_{\rm post}\ge\pi_i\tau/2\). If normalized over all \(2N_t\) pre/post endpoints and only post blocks can be touched, the threshold is \(\varepsilon_{\rm endpoint}\ge\pi_i\tau/4\). These thresholds allow adversaries in both worlds. A one-sided adversary that must reproduce the other world without an adversary there needs fraction at least \(\pi_i\tau\) among post blocks.

3. **Huber-mixture contamination is different.** If the allowed law is specifically \((1-\eta)F+\eta H\) for arbitrary \(H\), the mixture-contamination neighborhoods overlap exactly when
   \[
   \operatorname{TV}(F_0,F_1)\le\frac{\eta}{1-\eta},
   \quad\text{equivalently}\quad
   \eta\ge\frac{\tau}{1+\tau}.
   \tag{14}
   \]
   This is not the replacement-fraction convention in (13). For reporter columns of \(E_\kappa=\kappa I+(1-\kappa)\mathbf1\mathbf1^T/K\), the TV separation is \(\kappa\), so Huber emission neighborhoods overlap at \(\eta\ge\kappa/(1+\kappa)\).

4. **Rare-row transition bound.** If a global fraction \(\varepsilon_{\rm endpoint}\) of the \(2N_t\) endpoints is bad, at most \(2\varepsilon_{\rm endpoint}N_t\) pairs are touched. A row of occupancy \(\pi_iN_t\) can therefore suffer corruption fraction as large as \(\min(1,2\varepsilon_{\rm endpoint}/\pi_i)\). There is no valid \(O(\varepsilon_{\rm endpoint})\) row bound uniform in \(p_*\). A two-state one-sided witness with \(\pi=(p,1-p)\), row 0 of \(P_0\) always ending at 0, and row 0 of \(P_1\) always ending at 1 erases the distinction by corrupting all row-0 post blocks. This costs \(pN_t\) bad post blocks, or \(p/2\) of all endpoints. With two-sided replacement and endpoint-law TV \(\tau\), the exact indistinguishability threshold is lower: \(p\tau/4\) of all endpoints, as in item 2. The \(p/2\) example is a simple one-sided construction, not the minimax overlap threshold.

The theorem's \(q_{\rm phys}\le p_*\bar\Gamma/768\) is sufficient, not sharp. It is determined by the proof's row-error allocation, class visibility, and testing gap; it is not asserted to equal an information-theoretic threshold.

## Equally informed control and physical gate

For a fixed active schedule and nuisance/model class, an optimal likelihood on the same categorical records receives at least as much information as frequency clustering. The comparison must use the same founders, observation channel, emission nuisance class, and disturbance model. If raw time tags are also available, their full likelihood may use more information; this categorical theorem does not model or lower-bound that richer channel. A passive likelihood is ruled out only by a lower bound for a declared passive action class; the separate no-freeze full-likelihood result supplies such a bound for uniformly mixing, common-stationary actions, not arbitrary passive HMMs.

For the mathematical cycle witness \(K=3,\Gamma=0.20900495,p_*=1/3,\alpha=0.05,\kappa=0.1,\Delta=0.01\) s, the formulas give \(\epsilon=p_*\Gamma/192\approx3.63\times10^{-4}\), \(q_{\rm phys}\le\epsilon/4\approx9.08\times10^{-5}\), and \(N_t\approx2.95\times10^5\) episodes. A covered maximum epoch is \(R_J=524{,}288\), giving about \(3.09\times10^{11}\) frames and 97.8 years of held-read time at 10 ms/frame. With \(q_{\rm ramp}=0\) and \(\Lambda=10\,\mathrm{s}^{-1}\), (2) permits only \(\rho\lesssim1.73\times10^{-9}\). These conservative model-bound costs omit ramps, preparation, control, calibration, and recovery. The 10-ms interval is the mathematical witness, not the NV RIM interval.

The separate NV-\(^{14}\)N report records 80,000 RIMs in 1.695 s (about 21.19 \(\mu\)s/RIM and 0.05 detected photons/RIM), with fitted 1.695-s exit estimates around 10.7% and 13.8% at a conditionally matched duty point. These are not a worst-case history-conditioned envelope. The theorem's cost witness uses 524,288 10-ms categorical reads per block, while NV uses a distinct RIM, emission, and quantum-instrument interface; the fitted exits cannot be ratio-compared to the theorem's per-block gate. The NV source audit notes the operating-condition join and absent matched likelihood/resource comparison. These NV numbers and the mathematical cycle witness are separate systems and operating points.

## Prior-art and novelty boundary

Three-view mixture identification, latent-state permutation ambiguity, vector concentration, robust clustering, and Dobrushin contraction are established tools. Orthogonal tensor inversion in the separate transition report has a conservative \(\kappa^{-16}\)-type record exponent after charging whitening and inverse emission matrices. The conditional composition here is repeated block means, an observable outlier certificate, a history-uniform martingale count, and the rowwise deletion/reassignment bound (7)–(8). Novelty and priority remain UNKNOWN; there is no external review or physical validation.
