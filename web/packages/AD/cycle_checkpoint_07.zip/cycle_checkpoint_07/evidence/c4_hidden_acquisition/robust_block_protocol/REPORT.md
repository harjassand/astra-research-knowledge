# Robust slow-block acquisition: report

## Result

A finite fixed-pair test can tolerate a calibrated *fraction* of corrupted pre/post blocks, rather than requiring every block to remain jump-free. After charging adversarial corruption to each transition row, a sufficient history-uniform physical block risk is
\[
q_{\rm phys}\le p_*\min(1,\Gamma)/768.
\]
The bound is independent of the number of blocks \(B\), unlike the prior \(\alpha/(4B)\) union bound. The proof uses no supplied labels, reset, known \(E\), \(\kappa\) oracle, or free calibration cohort. Pre blocks from the same paired transition cohort identify emission clusters with a finite observable certificate.

The hostile rare-row audit changes the constant materially. A global fraction of bad endpoints \(\epsilon\) can put as much as \(2\epsilon/p_*\) of one rare row's paired data at risk. The transition-estimation error therefore carries \(\epsilon/p_*\); the proof explicitly budgets source-label reassignment as well as destination corruption. The minimax overlap threshold depends on the precise corruption convention and is listed in [PROOF.md](PROOF.md).

This theorem is only conditional on a uniform per-block physical bound across all states, histories, ramps, and read actions. It does not infer that bound from an average jump rate or fitted T1. Robust clustering is a summary of the same records, so an optimal likelihood on the same active schedule is at least as informed.

## Resource witness

The mathematical three-state cycle pair uses \(K=3\), \(\Gamma=0.20900495\), \(p_*=1/3\), \(\alpha=0.05\), \(\kappa=0.1\), and a 10-ms read interval. The finite calculator gives
\[
\epsilon=3.6286\times10^{-4},\quad q_{\rm phys}\le9.0714\times10^{-5},
\quad N_t=294{,}411,\quad R_J=524{,}288.
\]
That is 588,822 slow blocks, at most \(3.0871\times10^{11}\) frames, and 97.83 years of held-read time, excluding ramps, probe actions, calibration, founders, detector/control overhead, culture, viability, and recovery. If the ramp risk were zero and the exact scalar-rate model held with \(\Lambda=10\,{\rm s}^{-1}\), the maximum-epoch requirement permits only \(\rho\le1.73\times10^{-9}\). The improvement over the prior no-jump gate is a looser block-risk budget, not a practical acquisition win: read wall time remains enormous and the paid slowdown is extreme.

The output of [check_robust_and_mixing.py](check_robust_and_mixing.py) and [finite_check.json](finite_check.json) is a finite arithmetic check, not a physical measurement or proof of nature.

## Physical interface

The closest source-supported repeated-read/action examples are separate and do not close the theorem gate:

- The 2025 NV-\(^{14}\)N experiment reports 80,000 RIMs in 1.695 s, about 21.19 \(\mu\)s/RIM and 0.05 detected photons/RIM, with 97% \(\pm2\%\) final bright/dark readout at its fidelity setting. Its fitted state-exit estimates at a conditionally matched duty point are 10.7% and 13.8% over 1.695 s. These are fitted means/standard deviations, not a worst-case history-conditioned upper bound; the theta condition for the T1 scan is not explicitly joined to the fidelity point. The nuclear system is a discrete-time quantum instrument, and the source does not certify a common \(E\), uniform ramp envelope, or matched likelihood advantage. See [robust_nv/REPORT.md](../robust_nv/REPORT.md) and [robust_nv/SOURCES.md](../robust_nv/SOURCES.md). I do not convert its RIM cadence or fitted exits into the mathematical cycle's 10-ms read cost.
- Hohng et al.'s force-smFRET Holliday-junction experiment shows reversible force changes while acquiring FRET traces, with HMM-inferred force-dependent kinetics. Its 10-ms integration traces and force calibration do not provide a per-state, ramp-inclusive disturbance envelope or photon/time-matched full-likelihood comparison. The force changes occupancy and rates asymmetrically; it is not a validated scalar slowdown. See [application_smfret/REPORT.md](../application_smfret/REPORT.md) and [application_smfret/SOURCES.md](../application_smfret/SOURCES.md).
- Cryo-arrest sources demonstrate selected repeated imaging after temperature/medium ramps, not a \(Q\mapsto\rho Q\) action on arbitrary fate states with invariant emission columns and a bound at this \(q_{\rm phys}\). See [slow_readout/SOURCES.md](../slow_readout/SOURCES.md).

No named physical system currently passes the needed action, emission, occupancy, ramp, read-duration, and cost gates. Application status is UNKNOWN.

## Stronger passive control and novelty

A separate full-sequence lower bound in [no_freeze_full_likelihood/PROOF.md](../no_freeze_full_likelihood/PROOF.md) shows that, for a known weak reporter with uniform stationary law and an action set whose doubly stochastic kernels all have Dobrushin coefficient bounded by a fixed \(r<1\), every adaptive full-likelihood test needs \(\Omega(\kappa^{-4})\) observations. It covers the complete sequence and outcome-adaptive action choice, so the earlier two-read-pair lower bound is not the only passive evidence. The conclusion stops at this uniformly mixing class: if a legal cadence shrinks so \(r\to1\), the bound loses uniformity. Such a cadence needs separate wall-time, photon-dose, and disturbance analysis.

Three-view identification, Dobrushin contraction, and robust concentration are prior art. The rowwise corruption composition is internally reconstructed here; no external novelty or priority claim is made. The slow-action \(\kappa^{-2}\) construction, the passive \(\kappa^{-4}\) lower bound, and all physical evidence remain distinct status items.
