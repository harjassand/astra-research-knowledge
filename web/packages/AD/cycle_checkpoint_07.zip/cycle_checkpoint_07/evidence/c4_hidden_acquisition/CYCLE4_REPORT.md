# Cycle 4 hidden-state acquisition continuation

## Verdict

The strongest defensible continuation is two model results and one unresolved physical gate:

1. **Robust bounded-corruption extension.** The paid repeated-read theorem can tolerate a calibrated *fraction* of bad blocks using a martingale count bound instead of union-bounding every block. Hostile rare-row auditing forces a \(1/p_*\) transition error penalty. The resulting sufficient uniform block-jump gate is
   \[
   q_{\rm phys}\le p_*\min(1,\Gamma)/768.
   \]
   This is independent of block count \(B\), roughly 4,300 times looser than the old \(\alpha/(4B)\) gate in the finite witness. It remains a demanding uniform physical premise. The proof and exact thresholds are in [robust_block_protocol/PROOF.md](robust_block_protocol/PROOF.md).

2. **Full-sequence no-freeze lower bound.** Under a declared class of common-uniform-stationary, doubly stochastic controls whose Dobrushin coefficients are bounded by a fixed \(r<1\), every adaptive policy and the optimal likelihood on the same categorical output sequence require \(\Omega(\kappa^{-4})\) observations. This goes beyond the two-read pair-law lower bound, but it does not cover cadence families whose \(r\) approaches one as \(\kappa\) shrinks. See [no_freeze_full_likelihood/PROOF.md](no_freeze_full_likelihood/PROOF.md).

3. **No validated physical action.** NV-\(^{14}\)N offers repeated state-sensitive fluorescence and an operating-point read cadence, and force-smFRET offers reversible force actions during observation. Neither source establishes the theorem's stable common emission matrix, calibrated state/history/ramp disturbance envelope, matching classical action family, or same-resource likelihood advantage. Cryo-arrest is not evidence for a scalar slowdown of arbitrary fate-state transitions. Application status remains UNKNOWN.

These are conditional model statements, not biological or materials-system results. Novelty and priority remain UNKNOWN.

## Robust extension: proof and costs

The theorem estimates the unknown shared emission clusters using pre-read blocks from the same \(N_t\)-episode paired transition cohort. It supplies no state labels, reset, known \(E\), \(\kappa\) oracle, or separate calibration cohort. Its finite observed-center certificate is sound and abstains if no tuple passes; the exhaustive search costs \(O(\binom{N_t}{K}N_tK)\), so scalability is not claimed.

The key hostile correction is that a global fraction of corrupted endpoint blocks can concentrate in a rare source row. If at most \(\epsilon N_t\) pre and \(\epsilon N_t\) post blocks are bad, at most \(2\epsilon N_t\) pairs are touched. Row \(i\)'s transition error is bounded by \(24\epsilon/p_a\), with \(p_a\) a lower bound on action-boundary occupancy. The resulting finite-pair budget chooses \(\epsilon=p_*\bar\Gamma/192\) and \(q_{\rm phys}\le\epsilon/4\). Corrupted pre-label reassignments and post-endpoint replacements are both charged.

For the mathematical cycle witness at \(K=3,p_*=1/3,\Gamma=0.20900495,\alpha=.05,\kappa=.1,\Delta=.01\) s, the finite calculator gives \(N_t=294{,}411\), 588,822 read blocks, 524,288 frames per block, and \(3.0871\times10^{11}\) frames in total: 97.825 years of held-read time. This excludes ramps and all setup/control/recovery costs. The sufficient physical risk cap is \(9.0714\times10^{-5}\) per block. If \(q_{\rm ramp}=0\), the exact scalar-multiplier premise with \(\Lambda=10\,{\rm s}^{-1}\) requires \(\rho\le1.7302\times10^{-9}\). Thus the robust count extension eases the per-block probability gate but does not make the action accessible or the resource cost practical. A slowdown-price law is still unpriced; \(\rho\) may impose another cost.

The NV point is reported separately: 80,000 RIMs in 1.695 s, 21.19 microseconds/RIM, and about 0.05 detected photons/RIM, with fit-derived 10.7%/13.8% exit estimates over that source's 1.695-s cadence under a qualified operating-condition join. Those quantities are not directly ratio-compared with the mathematical cycle's 10-ms categorical read or the \(9.0714\times10^{-5}\) gate over 524,288 such reads. The source does not supply a worst-case confidence envelope, common classical \(E\), or the necessary state/history/ramp bound. Full details remain in [robust_nv/REPORT.md](robust_nv/REPORT.md).

## Exact information-theoretic corruption boundaries

Keep corruption models and denominators distinct:

- For arbitrary replacement of a fraction \(\varepsilon_{\rm pair}\) of whole paired records, the clean-law TV neighborhoods overlap iff \(\operatorname{TV}(F_0,F_1)\le2\varepsilon_{\rm pair}\). This is the exact two-world population overlap condition.
- If pre-record laws match and a post-block law differs by conditional TV \(\tau\) only on a row of mass \(\pi_i\), then \(\operatorname{TV}(F_0,F_1)=\pi_i\tau\). The exact two-sided threshold is \(\pi_i\tau/2\) among paired records or post blocks; if normalized over all pre and post endpoint blocks and only posts are corrupted, it is \(\pi_i\tau/4\). One-sided conversion to a clean alternate law costs \(\pi_i\tau\) post blocks.
- Under Huber mixture contamination \((1-\eta)F+\eta H\), overlap instead occurs iff \(\operatorname{TV}(F_0,F_1)\le\eta/(1-\eta)\), equivalently \(\eta\ge\tau/(1+\tau)\). For the \(E_\kappa\) reporter columns, \(\tau=\kappa\).
- Independently of exact overlap, a global endpoint fraction \(q\) only bounds a rare row's corruption fraction by approximately \(2q/p_i\). The two-state one-sided erasure at \(q=p_i/2\) is a concrete construction, not the two-sided minimax overlap point.

The robust theorem's \(p_*\bar\Gamma/768\) physical envelope is a sufficient proof threshold, not an information-theoretic sharp boundary. Exact statements and qualifications are preserved in the proof.

## Stronger full-likelihood control

For the known weak reporter \(W_\kappa=\kappa I+(1-\kappa)U\), a uniform stationary law, and all legal transition actions doubly stochastic with fixed Dobrushin bound \(r<1\), every possible observation history leaves each predictive filter within \(K\kappa r/(1-r)\) of uniform. Hence the next-output KL is at most \(8K^3\kappa^4(r/(1-r))^2\), and the KL of the full adaptive observation/action transcript is at most \(n\) times that bound. Pinsker yields the explicit sample lower bound in the proof.

At the mathematical three-state cycle's \(t=.05\) transition interval the Dobrushin coefficients are .47236655 and .53352270. At \(\delta=.05\), the explicit finite lower-bound coefficient is only \(n\ge0.0057335\kappa^{-4}\), about 58 observations at \(\kappa=.1\); it is an asymptotic-exponent result, not a strong finite-sample prediction there. For this irreducible cycle, any cadence floor \(t_{\min}>0\) fixed independently of \(\kappa\) gives a uniform \(r_{\max}<1\), so adaptive cadence choices above that floor remain covered. As \(t_{\min}\to0\), \(r_{\max}\to1\); an optimizer entering this regime needs a priced uniform-cadence analysis.

For any same-schedule categorical active data, the optimal likelihood dominates the block-frequency test by data processing. If a platform also records informative photon timestamps, those are extra observations outside the categorical theorem and may improve the physical likelihood. For the declared uniformly mixing class, even the optimal likelihood on the categorical sequence obeys the \(\kappa^{-4}\) lower bound. No active-versus-passive likelihood win is claimed outside it.

## Primary prior art and evidence status

- McDonald–Yuksel's controlled Dobrushin filter stability is prior art for controlled contraction; it does not state the present weak-reporter \(\kappa^4\) full-transcript KL bound.
- Allman–Matias–Rhodes, HMM spectral learning, robust tensor perturbation, categorical concentration, and robust contamination geometry are established ingredients. The new claims are only the internally reconstructed composition and exact constants/interface in these reports; no novelty priority claim.
- Gopich–Szabo and later photon-by-photon HMM methods are the relevant equally informed smFRET likelihood baseline. The available force-smFRET papers do not report the raw matched photon/time data needed for an equal-dose comparison.
- The 2025 NV-\(^{14}\)N paper documents repeated RIM readout, 80k/1.695-s, and duty-dependent persistence. Its readout and persistence points do not close the matched-confidence or classical-model bridge.
- The cryo sources document staged reversible imaging protocols and selected viability/function checks. They do not validate a fate-state \(Q\mapsto\rho Q\) law.

Astra-specific imported claims: none. This continuation composes the local c4 prior artifacts and the primary sources listed in the source notes; it does not treat the Astra path index or source coverage as theorem validation.

## Next decisive gate

The physical path stays UNKNOWN until one named assay supplies all of: a lower occupancy bound \(p_*\); an action kernel orbit gap \(\Gamma\); a shared full-rank state-conditioned emission law with read-duration and drift bounds; a one-sided jump/ramp envelope valid for every starting state and history at or below \(p_*\bar\Gamma/768\); and all-in resource measurements. A matched likelihood comparison must use the same raw photons, founders, elapsed time, detector dose, and action-ramp overhead. If the envelope or resource cap fails, reject this route for that assay.
