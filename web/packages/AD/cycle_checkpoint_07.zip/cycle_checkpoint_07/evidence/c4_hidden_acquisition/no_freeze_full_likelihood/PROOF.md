# Full-sequence lower bound without a slowly mixing action

## Interface

There are \(K\ge2\) hidden states, two candidate worlds \(b\in\{0,1\}\), and a known uniform initial state law \(u=(1/K,\ldots,1/K)\). At every observation time the tester sees \(Y_t\) from the symmetric weak reporter
\[
W_\kappa(y\mid i)=\frac{1-\kappa}{K}+\kappa\,\mathbf1\{y=i\},\qquad 0<\kappa\le\tfrac12.
\tag{1}
\]
This channel is known to the tester. It has smallest singular value \(\kappa\), uniform stationary law, and each symbol has probability at least \((1-\kappa)/K\).

After observing \(Y_t\), the tester may choose a control \(A_t\) by any randomized rule depending on the full past observation/action history. In world \(b\), the next hidden state is drawn from row-stochastic \(P_b^{A_t}\). Assume every legal matrix is doubly stochastic, so \(uP_b^a=u\), and has Dobrushin coefficient
\[
\delta(P)=\max_{i,j}\operatorname{TV}(P_{i\cdot},P_{j\cdot})\le r<1,
\tag{2}
\]
where \(r\) is fixed independent of \(\kappa\). The same policy is used in both worlds; it may know the two candidate worlds and all model parameters, but it sees only past outputs and actions. Every read and action has its actual positive cost; this theorem counts observations first.

This is a restricted passive/control class. It excludes a legal near-identity action whose Dobrushin coefficient approaches one as \(\kappa\to0\), a state-dependent permutation action, a change of stationary law, or a paid metastable hold. Those are separate interfaces.

## Filter perturbation

For a predictive state law \(\mu\) before one observation \(y\), Bayes' rule gives
\[
\mu^y_i=\frac{\mu_i[(1-\kappa)/K+\kappa\mathbf1\{i=y\}]}
{(1-\kappa)/K+\kappa\mu_y}.
\]
Direct subtraction yields
\[
\|\mu^y-\mu\|_1
=\frac{2\kappa\mu_y(1-\mu_y)}
{(1-\kappa)/K+\kappa\mu_y}
\le \frac{K\kappa}{2(1-\kappa)}
\le K\kappa.
\tag{3}
\]
The last inequality uses \(\kappa\le1/2\). This is a deterministic bound for every prior and observed symbol.

Let \(\mu_{b,t}\) be the predictive law of \(X_t\) in world \(b\), conditional on a common realized history \(H_t\) before \(Y_t\). Put \(x_{b,t}=\|\mu_{b,t}-u\|_1\). After \(Y_t\), (3) gives distance at most \(x_{b,t}+K\kappa\) from \(u\). The chosen action is the same conditional rule in both worlds, and its transition matrix is doubly stochastic with coefficient at most \(r\). Dobrushin contraction therefore gives
\[
x_{b,t+1}\le r(x_{b,t}+K\kappa).
\tag{4}
\]
Since \(x_{b,0}=0\), for every history,
\[
\|\mu_{b,t}-u\|_1\le \frac{K\kappa r}{1-r}.
\tag{5}
\]
This uses only a per-action bound, so actions may change with the observed history.

## Conditional observation divergence

The next-symbol law is
\[
q_{b,t}(y\mid H_t)=\sum_i\mu_{b,t}(i)W_\kappa(y\mid i)
=\frac1K+\kappa\left(\mu_{b,t}(y)-\frac1K\right).
\tag{6}
\]
By (5),
\[
\|q_{0,t}-q_{1,t}\|_1
\le\frac{2K\kappa^2r}{1-r}.
\tag{7}
\]
Every coordinate of either law is at least \((1-\kappa)/K\ge1/(2K)\). Using \(D(p\|q)\le\chi^2(p,q)\) and \(\|v\|_2\le\|v\|_1\),
\[
D(q_{0,t}\|q_{1,t})
\le 2K\|q_{0,t}-q_{1,t}\|_1^2
\le 8K^3\kappa^4\left(\frac r{1-r}\right)^2.
\tag{8}
\]
Conditioned on a shared history, the action policy has the same action distribution in both worlds. Thus actions contribute zero conditional KL. For \(n\) outputs \(Y_0,\ldots,Y_{n-1}\) and the \(n-1\) intervening actions, the chain rule gives the full-transcript bound
\[
D(\mathbb P_0^{A_{0:n-2},Y_{0:n-1}}\|
\mathbb P_1^{A_{0:n-2},Y_{0:n-1}})
\le 8K^3n\kappa^4\left(\frac r{1-r}\right)^2.
\tag{9}
\]
This applies to full observation sequences and every adaptive policy in this action class, not only one-lag pairs or frequency summaries. Here the observations are the categorical symbols in (1); additional photon interarrival times, waveforms, or action-duration signals are outside the model and need their own bound.

For a test with both errors at most \(\delta<1/2\), equal-prior average error is at most \(\delta\), so transcript TV is at least \(1-2\delta\). Pinsker then forces KL at least \(2(1-2\delta)^2\). Combining with (9),
If each output has a measured integration/wall-time cost bounded below by \(c_t>0\) and a detected-photon cost bounded below by \(c_\phi>0\), uniformly over the admitted controls and \(\kappa\), (10) also gives those same \(\kappa^{-4}\) resource lower bounds after multiplying by \(c_t\) or \(c_\phi\). When cadence changes these prices, no such conversion follows without a uniform priced-control analysis.
\[
n\ge
\frac{(1-2\delta)^2(1-r)^2}
{4K^3r^2\,\kappa^4}.
\tag{10}
\]
For \(r=0\), all transition actions reset to the common uniform law and the output laws are exactly equal at every time. Thus with fixed \(K,r<1\), fixed error below one half requires \(\Omega(\kappa^{-4})\) observations even though the reporter, stationary law, and candidate models are known to the tester. Hiding the reporter cannot improve this minimax lower bound.

## Three-state cycle instance

Take a directed three-state cycle generator with clockwise/counterclockwise rates \(5,5\) in world 0 and
\[
5+\frac{2\pi}{\sqrt3},\qquad5-\frac{2\pi}{\sqrt3}
\]
in world 1. At sampling/action interval \(t=0.05\), both transition matrices are doubly stochastic. The nontrivial eigenvalues have common modulus \(e^{-0.75}\) and phases \(0\) versus \(2\pi t\). Their maximum row-pair total-variation coefficients are
\[
r_0=0.4723665527,\qquad r_1=0.5335226983.
\]
Consequently (9) holds with \(K=3,r=0.5335226983\). At lag \(t=1\), phases agree modulo \(2\pi\) and endpoint matrices coincide; the \(0.05\) action is the distinguishing probe. The adjacent finite-check script verifies row-stochasticity, alias, Dobrushin values, and conditional KL bounds along every output history through depth five. This is arithmetic checking; (3)–(10) are the proof.

For this irreducible continuous-time cycle, every \(P_b(t)=e^{Q_bt}\) is strictly positive for \(t>0\), so \(\delta(P_b(t))<1\), and \(P_b(t)\to U\) as \(t\to\infty\). Consequently any cadence set with a positive minimum interval \(t_{\min}>0\), fixed independently of \(\kappa\), has a common bound \(r_{\max}(t_{\min})=\sup_{b,t\ge t_{\min}}\delta(P_b(t))<1\). The full-sequence theorem therefore also covers outcome-adaptive cadence choice within that fixed-floor set. It does not cover a cadence family whose minimum step shrinks with \(\kappa\): as \(t\to0\), transition matrices approach identity and \(r(t)\to1\), so the constant \(r/(1-r)\) in (9) diverges. Any optimization that moves into this regime needs the actual photon/read duration, action-time cost, and a bound uniform in cadence.

## Scope and status

The lower bound uses a known weak reporter and known uniform initial law, giving the tester more information than unknown-emission acquisition. It is a conditional theorem for common-stationary uniformly mixing actions, not a no-go theorem for all HMMs, all cadence policies, or all controlled experiments. The paid positive-slowdown protocol is outside its action class precisely because it seeks a transition kernel with \(r\) close to one while continuing to acquire emissions.

No real assay in the current source set is shown to satisfy this common-uniform, doubly stochastic kernel family. NV-14N is a discrete-time quantum-instrument metastability experiment; force-smFRET changes a molecular free-energy landscape and occupancy. Neither source establishes the present classical kernel family. Physical transfer remains UNKNOWN.
