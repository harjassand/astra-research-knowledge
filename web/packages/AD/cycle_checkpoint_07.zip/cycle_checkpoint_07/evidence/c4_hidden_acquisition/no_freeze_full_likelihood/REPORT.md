# Full-likelihood lower bound for uniformly mixing controls

The passive lower bound now covers the entire modeled categorical observation/action transcript, including adaptive action choice. With a known weak reporter \(W_\kappa=\kappa I+(1-\kappa)U\), common uniform stationary law, and every allowed transition kernel doubly stochastic with Dobrushin coefficient at most a fixed \(r<1\), the hidden predictive distribution stays within \(O(K\kappa r/(1-r))\) of uniform after every possible history. Each output law therefore differs between candidate worlds by only \(O(\kappa^2)\) in total variation and \(O(\kappa^4)\) in conditional KL. The chain rule gives
\[
D(\mathbb P_0^{\text{full transcript}}\|\mathbb P_1^{\text{full transcript}})
\le8K^3n\kappa^4\left(\frac r{1-r}\right)^2.
\]
Pinsker then forces \(n\ge (1-2\delta)^2(1-r)^2/[4K^3r^2\kappa^4]\) observations for both testing errors at most \(\delta<1/2\).

The action policy may know the two candidates and adapt to all categorical read outputs. Since its conditional rule is identical in the two worlds, its actions add no direct KL. This is stronger than a two-read-pair calculation for this declared action class. An optimal likelihood on these same categorical outputs cannot evade the lower bound. If photon timestamps or analog waveforms are separately observed, they are extra data outside this theorem.

For the specified three-state cycle at interval \(t=0.05\), a finite calculation gives Dobrushin coefficients \(0.47236655\) and \(0.53352270\); hence the bound applies with \(K=3,r=0.53352270\). At error target \(\delta=.05\), its explicit coefficient is only \(n\ge0.0057335\kappa^{-4}\), or about 58 observations at \(\kappa=.1\). This constant is weak at that finite point; the conclusion is the asymptotic exponent and full-sequence scope, not a practically large sample lower bound. At lag \(t=1\), endpoint matrices alias up to floating-point error, and the shorter probe distinguishes them.

This does not prove a passive lower bound for all CTMC acquisition. In the specific irreducible cycle, any admitted cadence with a fixed positive minimum interval has a uniform \(r_{\max}<1\), so the theorem covers adaptive choices within that set. If the minimum cadence approaches zero as \(\kappa\) shrinks, then \(r\to1\) and the constant diverges. Such an optimizer requires a bound priced against actual photon rate, detector integration, elapsed time, and disturbance.

The bound is a model theorem, not a physical statement about NV or smFRET. The 2025 NV report gives an actual 80,000-RIM / 1.695-s point and approximately 0.05 detected photons per RIM, but its spin system is a discrete-time quantum instrument and the source does not establish the theorem's classical uniform-stationary action family. Hohng force-smFRET records force-conditioned transitions, not a uniformly mixing common-stationary control family. Those physical interfaces remain UNKNOWN.

Novelty and priority are UNKNOWN. Filter contraction using Dobrushin coefficients is established prior art; the source boundary is documented in SOURCES.md. The \(\kappa^4\) full-sequence KL calculation and adaptive-policy consequence are internally derived here and have not been externally reviewed.
