# Primary-source notes

These sources delimit the result and its prior art. They do not validate the constructed mechanism pair or the biological assay assumptions.

1. **Gillespie (2000), “The chemical Langevin equation,” *Journal of Chemical Physics* 113(1), 297–306.** [DOI: 10.1063/1.481811](https://doi.org/10.1063/1.481811). Primary source for the CLE as a diffusion approximation derived from a chemical jump process. The present construction uses only the exact first two jump moments; equality of those coefficients does not assert equality of the underlying jump law.

2. **Nitinawarat, Atia & Veeravalli (2013), “Controlled Sensing for Multihypothesis Testing,” *IEEE Transactions on Automatic Control* 58(10), 2451–2464.** [DOI: 10.1109/TAC.2013.2261188](https://doi.org/10.1109/TAC.2013.2261188); [author/arXiv version](https://arxiv.org/abs/1205.0858). The paper treats fixed-sample and sequential controlled hypothesis tests. For binary fixed-sample testing it characterizes the optimal asymptotic error exponent through the best control, with a stationary open-loop choice asymptotically optimal among causal policies. This establishes that the generic controlled-sensing framework and likelihood-ratio methodology are prior art; it does not give the exact finite-n risk computed here for the specified CLE-alias family.

3. **Nitinawarat & Veeravalli (2013), “Controlled Sensing for Sequential Multihypothesis Testing with Controlled Markovian Observations and Non-Uniform Control Cost.”** [Primary author-hosted arXiv manuscript](https://arxiv.org/abs/1310.1844). This work treats sequential active acquisition with controlled Markov observations and unequal control costs, including asymptotic information-per-cost bounds. It is closer to the costed adaptive interface than a generic SPRT citation. The current proof is an exact two-point finite-channel specialization with an exact stopped-transcript KL identity, not a new general sequential-testing theorem.

4. **Chernoff (1959), “Sequential Design of Experiments,” ONR report SOL ONR 42.** [Stanford technical-report record](https://statistics.stanford.edu/technical-reports/sequential-design-experiments). Classical sequential experiment choice; cited only for the history of adaptive test design. The Stanford repository item was not successfully opened during this pass, so no detailed theorem attribution to it is used.

## Local evidence consulted

- `work/agents/cell_control/cell_lineage_graph/CYCLE3_REPORT.md`: exact $\nu_1,\nu_2,\nu_2^{rev}$ actionwise CLE alias; opposite safe-reach ranking; unknown-emission alias; previously reported one-bit/fixed-gap sample calculations. The mechanism pair is inherited from this file, and the current report does not claim a new construction.
- `work/agents/cell_control/cell_observation_design/CYCLE3_REPORT.md` and `CYCLE3_CLAIMS.json`: three-view controlled-HMM identifiability under full-rank emissions, plus the rank-one no-go and the standard HMM prior-art boundary.
- `work/agents/cell_control/cell_metastability/CYCLE3_REPORT.md`: exact hidden-phase pulse-word separation, finite grid/Lipschitz certificate, sequential confidence-set design, and high-switching abstention. This was not reused as the present construction.
- `work/agents/learning_acquisition/CYCLE2_REPORT.md`, `children/adaptive_conditioning/CYCLE2_REPORT.md`, and `proofs/rare_context_hmm.md`: exact separation of passive rare-context acquisition from chosen-prefix conditional sampling, and adaptive transcript accounting. Those reports motivate charging the actual sample/control interface; their rare-context lower bound is not used in the proof here.

## Search boundary

The primary-source pass checked classical and modern controlled-sensing literature at the level needed to avoid presenting adaptive sample allocation, likelihood-ratio stopping, or information-per-cost as new. It was not a comprehensive novelty review of branching processes, lineage assays, or CLE-equivalent mechanism identification. Novelty/priority remains **UNKNOWN**.
