# Proof: exact adaptive minimax acquisition for the three-daughter pair

## 1. Pointwise actionwise CLE equality and reversed optimum

The three family laws are

\[
\nu_1=(1,3,3,1)/8,\quad
\nu_2=(1,9,3,3)/16,\quad
\nu_2^{\rm rev}=(3,3,9,1)/16.
\]

Direct summation gives $E K=3/2$ and $E K^2=3$ for $\nu_1,\nu_2$. For $\nu_2^{\rm rev}$, write $K'=3-K$ with $K\sim\nu_2$; then

\[
E K'=3-EK=3/2,\qquad E(K')^2=9-6EK+EK^2=9-9+3=3.
\]

For $v_K=(K-1,3-K)$,

\[
E(K-1)=1/2,\quad E(3-K)=3/2,
\]

\[
E(K-1)^2=EK^2-2EK+1=1,
\]

\[
E(3-K)^2=9-6EK+EK^2=3,
\]

\[
E[(K-1)(3-K)]=4EK-EK^2-3=0.
\]

At state $(r,u)$, the division event rate is $\lambda r$. The CLE drift is the event rate times $E v_K$; its covariance rate is the event rate times the raw second moment $E[v_Kv_K^T]$. The resulting displayed $(b,A)$ are identical for every action and every full count state. In $W_+$, action A uses $\nu_1$ and B uses $\nu_2$; in $W_-$, A still uses $\nu_1$ and B uses $\nu_2^{\rm rev}$. Hence the two worlds have exactly the same actionwise $(b,A)$.

For all-R safe reach, $V(A)=\nu_1(3)=1/8$, $V_+(B)=\nu_2(3)=3/16$, and $V_-(B)=\nu_2^{\rm rev}(3)=1/16$. The unique best action is B in $W_+$ and A in $W_-$.

## 2. Sufficient statistic for one B-founder assay

For a B-assigned founder, let $K$ be the observed R-daughter count. Define

\[
S=\mathbf1\{K\in\{1,3\}\}.
\]

Then

\[
P_+(S=1)=\frac{9+3}{16}=\frac34,\qquad
P_-(S=1)=\frac{3+1}{16}=\frac14.
\]

The likelihood ratios for (K=0,1,2,3), in that order, are

\[
\frac{\nu_2(k)}{\nu_2^{\rm rev}(k)}=(1/3,3,1/3,3).
\]

Thus the full $K$-record likelihood ratio depends only on $S$. Given the parity class $S$, the conditional law of $K$ is the same in both worlds: when $S=1$, $P(K=1\mid S)=3/4$, and when $S=0$, $P(K=0\mid S)=1/4$. Conditional on $K$, the three ordered sister-label patterns are uniform in both worlds. Therefore $S$ is sufficient for the complete three-sister record, not merely a convenient lossy summary. Its log-likelihood increment is $+\log3$ when $S=1$ and $-\log3$ when $S=0$.

For action A, the same $\nu_1$ is used under both worlds, so every possible A record has likelihood ratio 1. The first-division time also has the same $\operatorname{Exp}(\lambda)$ law under both worlds, and is ancillary for the mechanism sign.

## 3. Exact fixed-sample minimax risk

First suppose $n$ B-assigned independent founders are observed. Let $T=\sum_{i=1}^n S_i$. The log likelihood ratio is

\[
\log\frac{dP_+}{dP_-}=(2T-n)\log3.
\]

The likelihood-ratio test chooses $W_+$ if $T>n/2$, $W_-$ if $T<n/2$, and randomizes fairly on a tie. Under $W_+$, $T\sim\operatorname{Bin}(n,3/4)$; under $W_-$, its distribution is the reflection $n-T_+$. This symmetry makes the two error probabilities equal. The equal-prior Bayes risk is a lower bound on the maximum error of every test, and the symmetric likelihood-ratio test attains that Bayes risk with equal errors. It is therefore the exact minimax test, with

\[
R_n=\sum_{k=0}^{\lfloor(n-1)/2\rfloor}{n\choose k}(3/4)^k(1/4)^{n-k}
+\mathbf1_{2\mid n}\frac12{n\choose n/2}(3/4)^{n/2}(1/4)^{n/2}.
\]

For $n=8$, this is $289/4096\approx0.0705566$. For $n=9$, it is $6413/131072\approx0.0489273$. Hence $n=9$ is the smallest fixed number of informative founder assays meeting a 5% maximum-error target.

Now allow any causal policy to choose A or B before each founder, using prior records, and stop by a cap of $n$ founders. Conditional on the prior history and chosen action, an A record has the same law under both hypotheses. A B record is exactly one draw from the channel above. Any such experiment can be simulated from $n$ i.i.d. B records by discarding records whenever the adaptive policy chooses A and generating common A records from their identical law. This is hypothesis-independent random postprocessing of the all-B data. By Blackwell/data-processing monotonicity, no adaptive policy under the $n$-founder cap has lower minimax error than the exact $R_n$; assigning B to every founder attains $R_n$. This proves all-B minimaxity for the two-point pair.

The action A can still be useful to check a broader model or establish that a real treatment matches the stipulated \(\nu_1\); those are separate hypotheses and costs. It cannot improve the sign test within the declared two-world family.

## 4. Adaptive optional stopping: exact information lower bound

Consider any randomized causal policy that selects actions between independent founders, observes the corresponding full record, stops at a stopping time $\tau$, and outputs $\widehat m\in\{+,-\}$. Assume $E_+N_B,E_-N_B<\infty$, where $N_B$ is the number of B-assigned founders before stopping. The policy's action-selection and stopping kernels are the same functions of the data under both mechanisms, so they cancel in the transcript likelihood ratio. Each B assay contributes expected log-likelihood $\log3$ with probability $3/4$ and $-\log3$ with probability $1/4$ under $W_+$, giving

\[
d:=D(\operatorname{Bern}(3/4)\|\operatorname{Bern}(1/4))
=\frac34\log3+\frac14\log(1/3)=\frac12\log3.
\]

By the likelihood-ratio chain rule (or Wald's identity for the stopped log-likelihood),

\[
D(P_+^{\tau}\|P_-^{\tau})=d\,E_+N_B.
\]

The reverse divergence is likewise $D(P_-^{\tau}\|P_+^{\tau})=d\,E_-N_B$. If each error probability is at most $\delta<1/2$, data processing from the full transcript to the terminal decision gives

\[
D(P_+^{\tau}\|P_-^{\tau})
\ge \operatorname{kl}(P_+(\widehat m=+),P_-(\widehat m=+))
\ge \operatorname{kl}(1-\delta,\delta).
\]

Therefore, under both worlds,

\[
E_{\pm}N_B\ge \frac{\operatorname{kl}(1-\delta,\delta)}{(1/2)\log3}.
\]

At $\delta=0.05$, the right side is $0.9\log19/(0.5\log3)\approx4.825$. If a B-assigned founder assay has constant total price $c_B^{\rm assay}$, this yields the paid-data lower bound $E_{\pm}C\ge c_B^{\rm assay}\operatorname{kl}(1-\delta,\delta)/((1/2)\log3)$, before adding required fixed calibration and confirmation costs. A-only trials add positive cost but no information and cannot lower this bound.

## 5. A finite-cost sequential upper bound

Use only B and accumulate the parity log likelihood. Let $Z_j=+1$ when the jth $S$ is one and $Z_j=-1$ otherwise. Stop when

\[
\left|\sum_{j=1}^N Z_j\right|=m,
\qquad m=\left\lceil\frac{\log((1-\delta)/\delta)}{\log3}\right\rceil,
\]

and choose the sign of the sum. Under $W_+$, $Z_j$ is $+1$ with probability $3/4$; under $W_-$, those probabilities reverse. The gambler's-ruin calculation gives the exact equal error probabilities $P_+(\widehat m=-)=P_-(\widehat m=+)=1/(1+3^m)\le\delta$.

The biased nearest-neighbor walk hits $\pm m$ almost surely. Optional stopping for the bounded stopped walk gives, under either world,

\[
E_{\pm}N=\frac{m(3^m-1)}{(3^m+1)(1/2)}
=2m\frac{3^m-1}{3^m+1}.
\]

For $\delta=0.05$, $m=3$, so the exact error is $1/28$ and $E_{\pm}N=39/7\approx5.571$. Each parity $S$ is computed from one complete family record, so the variable assay price is $(39/7)c_B^{\rm assay}$. This is an explicit feasible rule, not a proof that it is the exact minimum expected sample size for each finite $\delta$; the KL converse above is the lower bound.

## 6. Interface boundary

The exact nine-founder result requires: (i) the two specified simple hypotheses; (ii) direct, semantically anchored daughter labels; (iii) independent founders; (iv) one action fixed before each first division; (v) complete first-division records; and (vi) no interference between founders. Unknown reporter matrices, extra candidate transition laws, lineage dependence across founders, right censoring, and population clustering invalidate the simple Bernoulli likelihood and must be included in an expanded model. If only (b,A) are returned, the transcript is exactly identical under the pair and no finite or infinite adaptive query budget can identify the optimal action.
