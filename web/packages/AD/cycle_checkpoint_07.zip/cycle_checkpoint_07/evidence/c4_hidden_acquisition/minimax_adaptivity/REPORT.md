# Adaptive minimax acquisition for an actionwise CLE alias

## Result

I derived an exact acquisition benchmark for the strict three-daughter actionwise CLE alias already recorded in the cell-lineage Cycle 3 report. Under the legal assay below, the full three-sister outcome has a one-bit sufficient statistic. Action A is exactly uninformative between the two candidate mechanisms, while action B yields Bernoulli observations with probabilities $3/4$ and $1/4$. Therefore, among all adaptive choices across independent founder assays, using B on every founder is minimax for this two-mechanism discrimination task.

For $n$ B-founder observations, the exact minimax error is

\[
R_n=\Pr\{T<n/2\}+\tfrac12\Pr\{T=n/2\},\qquad T\sim\operatorname{Bin}(n,3/4),
\]

where the tie term is zero for odd $n$. The smallest fixed sample size giving error at most $0.05$ is **nine independent B-founder assays**, with exact error $6413/131072\approx0.04893$. Eight assays have error $289/4096\approx0.07056$. For any adaptive, possibly sequential policy whose worst-case error is at most $\delta<1/2$, the expected number of B-founder assays under either mechanism is at least

\[
\frac{\operatorname{kl}(1-\delta,\delta)}{\tfrac12\log 3}.
\]

At $\delta=0.05$, this is about 4.825 B assays. A simple SPRT uses one sufficient bit from each full family record and has error exactly $1/28\approx0.0357$ and expected sample size $39/7\approx5.571$ under either mechanism. Thus the lower and constructive upper bounds are close in founder count.

This is a scoped two-point minimax result, not a claim to identify an unrestricted CLE-equivalence class. Any procedure required to recover the optimal action uniformly over a larger class containing these two mechanisms inherits this lower bound. The result gives a strong model-based acquisition benchmark; it does not remove calibration, model checking, or biological validation costs.

## Legal control and observation interface

There are independent founder clones. Each clone is assigned exactly one action, A or B, before its first division. After that first division, the assay records the semantic R/U fate of each of the three daughters and the division time. All three daughter labels from one founder form one observation; they are never counted as independent samples. No within-clone feedback action, hidden-state label, chosen-prefix sample, or latent-feature oracle is available. Between founders, the next action and the stopping decision may be randomized functions of the complete prior transcript.

The event time has the same rate under both hypotheses. The mechanistic test conditions on the first completed division, so the common rate does not affect its daughter-law likelihood. A real assay must either follow to completion or include right-censoring in the likelihood. The total price of one B observation is denoted

\[
c_B^{\rm assay}=c_{\rm founder}+c_{\rm B\ dose}+c_{\rm followup}+c_{\rm barcode}+3c_{\rm fate\ read}.
\]

Here follow-up includes event monitoring until the first division. At common rate $\lambda$, mean follow-up time is $1/\lambda$; if monitoring costs $c_{\rm time}$ per time unit, use $c_{\rm followup}=c_{\rm time}/\lambda$ (or $c_{\rm time}/\lambda_{\min}$ for a supplied lower rate bound). The result's expected variable cost lower bound is $c_B^{\rm assay}\operatorname{kl}(1-\delta,\delta)/(\tfrac12\log 3)$, under the stated constant per-founder price. Add one-time costs for semantic fate-panel calibration, delivered-dose calibration, independent-founder/blocking checks, and any empirical confirmation that the two actionwise CLE fields match. These costs are not supplied by the theorem and must be reported separately. If the fate labels are unknown or unanchored, the interface changes and this result does not identify biological R/U semantics.

## CLE-equivalent mechanism pair and control objective

Let $K\in\{0,1,2,3\}$ be the number of regenerative (R) daughters; the remaining daughters are unsafe (U). Conditional on $K$, the R sister positions are uniformly selected. The action-conditioned family laws are

| law | $P(K=0,1,2,3)$ |
|---|---|
| $\nu_1$ | $(1,3,3,1)/8$ |
| $\nu_2$ | $(1,9,3,3)/16$ |
| $\nu_2^{\rm rev}$ | $(3,3,9,1)/16$ |

The two candidate worlds are $W_+=(A:\nu_1,B:\nu_2)$ and $W_-=(A:\nu_1,B:\nu_2^{\rm rev})$. Every R parent divides at the same rate $\lambda$ under either action and world. The full count increment at division is $v_K=(K-1,3-K)$, giving $E[v_K]=(1/2,3/2)$ and $E[v_Kv_K^T]=\begin{psmallmatrix}1&0\\0&3\end{psmallmatrix}$ under all three laws. At every full count state $(r,u)$, for either action,

\[
b((r,u),a)=\lambda r(1/2,3/2),\qquad
A((r,u),a)=\lambda r\begin{pmatrix}1&0\\0&3\end{pmatrix}.
\]

Thus $W_+$ and $W_-$ are exactly actionwise CLE-equal. The target is the action maximizing one-division all-R safe reach, $V(a)=P_a(K=3)$. In $W_+$, $V(B)=3/16>1/8=V(A)$; in $W_-$, $V(A)=1/8>1/16=V(B)$. Correct action recovery therefore identifies the mechanism sign.

If the supplied data service returns only the exact CLE fields $b(x,a),A(x,a)$, its transcript is identical in the two worlds for every adaptive state/action query. Every randomized selector then has worst-case error at least $1/2$, regardless of query budget. A jump-level family observation is necessary.

## Practical reading

The existing lineage report obtains a sufficient Hoeffding design by comparing two action-arm safe-reach estimates and gives a 767-founder-per-action figure for its stated gap. The exact calculation here solves a narrower but relevant acquisition problem: the candidate pair is specified, the common A-law is part of that specification, and the complete first-division family record is directly classified. Under those conditions A outcomes carry no information about the sign; spending founders on A cannot improve the minimax discrimination risk. The parity statistic $\mathbf1\{K\text{ is odd}\}$ retains all the B-law information, so a likelihood-ratio test sharply reduces the sufficient count.

This comparison is not a claim that nine founders suffice for discovery of the model class, estimation of an unknown baseline mechanism, unknown emission calibration, donor-level generalization, or biological confirmation. Those tasks add data and calibration costs. A real assay should record complete sister patterns and retain the full K histogram when its action-law assumptions are not already certified.

## Prior-art and claim boundary

Controlled sensing, likelihood-ratio testing, and cost-aware sequential design are established. The local theorem is an exact finite-sample specialization to this two-point actionwise CLE alias: it identifies the sufficient statistic, gives the fixed-$n$ minimax risk, proves that adaptive action allocation cannot outperform B-only sampling for this pair, and gives a finite expected-cost lower bound. No external priority claim is made. The mechanism pair itself was already present in the local Cycle 3 report; this report contributes an acquisition/minimax audit for that pair and has not undergone independent mathematical review.

## Evidence status

- Exact algebraic identities and finite-sample risks are derived in [PROOF.md](PROOF.md).
- Primary-source scope and retrieval notes are in [SOURCES.md](SOURCES.md).
- No new simulation, laboratory data, model fit, or external review was performed.
- The result assumes direct semantic labels and the exact two-world hypothesis set. Unknown labels, action delivery, division censoring, or extra candidate mechanisms require an expanded likelihood and can only increase the required acquisition budget or force `UNKNOWN`.
