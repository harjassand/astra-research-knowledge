# Primary-source ledger: photon-emitting defect candidate

Sources reviewed on 2026-10-08. The links below point to primary experimental papers or author-hosted full text. Statements are scoped to the conditions actually reported.

## NV-centre nuclear-spin readout and slowdown

1. **Philipp Neumann et al., “Single-Shot Readout of a Single Nuclear Spin,” Science 329, 542–544 (2010).** [DOI / publisher record](https://doi.org/10.1126/science.1189075); [author-hosted full text PDF](https://www3.physik.uni-stuttgart.de/TR21/common/show_file.php/publications/567/publication.pdf).
   - The measured state is the NV-host nitrogen \(^{14}\mathrm N\) spin. State-selective microwaves map it to the NV electron spin, whose fluorescence is measured optically; repeated measurements are described as nondestructive to the nuclear-state population under their operating conditions.
   - Each displayed time-series point averages 5 ms / 2,000 readout repetitions. Photon-count histograms distinguish \(m_I=-1\) from \(m_I=0,+1\), with fidelity \(92\pm2\%\) at 0.65 T. Consecutive readouts return the same class with about 82% probability.
   - The authors report a measured transition matrix from approximately 10,000 nuclear-spin jumps, with uncertainty bars on lifetime measurements. They measure a quadratic increase in lifetime as the axial magnetic field is detuned from the excited-state level anticrossing near 50 mT. The article explains the mechanism as suppression of excited-state electron–nuclear flip-flops by increasing Zeeman mismatch.
   - **Limit:** this is an empirical setting-specific estimate, not a finite-protocol worst-case confidence bound or a bound on field-ramp disturbance. The state-class histogram is not one common emission matrix proven invariant over the field sweep.

2. **Matthias Pfender et al., “Nonvolatile nuclear spin memory enables sensor-unlimited nanoscale spectroscopy of small spin clusters,” Nature Communications 8, 834 (2017).** [Published paper](https://www.nature.com/articles/s41467-017-00964-z); [author-hosted HTML full text](https://arxiv.org/html/1610.05675v1).
   - This study measures \(^{14}\mathrm N\) nuclear-memory lifetime in the dark and during continuous single-shot readout as a function of external field. Its text says the lifetime during repeated readout scales approximately quadratically with field and reaches about 1 s at 3 T. It explicitly notes dependence on the microwave, wait, and laser timing.
   - The experiment uses a superconducting vector magnet up to 3 T and microwave transitions near 40 GHz. The paper reports a different, much longer dark-state lifetime (roughly 240–280 s at 1.5 T); that number must not be substituted for lifetime during optical readout.
   - **Limit:** the paper does not provide a wall-clock ramp/settling price or a matched passive likelihood test.

3. **“Observation of metastability in open quantum dynamics of a solid-state system,” Nature Communications (2025).** [Published paper](https://doi.org/10.1038/s41467-025-64772-6); [open full text via Nature](https://www.nature.com/articles/s41467-025-64772-6).
   - At room temperature, the authors use the NV electron as probe and the host \(^{14}\mathrm N\) spin as a three-state bath/memory. They show two- and three-level jump traces under repeated interaction measurements, fit the traces with an HMM, and report state-dependent bright/dark photon distributions and readout fidelity \(97\pm2\%\) for a specified bright/dark classification.
   - The stated operating point includes \(B=108.4\pm0.2\) G, field tilt \(7\pm2^\circ\) for the reported single-shot fidelity, RIM interval \(374\) ns, a 220 ns optical readout pulse, and 80,000 repetitions in 1.695 s. The detected mean is about 0.05 photon per measurement. Microwave resonance is remeasured and adjusted before sequential runs to compensate temperature drift.
   - Varying optical duty cycle and inserting waits between measurements changes measured nuclear-spin relaxation; the longest reported \(T_1\) is \(15\pm3.5\) s. This is a paid timing action. The source also states that field angle and RIM interval affect metastability and readout, so emissions and transition laws must be calibrated per condition.
   - The 1.695 s / 97% readout point and the longest-lifetime point are not reported as one jointly optimized schedule; do not combine them as a single certified performance point.
   - **Limit:** fitted lifetime/HMM evidence is not a one-sided state-by-state transition envelope, and the paper does not compare passive and altered schedules at equal walltime and detected-photon budget.

4. **Timothée de Guillebon et al., “Temperature-dependence of \(T_1\) spin relaxation of single NV centers in nanodiamonds” (2020 preprint).** [Author-hosted arXiv full text](https://arxiv.org/abs/2005.12083).
   - The same nanodiamond NV is measured at 298 K and 4 K: one reported center changes from \(T_1=82.6\pm6.6\,\mu\mathrm{s}\) to \(137\pm37\,\mu\mathrm{s}\); across 31 centers the mean relaxation-rate ratio is reported as \(\Gamma_1^{4K}/\Gamma_1^{298K}=0.41\pm0.1\). The paper attributes the weak temperature-dependent contribution to surface-related magnetic noise.
   - **Limit:** this modest change does not establish a tunable scalar slowdown, a repeated-read emission law preserved across temperature, or a field/temperature ramp envelope. It is a secondary candidate to the room-temperature field/timing action.

## Comparison candidates that fail the action gate

5. **K. T. Shimizu et al., “Blinking statistics in single semiconductor nanocrystal quantum dots,” Physical Review B 63, 205316 (2001).** [APS primary paper](https://journals.aps.org/prb/abstract/10.1103/PhysRevB.63.205316).
   - Single CdSe quantum-dot fluorescence on/off-time statistics follow a temperature-independent power law across the tested conditions. This is direct evidence against assuming low temperature alone suppresses the relevant blinking transitions in those dots.

6. **“Tunable and high-purity room-temperature single-photon emission from atomic defects in hexagonal boron nitride.”** [Primary paper full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC5615041/).
   - Demonstrates strain-controlled spectral tuning over 6 meV and high-purity, photostable single-photon emission. It does not report a hidden-state transition-rate slowdown with the emission likelihood fixed.

7. **“An ultrastable and robust single-photon emitter in hexagonal boron nitride,” Physica E 124 (2020), 114251.** [Primary paper](https://doi.org/10.1016/j.physe.2020.114251).
   - Reports long photostability and pressure-associated fluorescence activation/quenching that recovers on return to atmospheric pressure. Those are changes in emitter activation/availability; they do not furnish a calibrated transition-rate envelope for a hidden-state model under repeated emission reads.

## Audit boundary

The primary evidence supports the hardware feasibility and selected operating-point measurements described above. No source found in this audit reports the decisive comparison under equal elapsed time and equal detected-photon dose, with the transition-pair likelihood scored on held-out trajectories. No source supplies a protocol-wide field-ramp, settling, and repeated-read transition confidence envelope. Those are the outstanding experimental gates; they are not implied by a successful readout fidelity or an exponential \(T_1\) fit.
