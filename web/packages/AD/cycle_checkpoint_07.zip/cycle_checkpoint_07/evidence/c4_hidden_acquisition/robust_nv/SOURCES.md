# Primary sources and evidence map

## S1. Main experiment

Jun-Xiang Zhang, Yuan-De Jin, Chu-Dan Qiu, Wen-Long Ma, and Gang-Qin Liu, “Observation of metastability in open quantum dynamics of a solid-state system,” *Nature Communications* 16, 9818 (2025), [DOI/full article](https://doi.org/10.1038/s41467-025-64772-6).

Relevant locations in the publisher article:

- Experimental implementation / Fig. 4 discussion: B = 108.4 ± 0.2 G; τ = 374 ns; 220 ns read pulse; average 0.05 detected photons/RIM; m = 80,000, total readout 1.695 s, 97% ± 2% fidelity, threshold count 2,950; bright/dark definition; longest fitted T₁ = 15 ± 3.5 s. [Article](https://www.nature.com/articles/s41467-025-64772-6)
- Methods / experimental setup: room-temperature apparatus, 532 nm laser, approximately 300 kcps saturation count rate, magnetic field and microwave calibration. The ODMR spectrum is remeasured and the microwave adjusted before each sequential RIM run to compensate temperature drift. [Article](https://www.nature.com/articles/s41467-025-64772-6)
- Fig. 4 caption: fidelity series uses θ = 7° ± 2° and τ = 374 ns (red) or 370 ns (blue); panel b is T₁ versus excitation-laser duty ratio, with vertical errors described as fit standard deviations. DR is defined as measurement time divided by waiting time. [Article](https://www.nature.com/articles/s41467-025-64772-6)
- The discussion attributes transitions to excited-state hyperfine flips triggered by optical excitation and says shorter excitation and added waits suppress relaxation. [Article](https://www.nature.com/articles/s41467-025-64772-6)

## S2. Supplementary information

Zhang et al., Supplementary Information for the same paper, [publisher PDF](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-64772-6/MediaObjects/41467_2025_64772_MOESM1_ESM.pdf).

Page/passage map (PDF page numbers are zero-indexed in the browser extraction):

- pp. 1–2, Supplementary Note I: one RIM consists of a 720 ns polarization pulse, 24 ns π/2 pulse, free evolution τ, second 24 ns π/2, and a 220 ns read pulse. The source says the polarization pulse is 720 ns at about 500 µW; most sequential RIM runs insert a 20 µs wait after a laser pulse, while the T₁ scan varies waits from 1 to 20 µs. It states the per-shot average is about 0.05 photons.
- p. 9, Supplementary Fig. S9 caption: high-fidelity photon-count histograms use m = 80k; a continuous single-shot readout PL trace contains jumps and is fit by a three-state HMM to extract nuclear T₁.
- p. 10, Supplementary Fig. S10 caption: at fixed total sequence length, changing optical excitation duty / wait setting from 1:8 to 1:1 changes the jump rate. This is a fixed-setting comparison, not an outcome-adaptive full-likelihood versus passive comparison at matched photon dose.

## S3. Source Data workbook

The publisher's source-data archive is [MOESM3 Source Data RAR](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-64772-6/MediaObjects/41467_2025_64772_MOESM3_ESM.rar). It contains `Fig4b.xlsx`. Values read from the workbook (columns DR, T1B(s), errB(s), T1D(s), errD(s)):

| DR | T₁ bright | fit s.d. | T₁ dark | fit s.d. |
|---:|---:|---:|---:|---:|
| 1 | 4.69 | 2.50 | 3.48 | 2.07 |
| 0.25 | 6.95 | 1.51 | 4.19 | 1.21 |
| 0.125 | 7.73 | 2.08 | 5.36 | 1.64 |
| 0.0833333 | 8.09 | 1.53 | 5.53 | 1.43 |
| 0.0625 | 11.09 | 2.12 | 8.30 | 2.21 |
| 0.05 | 15.00 | 3.52 | 11.40 | 3.11 |

The calculation in `REPORT.md` uses the DR = 0.05 row and the main-text 1.695 s duration. `q = 1 - exp(-1.695/T1)` is a derived exponential-residence estimate, not a value printed by the paper and not a hard confidence bound. The paper defines DR as measurement-time/wait-time; the SI states a 1–20 µs wait scan and 20 µs waits in most sequential RIMs. Because panel 4b does not independently state the misalignment angle, the exact joint match to the θ = 7° ± 2°, 80k fidelity point remains qualified in the report.
