# NV-¹⁴N matched-point audit

## Verdict

The primary data support an *estimated*, state-conditional probability of at least one nuclear-spin jump during a nominal 80,000-RIM readout block, but not a strict bound and not a demonstrated active-versus-passive advantage. The best-supported nominal setting is the paper's 80k, 1.695 s readout at τ = 374 ns and duty ratio DR = 0.05. At that duty ratio, the source-data fit reports T₁ = 15.00 ± 3.52 s for the bright state and 11.40 ± 3.11 s for the dark state. Converting those fitted residence times to a 1.695 s block gives approximately 10.7% and 13.8% probabilities of at least one exit, respectively, under an exponential-residence model.

There is a material join caveat: the paper gives the angle θ = 7° ± 2° for the 97% readout-fidelity series, but does not separately restate θ for the T₁-versus-duty scan. The supplement ties the 20 µs wait to the usual RIM sequence and describes a 1–20 µs wait scan for T₁; DR = 0.05 is consistent with the 20 µs point. It does not explicitly identify the T₁ scan's angle as the same θ = 7° ± 2° readout run. I therefore report the block probabilities as a **conditional matched-cadence estimate**, and the strict all-parameters-same-point transition bound as **UNKNOWN**. The reported ± values are fit standard deviations, not hard confidence limits.

## Point and timing ledger

| Quantity | Primary-source value | Interpretation |
|---|---:|---|
| Platform | Room-temperature NV electron probe and nearby ¹⁴N nuclear spin; B = 108.4 ± 0.2 G near the NV axis | One physical NV/¹⁴N setup |
| RIM free evolution | τ = 374 ns | Used for the high-fidelity point; selected relative to electron T₂* and nuclear relaxation |
| Binary readout geometry | θ = 7° ± 2° for the fidelity trace | Bright = mixed {|0⟩, |−1⟩}; dark = |+1⟩ |
| RIM count and wall time | m = 80,000; 1.695 s total | 21.1875 µs per RIM, calculated as 1.695 s / 80,000 |
| Per-RIM optical pulses | 220 ns count/read pulse and 720 ns spin-polarization pulse | The latter follows readout; π/2 pulses are 24 ns each |
| Usual wait | 20 µs after the laser pulse in most sequential RIMs | T₁ scan varies this wait from 1 to 20 µs; DR is defined as measurement time / wait time |
| Nominal detected-photon dose | About 0.05 detected photons per RIM; about 4,000 per 80k block in expectation | Product of rounded source average and m; not a fixed realized count |
| Endpoint readout | 97% ± 2% fidelity at m = 80k, photon-count threshold 2,950 | End-to-end bright/dark classification estimate, not a per-RIM confusion matrix |

The 1.695 s block cadence is consistent with the standard approximately 20 µs inter-RIM wait plus pulse/control overhead. The supplement's DR = 0.05 T₁ point is the closest source-supported match to this cadence: the T₁ scan covers waits of 1–20 µs, and its excitation-plus-polarization measurement time is about 1 µs. Because the paper does not explicitly cross-label the angle for panel 4b, this is a nominal cadence match, not an exact joint calibration claim.

## Transition calculation

The primary source-data workbook `Fig4b.xlsx` gives the following values at DR = 0.05:

| Prepared state | T₁ fit | q over 1.695 s, using q = 1 − exp(−1.695/T₁) | Propagated T₁ ±1 fit-s.d. range |
|---|---:|---:|---:|
| Bright | 15.00 ± 3.52 s | 10.7% | 8.7%–13.7% |
| Dark | 11.40 ± 3.11 s | 13.8% | 11.0%–18.5% |

These are estimates for leaving the currently prepared bright/dark state at least once during a 1.695 s block, assuming the fitted T₁ is an exponential residence time and the DR = 0.05 cadence is the same cadence as the 80k block. They are not a strict probability bound: the error bars are standard deviations from fits, the exact θ match is not stated for the duty scan, and the source does not report a confidence construction or worst-case transition envelope. Nor should 97% ± 2% endpoint classification fidelity be substituted for q: classification error folds together photon-count overlap and within-block state transitions.

The experiment itself identifies the mechanism as optically triggered nuclear-spin flips via excited-state hyperfine interaction. Thus the RIM/readout action is perturbative, not a nondisturbing passive observation. The source reports that shorter optical excitation and longer waits reduce the jump rate.

## Calibration and stationarity evidence

The paper reports mean detection of about 0.05 photons per RIM and models state-conditioned counts with Poisson statistics, but does not publish a full state-by-action emission matrix or a time-resolved calibration showing that its parameters stay fixed across read blocks or duty/ramp changes. The 97% ± 2% readout value is an endpoint classification result after thresholding the 80k accumulated counts. The authors report preselecting bright/dark trajectories with initialization fidelity above 99% and use threshold 2,950 for the 80k result. They also remeasure ODMR spectra and retune microwaves before sequential RIM runs to compensate system temperature drift. This is relevant calibration practice, but the article does not give its time cost, residual drift, or repeated photon-likelihood calibration before/after each run.

Accordingly, source evidence for emission stationarity across blocks or a control ramp is **UNKNOWN**. A full-likelihood acquisition would require state-conditional count distributions calibrated at each action setting and checked over time; a single endpoint fidelity number does not supply that interface.

## Equal-cost comparison and ramp accounting

No primary-source result compares an outcome-adaptive full-likelihood policy to a passive policy at both matched wall time and matched detected-photon dose. Figure 4b is a fixed-duty T₁ scan, and Supplementary Fig. S10 compares duty settings at fixed total sequence length; neither reports a photon-dose-matched adaptive/passive likelihood comparison. Shortening optical pulses changes information per action as well as disturbance, so matching only elapsed time is insufficient.

A valid follow-on comparison would preregister the same 80,000 read pulses, 80,000 polarization pulses, τ, laser power and pulse energy, and total 1.695 s acquisition window in both arms. The active arm may place fixed-total wait gaps according to the full likelihood; the passive control should use a predetermined or observation-independent ordering of the same gaps and pulses. Record actual detected counts and include ODMR recalibration, microwave retuning, setting ramps, settling, and all added dark time in wall-time matching. If a condition ramp changes the photon emission law, reacquire the count calibration under that setting before evaluation. The paper gives no ramp/settling/calibration duration, so those costs and any equal-cost advantage remain **UNKNOWN**; its 15 s T₁ point cannot by itself establish an active protocol win.

## Gate result

- **Measured and source-backed:** 80k/1.695 s endpoint classification; optical/RIM pulse schedule; mean detected photons per RIM; T₁ fits by duty ratio; ODMR retuning practice.
- **Conditional finite calculation:** approximately 10.7% bright-state and 13.8% dark-state block-exit probability at the 80k wall time if the DR = 0.05 T₁ point is taken as the same cadence.
- **UNKNOWN:** strict same-θ transition bound; per-RIM state-transition probability; stationarity of the full emission likelihood; ramp and calibration costs; equal-walltime/equal-photon active-versus-passive performance.
