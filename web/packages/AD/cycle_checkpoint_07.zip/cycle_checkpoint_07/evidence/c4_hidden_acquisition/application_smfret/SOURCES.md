# Primary-source notes: force-perturbed smFRET

## Hohng et al. (closest full match)

S. Hohng et al., “Fluorescence-force spectroscopy maps two-dimensional reaction landscape of the Holliday junction,” *Science* 318 (2007), 279–283. DOI: [10.1126/science.1146113](https://doi.org/10.1126/science.1146113). Primary article: [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC3558530/); [Science PDF copy](https://courses.physics.illinois.edu/phys498bio/sp2010/Ha_Science_2007.pdf). Supporting-method excerpts were also available at [full-text PDF mirror](https://www.researchgate.net/publication/5913508_Fluorescence-Force_Spectroscopy_Maps_Two-Dimensional_Reaction_Landscape_of_the_Holliday_Junction).

- Main article, Fig. 1 and pp. 279–280: construct/labels, force direction, force-dependent FRET histograms, and surface motion against trapped bead. Force is applied by moving the surface-tethered molecule relative to the trap; the confocal spot follows the molecule.
- Main article, Fig. 2 and pp. 280–281: five force conditions; 10-s traces with 10-ms integration; one to five cycles / 50–250 s per molecule before bleaching; low-FRET bias above 1 pN for XR; HMM-derived forward/backward rates against force.
- Main article, Table 1: mean transition-state distances and SD across five molecules. For XR: \(\Delta x_b^\ddagger=1.5\pm0.3\) nm and \(\Delta x_f^\ddagger=2.9\pm0.6\) nm. These are model-derived distances, not direct state-transition observations or confidence limits.
- Supporting Methods, “Experimental scheme and data analysis”: force-extension curves select stage displacement for a desired force; 10-s FRET acquisitions at room temperature; 5-ms resolution for BR and 10 ms for the other constructs; repeated until photobleaching; transition rates inferred by HMM.
- Supporting Methods, trap calibration paragraph: trap stiffness 0.11 pN/nm from 10-kHz bead-position power spectrum with hydrodynamic correction; force noise 0.2 pN at 2 pN and 100-Hz bandwidth; \(\lambda\)-DNA effective stiffness 0.002 pN/nm at 2 pN, hence about 0.01 pN force fluctuation for a 5-nm conformational move. This is a force-noise/elasticity estimate, not a bound on all hidden jumps during a force ramp.
- Scope limits: article reports condition-specific rate estimates and SD over a small number of molecules, but not calibrated actuator latency, force-ramp duration, a confidence envelope on blockwise jump counts, photon totals, or matched resource comparison. Force changes rates asymmetrically and changes equilibrium occupancy.

## Tarsa et al. (clean reversible-force precedent)

P. B. Tarsa et al., “Detecting Force-Induced Molecular Transitions with Fluorescence Resonant Energy Transfer,” *Angewandte Chemie International Edition* 46 (2007), 1999–2001. DOI: [10.1002/anie.200604546](https://doi.org/10.1002/anie.200604546). [PMC article](https://pmc.ncbi.nlm.nih.gov/articles/PMC3870335/); [author-hosted PDF](https://lab.vanderbilt.edu/lang-lab/wp-content/uploads/sites/195/2023/01/Tarsa_Angewandte_FRET2007.pdf).

- Experimental section: a 20-bp DNA hairpin FRET construct; trap stiffness 0.204 pN/nm; coverslip translated at 250 nm/s through repeated unfolding/refolding; bead-force and donor/acceptor channels sampled at 20 Hz. The source describes several transitions and a representative donor bleach at about 65 s.
- Fig. 2: unfolding near 18 pN; force cycled between approximately 6 and 24 pN; force-linked FRET changes distinguish open and closed structures.
- Useful for evidence that a reversible mechanical action can be performed on a single molecule while collecting repeated FRET signals. It does not fit \(Q(F)\) or give a statistical upper bound on transition probabilities.

## Passive time-tag likelihood comparator

I. V. Gopich and A. Szabo, “Decoding the Pattern of Photon Colors in Single-Molecule FRET,” *Journal of Physical Chemistry B* 113 (2009), 10965–10973. DOI: [10.1021/jp903671p](https://doi.org/10.1021/jp903671p). [Primary full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC2802060/).

- The data object is the sequence of donor/acceptor photon colors and interphoton intervals. The likelihood estimates state transition rates and FRET efficiencies without time-binning; for immobilized molecules, it uses state-specific donor/acceptor count rates and the transition generator.
- The method assumes a specified finite-state kinetic model and state-dependent Poisson photon statistics (with explicit extensions for background). The article's demonstrations are simulated trajectories, so it is the likelihood baseline, not evidence of a force-action experiment.

P. D. Harris et al., “Multi-parameter photon-by-photon hidden Markov modeling,” *Nature Communications* 13 (2022), 1000. DOI: [10.1038/s41467-022-28632-x](https://doi.org/10.1038/s41467-022-28632-x). [Primary article](https://pmc.ncbi.nlm.nih.gov/articles/PMC8863987/).

- Applies photon-by-photon HMM to ALEX smFRET streams without binning into intensity traces and demonstrates state-rate inference on DNA hairpin, maltose-binding protein, and YopO data, with dynamics ranging from sub-second to microsecond. It is a stronger real-data passive analysis comparator than binned FRET traces, while still requiring a specified hidden-state/emission model and photophysics checks.

## Resource-reading rule

The force papers report integration/sample rates, not total detected photon counts. Their fluorescence streams therefore cannot be compared numerically to a photon-by-photon passive analysis at fixed photon budget from the published summaries. A valid comparison needs raw photon time tags, force command and actual-force timestamps, matched observation windows, per-condition rate uncertainty, and all actuator/setup time. The Hohng paper gives enough information to identify a concrete action/read protocol, but not enough to claim that force intervention is statistically cheaper or more informative per photon than optimal passive likelihood fitting.
