# Hidden-state acquisition beyond endpoint aliasing

## Verdict

The strongest defensible new line is a conditional acquisition theorem: a paid, strictly positive slow-read action lets an unknown full-rank reporter be learned by repeated outputs and reduces the read-frame conditioning exponent of one fixed CTMC-pair test from κ⁻⁴ to κ⁻². The theorem does not rely on state labels, a reset, a known reporter matrix, a singular-value oracle, or a zero-time/unchanged-state freeze. Every slow block has finite read time and a measured transition/ramp budget. The action interface remains a model assumption, and no named biological fate-state system has passed it.

The best concrete physical testbed found is the NV 14N nuclear-spin fluorescence channel, which has repeatable photon reads and source-reported field/duty-dependent persistence. It lacks the theorem-required ramp-inclusive one-sided transition envelope, common invariant emission matrix, independent-founder proof interface, and matched likelihood comparison. Reversible cryo-arrest also supports repeated imaging in selected cell assays but does not validate Q→ρQ for arbitrary fate transitions. Thus the model theorem is conditional and every physical bridge remains UNKNOWN; the detailed NV gate is in [application_gate/REPORT.md](application_gate/REPORT.md). A frame-dependent state-independent later-read channel is an exact counterexample to any unconditional exponent guarantee.

I also completed a separate exact two-world minimax acquisition analysis of the existing three-daughter actionwise CLE alias. It gives a sharp finite fixed-sample result and adaptive information lower bound under direct semantic family labels. That is a different, narrower interface. Root can choose which lane better advances the synthesis.

## Primary result: paid slow-read blocks

The model and repaired proof are saved under [slow_readout/](slow_readout/REPORT.md). A hostile audit caught an unnecessary K factor in the original per-block coordinatewise frequency bound and a missing optional-stopping confidence schedule. The proof now uses a dimension-free vector-norm concentration inequality and spends confidence across every prefix in a predeclared finite maximum-epoch run; it requires supplied/certified p_*>0 and an action setting safe at that maximum. For a specified pair of K-state probe kernels separated by permutation-quotiented Frobenius gap γ>0, unknown shared full-rank K×K reporter E with κ=σ_min(E)>0, and native-founder law with each state mass at least p_*, the test uses:

- O(K γ⁻² p_*⁻¹ log(K/α)) independent founders for fixed confidence;
- O(K/(p_*γ²) · κ⁻² · polylog(K/(αp_*γ))) total reporter frames;
- RΔ plus measured entry/exit ramp time per block, and all pulse, culture, reporter/actuator calibration, exposure, viability, and recovery costs.

The factor K in per-row transition estimation and the founder cap is included. The corrected dimension-free repeated-read bound removes the extraneous K from frames per block. A full-protocol union bound charges every slow block, including ramps: if the per-block ramp floor q_ramp is at least α/(4B), the finite protocol returns UNKNOWN. The actual action can still change the hidden state; no freeze is assumed. The model theorem estimates the unknown emission columns from repeated frequency clusters and then estimates the finite transition matrix up to a common relabeling.

For the explicit three-state cycle pair, the lag-1 endpoint matrices agree to 2.33×10⁻¹⁵ in the floating-point check, while the nominal 0.05 probe has permutation-orbit gap γ≈0.20900495. In the specified passive pair-law family, D(J0||J1)=O(κ⁴) and the coefficient D/κ⁴ tends to 0.0218415; fixed-error testing therefore needs Ω(κ⁻⁴) independent pairs even with nuisance parameters disclosed. This applies only to that two-read pair-law family, not all passive multi-time likelihoods. An optimal likelihood on the same active data is at least as informed as the cluster estimator, so no advantage over that active likelihood is claimed. The repaired full-protocol sufficient-bound illustration is severe: at K=3, p*=1/3, γ≈0.209, α=0.05, κ=0.1, Δ=10 ms it needs 49,064 starts per row, 589,085 blocks, and a worst-case cap of about 3.09×10^11 reads (~98 years of held-read time), before ramps (the data-dependent stop may be earlier). It also requires per-block ramp probability below 2.2×10^-8. These are conservative sufficient-bound outputs, not physical measurements or feasibility evidence.

The script [slow_readout_witness.py](slow_readout/slow_readout_witness.py) passes its finite arithmetic checks; saved JSON is [slow_readout_witness.json](slow_readout/slow_readout_witness.json). These are finite numerical checks, not interval certification or biological validation. Primary source pointers and physical action limits are in [slow_readout/SOURCES.md](slow_readout/SOURCES.md), [application_gate/SOURCES.md](application_gate/SOURCES.md), and [legal_actions/SOURCES.md](legal_actions/SOURCES.md). Standard HMM identifiability and spectral-learning results are explicit prior art; no priority claim is made for this conditional rate.

## Alternate result: adaptive minimax acquisition for the CLE pair

The separate report is [minimax_adaptivity/REPORT.md](minimax_adaptivity/REPORT.md), with [proof](minimax_adaptivity/PROOF.md) and [sources](minimax_adaptivity/SOURCES.md). On the exact two-world three-daughter pair, action A is identical in both worlds and action B gives a sufficient Bernoulli bit with probabilities 3/4 and 1/4. Thus B-only sampling is minimax among all adaptive fixed-founder policies for this specified pair. The exact minimax error first falls below 5% at nine B-founder observations (6413/131072≈0.04893); eight yield 289/4096≈0.07056. For any sequential adaptive policy with maximum error δ, each world requires expected B-founder count at least kl(1−δ,δ)/(0.5 log 3). A simple SPRT gives error 1/28 and expected 39/7≈5.571 B founders at δ=0.05.

This is an exact acquisition theorem for a specified pair and direct semantic daughter labels, not unrestricted CLE-model discovery. It is separate from the paid slow-read route and adds no biological validation. Its acquisition advantage is data-efficient in founders but relies on the prior mechanisms and labels being known; unknown reporter calibration or a larger model class changes the likelihood.

## Evidence classification

- **Conditional theorem:** unknown-emission repeated-read reconstruction and κ⁻² total-frame scaling under a calibrated positive slow action, full-rank stable E, full-support occupancy, and finite action/ramp disturbance bounds.
- **Proved for stated family:** κ⁴ passive pair-law KL / Ω(κ⁻⁴) pair count for the explicit three-state witness.
- **Exact finite theorem:** adaptive minimax fixed-pair sample risk and sequential KL lower bound for the CLE-alias acquisition interface.
- **Finite computation:** endpoint alias, probe gap, and passive KL coefficient in the saved Python run; no interval arithmetic.
- **Supported physical fact:** NV nuclear-spin photon readout can be repeated and persistence changes under field/duty controls; reversible cryo-arrest/repeated imaging also exists for selected cell assays. Neither validates the theorem interface.
- **UNKNOWN:** whether any target biology or materials assay supplies a tunable scalar slowdown, stable repeated-frame emissions, a sufficiently small ramp disturbance, independent native founders (or an effective-sample-size proof), useful p_* and γ, and favorable all-in cost. NV does not close these gates.
- **Refuted as universal claim:** later frames can be state-independent, so a paid pause alone does not ensure extra hidden-state information.
- **Novelty/priority:** UNKNOWN; no priority claim.

## Next decisive gate

For a named assay, acquire a protocol-specific held and ramp transition-kernel envelope, repeated-frame emission estimates with a lower confidence bound on column separation, a lower founder-occupancy bound, and total exposure/time/viability/recovery costs. If the ramp floor is too large, E drifts, or no positive rate setting supports the needed R, reject the application. Do not substitute cryo-arrest in a molecular-motion paper for fate-state validation.
