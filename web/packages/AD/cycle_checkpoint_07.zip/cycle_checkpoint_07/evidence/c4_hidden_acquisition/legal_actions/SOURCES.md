# Sources and evidence notes: physical actions, repeated reads, and conditioning

This audit focuses on whether the proposed operation is an action with a physically implementable interface, what existing results already cover repeated hidden-state observations, and which cost/disturbance claims remain unsupported. Web sources below are primary research papers or their author protocols. The cited literature does not validate a freeze action for an unspecified cell-fate variable.

## Reversible cryo-arrest: closest physical acquisition prior art

**Masip et al. (2016), “Reversible cryo-arrest for imaging molecules in living cells at high spatial resolution,” Nature Methods 13, 665–672.** [Primary article, PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC5038880/); [Nature publisher page](https://www.nature.com/articles/nmeth.3921); DOI [10.1038/nmeth.3921](https://doi.org/10.1038/nmeth.3921).

- Exact pointers in the article: “Development and validation of reversible cryo-arrest,” Fig. 1 (temperature/DMSO trajectory and thermometry), Fig. 2 (diffusion/immobility evidence), Fig. 3 (three consecutive cycles/survival), Fig. 4 (EGF/ERK and stress response), and the Discussion paragraphs on protocol scope and cooling time.
- The cycle starts at 37°C, cools to 4°C while exchanging medium with staged DMSO, then goes stepwise to −45°C while increasing DMSO, and reverses the protocol to warm. The paper reports 35–50°C/min cooling, 75–130°C/min warming, and 1°C chamber control with thermocouple measurement. Its tested setup takes about 10 minutes to cool from 37°C to −45°C; 4°C is reached after about 50 seconds. The authors state that biochemistry is already greatly reduced at 4°C and interpret the −45°C state as corresponding to roughly one minute after cooling began.
- Repeated acquisition is concrete: the paper describes three consecutive cryo-arrests, an example with 36 FLIM frames in 37 minutes, and PALM acquisitions with 1,000 100-ms frames. Five tested adherent cell lines had survival above 80% after three cycles. EGF-induced signaling was preserved in the tested system; the authors caution that functionality must be verified for each application.
- Crucial boundary: this evidence concerns membrane/receptor diffusion and selected RTK signaling. It establishes neither a uniform factor multiplying every hidden fate-transition rate nor a confidence bound on residual fate-state transitions during cryo, ramps, and warming. The protocol also changes temperature, DMSO, and optical emissions, so its held-condition observation matrix is a new nuisance object.

**Huebinger et al. (2017), “Reversible Cryo-arrests of Living Cells to Pause Molecular Movements for High-resolution Imaging,” Bio-protocol 7(8):e2236.** [Primary protocol, PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC5450929/); DOI [10.21769/BioProtoc.2236](https://doi.org/10.21769/BioProtoc.2236).

- Exact pointers: Abstract (consecutive cycles to track molecular-pattern evolution in individual cells); Background (acquisition takes minutes, motivating immobilization); Protocol section “Reversible cryo-arrest” and its equipment list (cryo-stage, low-pressure pump, thermocouple, DMSO/temperature steps); Discussion (cell-line/application-specific validation, including morphology, viability, stress response, and assay measurements with and without cryo-arrest).
- The protocol is explicitly not “pause without assay”: it requires temperature and medium exchanges and advises additional tests for a new lab or cellular system.

## Read disturbance and emission calibration

**Kiepas et al. (2020), “Optimizing live-cell fluorescence imaging conditions to minimize phototoxicity,” Journal of Cell Science 133(4):jcs242834.** [Primary article](https://journals.biologists.com/jcs/article/133/4/jcs242834/224018/Optimizing-live-cell-fluorescence-imaging); DOI [10.1242/jcs.242834](https://doi.org/10.1242/jcs.242834).

- Exact pointers: Abstract and Introduction (illumination overhead causes phototoxicity and photobleaching); Results “IO is a widespread problem in fluorescence imaging”; workflow in Fig. 7 (measure exposure limits, reduce excitation, assess cell health). The study supports charging illumination timing and dose and checking cell health. It does not set a universal disturbance probability for another reporter/cell type.
- Relation to cryo: Masip et al. report increased photon economy at low temperature, but that does not establish zero read disturbance. The measured held-state reporter matrix and any frame dependence still need calibration under the actual temperature, DMSO, and illumination sequence.

## HMM identifiability and conditioning: closest mathematical prior art

**Gassiat, Cleynen & Robin (2016), “Inference in finite state space non parametric Hidden Markov Models and applications,” Statistics and Computing 26, 61–71.** [Author preprint PDF](https://arxiv.org/pdf/1306.4657); DOI [10.1007/s11222-014-9523-8](https://doi.org/10.1007/s11222-014-9523-8).

- Theorem 2.1, pp. 2–3 of the preprint: a stationary finite-state HMM with known hidden-state count is identifiable up to label permutation from three consecutive observations if the hidden transition matrix has full rank and the emission distributions are linearly independent.
- Relevance: this is the closest clean precedent for learning unknown emissions from a short repeated observation word. It is an identifiability result, not a quantitative finite-sample theorem, not a controlled freeze result, and not a guarantee for a possibly changing per-frame emission matrix.

**Allman, Matias & Rhodes (2009), “Identifiability of parameters in latent structure models with many observed variables,” Annals of Statistics 37(6A), 3099–3132.** [Author PDF](https://jarhodesuaf.github.io/papers/Latent.pdf); DOI [10.1214/09-AOS689](https://doi.org/10.1214/09-AOS689).

- Corollary 3, pp. 17–18: a three-view latent-class model is generically identifiable up to labels when the three view-factor Kruskal ranks satisfy ∑_l min(r,κ_l) ≥ 2r+2.
- Theorem 6, pp. 22–23: an (r)-state HMM is generically identifiable from (2k+1) consecutive observations when \(\binom{k+\kappa-1}{\kappa-1}\ge r\), with κ denoting observable alphabet size in that theorem. Do not confuse that alphabet symbol with this audit's reporter singular value.
- Relevance: supports the C3 report's three-view tensor construction. It does not establish the sample exponent of the repeated-read protocol; the Kruskal conditions are qualitative and generic.

**Hsu, Kakade & Zhang (2012), “A Spectral Algorithm for Learning Hidden Markov Models,” Journal of Computer and System Sciences 78(5), 1460–1480.** [Author preprint PDF](https://arxiv.org/pdf/0811.4413); DOI [10.1016/j.jcss.2011.12.025](https://doi.org/10.1016/j.jcss.2011.12.025).

- Theorem 6, p. 10 of the preprint (PDF page 10; theorem begins on page 9): finite-sample joint-word accuracy under HMM conditions has polynomial dependence on inverse singular values of the emission matrix and the joint observation/state matrix, including \(\sigma_m(O)^{-2}\) and \(\sigma_m(P_{2,1})^{-4}\) factors. It is closest prior art for quantitative conditioning in finite-state HMM learning.
- Boundary: the theorem concerns spectral estimation of a conventional HMM and word-probability prediction. It does not contain a physical slow/freeze action, repeated emissions from a deliberately held state, or the κ⁻⁴-to-κ⁻² resource conversion considered here.

**Liu & Bitmead (2010), “Observability and Reconstructibility of Hidden Markov Models: Implications for Control and Network Congestion Control,” IEEE CDC 2010, 918–923.** [DOI](https://doi.org/10.1109/CDC.2010.5717730).

- Relevance: direct control/observability precedent for hidden Markov models with external inputs. Cite as adjacent controlled-HMM prior art; this audit did not use it as a premise for a cryo or sample-complexity claim.

## What the local Cycle2/Cycle3/molecular artifacts state

- [`CYCLE2_REPORT.md`](../../cell_control/cell_observation_design/CYCLE2_REPORT.md), “Interface and observation contract” and “Sampling, noise, precision, and cost”: pure starts, independent wells, reporter calibration, and a known confusion matrix; a rank-deficient or unknown reporter leaves aliases. No freeze/slowdown action is specified.
- [`cycle3_hidden_word.py`](../../cell_control/cell_observation_design/cycle3_hidden_word.py), lines 20–23 and 73–163: the pair law is (J=E\operatorname{diag}(\pi)P^\top E^\top); with its two-cycle witness, the hidden skew is damped by two emissions, giving the κ² signal and κ⁻⁴ sufficient pair count; lines 110–163 include the rank-one all-word no-go.
- [`CYCLE3_REPORT.md`](../../cell_control/cell_observation_design/CYCLE3_REPORT.md), “Three-read controlled word” and “Finite-noise rule”: the three-view HMM realization is a standard result; the independent unit is a lineage; cost explicitly includes three reads/two action intervals and calibration. Its uniform count is `UNKNOWN` until compact nuisance sets have a certified profiled γ>0. The read word follows hidden transitions; it is not a held-state repeat block.
- [`cell_metastability/CYCLE3_REPORT.md`](../../cell_control/cell_metastability/CYCLE3_REPORT.md), “Exact finite-state interface,” “Actuation and reporter uncertainty debit,” and the high-switching abstention: action durations and noisy endpoint reads are charged; κ denotes the hidden phase rate in that lane. No cryo action is represented.
- [`molecular_cadence_theorem/FINAL_REPORT.md`](../../molecular_cadence_theorem/FINAL_REPORT.md) and [`PROOF.md`](../../molecular_cadence_theorem/PROOF.md), §§1 and 7: exact cumulative counts are observed at distinct process times; rate/volume/time are known in the main theorem, with a narrow model for common mean-zero endpoint read error. Read latency and assay costs remain external. Those are process-time samples, not same-state repeated reads.
- Molecular cadence prior art in the local source notes: Duval & Hoffmann (2011), Theorems 2.2, 2.4, 2.5, [DOI](https://doi.org/10.1214/11-EJS660); Duval (2014), [DOI](https://doi.org/10.1214/14-EJS885). This literature establishes broad sampling-scale information loss for compound-Poisson processes, not a freeze/read action.

## Audit boundary

The only quantitative physical statements in this file are those reported in the cited cell-imaging papers. The κ-conditioning lower bound is derived for the explicit finite-alphabet stationary pair in `cycle3_hidden_word.py`'s interface. The κ⁻² repeated-frame scaling is conditional on stable-state and common-emission assumptions; it is not credited as a biological result from the cryo papers. No current citation demonstrates a per-cell-fate transition-rate bound, a uniform scalar cooling factor on all hidden transitions, or a cost-calibrated in-cell measurement protocol for the proposed target.
