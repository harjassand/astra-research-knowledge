# Legal physical slowdown and repeated-read audit

**Verdict.** A paid, finite-duration reversible pause followed by repeated imaging is a real physical acquisition action in a limited live-cell microscopy setting. The best match is reversible cryo-arrest: cells are cooled with staged cryoprotectant, imaged while arrested, and warmed again. This supports an action with measured duration and protocol-specific perturbation; it does not support treating a fate-state CTMC as exactly frozen or uniformly slowed. The Cycle2/Cycle3 artifacts do not include such an action. A κ⁻⁴-to-κ⁻² improvement is therefore **conditional at the model level and UNKNOWN for a biological implementation**. As an unconditional guarantee over legal observation/action interfaces, it is false: a repeated-read channel can add no state information, leaving the κ⁻⁴ lineage requirement intact.

Here κ means the reporter conditioning parameter σ_min(E), as in `cycle3_hidden_word.py`. It is not the hidden-phase transition rate called κ in the cell-metastability report, or the susceptibility kernel in that report's action-timing notes.

## What a legal physical action must specify

The action must be a protocol, not a free instruction to “freeze.” At minimum write it as a commanded temperature/medium trajectory, including cryoprotectant concentrations, ramp and dwell times, imaging exposure and read times, and warm/recovery steps. Its model interface needs (i) a transition kernel during cooling, hold, and warming, (ii) the observation channel during the exact held condition and frame sequence, (iii) a bound or confidence region for state changes caused by the ramps, hold, and reads, and (iv) elapsed-time, culture, stage, reagent, calibration, and readout costs. Each independent founder/well remains the biological sampling unit; multiple images of one founder are repeated observations, not multiple lineages.

Primary physical evidence establishes feasibility in scope. Masip et al. cool cells from 37°C to −45°C with staged DMSO, reverse the protocol to warm, and image molecular patterns during repeated arrests. The authors report three consecutive cycles and survival above 80% in each of five tested cell lines. Huebinger et al. publish a microscope protocol for consecutive reversible cycles. The Masip paper reports 36 FLIM frames over 37 minutes for one image stack and 1,000-frame PALM acquisitions, so repeated reads under a held sample are not hypothetical. These results concern particular molecular-motion, receptor, and signaling readouts, not the transition hazard of an arbitrary cell-fate label. See [Masip et al. (2016)](https://pmc.ncbi.nlm.nih.gov/articles/PMC5038880/) and [Huebinger et al. (2017)](https://pmc.ncbi.nlm.nih.gov/articles/PMC5450929/).

The protocol has non-negligible timing and disturbance. In the tested setup, cooling from 37°C to −45°C takes about 10 minutes; 4°C is reached at about 50 seconds, when biochemical reactions are already greatly reduced, and the authors interpret the imaged state at −45°C as representing roughly one minute after cooling began. Medium/DMSO exchanges are part of the action. The same paper reports preserved morphology and selected EGF/ERK responses under its tested conditions, but explicitly says functionality must be verified case by case. This is evidence for a controlled, perturbing protocol with application-specific checks, not a zero-disturbance pause theorem.

The reporter must also be calibrated in the action's actual optical and chemical condition. Cryo-arrest changes temperature and DMSO and changes fluorophore photophysics; the protocol notes improved photon yield before bleaching and lower cytotoxic-radical production at low temperature. That helps repeated imaging but also means a physiological-temperature emission matrix cannot simply be reused. Live fluorescence reads have their own cumulative effects: Kiepas et al. show that illumination overhead contributes to both photobleaching and phototoxicity and recommend measuring exposure/dose and checking cell health. Thus the relevant matrix is (E_F), conditional on the exact cryo/hold/frame protocol, and its minimum singular value must be acquired or certified. See [Kiepas et al. (2020)](https://journals.biologists.com/jcs/article/133/4/jcs242834/224018/Optimizing-live-cell-fluorescence-imaging).

## Why the existing κ⁻⁴ count appears

For the two-read stationary cycle witness, let

\[
E_\kappa=\kappa I+(1-\kappa)\mathbf 1\mathbf 1^\top/K,
\qquad 0<\kappa\le1.
\]

This is column-stochastic with singular values (1,\kappa,\ldots,\kappa). Use two doubly stochastic hidden transition matrices (P_+,P_-) with the same uniform stationary law and nonzero difference (D=P_+^\top-P_-^\top). Their observed pair matrices are

\[
J_\pm=E_\kappa (I/K)P_\pm^\top E_\kappa^\top,
\quad
J_+-J_-=\frac{\kappa^2}{K}D.
\]

The equality follows because (D\mathbf1=\mathbf1^\top D=0), so both emission factors act as κ on the nonconstant subspace. As κ→0, both pair laws converge entrywise to the same strictly positive law with every cell (1/K^2). For small enough κ, all denominator cells are at least (1/(2K^2)); hence

\[
D_{\rm KL}(J_+\Vert J_-)≤\chi^2(J_+,J_-)≤ C\kappa^4
\]

for a fixed finite (C), since the finite alphabet pair-law difference is (O(\kappa^2)). For (n) independent two-read lineages, KL adds to at most (nC\kappa^4); Pinsker and the two-point testing bound imply (n=\Omega(\kappa^{-4})) to keep both testing errors bounded away from (1/2). This is a lower bound for this fixed pair-law interface, even if its nuisance parameters are disclosed. It is not a lower bound for every adaptive action or repeated-read design.

The executable [pair-law witness](../../cell_control/cell_observation_design/cycle3_hidden_word.py) uses the corresponding κ² observed-skew lower bound and a finite-alphabet concentration bound, yielding a sufficient (O(\kappa^{-4})) lineage count for that word. Its rank-one-emission check is an exact no-go. The later [C3 observation report](../../cell_control/cell_observation_design/CYCLE3_REPORT.md) uses a three-read, two-action word with unknown (E), but makes the composite-nuisance sample count `UNKNOWN` until the profiled word-law margin γ is certified. None of those artifacts contains a freeze action.

## Conditional improvement and its unit of accounting

If the actual held-state action keeps the relevant latent label fixed through the whole read block, the emissions are conditionally independent with one shared full-rank (E_F), and the calibration/labeling procedure has a certified error bound, then averaging (R) frames separates reporter columns at scale κ per frame. Standard bounded categorical concentration gives classification error falling exponentially in (R\kappa^2); therefore (R=O(\kappa^{-2}\log(1/\eta))) frames per endpoint suffice for fixed label error η. For a fixed positive hidden transition-law gap (g), the number of independent lineages can then be (O(g^{-2}\log(1/\delta))), while the repeated-read resource is (O(\kappa^{-2})) per endpoint. This is a read-cost conditioning improvement; it does **not** mean the independent-lineage count itself scales as κ⁻². The stronger unknown-(E_F), positive-slow-action construction requires its own emission-identification and residual-jump proof, which requires a separate emission-identification and residual-jump proof.

For a real action the held interval has finite duration. If its measured hidden-state exit-rate bound is Λ_F, the probability of at least one hidden transition during dwell (t_F) is at most (1-e^{-\Lambda_Ft_F}\le\Lambda_Ft_F). Ramp effects and per-frame disturbance must be debited too. A valid guarantee needs their total probability/TV effect smaller than the separation left after decoding, and needs the same calibrated (E_F) throughout the block (or a separately profiled (E_{F,r}) for each frame). If (t_F) grows with (R), a fixed positive residual state-change rate or fixed per-frame disturbance eventually consumes the gap as κ→0. Cryo-arrest literature does not bound these quantities for the target fate labels or show a uniformly tunable rate multiplier approaching zero.

The right cost ledger is at least

\[
C=n\{c_{\rm lineage}+c_{\rm ramps}+c_{\rm dwell}(t_F)+2R c_{\rm read}\}
+c_{\rm reporter/hold\ calibration}+c_{\rm actuator\ calibration},
\]

with failed/bleached tracks, DMSO/media, and recovery included in the local unit costs. Current papers provide protocol detail, not transferable prices or transition bounds.

## No unconditional exponent improvement: explicit counterexample

Allow the read channel to depend on frame number during a finite freeze/read action. Let the first frame emit through (E_\kappa), and let every later frame have a state-independent emission vector (v), i.e. (E_{F,r}=v\mathbf1^\top) for (r\ge2). The hidden state can remain perfectly fixed and the action can be finite and paid, but all later frames are independent of its label. In a pre/post block protocol, retain only the first informative frame of each block; all other frames factor out of the likelihood. The per-lineage information remains that of the original two-read pair, (D_{\rm KL}=O(\kappa^4)), so Ω(κ⁻⁴) lineages are still required. This is a lawful counterexample whenever frame-stationary emissions are not assumed or calibrated. It is physically motivated by bleaching/temperature-dependent photophysics, but is not a claim that Masip's particular cryo system becomes rank one.

Even with a constant emission matrix across frames, the current exact rank-one case (E= v\mathbf1^\top) destroys all hidden-state information under every word. It is the κ=0 boundary, already implemented in `cycle3_hidden_word.py`. For positive κ, a fixed-E, held-state repeated-read guarantee is possible; the point is that the action's mere existence does not supply those assumptions.

## What the three local lanes establish

- [Cycle2 observation design](../../cell_control/cell_observation_design/CYCLE2_REPORT.md) charges for reporter calibration and says a known invertible confusion matrix can be corrected; an unknown or rank-deficient reporter leaves aliases. It treats endpoint counts/fractions and action costs but has no physical pause.
- [Cycle3 observation design](../../cell_control/cell_observation_design/CYCLE3_REPORT.md) establishes an exact controlled HMM realization result for a three-read word and charges lineage, read, action, state-calibration, and dose-calibration costs. It explicitly returns `UNKNOWN` without a certified profiled margin over unknown emissions and other nuisances. Its readouts occur along hidden transitions; they are not repeated draws from a held state.
- [Cycle3 cell metastability](../../cell_control/cell_metastability/CYCLE3_REPORT.md) uses a two-pulse AB/BA model, binary endpoint emissions, and explicit pulse/reporter tolerance debits. The rate called κ there is the hidden-phase switching rate. It includes no freeze action and makes no biological validation claim.
- [Molecular cadence](../../molecular_cadence_theorem/FINAL_REPORT.md) assumes exact cumulative-count reads at distinct times of an ongoing compound-Poisson process. Its independent increments come from process evolution, not repeated reads of one held latent state. Detector/read latency is a cost outside that idealized experiment; it provides no freeze/re-read theorem.

## Scoped disposition

| Claim | Status | Scope |
|---|---|---|
| A paid finite pause plus repeated imaging is physically real | **SUPPORTED** | Reversible cryo-arrest in the tested imaging systems; not yet for a target fate-state model |
| Cryo-arrest equals a pure action (Q\mapsto\rho Q) with known ρ and zero ramp/read disturbance | **UNKNOWN** | No cited source provides this uniform rate law or a fate-state error bound |
| Fixed two-read pair-law signal has κ² amplitude and κ⁻⁴ lineages | **PROVED for the stated family** | Uniform stationary cycle pair, finite alphabet, fixed one-pair design |
| Repeated same-state frames can reduce read resources to κ⁻² | **CONDITIONAL** | Shared full-rank (E_F), repeatable emissions, stable hidden label, calibrated/proved unknown-(E_F) handling, charged action duration/disturbance |
| The physical cryo action yields that exponent for the actual biology | **UNKNOWN** | Requires protocol-specific (Q_F(t)), ramp/read perturbation, (E_F), and cost data |
| Every legal freeze/re-read action improves κ⁻⁴ to κ⁻² | **REFUTED** | Frame-dependent state-independent emissions make later reads uninformative |

The strongest accurate conclusion is: **one can write and charge a genuine slowdown/read action, and ideal held-state repeated measurements have better conditioning in total reads; present physical sources do not validate the assumptions needed to substitute cryo-arrest into Cycle2/Cycle3.** Keep the action-model theorem separate from any claim about the cell's actual fate-state mechanism.
