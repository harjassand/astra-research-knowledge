# Primary sources: NV repeated nuclear-spin fluorescence and controlled persistence

All claims below are limited to the named device and protocols.

1. Philipp Neumann et al., “Single-Shot Readout of a Single Nuclear Spin,” *Science* 329 (2010), 542–544. [DOI](https://doi.org/10.1126/science.1189075); [author-hosted PDF](https://www3.physik.uni-stuttgart.de/TR21/common/show_file.php/publications/567/publication.pdf).
   - PDF pp. 1–2 / web-extracted lines 53–92: repeated nuclear-readout mechanism; electron mapped and optically read, nuclear population almost undisturbed, 92±2% fidelity.
   - Web-extracted lines 123–129: one trace point is 5 ms / 2,000 repetitions.
   - Lines 203–234, 333–344: excited-state hyperfine flip-flops, suppression with axial-field detuning, field-dependent lifetime plot and a transition matrix from ~10,000 quantum jumps.
   - The source does not give a ramp-inclusive one-sided state-change bound or matched resource likelihood study.

2. Matthias Pfender et al., “Nonvolatile nuclear spin memory enables sensor-unlimited nanoscale spectroscopy of small spin clusters,” *Nature Communications* 8, 834 (2017). [DOI](https://doi.org/10.1038/s41467-017-00964-z); [primary full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC5635067/).
   - Article reports lifetime during continuous single-shot readout, approximately quadratic field dependence reaching ~1 s at 3 T, and dependence on microwave/wait/laser timing.
   - It separates the long dark lifetime from the lifetime during readout. No equal-walltime/equal-photon passive likelihood or magnet ramp budget is reported.

3. Jun-Xiang Zhang et al., “Observation of metastability in open quantum dynamics of a solid-state system,” *Nature Communications* 16, 9818 (2025). [DOI](https://doi.org/10.1038/s41467-025-64772-6); [publisher full text](https://www.nature.com/articles/s41467-025-64772-6); [publisher PDF](https://www.nature.com/articles/s41467-025-64772-6.pdf).
   - Article lines 73–85: repeated Ramsey-interferometry measurements on a 14N nuclear spin induce discrete-time open dynamics; state is metastably polarized before relaxing toward maximal mixture.
   - Lines 121–178: the RIM induces a quantum channel; one 220 ns optical read pulse per RIM; 0.05 detected photons/RIM; 80k repetitions/1.695 s gives 97±2% readout; changing pulse duration and waits changes measured T1 up to 15±3.5 s.
   - Lines 193–196: field, tilt and RIM interval are protocol variables, and each RIM includes optical readout; the emitted channel depends on operating condition.
   - Lines 278–282 in publisher PDF: initial 14N state is thermal/evenly distributed over mI=0,±1; no nuclear-state initialization is used before the reported sequence.
   - The 97% readout point and 15 s maximum T1 are distinct; the latter is not a confidence envelope for the former.

4. F. Gopich and A. Szabo, “Decoding the Pattern of Photon Colors in Single-Molecule FRET,” *J. Phys. Chem. B* 113 (2009), 10965–10973. [DOI](https://doi.org/10.1021/jp903671p); [primary full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC2802060/).
   - Used only as prior art for likelihood methods on photon-resolved hidden dynamics; it is not an NV source and does not support an action advantage here.

## Evidence boundary

Repeated spin-dependent photon acquisition, field/duty-dependent persistence, state-specific readout statistics, and a finite tested RIM schedule are experimentally established for their respective NV settings. A shared emission matrix across actions, protocol-wide ramp-inclusive transition confidence bound, independent-founder assumptions, matched likelihood advantage, and mapping to the scalar-CTMC action theorem are not established by these sources.
