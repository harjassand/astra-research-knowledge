# Robust hidden-transition estimation with unknown emissions

## Result and scope

A finite-sample estimator recovers a controlled hidden-state transition matrix with unknown emissions, unknown hidden starts, no state labels, and adversarial block replacement. Three repeated pre-transition reads identify the reporter and start law as an unlabeled product-mixture tensor. One paired pre/post table then identifies the transition matrix. Corruptions may be selected using the hidden start or transition endpoint; the proof bounds the entire joint table and never assumes post corruption is missing-at-random.

This estimates one finite-state transition kernel for a stated action. It does not distinguish generators that induce identical transition matrices under every legal control word. Applying the result to CLE-equal mechanisms first requires a positive gap between their controlled transition-matrix orbits. Estimating a sampled transition matrix does not solve the separate Markov-embedding problem.

The bound displays dependence on the hidden-start floor \(p_*\), reporter singular-value floor \(\gamma\), state count \(K\), failure probability \(\alpha\), and corruption fraction \(\varepsilon\). The lower bound gives the exact overlap threshold for whole paired-record contamination and an exact endpoint-sensitive post-read witness. No physical control, read invariance, corruption fraction, or calibration certificate is asserted for a biological system.

## Legal observation contract

Fix \(K\ge2\) hidden states and \(K\) categorical read symbols. An independent episode starts at an unobserved \(X\sim\pi\), with \(\pi_i\ge p_*>0\). Before acting, take one pre-read block \(U=(U_1,U_2,U_3)\): three conditionally independent emissions from the same unchanged hidden state. Apply the selected control once, with row-stochastic transition matrix \(P\), then take one post-read \(V\). Every clean read uses the same unknown column-stochastic matrix \(E\), with \(\sigma_{\min}(E)\ge\gamma>0\). An entire episode, not an individual read, is an independent unit.

The pre block must be a same-state three-read block. Any state change, reporter failure, or other behavior that invalidates this model is charged to the corruption budget. Post corruption may depend on the realized endpoint \(X'\), the start \(X\), the pre-read values, and the whole experiment. No hidden labels, known \(E\), known \(\pi\), pure-state starts, or free conditional samples are supplied.

Two corruption conventions are useful:

- **Paired-record convention:** at most \(\varepsilon_{\rm pair}n\) of the \(n\) whole records \((U,V)\) are replaced arbitrarily. This is the main theorem's budget.
- **Separate-block convention:** at most \(\varepsilon n\) pre blocks and at most \(\varepsilon n\) post blocks are replaced, separately. At most \(2\varepsilon n\) paired records are touched, so use \(\varepsilon_{\rm pair}=2\varepsilon\) (capped at 1). If each of the three pre reads is separately budgeted, use \(\varepsilon_{\rm pair}\le4\varepsilon\).

These are deterministic fraction bounds, not independent Bernoulli-contamination assumptions. Corruptions can be selected after seeing hidden states and endpoints. The calibrated fraction is an input, not something inferred from the transition data for free.

## Estimator and finite-sample bound

Let \(G\) be the clean pre-triple distribution and \(J\) the clean \(K\times K\) table for \((U_1,V)\). They satisfy
\[
G_{abc}=\sum_{i=1}^K\pi_i E_{ai}E_{bi}E_{ci},
\qquad
J=E\operatorname{diag}(\pi)P E^T.
\]

The estimator forms the empirical pre-triple tensor and empirical \((U_1,V)\) table. It symmetrizes the triple tensor, computes its pair marginal \(M=E\operatorname{diag}(\pi)E^T\), whitens the tensor, and applies robust orthogonal tensor decomposition. The population whitened tensor is
\[
M^{-1/2}\times_1 M^{-1/2}\times_2 M^{-1/2}\times_3 G
=\sum_{i=1}^K\pi_i^{-1/2}u_i^{\otimes3},\qquad
u_i=\sqrt{\pi_i}M^{-1/2}E_{\cdot i},\qquad u_i^Tu_j=\mathbf1\{i=j\}.
\]
Its orthogonal factors and positive weights recover \(E,\pi\) up to one common permutation. Then use
\[
\widehat P=\operatorname{diag}(\widehat\pi)^{-1}\widehat E^{-1}\widehat J\widehat E^{-T}.
\]
Align the estimated states in that same permutation and project onto row-stochastic matrices; projection cannot increase Frobenius error to the true \(P\).

Define
\[
u_n=\sqrt{\frac{2}{n}\log\frac{3(2^{K^3}-2)}{\alpha}},\qquad
z_n=2\varepsilon_{\rm pair}+u_n,\qquad
\lambda_*=p_*\gamma^2.
\]
With probability at least \(1-2\alpha/3\), the clean empirical pre tensor and pair table are each within \(u_n\) in \(L^1\) of their population values. This is the finite-alphabet \(L^1\) inequality of Weissman et al. Replacing at most \(\varepsilon_{\rm pair}n\) whole records changes either empirical table by at most \(2\varepsilon_{\rm pair}\) in \(L^1\). Thus both total errors are at most \(z_n\), irrespective of dependence between corruption and \(X,X'\).

The robust tensor-power perturbation theorem supplies universal constants \(c,C>0\). Choose its finite restart/iteration schedule so that its own failure probability is at most \(\alpha/3\). Define
\[
\xi_n=Cz_n\lambda_*^{-5/2},\qquad
C_E=C\left[\frac{\sqrt K}{p_*\gamma}
+\frac{K}{\sqrt{p_*}}\lambda_*^{-5/2}\right],\qquad
C_\pi=CK\lambda_*^{-5/2},
\]
where \(C\) may be enlarged by universal factors. If
\[
z_n\le\lambda_*/2,\quad \xi_n\le c/K,\quad 80K\xi_n\le1/2,\quad
C_Ez_n\le\gamma/2,\quad C_\pi z_n\le p_*/2,
\tag{1}
\]
then, with probability at least \(1-\alpha\),
\[
\min_{\Pi\in\mathfrak S_K}\|\widehat P-\Pi^TP\Pi\|_F
\le \frac{8z_n}{p_*\gamma^2}
+\frac{12C_Ez_n}{p_*\gamma^3}
+\frac{2C_\pi z_n}{p_*^2\gamma^2}.
\tag{2}
\]
The final two conditions in (1) keep the fitted reporter invertible and the fitted start law bounded away from zero. Constants \(c,C\) come from standard whitening and robust orthogonal-tensor perturbation results; the displayed dependence on \(p_*,\gamma,K\) is not hidden in an unspecified HMM profile margin.

The source-row error obeys
\[
\min_{\Pi\in\mathfrak S_K}\max_i\|\widehat P_{i\cdot}-(\Pi^TP\Pi)_{i\cdot}\|_1
\le\sqrt K\min_{\Pi\in\mathfrak S_K}\|\widehat P-\Pi^TP\Pi\|_F.
\tag{3}
\]
For target Frobenius error \(r\), put
\[
A=\frac8{p_*\gamma^2}+\frac{12C_E}{p_*\gamma^3}
+\frac{2C_\pi}{p_*^2\gamma^2}.
\]
Let \(z_0>0\) satisfy all conditions in (1) with \(z_n\) replaced by \(z_0\), and set
\[
u_*=\min\{z_0-2\varepsilon_{\rm pair},\ r/A-2\varepsilon_{\rm pair}\}.
\]
If \(u_*>0\), the sufficient sample size is
\[
n\ge\frac{2}{u_*^2}\log\frac{3(2^{K^3}-2)}{\alpha}.
\tag{4}
\]
For max-source-row \(L^1\) accuracy \(r_{\rm row}\), substitute \(r=r_{\rm row}/\sqrt K\). At fixed \(K,p_*,\gamma\), the confidence factor is logarithmic in \(2^{K^3}/\alpha\). Contamination creates a nonzero error floor: if (2) at \(u_n=0\) exceeds the target, increasing \(n\) cannot fix it.

For a finite candidate set with minimum permutation-orbit Frobenius gap \(\Delta_P>0\), any \(r<\Delta_P/2\) lets the nearest-orbit rule identify the candidate. The estimator also applies action by action. A shared pre-read cohort can calibrate \(E,\pi\) for several actions, but each action needs its own post table and finite-sample budget.

## Minimax threshold and exact endpoint-sensitive witness

Under arbitrary replacement of an \(\varepsilon_{\rm pair}\) fraction of whole paired records, the total-variation contamination neighborhoods of clean laws \(F_0,F_1\) intersect exactly when
\[
\operatorname{TV}(F_0,F_1)\le2\varepsilon_{\rm pair}.
\tag{5}
\]
When (5) holds, their midpoint is within \(\varepsilon_{\rm pair}\) of both and can be made the common observed law by randomized replacement. No estimator can then uniformly recover transition matrices separated by \(d_P\) to Frobenius error below \(d_P/2\), even with infinitely many records. A certified lower profile modulus \(\operatorname{TV}(F_\theta,F_{\theta'})\ge\lambda d_P(P_\theta,P_{\theta'})\) implies that pairs farther apart than \(2\varepsilon_{\rm pair}/\lambda\) have disjoint contamination neighborhoods; this is a sufficient resolution threshold, not by itself a minimax lower bound. A lower bound requires an explicit pair whose clean-law TV is small relative to its transition gap. If distinct transition orbits induce exactly the same clean law, recovery is impossible even when \(\varepsilon=0\); a zero linear modulus alone only rules out a uniform linear inverse bound.

For separate \(\varepsilon\)-budgets on pre and post blocks, \(\varepsilon\) is already an impossibility threshold whenever two models share the pre-block marginal: a midpoint can be reached by corrupting post reads alone. The safe universal upper conversion is that at most \(2\varepsilon n\) paired records are touched; using \(\varepsilon_{\rm pair}=2\varepsilon\) gives a sufficient population separation greater than \(4\varepsilon\). In this separate-budget interface the exact pairwise threshold is overlap of the read-level corruption neighborhoods; it lies between the common-pre \(2\varepsilon\) lower threshold and the \(4\varepsilon\) outer-TV sufficient threshold. I do not call \(4\varepsilon\) exact for arbitrary pairs.

The exact rational witness is checked by [check_post_contamination.py](check_post_contamination.py). Set \(K=2\), \(\pi=(1/2,1/2)\),
\[
E=\begin{pmatrix}3/4&1/4\\1/4&3/4\end{pmatrix},\quad
P_0=\begin{pmatrix}3/4&1/4\\1/4&3/4\end{pmatrix},\quad
P_1=\begin{pmatrix}5/8&3/8\\3/8&5/8\end{pmatrix}.
\]
Here \(p_*=1/2\), \(\gamma=\sigma_{\min}(E)=1/2\), and transition matrices are \(1/4\) apart after every state permutation. The pre-triple law is identical in both models. The full \((U_1,U_2,U_3,V)\) law has exact total-variation distance \(11/256\); its midpoint is reached in either world by post-only replacement at rate \(11/512\), using a kernel conditional on the observed pre triple. Such endpoint-sensitive corruption is allowed. At post-corruption budget \(\varepsilon=11/512\), every estimator has worst-case probability at least \(1/2\) of error at least \(1/8\) in Frobenius norm on this pair. This is an exact lower bound, not a concentration artifact; endpoint-independent post corruption would overstate identifiability.

## Costs, limits, and prior-work boundary

One transition estimate at confidence \(1-\alpha\) costs \(n\) independent starts and
\[
n(3c_{\rm read,pre}+c_{\rm action}+c_{\rm read,post}+c_{\rm founder}),
\]
plus reset, elapsed read-block time, calibration, censoring/follow-up, and physical action/ramp verification. For multiple separately sampled actions, add their episode costs and allocate confidence across action tables. Pre-triple reads are paid observations, not free labels. If same-state pre reads and reporter invariance are not guaranteed or included in the calibrated \(\varepsilon\) fraction, the theorem does not apply.

The ingredients are established prior art: finite-state HMM/latent-class identifiability up to permutation, whitening, robust orthogonal-tensor perturbation, and finite-alphabet \(L^1\) concentration. The exact algebra here is the paired design and corruption accounting: a pre-only three-view mixture identifies unknown \(E,\pi\), then one transition pair gives \(P=\operatorname{diag}(\pi)^{-1}E^{-1}JE^{-T}\). No full-rank condition on \(P\) is needed. I make no novelty or priority claim. Primary-source notes are in [SOURCES.md](SOURCES.md), the derivation is in [PROOF.md](PROOF.md), and the counterexample is reproduced by [check_post_contamination.py](check_post_contamination.py).

If all legal action kernels coincide across candidate generators, their alias remains impossible to resolve even with zero corruption and perfectly visible states. A transition-orbit gap, an action separating the generators, or a short-lag injectivity premise is still needed. For \(P=e^{Q\tau}\), a branch condition such as \(\tau\|Q\|<\pi\) allows the principal logarithm to recover \(Q\); without it, only \(P\) is estimated.
