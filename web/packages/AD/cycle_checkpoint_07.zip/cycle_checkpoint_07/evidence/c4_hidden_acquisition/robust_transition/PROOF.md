# Proof: robust transition estimation

## Model and observable moments

There are \(K\ge2\) hidden states and \(K\) read symbols. A clean independent episode starts at \(X\sim\pi\), \(\pi_i\ge p_*\), emits three conditionally iid pre-reads \(U_1,U_2,U_3\) from the unchanged state, applies one row-stochastic transition \(P\), then emits \(V\) from the endpoint. The common unknown column-stochastic reporter \(E\) satisfies \(\sigma_{\min}(E)\ge\gamma\). Let \(e_i=E_{\cdot i}\) and \(D_\pi=\operatorname{diag}(\pi)\). The clean pre tensor, pair marginal, and transition table are
\[
G=\sum_i\pi_i e_i^{\otimes3},\qquad
M=\sum_i\pi_i e_ie_i^T=ED_\pi E^T,\qquad
J=ED_\pi P E^T.
\tag{P1}
\]
The last identity is in row-stochastic transition convention.

The main contamination model replaces at most \(\varepsilon_{\rm pair}n\) complete records. If separate pre and post blocks are each corrupted at most \(\varepsilon n\) times, at most \(2\varepsilon n\) episodes are touched. Selection and replacement may depend on all hidden states and endpoints.

## 1. The pre tensor identifies the unknown reporter and start law

For every \(v\),
\[
v^TMv=\|D_\pi^{1/2}E^Tv\|_2^2
\ge p_*\|E^Tv\|_2^2
\ge p_*\gamma^2\|v\|_2^2.
\]
Hence \(\lambda_{\min}(M)\ge\lambda_*:=p_*\gamma^2\). Define
\[
u_i=\sqrt{\pi_i}M^{-1/2}e_i.
\]
Then \(\sum_i u_iu_i^T=I\); these vectors form an orthonormal basis. Whiten all three tensor modes:
\[
S:=G(M^{-1/2},M^{-1/2},M^{-1/2})
=\sum_i\pi_i^{-1/2}u_i^{\otimes3}.
\tag{P2}
\]
This is an orthogonal rank-\(K\) decomposition with positive coefficients \(\lambda_i=\pi_i^{-1/2}\in[1,p_*^{-1/2}]\). Its factors and weights recover \(E,\pi\) up to one common permutation: \(\pi_i=\lambda_i^{-2}\) and \(e_i=M^{1/2}u_i\lambda_i\). This construction estimates the latent-class reporter from unlabeled starts; it does not require \(P\) to be full rank.

## 2. Empirical and corruption error

For a categorical law \(q\) on \(d\) symbols, Weissman et al.'s inequality is
\[
\Pr\{\|\widehat q-q\|_1>t\}\le(2^d-2)e^{-nt^2/2}.
\tag{P3}
\]
Apply it to \(G\) on \(K^3\) outcomes and the \((U_1,V)\) table \(J\) on \(K^2\) outcomes. With
\[
u_n=\sqrt{\frac2n\log\frac{3(2^{K^3}-2)}{\alpha}},
\]
each event fails with probability at most \(\alpha/3\); their union fails with probability at most \(2\alpha/3\). Replacing one episode changes either empirical categorical law by \(L^1\) at most \(2/n\). Thus, for any state/end-point-dependent selection of at most \(\varepsilon_{\rm pair}n\) records,
\[
\|\widehat G-G\|_1\le z_n,\qquad
\|\widehat J-J\|_1\le z_n,\qquad
z_n=2\varepsilon_{\rm pair}+u_n.
\tag{P4}
\]
Symmetrizing the empirical tensor cannot increase its \(L^1\) error because \(G\) is symmetric. Marginalization contracts \(L^1\), so \(\|\widehat M-M\|_2\le z_n\); also the tensor operator-norm error is at most its Frobenius and hence its \(L^1\) error.

## 3. Whitening and tensor perturbation

Assume \(z_n\le\lambda_*/2\). Then \(\lambda_{\min}(\widehat M)\ge\lambda_*/2\). Functional calculus on \([\lambda_*/2,\infty)\) gives universal constants \(c_0,C_0\) such that
\[
\|\widehat M^{-1/2}\|_2\le\sqrt{2/\lambda_*},\qquad
\|\widehat M^{-1/2}-M^{-1/2}\|_2\le C_0z_n\lambda_*^{-3/2}.
\tag{P5}
\]
Since \(G\) is a probability tensor, \(\|G\|_F\le1\). Telescope the three whitening modes in
\(\widehat S=\widehat G(\widehat M^{-1/2},\widehat M^{-1/2},\widehat M^{-1/2})\). Using (P4) and (P5),
\[
\|\widehat S-S\|_{\rm op}
\le z_n\|\widehat M^{-1/2}\|_2^3
+3\|G\|_F\max(\|M^{-1/2}\|_2,\|\widehat M^{-1/2}\|_2)^2
\|\widehat M^{-1/2}-M^{-1/2}\|_2
\le C_1z_n\lambda_*^{-5/2}.
\tag{P6}
\]
The \(\lambda_*^{-5/2}\) term is the conservative cost of perturbing the whitening matrix, not just the third empirical moment. Symmetrize \(\widehat S\) before decomposition.

The robust orthogonal tensor-power theorem of Anandkumar et al. (Theorem 5.1) applies to (P2). Its minimum component coefficient is at least 1. If
\[
\xi=C_1z_n\lambda_*^{-5/2}\le c/K,
\]
the theorem's finite restart and iteration schedule returns, with algorithmic failure probability at most \(\alpha/3\), estimates satisfying for one permutation \(\sigma\)
\[
\|\widehat u_i-u_{\sigma(i)}\|_2\le8\xi,\qquad
|\widehat\lambda_i-\pi_{\sigma(i)}^{-1/2}|\le5\xi.
\tag{P7}
\]
The restart count can be chosen polynomial in \(K\) times \(\log(K/\alpha)\); the iteration count also depends on \(\log\log(\lambda_{\max}/\xi)\), where \(\lambda_{\max}\le p_*^{-1/2}\). These are computation costs, separate from the \(n\) acquired episodes.

## 4. Reporter and initial-law error

Take \(\widetilde\pi_i=\widehat\lambda_i^{-2}\) and normalize to sum one. If \(80K\xi\le1/2\), then \(\widehat\lambda_i\ge1/2\); the derivative of \(x^{-2}\) has magnitude at most 16 on \(x\ge1/2\). From (P7),
\[
|\widetilde\pi_i-\pi_{\sigma(i)}|\le80\xi.
\]
Normalization adds at most an \(O(K)\) factor, so
\[
\|\widehat\pi-\Pi^T\pi\|_\infty\le C_\pi z_n,\qquad
C_\pi=C K\lambda_*^{-5/2}.
\tag{P8}
\]
For \(E\), form \(\widetilde e_i=\widehat M^{1/2}\widehat u_i\widehat\lambda_i\), then project each column onto the probability simplex. Since \(\|M^{1/2}\|_2\le\sqrt K\), \(\pi_i^{-1/2}\le p_*^{-1/2}\), and
\(\|\widehat M^{1/2}-M^{1/2}\|_2\le C z_n/\sqrt{\lambda_*}\), the three product differences (matrix square root, vector, scalar coefficient) yield
\[
\|\widehat E-E\Pi\|_F
\le C z_n\left[\frac{\sqrt K}{p_*\gamma}
+\frac{K}{\sqrt{p_*}}\lambda_*^{-5/2}\right]
=:C_Ez_n.
\tag{P9}
\]
Simplex projection is nonexpansive, so it does not worsen the column error. The common permutation in (P8) and (P9) is the tensor decomposition permutation.

## 5. Invert the observed transition table

If \(C_Ez_n\le\gamma/2\), then
\[
\|\widehat E^{-1}\|_2\le2/\gamma,\qquad
\|\widehat E^{-1}-(E\Pi)^{-1}\|_2\le2C_Ez_n/\gamma^2.
\]
If \(C_\pi z_n\le p_*/2\), then
\[
\|D_{\widehat\pi}^{-1}\|_2\le2/p_*,\qquad
\|D_{\widehat\pi}^{-1}-D_{\Pi^T\pi}^{-1}\|_2
\le2C_\pi z_n/p_*^2.
\tag{P10}
\]
Because \(J=ED_\pi PE^T\), the exact inverse is \(P=D_\pi^{-1}E^{-1}JE^{-T}\). Compare with the plug-in estimator.

The pair-table perturbation contributes
\[
\|D_{\widehat\pi}^{-1}\widehat E^{-1}(\widehat J-J)\widehat E^{-T}\|_F
\le \frac{2}{p_*}\frac{4}{\gamma^2}z_n
=\frac{8z_n}{p_*\gamma^2}.
\]
Changing both emission inverses contributes
\[
\frac{2}{p_*}\left[
\frac{2C_Ez_n}{\gamma^2}\frac1\gamma+
\frac1\gamma\frac{2C_Ez_n}{\gamma^2}
\right]
=\frac{12C_Ez_n}{p_*\gamma^3}.
\]
Changing the inverse start probabilities contributes
\[
\frac{2C_\pi z_n}{p_*^2}\frac1{\gamma^2}
=\frac{2C_\pi z_n}{p_*^2\gamma^2},
\]
using \(\|J\|_F\le1\). Summing gives report bound (2). For any row,
\(\|A_{i\cdot}\|_1\le\sqrt K\|A_{i\cdot}\|_2\le\sqrt K\|A\|_F\). Apply this to the common permutation minimizing the Frobenius orbit distance to obtain (3). Formula (4) follows from \(z_n=2\varepsilon_{\rm pair}+u_n\), the error coefficient \(A\), and \(u_n\le u_*\).

## 6. Minimax contamination threshold

For whole-record replacement at fraction \(\varepsilon_{\rm pair}\), the possible population laws are the total-variation balls of radius \(\varepsilon_{\rm pair}\) around each clean law. The balls intersect iff their centers have distance at most \(2\varepsilon_{\rm pair}\); their midpoint is a common attainable law. Thus (5) is exact. If two parameter orbits have distance \(d_P>0\) but their clean episode laws satisfy (5), the observation law is identical under a suitable adversary in either world. The radius-\(d_P/2\) success sets are disjoint, so at least one world has error probability at least \(1/2\) for every estimator.

With separate budgets on pre and post blocks, the replacement neighborhoods are smaller than the outer whole-record TV ball of radius \(2\varepsilon\), but they contain all whole-record replacements of rate \(\varepsilon\). Thus the exact pairwise overlap condition is interface-specific. If two clean laws have a common pre-block marginal, their midpoint is reachable with post-only corruption whenever their full-law TV distance is at most \(2\varepsilon\). The report's exact rational witness is in the checker.
