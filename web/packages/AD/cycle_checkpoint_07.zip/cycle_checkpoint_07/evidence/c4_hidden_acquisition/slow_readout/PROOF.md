# Paid slow-read blocks: a conditional κ⁻² acquisition bound

## Status and target

This is a model-level result. It shows how repeated reads during a *strictly positive*, calibrated slowdown can replace the κ⁻⁴ cost of a two-read hidden-pair statistic by a κ⁻² read-cost for a fixed, separated pair of CTMC hypotheses. It does not show that a biological intervention implements the required rate multiplier, leaves the reporter law invariant, or is worth its time/actuation cost. Those gates remain `UNKNOWN`.

The result treats κ as the smallest singular value of the unknown square reporter matrix E. It is not supplied to the acquisition algorithm. A finite maximum-epoch doubling schedule spends confidence across all inspected prefixes and uses only observed clusters, a concentration radius, and their separation; it returns UNKNOWN at the declared cap if uncertified. State names are never observed: the procedure discovers emission clusters up to a common permutation and compares transition matrices modulo that permutation. No hidden-state reset is used.

## Interface

There are K hidden states and K read categories. Under hypothesis b in {0,1}, a finite probe action has generator Q_b. A nondestructive reporter read takes a measured, strictly positive duration Δ and returns Y with

\[
\Pr(Y=y\mid X=i)=E_{yi},
\]

where E is unknown, shared across both hypotheses and both actions, column-stochastic, full rank, and constant through a read block. Conditional reads are independent given the latent path. Write \(\kappa=\sigma_{\min}(E)>0\), \(d_E=\min_{i\ne j}\|E_{\cdot i}-E_{\cdot j}\|_2\), and \(\Lambda=\max_{b,i}(-Q_{b,ii})\). Since \(\|e_i-e_j\|_2=\sqrt2\), \(d_E\ge\sqrt2\kappa\).

The additional control is a reversible slow mode S_\rho with \(Q_b^{S_\rho}=\rho Q_b\), for a calibrated \(\rho\in(0,1)\). It therefore still permits transitions. During the held interval, a slow block of R read intervals has jump probability at most $\rho\Lambda R\Delta$. Include the entry/exit ramps separately: if their calibrated total jump bound is $q_{\rm ramp}$, the entire commanded block has bound $q_R\le q_{\rm ramp}+\rho\Lambda R\Delta$.

The rate bound \(\Lambda\), read duration \(\Delta\), realized slow factor \(\rho\), and any finite switch/ramp schedule must be acquired or certified and their costs added. A ramp is part of the probe transition kernel and its measured duration is charged; it is never treated as a zero-time switch. If a physical controller only approximately scales the generator, replace \(\rho Q_b\) by the calibrated slow-mode generator and use its certified exit-rate bound. If no such bound is available, the disturbance guarantee is `UNKNOWN`.

The experiment starts independent native founder trajectories from a common unknown distribution \(\pi\); no founder's state is supplied or reset. A finite-sample cost statement assumes \(\pi_i\ge p_*>0\), or a sequential procedure that keeps sampling and returns `UNKNOWN` if it cannot populate every inferred state cluster. The input model order K and the two candidate probe generators are given for this pairwise design. General unknown-model discovery is outside this theorem.

## Lemma: repeated reads separate unknown emission columns

For a block known only to contain no state change, let \(\widehat e\) be the empirical K-category frequency vector from R reads. Write the reads as iid one-hot vectors \(Z_1,\ldots,Z_R\) with mean \(e_i=E_{\cdot i}\). Then

\[
\mathbb E\|\widehat e-e_i\|_2^2=R^{-1}(1-\|e_i\|_2^2)\le R^{-1}.
\]

The map \((Z_1,\ldots,Z_R)\mapsto\|R^{-1}\sum_rZ_r-e_i\|_2\) changes by at most \(\sqrt2/R\) when one read is replaced. McDiarmid's inequality gives, for \(\delta\in(0,1)\),

\[
\Pr\{\|\widehat e-e_i\|_2>r(R,\delta)\}\le\delta,
\qquad r(R,\delta)=\frac{1+\sqrt{\log(1/\delta)}}{\sqrt R}.
\]

For N blocks, a fixed-budget radius is \(r(R,\alpha/N)\). If \(r\le d_E/16\), same-state block means are within \(2r\), while distinct-state means are at least \(d_E-2r\ge14r\) apart. Connecting means at distance at most \(4r\) yields one component per represented state; each component average is within r of its column, and the component labels are one arbitrary common permutation. Since \(d_E\ge\sqrt2\kappa\), it suffices that

\[
R\ge C\kappa^{-2}\left(1+\log\frac N\alpha\right)
\]

for a universal constant C. This removes the extraneous dimension factor K from coordinatewise concentration.

### Unknown \(\kappa\): finite anytime-safe doubling rule

Fix a maximum epoch J and N physical blocks before acquisition, and set \(R_j=2^j\) for \(j=0,\ldots,J\). At epoch j spend

\[
\delta_j=\frac{\alpha}{4N(j+1)(j+2)},\qquad
r_j=r(R_j,\delta_j).
\]

Since \(\sum_{j=0}^J[(j+1)(j+2)]^{-1}\le1\), a union bound makes the frequency event simultaneous over blocks and all inspected epochs with failure probability at most \(\alpha/4\). The algorithm uses nested prefixes of each block, reclusters at each epoch, and stops at the first epoch with exactly K components; if none appears by J it returns `UNKNOWN`. On the simultaneous event and the calibration-occupancy event, K components certify all K emission columns. The guarantee applies whenever \(r_J\le d_E/16\), without supplying \(\kappa\) to the stopping rule.

Choose one positive slowdown setting for the run using maximum horizon \(R_J\). If the ramp bound is uniform over all permitted entry/exit timing and \(q_R\le q_{\rm ramp}+\rho\Lambda R_J\Delta\), require

\[
q_{\rm ramp}<\frac{\alpha}{4N},\qquad
0<\rho\le\min\!\left\{\frac12,
\frac{\alpha/(4N)-q_{\rm ramp}}{\Lambda R_J\Delta}\right\}.
\]

Then a union bound over N blocks makes the chance of any slow-block state change at most \(\alpha/4\), even under data-dependent stopping at an earlier epoch. The controller, finite ramp path, maximum duration, and its calibration are declared and charged in advance. If the ramp floor misses this gate or the required positive \(\rho\) is below the hardware floor, the algorithm returns `UNKNOWN`.

## Theorem: decode a controlled transition at O(κ⁻²) read cost

The observed system is generated by one unknown member b∈{0,1} of a supplied pair. The finite probe word has transition matrix P_b, including all nominal pulse and switching-ramp kernels, and the pair has label-orbit gap

$$
\gamma=\min_{S\in\mathfrak S_K}\|P_0-S^{-1}P_1S\|_F>0.
$$

Assume: (i) independent native founders have a common unknown law π with supplied/certified π_i≥p_*>0; (ii) each read has fixed positive measured duration Δ; (iii) every slow block has conditionally independent categorical reads from one unknown, shared, full-rank E when its hidden state does not change; and (iv) every block, including entry/exit ramps, has a calibrated no-change failure bound q_R. No hidden labels or resets are supplied. The finite model order K and the two candidate probe kernels are known for this fixed-pair test. A pilot for p_* is not part of this theorem; if used, it must supply simultaneous one-sided lower confidence bounds for every state frequency, charge all pilot founders and readouts, and reserve a separate failure probability. A zero lower bound means `UNKNOWN`.

Let m be the number of starts required per transition row. A vector bounded-differences bound gives, for a row estimated from m independent endpoints,

$$
\Pr\{\|\widehat p_i-p_i\|_2>m^{-1/2}+\sqrt{\log(1/\delta)/m}\}\le\delta.
$$

Thus m=C K γ⁻² log(8K/α) suffices, for a universal C, to make every row error at most γ/(8√K) with failure probability α/4. If p_* is supplied, choose

$$
N_c\ge p_*^{-1}\log(8K/\alpha),\qquad
N_t\ge p_*^{-1}\{2m+8\log(8K/\alpha)\},
$$

with constants rounded upward as needed. Since (1−p_*)^Nc≤e^{-p_*Nc}, all K calibration states are represented with failure at most α/8. Chernoff's bound and N_t p_*≥2m give at least m pre-block founders from each state with failure at most α/8. These are independent native founders; no labels are provided. Let B=N_c+2N_t be the declared maximum number of slow-read blocks.

Before the run declare a finite maximum epoch J, block count B, and one action setting for the entire run. Set R_j=2^j. At epoch j, form empirical frequencies from nested prefixes and use

$$
\delta_j=\frac{\alpha}{4B(j+1)(j+2)},\qquad
r_j=\frac{1+\sqrt{\log(1/\delta_j)}}{\sqrt{R_j}}.
$$

The lemma's confidence spending yields one simultaneous event over every inspected epoch and every block, with failure probability at most α/4. Cluster calibration-block means by connecting pairs within distance 4r_j. Stop only when the graph has exactly K connected components and their component-average centers have minimum pairwise distance greater than 6r_j. Use those centers, up to one common arbitrary permutation, to decode every pre/post endpoint; if the certificate never appears by J, return `UNKNOWN`. On the simultaneous concentration and no-jump events, all observations from one state are mutually within 2r_j, so one state cannot split across components. Exactly K separated components therefore correspond to all K true states; the 6r_j center-separation certificate makes nearest-center endpoint classification correct. The stopping rule uses no κ or singular-value oracle. The declared J is a charged maximum measurement budget, not a supplied hidden trajectory horizon.

For the stated guarantee at a given κ, choose J large enough that r_J≤d_E/16, where d_E=min_{i≠j}||E_{·i}−E_{·j}||_2≥√2κ. It suffices that

$$
2^J\ge C\kappa^{-2}\left[1+\log\frac{4B(J+1)(J+2)}{\alpha}\right]
$$

for a universal C. Although this coverage condition is written using κ, the algorithm is not given κ: for each fixed κ in the covered range it stops at a data-dependent epoch or returns `UNKNOWN` at J. The nested-prefix confidence spending handles the optional stopping.

Allocate another α/4 to any state change inside the B slow-read blocks. For a positive scalar-multiplier hold Q_b^{S_ρ}=ρQ_b, a measured bound q_R≤q_ramp+ρΛR_JΔ suffices if

$$
q_{\rm ramp}<\frac{\alpha}{4B},\qquad
0<\rho\le\min\!\left\{\tfrac12,
\frac{\alpha/(4B)-q_{\rm ramp}}{\Lambda R_J\Delta}\right\}.
$$

The ramp bound must cover the entire permitted entry/exit paths for every possible stopping epoch. The selected ρ is positive and held fixed; the hardware's positive lower-rate floor must permit it. If the ramp floor is too large, the bound is unavailable, or the control changes E, return `UNKNOWN`. The ramp and all slow-read time are paid; no unchanged-time freeze is used.

On the joint good event, calibration blocks recover the K columns of E up to one common permutation and endpoint blocks are decoded exactly. For each probe founder take one pre-block, execute the finite nominal word, and take one post-block. All action and transition ramps belong to P_b. Conditional on the starting state, the m endpoint samples in each row are independent. The row concentration bound gives Frobenius error ≤γ/8 with probability at least 1−α/4. A nearest-orbit test is then within γ/8 of the true orbit and at least 7γ/8 from the other. Combining calibration occupancy, probe occupancy, all-epoch frequency concentration, all-block no-jump, and transition-row events gives probability at least 1−α of returning the correct hypothesis with no abstention. If any resource, action, or calibration gate cannot be certified, return `UNKNOWN`.

For fixed K,p_*,γ,α and a covered κ, N_c+2N_t=O(Kγ⁻²p_*⁻¹ log(K/α)) blocks, and R_J=O(κ⁻² log(BJ/α)); hence total reporter-frame cost is

$$
O\!\left(\frac{K}{p_*\gamma^2}\,\kappa^{-2}\,\operatorname{polylog}\frac{KJ}{\alpha p_*\gamma}\right).
$$

The wall-time cost includes the actual R_jΔ and ramp duration for every block, nominal probe duration, detector and control overhead, calibration, founders, culture, exposure/phototoxicity, viability, and recovery. With bounded per-read and per-wall-time price, the read and block wall-time exponents are κ⁻²; this theorem does not bound a price that diverges as ρ decreases. A fixed positive hardware floor or q_ramp can cap the covered κ range or make the protocol infeasible.

This is a conditional, fixed-pair model theorem. It does not discover arbitrary CTMCs and does not establish that any biological or materials actuator realizes the slow generator, invariant E, or ramp bound. The near-freeze primitive q_ramp+ρΛR_JΔ<α/(4B) is a paid physical premise, not validated by the cited cryo protocols.

## A concrete alias pair and the passive two-read cost

Use the three-state directed cycle from the earlier embedding example. Let total clockwise-plus-counterclockwise rate be \(s=10\), and set

\[
Q_0=Q(5,5),\qquad Q_1=Q\!\left(5+\frac{2\pi}{\sqrt3},5-\frac{2\pi}{\sqrt3}\right).
\]

Both generators preserve the same unknown uniform stationary distribution. Their time-1 endpoint matrices coincide exactly because the complex generator eigenvalues differ by \(\pm2\pi i\) at time 1. Their Markov generators are not related by a state permutation. A nominal probe pulse of duration 0.05 has, in the saved floating-point calculation, permutation-quotiented transition-matrix gap \(\gamma=0.2090049507\). The endpoint transition matrices therefore remain distinguishable once latent endpoints can be decoded.

For a transparent reporter family take \(E_\kappa=\kappa I+(1-\kappa)\mathbf1\mathbf1^T/3\), which has \(\sigma_{\min}(E_\kappa)=\kappa\). Under stationary initialization, one passive two-read pair at pulse duration t has law

\[
J_b=\tfrac13 E_\kappa P_b(t)^T E_\kappa^T.
\]

The matrices P_b are doubly stochastic, so the exact difference is

\[
J_0-J_1=\frac{\kappa^2}{3}\left(P_0(t)-P_1(t)\right)^T.
\]

As \(\kappa\to0\), every cell of \(J_b\) tends to \(1/9\), and Taylor expansion gives

\[
D(J_0\|J_1)=\frac{\kappa^4}{2}\|P_0(t)-P_1(t)\|_F^2+o(\kappa^4).
\]

For small $\kappa$, every cell of both laws is bounded below by (say) $1/18$, so $D(J_0\|J_1)=O(\kappa^4)$. For $n$ independent pairs, KL adds; Pinsker and the two-point testing bound then imply $n=\Omega(\kappa^{-4})$ for any fixed error below $1/2$, even if E and $\pi$ are known to the test. Unknown calibration cannot improve that lower bound. The active protocol instead spends $\Theta(\kappa^{-2})$ repeated frames per decoded endpoint, plus $O(K\gamma^{-2}p_*^{-1})$ independent native founders for fixed confidence. This is only a constructive upper bound under the paid near-freeze action. An optimal likelihood using the same active reads is at least as informed as the clustering estimator, so no advantage over that equally informed active control is proved. The lower bound is only for the specified independent two-read passive pair-law; it does not rule out a better passive multi-time likelihood or other passive protocol.

## Falsifiers and limits

The model result fails if any of these conditions fails: the slow action changes state-specific emissions; the reporter bleaches or drifts within a block; reads are path-integrated over an exposure in a way not represented by conditionally independent emissions; a slow action induces unmodeled state changes; finite ramps are omitted from the pulse kernel; the initial law has unpopulated states; or the transition kernels overlap after a common state permutation. A rank-deficient reporter can make two states observationally identical, in which case no amount of same-state rereading distinguishes them.

The biological gate is direct: demonstrate, in the selected system, a reversible nonzero slowdown with a measured rate envelope over the entire action path, stable and action-invariant emission columns, fixed minimum read duration, and viability/photophysics bounds. Re-run the computation using the measured ramp and disturbance kernels. A failure of the slowdown factor to act approximately as \(Q\mapsto\rho Q\), or an emission shift larger than the certified state-separation margin, rejects this protocol for that system. No biological application has passed these gates.
