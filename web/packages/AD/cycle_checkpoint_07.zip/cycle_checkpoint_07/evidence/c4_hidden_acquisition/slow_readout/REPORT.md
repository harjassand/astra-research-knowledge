# Conditional κ⁻² acquisition via paid slow-read blocks

## Verdict

A positive finite-duration slow-read action can, under a calibrated model interface, replace the κ⁻⁴ reporter-read burden of the existing stationary two-frame hidden-pair assay by κ⁻² total repeated-frame burden for a fixed, separated pair of CTMC probe kernels. The unknown shared reporter matrix is learned from repeated noisy outputs; labels remain hidden and are recovered only up to one common permutation. The slow action is strictly positive-rate, has finite elapsed time, and includes a measured ramp-disturbance budget. No reset, free state label, supplied emission matrix, singular-value oracle, or unchanged-time freeze is used.

This is a conditional statistical theorem, not a biological result or a novelty/priority claim. Reversible cryo-arrest proves that paid cooling/imaging/warming protocols with repeated frames are physically real in selected cell systems. Existing primary sources do not prove that cryo-arrest implements a scalar rate multiplier on arbitrary cell-fate states, keeps the reporter law fixed, or has ramp disturbance below the theorem's threshold. The biological gate remains UNKNOWN. A legal frame-dependent emission channel that becomes state-independent after its first frame refutes any unconditional κ⁻⁴-to-κ⁻² guarantee; that counterexample and the physical audit are in [legal_actions/REPORT.md](../legal_actions/REPORT.md).

## Exact model-level interface and theorem

The system has K hidden states, K read categories, and one unknown candidate mechanism b in {0,1}. A finite probe word has transition matrix P_b, with all pulse and probe-ramp effects included. The two candidate matrices are separated after state relabeling by

$$
γ = min_{S∈S_K} ||P_0 - S^{-1}P_1S||_F > 0.
$$

A slow-read block takes R fixed-duration Δ frames, with conditionally independent outputs from one unknown, shared, full-rank column-stochastic reporter matrix E. Its least singular value κ is unknown. Because the columns of E are separated by at least √2κ, block-frequency concentration recovers each unknown emission column. Independent founders have a common initial law π with each π_i≥p_*>0. The theorem uses a calibration cohort and an independent probe cohort. Each slow-read block, including entry and exit ramps, must have calibrated probability q_R of any hidden state change; for a scalar-multiplier hold with total ramp bound q_ramp, q_R≤q_ramp+ρΛRΔ. All slow-block jumps are union-bounded across the full protocol. The proof explicitly requires q_ramp<α/(4B), where B is the declared total number of blocks; when that fails the algorithm abstains.

For confidence 1−α, fixed K,p_*,γ, the construction needs

- O(Kγ⁻² p_*⁻¹ log(K/α)) independent native founders, independent of κ;
- O((K/(p_*γ²)) κ⁻² polylog(K/(αp_*γ))) reporter frames;
- RΔ plus measured entry/exit ramp time for every block, the nominal probe duration, and all read, culture, reporter-calibration, actuator-calibration, and recovery costs.

The frame count is therefore κ⁻² for fixed K, occupancy p_*, and transition margin γ. Passive two-read pairs for the saved cycle witness have per-pair KL O(κ⁴), so fixed-error testing requires Ω(κ⁻⁴) such pairs, even when the nuisance parameters are disclosed. This is a matched baseline for that fixed pair-law interface; it is not a lower bound on every passive trajectory estimator or on every richer action suite.

The proof first estimates E up to permutation from frequency clusters across independent slow-read blocks. It then decodes both endpoints of each finite pulse, estimates the transition matrix by its conditional rows, and compares the estimated matrix with the two candidate permutation orbits. The unknown start distribution is not needed for row estimation, but p_* controls the required founder cohort. If a confidence interval for p_* or the K-cluster separation cannot be certified, the procedure returns UNKNOWN. The adaptive frame-doubling rule does not know κ.

The proof and sample accounting are in [PROOF.md](PROOF.md). I repaired the repeated-read concentration with a dimension-free vector bound and replaced the informal first-success doubling rule with a finite maximum epoch, confidence spending across all prefixes, and a predeclared positive slowdown setting safe through that maximum. The finite theorem requires a supplied/certified $p_*>0$; a pilot is outside the theorem unless it adds its own simultaneous lower confidence bounds, failure allocation, and read/founder cost. This is a fixed-pair controlled acquisition theorem. It does not identify arbitrary unknown CTMCs or validate a physical slowdown device.

## Concrete finite witness

The script [slow_readout_witness.py](slow_readout_witness.py) reuses the Cycle 3 three-state directed-cycle alias. It checks the theoretical lag-1 endpoint alias to floating precision (maximum absolute matrix gap 2.33×10⁻¹⁵), and a nominal 0.05-time probe whose permutation-quotiented matrix gap is γ≈0.20900495. For E_κ=κI+(1−κ)11ᵀ/3, it verifies J_0−J_1=κ²(P_0−P_1)ᵀ/3 and the passive KL coefficient tends to 0.0218415; computed D(J_0||J_1)/κ⁴ at κ=0.4,0.2,0.1,0.05 is 0.0233905, 0.0222029, 0.0219304, 0.0218637.

The corrected script instantiates the full-founder/full-block sufficient bound for the explicit witness. At K=3, p*=1/3, γ≈0.209, α=0.05 it requires 49,064 starts per row and 589,085 total slow-read blocks. At κ=0.1 the declared worst-case cap is 524,288 reads per block, or about 3.09×10^11 reporter frames (~98 years of 10-ms held-read time), before ramps or any other cost; the data-dependent stopping time can be earlier. The per-block ramp probability must be below 2.2×10^-8; the displayed positive ρ assumes q_ramp=0. These conservative constants expose a severe practical gate rather than a practical assay. The calculation is finite floating-point evidence, not interval certification, experiment, or proof about nature.

## Prior art and novelty boundary

The core statistical components are established: concentration of repeated categorical outputs, HMM recovery up to hidden-label permutations, and controlled hidden-model estimation. Gassiat, Cleynen, and Robin's Theorem 2.1 identifies a finite-state HMM from three observations under full-rank transition and linearly independent emission conditions; Allman, Matias, and Rhodes give generic latent-structure identifiability criteria; Hsu, Kakade, and Zhang establish finite-sample spectral HMM learning with inverse-singular-value dependence; Liu and Bitmead study controlled HMM observability. These results do not validate a physical slow-read action. Masip et al. and Huebinger et al. establish reversible cryo-arrest protocols with repeated imaging for selected cellular measurements, while Kiepas et al. document illumination-related photobleaching and phototoxicity. Exact theorem/source pointers and the action audit are in [SOURCES.md](SOURCES.md).

The conditional κ⁻² rate is reconstructed directly from repeated-output concentration plus a finite jump-probability budget. I make no priority claim: whether this precise action-conditioned, ramp-accounted sample conversion has been previously stated is not established. The theorem is not presented as a new general HMM-identifiability result. The possible contribution is the explicit resource interface and its distinction between repeated read cost and passive independent-pair cost; its broader novelty remains UNKNOWN.

## Strong controls, failure cases, and next observation

The fixed-pair passive control is the exact independent two-read assay on the same alias pair, with the same candidate CTMCs; its κ⁴ KL law gives an Ω(κ⁻⁴) lower bound for that pair-law experiment, even if E and π are known. This is not a lower bound on all passive multi-time trajectories. The active result is an estimator upper bound under a new paid action; the optimal likelihood on the same active data is at least as informative, and no advantage over that control is proved.

The protocol fails or must return UNKNOWN if any of these measurements miss their gates: the held condition changes E; frame emissions drift or bleach; the read integrates a changing latent path; the no-jump rate envelope or finite-ramp bound is absent; q_ramp alone exceeds the allocated error; a positive hardware rate floor prevents the selected block size; a state has zero/uncertified initial mass; or the probe orbits overlap. The decisive next observation is a measured action path in a named biological system yielding (1) a state-specific transition-kernel envelope during hold and ramps, (2) invariant repeated-frame E estimates with a lower confidence bound on column separation, (3) positive founder occupancy bounds, and (4) total wall-time, exposure, viability, and recovery costs. Cryo-arrest alone supplies none of these fate-state calibrations.

A separate exact two-world adaptive minimax acquisition result on the existing three-daughter CLE alias was also derived. It is independent of this route and saved at [minimax_adaptivity/REPORT.md](../minimax_adaptivity/REPORT.md); root may select either result for synthesis.
