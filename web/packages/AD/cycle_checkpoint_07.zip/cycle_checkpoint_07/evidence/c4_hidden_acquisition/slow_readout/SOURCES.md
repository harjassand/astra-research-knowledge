# Sources and evidence notes

These sources are primary papers or author protocols. They establish mathematical prior art or a limited physical protocol, not the target biological rate/emission assumptions.

## HMM identifiability and controlled hidden-state observation

- **Gassiat, Cleynen & Robin (2016), “Inference in finite state space non parametric Hidden Markov Models and applications,” Statistics and Computing 26, 61–71.** [Author preprint](https://arxiv.org/abs/1306.4657), [DOI](https://doi.org/10.1007/s11222-014-9523-8). Theorem 2.1 in the preprint, pp. 2–3: a stationary finite-state HMM with known hidden-state count is identifiable up to permutation from three consecutive observations under full-rank transition and linearly independent emission laws. Qualitative identifiability, not the present paid-slowdown/ramp-cost theorem.
- **Allman, Matias & Rhodes (2009), “Identifiability of parameters in latent structure models with many observed variables,” Annals of Statistics 37(6A), 3099–3132.** [Author PDF](https://jarhodesuaf.github.io/papers/Latent.pdf), [DOI](https://doi.org/10.1214/09-AOS689). Corollary 3, pp. 17–18: three-view latent-class generic identifiability from Kruskal-rank conditions. Theorem 6, pp. 22–23: generic finite-state HMM identifiability from grouped observations. Not a quantitative slow-read result.
- **Hsu, Kakade & Zhang (2012), “A Spectral Algorithm for Learning Hidden Markov Models,” JCSS 78(5), 1460–1480.** [Author preprint](https://arxiv.org/abs/0811.4413), [DOI](https://doi.org/10.1016/j.jcss.2011.12.025). Theorem 6, PDF p. 10: finite-sample HMM prediction error depends polynomially on inverse emission/joint-observation singular values. It concerns a conventional HMM word law, not an added scalar slowdown action.
- **Liu & Bitmead (2010), “Observability and Reconstructibility of Hidden Markov Models: Implications for Control and Network Congestion Control.”** [DOI](https://doi.org/10.1109/CDC.2010.5717730). Adjacent controlled-HMM observability prior art; not used as a sample-complexity premise.

## Physical repeated imaging and disturbance

- **Masip et al. (2016), “Reversible cryo-arrest for imaging molecules in living cells at high spatial resolution,” Nature Methods 13, 665–672.** [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC5038880/), [Nature page](https://www.nature.com/articles/nmeth.3921), [DOI](https://doi.org/10.1038/nmeth.3921). Figures 1–4 and Discussion: staged DMSO/temperature cooling and warming, repeated cryo-arrest imaging, three cycles, and selected viability/function tests. The tested setup reaches −45°C in about ten minutes and 4°C after about 50 seconds. It does not establish Q↦ρQ for arbitrary cell-fate states, nor an invariant fate-state reporter E.
- **Huebinger et al. (2017), “Reversible Cryo-arrests of Living Cells to Pause Molecular Movements for High-resolution Imaging,” Bio-protocol 7(8):e2236.** [PMC protocol](https://pmc.ncbi.nlm.nih.gov/articles/PMC5450929/), [DOI](https://doi.org/10.21769/BioProtoc.2236). Protocol and Discussion specify temperature/medium ramps, cryoprotectant, repeated imaging, and application-specific validation.
- **Kiepas et al. (2020), “Optimizing live-cell fluorescence imaging conditions to minimize phototoxicity,” Journal of Cell Science 133(4):jcs242834.** [Primary article](https://journals.biologists.com/jcs/article/133/4/jcs242834/224018/Optimizing-live-cell-fluorescence-imaging), [DOI](https://doi.org/10.1242/jcs.242834). Abstract, results, Fig. 7: illumination contributes to phototoxicity and photobleaching; exposure and cell health need measuring for the actual system.

## Local evidence and mathematical controls

- [Cycle 3 controlled-observation report](../../cell_control/cell_observation_design/CYCLE3_REPORT.md): standard three-view HMM realization for actionwise CLE-equal CTMC mechanisms; nuisance-profiled sample count remains UNKNOWN without a certified profile margin. The passive pair-law construction in [cycle3_hidden_word.py](../../cell_control/cell_observation_design/cycle3_hidden_word.py) supplies the κ² pair-signal / κ⁴ passive-KL baseline and rank-one no-go.
- [Cycle 2 observation-design report](../../cell_control/cell_observation_design/CYCLE2_REPORT.md): charges reads, independent founder units, action intervals, reporter calibration, and costs; no freeze/slowdown action.
- [Legal action audit](../legal_actions/REPORT.md) and [source ledger](../legal_actions/SOURCES.md): cryo protocol scope, ramp and emission caveats, and a state-independent later-frame counterexample.
- [Adaptive minimax report](../minimax_adaptivity/REPORT.md): separate exact acquisition theorem for a specified two-world actionwise CLE alias.
- [Molecular cadence report](../../molecular_cadence_theorem/FINAL_REPORT.md): distinct process-time cadence experiment; it does not provide a repeated-held-state observation action.

## Boundary

No cited source validates a fate-state transition-rate multiplier, a ramp-jump probability below the theorem's union-bound budget, a stable unknown E during the held action, or a cost curve for the selected target. Those are measurements required for an application. No external reviewer or experiment assessed the saved theorem.
