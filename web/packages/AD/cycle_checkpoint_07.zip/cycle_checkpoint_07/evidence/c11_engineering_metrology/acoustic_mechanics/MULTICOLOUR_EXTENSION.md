# Multi-colour estimator and falsifiability extension

This extension makes the measurement model's identifiability boundary explicit. It is an internally derived linear-estimation result applied to the reported first-order helium response; it is not a new general metrology theorem or a device result.

## Conditional estimator

For `m` simultaneously observed frequencies, write the dimensionless resonance coordinates as

\[
z = p a + X\beta + \varepsilon,
\qquad \mathbb E\varepsilon=0,\quad \operatorname{Cov}(\varepsilon)=\Sigma>0.
\]

Here `a_i=3 A_R(nu_i)/(2RT)` is the known gas pressure slope, `X beta` is an explicitly specified set of cavity nuisances, and `Sigma` is the measured cross-colour covariance. Pressure is identifiable exactly when

\[
\operatorname{rank}[a\;X]=\operatorname{rank}(X)+1,
\]

equivalently, `a` is outside the nuisance column space. Under that condition, generalized least squares gives the minimum-variance linear unbiased estimator,

\[
\widehat\theta=([a\;X]^T\Sigma^{-1}[a\;X])^{-1}[a\;X]^T\Sigma^{-1}z,
\]

and its covariance is `([a X]^T Sigma^-1 [a X])^-1`. For the paper's shared-length model, `X=1`, so two colours identify pressure iff their gas dispersion slopes differ; the estimator reduces to the difference quotient in the report. With `m>2`, the minimized residual statistic has `m-rank([a X])` degrees of freedom under Gaussian errors and a correct covariance model. This gives an over-identification check for departures from shared-length response.

For exactly three colours and `X=1`, define `q=(a3-a1)/(a2-a1)`. The contrast

\[
r=z_3-z_1-q(z_2-z_1)
\]

has zero expectation under every pressure `p` and common nuisance `d`. Its variance is `c^T Sigma c`, for `c=(q-1,-q,1)^T`. A significant standardized residual falsifies the shared additive-nuisance model at the chosen error level. This is sharper than comparing fitted pressure values informally because it includes measured channel covariance. A third colour is the minimum number of channels that can give one residual degree of freedom for the two-parameter shared-length model.

## Exact remaining non-identifiability

More wavelengths do not make the result theory-free. If an unmodelled colour-dependent error is parallel to the pressure vector, `z=(1+eta) p a + X beta`, every colour fits perfectly at the biased value `(1+eta)p`; its residual is exactly zero for any `m`. A common additive component is already absorbed by the shared-length nuisance. In the helium first-order expansion, pressure response includes the known dispersion coefficient `A2`. An unknown multiplicative calibration error in that coefficient is exactly such a parallel error and is not removed by adding colours. The source's 4 ppm dispersion-theory contribution is therefore a genuine external knowledge floor for this inference, not a readout defect that more same-gas colours automatically fix.

If an additional chromatic nuisance basis `g` is proposed, pressure is identifiable only if `a` is not in `span(X,g)`. This condition has to be checked before adding colours. For example, allowing arbitrary unknown coefficients on both a constant and the same `nu^2` basis that carries the leading helium dispersion makes pressure non-identifiable, regardless of colour count. Such a model needs an external constraint, a gas with a different independently known spectral signature, or a separate direct measurement of the chromatic cavity response.

## Numerical design check

`multicolor_diagnostic.py` uses the paper's two laser frequencies plus a hypothetical 750 THz channel, the published helium coefficients, and independent 200 Hz/channel noise for illustration. It calculates the GLS uncertainty and the one-degree-of-freedom third-colour contrast. The 750 THz channel is not treated as fabricated or tested. The script also injects a synthetic `2e-12` fractional offset in that channel solely to verify the residual code, and constructs the exact `5.7 ppm` parallel-error alias to check the no-go. Results are in `multicolor_design_check.json`.

The practical experiment should record the full synchronized frequency covariance and compare the three pairwise pressure estimates under deliberate pressure, temperature and fill-history perturbations. Use at least four colours if one additional, specified chromatic parameter is fitted and a separate model-check residual is required. No finite number of colours can validate an unconstrained arbitrary spectral nuisance or remove an error component parallel to `a`.

Costs are extra stable laser references, counters, coating bands and wavelength-dependent mirror-phase characterization; the original two-colour cavity, settling and helium purification burden remains. A third-colour rejection would block transfer of the 5.7 ppm claim to the perturbed instrument; agreement only validates the tested perturbation/model class and does not clear the theory contribution or establish broad priority.
