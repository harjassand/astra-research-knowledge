# Source notes

## Workspace routing read

- `work/ROOT_MANDATE.txt`: current objective/evidence boundaries, source-first workflow, and required cost/interface accounting.
- `outputs/research/CYCLE10_PROGRESS.txt` and `outputs/research/ACTIVE_GATES.json`: current application breadth has no cleared metrology priority; thermal reciprocity/fracture proxy routes are low-ceiling; the engineering lead is open for measurement/design work.
- `work/astra_prior/00_START_HERE.txt`, `01_CORE.txt`, `RESEARCH_WORKFLOW.txt`, and `AGENTS.md` were read. Searches of the supplied small topic indexes found no direct optical-pressure/acoustic-measurement card; this is not a claim that no such external prior art exists.

## Primary result and direct source read

- Yang, Stone & Egan, “Demonstration of dispersion gas barometry,” *Phys. Rev. Applied* 23, 064041 (2025), [DOI](https://doi.org/10.1103/z9zz-lqzh), [NIST publication page](https://www.nist.gov/publications/demonstration-dispersion-gas-barometry), [NIST-hosted PDF](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=959484).
- PDF downloaded during this audit to `/tmp/c11_dispersion_gas_barometry.pdf`; SHA-256 `fb71edbfdaf261722261ed288fa8f6a79744638544a971c6f947d0107e40f7a2`. Text extracted locally for review. Read main text pp. 1–7 and supplement, especially refractometer working equations (S1)–(S12), helium result, and uncertainty table. Do not treat this PDF digest as a proof or validation artifact.
- Data archive metadata: [NIST dataset DOI 10.18434/mds2-3695](https://doi.org/10.18434/mds2-3695), [Data.gov catalog entry](https://catalog.data.gov/dataset/demonstration-of-dispersion-gas-barometry). Metadata describes two-colour observations and source scripts. `data.nist.gov/od/ds/ark:/88434/mds2-3695/data-2color.zip` timed out via both shell and web fetch; raw observations and author scripts were not read/replayed.

## Prior art and current competitor screen

- Ricker et al. (2018), [“Towards Photonic based Pascal Realization as a Primary Pressure Standard”](https://doi.org/10.1088/1742-6596/1065/16/162018): full-text page opened; used only to establish optical-FP pressure methods and known distortion/diffusion problems.
- Egan et al. (2019), [“Measured relationship between thermodynamic pressure and refractivity for six candidate gases in laser barometry”](https://doi.org/10.1116/1.5092185): NIST record and primary-paper extracts searched/read for its two-gas common-distortion proposal. It predates the same-fill two-colour demonstration.
- Silander et al. (2022), [mirror penetration depth in FP refractometers](https://doi.org/10.1364/OE.463285): abstract/metadata read; distinct mirror-phase/penetration systematic.
- Forssén et al. (2024), [transportable TOP/GAMOR ring comparison](https://doi.org/10.3390/s24010007), and Ricker et al. (2025), [portable FLOC report](https://doi.org/10.1016/j.measen.2024.101676): metadata and abstracts read to screen field-transportability novelty.
- Nie et al. (2026), [compact dual-cavity pressure manometer](https://arxiv.org/abs/2609.11964): full arXiv text read. It reports a small fused-silica device but calibrates the deformation coefficient against a piston manometer; it is a relevant unrefereed comparison, not a primary-pressure validation.
