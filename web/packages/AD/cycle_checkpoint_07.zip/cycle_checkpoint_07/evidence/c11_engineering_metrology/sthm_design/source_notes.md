# Source notes: SThM calibration design

## Primary target

- Charvátová Campbell et al., “Calibration of Scanning Thermal Microscope using Optimal Estimation of Function Parameters by Iterated Linearization,” arXiv:2501.08961 (submitted 2025-01-15), later *International Journal of Thermal Sciences* 218 (Dec. 2025), article 110080. DOI: https://doi.org/10.1016/j.ijthermalsci.2025.110080 ; primary preprint: https://arxiv.org/abs/2501.08961
- Read: complete arXiv HTML body via `https://arxiv.org/html/2501.08961`; publisher abstract/index only (publisher page returned 403 in browsing). Relevant body: introduction describes probe/contact/parasitic calibration, drift, tip changes, sample constraints; Methods gives `Y = U_sample - U_SiO2`, the rational calibration law, six calibration standards and five unknowns, sample-reference alternating acquisition; Results gives dataset-3 parameters, run correlations, sensitivity limitation above ~10 W/mK, defects/manual corrections and a failed/out-of-range sample; Conclusion describes automation. Exact code for OEFPIL and processed data tables were not independently run here.
- Public supplementary raw AFM dataset: https://doi.org/10.5281/zenodo.14671868. Dataset contains two runs of Bruker `.spm` files. It was downloaded/listed during source triage but not decoded or reanalyzed; no experimental evidence is claimed from it.
- Source-reported facts used: model `Y=a k/(b+k)+c`; dataset-3 fit `(a,b,c)=(0.8245,0.1892,-0.7128)`; about ten hours for the six-standard/five-unknown protocol; useful sensitivity range about 0.1–10 W m⁻¹ K⁻¹; calibration fit correlations up to about 0.999 in magnitude; full-sample voltage uncertainty around 10⁻³ in the paper's stated scale. Numerical design uses the first, second and range facts only. The illustrative `sigma_Y=10^-3` is an assumed scale for a local propagation calculation, not an independently re-estimated noise parameter.

## Direct SThM prior

- Fleurence et al., “Quantitative Measurement of Thermal Conductivity by SThM Technique: Measurements, Calibration Protocols and Uncertainty Evaluation,” *Nanomaterials* 13 (2023), 2424. DOI: https://doi.org/10.3390/nano13172424 ; full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC10490493/
- This primary prior establishes a traceable SThM calibration and uncertainty protocol and joint Bayesian inversion of a nonlinear calibration curve. It preempts any claim that joint parameter/sample estimation or full uncertainty propagation is new here. It also reports declining sensitivity above approximately 10 W m⁻¹ K⁻¹.

## Optimal-design prior and boundary

- The support result is the classical D-optimal design for quadratic polynomial regression after the local transformation `z=k/(b+k)`. General optimal design for nonlinear/rational regression predates this application; see the methods and references surveyed in “Optimal designs for rational function regression,” https://arxiv.org/abs/1009.1444, and the Michaelis–Menten design literature. No general-design or priority claim is made.
- Exact-material selection requires the actual traceable conductivity values/covariances for feasible standards, a local pilot estimate of `b`, and a stable probe configuration. The paper's complete raw `.spm` archive has not been independently interpreted; source-reported processed fit values remain the basis of the fixture.

## Astra boundary

Cycle 10/11 state files and the pinned `work/astra_prior/00_START_HERE.txt`, `01_CORE.txt`, and `RESEARCH_WORKFLOW.txt` were read. No directly applicable SThM optimal-calibrant result was found in the scoped Astra `01_CORE` intake; no Astra theorem is used as a premise. This is a selective negative search, not an exhaustive repository audit.
