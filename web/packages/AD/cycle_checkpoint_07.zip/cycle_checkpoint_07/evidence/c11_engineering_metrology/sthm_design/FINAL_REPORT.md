# SThM reference-standard placement: a conditional design result

## Result

For the nonlinear SThM calibration response reported by Charvátová Campbell et al., I derived a local D/G-optimal reference-standard design. Under a correct, stable rational response law, exact standards and independent equal-variance voltage noise, six reference measurements on the declared conductivity interval should be split evenly between its two endpoints and the conductivity that is the midpoint after the saturation transform (z=k/(b+k)). For (k\in[0.1,10]\,\mathrm{W\,m^{-1}K^{-1}}) and the paper's dataset-3 fit (b=0.1892), that third support point is (k_*=0.373236\,\mathrm{W\,m^{-1}K^{-1}}).

In the local model calculation, the six-reading design has 1.97 times the information determinant of six log-spaced standards on the same interval and reduces the worst response-prediction leverage from 5.72 to the sharp optimum 3. The generated [check file](design_check.json) and [calculator](optimal_reference_design.py) reproduce these figures. With an illustrative (10^{-3}) response-unit standard deviation for both reference and unknown readings, inverse uncertainty at (k=10) is still about (0.82\,\mathrm{W\,m^{-1}K^{-1}}): the small response slope, not poor numerical fitting alone, limits high-conductivity resolution.

This is a standard optimal-design theorem specialized to a recent nanoscale measurement protocol, not a new optimal-design principle or a priority claim. It proposes a testable acquisition improvement; no physical device result has been demonstrated.

## Source problem and exact interface

The 2025 SThM study treats the measured difference voltage as (Y=U_{sample}-U_{SiO_2}) and fits (Y=c+a k/(b+k)). Because probe-sample contact resistance and parasitic heat paths are not measured directly, the authors calibrate the full tip/electronics configuration on traceable standards. Their automated demonstration uses six calibration materials and five unknown optical windows, with a complete run taking about ten hours. The paper reports long-term voltage drift, abrupt jumps associated with possible apex changes or contamination, strongly correlated calibration parameters, manually corrected images, and poor sensitivity above roughly (10\,\mathrm{W\,m^{-1}K^{-1}}). The traceable 2023 SThM study already established Bayesian joint calibration and uncertainty propagation, so the present work does not claim those as new.

## Derivation and design algorithm

For (z=k/(b+k)),

\[
\nabla_{(a,b,c)} f(k)=\left(z,-\frac ab z(1-z),1\right).
\]

This is a nonsingular parameter transformation of the quadratic-regression row ((1,z,z^2)). D-optimality is therefore invariant to that transformation. On the transformed interval ([z_L,z_U]), the quadratic-regression D-optimal design has mass (1/3) at (z_L,(z_L+z_U)/2,z_U). Its sensitivity function is bounded by 3 and reaches 3 at the support, so the same design is G-optimal for local prediction of the calibration response. Mapping the midpoint back gives

\[
k_* = \frac{b(k_L+k_U)+2k_Lk_U}{2b+k_L+k_U}.
\]

For six equal-cost reference images, the local prescription is two measurements at each of (k_L,k_*,k_U). The proof and inverse-slope consequence are in [proof.md](proof.md). Runtime is negligible: evaluating and inverting a (3\times3) information matrix is (O(n p^2+p^3)), (p=3). The material preparation, traceable certificates, tip stability, and time for repeated images dominate the experiment.

## Equal-information control and conditional limits

The code compares six optimized support measurements with a six-point log-uniform panel on the same interval; both use the same total acquisition count and nominal fit information. This is a mathematical reference-panel control, not the authors' actual six-material set, whose exact conductivity certificate table was not reanalyzed. The source's Bayesian EIV method or OEFPIL remains the stronger fitting baseline; the change here is reference placement.

The central assumption is exact, common-variance (k_i). In a real calibration, conductivity certificates have uncertainty; SiO\(_2\) subtraction may correlate errors; drift and apex changes can change the curve itself; and roughness can violate the common contact-response law. First-order EIV replaces equal weights by (1/(\sigma_{Y,i}^2+f'(k_i)^2\tau_i^2)), and shared reference reads require the full covariance matrix. These generally change the support and weights. The design must be recomputed from actual standard certificates and measurement covariance, and recalibration is required after an apex-state change. The public `.spm` archive was not decoded, so no raw-data reanalysis is claimed.

## Decisive experiment

On one probe/electronics epoch, compare two six-image reference panels with equal total acquisitions: (a) two traces each at certified (k_L,k_*,k_U); (b) the strongest feasible six-standard panel chosen before fitting. Use matched force, bridge current, surfaces and image area. Time-stamp every image, record the raw bridge voltages and certificate covariance, and bracket each panel with repeated SiO\(_2\) references. Reserve one additional standard image as a held-out lack-of-fit check if the one-day budget permits. Then compare held-out voltage prediction error and blinded-sample conductivity coverage, counting `OUT_OF_CALIBRATION_RANGE` and `PRECISION_UNRESOLVED` as correct outcomes when the response is saturated.

The result is falsified as a useful acquisition improvement if it does not lower held-out predictive error or improve conductivity coverage at the same number of images, or if the required (k_*) reference cannot be fabricated/certified or is materially rougher than the other standards. No numeric cost saving is claimed; the published six-standard/five-unknown run took about ten hours. The design may reduce distinct sample swaps from six materials to three, but that must be timed on the actual instrument.

## Evidence and status

- **Conditional theorem:** local D/G-optimal support for the stated rational response and exact/equal-noise standards, proved in [proof.md](proof.md).
- **Finite computation:** nominal parameter fixture and equal-information comparison pass in [optimal_reference_design.py](optimal_reference_design.py); output in [design_check.json](design_check.json).
- **Source-reported:** the target paper's calibration model, sample/run counts, approximate runtime, parameter estimates and high-(k) sensitivity limitation.
- **Unknown:** whether the optimal intermediate standard can be fabricated with traceable conductivity, whether the D-opt panel improves real SThM measurements, how shared-reference and drift covariance alter it, and whether any practical or priority-level advance follows.

Sources, read depth and prior-art boundary are recorded in [source_notes.md](source_notes.md). The claim ledger is [CLAIMS.json](CLAIMS.json).
