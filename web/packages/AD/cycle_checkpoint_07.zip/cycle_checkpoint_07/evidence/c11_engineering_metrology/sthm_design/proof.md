# Local optimal calibration design for the SThM saturation curve

## Interface and source mechanism

The 2025 SThM calibration study models the difference voltage by

\[
f(k; a,b,c)=c+\frac{ak}{b+k},\qquad k>0,\ a,b>0,
\]

and jointly estimates this calibration curve and unknown sample conductivities with OEFPIL. Its automated experiment uses six small traceable bulk standards plus five unknown windows; the complete measurement takes about ten hours. The paper reports strong calibration-parameter correlations, curve flattening and poor conductivity estimates above about \(10\,\mathrm{W\,m^{-1}K^{-1}}\). This note asks a narrower acquisition-design question: if the reference standards can be selected from a feasible conductivity interval, where should six reference measurements be placed to identify the local calibration curve most evenly?

## Conditional local theorem

Assume the stated curve is correct in one stable tip/electronics epoch; the reference conductivities \(k_i\) are known without error; voltage errors are independent, centered, and have common variance \(\sigma_Y^2\). This is a *local* Fisher-information result at nominal \((a,b,c)\), not a global nonlinear confidence theorem.

The per-observation sensitivity vector is

\[
g(k)=\nabla_{(a,b,c)}f(k)=\left(z,-\frac ab z(1-z),1\right),
\qquad z=\frac{k}{b+k}.
\]

The parameter-independent factor is a nonsingular linear transform of the quadratic-regression vector \(p(z)=(1,z,z^2)^T\). Consequently, the determinant of the local information matrix for any approximate design \(\xi\) is a positive constant times

\[
\det M(\xi),\qquad M(\xi)=\int p(z)p(z)^T\,d\xi(z).
\]

On the feasible interval \(z\in[z_L,z_U]\), the quadratic-regression D-optimal design puts mass \(1/3\) at each of \(z_L,(z_L+z_U)/2,z_U\). For six measurements, take two replicates at each support point. In conductivity coordinates the middle point is

\[
k_* = \frac{b(k_L+k_U)+2k_Lk_U}{2b+k_L+k_U}.
\]

To verify optimality, rescale \([z_L,z_U]\) to \([-1,1]\). The information matrix for equal weights at \(-1,0,1\) has sensitivity function \(p(x)^TM^{-1}p(x)\le3\), with equality at all three support points; the Kiefer–Wolfowitz equivalence theorem gives D-optimality. The same bound is a G-optimal bound: the delta-method variance of the fitted mean response obeys

\[
\sup_{k\in[k_L,k_U]}\operatorname{Var}(\hat f(k))\le \frac{3\sigma_Y^2}{n},
\]

and equality holds at the design support. The bound is sharp under this local, homoscedastic, exact-standard model.

For a new sample with independent voltage variance \(\sigma_u^2\), first-order inverse propagation gives

\[
\operatorname{sd}(\hat k)\approx
\frac{\sqrt{\sigma_u^2+\operatorname{Var}(\hat f(k))}}{f'(k)},
\qquad f'(k)=\frac{ab}{(b+k)^2}.
\]

Even with the D-optimal design, the direct voltage-noise floor grows as \((b+k)^2/(ab)\); conductivity uncertainty diverges quadratically as \(k\to\infty\). This produces an admission rule: before reporting \(k\), invert only when the entire declared uncertainty interval in voltage lies inside the fitted response range and the propagated conductivity interval meets the predeclared precision target. Otherwise return `OUT_OF_CALIBRATION_RANGE` or `PRECISION_UNRESOLVED`.

## Scope changes under real standards

The theorem does not cover the practical features that dominate real SThM data: uncertain certified \(k_i\), shared SiO\(_2\) reference errors, sample topography, apex changes, time drift, or model misspecification. With independent uncertain reference conductivity of variance \(\tau_i^2\), a first-order profile likelihood replaces the equal information weight by

\[
w_i=\frac{1}{\sigma_{Y,i}^2+f'(k_i)^2\tau_i^2}.
\]

Unequal weights generally move the optimal support and allocation. A shared reference reading creates off-diagonal covariance and must be represented in the full GLS/OEFPIL covariance. A change in probe apex can change \((a,b,c)\) and invalidates any fixed-epoch design. Therefore the three-point formula is a pilot design rule for a measured feasible interval, not a substitute for standards certification or an epoch-change test.

## Finite diagnostic

Using the source paper's dataset-3 table values \((a,b,c)=(0.8245,0.1892,-0.7128)\), the paper's stated useful range \([0.1,10]\,\mathrm{W\,m^{-1}K^{-1}}\), and six equal-variance reference readings, the transformed-space middle standard is \(k_*=0.373236\,\mathrm{W\,m^{-1}K^{-1}}\). In the supplied numerical check, this design yields an information determinant about 1.97 times that of six log-spaced reference conductivities and reduces the grid maximum local response leverage from 5.72 to 3.00. These are calculations for a synthetic exact-\(k_i\), equal-voltage-variance design, not a reanalysis of the authors' raw AFM data or a prediction of a fabricated probe's uncertainty.

With \(\sigma_u=\sigma_Y=10^{-3}\) in the article's voltage-difference units, local inverse standard uncertainty at \(k=10\) is still about \(0.82\,\mathrm{W\,m^{-1}K^{-1}}\) even under this design. That number illustrates the inverse-slope penalty; it is not a reported device performance.

## Decisive experimental test and costs

For one stable probe/electronics epoch, use the same six image acquisitions in two panels: (i) the three equal-count conductivity standards at \(k_L,k_*,k_U\); (ii) the strongest feasible six-standard comparison panel selected before fitting. Use matched surface finish, tip force, bridge current, and image regions. Record actual timestamps, raw bridge voltage, certified conductivity covariance, topography, and at least one repeated reference before and after every panel. Hold back one standard image as a lack-of-fit witness. Compare held-out response prediction error and the propagated uncertainty of blinded unknowns, including the fraction that correctly return an unresolved range status. Recalibrate after an apex/reference residual step.

The design has negligible arithmetic cost (three-by-three matrix inversion; \(O(n p^2+p^3)\) for \(p=3\)) but requires standards at the chosen conductivities, traceable certificates, at least six reference images, controlled sample surfaces, and time to detect tip changes. The source's full six-calibrant/five-unknown automated run required about ten hours; no time saving is claimed until the same instrument runs the matched panel test. A fair baseline includes the same number of acquisitions and OEFPIL or the source's Bayesian EIV method; the proposed contribution is where standards are placed, not replacing sound uncertainty propagation.

## Evidence and novelty boundary

The algebra and numerical fixture are internally checked. The D-optimal/G-optimal theorem is a classical optimal-design consequence specialized to this response law. OEFPIL and the 2023 Bayesian inversion already address nonlinear errors-in-variables calibration and uncertainty; no priority claim is made for that machinery. The design rule is a candidate practical extension. It has no experimental validation and requires an identified pilot \(b\), stable probe epoch, and independently characterized reference materials.
