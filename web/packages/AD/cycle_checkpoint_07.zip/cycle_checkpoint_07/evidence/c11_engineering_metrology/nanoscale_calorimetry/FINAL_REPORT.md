# Cycle 11 scout: layer-resolved calorimetry of CrSBr

## Verdict

The strongest lead is Gómez-Torres et al., “Layer- and Field-Dependent Magnetic Order in 2D CrSBr Revealed by Pulsed Nanocalorimetry,” arXiv:2607.29395 (first posted 31 July 2026, revised 11 September 2026; source status checked 8 October 2026: preprint). It reports direct heat-capacity curves for hBN-encapsulated CrSBr flakes from one layer through bulk-like thickness, under in-plane fields, using microsecond pulse-heating nanocalorimetry. The important measurement advance is access to thermodynamic heat capacity in femtogram flakes, where optical, transport, and local magnetic probes observe related order parameters but do not measure entropy. The source's magnetic-entropy interpretation additionally depends on hBN and Debye-lattice background choices.

The advance is source-reported, not independently replayed. The arXiv preprint says its measurement data are deposited at [CORA.RDR DOI 10.34810/DATA3638](https://doi.org/10.34810/DATA3638), but the repository API presented an anti-bot challenge during this audit, so I could not inspect the files. An APS March 2026 abstract calls the work “in preparation for submission”; the current evidence therefore supports “recent primary preprint,” not peer-reviewed validation or priority clearance.

## Exact physical interface and mechanism

Each cell is a suspended 180-nm SiN membrane with a Ti/Pt strip that is both Joule heater and resistance thermometer in a four-probe layout. Two cells are wired in series and read differentially: one carries the CrSBr/hBN flake, the other is a matched reference. The device sits in an in-plane field aligned with the CrSBr easy (b)-axis. The source reports device suspended areas from (15\times15) to (50\times50\,\mu\mathrm m^2), and flake areas from 35 to 90 \(\mu\mathrm m^2\).

For each field and base temperature, a 50-\(\mu\)s current pulse (12–17 mA, depending on device) heats both cells at about (10^5\,\mathrm{K/s}); pulses are separated by 0.1 s for full thermal relaxation. The measured observables are current (I(t)), cell voltages (V_S(t),V_R(t)), and amplified differential voltage \(\Delta V(t)=V_S(t)-V_R(t)\). A calibrated Pt (R(T)) curve converts (V/I) into (T_S,T_R) and slopes \(\beta_S=dT_S/dt\), \(\beta_R=dT_R/dt\). Under the quasi-adiabatic pulse assumption, the differential heat capacity is reconstructed from input Joule power and the transient slopes. The methods paper gives the working expression

\[
\Delta C_p(T_S)=\frac{I\Delta V}{\beta_S}
-\frac{V_R}{\beta_S\beta_R}\,
\frac{(d\Delta V/dt)}{(dR_S/dT_S)}
+\frac{V_R I}{\beta_S}\left(1-\frac{dR_R/dT_R}{dR_S/dT_S}\right),
\]

The 2026 methods paper's full protocol also subtracts a pre-deposition differential baseline; the CrSBr preprint does not make clear whether that step was repeated for each flake. The physical mechanism is short-time Joule heating: reducing the pulse duration limits lateral heat diffusion, keeps a smaller thermal mass participating, and reduces background heat capacity while retaining a measurable temperature ramp. This is a direct electrical calorimetric interface, distinct from inferring heat capacity through a mechanical frequency shift.

The CrSBr preprint adds a second background problem. After subtracting the platform with the reference cell, the hBN encapsulation contribution is estimated from AFM dimensions and tabulated hBN heat capacity; a constant per-device offset is applied. Magnetic excess heat capacity is then separated using a Debye-type phonon fit above the anomaly, and magnetic entropy is calculated as \(\Delta S(T)=\int \Delta C_p(T)/T\,dT\). The authors explicitly say the absolute entropy and entropy-derived moment depend somewhat on these background choices; relative field/thickness trends are more robust. The layer assignment for 2ML and monolayer is from optical contrast and deterministic transfer because encapsulated flakes could not be resolved reliably by AFM.

## Quantitative result and bounded replay

The v2 preprint reports (i) interlayer anomaly inflection temperatures of 139.22 K (6ML), 134.3 K (3ML), and 133.28 K (2ML) at zero field; (ii) a monolayer feature near 145 K attributed to intralayer correlations, with no interlayer transition; (iii) an extra high-temperature anomaly near 145 K in odd-layer samples, weaker/broader in even-layer samples; and (iv) suppression of the multilayer interlayer anomaly by easy-axis in-plane fields up to 100 mT. A sigmoid fit to the entropy suppression gives a characteristic field near 40 mT for 2ML and 85 mT for 6ML. The source estimates ±0.5–1 K uncertainty for inflection temperatures, mainly from noise, differentiation, and spline choice. These are source-reported measured outcomes; the parity and intralayer-correlation mechanisms are interpretations supported by earlier magnetic probes.

The source's supplementary table permits a bounded arithmetic check of the quadratic transition-line claim (T^*(H)=T^*(0)-aH^2). Ordinary least-squares fits to the rounded tabulated inflection points give slopes (-0.997\times10^{-3}\), (-1.077\times10^{-3}\), and (-1.049\times10^{-3}\,\mathrm{K/mT^2}) for 2ML, 3ML, and 6ML, with (R^2=0.927,0.961,0.902). These agree in scale with the manuscript's fits (1.05,1.08,1.14\times10^{-3}\,\mathrm{K/mT^2}), allowing for rounded table entries and curve-level fits. This is arithmetic reconstruction from source values, not independent data replay.

The thin-flake readout removes a real observability constraint, but the platform does not directly image a local heat-capacity map: each run returns a scalar, thermally weighted (C_p(T)). The demonstrated sample areas are tens of \(\mu\mathrm m^2\), while the cell footprints are at least (15\times15\,\mu\mathrm m^2\). Claims of single-monolayer capability are experimentally demonstrated for CrSBr, while the further projection to general monolayer materials remains material- and coupling-dependent.

## Prior art and novelty boundary

- Bulk CrSBr direct heat capacity already resolved anomalies near 185, 156, and 132 K: Liu et al., “A Three-Stage Magnetic Phase Transition Revealed in Ultrahigh-Quality van der Waals Bulk Magnet CrSBr,” *ACS Nano* 16 (2022), [DOI 10.1021/acsnano.2c02896](https://doi.org/10.1021/acsnano.2c02896). The current lead is not discovery of CrSBr heat-capacity anomalies.
- Guo et al., “Extraordinary Phase Transition Revealed in a van der Waals Antiferromagnet,” *Nature Communications* 15 (2024), [DOI 10.1038/s41467-024-50900-1](https://doi.org/10.1038/s41467-024-50900-1), combines bulk heat capacity with SHG and reports a distinct ~140 K symmetry-sensitive feature. This makes it especially important not to equate every calorimetric or optical anomaly with one identical transition.
- Fei et al., “Spin-Mechanical Coupling in 2D Antiferromagnet CrSBr,” *Nano Letters* 24 (2024), [DOI 10.1021/acs.nanolett.4c01751](https://doi.org/10.1021/acs.nanolett.4c01751), used opto-electromechanical resonance on a ~30-nm membrane and inferred a heat-capacity anomaly through a frequency-slope relation; it did not provide direct differential pulse calorimetry across the few-layer-to-monolayer series and field.
- Zhang et al., “Short-range magnetic dynamics drive spin-phonon coupling above the Néel temperature in CrSBr,” *Physical Review B* 114, 154426 (published 25 September 2026), [DOI 10.1103/pmln-p6vv](https://doi.org/10.1103/pmln-p6vv), is a direct, contemporaneous comparator. It used bulk crystals on a 150-nm SiN membrane with NiCr/SiOx thermometers, a Cr AC heater plus offset heater, variable-frequency AC steady-state nanocalorimetry, grease attachment, magnetoresistance correction, and separately measured membrane/grease background. Its bulk Cp anomaly is suppressed as field rises to 0.2 T; it assigns a weak ~155 K feature to background, while polarized Raman observes phonon self-energy/intensity changes above TN and supports spin-phonon coupling in the precursor regime. Thus the thin-flake paper is not the first field-dependent Cp measurement on CrSBr. Its bounded increment is low-field, layer-resolved direct calorimetry down to a monolayer, not a general discovery of field-sensitive thermodynamics or a spin-only entropy separator.
- The enabling µs-PHnC implementation is separately described by Gómez-Torres et al., *Microsystems & Nanoengineering* 12, 323 (2026), [DOI 10.1038/s41378-026-01426-7](https://doi.org/10.1038/s41378-026-01426-7). Its CoO benchmark narrows the observed anomaly from ~20 K under millisecond QAnC to ~5 K under 50-µs pulses. Earlier quasi-adiabatic nanocalorimetry, AC/relaxation nanocalorimetry, and 2010–2013 µs-pulsed methods predate the 2026 implementation. The defensible increment is miniaturized pulsed differential measurement and its layer-resolved CrSBr application, not invention of calorimetry or of microsecond pulsing.

The strongest comparator is therefore not “no prior thermodynamic data”; it is the existing bulk heat-capacity curve, the 2026 field-dependent bulk AC calorimetry, equally informed layer-resolved optical/magneto-transport probes, and the 2024 indirect nanomechanical measurement. The new information is direct heat capacity under controlled layer number and field. The source's entropy trend is an analysis product, not a direct spin-only observable.

## Missing quantitative algorithm and derivation

The paper's reported magnetic \(\Delta S(T,H)\) requires an assumed phonon background. A narrower observable that avoids specifying a Debye background is total field-induced specimen entropy. Suppose for one fixed flake/device

\[
C_{\rm obs}(T,H)=A(T)+C_{\rm flake}(T,H)+\epsilon(T,H),
\]

where \(A(T)\) is the field-invariant platform/encapsulant background and \(C_{\rm flake}\) is the full field-dependent specimen heat capacity. Then for a reference field \(H_0\),

\[
\Delta S_{\rm specimen}(T;H,H_0)=\int_{T_0}^T\frac{C_{\rm obs}(u,H)-C_{\rm obs}(u,H_0)}{u}\,du
=\int_{T_0}^T\frac{C_{\rm flake}(u,H)-C_{\rm flake}(u,H_0)}{u}\,du
+\text{measurement/quadrature error}.
\]

This follows by subtracting the two measurement equations before integrating: a field-invariant additive background cancels pointwise. For sampled data, interpolate only onto a shared temperature grid and apply the composite trapezoid rule to \([C(T,H)-C(T,H_0)]/T\). If \(W\) is the cumulative trapezoid operator and \(\Sigma_\Delta=\Sigma_H+\Sigma_{H_0}-\Sigma_{H,H_0}-\Sigma_{H_0,H}\) is the covariance of the paired heat-capacity difference, then \(\Sigma_S=W\Sigma_\Delta W^\top\) gives the accumulated entropy covariance, retaining correlations from shared calibration or common-mode drift. This estimates total field-induced entropy of the specimen, not spin-only entropy. The 2026 PRB bulk study reports precursor spin-phonon coupling, so field-dependent heat capacity cannot be assigned to spins alone without a separation model even if addenda cancel. A matched empty-cell/hBN-only run tests background cancellation; H–H0–H bracketing tests drift and reversibility; field-dependent Raman or a lattice-coupling model is needed to support a spin-only attribution.

I derived the cancellation identity and numerically checked it on synthetic grids with a deliberately arbitrary smooth field-invariant background. On 251, 501, 1001, and 2001 points, maximum errors were \(1.86\times10^{-13},4.65\times10^{-14},1.16\times10^{-14},2.91\times10^{-15}\,\mathrm{J/K}\), consistent with second-order grid convergence. I also checked the full paired-covariance propagation against 30,000 synthetic draws (relative covariance-matrix error 0.013). The implementation is a standard estimator, not a novelty claim or a demonstrated new capability; the uncancelled lattice coupling means its output is not spin-only entropy. The runnable reduction and checks are in [field_difference_entropy.py](field_difference_entropy.py). Applying it to the authors' curves is blocked by the inaccessible data repository in this audit. The next gate is a raw-curve field-paired reduction with H–H0–H drift controls and an empty-cell field sweep; a spin-only interpretation additionally needs a validated spin/lattice decomposition.

## Costs, calibration, and failure observations

- **Acquisition:** individual pulses last 50 µs but require 100 ms between pulses, so the readout is quasi-static rather than a probe of sub-100-ms spin kinetics. The current is 12–17 mA, the heating rate ~(10^5\) K/s, and the field calibration resolution is ±2 mT over a coil range to 100 mT. The source reports high-vacuum operation at ~(10^{-8}\) mbar, ~1 mK base-temperature stability, and 80–300 K coverage. Full curve durations and per-device sample noise are not stated in the CrSBr preprint.
- **Resolution and runtime:** the methods paper reports a noise density of 75 pJ K⁻¹ Hz⁻¹ᐟ² mm⁻², measured over 50 s on a matched pair of nominally identical meander sensors. Scaling by area projects about 7.5 fJ K⁻¹ Hz⁻¹ᐟ² for 100 µm²; this is an area projection, not a CrSBr device result. Its 4 MS/s, 16-bit digitizer and 3-µs amplifier settling support the 50-µs pulse, but first 10–20 µs are discarded (the paper's text and SI differ on the exact cut), constraining further pulse shortening. Full CrSBr curve time, repetitions per point, and per-device noise are not reported.
- **Thermal/readout model:** requires four-probe (R(T)) calibration, measured (I,V_S,V_R,\Delta V), stable matched-cell response, differential amplifier bandwidth, transient-window selection, and correction for non-adiabatic heat loss. These electronics are fast enough for the reported 50-µs pulses but constrain further pulse shortening.
- **Sample preparation:** dry transfer and hBN encapsulation under (<0.5) ppm oxygen and moisture, device fabrication/anneal, AFM/optical thickness/area measurements, and a suspended calorimeter in high vacuum. The active cell also perturbs temperature by a few kelvin during each pulse; full relaxation reduces cumulative heating but does not establish the absence of rate-dependent shifts. Indeed, the preprint notes its bulk-like transition near 139–140 K rather than the common ~132 K and flags strain or the ~(10^5\) K/s heating protocol as possible causes.
- **Interpretation:** inflection-point (T^*(H)) is relatively robust to smooth baselines; the magnetic entropy and entropy-equivalent moment require phonon subtraction, hBN correction, area/layer normalization, and a localized (S=3/2) spin entropy interpretation. The preprint explicitly says the entropy-derived moment is not magnetometry. Odd/even visibility is evidence consistent with uncompensated layer moments, not a direct measurement of those moments.
- **Decisive controls:** acquire same-flake H–H0–H sweeps on a common temperature grid; measure empty reference cells and hBN-only devices over the same fields; compare strain-matched flakes if feasible; independently verify layer count and flake area; compare transition extraction with and without spline choices. A field effect that survives these controls supports a thermodynamic specimen signal; non-reversible H cycles or a same-size field curve on a nonmagnetic control indicates an unresolved measurement/background effect. Spin-only attribution requires a validated spin/lattice decomposition.

## Claim status

Source-reported experimental capability and results; internal interface reconstruction; finite arithmetic check of rounded transition-table slopes; derived conditional field-difference entropy identity and covariance propagation. No independent raw-data replay, no independent device experiment, no proof of universal sensitivity across 2D materials, and no novelty/priority clearance. This is a strong capability lead, but the background-cancellation estimator is standard and the spin-only entropy interpretation remains model dependent.

## Source ledger

1. Gómez-Torres et al. (2026 preprint), [arXiv:2607.29395](https://arxiv.org/abs/2607.29395), including its supplementary information and data-availability DOI 10.34810/DATA3638.
2. Gómez-Torres et al. (2026), [µs-PHnC methods paper](https://doi.org/10.1038/s41378-026-01426-7).
3. Liu et al. (2022), [bulk CrSBr heat capacity](https://doi.org/10.1021/acsnano.2c02896).
4. Guo et al. (2024), [bulk heat-capacity and SHG comparison](https://doi.org/10.1038/s41467-024-50900-1).
5. Fei et al. (2024), [nanomechanical CrSBr thermodynamic/magnetostriction study](https://doi.org/10.1021/acs.nanolett.4c01751).
6. APS March 2026 meeting abstract, [conference record](https://meetings-archive.aps.org/smt/2026/mar-b41/4/), reporting the work was in preparation for submission at that time.
7. Zhang et al. (2026), [published PRB 114, 154426](https://doi.org/10.1103/pmln-p6vv), bulk AC nanocalorimetry and Raman study of field-dependent heat capacity and precursor spin-phonon coupling.
