# Cycle 12: all-odd-Spin uniformity restart

## Verdict

The all-$n$ factor-two/common-canonical-EB assertion remains **UNKNOWN**. This restart adds two scoped pieces of evidence: an exact Spin(13) replay of the proposed termwise bound on every $r\ge1$ block, and an exact Spin(15) rescue of one direction where the original finite seed hull was too small. Neither closes the all-$n$ theorem. In particular, the Spin(15) seed-hull failures are not channel counterexamples: the failed test used an attained-seed lower bound in place of the full canonical support.

The primary unresolved work is now sharply split:

1. Prove or refute the all-$n$ recoupling gap on $r\ge1$ blocks.
2. Prove the $r=0$ star inequality against the true continuous pure-spinor support (h_n(\alpha)), or produce a legal global obstruction.

The second item is the high-value unresolved block. No supplied-seed lower-support failure is counted as a global counterexample.

## Exact block reduction and the termwise gate

Use the inherited all-$n$ representation reduction and the convention $d_k=\binom{2n+1}{k}$, $D_{k,r}=\operatorname{diag}(\mu_{k,r},\ldots,\mu_{k,n})$,

\[
H_{k,r}=D_{k,r}+F_rD_{k,r}F_r,
\qquad
\mu_{k,j}=\sum_{\ell}(-1)^{kj-\ell}\binom{j}{\ell}\binom{2n+1-j}{k-\ell}.
\]

The proposed shortcut is expressly the termwise claim (H_{k,r}\preceq d_k I) for $r\ge1$; it is not asserted on $r=0$. Define

\[
L_{k,r}=I-D_{k,r}/d_k.
\]

Then the termwise claim is exactly

\[
L_{k,r}+F_rL_{k,r}F_r\succeq I.
\]

For a fixed $j$, $\mu_{k,j}/d_k$ is the average of

\[
(-1)^{kj-|A\cap J|}
\]

over uniformly chosen $k$-subsets $A\subseteq[2n+1]$, with any fixed $j$-subset $J$. Thus the diagonal entries of $L_{k,r}$ are twice the probability that this parity character is $-1$. This identifies the shortcut as a two-coupling complementarity/spectral-gap problem. It is a reduction, not a proof of the gap.

For Spin(13), $n=6$, I used the inherited exact reduced matrices and checked every principal minor of (d_kG-B_k) for $k=1,\ldots,6$, all $r=1,\ldots,6$, and every present output-swap sign. All **66 grade/block gaps** pass **222 exact rational principal-minor checks**. The $r=0$ blocks are excluded intentionally. The run and full determinants are in [the certificate](spin13_r_ge1_termwise_certificate.json), replayed by [the checker](check_n6_r_ge1_termwise.py). This is finite evidence at one $n$, not an all-$n$ proof, and it reuses rather than independently reconstructs the Spin(13) extraction.

## Spin(15): what the finite-seed failure does and does not show

The exact $r=0$ recoupling formula from cycle 11 gives an $8\times8$ compression for Spin(15), $n=7$. Testing the original eight Jordan--Wigner seeds \(\psi_h\) gives three failed rays in their support-cone enumeration, across 40 distinct rays and 10,200 exact principal minors. The simplest is \(\alpha=e_5+e_6\): the seeds give support 62, the trace term is 8008, and the exact determinant of the full candidate gap is negative. These values refute only the proposed eight-seed upper comparator at this direction.

I replayed an explicitly attained rational pure spinor with the exact Clifford words. Its moments are

\[
(s_1,\ldots,s_7)=\frac{1}{99{,}460{,}729}
(6{,}099{,}009,65{,}937{,}487,346{,}216{,}199,992{,}159{,}749,
2{,}390{,}843{,}581,3{,}899{,}509{,}747,4{,}930{,}746{,}811),
\]

with exact Parseval sum 127. Hence its attained $s_5+s_6$ equals

\[
6290353328/99460729=63.2445930292749\ldots.
\]

For the same ray, all 255 principal minors of the exact $8\times8$ r=0 matrix \((80711/10)I-H_{e_5+e_6,0}\) are nonnegative. Therefore

\[
\lambda_{\max}(H_{e_5+e_6,0})-8008\le 63/10
< 6290353328/99460729\le h_7(e_5+e_6).
\]

This exactly rescues that one ray in the true-support comparison. The rational state and its Clifford-moment replay are in [the seed certificate](spin15_rational_seed_certificate.json) and [source](spin15_rational_seed.py); the exact star upper bound and comparison are in [the rescue certificate](r0_seed_rescue_n7.json), replayed by [this checker](certify_r0_seed_rescue_n7.py).

Adding that state to the seed family and rerunning the exact cone enumeration leaves two failed rays among 48; see [the augmented check](r0_augmented_seed_check_n7.json). They remain failures of a finite attained-seed lower support bound only. The random-search note from the interrupted attempt is not promoted to evidence: it had narrow floating margins and no preserved exact replay. No legal channel, complete canonical-support upper bound, or global Spin(15) obstruction was produced.

## All-(n) theorem and negative transfer values

The inherited exact canonical-support identity is

\[
h_n(\alpha)=\max_{\|\psi\|=1}\sum_{k=1}^n\alpha_k s_k(\psi),\qquad \alpha\ge0.
\]

The full-star condition

\[
\lambda_{\max}(H_\alpha)\le\sum_{k=1}^n d_k\alpha_k+h_n(\alpha)
\]

implies by positive-cone separation one common full-domain canonical EB comparator for a Spin-covariant unital, trace-preserving, Hilbert--Schmidt-self-adjoint self-compatible channel. The separation step allows arbitrary real transfers \(\lambda_k\), including negative values; positivity is imposed only on the dual weights \(\alpha_k\ge0\). Replacing $h_n$ by the original finite seed support is false already at $n=7$. The exact scope of the conditional implication is in the cycle 11 representation report, §“Uniform broadcaster-to-comparator criterion, including negative transfers.”

If the termwise claim holds for all $r\ge1$, those blocks are immediately bounded by \(\sum_k d_k\alpha_k\), since $h_n(\alpha)\ge0$. This still leaves the exact $r=0$ condition. A proof of the recoupling gap alone therefore does not complete the theorem.

## Mathematical source boundary

The recoupling entries and the diagonal \(\mu_{k,j}\) are Krawtchouk-type transforms on Clifford grades. This resembles the quantum-weight-enumerator/MacWilliams framework of Rains and later generalizations; those sources motivate checking for a positivity or linear-programming certificate but do **not** prove the Spin star inequality or classify $h_n$:

- E. M. Rains, [Quantum Weight Enumerators](https://arxiv.org/abs/quant-ph/9612015).
- E. M. Rains, [Quantum Shadow Enumerators](https://arxiv.org/abs/quant-ph/9611001).
- C. Cao and B. Lackey, [Quantum Weight Enumerators and Tensor Networks](https://arxiv.org/abs/2211.02756).

No external proof review, proof-assistant verification, exact priority/novelty clearance, or validation in nature was performed. The broader prior-art boundary and the distinction between a structured theorem and the unrestricted factor-two problem remain as stated in [the inherited all-$n$ report](../c11_spin_uniform/rep/UNIFORM_REPRESENTATION_REPORT.md) and [cycle 10 progress](../../../outputs/research/CYCLE10_PROGRESS.txt).

## Reproduction and resource record

- `python3 work/agents/c12_spin_uniform/check_n6_r_ge1_termwise.py` — PASS; exact arithmetic on saved Spin(13) reduced blocks; 66 gaps / 222 principal minors.
- `python3 work/agents/c12_spin_uniform/spin15_rational_seed.py` — PASS; exact Pauli-word replay on 128 complex amplitudes and all grades; Parseval sum 127.
- `python3 work/agents/c12_spin_uniform/certify_r0_seed_rescue_n7.py` — PASS; exact r=0 $8\times8$ check, 255 principal minors.
- `python3 work/agents/c12_spin_uniform/r0_augmented_seed_check_n7.py` — exact finite enumeration; 48 rays, 12,240 principal minors, two finite-seed failures.
- The inherited Spin(13) sparse extractor never formed a dense (262144\times262144) matrix. Its saved output records about 80.7 seconds elapsed; this restart only read its reduced blocks.

No dense triple-space matrix was formed and no new star extractor or channel compiler was built. Full unrestricted factor two, exact all-$n$ support classification, and a legal global counterexample remain unresolved.

## Reproducibility hashes

SHA-256 (code, reduced input, and exact outputs):

| File | SHA-256 |
|---|---|
| `check_n6_r_ge1_termwise.py` | `24b4569f0aef565955bf730acd304d300dcaaf633dc9c1910261e47fab760868` |
| `spin13_r_ge1_termwise_certificate.json` | `13ef996d9480a59bf88236c708abca52fff4210941fe45f08f0d187e979a561b` |
| inherited `spin13_fullstar_blocks.json` | `62e7afe6b3ae49e06cd35b4250c795ed156ab5098152150c4b1fb08bcab726f0` |
| `spin15_rational_seed.py` | `e385b657d1c30daa9a8f5fde04f17c062285a54030adfb688c6992aa762f4676` |
| `spin15_rational_seed_certificate.json` | `b5cdc177fe524b0a8177381106df855c1fa467a1204de9cb9504d6859fc0581d` |
| `certify_r0_seed_rescue_n7.py` | `e156aa04930b1886c71a6b5a8e9a45a988545943027ad1db1385f6c0ac55624e` |
| `r0_seed_rescue_n7.json` | `fddeabf7f1c425274ba16a2d291bcd13e4b5c7c4900a128d24ca87279aa70974` |
| `r0_seed_cone_probe.py` | `e412c72dcff2c1073f4739352f49291f3c3d65b04f099ce1bcc76e2d8156f48c` |
| `r0_seed_cone_n7.json` | `892e8a21d4b259687a16fdc782be50118e7f39fbbd14bd2897872639ba6f68fc` |
| `r0_augmented_seed_check_n7.py` | `5efe54101c15c9a6ffd0c5e649ebd25dd8e0461e8b87599528da23d4e47680d1` |
| `r0_augmented_seed_check_n7.json` | `c457b7ed46e198d95334b9f464ef16f6dcf83456fff7528a7516398a3a1d2734` |
| `CLAIMS.json` | `d6ae51bfa2eefeed0423743545135c67814f352247d12bab151de467bfe09e8e` |
