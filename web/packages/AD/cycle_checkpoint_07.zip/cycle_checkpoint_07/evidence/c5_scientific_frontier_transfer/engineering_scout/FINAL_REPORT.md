# Engineering scout: finite-resource equivalence testing for switched rational systems

## Verdict

The best unused engineering target I found is a noise-robust, energy-accounted equivalence test for switched systems whose input/output laws are noncommutative rational series. The exact algebraic hook is real: the pinned OpenAI release gives a polynomial-bit matrix hitting list for bounded-size noncommutative rational formulas, including inverse-domain checks. But it only applies to exact full matrix-output queries. A hidden-word system gives an exponential lower bound under both (i) ordinary noisy pulse-sequence experiments and (ii) the stronger adaptive matrix-query interface when total excitation is bounded. This is a principled rejection of the tempting claim that the release result yields efficient physical system identification. The remaining theorem target is a sharp minimax result under explicit signal, stability, and actuator margins; no positive advance or priority claim is made here.

## Exact candidate interface

Let two unknown models be represented by admissible rational formulas \(\Phi_0,\Phi_1\) over \(n\) noncommuting actuator/mode symbols, each of tree size at most \(s\). A query is a tuple \(X=(X_1,\ldots,X_n)\) of rational \(D\times D\) matrices. The exact oracle returns `UNDEFINED` if an inverse occurrence in the supplied formula is singular; otherwise it returns the full exact rational matrix \(\Phi_j(X)\). Assume \(\Phi_0-\Phi_1\) has a nonempty common evaluation domain. This last condition matters because equivalent formulas can impose different inverse-domain restrictions.

At the pinned `openai/math` snapshot `adc7f1241b42e322a6451854ab7e4b4c146bf78a`, *Polynomial Hitting Lists for Noncommutative Rational Formulas*, Theorem 1.1, gives a deterministic generator which receives unary \((n,s)\), no formula or oracle, and emits a polynomial-bit list of rational matrix tuples. For every nonzero admissible size-\(s\) formula, some list point is defined and has an invertible value. The construction counts arbitrary inverse depth and arbitrary rational-constant height, while bounding list size, common matrix dimension, entry bit length, and total list bits by \(\operatorname{poly}(n+s)\). Applying it to \(\Phi_0-\Phi_1\), with size at most \(2s+1\), gives exact black-box equivalence testing by comparing the two oracle outputs across the list, provided both formulas share a domain. The correctness test is exact; the list-generation theorem does not bound oracle runtime or response length when coefficients have unbounded bit height.

This model has a legitimate engineering interpretation. Ball, Groenewald, and Malakorn developed realization, controllability, observability, and Hankel theory for systems evolving over a free semigroup; their transfer functions are formal series in noncommuting variables. That establishes the system class as prior mathematical control theory. It does not make arbitrary matrix tuples into ordinary physical input pulses.

There is also a direct Astra correction to the candidate's novelty boundary. Its L01 card says the release-116 theorem, plus routine truncation, already implies polynomial proper-cyclic exact learning at larger query dimension \(O(nm^5)\); the card's own increment is a compactness/query-cost accounting improvement. It records exact full-matrix-oracle costs and explicitly leaves useful physical oracle acquisition and numerical stability open. The relevant indexed full L01 proof note was absent from the pinned static tree (the earlier retrieval record reports 404), so I use the scoped card as a prior claim, not as an independently checked proof. The decisive problem below is therefore the missing noisy/physical acquisition interface, not another exact cyclic detector.

## Decisive acquisition obstruction

For alphabet size \(n\) and depth \(d\), take a hidden word \(w=(w_1,\ldots,w_d)\in[n]^d\) and define

\[
 f_w(x_1,\ldots,x_n)=x_{w_1}\cdots x_{w_d},\qquad f_0=0.
\]

The formula size is \(2d-1\), all coefficients are 0 or 1, and \(f_w\) has a minimal \((d+1)\)-state acyclic linear realization: state \(k\) advances to \(k+1\) only on the required symbol \(w_{k+1}\), and the output is one only at the terminal state. Its Hankel matrix has rank \(d+1\), witnessed by the \(d+1\) matching prefix/suffix pairs.

First consider a physical interface with resettable trials and external output only: each trial applies one ordinary symbol sequence \(v\in[n]^d\), observes the scalar output \(f(v)+Z\), and then resets. The series returns zero on every shorter prefix, so intermediate output samples do not reveal the hidden prefix. Here \(Z\sim N(0,\sigma^2)\) independently. A query to \(f_w\) has mean one exactly when \(v=w\); otherwise its mean is zero. Let \(N_w\) count how often the adaptive tester queries word \(w\), under the zero model. The Gaussian adaptive KL identity gives

\[
 D_{\rm KL}(P_0\Vert P_w)=\frac{\mathbb E_0N_w}{2\sigma^2}.
\]

If a test has both errors at most \(\delta<1/2\), binary data processing gives \(D_{\rm KL}(P_0\Vert P_w)\ge \operatorname{kl}(1-\delta,\delta)\). Summing this bound over all \(n^d\) alternatives yields

\[
\mathbb E_0[\text{number of reset runs}]
\ge 2\sigma^2 n^d\operatorname{kl}(1-\delta,\delta).
\]

Each run requires \(d\) actuator steps, so the corresponding pulse count is at least \(2d\sigma^2 n^d\operatorname{kl}(1-\delta,\delta)\). This holds even though the plant coefficients are exact 0/1 values; the observation noise gives the displayed fixed-variance factor. It blocks a polynomial-cost promise for ordinary sequence experiments without additional structure or a nonzero signal margin.

The Astra N25 attack is stronger because it grants adaptive matrix-valued queries and full matrix output. For a query dimension \(D\), impose a total-excitation cap

\[
\sum_{i=1}^n X_i^*X_i\preceq E I_D.
\]

For every such tuple,

\[
\sum_{w\in[n]^d}\|X_{w_1}\cdots X_{w_d}\|_F^2\le D E^d.
\]

To see this, sum \(X_w^*X_w\) recursively over one letter at a time and use \(\sum_iX_i^*X_i\preceq EI\) at each step, then take the trace. With independent entry noise \(N(0,\sigma^2)\), the adaptive KL chain rule, averaging over the hidden word, and binary data processing imply that any zero-versus-every-\(f_w\) test with both errors at most \(\delta\) must spend expected total query dimension \(C\) under the zero model satisfying

\[
 C\ge 2\sigma^2(n/E)^d\operatorname{kl}(1-\delta,\delta).
\]

Full matrix responses have \(D^2\ge D\) entries, so returned-entry cost is at least this large as well. At fixed \(n\ge2\), fixed \(E=1\), and fixed noise/error levels, the bound is exponential in realization depth \(d=r-1\), despite the 0/1 coefficients. If only individual bounds \(\|X_i\|\le1\) are charged, then \(E=n\) is allowed and this argument no longer gives an exponential lower bound; the total excitation charge is essential. This is not a refutation of the exact hitting-list theorem. It is a direct obstruction to upgrading that theorem uniformly to a noisy, energy-bounded acquisition protocol.

The second bound is recorded in the Astra N25 card and detailed in the prior workspace's `COMPILER_PROOF.md`; I reconstructed the word-energy and KL steps above. Astra marks N25 `source_derived_unreviewed`, so it is internal evidence, not external proof validation.

## Full cost contract and boundary

The exact release theorem charges unary \((n,s)\), polynomial bit operations to generate the whole list, polynomial total query-description bits, and polynomial dimension/entry bit lengths. An engineering test must additionally charge every oracle call, each full \(D\times D\) response, exact or finite-precision output, physical actuator energy, reset/recovery time, and model-evaluation time. Those latter costs are not bounded by the release theorem. Arbitrary rational constant heights also prevent a uniform finite-precision gap; the signal can be much smaller than one ulp even at formula size one.

The high-ceiling theorem target left open is therefore specific: characterize the minimax experiment cost for distinguishing stable noncommutative rational transfer systems under (a) a physically realizable query map from control pulses to matrix tuples, (b) a total-energy budget, (c) a supplied or safely acquired singular-value/stability margin, (d) a stated response-noise model, and (e) an explicit structural restriction on the model/query class. A useful positive theorem would give an algorithm with dependence on these quantities and match it to a lower bound; a useful negative theorem would show which dependence is unavoidable. The hidden-word family falsifies any bound polynomial only in formula size, state dimension, and alphabet size when energy remains O(1). For ordinary scalar experiments, the target still requires a restriction excluding that family or an experimentally available superposition interface: its scalar signal gap is already one, yet the number of possible words is exponential. The optimal bound after those restrictions are supplied remains open.

## Prior-art and novelty attack

The broad claim “noncommutative rational series are a new model for engineering” is preempted by Ball–Groenewald–Malakorn's established free-semigroup system and realization theory. Bounded-energy input design for system identification is also established: Manchester's 2010 paper optimizes Fisher information under input-amplitude/power constraints. In algebra, Arvind–Chatterjee–Mukhopadhyay already give deterministic quasipolynomial black-box tests for arbitrary-inversion-height rational formulas, and Derksen–Makam give randomized polynomial-time rational identity testing; the pinned OpenAI manuscript supplies a stronger polynomial-bit deterministic list for its exact rational-matrix interface. The result here is not a new identity-testing theorem. The useful engineering question is precisely where exact matrix queries cease to correspond to safe, finite-energy plant experiments.

**Decision:** reject the direct engineering transfer as a frontier advance. Keep the constrained minimax problem as a target only if a concrete actuator/query map, excluded hard-family structure, and matched input-design baseline can be specified. The next decisive falsifier for any claimed polynomial noisy upgrade is the hidden-word family above at fixed total excitation. A claimed algorithm must exhibit its query tuples and costs on that family and meet the lower bound.

## Evidence and sources

- Astra snapshot `8ede33c2f09a8abe07b430892b3ac4bb71c27c83`: acquisition index routes to `L01-cyclic-grid`; methods index routes to `N25-acquisition-interface-tests`; blocker `B-EXACT-ORACLE-INTERFACE` states the mismatch between exact full-matrix and noisy total-excitation interfaces. N25 card states the hidden-word bound. Detailed local proof range: `work/agents/learning_acquisition/children/exact_noisy_oracles/COMPILER_PROOF.md`, lines 81–96. These are source-derived/internal records and have not received external specialist review.
- Astra L01 card, `work/agents/measurement_inverse/active_observability/L01-cyclic-grid.txt`, lines 1–15: exact full-output cyclic detector/learner, release-116 truncation correction, charged queries, and acquisition/stability limits. The indexed full proof note could not be loaded from the pinned tree, so no stronger proof status is claimed.
- OpenAI, *Polynomial Hitting Lists for Noncommutative Rational Formulas*, pinned release commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`, Theorem 1.1 and §§4–5.1–5.3 (exact formula domains, list construction, and quantitative bounds): [pinned manuscript](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026.pdf).
- Ball, Groenewald, and Malakorn, *Structured Noncommutative Multidimensional Linear Systems*, SIAM Journal on Control and Optimization, DOI [10.1137/S0363012904443750](https://doi.org/10.1137/S0363012904443750): free-semigroup systems, realization, controllability/observability, and Hankel theory.
- Manchester, *Input Design for System Identification via Convex Relaxation*, arXiv [1009.5614](https://arxiv.org/abs/1009.5614): Fisher-information design with input amplitude and power constraints.
- Arvind, Chatterjee, and Mukhopadhyay, *Black-Box Identity Testing of Noncommutative Rational Formulas in Deterministic Quasipolynomial Time*, arXiv [2309.15647v4](https://arxiv.org/abs/2309.15647v4): deterministic quasipolynomial prior art for rational formulas of arbitrary inversion height; its introduction summarizes randomized polynomial-time rational identity testing via Derksen–Makam.
- Workspace engineering anchor, [current engineering report](../../../../outputs/research/cycle_checkpoint_02/evidence/engineering_control/FINAL_REPORT.md): directed finite-volume safety and safe adaptive-LQR remain distinct active lines; neither gives the noisy noncommutative query bridge considered here.
