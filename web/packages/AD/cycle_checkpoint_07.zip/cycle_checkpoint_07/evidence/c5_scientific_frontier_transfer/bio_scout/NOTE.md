# Biological scout: identify TCR proofreading architecture

## Verdict

The strongest distinct cell target I found is resolving whether single T-cell receptors integrate parallel ITAM reaction threads at LAT-condensation firing, as proposed by Morita and Groves, or whether the same measured behavior can come from an effective sequential/recycling pathway. This is a high-ceiling experimental target because it concerns the physical source of antigen discrimination and may affect receptor engineering. I do **not** have a new theorem or a priority claim: the exact mathematical obstruction below is a concrete instance of established phase-type non-identifiability, and the architecture question is already explicit in 2025 primary literature.

The existing cycle-2 anchors cover scalar CTMC information limits, serial reset tradeoffs, and which output statistic is scored; there is also an adjacent kinetic-proofreading lane. None resolves the joint internal architecture of ITAM phosphorylation and LAT firing. This scout therefore rejects the claim that more precise activation-time/FPT data alone can settle that architecture, while recording the smallest extra observable that separates a model pair.

## Exact observation contract and counterexample

Consider one receptor episode with an initially unmodified receptor, two transient phosphorylation states, and one absorbing activation event. The oracle returns the exact activation-time law, or equivalently any number of independent activation times with exact timestamps. It may also report whether activation occurred before an independent exponential ligand-unbinding clock of rate \(\delta\). The interventions supplied to the oracle are ligand dwell/off-rate settings; transient states are hidden.

Model A is a sequential two-checkpoint mechanism:

\[
\alpha_A=(1,0),\qquad T_A=\begin{pmatrix}-3&1\\0&-1\end{pmatrix},\qquad r_A=-T_A\mathbf 1=\begin{pmatrix}2\\1\end{pmatrix}.
\]

Thus state 1 advances to state 2 at rate 1 and activates at rate 2; state 2 activates at rate 1. Model B is a recycling pathway:

\[
S=\begin{pmatrix}1&0\\1/4&3/4\end{pmatrix},\quad
T_B=S^{-1}T_AS=\begin{pmatrix}-11/4&3/4\\7/12&-5/4\end{pmatrix},\quad
\alpha_B=\alpha_AS=(1,0),\quad
r_B=S^{-1}r_A=\begin{pmatrix}2\\2/3\end{pmatrix}.
\]

Every off-diagonal and absorption rate is positive in both models, and \(T_i\mathbf 1+r_i=0\); both are valid transient CTMCs with the same known initial state. A has no reverse transition; B has a positive state-2-to-state-1 transition.

Similarity gives, for every \(t\ge0\),

\[
\alpha_B e^{T_Bt}r_B=\alpha_A e^{T_At}r_A
=\tfrac32 e^{-3t}+\tfrac12e^{-t}.
\]

Consequently the entire activation-time distribution is identical, even with infinite noiseless observations. For every exponential ligand off-rate \(\delta\ge0\), both predict the same activation-before-unbinding probability

\[
\Pr(T_{act}<T_{off})=\int_0^\infty e^{-\delta t}\,dF(t)
=\frac{3/2}{\delta+3}+\frac{1/2}{\delta+1}.
\]

Thus no estimator using only those outputs can identify which of these two valid mechanisms generated them; under equal prior weight its minimax architecture-classification error is \(1/2\), regardless of sample count or timestamp precision. This is structural non-identifiability, separate from the stochastic-sample information bounds in the Astra N25 card.

One additional labeled intermediate-state occupancy separates this pair. At time \(t\),

\[
\Pr_A(X_t=2)=\tfrac12(e^{-t}-e^{-3t}),\qquad
\Pr_B(X_t=2)=\tfrac34\Pr_A(X_t=2).
\]

At \(t=\tfrac12\log 3\), the occupancy gap is exactly \(1/(12\sqrt3)\approx0.0481\). Under the illustrative pair's known rates and an ideal calibrated binary phase-state readout, a midpoint test needs \(n\ge2\log(20)/\Delta^2=2589\) independent receptor episodes for a one-sided Hoeffding error bound of 0.05, where \(\Delta=1/(12\sqrt3)\). This is a model-only design calculation, not a measured T-cell effect or experimental sample-size recommendation. The pair is not the Morita–Groves multithread model and provides no evidence that a real TCR has the displayed reverse transition. A concrete architecture test would acquire per-ITAM/ZAP70 intermediate-state signals and LAT-condensation timing on the same receptor episodes, with controlled pMHC dwell-time, ligand-density, and ITAM-count perturbations. Fit on one set of dwell times, then compare the best parameter-matched sequential and multithread models on held-out dwell times and the joint intermediate/output records. Charge receptor episodes, imaging/photophysics, reporter calibration, pMHC calibration, failed tracks, cell/donor replication, and model fitting. Biological sample size and monetary cost remain `UNKNOWN` until a pilot supplies event-rate, readout-error, and clustering data.

## Why the algebraic-release route does not solve this target

OpenAI/math at `adc7f1241b42e322a6451854ab7e4b4c146bf78a`, *Polynomial Hitting Lists for Noncommutative Rational Formulas*, Theorem 1.1 (PDF p. 1), takes only unary alphabet and formula-size bounds and generates a polynomial-bit list of rational matrix tuples. For every nonzero admissible rational formula of the promised size, some tuple gives a defined invertible value. Its query semantics are arbitrary exact rational matrices, and every inverse in the expression tree must be defined. The theorem does not give a map from those matrices to nonnegative receptor rates, single-molecule readouts, a noisy assay, or fitted cell parameters. The release's universal exact-matrix hit is therefore not an architecture-identification oracle.

The pinned Astra route `agent/topics/acquisition.tsv` → N25, plus blocker entry lines 274–295, explicitly separates exact full-matrix access from noisy adaptive matrix queries. N25's supplied proof at `web/pages/d-5ad21eeb8590ce66.html`, lines 63–109, proves a bounded-excitation cost for a specific oracle: if an unknown word of length \(d\) over \(n\) symbols is the only nonzero target, full matrix outputs have independent Gaussian entry noise \(\sigma^2\), queries obey \(\sum_iX_i^*X_i\preceq EI\), and expected total query dimension under the zero target is \(C\), then error at most \(\epsilon<1/2\) in both cases requires

\[
C\ge 2\sigma^2(n/E)^d\operatorname{kl}(1-\epsilon,\epsilon).
\]

This reinforces that a high-order matrix probe's excitation and readout costs must be charged. It is **not** a biological lower bound: the cell assay above has scalar event-time/state observations, not the N25 full-matrix oracle, and N25 does not refute exact L01 learning.

## Prior-art attack and status

Morita and Groves (PNAS 2025, DOI 10.1073/pnas.2514057122) explicitly compare sequential proofreading with parallel ITAM threads integrated at LAT condensation and reinterpret previous affinity–potency, delay, and ITAM-mutant data under the multithread model. Their article presents a model-based mechanism, not a direct joint-state architecture-resolution experiment. Voisinne et al. (Nature Immunology 2022, DOI 10.1038/s41590-022-01288-x) already acquired time-resolved proteomics/interactomics across ligand affinities, with differential ZAP70 activation and LAT versus CD6 signalosome effects. Li and Chou (PLOS Computational Biology 2024, DOI 10.1371/journal.pcbi.1012183) show that conclusions depend on whether ligand discrimination is scored by first-passage time or product counting. These sources make the proposed target biologically real while ruling out a novelty claim for generic kinetic-proofreading, output-statistic, or sequential-versus-parallel modeling.

The exact representation ambiguity is established phase-type prior art. Lindqvist's 2023 review of phase-type competing-risk models states the Telek–Horváth result: two nonredundant equal-dimensional representations have the same absorption law iff they are related by a nonsingular similarity \(B\) with \(B\mathbf1=\mathbf1\), alongside the corresponding initial-vector and generator transforms. The matrices above are an explicit all-positive kinetic witness. Novelty of this particular instantiation is `UNKNOWN` and should be treated as none unless a focused priority review establishes otherwise.

**Decisive next gate:** establish whether a feasible same-receptor assay can jointly resolve ITAM-specific intermediate states and LAT-condensation times under randomized, dwell-time-controlled ligand encounters, then test withheld affinity and ITAM-mutant conditions against parameter-matched models. If only aggregate activation/FPT data are available, stop claiming architecture identification. This is a research target, not a biological conclusion or treatment recommendation.
