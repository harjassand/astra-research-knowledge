# Source and route notes

## Task inputs

- Read `work/ROOT_MANDATE.txt`, `outputs/research/CURRENT_STATE.txt`, and `work/astra_prior/{00_START_HERE.txt,01_CORE.txt,RESEARCH_WORKFLOW.txt,AGENTS.md}`.
- The current-state biological anchors include finite-state cell reach–avoid control, lineage branching, endpoint aliasing, causal transport, aging-memory observability, cancer measurement starvation, and kinetic-proofreading/immune-memory work. Relevant detailed local reports inspected: `outputs/research/cycle_checkpoint_02/evidence/cell_control/cell_controllability/FINAL_REPORT.md`, `cell_metastability/FINAL_REPORT.md`, `cell_observation_design/FINAL_REPORT.md`, `cell_causal_transport/FINAL_REPORT.md`, `cell_aging_memory/FINAL_REPORT.md`, and `outputs/research/cycle_checkpoint_02/evidence/immunology/kinetic_proofreading/FINAL_REPORT.md`.

## Astra route at pinned commit

- Pin: `8ede33c2f09a8abe07b430892b3ac4bb71c27c83`; `tree.json` treated as path-only.
- `agent/topics/acquisition.tsv:30` routes to N25 `cards/N25-acquisition-interface-tests.txt`; card lines 1–10 record the exact lower-bound interface, scope warning, status, and source IDs. `indexes/blockers.json:268–303` states that exact full-matrix and noisy adaptive matrix guarantees cannot be transferred across oracle, query, or acquisition models; N25 explicitly does not refute L01 exact-oracle learning.
- Full supplied source record was inspected through `web/pages/d-5ad21eeb8590ce66.html`, proof/attack lines 63–109. Lines 66–93 state the adaptive Gaussian full-matrix lower bound and proof; lines 94–109 give its scalar controlled-chain interpretation, coordinate-blocking positive repair, and fatal scope checks. The source package labels the candidate internally audited/source-derived but externally unreviewed; it is not used as a biological theorem premise here.
- Astra’s N51 universal integer rational-formula list was consulted as a related acquisition mechanism. Its pinned card URL is `https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/N51-universal-integer-hitting.txt`. It is likewise an unreviewed source-derived candidate and does not supply physical receptor tuples.

## OpenAI math release at pinned commit

- Pinned PDF: `https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026.pdf`.
- Read Theorem 1.1 and definitions on PDF p. 1, prior-art/interface discussion on p. 2, and the rational representation/list construction at §§5.1–5.3 (PDF pp. 16–21). It is an exact rational-matrix hitting-list theorem for an unknown noncommutative rational formula with unary variable/formula-size bounds; arbitrary rational matrix substitutions and full exact formula evaluation are supplied interfaces. No inference to cellular observability, physical actuation, or noise is valid without an explicit bridge.

## Primary biological literature

- Morita S, Groves JT. “Parallel reactions on a single T cell receptor offer a robust kinetic proofreading mechanism.” PNAS 2025;122(40):e2514057122. DOI `10.1073/pnas.2514057122`; PubMed PMID 41021801. PubMed abstract lines 242–246 state the sequential/parallel ITAM/LAT contrast and reanalysis of prior observations. Figure captions at lines 300–322 document reinterpreted affinity–potency, delay, and ITAM-mutant data. These are model fits/reinterpretations, not a newly performed direct joint-state architecture measurement.
- Voisinne G et al. “Kinetic proofreading through the multi-step activation of the ZAP70 kinase underlies early T cell ligand discrimination.” Nature Immunology 2022;23:1355–1364. DOI `10.1038/s41590-022-01288-x`. Search/opened primary article record describes time-resolved proteomics/interactomics across ligands and the differential ZAP70/LAT/CD6 results. This establishes an existing molecular measurement channel and narrows novelty.
- Li X, Chou T. “Reliable ligand discrimination in stochastic multistep kinetic proofreading: First passage time vs. product counting strategies.” PLOS Computational Biology 2024;20(6):e1012183. DOI `10.1371/journal.pcbi.1012183`; PubMed PMID 38857304. The primary abstract states that information-extraction strategy changes the performance conclusion.
- Lindqvist BH. “Phase-type models for competing risks, with emphasis on identifiability issues.” Lifetime Data Analysis (2023), PMCID PMC10006281. Theorem 1 quotes Telek–Horváth’s same-dimensional similarity characterization; Example 2 gives another positive Markov representation ambiguity. This preempts a novelty claim for the abstract similarity mechanism.

## Local bounded check

`exact_alias_check.py` checks the displayed rational similarities, generator row sums, equal Laplace transforms for arbitrary symbolic off-rate, and the intermediate-state occupancy gap using exact rational/symbolic arithmetic. `CHECK_OUTPUT.json` is only a finite symbolic-algebra diagnostic; the equality for all time follows from the explicit similarity identity in `NOTE.md`, and no biological model fit is validated.
