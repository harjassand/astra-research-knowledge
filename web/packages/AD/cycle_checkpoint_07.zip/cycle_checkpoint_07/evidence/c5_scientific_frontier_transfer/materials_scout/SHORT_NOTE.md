# Materials scout: phase-sensitive calibration at coexistence

## Verdict

**High-ceiling target:** obtain local Gibbs-prediction guarantees for calibrated interacting materials from *acquired phase-stability information* (for example a local susceptibility / correlation-sum bound), rather than from a global Hamiltonian norm alone. The unconditional version is false even in a finite-range, exactly specified magnetic model. The counterexample below is a source-level corollary of rigorous finite-size scaling, not a new theorem or priority claim.

This is beyond the existing materials anchors: the prior many-body line has a global exponent-norm calibration budget, while its N90/N97 algorithms assume a supplied model/gap. The current report explicitly leaves local stability under locality or clustering hypotheses unresolved. The Ising construction shows that this gap is real at phase coexistence, and quantifies how much field calibration is needed.

## Exact model, input, and counterexample

Let \(\Lambda_L=(\mathbb Z/L\mathbb Z)^2\), \(N=L^2\), with spins \(\sigma_x\in\{-1,+1\}\). Use the dimensionless finite-volume Gibbs weight

\[
\mu_{L,s}(\sigma)=Z_{L,s}^{-1}\exp\{K\sum_{\langle x,y\rangle}\sigma_x\sigma_y+s\sum_x\sigma_x\},
\]

where \(K\) is fixed sufficiently deep in the low-temperature regime for the Borgs–Kotecký contour hypotheses, and \(s=\beta h\) is the dimensionless uniform magnetic field. Boundary conditions are periodic. The acquisition oracle supplies \(L,K\), the graph, and only the interval \(s\in[-c/N,c/N]\), for a fixed \(c>0\); it does not reveal the true field within that interval. The target is the one-site marginal at a specified site, measured by \(\sigma_0\). Costs are the precision and number of acquired field parameters plus independent equilibrium snapshots; the oracle supplies no equilibration guarantee.

Write \(m_*=(m_+-m_-)/2>0\) for the spontaneous-magnetization jump at zero field. For the square-lattice Ising normalization above, Yang gives \(m_*(K)=[1-\sinh^{-4}(2K)]^{1/8}\) when \(K>K_c=\tfrac12\log(1+\sqrt2)\); choose \(K\) also deep enough for the cited finite-size theorem. Borgs–Kotecký's periodic finite-size scaling theorem says that, for the class above,

\[
\mathbb E_{\mu_{L,s}}[N^{-1}\sum_x\sigma_x]
 =m_{\rm per}(0)+m_*\tanh(m_*N s)+o(1)
\]

on the \(Ns=O(1)\) window. Spin-flip symmetry gives \(m_{\rm per}(0)=0\), and \(m_-=-m_+\). Consequently, at the two indistinguishable oracle-compatible inputs \(s_\pm=\pm c/N\), the one-site means are

\[
\mathbb E_{\mu_{L,s_\pm}}\sigma_0=\pm a_c+o(1),\qquad a_c=m_*\tanh(m_*c)>0.
\]

The one-site total-variation distance is therefore \(a_c+o(1)\). Any predictor receiving only the shared interval and nominal field zero has worst-case one-site TV error at least \(a_c/2-o(1)\). Thus a per-site coefficient uncertainty shrinking as \(1/N\) does **not** guarantee even a vanishing local-state error. To force error \(\varepsilon\) near coexistence, the same finite-size formula requires resolving the uniform dimensionless field to order \(\varepsilon/N\) (up to constants depending on \(m_*\)); for \(N\) independently calibrated site fields with adversarial coherent error, this is \(N\) fields at that precision.

This is an equilibrium statement. Estimating the local mean from independent equilibrium spin-readout shots costs \(O(a_c^{-2}\log(1/\delta))\) samples by Hoeffding. It does not charge preparing those samples: phase-switching/autocorrelation can be exponentially costly in \(L\), and must be measured or supplied for a physical protocol. The strongest matched control is the same periodic sample, temperature, and readout at fields \(0\) and \(\pm c/N\), with equal numbers of independently equilibrated snapshots.

## Relation to repository evidence and the pinned release

- Astra routes `work/astra_prior/agent/topics/analysis.tsv` (N52 at line 21) and `probability.tsv` (N52 at line 47) point to card `work/agents/materials_energy/manybody_certification/astra/cards__N52-gibbs-L2-continuity.txt` and proof `work/agents/materials_energy/manybody_certification/astra/source_pages/d-59494d4a5536a65a.txt` (especially §§1–4 and 6). This is an internally audited, source-derived proof candidate, not external validation. It gives a dimension-uniform quantum/classical Gibbs continuity bound in terms of the *reference-weighted* perturbation \(\epsilon=\operatorname{Tr}(\omega(A-B)^2)\). Here \(D=s\sum_x\sigma_x\), and coexistence gives \(\mathbb E_{\mu_{L,0}}[(\sum_x\sigma_x)^2]\asymp m_*^2N^2\). With \(s=c/N\), \(\epsilon\asymp c^2m_*^2\), not \(o(1)\): the Astra interface also correctly does not promise stability from a merely vanishing per-site error.
- Astra `work/agents/materials_energy/manybody_certification/astra/quantum.tsv` and card `work/agents/materials_energy/manybody_certification/astra/cards__N90-easy-plane-spin-counting.txt` describe a conditional easy-plane XXZ thermal algorithm; proof package `source_pages/d-ce937933a41ab095.txt` (§§1–3) records its scope. N97 card `work/agents/materials_energy/manybody_certification/astra/cards__N97-relative-renyi-groundspace.txt` separately requires a supplied gap for its global groundspace route. Neither acquires phase selection/calibration for a material. Their source and algorithm status remains conditional/unreviewed as recorded in those cards.
- Pinned OpenAI/math commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`, family 093, states a dimension-free logarithmic-Sobolev inequality for centered log-concave densities with uniformly subgaussian linear marginals (constant bounded by a universal multiple of the squared subgaussian parameter). This source-reported, not independently proof-verified result offers a useful single-convex-phase comparison mechanism, but it does not apply to the finite, bimodal low-temperature Ising spin law and cannot bridge this coexistence example. Source: `preprints/A-dimension-free-logarithmic-Sobolev-inequality-for-subgaussian-log-concave-measures-September-23-2026/paper.pdf`; pinned catalog statement is `overview.tex`, family 093.

## Prior-art attack and next theorem gate

The decisive prior art is Borgs & Kotecký, *A Rigorous Theory of Finite-Size Scaling at First-Order Phase Transitions*, J. Stat. Phys. 61 (1990), 79–119, DOI 10.1007/BF01013955: its periodic-boundary theorem gives the \(N(h-h_t)\) hyperbolic-tangent crossover. The low-temperature square-lattice Ising order parameter is positive (Yang, *Phys. Rev.* 85 (1952), 808–816, DOI 10.1103/PhysRev.85.808). This fully preempts novelty for the counterexample mechanism; our deduction only translates it into a calibration lower bound for the local-marginal prediction interface.

The worthwhile open target is therefore a **conditional** materials theorem: under a supplied/acquired bound on the integrated influence of local coefficient errors on a selected local observable (e.g. a uniform covariance/Duhamel correlation sum along the calibration path), give a finite-volume TV or observable-error bound with local rather than global precision scaling, and show how the influence bound is acquired from named response measurements. Standard linear response and Dobrushin/cluster-expansion work are strong prior art; no novelty is claimed here. The decisive nature test is a named finite magnetic material with field-calibration intervals and an independent susceptibility/correlation measurement. A failed mixing/influence certificate rejects the robust-prediction route; one must retain explicit phase uncertainty rather than report a single local Gibbs prediction.

### Status ledger

- Exact finite model/interface: internally reconstructed source consequence.
- Finite-size scaling input and Ising order parameter: established primary-source results, not replayed here.
- Material mapping, actual equilibration, calibration, and priority: `UNKNOWN`.
- Falsifier of this transfer: a mismatch between the stated model normalization and the Borgs–Kotecký theorem's field convention, or failure of the theorem's low-temperature contour assumptions for the chosen parameter range. No physical-system claim follows automatically.
