# Cycle 7 failure and unresolved gates

## What the transferred proof does not establish

The derived theorem bounds the mass outside the maximal-spin ground multiplet. Its sufficient inverse temperature grows as

\[
\beta J_-\ge\frac{6L^2}{S}\log\!\left(\frac{2L^3}{\log(1+r)}\right).
\]

This yields a rigorous finite-size one-axis law at radius \(S\) only when temperature is driven to zero jointly with specimen growth. It is not a bound at fixed \(\beta\) and cannot replace

\[
W_1\bigl(\mathcal L(M^3/V),\operatorname{Unif}[-m_{\beta,J},m_{\beta,J}]\bigr)\le r_{S,\beta,J}(L).
\]

The needed family-271 gates remain the finite-torus local-marginal modulus \(\delta_{\rm loc}(L,R_*)\), and a numerical small-field secant modulus \(h_\epsilon\). The cited anisotropic Bloch asymptotic gives an ordered-limit leading low-temperature deficit, not either modulus.

## Why the direct source mechanism stalls

CGS Proposition 5.2 supplies a full-box spectral inequality with coefficient of order \(L^{-2}\). At fixed temperature, combining it with an \(O(V)\) thermal energy bound yields at best

\[
\mathbb E[(SV-J^T)/V]\le O(L^2),
\]

which does not tend to zero. Even granting a low-temperature energy-density scale \(O(\beta^{-5/2})\), the estimate is \(O(L^2\beta^{-5/2})\), not the desired fixed-\(\beta\) thermodynamic deficit. Applying the same proposition to blocks of side \(\ell\approx\sqrt\beta\) gives a local-block deficit of order \(\beta^{-3/2}\), but says nothing about the relative orientations of those blocks. The spherical-law manuscript controls these via multiscale partitions and a pressure-tangent argument; its compactness passage to the finite-torus block observable remains qualitative.

The CGS boson trace estimate is likewise not the missing theorem: it controls the low-temperature free energy after a low-energy cutoff and estimates interactions through a two-particle density. It does not bound the finite-volume distribution of \(J^T/V\) uniformly in \(L\) at fixed \(\beta\). The exact one-magnon band shows that \(\Pr(J^T=SV)\to0\) at fixed \(\beta\), so any useful fixed-temperature proof must retain a nonzero spin-wave density rather than force the ground multiplet.

## Exact counterexample to an invalid shortcut

A two-domain coherent product state has \(O(L^{-1})\) energy density but only \(O(V^{-1/2})\) normalized total spin. Its global SU(2) average preserves both facts. This refutes the inference from “low energy density + local block order + rotation invariance” to “macroscopic total-spin radius.” It is not a Gibbs state and does not refute the periodic finite-temperature theorem; the Gibbs-specific orientation-alignment argument is still necessary.

## External falsifiers and costs

- If exact finite-torus diagonalization for small \(L,S\) violates the sector inequality or the tail, the corollary is wrong; the present finite code checks do not rule this out for all sizes.
- If independent review finds a missing multiplicity, ground-degeneracy, or path-load factor, revise the cooling schedule before reuse.
- For \(S=1/2,J_-=1,L=64,r=1/V\), the sufficient bound is \(\beta J_-\ge1.26\times10^6\). Even with an ideal global readout, radius sampling error \(\eta=0.01\) at 95% confidence requires about 18,445 independent equilibrated specimens. No preparation time, autocorrelation, field residual, parameter calibration, or real-material nonexchange error is included.
- A fixed-\(\beta\) experiment that departs from \(\operatorname{Unif}[-m_{\beta,J},m_{\beta,J}]\) would test the underlying model law only after surface terms, field, domains, spin-orbit terms, and dipolar interactions are controlled. The current result makes no prediction for a named material.

## Next decisive theorem

Prove or refute a quantitative finite-torus low-temperature spin-wave-density statement that controls

\[
\mathbb E[(SV-J^T)/V]-(S-m_{\beta,J})
\]

uniformly over sufficiently large \(L\) at fixed \(\beta\), with explicit dependence on \(S,\beta,J_i\). A viable proof likely needs a finite-size interacting spin-wave mode count plus a Gibbs-specific multiscale estimate for block-orientation alignment. If that estimate cannot be extracted, the finite-temperature specimen budget remains **UNKNOWN**; do not substitute the extreme-cooling ground-state schedule.
