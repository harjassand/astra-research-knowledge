# Weighted-torus low-temperature finite-volume corollary

## Statement and exact interface

Fix a spin (S\in\{1/2,1,3/2,\ldots\}), an even side length (L\ge4), and three strictly positive spatial exchange constants (J_1,J_2,J_3). Let (V=L^3), use the periodic cubic graph, count each positive-coordinate bond once, and set

\[
H_L=-\sum_{x\in(\mathbb Z/L\mathbb Z)^3}\sum_{i=1}^3J_i\,\mathbf S_x\cdot\mathbf S_{x+e_i},\qquad
K_L=\sum_{x,i}J_i(S^2I-\mathbf S_x\cdot\mathbf S_{x+e_i}).
\]

The two Hamiltonians differ by the scalar (S^2V(J_1+J_2+J_3)), so they define the same Gibbs state. Write (J_-:=\min_iJ_i), (J^T:=|\sum_x\mathbf S_x|), and (d:=SV-J^T\in\{0,1,\ldots,SV\}). Because (L) is even, (SV) and all possible (J^T) are integers. The state is exactly invariant under global SU(2); there is no field or boundary pin.

The derived finite-volume result is

\[
K_L\big|_{J^T=SV-d}\ \ge\ a_Ld,\qquad a_L:=\frac{S J_-}{6L^2}.
\tag{1}
\]

Let (Z_0=2SV+1) be the ground-multiplet trace and (Z_{\rm ex}) the trace over every lower-total-spin sector. For (0<r\le1), a sufficient cooling condition is

\[
\beta\ \ge\ \frac{6L^2}{S J_-}\log\!\left(\frac{2V}{\log(1+r)}\right).
\tag{2}
\]

It implies

\[
\frac{Z_{\rm ex}}{Z_0}\le r,\qquad
\Pr_\beta(J^T<SV)\le\frac{r}{1+r},\qquad
\mathbb E_\beta\frac{SV-J^T}{V}\le\frac{Sr}{1+r}.
\tag{3}
\]

For the one-axis measurement (X=M^3/V\in[-S,S]), with (M^3=\sum_x S_x^3), the resulting law obeys

\[
W_1\!\left(\mathcal L_\beta(X),\operatorname{Unif}[-S,S]\right)
\le \frac{1}{3V}+\frac{S}{2}\frac{r}{1+r},
\tag{4}
\]

and

\[
\left|\mathbb E_\beta X^2-\frac{S^2}{3}\right|
\le \frac{S}{3V}+\frac{2S^2}{3}\frac{r}{1+r}.
\tag{5}
\]

The radius estimator from (R) independent zero-field equilibrium measurements,

\[
\widehat S_R=\frac{2}{R}\sum_{q=1}^{R}|X_q|,
\]

has absolute bias at most

\[
\left|\mathbb E\widehat S_R-S\right|
\le \frac{1}{2V}+S\frac{r}{1+r}.
\tag{6}
\]

Its sampling error is at most (\eta) with probability at least (1-\delta) if

\[
R\ge\frac{2S^2}{\eta^2}\log\frac{2}{\delta},
\tag{7}
\]

by Hoeffding, since each (2|X_q|\in[0,2S]). A collective-axis readout costs (R) specimen runs; reconstructing each moment by local readouts costs (RV) single-site spin records. The theorem does not provide a thermalization time or produce independent Gibbs samples.

If one additionally imports the family-271 anisotropic Bloch-law source claim that (m_{\beta,J}\to S) as \(\beta\to\infty), then for its pressure magnetization

\[
W_1\!\left(\mathcal L_\beta(M^3/V),\operatorname{Unif}[-m_{\beta,J},m_{\beta,J}]\right)
\le \frac{1}{3V}+\frac{S r}{2(1+r)}+\frac{S-m_{\beta,J}}{2}.
\tag{8}
\]

Along any schedule with (V\to\infty), (r\to0), and (2), the first two terms are explicit and the last tends to zero by that imported low-temperature limit. Its finite-β threshold/remainder is unavailable, so (8) is an asymptotic bridge, not a specimen-size certificate to the finite-temperature radius.

## Proof of the sector bound

Use the positive bond operator (Q_{xy}:=S^2I-\mathbf S_x\cdot\mathbf S_y\). Correggi–Giuliani–Seiringer (CGS), Prop. 5.2, prove the local three-spin inequality

\[
Q_{xy}+Q_{yz}\ge\tfrac12Q_{xz}
\tag{8}
\]

for distinct sites, and derive from it their path inequality (their Eqs. (5.9)–(5.10)): for a simple path \(\gamma=(x=x_0,\ldots,x_n=y)\),

\[
Q_{xy}\le2n\sum_{j=1}^nQ_{x_{j-1}x_j}.
\tag{9}
\]

The local inequality follows by putting (A=\mathbf S_x+\mathbf S_z), decomposing into its spin-(t) sectors, and bounding 
\(-\mathbf S_y\cdot A\ge-St\). The resulting scalar lower bound is

\[
S^2-\frac S2-St+\frac{t(t+1)}4
=\frac14(2S-t)(2S-t-1)\ge0,
\]

because (t\in\{0,1,\ldots,2S\}). The iteration to (9) is the CGS path lemma. Their source argument is on open cubes; the local inequality is independent of boundary condition and of the exchange weights.

For each ordered pair (x\ne y) on the periodic torus, route coordinates in order (1,2,3) along a shortest signed arc, choosing the positive direction at a tie. The path is simple and has length (n\le3L/2). For a fixed directed edge in coordinate (i), the pair of endpoint coordinates ((x_i,y_i)) has at most (L^2) choices. The other two axes each contribute exactly at most (L) choices: before axis (i), the target coordinate is fixed by the edge and the starting coordinate is arbitrary; after axis (i), the starting coordinate is fixed and the target is arbitrary. Thus at most (L^4) ordered-pair paths use any fixed directed edge. Summing (9), using the maximum path length and then pairing the two orientations of each undirected edge, gives

\[
\sum_{x\ne y}Q_{xy}
\le 3L\cdot L^4\sum_{\text{directed }e}Q_e
=6L^5\sum_{\text{undirected }e}Q_e.
\tag{10}
\]

On the total-spin-(J^T) sector, SU(2) addition gives the exact scalar identity

\[
\sum_{x\ne y}Q_{xy}
=SV(SV+1)-J^T(J^T+1)
=(SV-J^T)(SV+J^T+1)\ge SVd.
\tag{11}
\]

Since (K_L\ge J_-\sum_{\text{undirected }e}Q_e), (10)–(11) imply (1). In particular the zero-energy space is exactly the single maximal-spin irrep, with dimension (Z_0=2SV+1); no separate ferromagnetic ground-state theorem is needed for this conclusion.

## Sector count and Gibbs tail

Let (a_d=[z^d](1+z+\cdots+z^{2S})^V). This is the dimension of the (M^3=SV-d) weight space. If (g_d) denotes the number of spin-(SV-d) irreducible representations, SU(2) weight counting gives (a_d=\sum_{j=0}^d g_j), so (g_d=a_d-a_{d-1}\le a_d). Each such irrep has dimension (2(SV-d)+1\le2SV+1). Applying (1) to every eigenvalue in the sector,

\[
\frac{Z_{\rm ex}}{Z_0}
\le\sum_{d=1}^{SV}g_de^{-\beta a_Ld}
\le\sum_{d\ge1}a_dq^d
=\left(1+q+\cdots+q^{2S}\right)^V-1,
\quad q=e^{-\beta a_L}.
\tag{12}
\]

For (0<q\le1/2), (1+q+\cdots+q^{2S}\le(1-q)^{-1}) and (-\log(1-q)\le2q). Condition (2) makes (q\le\log(1+r)/(2V)\le1/2), hence the right side of (12) is at most (e^{2Vq}-1\le r). This proves (3).

## SU(2) phase mixing and observable conversion

In each spin-(J) irreducible representation, any SU(2)-invariant density matrix is scalar on the magnetic quantum number (m=-J,-J+1,\ldots,J). Thus, conditional on (J^T=J), (X) is uniform on the grid 

\[
\{-J/V,(-J+1)/V,\ldots,J/V\}.
\]

For (J\ge1), direct integration of the one-dimensional CDFs gives the grid-to-continuous error

\[
W_1\bigl(\text{grid}_J,\operatorname{Unif}[-J/V,J/V]\bigr)
=\frac1V\frac{4J+1}{6(2J+1)}\le\frac1{3V};
\]

for (J=0), the error is zero. The continuous uniform laws at radii (J/V) and (S) are at W1 distance ((SV-J)/(2V)=d/(2V)). Convexity of (W_1) under mixtures and (3) prove (4).

The conditional second moment is (J(J+1)/(3V^2)). Writing (d=SV-J) and comparing (J^2) with ((SV)^2) gives

\[
\left|\frac{J(J+1)}{3V^2}-\frac{S^2}{3}\right|
\le\frac{S}{3V}+\frac{2S}{3}\frac dV,
\]

which proves (5). For integer (J), the conditional mean of (2|X|) is

\[
\frac{2J(J+1)}{V(2J+1)}=\frac JV+\frac{J}{V(2J+1)},
\]

so it differs from (S) by at most (d/V+1/(2V)). Averaging and using (3) proves (6); (7) is the standard bounded-variable Hoeffding inequality.

## Free-boundary cube

The same proof applies to an open (L\times L\times L) cube with free surfaces. Coordinate-monotone paths have length at most (3(L-1)), and at most (L^4) ordered endpoint pairs use any fixed directed edge. Therefore (10) becomes

\[
\sum_{x\ne y}Q_{xy}\le12L^5\sum_{e\text{ open-cube bond}}Q_e,
\]

so replace (6) in (1)–(2) by (12). Free boundaries preserve SU(2); pinned or anisotropic boundary fields do not satisfy this phase-mixing statement.

## Scope, prior, and decisive limitation

This is a **derived corollary**, not a new spin-wave mechanism. CGS, *Validity of the spin-wave approximation for the free energy of the Heisenberg ferromagnet*, Prop. 5.2, already prove the open-cube total-spin sector gap (H_{\Lambda_\ell}\ge C S\ell^{-2}(S\ell^3-S^T)) using (8)–(9) and a geometrically balanced path family. Their Eqs. (5.14)–(5.16) already give a finite-block trace bound from binomial slot counting. The present reconstruction supplies a simple explicit periodic-torus routing constant, a (J_-) anisotropic comparison, and a direct Gibbs tail-to-observable conversion. Priority and external validation of this derived statement are not claimed.

The sufficient schedule (2) is (\beta J_-=O((L^2/S)\log(V/r))). It forces almost all Gibbs mass into the exact ground multiplet. It is therefore an extreme-cooling corollary, not a finite-size rate at a fixed positive temperature. The missing target is a bound on (\mathbb E[(SV-J^T)/V]) at fixed β relative to (S-m_{\beta,J}), with the thermal spin-wave density retained.

The source gap by itself cannot supply that bound: at (\beta) fixed it gives only

\[
\frac{\mathbb E d}{V}\le\frac{6L^2}{S J_-V}\,\mathbb E K_L,
\]

whose right side scales like (L^2) if the energy density remains bounded. Even if one inserts the low-temperature energy-density order (e_\beta=O(\beta^{-5/2})), this route gives (O(L^2\beta^{-5/2})), not a uniform-in-(L) (O(\beta^{-3/2})) radius deficit. Local blocks of side ℓ≈\sqrt\beta) do recover the latter scale from the same gap, but do not fix relative orientations across blocks. The family-271 spherical-law proof handles those orientations through a multiscale compactness/pressure argument; its current source interface leaves the finite-torus local-marginal modulus δ_loc(L,R*) and the small-field pressure modulus (h_\epsilon) unquantified. This report does not claim those gaps are closed.

The single-magnon band gives an independent exact warning against interpreting (2) as a necessary fixed-temperature condition or as the thermal law. In the (M^3=SV-1) subspace, the Hamiltonian is (S) times the weighted torus graph Laplacian. Its nonzero Fourier modes have energies

\[
\epsilon(k)=2S\sum_{i=1}^3J_i\bigl(1-\cos(2\pi k_i/L)\bigr),\qquad k\ne0.
\]

Each is a spin-(SV-1) multiplet. Therefore

\[
\frac{Z_{\rm ex}}{Z_0}\ge\frac{2SV-1}{2SV+1}\sum_{k\ne0}e^{-\beta\epsilon(k)}.
\tag{13}
\]

For every fixed β>0, the sum is Θ(V), by a Riemann-sum limit to a strictly positive Brillouin-zone integral. Consequently the exact ground-multiplet probability goes to zero at fixed temperature. The typical total-spin defect can nevertheless be only a small fraction of (V); proving and quantifying that density, rather than excluding every excitation, is the unresolved finite-β gate.

The single mode (k=(1,0,0)) also shows that (\beta J_1/L^2\to\infty) is necessary if one demands ground-multiplet probability tending to one: its energy is (2SJ_1(1-\cos(2\pi/L))\sim4\pi^2SJ_1/L^2), so bounded (\beta J_1/L^2) leaves a nonvanishing excited-to-ground ratio (with fixed (S>0)). The sufficient schedule (2) has an extra logarithm from the binomial slot majorant. Closing that gap only sharpens ground-state purification and does not resolve the fixed-β normalized-spin question.

An energy-density argument cannot silently replace that gate. For example, a product of spin-coherent vectors pointing (+\hat z) on half of a periodic cube and (-\hat z) on the other half has only two planar interfaces. Its shifted energy expectation is (4S^2J_1L^2), hence energy density (4S^2J_1/L\to0), while

\[
\langle\mathbf M^2\rangle=SV,
\qquad
\frac{\sqrt{\langle\mathbf M^2\rangle}}{V}=\sqrt{S/V}\to0.
\]

This product state is not a Gibbs state. Averaging its density matrix over a uniform global SU(2) rotation leaves both displayed quantities unchanged and makes the state exactly rotation-invariant, so the example also preserves zero-field phase mixing at the level of symmetry. Since \(\mathbf M^2\) has eigenvalue \(J(J+1)\), this mixture has \(\mathbb E[J(J+1)]=SV\) and hence \(\mathbb E[J/V]\le\sqrt{S/V}\to0\). It is **not** a counterexample to the periodic Gibbs theorem. It is an exact counterexample to inferring macroscopic global spin from vanishing energy density and SU(2) invariance alone; orientation alignment across scales is indispensable.
