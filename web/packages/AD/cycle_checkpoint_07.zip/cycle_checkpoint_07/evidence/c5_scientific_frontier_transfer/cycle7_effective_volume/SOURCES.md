# Primary source and prior boundary

## Directly used prior result

Correggi, Giuliani, and Seiringer, “Validity of the spin-wave approximation for the free energy of the Heisenberg ferromagnet,” arXiv:1312.7873v2 (2019; published in *Communications in Mathematical Physics* 339, 2015), [official arXiv record](https://arxiv.org/abs/1312.7873), [official HTML text](https://arxiv.org/html/1312.7873).

Relevant primary ranges:

- Proposition 5.2, Eqs. (5.5)–(5.12): open-cube total-spin sector gap (H_{\Lambda_\ell}\ge C S\ell^{-2}(S\ell^3-S^T)). It proves the three-spin operator inequality (5.6), the path inequality (5.9)–(5.10), then uses a geometrically balanced family of paths to control edge traffic.
- Eqs. (5.14)–(5.16): finite-block total-spin multiplicity and trace tail from bounded bosonic slots.
- Eqs. (5.22)–(5.42): reduction of the finite-volume trace to low-energy total-spin sectors, an interacting-boson correction, and a truncated free-boson mode partition bound. These estimates support their low-temperature free-energy result; they do not state a W1 rate for the total-spin distribution at fixed temperature.
- Theorem 2.1 concerns the thermodynamic free-energy asymptotic as β→∞, not a finite-torus fixed-β magnetization-radius estimate.

The exact periodic routing count, weighted comparison by (J_-\), and the finite Gibbs-tail/W1 corollary in this folder are reconstructed consequences. They are not claimed as new source results or as independently externally validated mathematics.

## Current task’s pinned scientific prior

The prior anisotropic spherical-law transfer is in [`anisotropic_spherical_law.md`](../proofs/anisotropic_spherical_law.md). The source-scope audit is [`family271_source_audit.md`](../source_notes/family271_source_audit.md). Both use the pinned snapshot `openai/math@adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

- Spherical-law manuscript: [pinned primary PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/spherical-magnetization.pdf). It states a qualitative thermodynamic-limit law at fixed sufficiently low positive temperature for isotropic nearest-neighbor exchange. Its proof's finite-volume compactness step does not give a computable modulus for the local-marginal error \(\delta_{\rm loc}(L,R_*)\) or the small-field pressure modulus \(h_\epsilon\).
- The separate anisotropic Bloch-law companion: [pinned primary PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Blochs-Law-for-Finite-Range-Heisenberg-Ferromagnets-in-Three-Dimensions-October-5-2026/bloch-law-heisenberg.pdf). The source-reported Theorem 1.1 gives the ordered-limit low-temperature deficit for nonnegative finite-range couplings whose support generates \(\mathbb Z^3\), including positive axis couplings. Its asymptotic has no explicit finite-β remainder or finite-volume total-spin distribution, so it cannot turn this report’s cooling schedule into a practical finite-temperature budget to \(m_{\beta,J}\).

The cycle6 finite-volume rate gate already records the missing fixed-β ingredients: [`finite_volume_rate_gate.md`](../cycle6_weighted_transfer/finite_volume_rate_gate.md) and [`prior_and_interface_audit.md`](../cycle6_weighted_transfer/prior_and_interface_audit.md). This report does not relabel those unknown moduli as solved.

## Evidence classification

- CGS theorem and estimates: externally published/source-reported primary result; exact correctness of the derived weighted-torus corollary has not received external proof review.
- Weighted periodic path load and three-spin matrix checks: finite diagnostics, not theorem proof. The analytic geometry and operator argument are in [`PROOF.md`](PROOF.md).
- SU(2) sector count and thermal tail: internal derivation from the source path lemma and explicit torus count.
- Fixed-temperature finite-volume spherical law/rate: **UNKNOWN / not established here**.
- Historical priority for any broader interpretation: **UNKNOWN**. No novelty claim is made.
