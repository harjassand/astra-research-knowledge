# Cycle 7 handoff

- [`FINAL_REPORT.md`](FINAL_REPORT.md): result, novelty boundary, costs, and verdict.
- [`PROOF.md`](PROOF.md): complete weighted-torus derivation, observable conversion, one-magnon obstruction, and energy-density counterexample.
- [`FAILURE_GATES.md`](FAILURE_GATES.md): unresolved fixed-temperature gate and exact limitation record.
- [`SOURCES.md`](SOURCES.md): primary theorem ranges and prior boundary.
- [`CLAIMS.json`](CLAIMS.json): machine-readable claim/status/cost/falsifier ledger.
- [`code/`](code/), [`checks/`](checks/): diagnostics and captured outputs.

Reproduce the standard-library checks with:

```sh
python3 code/periodic_path_load.py 4 6 8
python3 code/multiplicity_identity_check.py
python3 code/one_magnon_ground_weight.py --L 32 --S 0.5 --beta 1
python3 code/cooling_threshold.py --L 64 --S 0.5 --Jmin 1 --r 0.000003814697265625
```

`local_pair_operator_check.py` additionally requires NumPy. Finite checks are diagnostics only; the analytic proof and source comparison are recorded separately.
