# Cycle 7: finite-volume low-temperature magnetization transfer

## Result

I derived an explicit finite-volume Gibbs tail for the weighted, spin-isotropic Heisenberg ferromagnet on an even periodic cubic torus, and converted it into a one-axis Wasserstein-1 bound while retaining exact zero-field SU(2) mixing. For (V=L^3), fixed (S>0), and (J_-:=\min_iJ_i>0), the total-spin-(SV-d) sector obeys

\[
K_L\ge \frac{S J_-}{6L^2}d,
\qquad K_L=\sum_{x,i}J_i(S^2-\mathbf S_x\cdot\mathbf S_{x+e_i}).
\]

For any (0<r\le1), it is sufficient that

\[
\beta J_-\ge \frac{6L^2}{S}\log\!\left(\frac{2L^3}{\log(1+r)}\right)
\]

to get 

\[
W_1\!\left(\mathcal L(M^3/V),\operatorname{Unif}[-S,S]\right)
\le \frac{1}{3L^3}+\frac{S r}{2(1+r)}.
\]

The proof is in [`PROOF.md`](PROOF.md); primary-source scope and priority are in [`SOURCES.md`](SOURCES.md). The theorem also gives a second-moment error and a bias/sampling bound for the estimator (2R^{-1}\sum_q|M_q^3|/V).

Combining the explicit bound with the pinned anisotropic Bloch-law source asymptotic gives the conditional triangle bound to the thermodynamic radius (m_{\beta,J}): add ((S-m_{\beta,J})/2). That term tends to zero along the cooling schedule, but its finite-β remainder is not available, so it is not a specimen-size guarantee.

This is a mathematically valid finite-size certificate only along an **increasing inverse-temperature schedule** β(L) of order (L^2\log L), obtained by suppressing essentially every non-ground-spin sector. It does not certify the family-271 target at fixed β, (m_{\beta,J}), and does not close the prior `δ_loc(L,R*)` or `h_ε` gates. It gives an explicit theorem in the size-dependent near-ground-state regime, not a practical materials claim.

## Mechanism and prior boundary

The load-bearing operator mechanism is already prior art: Correggi–Giuliani–Seiringer, Prop. 5.2 and Eqs. (5.5)–(5.12), prove the three-spin inequality and an open-box sector gap (H_{\Lambda_\ell}\ge C S\ell^{-2}(S\ell^3-S^T)); their Eqs. (5.14)–(5.16) count the finite-block sectors by bosonic slots. The new work here is a direct weighted-torus routing count, comparison by (J_-), and explicit tail-to-W1 conversion. Treat it as a derived corollary. No novelty or external validation claim is made.

The primary CGS manuscript also pursues the relevant spin-wave representation and finite-block trace controls (Eqs. (5.22)–(5.42)). Those control free energy with an interacting-boson error and a truncated free-boson mode partition. They do not state an explicit fixed-temperature finite-torus bound on β-normalized total-spin deficit or a W1 error relative to (m_{\beta,J}). The separate pinned family-271 anisotropic Bloch-law result gives only an ordered-limit low-temperature asymptotic for the pressure magnetization; it supplies no finite-β remainder or specimen-size law.

## Decisive limitation and falsification

The all-volume sector gap scales (L^{-2}). Combined with a thermal energy-density bound, it loses (L^2), so it cannot bound the normalized spin deficit uniformly in (L) at fixed β. CGS spin-wave density can control local blocks at side length ℓ≈\sqrt\beta), at the expected (O(\beta^{-3/2})) deficit scale. It does not align the orientations of different blocks; the spherical-law source uses a multiscale/pressure argument there, and its finite-torus marginal and small-field moduli remain unquantified.

An exact single-magnon calculation makes clear why suppressing all excitations is too strong. At fixed β the nonzero one-magnon momenta alone give (Z_{\rm ex}/Z_0=\Omega(V)), so the ground-multiplet probability vanishes. The modes are retained while their normalized spin deficit may still be small. The next valid route would need a uniform finite-volume spin-wave-density bound plus quantitative block-orientation coupling and a pressure modulus; neither is supplied by the inspected prior results.

For the related shortcut “low energy density plus SU(2) symmetry implies macroscopic global spin,” there is an exact counterexample (within the class of states, not Gibbs states): a half-up/half-down coherent domain-wall product state on the torus has energy density (O(L^{-1})) and ⟨M²⟩=SV, hence normalized radius at most (O(V^{-1/2})). Averaging over global SU(2) rotations preserves these values and restores exact rotation invariance. This does not refute the periodic Gibbs law; it falsifies that proposed energy-density-only inference.

## Verification and costs

The routed-pair count passed exhaustive checks at (L=4,6,8); the sourced local operator inequality passed floating-point eigenvalue checks for (S=1/2,1,3/2,2); and exact-integer SU(2) multiplicity checks passed for (2S=1,2,3), (V=2,4,8). These are diagnostics, not proof. The analytic steps are shown in `PROOF.md`.

For (S=1/2), (J_-=1), (L=64), and (r=1/V), the sufficient bound is βJ_-≥1,260,574; it gives the W1 upper bound (2.23\times10^{-6}). At (L=8), the analogous sufficient bound is βJ_-≥10,115. At (L=32), (S=1/2), (J_i=1), and β=1, the one-magnon contribution alone yields (Z_{\rm ex}/Z_0\ge3,309), hence the exact ground-multiplet probability is at most (3.03\times10^{-4}). These values expose the schedule's impracticality and the fixed-β distinction.

An estimator sampling error η at confidence (1-δ) needs (R\ge2S^2\eta^{-2}\log(2/\delta)) independent global-axis draws. For (S=1/2,η=0.01,δ=0.05), this is about 18,445 draws, in addition to preparing and equilibrating each specimen. Device precision, equilibration time, actual (J_i,T) acquisition, nonexchange interactions, and material costs remain unprovided; no experimental budget is asserted.

Reproduce the diagnostics with the scripts under [`code/`](code/); captured outputs are under [`checks/`](checks/). Full exact assumptions, source theorem numbers, state-space costs, and the failed fixed-β gate are retained in [`CLAIMS.json`](CLAIMS.json).
