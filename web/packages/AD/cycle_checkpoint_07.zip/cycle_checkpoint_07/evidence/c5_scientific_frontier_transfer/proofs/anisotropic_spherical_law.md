# Candidate transfer: spatially anisotropic exchange, spin-isotropic law

## Exact proposed statement

Fix a spin `S in {1/2,1,3/2,...}` and fixed spatial bond constants `J_1,J_2,J_3>0`. On even periodic cubes `Lambda_L=(Z/LZ)^3`, count each positive-direction bond once and set

```
H_{S,L,J} = - sum_x sum_{i=1}^3 J_i S_x . S_{x+e_i},
M_L^a=sum_x S_x^a, V=L^3.
```

Let `p_{S,beta,J}(h)=lim_{L even} (beta V)^(-1) log Tr exp[-beta(H_{S,L,J}-h M_L^3)]` and `m_{S,beta,J}=p'_{S,beta,J}(0+)`. The candidate extension is: for every fixed `S,J` there is a finite `beta_0(S,J)` such that for every fixed finite `beta>=beta_0`, `m_{S,beta,J}>0` and for every `t in R^3`

```
lim_{L even -> infinity} < exp( V^(-1) sum_a t_a M_L^a ) >_{beta,L,J}
       = sinh(m_{S,beta,J}|t|)/(m_{S,beta,J}|t|),
```

with value 1 at `t=0`; also `V^(-2) sum_{x,y}<S_x . S_y> -> m_{S,beta,J}^2`.

This is *spatial* anisotropy only. Every bond still couples the SU(2)-invariant scalar product, so the finite-volume Gibbs state remains spin-rotation invariant. The claim says the thermodynamic symmetric state selects one radius, not merely a rotation-invariant mixture of radii. It makes no claim for XXZ, single-ion anisotropy, field, disorder, frustrated/negative bonds, or vanishing `J_i`; if any `J_i=0`, the nearest-neighbor graph loses 3D connectivity and this low-temperature ordered conclusion need not hold.

## Load-bearing proof mechanism

The primary source is the OpenAI/math release manuscript `The spherical magnetization law for the three-dimensional quantum Heisenberg ferromagnet`, pinned commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`, PDF pp. 1–4, 11–30, 37–43, and 44–46, Theorem 1.1 and equations (1.4)–(1.8), (3.5)–(3.6), (4.1), (7.4)–(7.8). The result’s key mechanism is not rotation invariance alone: a field-induced killed-hole resolvent and sparse pins prove a weak exponential estimate for all zero-sum block tests; nested block comparisons transfer it to local magnetization; replica pressure tangents rule out equilibrium states with differing magnetization radii; SU(2) representation theory converts total-spin concentration into the spherical transform.

The anisotropic model admits an exact exchange representation by putting Poisson transposition rate `J_i/2` on every slot edge over a site bond in direction `i` (rather than the source rate `1/2`). The layer/seam identity remains exact because the weighted sum of slot swaps is precisely the weighted Heisenberg interaction, and all bond sums still commute with the symmetric-slot projector.

The following weighted geometric substitutions are proved directly. Let `J_- = min_i J_i` and `J_+ = max_i J_i`. On any available-slot graph from source Section 3, every available edge over direction `i` has conductance `J_i`; for the unweighted and weighted Dirichlet forms `D_0,D_J`,

```
J_- D_0(v) <= D_J(v) <= J_+ D_0(v).
```

Thus the released local Nash inequality `||v||_2^(10/3) <= C D_0(v)||v||_1^(4/3)` implies

```
||v||_2^(10/3) <= (C/J_-) D_J(v)||v||_1^(4/3).
```
The released divergence-one flow `F` obeys weighted energy `sum_e F(e)^2/J_e <= J_-^(-1) sum_e F(e)^2`; hence its pointwise decay and all flow/Cauchy–Schwarz bounds survive with constants multiplied by `J_-^(-1)` (or its square root in first-moment bounds). For the continuous hole walk, the weighted generator has the same form, with Dirichlet dissipation `D_J`; contraction and killed-resolvent arguments are unchanged. The uniform upper rate `J_+` bounds local ordered Poisson-mark counts by `(C J_+ beta)^k/k!` and short-window flags by `C J_+ beta delta`, so the sparse bad-box/short-time event estimates retain their factorial tail after changing constants. Thus the source’s finite-volume geometry is uniformly elliptic when `J_->0`; the low-temperature threshold may worsen as `J_-/J_+` decreases.

The section-7 pressure-tangent cancellation also has an exact weighted replacement. On a cube `C_B`, let `L_bond^J` be the graph Laplacian on slot vertices with edge conductance `J_i` for each slot pair above a spatial bond in direction `i`; let `L_full` be the complete-slot-graph Laplacian. Since every `J_i>=J_->0`, the weighted nearest-neighbor slot graph is connected and

```
L_bond^J >= J_- lambda_2(L_bond^0) I
```
on the zero-sum subspace. Hence choose `c_B` large enough that

```
Q_C = c_B L_bond^J - B^(-6) L_full >= 0.
```
This decomposes into negative-square generators exactly as the source’s (7.4). For the large-cube compensation, the weighted bond-Laplacian sum has operator norm at most `J_+` times the released degree bound. Increasing `D_B` by a factor `J_+` makes

```
R_C = D_B W^(-6)L_full_C - (c_B/n_{B,W}) sum_{C' subset C} L_bond^J_{C'} >= 0.
```
The resulting perturbation reduces the coefficient of each original bond in proportion to `J_i`, so the physical coupling stays ferromagnetic for all sufficiently small perturbation parameters uniformly in volume. Compression to physical spins and the SU(2) endpoint are unchanged.

These substitutions identify an internal proof strategy, not a completed independent proof audit of all source sections. In particular, every conditioned-cycle identity and every conditional next-pin kernel in Sections 2–5 must be checked with direction-dependent rates; constants in all sparse-pin induction levels must be propagated; and the variational/pressure endpoint must be verified under the anisotropic interaction. The source paper itself has no external expert review or independent build in the available verification record. Therefore the theorem above remains **conditional candidate / UNKNOWN**, not an externally validated result or a novelty claim.

## Application contract and test

The modeled material is a 3D crystal with spin-isotropic exchange but different positive exchange strengths along the three crystal axes, at zero applied field and fixed low positive temperature. The quantifier order matters: thermodynamic limit first at fixed `beta,J,S`, then the infinitesimal pressure field derivative. The release’s observation interface is self-adjoint `t . M/V` linear combinations; it does not posit a simultaneous finite-volume measurement of noncommuting components. Under the candidate theorem, for independently equilibrated specimens, `X=M^3/V` converges to `Uniform[-m,m]`, so `m` can be estimated asymptotically by `2 E|X|`; no finite-volume bias rate is supplied, so no certified finite-size sample count follows. A decisive experiment would compare normalized total-moment directional statistics across several aspect-preserving specimen sizes and fixed field-axis protocols while independently calibrating each `J_i`; domain formation, finite field, spin-space anisotropy, boundary pinning, and long-range dipolar effects are competing explanations and must be measured/controlled. Model sample/measurement cost is `R` independent equilibration-and-collective-readout runs (or `R*V` local spin readouts); specimen size required for a certified error, device precision, equilibration time, and experimental dollar cost remain `UNKNOWN` because neither the source nor this transfer provides finite-size rates or material-specific calibration.

## Priority boundary

The same pinned release contains a separate companion Bloch-law result for nonnegative symmetric finite-range couplings with support generating `Z^3`, including spatially anisotropic couplings. That does **not** state the finite-temperature spherical distribution: the spherical-law manuscript explicitly scopes its theorem to the nearest-neighbor isotropic exchange model. Targeted searches found no independent spatially anisotropic finite-temperature spherical-law statement, but this is not a complete priority search. Treat priority as `UNKNOWN`; do not call this a discovery until the weighted proof audit and a broader source review pass.
