# Exact two-state phase-type alias (biological observation boundary)

## Contract

The hidden process begins in known transient state 1, has two transient states and one absorbing activation event, and is observed only through activation time. An intervention may additionally stop observation at an independent exponential ligand-off time of rate `delta`; the output is activation before off. The rates are time-homogeneous and nonnegative. No intermediate-state signal is supplied.

## Two generators

For row-vector initial laws, let `r=-T 1` be the absorption-rate column. Define

```
A: alpha_A=(1,0),  T_A=[[-3,1],[0,-1]],       r_A=(2,1)^T
B: alpha_B=(1,0),  T_B=[[-11/4,3/4],[7/12,-5/4]], r_B=(2,2/3)^T
S=[[1,0],[1/4,3/4]].
```

Every off-diagonal entry and every absorption rate is strictly positive; each row of `T_i` plus the corresponding entry of `r_i` sums to zero. `T_A` has no reverse edge, while `T_B` has rate `7/12` from state 2 to state 1. Both are valid two-phase absorbing CTMCs with the same initial transient state. Direct multiplication gives

```
T_B=S^{-1}T_A S,  alpha_B=alpha_A S,  r_B=S^{-1}r_A.
```

Therefore for every `t>=0`, `alpha_B exp(T_B t) r_B=alpha_A exp(T_A t)r_A`. Computing the latter gives the common density

```
f(t)=(3/2) exp(-3t)+(1/2) exp(-t).
```

For every independent exponential off-rate `delta>=0`, the common activation-before-off probability is the Laplace transform

```
P(T_act<T_off) = integral exp(-delta*t) dF(t)
                 = (3/2)/(delta+3)+(1/2)/(delta+1)
                 = (2*delta+3)/((delta+1)(delta+3)).
```

Any statistic measurable with respect to activation-time records and any collection of these off-rate interventions consequently has the same law under A and B. Under equal prior weight on the two architectures, every classifier has error exactly `1/2`, for any number of exact observations. This conclusion is structural and does not depend on a sampling-noise bound.

## Separating measurement and model-specific cost

State-2 occupancy differs. For A,

```
p_A2(t)=integral_0^t exp(-3s) exp(-(t-s)) ds
       =(exp(-t)-exp(-3t))/2.
```

The similarity identity also gives `p_B2(t)=(3/4)p_A2(t)`. Thus the maximum absolute occupancy gap is

```
max_t |p_A2(t)-p_B2(t)|=1/(12 sqrt(3))
```

at `t=(log 3)/2`. If the rates are known and an ideal calibrated binary state-2 reporter is available at that time, a midpoint test based on independent receptor episodes needs `n>=ceil(2 log(20)/Delta^2)=2589` to make each one-sided Hoeffding error at most 0.05, with `Delta=1/(12 sqrt(3))`. This is only a rate-unit, ideal-readout model calculation. Real reporter error, imaging/photophysics, pMHC dwell-time calibration, dropout, cell/donor clustering, and biological sample/financial costs are unknown. The explicit pair is not a parameterized biological TCR model and does not establish that a real receptor has these rates.

## Priority/status boundary

The similarity construction is a finite, exact internal counterexample. Nonuniqueness of phase-type representations is established prior art (Telek–Horváth criterion, summarized in Lindqvist 2023); this note claims no novelty for the algebra. Morita–Groves (PNAS 2025) compare sequential proofreading with parallel ITAM threads/LAT condensation; Voisinne et al. (Nature Immunology 2022) report time-resolved TCR signalosome measurements. These make the architecture question concrete but do not make the displayed CTMC pair a biological finding. The precise next experiment would jointly observe receptor-specific intermediate ITAM/ZAP70 state and LAT-condensation time during randomized ligand-dwell-time encounters, and test parameter-matched sequential and multithread models on held-out dwell times. If only aggregate activation/FPT data are available, architecture identification is impossible for this pair.
