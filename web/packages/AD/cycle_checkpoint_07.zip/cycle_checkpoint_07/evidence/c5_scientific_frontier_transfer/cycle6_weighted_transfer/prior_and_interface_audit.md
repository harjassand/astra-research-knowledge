# Family 271 anisotropic spherical-law: source and interface audit

## Verdict

The spatially anisotropic spherical law remains a **conditional theorem candidate**, not a result supplied by family 271 or by the Astra cards. The pinned spherical-law manuscript proves a qualitative thermodynamic-limit statement for the nearest-neighbor model with equal, spin-isotropic exchange. A distinct family-271 companion allows spatially anisotropic finite-range exchange, but proves a low-temperature asymptotic for the pressure magnetization, not concentration of the finite-volume total-spin label or a spherical distribution. I found no quantitative finite-size bias bound for the spherical law in the targeted primary sources. This blocks any certified specimen-size or experimental-cost claim.

## Exact scope and missing step

The pinned manuscript, [*The spherical magnetization law for the three-dimensional quantum Heisenberg ferromagnet*](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/spherical-magnetization.pdf), Theorem 1.1 (p. 2), fixes (S\in\{1/2,1,\ldots\}) and uses even periodic cubes (\Lambda_L=(\mathbb Z/L\mathbb Z)^3\), (V=L^3), with

\[
H_L=-\sum_{\{x,y\}\text{ nn}}\mathbf S_x\cdot\mathbf S_y.
\]

At every fixed sufficiently low finite (\beta>0), it sets (m=p'_{S,\beta}(0+)>0), where the thermodynamic pressure limit is taken before the right field derivative. It proves, for each fixed (t\in\mathbb R^3\),

\[
\left\langle e^{V^{-1}t\cdot\mathbf M_L}\right\rangle_{\beta,L}\longrightarrow
\frac{\sinh(m|t|)}{m|t|},\qquad
V^{-2}\sum_{x,y}\langle\mathbf S_x\cdot\mathbf S_y\rangle_{\beta,L}\longrightarrow m^2.
\]

This is spatially isotropic and spin-rotation invariant. The proof's load-bearing concentration statement is (J_L/V\to m) in probability for the total-spin label. The finite-volume SU(2) decomposition itself is exact: conditional on (J_L=J), any fixed component has the discrete uniform spectrum (r=-J,-J+1,\ldots,J). The unresolved probabilistic input is that the model-dependent (J_L/V) law concentrates at the pressure radius. The theorem gives no continuous exact finite-volume spherical law.

The candidate extension instead has

\[
H_{L,J}=-\sum_{x\in\Lambda_L}\sum_{i=1}^3J_i\,\mathbf S_x\cdot\mathbf S_{x+e_i},\qquad J_i>0,
\]

with periodic wrapping. This is **spatial exchange anisotropy only**: every bond still uses the scalar product, so SU(2) remains exact. The proposed conclusion replaces (m) by (m_{\beta,J}=p'_{\beta,J}(0+)\). The missing theorem is quantitative or qualitative concentration (J_L/V\to m_{\beta,J}) for these weighted finite-volume Gibbs states. The internal transfer note [anisotropic_spherical_law.md](../proofs/anisotropic_spherical_law.md) identifies plausible weighted Dirichlet-form and Laplacian replacements, but explicitly leaves the direction-dependent conditioned-cycle identities, next-pin kernels, all sparse-pin constants, and pressure endpoint to a full audit. Those substitutions do not establish the extension.

## Why the companion anisotropy does not transfer

The family-271 [pinned contents entry](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/CONTENTS.md) at lines 5838–5863 separates three claims. Its Bloch-law companion, [*Bloch's Law for Finite-Range Heisenberg Ferromagnets in Three Dimensions*](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Blochs-Law-for-Finite-Range-Heisenberg-Ferromagnets-in-Three-Dimensions-October-5-2026/bloch-law-heisenberg.pdf), allows (J(z)\ge0), symmetric finite-range couplings whose support generates \(\mathbb Z^3\), including spatially anisotropic interactions. Its Theorem 1.1 is the ordered-limit asymptotic

\[
\lim_{\beta\to\infty}\beta^{3/2}(S-m_{S,J}(\beta))
=\frac{\zeta(3/2)}{8\pi^{3/2}\sqrt{\det D_{S,J}}},\qquad
D_{S,J}=\frac S2\sum_zJ(z)zz^{\mathsf T}.
\]

The limit order is volume \(\to\infty\), field \(h\downarrow0\), then \(\beta\to\infty\). For the three axis couplings, (D=S\operatorname{diag}(J_1,J_2,J_3)). Equivalently, with \(\lambda_i=\beta J_i\), the leading deficit is

\[
S-m\sim\frac{\zeta(3/2)}{8\pi^{3/2}S^{3/2}\sqrt{\lambda_1\lambda_2\lambda_3}}.
\]

This says neither that (J_L/V\) concentrates nor that the zero-field magnetization component has a uniform limit. It supplies no explicit finite-\(\beta\) remainder or finite-volume distribution rate. The companion [first lattice correction](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/CONTENTS.md) is for nearest-neighbor isotropic coupling and does not supply the anisotropic spherical law either. Finally, spin-space XXZ or single-ion anisotropy is outside the candidate: it breaks the SU(2) orbit needed for a uniform sphere.

## Finite-size rate and prior-art audit

The spherical manuscript's statement is qualitative. In its final proof (pp. 45–46), the lower total-spin second moment is obtained by first taking (L\to\infty) at fixed spatial scale and then sending the scale (R_*\to\infty); the upper tail uses the pressure limit at a fixed positive field. The proof concludes (J_L/V\to m) and convergence of the Laplace transforms, without an explicit (L_0(\varepsilon)), rate for (\mathbb E|J_L/V-m|\), or error bound for the law of (M_L^3/V\). Earlier block estimates are quantitative in selected scales, but the compactness/limit argument does not combine them into a certified finite-(L) bias.

The primary antecedent [Björnberg–Fröhlich–Ueltschi, *Quantum spins and random loops on the complete graph*](https://arxiv.org/abs/1811.12834), Theorem 2.1, proves the spherical transform for the mean-field complete graph. The authors explicitly say the corresponding lattice universality is expected while rigorous proofs eluded them (Introduction). [Ueltschi's 3D loop-soup account](https://arxiv.org/abs/1703.09503) obtains the spin-1/2 spherical transform conditional on a conjectured Poisson–Dirichlet law for macroscopic loops. These are important prior art but do not state the proposed anisotropic lattice theorem. A relevant finite-size primary source, Peczak–Ferrenberg–Landau's [classical simple-cubic Heisenberg Monte Carlo study](https://doi.org/10.1103/PhysRevB.43.6087), reports magnetization-distribution simulations and finite-size scaling for (L\le24) near criticality; it is not a quantum low-temperature theorem or a certified anisotropic bias bound. This targeted search does not clear priority globally.

The relevant pinned Astra routes agree with this boundary. `work/astra_prior/agent/topics/probability.tsv` routes N02 and `analysis.tsv` routes N20. N02's [card](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/N02-correlated-sphere.txt), lines 3–7, assumes a supplied rotation-invariant reference with (a_N=\mathbb E_0|J_N/N-m|\to0). It gives a weak-field von Mises–Fisher sphere experiment and a remainder containing (a_N); it does not prove that premise for anisotropic lattices. Its linked proof summary ([source d-ece46f964518dbb3](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/web/pages/d-ece46f964518dbb3.html), §3, lines 152–249) says the OpenAI family-271 concentration is needed for the 3D Heisenberg application, not the separate Bloch asymptotic. N20's [card](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/N20-critical-quartic.txt) instead concerns an all-to-all critical spin-half model with an unknown collective quadratic form, whose limiting observation has a quartic density on \(\mathbb R^3\); it is neither the local cubic lattice nor the fixed-low-temperature spherical law. Its [proof summary](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/web/pages/d-2f8ab8dc07c5e8b8.html), §2, lines 149–210, derives that different critical scaling from coherent-spin symbols and Stirling asymptotics.

## Strongest measurement interface and charged costs

The cleanest test of the candidate model is one global spin projection per independently equilibrated specimen, not a simultaneous vector measurement. Fix an axis \(\hat n\) and measure

\[
X_L=V^{-1}\hat n\cdot\mathbf M_L\in[-S,S].
\]

One can obtain this from a bulk moment channel (such as calibrated magnetometry) or by measuring every site along that one axis and summing. Under the candidate theorem, (X_L\Rightarrow\mathrm{Unif}[-m_{\beta,J},m_{\beta,J}]). A simple radius estimator is \(\widehat m=2R^{-1}\sum_{r=1}^R|X_L^{(r)}|\). With independent Gibbs draws, (Y=2|X_L|\in[0,2S]); Hoeffding gives sampling error at most \(\eta\) with probability (1-\delta\) once

\[
R\ge\frac{2S^2}{\eta^2}\log\frac2\delta.
\]

At total error \(\varepsilon\), this is sufficient only if the finite-size bias (B_L=|2\mathbb E|X_L|-m_{\beta,J}|) is already certified below \(\varepsilon/2\); then use \(\eta=\varepsilon/2\). This costs (R) collective readouts or (RV) site-spin readouts. Distributional uniformity can instead be tested by an empirical CDF, but its (O(\varepsilon^{-2}\log(1/\delta))) sampling requirement still does not remove the unknown model bias. The release specifies no equilibration time or independent-sample generator; preparation, autocorrelation, thermal cycling, readout noise, and cost in seconds/joules/dollars remain uncharged.

For a **radius-prediction** test (as opposed to fitting (m) freely and testing only the uniform shape), one must acquire (S,T,J_1,J_2,J_3) and justify (\beta\ge\beta_0(S,J)\). The Bloch coefficient gives a leading-order calibration sensitivity: a relative error in the product (\lambda_1\lambda_2\lambda_3\) produces roughly half that relative error in the predicted low-temperature deficit. Because the Bloch theorem supplies only a limit, it does not quantify its own finite-temperature remainder; nor does the sphere theorem give a modulus for (m_{\beta,J}) versus calibration errors. Separate measurements of the exchange dispersion (for example, wave-vector-resolved magnon data) and temperature are therefore needed, with tolerances determined by a future explicit response bound, not by the release.

There is a stringent zero-field requirement. In the weak-field scaling used by N02, the orientation law is proportional to \(e^{m b\cdot u}\), with (b=\beta Vh\) for a uniform field coupled as \(-hM_{\hat n}\). A residual field with fixed nonzero \(\beta Vh\) produces a nonuniform limiting orientation law. Thus to test the zero-field uniform direction at vanishing total-variation tolerance, one needs \(m\beta V|h|\to0\); the exact (V\)-dependent field calibration must be recorded. Surface/boundary effects, domains, dipolar interactions, spin-orbit anisotropy, disorder, and field inhomogeneity must also be bounded against the same distributional error. The theorem is for ideal periodic boxes; no named real material or material-specific calibration/equilibration record was found that establishes this interface.

## Decisive gate

Keep the spatially anisotropic theorem as a **conditional mathematical candidate**, while rejecting a quantitative materials claim for now. The decisive mathematical gate is an independently checked weighted proof of total-spin concentration plus an explicit finite-size estimate such as

\[
W_1\!\left(\mathcal L(X_L),\mathrm{Unif}[-m_{\beta,J},m_{\beta,J}]\right)\le r_{S,\beta,J}(L),
\]

with an explicit (r(L)\to0), (L_0(\varepsilon)), and parameter modulus for (m_{\beta,J}). Since (x\mapsto|x|\) is 1-Lipschitz, this would certify the radius-estimator bias at most (2r(L)) and turn the readout formula above into a size-and-sample budget. Without it, no finite (L) or experimental precision can be selected from the theorem. The decisive material gate is then a named 3D spin-isotropic ferromagnet with measured (J_i,T), residual field of order (o((\beta V)^{-1})), controlled finite boundaries and nonexchange terms, plus an independently verified preparation/equilibration protocol. If those parameters cannot be supplied, report a fitted finite-size distribution only; do not attribute it to the anisotropic spherical law.

### Source trail and status

- Family-271 release pin: `openai/math@adc7f1241b42e322a6451854ab7e4b4c146bf78a`; spherical theorem PDF pp. 2–4 and 45–46; anisotropic Bloch theorem `build/sections/01-introduction.tex`, `07-pressure.tex`, and `06-ideal.tex`.
- Astra pin: `8ede33c2f09a8abe07b430892b3ac4bb71c27c83`; `agent/topics/probability.tsv` (N02), `agent/topics/analysis.tsv` (N20), N02/N20 cards and linked proof-summary ranges cited above. Their status is source-derived/unreviewed; N02's hypothesis is not acquired by reading the card.
- Existing candidate proof note: `work/agents/c5_scientific_frontier_transfer/proofs/anisotropic_spherical_law.md`; prior source scope note: `work/agents/c5_scientific_frontier_transfer/source_notes/family271_source_audit.md`.
- Status: release and Astra statements are source-reported; the anisotropic extension is an internal conditional candidate; finite-volume rate, real-material calibration, equilibration, and priority are UNKNOWN.
