# Cycle 6: exact audit of the weighted pressure-tangent cancellation

## Scope and verdict

This note audits only the family-271 Section 7.1 pressure-tangent Laplacian construction for the spatially anisotropic, spin-isotropic exponent

\[
H_{0,J}=\beta\sum_{x\in\Lambda_L}\sum_{i=1}^3J_i\,S_x\cdot S_{x+e_i},
\qquad J_i>0,
\]

which corresponds to the physical Hamiltonian \(-\sum_{x,i}J_iS_x\cdot S_{x+e_i}\). Each positive-direction bond is counted once. The result below is an exact algebraic replacement for the Laplacian and slot-compression part of source equations (7.4)--(7.8), with explicit constants. It is **not** a proof of the anisotropic spherical-law theorem: Section 7.2 still needs the anisotropic version of the earlier zero-sum exponential estimate used in Lemma 6.3, and low-temperature positivity of the anisotropic pressure slope needs its own verified input.

The primary source is the pinned `openai/math` snapshot `adc7f1241b42e322a6451854ab7e4b4c146bf78a`, “The spherical magnetization law for the three-dimensional quantum Heisenberg ferromagnet,” §7.1, PDF pp. 38–39, equations (7.4)–(7.8). The locally extracted source is [family271_spherical_magnetization.txt](../source_notes/family271_spherical_magnetization.txt), around lines 2110–2210. The model in that manuscript has equal spatial couplings. Its Section 6 variational principle is stated for bounded finite-range translation-invariant interactions, but the Section 5 estimate imported by Lemma 6.3 is proved in the source model and is not transferred by this note.

## Weighted graphs and constants

Let \(\ell=2S\) be the number of spin-\(1/2\) slots per site. For a cube \(C_B\) of side \(B\ge2\), the slot vertices are \((x,a)\), with \(x\in C_B\), \(1\le a\le\ell\). Define the weighted bond Laplacian by its quadratic form

\[
z^\mathsf TL_{\mathrm{bond},C_B}^{J}z
=\sum_{i=1}^3J_i\sum_{\substack{x,x+e_i\in C_B}}
  \sum_{a,b=1}^{\ell}(z_{x,a}-z_{x+e_i,b})^2.
\]

The sum is over undirected spatial bonds once, and all \(\ell^2\) slot pairs above each such bond. Let \(L_{\mathrm{full},C_B}\) be the unit-conductance complete-graph Laplacian on these \(\ell B^3\) slots. Its kernel is the constants and its eigenvalue on the zero-sum subspace is exactly \(\ell B^3\).

Write \(J_-:=\min_iJ_i\), \(J_+:=\max_iJ_i\), and \(g_B:=2(1-\cos(\pi/B))\), the spectral gap of the unweighted path-cube graph \(P_B\square P_B\square P_B\). For any slot vector, put \(\bar z_x=\ell^{-1}\sum_a z_{x,a}\) and \(\eta_{x,a}=z_{x,a}-\bar z_x\). Then \(\sum_a\eta_{x,a}=0\), and direct expansion gives

\[
z^\mathsf TL_{\mathrm{bond},C_B}^{J}z
=\ell^2\sum_{i,x}J_i(\bar z_x-\bar z_{x+e_i})^2
+\ell\sum_x d_J(x)\sum_a\eta_{x,a}^2,
\]

where \(d_J(x)=\sum_iJ_i\deg_i(x)\) and \(\deg_i(x)\ge1\) for every axis and every site when \(B\ge2\). The first term is at least \(\ell^2J_-g_B\sum_x\bar z_x^2\). The second is at least \(3\ell J_-\sum_{x,a}\eta_{x,a}^2\), and \(g_B\le2<3\). Since \(\|z\|^2=\ell\sum_x\bar z_x^2+\sum_{x,a}\eta_{x,a}^2\),

\[
L_{\mathrm{bond},C_B}^{J}\succeq \ell J_-g_B I
\quad\text{on }\mathbf1^\perp.
\]

Consequently the following explicit choice works:

\[
c_B:=\frac{1}{2J_-B^3(1-\cos(\pi/B))}
=\frac{1}{J_-B^3g_B},
\qquad
Q_C:=c_BL_{\mathrm{bond},C}^{J}-B^{-6}L_{\mathrm{full},C}\succeq0.
\tag{A}
\]

Indeed, on \(\mathbf1^\perp\), the first term has eigenvalue at least \(c_B\ell J_-g_B=\ell/B^3\), exactly the eigenvalue of \(B^{-6}L_{\mathrm{full},C}\); both terms annihilate constants. Every positive-eigenvalue vector in a spectral decomposition \(Q_C=\sum_v vv^\mathsf T\) is therefore real and zero-sum.

For the large cube \(C_W\), \(W\ge2B\), put \(n_{B,W}=(W-B+1)^3\), the number of side-\(B\) cubes contained in it. Each weighted small-cube slot graph has maximum weighted degree at most \(6\ell J_+\), hence Laplacian norm at most \(12\ell J_+\). A slot belongs to at most \(B^3\) small cubes, so the positive-semidefinite sum obeys

\[
\left\|\sum_{\substack{C'\in\mathcal C_B:C'\subset C_W}}
L_{\mathrm{bond},C'}^J\right\|
\le 12\ell J_+B^3.
\]

Since \(n_{B,W}\ge W^3/8\), the subtracted term in

\[
R_C:=D_BW^{-6}L_{\mathrm{full},C_W}
-\frac{c_B}{n_{B,W}}
\sum_{\substack{C'\in\mathcal C_B:C'\subset C_W}}
L_{\mathrm{bond},C'}^J
\tag{B}
\]

has norm at most \(96c_B\ell J_+B^3/W^3\). On the zero-sum subspace, the first term in (B) is exactly \(D_B\ell/W^3\) times the identity. Thus the uniform choice

\[
D_B:=96c_BJ_+B^3+1
\tag{C}
\]

makes \(R_C\succeq (\ell/W^3)I\) on \(\mathbf1^\perp\); on constants it is zero. This proves \(R_C\succeq0\) for every \(W\ge2B\), with \(D_B\) independent of \(W\). The `+1` is only a strict slack; equality at \(96c_BJ_+B^3\) already gives semidefiniteness.

## Compression and cancellation check

Let \(P_*\) project each site's \(\ell\) slots to the symmetric spin-\(S\) subspace, and write \(s_{x,a}^q\) for slot spin components. The required compression facts are

\[
P_*\left(\sum_{a=1}^{\ell}s_{x,a}^q\right)P_*=S_x^q,
\qquad
P_*\left(\sum_{u\in C}s_u^q\right)^2P_*=(S_C^q)^2.
\]

These facts compress the *full quadratic slot expression*. One must not replace \(P_*G^2P_*\) by \((P_*GP_*)^2\); an individual generator need not preserve the physical subspace.

For a small cube, decompose \(Q_C=\sum_vvv^\mathsf T\) and use the source's generators \(G_v=iD_v^2\), where \(D_v^q=\sum_uv_us_u^q\). Their total square is

\[
\sum_vG_v^2=-\sum_{u,w}(Q_C)_{uw}s_u^2s_w^2.
\]

For distinct slots \(u,w\) lying over a spatial bond in direction \(i\), the matrix entry is \((Q_C)_{uw}=-c_BJ_i+B^{-6}\). Therefore the generator contributes \(+c_BJ_i-B^{-6}\). Define the static reduction using the same conductance:

\[
T_{B,L}^{J}:=-c_B\sum_{C\in\mathcal C_B}\sum_{\substack{u,w\in C\text{ slots}:\\\text{sites of }u,w\text{ form an NN bond}}}
J_{\mathrm{dir}(u,w)}\sum_{q=1}^3s_u^qs_w^q,
\]

where the slot-pair sum is ordered, as in source (7.7). Its coefficient on that ordered pair is \(-c_BJ_i\), leaving exactly \(-B^{-6}\) in the \(Y\)-direction after adding the small-cube generators.

For a large cube, decompose \(R_C=\sum_vvv^\mathsf T\) and use \(D_v^1,D_v^3\). The combined \(X,Z\) coefficient from that cube on an off-diagonal slot pair is

\[
(R_C)_{uw}=-D_BW^{-6}
+\frac{c_B}{n_{B,W}}\sum_{C'\subset C}J_{\mathrm{dir}(u,w)}E_{C'}(u,w).
\]

Every fixed small cube is contained in exactly \(n_{B,W}\) large cubes. Summing over translations, the second term cancels the static reduction \(-c_BJ_i\) for each small-cube occurrence of that bond, leaving \(-D_BW^{-6}\) on each ordered pair of each large cube. Diagonal terms are scalar because \((s_u^q)^2=I/4\); translation invariance makes their sum a scalar multiple of \(V\). Thus the exact weighted version of (7.8) is

\[
T_{B,L}^{J}+\sum_\alpha P_*G_\alpha^2P_*
=\sum_x\tau_x\!\left[-\frac{Y_{C_B}^2}{B^6}
-D_B\frac{X_{C_W}^2+Z_{C_W}^2}{W^6}\right]
+C_{B,W,J}VI.
\tag{D}
\]

Here \(X_C,Y_C,Z_C\) are the physical block spins. The scalar may depend on \(J,B,W,S\), but not on \(L\) once \(L>2W\).

The zero-sum property also survives compression in the form needed for replica cross terms. For \(\sum_uv_u=0\),

\[
P_*D_v^qP_* = \sum_x c_xS_x^q,
\qquad c_x=\ell^{-1}\sum_{a=1}^{\ell}v_{x,a},
\qquad \sum_xc_x=0.
\]

So whenever the requisite anisotropic version of source Lemma 6.3 applies, the cross-replica products of these compressed generators have zero pressure density. This is separate from the single-replica identity (D).

## Ferromagnetic perturbation

Each unordered bond in direction \(i\) belongs to exactly \(\nu_B=(B-1)B^2\) translates of \(C_B\). The ordered slot sum in \(T_{B,L}^J\) contributes twice the physical bond operator. Hence

\[
P_*T_{B,L}^JP_*=-2c_B\nu_B\sum_{x,i}J_iS_x\cdot S_{x+e_i},
\]

and

\[
H_{0,J}+tP_*T_{B,L}^JP_*
= (\beta-2tc_B\nu_B)\sum_{x,i}J_iS_x\cdot S_{x+e_i}.
\]

For \(0<t<\beta/(2c_B\nu_B)\), every effective directional coupling is still positive. This condition is uniform in \(L>2W\). Weighting the static reduction by \(J_i\) is essential: an unweighted reduction would leave directional coefficients \(\beta J_i-2tc_B\nu_B\), which can turn negative for small \(J_i\) and would not cancel the weighted Laplacian entries.

## Isotropy and the exact failure gate

There is **no equal-spatial-coupling dependency in (A)–(D)**. The argument only needs fixed positive directional couplings, translation invariance, and the same \(J_i\) in the Laplacian and static reduction. The global spin-rotation symmetry is still essential and is preserved by all \(J_iS_x\cdot S_{x+e_i}\) bonds; it is what supports the rotation operations and the magnetization-vector endpoint in the source. This does not extend to spin-anisotropic XXZ couplings.

Two dependencies remain outside this algebraic audit:

1. Source Lemma 6.3 obtains vanishing replica cross terms by applying Proposition 5.2 to zero-sum block observables. For anisotropic \(J_i\), one must establish that earlier estimate with direction-dependent exchange rates, including the conditional pin/cycle steps in Sections 2–5. If this fails, the weighted square identity alone does not yield the pressure-tangent conclusion of Proposition 7.1.
2. The source's low-temperature assertion \(m>0\) is for its equal-coupling model. A positive anisotropic pressure slope must be supplied/proved separately before asserting the nontrivial spherical law. The adjacent anisotropic Bloch-law manuscript is not the same conclusion and was not independently verified here.

The positive-coupling boundary is a hard failure for these constants: if any \(J_i=0\), the slot bond graph splits into slabs. A nonconstant vector that is constant on each connected slab and has total sum zero then satisfies \(L_{\mathrm{bond}}^Jz=0\), while \(z^\mathsf TL_{\mathrm{full}}z>0\). Consequently no finite \(c_B\) can make \(Q_C\succeq0\). This precisely explains the assumption \(J_->0\).

## Astra relevance and evidence status

The pinned Astra index has `N02-correlated-sphere` under `agent/topics/probability.tsv` (line 4); its card is `cards/N02-correlated-sphere.txt` in Astra commit `8ede33c2f09a8abe07b430892b3ac4bb71c27c83`. The card/page identifies the operational weak-field transfer's exact input as concentration of total spin \(j/N\to m>0\), and explicitly says the family-271 spatial-comparison/equilibrium proof was an unaudited dependency (page lines 152–160 and 176–208; release-boundary note at line 249). That result is downstream context only; it supplies none of the weighted Section 7.1 algebra. Astra marks it source-derived/unreviewed and says its detailed linked research pack was not attached, so no Astra proof is being attributed to or replayed here.

**Status:** the weighted Section 7.1 Laplacian positivity, ordered-pair cancellation, physical compression, and positivity of the perturbed ferromagnetic couplings are reconstructed exactly with the constants above. The full anisotropic Section 7 pressure-tangent proposition and the spherical-law transfer remain **conditional / UNKNOWN**, not proved or externally validated. **Failure gate:** prove (or find a counterexample to) the anisotropic Proposition 5.2 estimate required by Lemma 6.3, with all positive \(J_i\) fixed, and provide a verified low-temperature \(m_{\beta,J}>0\) input. Failure of either blocks the full theorem even though (A)–(D) hold.

### Sources

- Pinned OpenAI/math paper: [spherical-magnetization.pdf](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/spherical-magnetization.pdf), §7.1, equations (7.4)–(7.8), PDF pp. 38–39; Lemma 6.3 and Proposition 5.2 for the stated dependency.
- Pinned Astra index/card: [probability.tsv](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/agent/topics/probability.tsv), [N02 card](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/N02-correlated-sphere.txt), and [linked summary page](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/web/pages/d-ece46f964518dbb3.html).
