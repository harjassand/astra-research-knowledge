# Cycle 6: weighted transfer integration

Task is not to restate the candidate. The end-to-end target is to determine whether the source proof, with every weighted kernel and pressure tangent checked, proves the finite-temperature spherical law for fixed strictly positive spatially anisotropic NN couplings. If yes, identify a quantitative consequence beyond that corollary; if no, isolate a counterexample or the first genuine theorem gate and reallocate.

Exact proposed Hamiltonian and quantifiers are in `../proofs/anisotropic_spherical_law.md`. Three independent audits are requested in this folder: `nash_sparsepins_audit.md`, `pressure_tangent_audit.md`, `prior_and_interface_audit.md`. They are scoped independent components; the integration owner must still check their interfaces against the source proof.

The key questions:

1. Do direction-dependent Poisson rates preserve every conditioned-cycle identity, sparse-pin induction hypothesis, and regular-slice diffusion estimate, with constants depending only on fixed S, `J_min`, `J_max` and beta?
2. Does the weighted pressure-laplacian factorization cancel all ordered slot-pair coefficients exactly after compression to physical spins, and does the perturbed Hamiltonian remain ferromagnetic at each infinitesimal perturbation parameter?
3. Does primary prior art already establish the spherical finite-volume law for the anisotropic model? What finite-size/temperature/coupling error bound exists for estimating `m` from one collective spin component?
4. What experimentally measurable outcome would be certified, with all sample, equilibration, calibration, specimen-size and device costs charged?
