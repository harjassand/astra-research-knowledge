# Cycle 6 integrated result: weighted family-271 spherical law

## Decision

The anisotropic transfer is not blocked by an isotropic-only step in the proof mechanism. Combining three independent audits with an end-to-end pass through the pinned manuscript, I obtain the following **internal proof-transfer theorem**: every use of the equal nearest-neighbor rate in the family-271 spherical-law proof can be replaced for fixed `0<J_min<=J_i<=J_max<infinity`; the sparse-pin exponents and pressure-tangent construction survive with constants depending on `(S,J_min,J_max)`. The result is stronger than an informal “anisotropy should not matter”: it identifies the exact weighted generators, return estimates, Laplacian constants, perturbation interval, and observable corollary.

This is a proof transfer from a source manuscript, not an external proof validation of that source. The source’s own verification record reports no independent build or expert review. I therefore do not advertise it as an externally established theorem or make a priority claim. The mathematical integration is complete conditional only on the explicitly cited source core being correct; it does not stop at an unlocated weighted lemma. The actionable result beyond the straightforward anisotropic law is a **single-axis, zero-field low-temperature stiffness-determinant formula** below. It is asymptotic only: no L-dependent bias rate exists in the source, so there is no finite-specimen certificate.

## Exact theorem and model

Fix `S in {1/2,1,3/2,...}` and fixed directional exchange constants `J_1,J_2,J_3>0`. On even periodic cubes `Lambda_L=(Z/LZ)^3`, write `V=L^3`, count each positive-direction bond once, and set

```
H_{S,L,J} = -sum_x sum_{i=1}^3 J_i S_x . S_{x+e_i},
M_L^a = sum_x S_x^a.
```

Define the thermodynamic pressure with the thermodynamic limit before the one-sided field derivative,

```
p_{S,beta,J}(h)=lim_{L even->infinity} (beta V)^(-1) log Tr exp[-beta(H_{S,L,J}-h M_L^3)],
m_{S,beta,J}=p'_{S,beta,J}(0+).
```

The transferred claim is: for each fixed `S,J`, there is a finite `beta_0(S,J)` such that every fixed finite `beta>=beta_0` has `m_{S,beta,J}>0`, and, for all `t in R^3`,

```
lim_{L even->infinity} < exp( V^(-1) sum_a t_a M_L^a ) >_{beta,L,J}
    = sinh(m_{S,beta,J}|t|)/(m_{S,beta,J}|t|),
```
with value 1 at `t=0`; also

```
lim_{L even->infinity} V^(-2) sum_{x,y}<S_x . S_y>_{beta,L,J}=m_{S,beta,J}^2.
```

The weighted exchange clock has dimensionless low-temperature parameter `theta=beta J_min` and rate ratio `rho=J_max/J_min`; the proof threshold is finite `theta_0(S,rho)`, so `beta_0(S,J)=theta_0(S,rho)/J_min`. No explicit numerical value is supplied by the source. The anisotropy is **spatial only**: every bond couples `S_x dot S_y`, so the Hamiltonian is still exactly SU(2)-invariant. The theorem does not cover XXZ/single-ion spin anisotropy, external field, disorder, frustrated/negative bonds, or a missing spatial direction. Strict `J_min>0` is essential to the proof: at `J_3=0` the system becomes uncoupled two-dimensional layers, the weighted slot graph has nonconstant zero modes, its required 3D Nash coercivity vanishes, and the finite-temperature Mermin–Wagner obstruction applies.

## Proof integration, by source dependency

The primary manuscript is the pinned family-271 spherical-law PDF, Theorem 1.1 and Sections 2–8, at commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`. Its main burden is concentration of the total-spin label `J_L/V` at the field-selected pressure radius; SU(2) symmetry alone allows mixtures of radii. The source proves a sparse-pin spatial comparison, a weak exponential bound for zero-sum block tests, vanishing cross-replica terms, and a harmonic pressure-tangent argument before using SU(2) representation theory. Here is the exact transfer audit.

### 1. Exchange representation and conditioned cycles

Put `ell=2S` spin-half slots at each site. On every slot edge above a direction-`i` site bond, run a Poisson transposition clock of rate `J_i/2` over time interval `[0,beta)`; the seam still uses an independent uniform permutation within each site. Since for a spin-half pair `s_u dot s_v=(U_uv/2)-(I/4)`, summing the `ell^2` slot pairs over a bond gives the weighted physical Heisenberg bond plus its scalar. Thus the slot/seam trace identity remains exact, with the scalar prefactor adjusted to the weighted total bond rate. Each weighted bond-swap sum commutes with the product of sitewise symmetric-slot projections, and spin compression is unchanged.

Use the dimensionless time `theta=beta J_min` and ratios `j_i=J_i/J_min in [1,rho]`, `rho=J_max/J_min`; the weighted interval `[0,beta)` at rates `J_i/2` is exactly the interval `[0,theta)` at rates `j_i/2`. Thus all low-temperature powers are in `theta`, with constants depending on `S,rho`, and the threshold can be written `beta_0(S,J)=theta_0(S,rho)/J_min`. The finite pin and determinant/next-pin statements in source Lemmas 2.1–2.2 already permit independent Poisson exchanges on an arbitrary finite slot graph and an arbitrary admissible permutation law. Their proofs use only independence, the rank-one transposition identity, stability under Bernoulli transpositions, and the prescribed positive-rate edge intensity. Unequal directional rates therefore leave (2.8), (2.11)–(2.16) exact with weighted mean transition matrix `K`. This preserves the crucial scope distinction: conditional next-pin *first moments* are represented by an independent-transition hitting walk; the original repeated permutation trajectories do not become independent.

After exposing cycles, the fresh one-turn hole walk has symmetric direction-weighted heat-kernel factors, forced transports that are bijections, and uniform residual seam completions. Thus `K` remains doubly stochastic. Ghost killing is still an independent Bernoulli switch with `q=1-e^{-b}`, so `U=(1-q)K` and the return-energy gap

```
E g = <g,(I-(U+U*)/2)g> >= q ||g||_2^2
```
are unchanged. The Poisson factorial estimate must use `d lambda_J(e,t)=(J_dir(e)/2)dt`; its local upper bound is the old one with the rate multiplied by `J_max`.

### 2. Weighted Nash, localization, and sparse pins (Sections 3–5)

At a slice let `D_0(v)=1/2 sum_edges (v_a-v_b)^2` be the unweighted available-slot energy used by the released lattice lemma, and

```
D_J(v)=1/2 sum_edges J_dir(a,b)(v_a-v_b)^2.
```
On every available-slot graph,

```
J_min D_0 <= D_J <= J_max D_0,
||v||_2^(10/3) <= (C/J_min) D_J(v)||v||_1^(4/3).
```
The available graph itself is unchanged. The released deterministic 3D graph supplies both Nash smoothing and a divergence-one unit flow with pointwise decay exponent `k=199/100`. The same unweighted flow is valid under weighted energy and satisfies

```
sum_e F(e)^2/J_dir(e) <= J_min^(-1) sum_e F(e)^2.
```
Therefore the tapered sparse-source pairing becomes, with source notation `m_T,A,L,q`,

```
|<mu,Y>| <= C J_min^(-1/2) sqrt(m_T A^alpha) sqrt(D_J(Y))
            + C m_T L^(1/2-k)||Y||_2,
```
where `alpha=1/100`, `k=199/100`. The divergence-cutoff error is unchanged; Cauchy–Schwarz uses the reciprocal-conductance flow energy.

For the continuous hole walk, `H'=-2D_J(v)` on regular times, so the weighted Nash inequality yields half-turn `2`-norm smoothing `C(S,rho) theta^(-3/4)` and one-turn entry bound `C(S,rho) theta^(-3/2)`. A path leaving a local ball uses actual picture marks and independent fresh clocks. After time rescaling, its local mark intensity is bounded above by `C_S rho`; the ordered-path estimate is `(C_S rho theta)^a/a!`. Taking localization radius `A=ceil(C_loc(S,rho) theta)` yields discarded mass `C_{S,rho} exp(-c_{S,rho} theta)`. In original units, `J_min` enters smoothing and `J_max` enters path/short-time bounds; after rescaling, these are the normalized bounds `1` and `rho`.

The exact return decomposition (3.14)–(3.18), ghost killing, and downward induction on deterministic pins need no algebraic change. In the return estimate (3.20), only constants change:

```
r(E,T) <= C_{S,rho} [ exp(-c_{S,rho} theta) + Delta_A
       + A^alpha theta^(-3/2) + A^alpha theta^(-1)
       + |T| L^(1-2k)/q ],
```
with `Delta_A <= C_{S,rho} A^3 p^6 + C_{S,rho}exp(-c A^(lambda nu))` and the source exponents `alpha=1/100`, `k=199/100`, `nu=1/300`, and `lambda=log_a 2`. As `A=Theta_{S,rho}(theta)`, the terms decay as `exp(-c theta)`, `O_{S,rho}(theta^(-12/5))`, `O_{S,rho}(theta^(-149/100))`, and `O_{S,rho}(theta^(-99/100))`, respectively. Since `p=theta^(-9/10)`, all are `o(p)` as theta grows. Sparseness gives `|T|<=C_s L^alpha`, and `q>=L^(-5/2)` makes the torus-cutoff remainder `O(L^(-47/100))`. Choose `theta` first, then `L_*(theta,S,rho)`; the same finite pin induction yields the source sparse-pin result with `p=theta^(-9/10)=(beta J_min)^(-9/10)`.

The six-block/short-time estimates use the same source combinatorics, replacing normalized rates by their upper bound `rho`; weighted connectivity and transition lower bounds use the normalized lower bound `1`. The comparison/communication graph in Section 4 has positive endpoint transition probability and positive contact-rate lower bound for all fixed `J_min>0`; constants become `C_{theta,S,rho}` while the spatial powers remain unchanged. This gives the source weak-field spatial estimate and Section 5 zero-sum block exponential bound with constants and length thresholds depending on `S,rho,theta`. The order remains `theta` (equivalently beta for fixed J) fixed, then `L,R` limits. The independent audit and all intermediate rate substitutions are in [nash_sparsepins_audit.md](nash_sparsepins_audit.md).

### 3. Translation-invariant variational endpoint (Section 6)

The anisotropic directional Hamiltonian is still bounded, finite-range, and translation-invariant. Source Proposition 6.1’s entropy-density, Gibbs variational, compactness, and pressure-slope arguments use only those properties, not equality of the three directional coefficients. The equilibrium face is therefore redefined using `H_J`; SU(2) gives the same rotation relation between directional pressure slopes. With the just-transferred Section 5 zero-sum replica estimate, source Lemma 6.3 applies to the anisotropic equilibrium face and eliminates spatially averaged cross-replica terms. This is the exact interface between the sparse-pin and pressure-tangent audits.

### 4. Exact weighted pressure-tangent cancellation (Section 7)

The independently reconstructed algebra appears in [pressure_tangent_audit.md](pressure_tangent_audit.md), equations (A)–(D). Its explicit constants are

```
g_B = 2(1-cos(pi/B)),
c_B = 1/(J_min B^3 g_B),
D_B = 96 c_B J_max B^3 + 1.
```
On each side-`B` cube, the slot bond Laplacian has spectral gap at least `ell J_min g_B`, so `Q_C=c_B L_bond,C^J-B^(-6)L_full,C` is PSD. On side-`W` cubes, `R_C=D_B W^(-6)L_full,C-(c_B/n_{B,W})sum_{C' subset C}L_bond,C'^J` is PSD for every `W>=2B`. The weighted static reduction uses `-c_B J_i` on an axis-`i` bond. In the X/Z directions the large-cube weighted term cancels that reduction once each small cube is counted in its `n_{B,W}` containing large cubes; in Y, the small-cube term leaves exactly the complete-graph coefficient `-B^(-6)`. Ordered slot-pair compression gives

```
P_* T_{B,L}^J P_* = -2 c_B (B-1)B^2 sum_{x,i} J_i S_x . S_{x+e_i}.
```
Thus the perturbed directional coefficient is `J_i (beta-2t c_B(B-1)B^2)`, positive for every axis whenever `0<t<beta/[2c_B(B-1)B^2]`. Here `t` is the dimensionless perturbation parameter and occurs linearly in the coefficient; it does not occur in the denominator of its own bound. This matches the source's isotropic coefficient `beta-2t c_B(B-1)B^2`. No equal-spatial-coupling dependency remains in (7.4)–(7.8). Exact SU(2) invariance is essential and remains intact. The scalar diagonal contribution is uniform because fixed directional couplings are translation-invariant.

### 5. Total-spin endpoint (Section 8)

For any fixed anisotropic interaction of the stated form, the finite-volume Gibbs state commutes with global SU(2) rotations. Its representation decomposition and the conditional uniform spectrum of any one total-spin component are unchanged. The pressure upper-tail argument uses the anisotropic `p_{S,beta,J}` and its right derivative. The transferred Section 5 estimate and weighted pressure-tangent result give the same lower normalized Casimir bound with that `m`. Hence `J_L/V -> m` in probability and the same spherical moment-generating transform follows. The pin corollary itself supplies `m>=S(1-theta^(-9/10))>0`, with `theta=beta J_min`, after the weighted low-temperature threshold; positivity need not be assumed from an unrelated theorem.

This is the full weighted transfer proof, modulo correctness of the cited source lemmas and proof blocks themselves. It does not use a theorem headline to infer that anisotropy is harmless; it verifies the direction-dependent rates through each proof dependency and the exact ordered-pair cancellation.

## Higher-value consequence: infer the anisotropic stiffness determinant from one zero-field component

The same pinned family 271 contains a separate Bloch-law theorem for every nonnegative symmetric finite-range spatial coupling whose support generates `Z^3`. This companion concerns pressure magnetization only, not spherical concentration. For our convention `J(±e_i)=J_i`, its dispersion matrix is

```
D_{S,J}=(S/2) sum_z J(z) z z^T = S diag(J_1,J_2,J_3),
```
so the source’s low-temperature asymptotic is

```
lim_{beta->infinity} beta^(3/2)(S-m_{S,J}(beta))
 = C_J := zeta(3/2)/(8 pi^(3/2) S^(3/2) sqrt(J_1 J_2 J_3)).
```
The release order is the thermodynamic limit first, the positive-field derivative second, and beta-to-infinity last. The newly useful combination with the transferred sphere law is a zero-field, one-component observable formula. Let `X_L=M_L^3/V` be the spectral outcome of the *single self-adjoint total-spin component*; no simultaneous vector measurement is made. At each fixed sufficiently low beta,

```
X_L => Uniform[-m_{S,J}(beta),m_{S,J}(beta)],
E X_L^2 -> m_{S,J}(beta)^2/3,
E X_L^4/(E X_L^2)^2 -> 9/5.
```
Consequently the complete two-limit statement is

```
lim_{beta->infinity} beta^(3/2) [ S - sqrt( 3 lim_{L->infinity} E X_L^2 ) ] = C_J.
```
This lets the symmetric zero-field fluctuation histogram encode the determinant (product) of the anisotropic spin stiffness, rather than extracting `m` only from a small positive field. The `9/5` normalized one-axis fourth/second moment is a calibration-free asymptotic signature of deterministic radius; a rotation-invariant mixture of radii gives a ratio `(9/5) E[R^4]/E[R^2]^2 >= 9/5`, with equality only at a fixed radius.

This is a genuine quantitative **asymptotic prediction** beyond the bare directional extension, but it is not a finite-specimen engineering protocol. The Bloch companion gives only an `o(beta^(-3/2))` remainder and the spherical-law manuscript gives no `L`-dependent bias rate. Therefore no finite `(L,beta)` can yet be certified to achieve a specified material error.

## Measurement contract, calibrations, and costs

For a fixed beta and axis, collect `R` independently equilibrated specimens (or independent equilibrium draws) and one `M^3` measurement per draw; alternatively sum `V` single-site spin readouts. Since `X_L in [-S,S]`, the estimator

```
mhat = (2/R) sum_{r=1}^R |X_L^(r)|
```
has sampling error at most `eta` with probability at least `1-delta` if

```
R >= (2 S^2 / eta^2) log(2/delta).
```
Its total error is this sampling error plus unknown thermodynamic bias `b_L=|2 E|X_L|-m_{S,J}(beta)|`; the source proves only `b_L -> 0`. For the Bloch coefficient, resolving the deficit requires `eta=o(beta^(-3/2))`, hence `R` on the order of `beta^3` up to tolerance and confidence factors, plus finite-size and temperature/coupling systematic errors smaller than that deficit. At first order, relative error in `C_J` from couplings is `1/2 sum_i delta J_i/J_i`; `S`, beta/temperature, and `J_i` need external calibration. To maintain the uniform zero-field orientation, a residual field must satisfy `beta V |h| -> 0` (otherwise the limiting direction law is tilted). Readout resolution must scale to the target per-site precision; equilibration/autocorrelation, boundary/domain effects, dipolar/spin-orbit terms, field gradients, material selection, and dollars/joules are all unmeasured. The strongest control is same-`S,T,J` low-field pressure magnetization with matching geometry and thermal preparation; the zero-field histogram has no small applied field but does not yet have a finite-size certificate.

A usable finite-material theorem would need an explicit bound such as

```
W_1(Law(X_L), Uniform[-m_{beta,J},m_{beta,J}]) <= r_{S,beta,J}(L),
```
plus a parameter modulus for `m` and quantified preparation/readout conditions. Then `2 r(L)` directly bounds the radius-estimator's distributional bias. The source has no such `r(L)` or explicit `L_0(epsilon)`, so do not claim finite-volume certification.

The follow-up finite-size audit in [finite_volume_rate_gate.md](finite_volume_rate_gate.md) extracts the quantitative part that *is* in the proof: the nested-partition comparison has an explicit `C_{S,beta,J}/log R_*` term and a telescoping remainder of order `C_{S,beta,J}(1+log log L) exp(-c_{S,beta,J} sqrt(L))`. The remaining lower-bound step in Proposition 8.2 replaces fixed-cell local convergence by `o_L(1)` and supplies no modulus. The upper-tail step can use the finite-torus pressure error `O(beta S(S+1)(J_1+J_2+J_3)/L)`, but its field scale `h_epsilon` is only existential from the pressure derivative. Consequently the source yields a useful symbolic conditional bound, not an explicit size/sample budget. The orientation coexistence itself is not a counterexample: the proof establishes the same radius in every ergodic equilibrium state. A rate uniform as `J_min` tends to zero is impossible because the limiting model at `J_min=0` has decoupled lower-dimensional layers, but this does not rule out a fixed-parameter rate for strictly positive couplings.

## Prior art and release boundary

The spherical-law source explicitly proves only equal nearest-neighbor spatial couplings. The same release’s distinct Bloch-law companion permits nonnegative symmetric finite-range anisotropic spatial couplings and provides the pressure-magnetization asymptotic above; this does not by itself prove `J_L/V` concentration or a spherical finite-volume law. The complete-graph spherical transform of Björnberg–Fröhlich–Ueltschi ([arXiv:1811.12834](https://arxiv.org/abs/1811.12834)) and Ueltschi’s loop-soup derivation ([arXiv:1703.09503](https://arxiv.org/abs/1703.09503)) are antecedents but not the anisotropic lattice claim. A targeted primary-source search found no independent anisotropic spherical-law theorem; broad priority remains UNKNOWN. The family index reports no independent build and no expert review for the released source.

Astra N02 is useful interface context, not a proof premise: it assumes the total-spin length is already concentrated and retains that concentration error as a remainder. It does not provide the anisotropic weighted concentration argument. The current source/primary interface audit and no-finite-size-rate finding are in [prior_and_interface_audit.md](prior_and_interface_audit.md).

## Evidence status and next decisive gate

- **Internal proof transfer:** direction-weighted exchange/pins, sparse-pin return powers, Sections 4–5 constants, translation-invariant variational endpoint, weighted pressure factorization, and SU(2) total-spin endpoint checked in the notes linked above. Full argument assumes the base source’s unweighted deterministic lattice and zero-free estimates are correct.
- **Source-reported:** family-271 isotropic spherical law and anisotropic Bloch asymptotic at the pinned release. The source is not externally audited in its verification record.
- **Not established:** independent proof validation of the source itself, priority of the anisotropic spherical law, finite-size bias/rate, a named real-material calibration/equilibration protocol.

The next mathematical gate is not another anisotropic bound: all weighted substitutions have been supplied. It is independent scrutiny or formal/source-level validation of the original family-271 sparse-pin, weak-field, zero-free, and pressure-tangent proof blocks. The next experiment gate is a 3D spin-isotropic material with measured `S,J_i,T`, residual field well below `(beta V)^(-1)`, controlled boundaries and nonexchange interactions, and an independent equilibrium-sampling protocol; until it supplies finite-size bias and equilibration data, report only a model asymptotic, not a certified specimen prediction.

## Independent audit files

- [Nash, conditioned cycles, and sparse pins](nash_sparsepins_audit.md)
- [Pressure-tangent weighted Laplacian algebra](pressure_tangent_audit.md)
- [Primary prior art and finite-size measurement interface](prior_and_interface_audit.md)
- [Pinned source extraction and scope](../source_notes/family271_source_audit.md)
