# Cycle 6 audit: anisotropic rates through Sections 2–5

## Verdict and scope

For fixed spin \(S\) and fixed constants \(0<J_-:=\min_iJ_i\le J_i\le J_+:=\max_iJ_i<\infty\), I find no weighted-rate obstruction in the Sections 2–5 mechanism audited here. Every place where the isotropic rate \(1/2\) enters the exchange/pin construction admits an exact replacement or a bound with constants depending on \(S,J_-,J_+\); the sparse-pin exponents remain unchanged. This is a transfer audit conditional on the source's unweighted deterministic lattice Nash/flow lemmas and its other released arguments. It is not an independent proof validation of that source. The anisotropic spherical-law candidate remains **UNKNOWN**.

The quantifiers needed for the sparse-pin step are: fix \(S,J\); choose \(\beta_0(S,J,C_s)\); for each fixed \(\beta\ge\beta_0\), choose \(L_*(\beta,S,J)\); then for even \(L\ge L_*\), every \(q\in[L^{-5/2},1)\), every allowed finite extra pin set, and every sparse test \(T\) at one time, the desired bound is \(P_E(T\subset B_E)\le (\beta^{-9/10})^{|T|}\). The constants need not be uniform as \(J_-\downarrow0\) or \(J_+\uparrow\infty\).

## Exact finite identities

Write \(\ell=2S\), and put independent Poisson transpositions of rate \(J_i/2\) on each slot edge above a spatial bond in direction \(i\). For one slot pair, \(s_x\cdot s_y=\tfrac12 U_{xy}-\tfrac14I\). Summing all \(\ell^2\) slot pairs over a bond and multiplying by \(J_i\) gives the weighted Heisenberg bond plus a scalar. Hence the layer/seam representation (source (2.2)) is exact with scalar \(\exp\{(\beta\ell^2/4)\sum_{\langle xy\rangle}J_{xy}\}\); each weighted bond-swap sum commutes with the sitewise symmetric-slot projector. Directional rates do not affect the spin-\(S\) compression or SU(2) invariance.

Unequal-rate finite-time Poisson products are still admissible permutation laws. Lemma 2.2's exterior-power/determinant proof only uses independence and the rank-one transposition identity, so (2.11)–(2.16) remain exact for their mean matrix \(K\). In particular, after exposure and conditioning all residual cycles to hit the pins, the *conditional next-pin first moment* is still the first-hit kernel of the independent-transition Markov walk with transition matrix \(K\); the original repeated permutation paths are not thereby made independent. Soft pins are independent Bernoulli switches with the same \(q=1-e^{-b}\), unaffected by \(J\). The ghost-killed one-turn real-hole kernel remains \(U=wK\), \(w=1-q\), and \(K\) is doubly stochastic: weighted heat factors are symmetric stochastic kernels, while transports and residual seam completions are bijective/uniform. Therefore
\[
\mathcal E g=\langle g,(I-(U+U^*)/2)g\rangle\ge q\|g\|_2^2
\]
is unchanged.

The factorial insertion estimate must use the weighted intensity measure, not an isotropic one: for ordered distinct marks it is \(2^j\int F\,d\lambda_J^{\otimes j}\), where \(d\lambda_J(e,t)=(J_{\operatorname{dir}(e)}/2)\,dt\). Thus it remains exact, and any local union bound with \(n\) relevant site-stars is at most the source bound with intensity \(C_SJ_+n\) times the interval length. This supplies all mark-count and short-time-flag estimates below.

## Weighted geometry and sparse-pin induction

At a time slice, define
\[
D_J(v)=\frac12\sum_{\{a,b\}\text{ available}}J_{\operatorname{dir}(a,b)}(v_a-v_b)^2.
\]
The source energy is \(D_0(v)=\tfrac12\sum(v_a-v_b)^2\). Uniform ellipticity gives, on every available-slot graph,
\[
J_-D_0(v)\le D_J(v)\le J_+D_0(v),\qquad
\|v\|_2^{10/3}\le (C/J_-)D_J(v)\|v\|_1^{4/3}.
\]
This is the needed Nash transfer; graph regularity and the flow construction themselves are unchanged. The same source unit flow satisfies
\[
\sum_e F(e)^2/J_{\operatorname{dir}(e)}\le J_-^{-1}\sum_eF(e)^2.
\]
Consequently the tapered-flow pairing (source (3.12)) becomes
\[
|\langle\mu,Y\rangle|\le C J_-^{-1/2}\sqrt{mA^\alpha}\sqrt{D_J(Y)}
       +CmL^{1/2-k}\|Y\|_2,
\]
where the unchanged cutoff-divergence error has \(k=199/100\). The factor 2 in Cauchy–Schwarz is absorbed into \(C\).

Nash dissipation over a regular half-turn now gives localized \(2\)-norm \(C(S,J_-)\beta^{-3/4}\), hence a one-turn localized entry bound \(C(S,J_-)\beta^{-3/2}\). For escape localization, count paths using actual marks and independent fresh clocks; each has total local rate bounded by \(C_SJ_+\). The source factorial estimate is therefore \((C_SJ_+\beta)^a/a!\); choosing \(A=\lceil C_{\mathrm{loc}}(S,J_+)\beta\rceil\) makes the discarded mass \(C_{S,J}e^{-c_{S,J}\beta}\). No all-hit-conditioned fresh-clock estimate is needed.

In the return-energy step, the exact algebra (3.14)–(3.18) and the ghost killing gap are unchanged. The only change in (3.19) is
\[
|J_d|\le C\left[\sqrt{\frac{m_TA^\alpha}{\beta J_-}}
       +\frac{m_TL^{1/2-k}}{\sqrt q}\right]\sqrt{\mathcal E g}.
\]
Completing the square changes the leading term in (3.20) to \(C m_TA^\alpha/(\beta J_-)\); the torus-cutoff term remains \(C m_TL^{1-2k}/q\). Thus the return bound is bounded by
\[
C_{S,J}\{e^{-c_{S,J}\beta}+\Delta_A
  +J_-^{-3/2}A^\alpha\beta^{-3/2}
  +J_-^{-1}A^\alpha/\beta
  +m_TL^{1-2k}/q\},
\]
with \(\Delta_A=C_{S,J}A^3p^6+C_{S,J}e^{-c_{S,J}A^{\lambda\nu}}\), \(p=\beta^{-9/10}\), \(\alpha=1/100\), \(\lambda=\log_a2\), and \(k=199/100\). The first polynomial term in \(\Delta_A\) is \(O_{S,J}(\beta^{-12/5})\); the two diffusion/flow terms are \(O_{S,J}(\beta^{-149/100})\) and \(O_{S,J}(\beta^{-99/100})\), both \(o(p)\). Sparseness gives \(m_T\le C_sL^\alpha\), and \(q\ge L^{-5/2}\) makes the last term \(O(L^{\alpha+7/2-2k})=O(L^{-47/100})\). Therefore choose beta first, then \(L_*(\beta,S,J)\), so \(2r(E,T)\le p\) and the same finite downward induction closes. For the six-site and sparse-blocking bounds, replace source mark constants by \(C_SJ_+\); the exponents \(p^6\), \(C\sqrt p\), and the stretched-exponential component tail persist after increasing \(\beta_0(S,J)\).

## Check through Sections 4–5

The resolvent and pin identities using \(D=I-wK\) are algebraic and need only the weighted \(K\) above. In the communication graph argument (source Lemma 4.4), an endpoint transition has probability at least \(c_{\beta,S,J}>0\); a contact lasting \(\tau\) has a specified one-jump transition probability at least \(c_{\beta,S,J}\tau\), using \(J_-\) for that edge and an \(e^{-C_SJ_+\beta}\) no-other-jump factor. Thus the comparison constants become \(C_{\beta,S,J}\) (and the contact cost \(C_{\beta,S,J}\tau^{-1}\)); positivity \(J_->0\) is essential. Bad-box path and flag bounds use \(C_SJ_+\) in the factorial intensities. At fixed beta, the choice of delta and then large \(R\) still works, so the powers of \(R\) in Sections 4–5 are unchanged, with constants and thresholds depending on \(S,J,\beta\).

The remaining Section 5 steps use translation invariance, spin rotation invariance, commutation of the Hamiltonian with total-spin Casimir, and zero-freeness for admissible permutation layers. All hold for direction-dependent scalar couplings: each bond remains an SU(2)-scalar, and lattice translations preserve the three fixed directional couplings. Hence no new \(J_i\)-dependent term enters the strip-curvature or nested-partition exponents once the weighted Section 4 estimate is available.

## First failure boundary / status

No weighted inequality in this chain fails for the stated fixed, strictly positive finite \(J_i\). The first necessary dependency that would fail if the assumptions were weakened is coercivity at \(J_-=0\): \(D_J\ge J_-D_0\) disappears, the transverse graph may split into lower-dimensional layers, the Nash smoothing and unit-flow energy comparison no longer follow, and the prescribed contact edge need not have positive transition probability. The upper-rate bound also requires finite \(J_+\) for the uniform factorial/path controls.

This audit proves the rate substitutions against the source's stated unweighted Lemma 3.2 and Sections 2–5 identities; it does not validate the source's underlying deterministic lattice results, all its isotropic estimates, Sections 6–7 variational argument, or novelty. Accordingly it supplies no theorem-level upgrade: anisotropic spherical-law claim remains **UNKNOWN**.
