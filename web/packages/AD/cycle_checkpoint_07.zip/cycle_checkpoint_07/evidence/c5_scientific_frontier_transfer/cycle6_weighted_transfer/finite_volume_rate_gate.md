# Finite-volume rate audit for the one-axis law

## Result of the audit

The source contains a useful partially quantitative finite-volume route, but it does not supply a W1 rate or an explicit specimen size. Tracking its parameters isolates two non-effective moduli: (i) how quickly finite-torus local marginals approach the equilibrium-state set for fixed terminal blocks, and (ii) how small a field must be for the infinite-volume pressure secant to approximate its right derivative. The fixed-parameter theorem implies both moduli tend to zero in the required order, but the source does not bound either one in terms of (S,\beta,J_i\). Phase coexistence is not by itself a counterexample: all ergodic equilibrium states in the source proof have the same magnetization radius.

## Exact finite-volume conversion from total spin to one component

Let (V=L^3), (Y_L=J_L/V\in[0,S]), and (X_L=M_L^3/V\). The finite-volume Gibbs state commutes with global SU(2). Conditional on (J_L=j), (X_L) is uniform on

\[
\{-j/V,(-j+1)/V,\ldots,j/V\},
\qquad
\mathbb E[X_L^2\mid J_L=j]=\frac{j(j+1)}{3V^2}.
\]

Coupling this grid in quantile order to (U[-j/V,j/V]) costs at most (1/V) in W1; changing the radius from (Y_L) to (m=m_{S,\beta,J}) costs |Y_L-m|/2. Therefore the exact implication is

\[
W_1(\mathcal L(X_L),U[-m,m])
\le V^{-1}+\tfrac12\mathbb E|Y_L-m|.
\tag{1}
\]

For the measured second moment, the exact identity is

\[
\mathbb E X_L^2=\frac{\mathbb E[J_L(J_L+1)]}{3V^2}.
\tag{2}
\]

Thus the genuine missing finite-volume input can be stated as a bound on the radius label; there is no noncommuting-observable issue.

## What the nested partitions quantify

The anisotropic rate substitutions preserve the powers in Propositions 5.2–5.3, with constants now depending on the fixed (S,\theta=\beta J_{\min},\rho=J_{\max}/J_{\min}\). In the nested partition, (R_0=L), (R_{j+1}=R_j^{9/10}), and the terminal scale obeys

\[
R_*\le R_n<R_*^{10/9},\qquad
n=O(\log\log L).
\]

At each refinement the proof gives an expected squared-increment error bounded by

\[
C_{S,\theta,\rho}(\log R_j)^{-1}
+C_{S,\theta,\rho}\exp(-c_{S,\theta,\rho}V R_j^{-5/2}).
\]

Since (V R_0^{-5/2}=L^{1/2}), the explicit telescoped remainder is

\[
\varepsilon_{\rm part}(L,R_*)
=\frac{C_{S,\theta,\rho}}{\log R_*}
+C_{S,\theta,\rho}(1+\log\log L)e^{-c_{S,\theta,\rho}\sqrt L}.
\tag{3}
\]

This is an actual extracted error term, rather than an unspecified (o_L(1)). The source uses (3) in Proposition 8.2 only after (L\to\infty) at fixed (R_*), because the finite-volume expectation of terminal-cell observables is replaced by its limit in an equilibrium state.

Make that missing term explicit as follows. Let \(\mathcal C_*(R_*)\) be the finite collection of integer rectangular shapes with side lengths in 
\([R_*/2,4R_*^{10/9}]\), and set

\[
\delta_{\rm loc}(L,R_*)=
\left[m^2-\min_{C\in\mathcal C_*(R_*)}
\sum_{a=1}^3\langle(S_C^a)^2\rangle_{\beta,L,J}\right]_+.
\]

The compactness argument in Proposition 8.2 implies 
\(\delta_{\rm loc}(L,R_*)\to0\) for each fixed (R_*), after the weighted Section 5 transfer. It gives no rate. Combining its block lower bound with (3) yields the semi-quantitative inequality

\[
\mathbb E Y_L^2\ge m^2-
\delta_{\rm loc}(L,R_*)-\varepsilon_{\rm part}(L,R_*)-S/V.
\tag{4}
\]

The (S/V) term changes (J(J+1)/V^2) to (J^2/V^2). For the component second moment (2), that correction is not needed. The source-derived guarantee is therefore a symbolic error formula with an unbounded \(\delta_{\rm loc}\), not a finite-size certificate. Choosing (R_*\) so that (C_{S,\theta,\rho}/\log R_*\le\epsilon) is explicit at the level of the source constants; the source gives neither their numerical values nor a bound on \(\delta_{\rm loc}\).

## A finite-volume pressure tail that can be made explicit up to a pressure modulus

For the anisotropic nearest-neighbor Hamiltonian, define

\[
\psi_L(h)=V^{-1}\log\operatorname{Tr}e^{-\beta(H_{L,J}-hM_L^3)},
\qquad \psi(h)=\lim_{L\to\infty}\psi_L(h)=\beta p_{S,\beta,J}(h).
\]

Cutting a periodic (L\)-torus into (q^3) independent periodic (L\)-blocks changes only the (3q^3L^2) inter-block bonds. Since \(\|\mathbf S_x\cdot\mathbf S_y\|=S(S+1)\), the log-partition Lipschitz inequality gives, uniformly in (h\),

\[
|\psi_L(h)-\psi(h)|\le
\frac{\beta S(S+1)(J_1+J_2+J_3)}{L}.
\tag{5}
\]

For \(0<\epsilon<S-m\), the derivative definition supplies some \(h_\epsilon>0\) with
\(p(h_\epsilon)-p(0)\le h_\epsilon(m+\epsilon/4)\). It does not supply a computable value of (h_\epsilon). Combining (5) with exponential Markov gives, for

\[
L\ge\frac{16S(S+1)(J_1+J_2+J_3)}{h_\epsilon\epsilon},
\]

\[
\mathbb P(M_L^3/V>m+\epsilon/2)
\le e^{-\beta h_\epsilon\epsilon V/8}.
\]

For all sufficiently large (V\), conditional on (J_L/V>m+\epsilon), at least an \(\epsilon/[4(2S+1)]\) fraction of its uniformly distributed magnetic levels satisfy (M_L^3/V>m+\epsilon/2). Hence

\[
\mathbb P(Y_L>m+\epsilon)
\le \frac{4(2S+1)}{\epsilon}
e^{-\beta h_\epsilon\epsilon L^3/8}.
\tag{6}
\]

This is stronger than the source's stated limiting upper-tail conclusion: the finite-torus pressure approximation contributes an explicit (L^{-1}) boundary error. But (6) remains non-effective because (h_\epsilon) is obtained only from the derivative limit. The anisotropic Bloch asymptotic does not determine this fixed-β small-field modulus.

## W1 bound conditional on the missing modulus

Equations (4) and (6) give a transparent route to an actual one-axis rate if \(\delta_{\rm loc}\) and (h_\epsilon) are bounded. For (0<\epsilon_0<m), (0<\epsilon_1<S-m), define

\[
d=\delta_{\rm loc}(L,R_*)+\varepsilon_{\rm part}(L,R_*)+S/V,
\quad \alpha=\mathbb P(Y_L>m+\epsilon_1),
\]

and

\[
\Delta=(m+\epsilon_1)^2-(m-\epsilon_0)^2.
\]

Splitting the radius distribution below (m-\epsilon_0), in the middle interval, and above (m+\epsilon_1), (4) implies

\[
\mathbb P(Y_L<m-\epsilon_0)
\le \frac{(m+\epsilon_1)^2-m^2+d+S^2\alpha}{\Delta}.
\tag{7}
\]

Consequently, with \(a=\max(\epsilon_0,\epsilon_1)\),

\[
W_1(\mathcal L(X_L),U[-m,m])
\le V^{-1}+\frac12\left[
a+S\left(\alpha+
\frac{(m+\epsilon_1)^2-m^2+d+S^2\alpha}{\Delta}\right)
\right].
\tag{8}
\]

This is a derived conditional finite-size W1 inequality with the source's actual scales and a concrete place to insert a local-equilibrium modulus. It is not a numeric bound until the two non-effective quantities are controlled. For the second moment, (2), (4), and (6) give the explicit conditional bound

\[
\left|\mathbb E X_L^2-\frac{m^2}{3}\right|
\le \frac13\max\left\{
\delta_{\rm loc}(L,R_*)+\varepsilon_{\rm part}(L,R_*),
(m+\epsilon_1)^2-m^2+S^2\alpha+S/V
\right\}.
\tag{9}
\]

As with (8), this is not a numeric rate while \(\delta_{\rm loc}\), \(h_{\epsilon_1}\), and the weighted constants are unbounded.

## Why the current source cannot finish the bound

1. The source explicitly says the entropy-density step (6.5) has no rate. Lemma 6.3 first sends the replica box size to infinity at a fixed sparse-test scale. Its proof is qualitative compactness/variational convergence.
2. Proposition 8.2 takes local limits of periodic Gibbs states, then uses the finite list of fixed terminal cell shapes. That proves \(\delta_{\rm loc}\to0\) by contradiction, but no finite-box free-energy stability modulus for these local expectations is derived.
3. Proposition 7.1 selects nonvanishing random traces through a second-moment argument with sequential existential choices (t\), then (L\), then product-formula order (k\). The harmonic compactness argument records no numerical modulus. Thus the radius-locking input has no effective finite-size error from which \(\delta_{\rm loc}\) can be bounded.
4. The source defines (m\) by a right derivative and proves (m>0\), but gives no computable (h_\epsilon\) for the secant. The anisotropic Bloch statement is only a separate β→∞ leading asymptotic and supplies neither a fixed-β pressure modulus nor a remainder.
5. The anisotropic transfer has exact ellipticity/pressure-tangent constants, but the released Nash, localization, sparse-pin, and zero-free bounds carry non-explicit constants depending on (S,\theta,\rho). So even the (C_{S,\theta,\rho}) in (3) is not numerically instantiated in the source.

There is no falsifier here for a rate at one fixed strictly positive coupling vector and one fixed β above threshold. What can be ruled out is a rate uniform over the whole stated coupling class: as (J_{\min}\downarrow0), the anisotropic threshold \(\beta_0\sim\theta_0/J_{\min}\) diverges, and at (J_{\min}=0) the lattice decomposes into lower-dimensional layers where positive-temperature ordering fails. Uniformity near a critical-temperature boundary is likewise not asserted. The finite-volume observable is therefore an asymptotic model prediction only; a measurement capability requires an independently established bound on \(\delta_{\rm loc}\), a pressure-secant modulus (h_\epsilon), and numerical weighted constants.

## Pressure-tangent unit check

In the source's exponent convention, the unperturbed bond coefficient is \(\beta J_i\). The weighted static reduction contributes \(-2t c_B(B-1)B^2J_i\), so the coefficient is

\[
J_i\bigl(\beta-2t c_B(B-1)B^2\bigr).
\]

Here (c_B\) has units (J^{-1}), while (t) is dimensionless. The exact positivity interval is

\[
0<t<\frac{\beta}{2c_B(B-1)B^2}.
\]

There is no additional factor of (t) in the denominator. It agrees with the isotropic source formula (7.7), where \(c_B\) is dimensionless under (J_i=1\).
