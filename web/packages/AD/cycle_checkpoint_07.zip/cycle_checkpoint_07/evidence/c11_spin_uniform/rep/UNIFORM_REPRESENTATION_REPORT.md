# Cycle 11: dimension-uniform Spin(2n+1) representation and support reduction

## Result and status

This report proves a dimension-uniform representation reduction and a positive-dual separation principle for Spin-covariant spinor channels. It also gives a closed dimension-uniform family of pure-spinor orbit seeds, with exact grade moments. The reduction applies to every Clifford grade from 1 through n, keeps both output-swap sectors, and places no sign restriction on the channel transfers λₖ.

The remaining dimension-uniform broadcaster-to-comparator assertion is reduced to one explicit family of star-matrix inequalities. I do **not** prove those inequalities for all n, and I do not assert a counterexample. Their status is **UNKNOWN** outside the exact n=4,5 checks recorded in cycles 9 and 10. Thus this is a reusable theorem-level reduction and a precise unresolved gate, not an all-dimensions common-comparator theorem.

## Conventions and channel coordinates

Let V=ℝ^{2n+1}, let S be the complex spinor of dimension d=2^n, and choose Hermitian Clifford generators

\[
\Gamma_a\Gamma_b+\Gamma_b\Gamma_a=2\delta_{ab}I.
\]

For a subset A={a₁<…<aₖ}, put

\[
T_A=i^{k(k-1)/2}\Gamma_{a_1}\cdots\Gamma_{a_k},\qquad 0\leq k\leq n,
\]

and use normalized trace \(\tau(X)=\operatorname{Tr}(X)/d\). These are Hermitian, square to I, and satisfy \(\tau(T_AT_B)=\delta_{AB}\). The odd Clifford volume element is scalar in the irreducible representation, so grades 0 through n give the full decomposition

\[
\operatorname{End}(S)\cong\bigoplus_{k=0}^{n}\Lambda^k V,
\qquad d_k=\dim\Lambda^kV=\binom{2n+1}{k}.
\]

A Spin-covariant Hilbert--Schmidt-self-adjoint map is scalar on these multiplicity-free sectors. Write \(\Phi(T_A)=\lambda_kT_A\) on grade k and \(\lambda_0=1\). Unitality and trace preservation fix the scalar sector; complete positivity constrains the remaining real transfers, but no positivity assumption on any \(\lambda_k\) is used below.

## Pair interaction spectrum and full triple-space reduction

Define the grade-k pair operator on \(S^*\otimes S\)

\[
K_k=\sum_{|A|=k}T_A^T\otimes T_A.
\]

Under the Choi vectorization \(|X\rangle\!\rangle=(I\otimes X)|\Omega\rangle\), this is the map \(X\mapsto\sum_{|A|=k}T_AXT_A\). Since Clifford monomials of grades k and j commute with sign \((-1)^{kj-|A\cap B|}\), the pair decomposition \(S^*\otimes S\cong\bigoplus_{j=0}^{n}\Lambda^jV\) diagonalizes K_k. Its exact eigenvalue on grade j is

\[
\mu^{(n)}_{k,j}=
\sum_{\ell=0}^{\min(k,j)}(-1)^{kj-\ell}
\binom{j}{\ell}\binom{2n+1-j}{k-\ell}.
\tag{1}
\]

In particular \(\mu_{k,0}=d_k\), and for grade one \(\mu_{1,j}=(-1)^j(2n+1-2j)\). Formula (1) includes the top grade (k=n).

The gamma-trace decomposition of spinor-valued forms gives

\[
S^*\otimes S\otimes S\cong\bigoplus_{r=0}^{n}T_r\otimes M_r,
\quad \dim M_r=n+1-r,
\]

where \(T_r\) has highest weight \((\tfrac32^r,\tfrac12^{n-r})\) and

\[
\dim T_r=d\left[\binom{2n+1}{r}-\binom{2n+1}{r-1}\right],
\quad \binom{2n+1}{-1}=0.
\tag{2}
\]

One way to see the multiplicity is that \(\Lambda^jV\otimes S\) contains each T_r for 0≤r≤j, once. Hence a fixed T_r occurs once for each pair grade j=r,...,n. The dimension sum is exact:

\[
\sum_{r=0}^{n}(n+1-r)\dim T_r=d\sum_{j=0}^{n}\binom{2n+1}{j}=d^3.
\]

Use the 12-coupling basis of M_r indexed by j=r,...,n, and write

\[
D_{k,r}=\operatorname{diag}(\mu_{k,r},\mu_{k,r+1},\ldots,\mu_{k,n}).
\]

The output swap \(P_{23}\) acts on M_r by an orthogonal involution F_r. In this basis the complete ordinary-tensor star

\[
H_\alpha=\sum_{k=1}^{n}\alpha_k\sum_{|A|=k}
T_A^T\otimes(T_A\otimes I+I\otimes T_A)
\]

has the exact multiplicity block

\[
H_{\alpha,r}=\sum_{k=1}^{n}\alpha_k\bigl(D_{k,r}+F_rD_{k,r}F_r\bigr).
\tag{3}
\]

The top eigenvalue on the full triple product is the maximum over every r and both eigenspaces of F_r. The output-swap multiplicities are explicitly

\[
m_{r,\pm}=\#\{j\in\{r,\ldots,n\}:\epsilon_j=\pm1\},
\qquad \epsilon_j=(-1)^{(n-j)(n-j+1)/2},
\tag{4}
\]

because the flip on the grade-j summand of \(S\otimes S\cong\bigoplus_{j=0}^{n}\Lambda^jV\) has sign \(\epsilon_j\). Thus (2)--(4) retain the full tensor product and do not assume Bose support. The remaining numerical content of the all-n star problem is the family of recoupling involutions F_r, equivalently the Spin(2n+1) spinor 6j matrices; (1)--(4) do not themselves imply a mixed-weight upper bound.

## Canonical-EB support and explicit all-n orbit seeds

For a unit spinor ψ, define its grade moments

\[
s_k(\psi)=\sum_{|A|=k}|\langle\psi,T_A\psi\rangle|^2,
\qquad \eta_k(\psi)=s_k(\psi)/d_k.
\]

For nonnegative invariant weights \(\alpha\in\mathbb R_+^n\), let \(\Pi_k\) be the Hilbert--Schmidt projection onto grade k and define \(F_\alpha(\Psi)=\operatorname{Tr}_{HS}[(\sum_k\alpha_k\Pi_k)\Psi]\). Its support over all full-domain canonical measure-and-prepare channels is exactly

\[
S_{\mathrm{can}}(\alpha)=h_n(\alpha)
=\max_{\|\psi\|=1}\sum_{k=1}^{n}\alpha_ks_k(\psi).
\tag{5}
\]

Indeed, twirling a canonical channel leaves this invariant score unchanged. Refining its POVM effects into rank-one effects makes the score a weighted average of pure-seed scores, since the quadratic form has nonnegative coefficients. Conversely, the Spin orbit POVM with effects d|U_gψ⟩⟨U_gψ| dg, preparing the same orbit state, is normalized by irreducibility and attains the score in (5). Its transfer vector is \(\eta(\psi)\). Equation (5) is an exact support identity; it does not classify the moment image.

There is an explicit seed family for every n. In the Jordan--Wigner basis, let

\[
\psi_0=|0^n\rangle,
\qquad \psi_h=2^{-1/2}(|0^n\rangle+|1^h0^{n-h}\rangle),\quad 1\leq h\leq n.
\]

With out-of-range binomial coefficients set to zero, its moments are

\[
s_k(\psi_0)=\binom{n}{\lfloor k/2\rfloor},
\tag{6}
\]

and, for h≥1, writing z=k mod 2,

\[
s_k(\psi_h)=
\sum_{\substack{0\leq q\leq h\\ q\equiv hz\pmod 2}}
\binom{h}{q}\binom{n-h}{\lfloor k/2\rfloor-q}
+\mathbf 1_{k\geq h}\,2^{h-1}\binom{n-h}{\lfloor(k-h)/2\rfloor}.
\tag{7}
\]

For (6), a Clifford word has nonzero diagonal expectation on |0ⁿ⟩ exactly when each site contributes either zero or both local generators, with the final Z^{⊗n} generator optional. For (7), diagonal words contribute the first sum: if q paired sites lie among the h flipped bits and z=k mod 2 records the optional final generator, the two diagonal amplitudes agree exactly when q≡hz (mod 2). Off-diagonal words must flip exactly those h bits. For each choice of paired generators on the other n−h sites, exactly half of the 2^h choices on the flipped sites have a real transition amplitude; these give the second term. Each nonzero amplitude has magnitude one, so counting them gives the squared moments.

For clarity, the dimension-uniform seed hull is

\[
V_n=\{(s_1(\psi_h),\ldots,s_n(\psi_h)):0\leq h\leq n\}.
\]

It gives a lower bound \(h_n(\alpha)\geq\max_{v\in V_n}\alpha\cdot v\) for every real α, but the exact equality is proved here only as the definition in (5), not as reduction to (V_n). The formulas reproduce the finite seed data:

| n | h | (s₁,...,sₙ) |
|---:|---:|---|
| 4 | 0, 1, 2 | (1,4,4,6) |
| 4 | 3 | (0,1,7,7) |
| 4 | 4 | (1,0,0,14) |
| 5 | 0, 1, 2 | (1,5,5,10,10) |
| 5 | 3 | (0,2,7,8,14) |
| 5 | 4 | (1,1,1,14,14) |
| 5 | 5 | (0,0,5,10,16) |

These are exactly the three Spin(9) support vertices in cycle 9 and the four Spin(11) attained seeds in cycle 10. The cycle 10 report expressly does not claim that its four seeds classify all of \(\mathbb{CP}^{31}\); (7) does not remove that limitation at larger n.

An analytic outer bound is also uniform. For every pure seed,

\[
0\leq s_k,\qquad \sum_{k=1}^{n}s_k=d-1,\qquad s_1\leq1,\qquad s_2\leq n.
\tag{8}
\]

The sum is Parseval for a rank-one projector in the τ-orthonormal Clifford basis. The grade-one bound follows from \(\|\langle\Gamma(\cdot)\rangle\|\leq1\). For grade two, put a two-form in SO(2n+1) skew-normal form \(\sum_{a=1}^{n}\sigma_a e_{2a-1}\wedge e_{2a}\); its Clifford image is a sum of n commuting involutions, so its operator norm is at most \(\sum_a|\sigma_a|\leq\sqrt n\|\sigma\|_2\), giving s₂≤n. Thus the pure moment image lies in the polytope

\[
\mathcal O_n=\{s\geq0:\sum_ks_k=d-1,\ s_1\leq1,\ s_2\leq n\}.
\]

For n≥3, its support, for any signed vector α, is

\[
h_{\mathcal O_n}(\alpha)=
\max_{\substack{3\leq j\leq n\\u\in\{0,1\},\ v\in\{0,n\}}}
\bigl[u\alpha_1+v\alpha_2+(d-1-u-v)\alpha_j\bigr].
\tag{9}
\]

This is an outer bound on pure-seed support; for α≥0 it is also an outer bound on canonical-EB support by (5). It is not an exact moment polytope.

## Uniform broadcaster-to-comparator criterion, including negative transfers

Let Λ be a CPTP two-output extension of Φ with equal marginals Φ, and set its normalized Choi state to \(\rho=J_\Lambda/d\). Symmetrizing the outputs preserves the marginals. With (3)'s full star and the stated Choi convention,

\[
\operatorname{Tr}(\rho H_\alpha)=2\sum_{k=1}^{n}d_k\alpha_k\lambda_k.
\tag{10}
\]

For any fixed set W⊂ℝⁿ of attained pure-seed moment vectors, define \(h_W(\alpha)=\max_{v\in W}\alpha\cdot v\) and the corresponding orbit transfer vectors \(\eta(v)_k=v_k/d_k\). The following is a dimension-uniform sufficient criterion:

\[
\lambda_{\max}(H_\alpha)\leq\sum_{k=1}^{n}d_k\alpha_k+h_W(\alpha)
\quad\text{for every }\alpha\geq0.
\tag{11}
\]

If (11) holds, (10) implies, with x=2λ−1,

\[
w\cdot x\leq\max_{v\in W}w\cdot\eta(v)
\quad\text{for every }w\in\mathbb R_+^n,
\qquad (w_k=d_k\alpha_k).
\tag{12}
\]

Finite-dimensional convex separation says exactly that (12) is equivalent to

\[
x\in\operatorname{conv}\{\eta(v):v\in W\}-\mathbb R_+^n.
\]

Consequently one convex mixture of the full-domain orbit POVM channels has transfer vector η̄≥x coordinatewise. It is one canonical EB channel Ψ on all of M_d, and its sector transfers give \(\Psi-(2\Phi-\mathrm{id})\succeq0\) on Hermitian matrices. Crucially, this separation statement is valid for arbitrary x∈ℝⁿ: none of the \(\lambda_k\) need be nonnegative. Negative channel multipliers are included without changing the dual cone; only the test weights (w) are nonnegative because the target is componentwise PSD dominance.

Taking W=V_n in (11) gives a concrete dimension-uniform candidate:

\[
\lambda_{\max}(H_\alpha)\stackrel{?}{\leq}
\sum_{k=1}^{n}\binom{2n+1}{k}\alpha_k+
\max_{0\leq h\leq n}\sum_{k=1}^{n}\alpha_ks_k(\psi_h),
\qquad \alpha\geq0.
\tag{13}
\]

If true for every n, it would give a single full-domain canonical EB comparator for every Spin-covariant unital, trace-preserving, Hilbert--Schmidt-self-adjoint self-compatible spinor channel, including channels with negative grade transfers. The exact cycle 9 and cycle 10 checks establish their finite cases (using the seeds in the table), and no (n\)-uniform proof follows from those cases.

## Precise unresolved gate and evidence boundary

The decisive missing statement is (13), or an alternative uniform support bound strong enough to imply (12). In the representation coordinates above, it is exactly the family of matrix inequalities

\[
\sum_{k=1}^{n}\alpha_k(D_{k,r}+F_rD_{k,r}F_r)
\preceq
\left(\sum_{k=1}^{n}d_k\alpha_k+h_{V_n}(\alpha)\right)I_{M_r}
\tag{14}
\]

for every n, every r=0,...,n, every α≥0, and both output-swap eigenspaces. Formula (1) supplies the diagonal entries, and (4) supplies the two sign dimensions, but no dimension-uniform bound on the recoupling involutions F_r has been established here. Nor has the full pure-spinor moment support been reduced to V_n; it remains the continuous maximization (5). These are two separate gaps: (14) is enough for the candidate comparator without exact full support, while exact canonical-EB support would additionally require classifying the support function (5).

The finite evidence inherited from cycle 9 is the exact n=4 all-mixed full-star check on every support cone, all nine isotypic/swap blocks and all ten rays, together with the separately derived exact Spin(9) pure-moment triangle. Cycle 10's exact n=5 check covers both output-swap signs, 11 blocks, 17 rays and 629 principal minors for its four attained seeds. Those checks are finite-dimensional exact arithmetic, not a proof of (14) for general n, not proof-assistant verification, and not external proof review. This cycle created no finite compiler or new exact numerical star certificate.

The checked prior artifacts are:

- Cycle 9 representation/star and support reports: `work/agents/c5_quantum_dimension_obstruction/cycle9_spin9_mixed/FINAL_REPORT.md`, `star_blocks.md`, `SPIN9_SUPPORT_POLYTOPE.md`, and `spin9_fullstar_certificate.json`.
- Cycle 10 representation/star and support reports: `work/agents/c5_quantum_dimension_obstruction/cycle10_spin11_probe/FINAL_REPORT.md`, `spin11_fullstar_blocks.json`, and `spin11_seed_support_certificate.json`.

The all-n derivations here use closed Clifford, gamma-trace, and convex-separation arguments. No external theorem review, formal proof-assistant check, novelty search, finite-outcome orbit implementation, or operational cost model was performed. The Haar orbit maps are existence constructions; discretization and implementation costs are uncharged.
