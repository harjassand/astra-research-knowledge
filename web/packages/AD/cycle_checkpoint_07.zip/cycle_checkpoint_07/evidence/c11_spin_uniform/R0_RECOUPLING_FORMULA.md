# Exact all-n recoupling matrix on the spinor isotypic block

## Result and status

For the \(r=0\) (spinor) isotypic component of

\[
S^*\otimes S\otimes S=\bigoplus_{r=0}^n T_r\otimes M_r,
\]
the output-swap recoupling involution has an explicit binomial formula. This converts the unresolved spinor block to compression of a diagonal matrix onto the two output-swap sectors. The identity is dimension-uniform and retains every Clifford grade, including the signed pair spectrum. It is a representation reduction only: it does **not** prove the desired factor-two support bound, and does not address the \(r\ge1\) blocks.

## Formula

Set \(N=2n+1\), \(d=2^n\), and \(d_j=\binom Nj\). In the pair-coupling basis \(j=0,\ldots,n\), define

\[
F^{(0)}_{jk}=
\frac{\binom Nj}{2^n\sqrt{\binom Nj\binom Nk}}
\sum_{\ell=0}^{\min(j,k)}(-1)^{jk-\ell}
\binom j\ell\binom{N-j}{k-\ell}.
\tag{1}
\]

Then \(F^{(0)}\) is a real symmetric orthogonal involution. Its \(+1/-1\) multiplicities are the dimensions of the corresponding output-symmetric/antisymmetric copies of \(T_0=S\), equivalently the counts of

\[
\epsilon_j=(-1)^{(n-j)(n-j+1)/2},\qquad 0\le j\le n,
\]
with signs \(+1/-1\).

For a real mixed-grade weight vector \(\alpha=(\alpha_1,\ldots,\alpha_n)\), put

\[
D_{\alpha,0}=\operatorname{diag}(c_0,\ldots,c_n),\qquad
c_j=\sum_{k=1}^n\alpha_k\mu^{(n)}_{k,j},
\]
where

\[
\mu^{(n)}_{k,j}=\sum_{\ell=0}^{\min(k,j)}(-1)^{kj-\ell}
\binom j\ell\binom{N-j}{k-\ell}.
\]
The full \(r=0\) star block is

\[
H_{\alpha,0}=D_{\alpha,0}+F^{(0)}D_{\alpha,0}F^{(0)}.
\tag{2}
\]
It commutes with \(F^{(0)}\). If \(P_\sigma=(I+\sigma F^{(0)})/2\), then on its \(\sigma\)-swap sector,

\[
H_{\alpha,0}\big|_{\operatorname{ran}P_\sigma}
=2\,P_\sigma D_{\alpha,0}P_\sigma\big|_{\operatorname{ran}P_\sigma},
\qquad \sigma\in\{+1,-1\}.
\tag{3}
\]

Thus the \(r=0\) mixed-grade question is an explicit compression problem for a diagonal sequence of Krawtchouk-type eigenvalues. Equation (3) is the full two-sign statement; no Bose-only restriction is made.

## Derivation of (1)

Let \(T_A=i^{|A|(|A|-1)/2}\Gamma_A\) be the Hermitian Clifford basis, so \(T_A^2=I\) and \(\operatorname{Tr}(T_AT_B)=d\,\delta_{AB}\). For each grade \(j\), define an intertwiner \(V_j:S\to S^*\otimes S\otimes S\) by

\[
V_jx=\frac1{\sqrt{d d_j}}\sum_{|A|=j}
\operatorname{vec}(T_A^T)\otimes T_Ax.
\tag{4}
\]

The normalized vectorization has squared norm \(d\); orthogonality of the Clifford basis and \(\sum_{|A|=j}T_A^2=d_jI\) show that \(V_j^*V_k=\delta_{jk}I\). These \(n+1\) isometries are the \(n+1\) spinor copies in \(S^*\otimes S\otimes S\), hence form the coupling basis of \(M_0\).

Let \(P_{23}\) swap the two output spinors. Its recoupling coefficient is

\[
F^{(0)}_{jk}=\frac1d\operatorname{Tr}_S(V_j^*P_{23}V_k).
\]

Expanding (4), the index contraction for fixed \(A,B\) is

\[
\sum_{r,a,b,s}
\overline{(T_A^T)_{ra}}\,\overline{(T_A)_{bs}}
(T_B^T)_{rb}(T_B)_{as}
=\operatorname{Tr}(T_AT_BT_AT_B).
\]

For \(|A|=j, |B|=k\) and \(|A\cap B|=\ell\), Clifford anticommutation gives

\[
T_AT_BT_AT_B=(-1)^{jk-\ell}I.
\]

There are \(\binom Nj\binom j\ell\binom{N-j}{k-\ell}\) such ordered pairs. Substitution yields (1). The symmetry and involution identities also follow from \(P_{23}=P_{23}^*=P_{23}^{-1}\) and the isometry basis. The stated parity multiplicities follow by restricting the standard output-swap action on \(S\otimes S\cong\bigoplus_{j=0}^n\Lambda^jV\).

## Exact checks and boundary

The companion checker verifies (1), \(F^T=F\), \(F^2=I\), and the swap-sign multiplicities by exact SymPy arithmetic for \(1\le n\le8\). These checks are reproducibility aids; the proof of (1) above is all-n and direct.

This formula offers the analytic branch a compact target for a uniform PSD argument. In particular, a proof of

\[
\lambda_{\max}(H_{\alpha,0})\le \sum_{k=1}^n\binom{2n+1}{k}\alpha_k+
\max_{0\le h\le n}\sum_{k=1}^n\alpha_k s_k(\psi_h),\qquad \alpha\ge0,
\]
would settle the spinor isotypic block using the explicit seed family, but (1)--(3) do not establish that inequality. The full canonical pure-state support may exceed this finite seed-family support, so a violation against the seeds alone is not a channel counterexample.

No all-n star inequality, Spin(13) counterexample, generic noncovariant result, novelty/priority claim, or efficient channel construction follows here. The universal theorem remains **UNKNOWN**.
