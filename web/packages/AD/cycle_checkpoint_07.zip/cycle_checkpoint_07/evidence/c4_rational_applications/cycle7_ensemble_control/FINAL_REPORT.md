# Cycle 7: shared-feed feasibility for a glycolysis genotype mixture

## Result

The application gate is now quantified for the two model genotypes that Janulevicius and van Doorn selected from their balanced-cell (BC) and imbalanced-cell (IC) subpopulations. Their paper reports these as a no-mutation coexistence pair in a chemostat, where glucose is a shared environmental variable. I recomputed the CellML's fourth-power expression cost separately for each genotype rather than using its rounded Table 2 values. This changes the ATP-profit thresholds to 0.364578 mM for BC and 0.546640 mM for IC.

For an admissible pair in the viable tube

\[
K=\{1.8\le F\le2.2,\quad 0.585\le A\le1.5,\quad P\ge2,\quad A+P\le14\},
\]

take a BC cell at \((F,A,P,H)=(1.8,0.585,7,1)\) and an IC cell at \((2.2,0.6,2,1)\), all concentrations in mM. Both cells have positive source ATP profit: 1.353624 and 0.184897 mM/min respectively. At \(H=H_{max}\), the source health law gives \(\dot H=0\) at both points; neither witness relies on accepting a cell already losing health.

Write the shared glucose input as \(z=G/(0.1+G)\). The source uptake is \(v_{up}=V_{max,up}\,q(A)z\), with \(q(A)=A/[0.1+A(1+A/3)]\). On the BC lower-F face, inwardness requires at least \(z\ge L/(V_{max,up}q(A))=0.469997\), or \(G\ge0.088678\) mM. This lower bound deliberately drops the positive growth-dilution term, so it is weaker than the true requirement. On the IC upper-F face, inwardness permits at most \(z\le[L+2.2g_{max}]/[V_{max,up}q(A)]=0.237754\), or \(G\le0.031191\) mM; here \(g_{max}\) includes the full source growth law and uses \(\ln2<0.7\). The allowable intervals are disjoint by 0.232243 in \(z\). Therefore no common glucose value can point both cells inward at that instant; changing the common feed over time cannot remove an instantaneous tangent-cone conflict.

Two independently controlled feed channels resolve these two active F-face constraints locally. At the same witness points, \(G_{BC}=0.1\) mM gives conservative \(\dot F\ge0.21521\) and \(\dot A\ge2.79077\) mM/min, while \(G_{IC}=0.03\) mM gives \(\dot F\le-0.05525\) and \(\dot P\ge15.66039\) mM/min. Those are local face-direction checks for this pair, not a recovery or basin theorem. The exact values and fractions are in [collective_feed_certificate.json](collective_feed_certificate.json).

## Individual-feed certificate and its limit

The same arithmetic gives an individually addressable actual-flux controller for each Table 2 genotype. Under

\[
v_{up}=v_{lo}-(F-2)+e,\qquad |e|\le0.15\;\text{mM/min},
\]

the set \(K\) above is forward invariant for the full CellML growth/dilution model, separately for BC and IC. The bound uses the source's genotype-dependent expression cost in ATP profit, the source growth gate, and every metabolite dilution term. Since the ATP floor 0.585 mM is above both genotype thresholds, \(\dot H\ge0\) throughout the tube whenever \(H>0\). The least inward face margins are 0.017232 mM/min at the IC ATP upper face and 0.032769 mM/min at the IC ATP lower face; all six faces pass for both genotypes.

The glucose inverse is finite throughout each tube under the stated error budget. Conservative upper glucose commands are 0.233754 mM for BC and 0.110291 mM for IC. If F is the only stale measurement, ATP and Pi are current, and every other kinetic and actuation error is zero, the sufficient F-channel delay limits are 14.02 s (BC) and 15.49 s (IC). Any other error consumes the same 0.15 mM/min budget. These numbers do not establish a physical sensor or glucose actuator meeting the bound.

The external command comes from the uptake law, not from directly actuating an intracellular flux: with \(c_i=V_{max,up,i}q(A)\), set \(G=0.1U/(c_i-U)\) whenever \(0<U<c_i\). Thus the interface needs per-cell or per-state-class estimates of F, ATP, Pi and genotype-specific kinetic parameters, plus calibrated extracellular glucose response. The exact source tube only certifies this ideal inverse subject to the total-error bound.

The CellML's documented metabolite start \((F,A,P,H)=(2,1,10.4,1)\) lies inside \(K\). With a genotype substitution, the tube theorem therefore applies if its feedback/feed command is already active at glucose onset. It does not cover a delay while cells first experience an unregulated high-glucose pulse, nor a later state outside \(K\).

This proves an individually addressable controller for a single model cell of either genotype. It does **not** show that one inlet per genotype controls a heterogeneous genotype subpopulation: cells with the same genotype can occupy different F/A/P states, and then their allowed glucose intervals may themselves fail to overlap. Nor does it prove recovery from outside \(K\), convergence to an attractor, or growth advantage. The number of feed channels required for a real ensemble must be computed from the measured state-and-parameter support, not inferred from genotype labels alone.

## General collective-feed test

For a fixed measured state and genotype, glucose enters the three concentration equations only through the scalar \(z\), because \(v_{up}=c_i z\) with \(c_i=V_{max,up,i}q(A_i)\). Consequently each active face inequality is one lower or upper bound on \(z\). For example, with actual flux error bounded by \(\delta\):

| Active face | Robust condition on \(z\) |
|---|---|
| \(F=F_{min}\) | \(z\ge(L+Fg+\delta)/c_i\) |
| \(F=F_{max}\) | \(z\le(L+Fg-\delta)/c_i\) |
| \(A=A_{min}\) | \(z\le(4L-k_{ATP}A-gA-2\delta)/(2c_i)\) |
| \(A=A_{max}\) | \(z\ge(4L-k_{ATP}A-gA+2\delta)/(2c_i)\) |
| \(A+P=S_{max}\) | \(z\ge(2L+k_{ATP}A+v_p-gS_{max}+2\delta)/(2c_i)\) |

The Pi-face and health inequalities are independent of the instantaneous glucose command and must pass separately. Intersecting these scalar constraints over every active cell/facet and over the declared state and kinetic uncertainty set gives the exact robust collective-feed interval. An empty intersection certifies infeasibility for every common glucose command at that instant. For known interval-valued state groups, the instantaneous minimum number of feed channels is the interval-stabbing number of the allowed-z intervals; the witness above has two disjoint intervals, so two channels are necessary and the exhibited two commands suffice for the active face directions. Extending this snapshot rule to finite sampling intervals requires reachable-set or derivative bounds for the unsampled period; that part remains open here.

This reduction is the actionable ensemble output: acquire each cell's joint state/kinetic uncertainty, compute its allowed-z interval, and either issue a common value from their intersection or flag the need to partition the culture. A bulk mean of ATP or FBP is insufficient to detect the two-cell conflict. No acquired single-cell F/A/P distribution or empirical confidence set for \(V_{max,up},V_{max,lo},k_{ATP},k_p,K_{vac}\) was available, so the witness is conditional on those states being jointly present.

## Primary prior and interface gate

The genotype pair is from the 2021 PLOS Computational Biology model, not from a measured isogenic strain panel. That paper's model explicitly includes shared chemostat glucose, distinct BC/IC genotypes, and coexistence under glucose cycling ([article and Table 2](https://doi.org/10.1371/journal.pcbi.1008547); [CellML supplement](https://doi.org/10.1371/journal.pcbi.1008547.s001)). Its existence does not establish that my two witness state vectors co-occurred in their simulations or in a living culture.

The strongest startup comparator remains known trehalose/T6P control: van Heerden et al. experimentally reported nongenetic metabolic heterogeneity during glucose startup and found transient ATP hydrolysis through futile cycling reduced entry into the imbalanced state ([Science 2014](https://doi.org/10.1126/science.1245114)). A separate primary study reports suppression of sugar-induced cell death after perturbing glycolysis ([FEMS Microbiology Letters 2025](https://doi.org/10.1093/femsle/fnaf026)). Thus feed partitioning is an actuator-feasibility result, not a new biological mechanism or a demonstrated advantage over known regulators.

Dynamic microfluidic glucose exposure and single-cell readouts are experimentally plausible. A 2024 dMSCC study used independent feast/starvation inlets and an ATP reporter across 1.5–48 minute cycles ([Blöbaum et al.](https://doi.org/10.1186/s12934-024-02318-z)). A 2026 primary report used microfluidic 30-second glucose dynamics, shifted by two seconds, and reported single-cell ATP plus an FBP-proxy reporter ([Blöbaum et al.](https://doi.org/10.1186/s12934-026-03029-3)). These studies establish dynamic exposure/readout tools, not a closed-loop per-cell controller with the composite error and latency bounds above. The cited setup does not supply an online single-cell Pi channel; a live feed controller would still need Pi acquisition or a separately validated robust bound.

## Discriminating experiment and costs

First identify two real yeast subpopulations or engineered clones whose measured parameter/state uncertainty sets reproduce a BC-like low-F/high-P state and an IC-like high-F/low-P state. Measure the joint FBP/ATP/Pi distribution after a preregistered startup pulse, fit the four genotype parameters plus the vacuolar-Pi law, and compute the robust z-intervals before optimizing glucose. FBP/ATP reporters and fast glucose switching can be implemented in separate perfused microfluidic chambers; Pi needs a rapid-quench or other destructive biochemical assay unless a validated live-cell channel is added. State sorting or separate preconditioning is necessary if the two groups share the same genotype.

The decisive comparison is (i) one shared best-fixed glucose concentration, (ii) one shared constrained-MPC policy with the same state information, (iii) a published Tps1/T6P or glucose-withdrawal control, and (iv) two separately perfused inputs using the precomputed interval/controller rule. Score single-cell survival, ATP recovery, FBP excursions, Pi, growth and glucose use on held-out startup pulses. Falsifiers are that the acquired joint support has a nonempty common-feed interval, the two states never co-occur, the fitted parameters put the ATP-profit threshold above the proposed ATP floor, or the two-lane rule fails the held-out health/survival endpoint.

The minimum actuator cost for the exact pair is one added independent glucose channel: two feed concentrations in total rather than one. Physically separate perfusion chambers can test this pair, but separating BC-like and IC-like cohorts removes their shared-resource competition; it tests the cell-control mechanism rather than the paper's mixed-chemostat ecology. A mixed culture needs a nonempty measured common interval or a validated cell-autonomous actuator. Guaranteeing an entire heterogeneous culture can require more channels, determined by its interval partition, and in the worst case one channel per independently varying cell. Additional costs are reporter burden and calibration, glucose-response and enzyme-parameter identification, per-channel flow calibration, Pi assays, and enough throughput to characterize tails rather than just population means. The cited sources do not price these items, so dollar and throughput costs remain unquantified. No nature-level robustness, natural co-occurrence, novelty or priority claim is made.

## Reproduction and status

Run:

```sh
python3 work/agents/c4_rational_applications/cycle7_ensemble_control/collective_feed_certificate.py
python3 -m py_compile work/agents/c4_rational_applications/cycle7_ensemble_control/collective_feed_certificate.py
```

The script uses exact `Fraction` arithmetic on the printed Table 2 decimals, checks all face signs for both individual full-growth tubes, asserts both health-positive witnesses, and asserts the strict common-feed gap. Its sole transcendental bound is \(\ln2<0.7\). The files [collective_feed_certificate.py](collective_feed_certificate.py) and [collective_feed_certificate.json](collective_feed_certificate.json) are source-model evidence only. The individual tube is a conditional theorem; the collective conflict is an exact two-state source-model obstruction; natural state support, online observability, finite-horizon channel allocation, and comparative benefit remain **unknown**.
