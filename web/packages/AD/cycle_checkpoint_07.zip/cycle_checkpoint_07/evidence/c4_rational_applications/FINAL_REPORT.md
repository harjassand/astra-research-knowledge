# Glycolysis startup control: viability tube and shared-input obstruction

## Finding

The PLOS CellML source equations support a full-growth, health-preserving invariant tube at the source-reference phosphate exchange value kp=0.3 per minute, provided the total actual upper-flux tracking error is at most 0.17 mM/min. The key correction is to set the ATP floor at 0.5 mM: this is exactly the source model's ATP expression-cost threshold, so health cannot decrease anywhere in the tube. Raising the Pi floor to 2 mM also leaves positive exact margin. No extra Pi-import intervention is required at the exact nominal source point.

The application-level obstruction is exact. One shared extracellular glucose signal cannot keep the whole tube invariant for a population whose cells simultaneously occupy its low- and high-FBP faces, even after including source growth dilution. Thus the certificate requires an individually addressable actuator or a separately proved population-state region. This is not a proof of recovery from outside the tube, a maximal basin, or a biological advantage over known glycolytic regulators. The defensible result is a model-control boundary with a concrete implementation obstruction, not a claimed biology breakthrough or novelty.

## Exact source model and certificate

The source is Janulevicius and van Doorn, “Selection for rapid uptake of scarce or fluctuating resource explains vulnerability of glycolysis to imbalance,” PLOS Computational Biology 17 (2021), e1008547, [DOI 10.1371/journal.pcbi.1008547](https://doi.org/10.1371/journal.pcbi.1008547). Its CellML model is retained in this directory under sources/.

Use F=FBP, A=ATP, P=Pi, D=5-A, and T=P+2F+A. The source rates are

    U = 10 A/[0.1 + A(1 + A/3)] * G/(0.1+G)
    L = 10 F/(1+F) * (5-A)/(0.1+5-A) * P/(2+P)
    Pv = 10/[1 + (T/250)^4]
    vp = kp(Pv-P)
    vATP = 10 A

The full source metabolite balances are

    Fdot = U-L-gF
    Adot = -2U+4L-10A-gA
    Pdot = -2L+10A+vp-gP
    Vdot = gV

CellML defines the expression cost as vATP,e = 5 times the ratio of the fourth-power genotype-capacity sum to the reference-capacity sum: Vmaxup^4+Vmaxlo^4+(1 mM katp)^4+(1 mM kp)^4, divided by the corresponding reference sum. At the source-reference genotype, the two sums coincide, so vATP,e=5 exactly. The source growth law has g=0 unless H>=1 and 10A-5>0; when active, g=(ln 2/693)(10A-5). Its health constants are ug=ln(2)/693 and ud=1/[420(0.46-5)]<0. The health law is Hdot=-ud(10A-5) when 10A-5<=0, Hdot=ug(10A-5) when 10A-5>0 and H<1, and zero when 10A-5>0 and H>=1. The proposed ATP floor A=0.5 therefore gives Hdot=0 at equality and Hdot>=0 above it. Every trajectory beginning with H0>0 keeps H>0 while it stays in the tube.

Define

    S+ = {1.8 <= F <= 2.2, 0.5 <= A <= 1.5, P >= 2, A+P <= 14}.

Apply the actual-flux law U=L-(F-2)+e, where |e|<=0.17 mM/min. In S+, T<=18.4, hence Pv>=9.9997065. On A<=1.5, g<=10 ln(2)/693 < 7/693 per minute. Exact rational face bounds for the full source equations are:

| Boundary | Inward normal bound (mM/min) |
|---|---:|
| F=1.8 | Fdot > 13/1100 = 0.011818 |
| F=2.2 | Fdot <= -0.03 |
| A=0.5 | Adot >= 2209/4025 = 0.548820 |
| A=1.5 | Adot <= -2.735814, even before helpful dilution |
| P=2 | Pdot >= 0.654166, using a conservative whole-tube Pv bound |
| A+P=14 | d(A+P)/dt <= -0.01, even before helpful dilution |

At A=0.5 the source growth flux is exactly zero. For A>0.5 the health law does not consume the reserve. The upper sum-face condition is the narrow parameter condition:

    d(A+P)/dt <= 0.4 + 2 delta - 2.5 kp - 14g.

With delta=0.17, kp>=0.296 is sufficient. The source kp=0.3 leaves 0.01 mM/min inward margin before growth dilution. At delta=0.18, that same face points outward by 0.01 mM/min. The source-point certificate has only 1.33% downward kp tolerance; no measured confidence interval for kp is available.

The external-glucose inverse is finite throughout S+. Conservative exact independent-extrema bounds give 2.755 <= U <= 6.227732 mM/min, while minimum glucose-saturated uptake is 300/47 = 6.382979 mM/min. The saturation gap is 0.155247 mM/min, so the ideal static inverse has the conservative bound G<=4.011491 mM. For the reconstructed earlier failure tuple (F,A,P)=(2,1,9.4), the zero-error command is G=0.332333 mM.

The source's 2021 CellML default starts at Pi=10.4 mM. The 2014 Science Figure 4 comparison changes initial Pi from 10.4 to 9.4 mM; carrying over the later model's F=2 and A=1 defaults gives the reconstructed tuple above. It is not the PLOS 2021 default and is not an experimentally measured intracellular state. Both tuples lie inside S+.

The exact face calculations, inverse feasibility, shared-input witness, delay bound, and parameter threshold are reproducible with:

    python3 work/agents/c4_rational_applications/full_growth_control_audit.py

The output is full_growth_control_certificate.json. The theorem assumes the source algebraic vacuolar-Pi law, source-reference kinetics, full health-gated growth law, and total actual-flux error bound.

## Shared-glucose obstruction

Take two otherwise identical cells on opposing FBP faces of S+:

    x_low  = (F,A,P) = (1.8, 0.5, 13.5)
    x_high = (F,A,P) = (2.2, 1.5, 2)

At x_low, source growth is off and lower-face inwardness requires U_low>=L(x_low)=5.47736. At x_high, even the maximum source growth allowance only permits U_high<=L(x_high)+2.2(7/693)<3.36424. For a common glucose command, both uptake rates contain G/(0.1+G), so their ratio is fixed by ATP-dependent saturation:

    U_high/U_low = C(1.5)/C(0.5) = 41/47.

Thus U_high>=4.77812, which contradicts the upper-face bound. This is an exact two-state obstruction for every time-varying shared glucose input. It does not imply that all mixed cultures fail to recover. It says the stated uniform tube guarantee cannot be implemented by one common culture input over the full state set. A bulk-average controller also cannot distinguish this pair.

The inverse command G(F,A,P) is a per-cell value, while extracellular glucose is ordinarily shared. A plausible experimental interface would need one independently addressable perfusion lane or droplet per cell/lineage, or a different common-input invariant set proved for the measured population distribution. Single-cell imaging in a common-flow chamber does not give per-cell actuation.

There is a separate glucose-independent Pi obstruction outside S+. At the source state (F,A,P)=(200,0,0.05), exact source equations give Pdot=-0.0938714 mM/min for every glucose command. At A=0 the uptake law has U=0 and growth is off, so Pdot=-2L+kp(Pv-P). For fixed A=0 and P=0.05 this margin decreases with F; therefore this Pi face points outward for all F>=200 mM. ATP starts increasing at the displayed point, so this local boundary test does not prove death or non-recovery. It does rule out extending the same Pi safety face to 0.05 mM at high FBP without a staged recovery proof or a different phosphate mechanism.

## Bandwidth and parameter boundaries

If only FBP sensing is delayed, ATP and Pi are current, and all other kinetics and actuation are exact, then on S+

    |e_delay| <= (1 + sup_S+ |dL/dF|) sup_S+ |Fdot| tau
              <= 0.818481 tau,

where tau is in minutes and flux error is in mM/min. The sufficient total-error budget is 0.818481 tau + e_other <= 0.17. With zero other error, tau<=12.46 seconds suffices. This is a mathematical upper bound for one delayed channel. Feed lag, ATP/Pi sensing, parameter fitting, genotype variation, and sensor noise all consume the same budget and are not certified.

At the sum face, effective kp below 0.296 per minute invalidates the certificate even with exact glucose tracking. The source Kvac=250 mM gives substantial model margin, but the PLOS authors say Kvac is poorly known and selected to limit FBP. No empirical parameter uncertainty set has been supplied. The result is nominal-source conditional rather than biologically robust.

## Recovery, comparators, and prior art

The reconstructed 2014 failure tuple lies inside S+, so a single isolated ideal cell starting at that state cannot leave S+ while the stated conditions hold; its health reserve also cannot decline. The theorem does not establish convergence to a healthy attractor, recovery from states outside S+, a maximal basin, or a finite-time recovery guarantee. The phosphate-equivalent balance is

    Tdot = vp - gT.

Glycolysis and ATPase redistribute phosphate among Pi, FBP and ATP, while vacuolar exchange and growth dilution govern total T. The sum-face and low-ATP Pi boundaries are necessary feasibility conditions, not a basin proof.

No fixed G makes all of S+ invariant: the low-FBP face above requires U>=5.47736, whereas the high-FBP state permits U<3.36424 with full-growth allowance. This is a rigorous equal-tube baseline result. It does not identify the best fixed G for recovery from one initial state; continuous fixed-G optimization and a same-information robust-MPC comparison remain undone.

The biological mechanism is already occupied by prior regulation. Van Heerden et al. discuss trehalose cycling, T6P inhibition of hexokinase, glucose removal, ATP feedback and phosphate mobilization as controls on startup ([Science 343 (2014), DOI 10.1126/science.1245114](https://doi.org/10.1126/science.1245114)). Overal et al. derive startup thresholds in yeast glycolysis ([Mathematical Biosciences 289 (2018), DOI 10.1016/j.mbs.2018.03.007](https://doi.org/10.1016/j.mbs.2018.03.007)). Knibbe et al. report synergy among allosteric regulation of glucokinase, phosphofructokinase and pyruvate kinase in a pathway transplant ([mBio (2025), DOI 10.1128/mbio.00219-25](https://journals.asm.org/doi/10.1128/mbio.00219-25)). Direct flux cancellation plus an FBP term is recognizable feedback design, not a new biological mechanism.

Available sensors cover parts of the interface. A yeast CggR reporter reads FBP/glycolytic flux through fluorescent-protein production rates rather than a validated fast FBP concentration signal ([Monteiro et al., Molecular Systems Biology (2019), DOI 10.15252/msb.20199071](https://doi.org/10.15252/msb.20199071)). The pH-robust yAT1.03 reporter provides single-cell ATP traces during yeast startup ([van Heerden et al., ACS Sensors (2020), DOI 10.1021/acssensors.9b02475](https://doi.org/10.1021/acssensors.9b02475)); a later yeast application sampled at 20-second intervals and showed ATP perturbation responses over several minutes ([primary report](https://pmc.ncbi.nlm.nih.gov/articles/PMC10793178/)). That is not a demonstrated closed-loop latency bound. The cited yeast Pi work uses population-level 31P-NMR ([yeast phosphate-starvation study, PMID 9032964](https://pubmed.ncbi.nlm.nih.gov/9032964/)) and does not provide the required fast per-cell feedback channel. These sources do not establish the joint FBP/ATP/Pi/flux error or latency bounds in the theorem.

A wet-lab gate would first identify Vmaxup, Vmaxlo, the ATP uptake curve, effective kp, Kvac and glucose-to-uptake response in a named strain; calibrate ATP and FBP reporters against biochemical assays; quantify Pi by rapid-quench metabolomics or 31P-NMR; and measure total flux-tracking error on held-out glucose steps. Then use independently perfused microfluidic compartments and compare with same-information constrained MPC, a prespecified best fixed-glucose setting, and a trehalose/T6P or glucose-withdrawal control. Score survival, ATP recovery time, maximum FBP, growth and glucose use. Costs include reporter burden, calibration runs, per-lane valves and flow calibration, metabolite assays, parameter estimation and glucose-withdrawal opportunity cost. Dollar and throughput costs remain unmeasured and must be priced by the lab before claiming practical feasibility.

## Evidence scope

full_growth_control_audit.py and full_growth_control_certificate.json hold the exact-rational certificate. full_growth_diagnostics.py now implements the CellML fourth-power expression-cost formula instead of fixing the rounded 2.63 value. At the imbalanced-cell genotype it computes 2.6348207642; across the declared +/-10% corners this cost varies from 1.7287059 to 3.8576411. Its RK4 output and population_schedule_sweep.json remain finite diagnostics only. The source-reference tube certificate and IC-genotype schedule sweep are distinct parameter cases.

After correcting the expression cost, common open-loop schedules with G=0 for 30, 35 or 40 minutes followed by G=0.1 mM failed some cases in a declared 128-run IC-genotype stress grid, respectively producing 14/13/12 deaths and 108/112/120 balanced endpoints. An ideal F-triggered controller with independent per-cell glucose was balanced in all 128 cases in cell_trigger_corner_sweep.json; that is an RK4 stress result, not validated numerics or a realizable shared-culture policy. The F=300 mM state is a source-model stress point, not an observed yeast state.

simulate_recovery.py is an earlier no-growth-only exploration. shared_actuator_audit.py uses the imbalanced-cell Table 2 genotype. Neither is evidence for the source-reference full-growth theorem. No stochastic permanence, natural-distribution, novelty, or priority claim is made.
