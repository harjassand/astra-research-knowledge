# Source audit

## Core pathway source

Miller ML et al. (2026), “Fungal-derived cellobiose metabolic pathway fuels T cells to bypass intratumoral glucose competition,” *Cell* 189(6):1717–1730.e16. [DOI 10.1016/j.cell.2026.01.015](https://doi.org/10.1016/j.cell.2026.01.015) · [ScienceDirect indexed full-text record](https://www.sciencedirect.com/science/article/pii/S0092867426001029) · [PubMed](https://pubmed.ncbi.nlm.nih.gov/41742411/).

The source reports mouse T cells and human CAR-T cells transduced with fungal CDT-1 and GH1-1; cellobiose restores glycolysis/metabolite pools under glucose withdrawal and restores several T-cell functional outputs. The article's data-availability statement says its non-sequencing data are in the main text or STAR Methods; the linked Figshare record is sequencing data only ([DOI 10.6084/m9.figshare.28185641](https://doi.org/10.6084/m9.figshare.28185641)). I did not identify a separate extracellular isotope-flux dataset.

## Publicly inspectable predecessor with assay detail

Matthew L. Miller, *Enhancing Tumor-Infiltrating T cells with an Exclusive Fuel Source*, UCLA PhD dissertation (2024). [Public dissertation PDF](https://escholarship.org/content/qt0p1615jf/qt0p1615jf.pdf?t=s7pnsn).

This is a pre-publication version and is cited for methods/measurement boundaries, not treated as a second independent replication of the 2026 paper. Its figure legend states that T cells received 5 mM U-\(^{13}\)C\(_{12}\)-cellobiose plus 200 µM unlabeled glucose (or labeled glucose) for 16 h, after which intracellular metabolites were extracted. The methods describe harvesting and extracting cell pellets; they do not describe measuring isotope in extracellular metabolites. Its discussion identifies CDT-1 as a proton symporter, says proton import offsets metabolism-driven extracellular acidification in ECAR, and its future-directions section reports only about a twofold control-relative intracellular cellobiose difference at 125 min plus a modest transporter effect. It also notes a 5–10 mM in-vitro cellobiose supply and rapid return of blood cellobiose toward baseline by 8 h after i.p. injection. These statements are all source-reported in the thesis; no new quantitative T-cell uptake or leak rate is inferred here.

The accessible thesis lines used during this audit:

- pathway, uptake, isotope and intracellular pools: pages 44–46;
- proton transport and ECAR interpretation: page 46;
- tumor-only cellobiose test and in-vivo dosing: pages 49–51;
- figure legends and isotope protocol: pages 53–64;
- pellet extraction and metabolomics workflow: pages 62–63;
- transporter/uptake caveat and 5–10 mM supply: pages 77–80.

## Primary precedent for lactate uptake by tumors

Sonveaux P et al. (2008), “Targeting lactate-fueled respiration selectively kills hypoxic tumor cells in mice,” *J Clin Invest* 118:3930–3942. [Primary article](https://www.jci.org/articles/view/36843) · [DOI 10.1172/JCI36843](https://doi.org/10.1172/JCI36843). The study reports hypoxic tumor cells exporting glycolytic lactate and oxygenated tumor cells taking it up through MCT1 for oxidative metabolism; MCT1 inhibition changed tumor metabolism in mouse and xenograft systems. This demonstrates a recipient mechanism in some tumors, not a claim that EL4-OVA or every CAR-T target has it.

Kennedy KM et al. (2013), “Catabolism of Exogenous Lactate Reveals It as a Legitimate Metabolic Substrate in Breast Cancer,” *PLoS ONE* 8:e75154. [Primary article](https://pmc.ncbi.nlm.nih.gov/articles/PMC3771963/) · [DOI 10.1371/journal.pone.0075154](https://doi.org/10.1371/journal.pone.0075154). The authors used labeled lactate and report uptake in well-perfused tumor regions, supporting direct isotope readout of recipient-cell carbon.

## Precedent that cellobiose-derived carbon can be exported in a different chassis

Lee J et al. (2016), “Adaptive evolution and metabolic engineering of a cellobiose- and xylose-negative *Corynebacterium glutamicum* that co-utilizes cellobiose and xylose,” *Microbial Cell Factories* 15:20. [Primary open article](https://link.springer.com/article/10.1186/s12934-016-0420-z) · [DOI 10.1186/s12934-016-0420-z](https://doi.org/10.1186/s12934-016-0420-z). The study measures extracellular glucose and reports cellobiose-derived glucose in culture medium during adaptation, including up to 12 g/L during evolution and 5 g/L in one later transfer series; another evolved strain did not secrete glucose. It also reports little or no extracellular beta-glucosidase activity. This establishes host- and state-dependent possible glucose release despite an intracellular enzyme design; it cannot be transferred quantitatively to mammalian T cells.

## Evidence boundaries

- Source-reported: T-cell uptake/catabolism, intracellular isotope labeling, net ECAR response, functional rescue, and tumor-only inability to benefit from cellobiose in selected tested lines.
- Independently verified within this task: chemical carbon accounting (12 C atoms per cellobiose; at most four C3 lactates) and the observation-interface calculation in `stoichiometric_gate.py`.
- Not measured in the source package reviewed here: T-cell U-\(^{13}\)C-cellobiose-derived efflux of glucose/lactate/other carbon, transfer into target cells, target lactate uptake in the selected coculture line, or incremental glutamine/O\(_2\)/amino-acid draw caused by cellobiose-supported effector expansion.
- The separate Figshare entry is sequencing-only; it does not supply the missing non-sequencing extracellular flux data.
- No public data were downloaded and reanalyzed. The Cell article's full-text endpoint returned 403; source-specific methods were checked against the open dissertation precursor and the article's indexed record.

## Acquisition-cost basis (checked 2026-10-08)

The proposed 240 media samples use two substrate states (200 µM unlabeled glucose alone, or the same medium plus 5 mM U-13C12-cellobiose); 120 are tracer-fed. For tracer molar mass 354.21 g/mol, the feed uses 1.77105 mg/mL. At 200 µL per tracer-fed sample, the nominal tracer requirement is 42.5052 mg; at 1 mL, it is 212.526 mg. This excludes isotope standards, dead volume, pilot optimization, and repeat samples. MedChemExpress lists a 100 mg U-13C12-cellobiose size but requires a quote and notes regional availability restrictions: https://www.medchemexpress.com/d-cellobiose-13c12.html. A second model doubles sample and tracer requirements.

The UCLA BSCRC FACS core publicly lists internal sorting at $71.48/h unassisted and $99.27/h assisted; sorting time is not fixed before cell yield and gating are known: https://stemcell.ucla.edu/shared-resources/flow-cytometry-core. The UCLA Metabolomics Center accepts culture-medium specimens, but I found no public fee schedule: https://ctsi.ucla.edu/ucla-metabolomics-center-ucla. Thus these are auditable reagent quantities and service-rate inputs, not an all-in budget. Obtain a core quote for the specified extracellular and sorted-cell isotope panel before claiming a dollar total.
