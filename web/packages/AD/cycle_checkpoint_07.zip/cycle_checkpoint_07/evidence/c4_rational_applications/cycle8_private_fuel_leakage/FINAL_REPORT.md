# Cycle 8: private-fuel leakage and the limits of cellobiose orthogonality

## Result

The available evidence supports **orthogonal uptake of cellobiose in tested cell lines**, but does not identify whether cellobiose-derived carbon remains private after CDT-1/GH1-1 T cells metabolize it. The publicly accessible methods-level tracer protocol is in the same research program's 2024 UCLA dissertation precursor: 5 mM U-\(^{13}\)C\(_{12}\)-cellobiose plus 200 µM unlabeled glucose for 16 hours, followed by intracellular-metabolite extraction. The 2026 article's data statement places non-sequencing results in the paper/STAR Methods and links a sequencing-only deposit; I found no species-resolved extracellular isotope balance or target-cell product uptake in the accessible source materials. The source's ECAR signal cannot fill that gap because CDT-1 imports a proton together with cellobiose, offsetting metabolism-associated extracellular acidification.

I derive a measurement-interface no-go: those readouts and a target-only cellobiose response do not establish an upper bound below the stoichiometric 100% limit on target-available carbon. The outer envelope is \([0,1]\), but its endpoints are not claimed to reproduce every measured isotope peak. This does **not** mean T cells are observed to release that carbon. It means the accessible evidence does not quantify transfer. In the tested 5 mM cellobiose tracer pulse, atom balance permits up to 10 mM glucose equivalents, or 20 mM lactate, if the entire feed is taken up and all carbon exits through lactate. The lower endpoint is zero. These are exact stoichiometric ceilings, not observed concentrations.

This matters because primary tumor studies have directly demonstrated MCT1-dependent uptake and oxidation of lactate in oxygenated tumor cells ([Sonveaux et al. 2008](https://www.jci.org/articles/view/36843); [Kennedy et al. 2013](https://pmc.ncbi.nlm.nih.gov/articles/PMC3771963/)). Those studies establish a real recipient mechanism in some models, not that the specific EL4-OVA or CAR-T cocultures in the Cell paper receive a consequential dose of cellobiose-derived lactate. The decisive measurement must label both source and recipient compartments.

## Model and quantitative gate

One cellobiose molecule has 12 carbon atoms. CDT-1 imports it with one proton, and intracellular GH1-1 hydrolyzes it into two glucose units. If both C6 units end as extracellular C3 lactate, the maximum is four lactate molecules per cellobiose. For the source's 5 mM tracer feed, this gives 60 mM carbon-atom equivalents and a maximum 20 mM lactate. For measured feed concentration \(B_0\), uptake fraction \(u\), and carbon fraction routed to lactate \(f_L\),

\[
L_{\mathrm{export}}=4B_0u f_L.
\]

For a coculture, let \(q_B\) be cellobiose uptake per engineered effector per hour, \(r=N_E/N_T\) the viable effector:target ratio, and \(a_L\) the fraction of cellobiose-derived lactate carbon captured and metabolized by target cells under the actual oxygen and pH conditions. The tumor-available amount in glucose carbon equivalents is

\[
J_{T,\mathrm{glc\;eq}}=2r q_B f_La_L.
\]

If \(d_T\) is the target's measured glucose-equivalent deficit needed to change its net growth or survival by a preregistered margin, crossfeeding can reach that margin only when

\[
2r q_B f_La_L\ge d_T.
\]

The same system must separately measure shared glutamine, oxygen, and amino-acid use. Cellobiose may support greater effector activity or expansion, which changes the common-resource terms even if no public carbon is released. CDT-1 imports one proton per cellobiose in the source model, but the ATP-equivalent cost to restore the proton gradient is unreported; constitutive CDT-1/GH1-1 expression adds another unquantified translation/turnover cost. The dynamic model therefore includes unknown measurable terms \(c_Hq_B\) and \(c_{expr}\) in the effector energy balance, alongside shared-resource depletion, species-specific byproduct balances, and separate extracellular pH. It does not assign guessed ATP values or impute rates from the publication.

`stoichiometric_gate.py` computes the exact carbon ceiling and encodes the symbolic target-flux threshold using rational arithmetic. It labels the 5 mM pulse as a source-reported assay condition and explicitly does not estimate an actual leakage rate.

## Source and prior-art boundary

The primary paper is Miller et al., *Cell* 189 (2026), [DOI 10.1016/j.cell.2026.01.015](https://doi.org/10.1016/j.cell.2026.01.015). Its published abstract reports cellobiose-supported mouse and CAR-T functions and tumor control; indexed full text says tumor cells cannot use cellobiose. Its data statement places non-sequencing results in the article/STAR Methods and links sequencing data separately. No extracellular labeled-metabolite dataset was found in that linked deposit.

The methods boundary was checked against Miller's open [2024 UCLA dissertation precursor](https://escholarship.org/content/qt0p1615jf/qt0p1615jf.pdf?t=s7pnsn). It reports intracellular labeling, cell-pellet extraction, and proton symport/ECAR compensation; it also identifies modest CDT-1-dependent cellobiose accumulation in T cells. This is the same research program and is not an independent replication. It cannot establish secretion. A primary *Corynebacterium glutamicum* study using an intracellular GH1-1 pathway found state-dependent cellobiose-derived extracellular glucose (up to 12 g/L during adaptation and 5 g/L in one later transfer, while another evolved strain did not release detectable glucose) despite little or no extracellular β-glucosidase activity ([Lee et al. 2016](https://link.springer.com/article/10.1186/s12934-016-0420-z)). This is a proof that the pathway architecture does not universally force zero glucose release across hosts; bacterial values cannot be transferred to T cells.

Novelty remains **UNKNOWN**. The atom-balance calculation and observation non-identifiability argument are internally checked consequences of a deliberately restricted measurement interface; they are not a new biochemical pathway discovery, a tumor-fueling observation, or a claim that leakage occurs. Existing tumor lactate shuttling literature precludes presenting lactate as a newly discovered public metabolite.

## Decisive experiment and costs

Start with the source's EL4-OVA/OT-I model and then test the human CAR-T/Raji pairing. Match sorted CDT-1/GH1-1 effectors against empty-vector effectors; measure effector-only, transwell, and direct coculture in 200 µM unlabeled glucose alone or with 5 mM U-\(^{13}\)C\(_{12}\)-cellobiose. Follow 0, 1, 4, 8, and 16 hours. Quantify residual cellobiose and extracellular labeled glucose, lactate, pyruvate, alanine, acetate, and targeted organic acids. Sort target cells to quantify labeled carbon in their central metabolites and biomass, with viable effector and target counts. In separate target-only arms, titrate U-\(^{13}\)C-lactate and low glucose at matched oxygen and pH to estimate \(a_L\) and \(d_T\). Measure pH separately from ECAR. Record glutamine, oxygen, and amino-acid depletion to detect non-carbon resource competition.

For the first EL4 acquisition, 2 constructs × 2 substrate conditions × 3 culture geometries × 5 time points × 4 independent biological blocks gives 240 media samples before separate target-pellet, function, and energy-balance wells. Half contain 5 mM U-13C12-cellobiose. At 200 µL per labelled sample this consumes 42.5 mg of tracer; at 1 mL it consumes 212.5 mg, before standards, pilot losses, or repeats. A vendor lists a 100 mg size at quote-only pricing ([MCE catalog](https://www.medchemexpress.com/d-cellobiose-13c12.html)). UCLA publishes internal FACS sorting rates of $71.48/h unassisted or $99.27/h assisted, but sorting time depends on sample yield ([current rate sheet](https://stemcell.ucla.edu/shared-resources/flow-cytometry-core)). The UCLA Metabolomics Center accepts culture-media samples but publishes no fee schedule, so the all-in LC-MS cost needs a core quote ([service description](https://ctsi.ucla.edu/ucla-metabolomics-center-ucla)). A second human CAR-T/Raji system doubles the base media count to 480. Oxygen/pH coverage and effector:target ratios must span the tumor-killing trajectory.

Falsify a tested-context private-fuel guarantee if labeled target uptake or target growth/survival rescue exceeds its preregistered materiality threshold, or if cellobiose-supported effector expansion depletes a shared limiting resource enough to alter target outcome. Support is context-limited: it requires upper confidence bounds on both transfer and shared-resource effects below the declared thresholds in the named target, oxygen, pH, dose, and effector:target range.

## Validation and files

The runnable calculation returns 60 mM carbon atoms, 10 mM glucose equivalents, and a 20 mM lactate ceiling for the source's 5 mM labeled-cellobiose pulse. It also returns the stoichiometric target-availability envelope and encodes the assay gate $2r q_B f_L a_L \ge d_T$. The 5 mM and 10 mM lactate examples are planning calculations, not measured levels. The Python source compiled, JSON certificates parsed, and exact `Fraction` checks passed for the atom-balance ceilings, interface endpoints, target-flux gate, and tracer-mass calculation. See [PROOF.md](PROOF.md) for the non-identifiability argument and dynamic balances, [SOURCE_NOTES.md](SOURCE_NOTES.md) for the primary-source audit, and [CLAIMS.json](CLAIMS.json) for the scoped claim ledger.
