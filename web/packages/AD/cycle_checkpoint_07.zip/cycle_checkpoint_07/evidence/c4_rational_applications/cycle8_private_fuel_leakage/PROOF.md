# Carbon-transfer identifiability and assay gate

## Reaction interface

The source pathway has three specified steps:

\[
\begin{aligned}
\mathrm{cellobiose}_{e}+\mathrm{H^+}_{e}
  &\xrightarrow{\mathrm{CDT\!-!1}}
  \mathrm{cellobiose}_{i}+\mathrm{H^+}_{i},\\
\mathrm{cellobiose}_{i}+\mathrm{H_2O}
  &\xrightarrow{\mathrm{GH1\!-!1}}
  2\,\mathrm{glucose}_{i}.
\end{aligned}
\]

The 1:1 proton symport is reported in the primary-source thesis figure and
discussion; the 2026 Cell paper likewise identifies CDT-1 as a proton
symporter. No ATP-per-transport stoichiometry is reported for the mammalian
T-cell construct, so none is assigned here. The hydrolysis conserves the 12
carbon atoms. If both glucose units pass through glycolysis and end as
extracellular lactate, the exact carbon-only endpoint is

\[
1\ \mathrm{cellobiose}\longrightarrow 4\ \mathrm{lactate},
\]

because each lactate contains three carbons. Consequently, for an initial
batch feed \(B_0\) mM, the strict atom-balance ceiling is

\[
0\le L_{\rm from\;B}\le 4B_0\quad\text{mM},
\qquad
0\le C_{\rm public}\le 12B_0\quad\text{mM carbon atoms}.
\]

The lower endpoint corresponds to complete retention/oxidation of the
cellobiose-derived carbon rather than organic-carbon release. The upper
endpoint is a feasible stoichiometric fermentation limit, not a prediction
that T cells reach it. For the source's 5 mM U-\(^{13}\)C\(_{12}\)-cellobiose
pulse, the ceiling is 10 mM glucose equivalents, 60 mM carbon atoms, or
20 mM lactate if all substrate is consumed and all carbon is secreted as
lactate. If only fraction \(u\) of the feed is consumed and fraction \(f_L\)
of consumed substrate carbon exits as lactate, the batch relation is

\[
L_{\rm from\;B}=4B_0u f_L.
\]

## Non-identifiability result

**Claim.** Intracellular isotope labeling of central-carbon pools, a scalar
extracellular-acidification-rate (ECAR) readout, and a target-only assay of
cellobiose non-use do not yield a robust upper bound below atom balance on the
fraction of consumed cellobiose carbon that can become target-available.

**Proof.** Let \(u\) be the fraction of dosed cellobiose taken up, \(f_j\) the
fractions of its carbon released into extracellular species \(j\), and
\(a_j\) the fraction of each released species captured/metabolized by targets.
The target-only cellobiose assay reports no functional benefit from direct
cellobiose supplementation in the tested line; it is not a flux measurement
and places no constraint on \(a_j\) for glucose, lactate, pyruvate, or other
public products. The 2024 thesis precursor describes a tracer protocol that
extracts intracellular metabolites after labeling. The accessible paper record
places non-sequencing results in the article/STAR Methods and its linked
sequencing deposit contains no
extracellular isotope-flux dataset. I found no species-resolved extracellular
labeled-metabolite balance in the accessible source materials. A labeling
fraction inside glycolytic, pentose-phosphate, or TCA pools reports atom origin
in those pools, not the cumulative fraction leaving the cell through a branch.

The same U-\(^{13}\)C substrate can therefore label intracellular
intermediates whether downstream carbon is released as lactate, retained in
biomass, oxidized to CO\(_2\), or split among those destinations. The
precursor thesis reports fractional labeling of intracellular pools, not a
cellobiose uptake total or a closed intracellular-plus-extracellular carbon
balance. Fractional enrichment establishes atom origin, but by itself gives no
ratio between cumulative throughput and the amount present in the sampled
intracellular pools. ECAR is also not a species-resolved carbon-flux readout:
the source identifies H\(^+\) cotransport into the cell with cellobiose, which
offsets extracellular acidification produced during catabolism, while ECAR
aggregates other acid/base sources. Target capture \(a_j\) is likewise
unobserved. Thus these measurements do not identify the transfer fraction.

Write \(f_j\ge0\) for the share of consumed carbon secreted as extracellular
species \(j\), with \(\sum_j f_j\le1\), and \(a_j\in[0,1]\) for the share of
that species captured by targets. The target-available share is
\[\phi=\sum_j f_j a_j\in[0,1].\]
Under the declared measurement interface, the identified outer set is exactly
\[
\Phi_{\rm interface}
=\left\{\sum_j f_j a_j:\ f_j\ge0,\ \sum_j f_j\le1,\ 0\le a_j\le1\right\}
=[0,1].
\]
For any \(\phi\in[0,1]\), a stoichiometric completion is \(f_L=\phi\),
\(a_L=1\), with the remaining carbon assigned to unobserved fates. The
script emits the endpoint completions for the 5 mM feed. They satisfy atom
balance but are not claimed to reproduce every measured isotope peak or a
complete T-cell kinetic model. The source does not quantify uptake, close the
carbon balance, or supply a calibrated map from intracellular labeling/ECAR
to the secretion and capture fractions. Thus the maximum \(\phi=1\) is the
robust upper limit from this interface, not a finding that all carbon is
released or consumed by targets; a sub-100% limit requires acquired kinetic,
pool-size, or extracellular flux data. Tumor lactate uptake is not a
hypothetical capability: primary studies demonstrate MCT1-dependent lactate
uptake and oxidation in oxygenated tumor cells. This establishes a possible
recipient mechanism, not that the studied EL4-OVA or CAR-T cocultures have
consequential cellobiose-derived lactate transfer.

Hence the identified robust envelope for target-available consumed carbon is
the full atom-balance range, with supremum 1; this is an observation-interface
no-go, not a claim that T cells realize the upper endpoint. The absolute
extracellular ceiling is \(12\int J_B\,dt\) carbon atoms, and even the uptake
integral \(J_B\) is not reported for the relevant coculture. This proves the
non-identifiability claim. \square

## A measurable consequence threshold

Let \(q_B\) be cellobiose uptake per engineered effector per hour, \(r=N_E/N_T\)
the viable effector:target ratio, \(f_L\) the fraction of cellobiose carbon
secreted as lactate, and \(a_L\) the fraction of this lactate carbon captured
and used by targets under the assay's oxygen/pH conditions. A carbon-equivalent
upper estimate of target supply is

\[
J_{T,\mathrm{glc\;eq}}=2r q_B f_La_L
\quad\text{glucose-equivalents per target per hour}.
\]

This is not an ATP equivalence. Let \(d_T\) be the target line's experimentally
measured glucose-equivalent flux needed to change its net growth/survival by a
preregistered margin under the same low-glucose, oxygen, and pH condition. A
carbon-transfer mechanism can reach that margin only if

\[
2r q_B f_La_L\ge d_T.
\]

Thus the falsifiable leakage gate is

\[
f_La_L\ge \frac{d_T}{2r q_B}.
\]

All four quantities must be measured in the same cell/medium regime. The
primary cellobiose paper provides a 5 mM, 16-hour intracellular isotope-pulse
protocol, but not \(q_B\), \(f_L\), or \(a_L\); the 2024 thesis precursor
reports that CDT-1-dependent intracellular cellobiose after 125 minutes was
only about twice control and that the transporter effect was modest. Neither
source can populate this inequality for live co-culture.

## Shared-resource extension

Even when \(f_La_L=0\), cellobiose-supported proliferation can change demand
for nutrients that are still shared. For each shared substrate \(s_i\), a
minimal well-mixed balance is

\[
\dot s_i = D_i(s_i^{\rm in}-s_i)
  -N_E q_{E,i}(B,s_i,O_2,\mathrm{activation})
  -N_T q_{T,i}(s_i,O_2)
  -N_O q_{O,i}(s_i)+p_i,
\]
where \(N_O\) represents other cells, \(p_i\) is measured production, and
\(D_i\) is a supply/clearance term. Cellobiose can increase \(N_E\), effector
activation, or per-cell respiratory/biomass demand, so cellobiose exclusivity
does not remove any of these terms.

The energy balance also needs terms for the measured one-proton cotransport and
unmeasured expression burden, for example

\[
\Pi_{E,\rm net}=\Pi_{\rm substrate}(B,G,O_2)
  -c_HJ_B-c_{\rm expr}N_E,
\]

where \(J_B=N_Eq_B\) is total cellobiose uptake per time, \(c_H\) is the
ATP-equivalent cost of restoring the proton gradient per cellobiose imported,
and \(c_{\rm expr}\) is the ongoing translation/turnover cost of CDT-1/GH1-1
expression per viable effector. The \(\Pi\) terms denote ATP fluxes, not ATP
pool concentrations. The source fixes the proton-import stoichiometry but
reports neither coefficient, so they must be measured rather than assigned
guessed ATP values. A matched glucose-replete comparison of sorted dual-positive
versus empty-vector T cells estimates the expression/fitness penalty;
substrate-resolved ATP/ADP, respiration, and proton-flux measurements in
cellobiose-fed cells estimate the transport-linked term. These costs can
change effector proliferation and thereby all common nutrient terms above.
For extracellular byproduct \(m_j\),

\[
\dot m_j=N_E J_{E,j}(B)-N_T q_{T,j}(m_j,O_2)-k_jm_j.
\]

The paper's own discussion of CDT-1 proton cotransport means the acidity state
must be modeled separately from the carbon state; a single ECAR value cannot
substitute for species-resolved carbon and pH. These equations are an assay
interface, not a fit to unreported kinetics.

## Decision experiment

Use the published EL4-OVA/OT-I system first, then repeat the decisive result in
the human CAR-T/Raji pairing. At minimum:

1. Compare sorted dual-positive CDT-1/GH1-1 effectors with matched empty-vector
   effectors, each alone and with targets in a transwell and direct coculture.
2. Reproduce the source's 5 mM U-\(^{13}\)C\(_{12}\) cellobiose, 200 µM
   unlabeled glucose, 16-hour pulse; add a 0/1/4/8/16-hour time course and a
   cellobiose-only arm. Measure residual cellobiose, glucose, lactate,
   pyruvate, alanine, acetate, and other targeted organic acids in media; do
   not infer them from ECAR.
3. Sort target cells and quantify labeled target central-carbon metabolites
   and biomass alongside live target and effector counts. Measure extracellular
   pH and ECAR as separate channels. Add U-\(^{13}\)C-lactate titration to
   target-only cultures to estimate \(a_L\), and a low-glucose titration to
   estimate \(d_T\).
4. Measure shared-resource draws (at least glutamine, oxygen, and amino-acid
   depletion) in matched conditions. Repeat at the effector:target ratios
   reached over the target-killing trajectory, not only at the initial ratio.
5. Stop the private-fuel claim for a tested context if target isotope uptake
   and target growth/survival rescue exceed the preregistered margin, or if
   cellobiose measurably depletes a shared limiting resource enough to change
   target outcome. Support it only for a declared line/oxygen/pH/range if the
   upper confidence bounds on both crossover and shared-resource effects are
   below the predeclared materiality margins.

For a source-matched acquisition, use two substrate states: 200 µM unlabeled
glucose alone, or the same medium plus 5 mM U-\(^{13}\)C\(_{12}\)-cellobiose.
The first EL4 experiment then has 2 effector constructs × 2 substrate states ×
3 culture geometries (effector alone, transwell, direct coculture) × 5 time
points × 4 independent biological blocks = 240 media samples. Half are
tracer-fed. At 200 µL per tracer-fed sample, the nominal feed uses 42.5 mg
U-\(^{13}\)C\(_{12}\)-cellobiose; at 1 mL it uses 212.5 mg, before standards,
pilot losses, and repeats. The product page lists 100 mg as a quote-only size.
UCLA publishes internal FACS sorting rates of $71.48/h unassisted or $99.27/h
assisted; sorting time depends on sample yield. The UCLA Metabolomics Center
accepts culture-media samples but does not publish a fee schedule, so a core
quote is needed for the 240-sample isotope panel. Target-pellet isotope
quantitation, functional wells, pH/ECAR, viable counts, ATP/ADP, respiration,
and proton-flux assays add samples and labor. A second CAR-T/Raji system
doubles the base media count to 480.
