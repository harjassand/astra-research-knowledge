# Family 131: degree-preserving graph nulls and their biological boundary

## Verdict

Family 131 supplies a source-reported, worst-case mixing guarantee for one precise null model: the uniform distribution over all simple undirected graphs on the same labeled vertices with exactly the observed degree at each vertex. It does not justify biological inferences that require spatial feasibility, cell-type mixing, connectivity, weights, direction, or assay-detection structure to be preserved.

For a two-compartment cell-contact graph, the degree-only null puts substantial mass on contacts that cannot occur across the physical separation. This gives a concrete counterexample to treating convergence to the degree-conditioned uniform law as evidence that the null captures the contact-generating biology. It does not contradict the mixing theorem. The theorem remains useful when the question is explicitly “unusual relative to all simple graphs with these fixed labeled degrees.”

Status: I retrieved and text-extracted the release PDF at the specified OpenAI math snapshot and reconstructed its interfaces and stated bounds. I did not verify the source proof, re-run its proof checks, or establish independent correctness or priority.

## The source theorem and exact randomization

Let V={1,…,n}, n≥4, and let d=(d1,…,dn) be a graphical labeled degree vector. The state space Ωd is every simple undirected graph on V in which vertex i has degree di. The stationary target πd is uniform on Ωd. Thus the vertex labels and each individual vertex’s degree are fixed; only the edge set varies. The host is the complete graph: every unordered vertex pair is eligible in principle.

The paper’s discrete-time chain is lazy. With probability 1/2 it stays put. Otherwise it chooses a four-vertex set S uniformly from the binom(n,4) choices, then chooses one of the six ordered pairs (F,F′) of distinct perfect matchings on S uniformly. If the two edges in F are present and the two in F′ are absent, it deletes F and inserts F′; otherwise the proposal is rejected and the chain stays. This is a simple-graph double-edge switch. For each switch-neighbor G′ of G, the stated transition probability is 1/(12 binom(n,4)); the remaining probability is a self-loop. The paper states that the chain is connected on Ωd, reversible, and has uniform stationary distribution.

Theorem 1.1 states that for every graphical d and every starting graph,

    t_mix(d) = min{t : max_G ||P_d^t(G,·)-π_d||_TV ≤ 1/4} ≤ 2 n^8.

If |Ωd|>1, it also states a spectral-gap lower bound of [24 n² binom(n,4)]^−1. If |Ωd|=1, mixing time is zero. This is a worst-case bound for the complete-host simple-undirected chain, counting every lazy or rejected proposal as a step. It is not a bound for spatially restricted or biologically typed switches.

Corollary 1.2 states an exact sampler for every finite graphical labeled degree vector. It uses unbiased random bits, terminates almost surely, outputs exactly uniform from Ωd, and has expected bit running time bounded by a fixed polynomial in the binary encoding length of d. The expected-time qualification is essential. The construction usually runs a finite-time chain from one deterministically constructed realization; with an exponentially small probability it takes a correction branch that enumerates up to 2^binom(n,2) adjacency bitstrings and tabulates the finite-time law. That rare branch can take exponential time. Rejection-based integer draws also have unbounded tails. The paper explicitly does not claim a polynomial bound on every execution.

For a practical degree-only null, the direct consequence is a conservative burn-in certificate: at most 2n^8 steps bring this specified chain within TV distance 1/4 of uniform from any starting graph, conditional on the observed degree vector. A tighter accuracy δ can be read from the source proof’s gap estimate and dependence on |Ωd|. This is a mathematical certificate, not evidence that the degree-only distribution is the right biological null.

## Cell-contact counterexample

Fix m≥5 and split n=2m labeled cells into two tissue compartments A and B separated by a barrier large enough that cross-compartment contacts are physically impossible. Within each compartment, put a 4-regular circulant graph: connect each cell to its two nearest cells in each direction around that compartment’s cycle. The observed graph is the disjoint union of these graphs. It is simple, has degree di=4 at every labeled cell, and has zero cross-compartment edges.

The Family 131 degree-only null is uniform over all simple 4-regular graphs on the 2m labeled vertices. By invariance under vertex permutations, every potential edge has probability 4/(2m−1): for any vertex the 2m−1 possible neighbors are exchangeable and its expected degree is exactly 4. There are m² possible A–B edges, so if X counts cross-compartment edges,

    Eπ[X] = 4m²/(2m−1) ≈ 2m.

Also X≤4m because A has 4m total degree stubs. Consequently

    π(X≥m) ≥ (Eπ[X]−m)/(3m)
            = (2m+1)/(6m−3) > 1/3.

After 2(2m)^8 steps from any starting graph, the source theorem’s TV guarantee would therefore imply probability greater than 1/12 of a randomized graph having at least m cross-compartment edges. Those edges are impossible in the actual tissue geometry. The counterexample keeps every labeled cell and its degree fixed; the failure comes solely from using a complete-host degree-only state space when physical edges are restricted by space.

This invalidates a biological interpretation beyond the null’s stated conditioning. Degree-only rewiring can answer a descriptive question about topology beyond exact labeled degrees. It cannot by itself distinguish biological interaction preference from distance, cell-type compatibility, barriers, tissue compartments, or observation bias. It also does not imply rapid mixing after adding any of those constraints.

## What is fixed, and what is not

In the valid degree-only cell-contact null, keep fixed: cell identities as vertex labels, the observed undirected/unweighted representation, and each cell’s observed degree. The randomized object is the edge set among all unordered pairs, subject only to simplicity and the fixed degree vector.

The chain does not preserve cell coordinates, edge lengths, contact area, cell-type assortativity, regional membership, connectedness, clustering, motifs, or edge weights. If edges must lie within a contact radius or between compatible cell types, the admissible host is no longer complete. A rejected switch chain on that host could be reducible or mix slowly; Family 131 does not cover it. Directed molecular regulation, bipartite ligand–receptor graphs, multi-edges, and weighted interaction strengths are also outside this theorem.

For an empirical cell-contact analysis, record at least the per-edge distance or shared-boundary length; cross-region and cross-cell-type contact counts; local cell-type densities; graph connectivity; and assay confidence or missing-edge indicators. Test the statistic relevant to the biological hypothesis against nulls that preserve the corresponding constraints. A local spatial-coordinate randomization is a stronger matched control when the question concerns whether contacts exceed local spatial chance.

## Primary prior art and matched controls

Maslov and Sneppen’s 2002 protein-network study is a primary biological precedent for degree-preserving rewiring: it compares protein interaction and regulatory networks with randomized networks to assess degree correlations. A later primary PPI null-model study states the same-vertex, per-vertex-degree constraint explicitly. Family 131’s claimed advance is the worst-case mixing guarantee for every graphical labeled degree vector in the simple-undirected complete-host model; its source proof and novelty are not independently certified here.

For spatial cell interactions, the matched control is more constrained. The whole-mouse-brain cell atlas by Yao et al. assesses cell-type interaction frequencies using local spatial-coordinate randomizations that disrupt neighbor relations while preserving local cell-type density and brain structure. That design retains biological geometry that the degree-only null erases. It is not a degree-preserving graph chain, and Family 131 does not establish its mixing properties.

Primary sources:

- OpenAI, “Polynomial mixing of the switch chain for every graphical degree sequence,” release snapshot adc7f1241b42e322a6451854ab7e4b4c146bf78a, PDF pages 1–2 and 17–21. [Pinned release PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Mixing-of-the-Switch-Chain-for-Every-Graphical-Degree-Sequence-September-25-2026/main.pdf)
- Maslov and Sneppen, “Specificity and stability in topology of protein networks,” Science (2002), DOI 10.1126/science.1065103. [Primary article](https://doi.org/10.1126/science.1065103)
- Yao et al., “A molecularly defined and spatially resolved cell atlas of the whole mouse brain,” Nature (2023), DOI 10.1038/s41586-023-06808-9. [Primary article](https://doi.org/10.1038/s41586-023-06808-9)
- Liu et al., “A complex network framework for unbiased statistical analyses of DNA–DNA contact maps,” Nucleic Acids Research (2013). The authors explain that ordinary rewiring can disrupt global clustering in contact networks and introduce additional constraints. [Primary article](https://pmc.ncbi.nlm.nih.gov/articles/PMC3553935/)

## Cost and falsifier

The source chain costs at most 2n^8 discrete proposals to reach TV 1/4; each proposal samples a four-set and one of six matching directions and checks at most four edges. This polynomial worst-case mixing bound is very large and may be impractical at tissue-atlas sizes. The exact sampler has expected polynomial bit time in the explicit degree-vector length, but the rare correction branch enumerates exponentially many graph encodings; no per-run polynomial guarantee is available. Data acquisition, degree-estimation uncertainty, cell segmentation, false contacts, and biological replication are not included in either bound.

The biological transfer is falsified for a proposed spatial-contact claim if the complete-host degree null assigns substantial mass to geometrically impossible edges or produces a nontrivial edge-length distribution absent from the experiment. In the two-compartment family above, the exact expectation and probability lower bound already show this mismatch.

## Positive capability: a conditional graph randomization test

The theorem does support a narrower, positive procedure. Fix in advance a partition of the labeled vertices into compartments C_1,…,C_s, and suppose cross-compartment edges are disallowed by the assay’s physical design. Let d_i be each vertex’s observed within-compartment degree. Define the stratified null H0^strat by drawing, independently for each compartment C_j, a graph uniformly from Ω_{d|C_j}, the simple undirected graphs on that compartment’s fixed labels with the specified labeled degrees. This is a product of degree-sequence-conditioned uniform laws. It preserves each cell identity, each observed degree, the compartment partition, and the absence of between-compartment edges. Because each within-compartment host is complete, Family 131’s chain and sampler apply separately to each factor (small factors can be enumerated directly).

Before inspecting the observed edge pattern, preregister the statistic T and tail direction (or use a statistic that depends only on covariates being conditioned on, with any selection accounted for). For example, if node labels encode two molecular cell types, T can count within-compartment edges joining types A and B; for measured receptor/ligand scores r_i and l_i, T can be the edge score ∑_{ {i,k}∈E }(r_i l_k+r_k l_i). The latter tests a graph-level co-neighbor association conditional on the fixed node scores and degrees; it is not a causal signaling test. Given the observed graph G_0 and B independently sampled null graphs G_1,…,G_B, the one-sided upper-tail Monte Carlo p-value is

    p_MC = (1 + #{b : T(G_b) ≥ T(G_0)})/(B+1).

Under the explicit assumption that, conditional on the fixed compartments, labeled degrees, and node covariates, G_0 itself is uniform under H0^strat, G_0,G_1,…,G_B are exchangeable. Therefore p_MC is super-uniform and the test that rejects when p_MC≤α has conditional type-I error at most α; ties make this version conservative. This is a finite-sample Monte Carlo randomization test, not a new network-science theorem. Conditioning on degrees alone does not establish this exchangeability: it is the biological/statistical null assumption that needs justification from the sampling design.

For a fixed observed score T(G_0), let q=P_{H0^strat}(T(G)≥T(G_0)) and let K be the number of exceedances in B exact uniform draws. Hoeffding gives P(|K/B−q|≥ε)≤2 exp(−2Bε²), so B≥log(2/β)/(2ε²) estimates q within ε with confidence at least 1−β. The plus-one p-value above has minimum resolution 1/(B+1); at level α, at least B+1≥1/α is needed for rejection to be attainable.

There are two source-supported sampling cost statements, with different guarantees. Running the Corollary 1.2 exact sampler afresh for each draw gives exact independent uniform samples and hence the finite-sample test above. Its expected bit cost is polynomial in the explicit degree-vector length, but its execution time is unbounded: the rare correction branch has probability δ=2^{−(4 binom(n,2)+10)} and can enumerate up to 2^{binom(n,2)} encodings. Thus the exact test has an expected-cost guarantee, not a useful worst-case runtime bound. Alternatively, for an approximate switch-chain implementation, standard TV mixing-time amplification applied to the source’s t_mix(1/4)≤2n_j^8 gives t_mix(ε_j)≤2n_j^8⌈log_2(1/ε_j)⌉ proposals per compartment. If each of the B independent product draws uses ε_j=η/(Bs), the joint law of all randomized graphs is within η TV of the ideal iid product law by a union bound. The plus-one test with this approximate sampler then has type-I error at most α+η; using cutoff α−η (for α>η) restores a bound of at most α. The total proposal count is at most 2B⌈log_2(Bs/η)⌉∑_j n_j^8, excluding graph storage and data preparation. This can still be prohibitive, and the result is conditional on the source theorem, whose proof has not been independently checked here.

This compartment-preserving null is a matched control for the two-compartment counterexample: it removes the impossible cross-compartment edges before evaluating within-compartment type mixing or molecular co-neighbor scores. It is not a spatial null within compartments. Strong dependence of edge opportunity on distance, boundary length, local density, or tissue architecture falsifies uniform within-compartment exchangeability; in that case a local-coordinate randomization such as the Yao et al. design is better matched, but Family 131 supplies no mixing guarantee for that constrained procedure. Other direct falsifiers include post-hoc compartment definitions, cell-type-dependent contact opportunity, systematic missing-edge/segmentation error, and observed within-stratum degree-preserving edge statistics that remain strongly tied to spatial covariates. Report contact distance/shared boundary, local cell-type density, compartment, edge confidence, and the preregistered T alongside the p-value.

The biological claim is therefore explicitly conditional: the procedure can test whether a preregistered graph statistic is unusual under a uniform, degree-conditioned, compartment-preserving graph law. It cannot establish that this law generated the tissue, nor infer molecular causality. A decisive empirical follow-up would freeze compartments, degrees, covariates, and T before sampling; report complete-host and compartment-preserving results side by side; then compare to a spatially matched control and show whether the result survives the geometry-aware null.

## L04 selective-output boundary retained

L04 concerns X∈Z^(N×D), Y∈Z^(D×N), D=N^1/4, and a supplied arbitrary mask W of requested entries of XY, |W|≤N^15/8. Some legal masks force Ω(N²) total charge for independently charged complete-block covers that cover every requested pair-coordinate contribution. Shared output-local arithmetic remains allowed. This does not imply a lower bound on general selective algorithms or biological samples. The expanded proof text and its provenance are retained in sources/SELECTIVE_OUTPUT_AUDIT.md and sources/source_manifest.json.
