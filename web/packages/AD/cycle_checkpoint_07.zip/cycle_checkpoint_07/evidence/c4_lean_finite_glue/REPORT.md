# Finite-cover gluing component for N33 affine approximation

## Result

`N33FiniteGlue.lean` formalizes the finite interval-gluing stage against the shared `N33Affine` interface. The Lean-checked results are:

- After removing contained members, pairwise noncontainment of the retained symmetric open intervals and strict center ordering force both endpoint sequences to be strictly ordered.
- A cover of `[a,b]` has no gap between consecutive retained intervals. The midpoint of the open overlap between the earlier right endpoint and later left endpoint lies strictly between both centers and inside both intervals. These cuts are strictly increasing.
- The first retained interval extends strictly left of `a`, and the last extends strictly right of `b`.
- The combined finite family is the sigma-tagged union of all local families. The offset for tag `j` is the local offset minus the prefix sum `Σ_{l<j} h^(q_l)`. It is finite and nonempty, and each shifted offset remains `o(h^a)` when the local offset is `o(h^(c_j+r_j))`, `a≤c_j`, `r_j>0`, and the source cuts satisfy `q_l>c_l`.
- Weak activity of a fixed tagged label in the combined family implies weak activity in its local family because the shared prefix cancels exactly. Thus if the limiting minimum-coordinate `s` belongs to that tag's closed cut slab, the cut inequalities put `s` strictly inside the local open neighborhood, and the local neighborhood guarantee applies.

The file keeps the tolerance `E` opaque. It adds no continuity or measurability assumption. The approximating sequence `pSeq` is unrestricted; only its limit must be in the cube. Activity is the weak comparison against every label, so all ties remain included.

## Exact integration boundary

This component proves the inheritance step **conditional on the limiting minimum-coordinate belonging to the family's assigned cut slab**. It does not prove that eventual global activity forces that slab membership. That active-comparison argument needs the varying-real-exponent separation lemmas plus the local slope and base-label properties from the other proof components. Keep this as an explicit integration gate; this file alone does not establish the full affine approximation theorem.

The compact-neighborhood theorem that supplies `LocalNeighborhoodGuarantee`, and the slice induction that constructs the local families, are inputs to this component. The current signature is compatible with `N33Affine.Label`, `Active`, `InCube`, `AtMinSlice`, `LittleO`, and `FiniteFamily` from `N33Affine.AffineCore` / `N33Affine.SliceFamily`.

## Lean evidence

The source was checked with the read-only Lean 4.28 environment at `/Users/harjas/Documents/Codex/2026-07-14/i-want-you-to-look-at/work/tmp/erdos-1005-lean`. The task-local file sits outside that Lake project's root, so the command uses `lake env lean -R <task-directory> <absolute-task-file>` and points `LEAN_PATH` to its already-built Mathlib and shared companion `.olean` files. No file under the Lean project was edited.

- `logs/glue_compile.log`: successful source check, exit code 0.
- `logs/olean_compile.log`: successful object-file build, exit code 0.
- `logs/axiom_audit.log`: `#print axioms` on the cut, family, offset, and inheritance theorems. Each reports only `propext`, `Classical.choice`, and `Quot.sound`; no `sorryAx` or custom axiom appears.

## Main exported declarations

In namespace `N33Affine.Glue`:

- `exists_ordered_cuts` and `exists_cover_gluing_data`
- `cover_boundary_bounds` and `cut_slab_inside_local_interval`
- `gluedFamily`, `gluedFamily_active_restricts`, and `gluedFamily_offsets_littleO_of_cover`
- `active_label_inherits_from_cut_slab` and `finite_family_active_label_inherits_from_cut_slab`

No external project source was changed. The only outputs are in this agent's directory.
