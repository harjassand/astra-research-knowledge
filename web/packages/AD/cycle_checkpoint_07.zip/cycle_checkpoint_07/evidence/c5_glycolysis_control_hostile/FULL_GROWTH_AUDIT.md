# Independent audit of the full-growth glycolysis candidate

## Verdict

The new C4 exact-rational calculations for the **reference-genotype** PLOS 2021 CellML model reproduce. The health, growth, and metabolite-dilution signs are also consistent with the source. However, the original metabolic tube permits negative net ATP profit, so it does not guarantee viability for every positive initial health value. A slightly narrower tube,

\[
S_+=\{1.8\le F\le2.2,\quad 0.5\le A\le1.5,\quad P\ge2,\quad A+P\le14\},
\]

has an independently checked full-growth certificate at `δ=0.17 mM/min`, source `kp=0.3 min⁻¹`, and reference genotype. It also makes net ATP profit nonnegative everywhere and therefore prevents the source health variable from decreasing. This includes the PLOS CellML's documented low-initial-phosphate startup case if feedback is applied from glucose onset. It does not show recovery after a cell has already entered the high-FBP, low-ATP, low-Pi collapsed state.

The application gate remains decisive: the source paper models a shared glucose concentration across a population. A single common glucose value cannot satisfy the opposing FBP-face conditions for two admissible cells in `S+`. The per-cell actual-flux law therefore has no direct implementation in that shared-culture setup. The `12.44 s` lag calculation is valid only for FBP measurement staleness with current ATP/Pi, exact kinetics, instantaneous glucose inversion/actuation, and no other flux error. No physical controller or sensor/actuator meeting those conditions has been demonstrated.

## Source equations and signs

The audited equations are transcribed from [Janulevicius and van Doorn, PLOS Computational Biology (2021), DOI 10.1371/journal.pcbi.1008547](https://doi.org/10.1371/journal.pcbi.1008547) and its [S1 CellML model](https://doi.org/10.1371/journal.pcbi.1008547.s001). The source defines `ADP=5−A`, `v_atp=katp A`, `Ptot=P+2F+A`, and

\[
P_{vac}=\frac{10}{1+(P_{tot}/250)^4},\qquad
v_p=kp(P_{vac}-P).
\]

At the reference genotype `(Vmaxup,Vmaxlo,katp,kp)=(10,10,10,0.3)`, CellML's fourth-power expression-cost ratio is exactly `vatpe=vatper=5 mM/min`. Thus `vatpg=10A−5`. Its growth gate is

\[
g=V'/V=\begin{cases}
u_g(10A-5),&H\ge H_{max}\text{ and }10A-5>0,\\
0,&\text{otherwise},
\end{cases}
\qquad u_g=\frac{\ln2}{90(12.7-5)}=\frac{\ln2}{693}.
\]

Therefore `g` is never negative; on `A≤1.5`, `0≤g<7/693=1/99 min⁻¹`. The full concentration equations include the *negative* dilution terms `−Fg`, `−Ag`, and `−Pg`. Under the candidate actual-flux input `U=L−(F−2)+e`, they reduce to

\[
\dot F=2-F+e-Fg,\quad
\dot A=2L+2(F-2)-2e-10A-Ag,\quad
\dot P=-2L+10A+0.3(P_{vac}-P)-Pg.
\]

Summing the last two cancels `L` and gives `d(A+P)/dt=2(F−2)−2e+0.3(Pvac−P)−(A+P)g`, matching the candidate. These signs make growth dilution helpful at the high-FBP and high-`A+P` faces, and adverse at ATP/Pi lower faces; the calculations use the conservative side at each face.

For health, CellML gives `vatpgri=vatpri−(vatper+vatpm)=0.46−5=−4.54`, hence

\[
u_d=\frac1{420(-4.54)}=-\frac5{9534}<0.
\]

When `vatpg≤0`, `Hdot=−ud vatpg=(5/9534)(10A−5)`, which is negative below `A=0.5`. When `vatpg>0` and `H<Hmax`, `Hdot=ug vatpg≥0`; when `vatpg>0` and `H≥Hmax`, `Hdot=0`. The paper defines death at `H=0`; the CellML piecewise equations do not themselves encode a death event. The growth gate never lets `g<0` even while health declines.

## Exact face certificate for the viable-profit sub-tube

The standalone verifier [FULL_GROWTH_AUDIT.py](FULL_GROWTH_AUDIT.py) uses `Fraction` arithmetic and no imports from C4's calculator. Its machine-readable output is [FULL_GROWTH_AUDIT.json](FULL_GROWTH_AUDIT.json). The source decimal parameters and only non-rational step `ln(2)<0.7` give these conservative normal derivatives for `S+`:

| Face | Worst inward normal derivative (mM/min) |
|---|---:|
| `F=1.8` lower | `13/1100 = 0.01181818…` |
| `F=2.2` upper | `−3/100 = −0.03` |
| `A=0.5` lower | `2209/4025 = 0.54881988…` |
| `A=1.5` upper | `−285619/104400 = −2.73581418…` |
| `P=2` lower, conservative | `0.65416647…` |
| `A+P=14` upper | `−1/100 = −0.01` |

On the whole tube `Ptot≤14+2(2.2)=18.4`, so the source algebraic store gives `Pvac≥9.99970657 mM`. On `S+`, `vatpg=10A−5≥0`: if `H>0`, health cannot decrease; if `H=Hmax`, it remains there. Thus the metabolite tube plus `H>0` is viable under these source equations. The source `kp=0.3` is only `0.004` above the exact sum-face threshold `kp≥0.296`; a downward change of `1/75=1.333…%` reaches the boundary. No strain-level confidence interval is supplied for `kp` or `Kvac`.

As a separate reserve check, even the wider region `A∈[0.3,0.5]`, `P≥2` has `Adot≥2209/4025` until it reaches `A=0.5`. Starting at `A=0.3,H=Hmax=1`, this takes at most `805/2209≈0.36442 min`; the worst integrated source health loss is bounded by `575/1504329≈0.00038224`, leaving `H≥0.99961776`. Once `A≥0.5`, health cannot fall. This transient bound needs `P≥2`; it is not valid for the old `P≥1` tube by this calculation.

The old larger tube really is not an all-health-state viability set. For example, at `F=1.8,A=0.3,P=2`, reference `vatpg=−2` and `Hdot=−5/4767≈−0.00104888/min`. Since the source treats `H=0` as death, sufficiently small positive `H0` reaches zero before the metabolite state leaves a neighborhood of this point. The original metabolite-invariance result remains valid, but it must not be described as survival for all points of that tube.

## Glucose inverse, shared-feed obstruction, and lag

For `S+`, the source lower flux gives conservative `2.755≤U≤6.22773142 mM/min`; the minimum upper-flux saturation capacity over `A∈[0.5,1.5]` is `300/47≈6.38297872`, leaving a positive gap `0.15524731`. The static inverse `G=0.1U/(C(A)-U)` is finite, with conservative `G≤4.011491 mM`. This only proves static pointwise invertibility, not that an extracellular feed actuator realizes `U` at the required speed.

The common-input contradiction remains on `S+`. At `(F,A,P)=(1.8,0.5,13.5)`, `g=0` and the lower FBP face needs `Ulow≥Llow=5.477359…`. At `(2.2,1.5,2)`, the same external `G` forces `Uhigh/Ulow=C(1.5)/C(0.5)=41/47`, so `Uhigh≥4.778121…`. Even allowing the full `g<7/693` at the high-FBP face, inwardness permits only `Uhigh≤Lhigh+2.2gmax=3.364236…`. Thus no one common glucose concentration can guarantee invariance for every admissible cell state. The source article explicitly models cells sharing the glucose concentration in a chemostat; a per-cell feed would require isolated or otherwise individualized actuation.

For a stale F-only state, the induced equivalent flux mismatch obeys

\[
|e_{delay}|\le(1+\sup |\partial L/\partial F|)\sup|\dot F|\,\tau.
\]

On the original tube `sup|∂L/∂F|=804875/738528≈1.08983681`; the candidate full-growth vector field with total flux error at most `0.17` has `sup|Fdot|=353/900≈0.39222222`. Their product is `544821259/664675200≈0.81968044` per minute of delay, giving `τ≤0.2073979 min=12.4438739 s` if this entire error budget is available to F staleness. This is a conditional sufficient bound, closed by a first-exit argument while the trajectory/history remain in the tube. On `S+`, recomputing the derivative bound gives `12.4621164 s`. Any other flux-estimation, genotype, glucose-inversion, transport, or actuation error consumes the same `0.17` budget, reducing the allowed delay proportionally. This calculation assumes ATP/Pi are current and feed actuation is instantaneous; it supplies no actual sensor bandwidth or feed-response evidence.

## Genotype and failure-model boundaries

The new C4 candidate is for the CellML **reference genotype** `(10,10,10,0.3)`, where the source cost formula returns `vatpe=5` exactly. The PLOS Table 2 IC genotype is instead `(10.92211,5.65143,4.82003,2.07099)`. Substitution into the same CellML fourth-power formula gives `vatpe=2.634820764… mM/min`, matching the paper's rounded `2.63`; its net-profit threshold is `A≥vatpe/katp≈0.54663991`, not `0.5`. The full-growth face numbers and `S+` health proof above must not be transferred to that genotype without redoing the facets and controller calibration.

There are two source starts to keep separate. The 2014 *Science* generalized core model's Figure 4 says its balanced and imbalanced panels differ only in initial `Pi=10.4` versus `9.4 mM`; it is a three-metabolite core ODE without the later `H` or volume state ([van Heerden et al. (2014)](https://doi.org/10.1126/science.1245114)). Mapping the latter panel's other coordinates to `F=2,A=1` gives `(2,1,9.4)`, but applying the 2021 growth certificate to it is a model transfer, not a proof about the 2014 ODE.

The actual expanded 2021 CellML initializes `GLC=2,F=2,A=1,Pi=10.4,V=3.35×10⁻¹⁵ L,H=Hmax=1` with reference genotype. Its comment says lowering initial Pi (for example to `7 mM`) produces imbalanced dynamics. Both `(2,1,9.4)` and this explicit `(2,1,7)` imbalanced-start example lie in `S+`. With feedback active at glucose onset, the zero-error inverse glucose values are `0.33233299 mM` and `0.26374589 mM`, respectively. Thus the certified experiment must apply the controlled glucose value at or before the glucose pulse; the 12.44-second calculation does not cover a transition from the source's uncontrolled `GLC=2` to the feedback command. The tube certificate also does not establish recovery if glucose was first left uncontrolled until the cell had already moved to a high-FBP/low-ATP/low-Pi collapsed state; those states are outside the tube. The synthetic no-growth `G=0` depletion experiment in other C4 diagnostics is not full-growth live-cell rescue evidence.

## Evidence and next gate

The exact source-model result is now reproducible with:

```sh
python3 work/agents/c5_glycolysis_control_hostile/FULL_GROWTH_AUDIT.py
```

The decisive next test is not a larger simulation. It is an actuator-level feasibility check in the actual population geometry: either show individualized external glucose control, or replace the target with a common-feed policy and re-prove its population-level invariant set. Then measure the strain-specific `kp`, vacuolar-store law, per-cell `F/A/P` errors, and total delay/error budget against constrained MPC using the same information and actuator. Until that gate passes, retain this as a conditional source-model certificate and a no-go for a universal shared-glucose tube controller.
