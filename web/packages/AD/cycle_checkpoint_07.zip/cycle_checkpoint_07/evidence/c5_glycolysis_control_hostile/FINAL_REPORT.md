# Hostile application audit: feedback control of glycolytic startup

## Verdict

The original candidate has a valid, nontrivial **conditional invariant-tube certificate for the reduced three-metabolite source model**. A follow-on independent audit now also verifies a full-growth reference-genotype tube, with a tighter ATP/profit floor for health safety. Both are mathematical and model-scoped: neither shows that living yeast can implement the law, and neither establishes novelty or priority.

The 2014 Figure 4 comparison changes only Pi from 10.4 to 9.4 mM in its generalized three-metabolite core model. Mapping the later source's default FBP/ATP values gives `(2,1,9.4)`, but this is not the expanded CellML model. The full-growth source CellML instead defaults to `(F,A,Pi)=(2,1,10.4)` and comments that Pi=7 mM yields imbalanced dynamics; both starts lie in the audited full-growth tube when the feedback glucose value is applied at onset. The full source-model scope and the distinction between startup control and post-collapse recovery are documented in [FULL_GROWTH_AUDIT.md](FULL_GROWTH_AUDIT.md).

## Reconstructed equations and result

The 2021 source CellML gives `ADP=5-ATP`, `vATP=10 ATP`, a saturating glucose- and ATP-dependent upper flux, a three-substrate lower flux, and `Pi_vac=10/[1+((Pi+2 FBP+ATP)/250)^4]`. Setting its cell-volume growth rate to zero leaves

`Fdot=U-L`, `Adot=-2U+4L-10A`, and `Pdot=-2L+10A+kp(Pv-P)`.

With `U=L-(F-2)+e`, `|e|<=.18`, the exact six-face test gives inward margins: FBP faces `±.02`; ATP faces `+.43643` and `-2.71581`; Pi floor `+1.91215`; and `A+P=14` ceiling `-.24`, all in mM/min. A separate exact-rational calculation proves glucose inversion stays below the source uptake saturation at every state. The full expressions, proof, and reproducible calculator are in [model_and_proof.md](exactaudit/model_and_proof.md), [certificate.py](exactaudit/certificate.py), and [certificate_output.txt](calcs/certificate_output.txt).

The vacuolar-store condition follows comfortably from the source's chosen `Kvac=250`: on the whole tube `Ptot<=18.4`, so `Pv>=9.9997066 mM`. Because the source calls Kvac poorly known, the result remains conditional on that empirical relation; `Kvac>=38.42 mM` suffices to keep `Pv>=9.5` on the full tube. For the Pi-floor face alone the required vacuolar Pi is only about 4.72 mM. The active phosphate requirement is instead the `A+P` ceiling: `kp>=.304 min^-1` is sufficient under the stated error and `Pv<=10`; the source reference `kp=.3` has an outward derivative near `+.01`, while the proposed `.4` gives `-.24`.

A single fixed glucose level cannot preserve the whole polytope. The low-FBP face requires uptake at least 5.493 mM/min at one corner, while the high-FBP face permits at most 2.228 at another. The ATP dependence in the uptake law makes these demands incompatible for any fixed glucose concentration.

## Hostile gates

The command is a desired upper **flux**. The proof assumes that actual upper flux tracks `L-(F-2)+e`; it does not prove that an extracellular glucose feed realizes that flux. A physical controller must estimate FBP and lower flux (or estimate FBP, ATP, Pi and calibrated kinetics), invert the glucose response, and include actuator and delay error in `e`. The full composite flux error must stay within 0.18 mM/min, leaving only 0.02 at the FBP faces. If that 0.18 already accounts for biological/process disturbance, a stale-FBP contribution gets only the remaining 0.02; the rough bound from the model's maximum `|Fdot|` then requires sensing-to-actuation latency under about 3.2 seconds. This is a derived target, not a measured capability.

The full-growth follow-on audit uses `U=L-(F-2)+e`, `|e|<=0.17`, the source reference genotype, and `kp=.3`. It certifies `1.8<=F<=2.2`, `0.5<=A<=1.5`, `Pi>=2`, `A+Pi<=14`; the exact margins and independent verifier are in [FULL_GROWTH_AUDIT.md](FULL_GROWTH_AUDIT.md), [FULL_GROWTH_AUDIT.py](FULL_GROWTH_AUDIT.py), and [FULL_GROWTH_AUDIT.json](FULL_GROWTH_AUDIT.json). This tighter ATP floor ensures `vatpg=10A-5>=0`, so source health cannot decrease from any `H>0`. The earlier `A>=.3` tube remains a metabolic-invariance result only: it allows health decline and sufficiently small positive H can reach the source death boundary. The source `kp=.3` sits just 1.33% above the sum-face boundary, and no strain-level uncertainty interval for it or `Kvac` is supplied. The algebraic vacuolar store, heterogeneous enzyme levels, omitted branches such as trehalose cycling/glycerol and redox coupling, and a scalar `kp` without a validated one-gene mapping still limit translation.

The same follow-on verifier proves no single shared glucose concentration can preserve the full-growth tube for all admissible cell states. Its `12.44 s` delay inequality is only for FBP measurement staleness with ATP/Pi current and an otherwise exact instantaneous flux inverse and actuator; it does not include shared-culture feed dynamics. These two gates prevent an application claim in the source's population-feed setting.

Published sensors cover pieces of the loop: a yeast CggR FBP/flux sensor reports via fluorescent-protein production rates; yAT1.03 provides pH-robust single-cell ATP traces during startup; vacuolar phosphate studies use 31P-NMR; and a related FBP-responsive glycolysis-control system has been used in *E. coli*. None of the cited work demonstrates the required fast, calibrated per-cell FBP/ATP/Pi/lower-flux vector plus glucose actuation with the stated total-error bound. These boundaries and primary references are recorded in [implementation_and_prior_art.md](calcs/implementation_and_prior_art.md).

The strongest fair comparison is constrained model-predictive control using the same state estimator, glucose actuator, strain-specific parameters, and same `kp` intervention, with actuator delay and growth included. Add fixed glucose and `U=L` flux matching as interpretable controls. Outcomes should include the low-ATP/viability fraction, peak FBP, ATP recovery time, growth, and glucose consumption. Compare against published natural mechanisms too: the source literature already models ATP feedback, trehalose/T6P regulation, and phosphate mobilization as ways to suppress imbalance. Direct flux matching plus proportional FBP feedback is recognizable control design; this audit makes no originality claim.

## Worker files and evidence scope

The requested C4 folder contained source files and exploratory scripts but no `FINAL_REPORT.md` or `CLAIMS.json`. This independent audit and follow-on recertification are under `work/agents/c5_glycolysis_control_hostile/`. The exact source-model calculations are reproducible; nothing here upgrades them to nature or full-cell validation. The claim ledger separates the reduced theorem, full-growth theorem, health counterexample, shared-feed no-go, source-start mapping, and still-unknown implementation gate.
