# Measurement, actuation, and prior-art attack

## Required physical interface

The theorem assumes actual upper flux obeys `U=L(F,A,P)-(F-2)+e`. If a controller computes `Lhat` and `Fhat`, and the actuator realizes its requested upper flux with error `delta_u`, then

`e_total = e_disturbance + (Lhat-L) - (Fhat-F) + delta_u`

for `K=1 min^-1`. The admissible quantity is the total signed flux mismatch, not just an external disturbance. The mathematical tube remains invariant for `|e_total|<=0.2`; the proposed `0.18` leaves only `0.02 mM/min` of extra margin at the FBP faces. A controller error budget therefore has to include metabolite measurement, flux-model fitting, external glucose realization, genotype heterogeneity, and delay. At the source failure point, an absolute lower-flux error of 0.18 is only about 3.4% of `L`.

A pure stale-FBP error contributes approximately `K |F(t)-F(t-tau)|` to this budget. Since `|Fdot|<=0.38 mM/min` under the stated interface, a crude bound is `0.38 tau`. If ±0.18 is already consumed by other disturbances and only the remaining 0.02 is left, this crude sufficient bound requires `tau<=0.0526 min`, about 3.2 s. If every error including delay is inside the total ±0.18 budget, the corresponding allowance is about 28 s. These are interface requirements, not verified sensor or microfluidic performance.

`L` can be model-estimated from F, ATP, Pi and a calibrated `Vmaxlo`, or measured from flux. It cannot be considered known for free. The underlying paper allows genotypes and enzyme levels to differ, so a strain-specific `Vmaxlo` or independent flux estimate is needed. `Vmaxup` and the ATP-dependent saturation curve must also be acquired to invert external glucose to the desired flux.

## What published tools establish

- Monteiro et al. developed a CggR-based transcriptional FBP/glycolytic-flux biosensor in living yeast with single-cell microscopy and flow cytometry (Molecular Systems Biology 2019, https://doi.org/10.15252/msb.20199071). Their momentary proxy uses YFP/mCherry production rates; it is not a direct fast concentration sensor with the required calibrated error bound.
- Van Heerden et al. developed the pH-robust yAT1.03 FRET ATP sensor for single yeast cells and directly observed heterogeneous startup, including a small low-ATP group. In their ethanol-to-glucose transition, most cells recovered in roughly 8–12 minutes, while a small group recovered slowly or not during the observation window (ACS Sensors 2020, https://doi.org/10.1021/acssensors.9b02475). This demonstrates ATP sensing, but does not establish the full `A in [0.3,1.5]` absolute calibration and error budget needed by this controller.
- In vivo yeast 31P-NMR distinguishes cytosolic and vacuolar phosphate pools and reports phosphate mobilization during starvation (e.g. https://pubmed.ncbi.nlm.nih.gov/9032964/). It supplies population-level evidence, not a demonstrated fast intracellular Pi sensor for per-cell feedback.
- A 2021 bifunctional FBP/Cra sensor dynamically adjusted glycolysis-associated regulation in *E. coli* and improved production (https://doi.org/10.1016/j.ymben.2021.09.011). This is close prior art for metabolite-sensing flux control, though it regulates expression in a different organism and application.
- Yeast OptoINVRT7 expression control was reported with induction after about 0.6 h (36 min) after a light-to-dark switch (https://pmc.ncbi.nlm.nih.gov/articles/PMC10399620/). This expression actuator is slow compared with the minute-scale startup transients; it is not the candidate’s glucose-feed actuator.

The source paper already discusses endogenous ATP inhibition of upper glycolysis, trehalose futile cycling/T6P feedback, and increased ATPase, glycerol or vacuolar phosphate mobilization as routes that reduce imbalance. Earlier mathematical analysis proves a bifurcation/startup threshold in a more detailed glycolysis model (van Heerden et al., Mathematical Biosciences 2018, https://doi.org/10.1016/j.mbs.2018.03.007). A direct matching-plus-proportional FBP term is recognizably feedback linearization; no novelty or priority claim follows from the new boundary calculation.

## Strongest equally informed baseline

Use the same real-time state estimator, glucose actuator, calibrated pathway parameters, and identical `kp` perturbation for both controllers. Compare (1) constrained robust model-predictive control on the full source model, including growth dilution and actuator lag, against (2) the fixed-gain cancellation law. Also include the source-native fixed-glucose case and the equally informed `U=L` flux-matching control (`K=0`) as interpretable controls. The comparison must score viability/low-ATP fraction, maximum FBP, time to ATP recovery, growth, and glucose consumption. A result against fixed glucose alone would not establish a controller-specific advantage.

## Acquisition and falsification gate

First calibrate `Vmaxup`, `Vmaxlo`, `Km` terms, k_p, and `Kvac` in the specific strain and growth condition; `Kvac` and the algebraic vacuolar-storage law are explicit source uncertainties. Raise effective phosphate exchange from source reference 0.3 to at least 0.4 min^-1, then measure rather than infer its achieved value and ATP cost. Pair a fast ATP reporter with an FBP-state/flux measurement and Pi assay; identify closed-loop sensor, software, and glucose-feed latency. Estimate the composite `e_total` independently during held-out glucose step transitions. Fail the application gate if `|e_total|>0.18`, if any measured facet normal points outward, if the controller saturates at a glucose command, or if it does not rescue the 9.4-mM-Pi failure-start cohort against the equally informed MPC baseline.
