# Source parameter and initial-state audit

## Source

Janulevicius & van Doorn, “Selection for rapid uptake of scarce or fluctuating resource explains vulnerability of glycolysis to imbalance,” PLOS Computational Biology 17 (2021), e1008547, https://doi.org/10.1371/journal.pcbi.1008547. Local full paper: `work/agents/c4_rational_applications/sources/plos_2021.xml`; model: `work/agents/c4_rational_applications/sources/plos_2021_S1_Model.cellml`.

| Parameter | Source value | Units |
|---|---:|---|
| `Vmaxup` | 10 | mM/min |
| `Kmglc` | 0.1 | mM |
| `Kmatp` | 0.1 | mM |
| `Kiatp` | 3 | mM |
| `atot` | 5 | mM |
| `Vmaxlo` | 10 | mM/min |
| `Kmfbp` | 1 | mM |
| `Kmadp` | 0.1 | mM |
| `Kmp` | 2 | mM |
| `katp` | 10 | min^-1 |
| reference `kp` | 0.3 | min^-1 |
| `Pivacmax` | 10 | mM |
| `Kvac` | 250 | mM |
| `m` | 4 | -- |

The same paper labels `Kvac` “not well known” and says it was chosen to limit FBP to a few hundred mM. Its CellML comment says reducing initial Pi (e.g. to 7 mM) gives imbalanced dynamics. Table 1 gives default initial `(F,A,P)=(2,1,10.4)`. The earlier van Heerden et al. Science 2014 core-model Figure 4 reports that its viable and imbalanced simulations differ only in initial Pi, 10.4 versus 9.4 mM. Combining that with the later paper’s unchanged FBP/ATP starting values yields the actual cited failure start `(2,1,9.4)` used in this audit. It lies inside the proposed `S`; this is why the conditional certificate directly covers the named failure start.

The base `kp` is 0.3, below the sufficient 0.304 threshold from the `A+P` face; the requested 0.4 change is +33.3% relative to reference. Source treats `kp` as a genotype parameter, not as a validated single-gene intervention. Under the source’s fourth-power enzyme-expression cost formula, changing only `kp` from 0.3 to 0.4 changes the modeled expression ATP flux from 5 to approximately 5.00000292 mM/min; the source model therefore assigns nearly zero cost to this small transport rate next to the 10 mM/min pathway capacities. That is a model cost, not a measured transporter-expression or resource cost.

## Claim-bearing source pointers

- CellML initialization: lines 28–30; reference and pathway parameters: lines 43–58.
- `Ptot`, algebraic vacuolar store, and Pi transport: lines 170–219.
- ATPase and growth/demand construction: lines 223–402.
- No-growth metabolite balances (growth dilution is explicit in the last term): lines 403–578.
- PLOS Table 1 parameter and initial-state annotations: `plos_2021.xml` around Table 1 rows with `Kmglc`, `Kvac`, `[FBP]0`, `[ATP]0`, `[Pi]0`.
- Earlier startup failure states: van Heerden et al., Science 343 (2014), doi:10.1126/science.1245114, especially Figure 4 and its accompanying text (the two core-model panels differ only in initial Pi, 10.4 vs 9.4 mM).
