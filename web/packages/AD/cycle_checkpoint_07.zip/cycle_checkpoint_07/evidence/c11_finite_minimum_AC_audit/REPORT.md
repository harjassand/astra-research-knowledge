# Independent API audit: finite affine-minimum Carathéodory bridge

## Verdict

**PASS for the requested finite-minimum bridge contract.** Static review finds that the c10 module proves the intended chain from vector-valued interval absolute continuity to scalar affine branches and their finite minimum, obtains the common a.e. differentiability set from AC, identifies the derivative of every weakly active tied branch, and transfers a common active-branch drift lower bound to the minimum. Its public AE APIs do not assume pointwise differentiability. This verdict audits the recorded source and artifacts; I did not run Lean, Lake, or a build.

## Contract check

- **Vector AC to coordinate/branch/minimum AC.** `coord_absolutelyContinuous` composes the supplied vector path with each 1-Lipschitz coordinate projection (source lines 159–167). Finite sums, scalar multiplication, and a fixed additive offset establish branch AC (147–157). The proof establishes absolute-value AC and expresses binary minimum using `min f g = (f + g - |f-g|)/2` (59–107), then uses nonempty finite-set induction for the exact `Finset.inf'` finite minimum (109–132). The public theorem takes only `hx : AbsolutelyContinuousOnInterval x a b` and fixed `coeff`, `offset` (185–202).
- **A.e. finite intersection and path differentiability.** The common-differentiability theorem derives AE differentiability of the minimum, each coordinate, and each branch using `AbsolutelyContinuousOnInterval.ae_differentiableAt`; it intersects the finite-index families with `ae_all_iff` and reconstructs vector differentiability with `differentiableAt_pi` (243–280). There is no pointwise differentiability input to either this theorem or `affineMinimumAlong_ae_active_derivative_eq` (285–300).
- **All weak active ties.** The pointwise identity uses the parent finite-minimum theorem for any supplied `i` satisfying branch-value equality (218–241). The AE identity retains `∀ i` followed by the weak-active equality implication (285–300), so every tied minimizer is covered. The drift theorem also assumes its lower bound for every active index; only after intersecting the two AE sets does it use finite attainment to select an active branch at each time (302–325).
- **N33 specialization.** In OA149, for any fixed admissible scale `h`, the lower-envelope branch is `L_{λ,h}(x)=r_λ·x+b_λ(h)` and the finite family is fixed (OA149 `trapping.tex`, lines 38–47). Instantiate `coeff λ j = r_{λ,j}` and `offset λ = b_λ(h)`; the offset is constant in trajectory time. Along an AC state trajectory, the branch derivative is `r_λ·x'(t)`. Thus the drift premise can be supplied by the N33 active-flux bound for all weakly active labels. The source gives nonnegative drift for all active labels and a uniform positive bound for active labels off the plateau (lines 145–161); c10 transfers either such bound to the derivative of the envelope. This is the a.e./AC route needed for the parent’s scalar monotonicity and finite-entry composition. It does not prove the active-flux estimate, the ODE/Carathéodory trajectory itself, or the later plateau/box conclusions.
- **Endpoints and dimensions.** There is no `a ≤ b` or strict-endpoint premise; all conclusions are stated on `uIcc a b`, so the interval is unordered. `m : ℕ` has no positivity constraint and includes `m = 0`; the branch family, in contrast, must be finite and nonempty via `[Fintype ι] [Nonempty ι]`, as required for a finite minimum. At `m = 0`, the coordinate/sum parts are vacuous and branches are fixed offsets.
- **Fixed data and path representation.** `coeff : ι → Fin m → ℝ` and `offset : ι → ℝ` are explicit parameters independent of time (171–181); this matches N33 after fixing `h`. The function has type `x : ℝ → Fin m → ℝ` but AC is required only on the interval, allowing an interval trajectory to be represented by any extension outside it. A time-varying scale or offset would require a different derivative formula and is not covered.
- **AE measure/filter.** The recorded `#check` output in `axiom-audit.log` prints each public AE result as `∀ᵐ (t : ℝ), t ∈ Set.uIcc a b → ...`, with no extra arbitrary-filter or measure parameter. In this bare `∀ᵐ` notation the measure is the default Lebesgue volume measure on `ℝ`; the interval-membership implication localizes the conclusion. No accidental `atTop`, `nhds`, or user-supplied measure binder appears in the public contract.

## Recorded verification, not replayed

The c10 `REPORT.md`, `CLAIMS.json`, `compile.log`, `axiom-audit.log`, and `verify.sh` record a Lean 4.28.0 compile against the existing cache and a passing audit. `compile.log` is recorded empty. The axiom log lists `[propext, Classical.choice, Quot.sound]` for each of the five public theorems and contains no `sorryAx`; the script’s PASS line is recorded in the report. I inspected these artifacts but did not freshly compile or rerun the audit, consistent with the read-only request.

## Scope boundary

This closes only the finite affine-minimum AC/a.e. derivative transfer API contract. It is a generic scalar lower-envelope lemma, not a proof of N33 permanence. In particular, it does not itself supply the Carathéodory solution’s AC hypothesis, the reaction-system active drift premise, plateau invariance/entry, global existence, or absorption in a compact stoichiometric-class set. Those remain separate gates.

## Evidence paths

- Source reviewed: `work/agents/c10_finite_minimum_AC/FiniteMinimumCaratheodory.lean` (especially lines 19–32, 59–67, 90–132, 147–202, 204–325).
- Recorded API and axiom audit: `work/agents/c10_finite_minimum_AC/AxiomAudit.lean`, `axiom-audit.log`, `compile.log`, `verify.sh`, `REPORT.md`, `CLAIMS.json`.
- Parent finite-minimum derivative identity: `work/agents/c4_rational_hostile/formalization/dynamics/FiniteMinimum.lean`.
- N33 source match: `work/agents/permanence_hostile/OA149/affine.tex` (lines 11–26) and `trapping.tex` (lines 38–47, 145–161, 243–274).
- Related parent AC increment/plateau interface reviewed for scope only: `work/agents/c4_rational_hostile/formalization/dynamics/PlateauPrinciples.lean`.
