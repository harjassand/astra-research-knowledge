# C4: common entanglement-breaking comparator from an iterated broadcaster

## Verdict

The requested dimension-free factor-two comparator is still **UNKNOWN** in arbitrary dimension, and I found no bounded-Holevo counterexample with vanishing two-output error. I did derive a general dimension-dependent result: every unital, trace-preserving, Hilbert–Schmidt-self-adjoint self-compatible channel on (M_d) has a single canonical entanglement-breaking comparator satisfying

\[
I-\Psi\preceq 2\lceil\log_2(d^2)\rceil (I-\Phi).
\]

This establishes a direct logarithmic-dimension operator-order bound, but it does not close N93. The proof and proof boundary are below. Novelty and independent mathematical review remain unassessed.

## Interface

Let (\Phi:M_d\to M_d) be CPTP, unital and self-adjoint on the real Hilbert space of Hermitian matrices with inner product (\langle A,B\rangle_\tau=\operatorname{Tr}(AB)/d). Self-compatibility means a CPTP channel (\mathcal B:M_d\to M_d\otimes M_d) has both marginals equal to (\Phi). A common EB comparator is a full-domain measure-and-prepare CPTP map; the operator order is on the Hilbert–Schmidt space.

No positivity assumption on (\Phi) as a Hilbert–Schmidt operator is needed. Kadison Schwarz and trace preservation make a unital CPTP map an HS contraction; self-adjointness gives real spectrum in ([−1,1]). The proof assumes the broadcaster and (\Phi) are supplied as finite-dimensional channels. The Choi reference is only a mathematical representation. It does not assume any output side register or data-acquisition procedure.

## Tree measurement lemma

Symmetrize the supplied broadcaster over its two outputs if needed. Reapply it to every receiver at each level of a full binary tree of depth

\[
m=\lceil\log_2(d^2)\rceil,\qquad K=2^m.
\]

The resulting (K)-output CPTP channel has every one-receiver marginal (\Phi^m). This follows by induction: a leaf at depth (j) has marginal (\Phi^j), since the same broadcaster is applied once more and either child marginal is (\Phi).

For any Hermitian (A=\sum_y a_yP_y), measure its spectral PVM on one receiver. The induced input effects are (E_y=\Phi^m(P_y)), because (\Phi) is Hilbert–Schmidt self-adjoint. Trace preservation gives (p_y=\tau(E_y)=\tau(P_y)). Define the canonical EB map associated with an input POVM (M=(M_z)) by

\[
\Psi_M(X)=\sum_z\frac{\tau(M_zX)}{\tau(M_z)}M_z,
\]

omitting zero effects. It is CPTP, unital, entanglement-breaking, and Hilbert–Schmidt self-adjoint. Its quadratic form is the classical score (\langle A,\Psi_M(A)\rangle_\tau=\sum_z\tau(M_zA)^2/\tau(M_z)).

For the receiver's marginal POVM (E_y=\Phi^m(P_y)), self-adjointness and (A=\sum_y a_yP_y) yield

\[
\begin{aligned}
\sum_y\frac{\tau(E_yA)^2}{p_y}
-\left(2\langle A,\Phi^m(A)\rangle_\tau-\|A\|_{2,\tau}^2\right)
&=\sum_y\frac{(\tau(E_yA)-a_yp_y)^2}{p_y}\\
&\ge0.
\end{aligned}
\]

If a joint POVM on all (K) receiver systems refines this marginal measurement, its canonical score is at least the marginal score by weighted Cauchy–Schwarz. For any frame (A_1,\ldots,A_r) with (r\le d^2\), measure the spectral PVM of (A_i) on receiver (i), and measure the identity on unused receivers. The product POVM pulled back through the tree channel is one input POVM (M); its canonical EB map satisfies the score inequality for every member of the frame simultaneously.

If only an \(r\)-dimensional real test subspace is relevant, the same argument needs \(K=2^{\lceil\log_2 r\rceil}\) leaves and gives the restricted comparison constant \(2\lceil\log_2 r\rceil\). This follows by applying cone separation inside that subspace. The full channel can be treated on the traceless space of dimension \(d^2-1\), since both channels fix the identity.

## From a frame to one full-channel comparison

Write (Q\succeq0) for any positive operator on the real (d^2)-dimensional Hermitian space, and decompose it as (Q=\sum_{i=1}^r w_i|A_i\rangle\langle A_i|), where (r\le d^2), (w_i\ge0). The frame POVM above gives one (\Psi_M) with

\[
\operatorname{Tr}_{HS}Q\bigl(\Psi_M-[2\Phi^m-I]\bigr)\ge0.
\]

Kadison Schwarz and trace preservation make (\Phi) a Hilbert–Schmidt contraction, so self-adjointness gives spectrum in ([−1,1]). For (λ∈[0,1]), Bernoulli gives (λ^m≥1−m(1−λ)); for (λ<0), the inequality is equality at (m=1), and for (m≥2) its right side is at most (−1) while (λ^m≥−1). Thus (\Phi^m\succeq I-m(I-\Phi)), hence

\[
2\Phi^m-I\succeq I-2m(I-\Phi).
\]

Therefore, for every (Q\succeq0), some canonical measurement channel satisfies

\[
\operatorname{Tr}_{HS}Q\bigl(\Psi_M-[I-2m(I-\Phi)]\bigr)\ge0.
\]

The set of canonical measurement channels is convex: mix POVMs and retain the random coin in the outcome. It is compact by representing each POVM effect as \(M_z=d p_z\rho_z\), with \(\sum_zp_z\rho_z=I/d\), and taking the continuous image of the weak-* compact set of probability measures on the compact state space with that barycenter. Every such measure’s first and second moments have a finite-support representative by Carathéodory, so it gives the same channel as a finite-outcome canonical map. If no single \(\Psi\) in this compact convex set satisfied \(\Psi\succeq I-2m(I-\Phi)\), separation from the positive-semidefinite cone would give a \(Q\succeq0\) for which the displayed supremum is negative, contradicting the frame construction. Thus a single full-domain canonical EB map satisfies

\[
I-\Psi\preceq 2m(I-\Phi),\qquad m=\lceil\log_2(d^2)\rceil.
\]

The separation step is essential: separate measurements for separate frame elements do not suffice. Here the whole tree POVM handles one finite frame at once, and compact-convex separation turns the resulting all-frame support inequalities into one universal comparator.

## Consequence for likelihood families and charged costs

For bounded tracial likelihoods (\rho_H=(I+H)/d), (\|H\|_\infty\le\theta<1), define (r=\sup_H\|\Phi(H)-H\|_{1,\tau}). Then

\[
\langle H,(I-\Phi)H\rangle_\tau\le\theta r.
\]

Canonical (\Psi) is a positive Hilbert–Schmidt contraction, so ((I-\Psi)^2\preceq I-\Psi). Combining this with the comparator and normalized Schatten monotonicity gives

\[
\sup_H\frac12\|\Psi(\rho_H)-\rho_H\|_{1}
\le\frac12\sqrt{2m\theta r}.
\]

Here \(\rho_H=(I+H)/d\) implies \(\|\Psi(\rho_H)-\rho_H\|_1=\|\Psi(H)-H\|_{1,\tau}\); there is no extra factor of \(d\). Thus \(r\log d\to0\) is a sufficient dimension-dependent condition for uniform EB reconstruction. This does not imply the target from bounded Holevo information alone, since it supplies no control of \(r\log d\).

The explicit tree uses (K-1<2d^2) invocations of the supplied broadcaster and (K=2^m<2d^2) receiver systems for (d\ge2). The raw joint POVM may have (d^K) outcomes. Carathéodory yields a finite-outcome comparator, but this proof does not give a polynomial-time way to find it or a hardware implementation. All channel operations and measurement precision are assumed exact in the mathematical interface.

## Weighted variable-depth extension

The full-level tree assigns one receiver to every frame element and pays the maximum depth. A variable-depth prefix tree replaces this by an average depth. The full derivation and assumptions are in [WEIGHTED_TREE.md](WEIGHTED_TREE.md). Its result is one canonical EB comparator satisfying on the traceless Hilbert–Schmidt space

\[
I-\Psi\preceq 2G\left[I+\log_2\left(\frac{\operatorname{Tr}_{HS}G}{G}\right)\right],\qquad G=I-\Phi,
\]

with \(g[1+\log_2(T/g)]=0\) at \(g=0\), \(T=\operatorname{Tr}_{HS,\mathcal H_0}G\). This is an operator-valued spectral profile rather than a dimension-free bound; for a flat nonzero spectrum it still has logarithmic rank loss. More generally, any full-rank reference density \(\omega\) on the traceless space gives \(I-\Psi\preceq2G+2G^{1/2}(-\log_2\omega)G^{1/2}\). For a fixed dual frame the relevant cost is its energy-weighted entropy. Prefix coding cannot beat this entropy lower bound: Kraft’s inequality forces average leaf depth at least the Shannon entropy of the normalized frame-energy weights. This extension replaces the crude maximum-depth charge by a spectral-reference cost that can redistribute loss across anisotropic modes; it does not uniformly dominate the equal-depth bound. Removing log dimension requires reusing one receiver measurement across directions or exploiting extra channel structure.

## Remaining gate and falsifiers

The dimension-free target remains one of:

1. replace the (d^2)-receiver frame assignment with a single measurement whose Dirichlet loss is bounded by a universal multiple independent of frame rank; or
2. exhibit a self-compatible (\Phi_d) and positive dual frame (Q_d) such that the support function of every EB map is below (\operatorname{Tr}Q_d(2\Phi_d-I)), or produce a bounded-Holevo state family with vanishing broadcast error and EB error bounded below.

A failure of the sharp (c=2) conjecture would not by itself refute all finite dimension-free constants, and failure of this canonical measurement subclass would not rule out a general EB comparator.

## Evidence status and prior-art boundary

Prior records already establish (c=2) for qubits, prime-dimensional Weyl line-constant channels, supplied POVM/Lüders channels, and supplied instrument channels after the stated Petz correction; the dimension-five Weyl line-cover bound fails but that example has a rational-weight EB repair. See `outputs/research/cycle_checkpoint_02/evidence/quantum_physics/broadcast_lift/REPORT.md` and `D5_AUDIT.md`. The adjacent incompatibility-breaking literature treats channels whose pulled-back measurement families are compatible; Heinosaari–Kiukas–Reitzner–Schultz distinguish finite-wise from all-family breaking, and the October 2026 Chitambar–Zhang preprint gives a qubit dichotomic characterization. These notions do not supply the requested all-dimensional EB Loewner comparator: [2015 primary paper](https://arxiv.org/abs/1504.05768), [2026 preprint](https://arxiv.org/abs/2610.06642).

The bounded-Holevo finite-family theorem in `outputs/research/cycle_checkpoint_02/evidence/broadcast_information_attack/CYCLE2_REPORT.md` has an (N\sqrt{C/K}) loss. The N93 detailed-balance report provides the all-frame joint-variance dual and records a dimension-dependent finite-copy route through standard de Finetti estimates. This branch's tree construction is an internal derivation; no external theorem review or novelty clearance has occurred. No large numerical search was run.
