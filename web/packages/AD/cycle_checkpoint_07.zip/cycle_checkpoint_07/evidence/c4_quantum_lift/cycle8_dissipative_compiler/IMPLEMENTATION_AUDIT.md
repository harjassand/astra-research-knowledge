# Cycle 8: dissipative lift implementation and bit-cost audit

## Verdict

For a bistochastic channel Lambda with an explicit finite Kraus list L_1,...,L_q, the lift

\[
\mathcal B'=(\Lambda^*\otimes\Lambda^*)\circ\mathcal B_0\circ\Lambda,
\qquad
\Phi'=\Lambda^*\circ\Phi_0\circ\Lambda
\]
is a valid symmetric broadcaster even when Lambda is not Hilbert--Schmidt self-adjoint. The adjoint channel is explicit: its Kraus operators are L_i^dagger. A raw Kraus list for one B' call has at most r_0 q^3 terms if B_0 is given by r_0 weighted Kraus operators. The naive Kraus list for the full K-leaf tree has (r_0 q^3)^(K-1) indexed terms, and its product-POVM has d^K outcomes; neither should be materialized.

The individual pulled-back outcome effects remain d-by-d and have an exact staged recursion. The correlated sampler also forms a d^2-by-d^2 joint output state at an active broadcaster node; a depth-first implementation stores only polynomially many such matrices (O(log K) on the recursion stack), not the d^K-dimensional full tree state. With rational finite-bit Kraus or Liouville data, the effects, probabilities, and normalized preparations have polynomial bit length for the balanced K=O(d^2) tree; full-support noisy leaf POVMs give an explicit positive lower bound on every sample probability. A small rational qubit replay passes all direct/staged checks and deliberately fails if Lambda is substituted for Lambda*.

There is a simpler implementation when a canonical comparator Psi_0 for Phi_0 is already known: Psi'=Lambda* Psi_0 Lambda is itself canonical EB, preserves the same number of outcomes, and inherits the factor-2 comparison. This bypasses the generic tree sampler entirely. The unresolved boundary is a circuit-only description of Lambda without explicit Kraus operators or a supplied implementation of Lambda*: there is no cost-free instruction to reverse the dissipative circuit. The dense compiler is polynomial in d and the dense input bit length, not in the number of qubits when d=2^n.

## Algebra and exact instrument formulas

Take Lambda(X)=sum_i L_i X L_i^dagger, with
\[
\sum_iL_i^\dagger L_i=I,\qquad \sum_iL_iL_i^\dagger=I.
\]
Then Lambda* is CPTP and unital with Kraus list L_i^dagger. If B_0 has Kraus A_a, then
\[
\mathcal B'(X)=\sum_{a,i,j,k} w_a
K_{aijk}XK_{aijk}^\dagger,\qquad
K_{aijk}=(L_j^\dagger\otimes L_k^\dagger)A_aL_i,
\]
where a weighted base term w_a A_a X A_a^dagger is kept with its rational weight w_a. Thus the raw indexed count is r_0 q^3; exact cancellations or a smaller Choi rank may reduce it, but the implementation should not rely on such compression.

Postprocessing both outputs by the same Lambda* commutes with their swap, so B' is symmetric. Since Lambda* is trace preserving,
\[
\operatorname{Tr}_2\mathcal B'(X)
=\Lambda^*\Phi_0\Lambda(X)
=\operatorname{Tr}_1\mathcal B'(X).
\]
The marginal Phi' is bistochastic. It is Hilbert--Schmidt self-adjoint whenever Phi_0 is:
\[
(\Lambda^*\Phi_0\Lambda)^*
=\Lambda^*\Phi_0^*\Lambda
=\Lambda^*\Phi_0\Lambda.
\]
No self-adjointness of Lambda is used.

For leaf effects E_L,E_R >=0, the exact Heisenberg recursion is
\[
E_{(L,R)}
=\mathcal B'^*(E_L\otimes E_R)
=\Lambda^*\!\left[
\mathcal B_0^*\bigl(\Lambda(E_L)\otimes\Lambda(E_R)\bigr)
\right].
\tag{1}
\]
Here the two occurrences of Lambda inside the brackets are Schrödinger/linear-map applications to effects; the outer map is Lambda*. This orientation follows by taking the Hilbert--Schmidt adjoint of the three-stage composition. In particular, it is not Lambda*(B_0*(Lambda*(E_L) tensor Lambda*(E_R))).

For a complete leaf label z, recurse (1) to obtain E_z. The canonical pulled-back channel is exactly
\[
\Psi_{\rm tree}(X)=\sum_z\operatorname{Tr}(E_zX)\rho_z,
\qquad \rho_z=\frac{E_z}{\operatorname{Tr}E_z}.
\tag{2}
\]
The ordinary trace-one state is E_z/Tr(E_z)=E_z/(d tau(E_z)). E_z/tau(E_z) has trace d, and must not be passed to state preparation as a density operator. Since the adjoint tree is unital, sum_z E_z=I. Equation (2) is finite and canonical, but its raw outcome count is product_v |outcomes(v)|, equal to d^K for rank-one d-outcome leaf PVMs.

## Known-comparator lift: no outcome blow-up

Suppose the supplied base comparator is canonical:
\[
\Psi_0(X)=\sum_{j=1}^J\operatorname{Tr}(M_jX)\sigma_j,
\qquad \sigma_j=M_j/\operatorname{Tr}M_j.
\]
Define Psi'=Lambda* Psi_0 Lambda. It has the same J outcomes:
\[
M'_j=\Lambda^*(M_j),\qquad
\sigma'_j=\Lambda^*(\sigma_j).
\]
Because Lambda* is TP and unital, sigma'_j=M'_j/Tr(M'_j), sum_j M'_j=I, and sum_j Tr(M'_j)sigma'_j=I. The map stays canonical EB, bistochastic, and HS-self-adjoint. The physical controller can run Lambda, then the base J-outcome instrument, then Lambda* on the prepared state; no global outcome table is needed if these components have circuits. The environment/Kraus labels used internally by Lambda* are discarded; they do not multiply the public POVM's J outcome labels.

Let K_Lambda=Lambda* Lambda <= I, which follows from the normalized-HS contraction of a unital, trace-preserving CP map. If
\[
I-Psi_0 <= c(I-Phi_0)+delta I,\qquad c>=1,
\]
then
\[
\begin{aligned}
I-Psi'
&=I-K_\Lambda+\Lambda^*(I-Psi_0)\Lambda\\
&<=I-K_\Lambda+c\Lambda^*(I-Phi_0)\Lambda+delta K_\Lambda\\
&<=c(I-Phi')+delta I,
\end{aligned}
\]
because the final slack difference is (c-1+delta)(I-K_Lambda) >=0. In particular, factor 2 and additive compiler slack delta are preserved. If Psi_0 is explicitly listed, generating the transformed effect/state list costs O(J q d^3) dense arithmetic and stores O(Jd^2) entries; its output count stays J. This is the cleanest route for a known structured base comparator.

## Finite-bit input and runtime regimes

The following distinctions are material.

| Input / output interface | Supported cost claim | Limitation |
|---|---|---|
| Rational or Gaussian-rational explicit Kraus lists for Lambda and B_0, with entries and list lengths charged in input bits | Build one raw B' Kraus list in O(r_0 q^3 d^5) arithmetic; alternatively compose exact Liouville maps. Entry bit length grows by at most the fixed number of product/sum stages, plus logarithmic summation growth. | The q^3 list is only polynomial in the explicit input because q itself is charged. |
| Dense rational Liouville/Choi matrices with d^6 entries for B_0 and d^4 entries for Lambda | Materialize B' by exact composition in polynomial dense arithmetic; then one effect/state contraction costs O(d^6) with a dense B' superoperator. A naive two-stage superoperator multiplication costs O(d^10). | Polynomial in d and dense bit length, not polynomial in n when d=2^n. |
| Explicit circuit for Lambda with discarded environment, but no Kraus list or Lambda* circuit | Can run Lambda physically; no classical exact matrix contraction follows merely from the circuit description. | A generic circuit reversal does not implement Lambda*. Direct branch enumeration can have 2^e Kraus terms for e environment qubits. The channel rank is at most d^2, but no efficient compression from an arbitrary circuit is assumed here. |
| Explicit Kraus list or separately supplied circuit for Lambda* | B' can be implemented compositionally as Lambda, then B_0, then two Lambda* calls; local gate count is C_Lambda+C_B0+2C_Lambda* per broadcaster node. | The circuit-size bound for Lambda* must be part of the interface; bistochasticity proves existence, not a cheap reverse circuit. |

For explicit Kraus data, set q=|{L_i}|, r_0=|{A_a}|. A direct staged call avoids constructing the q^3 r_0 list:

* forward B'(X): apply Lambda once, B_0 once, and Lambda* to each of the two outputs;
* adjoint effect contraction: apply Lambda to each child effect, B_0* once, then Lambda* once;
* with dense local Kraus matrices these cost O((q+r_0)d^5) arithmetic per node (a conservative bound); direct use of the expanded list costs O(q^3 r_0 d^5).

If only a Stinespring circuit (V|\psi\rangle=\sum_i L_i|\psi\rangle|i\rangle) is supplied, then Λ* has the valid Kraus list L_i^dagger, but the original forward dilation is not itself a forward circuit for that channel. One generic route is to extend V to a unitary U, prepare a maximally entangled environment/reference pair, apply U^dagger, and postselect the environment back onto its initialized subspace. The successful block is the Λ* Stinespring isometry scaled by (1/\sqrt r), with success probability (1/r) for (r) environment labels. This is an existence/overhead illustration, not a lower bound: a special circuit may have a much cheaper adjoint, and a compressed Kraus representation may be available. The compiler contract must provide Λ* or charge for its construction and execution.

For a balanced tree K=2^m<2(d^2-1), individual effects require O(K) staged contractions and each effect message is d-by-d. A recursive correlated sampler uses O(K) forward/adjoint contractions per draw, holds at most O(log K) active d^2-by-d^2 joint output matrices plus d-by-d effects/conditional states, and never constructs the d^K-dimensional full tree state. Independent sampling from the two marginals is wrong because the two child outputs are correlated. With full-support leaves F_y >= (gamma/d)I, every leaf-string effect obeys
\[
E_z >= (gamma/d)^K I,\qquad
tau(E_z) >= (gamma/d)^K.
\]
Therefore log(1/p_z)=O(K log(d/gamma)) is polynomial in d, log(1/gamma), and the precision bits. Rational Liouville/Kraus data and rational leaf effects make all p_z,E_z,rho_z exact rational/Gaussian-rational quantities. Without full-support noise, zero-probability branches need exact zero detection or certified interval handling; a division by a numerically tiny, unclassified branch is not a bit-complexity proof.

The cycle-6 sampled compiler can then be run with B' as its dense broadcaster input. Its generic bound remains polynomial in d and 1/delta (the stored analysis gives O(d^9 delta^(-4) polylog(d/eta_fail)) dense arithmetic for the cycle-6 sampler/MW route). Its final finite measure-and-prepare list has T(N+1)=poly(d,1/delta,log(1/eta_fail)) outcomes; the deployed list does not need B' calls. The offline compiler does need dense access to the transformed channel. For succinct circuits on n qubits, d=2^n, that is generally exponential in n. A product/local Lambda and product/local B_0 may admit a separate local compiler, but that is an added structure promise.

If the full tree channel itself is flattened into Kraus paths, the count is (r_0 q^3)^(K-1); its local circuit representation stores only K-1 nodes and incurs K-1 Lambda calls, K-1 B_0 calls, and 2(K-1) Lambda* calls. The direct tree POVM still has d^K labels. The sampled rational completion is an offline way to obtain a polynomial-outcome EB map from the dense descriptor; it does not make the raw tree's Kraus or outcome list small.

## Decisive exact small replay

The executable control is dissipative_lift_replay.py; its saved output is DISSIPATIVE_REPLAY.json. It uses the rational weighted-Kraus cycle-7 qubit broadcaster B_0 and
\[
U=\frac{3I+4iX}{5},\qquad
L_0=\frac35I,\qquad L_1=\frac45U.
\]
Since U is unitary and L_0,L_1 are rational Gaussian matrices, Lambda is exactly bistochastic. Its Pauli transfer matrix has a Y,Z block
\[
\begin{pmatrix}113/625&384/625\\-384/625&113/625\end{pmatrix},
\]
so it is decisively not HS-self-adjoint. The replay verifies:

* the direct 32-term weighted Kraus form of B' equals the staged map (Lambda* tensor Lambda*)B_0Lambda, and B' is TP and swap invariant;
* its two marginals equal Lambda*Phi_0Lambda, whose transfer matrix is exactly symmetric;
* replacing the output Lambda* by Lambda produces a nonsymmetric marginal, so the wrong adjoint orientation is caught;
* the transformed three-outcome base comparator has effects M'_j=Lambda*(M_j), states sigma'_j=Lambda*(sigma_j), exact canonical ratios, both bistochastic sums, and a PSD exact factor-2 slack;
* for a depth-2, four-leaf tree with rational full-support X/Y/Z/X leaf POVMs at gamma=1/10, all 16 staged pullback effects match the direct adjoint of the 32-term B' Kraus list, are PSD, sum exactly to I, and have rational probabilities. The smallest probability exceeds (1/20)^4. A deliberately wrong-star effect has a nonzero exact matrix gap.

The replay's exact factor-2 slack on the traceless Pauli block is
\[
\begin{pmatrix}
13/15&0&0\\
0&3621997/5859375&188032/1953125\\
0&188032/1953125&1790976/1953125
\end{pmatrix}.
\]
Its YZ principal determinant is 680623104/1220703125 and the full determinant is 2949366784/6103515625, both positive. In this replay, the 16-by-4 B' Liouville matrix has maximum coefficient numerator/denominator bit length 25; the 16 pulled-back effects have maximum entry bit length 65, their normalized preparations 62, and their tracial probabilities 66. The transformed three-outcome comparator entries have maximum bit length 14. The qubit replay's raw local B' Kraus count is 32. Naively expanding the three internal tree nodes would create 32^3=32768 indexed Kraus paths for just four leaves, despite the small physical circuit; the replay therefore stores local Kraus data and the tree recursion, never the expanded global list. The transformed known comparator is only three outcomes. These are different output interfaces and should not be conflated.

Run:

    python3 work/agents/c4_quantum_lift/cycle8_dissipative_compiler/dissipative_lift_replay.py

The replay is a finite exact implementation check, not a worst-case complexity experiment or a proof of efficient Lambda* synthesis from an arbitrary channel circuit.

## Claim/status boundary

1. **Established algebraically:** explicit Kraus data for bistochastic Lambda gives a CPTP symmetric B' with self-adjoint marginal Lambda*Phi_0Lambda, even for non-self-adjoint Lambda.
2. **Established implementation formulas:** Lambda* Kraus are L_i^dagger; one B' node has r_0 q^3 raw Kraus terms; exact tree effects obey (1); a full-support leaf POVM supplies a polynomial-bit rare-event bound for K=O(d^2).
3. **Established comparator transport:** any canonical factor-c comparator with c>=1 for Phi_0 transports to the same c and same additive slack for Phi'; the outcome count is unchanged.
4. **Unresolved interface claim:** a succinct circuit for Lambda alone does not, by the present argument, yield a polynomial-size circuit for Lambda* or a polynomial-time dense effect evaluator in qubit-count complexity. Charge an explicit Kraus list, a separately supplied Lambda* circuit, or an appropriate local/tensor-network representation before making such a claim.

This audit validates the algebra and the finite rational replay. It does not claim a general circuit-complexity theorem for channel adjoints, and it does not turn the generic dense compiler into a poly(n)-time algorithm for succinct n-qubit channels.
