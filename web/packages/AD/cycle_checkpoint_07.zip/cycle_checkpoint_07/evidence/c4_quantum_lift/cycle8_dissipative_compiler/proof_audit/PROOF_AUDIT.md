# Independent proof audit: bistochastic sandwich closure

## Verdict

The closure follows under the stated bistochasticity and coefficient conditions. If \(\Lambda\) is CPTP and unital, its Hilbert--Schmidt adjoint \(\Lambda^*\) is also CPTP and unital, though it need not equal \(\Lambda\). The sandwiched \(\Phi=\Lambda^*\Phi_0\Lambda\) is bistochastic, HS-self-adjoint, and self-compatible with the supplied

\[
\mathcal B=(\Lambda^*\otimes\Lambda^*)\,\mathcal B_0\,\Lambda.
\]

The sandwiched \(\Psi=\Lambda^*\Psi_0\Lambda\) is a canonical EB channel, and if \(c\ge1\),

\[
I-\Psi\preceq c(I-\Phi).
\]

No HS-self-adjointness assumption on \(\Lambda\) is needed. Dropping unitality or trace preservation can break the channel/broadcaster and canonical-map properties and can make the order fail. The threshold \(c\ge1\) is also necessary for a general closure guarantee, though not for every special \(\Lambda\).

## Channel and self-compatibility checks

All adjoints below are for the trace/HS pairing. Since \(\Lambda\) is CPTP and unital, \(\Lambda^*\) is CP, unital (from TP of \(\Lambda\)), and TP (from unitality of \(\Lambda\)). Thus all factors in \(\Phi\) are channels and preserve the identity. For self-adjointness,

\[
(\Lambda^*\Phi_0\Lambda)^*
=\Lambda^*\Phi_0^*\Lambda
=\Lambda^*\Phi_0\Lambda=\Phi,
\]

and identically \(\Psi^*=\Psi\). This does not require \(\Lambda=\Lambda^*\).

The map \(\mathcal B\) is CPTP by composition. Using that \(\Lambda^*\) is TP to pass it through a partial trace,

\[
\operatorname{Tr}_2[(\Lambda^*\otimes\Lambda^*)Y]
=\Lambda^*(\operatorname{Tr}_2Y).
\]

Therefore either marginal of \(\mathcal B\) is \(\Lambda^*\Phi_0\Lambda=\Phi\). If \(\mathcal B_0\) is swap-symmetric, \(\mathcal B\) remains swap-symmetric because the same post-channel is applied to each output.

If \(\Lambda\) is not unital, this partial-trace identity changes to
\(\operatorname{Tr}_2[(\Lambda^*\otimes\Lambda^*)Y]
=\Lambda^*(\operatorname{Tr}_2[(I\otimes\Lambda(I))Y])\); the proposed marginal formula is then not generally valid. If \(\Lambda\) is unital but not TP, \(\Lambda^*\) is TP so the marginal calculation still works algebraically, but the input precomposition \(\Lambda\) is not a channel.

## Canonical POVM and trace normalization

Write the finite canonical core map as

\[
\Psi_0(X)=\sum_i\operatorname{Tr}(M_iX)\,\sigma_i,
\qquad \sum_iM_i=I,
\qquad \sigma_i=M_i/\operatorname{Tr}M_i
\]

for nonzero effects. Define \(N_i=\Lambda^*(M_i)\). CP and TP/unitality give

\[
N_i\succeq0,\quad \sum_iN_i=\Lambda^*(I)=I,\quad
\operatorname{Tr}N_i=\operatorname{Tr}(M_i\Lambda(I))=\operatorname{Tr}M_i.
\]

The prepared output becomes

\[
\Lambda^*(\sigma_i)=\frac{\Lambda^*(M_i)}{\operatorname{Tr}M_i}
=\frac{N_i}{\operatorname{Tr}N_i},
\]

which is a density operator and is precisely the normalized effective effect. Hence

\[
\Psi(X)=\sum_i\operatorname{Tr}(N_iX)\frac{N_i}{\operatorname{Tr}N_i}
\]

is itself canonical EB. This trace equality is where unitality of \(\Lambda\) is essential; the POVM normalization \(\sum N_i=I\) uses TP of \(\Lambda\).

## Order proof and role of \(c\ge1\)

A unital CPTP map is an HS contraction even when it is not HS-self-adjoint: Kadison--Schwarz and TP imply \(\|\Lambda(X)\|_2^2\le\operatorname{Tr}\Lambda(X^*X)=\|X\|_2^2\). Thus \(K:=I-\Lambda^*\Lambda\succeq0\). On superoperator space,

\[
I-\Psi=K+\Lambda^*(I-\Psi_0)\Lambda,
\qquad
I-\Phi=K+\Lambda^*(I-\Phi_0)\Lambda.
\]

Consequently,

\[
c(I-\Phi)-(I-\Psi)
=(c-1)K+\Lambda^*\bigl(c(I-\Phi_0)-(I-\Psi_0)\bigr)\Lambda\succeq0
\]

when \(c\ge1\) and the core inequality holds. Congruence preserves positive order, so no commutation between \(\Lambda\) and the core maps is required.

## Counterexamples when assumptions are dropped

The failures below use the same valid core: \(\Phi_0=\mathcal D_{3/5}\) and canonical EB \(\Psi_0=\mathcal D_{1/5}\), where \(\mathcal D_\lambda(X)=\lambda X+(1-\lambda)\operatorname{Tr}(X)I/2\). The core \(\Phi_0\) is self-compatible: mix a universal-cloner broadcaster (marginal \(\mathcal D_{2/3}\)) with the symmetric replacer \(X\mapsto\operatorname{Tr}(X)I_4/4\), using weights \(9/10,1/10\). For \(\Psi_0\), the six-outcome Pauli POVM \(M_{j,s}=(I+s\sigma_j)/6\), \(j\in\{x,y,z\},s\in\{\pm1\}\), prepared in its normalized effects, gives the canonical depolarizer \(\mathcal D_{1/3}\). Mix it with the one-effect canonical replacer \(\mathcal D_0\), using weights \(3/5,2/5\), by scaling the six effects by \(3/5\) and adding residual effect \((2/5)I\). This is a rational/algebraic finite canonical POVM for \(\Psi_0=\mathcal D_{1/5}\). Then \(I-\Psi_0=2(I-\Phi_0)\), exactly.

* **Drop unitality of \(\Lambda\), retain CPTP.** Take amplitude damping with parameter \(0<\gamma<1\). Then \(\Lambda(I)=I+\gamma Z\), while \(\Lambda^*(Z)=\operatorname{diag}(1,2\gamma-1)\). The composed maps remain CP and HS-self-adjoint, but
  \[
  \Phi(I)=I+\tfrac35\gamma\Lambda^*(Z)\ne I,
  \qquad \Psi(I)=I+\tfrac15\gamma\Lambda^*(Z)\ne I.
  \]
  Since they are self-adjoint, they are also not TP. The algebraic \(\Phi\) therefore cannot be a CPTP marginal; moreover the partial-trace identity above fails, so the proposed \(\mathcal B\) need not have the claimed marginals. For the stated core, \(\gamma=1/2\), and its broadcaster (\(9/10\) cloner plus \(1/10\) replacer), direct evaluation gives \(\operatorname{Tr}\mathcal B(I)=11/4\ne2\), so this \(\mathcal B\) is not TP either. Canonical trace normalization fails: \(\operatorname{Tr}\Lambda^*(M_i)=\operatorname{Tr}(M_i\Lambda(I))\) need not equal \(\operatorname{Tr}M_i\), and \(\Lambda^*(\sigma_i)\) need not have trace one. The order fails too: the core slack vanishes at \(c=2\), so the sandwiched slack is \(K\); on \(I\), \(\langle I,KI\rangle_\tau=1-\|I+\gamma Z\|_{2,\tau}^2=-\gamma^2<0\).

* **Drop trace preservation, retain CP and unitality.** Take \(\Lambda\) to be the adjoint of that amplitude-damping channel. It is unital CP but not TP, and \(\Lambda^*=\mathrm{AD}_\gamma\). Then \(\Phi(I)=\Psi(I)=\Lambda^*(I)=I+\gamma Z\ne I\); the effective effects sum to \(\Lambda^*(I)\ne I\), and the precomposition \(\Lambda\) makes \(\mathcal B\) non-TP: for \(X=Z\), its output trace is \(\operatorname{Tr}\Lambda(Z)=2\gamma\ne0=\operatorname{Tr}Z\). With the same zero-slack core at \(c=2\), the sandwich slack is again \(K\). On \(H=I+Z\), \(\|H\|_{2,\tau}^2=2\) and \(\|\Lambda(H)\|_{2,\tau}^2=2+2\gamma^2\), so \(\langle H,KH\rangle_\tau=-2\gamma^2<0\).

* **Drop \(c\ge1\), retain a bistochastic \(\Lambda\).** Let \(\Phi_0=\mathcal D_{1/10}\), self-compatible by mixing the universal cloner and replacer with weights \(3/20,17/20\), and keep \(\Psi_0=\mathcal D_{1/5}\), canonical EB as above. The core condition holds with \(c=8/9<1\), since \(1-1/5=(8/9)(1-1/10)\) on every traceless mode. Take \(\Lambda=\Delta_Z\), which is bistochastic. On an X mode (also Y), \(\Phi=\Psi=0\), so \(I-\Psi\) has eigenvalue 1 while \(c(I-\Phi)\) has eigenvalue \(8/9\). The claimed conclusion is false. Algebraically, the core slack is zero and the new slack is \((c-1)(I-\Delta_Z)\), which is negative on X and Y.

These show the conditions are sufficient and cannot be dropped as a general theorem. Particular non-bistochastic \(\Lambda\) or coefficients below one can still preserve a special comparator; the counterexamples establish failure of the blanket guarantee, not failure for every individual case.
