# Cycle 8: bistochastic dissipative sandwich closure

## Result

The adjoint sandwich preserves a supplied self-compatible core and its canonical entanglement-breaking comparison under an exact, easy-to-state hypothesis: λ must be both completely positive trace preserving and unital (bistochastic). It need not be Hilbert–Schmidt self-adjoint. If

\[
I-\Psi_0\preceq c(I-\Phi_0)+\delta I
\]

on the real Hilbert space of Hermitian matrices, then the dressed maps

\[
\Phi=\Lambda^*\Phi_0\Lambda,\qquad
\Psi=\Lambda^*\Psi_0\Lambda,\qquad
\mathcal B=(\Lambda^*\otimes\Lambda^*)\mathcal B_0\Lambda
\]

obey the same comparison

\[
I-\Psi\preceq c(I-\Phi)+\delta I
\]

provided (c+\delta\ge1). Here (\mathcal B_0) is a symmetric broadcaster for (\Phi_0), and (\Psi_0) is a finite canonical EB comparator. In the exact case (\delta=0), it suffices that (c\ge1). This is a standard composition closure, not a new general theorem about compatibility or entanglement breaking. Its concrete capability is an exact dissipative-circuit wrapper for a supplied structured core; it does not compile arbitrary many-body broadcasters.

An exact (d=4) replay uses a CNOT-interacting core followed by a one-site bistochastic noise channel that is not Hilbert–Schmidt self-adjoint. It constructs the (128)-Kraus dressed broadcaster, checks its trace-preserving Kraus sum, constructs the same nine-outcome canonical EB instrument by pulled-back effects, and verifies the full (16)-mode operator slack with exact rational arithmetic and pivoted (LDL^T). Both final transfer matrices have off-diagonal entries in the core Pauli basis. The replay and all exact matrices are in [DISSIPATIVE_SANDWICH_REPLAY.json](DISSIPATIVE_SANDWICH_REPLAY.json).

## Exact closure proof

All maps in this report are Schrödinger-picture linear maps on (M_d), and (\Lambda^*) denotes the trace/HS adjoint: if (\Lambda(X)=\sum_a K_aXK_a^*\), then (\Lambda^*(X)=\sum_aK_a^*XK_a\). Assume (\Lambda) is CPTP and unital. Then (\Lambda^*) is also CPTP and unital. Thus both pre- and post-processing maps in (\Phi), (\Psi), and (\mathcal B) are channels.

For a symmetric core broadcaster, the dressed map (\mathcal B) is CPTP and remains swap-symmetric because the same (\Lambda^*) acts on both outputs. Since (\Lambda^*) is trace preserving,

\[
\operatorname{Tr}_2[(\Lambda^*\otimes\Lambda^*)(Y)]
=\Lambda^*(\operatorname{Tr}_2Y).
\]

Therefore each marginal of (\mathcal B) is (\Lambda^*\Phi_0\Lambda=\Phi). The dressed marginal is unital and trace preserving. Its HS adjoint is

\[
(\Lambda^*\Phi_0\Lambda)^*
=\Lambda^*\Phi_0^*\Lambda
=\Lambda^*\Phi_0\Lambda,
\]

so it is HS-self-adjoint even when (\Lambda^*\ne\Lambda).

For canonicality, write the core comparator as

\[
\Psi_0(X)=\sum_i\operatorname{Tr}(M_iX)\frac{M_i}{\operatorname{Tr}M_i},
\qquad \sum_iM_i=I,
\]

omitting zero effects. Set (N_i=\Lambda^*(M_i)). Complete positivity gives (N_i\succeq0); trace preservation of (\Lambda) gives \(\sum_iN_i=\Lambda^*(I)=I\); and unitality of (\Lambda) gives

\[
\operatorname{Tr}N_i=\operatorname{Tr}(M_i\Lambda(I))=\operatorname{Tr}M_i.
\]

The pulled-back preparation is exactly the normalized pulled-back effect:

\[
\Lambda^*\!\left(\frac{M_i}{\operatorname{Tr}M_i}\right)
=\frac{N_i}{\operatorname{Tr}N_i}.
\]

Consequently

\[
\Psi(X)=\sum_i\operatorname{Tr}(N_iX)\frac{N_i}{\operatorname{Tr}N_i}
\]

is again a finite canonical EB map, with the same number of outcomes. The effect sum uses TP of (\Lambda); preservation of each effect trace and normalization of each prepared state use unitality. This denominator check is necessary: EB preservation alone would not establish this stronger canonical form.

For the order comparison, restrict to traceless Hermitian operators and let (L=\Lambda|_{\mathcal H_0}). Bistochasticity makes (L) an HS contraction: Kadison–Schwarz and trace preservation give

\[
\|\Lambda(X)\|_{2,\tau}^2
\le \operatorname{Tr}\Lambda(X^*X)/d
=\|X\|_{2,\tau}^2,
\qquad P:=I-L^*L\succeq0.
\]

The lifted slack factors exactly:

\[
\begin{aligned}
c(I-\Phi)+\delta I-(I-\Psi)
&=(c+\delta-1)P\\
&\quad+L^*\bigl(c(I-\Phi_0)+\delta I-(I-\Psi_0)\bigr)L.
\end{aligned}
\tag{1}
\]

Both terms are PSD when (c+\delta\ge1). This establishes the complete Hermitian-space comparison without assuming that (\Lambda) commutes with either core map. Identity and traceless sectors do not mix because (\Lambda) is both unital and trace preserving.

## What fails outside the interface

Both parts of bistochasticity are needed for the claimed channel construction. If (\Lambda) is CPTP but nonunital, (\Lambda^*) is generally not TP: output preparations can have the wrong trace, and the partial-trace identity that supplies the asserted broadcaster marginal changes. If (\Lambda) is CP unital but non-TP, the input pre-processing is not a channel and the effective POVM effects need not sum to (I). The independent [proof audit](proof_audit/PROOF_AUDIT.md) gives explicit amplitude-damping examples for both failures, including a negative order slack.

The threshold (c+\delta\ge1) is a closure condition, not a claim that individual cases below it always fail. It cannot be dropped as a general guarantee. For qubit depolarizers (\Phi_0=\mathcal D_{1/10}), (\Psi_0=\mathcal D_{1/5}), the core order is equality with (c=8/9). Both have finite self-compatible/canonical realizations. Bistochastic Z dephasing kills an X mode, leaving final deficits (1) and (8/9), so the lifted order fails. The construction and exact core realizations are written out in the proof audit.

No condition (\Lambda=\Lambda^*) is required. Our replay deliberately uses a non-self-adjoint (\Lambda); replacing (\Lambda^*\) by (\Lambda) would be incorrect for this instance.

## Finite dissipative replay

The core is the two-qubit CNOT-dressed product of the rational one-qubit symmetric broadcaster

\[
B_1=\tfrac9{10}B_Z+\tfrac1{10}B_U,
\]

used in cycle 7. Its core EB comparator is the CNOT dressing of the product local map (\Psi_1=(14/15)\Delta_Z+(1/15)D). The core comparison is the exact factor-two certificate from [FINITE_DEPTH_DRESSED_COMPARATOR.json](../cycle7_replay/FINITE_DEPTH_DRESSED_COMPARATOR.json).

The new, genuinely dissipative dressing acts only on the first site:

\[
\Lambda=(\operatorname{Ad}_V\circ(\tfrac34\operatorname{id}+\tfrac14\operatorname{Ad}_Z))\otimes\operatorname{id},
\qquad V=\tfrac13I+\tfrac{2i}{3}X+\tfrac{2i}{3}Y.
\]

The entries of (V) are rational complex numbers and (V^*V=I) exactly. The two weighted Kraus terms are (3/4,V\otimes I) and (1/4,VZ\otimes I). The exact PTM shows (\Lambda^*\ne\Lambda); its contraction defect (I-L^*L) is PSD. The complete composed broadcaster has (2^3\cdot16=128) Kraus terms and its exact weighted (\sum K^*K) is (I_4). The two dressed marginal transfer matrices agree, the marginal is unital/TP and self-adjoint, and both the marginal and EB transfer matrices have nonzero off-diagonal entries in the core Pauli basis.

Pulling back the core effects and output states through (\Lambda^*) retains nine outcomes. The script checks each state has trace one, each state equals its effect divided by the effect trace, the effects sum to (I_4), the trace-weighted states sum to (I_4), and the instrument transfer matrix equals (L^*\Psi_0L). It then checks the exact (16\times16) slack from (1). The identity mode is the sole zero pivot; the remaining 15 rational pivots are positive. The full final slack matrix, Kraus sum, input/noise matrices, and instrument are serialized in the replay JSON.

The replay uses (d=4), two sites, one local noisy channel gate, one core CNOT, 128 expanded broadcaster Kraus terms, and nine comparator outcomes. The input channel parameters have finite exact rational-complex encodings; no floating-point approximation is used. The Python/SymPy script and resulting file are in [dissipative_sandwich_replay.py](dissipative_sandwich_replay.py) and [DISSIPATIVE_SANDWICH_REPLAY.json](DISSIPATIVE_SANDWICH_REPLAY.json).

## Succinct circuit interface and costs

The algebraic theorem permits any exact finite-dimensional bistochastic (\Lambda), but a useful many-body implementation needs more structure. Suppose the core broadcaster/comparator has a succinct representation and (\Lambda=\lambda_D\circ\cdots\circ\lambda_1) is supplied as depth-(D) local layers, each local gate bistochastic. Then

\[
\Lambda^*=\lambda_1^*\circ\cdots\circ\lambda_D^*
\]

is physically implementable by the local adjoint gates in reverse application order; each adjoint gate remains CPTP. The dressed broadcaster is implemented by (\Lambda), the core broadcaster, then (\Lambda^*) on both receivers. The EB instrument is implemented by (\Lambda), the core measure-and-prepare instrument, then (\Lambda^*) on the prepared output. For bounded-range gates on (L) sites, the wrapper uses (O(LD)) local channel operations, plus the supplied core cost. It remains valid for noise gates that are not HS-self-adjoint and for globally correlated channels generated by the local circuit.

The label count does not grow: a core comparator with (S) effects produces (S) pulled-back effects. If its core instrument is a tensor product of three-outcome instruments, the flattened outcome list still has (3^L) strings; the implementation must stay in circuit/instrument form. For an explicitly expanded Kraus representation with (q) Kraus operators for (\Lambda) and (r_0) core broadcaster Kraus operators, (\mathcal B) has at most (q^3r_0) Kraus operators. Explicitly forming all pulled effects and states costs (O(Sq d^3)) dense arithmetic for (d\times d) Kraus matrices and requires (O(Sd^2)) output entries, apart from coefficient bit growth. A local circuit may have exponentially many global Kraus paths; do not expand it. Retain its gate list and reverse adjoint circuit. If only a dense global (\Lambda) is supplied, the algebra still holds but the dimension and dense input cost return.

The exact compiler interface requires rational or otherwise exactly represented gate coefficients plus locally checkable CPTP and unitality certificates. Approximate floating-point gates can break exact trace preservation, unitality, the pulled-effect POVM sum, and the adjoint-channel property. No generic finite-precision repair/error bound is claimed here. A black-box physical channel without a supplied gate/Kraus representation likewise does not supply the exact adjoint operations needed by this compiler.

## Slow-mode consequence

The same operator-order statement gives one common EB reconstruction channel for every promised family of bounded tracial likelihoods. Let (H=H^*), \(\tau(H)=0\), \(\|H\|_\infty\le\theta<1\), \(\rho_H=(I+H)/d\), and

\[
r=\sup_H\|(I-\Phi)H\|_{1,\tau}.
\]

The canonical (\Psi) is a positive HS contraction, so ((I-\Psi)^2\preceq I-\Psi). Combining this with the order and trace duality gives

\[
\begin{aligned}
\|(I-\Psi)H\|_{2,\tau}^2
&\le\langle H,(I-\Psi)H\rangle_\tau\\
&\le c\langle H,(I-\Phi)H\rangle_\tau+\delta\|H\|_{2,\tau}^2\\
&\le c\theta r+\delta\theta^2.
\end{aligned}
\]

Since (\|X\|_{1,\tau}\le\|X\|_{2,\tau}), the ordinary physical half-trace error satisfies

\[
\sup_H\tfrac12\|\Psi(\rho_H)-\rho_H\|_1
\le\tfrac12\sqrt{c\theta r+\delta\theta^2}.
\]

There is no dimension or family-cardinality factor in this consequence once the all-mode channel inequality is supplied. Standard data processing alone does not produce this one common canonical EB channel or its Loewner comparison; it only contracts information/distances under channel composition. Conversely, the sandwich hypothesis is supplied structure, not something learned from a capacity bound. It may be useful when a many-body process is known to consist of a locally dissipative encoder, a core compatible evolution, and the matching adjoint decoder.

## Prior-art boundary and unresolved scope

The primary-source audit is in [PRIOR_ART_AUDIT.md](PRIOR_ART_AUDIT.md). Heinosaari–Miyadera, [*Quantum incompatibility breaking channels*](https://arxiv.org/abs/1608.01794), Propositions 3 and 8, already provide compatibility closure under channel processing. Horodecki–Shor–Ruskai, [*General Entanglement Breaking Channels*](https://arxiv.org/abs/quant-ph/0302031), Theorem 2, gives the Holevo measure-and-prepare form and hence EB closure under pre/post-processing. The operator-order step here is the direct HS contraction of a bistochastic channel (Kadison–Schwarz), not a consequence of the coherent-information data-processing inequality. The cycle-7 product construction and qubit factor-two comparator are inherited internal results; see [cycle 7](../cycle7_replay/FINAL_REPORT.md) and [the weighted-tree record](../WEIGHTED_TREE.md). The pinned Astra task record lists the bounded-Holevo lift as open under original commit `8ede33c2f09a8abe07b430892b3ac4bb71c27c83` and selective refresh `0132f3d37f9ba3b0ab0de07779ef3e17e5768e30`; this is context, not a premise or novelty source. This report makes no priority claim for the standard closure.

The closure supplies no bound for arbitrary self-compatible channels unless they admit the stated factorization with a known core and bistochastic (\Lambda). It does not handle a supplied circuit whose individual gates are not channels/unital even if a global matrix happens to be bistochastic, unless a succinct physical implementation of the global adjoint is separately given. A local EB comparator may still carry (3^L) outcome strings when flattened, and general interacting/dissipative cores, bounded-treewidth compatibility witnesses, and capacity-only broadcasting remain open. In the task's pinned Astra record the bounded-Holevo lift remains an unresolved gate; that record is context, not a premise of this closure.
