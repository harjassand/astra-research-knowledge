# Prior-art audit: bistochastic adjoint sandwiches

## Finding

The algebraic closure needed for a “dissipative dressing” is standard. A supplied bistochastic channel λ can be wrapped around a symmetric broadcaster and a canonical measure-and-prepare comparator as

\[
\mathcal B_\lambda=(\lambda^\dagger\otimes\lambda^\dagger)\circ\mathcal B\circ\lambda,
\qquad
\Phi_\lambda=\lambda^\dagger\circ\Phi\circ\lambda,
\qquad
\Psi_\lambda=\lambda^\dagger\circ\Psi\circ\lambda,
\]

where all maps here are in the Schrödinger picture and \(\lambda^\dagger\) is the Hilbert--Schmidt adjoint. Bistochasticity makes both \(\lambda\) and \(\lambda^\dagger\) CPTP. Thus \(\mathcal B_\lambda\) is again a symmetric broadcaster with equal marginal \(\Phi_\lambda\); \(\Psi_\lambda\) remains canonical EB. If \(\Phi\) or \(\Psi\) is HS-self-adjoint, its sandwich is HS-self-adjoint as well.

This gives an immediate extension of the cycle-7 unitary-dressed product construction to a *supplied finite-depth circuit of local bistochastic channels*. It is a standard closure corollary, not a new general compatibility theorem or a compiler for arbitrary dissipative many-body dynamics. Its practical value is a succinct circuit wrapper when that circuit is part of the input. The bounded search below does not establish priority for the wrapper.

## Primary-source statements checked

Heinosaari and Miyadera define compatible channels as channels that are marginals of one broadcasting channel. Their [Proposition 3](https://arxiv.org/html/1608.01794v2) states that if \(\Phi_i\preceq\Lambda_i\) in their concatenation preorder and \(\Lambda_1,\Lambda_2\) are compatible, then \(\Phi_1,\Phi_2\) are compatible. In their Heisenberg-picture convention, the proof composes the joint channel with the tensor product of the two local channels. In Schrödinger language this is closure under local output post-processing. Common input pre-processing is also immediate: precompose the joint broadcaster with that input channel. The paper states the corresponding result for any finite number of channels in Proposition 8. This exactly covers compatibility closure; using the *same* local post-channel on both outputs also preserves swap symmetry.

Horodecki, Shor, and Ruskai's [Theorem 2](https://arxiv.org/html/quant-ph/0302031v2) says an EB channel has Holevo form

\[
\mathcal E(X)=\sum_k \operatorname{Tr}(F_kX)\,\rho_k,
\]

with positive effects \(F_k\) and states \(\rho_k\); trace preservation is equivalent to \(\{F_k\}\) being a POVM. This directly gives two-sided EB closure. For channels \(\mathcal C,\mathcal D\),

\[
(\mathcal D\circ\mathcal E\circ\mathcal C)(X)
=\sum_k\operatorname{Tr}(\mathcal C^\dagger(F_k)X)\,\mathcal D(\rho_k),
\]

and \(\{\mathcal C^\dagger(F_k)\}\) is again a POVM. The output states \(\mathcal D(\rho_k)\) are again states. No new EB-preservation lemma is needed.

For the stronger canonical subclass used by the compiler, write

\[
\Psi_M(X)=\sum_i\operatorname{Tr}(M_iX)\,\frac{M_i}{\operatorname{Tr}M_i},
\qquad \sum_iM_i=I.
\]

Under the bistochastic sandwich,

\[
\Psi_\lambda(X)=\sum_i\operatorname{Tr}(M_i'X)\,\frac{M_i'}{\operatorname{Tr}M_i'},
\qquad M_i'=\lambda^\dagger(M_i).
\]

Indeed \(\sum_iM_i'=I\), and \(\operatorname{Tr}M_i'=\operatorname{Tr}M_i\), using respectively that \(\lambda\) is TP and unital. Thus this particular matching-effect/preparation form is preserved exactly, including finite outcome labels; it is a direct corollary of the Holevo representation plus bistochasticity. A generic EB map remains EB under the sandwich, but need not become self-adjoint or take this matching canonical form unless it had the corresponding property initially.

## Order comparison and data processing

There is a useful additional closure fact for the compiler's inequality. Let \(\mathsf H_0\) be traceless Hermitian matrices with the HS inner product, and let \(L=\lambda|_{\mathsf H_0}\). Bistochasticity implies \(L^*L\preceq I\): Kadison--Schwarz for the unital CP map gives \(\lambda(X)^*\lambda(X)\preceq\lambda(X^*X)\); taking traces and using trace preservation proves HS contractivity. This is the standard Schwarz inequality for unital CP maps (see Choi, [“A Schwarz inequality for positive linear maps on C*-algebras”](https://doi.org/10.1215/ijm/1256051007)).

Suppose the supplied pair obeys

\[
I-\Psi\preceq c(I-\Phi)+\delta I
\]

on \(\mathsf H_0\). Congruence by \(L\), followed by adding \(I-L^*L\succeq0\), yields

\[
I-\Psi_\lambda
\preceq I-c\Phi_\lambda+(c+\delta-1)L^*L.
\]

When \(c+\delta\ge1\), contractivity gives

\[
I-\Psi_\lambda\preceq c(I-\Phi_\lambda)+\delta I.
\]

The logarithmic compiler has \(c=2m\ge2\), and the structured cycle-7 comparator has \(c=2\), so the same coefficient and slack survive. For a unitary dressing \(L^*L=I\), this is ordinary unitary congruence. For nonunitary bistochastic dressing, the identity term is not fixed by congruence; the conclusion follows from the HS-contraction defect and requires \(c+\delta\ge1\). This proof is the relevant order argument.

Schumacher and Nielsen's [quantum data-processing inequality](https://arxiv.org/html/quant-ph/9604022v1), Section 5, concerns nonincrease of coherent information under subsequent channel dynamics. It is related in spirit to processing monotonicity, but it is not the argument above and by itself does not imply the compiler's Loewner-order comparison. The needed implication is the elementary HS contraction of a bistochastic CP map, applied to the superoperator inequality. Avoid presenting “data processing” alone as justification for this matrix-order step.

## Consequence for a structured many-body input

If the cycle-7 product broadcaster/comparator is supplied together with a depth-\(D\) circuit \(\lambda\) whose local gates are bistochastic channels, then the dressed broadcaster is implemented as \(\lambda\), the local product broadcaster, then \(\lambda^\dagger\) on each receiver. The adjoint circuit runs the local adjoint gates in reverse order; each remains CPTP because its gate was bistochastic. The comparator is implemented as \(\lambda\), the local product measure-and-prepare instrument, then \(\lambda^\dagger\). This costs \(O(LD)\) local channel operations, subject to the gate implementation costs and the supplied local-circuit representation. It can entangle and dissipate while retaining the factor-2 comparison.

The flattened comparator still has up to \(3^L\) outcome effects \(M'_z=\lambda^\dagger(M_z)\). Keep it as the circuit/instrument composition; do not claim a polynomial-size explicit dense POVM list. If \(\lambda\) is only a dense global map, the algebraic closure still holds, but it gives no \(O(LD)\) or other succinct runtime. Nor does it compile an arbitrary interacting/dissipative broadcaster: the input broadcaster must already have the product (or another certified) structure, and \(\lambda\) must be supplied in an efficient representation. If only the total \(\lambda\) is bistochastic but its given gate factors are not, the existence of a succinct physical circuit for \(\lambda^\dagger\) needs a separate representation argument.

This is therefore best stated as an **immediate bistochastic-circuit dressing corollary** to the structured product certificate. It extends the unitary-only dressing boundary in [the cycle-7 report](../cycle7_replay/FINAL_REPORT.md), but does not establish a generic many-body dissipative compiler or a new prior-art theorem.

## Search scope and limits

Targeted primary-source searches covered quantum-channel compatibility under processing, the Holevo form and EB composition, coherent-information data processing, and the Schwarz inequality for unital CP maps. I checked Heinosaari--Miyadera (2017; arXiv:1608.01794, Sections 2--3, Propositions 3 and 8), Horodecki--Shor--Ruskai (2003; arXiv:quant-ph/0302031, Theorem 2 and the equivalent characterizations), Schumacher--Nielsen (1996; arXiv:quant-ph/9604022, Section 5), and Choi (1974; DOI above). The exact sandwich, canonical-form rewrite, and order-transfer calculation here are explicit derivations from those statements. This was a bounded targeted audit, not an exhaustive search for every application or a basis for a priority claim.
