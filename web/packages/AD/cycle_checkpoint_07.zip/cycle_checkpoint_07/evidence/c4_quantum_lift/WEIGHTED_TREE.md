# Variable-depth broadcast tree and spectral-profile comparator

## Claim and boundary

Let \(\Phi:M_d\to M_d\) be unital, trace-preserving, CPTP, Hilbert--Schmidt self-adjoint, and admit a symmetric two-output CPTP broadcaster with both marginals \(\Phi\). On the real Hilbert space \(\mathcal H_0\) of traceless Hermitian matrices, put

\[
G=I-\Phi\succeq0,\qquad n=d^2-1,\qquad T=\operatorname{Tr}_{HS,\mathcal H_0}G.
\]

For \(d\ge2\), \(T>0\): if \(G\) vanished on \(\mathcal H_0\), then \(\Phi\) would be the identity channel. Its extension would output \(\lvert\psi\psi\rangle\) for every pure input \(\lvert\psi\rangle\); Stinespring inner-product preservation cannot map nonorthogonal pure inputs to these pairwise squared-overlap outputs, so no such broadcaster exists. An internally reconstructed, dimension-dependent spectral-profile comparison is

\[
I-\Psi\preceq 2G\left[I+\log_2\left(T/G\right)\right]
\quad\text{on }\mathcal H_0,
\tag{WT}
\]

for one canonical entanglement-breaking channel \(\Psi\), with the scalar function \(g[1+\log_2(T/g)]\) defined to be zero at \(g=0\). Equivalently, each eigenmode of \(G\) with gap \(g>0\) has comparator deficit at most \(2g[1+\log_2(T/g)]\). This is an alternative spectral-profile bound; it can redistribute loss across modes but does not uniformly improve the equal-depth bound. It is still not dimension-free in general: if all \(n\) nonzero gaps are equal, the right side is \(2(1+\log_2 n)G\). It neither proves the conjectured constant 2 nor resolves the bounded-Holevo lift.

## Variable-depth score bound

For any integer \(\ell\ge0\) and Hermitian \(A=\sum_y a_yP_y\), measuring this spectral PVM on one receiver of an \(\ell\)-level broadcast tree induces effects \(E_y=\Phi^\ell(P_y)\). If \(p_y=\tau(P_y)=\tau(E_y)\), the canonical measurement score obeys

\[
\sum_y\frac{\tau(E_yA)^2}{p_y}
\ge 2\langle A,\Phi^\ell(A)\rangle_\tau-\|A\|_{2,\tau}^2
\ge \|A\|_{2,\tau}^2-2\ell\langle A,GA\rangle_\tau.
\tag{1}
\]

The first inequality is the exact square-variance identity in `FINAL_REPORT.md`. The second uses \(\lambda^\ell\ge1-\ell(1-\lambda)\) for all \(\lambda\in[-1,1]\); this does not require HS-positivity of \(\Phi\).

Take any \(Q\succeq0\) on \(\mathcal H_0\) and \(\varepsilon>0\). Set \(K=G+\varepsilon I\) and \(\omega=K/\operatorname{Tr}K\), which is a full-rank density operator on \(\mathcal H_0\). Diagonalize

\[
K^{1/2}QK^{1/2}=\sum_i r_i|u_i\rangle\langle u_i|,
\qquad r_i>0,
\]

with orthonormal \(u_i\). Define \(A_i=K^{-1/2}u_i\), so

\[
Q=\sum_i r_i|A_i\rangle\langle A_i|,
\qquad \langle A_i,KA_i\rangle=1,
\qquad 0\le e_i:=\langle A_i,GA_i\rangle\le1.
\]

Let \(q_i=\langle u_i,\omega u_i\rangle>0\). Since \(\sum_iq_i\le1\), the integer lengths \(\ell_i=\lceil-\log_2q_i\rceil\) satisfy Kraft's inequality. Thus there is a binary prefix code with these leaf depths. Complete its tree with dummy leaves if needed, and implement every internal node by one invocation of the supplied broadcaster. The output at leaf \(i\) has marginal \(\Phi^{\ell_i}\). Measure the spectral PVM of \(A_i\) on leaf \(i\), and the identity on dummy leaves. Pulling back the product PVM gives one input POVM \(M_Q\). Its canonical EB map \(\Psi_{M_Q}\) refines each one-leaf marginal, so weighted Cauchy--Schwarz and (1) give

\[
\begin{aligned}
\operatorname{Tr}_{HS}Q\Psi_{M_Q}
&\ge \operatorname{Tr}_{HS}Q-2\sum_i r_i\ell_i e_i\\
&\ge \operatorname{Tr}_{HS}Q-2\sum_i r_i\ell_i.
\end{aligned}
\tag{2}
\]

To bound code cost, Jensen's inequality for the concave logarithm gives

\[
-\log_2 q_i\le \langle u_i,-\log_2\omega\,u_i\rangle.
\]

Therefore, writing \(R=K^{1/2}QK^{1/2}\),

\[
\begin{aligned}
\sum_i r_i\ell_i
&\le \operatorname{Tr}_{HS}R+
\operatorname{Tr}_{HS}\!\left(R(-\log_2\omega)\right)\\
&=\operatorname{Tr}_{HS}\!\left[QK+QK^{1/2}\log_2\left(\frac{\operatorname{Tr}_{HS}K}{K}\right)K^{1/2}\right].
\end{aligned}
\tag{3}
\]

Combining (2)--(3), every \(Q\succeq0\) has a canonical measurement map with nonnegative pairing against

\[
\Psi_{M_Q}-\left[I-2K-2K^{1/2}\log_2\left(\frac{\operatorname{Tr}_{HS}K}{K}\right)K^{1/2}\right].
\]

## One comparator by separation; singular limit

The canonical maps form a compact convex set. To see compactness exactly, write each nonzero POVM effect as \(M_z=d p_z\rho_z\), where \(p_z=\tau(M_z)\), \(\rho_z=M_z/\operatorname{Tr}M_z\), and \(\sum_zp_z\rho_z=I/d\). Their maps are

\[
\Psi(X)=d\sum_zp_z\operatorname{Tr}(\rho_zX)\rho_z.
\]

They are the continuous image of the weak-* compact set of probability measures on the compact density-matrix space with barycenter \(I/d\). Every such measure’s first and second moments can be preserved exactly by a finite-support measure via Carathéodory in finite dimension, giving the same map from a finite POVM. Convexity follows by retaining the random coin as part of the outcome.

Positive-cone separation now implies that one canonical EB map \(\Psi_\varepsilon\) satisfies

\[
I-\Psi_\varepsilon\preceq
2K+2K^{1/2}\log_2\left(\frac{\operatorname{Tr}_{HS}K}{K}\right)K^{1/2}
=2K\left[I+\log_2\left(\frac{\operatorname{Tr}_{HS}K}{K}\right)\right].
\tag{4}
\]

The set is compact and the right side converges spectrally as \(\varepsilon\downarrow0\): for \(g>0\), it tends to \(2g[1+\log_2(T/g)]\); at \(g=0\), \((g+\varepsilon)\log_2((T+n\varepsilon)/(g+\varepsilon))\to0\). A convergent subsequence of \(\Psi_\varepsilon\) gives (WT), including zero-gap modes. Both canonical maps and \(\Phi\) fix the identity and preserve the traceless space, so the inequality on \(\mathcal H_0\) extends to the full Hermitian space with both sides zero on the identity direction.

## More general reference profile

The same construction works with any fixed full-rank density operator \(\omega\) on \(\mathcal H_0\), using lengths \(\ell_i=\lceil-\log_2\langle u_i,\omega u_i\rangle\rceil\). After the same \(K=G+\varepsilon I\) limit, it gives a single \(\Psi\) with

\[
I-\Psi\preceq 2G+2G^{1/2}(-\log_2\omega)G^{1/2}.
\tag{5}
\]

For \(\omega=I/n\), direct equal-depth coding recovers the sharper scalar bound \(2\lceil\log_2 n\rceil G\) (versus the real-valued entropy estimate's additive overhead). For \(\omega\) chosen diagonal in an eigenbasis of \(G\), (5) gives a pointwise spectral allocation: any full-support probabilities \(q_j\) produce mode cost \(2g_j[1+\log_2(1/q_j)]\). The choice \(q_j=(g_j+\varepsilon)/\operatorname{Tr}(G+\varepsilon I)\) yields (WT). This is a Pareto family of operator bounds; it does not by itself identify a dimension-free choice.

When \(G\succ0\) on \(\mathcal H_0\), there is a sharper Q-dependent support statement. For \(R=G^{1/2}QG^{1/2}\), \(E=\operatorname{Tr}_{HS}R=\operatorname{Tr}_{HS}(QG)\), and \(\sigma_R=R/E\), the eigenframe construction with source probabilities \(p_i=r_i/E\) gives

\[
\sup_{\Psi_M}\operatorname{Tr}_{HS}(Q\Psi_M)
\ge \operatorname{Tr}_{HS}Q-2E\bigl[1+S_2(\sigma_R)\bigr],
\tag{6}
\]

where \(S_2\) is von Neumann entropy in bits. Each frame vector has unit \(G\)-energy, so these coding weights are exactly the Dirichlet-energy weights. The average code depth can also be capped by the fixed equal-depth code, giving \(E\min\{\lceil\log_2 n\rceil,1+S_2(\sigma_R)\}\). This does not yet produce one common comparator with a Q-dependent right side; fixing the reference \(\omega\) is the linearization step used for (5).

There is a separate measurement-reuse improvement when the test frame can be grouped into commuting classes. Assume \(G\succ0\) and write \(Q=\sum_{j=1}^s Q_j\), where each \(Q_j\) is a sum of frame terms \(w_i|A_i\rangle\langle A_i|\) and all observables in that group commute pairwise. One joint spectral PVM on a single receiver refines every PVM in the group. Put \(E_j=\operatorname{Tr}(Q_jG)>0\), \(E=\sum_jE_j\), and \(p_j=E_j/E\). A prefix tree with one leaf per commuting group then gives one pulled-back POVM satisfying

\[
\operatorname{Tr}(Q\Psi_M)\ge \operatorname{Tr}Q-2E\sum_jp_j\ell_j,
\qquad
\sum_jp_j\ell_j\le \min\{\lceil\log_2s\rceil,1+H_2(p)\}.
\]

For \(s=1\), the joint spectral PVM can be measured directly on the input (depth zero), so the score is exactly \(\operatorname{Tr}Q\). This replaces the number of tests by the number and energy distribution of noncommuting groups. It is conditional: the general channel problem supplies no bounded commuting-cover number for every positive dual frame. The proof is the same leaf score inequality (1), summed within each commuting block before coding.

The entropy cost is unavoidable within the leaf-private prefix-tree strategy. For any prefix lengths \(\ell_i\) and normalized weights \(p_i\), Kraft gives \(Z=\sum_i2^{-\ell_i}\le1\). The normalized distribution \(q_i=2^{-\ell_i}/Z\) has cross entropy \(H_2(p,q)=\sum_i p_i(\ell_i+\log_2Z)\le\sum_i p_i\ell_i\), while \(H_2(p)\le H_2(p,q)\). Hence \(\sum_i p_i\ell_i\ge H_2(p)\). For any rank-one frame decomposition of \(R/E\), its energy weights form a pure-state ensemble of \(\sigma_R\), whose Shannon entropy is at least \(S_2(\sigma_R)\); the eigen-decomposition attains that entropy before integer-code redundancy. Thus the flat rank-r case costs at least \(\log_2 r\) mean broadcast levels under this architecture. This is a limitation of assigning one separate output leaf per test direction, not an impossibility result for a single collective measurement that reuses one receiver.

## Costs and status

The variable prefix tree has at most a finite number of internal nodes for each finite frame, but its leaf depths and raw joint POVM outcome count can be large; no polynomial-time construction is claimed. The single comparator follows existentially from separation, with no constructive optimizer or precision bound. All broadcaster calls and channels are treated as exact. The proof is internally reconstructed and has not received independent external review or novelty clearance. A hostile audit is in progress.

The new invariant is frame/spectral entropy rather than raw leaf count: when \(G\) is invertible, the frame cost is the entropy of \(G^{1/2}QG^{1/2}/\operatorname{Tr}(QG)\); with a fixed reference state, this becomes the operator-valued profile (5). In a flat spectrum the logarithmic loss remains. Removing it there requires an additional structural fact (for example, a symmetry-specific common measurement), not more efficient prefix coding alone.
