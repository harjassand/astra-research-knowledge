# Finite-sample compiler for the logarithmic EB comparator

## Result and exact boundary

The tree support argument can be turned into a randomized, finite-bit compiler for an explicit common entanglement-breaking channel. It does not enumerate the tree's exponentially many product-POVM outcomes. It samples outcomes from each dual-dependent tree using only dense contractions on \(d\times d\) messages, turns those samples into an explicit \(N+1\)-outcome POVM by a rational completion, and uses matrix multiplicative weights to combine polynomially many approximate best responses.

Let \(d\ge2\), let \(\mathcal B:M_d\to M_d\otimes M_d\) be a supplied symmetric CPTP broadcaster with both marginals \(\Phi\), and assume \(\Phi\) is unital, trace preserving, and Hilbert--Schmidt self-adjoint. Let \(\mathcal H_0\) be the real space of traceless Hermitian matrices with normalized Hilbert--Schmidt inner product \(\langle X,Y\rangle_\tau=\tau(XY)\), where \(\tau=\mathrm{Tr}/d\). Set

\[
n=d^2-1,\qquad m=\lceil\log_2 n\rceil,\qquad G=I-\Phi\quad\text{on }\mathcal H_0.
\]

For any requested slack \(0<\delta\le1\) and failure target \(0<\eta_{\mathrm{fail}}<1\), the algorithm below returns, with probability at least \(1-\eta_{\mathrm{fail}}\), one explicitly listed finite canonical EB channel \(\widehat\Psi\) such that

\[
 I-\widehat\Psi\preceq 2m(I-\Phi)+\delta I
\tag{1}
\]

on \(\mathcal H_0\), hence on all Hermitian matrices. It uses \(T(N+1)\) outcomes, where

\[
T=O\!\left(\frac{m^2\log n}{\delta^2}\right),\qquad
N=O\!\left(\frac{d}{\delta^2}\log\frac{dTn}{\eta_{\mathrm{fail}}}\right).
\tag{2}
\]

The result is randomized and approximate. The coefficient remains \(2\lceil\log_2(d^2-1)\rceil\); it does not settle the sharp dimension-free \(c=2\) conjecture or the bounded-Holevo lift without an additional effective-complexity premise.

The bit-complexity statement assumes an exact finite representation, for example a rational Liouville/Choi matrix for \(\mathcal B\), with total input bit length \(L\), together with a promise or exact check that it is CPTP and has the stated marginals. The dense broadcaster superoperator has \(d^6\) entries. An arbitrary real oracle or a device-only black box does not define this classical bit-complexity problem.

## The support response

The channel \(\Phi\) is an HS contraction, so its real eigenvalues on \(\mathcal H_0\) lie in \([-1,1]\) and \(0\preceq G\preceq2I\). Put

\[
J=I-2mG.
\]

For any density matrix \(Q\succeq0\) on \(\mathcal H_0\), factor it as \(Q=\sum_{i=1}^n |A_i\rangle\langle A_i|\), allowing zero columns. No eigenbasis of \(Q\) is needed: a Gram factorization suffices. Each nonzero \(A_i\) is a traceless Hermitian observable, not necessarily normalized; apply the normalized score bound to \(A_i/\|A_i\|_2\) and multiply back by \(\|A_i\|_2^2\). Put its spectral PVM on a different leaf of a full balanced broadcaster tree with \(K=2^m<2n\) leaves; fill unused leaves with any rank-one PVM. The tree has \(K-1=O(d^2)\) internal broadcaster nodes.

For a normalized Hermitian \(A\), the canonical EB map from measuring its spectral PVM after \(m\) marginal steps has score

\[
\sum_y\frac{\tau(\Phi^m(P_y)A)^2}{\tau(P_y)}
\ge 2\langle A,\Phi^m(A)\rangle_\tau-\|A\|_{2,\tau}^2
\ge \|A\|_{2,\tau}^2-2m\langle A,GA\rangle_\tau.
\tag{3}
\]

The first inequality is the square-variance identity; the second uses \(\lambda^m\ge1-m(1-\lambda)\) for \(\lambda\in[-1,1]\), so HS positivity of \(\Phi\) is not assumed. The full tree POVM refines each one-leaf POVM, and conditional Cauchy--Schwarz can only increase its canonical score. Summing (3) over the factor columns gives an exact tree response \(\Psi_Q\) with

\[
\operatorname{Tr}_{HS}(Q\Psi_Q)\ge \operatorname{Tr}_{HS}(QJ).
\tag{4}
\]

For the finite sampler, replace each rank-one leaf PVM \(\{P_y\}_{y=1}^d\) by the full-support POVM

\[
F_y=(1-\gamma)P_y+\gamma I/d,
\qquad 0<\gamma<1.
\tag{5}
\]

It has \(d\) effects summing to \(I\). For traceless \(A\), the one-leaf score is exactly \((1-\gamma)^2\) times the projective score: the identity part has zero pairing with \(A\), and each outcome still has tracial probability \(1/d\). Since a canonical EB map is a positive HS contraction, the ideal score lies in \([0,1]\); consequently the noisy score loses at most \(2\gamma\). Thus (4) becomes

\[
\operatorname{Tr}(Q\Psi_Q)\ge\operatorname{Tr}(QJ)-2\gamma.
\tag{6}
\]

An approximate diagonalizer also fits the same budget without an eigengap assumption. If \(\mathcal D\) is the HS-orthogonal projection onto the diagonal algebra of a computed PVM and \(\|A-\widetilde A\|_{2,\tau}\le\zeta\|A\|_{2,\tau}\) for a matrix \(\widetilde A\) diagonal in that algebra, then \(\|A-\mathcal D A\|_2\le\zeta\|A\|_2\) by best approximation. For \(C=\Phi^m(A)\),

\[
\|\mathcal DC\|_2^2\ge2\langle A,C\rangle_\tau-\|A\|_2^2-2\|A\|_2\|A-\mathcal D A\|_2,
\]

so the approximate local basis costs at most \(2\zeta\) after normalizing \(A\). This avoids unstable claims about individual eigenvectors near degeneracy. The algorithm needs only a certified approximate diagonalizer, not a target eigenbasis: stable symmetric Jacobi diagonalization gives a polynomial-time unitary with a small residual, and a rational exact-unitary approximation preserves that residual bound. The factor columns used below have norm at least the smallest singular value of the matrix exponential, whose logarithmic condition cost is polynomial in \(d,1/\delta\); thus the required relative residual precision has polynomial bit length. The resulting noisy leaf effects in (5) remain an exact POVM.

## Sampling a tree outcome without listing the POVM

For leaf outcomes \(z=(y_v)_v\), their pullback effects are

\[
E_{v,y}=F^v_y\quad(v\text{ a leaf}),\qquad
E_{v,(z_L,z_R)}=\mathcal B^*(E_{L,z_L}\otimes E_{R,z_R}).
\tag{7}
\]

Every message is a \(d\times d\) positive matrix. The full outcome effect \(E_z\) has probability \(p_z=\tau(E_z)\) on \(I/d\), and its prepared state is the ordinary trace-one density \(\rho_z=E_z/\mathrm{Tr}(E_z)=E_z/(d p_z)\).

An exact sampler that returns both \(z\) and \(E_z\) is recursive. At an internal node with unnormalized input state \(X\), form \(Y=\mathcal B(X)\) and its left marginal \(X_L=\mathrm{Tr}_R Y\). Recursively sample the left subtree under \(X_L\), obtaining label \(z_L\) and effective effect \(E_L\). Then form the unnormalized conditional right state

\[
X_R=\mathrm{Tr}_L[(E_L\otimes I)Y]
\tag{8}
\]

and recursively sample the right subtree under \(X_R\). Return \(z=(z_L,z_R)\) and \(\mathcal B^*(E_L\otimes E_R)\). For every positive \(X\), the left label probability is \(\mathrm{Tr}(E_L\,\mathrm{Tr}_R\mathcal B(X))\), the conditional right-label probability is \(\mathrm{Tr}(E_R X_R)/\mathrm{Tr}X_R\), and their product is exactly \(\mathrm{Tr}(X\mathcal B^*(E_L\otimes E_R))/\mathrm{Tr}X\). Induction proves the claimed joint law. This respects sibling correlations; independent sampling from marginal channels is generally wrong.

The routine makes O(K) calls to the dense forward and adjoint contractions, each O(d^6) arithmetic operations, and holds only d-by-d effect/state messages plus the d^2-by-d^2 output matrix at active ancestors. It never constructs the full tree state of dimension \(d^K\), nor lists its \(d^K\) possible product labels.

In the partial-effect sampler, a partial assignment's root effect is the sum of all full outcome effects extending it. At the next leaf, compute the root effects for its \(d\) candidate labels and sample in proportion to their traces; the candidates sum to the current root trace. Cache sibling effects so changing one label requires recomputing only the path to the root. This alternative uses O(Kd log K) adjoint contractions per draw and avoids conditional-state normalization.

Because of (5), every complete leaf product effect is at least \((\gamma/d)^K I\). The full tree adjoint is unital CP, hence

\[
E_z\succeq(\gamma/d)^K I,\qquad p_z\ge(\gamma/d)^K.
\tag{9}
\]

Thus \(\log(1/p_z)\le K\log(d/\gamma)=O(d^2\log(d/\delta))\). Partial prefixes have the same polynomial-bit lower bound. Exact rational arithmetic prevents floating-point division by a rare prefix from amplifying a numerical error; exact categorical sampling from rational probabilities has expected O(bit-length) cost using integer rejection. Capping each rejection loop at O(log(TNK/\eta_{\mathrm{fail}})) trials makes the total runtime worst-case polynomial and adds at most \(\eta_{\mathrm{fail}}/8\) total abort probability over all samples.

## From samples to a valid finite EB response

The raw sample covariance alone need not be a channel. For \(N\) independent outcomes \(z_i\sim p\), set \(\rho_i=\rho_{z_i}\), \(v_i=\rho_i-I/d\), and define the empirical traceless superoperator

\[
\widehat C=\frac{d^2}{N}\sum_{i=1}^N |v_i\rangle\langle v_i|_\tau.
\tag{10}
\]

Its expectation is the traceless restriction \(\Psi_{Q,0}\) of the canonical tree map. Indeed, \(\mathbb E\rho_i=I/d\), and for traceless \(X\),

\[
\Psi_Q(X)=\mathbb E\,[d\,\mathrm{Tr}(\rho_iX)\rho_i],\qquad
P_0\Psi_QP_0(X)=\mathbb E\,[d^2\tau(v_iX)v_i].
\]

Each summand \(Y_i=d^2|v_i\rangle\langle v_i|_\tau\) is PSD and satisfies \(\|Y_i\|=d^2\tau(v_i^2)=d\mathrm{Tr}(\rho_i^2)-1\le d-1\). Also \(Y_i^2\preceq(d-1)Y_i\), so its variance proxy is at most \((d-1)\Psi_{Q,0}\preceq dI\). Matrix Bernstein therefore gives, for \(0<\varepsilon\le1\),

\[
\Pr\{\|\widehat C-\Psi_{Q,0}\|>\varepsilon\}
\le 2n\exp\!\left(-\frac{N\varepsilon^2}{2d+(2/3)d\varepsilon}\right).
\tag{11}
\]

The sample barycenter \(S=N^{-1}\sum_i\rho_i\) has mean \(I/d\). Matrix Chernoff gives

\[
\Pr\{dS\npreceq(1+\alpha)I\}\le d\exp[-N\alpha^2/(3d)]
\tag{12}
\]

for \(0<\alpha\le1\).

On the event \(dS\preceq(1+\alpha)I\), set \(c=(1+\alpha)^{-1}\) and define the explicit finite effects

\[
M_i=\frac{cd}{N}\rho_i\quad(i=1,\ldots,N),\qquad
M_0=I-cdS\succeq0.
\tag{13}
\]

They sum exactly to \(I\). Prepare \(\sigma_i=\rho_i=M_i/\mathrm{Tr}M_i\) for \(i\ge1\), and \(\sigma_0=M_0/\mathrm{Tr}M_0\) for the residual effect. Since \(\mathrm{Tr}M_0=d(1-c)>0\) when \(\alpha>0\), this is defined. The channel

\[
\widehat\Psi_Q(X)=\sum_{i=0}^N\mathrm{Tr}(M_iX)\sigma_i
\tag{14}
\]

is EB, trace preserving, unital, and HS-self-adjoint: every prepared state is its effect normalized, and the effects sum to \(I\). Its traceless HS transfer operator is exactly \(c\widehat C\) plus the PSD residual rank-one term

\[
\frac{d}{\mathrm{Tr}M_0}\,|P_0M_0\rangle\langle P_0M_0|_\tau,
\]

so \(\widehat\Psi_{Q,0}\succeq c\widehat C\). This rational completion avoids taking a matrix inverse square root and makes the resulting effects/states exactly rational whenever the input and sampled states are rational.

Suppose the actual response passed its support bound with error \(\xi_{\rm tree}\), and the sample event (11) holds. For any density \(Q\), (13)--(14) give

\[
\begin{aligned}
\mathrm{Tr}[Q(\widehat\Psi_{Q,0}-J)]
&\ge c\,\mathrm{Tr}(Q\widehat C)-\mathrm{Tr}(QJ)\\
&\ge c\,\mathrm{Tr}[Q(\Psi_{Q,0}-J)]-(1-c)\mathrm{Tr}(QJ)-c\varepsilon\\
&\ge -(1-c)-\xi_{\rm tree}-\varepsilon,
\end{aligned}
\tag{15}
\]

because \(\lambda_{\max}(J)\le1\). This is a polynomial-outcome approximate support oracle, not merely an estimate of a superoperator.

## Matrix multiplicative weights and one common channel

At round \(t\), let \(\widehat\Psi_t\) be the finite canonical response to the current density query \(Q_t\), and set the Hermitian loss

\[
D_t=J-\widehat\Psi_{t,0}.
\]

Since \(0\preceq G\preceq2I\) and \(0\preceq\widehat\Psi_{t,0}\preceq I\), \(\|D_t\|\le R:=4m\) (using \(R=4m+1\) is harmless). Define

\[
Q_t=\frac{\exp(\mu\sum_{s<t}D_s)}{\mathrm{Tr}\exp(\mu\sum_{s<t}D_s)}.
\tag{16}
\]

The plus sign is needed: \(Q_t\) tracks the largest eigenvalue of cumulative losses. For \(\mu R\le1/2\), Golden--Thompson and the scalar bound \(e^x\le1+x+x^2\) on \([-1/2,1/2]\) give the pointwise regret inequality

\[
\lambda_{\max}\!\left(\frac1T\sum_{t=1}^TD_t\right)
\le \frac1T\sum_{t=1}^T\mathrm{Tr}(Q_tD_t)
+\frac{\log n}{\mu T}+\mu R^2.
\tag{17}
\]

By (15) and the leaf/basis/query precision budgets, each score \(\mathrm{Tr}(Q_tD_t)\le\xi\) on the simultaneous good event. Choose local budgets so \(\xi\le\delta/4\), choose the MW learning rate \(\mu=\delta/(4R^2)\), and \(T\ge16R^2\log n/\delta^2\). Then the last two terms in (17) sum to at most \(\delta/2\), so

\[
\lambda_{\max}\!\left(J-\frac1T\sum_t\widehat\Psi_{t,0}\right)\le\delta.
\]

Set \(\widehat\Psi=T^{-1}\sum_t\widehat\Psi_t\). Convex mixtures of canonical EB channels remain canonical EB channels. The mixture has the explicit POVM with effects \(M_{t,i}/T\) and prepared states \(\sigma_{t,i}\), hence at most \(T(N+1)\) outcomes; it satisfies (1).

For exact updates, (16) is a mathematical definition; for a bit algorithm, approximate each density query by a rational PSD trace-one matrix within trace norm \(\theta\). Its response score changes by at most \(R\theta\), which is charged inside \(\xi\). Matrix exponentials can be computed to this precision in polynomial time: \(\mu T R=O(R\log n/\delta)\), so the condition number/required bit precision is polynomial in \(d,1/\delta,L\). A rational Gram approximation \(\widetilde W\) to \(\exp(\mu\sum D_s/2)\) yields the exactly PSD query \(\widetilde Q=\widetilde W\widetilde W^*/\mathrm{Tr}(\widetilde W\widetilde W^*)\), avoiding non-PSD rounding. Factor columns of \(\widetilde W\) directly specify the support frame; this avoids eigendecomposing the query matrix.

The resulting bit algorithm is: (i) approximate the matrix exponential by a rational Gram factor and normalize its PSD product; (ii) use its columns as the support frame, approximate each column's observable eigenbasis to the assigned score tolerance, and make the rational noisy leaf POVMs (5); (iii) draw \(N\) outcomes from this tree, compute their pullback effects, and form (10); (iv) test (12) and construct the exact rational completion (13)--(14); (v) set \(D_t=J-\widehat\Psi_{t,0}\) and continue (16). If the barycenter test or a capped random-integer draw fails, abort; otherwise stop after the fixed horizon \(T\). Before returning, check the final slack exactly: in any rational basis of \(\mathcal H_0\), the quadratic-form matrix for \(\delta I-(J-\widehat\Psi_0)\) is rational and symmetric, so an exact rational PSD/LDL check certifies (1). The complete failure probability is charged to the per-round concentration union bound, capped-sampler aborts, and the certified numerical tolerances.

## Costs, probability, and deployment

Take \(\gamma,\alpha,\varepsilon,\zeta\) each at most a sufficiently small constant times \(\delta\), and query/rounding error \(\theta\le\delta/(64R)\). A conservative simultaneous sample count is

\[
N=C\,d\,\delta^{-2}\log\!\frac{8dTn}{\eta_{\mathrm{fail}}}
\tag{18}
\]

for a sufficiently large absolute constant \(C\). This makes (11)--(12) hold for every adaptive round with total failure probability at most \(\eta_{\mathrm{fail}}/2\); capped exact integer sampling consumes at most another \(\eta_{\mathrm{fail}}/2\). Adaptivity is harmless because each round uses fresh samples and (11)--(12) hold conditionally on the entire past. The algorithm stops after \(T\) rounds and \(N\) samples per round; it need not estimate or enumerate any global tree outcome count.

For the equal-depth tree, \(K=O(d^2)\). A dense \(\mathcal B\) or \(\mathcal B^*\) contraction costs O(d^6) arithmetic operations. The recursive sampler costs O(Kd^6) per draw, giving a crude total O(TNKd^6) arithmetic count, or O(d^9\delta^{-4}\operatorname{polylog}(dT/\eta_{\mathrm{fail}})) before bit-operation factors. All intermediate exact rational bit lengths are polynomial in \(K,L\), and the rational local-basis and confidence precisions; full-support noise gives the explicit rare-outcome bound (9). The final list has \(D=T(N+1)=\operatorname{poly}(d,1/\delta,\log(1/\eta_{\mathrm{fail}}))\) outcomes and O(Dd^2) matrix entries. It can be deployed as an ordinary D-outcome POVM followed by classical preparation of one of D listed density matrices. A generic Naimark dilation and state-preparation synthesis are polynomial in \(d,D,L,\log(1/\delta)\). The deployed map requires no broadcaster calls; the broadcaster is used by the offline compiler through its exact dense description.

If an input is represented only by a physical black box, all that remains available is a different sampling/tomography problem; the exact contractions used here are unavailable. The compiler also does not improve the logarithmic theorem to a dimension-free comparison, so bounded Holevo information alone still does not yield the requested dimension-free approximate-broadcasting implication.

## Prior-art and evidence status

The proof ingredients are standard concentration and matrix-weights machinery, not novelty claims. For matrix Bernstein/Chernoff, see Tropp, [*User-Friendly Tail Bounds for Sums of Random Matrices*](https://arxiv.org/abs/1004.4389). For matrix multiplicative weights and approximate SDP feasibility, see Arora, Hazan, and Kale, [*Fast Algorithms for Approximate Semidefinite Programming using the Multiplicative Weights Update Method*](https://www.cs.princeton.edu/~arora/pubs/mw-focs.pdf). The specific combination of the reconstructed broadcast-tree support response, bounded canonical-map samples, rational POVM completion, and a finite explicit common comparator is internally derived here. No priority or external validation claim is made.

This is a constructive consequence of the internally audited logarithmic tree comparison in `../WEIGHTED_TREE.md` and `../FINAL_REPORT.md`. The exact tree-sampling lemma is independently recorded in `../../cycle6_constructive_comparator/oracle_sampling/ORACLE_SAMPLING.md`; the MW sign/interface audit is in `../../cycle6_constructive_comparator/mw_compiler/MW_AUDIT.md`; finite-precision constraints are in `../../cycle6_constructive_comparator/precision_interface/REPORT.md`.
