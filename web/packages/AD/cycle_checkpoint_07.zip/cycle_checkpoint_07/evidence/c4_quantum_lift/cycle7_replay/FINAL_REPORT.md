# Cycle 7: rational compiler replay and a structured product consequence

## Result

The rational residual-completion/compiler path now has an end-to-end small-instance replay with an exact final certificate. The test uses a nonvacuous self-compatible qubit channel with one near-fixed mode. It also gives a sharper constructive consequence when the supplied broadcaster has a repeated local tensor-product description: in that class, a common EB map satisfies the **sharp factor 2 on every global operator mode**, and its operational description costs (O(L)) for (L) sites even though the Hilbert-space dimension is (2^L).

Neither result settles the sharp factor-2 comparison for arbitrary self-compatible channels or the bounded-Holevo lift without structural assumptions. The small replay is finite evidence for the compiler mechanics. The product result is an exact theorem for the stated tensor-factorized channel family.

## Exact broadcaster and finite replay

Let (B_Z) copy a computational-basis input to (|00angle) or (|11angle), and let (B_U) be the symmetric universal qubit (1\to2) cloner. The local broadcaster is

\[
 B=\frac9{10}B_Z+\frac1{10}B_U.
\]

Its two marginals agree and are

\[
\Phi=\frac9{10}\Delta_Z+\frac1{10}\Gamma,
\qquad
\Gamma(X)=\frac23X+\frac16\operatorname{Tr}(X)I.
\]

In the (X,Y,Z) Pauli basis, the marginal eigenvalues are ((1/15,1/15,29/30)), so the Dirichlet gaps are ((14/15,14/15,1/30)). For (d=2), (m=\lceil\log_2(3)\rceil=2); the tree target (J=I-2m(I-\Phi)) has eigenvalues ((-41/15,-41/15,13/15)). The (Z)-mode remains a positive dual direction, so a universal-cloner-only control, whose corresponding target is negative in every direction, would not test this slow-mode gate.

The input is saved as a rational (16\times4) Liouville matrix in [INPUT_BROADCASTER_LIOUVILLE.json](INPUT_BROADCASTER_LIOUVILLE.json): 64 complex-rational entries with a summed numerator/denominator bit count of 234. An exact positive weighted Kraus decomposition certifies complete positivity and trace preservation; each Kraus range is swap-symmetric, so the two output marginals agree. Exact matrix checks also verify that (Phi) is unital, trace preserving, Hilbert–Schmidt self-adjoint, and has the stated Pauli transfer matrix.

Four depth-two leaves use noisy (X,Y,Z,Z) measurements with (γ=1/100). The script checks all 16 pullback effects are positive and sum exactly to (I), and verifies every recursive conditional path probability equals the corresponding exact enumerated tree probability. It also runs 256 seeded recursive sampler draws; every returned effect equals the exact effect indexed by its correlated outcome. The full-support lower bound is (p_z\ge(\gamma/2)^4=1/1{,}600{,}000{,}000).

The incorrect independent-marginal sampler has exact total-variation error (22869/50000=0.45738) on this same tree. Each leaf marginal is uniform, while the (Z,Z') sibling signs have correlation

\[
\frac{14}{15}(1-\gamma)^2=0.91476,
\]

which the product sampler sets to zero. The full-law TV equals the exact pair-law gap here. This is a direct falsifier of independent marginal reuse.

The adaptive finite run used (T=16) rounds, (N=1024) samples per round, δ=1/4, barycenter allowance α=1/10, completion scale (c=10/11), and seed 20261008. Repeated samples with the same outcome were aggregated by integer counts. Each response used the exact rational effects

\[
M_z=\frac{2c k_z}{N}\rho_z,
\qquad M_0=I-2cS,
\qquad S=\frac1N\sum_z k_z\rho_z.
\]

All 16 residuals passed exact (M_0\succeq0) checks. The pre-twirl channel transfer was checked to equal (c\widehat C) plus the exact positive residual rank-one covariance. Each completed channel was verified CP, TP, unital, and Hilbert–Schmidt self-adjoint, then Pauli-twirled using four exact unitary conjugates. The MW query was tracked from the previous exact rational losses using 60-digit decimal exponentials; queries remained diagonal in the Pauli basis, so the response PVM frame (X,Y,Z) was exact and unchanged by the positive query weights.

The saved [FINAL_CHANNEL.json](FINAL_CHANNEL.json) stores the complete 1088-outcome rational measure-and-prepare map. On (X,Y,Z), its exact transfer eigenvalues are

\[
\left(\frac{11626131}{655360000000},\frac{11658471}{655360000000},
\frac{1964386423987625}{2402750206836736}\right)
\approx(0.0000177401,0.0000177894,0.8175575).
\]

The exact operator-order slack is diagonal with entries

\[
\left(\frac{5865506878393}{1966080000000},
\frac{5865506975413}{1966080000000},
\frac{7240356946574567}{36041253102551040}\right)
\approx(2.98335,2.98335,0.200891),
\]

so the serialized channel satisfies

\[
I-\Psi\preceq 4(I-\Phi)+\frac14 I
\]

on the full Hermitian space. The script round-trips the serialized effects/states, rechecks the Choi matrix by exact principal minors, and reproduces the same rational transfer matrix and slack. Replay data and hashes are in [REPLAY.json](REPLAY.json). The run took about 75.5 seconds in the current SymPy 1.14 environment.

The compiler replay intentionally uses the exact 16-outcome enumeration as a small-instance sampling accelerator. It separately checks the recursive correlated sampler. It does **not** claim that the enumerated route scales. For comparison, the generic MW sufficient horizon at these (d,\delta) values is (T=18{,}000), with sample-count formula coefficient about (533.3C) before the unspecified absolute concentration constant (C). The 16-round instance passes because its final rational inequality is checked directly; it is not a high-probability generic-horizon demonstration. A flat global outcome table and the absolute constants in the generic dense compiler would be impractical at large (d).

## Exact (O(L)) structured compiler with sharp factor 2

Now supply (L) copies of this local broadcaster as a product/tensor-network descriptor. Regrouping each local output pair gives a symmetric global broadcaster with marginal

\[
\Phi_L=\Phi^{\otimes L}.
\]

The local comparator is the canonical three-outcome measure-and-prepare map

\[
\Psi_1(X)=\sum_{a=0}^2\operatorname{Tr}(M_aX)\sigma_a,
\]

with

\[
\begin{array}{lll}
M_0=\frac{14}{15}|0\rangle\langle0|,&\sigma_0=|0\rangle\langle0|,\\
M_1=\frac{14}{15}|1\rangle\langle1|,&\sigma_1=|1\rangle\langle1|,\\
M_2=\frac1{15}I,&\sigma_2=I/2.
\end{array}
\]

These rational effects sum to (I), their trace-weighted preparations sum to (I), and the map is EB, TP, unital, and Hilbert–Schmidt self-adjoint. Its Pauli eigenvalues are ((0,0,14/15)). The global compiler outputs the succinct local product instrument (\Psi_L=\Psi_1^{\otimes L}).

The comparison covers every Pauli word, hence every Hermitian operator. The local labels (I,X,Y,Z) have respective paired eigenvalues

\[
(\lambda,\mu)=(1,1),(1/15,0),(1/15,0),(29/30,14/15).
\]

For any word containing (X) or (Y), its (mu)-eigenvalue is zero and (0\le\lambda\le1/15), so (1-\mu=1\le2(1-\lambda)). The all-identity word has zero slack. A word with only (I,Z) and (k\ge1) copies of (Z) has (lambda=(29/30)^k), (mu=(14/15)^k). Put (x=14/15=2(29/30)-1). For (x_i\in[0,1]),

\[
\prod_{i=1}^k(1+x_i)\le2^{k-1}\left(1+\prod_{i=1}^kx_i\right).
\]

Induction proves this: after an induction step, the remaining inequality ((1+p)(1+y)\le2(1+py)) is equivalent to ((1-p)(1-y)\ge0). Taking every (x_i=x) yields ((14/15)^k\ge2(29/30)^k-1), or (1-\mu\le2(1-\lambda)). Thus

\[
I-\Psi_L\preceq2(I-\Phi_L)
\]

on all (4^L) Pauli modes, including the identity mode. A one-site (Z) mode tensored with identities attains equality, so the factor 2 is sharp for this family.

This is a real resource separation for succinct inputs. A homogeneous instance is specified by the 234-bit local rational Liouville descriptor plus the site count (L), while the dense global broadcaster has dimension (d=2^L) and (\Theta(d^6)) entries. The comparator description is one three-outcome local instrument repeated at (L) sites; applying it takes (O(L)) local measurements/preparations. If flattened into one global POVM, its outcome count is (3^L), and the artifact records that cost rather than hiding it. For a globally entangled input, the local outcome labels can be correlated; implementation uses the physical product measurement or sequential conditional sampling, never an independent-marginal shortcut.

There is also a dimension-free reconstruction consequence for any promised family of likelihoods (\rho_H=(I+H)/2^L), where (H=H^*), (\tau(H)=0), (\|H\|_\infty\le1/2), and (r=\sup_H\|\Phi_L(H)-H\|_{1,\tau}). A canonical EB channel has (0\preceq\Psi_L\preceq I) as an HS operator, so ((I-\Psi_L)^2\preceq I-\Psi_L). Therefore

\[
\begin{aligned}
\|(I-\Psi_L)H\|_{2,\tau}^2
&\le\langle H,(I-\Psi_L)H\rangle_\tau\\
&\le2\langle H,(I-\Phi_L)H\rangle_\tau\\
&\le2\|H\|_\infty\|\Phi_L(H)-H\|_{1,\tau}\le r.
\end{aligned}
\]

Since (\|X\|_{1,\tau}\le\|X\|_{2,\tau}), and the ordinary physical half-trace error equals (\frac12\|\Psi_L(H)-H\|_{1,\tau}), one common channel obeys

\[
\sup_H\frac12\|\Psi_L(\rho_H)-\rho_H\|_1\le\frac12\sqrt r.
\]

This does not use a Holevo bound; it uses the stronger supplied product-broadcaster structure and uniform near-fixedness. It illustrates where the unrestricted capacity-only obstruction can be bypassed without enumerating a growing family.

## Heterogeneous axes and site strengths

The product compiler also accepts nonidentical local factors. At site (i), choose a rational (	heta_iin[1/4,1]) and one of the Pauli axes (n_iin{X,Y,Z}), and supply

\[
B_i=\theta_i B_{Z,n_i}+(1-\theta_i)B_U,
\]

where (B_{Z,n_i}) copies the (n_i)-eigenbasis and (B_U) is the symmetric universal cloner. This remains a symmetric broadcaster. Its marginal eigenvalues on the identity, parallel, and two transverse modes are

\[
\lambda_{i,I}=1,\qquad \lambda_{i,\parallel}=\frac{2+\theta_i}{3},\qquad \lambda_{i,\perp}=\frac{2(1-\theta_i)}{3}.
\]

Use the local canonical instrument for

\[
\Psi_i=\alpha_i\Delta_{n_i}+(1-\alpha_i)D,
\qquad \alpha_i=2\lambda_{i,\parallel}-1=\frac{1+2\theta_i}{3},
\]

with effects \(\alpha_iP_{i,+},\alpha_iP_{i,-},(1-\alpha_i)I\) and preparations \(P_{i,+},P_{i,-},I/2\). They sum to (I), and the trace-weighted preparations also sum to (I). The local transfer pairs are \((1,1)\), \((\lambda_{i,\parallel},2\lambda_{i,\parallel}-1)\), and \((\lambda_{i,\perp},0)\). Since \(\theta_i\ge1/4\), each transverse \(\lambda_{i,\perp}\le1/2\).

For the tensor product, any eigenoperator with a transverse factor has global \(\mu=0\) and \(\lambda\le1/2\), so it satisfies \(1-\mu\le2(1-\lambda)\). If the word uses only identity and parallel factors, then at each active site \(\mu_i=2\lambda_i-1\in[0,1]\). The same product lemma gives \(\prod_i\mu_i\ge2\prod_i\lambda_i-1\), proving the comparison on every product eigenoperator. These local eigenoperators span the full global operator space, so this is an all-mode statement. A single parallel mode tensored with identities attains equality.

The exact finite instance in [HETEROGENEOUS_PRODUCT_COMPARATOR.json](HETEROGENEOUS_PRODUCT_COMPARATOR.json) uses seven factors with varied rational strengths and axes (Z,X,Y,Z,X,Y,Z); its script checks all (3^7) distinct spectral-type words exactly (the transverse type has multiplicity two). In general, the input is a list of local strengths/axes with total encoding length proportional to the list length and rational bit count, and the output is the list of local three-outcome instruments. Compilation and physical implementation take (O(L)) local operations. This extends the structured class to site-inhomogeneous product broadcasters; interactions and bounded-treewidth networks remain open.

## Entangling finite-depth circuit dressing

There is a structured interacting extension that does not require a product channel in the supplied coordinates. Let (B_{m prod}=igotimes_i B_i) be one of the product broadcasters above, and let (U) be a supplied (L)-site unitary circuit. Dress the input and both receivers by the same circuit:

\[
\widetilde B=(\operatorname{Ad}_U\otimes\operatorname{Ad}_U)\circ B_{\rm prod}\circ\operatorname{Ad}_{U^\dagger},
\qquad \operatorname{Ad}_U(X)=UXU^\dagger.
\]

Its marginal is \(\widetilde\Phi=\operatorname{Ad}_U\circ\Phi_{\rm prod}\circ\operatorname{Ad}_{U^\dagger}\). Use \(\widetilde\Psi=\operatorname{Ad}_U\circ\Psi_{\rm prod}\circ\operatorname{Ad}_{U^\dagger}\). Unitary pre- and post-processing preserve the EB property, and conjugation by the Hilbert–Schmidt unitary \(\operatorname{Ad}_U\) preserves operator order. Therefore

\[
I-\widetilde\Psi=\operatorname{Ad}_U(I-\Psi_{\rm prod})\operatorname{Ad}_{U^\dagger}
\preceq2\operatorname{Ad}_U(I-\Phi_{\rm prod})\operatorname{Ad}_{U^\dagger}=2(I-\widetilde\Phi)
\]

on the full Hermitian operator space. The dressed broadcaster remains symmetric: swapping the two receivers commutes with applying the same (U) to both. Its EB instrument is implemented by (U^\dagger), the local product measurement, local preparation, and (U). For a depth-(D) bounded-range circuit this takes (O(LD)) local gates/operations and stores the circuit plus local factors; the (3^L)-outcome flattened POVM is not materialized.

The exact replay [FINITE_DEPTH_DRESSED_COMPARATOR.json](FINITE_DEPTH_DRESSED_COMPARATOR.json) uses (L=2) and one CNOT. It verifies weighted Kraus completeness, symmetric output support, the unital marginal and all 16 Pauli-mode eigenpairs, the canonical POVM and trace-weighted preparation sums, and the exact factor-2 slack. This is genuinely nonproduct: the dressed marginal has transfer values \(1/225\) on (XI), \(1/15\) on (IX), and \(1/15\) on (XX); a product of one-site channels would force the last to be \((1/225)(1/15)=1/3375\). This closes the finite-depth *unitary-dressed product* structured case. It does not cover generic local interactions, dissipative circuits, or bounded-treewidth broadcasters whose eigenmodes are not a unitary image of the product modes.

## Resource and evidence boundary

The generic dense compiler in [CONSTRUCTIVE_COMPILER.md](../cycle6_constructive_comparator/CONSTRUCTIVE_COMPILER.md) has an (O(d^9\delta^{-4}\operatorname{polylog}(d/\eta_{\mathrm{fail}}))) dense-arithmetic upper bound under a finite-bit rational input and exact/charged validity checks. Here (\eta_{\mathrm{fail}}) is the probability target and (\mu) is the MW learning rate; the notation is separated in that report. Its equation (17) displays the required plus signs in the regret upper bound. The small replay is an exact fixture, not a validation of all worst-case constants. The local product compiler is exact and (O(L)) in its structured representation, but only when the tensor factors and local map are supplied and validated.

The product comparator uses the earlier internally reconstructed qubit factor-2 result and tensor-product closure. This report adds the explicit repeated local compiler representation and all-mode near-fixed corollary; no novelty or priority claim is made. Arbitrary self-compatible channels may not expose a product factorization, common eigenbasis, bounded tree width, or local EB comparators. The dimension-free theorem for that unrestricted class and the capacity-only broadcasting lift remain open.

## Reproduction

Run `python3 compiler_replay.py` to regenerate the dense input, serialized EB output, and exact adaptive replay. Run `python3 structured_product_compiler.py --sites 64` for the homogeneous comparator, `python3 heterogeneous_product_compiler.py` for the seven-site inhomogeneous certificate, and `python3 finite_depth_dressed_compiler.py` for the CNOT-dressed nonproduct instance. The exact adaptive round data, dense input, and complete 1088-outcome final map are retained next to these scripts. The independent sampler audit is in [ORACLE_AUDIT.md](oracle_audit/ORACLE_AUDIT.md); the product/all-mode argument passed independent review recorded in [PRODUCT_AUDIT.md](product_audit/PRODUCT_AUDIT.md).
