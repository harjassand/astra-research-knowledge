# Independent audit: cycle-7 qubit replay

## Verdict

The stated mixture gives the exact Pauli-diagonal marginal
\[
  \Phi: (x,y,z)\longmapsto (x/15,\ y/15,\ 29z/30),
\]
and a depth-2 balanced broadcaster tree has four leaf marginals \(\Phi^2\), with multipliers \((1/225,1/225,841/900)\). The symmetric extension and noisy leaf POVMs can be represented exactly; the cloner Kraus amplitudes contain radicals, but its channel matrix entries are rational. The recursive sampler must preserve sibling correlations. A particularly decisive check is the Z/extra-Z sibling sign correlation, \((14/15)(1-\gamma)^2\), whereas product-of-marginals sampling gives zero. The rational completion is valid when \(\sum_i k_i=N\), \(S=N^{-1}\sum_i k_i\rho_i\), and the certified condition \(2S\preceq(1+\alpha)I\) holds; Pauli twirling preserves the EB, unital, TP, and HS-self-adjoint properties and preserves the comparator slack because this \(\Phi\) is Pauli diagonal.

The correlation formulas below assume the four leaves are ordered as two sibling pairs \((X,Y)\) and \((Z,\text{extra-}Z)\), with extra-Z a duplicate Z basis. A general-axis formula is included in case that label means something else.

## Broadcaster and exact marginal

Let
\[
  \mathcal B_Z(\rho)=\sum_{b=0}^1\langle b|\rho|b\rangle\,|bb\rangle\langle bb|,
\]
with Kraus operators \(A_b=|bb\rangle\langle b|\). It is CPTP, invariant under swapping the two outputs, and both marginals are Z-dephasing
\(\Delta_Z(\rho)=\tfrac12(\rho+Z\rho Z)\).

One exact Stinespring isometry for the universal qubit cloner is
\[
\begin{aligned}
V|0\rangle&=\sqrt{2/3}|00\rangle|0\rangle_E
 +\sqrt{1/6}(|01\rangle+|10\rangle)|1\rangle_E,\\
V|1\rangle&=\sqrt{2/3}|11\rangle|1\rangle_E
 +\sqrt{1/6}(|01\rangle+|10\rangle)|0\rangle_E.
\end{aligned}
\]
The two Kraus operators after tracing the environment are
\[
\begin{aligned}
K_0&=\sqrt{2/3}|00\rangle\langle0|
 +\sqrt{1/6}(|01\rangle+|10\rangle)\langle1|,\\
K_1&=\sqrt{1/6}(|01\rangle+|10\rangle)\langle0|
 +\sqrt{2/3}|11\rangle\langle1|.
\end{aligned}
\]
Their outputs lie in the symmetric subspace and \(\sum_eK_e^\dagger K_e=I\). Tracing either clone gives
\[
  \Gamma(X)=\tfrac23X+\tfrac16\operatorname{Tr}(X)I,
\]
so for a state its Bloch vector is shrunk by \(2/3\).

The proposed broadcaster is
\[
  \mathcal B=\tfrac9{10}\mathcal B_Z+\tfrac1{10}\mathcal B_U,
\]
where \(\mathcal B_U(X)=\sum_eK_eXK_e^\dagger\). A Kraus list for the mixture is \(\{\sqrt{9/10}A_0,\sqrt{9/10}A_1,\sqrt{1/10}K_0,\sqrt{1/10}K_1\}\). Thus it is CPTP, swap-symmetric, and each marginal is
\[
  \Phi=\tfrac9{10}\Delta_Z+\tfrac1{10}\Gamma.
\]
In Pauli coordinates, \(\Delta_Z\) has multipliers \((0,0,1)\), and \(\Gamma\) has \((2/3,2/3,2/3)\); the mixture therefore has \((1/15,1/15,29/30)\). The exact matrix action on \(\rho=\begin{pmatrix}a&c\\\bar c&b\end{pmatrix}\) is
\[
  \Phi(\rho)=
  \begin{pmatrix}
    (59a+b)/60 & c/15\\
    \bar c/15 & (a+59b)/60
  \end{pmatrix}.
\]
All Liouville/Choi entries of \(\mathcal B_U\) are rational: products of the Kraus amplitudes used above are among \(2/3,1/6,1/3\). The mixture weights are rational too. Hence the dense channel supplied to the classical sampler can be exact rational data despite this convenient radical Kraus representation.

## Noisy leaf effects and the exact tree law

For Pauli direction \(n\in\{x,y,z\}\) and sign \(s\in\{\pm1\}\), the gamma-noisy measurement is the two-effect POVM
\[
  F^{(n)}_s=(1-\gamma)P^{(n)}_s+\gamma I/2
          =\tfrac12[I+s(1-\gamma)\sigma_n].
\]
It is a POVM rather than a PVM when \(\gamma>0\). With rational \(\gamma\), all X/Y/Z effects have rational Gaussian entries.

For the depth-2 tree with leaf effects \(F^X_{s_1},F^Y_{s_2},F^Z_{s_3},F^{Z'}_{s_4}\), the pulled-back outcome effect is exactly
\[
\begin{aligned}
E_{s_1s_2s_3s_4}
={}&\mathcal B^*\!\left(
  \mathcal B^*(F^X_{s_1}\otimes F^Y_{s_2})
  \otimes
  \mathcal B^*(F^Z_{s_3}\otimes F^{Z'}_{s_4})
\right),\\
p_{s_1s_2s_3s_4}={}&\tau(E_{s_1s_2s_3s_4})=\operatorname{Tr}(E_{s_1s_2s_3s_4})/2.
\end{aligned}
\]
The depth-2 marginal at every individual leaf is \(\Phi^2\), with Pauli multipliers \((1/225,1/225,841/900)\). In particular, input \(I/2\) gives state \(I/2\) at every leaf. Since \(\operatorname{Tr}F^{(n)}_s=1\), every one-leaf outcome is exactly uniform. A product-of-marginals sampler therefore outputs the uniform law on all 16 sign strings.

The exact correlated sampler uses the standard tree recursion. At a node with unnormalized input \(X\), form \(Y=\mathcal B(X)\), sample the left subtree on \(\operatorname{Tr}_R Y\), and return its effective effect \(E_L\). Update the right input to
\[
  X_R=\operatorname{Tr}_L[(E_L\otimes I)Y],
\]
sample the right subtree on \(X_R\), and return the parent effect \(\mathcal B^*(E_L\otimes E_R)\). For the full tree, this yields the probability above by induction: the left mass is \(q=\operatorname{Tr}[(E_L\otimes I)Y]\), the right conditional mass is \(\operatorname{Tr}(E_RX_R)/q\), and their product is \(\operatorname{Tr}[X\mathcal B^*(E_L\otimes E_R)]/\operatorname{Tr}X\). Thus exact recursive sampling matches \(\tau(E_z)\); independent leaf draws do not.

For \(0<\gamma<1\), every leaf effect obeys \(F_s\succeq(\gamma/2)I\). Unital positivity of \(\mathcal B^*\) propagates these lower bounds through the depth-2 pullback, giving \(E_z\succeq(\gamma/2)^4I\) and \(p_z\ge(\gamma/2)^4\). Thus this four-leaf example has no zero-probability strings and has a polynomial-bit lower bound on every outcome mass when \(\gamma\) is rational with finite input length.

## Decisive falsifier for independent marginals

On maximally mixed input, the two outputs of one bottom-level broadcaster call have state
\[
  \Omega=\mathcal B(I/2)
  =\tfrac9{10}\tfrac12(|00\rangle\langle00|+|11\rangle\langle11|)
   +\tfrac1{10}\tfrac13P_{\rm sym}.
\]
Here the cloner output is \(P_{\rm sym}/3\). Its two-qubit Pauli correlation matrix is
\[
  C_{ij}=\operatorname{Tr}(\Omega\,\sigma_i\otimes\sigma_j)
  =\operatorname{diag}(1/30,1/30,14/15).
\]
For sibling noisy Z and extra-Z outcomes \(s_3,s_4\),
\[
  \mathbb E_{\rm tree}[s_3s_4]
     =(1-\gamma)^2\operatorname{Tr}(\Omega Z\otimes Z)
     =\frac{14}{15}(1-\gamma)^2,
\]
whereas \(\mathbb E_{\rm product}[s_3s_4]=0\). Equivalently,
\[
  \Pr_{\rm tree}[s_3=s_4]
   =\tfrac12\left[1+\tfrac{14}{15}(1-\gamma)^2\right],
  \qquad
  \Pr_{\rm product}[s_3=s_4]=\tfrac12.
\]
The pair marginal TV distance is \(\tfrac7{15}(1-\gamma)^2\); the full four-leaf TV distance is at least this large. For example, at \(\gamma=1/10\), the correlation is \(0.756\), and the equality rate is \(0.878\), versus \(0.5\) under independent marginals. This is a narrow exact diagnostic, not a simulation claim.

For general sibling directions \(n,m\), the correlation is
\[
  \mathbb E[s_ns_m]=(1-\gamma)^2\left(
    \frac{n_xm_x}{30}+\frac{n_ym_y}{30}+\frac{14n_zm_z}{15}
  \right).
\]
If extra-Z instead denotes an arbitrary axis \(n'\) paired with the Z leaf, this reduces to \((1-\gamma)^2(14/15)n'_z\); a nonzero Z component still gives a signal.

## Rational completion and Pauli twirl

Let the \(N\) tree samples be compressed to distinct states \(\rho_i\) with integer frequencies \(k_i\) satisfying \(\sum_i k_i=N\), and set
\[
  S=\frac1N\sum_i k_i\rho_i,\qquad c=\frac1{1+\alpha}\quad(\alpha>0).
\]
If the exact rational PSD check certifies \(2S\preceq(1+\alpha)I\), then
\[
  M_i=\frac{2c k_i}{N}\rho_i,\qquad M_0=I-2cS
\]
are positive and sum to \(I\). Here \(d=2\); the general formula is \(M_i=(cd k_i/N)\rho_i\), \(M_0=I-cdS\). Moreover \(\operatorname{Tr}M_0=2(1-c)>0\), so \(\sigma_0=M_0/\operatorname{Tr}M_0\) is defined. Preparing \(\rho_i\) after effect \(M_i\) and \(\sigma_0\) after \(M_0\) gives an EB channel
\[
  \widehat\Psi(X)=\sum_i\operatorname{Tr}(M_iX)\rho_i
                  +\operatorname{Tr}(M_0X)\sigma_0.
\]
It is TP because the effects sum to \(I\), unital because \(\sum_i\operatorname{Tr}(M_i)\rho_i+M_0=2cS+M_0=I\), and HS-self-adjoint because every preparation is its effect divided by that effect's trace. Rational samples and rational \(c\) make the completion exactly rational. If the condition fails, \(M_0\) need not be positive; the construction must reject/resample or use its stated concentration event, not silently clip eigenvalues.

Pauli twirling is
\[
  \widehat\Psi_{\rm tw}=\frac14\sum_{P\in\{I,X,Y,Z\}}
       \operatorname{Ad}_P\circ\widehat\Psi\circ\operatorname{Ad}_P,
  \qquad \operatorname{Ad}_P(X)=PXP.
\]
An explicit canonical POVM uses effects \(M_{P,i}=PM_iP/4\) and preparations \(P\sigma_iP\), including the residual term. It is a convex mixture of unitary conjugates, hence remains EB, TP, unital, and HS-self-adjoint; all entries remain rational (Gaussian rational for Y conjugations). In the Pauli basis, twirling removes off-diagonal transfer entries and leaves the three Pauli multipliers unchanged. Since the target \(G=I-\Phi\) is Pauli diagonal, if a completed map already satisfies the PSD slack inequality, twirling preserves that inequality: it is the group average of the same PSD slack conjugated by orthogonal Pauli actions. Twirling is therefore safe here, though it does not repair a failed PSD completion test or make independent sampling correct.
