# Independent audit: repeated qubit-product comparator

## Verdict

The proposed structured example is correct. It gives an exact factor-two Hilbert--Schmidt operator-order comparator for every tensor power of this particular self-compatible qubit channel, with a local canonical EB instrument of three outcomes. The family consequence has the stated physical half-trace normalization. Its scope is the explicit tensor-factorized input descriptor; it is not a generic compiler for an arbitrary dense global broadcaster, and bounded Holevo information alone does not imply the stated near-fixedness promises.

## Local channels and canonical instrument

The local cloner marginal is \(\Gamma(X)=\frac23X+\frac16\operatorname{Tr}(X)I\), with Bloch multipliers \((2/3,2/3,2/3)\). Computational-basis copying has marginal \(\Delta_Z\), with multipliers \((0,0,1)\). Thus

\[
\Phi_1=\tfrac9{10}\Delta_Z+\tfrac1{10}\Gamma,
\qquad (\lambda_X,\lambda_Y,\lambda_Z)=(1/15,1/15,29/30).
\]

Both broadcaster components are swap-symmetric CPTP maps, so their mixture is a symmetric broadcaster for \(\Phi_1\). Its local \(16\times4\) Liouville matrix has rational entries: the cloner Kraus amplitudes contain square roots, but the channel products are \(2/3,1/6,1/3\); after mixture, the entries are rational. The product broadcaster \(\mathcal B_1^{\otimes L}\), with its outputs regrouped into two \(L\)-qubit receivers, therefore has both marginals \(\Phi_L=\Phi_1^{\otimes L}\).

For the proposed three effects and preparations,

\[
M_0=\tfrac{14}{15}|0\rangle\langle0|,\quad
M_1=\tfrac{14}{15}|1\rangle\langle1|,\quad
M_2=\tfrac1{15}I,
\]

\[
\sigma_0=|0\rangle\langle0|,\quad
\sigma_1=|1\rangle\langle1|,\quad
\sigma_2=I/2,
\]

each effect and state is PSD, \(\sum_iM_i=I\), and \(\sum_i\operatorname{Tr}(M_i)\sigma_i=I\). The resulting channel is

\[
\Psi_1(X)=\sum_i\operatorname{Tr}(M_iX)\sigma_i
=\tfrac{14}{15}\Delta_Z(X)+\tfrac1{15}\operatorname{Tr}(X)I/2.
\]

It is unital, TP, EB, and HS-self-adjoint, with Pauli multipliers \((\mu_X,\mu_Y,\mu_Z)=(0,0,14/15)\). Since each preparation equals \(M_i/\operatorname{Tr}M_i\), this is exactly the canonical map of the POVM, not just an arbitrary EB realization. Its tensor power \(\Psi_L=\Psi_1^{\otimes L}\) is likewise a canonical EB map.

## Full Pauli-mode operator inequality

Pauli strings diagonalize both tensor-power superoperators. For a Pauli word, write its eigenvalues as \(\lambda_w=\prod_j\lambda_{w_j}\) and \(\mu_w=\prod_j\mu_{w_j}\). The required operator-order inequality is the scalar check

\[
1-\mu_w\le2(1-\lambda_w)
\]

on every Pauli mode; this is Hilbert--Schmidt operator order, not complete positivity order.

If the word contains X or Y, then \(\mu_w=0\) and \(0\le\lambda_w\le1/15\). The slack \(2(1-\lambda_w)-(1-\mu_w)=1-2\lambda_w\) is at least \(13/15\). If the word contains only I and \(k\ge1\) Z factors, then \(\lambda_w=(29/30)^k\), \(\mu_w=(14/15)^k\). Put \(x=14/15\), so \((1+x)/2=29/30\). For \(x_j\in[0,1]\),

\[
\prod_{j=1}^k(1+x_j)\le2^{k-1}\left(1+\prod_{j=1}^kx_j\right).
\]

The base case is equality; the induction step reduces to \((1+p)(1+y)\le2(1+py)\), equivalent to \((1-p)(1-y)\ge0\). Taking every \(x_j=x\) gives \(2(29/30)^k\le1+(14/15)^k\), exactly the desired mode inequality. The all-I mode has equality. A single Z with identity on all other sites also has equality, so the factor 2 is sharp for this family.

Consequently,

\[
I-\Psi_L\preceq2(I-\Phi_L)
\]

on the full Hermitian Hilbert--Schmidt space for every integer \(L\ge1\), without a loss depending on \(L\), the global dimension, or the number of Pauli strings.

## Trace-distance consequence and its boundary

Let \(d=2^L\), \(\tau(X)=\operatorname{Tr}(X)/d\), and \(\rho_H=(I+H)/d\) for \(H=H^*\), \(\tau(H)=0\), and \(\|H\|_\infty\le1/2\). These conditions make \(\rho_H\) a state. Suppose a family has the **uniform** residual bound \(\|\Phi_L(H)-H\|_{1,\tau}\le r\). Put \(D=I-\Psi_L\) and \(G=I-\Phi_L\). Both are positive HS operators, and \(0\preceq D\preceq I\), so \(D^2\preceq D\). Then

\[
\|DH\|_{2,\tau}^2
=\langle H,D^2H\rangle_\tau
\le\langle H,DH\rangle_\tau
\le2\langle H,GH\rangle_\tau
\le2\|H\|_\infty\|H-\Phi_L(H)\|_{1,\tau}
\le r.
\]

Because \(\Psi_L\) is unital,

\[
\tfrac12\|\Psi_L(\rho_H)-\rho_H\|_1
=\tfrac12\|DH\|_{1,\tau}
\le\tfrac12\|DH\|_{2,\tau}
\le\sqrt r/2.
\]

The same map works for any finite or infinite promised family, with no family-size or Holevo term. This is a consequence for tracial perturbations satisfying both the pointwise \(\|H\|_\infty\le1/2\) bound and uniform near-fixedness. A bounded Holevo quantity by itself does not imply either promise; therefore this example is not a general bounded-Holevo theorem.

## Succinct interface and costs

The instrument for \(L\) sites is the tensor product of \(L\) three-outcome local instruments. Its flattened POVM has \(3^L\) outcomes (for \(L=64\), \(3433683820292512484657849089281\)), while its exact description has constant-size local matrices plus the site count. One physical use takes \(O(L)\) local measurements and state preparations, and it preserves the correct outcome correlations on entangled inputs. The global outcome distribution must not be replaced by independent samples from one-site marginals. The succinct cost assumes the channel is supplied in the stated repeated local-factor form; the comparator is not inferred from an opaque dense \(2^L\)-dimensional matrix. Classical simulation of this measurement on a general entangled input is a separate cost and is not established as polynomial here.

The local Liouville descriptor itself has only 16 rows and 4 columns, and its exact rational entries can be checked sitewise. Expanding the global broadcaster or flattening the global POVM would erase the claimed succinctness. The exact product construction avoids that expansion entirely. The accompanying small-instance tree replay is useful diagnostic evidence but is not needed for the symbolic all-\(L\) Pauli-mode proof above.
