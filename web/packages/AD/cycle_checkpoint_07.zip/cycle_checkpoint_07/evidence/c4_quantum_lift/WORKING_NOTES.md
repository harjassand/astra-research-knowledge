# C4 quantum lift attack (working notes)

This branch attacks the common-EB operator comparison for a unital, trace-preserving, Hilbert--Schmidt-self-adjoint, self-compatible channel \(\Phi:M_d\to M_d\): find one bistochastic EB \(\Psi\) with \(I-\Psi\preceq 2(I-\Phi)\), or refute it. The associated bounded-Holevo broadcaster implication is weaker; failure of the factor-two claim alone would not refute it.

## Exact prior boundary re-read

- Cycle-2 quantum lead report: `outputs/research/cycle_checkpoint_02/evidence/quantum_physics/FINAL_REPORT.md`.
- Exact d=2 construction, N92 classes, d=5 line-cover violation with an EB repair: `outputs/research/cycle_checkpoint_02/evidence/quantum_physics/broadcast_lift/REPORT.md`, `D5_AUDIT.md`.
- Finite-family information bound and the capacity/cardinality separation: `outputs/research/cycle_checkpoint_02/evidence/broadcast_information_attack/CYCLE2_REPORT.md`.
- All-frame dual and exact variance interface: `work/agents/broadcast_channel_attack/sources/detailed_balance_broadcast_attack.txt`.

The dimension-free factor-two result is established only for the qubit, prime-d Weyl line-constant, supplied-POVM/Luders, and supplied-instrument/Petz-corrected classes (plus the specified closure operations). Adjacent incompatibility-breaking work does not state the EB Loewner comparison; the October 2026 incompatibility preprint is qubit/dichotomic in scope. The d=5 line-constant peak bound is false but not the comparator: the exhibited channel has a rational EB repair on all 24 Weyl modes. No qualifying bounded-Holevo, vanishing-broadcast-error counterexample is present in the prior record.

## New attack formulation: EB frame cone

Use a real orthonormal basis \(F_i\) of traceless Hermitian operators under \(\tau=\mathrm{Tr}/d\). A canonical self-adjoint EB channel from a pure-state ensemble \(\{w_y,\psi_y\}\), \(\sum_yw_y\psi_y=I/d\), has transfer matrix

\[
S_{ij}=\sum_yw_y\,\mathrm{Tr}(\psi_yF_i)\,\mathrm{Tr}(\psi_yF_j).
\]

Thus the target can be read as finding one pure-state frame covariance \(S\) dominating \(D=2T-I\), where \(T\) is the transfer matrix of \(\Phi\). Convex separation says this is equivalent to an all-frame inequality, not coordinatewise clipping. For a positive dual frame operator \(Q\), the EB support function is

\[
 h_{EB}(Q)=\max_{\{w_y,\psi_y\}:\sum w_y\psi_y=I/d}\sum_yw_y\sum_{ij}Q_{ij}\,\mathrm{Tr}(\psi_yF_i)\mathrm{Tr}(\psi_yF_j).
\]

The missing implication is \(\mathrm{Tr}(QD)\le h_{EB}(Q)\) for every \(Q\succeq0\), from a symmetric Choi extension of \(\Phi\). This clarifies why checking each eigenmode or a fixed MUB cover is insufficient. It also suggests a possible construction: extract a single pure-state ensemble/covariance from the tripartite extension, rather than clipping the spectrum mode by mode. No such construction has been proved here.

A useful normalization check: for the universal 1->2 qudit cloner, \(D\) is isotropic with eigenvalue \(1/(d+1)\), and \(h_{EB}(I)=d-1\); this saturates the full-frame trace budget. The frame-cone condition is stronger than a trace budget, as an isotropic test shows.

## Literature/source search status

Primary-literature searches for a dimension-free antidegradable/self-compatible to EB Loewner comparator did not return a matching theorem. The nearby symmetric-extension hierarchy and fixed-k approximation results are dimension-dependent and have the wrong norm/interface. This is only a bounded search, not novelty clearance.

## Derived finite-dimensional common-EB comparator (proof candidate)

Let \(\Phi:M_d\to M_d\) be unital, trace preserving and HS selfadjoint, with a two-output CPTP extension whose two marginals equal \(\Phi\). Let \(\tau=\operatorname{Tr}/d\), \(\mathcal H_d\) be the real HS space of Hermitian matrices, and \(m=\lceil\log_2(d^2)\rceil\). Iterating the extension on a full binary tree of depth \(m\) gives a CPTP \(K=2^m\)-output channel whose every one-site marginal is \(\Phi^m\).

For any Hermitian \(A=\sum_y a_yP_y\), measure this spectral PVM on one receiver. Its pulled-back input POVM is \(E_y=\Phi^m(P_y)\) (using HS selfadjointness). Since \(\tau(E_y)=\tau(P_y)=p_y\), its canonical EB quadratic score satisfies the exact identity

\[
\sum_y\frac{\tau(E_yA)^2}{p_y}-\bigl(2\langle A,\Phi^m(A)\rangle_\tau-\|A\|_{2,\tau}^2\bigr)
=\sum_y\frac{(\tau(E_yA)-a_yp_y)^2}{p_y}\ge0.
\]

Now take any positive dual frame operator \(Q=\sum_{i=1}^r w_i|A_i\rangle\langle A_i|\) on \(\mathcal H_d\), with \(r\le d^2\). On distinct receivers, measure the spectral PVMs of all \(A_i\) simultaneously (unused receivers get the trivial measurement). The full product measurement pulls back to one input POVM \(M\). Refinement/coarse-graining by any receiver increases the canonical score, so the same canonical EB map \(\Psi_M\) obeys the preceding score inequality for every \(A_i\).

Kadison Schwarz and trace preservation make \(\Phi\) an HS contraction; selfadjointness gives eigenvalues \(\lambda\in[-1,1]\). For nonnegative \(\lambda\), Bernoulli gives \(\lambda^m\ge1-m(1-\lambda)\). For negative \(\lambda\), this is equality at \(m=1\); for \(m\ge2\), the right side is at most \(-1\) and \(\lambda^m\ge-1\). Thus \(\Phi^m\succeq I-m(I-\Phi)\). Therefore this one \(\Psi_M\) gives

\[
\operatorname{Tr}_{HS}Q\bigl(\Psi_M-[I-2m(I-\Phi)]\bigr)\ge0.
\]

This holds for every \(Q\succeq0\), with \(M\) allowed to depend on \(Q\). The finite-dimensional compact convex set of canonical measurement channels is convex (mix POVMs while retaining the coin outcome) and compact by representing POVMs as probability measures on density matrices with barycenter I/d; Caratheodory applied to first and second moments gives a finite-outcome representative. Rank-one refinement changes the canonical channel and is not used for compactness. Positive-cone separation then yields ONE canonical EB channel \(\Psi\) such that

\[
I-\Psi\preceq 2m(I-\Phi),\qquad m=\lceil\log_2(d^2)\rceil.
\]

This is not the desired dimension-free result. Its explicit tree uses \(K-1\) invocations of the supplied broadcaster, \(K<2d^2\) receiver wires (for \(d\ge2\)), and the raw product POVM can have up to \(d^K\) outcomes. Caratheodory gives a finite-outcome representation of the final first and second ensemble moments, but no efficient construction is claimed. The mechanism converts output count to logarithmic Dirichlet loss and fills a finite simultaneous-measurement gap; it does not make the loss independent of the operator-frame rank.

For bounded likelihoods \(\rho_H=(I+H)/d\) with \(\|H\|_\infty\le\theta\), if \(r=\sup_H\|\Phi(H)-H\|_{1,\tau}\), then
\[
\frac12\|\Psi(\rho_H)-\rho_H\|_{1,\tau}
\le \frac12\sqrt{2m\theta r}=\sqrt{m\theta r/2}.
\]
This follows from \((I-\Psi)^2\preceq I-\Psi\) for the canonical EB channel, the comparator, and \(\|X\|_1\le\|X\|_2\). It yields a sufficient condition \(r\log d\to0\), not the bounded-Holevo theorem without a dimension condition.

Potential caveat to audit: the all-frame separation is for the canonical \(\Psi_M\) subclass, which is sufficient for the requested EB comparator. It must not be presented as a characterization of every self-adjoint EB channel. The tree argument itself only needs this sufficient subclass.
