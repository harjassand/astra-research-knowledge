# Active-limit bad-neighborhood component

## Result

`BadNeighborhood.lean` provides a kernel-checked compactness component for the fixed-family affine argument. It imports the shared `N33Affine.AffineCore` definitions and proves:

- `activeLimit_isClosed`: each fixed label's active-limit set is closed. The diagonal chooses a genuine active point from each realizing sequence with both scale and point errors below `1/(n+1)`.
- `badFor_isClosed` and `badLimitSet_isClosed`: the fixed-label, fixed-coordinate violations are closed, as is their finite union over labels and coordinates.
- `badLimitSet_isCompact`: this closed union lies in the compact cube.
- `badLimitSet_excludes_slice`: the supplied `LocalApproximation` guarantee excludes every bad limit on the exact `AtMinSlice`.
- `exists_minimum_coordinate_radius`: there is a positive radius around the minimum-coordinate value `t` containing no bad limits.

The sequence points approximating a limit have type `Fin m → ℝ` and receive no cube restriction. Activity is the imported weak `∀` comparison, so ties remain included. The only appearance of the arbitrary tolerance function in the bad set is the fixed scalar `E (family j).slope`; no continuity of `E` is assumed.

## Integration interface

Main theorem:

```lean
N33Affine.BadNeighborhood.exists_minimum_coordinate_radius
  {ι : Type*} [Finite ι]
  (hm : 0 < m) (a b t : ℝ) (E : (Fin m → ℝ) → ℝ)
  (family : ι → N33Affine.Label m)
  (hSlice : ∀ j, N33Affine.LocalApproximation a b t E family j) :
  ∃ ρ : ℝ, 0 < ρ ∧
    ∀ p, N33Affine.InCube a b p →
      |N33Affine.BadNeighborhood.minCoordinate hm p - t| < ρ →
      p ∉ N33Affine.BadNeighborhood.BadLimitSet a b E family
```

`atMinSlice_iff_minCoordinate_eq` connects the core's `AtMinSlice` predicate to the finite-infimum `minCoordinate`. The theorem assumes the fixed-slice affine approximation result; it does not prove that harder induction. The component formalizes only the closedness, compactness, slice-exclusion, and neighborhood step.

## Validation

Compiled successfully with Lean 4.28.0 against the local compiled Mathlib 4.28.0 cache and the shared `N33Affine.AffineCore` module. The direct compiler exited 0 with no diagnostics; details and captured output are in `COMPILE.log` and `compile.stdout`. `Assumptions.lean` prints the dependencies for each exported theorem; the only reported kernel axioms are Mathlib/Lean's standard `propext`, `Classical.choice`, and `Quot.sound`. No `sorry`, `admit`, or new `axiom` declaration occurs in this component.

This formalization does not validate the mathematical proof of `LocalApproximation`, the later affine induction, or the endotactic permanence theorem. It discharges the assigned topological bridge conditional on the exact shared local-slice interface.
