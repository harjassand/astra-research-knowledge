# Next-type competitor asymptotic helper

## Result

The kernel-checked theorem
`N33Affine.NextTypeAsymptotic.finite_rpow_sum_add_littleO_tendsto_zero`
proves the requested finite-sum asymptotic. Let `ι` be any finite type,
`h : ℕ → ℝ` tend to zero through positive values, and let each exponent
sequence `p i` converge to `p₀ i > q`. For any fixed real coefficients
`c : ι → ℝ` and any `d : ℝ → ℝ` satisfying
`N33Affine.LittleO d q`,

```lean
Tendsto
  (fun n => (∑ i : ι,
    c i * (Real.rpow (h n) (p i n) / Real.rpow (h n) q)) +
    d (h n) / Real.rpow (h n) q)
  atTop (𝓝 0)
```

The coefficients need not be nonnegative; arbitrary fixed real coefficients
work. Each varying exponent sequence is unrestricted at finite indices and
only required to converge to its strict-gap limit. No bound placing its terms
inside the exponent cube is used.

The proof locally establishes the varying-exponent ratio lemma by fixing half
the limiting gap, bounding the ratio between zero and `h^gap` eventually, and
squeezing. It then takes fixed scalar multiples, sums over the finite type,
and composes the `LittleO` limit with `h`.

## Artifacts and validation

- Source: `NextTypeAsymptotic.lean`
- Compiled Lean object: `NextTypeAsymptotic.olean`
- Axiom audit source/output: `NextTypeAssumptions.lean`, `NextTypeAssumptions.stdout`
- Compiler: Lean 4.28.0, using the shared local `N33Affine` project and cached
  mathlib dependencies.
- `lake env lean <absolute path to NextTypeAsymptotic.lean>` from
  `work/agents/c4_rational_hostile/formalization/project/` exited 0 with no
  diagnostics. A direct Lean invocation also emitted the task-local `.olean`.
- `#print axioms` reports only `[propext, Classical.choice, Quot.sound]` for the
  varying-rpow lemma, little-o composition lemma, and exported finite-sum
  theorem. There is no project-specific axiom or `sorry`.

The source imports only `N33Affine.AffineCore` and
`Mathlib.Analysis.SpecialFunctions.Pow.Continuity`; it avoids a full `Mathlib`
umbrella import. For integration from another Lake package, place the file at
`N33Affine/NextTypeAsymptotic.lean` or add this task directory to `LEAN_PATH`
and import the module as `NextTypeAsymptotic`.
