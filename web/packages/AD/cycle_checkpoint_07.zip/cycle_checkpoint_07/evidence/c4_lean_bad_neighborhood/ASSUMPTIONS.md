# Kernel assumption audit

`Assumptions.lean` was compiled with Lean 4.28.0 after the final successful compilation of `BadNeighborhood.lean`. `assumptions.stdout` is the captured `#print axioms` output.

Each of the six exported theorems checked there depends on exactly:

- `propext`
- `Classical.choice`
- `Quot.sound`

There are no `sorryAx` dependencies and no project-defined axioms. Classical choice is used for the finite diagonal selections and finite-family reasoning. `LocalApproximation` remains an explicit theorem premise in the final radius result.
