# C12 immune-dynamics lane: report

## Verdict

This pass did not establish a new biological law. The strongest concrete result is a source-backed measurement/representation audit: the released CD36 rate workflow combines a daughter-pair odds ratio with an ON fraction from separate clone-level data. The same pair table supplies its own marginal; using that instead changes the conditional inferred total switching rate by 24.4%. The distance-based pair rule also leaves the true-sister fraction and matched spatial-background association unmeasured, so the biological rate interpretation remains conditional.

## What is established in this lane

The primary source is a bioRxiv preprint dated 2026-06-19, explicitly marked not peer reviewed. It reports a combination of MemorySeq, single-cell RNA-seq, microscopy, and infection assays. The manuscript's model is a two-state branching process with equal state growth, ON/OFF transitions, optional population-size-dependent `k_on`, and a clone-random `k_on,max`. It reports long-lived CD36-like variation, transient IL1β-like response, and infection association in the tested macrophage system. Those are preprint claims, not new claims produced here.

The exact released Rmd selects `CD36_Mock` pairs from the pair-count workbook, computes their OR, then sets `FractionON` to the unweighted mean of a separate 1,108-clone workbook. In the selectively extracted public inputs, the pair table has 57 ON/ON, 471 OFF/OFF, and 38 mixed pairs: `f_pair=0.134276`, `OR=74.3684`; the script fraction is 0.216803. Holding OR fixed, `k_on+k_off` changes from 0.015706 to 0.019544 h^-1 under the same stated inversion. See `proof/rate_input_marginal_mismatch.md`. In addition, the Methods select endpoint pairs by centroid proximity (not reported lineage tracking), and the simulation uses clone size in place of directly measured local-neighbor histories while clone size also grows with time. The full 2.5-GB archive was not downloaded; only two small model workbooks were range-fetched and CRC-checked, so no full bootstrap/optimization or image-level reproduction was performed.

Two conditional model/data results are documented: a routine mean-fraction lag identity and the pair-contamination sensitivity. The strongest audit result is the observed workflow mismatch above; it is still not a biological discovery, and its interpretation depends on what the authors intended `f_ON` to estimate.

## Strongest next gate

First resolve `f_ON` from the same source pair cohort and retain the joint bootstrap; then track a subset through division, measure how often the endpoint proximity rule selects true sisters, and estimate matched unrelated-neighbor association. Use those data to correct or bound rates. In the same experiment, independently vary local density and elapsed time within clones, comparing density, clock-only, and clone-competence models on held-out clones/plates. The full acquisition, confound, cost, and falsifier specification is in `experiment/DECISIVE_TEST.md`.

The separate 2026 T-cell ERK-affinity paper is a plausible dynamic-receptor mechanism: the abstract reports LCK-linked frequency and MEK-linked amplitude control. Publisher access returned HTTP 403, so this pass lacks methods, raw trajectories, and an equal-information baseline; it is not advanced as a result.

## Recovery and continuation

No C11 immune-dynamics task or artifact was present in the current directive, expected folder inventory, or inspected task list. This folder restores only the mandate stated by the parent; it does not invent prior progress. Read `RESTART.md` first to continue. Global gate bookkeeping remains with the root agent.
