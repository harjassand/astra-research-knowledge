# Decisive test: local-density feedback versus clock and clone competence

## Question

Does local neighbor density causally alter CD36-positive-state entry in a way that is separable from elapsed culture time and stable clone-to-clone competence, and are the endpoint-image pairs used to infer transition rates true sisters? The motivating evidence is the 2026 macrophage preprint, not a claim of settled mechanism.

## Acquired interface

For each cell at assay time, acquire its clone identity, well/plate, elapsed time since seeding, local neighbor count in the same approximately 30-μm radius used by the source, total clone size, single-cell CD36 intensity/positive status, lineage identity through division, and viability/morphology covariates. Compare tracked sister pairs with the preprint's one-frame proximity rule (≤30 pixels and ≥120 pixels from a third cell) and with matched unrelated neighbors. In a time course, image the same fields at fixed intervals; at minimum record endpoint status at two or more times. A separately measured NF-κB/TLR4 response marker can be retained as a secondary output, not substituted for CD36.

## Factorial design and matched-information controls

Randomize cells from each of the same source clones across a crossed `density × elapsed-time` design. Vary local packing independently of time using controlled starting numbers and fixed-area wells; retain conditions with the same final local density but different elapsed times, and the same elapsed time but different local densities. Use matched medium volume, lipid A exposure, plate position, conditioned-medium fraction, staining threshold, acquisition cadence, segmentation pipeline, and blinded cell inclusion. Track a subset of fields through cell division with a nuclear marker and low-light acquisition, then apply the original endpoint proximity rule to the same cells to estimate its true-sister fraction and background association. Record any density-induced differences in nutrient depletion, pH, viability, morphology, and cell-cycle state as measured covariates; do not silently assign these effects to receptor signalling.

Compare three preregistered models using the same measured inputs, clone random effects, plate effects, train/test split, and observation likelihood:

1. **Density model:** OFF→ON hazard depends on local neighbor count (with a prespecified saturating curve); OFF→ON and ON→OFF history is retained.
2. **Clock-only control:** the hazard depends on elapsed time and the same clone/plate terms but not local neighbors.
3. **Clone-competence control:** the hazard depends on a clone-specific random effect but no local-neighbor term; include the clock covariate as in the density model.

Fit on a subset of clones and plates, then score held-out clones and plates. Do not use an unobserved latent state or future measurements as an oracle. The inputs are measured local neighbor count, time, clone, and past CD36 observations only. If tracking is unavailable, use destructive matched wells and clearly charge the extra well/cell sampling required.

For transition-rate inference, publish the full pair-state table for each of the three pair classes. Compare the uncorrected proximity-pair rate estimate with a correction using the measured positive predictive value of the proximity rule and the matched unrelated-neighbor baseline; perform correction and rate inference jointly by clone/plate bootstrap.

First run a no-new-acquisition comparison on the existing pair tables: (a) the released Rmd estimator using the separate clone-level mean `FractionON`; (b) a same-cohort estimator using the pair-table cell marginal and pair OR from the same plates, bootstrapped jointly; and (c) after lineage tracking, a true-sister estimator with matched-neighbor correction. Keep the clone-level fraction as its own response summary; do not treat it as interchangeable with the pair-cohort marginal without a validated bridge. The first two conditions consume the same existing observations, while condition (c) must charge tracking time and pair-purity uncertainty.

## Resource and noise accounting

Charge: independent clone derivation and expansion; number of density/time/plate conditions; cells and wells per condition; antibody/reagent and image-acquisition time; frame cadence, duration, and illumination dose for lineage tracking; segmentation/neighbor-count compute; failed/ambiguous lineage and segmentation rates; plate-to-plate threshold uncertainty; cell loss, viability and growth differences; and the extra sampling needed for held-out clones. Use the preprint's reported microscopy scale (thousands of clonal populations across roughly ten generations) only as a feasibility anchor, not as a cost estimate for this new factorial. The public external archive is about 2.5 GB; full reanalysis input acquisition is not free.

## Falsifier

The density-feedback interpretation fails if, on held-out clones/plates, the density term adds no calibrated predictive value over the matched clock-only and clone-competence controls, or if its coefficient collapses after time, clone, viability, and morphology are included. A particularly direct falsifier is equal CD36 response at matched elapsed time across manipulated local densities, combined with different responses at matched density across elapsed times. The sister-rate interpretation fails if proximity-selected pairs have low or unstable true-sister positive predictive value, or their pair-state table is explained by the matched unrelated-neighbor baseline; a material corrected-versus-uncorrected rate shift would show the current rate estimate depends on pair purity.

## Decision threshold

Advance only if the density model improves held-out predictive log score beyond its uncertainty, predicts direction and saturation without refitting on held-out data, and survives a second independent plate/clone cohort. Even then the result would establish an in-vitro density-linked causal model in the tested macrophage line, not an in-vivo immune-control law. A stronger mechanism claim would additionally require identifying the intervening signal and testing a pathway-specific perturbation with matched toxicity and growth controls.
