# C12 source ledger

## Primary source: macrophage immune-state heterogeneity

Redondo et al., “Heritable single-cell gene expression states shape functional variability in innate immune responses,” bioRxiv preprint v1, 2026-06-19, DOI [10.64898/2026.06.17.732820](https://doi.org/10.64898/2026.06.17.732820). The PMC landing page states that this is a preprint and has not been peer reviewed: <https://pmc.ncbi.nlm.nih.gov/articles/PMC13307960/>.

The preprint reports RNA-seq fluctuation assays in immortalised murine bone-marrow-derived macrophages, protein imaging of IL1β/CD36 across clones and mixed populations, and infection assays with *Listeria monocytogenes*. It reports >25-division RNA state persistence for a subset of TLR4-dependent genes; density-reinforced CD36 and transient IL1β; clone-size/local-neighbourhood associations; and a two-state branching-process model with constant, size-dependent, and clone-heterogeneous transition rates. These are source-reported findings, not independent validation by this lane.

Exact model interface given in the Methods: each cell changes OFF→ON at `k_on` and ON→OFF at `k_off`, and proliferates at shared rate `lambda`; `f_ON=k_on/(k_on+k_off)` and sister-pair odds ratio `OR=(k_on+lambda)(k_off+lambda)/(k_on*k_off)` are used to infer switching rates. The size-dependent model uses a Hill function for `k_on(N)`; its third model samples clone-level `k_on,max` from a Beta distribution. This lane does not certify that the experimental proximity-pairs are true tracked sisters or that clone size equals local density.

Methods specify the pair acquisition as scanning Euclidean distances between cell nuclear centroids in an endpoint image: a pair is two nuclei within 30 pixels, at least 120 pixels away from the nearest third cell; pixel size is 0.598 μm. The method does not report lineage tracking for these pairs. Therefore “sister pair” rate inference relies on a proximity proxy; the rate bias under independent-neighbor contamination is derived in `proof/proximity_pair_rate_bias.md`. This is a measurement assumption, not proof of misclassification.

## Data and implementation

- BioImage Archive study: [S-BIAD2517](https://www.ebi.ac.uk/biostudies/bioimages/studies/S-BIAD2517), DOI 10.6019/S-BIAD2517. The API reports 19,653 file records and one `external_data.zip` of 2,496,119,118 bytes. The two small model-input workbooks were selectively range-fetched and CRC-checked; the full archive, large sequencing workbooks, image data, and complete external input set were not downloaded. Details: `data/README.md`.
- Public scripts: [macrophage-heritability GitHub repository](https://github.com/cellbiologyppaszek/macrophage-heritability), inspected at commit `7451dbc91d2584d42b1ab11c68ee7170ad8b297d`.
- Script-level diagnostics and the workbook marginal-input audit are recorded in `FAILURES.md` and `proof/rate_input_marginal_mismatch.md`; calculations are reproducible from `analysis/`.

## Primary source: T-cell receptor dynamic signalling (limited access)

Dunlock & Regot, “Antigen affinity modulates ERK pulsing frequency during T cell activation,” *Science Signaling* 19(920), eadw3709 (2026-01-13), DOI [10.1126/scisignal.adw3709](https://doi.org/10.1126/scisignal.adw3709). Primary abstract at [PubMed](https://pubmed.ncbi.nlm.nih.gov/41529098/). The abstract reports intermediate-affinity-induced ERK pulses, cumulative ERK association with activation, LCK-dependent pulse frequency, MEK-dependent amplitude, and distinct MLK/RAF contributions to LAT condensate promotion/sustainment. The publisher full text returned HTTP 403 during this audit; no methods, parameter values, raw data, or source code were reconstructed. Treat it only as a candidate mechanism until those are accessed.

## Existing immunology prior art / closed routes

- Dai et al., “Tracing back primed resistance in cancer via sister cells,” *Nature Communications* 15, 1158 (2024), DOI [10.1038/s41467-024-45478-7](https://doi.org/10.1038/s41467-024-45478-7), [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC10850087/). This primary paper uses uniquely barcoded lineages and shared labels after one division to identify sister cells; it validates that lineage-resolved sister measurements are feasible in a different assay. It establishes prior art for lineage-based cell-state analysis, so C12's contribution is only the macrophage-workflow-specific audit and sensitivity, not the general idea of tracking sisters.

- C7 B-cell adaptive mechanical proofreading and membrane-mobility confounds: `work/agents/c7_immunology_discrimination/CLAIMS.json`, with source links in that file. Do not relabel the published mechanism as a discovery.
- Standard immune-memory CTMC/exponential-mixture observability: `work/agents/immunology/immune_memory/CLAIMS.json`; already conditional and not a new result.
- Nutrient T-cell combo remains untested with leakage/cost unresolved per parent mandate; no re-analysis was attempted.
- Restricted RNA kinetic-barcode branch was not retried.
