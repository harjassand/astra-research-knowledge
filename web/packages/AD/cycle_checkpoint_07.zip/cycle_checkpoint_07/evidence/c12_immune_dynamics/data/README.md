# Selectively extracted public model inputs

Source archive: [BioImage Archive S-BIAD2517](https://www.ebi.ac.uk/biostudies/bioimages/studies/S-BIAD2517), direct ZIP `https://ftp.ebi.ac.uk/biostudies/fire/S-BIAD/517/S-BIAD2517/Files/external_data.zip`.

The archive is 2,496,119,118 bytes, ETag `"94c7c14e-6546fda219180"`. It advertises HTTP byte-range support. The final 8 MiB (`bytes 2487730510-2496119117`) was read to inspect the ZIP central directory. Only the following two small workbook payloads were then range-fetched and extracted from their ZIP entries; the full archive was not downloaded. ZIP central-directory records: method 8 (deflate), CRCs below; the extracted payload sizes and CRCs were checked against the local ZIP headers.

| File | ZIP path | Local ZIP header offset | Compressed bytes | Extracted bytes | CRC32 |
|---|---|---:|---:|---:|---|
| `IL1 and CD36 fractions repository.xlsx` | `external/excel_inputs/IL1 and CD36 fractions repository.xlsx` | 91 | 59,027 | 61,835 | `8b6a2537` |
| `odds_ratio_CD36_tnfa_il1b.xlsx` | `external/excel_inputs/odds_ratio_CD36_tnfa_il1b.xlsx` | 59,208 | 8,501 | 10,973 | `ead3cbb3` |

SHA-256: `fa7e23bbab399cb584b3efa849b3f863ad0d5b1fc8b517dba5dba8282e208b32` for the fractions workbook; `f52f0e9101a42accb92f2c49af5eae09fc78f393e67b28810e17d490179fad4f` for the odds-ratio workbook.

Recompute the model-input audit with `analysis/pair_rate_interface_audit.R` using R packages `readxl` and `dplyr`, or `analysis/pair_rate_interface_audit.py` using Python package `openpyxl`. The values support only the source-code/workbook comparison in `proof/rate_input_marginal_mismatch.md`; they do not reproduce the full manuscript or validate its biological claims.
