# C12 immune-dynamics lane: restart record

## Mandate

Search for a defensible new result in dynamic antigen/receptor signalling or population immune-state control, using 2025/26 primary mechanisms to identify a real measurement, representation, or control bottleneck. A useful result must state the acquired interface, assumptions, quantitative claim, baseline with equal information, all relevant observation/computation costs, and a falsifier. Do not turn a conditional standard model into a biological discovery.

Explicit exclusions: do not reopen the B-cell force/Fmax hidden-dose line, the untested nutrient T-cell combo, or the restricted RNA kinetic-barcode branch. No external messages, publishing, medical advice, or wet-lab actions.

## Recovery of the lost C11 work

The current C11 directive has no immune-dynamics task. The workspace has C11 folders for evolution control, biomolecular measurement, and engineering metrology, but no C11 immune folder or artifacts. The task list was checked and contained no identifiable C11 immune task. The parent prompt is therefore the only recoverable statement of this lane; no missing C11 result or approval is inferred. This directory records the restored work as C12.

## Read order and inherited constraints

1. `work/ROOT_MANDATE.txt`
2. `outputs/research/CURRENT_STATE.txt`, `outputs/research/ACTIVE_GATES.json`, `work/CYCLE11_DIRECTIVE.txt`
3. `work/astra_prior/00_START_HERE.txt`, `work/astra_prior/01_CORE.txt`
4. Existing immunology evidence: `work/agents/c7_immunology_discrimination/CLAIMS.json`, `work/agents/immunology/CLAIMS.json`, and `work/agents/immunology/immune_memory/`

The older gates already reject kinetic-proofreading folklore, standard two-state CTMC/Prony identifiability, and unsupported biological transfer. The C7 B-cell mechanical claim is published prior art and dose-sensitive. The immune-memory card is a standard-model reduction, not evidence of a new biological state.

## Work completed

- Audited the 2026 macrophage transcriptional-heritability preprint, its mathematical-model section, public scripts, and BioImage Archive manifest metadata.
- Reconstructed a conditional mean-field relation for the paper's equal-growth, two-state switching model and quantified the lag between the simulated fraction and instantaneous equilibrium.
- Selectively range-extracted and CRC-checked the two small public model workbooks (without downloading the 2.5-GB archive); audited the public parameter-optimization script and the rate-estimation Rmd for input mismatch, growth-rate inconsistency, and nearest-neighbour matching.
- Recomputed the CD36 Mock pair marginal and pair OR from the original workbook, then propagated the public script's clone-mean and the same-pair marginal through the stated rate inversion.
- Reviewed the 2026 T-cell ERK-pulsing paper at the PubMed abstract level; full primary article access was blocked, so no methods-level reconstruction is claimed.
- Designed one decisive crossed density/time/clone test that separates the most relevant alternatives with matched measurement and cost accounting.

## Current state

No genuinely new scientific advance has been established. The strongest defensible output is a scoped model/data audit and a falsifiable follow-up design. See `FINAL_REPORT.md`, `CLAIMS.json`, `proof/`, and `experiment/` before doing further work.

## Next gate

Do not optimize or generalize the model. First obtain a smaller, directly addressable input or table sufficient to reproduce the clone-size/CD36 analysis; then preregister a held-out-clone test that independently varies local density and elapsed time. Keep the 2026 ERK branch closed until full methods, raw trajectories, and same-information controls can be inspected.
