# Public CD36 rate workflow: marginal fraction and pair-OR inputs

## Finding

The public `Constant_Switching_Rates_Calculation.Rmd` computes the pair odds ratio from the CD36 Mock daughter-pair table (`CD36_Mock <- ... datasets$dataset5`, lines 82 and 108–119), but computes `FractionON` as the unweighted mean of a separate clone-level spreadsheet (`CD36_Mock_fraction`, lines 101 and 117). The source Methods give `f_ON=k_ON/(k_ON+k_OFF)` and the daughter-pair OR relation, but the inspected R workflow does not use the ON marginal of its own pair table.

If `f_ON` is meant to be the single-cell marginal corresponding to that pair table, this is an unexplained sample/interface mismatch. The alternative would require a model statement establishing why the unweighted mean over a different set of 1,108 clones equals the marginal for the mixed-population pair cohort; no such bridge is given in the inspected calculation script. This is a scoped code/workbook observation, not proof that every parameter reported in the preprint used this exact script or that the experimental biology is wrong.

## Reconstructed inputs

The small public inputs were extracted from the BioImage Archive's 2,496,119,118-byte `external_data.zip` by HTTP byte ranges, verified against local ZIP CRCs, and stored in `data/`. No full archive or large sequencing workbook was downloaded. Provenance and exact ranges are recorded in `data/README.md`.

For `per_cd36_intensity_80_mean / Mock`, the workbook gives four plate rows:

| Plate | ON/ON | OFF/OFF | Mixed | Pairs | Paired-cell marginal | Pair OR |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 5 | 70 | 3 | 78 | 0.08333 | 155.56 |
| 2 | 6 | 154 | 8 | 168 | 0.05952 | 57.75 |
| 3 | 23 | 162 | 14 | 199 | 0.15075 | 76.04 |
| 4 | 23 | 85 | 13 | 121 | 0.24380 | 46.27 |
| **Pooled** | **57** | **471** | **38** | **566** | **0.13428** | **74.37** |

The paired-cell marginal is `(2*ON_ON + Mixed)/(2*Pairs) = 152/1132 = 0.1342756`. The public R workflow's separate clone-fraction sheet contains 1,108 numeric rows; after the script's `1e-4` clipping, their unweighted mean is `0.2168029`. Weighting those clone fractions by cell count would give `0.3200990`, another different estimand.

## Propagated conditional effect

Hold the pooled pair OR fixed at `74.368421`, use `lambda=ln(2)/14.4 h^-1`, and invert the published relation

```text
OR - 1 = lambda/[f(1-f)m] + lambda^2/[f(1-f)m^2],
m=k_on+k_off.
```

With the R-script clone mean `f=0.2168029`, the inversion gives `k_on=0.0034051 h^-1`, `k_off=0.0123007 h^-1`, `m=0.0157057 h^-1` and `1/m=63.67 h`. With the paired-table marginal `f=0.1342756`, it gives `k_on=0.0026243 h^-1`, `k_off=0.0169198 h^-1`, `m=0.0195441 h^-1` and `1/m=51.17 h`. Thus the choice of marginal shifts the inferred total rate by 24.4% and changes the split between ON/OFF rates. This calculation isolates the `f` input; it is not a replay of the Rmd bootstrap and does not correct the separate proximity-pair purity issue.

## Bootstrap and control implications

The Rmd independently resamples pair rows for the OR and clone-fraction rows for `FractionON`, then solves using the two bootstrap means. If the intended `f` is the pair marginal, both statistics should be derived from the same pair tables and their joint uncertainty retained. If the intended `f` is a clone-level latent or stationary estimand, the mapping to the paired mixed-population marginal must be stated and validated. The stronger acquisition is to time-lapse track true sisters and compute the full 2×2 table, including the same-cell marginal, while also reporting matched unrelated-neighbor tables. `proof/proximity_pair_rate_bias.md` gives the conditional purity correction.

The workbook extraction and calculation are reproduced in both `analysis/pair_rate_interface_audit.py` (requires `openpyxl`) and `analysis/pair_rate_interface_audit.R` (replays the public Rmd parsing with `readxl`/`dplyr`, then uses the algebraic inverse instead of the unavailable `BB` package). The R replay returns the same pair rows, fraction means, OR, and rate values. Both use only the two small local workbooks.
