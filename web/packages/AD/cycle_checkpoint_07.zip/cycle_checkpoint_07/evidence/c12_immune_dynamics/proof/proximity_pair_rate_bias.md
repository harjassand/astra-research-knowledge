# Proximity-selected pairs and switching-rate inference

## Claim and boundary

The macrophage preprint describes its rate-estimation observations as daughter-cell pairs, but its Methods identify pairs in mixed populations by a one-time-point centroid-distance rule (maximum 30 pixels, at least 120 pixels from the nearest third cell; pixel size 0.598 μm). This note quantifies what happens if that operational pair set contains unrelated, conditionally independent neighbors. It does not show that any particular reported pair was misclassified; the true-pair fraction is not supplied by the distance rule alone.

## Pair-table parameterization

Assume exchangeable binary states with marginal ON probability `f`. Let `u=P(ON,OFF)=P(OFF,ON)` be the probability of either one mixed orientation, `a=P(ON,ON)=f-u`, and `b=P(OFF,OFF)=1-f-u`. The total mixed-pair probability is `2u`. The paper's definition therefore gives

```text
OR = 4 a b / (2u)^2
   = a b / u^2
   = (f-u)(1-f-u)/u^2
   = 1 + (f(1-f)-u)/u^2.
```

Write `c=f(1-f)`. Independence gives `u0=c` and `OR=1`. Positive sister-state association gives `0≤u_s≤c`, hence `OR_s≥1`.

If a proportion `ρ` of the measured pairs are true sisters and the remaining pairs are conditionally independent neighbors with the same marginal `f`, then

```text
u_obs = ρ u_s + (1-ρ)c.
```

Thus `u_s≤u_obs≤c` and `1≤OR_obs≤OR_s`. With unknown `ρ`, the true-sister odds ratio is not point-identified from `(f, OR_obs)`; a continuum of `(ρ, OR_s)` can produce the same observed table.

## Bias in inferred transition rates

The source's assumed sister-pair model gives

```text
f = k_on/(k_on+k_off),
OR_s = ((k_on+lambda)(k_off+lambda))/(k_on k_off).
```

Let `m=k_on+k_off` and `c=f(1-f)`. Substitution yields

```text
OR_s - 1 = lambda/(c m) + lambda^2/(c m^2),
m(OR) = 2 lambda / (sqrt(1+4 c (OR-1)) - 1),  OR>1.
```

`m(OR)` strictly decreases as `OR` increases. Under the independent-neighbor contamination model above, fitting `OR_obs` as if every pair were a sister pair gives `m_hat=m(OR_obs)≥m(OR_s)=m_true`, so the inferred relaxation time `1/m_hat` is no greater than the true-sister relaxation time. This direction is conditional on matched independent background pairs. If unrelated neighbors share local cues and have `OR_bg>1`, the bound need not hold without a matched spatial-background control.

If `ρ` is measured, convert an OR to the per-orientation disagreement probability by

```text
u(OR) = (sqrt(1+4 c (OR-1))-1)/(2(OR-1)),  OR>1,
u(1)=c.
```

Then `u_s=[u(OR_obs)-(1-ρ)c]/ρ`, followed by `OR_s=1+(c-u_s)/u_s^2` and the rate inversion above. Values outside `0≤u_s≤c` falsify the assumed mixture model or indicate measurement/threshold problems. In practice the full contingency counts, clone/plate structure, and their uncertainty should be fitted jointly rather than correcting a point estimate.

For an algebra check only, take `f=0.5`, observed `OR=4`, and assumed `ρ=0.5`. The inferred observed per-orientation mixed probability is `u_obs=1/6`; the corrected sister value is `u_s=1/12`, hence `OR_s=25`. With the source's 14.4-hour doubling rate (`lambda=ln(2)/14.4 h^-1`), the uncorrected rate sum is `0.09627 h^-1`, while the corrected one is `0.02407 h^-1`, exactly fourfold lower. This is a synthetic sensitivity example, not an estimate from the macrophage data.

## Decisive acquisition

Track cells through division and label true sisters; then apply the original proximity rule to the same field. This directly estimates the positive predictive value `ρ` of the rule and the within-field background pair table. A held-out comparison should include: tracked sisters; proximity-selected candidates; unrelated matched-distance neighbors; and pairs matched by clone, plate, time, local density, and staining threshold. Preserve the source's state thresholds and report the complete 2×2 tables, not only an odds ratio. The design, cost ledger, and falsifier are in `experiment/DECISIVE_TEST.md`.

## Status

Lineage-resolved sister-state measurement is established prior art (for example, barcode-based ReSisTrace in ovarian cancer cells; see `SOURCES.md`). The result here is only an internally derived, conditional sensitivity tied to the macrophage preprint's endpoint proximity rule. It is not a new biological law or a result that the source estimates are wrong. The key unresolved observable is `ρ` (plus the matched background dependence); without it the rate interpretation remains conditional.
