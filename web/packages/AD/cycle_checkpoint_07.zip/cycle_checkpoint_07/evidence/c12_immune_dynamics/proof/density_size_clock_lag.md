# Density/size-driven two-state model: conditional mean and lag

## Claim and scope

This note derives a conditional mean-field relation for the model class used in the macrophage preprint. It is a standard-model audit, not a new theorem about macrophages. The assumptions are: ON and OFF cells have the same per-cell birth rate `lambda`; birth produces a same-state daughter; there is no state-dependent death; conditional on the total-size path `N(t)`, OFF→ON and ON→OFF rates per cell are respectively `a(N(t))` and `b>0`; `F(t)` is the fraction ON. No claim is made that a clone's total size is its true local cell density or that these assumptions describe nature.

## First-moment equation

Write `N_ON = n1`, `N_OFF = n0`, `N=n0+n1`, and `F=n1/N`. For a birth of an ON cell, `F` increases by `(1-F)/(N+1)`; for a birth of an OFF cell, it decreases by `F/(N+1)`. Their conditional drift contributions cancel because the two birth rates are both `lambda` times their state counts. OFF→ON transitions have rate `a(N)N(1-F)` and increment `F` by `1/N`; ON→OFF transitions have rate `bNF` and decrement it by `1/N`. Thus the conditional drift is

```text
E[dF | F,N]/dt = a(N)(1-F) - bF.
```

For a deterministic size path, or for the conditional expectation given the full size path, the mean `p(t)=E[F(t)|N(·)]` solves

```text
p'(t) = a(N(t))(1-p(t)) - b p(t)
       = r(t)(q(t)-p(t)),
r(t) = a(N(t))+b,       q(t)=a(N(t))/(a(N(t))+b).
```

Let `R(t)=∫_0^t r(u)du`. Direct integration gives

```text
q(t)-p(t) = exp(-R(t)) (q(0)-p(0))
             + ∫_0^t exp(-(R(t)-R(s))) q'(s) ds.
```

Therefore if `q` is nondecreasing and `p(0)≤q(0)`, then `p(t)≤q(t)` for every later time. The discrepancy is an explicit, rate-weighted history lag; it vanishes only in an appropriate fast-relaxation limit. If `p(0)>q(0)`, the inequality need not hold initially, though the formula still applies.

For the preprint's Hill form `a(N)=a_min+(a_max-a_min)N^n/(K^n+N^n)` with `a_max≥a_min`, fixed `b`, and an increasing `N(t)`, `q(N)` is increasing. This establishes a useful prediction for the model, but it is not independent biological evidence.

## Numerical check

`analysis/density_switching_lag.py` integrates this conditional mean with an exact constant-rate update on a 0.001-hour grid and deterministic `N(t)=exp(lambda*t)` (`lambda=ln(2)/14.4 h^-1`, `N(0)=1`, `T=144 h`). For the public fixed-kmax diagnostic parameters (`a_min=0.001622386`, `a_max=0.01707356`, `K=2^6.4`, `n=3`, `b=0.02277356`, `p(0)=0.075`), it yields `N(T)=1024`, `p(T)≈0.378706`, and the instantaneous equilibrium `q(N(T))≈0.428352`. The initial value is slightly above `q(1)`, so the theorem's global upper-bound premise is not satisfied in this fixed-kmax case; the endpoint is simply a numerical lag calculation.

For a mean-parameter plug-in of the preprint's Beta-kmax model (`a_min=0.000672175`, `E[a_max]=0.0369818453`, `K=77.41251557`, `n=8.648981295`, `b=0.028`, `p(0)=0.003`), it yields `p(T)≈0.552036` versus `q(N(T))≈0.569110`. Here `p(0)<q(1)` and the bound applies. This is a plug-in calculation, not the mean over the stated Beta distribution and not a reproduction of the stochastic model.

## Interpretation / missing bridge

The preprint's Gillespie simulation uses `N` in `a(N)`, while the imaging analysis separately measures local neighbors within about 30 μm. Since total clone size also increases over elapsed culture time, `a(N)` can represent density feedback, a time-programmed switch, or a proxy for another growth-correlated exposure unless the experimental design independently varies those quantities. The preprint reports local-density regressions, but the clone-wide Gillespie model does not explicitly simulate spatial neighbors, conditioned medium, or paracrine transport.

The exact discrimination is not “does a Hill curve fit?” It is whether a rate depending on local neighbor count predicts held-out clone trajectories after controlling elapsed time and clone identity, and whether an equally informed clock-only model fails on the same data. See `experiment/DECISIVE_TEST.md`.
