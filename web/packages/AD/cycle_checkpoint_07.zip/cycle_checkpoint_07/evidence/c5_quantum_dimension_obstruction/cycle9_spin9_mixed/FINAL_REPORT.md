# Cycle 9: all-mixed Spin(9) spinor comparison

## Result

For the complexified 16-dimensional real spinor representation of Spin(9), the covariant all-grade comparison closes for arbitrary nonnegative mixed weights. If a Spin(9)-covariant, unital, trace-preserving, Hilbert--Schmidt-self-adjoint channel \(\Phi:M_{16}\to M_{16}\) has a two-output CPTP extension with both marginals equal to \(\Phi\), then there is one full-domain canonical entanglement-breaking channel \(\Psi\) such that

\[
\Psi- (2\Phi-\mathrm{id})\succeq 0
\]

as an operator on the real Hilbert space of Hermitian matrices. “One” means a single channel on the entire matrix algebra, not a separate state witness or a sector-by-sector choice. The proof reduces arbitrary positive duals to four invariant sector weights, computes the exact canonical-EB support, and checks the full ordinary-tensor three-copy star in both output-swap sectors.

This closes a structured covariant class only. The unrestricted dimension-free common-EB comparison, noncovariant channels, other irreducible representations, and the bounded-Holevo/vanishing-broadcast-error implication remain **UNKNOWN**. No novelty or priority claim is made.

## Proof route

The Hermitian operator space decomposes multiplicity-free into Clifford grades \(k=0,1,2,3,4\), with dimensions \(1,9,36,84,126\). For a pure spinor seed, its four nontrivial squared sector moments are parameterized by \(p,t\in[0,1]\):

\[
(s_1,s_2,s_3,s_4)=
(1-p)(1-t)v_H+(1-p)t v_V+p v_R,
\]

where \(v_H=(0,1,7,7)\), \(v_V=(1,4,4,6)\), and \(v_R=(1,0,0,14)\). Every point of this triangle is attained by an explicit pure seed. For a nonnegative invariant dual \(Q=\sum_{k=1}^4\alpha_k\Pi_k\), the score support over full-domain canonical EB channels is

\[
S_{\rm can}(Q)=\max\{\alpha_1+14\alpha_4,\;\alpha_2+7\alpha_3+7\alpha_4,\;
\alpha_1+4\alpha_2+4\alpha_3+6\alpha_4\}.
\]

The three vertices are attained by full-domain Spin(9)-orbit POVMs. For higher-rank canonical effects, convexity of the squared expectation bounds their score by the pure-seed maximum. This is a support statement; it does not assert that every canonical EB transfer vector lies in the pure-seed triangle.

For the compatibility side, define the ordinary-tensor star

\[
H_Q=\sum_{k=1}^4\alpha_k\sum_{|A|=k}
T_A^T\otimes(T_A\otimes I+I\otimes T_A).
\]

With \(\tau=\operatorname{Tr}/16\), a normalized Choi state of a broadcaster with marginal \(\Phi\) has star expectation \(2\,\operatorname{Score}_Q(\Phi)\). The desired support inequality is

\[
\lambda_{\max}(H_Q)\leq
9\alpha_1+36\alpha_2+84\alpha_3+126\alpha_4+S_{\rm can}(Q).
\]

The three linear pieces of \(S_{\rm can}\) partition \(\mathbb R_+^4\) into pointed cones. Exact rational active-facet enumeration gives 6, 6, and 7 extreme rays (10 distinct rays total). The full \(16\otimes16\otimes16\) star is decomposed into five Spin(9) irreducibles with multiplicities \(5,4,3,2,1\), then split by output swap. All nine resulting multiplicity blocks are retained, including the antisymmetric-output blocks. At every one of the ten cone rays, the exact principal minors of every support-gap block are nonnegative. Linearity extends PSD from the rays to every mixed weight in each cone.

For any compatible \(\Phi\), this gives the positive-dual inequality \(\operatorname{Score}_Q(\Phi)\leq(\operatorname{Tr}_{HS}Q+S_{\rm can}(Q))/2\). Covariance lets an arbitrary positive dual be twirled without changing its score, and twirling cannot increase canonical-EB support. Write \(d_k=\binom9k\), let \(\lambda_k\) be the four sector transfers of \(\Phi\), and set \(w_k=d_k\alpha_k\). The star bound becomes \(w\cdot(2\lambda-\mathbf1)\leq\max_i w\cdot\eta_i\) for every \(w\geq0\), where \((\eta_i)_k=(v_i)_k/d_k\). Convex separation gives one convex combination of these three \(\eta_i\) that dominates \(2\lambda-\mathbf1\) coordinatewise. The matching comparator is the same convex mixture of the three full-domain orbit POVM channels, so it is a single canonical EB map on the entire input space.

The star acts on the complete ordinary tensor product. The argument does not impose Bose support: a symmetric broadcaster can be swap-invariant while its Choi state has antisymmetric-output support. No “top eigenstate is symmetric” premise is used.

## Exact evidence and costs

The proof and exact orbit calculation are documented in [SPIN9_SUPPORT_POLYTOPE.md](SPIN9_SUPPORT_POLYTOPE.md) and [pure_orbits.md](pure_orbits.md). The block matrices and decomposition are in [star_blocks.md](star_blocks.md). The exact checker is [spin9_fullstar_blocks.py](spin9_fullstar_blocks.py), its full matrix/principal-minor certificate is [spin9_fullstar_certificate.json](spin9_fullstar_certificate.json), and the run record is [spin9_fullstar_blocks_run.txt](spin9_fullstar_blocks_run.txt). The independent cone enumerator is [enumerate_support_cone_rays.py](enumerate_support_cone_rays.py), with output in [SUPPORT_CONE_RAYS_OUTPUT.txt](SUPPORT_CONE_RAYS_OUTPUT.txt). The grade-three octonionic count is independently replayed over integer matrices in [check_octonion_grade3.py](check_octonion_grade3.py), with [captured output](OCTONION_GRADE3_OUTPUT.txt).

The replay uses SymPy exact arithmetic, not floating-point optimization or an SDP grid. It covers 4096 total triple-space dimensions, 2176 swap-even and 1920 swap-odd dimensions, nine reduced blocks, and all ten exact support-cone rays. The isotropic normalization check gives \(\lambda_{\max}(H_{(1,1,1,1)})=270\). Both the ray enumerator and full-star checker were rerun in this cycle and passed. The additional integer-matrix check verifies all 36 Clifford anticommutators and the grade-three support counts across all 84 triples. These are internal exact checks, not a proof-assistant kernel check or external proof review.

## Prior-art and falsification boundary

Spin(9)'s real spinor sphere, its Spin(7) stabilizer, and the octonionic Hopf geometry are standard representation facts. The group-orbit POVMs and universal cloners are also standard constructions. The source search was bounded and found no directly matching Spin(9), \(d=16\) all-mixed common-comparator theorem; this does not establish absence, novelty, or priority. See [SOURCE_AUDIT.md](SOURCE_AUDIT.md) for the checked references and boundary.

The theorem would fail if the real-spinor moment identities or orbit classification were wrong, if the Spin(9) triple-product multiplicity decomposition omitted a block, if either output-swap sign or any exact principal-minor calculation were wrong, or if the Choi/dual normalization changed the factor of two. A legal compatible Spin(9)-covariant channel violating \(\Psi\succeq2\Phi-\mathrm{id}\) for every full-domain canonical EB \(\Psi\) is a direct mathematical falsifier. The present checks do not test arbitrary noncovariant channels or dimensions beyond 16.
