# Cycle 9 source and prior-art audit

## Geometry and representation facts

The calculation uses standard facts about the real 16-dimensional Spin(9) spinor: Spin(9) acts transitively on its unit sphere, a real-unit-spinor stabilizer is Spin(7), and the spinor sphere carries the octonionic Hopf fibration \(S^{15}\to S^8\). A peer-reviewed geometric treatment with octonionic derivations is Daura Serrano, Kohn, and Lawn, [“G-invariant spin structures on spheres”](https://doi.org/10.1007/s10455-022-09855-z) (2022). A separate primary geometric account is Ornea, Parton, Piccinni, and Vuletescu, [“Spin(9) geometry of the octonionic Hopf fibration”](https://arxiv.org/abs/1208.0899) (2013). These support the classical sphere action and stabilizer framework; they do not state the broadcasting comparison proved in this package.

The Clifford decomposition \(S^*\otimes S\cong\bigoplus_{j=0}^4\Lambda^j\mathbb R^9\), followed by gamma-trace decomposition of spinor-valued forms, is standard representation theory. The finite multiplicity matrices are reconstructed internally from an explicit four-qubit Clifford model and exact highest-weight kernels. The source search did not locate an external table of these particular star blocks; none is required as an imported premise.

## Quantum-information controls

Universal symmetric cloning and covariant state estimation are established controls. See Werner, [“Optimal Cloning of Pure States”](https://arxiv.org/abs/quant-ph/9804001), and Keyl and Werner, [“Optimal Cloning of Pure States, Judging Single Clones”](https://arxiv.org/abs/quant-ph/9807010). The standard universal cloner gives a dimension-16 covariant compatible channel; it is a baseline, not a novelty claim. General representation methods for covariant cloning are developed by Chiribella, D'Ariano, Perinotti, and Cerf, [“Extremal quantum cloning machines”](https://arxiv.org/abs/quant-ph/0507130). The pure-seed orbit POVM here is the standard Haar-twirl construction. A preceding Spin(5) control is the standard \(U(4)\) universal cloner and pure-state estimation map, recorded in [cycle8 SOURCE_AUDIT.md](../cycle8_mixed_representations/SOURCE_AUDIT.md).

These references establish the constructional background only. They do not establish the all-mixed support inequality or the fixed full-domain canonical-EB comparator in the Spin(9) class.

## Search boundary

The bounded primary-source search on 2026-10-08 combined Spin(9), spinor, cloning, covariant state estimation, broadcasting, and entanglement-breaking terms. It found the geometric/Hopf and general cloning sources above, but no directly matching \(d=16\), all-grade Spin(9)-covariant common-comparator theorem. This is a limited search record. It is not proof that no such result exists, and it does not support a novelty or priority claim.

## Evidence status

The cited sources support background representation and standard cloning facts. The pure-state moment triangle, its canonical-EB support consequence, and the all-mixed compatibility-star inequality are internal derivations with exact symbolic checks. There was no external proof review, formal proof-assistant verification, or exhaustive literature review.
