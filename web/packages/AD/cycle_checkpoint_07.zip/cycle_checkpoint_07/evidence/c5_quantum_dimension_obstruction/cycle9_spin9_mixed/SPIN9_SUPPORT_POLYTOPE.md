# Spin(9) all-grade EB support and factor-two comparison

## Status

This package now gives an internal exact factor-two theorem for the Spin(9)-covariant class in the 16-dimensional real-spinor representation, conditional only on the stated representation/orbit derivations. The canonical-EB support formula is derived in pure_orbits.md, and the full legal ordinary-tensor star inequality is certified in star_blocks.md and spin9_fullstar_blocks.py. The finite symbolic checks are not a proof-assistant verification or external review.

The problem is restricted to the irreducible real Spin(9) spinor \(S_{\mathbb R}\cong\mathbb R^{16}\), its complexification, invariant positive duals \(Q=\sum_{k=1}^4\alpha_k\Pi_k\) with \(\alpha_k\ge0\), and a *common full-domain canonical EB comparator*. An invariant dual is enough for the covariant class: averaging any positive dual over Spin(9) preserves the score of a covariant marginal and cannot increase the canonical-EB support. No arbitrary-EB support claim is made.

## Exact pure-seed moment body

Let \(\Gamma_1,\ldots,\Gamma_9\) be real Clifford generators on \(S_{\mathbb R}\), and use Hermitian Clifford-form basis elements \(T_A=i^{|A|(|A|-1)/2}\Gamma_A\) for grades \(0\le |A|\le4\). With \(\tau=\operatorname{Tr}/16\), the sector score of a pure seed \(P_\psi\) is

\[
\begin{aligned}
s_k(\psi)&=16^2\|\Pi_k(P_\psi-I/16)\|_{2,\tau}^2\\
&=\sum_{|A|=k}|\langle\psi,T_A\psi\rangle|^2.
\end{aligned}
\]

The complete orbit parametrization is

\[
p=|\psi^T\psi|^2\in[0,1],\qquad t\in[0,1],
\]

To obtain it, multiply \(\psi\) by a phase so that its real and imaginary parts are orthogonal, and write \(\psi=u x+i v y\), where \(x,y\) are real orthonormal spinors, \(u^2+v^2=1\), and \(u\ge v\ge0\). Then \(p=(u^2-v^2)^2\). Spin(9) acts transitively on the real unit sphere \(S^{15}\); the stabilizer Spin(7) acts on \(x^\perp\) as \(\mathbf7\oplus\mathbf8\). The \(\mathbf7\) is the vertical tangent to the octonionic Hopf fiber and the \(\mathbf8\) is horizontal. Spin(7) is transitive on the unit sphere in each summand. After choosing the direction of \(y_{\mathbf7}\), its stabilizer is Spin(6)\(\cong SU(4)\); this subgroup acts transitively on the unit sphere of the real 8-dimensional spinor representation \(y_{\mathbf8}\) (the unit sphere in \(\mathbb C^4\)). Hence the ordered frame orbit is classified by \(t=\|y_{\mathbf7}\|^2\in[0,1]\), with every pair \((p,t)\) attained.

Choose a real symmetric Clifford realization. Under transpose, grades \(1,4\) are symmetric and grades \(2,3\) are skew. For a real unit \(x\), the octonionic Hopf vector \(a_i=x^T\Gamma_i x\) has unit norm and \(\Gamma(a)x=x\). Its positive eigenspace is the 8-dimensional real fiber space; \(x^\perp=\mathbf7\oplus\mathbf8\) splits into its positive-eigenspace tangent (vertical) and negative eigenspace (horizontal). Thus, for unit \(y=y_{\mathbf7}+y_{\mathbf8}\),
\[
a\cdot b(y)=y^T\Gamma(a)y=\|y_{\mathbf7}\|^2-\|y_{\mathbf8}\|^2=2t-1,
\quad b_i(z)=z^T\Gamma_i z.
\tag{6}
\]

For the grade-two bilinears let \(L_{ij}=\Gamma_i\Gamma_j/2\), the skew-spin generators. The eight generators \(L_{a v}\), with \(v\perp a\), act on \(x\) as \(-\Gamma(v)x/2\); the \(\Gamma(v)x\) form an orthonormal basis of the horizontal \(\mathbf8\). Their frame operator on that summand is \(\tfrac14I\). The \(\mathfrak{spin}(8)\) generators with both indices perpendicular to \(a\) preserve the positive eigenspace and act there as a chiral Spin(8) spinor. Their Casimir is \(-\sum L_{ij}^2=7I\). By Spin(7) invariance the frame operator on the irreducible vertical \(\mathbf7\) is scalar, and its trace is 7; hence it is \(I\). It follows exactly that
\[
\sum_{i<j}|x^T\Gamma_i\Gamma_j y|^2
=4\sum_{i<j}|\langle y,L_{ij}x\rangle|^2
=4\left(t+\frac{1-t}{4}\right)=1+3t.
\tag{7}
\]

The symmetric and skew parts of \(P_\psi\) are \(R=u^2xx^T+v^2yy^T\) and \(B=iuv(yx^T-xy^T)\). Directly, \(s_1=\|u^2a+v^2b(y)\|^2=p+(1-p)t\), and (7) gives \(s_2=(1-p)(1+3t)\). Also \(\operatorname{Tr}R^2=u^4+v^4=(1+p)/2\) and \(\operatorname{Tr}B^2=2u^2v^2\). Since the symmetric traceless part is grades \(1\oplus4\) and the skew part is grades \(2\oplus3\), their squared Clifford-coordinate norms yield
\[
s_1+s_4=16\operatorname{Tr}(R-I/16)^2=7+8p,\qquad
s_2+s_3=16\operatorname{Tr}(B^2)=8(1-p).
\tag{8}
\]
Subtracting \(s_1,s_2\) proves all four moment formulas below. These are exact identities in the real spinor model, not a numerical fit.

The exact moment formulas are

\[
\begin{aligned}
s_1&=p+(1-p)t,\\
s_2&=(1-p)(1+3t),\\
s_3&=(1-p)(7-3t),\\
s_4&=7(1+p)-(1-p)t.
\end{aligned}
\tag{1}
\]

The exact consistency identities are \(s_1+s_4=7+8p\), \(s_2+s_3=8(1-p)\), and \(\sum_{k=1}^4s_k=15\), as required by purity in dimension 16. Formula (1) maps the parameter square into the triangle with vertices

\[
v_0=(1,0,0,14),\qquad v_H=(0,1,7,7),\qquad v_V=(1,4,4,6).
\tag{2}
\]

Indeed the moment vector is affine in \(p\) and \((1-p)t\); the square image is precisely the triangle with these three extremal values, all attained by real, balanced-horizontal, and balanced-vertical spinors. For a rank-one canonical POVM, the score is an average of pure-seed scores. For a higher-rank effect, decomposing its normalized state into pure states and applying scalar convexity \((\sum_jq_jr_j)^2\le\sum_jq_jr_j^2\) can only increase the quadratic score, so the support is still bounded by the pure-seed maximum. A Spin(9) orbit POVM \(16P_g\,dg\mapsto P_g\) attains each vertex. Irreducibility makes \(\int P_g\,dg=I/16\), so each vertex corresponds to a full-domain canonical EB channel.

Thus the candidate exact support for \(\alpha\ge0\) is

\[
S_{\rm can}(Q)=\max\{L_0,L_H,L_V\},
\quad
\begin{cases}
L_0=\alpha_1+14\alpha_4,\\
L_H=\alpha_2+7\alpha_3+7\alpha_4,\\
L_V=\alpha_1+4\alpha_2+4\alpha_3+6\alpha_4.
\end{cases}
\tag{3}
\]

The corresponding EB transfer vectors are \(v_i/\binom9k\) sectorwise. A common EB map for a channel cannot be chosen separately by sector; (3) is the support of the *one full-domain canonical EB set*, so all-grade positive-cone separation would produce one map if the compatibility support inequality is proved.

## Exact finite-ray reduction for the star inequality

For each fixed dual, define the ordinary-tensor star

\[
H_Q=\sum_{k=1}^4\alpha_k\sum_{|A|=k}T_A^T\otimes(T_A\otimes I+I\otimes T_A).
\]

It is linear in \(\alpha\). On the cone \(C_i=\{\alpha\in\mathbb R_+^4:L_i\ge L_j\text{ for all }j\}\), the desired support inequality is the linear matrix inequality

\[
H_Q\preceq (\operatorname{Tr}_{\rm HS}Q+L_i(Q))I,
\qquad \operatorname{Tr}_{\rm HS}Q=9\alpha_1+36\alpha_2+84\alpha_3+126\alpha_4.
\tag{4}
\]

Every \(C_i\) is a pointed polyhedral cone. Therefore it is generated by its extreme rays, and (4) for all \(Q\in C_i\) follows from (4) at its extreme rays: both \(H_Q\) and the right-side scalar are linear in \(Q\). Exact active-facet enumeration gives the following union of distinct rays, written in \((\alpha_1,\alpha_2,\alpha_3,\alpha_4)\) coordinates:

\[
e_1,e_2,e_3,e_4,
 (0,0,1,1), (0,2,0,1), (0,7,5,6), (7,0,2,1),
 (0,1,1,0), (3,0,1,0).
\tag{5}
\]

There are 6 extreme rays in each of the \(L_0,L_H\) cones and 7 in the \(L_V\) cone; shared tie rays reduce the union to ten. The enumerator enumerate_support_cone_rays.py uses exact rational/nullspace arithmetic and verifies both the per-cone and union lists. It is a polyhedral completeness check, not a star-spectrum proof.

The independent exact calculation in star_blocks.md reduces the full \(16\otimes16\otimes16\) star into all nine isotypic/swap blocks, retains both output-swap sectors, and certifies every principal minor at the ten directions (5). The star inequality therefore holds for every nonnegative mixed weight in this Spin(9)-invariant dual cone.

## Compatibility and common-map boundary

For invariant \(Q\), \(H_Q\) commutes with \(\bar U\otimes U\otimes U\) and output swap. A top eigenprojector can be output-swap-averaged and Spin(9)-twirled without changing its expectation. The spinor irrep is irreducible, so all one-party marginals become \(I/16\); the resulting state is the normalized Choi state of a symmetric CPTP broadcaster and has an unital covariant marginal. This argument does not require support on the Bose subspace. It also means a strict star violation is not merely an unconstrained Hamiltonian artifact.

If the support inequality is valid for every invariant nonnegative \(Q\), compact convex separation between compatible transfer vectors and canonical-EB transfer vectors gives, for each compatible covariant channel, one full-domain canonical EB channel satisfying \(\Psi\succeq2\Phi-I\) on all four traceless sectors. Conversely, a strict inequality failure is a separating positive dual for the compatible channel against every canonical EB channel. This says nothing directly about noncovariant channels or EB maps with unrelated preparation and measurement states.

## Source boundary and unresolved work

The Spin(9) real spinor sphere and the Hopf fibration \(S^{15}\to S^8\), with point stabilizer Spin(7) and octonionic \(S^7\) fibers, are standard geometry. A peer-reviewed source account is Daura Serrano, Kohn, and Lawn (2022), [*G-invariant spin structures on spheres*](https://doi.org/10.1007/s10455-022-09855-z); its appendix gives octonionic derivations of the sphere-action facts. Another primary mathematical reference is the Spin(9)-structure literature on the 16-dimensional real spinor representation and the decomposition \(\Lambda^2(\Delta_9)=\Lambda^2(\mathbb R^9)\oplus\Lambda^3(\mathbb R^9)\). These sources support classical representation/orbit facts, not the new broadcasting comparison.

The bounded web search found no Spin(9)-spinor-specific cloning theorem. That is a limited search, not a priority result. Standard universal \(U(16)\) cloning and pure-state estimation remain prior controls; the Spin(5) spinor case is already the standard \(U(4)\) cloner. The other main project blockers remain unchanged: the arbitrary-channel dimension-free common-EB comparison and the bounded-Holevo/vanishing-broadcast-error implication are UNKNOWN.

The resulting theorem is: every Spin(9)-covariant unital, trace-preserving, Hilbert--Schmidt-self-adjoint channel on the complexified 16-dimensional spinor that has a two-output CPTP extension with identical marginals admits one full-domain canonical EB comparator \(\Psi\) satisfying \(\Psi\succeq 2\Phi-\mathrm{id}\) on the full Hermitian operator space. The proof uses the all-positive-dual support inequality and finite-dimensional separation, so it does not choose comparators sector by sector. An arbitrary compatible extension can be twirled and output-swap averaged; the legal Choi argument uses both swap signs and does not assume Bose support.

The remaining gate is extension beyond this representation class: arbitrary/noncovariant channels, other irreducible representations, and the bounded-Holevo/vanishing-broadcast-error implication remain UNKNOWN. No source-derived ingredient is called novel, and the bounded prior search supports no priority claim.
