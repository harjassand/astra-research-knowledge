# Exact Spin(9) three-copy star blocks

## Result and scope

Take the complexified real 16-dimensional Spin(9) spinor (S), normalized trace

\[
\tau(X)=\operatorname{Tr}(X)/16,
\]

and a Hermitian Clifford family \(\Gamma_1,\ldots,\Gamma_9\). For
\(A=\{a_1<\cdots<a_k\}\), set

\[
T_A=i^{k(k-1)/2}\Gamma_{a_1}\cdots\Gamma_{a_k}.
\]

For \(0\leq k\leq4\), these form a \(\tau\)-orthonormal Hermitian basis of
the \(\Lambda^k\mathbb R^9\) operator sector. Write

\[
H_k=\sum_{|A|=k}T_A^T\otimes(T_A\otimes I+I\otimes T_A),
\qquad H(\alpha)=\sum_{k=1}^4\alpha_kH_k.
\]

I computed the full \(S^*\otimes S\otimes S\) multiplicity blocks exactly,
including both output-swap signs. Using the three canonical-EB support
vertices supplied by the orbit task,

\[
v_0=(1,0,0,14),\quad v_H=(0,1,7,7),\quad v_V=(1,4,4,6),
\]

the exact block check proves, for every \(\alpha\in\mathbb R_+^4\),

\[
\lambda_{\max}(H(\alpha))\le
9\alpha_1+36\alpha_2+84\alpha_3+126\alpha_4+
\max\{v_0\cdot\alpha,v_H\cdot\alpha,v_V\cdot\alpha\}.
\tag{1}
\]

The conclusion is conditional only on the separate task's asserted exact
formula for \(S_{\rm can}(Q)\); the Hamiltonian and all PSD calculations here
are independent of the orbit calculation. No numerical grid is used. The
source and exact output are [`spin9_fullstar_blocks.py`](spin9_fullstar_blocks.py),
[`spin9_fullstar_certificate.json`](spin9_fullstar_certificate.json), and
[`spin9_fullstar_blocks_run.txt`](spin9_fullstar_blocks_run.txt).

## Representation reduction and exact blocks

Clifford multiplication gives the multiplicity-free pair decomposition

\[
S^*\otimes S\cong\bigoplus_{j=0}^4\Lambda^j\mathbb R^9.
\]

For each \(j\leq4\), gamma-trace contraction splits
\(\Lambda^j\mathbb R^9\otimes S\) into the new gamma-traceless spinor-form
representation and \(\Lambda^{j-1}\mathbb R^9\otimes S\). Thus

\[
S^*\otimes S\otimes S
\cong\bigoplus_{r=0}^4 T_r\otimes\mathbb C^{5-r},\qquad
\dim T_r=16\left({9\choose r}-{9\choose r-1}\right),
\tag{2}
\]

with \({9\choose-1}=0\). In e-coordinate notation the highest weights are
\(\lambda_r=(\tfrac32^r,\tfrac12^{4-r})\); the dimensions in order are
\(16,128,432,768,672\). They satisfy
\(\sum_r(5-r)\dim T_r=4096\), so this covers the full triple tensor product.

Here is how the matrices were extracted. Use the four-qubit Clifford model
\(\Gamma_{2i-1}=Z^{\otimes(i-1)}X_i\),
\(\Gamma_{2i}=Z^{\otimes(i-1)}Y_i\), \(\Gamma_9=Z^{\otimes4}\).
On the spinor Fock basis the positive simple-root maps are
\(c_i^\dagger c_{i+1}\) for \(i=1,2,3\) and bare local raising on qubit 4
for the short root \(e_4\). On the dual reference they act as their negative
transposes. Exact kernels at weight \(\lambda_r\) have dimensions \(5-r\).
Restrict each sparse Pauli-word \(H_k\) to these highest-weight spaces,
split the involution for output swap, and orthonormalize each sign space over
exact rational/square-root arithmetic. Since \(H_k\) commutes with Spin(9),
each resulting matrix is the complete multiplicity block for \(T_r\).

The following are the orthonormal multiplicity matrices. A missing sign means
the corresponding space has dimension zero.

\[
\begin{array}{c|c|c|c|c|c}
r&\text{swap}&H_1&H_2&H_3&H_4\\\hline
0&+&\begin{pmatrix}0&6&0\\6&0&0\\0&0&10\end{pmatrix}&
\begin{pmatrix}0&0&0\\0&16&0\\0&0&40\end{pmatrix}&
\begin{pmatrix}0&0&0\\0&0&8\sqrt{14}\\0&8\sqrt{14}&80\end{pmatrix}&
\begin{pmatrix}0&0&6\sqrt{14}\\0&0&10\sqrt{14}\\6\sqrt{14}&10\sqrt{14}&120\end{pmatrix}\\[4mm]
0&-&\begin{pmatrix}0&2\sqrt{21}\\2\sqrt{21}&0\end{pmatrix}&
\begin{pmatrix}28&0\\0&36\end{pmatrix}&
\begin{pmatrix}0&12\sqrt{21}\\12\sqrt{21}&40\end{pmatrix}&
\begin{pmatrix}42&10\sqrt{21}\\10\sqrt{21}&90\end{pmatrix}\\[4mm]
1&+&\begin{pmatrix}0&0\\0&-8\end{pmatrix}&
\begin{pmatrix}-2&0\\0&22\end{pmatrix}&
\begin{pmatrix}0&-2\sqrt{35}\\-2\sqrt{35}&-28\end{pmatrix}&
\begin{pmatrix}0&2\sqrt{35}\\2\sqrt{35}&12\end{pmatrix}\\[4mm]
1&-&\begin{pmatrix}0&-4\sqrt3\\-4\sqrt3&0\end{pmatrix}&
\begin{pmatrix}10&0\\0&18\end{pmatrix}&
\begin{pmatrix}0&-6\sqrt3\\-6\sqrt3&-20\end{pmatrix}&
\begin{pmatrix}-12&10\sqrt3\\10\sqrt3&0\end{pmatrix}\\[4mm]
2&+&[6]&[8]&[0]&[-16]\\[2mm]
2&-&\begin{pmatrix}0&2\sqrt5\\2\sqrt5&0\end{pmatrix}&
\begin{pmatrix}-4&0\\0&4\end{pmatrix}&
\begin{pmatrix}0&-4\sqrt5\\-4\sqrt5&8\end{pmatrix}&
\begin{pmatrix}2&2\sqrt5\\2\sqrt5&-14\end{pmatrix}\\[4mm]
3&+&[-4]&[-2]&[10]&[-6]\\[2mm]
3&-&[0]&[-6]&[-2]&[6]\\[2mm]
4&+&[2]&[-8]&[-8]&[12]
\end{array}
\]

The swap multiplicities are \((3,2),(2,2),(1,2),(1,1),(1,0)\) for
\(r=0,1,2,3,4\), respectively. Weighting these by \(\dim T_r\) gives
dimension 2176 in the swap-even sector and 1920 in the swap-odd sector. Thus
the antisymmetric-output blocks have not been dropped. As a normalization
check, \(H(1,1,1,1)\) has exact top eigenvalue 270, agreeing with the
dimension-16 isotropic star \(16^2+16-2\).

## Exact mixed-weight certificate

On the three cones where \(v_0\cdot\alpha\), \(v_H\cdot\alpha\), or
\(v_V\cdot\alpha\) is largest, the right side of (1) is linear. Exact active
facet enumeration gives the ray sets

\[
\begin{aligned}
C_0:&\ e_4,(0,0,1,1),(0,2,0,1),(0,7,5,6),e_1,(7,0,2,1),\\
C_H:&\ e_3,(0,0,1,1),(0,1,1,0),(0,7,5,6),(3,0,1,0),(7,0,2,1),\\
C_V:&\ e_2,(0,1,1,0),(0,2,0,1),(0,7,5,6),e_1,(3,0,1,0),(7,0,2,1).
\end{aligned}
\]

The union has ten rays. At each ray \(a\), the checker forms, in every one
of the nine \((r,\mathrm{swap})\) blocks,

\[
G_{r,\epsilon}(a)=\bigl(\operatorname{Tr}_{HS}Q(a)+S_{\rm can}(Q(a))\bigr)I
-H(a)\big|_{T_r,\epsilon}.
\]

It computes every nonempty principal minor exactly and checks it is
nonnegative. Since these are real symmetric matrices, that is an exact PSD
test. The replay passes all 10 rays × 9 blocks. For reference, the scalar
bounds \(\operatorname{Tr}_{HS}Q+S_{\rm can}\) in the order

\[
e_4,e_3,e_3+e_4,e_2,e_2+e_3,(0,2,0,1),(0,7,5,6),e_1,
(3,0,1,0),(7,0,2,1)
\]

are \(140,91,224,40,128,212,1512,10,118,378\).

Each \(C_i\) is a pointed cone generated by its listed rays. On that cone the
matrix gap is linear in \(\alpha\), so PSD on its extreme rays implies PSD on
the whole cone. This proves (1) for every nonnegative mixed weight, provided
the input support is exactly the three-vertex maximum above. The JSON file
contains the full block matrices, all cone rays, and each exact principal
minor used in the ten-ray PSD certificates; the run log lists the replayed
blocks and PASS line.

## Legal broadcaster Choi argument

For any invariant \(Q\), \(H(\alpha)\) commutes with
\(\bar U\otimes U\otimes U\) and with the swap of the two outputs. If an
exact violating top eigenvalue had appeared, its full spectral projector
would be invariant under both actions; a swap-odd eigenvector still gives a
swap-invariant rank-one density projector. Spin(9) irreducibility forces each
one-party marginal of the normalized projector to be \(I/16\). Hence its
reference marginal is \(I/16\), so it is the normalized Choi state of a
trace-preserving broadcaster; swap invariance makes the two marginals equal,
and the output marginals \(I/16\) make the common marginal unital. Thus a
star violation would have been a legal symmetric-broadcasting obstruction,
not an artifact of optimizing over arbitrary three-party states. For the
proved upper bound, the same full-space operator bound applies directly to
every legal Choi state.

## Claim boundary

The all-mixed invariant Spin(9) star comparison is now an exact finite
calculation conditional on the separate task's orbit/support formula. It
does not prove that orbit formula, any noncovariant all-sector statement, or
an arbitrary-dimension comparator theorem. The checker performs symbolic
matrix algebra, not formal proof-assistant kernel verification.
