# Spin(9) spinor: exact canonical-EB pure-seed support

## Conventions and result

Let $S_{\mathbb R}\cong\mathbb R^{16}$ be the real spin representation, let
$S=S_{\mathbb R}\otimes\mathbb C$, and set $d=16$ and
$\tau(X)=\operatorname{Tr}(X)/16$. Choose real symmetric Clifford generators
$\Gamma_i$ ($i=1,\ldots,9$) with
$\Gamma_i\Gamma_j+\Gamma_j\Gamma_i=2\delta_{ij}I$. For an increasing set
$A\subseteq[9]$, write
\[
T_A=i^{|A|(|A|-1)/2}\Gamma_A,\qquad
\Gamma_A=\prod_{i\in A}\Gamma_i.
\]
For grades $0,\ldots,4$, the $T_A$ are Hermitian involutions and form a
$\tau$-orthonormal basis of $M_{16}(\mathbb C)$, since
$\sum_{k=0}^4\binom 9k=256$. Let $\Pi_k$ be the associated orthogonal
projections. For a pure state $P_\psi=|\psi\rangle\langle\psi|$, define
\[
s_k(\psi)=16^2\|\Pi_k(P_\psi-I/16)\|_{2,\tau}^2
=\sum_{|A|=k}\bigl(\operatorname{Tr}(P_\psi T_A)\bigr)^2,
\quad k=1,\ldots,4. \tag{1}
\]
This fixes the normalization used below.

The exact pure-seed moment body is the triangle
\[
\mathcal M=\operatorname{conv}\{v_H,v_V,v_R\},\qquad
v_H=(0,1,7,7),\quad v_V=(1,4,4,6),\quad v_R=(1,0,0,14). \tag{2}
\]
Consequently, for $Q=\sum_{k=1}^4\alpha_k\Pi_k$ with $\alpha_k\geq0$, the
canonical-EB support is
\[
S_{\rm can}(Q)=
\max\{\alpha_2+7\alpha_3+7\alpha_4,\;
       \alpha_1+4\alpha_2+4\alpha_3+6\alpha_4,\;
       \alpha_1+14\alpha_4\}. \tag{3}
\]

## Exact pure-state moments

Spin(9) acts transitively on the real unit sphere $S^{15}\subset S_{\mathbb R}$;
the stabilizer of a real unit spinor is Spin(7). At a fixed $x$, its
orthogonal complement splits as the inequivalent irreducible Spin(7)-modules
$x^\perp=V_7\oplus H_8$. In the octonionic model
$S_{\mathbb R}=\mathbb O\oplus\mathbb O$, at $x=(1,0)$ these are
\[
V_7=\{(a,0):a\in\operatorname{Im}\mathbb O\},\qquad
H_8=\{(0,b):b\in\mathbb O\}. \tag{4}
\]
For $0<t<1$, Spin(7) is transitive on the unit sphere in $V_7$; the
stabilizer of a unit $V_7$ vector is
$\operatorname{Spin}(6)\cong\operatorname{SU}(4)$. It acts on $H_8$ as the
underlying real space of its defining $\mathbb C^4$ and transitively on the
unit $S^7$. The endpoint actions on the unit spheres in $V_7$ and $H_8$ are
also transitive. Thus, for fixed $x$, the number $t=\|y_{V_7}\|^2$
completely classifies the Spin(7)-orbit of unit $y\in x^\perp$.

Multiplying $\psi$ by a phase makes $\psi^T\psi$ real and nonnegative. Write
\[
\psi=u x+i v y,\qquad x\perp y,\quad \|x\|=\|y\|=1,\quad
u^2+v^2=1,\quad u\geq v\geq0.
\]
Set
\[
p=|\psi^T\psi|^2=(u^2-v^2)^2,\qquad t=\|y_{V_7}\|^2. \tag{5}
\]
Here $p,t\in[0,1]$; when $p=1$, $\psi$ is real up to phase and $t$ does not
affect the moments.
For $p<1$, these are complete invariants of the Spin(9)-orbit of the
pure ray: Spin(9) first moves $x$ to a fixed real spinor, and the preceding
Spin(7)-orbit description then identifies $y$ from $t$. The phase ambiguity
when $p=0$ does not change $t$, since (6) recovers it from the invariant
$s_1$. At $p=1$ there is just the real-spinor orbit and $t$ is immaterial.

For the grade-one calculation, define the Hopf vector
$h=b(x)=(x^T\Gamma_i x)_{i=1}^9$. The octonionic Hopf identity gives
$\|b(z)\|=1$ for every real unit $z$ and $\Gamma(h)x=x$. Thus the eigenspaces
of $\Gamma(h)$ give
$x^\perp=V_7\oplus H_8$: $V_7\subset E_+(\Gamma(h))\ominus\mathbb Rx$ and
$H_8=E_-(\Gamma(h))$. Indeed, the Hopf fiber over $h$ is the unit sphere in
$E_+(\Gamma(h))$, while
$H_8=\{\Gamma(a)x:a\perp h\}$ and $a\mapsto\Gamma(a)x$ is an isometry.
For a unit $y=y_7+y_8$ this gives
\[
h\cdot b(y)=y^T\Gamma(h)y=\|y_7\|^2-\|y_8\|^2=2t-1.
\]
Since the grade-one generators are symmetric,
\[
s_1=\|u^2b(x)+v^2b(y)\|^2
=u^4+v^4+2u^2v^2(2t-1)=p+(1-p)t. \tag{6}
\]

For $k=2,3$, the relevant $\Gamma_A$ are real skew-symmetric. Their
expectations on $\psi$ are, up to sign, $2uv\,x^T\Gamma_Ay$, so
\[
s_k=(1-p)B_k(x,y),\qquad
B_k(x,y)=\sum_{|A|=k}(x^T\Gamma_Ay)^2. \tag{7}
\]
Each $B_k$ is a Spin(7)-invariant quadratic form on $V_7\oplus H_8$.
The two summands are inequivalent and each occurs once, so
$B_k=c_{k,7}t+c_{k,8}(1-t)$.

For grade two, put $L_{ij}=\Gamma_i\Gamma_j/2$ for $i<j$. Then
$B_2=4\langle y,Fy\rangle$ with
$F=\sum_{i<j}(L_{ij}x)(L_{ij}x)^T$. Choose an orthonormal basis with its
ninth axis $h$. The eight $h\wedge h^\perp$ generators give
$L_{h,a}x=-\Gamma(a)x/2$; these form a $1/2$-scaled orthonormal frame of
$H_8$, hence $F|_{H_8}=I/4$. The other 28 generators are those of Spin(8)
on $E_+(\Gamma(h))$. This is a chiral Spin(8) spinor, for which
$\sum L_{ij}^2=-7I$ (each $L_{ij}^2=-I/4$). Therefore the trace of $F$ on
$V_7$ is $-\langle x,\sum L_{ij}^2x\rangle=7$. Spin(7)-invariance and
irreducibility of $V_7$ force $F|_{V_7}=I$. It follows exactly that
\[
B_2=4\left(t+\frac{1-t}{4}\right)=1+3t. \tag{8}
\]

For grade three, the two coefficients can be counted exactly in the
octonionic Clifford model
\[
\Gamma_a(z_0,z_1)=(\bar a z_1,a z_0)\ (a=e_0=1,e_1,\ldots,e_7),
\qquad \Gamma_8(z_0,z_1)=(z_0,-z_1). \tag{9}
\]
The octonion composition identity makes these real symmetric Clifford
generators.
Use the Fano multiplication triples
$(123),(145),(176),(246),(257),(347),(365)$. At $x=(1,0)$,
$x^T\Gamma_Ay$ has magnitude one exactly for the listed grade-three sets
below and is zero for every other three-element set:
\[
\begin{array}{c|c}
y & \{A:|A|=3,\ |x^T\Gamma_Ay|=1\}\\ \hline
(e_1,0)&(0,1,8),(2,3,8),(4,5,8),(6,7,8)\\
(0,1)&(1,2,3),(1,4,5),(1,6,7),(2,4,6),(2,5,7),(3,4,7),(3,5,6).
\end{array}
\]
The labels $0,\ldots,8$ in (9) just relabel the nine Clifford directions.
Thus $c_{3,7}=4$, $c_{3,8}=7$, and $B_3=7-3t$. Combining (7) and (8),
\[
s_2=(1-p)(1+3t),\qquad s_3=(1-p)(7-3t). \tag{10}
\]

The grades $0,\ldots,4$ form a full matrix basis. Parseval applied to a
rank-one projector gives $\sum_{k=0}^4\sum_{|A|=k}
(\operatorname{Tr}(P_\psi T_A))^2=16$; the grade-zero term is $1$. Hence
$\sum_{k=1}^4s_k=15$, and
\[
s_4=7(1+p)-(1-p)t. \tag{11}
\]
The four coordinates therefore satisfy
\[
(s_1,s_2,s_3,s_4)
=(1-p)(1-t)v_H+(1-p)t\,v_V+p\,v_R. \tag{12}
\]
Every barycentric point occurs: take
\[
x=(1,0),\quad y_t=(\sqrt t\,e_1,\sqrt{1-t}\,1),\quad
u=\sqrt{\frac{1+\sqrt p}{2}},\quad
v=\sqrt{\frac{1-\sqrt p}{2}},\quad \psi_{p,t}=u x+i v y_t. \tag{13}
\]
Here $x\perp y_t$ and $\|y_t\|=1$. The weights in (12) range over the full
simplex, proving the exact triangle claim (2).

## Canonical support and full-domain orbit POVM

For any pure seed $P_\psi$, let $U_g$ be the complex spinor representation,
$P_g=U_gP_\psi U_g^*$, and let $dg$ be normalized Haar measure on Spin(9).
Irreducibility and Schur's lemma give $\int P_g\,dg=I/16$. Thus
\[
M(dg)=16P_g\,dg,\qquad
\Psi_\psi(X)=16\int\operatorname{Tr}(P_gX)P_g\,dg \tag{14}
\]
is a full-domain rank-one canonical EB channel: its effects integrate to $I$,
and it prepares the same pure state as each normalized effect. It is both
trace-preserving and unital.

For clarity, use the canonical score
\[
\operatorname{Score}_Q(\Phi)
=\sum_{k=1}^4\alpha_k\sum_{|A|=k}
\tau\!\left(T_A\Phi(T_A)\right). \tag{15}
\]
For (14), each summand is the Haar average of the squared seed expectation,
so Spin(9)-invariance yields
$\operatorname{Score}_Q(\Psi_\psi)=\sum_k\alpha_ks_k(\psi)$. More generally,
a rank-one canonical POVM with effects $w_yP_y$ has score
$\sum_y(w_y/16)\sum_k\alpha_ks_k(P_y)$, since completeness implies
$\sum_yw_y=16$. A canonical effect $w\rho$ of higher rank contributes
$(w/16)F_Q(\rho)$; the weights again sum to $16$ by completeness. Here
$F_Q(\rho)=\sum_{k,A}\alpha_k(\operatorname{Tr}(\rho T_A))^2$ is convex.
Decomposing $\rho$ into pure states shows it cannot exceed the largest
pure-seed score. Since (12) is the full triangle, maximizing a linear
functional over it gives (3). The orbit channels (14) for the three seeds
corresponding to $v_H,v_V,v_R$ attain all three vertex scores.

This support is for **canonical** measure-and-prepare channels, where each
effect $E_y$ is prepared as $E_y/\operatorname{Tr}E_y$. An unrestricted EB
channel $X\mapsto\sum_y\operatorname{Tr}(E_yX)\sigma_y$ may use independent
preparations. Its score contains cross terms
\[
\frac1{16}\sum_{k,A}\alpha_k\sum_y
\operatorname{Tr}(E_yT_A)\operatorname{Tr}(\sigma_yT_A),
\]
rather than the squared pure-seed expectations in (1). Formula (3) therefore
does not bound the unrestricted EB class.

## Prior-art boundary

The geometric framework is established: Ornea, Parton, Piccinni, and
Vuletescu describe the Spin(9)-symmetric octonionic Hopf fibration
$S^{15}\to S^8$ and the transitive Spin(9) action on $S^{15}$ in
[*Spin(9) geometry of the octonionic Hopf fibration* (2013)](https://arxiv.org/abs/1208.0899).
Bernevig, Hu, Toumbas, and Zhang use the SO(9) Hopf spinor and symmetric
products of its fundamental spinor in the eight-dimensional quantum Hall
lowest-Landau-level construction
[*The Eight Dimensional Quantum Hall Effect and the Octonions* (2003)](https://arxiv.org/abs/cond-mat/0306045).
These are geometric and spinor-orbit precedents, not direct prior statements
of (3).

Targeted searches on 2026-10-08 for Spin(9) spinor cloning, covariant state
estimation, and coherent-state POVMs surfaced this geometric/Hopf/LLL
literature but no directly matching primary study of optimal estimation or
cloning for the full complex $d=16$ pure-state family. This is only a search
boundary, not evidence of absence and not a novelty or priority claim. The
orbit POVM in (14) is the standard compact-group twirl construction.
