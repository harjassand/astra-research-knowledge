# Cycle 10 run log

Commands were launched from the repository root against the scripts in this directory. Arithmetic is exact SymPy rational/integer arithmetic; no floating-point SDP or external solver was used.

1. `python3 work/agents/c5_quantum_dimension_obstruction/cycle10_spin11_probe/spin11_fullstar_blocks.py` — PASS. Extracted all six highest-weight spaces and 11 output-swap/isotypic blocks from the 32768-dimensional triple product. Full dimensions: swap-even 16896, swap-odd 15872. The run log and exact Gram/bilinear matrices are in `spin11_fullstar_blocks_run.txt` and `spin11_fullstar_blocks.json`.
2. `python3 work/agents/c5_quantum_dimension_obstruction/cycle10_spin11_probe/spin11_seed_moments.py` — PASS. Replayed each of four seeds against all 1023 nonidentity Clifford words; moments are `(1,5,5,10,10)`, `(0,2,7,8,14)`, `(1,1,1,14,14)`, `(0,0,5,10,16)`.
3. `python3 work/agents/c5_quantum_dimension_obstruction/cycle10_spin11_probe/spin11_seed_support_check.py` — PASS. Exact active-facet enumeration gave cone ray counts 10, 10, 9, 9 and 17 distinct rays. Checked all 17 rays in all 11 blocks, with 629 exact principal minors and no negative or undecided minor. The isotropic star top is exactly 1054.
4. `python3 work/agents/c5_quantum_dimension_obstruction/cycle10_spin11_probe/spin11_outer_support_check.py` — PASS. Checked the 12-vertex full-domain canonical-EB moment outer bound on 30 distinct support-cone rays and all 11 blocks. No negative or undecided principal minor; the isotropic bound 1054 is exact.

## Resource and scope accounting

The full star contains `2*C(11,k)` sparse Pauli-word terms in grade k, totaling 2046 terms across five grades. Highest-weight source spaces have dimensions 243, 81, 27, 9, 3, 1; their exact kernel dimensions are 6, 5, 4, 3, 2, 1. The reduced star blocks have order at most three. Every certificate is internal symbolic computation plus the stated representation derivation; no proof-assistant kernel, external mathematical review, or novelty/priority review was performed.
