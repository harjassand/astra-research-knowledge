# Cycle 10: Spin(11), dimension 32

## Result

For a Spin(11)-covariant, unital, trace-preserving, Hilbert--Schmidt-self-adjoint channel \(\Phi:M_{32}\to M_{32}\) with a CPTP two-output extension whose marginals are both \(\Phi\), there exists one full-domain canonical entanglement-breaking channel \(\Psi\) such that

\[
\Psi-(2\Phi-\mathrm{id})\succeq0
\]

on the real Hilbert space of Hermitian matrices. The comparator can be chosen from the convex hull of four full-domain Spin(11)-orbit POVM channels. This establishes the covariant Spin(11) continuation without classifying every pure-spinor orbit or asserting an exact formula for the support over all canonical EB channels.

## Representation and exact star check

For the 32-dimensional spinor \(S\),
\[
S^*\otimes S\cong\bigoplus_{j=0}^{5}\Lambda^j\mathbb R^{11}.
\]
Tensoring each exterior-power summand with \(S\) and removing its gamma-trace gives
\[
S^*\otimes S\otimes S\cong\bigoplus_{r=0}^{5}T_r^{\oplus(6-r)},\qquad
\lambda_r=(\tfrac32^r,\tfrac12^{5-r}),\qquad
\dim T_r=32\left[{11\choose r}-{11\choose r-1}\right],
\]
with \({11\choose-1}=0\). The dimensions are \(32,320,1408,3520,5280,4224\); the multiplicities are \(6,5,4,3,2,1\). Their weighted sum is \(32768=32^3\).

The exact five-qubit Clifford/highest-weight extractor retains both output-swap signs. The multiplicities \((+, -)\), by \(r=0,\ldots,5\), are \((3,3),(3,2),(2,2),(1,2),(1,1),(1,0)\). This gives 11 reduced blocks, with swap-even and swap-odd dimensions \(16896\) and \(15872\). In particular, the star calculation uses the complete ordinary tensor product and does not impose Bose support.

Let \(d_k={11\choose k}\), \(T_A=i^{k(k-1)/2}\Gamma_A\), and
\[
H_\alpha=\sum_{k=1}^{5}\alpha_k\sum_{|A|=k}T_A^T\otimes(T_A\otimes I+I\otimes T_A).
\]
For every \(\alpha\ge0\), the exact certificate proves
\[
\lambda_{\max}(H_\alpha)\le \sum_{k=1}^{5}d_k\alpha_k+\max_{v\in V}v\cdot\alpha,
\]
where the four *attained* pure-seed moment vectors are
\[
V=\{(1,5,5,10,10),\ (0,2,7,8,14),\ (1,1,1,14,14),\ (0,0,5,10,16)\}.
\]
The support cones of these four vectors have 10, 10, 9, and 9 extreme rays (17 distinct rays in their union). Every ray gap is PSD in all 11 blocks by exact rational principal minors: 187 block-ray checks and 629 principal minors. The matrices are kept in their exact Gram metric, so no floating-point eigensolver is involved. The full-isotropic star has top eigenvalue 1054; its \((r=0,+)\) generalized characteristic polynomial is \(139755(x-1054)(x+2)^2\), and the exact \(1054I-H_{(1,1,1,1,1)}\) gaps are PSD in every block.

## Attainable canonical-EB support and broadcaster argument

The seeds are explicit in the five-qubit computational basis: \(|0\rangle\), and \((|0\rangle+|2^h-1\rangle)/\sqrt2\) for \(h=3,4,5\), where basis labels are five-bit integers. Exact Clifford-word replay gives the four moment vectors above. For each seed \(\psi\), the Spin(11)-orbit POVM has effects \(32|U_g\psi\rangle\langle U_g\psi|\,dg\) and prepares the same normalized effect state. Irreducibility gives \(\int |U_g\psi\rangle\langle U_g\psi|dg=I/32\); hence each is a full-domain canonical EB channel. Their convex mixtures are also full-domain canonical EB channels.

Write \(\lambda_k\) for the transfer of \(\Phi\) on \(\Lambda^k\mathbb R^{11}\). For a normalized broadcaster Choi state \(\rho\), with \(\rho=J/32\) for the unnormalized Choi matrix, TP gives \(\operatorname{Tr}_{12}\rho=I/32\), while unital marginals give \(\operatorname{Tr}_{R2}\rho=\operatorname{Tr}_{R1}\rho=I/32\). The broadcaster can be symmetrized across its outputs without changing either marginal. With \(\tau=\operatorname{Tr}/32\),
\[
\operatorname{Tr}(\rho H_\alpha)=2\sum_k d_k\alpha_k\lambda_k.
\]
Thus the star certificate gives, for all \(w_k=d_k\alpha_k\ge0\),
\[
w\cdot(2\lambda-\mathbf1)\le \max_{v\in V}w\cdot(v_1/d_1,\ldots,v_5/d_5).
\]
Separation places \(2\lambda-\mathbf1\) in the downward closure of the convex hull of these four attainable transfer vectors. The corresponding mixture of orbit POVMs is the single comparator \(\Psi\) above. The Choi operator inequality was checked on the full tensor product, including both output-swap signs, so it applies to every legal TP broadcaster Choi state with the stated unital marginals.

## Full canonical-EB support bound

The exact support over all full-domain canonical EB channels is not claimed. A valid global upper bound is available. For a pure seed let \(s_k=\sum_{|A|=k}(\operatorname{Tr}(P T_A))^2\). Clifford anticommutation gives \(s_1\le1\). Putting a real 2-form in SO(11) normal form gives \(s_2\le5\): its Clifford operator has norm at most \(\sum_{j=1}^5|\sigma_j|\le\sqrt5(\sum_j\sigma_j^2)^{1/2}\). Parseval gives \(\sum_{k=1}^5s_k=31\). The score is convex in each normalized POVM effect state, so the same pure-seed bound applies after refining higher-rank effects and averaging over the full POVM. Therefore every full-domain canonical EB channel satisfies
\[
S_{\rm can}(\alpha)\le U(\alpha):=\max_{j=3,4,5}\{31\alpha_j,\ \alpha_1+30\alpha_j,\ 5\alpha_2+26\alpha_j,\ \alpha_1+5\alpha_2+25\alpha_j\}.
\]
This is an upper bound from the 12 vertices of the capped-moment outer polytope, not an equality or a transfer-set description. Its separate exact all-mixed star check also passes on 30 rays and all 11 blocks. The theorem above instead uses the support of an explicitly attainable subset, which is a lower bound on \(S_{\rm can}\); these two support statements are kept distinct.

The remaining exact-support problem is to maximize \(\alpha\cdot s(\psi)\) over every ray \(\psi\in\mathbb{CP}^{31}\). The four seeds do not classify that image, and the capped-moment outer polytope need not be tight. This unresolved optimization is unnecessary for the comparator theorem proved here; it is the precise gap to an exact formula for \(S_{\rm can}\).

## Evidence, costs, and boundary

The reproducible exact sources and outputs are [spin11_fullstar_blocks.py](spin11_fullstar_blocks.py), [spin11_fullstar_blocks.json](spin11_fullstar_blocks.json), [spin11_seed_moments.py](spin11_seed_moments.py), [spin11_seed_support_check.py](spin11_seed_support_check.py), [spin11_seed_support_certificate.json](spin11_seed_support_certificate.json), and [spin11_outer_support_check.json](spin11_outer_support_check.json). [RUN_LOG.md](RUN_LOG.md) records commands and costs.

The calculation uses 1023 nonidentity Clifford words, at most six-dimensional highest-weight kernels, 11 exact reduced blocks, and exact rational arithmetic. The orbit seed moments were replayed over all 1023 words for each seed. No SDP grid, numerical precision assumption, or proof-assistant kernel is used. The exact full canonical-EB orbit support, noncovariant channels, other irreducible representations, external proof review, and novelty/priority remain open; no priority claim is made.
