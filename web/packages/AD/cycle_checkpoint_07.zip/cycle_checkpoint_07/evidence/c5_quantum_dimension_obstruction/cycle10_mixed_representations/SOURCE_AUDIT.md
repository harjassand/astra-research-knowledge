# Cycle 10 source and priority boundary

## Checked primary references

1. André, Araújo, and Cameron, “The Classification of Partition Homogeneous Groups with Applications to Semigroup Theory,” *Journal of Algebra* 452 (2016), [author repository PDF](https://research-repository.st-andrews.ac.uk/bitstream/handle/10023/10228/Sn_pairs9Jan2016.pdf?isAllowed=y&sequence=1), [arXiv record](https://arxiv.org/abs/1304.7391). This is a known group-theory source for set/partition homogeneity. The cycle's claim of 4-homogeneity is independently checked by exhaustive exact enumeration of all 504 (PGL(2,8)) permutations and all 126 four-subsets. The calculation also explicitly checks that the permutations are even.

2. Ornea, Parton, Piccinni, and Vuletescu, “Spin(9) Geometry of the Octonionic Hopf Fibration,” [arXiv:1208.0899](https://arxiv.org/abs/1208.0899). This is prior geometry for the Spin(9)-symmetric Hopf fibration and spinor-sphere action used by the Cycle 9 seed-orbit argument. It is not a source for the finite signed lift or the specific three finite orbit frames.

3. Finite group averaging and Schur's lemma are standard mechanisms for constructing covariant POVMs. The contribution recorded here is an explicit signed lift, three stabilizer-quotiented orbit lists, exact tight-frame checks, and the proof that their Clifford second moments match the continuous comparators. It is not a new group-twirling principle.

## Bounded search and claim limits

The finite-compiler subtask made a bounded targeted search for primary literature matching a finite Spin(9), 16-dimensional spinor orbit-POVM realization or the same three seed-orbit sizes. No direct match was returned. This does not establish absence, novelty, or priority. The (PGL(2,8)) set-transitivity fact itself is known, and the POVM construction is an explicit finite-group average.

The Spin(11) result uses the standard Clifford identification (End(S)=\bigoplus_{k=0}^5\Lambda^k\mathbb R^{11}), gamma-trace/highest-weight decomposition, and finite exact star-block calculations. The representation-theoretic facts are not presented as new. No literature search comprehensive enough for a novelty claim was performed for the particular four-seed mixed-weight comparator theorem.

No experimental or hardware measurement was built. The finite Spin(9) effect list and exact Naimark isometry are mathematical circuit interfaces; the conservative generic gate count is explicitly not practical. The Spin(11) theorem is an internal proof/certificate with independent audit pending in the parent workflow, not an externally validated theorem.
