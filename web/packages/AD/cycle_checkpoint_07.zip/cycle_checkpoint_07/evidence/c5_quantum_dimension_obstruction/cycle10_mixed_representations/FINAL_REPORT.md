# Cycle 10: finite Spin(9) comparators and a Spin(11) extension

## Result

This cycle produced two separate, dimension-specific results.

First, the three Spin(9)-covariant canonical-EB comparators from Cycle 9 have exact finite POVM realizations. An even signed-permutation subgroup built from (PGL(2,8)) gives projective orbits of 1,152, 1,008, and 144 rank-one effects for the (v_H,v_V,v_R) seeds. Their channels have exactly the same full matrix as the continuous Spin(9)-orbit channels. A rational two-dimensional feasibility routine selects one common mixture from supplied sector transfers.

Second, an exact Spin(11) calculation in dimension 32 gives a further covariant-class common-comparator theorem: every Spin(11)-covariant unital, trace-preserving, Hilbert--Schmidt-self-adjoint channel with a legal two-output broadcaster has one full-domain canonical EB comparator Ψ satisfying Ψ − (2Φ − id) ≽ 0. The comparator is a mixture of four attained Spin(11)-orbit POVM channels. This continues the structured class from Spin(9), but does not prove a theorem for arbitrary representations or noncovariant maps.

The arbitrary-channel, dimension-free factor-2 question remains **UNKNOWN**. Neither result is a counterexample or a proof of the all-(Q) gate outside its stated covariant class. No novelty or priority claim is made.

## Finite Spin(9) POVMs

Use the real octonionic spinor coordinates O⊕O, with (x=(1,0)), (y_V=(e_1,0)) at coordinate 1, and (y_H=(0,1)) at coordinate 8. The three seeds are

\[
\psi_R=x,\qquad \psi_H=(x+i y_H)/\sqrt2,\qquad
\psi_V=(x+i y_V)/\sqrt2.
\]

Let (G=(C_2)^8\rtimes PGL(2,8)\le SO(9)) be the determinant-one signed-permutation action on the nine projective-line coordinates. It has order 129,024; its Spin(9) preimage has order 258,048. For each seed, quotient the action by its projective ray stabilizer. The exact orbit certificate gives:

| Seed moment | Stabilizer in (G) | Distinct effects | POVM effect | Label bits |
|---|---:|---:|---:|---:|
| (v_H=(0,1,7,7)) | 112 | 1,152 | (P/72) | 11 |
| (v_V=(1,4,4,6)) | 128 | 1,008 | (P/63) | 10 |
| (v_R=(1,0,0,14)) | 896 | 144 | (P/9) | 8 |

For each distinct orbit projector (P), the stated effect is (16P/N), where (N) is that seed's orbit size. The exact checker verifies ΣP=(N/16)I for each orbit, so the effects sum to (I). All effects have exact rational real and imaginary entries. The largest reduced coefficient denominators in the matrices are 1,152, 1,008, and 144, respectively; no numerical precision is needed to specify the POVM.

The full signed group contains the even coordinate sign subgroup. Its characters on Clifford words (T_A) distinguish every pair of subsets with (|A|,|B|\le4): on even sign masks, characters agree only if (A=B) or (A\triangle B=[9]), and the latter is impossible for these grades. Averaging therefore kills every off-diagonal second moment. (PGL(2,8)) is transitive on the (k)-subsets for (k=1,2,3,4), so it equalizes the diagonal moments within each Clifford grade. Their sums are the seed moments (v_i); hence the finite channel transfer on grade (k) is (v_{i,k}/\binom9k). Since (S^*\otimes S=\bigoplus_{k=0}^4\Lambda^k\mathbb R^9) is multiplicity-free, this identifies every transfer coefficient and the finite channel equals the continuous Spin(9)-twirled channel on all of (M_{16}), not merely on selected seed states.

The 4-subset property was checked by explicit enumeration of all 504 normalized projective matrices over F8 and all 126 four-subsets. The group is known to be 4-homogeneous; it is not 4-transitive. All 504 permutations were also checked to be even, and exact Clifford lifts were constructed and tested against each of the nine vector generators. The known group-theoretic fact is recorded by André, Araújo, and Cameron ([paper](https://research-repository.st-andrews.ac.uk/bitstream/handle/10023/10228/Sn_pairs9Jan2016.pdf?isAllowed=y&sequence=1)); the signed lift and the three seed-specific projective orbit certificates are the parts used here.

## One common comparator from the supplied transfers

With (d=(9,36,84,126)), the three exact transfers are

\[
\eta_H=(0,1/36,1/12,1/18),\quad
\eta_V=(1/9,1/9,1/21,1/21),\quad
\eta_R=(1/9,0,0,1/9).
\]

Given exact rational λ₁,…,λ₄ from the Cycle 9 channel class, the compiler finds (q_H,q_V,q_R\ge0), Σqᵢ=1, with

\[
\sum_i q_i\eta_{i,k}\ge2\lambda_k-1\quad(k=1,2,3,4).
\]

It parameterizes (q_R=1-q_H-q_V), enumerates the 21 pairs of boundary lines from the three simplex inequalities and four transfer inequalities, and checks every candidate with exact `Fraction` arithmetic. The Cycle 9 support theorem guarantees feasibility for a legal compatible transfer vector. It rejects floating-point inputs. The comparator is the one full-domain channel Ψ=ΣqᵢΨᵢ, with the three POVMs pooled and effects multiplied by (q_i). It has at most 2,304 outcomes, which fit in 12 bits. Exact rational (q_i) add no ambiguity to the symbolic POVM; for implemented rotations, the precision must track the supplied transfer precision and synthesis error separately.

## Circuit and resource boundary

The explicit measurement isometry for one seed is

\[
W_i|\phi\rangle=\sqrt{16/N_i}\sum_{P_j\in\mathcal O_i}
|j\rangle\langle\psi_j|\phi\rangle,
\qquad W_i^*W_i=I_{16}.
\]

Measuring the label after (W_i) realizes the listed POVM. It has an exact finite definition with 8, 10, or 11 output-label qubits. The same channel then prepares the corresponding 4-qubit seed orbit state; the mixture can use a pooled 12-bit outcome address. The group-lift checker gives at most eight coordinate-reflection factors per permutation, translating in a fixed Pauli-word realization to at most 48 CNOTs and eight (R_z(\pi/2)) rotations for the permutation part of a label-to-state preparation. This excludes the initial seed/basis-conversion cost and is not a cost for performing the POVM readout.

For an explicit generic upper bound on readout synthesis, pad the label space to (M=2^b), (b=11,10,8), and complete the 16-column isometry to a unitary by complex Givens elimination. The number of two-level rotations is at most
\[
G=16(M-1)-\binom{16}{2},
\]
namely 32,632, 16,248, and 3,960. A conservative decomposition of each two-level rotation on (b) label qubits uses at most (14b-24) CNOTs, at most (2(b-2)) Toffolis, and at most ten arbitrary one-qubit rotations. Add at most 16 one-state phase corrections, each using (12(b-1)) CNOTs and (2(b-1)) Toffolis. Counting six CNOTs and seven T gates per exact Toffoli gives these upper bounds:

| Seed | Label qubits (b) | Two-level rotations (G) | Total CNOT upper bound | Toffoli upper bound | T gates from Toffolis only | Arbitrary rotations | Clean workspace |
|---|---:|---:|---:|---:|---:|---:|---:|
| (v_H) | 11 | 32,632 | 4,244,080 | 587,696 | 4,113,872 | 326,336 | 10 |
| (v_V) | 10 | 16,248 | 1,886,496 | 260,256 | 1,821,792 | 162,496 | 9 |
| (v_R) | 8 | 3,960 | 349,824 | 47,744 | 334,208 | 39,616 | 7 |

The clean workspace is (b-1) qubits and is uncomputed; the label register also needs (b-4) clean qubits before the isometry. These are finite generic synthesis bounds, not optimized or resource-practical circuits. The arithmetic is replayed by [naimark_upper_bound.py](naimark_upper_bound.py), which writes [NAIMARK_UPPER_BOUND.json](NAIMARK_UPPER_BOUND.json); this checks the cost formulas only and does not emit the actual Givens angles or a physical circuit. For total unitary operator-norm error ε, assign each arbitrary one-qubit rotation operator-norm error at most ε divided by the count in the table. At ε=10⁻³, this requires 29, 28, and 26 binary accuracy bits per rotation under the convention that error is at most (2^{-p}). The T count for approximating arbitrary rotations is not included. Therefore the evidence establishes finite exact POVMs and a concrete synthesis route, but **does not establish an efficient physical readout circuit**.

## Spin(11), dimension 32

The exact certificate covers the full ordinary tensor (S^*\otimes S\otimes S), dimension 32,768, including both output-swap signs. It decomposes as

\[
S^*\otimes S\otimes S=\bigoplus_{r=0}^5T_r^{\oplus(6-r)},\qquad
\lambda_r=(\tfrac32\text{ repeated }r,\tfrac12\text{ repeated }5-r),\quad
\dim T_r=32\left[\binom{11}{r}-\binom{11}{r-1}\right].
\]

The swap-even/odd dimensions are 16,896 and 15,872; eleven reduced blocks cover them. For every nonnegative mixed weight α₁,…,α₅, the all-mixed star obeys

\[
\lambda_{\max}(H_\alpha)\le \sum_{k=1}^5\binom{11}{k}\alpha_k+
\max_{v\in V}v\cdot\alpha,
\]

for four *attained* moment seeds (V=\{(1,5,5,10,10),(0,2,7,8,14),(1,1,1,14,14),(0,0,5,10,16)\}). Exact support-cone enumeration produced 17 distinct rational rays. Their gaps passed exact principal-minor checks in every one of the eleven blocks (187 block-ray checks, 629 minors); the isotropic star maximum is 1,054. Replays in this cycle independently reran the extractor, all four seed moments, the 17-ray support check, and the separate 30-ray outer-support check.

For a legal broadcaster, the normalized Choi state has both unital marginals and its star expectation is (2\sum_k\binom{11}{k}\alpha_k\lambda_k). Separation against the convex hull of the four attained finite/invariant Spin(11)-orbit comparators gives one mixture dominating (2\lambda-\mathbf1), hence one full-domain canonical EB comparator. A separate analytic outer bound on support over all canonical EB channels is recorded in the Spin11 report; it is not used as an equality or as the attained-support lower bound in this argument. The exact-star certificate and representation derivation are internal evidence; external proof review and formal proof-assistant verification are not claimed here.

## Evidence paths and falsifiers

- Finite Spin(9) construction and exact group/lift/stabilizer checker: [cycle10_finite_compiler](../cycle10_finite_compiler/FINAL_REPORT.md), [checker](../cycle10_finite_compiler/finite_compiler.py), [certificate](../cycle10_finite_compiler/FINITE_CERTIFICATE.json).
- Spin(11) proof and exact reduced star blocks: [Spin11 report](../cycle10_spin11_probe/FINAL_REPORT.md), [extractor](../cycle10_spin11_probe/spin11_fullstar_blocks.py), [seed-support checker](../cycle10_spin11_probe/spin11_seed_support_check.py), [certificate](../cycle10_spin11_probe/spin11_seed_support_certificate.json).
- Independent prior-cycle controls: [Cycle 9 Spin(9) theorem](../cycle9_spin9_mixed/FINAL_REPORT.md) and [Cycle 8 mixed-representation checks](../cycle8_mixed_representations/FINAL_REPORT.md).

The finite Spin(9) claim is falsified by a wrong Clifford character action, a nontransitive (PGL(2,8)) subset layer, a lift that fails the nine generator conjugations, a wrong projective stabilizer/orbit, or failure of the exact frame identity. The Spin(11) claim is falsified by a missing triple-product block, a bad swap decomposition, a wrong seed transfer, a negative exact principal minor, or a legal covariant broadcaster violating all four-seed support inequalities. Neither package tests arbitrary noncovariant channels or establishes any all-dimension conclusion.
