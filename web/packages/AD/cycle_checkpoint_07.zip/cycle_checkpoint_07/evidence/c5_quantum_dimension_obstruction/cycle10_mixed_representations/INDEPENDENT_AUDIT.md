# Cycle 10 independent checks and implementation caveats

## Spin(9) finite-orbit audit

I independently implemented `PGL(2,8)` from normalized invertible `2×2` matrices over `F8 = F2[x]/(x^3+x+1)` in [pgl2f8_subset_orbits.py](../cycle10_group_probe/pgl2f8_subset_orbits.py). It constructs 504 distinct permutations and exhaustively verifies a single orbit on each subset layer `k=1,2,3,4`, of sizes 9, 36, 84, and 126. This was not inferred from sharp 3-transitivity.

There is also a short check of the special `k=4` fact. Normalize three ordered points of a 4-set to ∞, 0, 1 by sharp 3-transitivity; the fourth point has cross-ratio λ in `F8\{0,1}`. For an unordered set, the six anharmonic transforms are
\[
\lambda,\quad 1-\lambda,\quad 1/\lambda,\quad 1/(1-\lambda),\quad
\lambda/(\lambda-1),\quad(\lambda-1)/\lambda.
\]
Taking λ to be a primitive element α of `F8×`, these transforms are the six elements of `F8\{0,1}`. Thus all 4-sets share one orbit. This is 4-homogeneity, not 4-transitivity. The exact enumeration separately confirms the conclusion and the actual projective-matrix implementation.

The finite compiler's standard-library exact replay was rerun. It checks every Clifford anticommutator, each of the 504 signed-rational permutation lifts against all nine vector generators, the 256 even-sign actions, all three projective stabilizers, all three orbit sizes, each exact first moment, and the seed grade moments. Results:

- `|G|=504×256=129,024` in SO(9), with Spin preimage size 258,048.
- `(N_H,N_V,N_R)=(1,152,1,008,144)`, from stabilizers `(112,128,896)`.
- Effects `P/72`, `P/63`, and `P/9`; exact tight-frame identity and exact rational matrix coefficients.
-  The exact rational common-mixture smoke test passed.

The finite channel identity is supported by a complete coefficient argument: even-sign averaging removes all off-diagonal Clifford-basis second moments through grade 4, while subset transitivity makes each same-grade diagonal moment constant. Summing that diagonal gives the seed moment `s_k`, hence coefficient `s_k/binom(9,k)`. The full matrix-basis expansion then matches the continuous Spin(9)-orbit channel. The argument is about equality of the channel maps, not just a transfer-vector or statewise witness.

## Spin(11) replay audit

The exact Spin(11) extractor and all three downstream checks were rerun:

1. `spin11_fullstar_blocks.py`: all 32,768 tensor dimensions, both output-swap signs, 11 reduced blocks, dimensions 16,896 and 15,872.
2. `spin11_seed_moments.py`: all 1023 nonidentity Clifford words for each of four seeds, with exact moment vectors.
3. `spin11_seed_support_check.py`: 17 support-cone rays in 11 blocks, 629 exact principal minors, no negative or undecided minor.
4. `spin11_outer_support_check.py`: 30 distinct rays in all 11 blocks, all exact checks pass.

The positive-dual theorem uses only the support of the *attained* four-seed EB subset. The separately checked full-canonical-EB estimate is an outer support upper bound and is not identified with the attainable support. This distinction is essential to the separation direction. The representation derivation and Choi bookkeeping are internal mathematical arguments; the parent workflow has a separate Spin(11) proof audit, and no formal proof-assistant check is claimed here.

## Circuit-cost caveats

The exact finite POVMs have small outcome registers compared with the 129,024-element signed group because repeated projective rays are quotiented by their stabilizers. The state-preparation factor count uses a Pauli-word realization and charges the label-dependent permutation/sign operations; the seed preparation and basis conversion to that Pauli-word representation are excluded. It also does not compile the input POVM readout.

The generic Naimark/Givens bound is deliberately labeled non-practical. It is an arithmetic upper bound under arbitrary one-qubit rotations plus exact Toffoli decompositions. The script verifies the counts but emits neither the Givens angles nor a hardware circuit. Its precision figures are an operator-norm error allocation for the generic rotation list, not calibration data and not a gate-synthesis T count for arbitrary rotations. Thus the deliverable is an exact finite POVM and a constructive readout-synthesis route, not a claim of an efficient device implementation.
