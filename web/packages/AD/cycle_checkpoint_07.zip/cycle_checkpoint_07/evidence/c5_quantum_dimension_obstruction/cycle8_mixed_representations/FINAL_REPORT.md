# Cycle 8: symplectic defining-representation mixed-dual theorem

## Result

For every compact symplectic defining representation \(V=\mathbb C^d\), \(d=2n\geq4\), every \(G=\mathrm{USp}(2n)\)-covariant, unital, trace-preserving, Hilbert--Schmidt-self-adjoint channel with a two-output CPTP extension admits the one fixed canonical EB comparator

\[
\Psi_d(X)=\frac{X+\operatorname{Tr}(X)I}{d+1},
\qquad
\operatorname{id}-\Psi_d\preceq_{\rm HS}2(\operatorname{id}-\Phi).
\]

The proof establishes the exact support identity for every positive invariant dual with arbitrary nonnegative weights on the adjoint and primitive-two-form sectors. It explicitly includes the full output-antisymmetric block. For general positive duals, group twirling is justified by covariance. The maximizing star vector can itself be twirled into a valid symmetric broadcaster Choi state with every one-party marginal \(I/d\).

The detailed derivation is in [USp_fundamental_all_mixed_Q.md](USp_fundamental_all_mixed_Q.md). The essential calculation reduces the three-copy \(V\)-isotypic sector to three symplectic contractions. The output-symmetric eigenvalue \(h_+\) dominates the antisymmetric \(2\times2\) contraction block by exact trace and determinant, and dominates the remaining space by \(\|F_{01}+F_{02}\|\leq2\).

## Prior-art and novelty boundary

At \(d=4\), the exact symmetric broadcaster is the standard \(U(4)\) universal \(1\to2\) cloner, restricted to Spin(5), and the comparator is standard pure-state estimation. The cloner reaches \(3/5\) on both irreducible sectors and is extreme even in the unrestricted CPTP set; the orbit POVM yields \((X+\operatorname{Tr}(X)I)/5\). These constructions are recorded with exact derivations and primary-source links in [SOURCE_AUDIT.md](SOURCE_AUDIT.md). Prudhoe's symplectic channel work is adjacent one-channel CP/PPT/EB structure, not a two-output compatibility theorem. The bounded audit found no source stating this all-mixed support inequality, but the search is not exhaustive. No novelty or priority claim is made.

## Verification and limits

The algebraic checker [verify_uspsp_allmixed.py](verify_uspsp_allmixed.py) passes the Gram-metric, antisymmetric trace/determinant, complement-region, and EB support identities symbolically. The earlier exact Spin(5) certificate also reruns successfully: both vector and bivector star spectra match their exact characteristic polynomials and have the claimed maxima. These are internal checks, not independent proof review.

This does not address noncovariant channels, arbitrary irreducible representations, or the bounded-Holevo/vanishing-broadcast-error implication. The next mathematical gate is a genuinely mixed higher-form spinor representation with at least three nontrivial sectors; a common comparator there must optimize over full-domain EB maps and account for legal Choi marginals.
