# Spin(7) spinor: exact mixed three-sector star and canonical-EB comparator

## Result and scope

Let $S$ be the complexification of the real eight-dimensional spin representation of $\operatorname{Spin}(7)$, and write
\[
\operatorname{End}(S)=\mathcal V_0\oplus\mathcal V_1\oplus\mathcal V_2\oplus\mathcal V_3
\cong \mathbf1\oplus\mathbf7\oplus\mathbf{21}\oplus\mathbf{35}.
\]
For $Q=\alpha\Pi_1+\beta\Pi_2+\gamma\Pi_3$, with $\alpha,\beta,\gamma\ge0$, the exact canonical measure-and-prepare support, optimized over every pure seed on the full input $M_8$, is
\[
S_{\rm can}(Q)=\max\{\alpha+3\beta+3\gamma,\;7\gamma\}.
\tag{1}
\]
The full ordinary-tensor-product star maximum is
\[
h(\alpha,\beta,\gamma)=\lambda_{\max}(H_Q)
=X+\sqrt{X^2+140\gamma^2},\qquad X=4\alpha+12\beta+18\gamma.
\tag{2}
\]
It obeys the exact mixed-weight inequality
\[
h(\alpha,\beta,\gamma)\le 7\alpha+21\beta+35\gamma+S_{\rm can}(Q).
\tag{3}
\]
Thus the Spin(7)-covariant compatible class has one common canonical-EB comparator per marginal channel, simultaneously on all three traceless sectors and hence on every positive dual frame. An explicit comparator mixture is given below. This is a Spin(7), $d=8$, three-sector result. It does not claim a theorem for noncovariant broadcasters, $\operatorname{Spin}(2n+1)$ with $n\ge4$, or the larger set of EB channels with unrelated measurement and preparation states.

The star maximum is over the **full** $8\otimes8\otimes8$ Choi space. Both output-swap eigenspaces are reduced and checked; no Bose-support assumption is used. The exact finite representation reduction below is an analytic Racah calculation, not a parameter grid or SDP.

## Choi normalization and compatibility

Choose Hermitian Clifford generators $\Gamma_i$ with $\Gamma_i\Gamma_j+\Gamma_j\Gamma_i=2\delta_{ij}I$, $i,j=1,\ldots,7$, and $\tau=\operatorname{Tr}/8$. For an increasing index set $A\subseteq[7]$, set
\[
T_A=i^{|A|(|A|-1)/2}\Gamma_A,\qquad \Gamma_A=\prod_{i\in A}\Gamma_i.
\]
For $0\le |A|\le3$, these are Hermitian involutions and form a $\tau$-orthonormal operator basis; the grade-$\ell$ basis has $d_\ell=\binom7\ell$ elements. Define
\[
H_Q=\sum_{\ell=1}^3\alpha_\ell\sum_{|A|=\ell}
T_A^T\otimes(T_A\otimes I+I\otimes T_A),
\qquad (\alpha_1,\alpha_2,\alpha_3)=(\alpha,\beta,\gamma).
\tag{4}
\]
If $\mathcal E:R\to B_1B_2$ has normalized Choi state
$\Omega=(\mathrm{id}\otimes\mathcal E)(|\Phi_8\rangle\langle\Phi_8|)$, the normalized-Choi identity gives, for its marginal channels $\Phi_b=\operatorname{Tr}_{B_{3-b}}\circ\mathcal E$,
\[
\operatorname{Tr}(\Omega H_Q)=\sum_{\ell=1}^3\alpha_\ell\sum_{|A|=\ell}\sum_{b=1}^2
\frac18\operatorname{Tr}\bigl(T_A\Phi_b(T_A)\bigr).
\]
For a symmetric extension $\Phi_1=\Phi_2=\Phi$, this is
\[
\operatorname{Tr}(\Omega H_Q)=2\operatorname{Tr}_{\tau\text{-HS}}(Q\Phi).
\tag{5}
\]

Conversely, the top eigenvalue of $H_Q$ is attained by a legal symmetric extension, not just by a state with arbitrary marginals. The star commutes with $\bar U\otimes U\otimes U$ for $U\in\operatorname{Spin}(7)$ and with the output swap $S_{12}$. Given any normalized top eigenvector, average its projector with its output-swapped projector and twirl over Spin(7). The star expectation stays $h(Q)$; irreducibility forces each one-system marginal to be $I/8$. The reference marginal is exactly the TP Choi constraint, the output marginals make the common channel unital, and swap invariance gives equal marginal channels. Therefore
\[
h(Q)=\sup_{\mathcal E\;\mathrm{symmetric\ CPTP}}2\operatorname{Tr}_{\tau\text{-HS}}(Q\Phi_{\mathcal E}).
\tag{6}
\]
Here “symmetric” means output-swap invariant. It does not mean that the Choi state is supported only on the symmetric-output subspace.

## Exact pure-seed support on the full input

The real spinor structure gives a real form $S_{\mathbb R}\cong\mathbb R^8$. Its unit sphere is a transitive Spin(7) orbit with stabilizer $G_2$, and $G_2$ acts transitively on the unit sphere in the orthogonal seven-space, with stabilizer $SU(3)$. Consequently Spin(7) is transitive on ordered orthonormal two-frames in $S_{\mathbb R}$. These standard orbit facts are also stated in [the Spin(7)/$G_2$, $G_2/SU(3)$ sphere-action account](https://doi.org/10.1007/s10455-022-09855-z).

For any unit complex spinor, multiply by a phase so that its real and imaginary parts are orthogonal, and then write
\[
\psi=u x+i v y,\qquad x,y\in S_{\mathbb R},\quad x\perp y,\quad
u^2+v^2=1,\quad u\ge v\ge0.
\]
The ray orbits are therefore parametrized by
\[
t=|\psi^T\psi|^2=(u^2-v^2)^2\in[0,1].
\tag{7}
\]
In particular, $t=0$ and $t=1$ are both attained; there are no additional pure-seed orbit parameters.

As real Spin(7) modules,
\[
\operatorname{Sym}^2(S_{\mathbb R})=\mathbf1\oplus\mathbf{35},\qquad
\Lambda^2(S_{\mathbb R})=\mathbf7\oplus\mathbf{21}.
\]
In the Clifford grading, these are respectively grades $0\oplus3$ and $1\oplus2$. Put $P_\psi=|\psi\rangle\langle\psi|$. Its real-symmetric part is
$R=u^2xx^T+v^2yy^T$, and its imaginary-skew part is
$B=iuv(yx^T-xy^T)$. Since $\operatorname{Tr}(R^2)=u^4+v^4=1-2u^2v^2$,
\[
s_3(\psi):=8\operatorname{Tr}\bigl((\Pi_3P_\psi)^2\bigr)
=8\operatorname{Tr}\bigl((R-I/8)^2\bigr)
=7-16u^2v^2=3+4t.
\tag{8}
\]

For the skew piece, the seven-dimensional summand in $\Lambda^2S_{\mathbb R}$ is spanned by the seven real Clifford multiplications $e_i$, with $e_i^T=-e_i$ and $e_ie_j+e_je_i=-2\delta_{ij}I$. In the wedge inner product $\langle K,L\rangle=\tfrac12\operatorname{Tr}(K^TL)$, $e_i/2$ is an orthonormal basis. For fixed unit $x$, the vectors $e_ix$ form an orthonormal basis of $x^\perp$. Thus the unit simple bivector $x\wedge y$ has squared projection $1/4$ onto this $\mathbf7$ summand and $3/4$ onto the $\mathbf{21}$ summand. Since $\operatorname{Tr}(B^2)=2u^2v^2$, this yields
\[
s_1(\psi)=8\operatorname{Tr}\bigl((\Pi_1P_\psi)^2\bigr)=4u^2v^2=1-t,
\qquad
s_2(\psi)=8\operatorname{Tr}\bigl((\Pi_2P_\psi)^2\bigr)=12u^2v^2=3(1-t).
\tag{9}
\]
These normalizations agree with $s_1+s_2+s_3=7=8\operatorname{Tr}((P_\psi-I/8)^2)$.

For a canonical EB channel generated by a pure seed $P_\psi$, twirl the rank-one measure-and-prepare orbit $8P_g\,dg\mapsto P_g$. Irreducibility gives $\int P_g\,dg=I/8$, so this is a full-domain canonical EB channel. Its invariant $Q$-score is
\[
f_Q(\psi)=\alpha s_1(\psi)+\beta s_2(\psi)+\gamma s_3(\psi)
=\alpha+3\beta+3\gamma+t(4\gamma-\alpha-3\beta).
\]
Every canonical EB POVM refines to a probability ensemble of pure seeds, so its score is an average of $f_Q$ and cannot exceed its maximum. The two endpoint orbit channels attain both endpoint values, proving (1) exactly.

Denote the $t=0$ seed channel by $\Psi_0$, and the real-spinor $t=1$ channel by $\Psi_1$. Their transfer triples on $(\mathcal V_1,\mathcal V_2,\mathcal V_3)$ are
\[
\mu(\Psi_0)=\left(\frac17,\frac17,\frac3{35}\right),\qquad
\mu(\Psi_1)=\left(0,0,\frac15\right).
\tag{10}
\]

## Pair Casimir/Krawtchouk reduction

Use the vectorization isometry
$\Theta(|\bar u\rangle\otimes|v\rangle)=|v\rangle\langle u|$. On the first/reference-output pair, let
\[
K_\ell=\sum_{|A|=\ell}T_A^T\otimes T_A.
\]
Under $\Theta$, $K_\ell$ acts on $X\in\operatorname{End}(S)$ as
$X\mapsto\sum_{|A|=\ell}T_AXT_A$. On Clifford grade $r$, it is scalar
\[
\kappa_{\ell r}=\sum_t(-1)^{\ell r-t}\binom rt\binom{7-r}{\ell-t},
\qquad 0\le r,\ell\le3.
\tag{11}
\]
Indeed, $T_AT_BT_A=(-1)^{\ell r-|A\cap B|}T_B$. The exact eigenvalue table is
\[
\begin{array}{c|rrrr}
\kappa_{\ell r}&r=0&r=1&r=2&r=3\\\hline
\ell=0&1&1&1&1\\
\ell=1&7&-5&3&-1\\
\ell=2&21&9&1&-3\\
\ell=3&35&-5&-5&3
\end{array}.
\tag{12}
\]
Thus, for the pair-channel eigenvalues
\[
q_0=7\alpha+21\beta+35\gamma,\quad
q_1=-5\alpha+9\beta-5\gamma,\quad
q_2=3\alpha+\beta-5\gamma,\quad
q_3=-\alpha-3\beta+3\gamma,
\tag{13}
\]
the star is exactly $H_Q=K_Q^{12}+K_Q^{13}$, where $K_Q=\sum_\ell\alpha_\ell K_\ell$ has eigenvalue $q_r$ in pair channel $r$.

The pair channels $r=0,1,2,3$ are the Spin(7) irreducibles of highest weights $(0,0,0),(1,0,0),(1,1,0),(1,1,1)$ in orthogonal $B_3$ coordinates, of dimensions $1,7,21,35$. Tensoring each with the spinor highest weight $(\tfrac12,\tfrac12,\tfrac12)$ gives the complete triple decomposition:
\[
\begin{array}{c|c|c}
\text{total irrep }T&\dim T&\text{pair channels }r\text{ present}\\\hline
(\tfrac12,\tfrac12,\tfrac12)&8&0,1,2,3\\
(\tfrac32,\tfrac12,\tfrac12)&48&1,2,3\\
(\tfrac32,\tfrac32,\tfrac12)&112&2,3\\
(\tfrac32,\tfrac32,\tfrac32)&112&3
\end{array}
\tag{14}
\]
The multiplicities are $4,3,2,1$; $8\cdot4+48\cdot3+112\cdot2+112=512$, the full Choi dimension.

For completeness, the recoupling matrices can be reproduced without a spectral grid. Let $J_{ij}=\tfrac12\Gamma_i\Gamma_j$, and let
$C=-\sum_{i<j}(J_{ij}^{(R)}+J_{ij}^{(B_1)}+J_{ij}^{(B_2)})^2$, with the reference generator conjugated. Its four eigenvalues in (14) are $21/4,49/4,69/4,81/4$, so each total-irrep projector $P_T$ is the corresponding Lagrange polynomial in $C$. The pair projector is
\[
P_r^{12}=\prod_{s\ne r}\frac{K_1^{12}-\kappa_{1s}I}{\kappa_{1r}-\kappa_{1s}},
\]
and similarly for $P_s^{13}$. Exact Clifford trace reduction gives
\[
\frac1{\dim T}\operatorname{Tr}(P_TP_r^{12}P_s^{13})=|F^{(T)}_{rs}|^2,
\tag{15}
\]
where rows/columns are the allowed channels in increasing order, and
\[
\begin{array}{c|c}
T&(|F^{(T)}_{rs}|^2)\\\hline
8&\frac1{64}\begin{pmatrix}1&7&21&35\\7&25&27&5\\21&27&1&15\\35&5&15&9\end{pmatrix}\\[2mm]
48&\frac1{16}\begin{pmatrix}1&5&10\\5&9&2\\10&2&4\end{pmatrix}\\[2mm]
112_{(3/2,3/2,1/2)}&\frac14\begin{pmatrix}1&3\\3&1\end{pmatrix}\\[2mm]
112_{(3/2,3/2,3/2)}&(1)
\end{array}
\tag{16}
\]
With real CG phases chosen for the output transposition, the symmetric orthogonal Racah matrices are
\[
F^{(8)}=\frac18\begin{pmatrix}
1&\sqrt7&\sqrt{21}&\sqrt{35}\\
\sqrt7&-5&3\sqrt3&-\sqrt5\\
\sqrt{21}&3\sqrt3&1&-\sqrt{15}\\
\sqrt{35}&-\sqrt5&-\sqrt{15}&3
\end{pmatrix},\quad
F^{(48)}=\frac14\begin{pmatrix}
1&\sqrt5&\sqrt{10}\\
\sqrt5&-3&\sqrt2\\
\sqrt{10}&\sqrt2&-2
\end{pmatrix},
\tag{17}
\]
\[
F^{(112_{(3/2,3/2,1/2)})}=\frac12\begin{pmatrix}-1&\sqrt3\\\sqrt3&1\end{pmatrix},
\qquad F^{(112_{(3/2,3/2,3/2)})}=(1).
\tag{18}
\]
Each is a real symmetric involution. The $+1/-1$ eigenspaces are the output-swap-symmetric/antisymmetric multiplicity spaces. Their dimensions across (14) are respectively $16+48+112+112=288=8\cdot36$ and $16+96+112=224=8\cdot28$. Hence both Choi swap blocks are included.

## Exact star blocks and maximum

On the total-irrep multiplicity space for $T$, the star matrix is
\[
M_T=\operatorname{diag}_{r\in R_T}(q_r)+F^{(T)}\operatorname{diag}_{r\in R_T}(q_r)(F^{(T)})^T.
\tag{19}
\]
It commutes with the output swap $F^{(T)}$. Its characteristic polynomials on the two swap signs are
\[
\begin{aligned}
\chi_{8,+}(x)&=x^2-2Xx-140\gamma^2,\\
\chi_{8,-}(x)&=x^2-(32\beta+20\gamma)x-48\alpha^2-240\alpha\gamma
                  +240\beta^2+240\beta\gamma-300\gamma^2,\\
\chi_{48,+}(x)&=x+6\alpha-10\beta+6\gamma,\\
\chi_{48,-}(x)&=x^2-(4\beta-8\gamma)x-20\alpha^2+40\alpha\gamma
                  -12\beta^2+16\beta\gamma-20\gamma^2,\\
\chi_{112_{(3/2,3/2,1/2)},+}(x)&=x+4\beta-2\gamma,\\
\chi_{112_{(3/2,3/2,1/2)},-}(x)&=x-4\alpha+6\gamma,\\
\chi_{112_{(3/2,3/2,3/2)},+}(x)&=x+2\alpha+6\beta-6\gamma.
\end{aligned}
\tag{20}
\]
The $(8,+)$ block has upper root $R_*=X+\sqrt{X^2+140\gamma^2}$, which is at least $2X$. Every eigenvalue in the other blocks is at most $2X$. For the nontrivial other upper roots this follows from
\[
R_{8,-}=16\beta+10\gamma+4\sqrt{Z_8},\quad
Z_8=3\alpha^2+15\alpha\gamma+\beta^2+5\beta\gamma+25\gamma^2,
\]
\[
(8\alpha+8\beta+26\gamma)^2-16Z_8
=4(4\alpha^2+32\alpha\beta+44\alpha\gamma+12\beta^2+84\beta\gamma+69\gamma^2)\ge0,
\]
and
\[
R_{48,-}=2\beta-4\gamma+2\sqrt{Z_{48}},\quad
Z_{48}=5(\alpha-\gamma)^2+4(\beta-\gamma)^2,
\]
\[
(4\alpha+11\beta+20\gamma)^2-Z_{48}
=11\alpha^2+88\alpha\beta+170\alpha\gamma+117\beta^2+448\beta\gamma+391\gamma^2\ge0.
\]
In each case the nonnegative linear term and square comparison give $R_{8,-},R_{48,-}\le2X$. The $(48,+)$ and two $(112)$-blocks are linear roots directly bounded by $2X$. The lower roots are no larger than the corresponding upper roots. This proves (2), including the antisymmetric output-swap sector.

## Mixed comparison and explicit common EB map

Write
\[
A=8\alpha+24\beta+38\gamma,\qquad
B=7\alpha+21\beta+42\gamma.
\]
By (1), $\operatorname{Tr}_{\tau\text{-HS}}Q+S_{\rm can}(Q)=\max(A,B)$. Also $A-B=\alpha+3\beta-4\gamma$. If $A\ge B$, then
\[
(A-X)^2-(X^2+140\gamma^2)=16\gamma(\alpha+3\beta-4\gamma)\ge0,
\]
with $A-X=4\alpha+12\beta+20\gamma\ge0$, so $R_*\le A$. If $B\ge A$, then
\[
(B-X)^2-(X^2+140\gamma^2)
=7(4\gamma-\alpha-3\beta)(\alpha+3\beta+4\gamma)\ge0,
\]
and $B-X=3\alpha+9\beta+24\gamma\ge0$, so $R_*\le B$. This proves the genuinely mixed inequality (3), not just its three axis restrictions. Equality holds for all $\gamma=0$, and also on the branch boundary $4\gamma=\alpha+3\beta$; elsewhere the comparison is strict except the zero dual.

There is also a direct common-comparator construction. Let $\lambda_\ell$ be the transfer scalar of any Spin(7)-covariant symmetric-broadcast marginal and put $x_\ell=2\lambda_\ell-1$. The exact star formula at five positive duals gives
\[
x_1\le\frac17,\quad x_2\le\frac17,\quad x_3\le\frac15,
\qquad 4x_1+5x_3\le1,\quad 4x_2+5x_3\le1.
\tag{21}
\]
The first three follow from $Q=\Pi_1,\Pi_2,\Pi_3$ and (2)-(3); the last two follow from the genuinely mixed tests $Q=4\Pi_1+\Pi_3$ and $Q=\tfrac43\Pi_2+\Pi_3$, for each of which $h=70=\operatorname{Tr}Q+S_{\rm can}(Q)$. Choose
\[
q=7\max\{0,x_1,x_2\}\in[0,1],\qquad
\Psi=q\Psi_0+(1-q)\Psi_1.
\tag{22}
\]
Its transfers are $\mu_1=\mu_2=q/7$ and $\mu_3=(7-4q)/35$. The definition of $q$ gives $\mu_1\ge x_1$ and $\mu_2\ge x_2$. If $q=7x_1$ or $q=7x_2$, the corresponding mixed test in (21) gives $\mu_3\ge x_3$; if $q=0$, the axis bound $x_3\le1/5$ gives the same. Thus
\[
\Psi-(2\Phi-I)\succeq_{\tau\text{-HS}}0
\]
on all three traceless sectors. Both maps are unital, so the difference is zero on the scalar identity sector. The one channel (22) is a full-domain canonical EB map, and the operator inequality gives the all-frame comparator directly.

## Exact scope and checks

The calculation assumes a Spin(7)-covariant marginal and a positive invariant dual on the three traceless Clifford-form sectors. Equation (6) checks physical compatibility with the full reference and output marginals; the spectral reduction includes both output-swap signs, even though the maximizing block in (20) is swap-symmetric. The EB support is for canonical measure-and-prepare maps with the same pure state as effect seed and preparation; support over arbitrary EB maps with unrelated preparation states is not asserted here. The argument does not extend by itself to $n\ge4$, noncovariant compatible channels, or duals outside the stated sector cone.

The exact falsification points are explicit: (15)-(20) determine the full block spectrum, while (21) shows the mixed comparisons $4\Pi_1+\Pi_3$ and $\tfrac43\Pi_2+\Pi_3$ are both sharp at 70. Any proposed Spin(7) counterexample in this scope would have to contradict one of these exact block identities, the seed-orbit support (1), or the five derived transfer constraints (21). No such violation remains in this three-sector Spin(7) gate. This is an internal analytic derivation, not an external formal-verifier or priority claim.

## Exact checker and orbit-source status

Run `python3 work/agents/c5_quantum_dimension_obstruction/cycle8_mixed_representations/check_spin7_mixed_exact.py`. It checks all four Racah matrices as exact symmetric involutions, reconstructs the seven output-swap characteristic polynomials by restricting $D+FDF^T$ to the exact $\pm1$ eigenspaces, and verifies the mixed square-factor identities, root-comparison identities, sharp mixed tests, and comparator slack identities over exact radicals/rational polynomials. It uses multiplicity matrices of size at most four; it has no floating-point arithmetic or 512-dimensional numerical grid. The captured run is `SPIN7_EXACT_CHECK_OUTPUT.txt`.

The linked Daura Serrano–Kohn–Lawn 2022 paper is a peer-reviewed original research article on invariant spin structures for sphere actions. Its appendix gives octonionic arguments for both $G_2$ transitivity on $S^6$ with stabilizer $SU(3)$ and $\operatorname{Spin}(7)$ transitivity on $S^7$ with stabilizer $G_2$; it also cites Fontanals (2018) for some background facts about these actions. Thus it is a primary research article for its classification and a published derivation of the action facts used here, but not the original-discovery source for these classical group actions. The action facts are summarized at [the article's appendix](https://link.springer.com/article/10.1007/s10455-022-09855-z).
