# All-mixed dual support for the symplectic fundamental representation

## Theorem and scope

Let \(d=2n\geq4\), let \(V=\mathbb C^d\) be the defining representation of the compact symplectic group \(G=\mathrm{USp}(2n)\), and let \(\Phi:M_d\to M_d\) be a unital, trace-preserving, Hilbert--Schmidt self-adjoint channel that is \(G\)-covariant and has a two-output CPTP extension with both marginals equal to \(\Phi\). Then the fixed full-domain entanglement-breaking channel

\[
\Psi_d(X)=\frac{X+\operatorname{Tr}(X)I}{d+1}
\]

satisfies

\[
\Psi_d-(2\Phi-\operatorname{id})\succeq_{\rm HS}0,
\qquad\text{equivalently}\qquad
\operatorname{id}-\Psi_d\preceq_{\rm HS}2(\operatorname{id}-\Phi).
\tag{1}
\]

The order is positivity of a self-adjoint superoperator on the real Hermitian Hilbert--Schmidt space; it is not complete positivity of the difference. The proof below establishes the full positive-dual star bound for this covariant class, including every mixed choice of weights on both nontrivial operator sectors. It also checks the output-antisymmetric sector of the full three-copy Choi star. It does not cover noncovariant channels or settle the unrestricted all-dimension theorem.

For \(n=2\), \(G\simeq\operatorname{Spin}(5)\), and the operator sectors are the earlier ququart \(5\oplus10\) split. The Spin(5) ququart broadcaster and comparator have exact standard realizations as the \(U(4)\) universal cloner and pure-state estimation channel; see the bounded source audit in [SOURCE_AUDIT.md](SOURCE_AUDIT.md). That audit does not identify the common-comparator inequality or full compatible region in prior sources. This is an internal analytic extension, not a novelty or priority claim.

## Symplectic operator sectors and the EB score

Choose a unitary symplectic form \(J\) with \(J^T=-J\) and \(J^2=-I\), and define

\[
\theta(X)=J^{-1}X^T J.
\]

On Hermitian operators, \(\theta\) is a real Hilbert--Schmidt-orthogonal involution. Its \(-1\) eigenspace is the adjoint representation, isomorphic to \(\operatorname{Sym}^2 V\), of dimension

\[
N_+=\frac{d(d+1)}2.
\]

Its \(+1\) eigenspace contains the scalar identity and the irreducible primitive two-form representation, whose dimension is

\[
N_-=\frac{d(d-1)}2-1=\frac{(d-2)(d+1)}2.
\]

The orthogonal transfer-space projectors are

\[
\Pi_+=\frac{\operatorname{id}-\theta}{2},
\qquad
\Pi_-=\frac{\operatorname{id}+\theta}{2}-\Pi_0,
\qquad
\Pi_0(X)=\frac{\operatorname{Tr}(X)}d I.
\tag{2}
\]

Multiplicity-freeness implies that a \(G\)-covariant unital, trace-preserving, self-adjoint channel has real transfer eigenvalues \(\lambda_+\), \(\lambda_-\) on these two traceless sectors and eigenvalue one on the scalar sector.

The group is transitive on the unit sphere of \(V\). For any fixed rank-one projector \(P\), its orbit has second moment

\[
\int P_g\otimes P_g\,dg=\frac{I+F}{d(d+1)},
\]

where \(F\) is the swap. The orbit POVM with effects \(dP_g\,dg\), followed by preparation of \(P_g\), gives exactly \(\Psi_d\); it is trace preserving, unital, and entanglement breaking. The second-moment identity shows that its transfer is \(1/(d+1)\) on every traceless operator.

For invariant \(Q=a\Pi_++b\Pi_-\), with \(a,b\geq0\), the exact support of **all** entanglement-breaking channels is

\[
\sup_{\Xi\ {\rm EB}}\operatorname{Tr}_{\rm HS}(Q\Xi)
=\frac{aN_++bN_-}{d+1}
=\frac{\operatorname{Tr}_{\rm HS}Q}{d+1}.
\tag{3}
\]

Here is a direct bound that also covers noncovariant EB channels. Write a measure-and-prepare map using rank-one refined effects \(E_k=t_kP_k\), \(\sum_k t_kP_k=I\), and prepared density operators \(\sigma_k\). Refining an effect does not change its channel if its prepared state is retained, and \(\sum_k t_k=d\). Transitivity and the second-moment formula give, for every pure \(P\),

\[
\|\Pi_r(P-I/d)\|_{\rm HS}^2=\frac{N_r}{d(d+1)},\qquad r\in\{+,-\}.
\]

For any density operator \(\sigma\), convexity of the norm gives the same upper bound on \(\|\Pi_r(\sigma-I/d)\|_{\rm HS}\). Thus sectorwise Cauchy--Schwarz bounds each rank-one measure-and-prepare contribution by \(t_k(aN_++bN_-)/[d(d+1)]\). Summing \(t_k\) proves the upper bound in (3), and the orbit channel \(\Psi_d\) attains it. With scalar weight \(q_0\Pi_0\), the support is \(q_0+(aN_++bN_-)/(d+1)\). This is an EB support statement only for invariant \(Q\); for a general positive \(Q\), the argument below first twirls \(Q\), which is valid because \(\Phi\) is covariant.

## Choi pair-star operators

Use normalized Choi states and a Hermitian basis orthonormal for \(\tau(X)=\operatorname{Tr}(X)/d\). For a transfer-space projector \(\Pi_r\), let

\[
G_r=\sum_{T\in\mathcal B_r}T^T\otimes T.
\]

With this basis convention, \(G_r=d^2J(\Pi_r)\). The normalized Choi matrices of the identity map, \(\theta\), and \(\Pi_0\) are respectively

\[
J(\operatorname{id})=P_\Omega,\qquad
J(\theta)=\frac1dF_J,\qquad
J(\Pi_0)=\frac{I}{d^2},
\]

where \(P_\Omega=|\Omega\rangle\langle\Omega|\), \(\Omega\) is the normalized maximally entangled vector, and \(F_J=(I\otimes J^{-1})F(I\otimes J)\). Therefore

\[
G_+=\frac{d^2}{2}P_\Omega-\frac d2F_J,
\qquad
G_-=\frac{d^2}{2}P_\Omega+\frac d2F_J-I.
\tag{4}
\]

Identify the conjugate reference with \(V\) through the invariant symplectic form. Under this unitary identification \(P_\Omega\) becomes the projector \(P_\omega\) onto the normalized symplectic singlet and \(F_J\) becomes the ordinary swap. Label the reference by 0 and outputs by 1 and 2. The full Choi star associated with \(Q=a\Pi_++b\Pi_-\) is

\[
H_Q=\alpha(P_{01}+P_{02})+\beta(F_{01}+F_{02})+\gamma I,
\tag{5}
\]

where \(P_{0i}\) projects the pair \((0,i)\) onto the symplectic singlet, \(F_{0i}\) swaps that pair, and

\[
\alpha=\frac{d^2}{2}(a+b),\qquad
\beta=\frac d2(b-a),\qquad
\gamma=-2b.
\tag{6}
\]

All operators in (5) act on the ordinary tensor product \(V^{\otimes3}\). The proof checks both output-swap sectors and assumes no Bose support.

## Exact mixed spectrum on all three-copy sectors

Define three intertwiners \(U_{01},U_{02},U_{12}:V\to V^{\otimes3}\). In coordinates \((a,b,c)\) on the three factors, set

\[
(U_{01}v)_{abc}=d^{-1/2}J_{ab}v_c,\quad
(U_{02}v)_{abc}=d^{-1/2}J_{ac}v_b,\quad
(U_{12}v)_{abc}=d^{-1/2}J_{bc}v_a.
\]

Their Gram operators are

\[
U_{01}^*U_{02}=d^{-1}I,\quad
U_{01}^*U_{12}=-d^{-1}I,\quad
U_{02}^*U_{12}=d^{-1}I.
\tag{7}
\]

For \(d\geq4\), they are linearly independent and span the complete \(V\)-isotypic component: after identifying \(V^*\simeq V\), the relevant invariant tensors are in \(V^{\otimes4}\), whose symplectic invariant space is spanned by the three independent pair contractions. The range of \(P_{01}+P_{02}\) lies in this component. On its orthogonal complement \(P_{01}+P_{02}=0\), and \(\|F_{01}+F_{02}\|\leq2\).

The output swap exchanges \(U_{01}\) and \(U_{02}\), and sends \(U_{12}\) to \(-U_{12}\). On the output-symmetric vector \(u_+=U_{01}+U_{02}\),

\[
(P_{01}+P_{02})u_+=(1+d^{-1})u_+,\qquad
(F_{01}+F_{02})u_+=-u_+.
\]

Hence \(u_+\) is an eigenvector with eigenvalue

\[
h_+=\gamma+\alpha(1+d^{-1})-\beta
=\frac{d(d+2)}2a+\frac{d^2-4}{2}b.
\tag{8}
\]

On the output-antisymmetric part of the \(V\)-isotypic component, the ordered basis \((u_-=U_{01}-U_{02},U_{12})\) gives

\[
H_-=
\begin{pmatrix}
\alpha(1-d^{-1})-\beta+\gamma&-\alpha d^{-1}-\beta\\
-2\beta&\gamma
\end{pmatrix}.
\tag{9}
\]

This basis has positive Gram matrix

\[
\mathsf G_-=
\begin{pmatrix}
2(1-d^{-1})&-2d^{-1}\\
-2d^{-1}&1
\end{pmatrix},
\qquad
\det\mathsf G_-=\frac{2(d-2)(d+1)}{d^2}>0.
\]

Thus \(H_-\) represents a self-adjoint operator in a positive inner product and has real eigenvalues. Direct simplification gives

\[
\operatorname{Tr}(h_+I-H_-)=\frac d2\bigl((d+4)a+(d+2)b\bigr)\geq0,
\]

\[
\det(h_+I-H_-)=\frac{d^2}{2}\bigl((d+2)a^2+2(d+2)ab+(d-2)b^2\bigr)\geq0.
\tag{10}
\]

Because the eigenvalues are real, nonnegative trace and determinant imply \(h_+I-H_-\succeq0\).

On the orthogonal complement of the three contraction copies, (5) has eigenvalues at most \(\gamma+2|\beta|\). For \(a,b\geq0\),

\[
h_+-\gamma=\frac d2\bigl((d+2)a+db\bigr)\geq d|b-a|=2|\beta|.
\]

For \(b\geq a\), the difference after dividing by \(d\) is \(((d+4)a+(d-2)b)/2\geq0\); for \(a\geq b\), it is \((da+(d+2)b)/2\geq0\). This bounds the remaining sectors. Combining all blocks proves the exact full-space maximum for every mixed dual:

\[
\lambda_{\max}(H_Q)=h_+
=\frac{d(d+2)}2a+\frac{d^2-4}{2}b
=\operatorname{Tr}_{\rm HS}Q+\sup_{\Xi\ {\rm EB}}\operatorname{Tr}_{\rm HS}(Q\Xi).
\tag{11}
\]

The last equality follows from (3) and the dimensions in (2).

The maximizing vector is output-symmetric. Twirling its normalized projector under \(\overline U\otimes U\otimes U\) gives a positive swap-invariant state whose one-party marginals are all \(I/d\), by irreducibility of the defining representation. This is a legal normalized Choi state of a full-domain symmetric broadcaster. Therefore (11) is a legal compatible-channel support equality, not merely an unrestricted state witness with incorrect Choi marginals.

If \(Q=q_0\Pi_0+a\Pi_++b\Pi_-\), the scalar basis has star \(2q_0I\) and EB support \(q_0\). Adding these terms preserves (11) with the scalar contribution included.

## All positive duals and the common comparator

For any positive Hermitian-space dual \(Q\), average it under \(G\) to obtain \(\overline Q\). Since \(\Phi\) and \(\Psi_d\) are \(G\)-covariant,

\[
\operatorname{Tr}_{\rm HS}(Q\Phi)=\operatorname{Tr}_{\rm HS}(\overline Q\Phi),\qquad
\operatorname{Tr}_{\rm HS}(Q\Psi_d)=\operatorname{Tr}_{\rm HS}(\overline Q\Psi_d).
\]

The twirled operator has the form \(q_0\Pi_0+a\Pi_++b\Pi_-\), with nonnegative coefficients. If a normalized Choi state \(\Omega\) represents a two-output extension of \(\Phi\), the star identity is

\[
\operatorname{Tr}(\Omega H_{\overline Q})
=2\operatorname{Tr}_{\rm HS}(\overline Q\Phi).
\]

Equation (11) therefore yields the full positive-dual inequality

\[
\operatorname{Tr}_{\rm HS}(Q\Phi)
\leq\frac{\operatorname{Tr}_{\rm HS}(Q)+\operatorname{Tr}_{\rm HS}(Q\Psi_d)}2
\quad\text{for every }Q\succeq0.
\tag{12}
\]

There is one fixed comparator \(\Psi_d\) in (12). Taking \(Q=\Pi_+\) and \(Q=\Pi_-\) gives

\[
\lambda_+,\lambda_-\leq\frac{d+2}{2(d+1)}.
\]

The sector eigenvalues of \(\Psi_d-(2\Phi-\operatorname{id})\) are consequently

\[
\frac1{d+1}-(2\lambda_r-1)
=\frac{d+2}{d+1}-2\lambda_r\geq0,\qquad r\in\{+,-\},
\]

and its scalar eigenvalue is zero. This proves (1). The star calculation is genuinely mixed-\(Q\): it does not infer (12) from separate axis checks.

## Source boundary, cost, and falsifiers

The calculation uses standard symplectic representation decomposition, the invariant second moment of pure states, and standard measure-and-prepare/Choi facts. The bounded prior audit finds that at \(d=4\) the boundary broadcaster is Werner's \(U(4)\)-universal \(1\to2\) cloner, with both sector transfers \(3/5\), and the comparator is the \(U(4)\) pure-state estimation channel. Prudhoe's symplectic-covariant channel paper is adjacent CP/PPT/EB structure, not a two-output compatibility result. These are prior-art overlaps; no novelty or priority claim is made. The audit checked primary sources Werner, Keyl--Werner, Chiribella et al., Horodecki--Shor--Ruskai, Choi, and Prudhoe; its scope and direct source links are in [SOURCE_AUDIT.md](SOURCE_AUDIT.md).

The proof has no input data or sample-complexity cost. The algebraic representation description grows with \(d\); the result is not an efficient implementation of a broadcaster or a measurement procedure. The load-bearing checks are the Choi normalization and sign in (4), completeness of the three contraction intertwiners for \(d\geq4\), positivity of the antisymmetric-block Gram matrix, identities (9)--(10), and feasibility of the twirled top state. A failed identity in any one of these steps would falsify this derivation. The exact \(d=4\) ququart certificate is cross-linked in [the prior audit](SOURCE_AUDIT.md).

Higher Clifford-form covariant actions, multiplicity-bearing representations, noncovariant channels, and the bounded-Holevo-to-EB implication remain open gates. This structured result supplies no obstruction to a universal constant for arbitrary channels.
