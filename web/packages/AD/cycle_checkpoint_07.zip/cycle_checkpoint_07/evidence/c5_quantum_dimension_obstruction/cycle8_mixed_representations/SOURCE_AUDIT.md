# Spin(5) / Sp(2) cloning and EB prior-art audit

## Finding

Both target maps have exact standard constructions. The universal $1\to2$ ququart cloner, restricted from $U(4)$ to the spinor image of $\operatorname{Spin}(5)\simeq\operatorname{Sp}(2)$, is a legal symmetric broadcaster whose two marginal transfer values are exactly

\[
\lambda_{5}=\lambda_{10}=\frac35.
\]

It is an extreme point even in the full convex set of CPTP maps $M_4\to M_4\otimes M_4$, as verified below. Separately, the spinor pure-state orbit measurement-and-prepare channel is exactly

\[
\Psi(X)=\frac{X+\operatorname{Tr}(X)I}{5},
\]

the ordinary $U(4)$-covariant pure-state estimation channel restricted to $\operatorname{Sp}(2)$. These are exact matches for the broadcaster and EB comparator used in the workspace Spin(5) argument. The prior sources establish those channel constructions and general covariant-channel background; they do **not** state the newer common-comparator/two-sector star inequality or the full Spin(5)-compatible-channel region. No novelty or priority conclusion follows from this bounded audit.

## Exact broadcaster and transfer calculation

Werner's universal pure-state $N\to M$ map is

\[
\widehat T(\rho)=\frac{d[N]}{d[M]}P_M\bigl(\rho\otimes I^{\otimes(M-N)}\bigr)P_M,
\qquad d[k]=\binom{d+k-1}{k},
\]

where $P_M$ is the Bose projector [Werner, Eq. (3.3)](https://arxiv.org/html/quant-ph/9804001). For $N=1,M=2,d=4$, this gives

\[
\Lambda(X)=\frac25 P_+(X\otimes I)P_+,
\qquad P_+=\frac{I+F}{2}.
\tag{1}
\]

The projector sandwich is CP. For any $X$,

\[
\operatorname{Tr}\Lambda(X)=\frac25\operatorname{Tr}\bigl(P_+(X\otimes I)P_+\bigr)
=\frac25\frac{d+1}{2}\operatorname{Tr}X=\operatorname{Tr}X
\quad(d=4),
\]

so the map is TP. Its output is supported on the symmetric subspace; hence it is invariant under swapping outputs. The construction is $U(4)$-covariant and therefore also $\operatorname{Spin}(5)$-covariant.

Using $P_+=(I+F)/2$ and the partial-trace identities
$\operatorname{Tr}_2[(X\otimes I)F]=\operatorname{Tr}_2[F(X\otimes I)]=X$,

\[
\operatorname{Tr}_2\!\left[P_+(X\otimes I)P_+\right]
=\frac{(d+2)X+\operatorname{Tr}(X)I}{4}.
\]

Thus either marginal of (1) is

\[
\Phi(X)=\frac{6X+\operatorname{Tr}(X)I}{10}
=\frac35X+\frac25\frac{\operatorname{Tr}(X)}4I.
\tag{2}
\]

It is unital and trace preserving, and acts by $3/5$ on **every** traceless operator. In particular it has the same transfer $3/5$ on the inequivalent Spin(5) spinor-operator sectors of dimensions 5 and 10. Keyl--Werner state the one-clone shrink factor as $\gamma=\frac{N}{N+d}\frac{M+d}{M}$, which is $3/5$ at these parameters, and prove that their universal cloner is the unique optimum also for the single-clone criterion [Keyl--Werner, abstract and one-clone factor formula](https://arxiv.org/html/quant-ph/9807010). This is a dimension-four instance of universal cloning, not a distinct Spin(5)-specific cloner.

### Extremality certificate

Fix an orthonormal basis \(\{|i\rangle\}_{i=1}^4\) and define Kraus operators from \(\mathbb C^4\) to \(\mathbb C^4\otimes\mathbb C^4\) by

\[
K_i|\psi\rangle=\frac{|\psi\rangle\otimes|i\rangle+|i\rangle\otimes|\psi\rangle}{\sqrt{10}}.
\]

Then (1) is $\Lambda(X)=\sum_iK_iXK_i^\dagger$, and direct multiplication gives

\[
K_i^\dagger K_j=\frac15\bigl(\delta_{ij}I+|j\rangle\langle i|\bigr).
\tag{3}
\]

For $i\ne j$, these are the twelve off-diagonal matrix units up to a nonzero scalar. For $i=j$, the four matrices are $I+|i\rangle\langle i|$; they are independent because their coefficient matrix is $I_4+\mathbf 1\mathbf 1^{\mathsf T}$, with eigenvalues $5,1,1,1$. Hence the sixteen $K_i^\dagger K_j$ are linearly independent and span $M_4$. By the Kraus-product extremality criterion for CPTP maps (see Choi, [“Completely positive linear maps on complex matrices”](https://doi.org/10.1016/0024-3795(75)90075-0)), (1) is extreme in the full CPTP set, not merely in a covariant subclass. This verifies the requested “legal extremal broadcaster” claim directly.

## Exact orbit EB map

The four-dimensional spinor is the defining complex representation of compact $\operatorname{Sp}(2)$. Its action is transitive on pure-state rays, and $\operatorname{Sym}^2(\mathbb C^4)$ is the irreducible 10-dimensional representation. Therefore, for any fixed rank-one projector $P$, normalized Haar averaging over the orbit gives

\[
\int P_g\,dg=\frac I4,
\qquad
\int P_g\otimes P_g\,dg=\frac{P_+}{10}=\frac{I+F}{20}.
\]

The effects $4P_g\,dg$ form a POVM. Preparing $P_g$ after outcome $g$ gives

\[
\Psi(X)=4\int\operatorname{Tr}(P_gX)P_g\,dg
=4\operatorname{Tr}_1\!\left[(X\otimes I)\frac{I+F}{20}\right]
=\frac{X+\operatorname{Tr}(X)I}{5}.
\tag{4}
\]

So $\Psi$ is exactly EB on the full operator domain, unital and TP, and has transfer $1/5$ on both traceless Spin(5) sectors. Since the orbit is the full projective space, this is also the standard $U(4)$-covariant pure-state estimation measure-and-prepare map: the covariant-estimation literature gives the pure-state $SU(d)$ kernel $d|\psi\rangle\langle\psi|$ [Chiribella et al., Sec. V.1.1](https://arxiv.org/html/quant-ph/0403083). The Holevo-form characterization of EB channels as measurement followed by state preparation is established by Horodecki--Shor--Ruskai [Theorem 4](https://arxiv.org/html/quant-ph/0302031). Neither reference presents (4) as a new Sp(2)-specific channel.

## Symplectic-covariant channel threshold literature

Prudhoe's *Entanglement Breaking Structure of Cartan-Covariant Quantum Channels* explicitly treats the compact $\operatorname{Sp}(n/2)$-covariant class; for $n=4$, this is $\operatorname{Sp}(2)$ in its defining representation. The adjoint invariant subspace has dimension $\dim\mathfrak{sp}(2)=10$; its complement in the 15-dimensional traceless operator space has dimension 5. This is the same $10\oplus5$ operator-sector decomposition as the Spin(5) bivector/vector split. The arXiv record lists v3 revised 7 Aug 2026; I did not independently verify later publication status. The paper derives CP/CCP and EB structure from invariant Choi matrices and shows, for symplectic covariant channels, that EB is a proper subset of PPT in its stated parameter regime and that the class satisfies PPT-squared [arXiv v3, revised 7 Aug 2026](https://arxiv.org/abs/2501.03959; [Sp-invariant Choi matrices, Sec. 3](https://arxiv.org/html/2501.03959#S3)).

This is adjacent but not the same threshold: that source's parameters describe one-channel CP/PPT/EB regions. It does not derive symmetric two-output extendibility, the $3/5$ one-site shrink boundary, or the comparison with (4). The marginal (2) lies on the universal depolarizing $1\to2$ cloning boundary along the $U(4)$-isotropic line; the internal Spin(5) star proof separately shows the two sectorwise inequalities $\lambda_5,\lambda_{10}\le3/5$. Do not read the Sp(2) CP/PPT/EB region as an independent prior source for that broadcasting statement.

Chiribella--D'Ariano--Perinotti--Cerf provide a general representation-theoretic treatment of extremal group-covariant cloners for invariant state families ([arXiv:quant-ph/0507130](https://arxiv.org/html/quant-ph/0507130); Theorem 1 in the irreducible-representation setting). It supplies useful framework, but the exact ququart formula above is already the universal Werner cloner, and the explicit CPTP extremality check here does not rely on identifying their parameterization with this Sp(2) orbit.

## Source/claim ledger

| Claim | Source status |
|---|---|
| Formula (1), including CP/TP and symmetric-output universal $N\to M$ construction | Exact standard match: Werner, Eq. (3.3), specialized to $d=4,N=1,M=2$. |
| Marginal transfer $3/5$ | Exact standard match: direct marginal trace above; also Keyl--Werner's one-clone shrink factor. |
| A legal extremal symmetric broadcaster attains both sector values $3/5$ simultaneously | Exact construction plus independent finite algebraic certificate (3) and Choi extremality criterion. This identifies an attained boundary point, not the whole anisotropic compatibility region. |
| Formula (4) as a full-domain EB map | Exact standard match: spinor projective orbit 2-design and the standard $SU(4)$ pure-state estimation channel. |
| Sp(2)-covariant CP/PPT/EB channel-region analysis | Relevant primary background in Prudhoe; it treats one-channel positivity/separability thresholds, not two-extendibility. |
| A universal common-EB comparison for every compatible Spin(5)-covariant channel, or the full compatible region | Not identified in the checked sources. This is only a bounded search outcome; it supports no novelty or priority claim. The proof in `cycle6_dual_star/SPIN5_QUQUART_COVARIANT.md` is internal to this workspace. |

## Search boundary

Checked primary-source full texts and metadata for Werner (quant-ph/9804001), Keyl--Werner (quant-ph/9807010), Chiribella et al. on extremal covariant cloners (quant-ph/0507130), Chiribella et al. on covariant pure-state estimation (quant-ph/0403083), Horodecki--Shor--Ruskai on EB channels (quant-ph/0302031), and Prudhoe's Sp-covariant channel paper (arXiv:2501.03959, v3). Targeted arXiv searches used queries combining “Spin(5)”, “Sp(2)”, “spinor”, “covariant quantum cloning”, “entanglement breaking”, “measure and prepare”, and “compatibility/broadcasting”. The search surfaced no separate Spin(5)-specific optimal cloner that improves on or replaces the $U(4)$ universal cloner above. This was a bounded search, not a systematic review; no absence, novelty, or priority claim is made.

## External references

- R. F. Werner, [“Optimal Cloning of Pure States,” arXiv:quant-ph/9804001](https://arxiv.org/abs/quant-ph/9804001).
- M. Keyl and R. F. Werner, [“Optimal Cloning of Pure States, Judging Single Clones,” arXiv:quant-ph/9807010](https://arxiv.org/abs/quant-ph/9807010).
- G. Chiribella, G. M. D'Ariano, P. Perinotti, and N. J. Cerf, [“Extremal quantum cloning machines,” Phys. Rev. A 72, 042336 (2005)](https://arxiv.org/abs/quant-ph/0507130).
- G. Chiribella, G. M. D'Ariano, P. Perinotti, and M. F. Sacchi, [“Covariant quantum measurements which maximize the likelihood,” Phys. Rev. A 70, 062105 (2004)](https://arxiv.org/abs/quant-ph/0403083).
- M. Horodecki, P. W. Shor, and M. B. Ruskai, [“General Entanglement Breaking Channels,” Rev. Math. Phys. 15, 629 (2003)](https://arxiv.org/abs/quant-ph/0302031).
- M.-D. Choi, [“Completely positive linear maps on complex matrices,” Linear Algebra and its Applications 10(3), 285–290 (1975)](https://doi.org/10.1016/0024-3795(75)90075-0).
- S. Prudhoe, [“Entanglement Breaking Structure of Cartan-Covariant Quantum Channels,” arXiv:2501.03959v3](https://arxiv.org/abs/2501.03959).
