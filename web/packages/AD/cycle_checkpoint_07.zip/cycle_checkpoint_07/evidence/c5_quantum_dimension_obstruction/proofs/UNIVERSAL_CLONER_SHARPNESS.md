# Exact factor-two sharpness certificate

Fix (d\ge2). The optimal symmetric universal (1\to2) cloner has one-site marginal

\[
\Phi_d(X)=\eta X+(1-\eta)\operatorname{Tr}(X)I/d,
\qquad \eta=(d+2)/(2(d+1)).
\]

The joint cloning channel is a full-domain symmetric CPTP extension, so Φ_d is self-compatible. The map is unital, trace preserving and Hilbert--Schmidt self-adjoint. On the traceless Hermitian space its eigenvalue is η, and on the identity its eigenvalue is (1).

Let Ψ be any EB CPTP channel satisfying (I-\Psi\preceq c(I-\Phi_d)). Haar twirl it:

\[
\bar\Psi(X)=\int U^*\Psi(UXU^*)U\,dU.
\]

The twirl is CPTP and EB. Since Φ_d is covariant, averaging the conjugates of the assumed positive-semidefinite difference proves (I-\bar\Psi\preceq c(I-\Phi_d)). By irreducibility of the traceless representation, Ψ-bar has depolarizing form (\bar\Psi(X)=\mu X+(1-\mu)\operatorname{Tr}(X)I/d).

With normalized maximally entangled vector 
\[
|\Omega\rangle=d^{-1/2}\sum_{i=1}^d|ii\rangle,
\]
its normalized Choi state is (J_\mu=\mu|\Omega\rangle\langle\Omega|+(1-\mu)I/d^2). For a product unit vector (|a\rangle\otimes|b\rangle),
\[
|\langle\Omega|a\otimes b\rangle|^2=d^{-1}|\langle\bar a|b\rangle|^2\le d^{-1}.
\]
Convexity extends this to all separable states. Since Ψ-bar is EB, (J_\mu) is separable and hence
\[
\mu+(1-\mu)/d^2\le 1/d,
\qquad \mu\le 1/(d+1).
\]

Apply the operator inequality to any traceless Hermitian unit vector. This gives (1-\mu\le c(1-\eta)), so
\[
c\ge\frac{1-\mu}{1-\eta}\ge\frac{d/(d+1)}{d/(2(d+1))}=2.
\]

For attainment, the Haar POVM (d|\psi\rangle\langle\psi|d\psi), followed by preparation of (|\psi\rangle\langle\psi|), is an EB channel. The Haar second-moment identity gives
\[
\Psi_d(X)=d\int \operatorname{Tr}(P_\psi X)P_\psi d\psi
=\frac{X+\operatorname{Tr}(X)I}{d+1}.
\]
It has μ=1/(d+1), so equality holds on the traceless subspace and both differences vanish on the identity. This proves that the universal comparison constant, if it exists, cannot be less than (2).

## Precision and falsifiers

The proof is exact and uses no numerical approximation. A derivation-level falsifier would be an incorrect universal-cloner marginal coefficient, an invalid Choi normalization, or a separable state whose maximally entangled overlap exceeds (1/d). The only external input is the established universal-cloner construction and marginal coefficient; the EB overlap inequality is proved above.
