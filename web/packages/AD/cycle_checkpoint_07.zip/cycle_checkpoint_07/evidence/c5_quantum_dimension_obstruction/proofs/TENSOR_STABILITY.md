# Exact tensor stability certificate

Let (Phi_j,Psi_j) be self-adjoint maps with common orthonormal eigenbasis on each factor, and suppose all factor eigenvalues satisfy (0\le\lambda_j,\mu_j\le1) and μ_j\ge2λ_j−1. Then on a product eigenmode the tensor eigenvalues are

\[
\lambda=\prod_{j=1}^k\lambda_j,
\qquad \mu=\prod_{j=1}^k\mu_j.
\]

If any factor has λ_j\le1/2, then λ\le1/2 and μ\ge0\ge2λ−1. Otherwise all factors have (2\lambda_j−1>0). If the full product λ\le1/2, the same nonnegative-comparator argument applies. For λ>1/2, prove by induction

\[
\prod_{j=1}^k(2\lambda_j-1)\ge2\prod_{j=1}^k\lambda_j-1.
\]

The claim is equality at (k=1). If it holds for product (a>1/2), adding (t\in(1/2,1]) preserves it because

\[
(2a-1)(2t-1)-(2at-1)=2(1-a)(1-t)\ge0.
\]

Thus μ\ge2λ−1 for every tensor mode. As the product eigenbasis spans the whole tensor operator space, one product map satisfies (I-\otimes_j\Psi_j\preceq2(I-\otimes_j\Phi_j)).

If each Ψ_j is EB, their tensor product is EB. If each Φ_j has a supplied symmetric broadcaster (B_j), take the product of these channels and regroup first outputs and second outputs; both marginals equal ⊗Φ_j. Thus this is a common full-domain channel statement, not a family of modewise comparators.

## Exact application inherited from the d=5 fixture

The prior audit `work/agents/quantum_physics/broadcast_lift/D5_AUDIT.md` reports a channel Φ_5 with all nonidentity eigenvalues in 
\(
\{0.4638026469\ldots,0.5883098718\ldots,0.5398612374\ldots,0.7269225009\ldots\}
\)
and a common Weyl-covariant EB comparator whose 24 interval-checked gaps μ_x−(2λ_x−1) are all positive (minimum exceeds 0.0236). The comparator spectrum is nonnegative because it is a positive mixture of squared Weyl expectations. Assuming that inherited exact certificate, the tensor theorem proves the factor-two comparison for Φ_5^{⊗k} and Ψ_5^{⊗k} for every (k\ge1).

This branch did not rerun the interval checker. The base certificate's exact data and implementation are in the referenced audit and `work/agents/quantum_physics/broadcast_lift/scripts/d5_rational_interval_comparator.py`.
