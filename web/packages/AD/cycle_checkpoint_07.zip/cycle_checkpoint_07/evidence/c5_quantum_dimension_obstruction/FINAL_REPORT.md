# C5: adversarial search beyond the logarithmic EB lift

## Verdict

I found no high-dimensional counterexample to a dimension-free Dirichlet comparison and no bounded-Holevo family with vanishing two-output broadcast error but EB error bounded away from zero. The strongest exact adversarial check is the universal (1\to2) qudit cloner: it proves that any universal constant must be at least (2), in every dimension, and the covariant EB comparator attains (2) exactly. Thus the proposed factor is sharp, not merely a convenient target.

A second exact result rules out a natural amplification strategy. Factor-two comparisons with nonnegative, simultaneously diagonalizable transfer operators tensorize with the same constant. In particular, tensor powers of the repaired (d=5) Weyl channel remain factor-two comparable to a single full-domain EB product channel. A growing number of tensor factors cannot turn the (d=5) line-cover failure into an Ω(log d) lower bound.

These results support a structural reason to expect (2) for product and isotropic families, but do not prove it for a general self-compatible channel. The N93 bounded-Holevo implication remains UNKNOWN.

## Interface

The operator comparison is on the real Hilbert space of Hermitian matrices with normalized Hilbert--Schmidt inner product. A channel Φ is unital, trace preserving, Hilbert--Schmidt self-adjoint, and self-compatible when a full-domain CPTP map into two output copies has both marginals equal to Φ. The desired comparison is one full-domain EB CPTP map Ψ satisfying (I-\Psi\preceq c(I-\Phi)). The results below concern complete channels, not statewise witnesses.

## Exact lower bound (c\ge2), attained by the universal cloner

For each (d\ge2), let Φ_d be the marginal of the optimal symmetric universal (1\to2) qudit cloner. Its depolarizing parameter is

\[
\eta_d=\frac{d+2}{2(d+1)},\qquad
\Phi_d(X)=\eta_dX+(1-\eta_d)\frac{\operatorname{Tr}X}{d}I.
\]

This map satisfies the stated channel assumptions and is self-compatible by construction. Twirl any proposed EB comparator Ψ under (X\mapsto U XU^*\). Twirling preserves complete positivity, trace preservation, entanglement breaking, and the Loewner comparison because Φ_d is unitarily covariant. The twirled map is a depolarizing channel with some traceless eigenvalue μ.

The normalized Choi state of a depolarizing channel is

\[
J_\mu=\mu\,|\Omega\rangle\langle\Omega|+(1-\mu)I/d^2.
\]

For every separable state (\sigma=\sum_jp_j\rho_j\otimes\omega_j), one has (\langle\Omega|\sigma|\Omega\rangle\le1/d), since this holds for every product state by Cauchy--Schwarz. Thus EB implies

\[
\mu+(1-\mu)/d^2\le1/d,
\quad\text{so}\quad \mu\le1/(d+1).
\]

Testing the operator inequality on any traceless Hermitian matrix gives

\[
1-\mu\le c(1-\eta_d).
\]

Consequently

\[
c\ge\frac{1-\mu}{1-\eta_d}
\ge\frac{d/(d+1)}{d/[2(d+1)]}=2.
\]

Equality is attained by the EB covariant measure-and-prepare channel

\[
\Psi_d(X)=d\int \operatorname{Tr}(|\psi\rangle\langle\psi|X)\,|\psi\rangle\langle\psi|\,d\psi
=\frac{X+\operatorname{Tr}(X)I}{d+1},
\]

where (d\psi) is Haar probability measure. Its traceless eigenvalue is μ=1/(d+1); its Choi state saturates the separable-overlap bound, and on the traceless subspace (I-\Psi_d=2(I-\Phi_d)). Both sides vanish on the identity. This is a common full-map certificate and lower bound against every EB comparator, after twirling.

The cloning marginal is established prior work; this report's contribution is the direct conversion of its covariance and the isotropic EB threshold into a sharp lower bound for this operator-order problem. The primary cloning source is Keyl--Werner, [Optimal Cloning of Pure States, Judging Single Clones](https://arxiv.org/abs/quant-ph/9807010). No priority claim is made for the isotropic-state calculation.

## Tensor stability of factor two

Let each Φ_j and Ψ_j be self-adjoint contractions on a finite-dimensional real Hilbert space, diagonal in a shared orthonormal basis, with eigenvalues (0\le\lambda_j,\mu_j\le1) on the chosen mode and

\[
\mu_j\ge 2\lambda_j-1.
\]

For a tensor mode, the eigenvalues are λ=\(\prod_j\lambda_j\) and μ=\(\prod_j\mu_j\). If any λ_j\le1/2, then λ\le1/2 and μ\ge0\ge2λ-1. Otherwise every (2\lambda_j-1\) is nonnegative and

\[
\prod_j\mu_j\ge\prod_j(2\lambda_j-1)\ge2\prod_j\lambda_j-1.
\]

For the last inequality, induct on the number of factors. If (a=\prod_{j=1}^k\lambda_j>1/2) and (t\in(1/2,1]), then

\[
(2a-1)(2t-1)-(2at-1)=2(1-a)(1-t)\ge0.
\]

Thus (I-\bigotimes_j\Psi_j\preceq2(I-\bigotimes_j\Phi_j)). Tensor products of EB maps remain EB; tensor products of supplied two-output broadcasters give a full-domain broadcaster for the tensor-product channel. The proof does not use a modewise selection of different maps: the one product map ⊗Ψ_j works on the entire operator space.

The common-eigenbasis and nonnegative-spectrum conditions matter. This argument does not cover noncommuting transfer operators, negative eigenvalues, or an arbitrary self-compatible channel.

## Application to the (d=5) Weyl line-cover counterexample

The existing exact (d=5) audit gives a self-compatible Weyl random-unitary channel Φ_5 and one Weyl-covariant EB channel Ψ_5. The channel's algebraic compatibility kernel is rank one over \(\mathbb Q(\sqrt5)\); the comparator is a mixture of six twirled product Choi states with exact rational ket coordinates. The interval audit certifies all 24 nonidentity inequalities μ_x\ge2λ_x-1, with minimum direct slack greater than (0.0236). The same channel violates the naive sum-of-line-peaks budget (1.3369\ldots>1), but this is not an EB obstruction.

Every nonidentity eigenvalue of Φ_5 is positive, and every comparator mode μ_x is nonnegative. Therefore for each (k\ge1),

\[
\Phi_{5^k}=\Phi_5^{\otimes k},\qquad
\Psi_{5^k}=\Psi_5^{\otimes k}
\]

is an exact self-compatible channel and a single full-domain EB comparator satisfying (I-\Psi_{5^k}\preceq2(I-\Phi_{5^k})). The base certificate is inherited from [the (d=5) audit](../../quantum_physics/broadcast_lift/D5_AUDIT.md); I did not rerun its interval checker. The product extension itself is proved above and requires no new numerical search.

This exact sequence closes one tempting route to a growing lower bound: tensoring a finite-dimensional example that defeats a restricted family of EB maps does not help once that base channel has a common EB repair and the spectra are nonnegative.

## Costs, limits, and decisive next gate

The universal-cloner calculation has no data-acquisition step. Its dimension parameter is (d); the broadcaster and comparator are exact covariant channels. The comparator can be represented by the covariant measure-and-prepare channel, while a full Choi table costs (d^4) entries if explicitly materialized. The proof uses no finite-precision computation.

The (d=5) base record stores 25 Weyl probabilities and a 25-by-25 algebraic rank-one compatibility kernel. Its EB comparator uses six rational five-component kets and positive weights. The prior interval checker encloses radicals through integer-square checks and verifies 24 scalar gaps; its result is internal evidence, not independent external verification. The tensor sequence has a succinct (k=\log_5d)-factor description. Explicitly expanding a full superoperator would cost (d^4) coefficients; the tensor proof avoids this expansion.

No large SDP search, bounded-Holevo family construction, or numerical test was run. The remaining load-bearing question is whether a non-product, non-isotropic compatible channel can have a high-dimensional frame of modes that defeats every common EB map. A valid counterexample must provide a symmetric Choi extension and a positive dual frame (Q) separating the full EB set, or a bounded-Holevo state family with vanishing worst two-output marginal error and nonvanishing optimal full-domain EB error. A line-cover failure or separate one-map-per-state witnesses is insufficient.

The first proof attack for the universal conjecture should target channels whose near-fixed operator space is not close to an abelian algebra, rather than products of local cloners or Weyl channels with an already certified comparator. The first falsifier of the scoped tensor result is a factor/eigenmode violating the scalar induction above; the assumptions make that impossible by direct algebra.
