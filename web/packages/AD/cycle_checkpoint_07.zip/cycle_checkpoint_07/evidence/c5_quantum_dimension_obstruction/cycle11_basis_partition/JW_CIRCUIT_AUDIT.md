# Cycle 11 addendum: four-qubit Pauli readout circuit

## Scope

`FINAL_REPORT.md` certifies the exact (9/63/72) orthonormal-basis partitions
in the octonionic real-spinor coordinates. This addendum compiles the same
Spin(9)-covariant POVMs in the Pauli/Jordan--Wigner realization, where the
four-qubit Clifford gates are explicit. It is a circuit-interface result for
this fixed covariant (d=16) class; it does not extend the comparator theorem
to arbitrary channels or arbitrary dimensions.

## Exact seed-basis diagonalizers

The 256 even-sign Spin lifts form the projective four-qubit Pauli group in
the Jordan--Wigner realization. For each seed, the subgroup fixing its ray
has order 16 and is a maximal abelian Pauli subgroup. The checker maps every
one of these 16 stabilizer elements from the octonionic Clifford matrices to
the signed Jordan--Wigner Pauli word, verifies closure/commutation exactly,
and finds a Clifford (C_i) taking the computational basis to the seed
orbit's 16-vector basis. The complete signed Pauli tableaux and gate lists
are in `STABILIZER_READOUT_CERTIFICATE.json`.

| Seed | Bases | `C_i` preparation gates from `|0000>` | `C_i^dagger` measurement gates |
|---|---:|---|---|
| (v_R) | 9 | X0, H0, X1, CNOT(0,1), CNOT(0,3), CNOT(1,2) | reverse list |
| (v_V) | 63 | X0, X3 | reverse list |
| (v_H) | 72 | H0, S0, X1, H1, X3, CNOT(1,2), CNOT(1,3), CNOT(3,0) | reverse list with S0 replaced by S0^dagger |

The gate lists are in the transcript order used by the checker; all labels
are zero-based qubit indices. The tableaux certify the entire basis, not only
one seed vector: (C_i) maps the four computational (Z) generators to
generators of the ray-stabilizer subgroup. Its 16 images of computational
basis vectors therefore give exactly the even-sign seed orbit, up to a
permutation of outcome labels and global phases.

The octonionic and Jordan--Wigner Clifford generators have the same positive
volume element. An exact (16\times16) Gaussian-integer intertwiner (W)
satisfies (W\Gamma_a^{oct}=\Gamma_a^{JW}W), (W^*W=2I); hence (W/\sqrt2)
is unitary. The certificate stores this matrix. The runtime gates below are
specified directly in Jordan--Wigner computational coordinates, so this
fixed representation equivalence is not a runtime gate. Translating an
already-fixed octonionic device encoding into this coordinate convention
would require an additional synthesis of (W/\sqrt2), which is not charged
or claimed here.

## Random-basis measurement

For seed (i), let (m_i\in\{9,63,72\}) be its number of basis blocks and
let (p) be the stored representative of a right coset in
\(PGL_2(8)/H_i\), where the exact setwise stabilizer orders are
\(|H_R|=56, |H_V|=8, |H_H|=7\). The basis is
\[
  \{U_p C_i|j\rangle: j\in\{0,1\}^4\}.
\]
Choose one of the (m_i) cosets uniformly, apply (U_p^\dagger) followed
by (C_i^\dagger), and measure the four qubits in (Z). The effects are
\[
  E_{p,j}=m_i^{-1}U_pC_i|j\rangle\langle j|C_i^*U_p^*.
\]
Since (m_i=N_i/16), these are exactly (16/N_i) times the distinct
projector-orbit elements from Cycle 10. Thus this randomized projective
measurement implements the same finite canonical POVM, not a new or
approximating one. For the common comparator, first choose seed (i) with
the compiler's common mixture probability (q_i), retaining that seed tag;
the resulting single POVM has effects (q_iE_{p,j}) and defines one full
measure-and-prepare EB map for all test directions.

In the Jordan--Wigner representation each Γ_a is a Pauli word. For all 36
axis pairs the checker exactly verifies that
\(P_{ab}=i\Gamma_a\Gamma_b\) is a signed Hermitian Pauli word of weight at
most four. The reflection factor in a permutation lift has the identity
\[
  R_{ab}=(\Gamma_a-\Gamma_b)/\sqrt2
       =\Gamma_a\exp(i\pi P_{ab}/4).
\]
An exact parity-network implementation of this Pauli quarter-turn uses at
most (2(w-1)\le6) CNOTs, one (R_z(\pm\pi/2)), and local Clifford gates;
the Γ_a factor is local Pauli. Every PGL representative has a certified
factorization into at most eight coordinate transpositions. Therefore one
selected-basis input readout costs at most 48 CNOTs, 8 exact quarter-turns,
plus at most 3 CNOTs for (C_i^\dagger) and the listed local Clifford gates.
The input readout measures four bits and uses no ancillary qubits.

If the EB channel is physically executed as measure-and-prepare, output
preparation applies (C_i), the same at-most-eight-reflection lift (U_p),
and at most four (X) gates to prepare the observed computational label
\(|j\rangle). Counting both input and output sides gives a conservative
upper bound of 96 CNOTs and 16 exact Pauli quarter-turns per channel use,
plus at most 6 seed-basis CNOTs and local Clifford/label-initialization
gates. This bound follows the unreduced transposition factorization; it is
not claimed optimal.

Uniform coset selection by drawing (L=\lceil\log_2m_i\rceil) fair bits
and rejecting values at least (m_i) has expected random-bit costs
\(64/9\), (128/21), (112/9) for (R,V,H), respectively. The basis
register uses 4, 6, or 7 fixed-width bits; the outcome is four bits, so a
fixed-width POVM outcome label uses 8, 10, or 11 bits. A static table stores
one representative per coset and its at-most-eight-reflection factorization;
it is indexed by the basis register. Effects have exact rational entries,
with largest coefficient denominators 144, 1008, 1152 for (R,V,H). No
floating-point approximation is needed. If a common mixture (q_i) is
derived from non-rational supplied transfers, finite-bit computation of the
mixture and its sampling precision are a separate input-precision issue.

## Verification and boundary

Run:

```sh
python3 work/agents/c5_quantum_dimension_obstruction/cycle11_basis_partition/stabilizer_readout.py
```

The script exact-checks the representation intertwiner, all 36 Pauli
reflection axes, each 16-element seed stabilizer group, and the BFS-produced
Clifford circuit by replaying its conjugation action on the complete
stabilizer tableau. SymPy is used only for the exact (16\times16)
intertwiner; group and stabilizer operations use integer phase/binary
arithmetic. `basis_partition.py` separately checks every projector, coset
block, disjointness, union, and orthogonality edge in the three finite
orbits. These are internal exact computations, not proof-assistant
verification or external review.

The gate bound is in a declared four-qubit CNOT + local-Clifford + exact
\(R_z(\pi/2)\) model. It gives a small, explicit readout circuit in the
Jordan--Wigner coordinates and replaces the generic large Naimark upper
bound for these three finite POVMs. It is not a hardware advantage claim:
connectivity, native gate calibration, noise, routing, classical table
lookup, and the fixed octonion-to-Jordan--Wigner coordinate conversion are
not experimentally measured here.
