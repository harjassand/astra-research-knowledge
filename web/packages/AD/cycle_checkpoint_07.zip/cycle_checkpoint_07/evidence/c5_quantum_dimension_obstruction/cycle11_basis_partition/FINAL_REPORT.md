# Cycle 11: exact orthonormal-basis partitions

## Result

All three finite Spin(9) projector orbits partition exactly into orthonormal bases. The 144-ray $v_R$ orbit gives 9 bases, the 1008-ray $v_V$ orbit gives 63, and the 1152-ray $v_H$ orbit gives 72. The executable checker reconstructs the Cycle 10 Spin lifts and projectors, verifies every seed basis and PGL coset block over exact integers, and checks the full orthogonality graph. Its output and machine-readable certificate are [basis_partition_output.txt](basis_partition_output.txt) and [BASIS_CERTIFICATE.json](BASIS_CERTIFICATE.json).

The 16 rays from the even-sign subgroup form the seed basis in each case. For $v_R=x$, they are the computational basis $\{|j\rangle:0\leq j<16\}$. For $v_V=(x+i y_V)/\sqrt2$, they are the product basis with the computational basis on bits 1–3 and the $Y$ basis on bit 0:
\[
 (|2r\rangle\pm i|2r+1\rangle)/\sqrt2,\quad 0\leq r<8.
\]
For $v_H=(x+i y_H)/\sqrt2$, replace bit 0 with bit 3:
\[
 (|r\rangle\pm i|r+8\rangle)/\sqrt2,\quad 0\leq r<8.
\]
Thus the basis-change unitary is $B=I$ for $R$ and $B=SH$ on the indicated one qubit for $V,H$. The 256 even-sign elements have exactly 16 distinct projectors on each seed, and the checker verifies that those projectors equal these displayed bases.

Let $H_i\leq PGL_2(8)$ be the setwise stabilizer of the corresponding 16-ray seed basis. Its orders are 56, 8, and 7. Exact enumeration identifies the $R$ stabilizer with the point stabilizer of infinity, the affine group $(C_2)^3\rtimes C_7=AGL(1,8)$; the $V$ stabilizer is abelian of order 8 with every nonidentity element of order 2, hence $C_2^3$; and the $H$ stabilizer has six elements of order 7, hence $C_7$. The full signed-vector group stabilizers of the basis blocks have orders 14,336, 2,048, and 1,792. The left cosets $pH_i$ therefore give respectively 9, 63, and 72 blocks. The certificate checks the blocks are pairwise disjoint and their union is exactly the complete Cycle 10 projector orbit.

The exact orthogonality graphs have these summaries:

| Orbit | Rays | Degree of every vertex | Edges | Components |
|---|---:|---:|---:|---:|
| $v_R$ | 144 | 15 | 1,080 | nine of size 16 |
| $v_V$ | 1,008 | 343 | 172,872 | one of size 1,008 |
| $v_H$ | 1,152 | 387 | 222,912 | one of size 1,152 |

For $R$, the basis blocks are also precisely the orthogonality graph components. For $V,H$, they are partitions of connected graphs; there are additional orthogonality edges between different basis blocks.

## Discrete measurement and costs

Choose a representative $p$ of a left coset $pH_i$ uniformly and measure in the basis $U_pB\{|j\rangle\}_{j=0}^{15}$. The resulting POVM effects are exactly
\[
 E_{p,j}=\frac1{m_i}U_pB|j\rangle\langle j|B^*U_p^*,\qquad
 m_i\in\{9,63,72\}.
\]
For each selected $p$, summing over $j$ gives $I/m_i$; summing over the $m_i$ cosets gives $I$. Each effect is $16/N_i$ times a distinct orbit projector, hence this is exactly the Cycle 10 canonical POVM. For its measure-and-prepare channel, prepare the observed $|j\rangle$, then apply $B$ and $U_p$.

The charged exact gate interface is:

- Input measurement: apply $U_p^*=U_p^{-1}$, then $B^*$, then measure four computational bits.
- Output preparation: use a fresh $|0000\rangle$ register and at most four $X$ gates to prepare the four-bit outcome, then apply $B$ and $U_p$.
- Each $U_p$ or $U_p^{-1}$ uses at most 8 exact four-qubit Spin reflection gates $(\Gamma_a-\Gamma_b)/\sqrt2$. The complete measure-and-prepare use therefore costs at most 16 such reflection-gate invocations. $B,B^*$ cost zero one-qubit gates for $R$, and two one-qubit Clifford gates each for $V,H$. The even-sign subgroup costs no gates: its 16 rays are exactly the seed basis measurement outcomes.

The four-qubit reflections are an explicit exact gate interface in the Cycle 10 real spinor coordinates. An elementary hardware-gate synthesis of these particular reflection matrices is not independently certified here; no efficient hardware implementation is claimed. The exact Spin lift matrices have rational entries with reduced common denominator at most 4; each reflection uses the exact coefficient $1/\sqrt2$. Seed basis gates use only $H,S,S^*$, and balanced seed amplitudes use $1/\sqrt2$ and phase $i$. The orbit effects have rational real and imaginary entries. Their largest reduced entry denominators and numerator magnitudes are:

| Orbit | Nonzero entry denominators | Maximum denominator bits | Maximum numerator |
|---|---:|---:|---:|
| $v_R$ | 9, 144 | 8 | 1 |
| $v_V$ | 126, 1,008 | 10 | 1 |
| $v_H$ | 144, 1,152 | 11 | 1 |

No floating-point precision is needed for the symbolic effects. A basis index uses 4, 6, or 7 fixed-width bits. Exact uniform selection by drawing $L=\lceil\log_2 m_i\rceil$ fair bits and rejecting values at least $m_i$ uses expected $64/9$, $128/21$, or $112/9$ fair bits per selection, respectively. Readout is four bits. A simple stored permutation label uses 9 four-bit point images (36 bits per coset representative), for flat representative tables of 324, 2,268, or 2,592 bits; the full lists are included in the certificate.

## Verification boundary

Run \`python3 basis_partition.py\` from this directory. The standard-library checker imports the exact Cycle 10 construction without writing bytecode there, enumerates all 504 projective permutations and all 256 even-sign actions, constructs every projector orbit and orthogonality edge, and checks the basis, stabilizer, coset, union, and disjointness claims. This is an exact finite computation, not proof-assistant verification or external review.
