# Spin(5)-covariant ququart: vector and bivector duals

## Theorem and scope

Let \(U\) be the four-dimensional spinor representation of \(\operatorname{Spin}(5)\). Suppose \(\Phi:M_4\to M_4\) is unital, trace-preserving, Hilbert--Schmidt self-adjoint, \(\operatorname{Spin}(5)\)-covariant, and is the common marginal of a two-output CPTP channel. Then the one fixed canonical entanglement-breaking channel

\[
\Psi(X)=\frac{X+\operatorname{Tr}(X)I}{5}
\]

satisfies

\[
\Psi-(2\Phi-\operatorname{id})\succeq_{HS}0,
\qquad\text{equivalently}\qquad
\operatorname{id}-\Psi\preceq_{HS}2(\operatorname{id}-\Phi).
\tag{1}
\]

The order here is positivity of a self-adjoint superoperator for the normalized Hilbert--Schmidt inner product, not complete positivity of the difference. The same \(\Psi\) works for every channel in this covariant compatible class. The proof includes all positive dual frames on the full Hermitian operator space, by symmetry reduction; the scalar identity sector contributes equally on both sides. It does not cover noncovariant ququart channels or establish the unrestricted dimension-free theorem.

## Spinor operator sectors

Choose five Hermitian Clifford matrices on \(\mathbb C^4\),

\[
\Gamma_1=X\otimes I,\quad \Gamma_2=Y\otimes I,\quad
\Gamma_3=Z\otimes X,\quad \Gamma_4=Z\otimes Y,\quad
\Gamma_5=Z\otimes Z,
\]

where \(X,Y,Z\) are the Pauli matrices. Put \(B_{ij}=i\Gamma_i\Gamma_j\) for \(i<j\). With \(\tau=\operatorname{Tr}/4\), the 15 matrices \(\Gamma_i,B_{ij}\) form a \(\tau\)-orthonormal basis of the traceless Hermitian operators. Under conjugation by \(\operatorname{Spin}(5)\), they split as two inequivalent irreducible real sectors,

\[
\operatorname{Herm}_0(\mathbb C^4)=\mathcal V_1\oplus\mathcal V_2,
\qquad \dim\mathcal V_1=5,\quad \dim\mathcal V_2=10,
\]

the vector and bivector (adjoint) representations. Thus a covariant unital, trace-preserving, self-adjoint map has real transfer eigenvalues \(\lambda_1,\lambda_2\) on these two sectors and eigenvalue one on the identity.

## Exact canonical-EB support

For a positive invariant dual frame \(Q=a\Pi_1+b\Pi_2\), \(a,b\geq0\), its canonical measure-and-prepare support is

\[
S_{\rm canEB}(Q)=a+2b.
\tag{2}
\]

Indeed, for a pure state \(P_\psi\), the Fierz identity

\[
\sum_{i=1}^5\Gamma_i\otimes\Gamma_i=I
\quad\text{on }\operatorname{Sym}^2(\mathbb C^4)
\tag{3}
\]

gives \(\sum_i\langle\Gamma_i\rangle_\psi^2=1\). To see (3) representation-theoretically, the left side is Spin(5)-invariant and swap-symmetric. The symmetric square of the spinor is the irreducible 10-dimensional representation, so the operator is scalar there. Its trace on that subspace is

\[
\operatorname{Tr}\!\left[\frac{I+F}{2}\sum_i\Gamma_i\otimes\Gamma_i\right]
=\frac12\sum_i\operatorname{Tr}(\Gamma_i^2)=10,
\]

so the scalar is one. Independently, Parseval for the 15-element traceless \(\tau\)-orthonormal basis gives

\[
\sum_i\langle\Gamma_i\rangle_\psi^2+
\sum_{i<j}\langle B_{ij}\rangle_\psi^2=4\operatorname{Tr}(P_\psi-I/4)^2=3,
\]

and hence \(\sum_{i<j}\langle B_{ij}\rangle_\psi^2=2\). A rank-one POVM/prepare score is an average of these pure-seed moments, so every rank-one canonical EB map has score \(a+2b\); the continuous Spin(5) orbit POVM attains it. For a higher-rank effect, a rank-one decomposition can only increase the score: for each basis observable this is the scalar inequality \( (\sum_k t_k r_k)^2/(\sum_k t_k)\leq\sum_k t_k r_k^2\). Thus allowing higher-rank POVM effects cannot increase the support.

This orbit is also a projective 2-design: since \(\operatorname{Sym}^2(\mathbb C^4)\) is irreducible,

\[
\int P_g\otimes P_g\,dg=\frac{I+F}{20}.
\]

Consequently \(4\int \operatorname{Tr}(P_gX)P_g\,dg=(X+\operatorname{Tr}(X)I)/5\), proving that the comparator in (1) is a canonical EB channel. It has transfer value \(1/5\) on both traceless sectors.

## Exact compatible-star certificate

For an orthonormal operator basis \(\mathcal B_r\) of sector \(r\), define the normalized-Choi star

\[
H_r=\sum_{T\in\mathcal B_r}T^T\otimes(T\otimes I+I\otimes T)
\quad\text{on }\bar{\mathbb C}^4\otimes\mathbb C^4\otimes\mathbb C^4.
\]

If \(\Omega\) is the normalized Choi state of a broadcaster with both marginals \(\Phi\), then

\[
\operatorname{Tr}(\Omega H_r)=2\operatorname{Tr}_{HS}(\Pi_r\Phi)
=2(\dim\mathcal V_r)\lambda_r.
\tag{4}
\]

An output-swap average may always be taken, since the two marginals already agree. The star is Hermitian and \(\Omega\) is a density matrix, so \(\operatorname{Tr}(\Omega H_r)\leq\lambda_{\max}(H_r)\).

Exact arithmetic on the explicit Pauli-word matrices gives

\[
\begin{aligned}
\chi_{H_1}(x)&=x^{16}(x-6)^4(x-2)^{20}(x+4)^{16}(x^2-20)^4,\\
\chi_{H_2}(x)&=x^4(x-12)^4(x-8)^4(x-2)^{16}(x+2)^{16}(x+4)^{20}.
\end{aligned}
\tag{5}
\]

Thus \(\lambda_{\max}(H_1)=6\) and \(\lambda_{\max}(H_2)=12\), including both output-swap sectors. Equations (4)--(5) imply

\[
\lambda_1\leq\frac{6}{2\cdot5}=\frac35,
\qquad
\lambda_2\leq\frac{12}{2\cdot10}=\frac35.
\tag{6}
\]

On sector \(r\), the eigenvalue of \(\Psi-(2\Phi-\operatorname{id})\) is \(1/5-(2\lambda_r-1)=6/5-2\lambda_r\), nonnegative by (6). On the scalar sector it is zero. This proves the common full-domain comparison (1).

For completeness, (5) also proves the all-invariant-dual support inequality directly. If the dual includes the scalar identity sector, write \(Q=q_0\Pi_0+a\Pi_1+b\Pi_2\), with \(q_0,a,b\geq0\). The identity-basis star is \(H_0=2I\), and every canonical comparator is unital, so \(S_{\rm canEB}(Q)=q_0+a+2b\). Therefore

\[
\lambda_{\max}(q_0H_0+aH_1+bH_2)
\leq 2q_0+6a+12b
=\operatorname{Tr}_{HS}Q+S_{\rm canEB}(Q).
\tag{7}
\]

For a general positive \(Q\) on the full Hermitian operator space, average it under Spin(5). Because \(\Phi\) is covariant, this preserves \(\operatorname{Tr}_{HS}(Q\Phi)\). The EB support is a convex invariant support function, so \(S_{\rm canEB}(\bar Q)\leq S_{\rm canEB}(Q)\). Multiplicity-freeness makes \(\bar Q=q_0\Pi_0+a\Pi_1+b\Pi_2\), and (7) yields the full all-frame support inequality. Here an explicit \(\Psi\) is already known, so separation is not needed to obtain the comparator.

## Exactness, prior-art boundary, and next gate

`scripts/spin5_ququart_bivector_check.py` constructs the matrices exactly over \(\mathbb Q(i)\), verifies Clifford relations and the \(\tau\)-orthonormal frame, checks (3) as an exact matrix identity, and asserts the two full characteristic polynomials (5). Run with Python and SymPy. This is a reproducible finite exact matrix certificate plus a short representation proof, not an external formal-verifier check.

Prior structure used here—Spin(5) spinor representations, covariance reduction, group twirling, and measure/prepare channels—is standard. A bounded primary-source search surfaced general results on spinor states and general covariant-channel twirling, but no direct matching theorem for this two-sector star bound/common comparator; this does not establish novelty or priority. See `SOURCE_NOTES.md` for the exact search boundary and links.

This result is confined to the Spin(5)-covariant ququart class. It does not control noncovariant maps, arbitrary dimension, arbitrary Clifford forms, or bounded-Holevo families. The next high-value test is to extend the exact star/support comparison to Spin(2n+1) spinors with all exterior-form sectors, or to find a genuinely noncovariant positive dual that separates every canonical EB map.
