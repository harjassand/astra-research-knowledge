# Exact mixed-weight gate: spin \(3/2\), dipole plus quadrupole

## Result and scope

For \(V_{3/2}\) and every \(a,b\geq0\), set
\[
Q=a\Pi_1+b\Pi_2,
\]
where \(\Pi_\ell\) projects onto the spin-\(\ell\) operator sector. The full three-spin Racah calculation gives the exact compatible-extension support
\[
h(a,b):=\sup_{\Lambda\ {\rm symmetric\ CPTP}}2\operatorname{Tr}_{\tau\text{-HS}}(Q\Phi_\Lambda)
=\lambda_{\max}(H_Q)
=\max\{r_1(a,b),r_2(a,b)\},
\tag{1}
\]
with
\[
r_1=\frac{6a+2\sqrt{9a^2+125b^2}}5,\qquad
r_2=\frac{140a+200b+\sqrt{2000(5a^2+4ab+5b^2)}}{50}.
\tag{2}
\]
The exact canonical-EB support, optimized over **all** pure seeds, is
\[
S_{3/2}(Q)=\frac95a+b.
\tag{3}
\]
Consequently every mixed weight satisfies
\[
h(a,b)\leq\frac{24}{5}a+6b
=\operatorname{Tr}_{\tau\text{-HS}}Q+S_{3/2}(Q).
\tag{4}
\]
In fact one fixed full-domain EB channel—the spin-coherent orbit channel—satisfies
\(\Psi_{\rm coh}-(2\Phi-I)\succeq0\) on the scalar, dipole, and quadrupole sectors for every marginal \(\Phi\) of a symmetric extension. This settles the complete dipole–quadrupole slice at \(j=3/2\). It does not settle the rank-3 sector at \(j=3/2\), or mixed weights for \(j\geq2\).

## Conventions and exact compatibility support

Write \(d=4\), \(\tau(X)=\operatorname{Tr}(X)/4\), and take Hermitian tensor operators \(A_{\ell m}\) orthonormal in \(\tau\)-HS. Thus \(\dim\mathcal T_\ell=2\ell+1\) and
\(\operatorname{Tr}_{\tau\text{-HS}}Q=3a+5b\). For a normalized Choi state
\(\Omega=(\mathrm{id}\otimes\Lambda)(|\Omega_4\rangle\langle\Omega_4|)\),
\[
H_Q=\sum_{\ell=1,2}\alpha_\ell\sum_m A_{\ell m}^{T}\otimes
 (A_{\ell m}\otimes I+I\otimes A_{\ell m}),\qquad (\alpha_1,\alpha_2)=(a,b),
\]
and equal extension marginals give
\(\operatorname{Tr}(\Omega H_Q)=2\operatorname{Tr}_{\tau\text{-HS}}(Q\Phi_\Lambda)\).

The full compatibility constraints are
\[
\Omega\succeq0,\quad \operatorname{Tr}\Omega=1,\quad
\operatorname{Tr}_{B_1B_2}\Omega=I_R/4,\quad
\operatorname{Tr}_{B_2}\Omega=\operatorname{Tr}_{B_1}\Omega=J_\Phi,\quad
S_{12}\Omega S_{12}=\Omega.
\tag{5}
\]
Swap invariance in (5) does not impose Bose support. For invariant \(Q\), the star commutes with both output swap and \(\bar U_{3/2}\otimes U_{3/2}\otimes U_{3/2}\). From any normalized top eigenvector \(v\), average \(|v\rangle\langle v|\) with its output-swapped copy and twirl over SU(2). The resulting state remains at star expectation \(\lambda_{\max}(H_Q)\), is swap invariant, and has every one-system marginal \(I/4\) by irreducibility. Its reference marginal is the TP condition in (5), and its output marginals make \(\Phi\) unital. It is therefore a legal full-domain symmetric CPTP extension Choi state, with a covariant, self-adjoint marginal. Hence the eigenvalue in (1) is the exact support over the stated compatibility class, not a relaxation that might violate its marginal constraints.

## Racah blocks and the exact star maximum

Couple \((R B_1)\) first to pair spin \(s\), then couple \(B_2\) to total spin \(F\). With the spin-flip identification of \(V_{3/2}^*\) and \(V_{3/2}\), the single-pair star term in sector \(\ell\) has eigenvalues
\[
v_\ell(s)=4(-1)^\ell(-1)^{3+s}(2\ell+1)
\begin{Bmatrix}3/2&3/2&s\\3/2&3/2&\ell\end{Bmatrix},
\]
so, for \(s=0,1,2,3\),
\[
(v_1(s))=(3,11/5,3/5,-9/5),\qquad
(v_2(s))=(5,1,-3,1).
\tag{6}
\]
The recoupling matrix from \(((R B_1)s,B_2)F\) to \(((R B_2)t,B_1)F\) is
\[
U^F_{st}=(-1)^{3+s+t}\sqrt{(2s+1)(2t+1)}
\begin{Bmatrix}3/2&3/2&s\\3/2&F&t\end{Bmatrix},
\quad
H_{\ell,F}=\operatorname{diag}_{s\in\mathcal S_F}v_\ell(s)
+U^F\operatorname{diag}_{t\in\mathcal S_F}v_\ell(t)(U^F)^T,
\tag{7}
\]
where \(\mathcal S_F=\{s:|s-3/2|\leq F\leq s+3/2\}\). The allowed sets are
\[
\begin{array}{c|ccccc}
F&1/2&3/2&5/2&7/2&9/2\\\hline
\mathcal S_F&\{1,2\}&\{0,1,2,3\}&\{1,2,3\}&\{2,3\}&\{3\}.
\end{array}
\]
For transparency, the two central blocks from (7) are
\[
H_{1,3/2}=\begin{pmatrix}
3&\sqrt3&0&0\\
\sqrt3&13/5&8\sqrt{15}/25&0\\
0&8\sqrt{15}/25&9/5&3\sqrt{35}/25\\
0&0&3\sqrt{35}/25&3/5
\end{pmatrix},\quad
H_{2,3/2}=\begin{pmatrix}
5&0&\sqrt5&0\\
0&13/5&2\sqrt{15}/5&\sqrt{21}/5\\
\sqrt5&2\sqrt{15}/5&-3&2\sqrt{35}/5\\
0&\sqrt{21}/5&2\sqrt{35}/5&17/5
\end{pmatrix}.
\tag{8}
\]
Their spectra, together with the other exact block spectra needed for the global comparison, are
\[
\begin{array}{c|c|c}
F&\operatorname{spec}(H_{1,F})&\operatorname{spec}(H_{2,F})\\\hline
1/2&\{18/5,2\}&\{0,-4\}\\
3/2&\{24/5,12/5,4/5,0\}&\{6,2,2\sqrt5,-2\sqrt5\}\\
5/2&\{14/5,2/5,-6/5\}&\{2,0,-4\}\\
7/2&\{0,-12/5\}&\{0,-4\}\\
9/2&\{-18/5\}&\{2\}.
\end{array}
\tag{9}
\]
The mixed characteristic polynomial of the central block is
\[
\det(xI-aH_{1,3/2}-bH_{2,3/2})=
\frac{(5x^2-12ax-100b^2)
(25x^2-(140a+200b)x+96a^2+480ab+300b^2)}{125},
\tag{10}
\]
where the numerator in (10) is the **product** of its displayed quadratic factors. Its largest root is \(\max(r_1,r_2)\) from (2).

To check that no total-spin block has been omitted from this maximum, use the normalized vector
\[
v=\frac1{20}(5\sqrt7,3\sqrt{21},\sqrt{35},1)^T\quad(F=3/2).
\]
Direct multiplication in (8) gives
\(\langle v,H_{1,3/2}v\rangle=\langle v,H_{2,3/2}v\rangle=24/5\), hence
\(\lambda_{\max}(aH_{1,3/2}+bH_{2,3/2})\geq24(a+b)/5\). By (9), the \(F=1/2\) block is bounded above by \(18a/5\), the \(F=5/2\) block by \(14a/5+2b\), the \(F=7/2\) block by zero, and the \(F=9/2\) block equals \(-18a/5+2b\leq2b\). Each is at most \(24(a+b)/5\). Thus the central block is globally maximal for every \(a,b\geq0\), proving (1) and (2). In particular, its individual sector maxima are \(\lambda_{\max}H_{1}=24/5\), \(\lambda_{\max}H_{2}=6\); Weyl subadditivity then gives
\[
h(a,b)\leq a\lambda_{\max}H_1+b\lambda_{\max}H_2=24a/5+6b.
\tag{11}
\]

## Full pure-seed optimization of canonical EB support

For a pure seed \(P_\psi\), write
\[
s_\ell(\psi)=4^2\|\Pi_\ell(P_\psi-I/4)\|_{\tau\text{-HS}}^2
=\sum_{m=-\ell}^{\ell}|\operatorname{Tr}(P_\psi A_{\ell m})|^2.
\]
Twirling and refining any canonical measure-and-prepare POVM into rank-one effects shows that its invariant score is bounded by the largest seed score. Conversely, the SU(2) orbit POVM \(4\,U_gP_\psi U_g^*\,dg\) has barycenter \(I/4\) and attains that seed score. Therefore the exact support is
\[
S_{3/2}(a\Pi_1+b\Pi_2)=\max_{\psi}\{a s_1(\psi)+b s_2(\psi)\}.
\tag{12}
\]

Realize \(V_{3/2}=\operatorname{Sym}^3(\mathbb C^2)\). For a pure symmetric three-qubit vector, let \(r\) be its one-qubit Bloch vector and let \(C_{uv}=\langle\sigma_u\otimes\sigma_v\rangle\) be its two-qubit correlation matrix. Permutation symmetry makes \(C\) real symmetric. Since
\(A_{1u}=\sqrt{4/5}\,J_u\) and \(\langle J\rangle=3r/2\),
\[
s_1(\psi)=\frac95|r|^2\leq\frac95.
\tag{13}
\]
The rank-2 tensor is the symmetric traceless part of
\(\tfrac12(J_uJ_v+J_vJ_u)-\tfrac54\delta_{uv}I\); its expectation matrix is
\[
D=\frac32C-\frac12I_3,
\qquad s_2(\psi)=\frac23\|D\|_F^2.
\tag{14}
\]
The coefficient in (14) follows by normalizing these five rank-2 tensors in \(\tau\)-HS. For \(E=\operatorname{diag}(1,-1,0)/\sqrt2\), direct use of the spin-\(3/2\) ladder matrices gives \(\tau[T(E)^2]=3/2\), where \(T(E)=\sum_{uv}E_{uv}[\tfrac12(J_uJ_v+J_vJ_u)-\tfrac54\delta_{uv}I]\). Rotational invariance makes this the same norm factor for every Frobenius-unit symmetric traceless \(E\). Thus \(A_{2,k}=T(E_k)/\sqrt{3/2}\) for a Frobenius-orthonormal tensor frame \(E_k\), and \(\sum_k|\operatorname{Tr}(P_\psi A_{2,k})|^2=(2/3)\|D\|_F^2\), proving (14).

Purity across the split \((12)|3\) gives
\(\operatorname{Tr}\rho_{12}^2=\operatorname{Tr}\rho_1^2=(1+|r|^2)/2\). Expanding \(\rho_{12}\) in the Pauli basis yields
\(1+2|r|^2+\|C\|_F^2=2+2|r|^2\), so \(\|C\|_F^2=1\). The fixed spin Casimir \(J^2=15I/4\), with \(J=\tfrac12\sum_{k=1}^3\sigma^{(k)}\), gives \(\operatorname{tr}C=1\). Hence
\[
\|D\|_F^2=\frac94\|C\|_F^2-\frac32\operatorname{tr}C+\frac34=\frac32,
\qquad s_2(\psi)=1
\quad\text{for every pure seed }\psi.
\tag{15}
\]
The coherent seed \(|3/2,3/2\rangle=|\uparrow\uparrow\uparrow\rangle\) has \(|r|=1\), so it simultaneously attains both bounds in (13) and (15). Equations (12)–(15) prove the full support (3), not merely a coherent-seed lower bound. The coherent EB channel has sector transfers
\[
\mu_1=\frac{S(\Pi_1)}3=\frac35,\qquad
\mu_2=\frac{S(\Pi_2)}5=\frac15.
\tag{16}
\]

## Mixed inequality and one common comparator

Combining (11), \(\operatorname{Tr}_{\tau\text{-HS}}Q=3a+5b\), and the exact seed optimization (3),
\[
\lambda_{\max}(H_Q)-\operatorname{Tr}_{\tau\text{-HS}}Q
\leq\frac95a+b=S_{3/2}(Q)
\quad(a,b\geq0),
\]
which is the required genuinely mixed-weight support inequality.

For a compatible covariant marginal with transfer scalars \(\lambda_1,\lambda_2\), the exact axis supports from (9) imply
\[
6\lambda_1=2\operatorname{Tr}(\Pi_1\Phi)\leq24/5,
\qquad
10\lambda_2=2\operatorname{Tr}(\Pi_2\Phi)\leq6,
\]
so \(\lambda_1\leq4/5\) and \(\lambda_2\leq3/5\). The **same** coherent EB channel from (16) obeys
\[
\mu_1-(2\lambda_1-1)=8/5-2\lambda_1\geq0,
\qquad
\mu_2-(2\lambda_2-1)=6/5-2\lambda_2\geq0.
\]
Both channels are unital, so their difference vanishes on the scalar identity sector. This proves the common-comparator claim on ranks 0, 1, and 2; no control of rank 3 is inferred. No separating witness or obstruction exists on this two-sector slice because the exact support inequality holds throughout its positive cone.
