# Independent exact audit: spin \(3/2\) mixed dipole--quadrupole gate

## Verdict

The exact block data and mixed \(F=3/2\) characteristic polynomial in MIXED_WEIGHT_GATE.md pass an independent reconstruction. I built the spin-\(3/2\) angular-momentum matrices directly, normalized the three rank-one and five rank-two Hermitian tensor components in \(\tau=\operatorname{Tr}/4\), formed the full \(64\times64\) tripartite star operators, applied the reference spin-flip, and restricted to fixed-\(F,M=F\) coupled bases using exact Clebsch--Gordan coefficients.

The checker is scripts/audit_mixed_weight_j32.py. It confirms all five \(F\)-block spectra for both sectors and the full mixed characteristic polynomial:
\[
\det(xI-aH_{1,3/2}-bH_{2,3/2})
=\frac{(5x^2-12ax-100b^2)
(25x^2-(140a+200b)x+96a^2+480ab+300b^2)}{125}.
\]
In this displayed expression the two quadratic factors are multiplied; the report's product formula is correct.

The exact checker output is:

\[
\begin{array}{ll}
F=1/2 &: \text{rank-1 and rank-2 block spectra PASS},\\
F=3/2 &: \text{rank-1 and rank-2 block spectra PASS},\\
F=5/2 &: \text{rank-1 and rank-2 block spectra PASS},\\
F=7/2 &: \text{rank-1 and rank-2 block spectra PASS},\\
F=9/2 &: \text{rank-1 and rank-2 block spectra PASS},\\
F=3/2 &: \text{mixed characteristic polynomial PASS}.
\end{array}
\]

## Scope and remaining audit boundary

This independently validates the star side of the \(j=3/2\), \(Q=a\Pi_1+b\Pi_2\) theorem. It is finite exact arithmetic, not an external proof check. The pure-seed support argument and the common coherent EB comparator are separately derived in MIXED_WEIGHT_GATE.md; they do not control the rank-three sector or any \(j\geq2\) mixed-weight cone. No Bose-support restriction was imposed: all total-spin blocks of the full Choi star were included.
