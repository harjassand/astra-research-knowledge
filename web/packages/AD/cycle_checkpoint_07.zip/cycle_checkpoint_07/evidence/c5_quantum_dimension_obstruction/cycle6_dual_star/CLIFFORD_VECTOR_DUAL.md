# Clifford-vector full-star dual: exact equality through m=11

## Construction and normalization

Let $m=2n+1$ and $d=2^n$. On the irreducible complex spinor space
$S=\mathbb C^d$, take the Hermitian Jordan--Wigner Clifford generators
$\Gamma_1,\ldots,\Gamma_m$ satisfying

$$
\Gamma_i\Gamma_j+\Gamma_j\Gamma_i=2\delta_{ij}I,
\qquad \tau(\Gamma_i\Gamma_j)=\delta_{ij},
\qquad \tau=\operatorname{Tr}/d.
$$

The Pauli-word construction in `clifford_star.py` fixes their convention:
$Z^{\otimes k}X$ and $Z^{\otimes k}Y$ for $0\leq k<n$, followed by
$Z^{\otimes n}$. The vector-frame dual is the positive operator

$$
Q=\sum_{i=1}^m |\Gamma_i\rangle\!\rangle
  \langle\!\langle\Gamma_i|,
\qquad \operatorname{Tr}_{\tau\text{-HS}}Q=m.
$$

Its full two-output star Hamiltonian is

$$
H_m=\sum_{i=1}^m\Gamma_i^T\otimes
   (\Gamma_i\otimes I+I\otimes\Gamma_i).
$$

With the normalized Choi state of a broadcaster and the normalized-trace
Hilbert--Schmidt inner product, $\operatorname{Tr}(\Omega H_m)=
2\operatorname{Tr}_{\tau\text{-HS}}(Q\Phi)$. This is the ordinary tensor
product of three spinor systems; no graded tensor product or fermionic
parity restriction is imposed.

## Canonical EB support

For a rank-one measure-and-prepare channel, refine each measurement effect
to $E_z=d p_zP_{u_z}$ and write its prepared state as $\sigma_z$. Define
the Clifford expectation vector $r(\rho)_i=\operatorname{Tr}(\rho\Gamma_i)$.
The dual score is

$$
\operatorname{Tr}_{\tau\text{-HS}}(Q\Psi)
=\sum_zp_z\,r(P_{u_z})\cdot r(\sigma_z).
$$

For every state $\rho$, $\|r(\rho)\|_2\leq1$: for a unit vector $a$,
$\sum_i a_i\Gamma_i$ squares to $I$, so
$|a\cdot r(\rho)|\leq1$. Consequently every canonical EB channel has
score at most one. The bound is attained. A $+1$ eigenstate $P_+$ of
$\Gamma_1$ has $r(P_+)=(1,0,\ldots,0)$, since the other generators
anticommute with $\Gamma_1$. Its Spin$(m)$ orbit has the same unit vector
length and averages to $I/d$ by irreducibility; the covariant rank-one POVM
and preparation of those same orbit states attain score one. Thus

$$
S(Q)=\sup_{\Psi\in\mathcal C_{EB}}\operatorname{Tr}_{\tau\text{-HS}}(Q\Psi)=1.
$$

The factor-two dual threshold is therefore $\operatorname{Tr}Q+S(Q)=m+1$.

## Exact star certificates

An exact Pauli-word calculation gives the following annihilating polynomials
and multiplicities of the top root:

| $m$ | spinor dimension $d$ | exact $p_m(H_m)=0$ | multiplicity of $m+1$ |
|---:|---:|---|---:|
| 3 | 2 | $x(x-4)(x+2)$ | 2 |
| 5 | 4 | $x(x-6)(x-2)(x+4)(x^2-20)$ | 4 |
| 7 | 8 | $x(x-8)(x-4)(x+2)(x^2-36)(x^2-48)(x^2-20)$ | 8 |
| 9 | 16 | $x(x-10)(x-6)(x-2)(x+4)(x+6)(x+8)(x^2-84)(x^2-48)(x^2-20)$ | 16 |
| 11 | 32 | $x(x-12)(x-8)(x-6)(x-4)(x+2)(x+6)(x+10)(x^2-128)(x^2-84)(x^2-80)(x^2-48)(x^2-20)$ | 32 |

Every root in each polynomial is real and the largest is $m+1$. Since
$H_m$ is Hermitian, $\lambda_{\max}(H_m)\leq m+1$. The top eigenvalue is
indeed attained: the polynomial

$$
q_m(x)=\frac{p_m(x)}{(x-(m+1))p_m'(m+1)}
$$

is the spectral projector polynomial for the simple root $m+1$. The exact
Pauli expansion gives $\operatorname{Tr}q_m(H_m)=2,4,8,16,32$ for
$m=3,5,7,9,11$, respectively. Hence $\lambda_{\max}(H_m)=m+1$ in all five
cases.

The calculation does not impose the Bose subspace. For an explicit legal
extension, set $\Omega_m=q_m(H_m)/\operatorname{Tr}q_m(H_m)$. It is a
positive trace-one spectral projector, commutes with the output swap, and is
Spin$(m)$ invariant. Irreducibility forces its reference and one-output
marginals to equal $I/d$; output-swap invariance makes the two output
marginals equal. Thus it is the normalized Choi state of a symmetric,
trace-preserving broadcaster whose marginal is unital. The multiplicity-free
decomposition
$\operatorname{End}(S)\cong\bigoplus_{k=0}^{n}\Lambda^k(\mathbb R^m)$ makes
the covariant Hermiticity-preserving marginal scalar and real on each
operator sector, hence Hilbert--Schmidt self-adjoint.

For this valid channel, the vector-sector score is
$(m+1)/2$, so the full-star and EB sides meet exactly:

$$
\lambda_{\max}(H_m)=m+1=\operatorname{Tr}Q+S(Q).
$$

This is an all-ordinary-tensor-product equality control, not a separator.
In particular, the informal $1/\sqrt2$ attenuation intuition from a
fermionic beam-splitter does not produce a legal violation for this dual.

## Reproducibility and scope

Run `clifford_star.py` for $m=3,5,7,9$ and `clifford_star_m11.py` for $m=11$.
Both use exact Gaussian-integer Pauli multiplication and prove
their annihilators coefficient-by-coefficient. The top multiplicity is the
identity-Pauli coefficient of $q_m(H_m)$ times the full Hilbert-space
dimension. These checks avoid dense eigensolvers, grids and SDP searches.
The largest case has three spinor factors of dimension $32$ (a
$32768$-dimensional Choi space), at most $524800$ Pauli words in a power of
$H_{11}$, and takes about 45 seconds in the memory-lean bitmask script.

$m=3,5,7,9,11$. It neither proves the all-$Q$ factor-two inequality for
Clifford-covariant channels nor yields a high-dimensional obstruction.
Arbitrary odd $m\geq13$, exact channel compilation into Kraus operators, and a literature
priority review of a Clifford-spinor cloning family remain open. Standard
universal cloning is established prior art; the exact bounded search note is
in `SOURCE_NOTES.md`, with no novelty or absence-of-prior-art claim.
