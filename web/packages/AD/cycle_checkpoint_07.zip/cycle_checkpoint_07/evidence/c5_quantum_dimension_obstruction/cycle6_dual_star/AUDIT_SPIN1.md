# Independent audit: spin-1 dual-star certificate

## Finding

I found no mathematical error in the normalized-Choi identity, invariant star spectrum, three-test coherent/nematic construction, or common-map argument, provided the comparator class remains the **canonical** measure/prepare set. The exact script runs successfully with `python3` and reproduces the cloner eigenvalues, projector ranks, characteristic factorization, and square-root identities.

## Checks reconstructed

For $J_\Phi=\frac13\sum_{a,b}|a\rangle\langle b|\otimes\Phi(|a\rangle\langle b|)$,

$$
\operatorname{Tr}[J_\Phi(A^T\otimes A)]
=\frac13\operatorname{Tr}[A\Phi(A)]
=\langle A,\Phi(A)\rangle_\tau.
$$

Thus each of the two equal reference/output marginals contributes $\operatorname{Tr}_{HS}(Q\Phi)$ to $\operatorname{Tr}(\Omega H_Q)$, giving the factor two. The normalized Choi state has trace one, so its star expectation is at most $\lambda_{\max}(H_Q)$.

For a canonical rank-one map
$\Psi_\mu(X)=3\int\operatorname{Tr}(P_\psi X)P_\psi\,d\mu(\psi)$,
the probability measure satisfies $\int P_\psi d\mu=I/3$, and
$\operatorname{Tr}_{HS}(Q\Psi_\mu)=\int f_Q(\psi)d\mu$. Parseval gives
$f_1+f_2=2$, while $f_1=\frac32|\langle\vec J\rangle|^2\in[0,3/2]$.
The coherent and nematic SU(2) orbits both have barycenter $I/3$ and attain the endpoints. Therefore the stated $S(\alpha,\beta)$ is exactly the support over this canonical set.

The six root families from (6) are
$$
\frac{5t+3}{2},\quad t-3,\quad-\frac{t+3}{2},\quad3-5t,
\quad\frac{3-7t}{2},\quad
\frac{7t+9\pm\sqrt{369t^2+126t+81}}4,
$$
with multiplicities summing to 27. For $t\ge0$, the plus root dominates: against the first root this reduces to $\sqrt D\ge3t-3$, whose squared difference for $t>1$ is $360t^2+144t+72>0$; the other comparisons follow directly from the roots and $\sqrt D\ge9$. The two stated square comparisons prove $\lambda_{\max}\le\operatorname{Tr}Q+S(Q)$, including the $\alpha=0$ limit.

The three tests yield $\lambda_1\le3/4$, $\lambda_2<7/10$, and $3\lambda_1+5\lambda_2\le5$. The coherent/nematic orbit channels have sector eigenvalues $(1/2,1/10)$ and $(0,2/5)$. With $u=(2\lambda_1-1)_+$ and $s=2u$, the first test ensures $s\in[0,1]$; their mixture has $(\mu_1,\mu_2)=(u,2/5-3u/5)$. If $u>0$, the mixed test gives $\mu_2=1-6\lambda_1/5\ge2\lambda_2-1$; if $u=0$, $\mu_1=0\ge2\lambda_1-1$ and $\mu_2=2/5>2\lambda_2-1$. Both maps fix the identity, so the sector inequalities give the full-map Loewner comparison.

## Precision edits recommended

1. In the separation paragraph, name the cone as the PSD cone on the **traceless transfer space**. Unitality and trace preservation make both $\Psi$ and $2\Phi-I$ equal to the identity on the scalar block and block diagonal, so full-map comparison is equivalent to positivity on the traceless block. The separating dual is then exactly a traceless-space $Q\succeq0$, covered by (9). If retaining the full PSD cone, state that the common scalar contribution cancels and compress the separating $Q$ to the traceless block.
2. Keep “canonical EB” explicit wherever $S(Q)$ is used. The support calculation optimizes over maps $3\int\operatorname{Tr}(P X)P\,d\mu$; it does not compute support over arbitrary entanglement-breaking channels with unrelated measurement and preparation states. The claimed canonical comparator is sufficient.
3. The refinement sentence is valid when each effect is prepared in its normalized effect state: splitting $E=\sum_j e_jP_j$ replaces $|E\rangle\langle E|/\operatorname{Tr}E$ by $\sum_j e_j|P_j\rangle\langle P_j|$, a positive weighted-variance increment. State this convention or omit the sentence and define the rank-one canonical set directly.

These are scope and notation clarifications, not failed bounds. The star certificate does not establish the unrestricted bounded-Holevo or arbitrary-channel statement.
