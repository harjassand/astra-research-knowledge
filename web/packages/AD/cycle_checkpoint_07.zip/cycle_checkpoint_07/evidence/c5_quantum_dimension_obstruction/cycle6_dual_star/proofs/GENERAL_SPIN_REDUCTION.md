# Exact star support and EB dual for spin $j$

This note records the representation-theoretic reduction that extends the spin-1 attack to every irreducible spin, without assuming Bose support of the extension Choi state.

## Choi convention and the full compatibility set

Let $V_j$ have dimension $d=2j+1$. Use normalized input trace $\tau(X)=\operatorname{Tr}(X)/d$, a $\tau$-orthonormal Hermitian basis $\{A_i\}$, and normalized maximally entangled vector $|\Omega_d\rangle=d^{-1/2}\sum_a|aa\rangle$. For a channel $\Lambda:M_d\to M_d\otimes M_d$, its normalized Choi state is

$$
\Omega_\Lambda=(\mathrm{id}\otimes\Lambda)(|\Omega_d\rangle\langle\Omega_d|),\qquad
\operatorname{Tr}_{B_1B_2}\Omega_\Lambda=I_R/d.
$$

For a symmetric broadcaster, symmetry means invariance under the output swap $S_{12}$; it does **not** mean $\Omega_\Lambda$ is supported on the symmetric-output subspace. This distinction is material: an output-swap-invariant density matrix can have an antisymmetric block.

The operator space on $V_j$ is multiplicity-free:

$$
\mathcal B(V_j)=\bigoplus_{l=0}^{2j}\mathcal T_l,\qquad \dim\mathcal T_l=2l+1.
$$

Let $Q=\sum_{l=1}^{2j}\alpha_l\Pi_l$ be a positive invariant dual on the traceless transfer space, and choose a $\tau$-orthonormal Hermitian basis $\{A_{lq}\}_{q=-l}^l$ in each $\mathcal T_l$. Define the star operator

$$
H_Q=\sum_{l,q}\alpha_l A_{lq}^{T}\otimes
   (A_{lq}\otimes I+I\otimes A_{lq})
$$

on $R\otimes B_1\otimes B_2$. For any symmetric extension with common marginal $\Phi$,

$$
\operatorname{Tr}(\Omega_\Lambda H_Q)=2\operatorname{Tr}_{\tau\text{-HS}}(Q\Phi).
\tag{1}
$$

Because $Q$ is invariant, $H_Q$ commutes with $\bar U_j\otimes U_j\otimes U_j$ and with $S_{12}$. Conversely, the maximum eigenvalue of $H_Q$ is attained by a valid compatible Choi state, not merely by a state with unconstrained or incorrect marginals. Given any normalized top eigenvector $v$, set

$$
\Omega=\int_{SU(2)}(\bar U_j\otimes U_j\otimes U_j)
\left(\frac{|v\rangle\langle v|+S_{12}|v\rangle\langle v|S_{12}}2\right)
(\bar U_j\otimes U_j\otimes U_j)^\dagger\,dU.
\tag{2}
$$

The star expectation remains $\lambda_{\max}(H_Q)$. This state is positive, trace one, globally invariant, and output-swap-invariant. Irreducibility forces $\Omega_R=I/d$ and each one-output marginal to equal $I/d$. The first identity is precisely the Choi trace-preservation constraint; the latter identities make the common marginal unital. Thus (2) is the normalized Choi state of a full-domain, symmetric CPTP broadcaster. Its marginal is SU(2)-covariant; multiplicity-free decomposition and Hermiticity preservation make it a real scalar $\lambda_l$ on each $\mathcal T_l$, hence Hilbert--Schmidt self-adjoint. Therefore

$$
\sup_{\substack{\Lambda\;\mathrm{symmetric\ CPTP}\mathrm{extension}}}
2\operatorname{Tr}_{\tau\text{-HS}}(Q\Phi_\Lambda)=\lambda_{\max}(H_Q)
\tag{3}
$$

for the covariant/unital/self-adjoint marginal class, for each invariant $Q$. This argument allows the twirled state to have weight in both output-swap sectors; it never assumes Bose support.

## Canonical EB support and the remaining higher-spin gate

For a pure seed $P_\psi$, the spin-$j$ covariant rank-one measure-and-prepare channel

$$
\Psi_\psi(X)=d\int_{SU(2)}\operatorname{Tr}(XU_jP_\psi U_j^*)\,U_jP_\psi U_j^*\,dU
$$

is a full-domain canonical EB map. Twirling an arbitrary canonical measure-and-prepare map and refining its POVM to rank-one effects shows that, for invariant $Q$, its support is

$$
S_j(Q)=\sup_{\Psi\,\mathrm{canonical\ EB}}\operatorname{Tr}_{\tau\text{-HS}}(Q\Psi)
=\max_{\psi\in\mathbb P(V_j)}\sum_{l=1}^{2j}\alpha_l\,d^2\,\bigl\|\Pi_l(P_\psi-I/d)\bigr\|_{\tau\text{-HS}}^2.
\tag{4}
$$

The common-comparator question for the whole covariant spin-$j$ class is therefore exactly the family of support inequalities

$$
\lambda_{\max}(H_Q)\le \operatorname{Tr}_{\tau\text{-HS}}Q+S_j(Q)
\quad\text{for all }\alpha_l\ge0.
\tag{5}
$$

Positive-cone separation on the traceless transfer block then produces one common full-domain canonical EB map for each channel. For a non-invariant dual $Q$, covariance of $\Phi$ preserves its score after SU(2) twirling; convexity and invariance of the canonical EB support give $S_j(\bar Q)\le S_j(Q)$. Thus (5) is also the complete all-frame gate for this covariant class. Equation (3) is the exact compatible-channel support; the unresolved part at $j>1$ is comparing it with (4), including the pure-state multipole moment body and the recoupled star spectrum.

No Bose-sector-only star eigenvalue is sufficient for (5) unless the antisymmetric block is checked separately. The spin-1 certificate checks both blocks explicitly in `../scripts/spin1_star_certificate.py`.
