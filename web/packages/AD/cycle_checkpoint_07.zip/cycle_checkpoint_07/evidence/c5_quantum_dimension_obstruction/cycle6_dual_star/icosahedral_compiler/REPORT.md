# Exact 18-outcome spin-1 comparator compiler

## Result

The explicit spin-1 common comparator in the parent theorem has an exact
finite implementation with at most 18 rank-one POVM effects and 18 pure
prepared states. This replaces the generic 81-outcome Caratheodory existence
bound for this covariant class. The construction is the icosahedral
degree-five design, used only to integrate degree-at-most-four Choi moments.

Let $\varphi=(1+\sqrt5)/2$ and take the twelve unit directions obtained by
normalizing

$$
(0,\pm1,\pm\varphi),\qquad (\pm1,\pm\varphi,0),\qquad
(\pm\varphi,0,\pm1).
$$

For each direction $v$, define the spin-1 rank-one projectors

$$
P_v=\frac{J_v^2+J_v}{2},\qquad N_v=I-J_v^2.
$$

$P_v$ is the coherent spin-$+1$ state and $N_v$ is the $m=0$ nematic state;
$N_v=N_{-v}$. The twelve directions form six unoriented nematic axes.

The coherent channel uses the twelve effects $E_v^{\rm coh}=P_v/4$ and
prepares $P_v$. The nematic channel uses the six effects
$E_a^{\rm nem}=N_a/2$ and prepares $N_a$, with one representative from each
antipodal pair. The exact sums are

$$
\sum_v E_v^{\rm coh}=I,\qquad \sum_{a\in\text{six axes}}E_a^{\rm nem}=I.
$$

For $s\in[0,1]$, concatenate the scaled branches:

$$
\left\{(sP_v/4, P_v):v\text{ a vertex}\right\}
\quad\cup\quad
\left\{((1-s)N_a/2,N_a):a\text{ an axis}\right\}.
$$

The first coordinate in each pair is a POVM effect and the second is the
prepared state. Their effects sum to $sI+(1-s)I=I$. There are twelve coherent
and six nematic outcomes, with zero-weight outcomes removable at $s=0$ or
$s=1$.

The normalized Choi matrix of each branch is the corresponding orbit average
of $P_v^T\otimes P_v$ or $N_v^T\otimes N_v$. Every matrix entry is a
polynomial of degree at most four in $v$. Exact coordinate-moment checks
through degree five show that the twelve icosahedral vertices reproduce the
uniform-sphere integral exactly. Thus these finite measurements implement
the same two full-domain canonical EB channels as the continuous covariant
POVMs, rather than merely matching selected input states. Direct exact
superoperator diagonalization gives

$$
\Psi_{\rm coh}=\Pi_0+\tfrac12\Pi_1+\tfrac1{10}\Pi_2,\qquad
\Psi_{\rm nem}=\Pi_0+0\,\Pi_1+\tfrac25\Pi_2,
$$

and hence the compiled mixture has sector eigenvalues
$\mu_1=s/2$ and $\mu_2=2/5-3s/10$. Set
$s=2(2\lambda_1-1)_+$ as in the spin-1 theorem; its exact star inequalities
give $s\in[0,1]$ and the common Loewner comparator for the full qutrit map.

## Cost and evidence boundary

The compiler takes the exact scalar $\lambda_1$ of a supplied covariant
channel, forms $s$, and outputs 18 effects and preparations in fixed
algebraic coordinates involving $\sqrt5$. In the generic interior case the
measurement has 18 nonzero outcomes; the endpoints use 6 or 12. The script
`check_icosahedral_spin1.py` checks the degree-five moments, projector
identities, POVM sums, six-axis aggregation, all 9-by-9 normalized-Choi
entries, and the three transfer spectra using exact SymPy arithmetic. It
passes in about 1.5 seconds on the current runtime.

This is an exact mathematical outcome count, not a device-level gate or shot
complexity bound. If the channel is provided only as a black-box physical
process, estimating $\lambda_1$ requires a separate tomography or estimation
protocol; this compiler does not charge or optimize that acquisition cost.
The icosahedral 5-design is established prior structure, not a novelty claim;
the contribution here is the exact low-outcome realization of the already
derived common comparator.
