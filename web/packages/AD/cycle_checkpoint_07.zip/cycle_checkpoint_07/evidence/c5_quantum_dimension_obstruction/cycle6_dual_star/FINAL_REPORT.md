# Cycle 6: the spin-1 dual-star test

## Verdict

The all-frame dual attack gives a positive result for a new structured class: every unital, trace-preserving, Hilbert--Schmidt-self-adjoint, SU(2)-covariant qutrit channel with a symmetric two-output broadcaster has a **single full-domain canonical EB comparator** satisfying

\[
I-\Psi\preceq2(I-\Phi).
\]

This is proved by an exact 27-dimensional star-Hamiltonian spectrum. Group averaging reduces every positive dual frame (Q) to two sector weights, and positive-cone separation produces one common EB map. Three exact star tests also give a concrete comparator formula: mix the spin-coherent and spin-nematic measure-and-prepare channels with weight (s=2(2\lambda_1-1)_+), where λ₁ is the vector-sector transfer eigenvalue. The class theorem is internal and does not settle arbitrary channels.

The same analysis supplies an exact non-Weyl qutrit broadcaster from the universal qubit (2\to4) cloner. Its transfer eigenvalues are (1) on the scalar sector, (3/4) on spin 1, and (7/20) on spin 2. The spin-coherent measure-and-prepare channel has eigenvalues (1/2) and (1/10) on the two traceless sectors, so it is a concrete common EB comparator and saturates factor two on the vector sector.

I found no counterexample. The exact star spectrum shows why this natural representation-theoretic candidate does not obstruct factor two: the largest possible compatible star energy stays below the common-EB support, with equality at a vector-only dual and at the isotropic dual.

## Dual interface

Let Φ act on (M_3), with normalized Choi convention (J_\Phi=(\mathrm{id}\otimes\Phi)(|\Omega\rangle\langle\Omega|)), ( |\Omega\rangle=3^{-1/2}\sum_i|ii\rangle). For a real-HS positive dual frame (Q=\sum_iw_i|A_i\rangle\langle A_i|), define

\[
H_Q=\sum_iw_i A_i^T\otimes(A_i\otimes I+I\otimes A_i).
\]

If Ω is the normalized Choi state of a symmetric broadcaster with marginal Φ, then

\[
\operatorname{Tr}(\Omega H_Q)=2\operatorname{Tr}_{HS}(Q\Phi).
\]

The factor-two support condition is therefore

\[
\operatorname{Tr}(\Omega H_Q)\le \operatorname{Tr}_{HS}Q+
\sup_{\Psi\in\mathcal C_{EB}}\operatorname{Tr}_{HS}(Q\Psi),
\]

where \(\mathcal C_{EB}\) is the compact convex set of canonical POVM/prepare maps. This formulation charges the common full-domain map through one cone-separation step; separate comparators for frame elements are never substituted for it.

## Exact spin-1 spectrum and EB support

Write (J_x,J_y,J_z\) for spin-1 angular momentum matrices. The Hermitian operator space decomposes multiplicity-free into ranks (0,1,2), with dimensions (1,3,5). Let Π_l denote these transfer-space projectors and (Q=\alpha\Pi_1+\beta\Pi_2), α,β≥0.

For a canonical EB map given by a rank-one POVM, its outcomes form a pure-state ensemble with barycenter (I/3), and

\[
\operatorname{Tr}_{HS}(Q\Psi)=\mathbb E_\mu f_Q(\psi),\quad
f_Q(\psi)=\alpha\sum_{a\in1}\langle\psi|A_a|\psi\rangle^2+
\beta\sum_{a\in2}\langle\psi|A_a|\psi\rangle^2.
\]

The spin-1 basis (A_i=\sqrt{3/2}J_i) is τ-orthonormal, and its contribution is (f_1=(3/2)|\langle\vec J\rangle|^2). Completeness of a τ-orthonormal traceless basis gives (f_1+f_2=2) on every pure state. Since (0\le|\langle\vec J\rangle|\le1), with coherent and nematic states attaining the endpoints, and their SU(2) orbits average to (I/3), the exact common-EB support is

\[
S(\alpha,\beta)=\sup_{\Psi\in\mathcal C_{EB}}\operatorname{Tr}_{HS}(Q\Psi)
=\begin{cases}
\frac32\alpha+\frac12\beta,&\alpha\ge\beta,\\
2\beta,&\beta\ge\alpha.
\end{cases}
\]

The exact star spectrum is encoded by the characteristic polynomial of (H_{\alpha,\beta}=\alpha H_1+\beta H_2). For α>0, set (t=\beta/\alpha\). Its largest eigenvalue is

\[
\lambda_{\max}(H_{\alpha,\beta})=
\frac{\alpha}{4}\left(7t+9+\sqrt{369t^2+126t+81}\right).
\]

If (0\le t\le1), then (\operatorname{Tr}Q+S=\alpha(9+11t)/2), and

\[
(9+15t)^2-(369t^2+126t+81)=144t(1-t)\ge0.
\]

If (t\ge1), then (\operatorname{Tr}Q+S=\alpha(3+7t)), and

\[
(3+21t)^2-(369t^2+126t+81)=72(t^2-1)\ge0.
\]

Thus \(\lambda_{\max}(H_Q)\le\operatorname{Tr}Q+S(Q)\) for all invariant (Q\). At α=0 the largest eigenvalue is (\beta(7+\sqrt{369})/4<7\beta=\operatorname{Tr}Q+S(Q)). Every compatible Choi extension is a density operator, so its star expectation is bounded by this largest eigenvalue, even before imposing its marginal and swap constraints.

For arbitrary (Q\succeq0) on the traceless operator space, twirl it over SU(2). The channel is covariant, so Φ-score and trace are unchanged. The canonical-EB support (S(Q)) is convex and invariant under that action, hence (S(\bar Q)\le S(Q)). Multiplicity-free decomposition gives (\bar Q=\alpha\Pi_1+\beta\Pi_2) with α,β≥0. The invariant star bound therefore proves the all-frame inequality for the original (Q\).

The canonical-map set is compact and convex: represent a rank-one POVM by a probability measure on pure qutrit states with barycenter (I/3), then map it continuously to the second moment (\int P_\psi\otimes P_\psi,d\mu\). Carathéodory gives finite support for every moment. Positive-cone separation now turns the all-(Q\) support inequalities into **one** canonical EB map satisfying (\Psi\succeq2\Phi-I). This is a common full-domain comparator for each channel in the stated covariant qutrit class.

An explicit comparator also follows from three star tests. The duals $Q=\Pi_1$, $Q=\Pi_2$, and $Q=\Pi_1+\Pi_2$ give

$$
\lambda_1\le\frac34,\qquad \lambda_2<\frac7{10},\qquad 3\lambda_1+5\lambda_2\le5.
$$

Set $u=(2\lambda_1-1)_+$ and $s=2u\in[0,1]$. Mix the nematic and coherent orbit EB maps as $\Psi_s=(1-s)\Psi_{\rm nem}+s\Psi_{\rm coh}$. Its sector eigenvalues are $\mu_1=s/2=u$ and $\mu_2=2/5-3s/10$. If $u=0$, then $\mu_1\ge2\lambda_1-1$ and $\mu_2=2/5>2\lambda_2-1$. If $u>0$, the mixed dual inequality gives $2\lambda_2-1\le1-6\lambda_1/5=\mu_2$, and $\mu_1=2\lambda_1-1$. Thus this one full-domain canonical EB map satisfies the Loewner inequality. It has an exact 18-outcome implementation: twelve icosahedral coherent effects and six antipodally aggregated nematic effects, verified entrywise at normalized-Choi level in [`icosahedral_compiler/REPORT.md`](icosahedral_compiler/REPORT.md).

The full projector construction, star characteristic polynomial and exact inequalities are in [`STAR_HAMILTONIAN.md`](proofs/STAR_HAMILTONIAN.md). The small exact-arithmetic generator is [`spin1_star_certificate.py`](scripts/spin1_star_certificate.py).

## Concrete qutrit channel

Identify (\mathbb C^3\) with the symmetric subspace of two qubits. Apply the established universal (2\to4) symmetric qubit cloner, then group its four output qubits into two symmetric pairs. This defines a full-domain qutrit broadcaster. Its one-pair marginal is SU(2)-covariant and exactly

\[
\Phi_{\mathrm{cl}}=\Pi_0+\frac34\Pi_1+\frac7{20}\Pi_2.
\]

The full exact (9\times9) transfer matrix and sector projectors are produced by the script. The coherent-state POVM (3P_\psi d\psi) on spin-1 coherent states, followed by preparation of (P_\psi), has

\[
\Psi_{\mathrm{coh}}=\Pi_0+\frac12\Pi_1+\frac1{10}\Pi_2.
\]

Therefore (1-\mu_1=2(1-\lambda_1)=1/2), while (1-\mu_2=9/10<13/10=2(1-\lambda_2)). This is one explicit qutrit EB map and exact full-channel comparison.

## Evidence status, costs, and next gate

The star certificate is finite exact arithmetic over rationals and √2 inside spin matrices; the characteristic polynomial factors over ℚ[t,x]. No SDP or grid search was used. The script depends on SymPy for exact symbolic matrix arithmetic. A concrete broadcaster can be specified by the universal-cloner formula and a (3\to5\) symmetric-subspace projection; explicitly listing its (27\times27) normalized Choi matrix is finite. The common-comparator compiler uses 18 outcomes in algebraic icosahedral coordinates. Extracting λ₁ from a black-box physical channel still incurs a separate tomography or estimation cost.

The spin-1 class theorem does not cover general qutrit channels without SU(2) covariance or the bounded-Holevo family theorem. The higher-spin continuation now gives exact recoupling blocks for each fixed $j$ and proves the dipole-only factor-two inequality is tight for every $j$; finite sector-axis checks through $j=2$ found no violation. Mixed multipole weights remain unresolved for $j>1$, and no noncovariant all-frame bound or separating dual has been found. See [`higher_spin/REPORT.md`](higher_spin/REPORT.md) for the exact formulas and the scope of those checks.

The higher-spin follow-through now gives an exact reduction rather than a bound: for every spin $j$ and every SU(2)-invariant positive dual $Q=\sum_{l=1}^{2j}\alpha_l\Pi_l$, the largest eigenvalue of the full star Hamiltonian equals the maximum dual score over all symmetric compatible CPTP extensions with covariant unital marginal. Twirl and output-swap-average a top eigenstate; its Choi state has reference marginal $I/d$ and each output marginal $I/d$. This uses swap-invariance only, not support on $\operatorname{Sym}^2(V_j)$. The remaining higher-spin factor-two test is the comparison of this exact star support with the canonical EB pure-seed support, whose sector score is $d^2\|\Pi_l(P_\psi-I/d)\|_{2,\tau}^2$ in normalized-trace convention. The formulas and proof gate are in [`GENERAL_SPIN_REDUCTION.md`](proofs/GENERAL_SPIN_REDUCTION.md). They make the arbitrary-$j$ problem finite-dimensional and representation-theoretic but do not yet prove the comparison for $j>1$ or address a noncovariant input channel.

The exact spin-1 star diagonalization was additionally split into output-swap $+$ and $-$ blocks of dimensions 18 and 9. The largest root lies in the $+$ block and dominates the $-$ block for all nonnegative weights. The compatibility proof nevertheless keeps both blocks, avoiding a Bose-support assumption. The updated exact checker reports both factorizations.

The distinct Clifford-vector dual was also checked on ordinary tensor-product spinors. Exact Pauli-word annihilators in [`CLIFFORD_VECTOR_DUAL.md`](CLIFFORD_VECTOR_DUAL.md) give $\lambda_{\max}(H_Q)=m+1=\operatorname{Tr}Q+S(Q)$ for $m=3,5,7,9,11$, with a legal symmetric full Choi extension from the top spectral projector. This targeted non-SU(2)-spin-1 candidate is a tight equality control, not an obstruction; larger odd $m$ and anisotropic Clifford duals remain open.

## Continuation update: 8 October 2026

The anisotropic Clifford-vector bound is now proved for every odd $m\geq3$ and real positive dual supported on the vector sector; the independent hostile audit is complete and passed with a scope clarification. See [`ANISOTROPIC_CLIFFORD_VECTOR.md`](ANISOTROPIC_CLIFFORD_VECTOR.md) and [`work/agents/c7_clifford_hostile/REPORT.md`](../../c7_clifford_hostile/REPORT.md). It does not cover higher Clifford forms.

A separate Spin(5) calculation now proves a common full-domain canonical EB comparator for every Spin(5)-covariant compatible ququart channel. The comparison uses the exact vector and bivector star maxima $6$ and $12$, pure-state EB support $a+2b$, and the fixed depolarizing EB channel $\Psi(X)=(X+\operatorname{Tr}(X)I)/5$. This is an all-positive-dual result for that covariant class; it is not a noncovariant or dimension-free theorem. The full argument and exact matrix certificate are in [`SPIN5_QUQUART_COVARIANT.md`](SPIN5_QUQUART_COVARIANT.md) and [`scripts/spin5_ququart_bivector_check.py`](scripts/spin5_ququart_bivector_check.py).

The open gates are now the anisotropic bivector/mixed-form comparison beyond this Spin(5) class, higher $\operatorname{Spin}(2n+1)$ spinors, noncovariant full-star duals, and the bounded-Holevo question. Exact calculations and internal audits establish scoped proof evidence only; external proof review and novelty/priority review remain open.
