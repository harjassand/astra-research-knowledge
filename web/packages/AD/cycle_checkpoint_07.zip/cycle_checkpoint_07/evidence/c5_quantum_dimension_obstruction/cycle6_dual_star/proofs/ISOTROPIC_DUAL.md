# Exact isotropic dual support in every dimension

This is a dimension-free equality control for the all-frame dual. It rules out an isotropic $Q$ as a separator and checks the normalization of the star Hamiltonian independently of spin covariance.

Let $d\ge2$, $\tau=\operatorname{Tr}/d$, and choose a $\tau$-orthonormal Hermitian basis $A_0=I,A_1,\ldots,A_{d^2-1}$ with $A_i$ traceless for $i>0$. Use normalized Choi vector $|\Omega_d\rangle=d^{-1/2}\sum_a|aa\rangle$. Completeness of the basis gives

$$
\sum_{i=0}^{d^2-1} A_i^T\otimes A_i=d^2|\Omega_d\rangle\langle\Omega_d|.
$$

For $Q=I$ on the traceless Hilbert--Schmidt block, the star operator is therefore

$$
H_I=d^2(P_{RB_1}+P_{RB_2})-2I,
\qquad P_{RB_k}=|\Omega_d\rangle\langle\Omega_d|_{RB_k}\otimes I_{B_{3-k}}.
$$

The two projections have principal angle cosine $1/d$ between their ranges: in the orthonormal range bases $|\Omega_d\rangle_{RB_1}|a\rangle_{B_2}$ and $|\Omega_d\rangle_{RB_2}|b\rangle_{B_1}$, their overlap matrix is $I/d$. Consequently $\lambda_{\max}(P_{RB_1}+P_{RB_2})=1+1/d$, so

$$
\lambda_{\max}(H_I)=d^2+d-2.
$$

The canonical EB support is also exact. For an effect POVM $M_z$, its canonical measurement channel is $\Psi_M(X)=\sum_z\tau(M_zX)M_z/\tau(M_z)$. Its Hilbert--Schmidt superoperator trace is $\sum_z\tau(M_z^2)/\tau(M_z)$. Refining effects to rank one can only increase this sum; for a rank-one POVM $M_z=dp_zP_z$, the sum equals $d$. The scalar identity mode contributes one, hence

$$
\operatorname{Tr}_{\tau\text{-HS},\,I^\perp}\Psi_M\le d-1,
\qquad S(I)=d-1.
$$

The upper value is attained by every rank-one canonical POVM, including a projective measurement. Since $\operatorname{Tr}_{\tau\text{-HS}}I=d^2-1$, this gives the exact equality

$$
\lambda_{\max}(H_I)=\operatorname{Tr}_{\tau\text{-HS}}I+S(I).
$$

The star maximum is attained by a valid compatible Choi state: an eigenvector can be output-swap averaged and group-twirled; its reference and output one-party marginals are maximally mixed. This proof does not assume Bose support. The result is an equality boundary check, not a proof for general positive $Q$.
