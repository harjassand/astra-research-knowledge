# Exact star-Hamiltonian proof for spin 1

## 1. Choi identity

Use τ=Tr/3 and a τ-orthonormal Hermitian frame. For (A=A^*), normalized Choi matrix (J_\Phi=(\mathrm{id}\otimes\Phi)(|\Omega\rangle\langle\Omega|)), and (|\Omega\rangle=3^{-1/2}\sum_i|ii\rangle),

\[
\operatorname{Tr}\bigl[J_\Phi(A^T\otimes A)\bigr]
=\frac13\operatorname{Tr}[\Phi(A)A]
=\langle A,\Phi(A)\rangle_\tau.
\]

Let Ω be a normalized Choi state for a symmetric broadcaster with equal marginals Φ. For (Q=\sum_iw_i|A_i\rangle\langle A_i|\succeq0), define

\[
H_Q=\sum_iw_i A_i^T\otimes(A_i\otimes I+I\otimes A_i).
\]

Both two-body marginals of Ω equal (J_\Phi), so
\[
\operatorname{Tr}(\Omega H_Q)=2\operatorname{Tr}_{HS}(Q\Phi).
\tag{1}
\]

This exact star interaction is the only use of compatibility in the spectral bound. Since Ω is a density matrix, its expectation is at most λmax((H_Q)).

## 2. Spin decomposition and common-EB support

The spin-1 conjugation action decomposes Hermitian matrices into scalar, vector, and quadrupole sectors of dimensions (1,3,5). Let Π_1 and Π_2 be the transfer-space projectors onto the latter two sectors. An invariant positive dual is (Q=\alpha\Pi_1+\beta\Pi_2), α,β≥0.

For a rank-one canonical POVM, write effects (M_z=3p_zP_{\psi_z}). Normalization is (\sum_zp_zP_{\psi_z}=I/3), and

\[
\operatorname{Tr}_{HS}(Q\Psi_M)=\sum_zp_z f_Q(\psi_z),
\quad
f_Q(\psi)=\alpha\sum_{a\in1}\langle A_a\rangle_\psi^2+
\beta\sum_{a\in2}\langle A_a\rangle_\psi^2.
\tag{2}
\]

Refine each effect $M=\sum_r M_r$ into its positive rank-one spectral pieces and prepare the normalized effect state for each piece, as in the canonical map definition. For each Hermitian $A$, the score increment is nonnegative by
$$
\sum_r\frac{\tau(M_rA)^2}{\tau(M_r)}\ge
\frac{\tau(MA)^2}{\tau(M)},
$$
so this covers the support maximum over canonical maps. For (A_i=\sqrt{3/2}J_i), (i=x,y,z), the (A_i) are τ-orthonormal and

\[
f_1(\psi)=\frac32|\langle\vec J\rangle_\psi|^2.
\]

For any pure state, a complete τ-orthonormal traceless Hermitian basis has squared expectation sum (3\operatorname{Tr}(P^2)-1=2). Hence (f_2=2-f_1). The vector expectation has norm at most one; spin-coherent (|1,\vec n\rangle) states attain one and the (|1,0\rangle) state attains zero. The SU(2) orbit of either state has average (I/3), so it defines a valid rank-one POVM ensemble attaining the pointwise maximum. It follows that

\[
S(\alpha,\beta):=\sup_{\Psi\in\mathcal C_{EB}}\operatorname{Tr}_{HS}(Q\Psi)
=\begin{cases}
\frac32\alpha+\frac12\beta,&\alpha\ge\beta,\\
2\beta,&\beta\ge\alpha.
\end{cases}
\tag{3}
\]

## 3. Exact star spectrum

Define the double-commutator operator on (M_3)
\[
\mathcal C(X)=\sum_{i=x,y,z}[J_i,[J_i,X]].
\]
It has eigenvalues (0,2,6) on ranks (0,1,2). Thus
\[
\Pi_1=\mathcal C(6I-\mathcal C)/8,
\qquad
\Pi_2=\mathcal C(\mathcal C-2I)/24.
\tag{4}
\]

If (J_{\Pi_l}) is the normalized Choi matrix of the superoperator Π_l, orthonormality gives
\[
K_l:=9J_{\Pi_l}=\sum_{a\in l}A_a^T\otimes A_a.
\]
With output order (R,B_1,B_2),
\[
H_{\alpha,\beta}=\alpha\left(K_1^{RB_1}\otimes I+K_1^{RB_2}\right)
+\beta\left(K_2^{RB_1}\otimes I+K_2^{RB_2}\right).
\tag{5}
\]

The matrix acts on the **full** $3\otimes3\otimes3$ Choi space, not only on the Bose-symmetric output subspace. Its exact output-swap decomposition has dimensions 18 (symmetric output pair) and 9 (antisymmetric output pair). The two characteristic polynomials are

$$
\chi_+(x)=\frac{(-t+x+3)^7(7t+2x-3)^5(-40t^2-7tx+2x^2-9x)^3}{256},
\qquad
\chi_-(x)=\frac{(-5t+2x-3)^3(t+2x+3)^5(5t+x-3)}{256}.
$$

Their product is the full characteristic polynomial

$$
\det(xI_{27}-(H_1+tH_2))=
\frac{(-5t+2x-3)^3(-t+x+3)^7(t+2x+3)^5(5t+x-3)(7t+2x-3)^5(-40t^2-7tx+2x^2-9x)^3}{65536}.
\tag{6}
$$

Here $t=\beta/\alpha$. The plus root in (7) belongs to the symmetric-swap block; the largest antisymmetric-block root is $(5t+3)/2$, which it dominates for every $t\ge0$. Thus the full-space and Bose-block maxima coincide in this spin-1 calculation, but compatibility only requires swap-invariance of the Choi state, not support on the Bose subspace. The exact script certifies both blocks separately.

The roots are

\[
\frac{5t+3}{2},\quad t-3,\quad-\frac{t+3}{2},\quad3-5t,
\quad\frac{3-7t}{2},\quad
\frac{7t+9\pm\sqrt{369t^2+126t+81}}4.
\]

For (t\ge0), the plus root dominates. It is at least ((5t+3)/2) because (\sqrt{369t^2+126t+81}\ge3t-3) (trivial for (t\le1); for (t>1), square both nonnegative sides and the difference is (360t^2+144t+72>0)). It is at least (3-5t) because the square root is at least (9), and the other displayed roots are plainly no larger. Therefore

\[
\lambda_{\max}(H_{\alpha,\beta})=
\frac{\alpha}{4}\left(7t+9+\sqrt{369t^2+126t+81}\right).
\tag{7}
\]

For (0\le t\le1), (4(\operatorname{Tr}Q+S)/\alpha=18+22t), so the needed square-root comparison is
\[
(9+15t)^2-(369t^2+126t+81)=144t(1-t)\ge0.
\]
For (t\ge1), (4(\operatorname{Tr}Q+S)/\alpha=12+28t), and
\[
(3+21t)^2-(369t^2+126t+81)=72(t^2-1)\ge0.
\]
Each right side is nonnegative and each square-root threshold is nonnegative, proving
\[
\lambda_{\max}(H_Q)\le\operatorname{Tr}_{HS}Q+S(Q).
\tag{8}
\]
When α=0, use (6) at the homogeneous limit: the largest eigenvalue is (\beta(7+\sqrt{369})/4<7\beta=\operatorname{Tr}Q+S(Q)). The zero frame is trivial.

## 4. Explicit common comparator from three dual tests

The same star bounds on only three frames give a constructive covariant comparator. For $Q=\Pi_1$, the largest star eigenvalue is $9/2$ and $S(Q)=3/2$, so (1) implies $6\lambda_1\le9/2$, hence $\lambda_1\le3/4$. For $Q=\Pi_2$, the largest eigenvalue is $(7+\sqrt{369})/4<7$ and $S(Q)=2$, so $10\lambda_2<7$, hence $\lambda_2<7/10$. For $Q=\Pi_1+\Pi_2$, the largest eigenvalue is $10$ and $S(Q)=2$, so $2(3\lambda_1+5\lambda_2)\le10$, hence $3\lambda_1+5\lambda_2\le5$.

Let $u=(2\lambda_1-1)_+$ and $s=2u$. Since $\lambda_1\le3/4$, $s\in[0,1]$. Let $\Psi_{\rm coh}$ be the covariant rank-one EB channel generated by the spin-coherent orbit; its sector eigenvalues are $(\mu_1,\mu_2)=(1/2,1/10)$. Let $\Psi_{\rm nem}$ be generated by the orbit of the spin-nematic state $|1,0\rangle$; its eigenvalues are $(0,2/5)$. Define the one full-domain EB channel

\[
\Psi_s=(1-s)\Psi_{\rm nem}+s\Psi_{\rm coh}.
\]

Its eigenvalues are $\mu_1=s/2=u$ and $\mu_2=2/5-3s/10$. If $u=0$, the vector inequality follows from $\lambda_1\le1/2$, and $\mu_2=2/5>2\lambda_2-1$ follows from $\lambda_2<7/10$. If $u>0$, then $s=2(2\lambda_1-1)$ and

\[
\mu_2=2/5-3(2\lambda_1-1)/5=1-6\lambda_1/5\ge2\lambda_2-1,
\]

where the final inequality is equivalent to $3\lambda_1+5\lambda_2\le5$. The vector comparison is equality. The identity comparison is also equality because both maps are unital. Therefore $\Psi_s$ satisfies $I-\Psi_s\preceq2(I-\Phi)$ on the full qutrit operator space.

The continuous orbit POVMs define finite-dimensional channels. Their Choi states lie in the convex hull of $P_\psi^T\otimes P_\psi$; Caratheodory gives an exact finite decomposition with at most 81 pure outcomes, preserving the Choi matrix and both marginals.

## 5. All-frame lift and one common EB map

The canonical-EB support function (S(Q)=\sup_{\Psi\in\mathcal C_{EB}}\operatorname{Tr}Q\Psi) is convex and invariant under SU(2) conjugation. For any positive traceless-space dual (Q), let ̄Q be its group average. Covariance gives (\operatorname{Tr}\bar Q\Phi=\operatorname{Tr}Q\Phi); positivity gives ̄Q=αΠ_1+βΠ_2 with α,β≥0; Jensen gives (S(\bar Q)\le S(Q)). Equations (1) and (8), applied to ̄Q, therefore prove

\[
2\operatorname{Tr}_{HS}(Q\Phi)-\operatorname{Tr}_{HS}Q\le S(Q)
\quad\text{for every }Q\succeq0.
\tag{9}
\]

The canonical set is compact convex. Represent a rank-one POVM by a probability measure μ on pure qutrit states with barycenter (I/3); its map is the continuous second-moment image (X\mapsto3\int\operatorname{Tr}(P_\psi X)P_\psi,d\mu). Probability measures with this fixed barycenter form a weak-* compact convex set. The image is compact convex, and Caratheodory preserves the finitely many first/second moments with finite support.

Both $\Psi$ and $2\Phi-I$ fix the scalar identity block, and covariance preserves the orthogonal splitting between the scalar and traceless sectors. Thus it is enough to separate their restrictions on the traceless transfer space. If no single canonical Ψ satisfied (\Psi-(2\Phi-I)\succeq0) there, strong separation of the compact convex canonical set from the translated PSD cone on that space would give a positive traceless (Q) with (S(Q)<2\operatorname{Tr}(Q\Phi)-\operatorname{Tr}Q), contradicting (9). Thus one full-domain canonical EB map works simultaneously on every mode.

## 5. Explicit cloner-derived channel and EB map

Identify input (M_3) with operators on (\mathrm{Sym}^2(\mathbb C^2)). The universal qubit (2\to4) cloner is
\[
\Gamma(\rho)=\frac35P_{\mathrm{sym},4}(\rho\otimes I_4)P_{\mathrm{sym},4}.
\]
Trace out two qubits. Because the output lies in Σym⁴, grouping the four outputs into two symmetric pairs yields a full CPTP qutrit broadcaster. Direct exact matrix contraction (the script) gives the marginal superoperator
\[
\Phi_{\rm cl}=\Pi_0+\tfrac34\Pi_1+\tfrac7{20}\Pi_2.
\]

For coherent spin-1 projectors (P_{\vec n}=|1,\vec n\rangle\langle1,\vec n|), take POVM (3P_{\vec n}d\vec n) and prepare (P_{\vec n}). The rank-1 transfer is computed from the moment (\mathbb E n_i n_j=\delta_{ij}/3), giving μ₁=1/2. The coherent quadrupole moment has (\langle J_z^2-2I/3\rangle=P_2(\cos\theta)/3), with (\mathbb E P_2^2=1/5); division by (\tau((J_z^2-2I/3)^2)=2/9) after scaling to the τ-orthonormal basis gives μ₂=1/10. Equivalently, (3) at the coherent endpoint produces the canonical EB support eigenvalues μ₁=1/2 and μ₂=1/10.

Thus the one map Ψ_coh satisfies (1-μ_1=2(1-λ_1)) and (1-μ_2=9/10\le13/10=2(1-λ_2)), with equality on the identity. No modewise comparator is used.

## 6. Exact certificate and limits

`../scripts/spin1_star_certificate.py` builds the cloner marginal, the double-commutator projectors, and the star Hamiltonians using exact SymPy matrices. It verifies (\Phi_{cl}=\Pi_0+3\Pi_1/4+7\Pi_2/20), projector ranks (1,3,5), and factorization (6). No floating-point optimization is involved.

The result depends on SU(2) covariance, multiplicity-free sectors, and the spin-1 pure-state moment identity. For higher spin or repeated irreducible sectors, invariant Q is matrix-valued and the current two-weight square-root comparison does not apply. The full bounded-Holevo implication remains outside this proof.
