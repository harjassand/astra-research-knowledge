# Clifford-vector star: analytic arbitrary-dimension result

## Scope and result

Let $m=2n+1\ge3$, $d=2^n$, and let $\Gamma_1,\ldots,\Gamma_m$ be an irreducible Hermitian complex Clifford family on $S=\mathbb C^d$:
\[
\Gamma_i\Gamma_j+\Gamma_j\Gamma_i=2\delta_{ij}I.
\]
All tensor products below are ordinary tensor products. For a subset $I\subseteq[m]$, set
\[
H_I=\sum_{i\in I}\left(\Gamma_i^T\otimes\Gamma_i\otimes I+\Gamma_i^T\otimes I\otimes\Gamma_i\right).
\]
The vector basis is orthonormal for normalized Hilbert--Schmidt inner product $\langle A,B\rangle_{\tau}=d^{-1}\operatorname{Tr}(A^\dagger B)$. For a real symmetric coefficient matrix $Q=(q_{ij})$ on this basis, define its two-output star by
\[
H_Q=\sum_{i,j}q_{ij}\,\Gamma_j^T\otimes(\Gamma_i\otimes I+I\otimes\Gamma_i).
\]
For a channel $\mathcal E:R\to B_1B_2$ with normalized Choi state $\Omega_{\mathcal E}=(\mathrm{id}_R\otimes\mathcal E)(|\Phi\rangle\langle\Phi|)$, where $|\Phi\rangle=d^{-1/2}\sum_a|a,a\rangle$, write $\Psi_b=\operatorname{Tr}_{B_{3-b}}\circ\mathcal E$ for its two marginal channels. The Choi trace identity gives
\[
\operatorname{Tr}(\Omega_{\mathcal E}H_Q)
=\sum_{b=1}^2\sum_{i,j}q_{ij}\,d^{-1}\operatorname{Tr}\bigl(\Gamma_i\Psi_b(\Gamma_j)\bigr).
\]
When $\Psi_1=\Psi_2=\Psi$, this is $2\langle Q,\Psi\rangle_{\tau\text{-HS}}$, with $\langle Q,\Psi\rangle_{\tau\text{-HS}}=\sum_{i,j}q_{ij}d^{-1}\operatorname{Tr}(\Gamma_i\Psi(\Gamma_j))$. In the diagonal case $q_{ij}=a_i\delta_{ij}$ this is precisely the star used below.
The following analytic statements hold for every such odd $m$.

1. For every $I$ with $|I|=k$, $\lambda_{\max}(H_I)\le k+1$.
2. For a real positive-semidefinite dual on the real Clifford-vector space, diagonalize it with eigenvalues $a_1\ge\cdots\ge a_m\ge0$. Its support over rank-one measure/prepare EB maps is exactly $S(Q)=a_1$, and
   \[
   \lambda_{\max}(H_Q)\le \sum_i a_i+a_1=\operatorname{Tr}_{\tau\text{-HS}}Q+S(Q).
   \]
   This remains true if the support is taken over all EB maps with arbitrary preparation states.
3. For the isotropic vector dual $a_i=1$, the bound is sharp: $\lambda_{\max}(H_{[m]})=m+1$. A top-eigenspace projector gives a positive, output-swap-symmetric normalized Choi state with maximally mixed one-party marginals, hence an exact symmetric broadcasting extension.

The finite exact annihilating-polynomial certificates through $m=11$ in `CLIFFORD_VECTOR_DUAL.md` and its scripts are unchanged. The proof below does not enumerate any larger case. It covers vector-sector duals; it does not cover duals involving higher Clifford-form sectors.

## EB support

Write $r_i(\rho)=\operatorname{Tr}(\rho\Gamma_i)$. For every state $\rho$,
\[
\|r(\rho)\|_2\le1,
\]
because for every real unit vector $u$, $\Gamma(u)=\sum_i u_i\Gamma_i$ is a Hermitian involution and $|u\cdot r(\rho)|=|\operatorname{Tr}(\rho\Gamma(u))|\le1$.

Refining a POVM into rank-one effects writes an arbitrary EB channel as effects $d p_zP_z$ and preparations $\sigma_z$, with $\sum_zp_zP_z=I/d$. Its score is
\[
\operatorname{Tr}_{\tau\text{-HS}}(Q\Psi)
=\sum_zp_z\sum_i a_i r_i(P_z)r_i(\sigma_z).
\]
For each outcome, Cauchy--Schwarz gives
\[
\left|r(P_z)^T\operatorname{diag}(a)r(\sigma_z)\right|
\le a_1\|r(P_z)\|_2\|r(\sigma_z)\|_2\le a_1.
\]
Thus the support is at most $a_1$. It is attained by measuring an orthonormal basis of the two eigenspaces of $\Gamma_1$ and preparing each measured basis state. Every such vector has $r(P)=\pm e_1$: the other generators exchange the two eigenspaces. The eigenspaces have equal dimension, so the uniform ensemble over both bases has barycenter $I/d$. This construction is canonical (each basis state is both measured and prepared) and has score $a_1$. In particular $S(Q)=1$ for the isotropic vector dual.

## A graph bound for every subset size

Fix $I$ of size $k$ and relabel its generators $1,\ldots,k$. Define
\[
X_i=\Gamma_i^T\otimes\Gamma_i\otimes I,\qquad
Y_i=\Gamma_i^T\otimes I\otimes\Gamma_i,\qquad
D_i=X_iY_i=I\otimes\Gamma_i\otimes\Gamma_i.
\]
The $D_i$ are commuting Hermitian involutions. Also, $X_i$ commutes with $D_i$ and anticommutes with $D_j$ for $j\ne i$, while $Y_i=X_iD_i$. (Here $D_i$ is an individual output-pair correlation; it is distinct from the aggregate central sign denoted $D$ in the hostile A/B report.) Decompose the triple tensor space into joint eigenspaces $\mathcal H_S$ of the $D_i$, indexed by the set $S\subseteq[k]$ of plus signs. Some sign patterns may be absent; they can be discarded.

On $\mathcal H_S$, the $i$th summand is
\[
X_i+Y_i=X_i(I+D_i)=\begin{cases}2X_i,&i\in S,\\0,&i\notin S.\end{cases}
\]
When $i\in S$, $X_i$ maps $\mathcal H_S$ unitarily onto
\[
\mathcal H_{T_i(S)},\qquad T_i(S)=\{i\}\cup([k]\setminus S).
\]
For $k\ge2$, these are distinct, non-loop edges, and each edge is reversible with the same label $i$. Therefore $H_I$ is a block-weighted adjacency operator on the graph with these subset vertices and edges; every off-diagonal block is twice a unitary. For a vector $v=\oplus_S v_S$, with $b_S=\|v_S\|$, its quadratic form obeys
\[
|\langle v,H_Iv\rangle|
\le4\sum_{\{S,T\}\in E}b_Sb_T
=\langle b,2A_Gb\rangle,
\]
where $A_G$ is the scalar adjacency matrix. Hence $\|H_I\|\le2\rho(A_G)$.

An edge sends level $r=|S|$ to level $s=k-r+1$, so the graph splits into level pairs with $r+s=k+1$. If $r<s$, the bipartite graph is $(r,s)$-biregular: a vertex on either side has degree equal to its level. Its adjacency spectral radius is at most $\sqrt{rs}$ (by Cauchy--Schwarz and the degree bounds). Thus
\[
2\rho(A_G)\le2\sqrt{rs}\le r+s=k+1.
\]
If $r=s$, then $k$ is odd and that level is $r=(k+1)/2$; it is $r$-regular, so $2\rho(A_G)\le2r=k+1$. The empty subset is isolated. For $k=1$, $X_1$ and $Y_1$ commute and $\|X_1+Y_1\|\le2=k+1$ directly. This proves $\lambda_{\max}(H_I)\le k+1$ for every subset size, including even $k$.

The sign blocks can be counted exactly, so the argument covers every physical chirality/parity block without assuming a canonical bit-model realization. For any nonempty proper $J\subsetneq[m]$, $\operatorname{Tr}\Gamma_J=0$: if $|J|$ is even, conjugate by a generator in $J$; if $|J|$ is odd, conjugate by one outside $J$. Hence for a selected set $I$ of size $k<m$, every nonempty product $D_J=\prod_{i\in J}D_i$ has trace zero on the two outputs. The joint projector for any sign pattern has rank $d^2/2^k$ on the outputs and rank $d^3/2^k$ on the full triple space. Thus every sign pattern occurs for a proper subset.

For the full odd set $k=m$, the sole relation is
\[
\prod_{i=1}^mD_i=I\otimes(\Gamma_1\cdots\Gamma_m)\otimes(\Gamma_1\cdots\Gamma_m)=(-1)^nI.
\]
All sign patterns satisfying this parity relation occur, each with output rank one and triple rank $d$; the opposite parity has rank zero. The edge operation $S\mapsto T_i(S)$ flips $k-1$ signs, so it preserves the allowed full-set parity. In particular, the central level $|S|=n+1$ is allowed and has every vertex present. These statements treat the full-frame chirality constraint and every proper-subset sign block explicitly. Missing vertices in the abstract graph bound are never needed for a physical block.

For $k=m$, a level $|S|=r$ is present exactly when $(-1)^{m-r}=(-1)^n$; paired levels $r$ and $m-r+1$ have the same parity, so each present level pair is complete and has the stated edge counts. The central level $r=n+1$ is present. Since the joint $D$-eigenspace decomposition is complete and $H_I$ only joins the listed adjacent blocks, its estimate also bounds every further invariant chirality/parity subspace considered in the $A/B$ reduction.

The scalar graph has no multiple edges: the edge from $S$ labelled $i$ has $S\cap T_i(S)=\{i\}$, which recovers its unique label, and the reverse edge has the same label. A level-$r$ vertex has degree $r$ and, if paired with level $s=k-r+1$, the level graph has $\binom{k}{r}r=\binom{k}{s}s$ undirected edges. Each operator edge block has weight $2$ times a unitary.

The equality conditions in this bound are also explicit. For a noncentral level pair $r<s$, $2\sqrt{rs}<r+s=k+1$, so that pair cannot saturate the $k+1$ bound. Only the central level $r=s=(k+1)/2$ for odd $k$ can saturate the scalar graph bound. On a central regular component, equality requires block norms constant on that component and, for every occupied edge oriented $S\to T_i(S)$, $\langle\psi_{T_i(S)},X_i\psi_S\rangle=\|\psi_{T_i(S)}\|\,\|\psi_S\|>0$; equivalently, the edge unitary carries one block vector to the other with the positive phase. The odd full-frame Jacobi construction below supplies an eigenvector attaining the bound for $k=m$. We make no equality claim for other restricted subsets; their upper bound is all the layer-cake argument needs. For $k=1$, the bound is sharp exactly on a common $+1$ eigenspace of the commuting $X_1,Y_1$.

## Layer-cake bound for every positive vector dual

Any dual supported on the real Hermitian Clifford-vector space is represented by a real symmetric coefficient matrix. An oriented $SO(m)$ change of basis diagonalizes it (if an orthogonal eigenbasis has determinant $-1$, flip one eigenvector; this leaves the diagonal matrix unchanged). The rotated generators still satisfy the Clifford relations. Sort the eigenvalues $a_1\ge\cdots\ge a_m\ge0$, set $a_{m+1}=0$, and let $H_{[k]}$ be the star for the first $k$ rotated generators. Then
\[
H_Q=\sum_{k=1}^m(a_k-a_{k+1})H_{[k]}.
\]
By subadditivity and positive homogeneity of $\lambda_{\max}$,
\[
\lambda_{\max}(H_Q)
\le\sum_{k=1}^m(a_k-a_{k+1})(k+1)
=\sum_{i=1}^m a_i+a_1
=\operatorname{Tr}_{\tau\text{-HS}}Q+S(Q).
\]
This supplies the even-subset bounds needed for layer-cake; no assumption that an even subset is itself an irreducible odd-dimensional spinor representation is needed. The layer-cake inequality is an equality only if every active $H_{[k]}$ (those with $a_k>a_{k+1}$) has top eigenvalue $k+1$ and their top eigenspaces have a common vector. For the isotropic weights, only $k=m$ is active, and the next section gives equality. No equality is asserted for general anisotropy.

## Exact equality for every odd isotropic vector star

It remains to show that $m+1$ is attained for $k=m=2n+1$. Reassociate the first two tensor factors by the isometry
\[
\Theta(|\bar u\rangle\otimes|v\rangle)=|v\rangle\langle u|,
\]
so $S^*\otimes S\otimes S\cong\operatorname{End}(S)\otimes S$. Under $\Theta$, $\sum_iX_i$ acts on the first factor as
\[
L(X)=\sum_i\Gamma_iX\Gamma_i,
\]
and $\sum_iY_i$ acts as
\[
D(X\otimes v)=\sum_i X\Gamma_i\otimes\Gamma_i v.
\]

For $A\subseteq[m]$, let $\Gamma_A$ be the increasing product of its generators and $E_A=d^{-1/2}\Gamma_A$. The $E_A$ with $|A|\le n$ form an orthonormal basis of $\operatorname{End}(S)$, organized into the inequivalent Spin$(m)$ sectors $\Lambda^k\mathbb R^m$. For $0\le k\le n$, define
\[
V_k(v)=\sum_{|A|=k}E_A\otimes\Gamma_Av,
\qquad
W_k(v)=\binom{m}{k}^{-1/2}V_k(v).
\]
The $W_k$ are mutually orthogonal isometric Spin intertwiners from $S$, so their direct sum is an invariant $S^{\oplus(n+1)}$ isotypic block. On grade $k$, $L$ is scalar
\[
t_k=(-1)^k(m-2k),
\]
since $\Gamma_i\Gamma_A\Gamma_i=(-1)^{k-1}\Gamma_A$ for $i\in A$ and $(-1)^k\Gamma_A$ otherwise.

Clifford multiplication gives, for $k<n$,
\[
D V_k=(-1)^k(k+1)V_{k+1}
      +(-1)^{k-1}(m-k+1)V_{k-1},
\]
where the second term is absent at $k=0$. At $k=n$, the lowering term is $(-1)^{n-1}(n+2)V_{n-1}$ and there is also $(n+1)V_n$. To see the top diagonal term, a raising monomial has degree $n+1$ and is proportional to its complementary degree-$n$ monomial. The proportionality factor squared is $(-1)^n$, because $(\Gamma_1\cdots\Gamma_m)^2=(-1)^nI$; the raising term already has sign $(-1)^n$, so their product is positive. Each complementary monomial has $n+1$ preimages.

After rephasing successive $W_k$ to remove the signs $(-1)^k$, the restriction of $H_m=L+D$ to this block is the Jacobi matrix with
\[
c_k=\sqrt{(k+1)(m-k)}\quad(0\le k<n),
\]
on the two off-diagonals, and diagonal
\[
d_k=(-1)^k(m-2k)\quad(k<n),\qquad d_n=(-1)^n+n+1.
\]
An exact eigenvector for eigenvalue $m+1=2n+2$ has positive coefficients
\[
v_k=\frac{w_k}{\sqrt{\binom{m}{k}}},\qquad
w_{2j}=w_{2j+1}=\binom nj
\quad\text{whenever the index is at most }n.
\]
Indeed, for $k<n$ its eigenvector recurrence, after multiplying by $\sqrt{\binom{m}{k}}$, is
\[
(k+1)w_{k+1}=(m+1-d_k)w_k-(m-k+1)w_{k-1},\qquad w_{-1}=0.
\]
For even $k=2j$, this follows from
$(2j+1)\binom nj=(4j+1)\binom nj-2(n-j+1)\binom n{j-1}$.
For odd $k=2j+1$, it follows from
$(2j+2)\binom n{j+1}=2(n-j)\binom nj$.
The last row is
\[
(n+2)w_{n-1}=(n+1-(-1)^n)w_n.
\]
For odd $n$, $w_{n-1}=w_n$; for even $n=2j$, the identity follows from
$(n+2)\binom n{j-1}=n\binom nj$.
Thus $m+1$ is an actual eigenvalue. Combined with the graph upper bound, this proves
\[
\lambda_{\max}(H_m)=m+1
\]
for every odd $m\ge3$.

## Legal symmetric extension

Let $P_{\max}$ be the spectral projector of $H_m$ at $m+1$ and set
\[
\Omega=P_{\max}/\operatorname{Tr}P_{\max}.
\]
The invariant-block eigenvector proves $P_{\max}\ne0$. The contracted vector sum defining $H_m$ commutes with the Spin$(m)$ action $U^*\otimes U\otimes U$, and $H_m$ commutes with the swap of the two outputs. Therefore $\Omega$ is Spin-invariant and output-swap-invariant. Each one-party marginal commutes with an irreducible spinor representation, so Schur's lemma and unit trace give $I/d$. In particular, $\operatorname{Tr}_{B_1B_2}\Omega=I_R/d$, making $\Omega$ a normalized Choi state of a trace-preserving broadcaster; output-swap invariance makes the two marginal channels equal, and their output marginals $I/d$ make them unital.

Conjugation on $\operatorname{End}(S)$ is multiplicity-free:
\[
\operatorname{End}(S)\cong\bigoplus_{k=0}^n\Lambda^k\mathbb R^m.
\]
The marginal channel commutes with Spin$(m)$, hence is scalar on each sector. It preserves Hermiticity, so each scalar is real; consequently it is Hilbert--Schmidt self-adjoint. Its vector-sector eigenvalue $\lambda_1$ obeys, by the normalized-Choi star identity,
\[
2m\lambda_1=\operatorname{Tr}(\Omega H_m)=m+1,
\qquad \lambda_1=\frac{m+1}{2m}.
\]
Thus the full ordinary-tensor-product star maximum is attained by a legal symmetric extension and saturates the canonical EB threshold $\operatorname{Tr}Q+S(Q)=m+1$ for every odd $m$.

## Comparison with the independent hostile audit

The existing `ANISOTROPIC_CLIFFORD_VECTOR.md` proves the same all-anisotropy vector-sector bound by a different route, and the completed `work/agents/c7_clifford_hostile/REPORT.md` independently audits it. The hostile report diagonalizes the commuting $A_i=\Gamma_i^T\otimes\Gamma_i\otimes I$, represents the anticommuting $B_i=\Gamma_i^T\otimes I\otimes\Gamma_i$ as bit-flip shifts, and reduces each orbit to $A_i=Z_i$, $B_i=\eta_i\prod_{j\ne i}X_j$. For odd proper subsets it separately retains both central signs; a total-spin SOS then proves the norm bound on each chirality/parity block. Its exact $m=5,k=3$ physical check confirms all four such blocks.

This note is an independent ordinary-tensor proof. It instead diagonalizes the commuting output correlations $D_i=A_iB_i=I\otimes\Gamma_i\otimes\Gamma_i$ and treats the star as a block-weighted subset graph. The exact sign-pattern ranks above show directly that all proper-subset signs occur and that the full odd set has just the volume parity constraint; the graph estimate applies to every present block at once, with no chirality inference or bit-model gauge choice. Its even-$k$ estimate is explicitly $2\sqrt{(k/2)(k/2+1)}<k+1$ at the largest level pair. The hostile SOS gives the simpler uniform expression $k+1$ but carries the additional orbit/chirality bookkeeping. Neither derivation replaces the other as a correctness check; both imply the same layer-cake vector-sector bound. The graph proof is not a duplicate finite fixture: it supplies a different all-$k$ operator argument, while the Jacobi block adds arbitrary-odd-$m$ equality and a legal symmetric extension beyond the finite exact annihilators.

The new equality component is separate from both subset upper-bound derivations: the Spin-isotypic Jacobi block gives an analytic $m+1$ eigenvector for every odd full frame, while the earlier finite certificates establish exact annihilators and top multiplicities only for $m\le11$. The Jacobi construction proves at least a $d$-dimensional top eigenspace; this note does not claim its exact multiplicity for arbitrary $m$.

## Boundary

This closes the isotropic Clifford-vector equality calculation and the full real-positive vector-sector dual bound, including anisotropic weights. It does not control positive duals with components in $\Lambda^k\mathbb R^m$ for $k\ge2$ or mixed vector/higher-form blocks. A general complex-Hermitian matrix on the complexified vector span is outside the stated real-PSD scope. No arbitrary-$Q$ factor-two theorem follows from this note.
