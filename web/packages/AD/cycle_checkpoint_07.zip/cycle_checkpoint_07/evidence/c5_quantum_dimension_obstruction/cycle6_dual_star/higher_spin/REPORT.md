# Higher-spin SU(2) dual-star extension: exact reduction and open gate

## Result and status

The universal (U(d)) cloner has an exact, spin-independent transfer on every nontrivial SU(2) tensor sector. The full two-output compatibility problem also has an exact support-function reduction to a finite three-spin star Hamiltonian. Its pair terms and Racah recoupling matrices are explicit for every (j). The dipole-only (c=2) comparison is exactly tight for every (j>0).

These facts do **not** settle the (c=2) comparison for arbitrary nonnegative mixtures of sectors when (j>1). I found no violating sector in the finite exact checks below, but those checks test individual (Q=Pi_ell), not all mixed weights. The remaining gate is the inequality

\[
 \lambda_{\max}(H_Q)-\operatorname{Tr}_{HS}Q\ \leq\ S_j(Q)
 \quad\text{for every }Q=\sum_{\ell=1}^{2j}\alpha_\ell\Pi_\ell,\ \alpha_\ell\geq0.
\]

A proof would give the common (c=2) EB comparator. A strict failure for any such (Q), together with the feasibility lemma below, would give a genuine SU(2)-covariant symmetric-extension obstruction. No general conclusion between those alternatives is claimed here.

## Conventions and universal cloner transfer

Set (d=2j+1), use normalized trace \(\tau(X)=\operatorname{Tr}(X)/d\), and choose Hermitian \(\tau\)-orthonormal tensor operators \(A_{\ell a}\) for \(\ell=0,\ldots,2j\). The sector \(\Pi_\ell\) has dimension \(n_\ell=2\ell+1\). An SU(2)-covariant, unital, trace-preserving, HS-self-adjoint map has

\[
 \Phi(A_{\ell a})=\lambda_\ell A_{\ell a},\qquad \lambda_0=1,\quad \lambda_\ell\in\mathbb R.
\]

For the Werner universal qudit \(N\to M\) cloner, with \(M\geq N\), input restricted to \(\operatorname{Sym}^N(\mathbb C^d)\), and \(D_r=\binom{d+r-1}{r}\), the channel is

\[
 \mathcal C_{N\to M}(X)=\frac{D_N}{D_M}\,P_M
       (X\otimes I^{\otimes(M-N)})P_M.
\]

For traceless one-body \(A\), its Heisenberg action on the symmetric input is

\[
 \mathcal C_{N\to M}^{\dagger}(A_1^{(M)})
   =\frac{M+d}{M(N+d)}\sum_{r=1}^N A_r^{(N)}.
\]

Thus on product inputs \(\rho^{\otimes N}\), every nontrivial one-site operator sector, including every spin multipole \(1\leq\ell\leq2j\), has the same transfer

\[
 \eta_{N,M,d}=\frac{N(M+d)}{M(N+d)},\qquad
 F_{1}=\frac1d+\frac{d-1}{d}\eta_{N,M,d}.
\]

For the one-input, two-output case relevant to the star, \(\lambda_\ell=(d+2)/(2(d+1))\) for every \(\ell\geq1\). This is the (U(d))-universal cloner, merely restricted to the spin-(j) representation. SU(2) covariance alone permits different \(\lambda_\ell\); the universal cloner is one feasible point, not the full covariant family. In particular, coherent-state cloning is a different objective and must not be identified with this all-pure-state cloner.

For reference, every SU(2)-covariant CPTP channel on a single irreducible spin space has normalized Choi state

\[
 J_\Phi=\sum_{L=0}^{2j}p_L\frac{P_L}{2L+1},\qquad
 p_L\geq0,\quad\sum_Lp_L=1,
\]

where \(P_L\) projects onto total spin \(L\) in \(V_j^*\otimes V_j\). With trace-HS-normalized spherical tensors \(T_{\ell m}\), its transfer coefficients are the Racah transform

\[
 \lambda_\ell=\sum_{L=0}^{2j}p_L\,d(-1)^{2j+L+\ell}
     \begin{Bmatrix}j&j&L\\j&j&\ell\end{Bmatrix}.
\]

This gives the complete CP region for a single covariant marginal: it is the image of the probability simplex under this linear transform. It does not by itself impose a two-output extension.

## Full extension constraints and exact support lemma

For a specified marginal \(\Phi\), a symmetric CPTP extension exists exactly when there is a normalized Choi state \(\Omega_{RB_1B_2}\) satisfying

\[
 \Omega\succeq0,\quad \operatorname{Tr}_{B_1B_2}\Omega=I_R/d,
 \quad \operatorname{Tr}_{B_2}\Omega=J_\Phi
       =\operatorname{Tr}_{B_1}\Omega,
 \quad S_{12}\Omega S_{12}=\Omega.
\]

For the covariant search one may additionally impose invariance under
\(\bar U_j\otimes U_j\otimes U_j\); twirling preserves the displayed constraints whenever \(\Phi\) is covariant. The common one-system marginals are \(I/d\) for unital \(\Phi\). These PSD, marginal, and swap equations are the full feasibility constraints; a scalar transfer vector alone is not a substitute for them.

For invariant \(Q=\sum_{\ell\geq1}\alpha_\ell\Pi_\ell\), \(\alpha_\ell\geq0\), define

\[
 H_Q=\sum_{\ell,a}\alpha_\ell A_{\ell a}^{T}\otimes
       (A_{\ell a}\otimes I+I\otimes A_{\ell a}).
\]

The normalized-Choi convention above gives \(\operatorname{Tr}(\Omega H_Q)=2\operatorname{Tr}_{HS}(Q\Phi)\). The exact Bose-versus-swap lemma is important here. Since \(H_Q\) commutes with output swap, take a normalized top eigenvector \(v\), replace \(|v\rangle\langle v|\) by

\[
 \rho_v=\tfrac12(|v\rangle\langle v|+S_{12}|v\rangle\langle v|S_{12}),
\]

and twirl \(\rho_v\) under \(\bar U_j\otimes U_j\otimes U_j\). The expectation stays \(\lambda_{\max}(H_Q)\), the result is swap-invariant, and irreducibility makes every one-system marginal \(I/d\). It is therefore the normalized Choi state of a symmetric CPTP extension whose marginal is covariant, unital, TP, and HS-self-adjoint (multiplicity-free tensor sectors plus Hermiticity preservation make each \(\lambda_\ell\) real). Consequently,

\[
 \sup_{\Phi\text{ with a symmetric CPTP extension}}
       2\operatorname{Tr}_{HS}(Q\Phi)=\lambda_{\max}(H_Q)
\]

for invariant \(Q\). Swap invariance of a channel does **not** require its Choi state to be supported only on \(\operatorname{Sym}^2(V_j)\). Projecting onto the Bose subspace would change the feasible class and can lower this support. Thus here the star spectral maximum is exact after the stated twirl; it is not merely an unconstrained relaxation.

## Canonical full-domain EB support

For a pure seed \(P_\psi=|\psi\rangle\langle\psi|\), the full-domain orbit measure-and-prepare channel

\[
 \Psi_\psi(X)=d\int_{SU(2)}\operatorname{Tr}(P_gX)P_g\,dg,
 \qquad P_g=U_gP_\psi U_g^\dagger,
\]

is covariant, unital, TP, HS-self-adjoint, and entanglement-breaking. For invariant tests, twirling and the rank-one orbit reduction give the exact support

\[
 S_j(Q)=\max_{\|\psi\|=1}\sum_{\ell=1}^{2j}
       \alpha_\ell d^2\|\Pi_\ell(P_\psi-I/d)\|_\tau^2.
\]

Equivalently the transfer of \(\Psi_\psi\) on sector \(\ell\) is

\[
 \mu_\ell(\psi)=\frac{d^2}{2\ell+1}
       \|\Pi_\ell(P_\psi-I/d)\|_\tau^2,
 \qquad S_j(\Pi_\ell)= (2\ell+1)\max_\psi\mu_\ell(\psi).
\]

The spin-coherent seed is one explicit support point, not generally the maximizer for every sector. Its channel is

\[
 \Psi_{\rm coh}(X)=d\int_{S^2}\langle j,n|X|j,n\rangle
       |j,n\rangle\langle j,n|\,\frac{d\Omega}{4\pi},
\]

and its exact multipole transfer is

\[
 \mu_\ell^{\rm coh}=
 \frac{(2j)!(2j+1)!}{(2j-\ell)!(2j+\ell+1)!},
 \quad 0\leq\ell\leq2j.
\]

This follows by applying the Funk–Hecke formula to the kernel
\(d|\langle j,n|j,n'\rangle|^2=d((1+n\cdot n')/2)^{2j}\). In particular,
\(\mu_1^{\rm coh}=j/(j+1)\). The formula is an EB construction, not an optimality claim for coherent-state cloning.

## Star Hamiltonian and recoupling formulas

Use trace-HS-orthonormal \(T_{\ell m}\) and \(\tau\)-orthonormal \(A_{\ell m}=\sqrt d\,T_{\ell m}\). Identifying the reference spin \(V_j^*\) with \(V_j\) by the spin-flip unitary maps rank \(\ell\) tensors by \(A\mapsto Y_jA^TY_j^\dagger=(-1)^\ell A\). The pair term for sector \(\ell\) is therefore \(d(-1)^\ell K_\ell\), where

\[
 K_\ell=\sum_{m=-\ell}^{\ell}(-1)^m
       T_{\ell m}\otimes T_{\ell,-m}.
\]

On total pair spin \(s=0,1,\ldots,2j\), the exact eigenvalue is

\[
 \kappa_{j,\ell}(s)=(-1)^{2j+s}(2\ell+1)
       \begin{Bmatrix}j&j&s\\j&j&\ell\end{Bmatrix},
 \qquad v_Q(s)=d\sum_{\ell\geq1}\alpha_\ell(-1)^\ell
       \kappa_{j,\ell}(s).
\]

For total three-spin value \(F\), let
\(\mathcal S_F=\{s:0\leq s\leq2j,\ |s-j|\leq F\leq s+j\}\). In the basis \(((j_Rj_{B_1})s,j_{B_2})F\), the change to \(((j_Rj_{B_2})t,j_{B_1})F\) is the Racah matrix

\[
 U^F_{st}=(-1)^{2j+s+t}\sqrt{(2s+1)(2t+1)}
       \begin{Bmatrix}j&j&s\\j&F&t\end{Bmatrix},
\]

up to the usual basis-phase convention. Thus the exact star block is

\[
 H_Q^{(F)}=\operatorname{diag}_{s\in\mathcal S_F}v_Q(s)
       +U^F\operatorname{diag}_{t\in\mathcal S_F}v_Q(t)(U^F)^\dagger,
 \qquad \lambda_{\max}(H_Q)=\max_F\lambda_{\max}(H_Q^{(F)}).
\]

This is a finite exact recipe for every fixed half-integer \(j\), with no grid search. The bound \(\lambda_{\max}(H_Q)\leq2\max_s v_Q(s)\) follows from subadditivity of \(\lambda_{\max}\), but can be loose; the Racah blocks give the star spectrum. The support lemma above then says the full swap-symmetric extension constraints do not lower the invariant support.

For the dipole sector, \(A_a=\sqrt{3/[j(j+1)]}\,J_a\) is \(\tau\)-orthonormal and

\[
 H_{\Pi_1}=-\frac{3}{j(j+1)}\,\mathbf J_R\cdot
       (\mathbf J_{B_1}+\mathbf J_{B_2}).
\]

The two leaves can have total spin \(L=2j\); coupling the center \(j\) to the minimal total \(F=j\) gives the largest star eigenvalue

\[
 \lambda_{\max}(H_{\Pi_1})=\frac{3(2j+1)}{j+1},\qquad
 \lambda_{\max}(H_{\Pi_1})-\operatorname{Tr}_{HS}\Pi_1
       =\frac{3j}{j+1}=S_j(\Pi_1).
\]

So the dipole-only (c=2) inequality is exact and saturated by a coherent EB seed for every \(j>0\). This does not control simultaneous weights in higher multipole sectors.

## Finite exact checks (sector axes only)

The table compares the exact Racah star maximum for \(Q=\Pi_\ell\) with one explicit EB seed score. These are checks of coordinate directions only; they do not prove the inequality for a mixed \(Q\).

| \(j\) | \(\ell\) | \(\lambda_{\max}(H_{\Pi_\ell})-(2\ell+1)\) | EB seed score \(d^2\|\Pi_\ell(P-I/d)\|_\tau^2\) |
|---:|---:|---:|---:|
| 1 | 1 | \(3/2\) | coherent: \(3/2\) |
| 1 | 2 | \((3\sqrt{41}-13)/4\) | \(|1,0\rangle\): \(2\) |
| \(3/2\) | 1 | \(9/5\) | coherent: \(9/5\) |
| \(3/2\) | 2 | \(1\) | coherent: \(1\) |
| \(3/2\) | 3 | \((2\sqrt{345}-29)/5\) | \(|3/2,1/2\rangle\): \(9/5\) |
| 2 | 1 | \(2\) | coherent: \(2\) |
| 2 | 2 | about \(1.1151\) | coherent: \(10/7\) |
| 2 | 3 | \((3\sqrt{41}-11)/4\) | \((|2,2\rangle+|2,-1\rangle)/\sqrt2\): \(19/8\) |
| 2 | 4 | about \(1.8352\) | \(|2,0\rangle\): \(18/7\) |

For the two approximate spin-2 entries, the exact top roots in the \(F=2\) block are respectively the largest roots of
\(98x^3-595x^2-1825x+11000=0\) and
\(98x^3-287x^2-8874x+5184=0\). Rational Sturm isolation puts them in \((6,45/7)\) and \((10,81/7)\), respectively; the all-\(F\) block check puts no larger root elsewhere. Hence the displayed seed scores certify those two axis inequalities. The explicit seeds also show why substituting the coherent seed for the full EB support is unsafe: it is not sectorwise optimal in general.

## Prior art and scope gate

- R. F. Werner, [“Optimal Cloning of Pure States,” Phys. Rev. A 58, 1827 (1998)](https://arxiv.org/abs/quant-ph/9804001): universal symmetric \(N\to M\) cloner.
- M. Keyl and R. F. Werner, [“Optimal Cloning of Pure States, Judging Single Clones,” quant-ph/9807010](https://arxiv.org/abs/quant-ph/9807010): same optimal device for single-clone quality.
- R. Demkowicz-Dobrzanski, M. Kus, and K. Wodkiewicz, [“Cloning of spin-coherent states,” quant-ph/0307061](https://arxiv.org/abs/quant-ph/0307061): a distinct SU(2)-orbit objective; the paper gives exact low-dimensional cases and reports higher-dimensional numerics/conjectures, not a general arbitrary-spin all-state cloner theorem.

The next decisive step is a proof or exact counterexample for the mixed-weight support inequality. A sectorwise table, a universal-cloner point, or the coherent-seed lower bound alone cannot settle it.
