# Cycle 10: finite exact Spin(9) orbit POVMs

## Result

The proposed finite-twirl route works. The candidate (PGL_2(8)) action is
transitive on (k)-subsets for every (k\leq4); this was checked by complete
enumeration, including all 126 four-subsets. Every projective permutation is
even, so it embeds in (SO(9)) and lifts to (Spin(9)). Combining it with all
even coordinate sign changes gives finite exact canonical POVMs whose
measure-and-prepare channels equal the three Cycle 9 Haar-orbit channels on
the full matrix algebra.

Write the nine vector coordinates as (\mathbb F_8\cup\{\infty\}), and use
the real octonionic spinor basis from `pure_orbits.md`. Let (x=(1,0)),
(y_V=(e_1,0)) (basis coordinate 1), and (y_H=(0,1)) (basis coordinate
8). The three seeds are

\[
 \psi_R=x,\qquad \psi_H=(x+i y_H)/\sqrt2,\qquad
 \psi_V=(x+i y_V)/\sqrt2.
\]

Let \(\mathcal G=(C_2)^8\rtimes PGL_2(8)\) be the subgroup of signed
permutation matrices whose sign product is (+1). It has order
\(256\cdot504=129{,}024\); its spin preimage has order 258,048. For the
projective orbit \(\mathcal O_i=\{U_g|\psi_i\rangle\langle\psi_i|U_g^*:g\in
\mathcal G\}\), use the effects
\[
 E_{i,P}=\frac{16}{|\mathcal O_i|}P
\quad(P\in\mathcal O_i),
\]
and prepare (P) after that outcome. Exact stabilizer enumeration and
orbit–stabilizer give:

| Seed moment vertex | Projector stabilizer in \(\mathcal G\) | Distinct outcomes | Effect per outcome |
|---|---:|---:|---:|
| \(v_H=(0,1,7,7)\) | 112 | 1,152 | \(P/72\) |
| \(v_V=(1,4,4,6)\) | 128 | 1,008 | \(P/63\) |
| \(v_R=(1,0,0,14)\) | 896 | 144 | \(P/9\) |

The stabilizers are projective stabilizers of the seed ray (for the balanced
seeds, preservation of the oriented real two-plane spanned by its real and
imaginary parts). The three POVMs each sum exactly to (I_{16}). A mixture
with all three coefficients positive has at most 2,304 outcomes.

## Why the finite channels reproduce the Haar Choi moments

For an even sign vector \(\epsilon\), conjugation sends a Clifford basis
element (T_A) to \(\chi_A(\epsilon)T_A\), where
\(\chi_A(\epsilon)=\prod_{j\in A}\epsilon_j\). On the even-sign subgroup,
two such characters agree only when (A=B) or (A\triangle B=[9]). For
\(|A|,|B|\leq4\), the symmetric-difference size is at most 8, so the second
case cannot occur. Averaging over signs therefore removes every off-diagonal
moment \(m_A m_B\) with (A\ne B\), including all cross-grade terms. It also
removes every non-scalar first moment.

The exact (PGL_2(8)) enumeration has one subset orbit of each size
\(9,36,84,126\) for (k=1,2,3,4). It therefore equalizes the remaining
diagonal second moments within each grade. Their sum in grade (k) is the
seed invariant (s_k), so every diagonal entry is exactly
\(s_k/d_k\), where \(d_k=\binom9k\). These are all the matrix coefficients
of the canonical channel in the complete (T_A) basis. Since
\(S^*\otimes S=\bigoplus_{k=0}^4\Lambda^k\mathbb R^9\) is multiplicity-free,
the finite channels equal the full Spin(9) Haar-twirl channels, not just their
four scalar transfers. The checker confirms the exact seed moments
\(v_H,v_V,v_R\) and each finite orbit's exact first moment (I/16).

The four-subset step is real and needed. (PGL_2(8)) is 4-homogeneous but
not 4-transitive; we did not infer set transitivity from 3-transitivity. A
complete finite calculation constructs its 504 permutations and verifies
one orbit on all 126 four-subsets. This classical group fact is also recorded
in André, Araújo, and Cameron, [*The Classification of Partition Homogeneous
Groups with Applications to Semigroup Theory*](https://research-repository.st-andrews.ac.uk/bitstream/handle/10023/10228/Sn_pairs9Jan2016.pdf?isAllowed=y&sequence=1),
which lists (PGL_2(8)) among the set-transitive degree-nine groups. No
novelty or priority claim is made for that group fact or for the standard
finite-group twirl.

## Exact lift and implementation interface

Every (PGL_2(8)) permutation has even parity. The checker factors each into
an even number (at most 8) of coordinate transpositions. A swap of coordinates
\(a,b\) is the reflection with unit normal \((e_a-e_b)/\sqrt2\), whose
Clifford lift is \((\Gamma_a-\Gamma_b)/\sqrt2\). The product of the even
number of factors is in (Spin(9)) and conjugates the nine generators by the
requested permutation. An even sign change on coordinate set (S) lifts to
\(\prod_{a\in S}\Gamma_a\). The exact checker verifies all (Cl_9) relations,
all 504 lift orthogonality relations, and the conjugation action on all nine
generators for every permutation. Reduced lift-matrix denominators are at
most 4.

An outcome label is an even sign mask, a normalized (2\times2) matrix over
\(\mathbb F_8\), and a seed label, quotiented by the listed seed stabilizer.
Its preparation circuit is the corresponding product of at most 8 reflection
factors and at most 8 Clifford-generator factors applied to the seed. In a
fixed Pauli-word realization, each reflection factor can be written
\[
 (\Gamma_a-\Gamma_b)/\sqrt2
 =\Gamma_a\exp(i\pi P_{ab}/4),\qquad P_{ab}=i\Gamma_a\Gamma_b,
\]
so it is one Pauli word and one quarter-turn Pauli rotation. With weight at
most four, a direct synthesis uses at most 6 CNOT gates and one
\(R_z(\pi/2)\) per rotation, plus local Clifford gates. Thus the state-prep
interface uses at most 48 CNOTs and 8 such rotations for the permutation
part, plus at most 8 sign-lift Clifford words. This is a label-to-state
preparation bound, not an optimized POVM readout circuit.

The full measure-and-prepare channel also has the exact Stinespring interface
\[
 V_i|\phi\rangle=\sqrt{16/N_i}\sum_{P_\omega\in\mathcal O_i}
 |\omega\rangle_C\otimes|\psi_\omega\rangle\langle\psi_\omega|\phi\rangle,
 \qquad N_i=|\mathcal O_i|.
\]
The tight-frame identity makes (V_i\) an isometry; dephasing and discarding
the outcome register gives the stated channel. The label register needs 11,
10, or 8 qubits for (v_H,v_V,v_R), respectively. This exact isometry is a
reproducible channel interface; a compiled physical Naimark readout and its
hardware gate count were not optimized here.

The seeds themselves use only coefficients (0,1,1/\sqrt2) and phase (i).
Every real and imaginary matrix-entry coefficient of every effect is a
rational number: after reduction, nonzero numerators have absolute value 1,
and the largest denominators are 1,152, 1,008, and 144 for (v_H,v_V,v_R).
The exact effects need no numerical precision. The isometry amplitudes add
\(\sqrt{16/N_i}=1/\sqrt{72},1/\sqrt{63},1/3\); approximation error for a
particular physical gate set is outside this certificate.

## One common comparator from supplied transfers

Let \(\lambda_1,\ldots,\lambda_4\) be the supplied sector transfers of the
compatible covariant channel and set \(d=(9,36,84,126)\). The three finite
comparator transfers are \(\eta_{i,k}=v_{i,k}/d_k\):
\[
\eta_H=(0,1/36,1/12,1/18),\quad
\eta_V=(1/9,1/9,1/21,1/21),\quad
\eta_R=(1/9,0,0,1/9).
\]
The Cycle 9 star inequality, with (w_k=d_k\alpha_k), gives
\[
 w\cdot(2\lambda-\mathbf1)\leq\max_i w\cdot\eta_i
 \quad\text{for every }w\geq0.
\]
Finite-dimensional separation therefore supplies one simplex vector
\(q_H,q_V,q_R\geq0\), \(\sum_iq_i=1\), satisfying
\[
 \sum_i q_i\,v_{i,k}/d_k\ \geq\ 2\lambda_k-1,
 \qquad k=1,2,3,4.
\]
Use the single full-domain canonical EB map
\(\Psi=q_H\Psi_H+q_V\Psi_V+q_R\Psi_R\), pooling the three finite POVMs
with effects scaled by (q_i). Its transfer on grade (k) is the left-hand
side, so \(\Psi-(2\Phi-\mathrm{id})\) is positive on every traceless grade;
both maps act identically on the scalar sector. The executable function
`common_mixture_from_transfers` solves these four rational inequalities by
enumerating at most \(\binom72=21\) boundary intersections plus the simplex
corners. Exact rational transfers give an exact rational mixture; the output
size depends on the input transfer bit lengths.

## Verification and limits

Run `python3 finite_compiler.py` from this directory. The standard-library
checker enumerates the finite group and all subset orbits, verifies Clifford
relations and lifts exactly, computes projective stabilizers and distinct
projector orbits, checks all exact first moments, and replays the seed grade
moments. Its captured output is `finite_compiler_output.txt`; machine-readable
counts are in `FINITE_CERTIFICATE.json`. This is exact internal computation,
not proof-assistant verification or an external proof review. A bounded
search confirmed the known (PGL_2(8)) set-transitivity fact and returned no
directly matching Spin(9) finite orbit-POVM construction. This small search
is not evidence of absence; no novelty or priority claim is made.
