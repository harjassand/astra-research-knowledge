# Conditional dose-interaction result for corneal regeneration

## Question and interface

The 2026 corneal study removes the limbal epithelial stem-cell compartment while preserving the niche, then measures K15-GFP mean fluorescence intensity (MFI) on day 25. In the rescue arm, clodronate is given on days −2, 3, and 8. Recombinant factors are injected subconjunctivally every other day from day −1 through day 10. Single-factor doses are IGF1 5 ng, CCL2 100 ng, CXCL10 100 ng, and CXCL16 100 ng per eye; every factor in a combination is given at half its single-factor dose. The reported group size is four biological replicates.

The source-data workbook (`sources/41467_2026_72331_MOESM11_ESM.xlsx`, Figure 5, Fig. 5p) supplies the raw replicates. The reproducible extraction and calculations are in `code/quantify_rescue.py` and `proofs/rescue_quantification.json`.

## Derived result

For each treatment mean, define the marker-gap recovery score

\[
e(x)=\frac{\bar Y_x-\bar Y_{\rm clodronate}}{\bar Y_{\rm control}-\bar Y_{\rm clodronate}}.
\]

This is a normalization of the measured marker endpoint, not an estimate of the fraction of cells that became stem cells. The source means give:

| Treatment | Dose | Mean K15-GFP MFI | Normalized marker-gap recovery |
|---|---:|---:|---:|
| Control | — | 5,077,776 | 1.000 |
| Clodronate | — | 2,239,202 | 0.000 |
| Clodronate + IGF1 | 5 ng | 4,217,792 | 0.697 |
| Clodronate + CCL2 | 100 ng | 4,443,324 | 0.776 |
| Clodronate + IGF1 + CCL2 | 2.5 ng + 50 ng | 5,154,749 | 1.027 |
| Clodronate + CXCL16 + CXCL10 | 50 ng + 50 ng | 3,177,714 | 0.331 |

Under a Bliss independent-action benchmark on this normalized endpoint, the joint effect is

\[
B(e_1,e_2)=1-(1-e_1)(1-e_2).
\]

Assume each single-factor response is nondecreasing with dose and lies in \([0,1]\) after normalizing to the control restoration gap. The combination doses are half of the corresponding single doses, so the effects of each factor at its combination dose cannot exceed the observed full-dose single effects. Since \(B\) is nondecreasing in each argument on \([0,1]\), the full-dose single data give an upper bound on any Bliss-independent half-dose pair:

- IGF1 + CCL2: \(B(0.697,0.776)=0.9323\). The observed pair is 1.027 uncapped, or 1.000 when capped at the control mean. It exceeds the independent-action ceiling by 0.0948 uncapped, and by at least 0.0677 (6.8 percentage points of the control-minus-clodronate gap) when capped.
- CXCL16 + CXCL10: \(B(0.165,0.218)=0.3467\), while the half-dose pair is 0.3306. It does not exceed this ceiling.

Thus the Figure 5p point estimates contain a cue-pair-specific supra-independent marker-rescue signal for half-dose IGF1 + CCL2. This calculation improves on simply repeating the authors' “in concert” description: the pair exceeds even an upper bound formed from full-dose singles, while the other tested pair does not. It is an interaction candidate on a specified response scale, not a universal or proven biochemical synergy claim.

## Why this is still not functional cell-state control

The positive result is only day-25 K15-GFP MFI. The independent natural-regeneration arm has lineage-traced evidence that corneal epithelial cells can restore stem-cell-like transcriptomic and long-term function; the cytokine rescue arm does not measure lineage-resolved donor state, day-40 molecular convergence, six-month homeostasis, or repeat-injury repair. Treat the cue-treated state transition and durable function as `UNKNOWN`.

The monotherapy doses are full dose while the pair doses are half dose each. This lets monotonicity produce an upper Bliss ceiling, but it does not estimate the single-agent half-dose response curves or a dose-response surface. The source also reports about 77% macrophage depletion on day 1, not during CCL2 rescue, and explicitly notes that CCL2 may recruit additional monocytes. IGF1 inhibition is systemic/non-cell-specific in vivo. The data therefore cannot assign the excess to direct epithelial instruction, CCL2-driven niche replenishment, or another interaction. The human experiment uses pre-existing human limbal stem-cell cultures under high-calcium differentiation conditions for six days; it is marker maintenance, not mature human corneal-cell conversion.

## Exact falsifiable experiment

Repeat the same injury and lineage-trace central-cornea donor cells, preserving the original doses and timing. Add matched vehicle, half-dose IGF1 alone (2.5 ng), half-dose CCL2 alone (50 ng), and half-dose IGF1 + CCL2 arms. Measure macrophage/monocyte abundance and local IGF1/CCL2 at days 1, 2, 5, 10, and 25; quantify donor-origin cells in the basal limbal compartments; sample a day-40 state endpoint; then track donor-derived homeostasis through six months and repeat injury.

The preregistered marker-scale prediction is: if the half-dose single-factor effects are monotone and their effects combine independently, the half-dose pair must not exceed the full-dose Bliss ceiling 0.9323. A reproducible pair score above 0.9323 falsifies that specified null. For mechanism, cross the factor arms with a myeloid-selective CCL2/CCR2 recruitment block while preserving epithelial CCL2-receptor capacity, and verify the targeted and untargeted cell populations directly. Loss of the pair's excess only when myeloid recruitment is blocked supports a niche-recruitment relay; persistence of the excess with verified myeloid recruitment blockade supports an epithelial or non-myeloid route. Durable functional recovery must be evaluated separately from MFI.

This is an experimental design, not an experiment performed here. It needs new mouse cohorts, lineage tracing, clodronate plus factor injections, flow cytometry/quantified imaging, and six-month follow-up. The cell-state endpoint is not complete until the lineage/function arm is run.

## Evidence status

- Source-reported: corneal lineage conversion and durable function after injury; macrophage dependence; factor inhibition and rescue of K15-GFP; half-dose combination design.
- Internally recomputed: group means and normalized MFI values from raw Figure 5p replicates; Bliss ceilings and pair-specific excess under the stated assumptions.
- Conditional: positive supra-Bliss marker interaction, conditional on monotone dose responses and the normalized MFI-gap effect scale.
- Not established: formal biochemical synergy; direct epithelial mechanism in vivo; factor-driven conversion of lineage-traced cells; durable function of cytokine-rescued cells; transfer to human mature corneal cells.
