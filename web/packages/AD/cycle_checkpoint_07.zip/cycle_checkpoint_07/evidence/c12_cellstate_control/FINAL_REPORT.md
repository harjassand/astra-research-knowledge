# C12 — cell-state control under regenerative niche feedback

## Result for the parent

The corneal primary data support a conditional, quantitative cue-pair interaction on day-25 K15-GFP marker recovery: half-dose IGF1 + CCL2 gives normalized recovery 1.027, while the most conservative Bliss independent-action ceiling formed from the corresponding full-dose single-agent means is 0.932. Clipping recovery at the untreated-control mean still leaves a 6.8-percentage-point surplus over that ceiling. The tested half-dose CXCL16 + CXCL10 pair does not show the same surplus (0.331 observed versus 0.347 ceiling). Raw values, assumptions, and a standard-library calculation script are preserved in this folder.

This is a source-data-derived candidate for cue-pair-specific dose interaction. It is not a result about durable LSC conversion, nor a proven biochemical synergy: there are four replicates per group, no half-dose single-agent groups, the response is continuous MFI rather than a responder probability, and no cytokine-rescue group is followed for long-term lineage function. The paper itself says CCL2 may recruit additional monocytic cells, while macrophage reduction is only measured at day 1 after clodronate. The rescue may therefore include niche replenishment or growth support.

## Why the candidate has a stronger quantitative core than a marker/fate critique

The dose design provides a nontrivial upper-bound comparison despite missing half-dose monotherapies. Under monotonic single-factor dose responses, half-dose single-agent effects cannot exceed the measured full-dose effects. Bliss independent action is monotone in both inputs, so its full-dose value upper-bounds the expected independent effect of the half-dose pair. The IGF1 + CCL2 point mean exceeds this bound. This is not the preempted pulse-LTI/AUC route, and it is distinct from a hidden-substate selection witness: it ranks two tested cytokine pairs using their actual doses and raw source-data means.

The strongest biological control architecture in the same tissue remains conditional: after injury, a transient macrophage wave coincides with epithelial reprogramming; IGF1 and CCL2 rescue the marker endpoint; corneal-lineage cells can regenerate the LSC compartment under an intact niche; conjunctival cells cannot. The cue rescue itself has not been linked to those durable lineage/function outcomes. The exact pathway of the pair is unresolved because CCL2 can recruit myeloid cells, clodronate depletion is incomplete, and the rescue arm lacks cell-type-specific receptor perturbations and macrophage counts during dosing.

## Quantitative details

- Vehicle control mean: 5,077,776 MFI; clodronate mean: 2,239,202 MFI; mean deficit gap: 2,838,574.
- Full-dose IGF1 (5 ng): 4,217,792 MFI, normalized recovery 0.697.
- Full-dose CCL2 (100 ng): 4,443,324 MFI, normalized recovery 0.776.
- Half-dose combination (2.5 ng IGF1 + 50 ng CCL2): 5,154,749 MFI, normalized recovery 1.027 (1.000 after clipping to the control mean).
- Full-dose single-agent Bliss ceiling: 0.932. Half-dose pair surplus: 0.0948 unbounded; 0.0677 with the response capped at 1.
- Other tested pair: half-dose CXCL16 + CXCL10 gives 0.331 recovery versus full-dose single-agent Bliss ceiling 0.347.

The calculation is reproducible with:

```bash
python3 work/agents/c12_cellstate_control/code/quantify_rescue.py
```

## Decisive experiment

Repeat the injury study with central-cornea donor cells carrying an irreversible lineage label. Add half-dose IGF1-alone and half-dose CCL2-alone arms to the existing half-dose combination and vehicle controls. Cross those conditions with a myeloid-selective CCL2/CCR2 recruitment block while preserving epithelial receptor signaling. Count myeloid cells and assay local cytokines at days 1, 2, 5, 10, and 25. Measure donor-derived basal-limbal identity at day 25 and day 40, then lineage contribution, homeostasis, and repeat-injury function to six months.

The preregistered marker-scale prediction is specific: if the matched half-dose single-agent effects are monotone and independent on this response scale, the pair cannot exceed 0.9323 normalized recovery. Reproducible recovery above that value rejects that model. If myeloid recruitment blockade removes the excess while epithelial receptor function is preserved, a myeloid recruitment relay is implicated; if not, the data favor an epithelial or non-myeloid route. The six-month functional output remains an independent requirement; the current day-25 MFI does not predict it numerically.

## Evidence ceiling and pivot options

The main source is Dimri-Wagh et al. (2026), [Nature Communications](https://doi.org/10.1038/s41467-026-72331-w), PMCID PMC13324013; its single-cell data are public as GSE303805, and Fig. 5p source data are preserved. GEO has one pooled library per timepoint (D0/2/5/10/40), not independent animal-level timecourse libraries, so the dynamic transcriptomic path is descriptive and cannot supply per-animal transition-rate uncertainty. The complete article/evidence boundary is summarized in `sources/NOTES.md` and `CLAIMS.json`.

A second 2026 primary paper on transplanted mature hepatocytes reports a more developed sequence of state-specific levers (Afp–PPARγ metabolic feedback, neutrophil TNF–TNFR1/AP-1 proliferation, OSM identity support, TGF-β-associated migration before zonation), but raw supporting data are available only from authors on request. Its own paper notes missing AFP-Cre fate proof. I did not contact authors, and I do not claim to have reconstructed its mechanism.

**Status:** This folder contains a real, reproducible, conditional quantitative marker-control result and a falsifiable next gate. It does not establish a new regenerative theorem or complete the root research goal. Use as a candidate for root comparison; pivot if the parent judges a Bliss-scale result too assay-specific.
