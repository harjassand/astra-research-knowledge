# C13 failure and scope ledger

- `C13-F01 — no parameterized controller`: source supports a candidate two-state spatial model but does not provide public animal-level absolute counts, state lineage transitions, migration coefficients, or pathway exposure measurements. Therefore no calibrated schedule/front-speed result is possible.
- `C13-F02 — selection versus transition`: cross-sectional single-cell state proportions and pseudotime cannot distinguish within-lineage state conversion from differential proliferation, survival, engraftment, or sampling.
- `C13-F03 — state-to-space substitution`: transient molecular zonation scores do not equal anatomical location; the source describes a week-3 molecular/anatomical Zone-2 divergence. A gene-expression state estimator alone is not a spatial sensor.
- `C13-F04 — mechanism overreach`: TNF/AP-1 has perturbation support in this source model; TGFβ/EMP migration and the Afp-low-to-Afp-high task division remain association-level/inferred in important parts. Do not attribute a quantitative spatial function to these paths.
- `C13-F05 — generic model formula`: the two-state linear determinacy speed formula is established control/PDE theory. Its restatement in source-aligned variables is not novel and does not count as the research advance.
- `C13-F06 — 2025 ammonia alternative not continued`: primary source and workbook were downloaded during bounded screening, but no second work cycle was undertaken. Treat those files as exploratory intake only.
