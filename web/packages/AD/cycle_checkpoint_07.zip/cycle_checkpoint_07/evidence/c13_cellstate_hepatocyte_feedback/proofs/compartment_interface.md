# Two-state spatial interface and identifiability boundary

## Proposed source-aligned state variables

Let `m(x,t)` denote an Afp-low, EMP-high donor population and `h(x,t)` an Afp-high, metabolically specialized donor population. A candidate linearized reaction–diffusion interface is

```text
∂t [m; h] = D ∂xx [m; h] + A [m; h],
D = diag(Dm,Dh),
A = [[gm-kmh, khm], [kmh, gh-khm]].
```

Here `g_i` are local net growth rates, `k_ij` transition rates, and `D_i` effective spatial dispersal coefficients. The source does not provide estimates for these quantities. The source's molecular zone score is not a spatial observation during the transient phase; histology is needed to observe position.

## Conditional front-speed identity

For a linearly determinate cooperative two-state branching-diffusion system with a stable zero state, exponential leading-edge ansatz `u(x,t)=exp(-λ(x-ct))v` gives the dispersion relation

```text
c λ v = (D λ² + A)v.
```

For cooperative `A`, the dominant real eigenvalue (equivalently the spectral abscissa) at spatial exponent `λ` is `s(Dλ²+A)`. The minimal wave speed is therefore

```text
c* = inf_{λ>0} s(D λ² + A)/λ.
```

This is a standard conditional result, not an internally established new theorem. It yields no numerical prediction until A and D are acquired, and linear determinacy must be checked for the nonlinear system.

## Why the current source cannot identify the controller

For cross-sectional observed abundance `y_i(t)` in state i, even the well-mixed two-compartment model

```text
m' = (g_m-k_mh-d_m)m + k_hm h
h' = k_mh m + (g_h-k_hm-d_h)h
```

only observes net linear combinations if the measurements are relative proportions. Scaling both populations and changing growth/death/transition terms can preserve the same proportions. With only four post-transplant timepoints in each round, no irreversible state label, and no per-animal absolute donor counts, the source trajectory does not separate `k_mh` from differential selection. The article also uses expression-derived zonation predictions and separately reports a transient disagreement between molecular Zone-2 assignment and anatomical Zone-2 occupancy. Thus zonation score cannot substitute for the spatial state required by a transport controller.

## Required measurable interface to advance

1. Absolute tdTomato+ donor-cell counts and host-cell counts per animal and timepoint.
2. Irreversible lineage label of the candidate Afp-low/Afp-high state, so within-lineage transitions can be separated from selection.
3. Registered spatial occupancy / migration distance per donor lineage, not expression-based zone labels alone.
4. Time-stamped dose, tissue exposure, target engagement, and washout for TNF/AP-1, AFP/PPARγ, OSM, and any migration intervention.
5. Held-out injury severity and timepoints for comparing a coupled transport/state model with homogeneous-state and independent-state-selection controls.

No such parameterized model or experiment was created in this round.
