# Restart contract

This is a frozen C13 checkpoint following parent direction to finish the current round and stop. C12 files are unchanged.

Resume only if a new parent checkpoint authorizes continuation and a public or already-authorized data interface supplies animal-level absolute donor counts plus irreversible state lineage and spatial occupancy. First test whether state-transition and differential-selection models are distinguishable under those observations. Do not fit synthetic Nature parameters to source prose. Keep the two-state front identity labeled standard/conditional. Compare any new model against homogeneous-state and independent-state-selection baselines.

Primary paths: `FINAL_REPORT.md`, `CLAIMS.json`, `proofs/compartment_interface.md`, `sources/NOTES.md`, `failures/FAILURES.md`.

No children were spawned; no external contact, wet-lab action, clinical recommendation, or publication occurred.
