# C13 checkpoint — transplanted-hepatocyte state and niche feedback

## Verdict

No new quantitative regenerative-control capability is established in this bounded round. The strongest cell-state lead examined is Fang et al. (2026), which reports mature donor hepatocytes entering a transient regenerative program during Fah−/− liver repopulation. It supplies a rich *candidate* sequence of measured states and perturbation levers, but the underlying data are author-request-only, the rates required for a control model cannot be acquired from the paper, and the article itself identifies a missing lineage proof for AFP-positive cells. I therefore stop at an evidence/interface reconstruction rather than attach invented parameters or promote the source's associations to a validated controller.

This is a C13 record. C12 remains unchanged.

## Reconstructed source interface

Primary source: Fang et al., “Conversion of Transplanted Mature Hepatocytes into Afp+ Reprogrammed Cells for Liver Regeneration After Injury,” *Advanced Science* 13(18), e17126 (2026), DOI [10.1002/advs.202517126](https://doi.org/10.1002/advs.202517126), PMID 41609487, PMCID PMC13042875. The full text is retained at the C12 intake path `work/agents/c12_cellstate_control/sources/PMC13042875_fullTextXML.xml`; this checkpoint does not modify it.

The experiment labels mature donor hepatocytes with tdTomato, transplants them into Fah−/− recipients by intrasplenic injection after NTBC withdrawal, and profiles donor-derived cells over two serial transplantation rounds. Eight scRNA-seq samples span 1, 3, 6, and 12 weeks in each round; the article reports 29,130 tdTomato+ cells. It reports ~90% donor AFP+ cells at week 1, declining to <5% by week 12, with Ki67+ donor-cell frequency peaking at week 3. A week-3 proliferative Afp-low subset is associated with elevated EMP/AP-1 activity; Afp-high cells are associated with metabolic and Zone-3-like signatures. Histology reports anatomical occupancy preceding recovered molecular zonation.

The proposed niche/control graph is: host/donor AFP ↔ PPARγ and metabolic program; neutrophil TNFα → donor TNFR1 → AP-1 → proliferation; neutrophil OSM is proposed to support hepatocyte identity; TGFβ-associated EMP is proposed to support migration; PPAR-associated programs are proposed to support zonation/maturation. Interventions reported include AFP knockdown/overexpression, recombinant AFP, PPARγ agonist/antagonist, and AP-1 inhibitor. The TNF/AP-1 perturbation is evidence for a requirement in this model; the TGFβ-to-migration and zonation links remain largely inferred from signatures and temporal/spatial association.

## Quantitative/model audit

The paper motivates a two-phenotype transport model: a more motile/proliferative Afp-low compartment and a more metabolically specialized Afp-high compartment. A generic linearized two-state branching-diffusion model would have state vector `x=(m,h)` with local growth/transition matrix `A` and diffusivity matrix `D`; its pulled-front speed, when the usual linear-determinacy and irreducibility conditions hold, is `c* = inf_{λ>0} s_max(D λ² + A)/λ`. This is a standard conditional model identity, not a new theorem and not a source-derived prediction here.

The article provides no public cell-count matrices or animal-level time series from which to estimate `A`, `D`, state-transition rates, or uncertainty: its Data Availability Statement says supporting data are available from the corresponding author upon reasonable request. The reported time points are sparse (1/3/6/12 weeks), and pseudotime / single-cell proportions do not identify cellwise transition rates separately from state-specific proliferation, death, engraftment, sampling, or host clearance. Spatially, the source itself reports that transcriptionally assigned Zone-2 fractions increase while the anatomical Zone-2 niche is disrupted at week 3; this rules out treating the molecular zonation score as a direct observation of location during the transient phase.

Thus the minimal acquired interface for a defensible control calculation is still absent: animal-level absolute donor-cell counts; lineage-resolved state transitions (including an irreversible Afp-state label); spatial occupancy per animal; timed pathway perturbation and washout; and dose/exposure measurements. Without them, an optimal pulse schedule or numerical front prediction would be synthetic. No controller was fitted and no nature-level quantitative prediction is claimed.

## Decisive falsifier / next gate

The key mechanistic test is whether the proposed motile Afp-low to metabolically specialized Afp-high division of labor is a real lineage transition that changes spatial repopulation, rather than a mixture of independently selected states. A decisive dataset would combine irreversible state/lineage labeling, absolute donor counts, spatial occupancy, and timed TNF/AP-1 versus PPARγ/AFP perturbation with washout across the 1–12 week interval. The model must beat equally informed controls that use only total donor burden, independent state-specific proliferation/selection, or a single homogeneous phenotype. The principal falsifier is no within-lineage transition or no incremental spatial prediction after conditioning on donor-cell abundance and injury severity.

This is a research specification, not an experiment performed here. No author was contacted; no wet-lab work, external messaging, medical advice, or publication occurred.

## Bounded alternative screen

While selecting the lead, I inspected Endaya et al. (2025), *Nature Communications* 16, 9664, DOI [10.1038/s41467-025-65451-2](https://doi.org/10.1038/s41467-025-65451-2), on ammonia-supported pyrimidine synthesis after partial hepatectomy. Its source workbook was publicly downloadable and opened locally, but this alternative was not pursued into a second research round. The article's tracer pulse is 9 mmol/kg 15NH4Cl intraperitoneally 30 minutes before sacrifice, and its source-reported ~50%/~75% labeling interpretation does not by itself resolve flux among glutamine/GDH/GOT and CPS1-associated routes. The workbook and one supplemental PDF intake attempt remain in `work/agents/c13_ammonia_redox_control/sources/`; they are exploratory artifacts, not findings or a second C13 result. No new downloads or analysis should be added without a new parent checkpoint.

## Evidence status

- Source-reported: measured donor-cell time course, state-associated proliferation/migration/metabolic programs, transplantation and perturbations.
- Internally reconstructed: source interface and separation of observed quantities from inferred transitions.
- Conditional model identity: the two-state branching-diffusion front-speed formula above.
- UNKNOWN: cellwise state-transition rates, spatial transport coefficient, a calibrated switching rule, and any optimal intervention schedule.
- Rejected route: using the reported state associations or the paper's inferred signatures as if they identified a numerical state-feedback controller.
