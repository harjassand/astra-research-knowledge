# Sources and boundary

## Primary cell-state source

Fang et al., “Conversion of Transplanted Mature Hepatocytes into Afp+ Reprogrammed Cells for Liver Regeneration After Injury,” *Advanced Science* 13(18), e17126 (2026), DOI `10.1002/advs.202517126`, PMID 41609487, PMCID PMC13042875.

- DOI: https://doi.org/10.1002/advs.202517126
- Full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC13042875/
- Locally retained source XML: `work/agents/c12_cellstate_control/sources/PMC13042875_fullTextXML.xml`
- Data statement: supporting data from corresponding author on reasonable request.
- Source-reported limitations: the authors note absence of AFP-Cre lineage tracing to formally show AFP-positive rHeps as a precursor of the repopulating cell population.

The locally retained XML was read to extract the source interface and results. No author contact was made; no raw count matrix was acquired or reconstructed.

## Bounded alternative examined during source choice

Endaya et al., “Regenerating liver uses ammonia to support de novo pyrimidine synthesis and cell proliferation,” *Nature Communications* 16, 9664 (2025), DOI `10.1038/s41467-025-65451-2`.

- DOI: https://doi.org/10.1038/s41467-025-65451-2
- Article: https://www.nature.com/articles/s41467-025-65451-2
- Public Source Data workbook, locally retained at `work/agents/c13_ammonia_redox_control/sources/source_data.xlsx`.
- The article methods report a 9 mmol/kg intraperitoneal 15NH4Cl pulse 30 minutes before sacrifice. The source article's ammonia-to-pyrimidine interpretation is not pursued here as a second lead.

This alternative was opened only during bounded source selection. No claims about its mechanisms or quantitative results are part of C13-01–03.
