# N33 permanence composition checkpoint

Status: partial formal reconstruction; the full global permanence theorem remains unproved.

## Frozen task-local artifacts

- `formalization/WeightedDrift.lean`: verbatim copy of the actual current c4 module. Its SHA256 is `eebe4a64c45f5d2388f4f5dd3bb2f9269fe28486d4360e0311d6c35db49f35f0`, identical to `work/agents/c4_rational_hostile/formalization/dynamics/WeightedDrift.lean`. This differs from the older hash recorded in the c4 report (`874d92c9e2454a08ad57e21b032d400c563f72480895ec6d1e47be859afab152`); the prior empty c4 kernel-audit log was left untouched.
- `formalization/TrajectoryDrift.lean`: SHA256 `62f424e3e927a4ad7317cff445a6d187da7609338efcd193c20978db333592ef`; 597 lines.
- `formalization/TrajectoryDrift.olean`: task-local compiled output, SHA256 `b6b32aa0cf02a6bad706c245b74df0a89b16ecd40421ae21e733e67a11dbc37e`.
- `formalization/PlateauPrinciples.olean`: task-local replay of the unchanged c4 source, SHA256 `6a2e0c5e1abd2d51deb682979682b5bd37365e07af63d2668b91aa79521e00e5`.
- `formalization/TrajectoryDriftAudit.lean` and `replay/TrajectoryDrift.kernel-audit.log`: `#print axioms` for the integration APIs below. Every listed theorem depends only on `[propext, Classical.choice, Quot.sound]`; there is no `sorryAx`, `admit`, or custom axiom in the audited declarations.
- `replay/TrajectoryDrift.compile.log`, `replay/PlateauPrinciples.compile.log`, `replay/WeightedDrift.compile.log`, and `replay/WeightedDrift.kernel-audit.log` preserve the compile and audit outputs. Lean 4.28 was used with the matching Mathlib 4.28 project path from the existing c4/c10 verification scripts; all new OLean outputs are task-local.

The pinned source hashes are `bbecea61cd373a787920bb4484494114b7d616d5f20ee096cae3831487707e9c` for `work/agents/permanence_hostile/endotactic_permanence.tex` and `28b8628ce97517025e22d1ac18eabbef39d0b4384f3aa7bad0463b3025d8bec0` for `work/agents/permanence_hostile/OA149/affine.tex`. Neither source was edited.

## Proved composition

`N33Dynamics.exists_affine_family_with_activity` composes `N33Affine.exists_full_affine_family` at the source tolerance `WeightedDrift.pointTolerance D` with `WeightedDrift.exists_activity_margin`. It constructs a family, its full approximation proof, and one positive uniform `hAct < 1`; those objects are not supplied as premises to this wrapper. The point tolerance is positive on every cube point by the compiled `pointTolerance_pos` lemma.

`N33Dynamics.exists_box_log_coordinates` proves the exact change of variables for arbitrary real exponents: if `0 < h < 1` and `h ≤ x_i ≤ h⁻¹`, then `x = scalePoint h p` with `p_i = log(x_i)/log(h)` and `p ∈ [-1,1]^d`. The construction handles zero coordinates in the index type by the same general theorem and does not discretize or truncate exponents.

The affine-envelope lemmas preserve all weak ties. Uniform activity gives `active_slope_coordinate_ge_margin`; consequently every active slope at an inner representative is zero, and one such zero-slope active branch proves the global ceiling `reactionAffineEnvelope F h y ≤ reactionAffineEnvelope F h c`. A second classwise lemma proves that below this representative level no weakly active branch can have slope orthogonal to the reaction span.

`reactionEnvelope_derivative_nonneg_ae` composes the pointwise weighted-drift estimate with the c10 finite-minimum AC chain rule along the actual vector path and its a.e. ODE identity. It covers every weakly active branch, including ties. `reactionEnvelope_derivative_ge_margin_below_ae` strengthens this to the uniform positive margin below the representative level inside the fixed class, using the nonperpendicular-slope lemma.

`reactionEnvelope_enters_plateau_by_range` is the one-scale finite-entry theorem. Define

\[
\delta=\kappa\,\mathrm{slopeMargin}(D,F)\,h^{\mathrm{sourceBudget}(D)},\qquad
m_0=\min_j\bigl(b_j(h)-\|s_j\|_1h^{-1}\bigr),\qquad
T=a+\frac{\mathcal E_h(c)-m_0}{\delta}.
\]

The theorem proves `∃ t ∈ [a,T], ReactionPlateau F h c (x t)` for an already-given AC path `x` on `[a,T]`, provided the explicit small-scale inequality `K * reactionBudget * h^slopeMargin ≤ κ * slopeMargin` holds, the representative lies in the positive scale box, its envelope is a global ceiling, and the entire path is supplied to remain in that box and the same stoichiometric class on the interval. Rate bounds and the coordinatewise ODE identity are required almost everywhere. The floor lemma proves `m₀ ≤ envelope(x(t))` throughout that box; the range/time estimate then forces contact with the ceiling. Thus the entry time is path/initial-state dependent, not claimed uniform over the class.

## Remaining gates to full permanence

1. Derive a usable scale `h` below the constructed `hAct` that also satisfies the explicit small-scale inequality. This checkpoint keeps that inequality visible; it does not hide it inside an unexplained cutoff.
2. Produce the source's class representative with all logarithmic coordinates strictly inside `slopeMargin`, and derive the global envelope ceiling from that representative. The local inner-representative implication is proved, but representative selection is not.
3. Prove forward invariance of the positive box/plateau from the vector field and weak-active derivative facts. The finite-entry theorem still assumes box and class preservation over its whole horizon.
4. Establish Carathéodory local existence and uniqueness for measurable rate profiles, positivity and stoichiometric-class preservation, and continuation while the solution remains in the compact box. No solution-existence or continuation theorem is claimed here.
5. Compose one-scale entry and invariance across the source's scale sequence (including its common classwise absorber). No common absorber or global-in-time trajectory theorem has been proved.
6. Audit the complete source claim against the OA149 interface and independently validate the reconstructed theorem. This formal reconstruction does not establish novelty or priority.

Accordingly, the proven result is a conditional one-scale AC trajectory composition with explicit quantitative gates—not global permanence for the original measurable-rate model.
