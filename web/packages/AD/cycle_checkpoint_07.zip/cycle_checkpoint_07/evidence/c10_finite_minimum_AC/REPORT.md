# Finite affine lower-envelope Caratheodory bridge

## Result

`FiniteMinimumCaratheodory.lean` compiles with Lean 4.28.0 against the existing pinned Mathlib cache and the read-only parent module `FiniteMinimum.lean`. It proves the finite affine lower-envelope bridge from vector-valued interval absolute continuity through the a.e. drift consequence. The compiled object and all logs are task-local.

The exact public API is recorded by `AxiomAudit.lean` and `axiom-audit.log`. The main declarations are:

```lean
affineMinimumAlong_absolutelyContinuous
  (hx : AbsolutelyContinuousOnInterval x a b) :
  AbsolutelyContinuousOnInterval (affineMinimumAlong x coeff offset) a b

affineMinimumAlong_ae_common_differentiable
  (hx : AbsolutelyContinuousOnInterval x a b) :
  ∀ᵐ t, t ∈ uIcc a b →
    DifferentiableAt ℝ (affineMinimumAlong x coeff offset) t ∧
    (∀ i, DifferentiableAt ℝ (affineBranchAlong x coeff offset i) t) ∧
    DifferentiableAt ℝ x t ∧
    (∀ j, DifferentiableAt ℝ (fun u => x u j) t)

affineMinimumAlong_ae_active_derivative_eq
  (hx : AbsolutelyContinuousOnInterval x a b) :
  ∀ᵐ t, t ∈ uIcc a b → ∀ i,
    affineBranchAlong x coeff offset i t = affineMinimumAlong x coeff offset t →
    (∑ j, coeff i j * deriv (fun u => x u j) t) =
      deriv (affineMinimumAlong x coeff offset) t

affineMinimumAlong_ae_drift_lower_bound
  (hx : AbsolutelyContinuousOnInterval x a b)
  (hbranchDrift : ∀ᵐ t, t ∈ uIcc a b → ∀ i,
    affineBranchAlong x coeff offset i t = affineMinimumAlong x coeff offset t →
    δ ≤ ∑ j, coeff i j * deriv (fun u => x u j) t) :
  ∀ᵐ t, t ∈ uIcc a b →
    δ ≤ deriv (affineMinimumAlong x coeff offset) t
```

Here `x : ℝ → (Fin m → ℝ)`, `coeff : ι → Fin m → ℝ`, `offset : ι → ℝ`, and `[Fintype ι] [Nonempty ι]`. The coefficient vectors and offsets are fixed. The time endpoints are unrestricted, so the theorem uses Mathlib's unordered closed interval `uIcc a b`. The type signatures also cover `m = 0` and `a = b`; no positive-dimension or strict-endpoint hypothesis was introduced.

## Proof correspondence

The module uses Mathlib's `AbsolutelyContinuousOnInterval` definition for both the vector path and the scalar branch/envelope functions. It derives coordinate AC by composing the vector path with each 1-Lipschitz coordinate projection. A fixed affine branch is then AC by finite sums, scalar multiplication, and addition. The absolute value of a scalar AC function is proved AC by the endpoint inequality `dist (|u|) (|v|) ≤ dist u v`; the identity `min f g = (f + g - |f-g|)/2` gives binary-minimum AC. Induction over `Finset.Nonempty.cons_induction` extends this to the exact `Finset.inf'` used by the parent `finiteMinimum` definition.

For a.e. regularity, the proof applies the actual Mathlib theorem `AbsolutelyContinuousOnInterval.ae_differentiableAt` to each scalar branch and to the scalar envelope. It applies it to every path coordinate and takes the countable/finite AE intersection. Mathlib's `differentiableAt_pi` then yields differentiability of the vector-valued path itself. Thus differentiability of the minimum is derived from AC; it is not an input assumption to the a.e. result.

At a common differentiability time, the affine branch derivative is proved by the finite-sum derivative rule and the coordinate chain rule. The parent `finite_minimum_active_derivative_eq` is then applied to every index satisfying equality with the minimum. The weak active condition is equality to the lower envelope, and the theorem universally quantifies over all such indices, so ties are retained. The drift corollary uses finite attainment only to select one active index after the hypothesis has already bounded every active branch.

## Verification and assumptions

Run `work/agents/c10_finite_minimum_AC/verify.sh`. The completed run returned:

```text
PASS: Caratheodory finite-minimum module compiles; audited declarations have no sorryAx.
```

`compile.log` is empty. `axiom-audit.log` reports the standard Lean/Mathlib axioms `[propext, Classical.choice, Quot.sound]` for each exported theorem; it reports no `sorryAx`. No new axioms are declared in the source.

The module imports the parent `FiniteMinimum` source only as a dependency; it does not edit or rebuild that module. The `.lean`, `.olean`, script, API audit, report, claims ledger, and logs are all under `work/agents/c10_finite_minimum_AC/`.

## Boundary

This closes the finite affine lower-envelope AC/a.e. differentiability and active-branch drift step. It does not formalize the global N33 permanence conclusion, the preceding dynamical estimates, or any external validation of the mathematical argument.
