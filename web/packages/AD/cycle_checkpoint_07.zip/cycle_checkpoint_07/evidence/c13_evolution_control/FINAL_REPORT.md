# C13 evolution steering — source/mechanism checkpoint

Date: 2026-10-08  
Scope: bounded primary-literature screen and candidate-gate definition. C12 is preserved unchanged. No biological work, experimental action, clinical inference, author contact, or publication was performed.

## Verdict

This checkpoint does **not** establish a new evolution-control capability, theorem, or priority claim. The timing/synchronization mechanism in phage cocktails is explicitly source-reported and preempted as a discovery by the 2019 timing-and-order paper as well as the 2026 primary paper. Do not promote that mechanism as C13's result or turn it into an operational protocol.

The strongest unresolved, higher-ceiling gate is whether a **measured, context-dependent genotype-transition graph** can predict or steer escape when both edge availability and state fitness change with ecological context. A suitable representation must keep distinct: (a) genotype/resistance states and measured transition frequencies, (b) their fitness/competition values in each environment, and (c) contemporaneous ecological/phage state. Available primary papers measure important pieces, but the inspected evidence does not join them into a calibrated route-level stochastic model or validate a state-aware policy against equally informed controls. This is a research direction, not a result.

## Primary evidence screened

1. **Van der Steen, Gralka & Mulla (2026), “Rapid resistance evolution against phage cocktails,” ISME Journal**, [DOI 10.1093/ismejo/wrag067](https://doi.org/10.1093/ismejo/wrag067). The paper reports a minimal bacteria–replicating-phage model in which asynchronous phage collapse can permit sequential acquisition of resistance, and tests matched versus non-matched collapse timing using *E. coli* MG1655 and phages p17, p33 and p61. The reported assays include one-step growth curves, serial-inoculum collapse measurements, and 48-hour dual-phage checkerboards. Its model estimates a resistant-mutant count and maps that to probability using an exponential-count assumption. The authors explicitly state that clinical pharmacokinetics are too poorly understood for quantitative transfer. These are source claims; I did not obtain or reconstruct the supplement or raw data.

   **Novelty boundary:** this is not an unreported timing principle. Wright et al. (2019), [“Resistance Evolution against Phage Combinations Depends on the Timing and Order of Exposure,” mBio](https://doi.org/10.1128/mBio.01652-19), already studies time/order-dependent phage resistance experimentally. C12's Appold timing contrast was separately rejected as a new control capability.

2. **Wu et al. (2026), “Phage receptor specificity drives cross-resistance patterns and governs fitness trade-offs during sequential resistance acquisition in *Salmonella*,” ISME Journal**, [DOI 10.1093/ismejo/wrag077](https://doi.org/10.1093/ismejo/wrag077). The article reports receptor-dependent cross-resistance among O-antigen, LPS-core, and BtuB-targeting phages; WGS on 59 resistant isolates; and a three-phage passage outcome in which LPS-associated resistance (including low-cost *rfaJ* routes) precedes later *btuB* changes. The indexed article text reports complete three-phage resistance by day 6. This supports a genotype/resistance-state topology as a necessary representation and directly warns against treating “three distinct receptors” as independent escape barriers. It does **not**, in the material inspected, provide a fully observed, denominator-complete mutation-transition kernel and state-by-environment fitness table sufficient for a calibrated escape controller.

3. **Muzafar et al. (2026), “Interspecies interaction alters the trajectory of antibiotic resistance evolution by amplifying negative fitness epistasis,” ISME Journal**, [DOI 10.1093/ismejo/wrag014](https://doi.org/10.1093/ismejo/wrag014). The paper reports approximately 640 generations of *Salmonella* evolution with or without *E. coli* under sub-MIC streptomycin, competition-associated *aadA* expression, and context-dependent epistasis in resistant isolates (six of ten co-culture isolates were reported to show negative epistasis; four were additive). The authors use *aadA* deletion comparisons. This is direct evidence that ecological context can reshape the genotype–fitness map; it does not establish an adaptive steering policy or a general “evolutionary trap.”

4. **Feng et al. (2025 preprint, version dated March 2026), “A theory of ecological invasions and its implications for eco-evolutionary dynamics,”** [arXiv:2503.10865](https://arxiv.org/abs/2503.10865). This theoretical primary source develops “dressed invasion fitness” and extinction-aware abundance shifts for LV/consumer-resource-type models, and analyzes correlated mutant invasions in an SSWM regime. Its stated evolutionary simulations neglect stochastic mutant dynamics (large-population approximation). It supplies a relevant ecological interaction framework, not finite-population escape probabilities or a controller.

The Astra topical index/blockers search found no matching evolution/ecology/phage card in the local topic tables; no Astra card was used as evidence or dependency.

## Candidate interface and decisive missing object

For a proposed nonclinical, in-vitro steering question, the acquired object would need to be a finite state graph with states (g) (genotype/resistance class), ecological context (e) (including competitor/resource state), and treatment/phage state (a). Needed data include the transition/event law (Q(g'\mid g,e,a)), the state-specific growth/survival/competition law (W(g,e,a)), and the observation model linking sequencing/phenotyping to these states. The question is whether a constrained choice over contexts or exposure histories changes the probability of reaching a prespecified escape set, relative to an equally informed static-susceptibility or endpoint-fitness baseline.

The load-bearing missing measurement is **route-linked acquisition under the same evolving conditions**: mutation/transition supply and genotype frequency through time, paired with the relevant environment-specific competition and susceptibility/fate. Endpoint resistant-isolate panels identify some states and phenotypes but not their route frequencies; one cocktail passage sequence does not estimate the probability of all competing paths. Conversely, population-level temporal susceptibility without genotype-linked abundance does not identify which path caused the change. Sequencing depth, isolate/competition assays, phage kinetics, detection limits, ecological replication, culture time, and compute needed for interval propagation must be charged. A missing or undetected path stays unknown rather than being assigned zero probability.

No policy or theorem was constructed in this checkpoint. The strongest equally informed comparison remains the full measured genotype/context transition model versus a static resistance/susceptibility or mean-fitness summary, but neither has been implemented here. Avoid calling a finite state-graph calculation a new capability until it beats that full-information comparator on held-out trajectories under matched acquisition cost.

## Independent falsification and restart gate

The candidate fails if measured transition edges and context-conditioned fitness do not improve held-out route/fate predictions over the equally informed static/full-history baselines; if the apparent graph omits low-frequency or unobserved escape routes; or if an intervention chosen from the graph fails to change route-level outcome under matched observation and exposure cost. State-dependent mutation supply, multi-mutant epistasis, density dependence, and changing resource/phage abundance are explicit threats to a static graph. No test was run, so all of these remain open falsifiers rather than results.

Next restart, if authorized by the parent checkpoint: first reconstruct the published *Salmonella* genotype × receptor-susceptibility × fitness evidence and the *Salmonella–E. coli* context-specific fitness evidence from their primary tables/supplements. Determine whether there is a common measurable state space or only disconnected data. Then attempt one finite, explicit adversarial example or policy comparison with mutation acquisition and ecological transitions charged. Stop if the evidence cannot identify route probabilities or if existing equal-information methods already solve the restricted problem. Do not pursue phage synchronization as a novelty claim.

## Evidence status and failures

- External/source-reported: the findings and experimental designs summarized above, at the exact scopes of the cited articles.
- Internally reconstructed: none.
- New theorem, policy, or finite computation: none.
- Priority/novelty: not established; timing/synchronization mechanism is preempted.
- Data access failure/limit: source discovery used indexed primary-article text and search/open results; no raw tables, supplements, or experimental data were downloaded or reconstructed in this checkpoint.
- No child agents were launched; no independent audit was performed.

