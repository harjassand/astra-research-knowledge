# Product isotope data do not identify the Cu–Fe C–C route

## Finding

The previous label-swapped fixture is only a probability-bookkeeping example. Its `0.2/0.8` precursor fractions were invented for that fixture, are not in either paper, and must not be read as a Cu–Fe prediction. More importantly, positional acetate labels alone do not give disjoint predictions once source-specific conversion, CO-site populations, reversible exchange, and carbon isotope effects are left as unknowns. I derived an exact intersection of the two product-law sets, including time-dependent traces. The Cu–Fe literature version inspected does not give the measured quantities needed to decide whether the real catalyst is near or far from that intersection.

This is a negative identifiability result under an explicit nuisance model, not a claim that the two mechanisms are physically identical. It blocks the proposed product-only assay as a decisive mechanism test. The next defensible experiment must observe a route-specific surface intermediate and establish that it is kinetically connected to acetate formation.

## What the Cu–Fe source actually specifies

The inspected July 2026 arXiv v1 reports a manually assembled reaction graph with 32 intermediates, 41 steps, nine paths, and four product families. Figure 2 shows both (i) `*CO + *CO -> OCCO* -> OCCOH* -> HCCO*` and (ii) `*CO -> *CHO; *CHO + *CO -> COCHO* -> HCCO*`, after which `HCCO*` can reach ketene and acetate. Yet the abstract and discussion separately say the newly proposed route is `*CO + *CH2 -> H2CCO*`. That direct atom-pair step is not the C–C edge drawn in Figure 2. These passages may describe sequential routes, alternate routes, or a figure/text mismatch; the release does not supply a machine-readable, atom-mapped graph that resolves it. The mass-balanced skeleton alone does not tell which carbon becomes acetate methyl versus carboxyl.

The quantitative energetics in the inspected version are much thinner than the pathway language suggests. The reported comparison is isolated Fe substitution in a CuO surface; a Fe2O3-like cluster is described as binding ketene strongly but no number is given. The authors argue that cathodic conditions make a metal-terminated surface the realistic active state, but the inspected report does not establish that active termination operando. Reported values are:

| Source-reported quantity | Value | What it establishes |
|---|---:|---|
| Ketene adsorption energy on the compared CuO surface | −0.61 eV | One model energy for an isolated adsorbate/surface configuration |
| Ketene adsorption energy after isolated Fe substitution in CuO | −0.48 eV | A +0.13 eV change (weaker binding in that comparison) |
| `CHO* + CO*` entry described as “lowest-barrier” | no numerical barrier reported | Qualitative ranking only |
| CO–CH2 coupling, CO dimerization, ketene desorption/capture, and competing branch transition states | no numerical barrier reported | No rate comparison or microkinetic route fraction can be reconstructed |

The preprint says its reasoning process bypasses ab initio reaction calculations; it later reports the two UMA ketene adsorption energies above. It also explicitly says reliable transition-state calculations are future work. Thus the +0.13 eV adsorption shift cannot be converted into an activation-barrier or selectivity prediction. The preprint's threefold acetate-selectivity result is source-reported experimental performance; it does not validate a particular atom map.

## Strongest competing pathway and direct counterexample to a label-ratio shortcut

The competing CO-dimer route is present in the Cu–Fe Figure 2 itself, predates this preprint, and has strong supporting evidence on other Cu systems. A 2017 primary study detected hydrogenated dimer `OCCOH*` by FTIR during CO reduction on Cu(100), but not Cu(111), so it establishes a real alternative while also warning that facet-specific behavior cannot be transferred to Cu–Fe without measurement. The 2022 acetate mechanism paper analyzes ketene formation/capture on Cu; it is prior to the Cu–Fe proposal.

More directly, a 2026 *Science Advances* CuBi study performed `12CO/13CO2` co-reduction at varied mixing ratios and reported `12CH3-13COO− / 13CH3-12COO− > 1`, increasing as the `12CO` share rose. The authors interpret this positional preference as asymmetric hydrogenation **after** mixed `*12CO-*13CO` coupling, producing `*12CH2-13CO` ketene at CuCO2/CuCO interfaces. Its isotope experiment is on CuBi under 5 M KOH COR conditions, not on Cu–Fe under the reported CO2RR conditions. It nevertheless disproves the simple inference that this positional orientation rules out a CO-dimer route. The study says its binomial input fraction was measured on products by GC–MS rather than assumed from feed composition; it does not report the Cu–Fe site-specific precursor pools needed here.

For independent effective precursor enrichments, let `pM` and `pC` be the fractions of 13C incorporated at methyl and carboxyl. The positional ratio is

`R = P(12M,13C) / P(13M,12C) = [(1-pM) pC] / [pM (1-pC)]`.

This is only the ratio of positional 13C odds. For direct coupling, `pM` may be the effective CH2-pool enrichment and `pC` the effective CO-pool enrichment. For a fixed-orientation dimer route, exactly the same expression holds with `pM = pA` and `pC = pB`, the two site-dependent CO-pool enrichments. An observed `R > 1` is therefore consistent with either route. Even under this independent-pool simplification, one measured ratio leaves a continuum of pool pairs: for any `pM` in `(0,1)`, `pC = R pM / (1-pM + R pM)`.

## Exact overlap, including time dependence, reversible exchange, and isotope effects

Write `J(i,j,t)` for the probability that the two carbon atoms captured into an acetate-forming event have labels `i,j ∈ {12,13}` at time `t`. Direct coupling reads the pair from effective CH2 and CO pools; dimer coupling reads it from site-A and site-B CO pools, followed by an orientation rule. If the pools are independent, `J` is the product of their Bernoulli laws. The executable symbolic witness in [transient_identifiability.py](transient_identifiability.py) verifies:

1. For arbitrary time functions `pCH2(t)` and `pCO(t)`, assign `pA(t)=pCH2(t)`, `pB(t)=pCO(t)`, and let site A become methyl. All four positional isotopomer probabilities are identical pointwise in time. No enrichment numbers are assumed.
2. If isotope exchange makes all four effective pools share one enrichment `p(t)`, the laws are identical for **every** dimer orientation probability `alpha ∈ [0,1]`. Complete precursor scrambling is therefore an exact overlap even when asymmetric hydrogenation is not perfect.
3. Any common downstream product residence/detector kernel preserves pointwise equality: integrating the same law against the same kernel cannot create route information. A shared reversible two-pool isotope-exchange transfer matrix is an explicit state-space realization of the same overlap.
4. A carbon kinetic-isotope effect maps source fraction `s` and isotope-specific rate ratio `κ=k13/k12` to effective fraction `p=sκ/(1-s+sκ)`. As Cu–Fe carbon KIEs and site-specific enrichment histories are unreported, these unknowns add freedom; they do not supply a disjoint prediction.

This is a constructive intersection, not proof that the complete physical attainable sets are equal. Some calibrated feed/surface regimes could make them separable. The inspected Cu–Fe source supplies no CO-site enrichment histories, CH2 enrichment, exchange constants, carbon KIEs, positional acetate transient, or elementary barriers with which to exclude the intersection. Product-only mass spectra, product-only position ratios, and position-resolved product SSITKA therefore cannot currently certify topology. The old `.2/.8` fixture remains only an arithmetic example and is not evidence of a source-separated Cu–Fe pool.

## Decisive observation to purchase

The potentially discriminating readout is not a more elaborate end-product ratio; it is a route-specific intermediate signal linked to acetate flux. The first experiment should keep the Cu–Fe CO2RR chemistry fixed and switch only carbon isotope at steady state (`12CO2 -> 13CO2 -> 12CO2`), with the reported Cu:Fe 1:1 catalyst and Cu-rich comparator, and at the reported electrolyte/pH conditions. Do not add CO for the primary result: CuBi data show that COR and CO2R can produce radically different acetate selectivities, and co-feed can create a different active-site/pool regime.

Combine time-resolved isotope-edited operando IR/Raman with steady-state isotope-transient analysis and fractionated acetate output. The target spectral components are the proposed `CO*–CH2*`/ketene branch and the competing hydrogenated CO-dimer (`OCCOH*`) branch. Record carbonate/bicarbonate and inlet/outlet carbon-isotope responses at the same time; fit separate CO adsorption-site populations, reversible exchange, isotope effects, reactor hold-up, detector response, and product residence as nuisance parameters. Use the product positional isotopomers as a downstream check, not as the sole discriminator. Fit both candidate state-space networks and profile the direct/dimer route fraction over all nuisance values compatible with uncertainty.

A route is supported only if its isotope-shifted intermediate has a validated spectral assignment and a transient kinetically connected to acetate formation, and the competing route cannot fit the joint intermediate-plus-product traces. Detection of a species alone is insufficient: the species may be a spectator or a parallel sink. Failure to see a predicted band is inconclusive unless a positive-control standard establishes the detection limit at the relevant coverage and turnover rate. If both route models still fit after profiling pools and KIEs, report `UNKNOWN`.

This is a technically grounded proposal, not a demonstrated assay. Primary literature establishes operando detection of hydrogenated CO dimer on Cu(100), later SERS work observes potential-dependent CO-dimerization/reduction intermediates on Cu, and 2026 electrochemical SSITKA is demonstrated on Pt-catalyzed methanol oxidation. These are method precedents, not validation on Cu–Fe acetate synthesis. The 2017 `OCCOH*` signal was facet-sensitive, so spectral visibility/assignment on the mixed Cu–Fe oxide is a major experimental gate. The 2026 eSSITKA article also warns that inert-gas substitution alone does not accurately represent reactant exchange time under electrochemical conditions; record feed and reactive isotope signals directly rather than using Ar alone to deconvolve the transient.

### Cost and resource ledger

| Required resource | Why it is charged | Amount/cost status |
|---|---|---|
| 13CO2 cylinders, isotope-certified CO2/CO standards, gas switching/mixing and isotope-ratio calibration | Label pulse, source purity, inlet/outlet isotope history | Consumption and price `UNKNOWN`; isotope switch count must follow pilot signal and mass balance |
| CuFe 1:1 and Cu-rich control synthesis, batch characterization, replicate electrodes | Reproduce source catalyst and reject batch/morphology artifacts | Source catalyst synthesis and characterization are required; independent replicate count, material use, and cost `UNKNOWN` |
| Gas-tight electrochemical flow/spectroelectrochemical cell, potentiostat, electrolyte, pH/current control | Preserve the actual steady-state CuFe regime during isotope switching | Cell time, electrolyte use, and waste `UNKNOWN` |
| Fast operando isotope-edited IR/Raman acquisition and standards | Separate CO, CH2/ketene and OCCOH signatures; establish detection limits | Instrument/beamtime hours and accessibility `UNKNOWN`; mode-specific cross sections on CuFe unmeasured |
| Online gas analysis and time-fractionated liquid product collection; positional 13C NMR/validated equivalent | Correct residence/hold-up and quantify acetate positions | Analysis throughput, sample number, minimum acetate quantity, and price `UNKNOWN` |
| Carbonate/bicarbonate isotope response and carbon/charge balances | Estimate DIC-mediated feed exchange and exclude missing carbon | Calibration effort and runtime `UNKNOWN` |
| DFT vibrational assignment on experimentally characterized CuFe phases, only if needed | Test whether overlapping bands can be assigned to pathway states | Compute, model uncertainty, solvation/field, and surface reconstruction costs `UNKNOWN`; do not substitute for measured isotope shifts |
| Pilot, parameter estimation, uncertainty/power calculation, preregistered model comparison | Set switch cadence, detection limits, and required replication from observed noise | Must be charged before confirmatory runs; size and runtime `UNKNOWN` |

No dollar, instrument-hour, or energy number is reported because no lab quote, access schedule, turnover time, or measured signal-to-noise was supplied. Computation for the symbolic counterexample is exact algebra with no numerical chemistry parameters; the dominant cost is physical measurement and target-specific spectral assignment.

## Stop/go and claim status

The existing position-only assay should be stopped as a proposed decisive test. Continue only after (a) the authors' complete atom-mapped 41-step graph and active surface state are obtained or reconstructed, (b) a pilot isotope switch demonstrates distinguishable, assignable route-specific intermediate transients on Cu–Fe, and (c) a nuisance-profiled model comparison has non-overlapping prediction regions at the measured precision. If any gate fails, retain the Cu–Fe selectivity result and mark the microscopic pathway `UNKNOWN`.

No new catalyst, pathway, isotope method, SSITKA theorem, or external validation is claimed here. The actual advance in this packet is a source-grounded correction to the earlier proposed assay: its decisive premise does not survive realistic unmeasured pools, and the precise missing observation is route-specific, product-connected intermediate dynamics. This remains a hard experiment rather than an achieved breakthrough.

## Primary sources

1. Choudhury et al. 2026, [arXiv:2607.08003 v1](https://arxiv.org/abs/2607.08003) and [PDF](https://arxiv.org/pdf/2607.08003). Source for Cu–Fe graph, the `−0.61/−0.48 eV` adsorption energies, experimental selectivity, textual/figure route discrepancy, and explicit future need for TS calculations.
2. Yang et al. 2026, [Science Advances DOI 10.1126/sciadv.aef9216](https://doi.org/10.1126/sciadv.aef9216), [full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC13557063/). Primary CuBi position-resolved co-feed experiment and post-dimer asymmetric-hydrogenation interpretation.
3. Pérez-Gallent et al. 2017, [Angew. Chem. DOI 10.1002/ange.201700580](https://doi.org/10.1002/ange.201700580). FTIR detection of OCCOH on Cu(100) during CO reduction; not evidence for Cu–Fe.
4. Heenen et al. 2022, [Energy & Environmental Science DOI 10.1039/D2EE01485H](https://doi.org/10.1039/D2EE01485H). Primary Cu acetate mechanism and ketene route prior art.
5. Ledesma et al. 2014, [ACS Catalysis DOI 10.1021/cs501264f](https://doi.org/10.1021/cs501264f). SSITKA method review (prior art).
6. 2026 eSSITKA primary proof-of-concept, [ACS Catalysis DOI 10.1021/acscatal.6c00526](https://doi.org/10.1021/acscatal.6c00526). Electrochemical SSITKA demonstrated for Pt-catalyzed methanol oxidation to CO2, with cautions on using inert gas as an exchange-time proxy.
7. Ma et al. 2024, [JACS DOI 10.1021/jacs.4c08755](https://doi.org/10.1021/jacs.4c08755). Prior art for source-separated isotope co-feed and *CO-site analysis.
