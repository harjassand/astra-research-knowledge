# Catalysis lead update: product isotope tracing does not resolve the Cu–Fe route

## Finding

I withdraw the earlier claim that a label-swapped, position-resolved acetate assay would by itself distinguish direct `*CO + *CH2` coupling from a CO-dimer route. Under real but unmeasured source-specific pools, site-dependent CO, reversible exchange, and carbon isotope effects, the two routes have an exact overlap in all four acetate positional isotopomer laws, including arbitrary time-resolved traces. The old `0.2/0.8` numbers were illustrative only. They are not reported or measured Cu–Fe enrichments.

The strongest defensible result is therefore a negative identifiability finding and a more stringent experiment: add route-specific, isotope-edited operando intermediate signals and test their kinetic connection to acetate. This is a costly, unperformed experiment, and its method components have prior art. I found no new catalyst, mechanism, or confirmed capability to claim as a breakthrough.

## Source reconstruction

The inspected July 2026 CoThinker v1 reports 32 intermediates, 41 steps, nine pathways, and four product families. Figure 2 draws both `*CO + *CO -> OCCO* -> OCCOH* -> HCCO*` and `*CHO + *CO -> COCHO* -> HCCO*`, with a shared downstream ketene/acetate branch. The abstract and discussion additionally describe a distinct `*CO + *CH2 -> H2CCO*` route, but that C–C edge is not shown in the Figure 2 graph. The inspected release has no machine-readable, atom-mapped network to determine whether these claims are sequential, competing, or inconsistent.

The only numerical Cu–Fe pathway energetics in the inspected version are ketene adsorption energies of −0.61 eV on the compared CuO surface and −0.48 eV after isolated Fe substitution, a +0.13 eV shift toward weaker binding in that particular model. A Fe2O3-like cluster is said to bind ketene strongly, but no number is supplied. The paper argues that a metal-terminated surface is realistic under cathodic conditions without establishing the active termination operando. It calls `*CHO + *CO` the “lowest-barrier” C–C entry but gives no numerical transition-state barrier. It gives no numerical barrier for CO–CH2 coupling, CO dimerization, ketene desorption/capture, or competing branches. It explicitly leaves transition-state modeling for future work. The adsorption-energy change is not a rate or barrier prediction.

The reported threefold acetate-selectivity increase, pH trend, and material characterization remain source-reported experimental results. They do not identify the active pathway. The inspected version reports GC and ¹H NMR product analysis, no position-resolved ¹³C route test.

## Adversarial identifiability result

The CuBi comparator is now a counterexample to the simple label-ratio argument. Yang et al. (2026) report a preference for `¹²CH₃¹³COO−` over `¹³CH₃¹²COO−` under `¹²CO/¹³CO₂` co-reduction and attribute it to asymmetric hydrogenation after mixed `*¹²CO-*¹³CO` coupling. That result is on CuBi in 5 M KOH COR conditions, not on Cu–Fe CO₂RR, but it proves that a positional preference can arise under a dimer-then-hydrogenation interpretation. The paper varies the co-feed composition and says the isotope fraction used in binomial calculations came from product GC–MS rather than from the gas-feed ratio. Its observed ratio cannot be treated as a measured Cu–Fe precursor-pool enrichment.

For independent effective precursor enrichments, the measured position ratio is

`R = P(12M,13C) / P(13M,12C) = [(1-pM)pC] / [pM(1-pC)]`.

Under direct coupling, `pM,pC` can be the reacting CH₂ and CO pools. Under a fixed-orientation dimer route, the same numbers can be the two site-dependent CO pools. Thus `R > 1` does not distinguish route topology. With arbitrary time-dependent effective enrichments, assigning dimer site A the direct route's CH₂ history, site B its CO history, and A-to-methyl orientation makes all four product isotopomer probabilities equal at every time. If reversible exchange equilibrates all pools, equality holds for any orientation. Common detector and product-residence kernels preserve the equality. Carbon kinetic isotope effects are an additional unconstrained part of each effective history because the Cu–Fe carbon KIEs are not reported.

The symbolic proof in [transient_identifiability.py](transient_identifiability.py) uses no invented enrichments, isotope-effect factors, or kinetic rates. This is an exact intersection witness under the stated nuisance model, not proof that all possible physical behaviors overlap. Measuring all relevant precursor histories may create a separable regime. No such Cu–Fe histories are reported, so a product-only signature cannot currently be called decisive.

## Strongest alternative and next experiment

The strongest alternative is already present in the Cu–Fe graph: CO dimerization followed by hydrogenation into the ketene/acetate branch. It also has independent primary support on Cu surfaces. Pérez-Gallent et al. detected hydrogenated dimer OCCOH by FTIR during CO reduction on Cu(100), but not Cu(111), showing both that the alternative is real and that it is structure-sensitive. The 2026 CuBi result provides position-resolved product evidence under a post-dimer interpretation. None transfers directly to the Cu–Fe catalyst.

To test Cu–Fe, maintain its CO₂RR feed, potential, electrolyte, pH, and flow while switching only ¹²CO₂/¹³CO₂ at steady state in both directions. Combine isotope-edited operando IR/Raman with SSITKA and time-fractionated acetate output. Track DIC/carbonate/bicarbonate, distinct CO adsorption-site populations, the proposed CO–CH₂/ketene species, hydrogenated CO dimer OCCOH, and position-specific acetate. Fit direct and dimer state-space models jointly with reversible exchange, isotope effects, reactor/detector hold-up, product residence, and spectral response as nuisance parameters.

A route-specific species must have a validated isotope-shifted assignment and a transient kinetically connected to acetate production. Mere detection can indicate a spectator or parallel route. A missing band is inconclusive without a measured coverage-dependent detection limit. If both nuisance-profiled models fit, retain `UNKNOWN`.

SSITKA itself is established prior art; the 2014 review covers broad heterogeneous catalysis, and a 2026 eSSITKA study demonstrates electrochemical isotope-transient measurements on Pt-catalyzed methanol oxidation. The latter cautions that inert gas alone does not accurately represent reactant exchange time under electrochemical conditions, so the proposed experiment must directly record inlet, dissolved-carbon, surface-isotope, and product responses. Prior operando FTIR/SERS evidence for CO dimerization does not validate detection on reconstructed Cu–Fe oxide. This assay is a research proposal, not an achieved capability.

The resource ledger in [TRANSIENT_IDENTIFIABILITY.md](TRANSIENT_IDENTIFIABILITY.md) charges labeled gases, isotope and gas-flow calibration, catalyst batches, electrochemical and spectroscopy time, isotope-edited standards/DFT assignment, online gas analysis, liquid fractionation, position-resolved NMR, mass balances, pilot/power analysis, and replication. Money, instrument hours, energy, minimum acetate signal, and runtime remain `UNKNOWN`; no lab quotes or signal-to-noise data were supplied.

## Artifacts and status

* [TRANSIENT_IDENTIFIABILITY.md](TRANSIENT_IDENTIFIABILITY.md): source reconstruction, exact overlap proof, paid experiment, controls, and cost ledger.
* [ATOM_MAPPING.md](ATOM_MAPPING.md): corrected atom-map and product-law conclusion.
* [transient_identifiability.py](transient_identifiability.py): executable exact symbolic check.
* [isotopomer_model.py](isotopomer_model.py): retained historical toy arithmetic only; its explicit `0.2/0.8` inputs are synthetic and not evidence.
* [CLAIMS.json](CLAIMS.json): updated source and model statuses, falsifiers, and next gate.

The gate before a confirmatory experiment is to resolve the Cu–Fe graph/atom-map, demonstrate distinguishable route-specific bands on the as-run catalyst, and show by nuisance-profiled power analysis that the joint intermediate/product predictions separate at measured precision. If those gates fail, do not spend the larger assay budget on product-only isotope ratios.

## Primary sources

* Choudhury et al. 2026, [arXiv:2607.08003](https://arxiv.org/abs/2607.08003).
* Yang et al. 2026, [Science Advances DOI 10.1126/sciadv.aef9216](https://doi.org/10.1126/sciadv.aef9216), [full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC13557063/).
* Pérez-Gallent et al. 2017, [Angew. Chem. DOI 10.1002/ange.201700580](https://doi.org/10.1002/ange.201700580).
* Heenen et al. 2022, [Energy & Environmental Science DOI 10.1039/D2EE01485H](https://doi.org/10.1039/D2EE01485H).
* Ledesma et al. 2014, [ACS Catalysis DOI 10.1021/cs501264f](https://doi.org/10.1021/cs501264f).
* 2026 eSSITKA primary proof-of-concept, [ACS Catalysis DOI 10.1021/acscatal.6c00526](https://doi.org/10.1021/acscatal.6c00526).
* Ma et al. 2024, [JACS DOI 10.1021/jacs.4c08755](https://doi.org/10.1021/jacs.4c08755).

## Required route record

Required local instructions were read before retrieval. SHA-256 hashes:

| File | SHA-256 |
|---|---|
| `work/ROOT_MANDATE.txt` | `085becba25e31939f5c94affe45b8e303516bbc606b442b96b2db289ef600cb6` |
| `work/astra_prior/00_START_HERE.txt` | `942f14761e72a88fbedacb268cf48272662a0f8e6005a6bdf1dd24c75374a77b` |
| `work/astra_prior/01_CORE.txt` | `d7a4c6b7c339aca36241a706d5d8f87620985c7684ec7c42f230806e973adbd4` |
| `work/astra_prior/RESEARCH_WORKFLOW.txt` | `2fad297cb3c879f47e33547c0aa6dd3307667c2aa6127e7aee98cce5b1f0a2b6` |
| `work/astra_refresh/0132f3d37f9ba3b0ab0de07779ef3e17e5768e30/00_START_HERE.txt` | `9d3631f1bd7a9396b33a9eb43717b5bd54d52c73f46b239f3f27617fcc559ac3` |
| `work/astra_refresh/0132f3d37f9ba3b0ab0de07779ef3e17e5768e30/01_CORE.txt` | `f12ea58ff0f14d86868cf7e923745c9c599b2565ca6b5211f7dab517eab90189` |
| prior `chemistry_dynamic_catalysis/FINAL_REPORT.md` | `10a09e29644417e3f93cbe2c40ec3bdb8279cc9c7ea2e592320043dd2f540acf` |
| prior `chemistry_catalytic_thermodynamics/FINAL_REPORT.md` | `07b041b2d218cdf0d82e3a39beab7002e2f3e988c6f9b5c1376dea4d2f5abbf4` |
| prior `chemistry_electrochemical_tradeoffs/FINAL_REPORT.md` | `a9f9c9e7be3ae8df9d205d573cf86fe56adfdc8b7f2c7d2627757caa4c097da4` |
| prior `materials_energy/FINAL_REPORT.md` | `d5710b24e8d3d84d4388b16cff9889236e739fdd8c1f584885f8b25902175891` |

The Astra prior/refresh cores did not supply a chemistry-specific mechanistic result used here. The selectively read local chemistry reports cover stationary current/affinity bounds, stochastic pumping, and electrochemical tradeoff accounting; this lead was kept distinct from those results.
