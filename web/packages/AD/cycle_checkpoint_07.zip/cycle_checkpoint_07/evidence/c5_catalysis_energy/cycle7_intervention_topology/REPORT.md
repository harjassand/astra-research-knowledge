# Cycle 7 — Can an isotope intervention break the CO–CH₂ / CO–CO topology overlap?

## Load-bearing target and verdict

**Target:** identify an operationally attainable state in which a labeled, pre-reduced C₁ intermediate survives while every labeled carbon atom that could enter the competing reactive-CO pool is quantitatively bounded. Then use a carbon-inventory inequality—not a fitted barrier or a positional-label heuristic—to test whether the measured acetate pulse is impossible under a CO–CO-only C–C-forming route.

**Verdict:** the inequality is exact and executable, and a 2025 Cu nanowire/GDL catalyst is a substantially better testbed than Cu–Fe for pursuing it. The published record does **not** establish the required CH₂-only isotope window, isotope-edited intermediate assignments, active-site CO flux limits, or acetate time series. The intervention is therefore **conditionally decisive but not yet demonstrated feasible**. I do not promote it as a new chemical discovery or a completed capability. If the pilot cannot verify the isotope window and all-CO nuisance bound, the mechanism remains `UNKNOWN` and the confirmatory isotope experiment should not proceed.

The key missing fact is not the rank of a regression matrix. It is a physically measured upper bound on how many old-label carbon atoms can visit an active CO state during the collection window, including atoms that start in CH₂ and might return to CO. Occupancy spectra alone do not bound this flux.

## Primary-source testbed and quantitative reconstruction

Sun et al. (first published 7 May 2025) used a Cu nanowire array covered with a hydrophobic alkanethiol gas-diffusion layer. Cu18 denotes 1-octadecanethiol and an approximately 2.5 nm layer. Their flow-reactor performance tests used 1 M KOH. Cu18 gave reported C₂+ FE 87% and C₂+ current density −1.05 A cm⁻²; Cu6 gave 70% and −0.42 A cm⁻². Cu18 acetate FE was reported as more than four times Cu6, but the main text does not give its absolute value. Performance bars report three replicates. Operando resonance Raman used 785 nm excitation and scanned current density from −10 to −200 mA cm⁻². At −10 mA cm⁻² the 379 cm⁻¹ band was assigned to Cu–CH₂; at −20 mA cm⁻² it shifted to 391 cm⁻¹ while a 1102 cm⁻¹ feature in the C–C=O region appeared. Those are source assignments, not isotope-validated labels. The paper reports four modeled CO configurations (physisorbed, atop, bridge, fourfold) at calculated frequencies 2120, 2012, 1880, and 1673 cm⁻¹; coadsorbed CH₂ also shifts modeled atop/bridge CO modes from 2012→1997 and 1880→1867 cm⁻¹. Thus one unresolved CO pool is not an adequate nuisance model.

For Cu(100), the paper reports CH₂–CO activation energies 0.76 eV (one configuration) and 0.81 eV (another), versus 1.22 eV for its symmetric CO–CO comparison. At 298.15 K, equal-prefactor transition-state theory would give

`k(CO–CO)/k(CH₂–CO) = exp(−ΔE/kBT) = 1.17×10⁻⁷` for ΔE=0.41 eV and `1.68×10⁻⁸` for ΔE=0.46 eV.

This is a conditional arithmetic consequence of the paper's Cu(100) barriers, equal prefactors, and equal relevant coverages. It is not an operando rate estimate, and it is not transferable to Cu–Fe, CuBi, or another Cu morphology. The isotope intervention below does not use these barriers.

The source's supporting context makes the test unusually attractive and unusually demanding: the same paper detects multiple post-CO signals under CO₂ feed, but does not report ¹³C switching, positional acetate isotopomers, or a competing OCCOH transient. Its data-availability statement says raw supporting data are available from the corresponding author on reasonable request; no raw spectra/time traces were in the source page. It also notes that other post-CO species may contribute to the complex CO bands. The 379/391 cm⁻¹ and 1102 cm⁻¹ assignments therefore need isotope-specific calibration before they can be used as state variables.

## The decisive intervention, with the exact condition for success

Use the Cu18 flow/Raman configuration, preserving 1 M KOH, the three-phase CO₂/electrode/electrolyte contact, and the source's measured potential/current regime. Do not use CO co-feed for the primary result: it changes the reaction regime and the pool being tested.

1. Establish a steady state under ¹³CO₂ and record the actual inlet isotope fraction, dissolved inorganic carbon (DIC) isotope fraction, current, and all resolved CO-site bands.
2. Switch to ¹²CO₂ using a calibrated low-dead-volume valve while holding operating conditions fixed. Measure, rather than assume, the feed, DIC, reactor, surface, and product response functions. Continue only if a time window exists in which a ¹³CH₂-specific signal remains above its validated limit while the total **unique old-label inventory capable of entering reactive CO** is bounded below the product assay's planned detection threshold.
3. In that window, apply a registered current step spanning the source's −10→−20 mA cm⁻² regime where the 1102 cm⁻¹ feature first appears. Record current and potential at sufficient bandwidth to resolve the cell's measured capacitive response. Collect product fractions with the measured liquid/product residence kernel, not nominal valve times.
4. Quantify methyl- and carboxyl-labeled acetate separately by quantitative ¹³C NMR (or a validated positional assay), and record isotope-edited Raman for CH₂, each CO binding geometry, ketene-like CH₂CO, and any CO-dimer/OCCOH candidate. A carbon mass balance includes inlet/outlet gas, liquid acetate and other C₁/C₂ products, DIC, catalyst inventory, and dead volume.
5. Run a matched sham valve switch (¹²CO₂→¹²CO₂) and a matched current waveform on a fresh randomized electrode. Use Cu6 as a GDL-thickness control and Cu foil–18 without the nanowire array as the source's spectral-enhancement control. A Cu(100) dimer-positive standard can calibrate whether an isotope-edited OCCOH signal is detectable, but it is not a substitute for a same-catalyst pathway comparison.

The registered alternative is `DIMER_ONLY`: both atoms at C–C formation must have visited reactive `*CO`. Let `Y₁₃Me` be the number of methyl-¹³C acetate molecules in the pulse fraction, corrected conservatively for natural abundance and instrument cross-talk. Let `B₁₃CO` be the upper bound on the number of **distinct** old-¹³C atoms that could have occupied a reactive CO state at any time during that fraction. It includes all four CO site classes, gas/liquid hold-up, old-label DIC that can re-enter CO, old-label feed leakage, other unresolved carbon pools, and ¹³CH₂ atoms that could convert back to CO before C–C formation. Then the dimer-only hypothesis obeys the stoichiometric implication

`Y₁₃Me ≤ B₁₃CO + B_background`.

Each methyl-¹³C acetate molecule requires one distinct ¹³C atom to have passed through reactive CO if the C–C bond was formed by two CO species; one atom cannot supply two final acetate molecules. This implication is independent of barrier heights, KIE values, site-specific enrichments, orientation bias after dimerization, and downstream product-residence kernels. If the measured lower confidence bound satisfies `Y₁₃Me,L > B₁₃CO,U + B_background,U`, `DIMER_ONLY` is refuted for the tested operating regime.

That inequality alone establishes a non-CO C₁ source, not specifically CH₂. To support `CH₂ + CO`, also require (i) an isotope-calibrated ¹³CH₂ signal, (ii) a temporally ordered ¹³CH₂ decrease and ¹³C-ketene appearance, (iii) product-connected acetate labeling after correcting the measured residence response, and (iv) a bound on any other pre-reduced C₁ source smaller than the same separation margin. If these are absent, report `DIMER_ONLY_REFUTED; ALTERNATIVE_C1_SOURCE_UNKNOWN`, not “CH₂ mechanism proven.”

### Why the state-preparation gate is decisive

If ¹³CH₂ can rapidly dehydrogenate back to ¹³CO with negligible measurable occupancy, a CO–CO route can mimic the labeled ketene/product pulse. A snapshot of CO coverage does not bound that flux. The pilot must therefore bound *all unique labeled atoms that can enter active CO during the window*, not just measured CO coverage at a few time points. The isotope-edited CO response must cover physisorbed/top/bridge/fourfold states and establish detection limits under CH₂ coadsorption, which the primary paper says can shift or suppress CO signatures. The DIC isotope transient must be acquired directly; inert-gas switching does not calibrate CO₂/DIC exchange in concentrated alkaline electrolyte.

If no interval meets the bound, this intervention fails cleanly. More product-only isotope ratios, position ratios, or longer SSITKA traces cannot repair it when the CO pools remain unbounded. A further intervention would need to block or trap the route-specific precursor without altering the shared active ensemble; I found no primary-source-validated selective CH₂ trap or CO–CO knockout for this catalyst. I do not claim one.

## Controls and confounders

The strongest mechanistic alternative is not a straw man: CO–CO dimerization is a widely discussed pathway; hydrogenated dimer OCCOH has been observed by FTIR on Cu(100), with facet dependence. CuBi isotope co-reduction has also shown positional acetate bias interpreted as asymmetric hydrogenation *after* CO dimerization, so a preferred methyl/carboxyl label cannot rule out dimer topology. The Cu18 paper itself compares CO–CO against CH₂–CO and claims lower modeled barriers for the latter. These facts make the direct-vs-dimer comparison balanced.

Pre-register the following as nuisance controls, not post-hoc excuses:

- Calibrate all isotope-switch transport kernels from inlet, outlet, DIC, and product traces. Do not infer reactive exchange time from an Ar switch alone.
- Run isotope-edited CO reference spectra across the source's four modeled adsorption states and the CH₂-coadsorbed condition; quantify cross-talk and the worst-case missed ¹³CO amount/flux.
- Calibrate Raman response and limits against independent coverage standards. Report band intensity as coverage only after calibration; frequency assignment alone does not quantify molecules.
- Measure ¹³CO₂ impurity and ¹³C in electrolyte/catalyst blanks. Quantify charge and all carbon-containing products to exclude a missing outlet reservoir.
- For a secondary H₂O/D₂O KIE run, measure temperature, conductivity, pD, uncompensated resistance, and isotopomer incorporation; compare rates at matched measured coverages. Both candidate mechanisms contain proton/electron chemistry, so a KIE is a nuisance-model constraint, not the main discriminator.
- Record current/potential synchronously, remove capacitive background using matched blank pulses, and integrate total charge. The current transient is required for matching the perturbation and checking electron/carbon balance; it is not by itself a path label.
- Run at least the source's triplicate electrode baseline for variance estimation, then set additional replication from measured pilot variance and a preregistered power calculation. Three replicates are not asserted to be sufficient for the isotope endpoint.

## Quantitative data and acquisition budget

No actual Cu18 isotope-pool values or acetate positional measurements are published in the 2025 paper. Do not substitute a guessed precursor enrichment. The following are the only direct numerical design anchors available from that primary source and elementary Faraday accounting.

For acetic acid/acetate, the source describes an eight-electron reduction per product molecule. Thus the charge-limited upper rate, even if every electron went to acetate, is

`ṅ_Ac,max/A = |j|/(8F)`.

At 10, 20, and 200 mA cm⁻², this gives 12.96, 25.91, and 259.11 nmol s⁻¹ cm⁻², respectively (0.777, 1.555, and 15.546 μmol min⁻¹ cm⁻²). These are strict charge upper bounds, **not** predicted acetate rates; the actual acetate FE is unpublished in the main text. If the smallest validated assay quantity is `n_min` and measured acetate FE is `φ_Ac`, required area-time is at least `A·t = 8 F n_min/(φ_Ac |j|)`. Until `n_min`, `φ_Ac`, time response, and acetate collection recovery are measured, the NMR sample size and number of repeated pulses remain `UNKNOWN`.

The total labeled feed consumed is `n(¹³CO₂) = q_gas · t · x_13` for molar flow `q_gas`, switch duration `t`, and certified isotope fraction `x_13`. The main article says gas/electrolyte flow was standardized but does not list the numerical flow rate there; retrieve the supporting information and verify it before ordering tracer gas. No cylinder quote, isotope-switch count, cell volume, DIC inventory, Raman/NMR acquisition time, electrode loading, replicate count beyond the source's triplicate performance bars, electrical energy, or staff/instrument cost is reported. Each remains `UNKNOWN`, not zero.

The explicit acquisition ledger is:

| Item | Required measured quantity | Cost/status |
|---|---|---|
| Raw source spectra/current data | Time-resolved Cu18 RRS and current/potential traces; request from corresponding author per data statement | Availability and staff time `UNKNOWN`; article does not deposit raw data |
| Catalyst | Cu-NWA plus Cu18 (about 2.5 nm 1-octadecanethiol layer), Cu6 control, foil–18 spectral control; batch characterization | Synthesis/loadings/time/price `UNKNOWN`; source has triplicate performance bars |
| Isotope feed and valves | ¹³CO₂ purity, ¹²/¹³ switch step response, leak/carryover, flow rates | Required amount `q_gas·t·x_13`; flow/pulse count/price `UNKNOWN` pending SI and pilot |
| Cell and electrolyte | 1 M KOH three-phase flow cell; active area, liquid volume, DIC inventory, temperature, iR, residence kernel | Source operation partly described; dimensions/volume/energy/runtime `UNKNOWN` |
| Raman | 785 nm RRS; time response and isotope shifts for CH₂, ketene, four CO states under coadsorption | Required calibration standards, beamtime and detection limits `UNKNOWN` |
| Electrochemistry | Synchronized high-bandwidth current/potential for −10→−20 mA cm⁻² step; capacitive blank and charge balance | Bandwidth needed is set by the measured response kernel; price/time `UNKNOWN` |
| Product analysis | Time-fractionated acetate; positional quantitative ¹³C NMR or validated alternative; all coproducts | `n_min`, recovery, sample number, NMR time, and price `UNKNOWN` |
| KIE nuisance check | Matched H₂O/D₂O pH/pD, conductivity, temperature, iR, label incorporation and measured coverages | Extra electrolyte/cell time/data and price `UNKNOWN`; omit from primary decision if not calibrated |
| Analysis/computation | Interval bounds, response-kernel fit, uncertainty propagation, power analysis | Script runtime negligible; calibration-data acquisition dominates. Parameter fit is not proof absent a valid bound |
| Carbon/energy/waste | CO₂ input/output, DIC and liquid carbon balance, integrated cell energy, KOH and copper-containing waste | Must be logged; amounts/energy `UNKNOWN` until the pilot measures them |

## Executable inference and status boundary

`certify_intervention.py` implements a fail-closed interval rule. It refuses to decide if the label-accessible CO bound is incomplete, a key nuisance field is absent, or the observation and budget are not reported in consistent molar units. Passing the dimer inequality rejects only the dimer-only topology. A second set of explicit flags is required before it returns support for CH₂ within a closed registered candidate network. `input_template.json` intentionally contains no fabricated measurements.

The computation is exact interval addition/comparison at the supplied precision. It does not estimate the pools, calibrate spectroscopy, infer missing barriers, or certify the physical validity of the bounds. Those are charged experimental inputs.

Verification performed: the Python file compiles; the intentionally empty template returns `UNKNOWN`; three abstract arithmetic branch checks pass (dimer-only exclusion without CH₂ attribution, conditional CH₂ support when all validation flags are supplied, and non-separation when the isotope budget overlaps). The small integer fixtures validate software control flow only and are not chemistry measurements or precursor probabilities.

## Claim status and next gate

- Source-reported: Cu18 operando signals/performance and Cu(100) modeled barrier values in Sun et al. (2025).
- Internally reconstructed: conditional equal-prefactor TST ratios and the charge-limited acetate rates above.
- Conditional theorem: if the measured lower product-label bound exceeds the complete upper bound on ¹³C that could visit active CO, the all-CO dimer hypothesis is impossible by carbon conservation.
- Unknown: whether Cu18 (or Cu–Fe) admits a window satisfying that condition; whether isotope-edited Raman can bound fast CO flux in the CH₂-coadsorbed state; whether the observed ketene signal is quantitatively product-connected; whether a different reduced C₁ intermediate supplies the label.
- Not claimed: a new catalyst, a demonstrated mechanistic resolution, external validation, or a new experimentally achieved capability.

The next gate is a no-product pilot that establishes (i) measured response kernels for feed/DIC/surface/product, (ii) isotope-calibrated CH₂ and all CO site states, (iii) complete upper bounds on label atoms that can enter reactive CO, and (iv) a nonempty time window where CH₂ label persists and that CO bound is smaller than the planned product-label detection limit. Failure of any item closes the topology assay and leaves the route unknown.

## Primary sources

1. Sun et al., “In Situ Observation of Post-CO Intermediates to Decode C–C Coupling Pathways in CO₂ Electroreduction,” *Angew. Chem. Int. Ed.* (2025), [DOI 10.1002/anie.202502740](https://doi.org/10.1002/anie.202502740), [open full text](https://onlinelibrary.wiley.com/doi/10.1002/anie.202502740). Primary source for Cu18, flow/Raman conditions, assignments, performance and DFT barrier comparison.
2. Pérez-Gallent et al., “Structure- and potential-dependent CO dimerization during CO reduction on copper electrodes,” *Angew. Chem. Int. Ed.* (2017), [DOI 10.1002/ange.201700580](https://doi.org/10.1002/ange.201700580). Primary FTIR evidence for hydrogenated CO dimer on Cu(100), with facet dependence.
3. Yang et al., *Science Advances* (2026), [DOI 10.1126/sciadv.aef9216](https://doi.org/10.1126/sciadv.aef9216). Primary CuBi isotope co-reduction result showing positional acetate preference can occur after dimerization under a different catalyst/feed regime.
4. Tomc et al., “Pulsed electrolysis controls copper restructuring via dissolution–redeposition to prolong selective CO₂ reduction to ethylene,” *J. CO₂ Utilization* 105 (2026), [DOI 10.1016/j.jcou.2026.103358](https://doi.org/10.1016/j.jcou.2026.103358). Current primary context: 23 h pulsed operation, dynamic restructuring, and ~30-fold increased dissolved Cu versus static operation; supports charging dissolution/material loss in any dynamic-catalysis follow-up.
5. Deng et al., “Copper-catalysed carbon monoxide electrolysis under dynamic operation,” *Nature Catalysis* (2026), [DOI 10.1038/s41929-026-01574-z](https://doi.org/10.1038/s41929-026-01574-z). Primary report of >750 h dynamic CO electrolysis with a controlled power-down potential and a TEA estimate up to 26% lower acetic-acid cost; this recently removed shutdown-stability bottleneck is already demonstrated and is not claimed as a cycle-7 discovery.
