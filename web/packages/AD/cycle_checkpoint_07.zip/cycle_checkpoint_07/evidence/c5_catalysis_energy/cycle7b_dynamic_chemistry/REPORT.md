# Cycle 7b: dynamic chemistry and molecular-hydrogen transfer

## Decision

No new catalytic capability or fundamental theorem is established in this cycle. The strongest new mechanism lead is the 2026 Cu(111) reaction-network result that adsorbed molecular H₂ can transfer H directly to oxygenated intermediates, competing with the usual atomic-H route. The published DFT barriers and the source model's own 500 K coverages imply a quantitative, falsifiable route-dominance criterion. It remains a **model-derived design lead**, not an experimentally established mechanism: the coverages are predicted, the experimental catalyst is Cu/SiO₂ rather than Cu(111), and the paper validates product trends rather than the proposed hydrogen-transfer event.

The dynamic-activation Cu/Al₂O₃ study reports a strong performance shift, but its impact-energy explanation does not close under its stated nanoscale geometry and atom count. A second resource issue is that its 0.34 W figure is the kinetic power carried by pressurized feed gas, not total reactor power. This is a negative physical/mechanistic window, not evidence that the measured activity/selectivity shift is false.

The prior no-pumping, equal-traffic, and cycle-space results in [the dynamic-catalysis reports](../chemistry_dynamic_catalysis/FINAL_REPORT.md) and [the network thermodynamics report](../chemistry_catalytic_thermodynamics/FINAL_REPORT.md) remain controls. Neither a generic Floquet optimum nor a thermodynamic-consistency projection is claimed as new here. In particular, pathway thermodynamic closure already has a recent, direct primary treatment by Zhang et al. (2025), discussed below.

## Lead A: a source-calibrated molecular-H₂ branch criterion

Verma et al. report 9,389 elementary reactions for CO₂ hydrogenation on Cu(111), generated from 105 adsorbates and a 152-reaction DFT dataset. The detailed preprint reports 304 directional activation barriers; its CatBoost activation-energy model has 0.13 eV test MAE, and the activation-free-energy model has 0.06 eV test MAE. The authors then explicitly recomputed four molecular-H₂ versus atomic-H hydrogenation barriers with DFT at 500 K. Their full automated model predicts a 500 K coverage of H₂* = 8.2708254×10⁻⁵ and H* = 0.3317565, so H₂*/H* = 2.4930412×10⁻⁴. The coverage row is in the public Materials Cloud source package, at `Source File/Main Figures/Fig 4/Fig 4c/Automated Reactions/500/coverage.dat`.

For two competing mean-field steps from the same adsorbed substrate (X^*), suppose

\[
r_{H_2}=\nu_{H_2}\theta_{X^*}\theta_{H_2^*}e^{-B_{H_2}/k_BT},\qquad
r_H=\nu_H\theta_{X^*}\theta_{H^*}e^{-B_H/k_BT}.
\]

Then, exactly within this two-channel TST model,

\[
\frac{r_{H_2}}{r_H}=\frac{\nu_{H_2}}{\nu_H}\frac{\theta_{H_2^*}}{\theta_{H^*}}
e^{(B_H-B_{H_2})/k_BT},
\quad
\frac{\theta_{H_2^*}}{\theta_{H^*}}>\frac{\nu_H}{\nu_{H_2}}e^{-(B_H-B_{H_2})/k_BT}
\ \Longleftrightarrow\ r_{H_2}>r_H.
\]

The crossover thresholds below assume equal effective prefactors, site molecularities, and common substrate coverage. The final column substitutes the source model's H₂*/H* ratio. These are internal calculations from source-reported DFT barriers and source-predicted coverages; they are not measured rate ratios.

| Hydrogenation step | DFT barrier via H₂* (eV) | via H* (eV) | Crossover H₂*/H* | Conditional molecular/atomic rate ratio |
|---|---:|---:|---:|---:|
| CO₂* → COOH* | 0.61 | 1.43 | 5.43×10⁻⁹ | 45,916 |
| CO₂* → HCOO* | 0.18 | 0.64 | 2.31×10⁻⁵ | 10.80 |
| HCOOH* → H₂COOH* | 0.54 | 0.91 | 1.86×10⁻⁴ | 1.34 |
| CH₃O* → CH₃OH* | 0.44 | 1.06 | 5.63×10⁻⁷ | 443 |

The useful mechanistic point is not that H₂* must dominate every step. The model predicts a very low H₂* occupancy, but the lower molecular-transfer barriers compensate for it strongly in three comparisons; the HCOOH* comparison is only marginal. This suggests a concrete design handle: increase molecular-H₂ availability or lower its transfer barrier at the oxygenated intermediates, while avoiding site blocking. It is a conditional prediction rather than a claim that stronger H₂ binding is always beneficial.

The equation is a direct TST rearrangement, not a new theorem. It is useful because it exposes what a design claim depends on: actual co-adsorbate ratio, the paired barrier difference, prefactor/site-order ratio, and measured substrate coverage. The 0.13 eV test MAE is not a per-reaction confidence bound. At 500 K, a 0.13 eV barrier shift changes a single TST rate by about 20.4×; opposite 0.13 eV errors in the two competing barriers change their ratio by about 418×. Therefore only the directly recomputed barrier pairs or calibrated uncertainty distributions can support the quantitative ratios above. The source's 0.06 eV mean error for the free-barrier regressor also must not be read as a hard interval.

### Strongest control and disconfirmation

The strongest control is already inside the source's network: it explicitly compares atomic-H routes against molecular-H₂ routes, then directly recomputes both barriers for the four listed steps. This is a better control than a handpicked H*-only mechanism. The experimental check is weaker: Cu/SiO₂ at 50 bar, H₂/CO₂ = 3, 483–523 K, and GHSV 7200 cm³ h⁻¹ g⁻¹ reproduces broad temperature/product trends, but the model is for Cu(111), and no isotope transient or operando H₂*/H* coverage was measured in the reported validation.

The design lead fails if the true catalyst's measured \(\theta_{H_2^*}/\theta_{H^*}\), paired barriers, and prefactor ratio place the molecular route below the crossover threshold. It also fails as an explanation of the observed product trend if H₂/D₂ transient data are fully explained by an atomic-H network with independently measured surface scrambling. A fair test would use a fixed 50 bar, 483–523 K Cu/SiO₂ flow experiment with rapid H₂↔D₂ steps, time-resolved product isotopologues by calibrated GC-MS, simultaneous H₂/HD/D₂ outlet analysis, and an operando surface probe capable of constraining molecular versus atomic adsorbed hydrogen. The strongest baseline is the same fitted network with both route classes present but with their hydrogen-transfer fluxes separately profiled under held-out pressure and isotope perturbations. No pulse duration, detection limit, catalyst batch, residence kernel, or instrument cost is invented here; these must be established in a pilot.

### Primary sources and prior art

- Verma et al., [“Data-driven massive reaction networks reveal mechanistic pathways underlying catalytic CO₂ hydrogenation,” *Nature Communications* (2026)](https://doi.org/10.1038/s41467-026-77080-4). The published article is current; the detailed numerical methods and barrier table were checked in the [ChemRxiv preprint](https://doi.org/10.26434/chemrxiv-2025-pnh6l).
- The accompanying primary data archive, [Materials Cloud 10.24435/materialscloud:94-1n](https://doi.org/10.24435/materialscloud:94-1n), includes the source figure files and geometries used for this reconstruction.
- Zhang et al., [“On the importance of thermodynamic consistency to DFT-based microkinetic analysis of complex heterogeneous reactions with multiple pathways,” *Chemical Engineering Science* 317 (2025), 122078](https://doi.org/10.1016/j.ces.2025.122078). It already uses independent pathway constraints to enforce consistency across complex networks. Cycle 7b does not advance that method.

## Lead B: dynamic Cu activation and the collision-energy audit

Zhang et al. report a purpose-built Cu/Al₂O₃ dynamic-activation reactor: 2.0 MPa, 300 °C, 3:1 H₂/CO₂, 360 mL min⁻¹, 0.1 mm nozzle, simulated gas speed about 452 m s⁻¹, and simulated particle impact speed about 75 m s⁻¹. At 40 wt% Cu the reported methanol STY is 660 mg gcat⁻¹ h⁻¹, compared with about 100 mg gcat⁻¹ h⁻¹ in a fixed bed; CO selectivity falls from about 60% to about 5%. The report has three independent performance measurements. It also reports a roughly 2 h active-state relaxation after reducing flow, post-reaction EXAFS changes, and a DFT energy increase of about 0.17 eV per Cu atom for the selected “discrete condensed” structure.

The 0.34 W input-power value can be reconstructed if 360 mL min⁻¹ is interpreted as standard volumetric flow at 22.414 L mol⁻¹. For a 3:1 H₂/CO₂ mixture, the mean molecular mass is 12.514 g mol⁻¹, giving mass flow 3.350×10⁻⁶ kg s⁻¹; \(\tfrac12\dot m(452\,\mathrm{m\,s^{-1}})^2=0.342\) W. This reproduces the reported number. Under that same conditional flow basis, a reversible isothermal ideal-gas compression from 1 to 20 bar at 298.15 K requires about 1.99 W, and heating the feed from 298 to 573 K requires roughly 2.28 W using ideal-gas heat capacities. These are plant-boundary estimates, not measured device power. The nozzle kinetic power comes from the pressurized gas stream, so adding 0.34 W on top of compression as a separate actuator would double count it. Actual compressor power, reactor pressure drop, heat recovery, the 3 s air-hammer consumption, recycle/separation, and catalyst attrition were not reported and remain `UNKNOWN`.

The reported STYs correspond to 5.72 μmol s⁻¹ gcat⁻¹ (DAR) and 0.867 μmol s⁻¹ gcat⁻¹ (FBR). Dividing the reconstructed 0.342 W gas-kinetic power by these rates gives 59.8 kJ per DAR mol methanol, or 70.5 kJ per incremental mol over the FBR baseline. Those are kinetic-stream energy scales, not extra electrical duties: the kinetic energy is a portion of the compressed-feed energy. With identical GHSV, the compressor and feed-heating duties per gram catalyst are common to both reactors in this idealized comparison. Whether the real dynamic device improves total energy per mole depends on the unreported pressure-drop and power data.

### A load-bearing arithmetic mismatch in the stated microscopic energy argument

The supplementary information estimates impact energy using a cylindrical 20 nm diameter × 100 nm length Cu-loaded alumina particle, density 4 g cm⁻³, 40 wt% Cu, and 75 m s⁻¹, then states that the particle contains about 13,000 Cu atoms. Direct mass/atom accounting from those same dimensions gives

\[
V=\pi(10\,\mathrm{nm})^2(100\,\mathrm{nm})=3.1416\times10^{-17}\,\mathrm{cm}^3,
\]
\[
N_{Cu}=\frac{0.4(4\,\mathrm{g\,cm^{-3}})V}{63.546\,\mathrm{g\,mol^{-1}}}N_A
\approx 4.76\times10^5,
\]

which is 36.6 times the reported 13,000. The same SI gives particle kinetic energy as 3.5×10⁻¹⁶ J but converts it to about 1,840 eV; the stated joules convert to about 2,185 eV, and the exact cylinder calculation gives about 2,206 eV. This smaller joule/eV discrepancy does not drive the conclusion.

Using the SI's own assumptions that one-half of the source-reported 1,840 eV is absorbed and one-third of Cu atoms are affected gives

\[
\frac{0.5\times1840\ \mathrm{eV}}{(4.76\times10^5)/3}
\approx 0.0058\ \mathrm{eV\ per\ affected\ Cu},
\]

about 29 times below the 0.17 eV per-atom DFT structural energy. Using the exact cylinder kinetic energy gives 0.00695 eV per affected Cu, about 24 times below. To reach 0.17 eV per affected atom with half the source-reported particle energy, at most about 5,412 Cu atoms can receive that energy, i.e. about 1.14% of the geometry-derived Cu count, rather than the assumed one-third. A 100 nm-long cylinder would need diameter about 3.3 nm (not 20 nm) to reproduce 13,000 Cu atoms at the stated density and loading.

This is a **conditional reconstruction of the SI arithmetic**, not a refutation of observed catalysis. The actual impacting powder is measured near 100 μm; the nanorod is an assumed representative energy-transfer unit, and impact energy may localize into a much smaller number of surface atoms. But that localization is precisely the missing measurement/model. Further, 0.17 eV/atom is a DFT total-energy difference on a selected optimized structure, not an experimentally measured free energy of the working catalyst. The paper's structural and catalytic observations remain source-reported; the calculated “enough energy per atom” explanation is not established by the stated numbers.

The leading falsifier is a size- and impact-velocity-resolved experiment with measured particle mass/velocity distributions and operando structure during collisions, paired with a mechanically matched control that supplies the same gas flow and pressure without target impact. The catalyst's real pressure drop and compressor electricity must be logged. If the change in Cu coordination and product distribution persists without impacts, the collision mechanism is disconfirmed; if only the impacted state shifts and a measured energy-deposition model closes the Cu atom budget, the mechanism strengthens. Required impact-frequency, powder-size, XAS time resolution, air-hammer duty, pressure-drop, catalyst-loss, and calorimetry costs are not in the paper and remain `UNKNOWN`.

Primary sources:

- Zhang et al., [“Dynamic activation catalysts for CO₂ hydrogenation,” *Nature Communications* 16, 9349 (2025)](https://doi.org/10.1038/s41467-025-64417-8), especially the [Supporting Information](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41467-025-64417-8/MediaObjects/41467_2025_64417_MOESM1_ESM.pdf).
- The source reports the same GHSV in the DAR and fixed-bed comparison but uses different reactor geometries and 1 g versus 0.2 g catalyst loading. It also reports that 20 wt% Cu shows little DAR/FBR difference, an important negative material control. These support an operating-mode effect but do not calibrate impact energy deposited per active Cu site.

## Resource, uncertainty, and claim ledger

- **Acquired evidence:** downloaded the public Materials Cloud `Source File.zip` (174,098,659 bytes; MD5 `cf3980b3c9435ef96fbed4a4b1a57124`), `reactions.zip` (833,647 bytes; MD5 `b85d372a68d599606e29f97b8c4938e0`), and `gas-phase.zip` (17,375 bytes; MD5 `040d0c45dc70e71ccfa07652837b8f78`). The working copy is under `raw/`. The archive itself reports about 416 MB uncompressed. Public data acquisition only; no DFT calculation, high-performance compute job, or experiment was run by this cycle.
- **Computation performed:** standard-library Python reconstructs the 500 K coverages, the four conditional TST ratios, ideal compression/heating scales, and the SI particle-energy/atom-count discrepancy. It runs in under one second locally. It is not a microkinetic solver and does not validate source kinetics or physical energy transfer.
- **DFT/MKM costs:** Verma et al. estimate roughly 10,000 CPU core-hours per explicit transition-state calculation in their preprint. That is a source estimate for future barrier acquisition, not work performed here. A realistic-support isotope mechanism study would require new validated barrier and frequency calculations; number and cost are `UNKNOWN` until the model surface and transition-state list are fixed.
- **Experimental costs:** the cited 2026 network paper reports fixed-bed experiments at 50 bar and the 2025 dynamic-activation paper reports 2 MPa and 300 °C. Labeled-gas consumption, catalyst synthesis, reactor time, GC-MS/XAS/IR time, compressor/heater/hammer energy, sample recovery, staff, and instrument prices were not reported for the proposed tests and remain `UNKNOWN`.
- **Status:** source-reported (publication); internally reconstructed (arithmetic); conditional (TST route ratios and collision energy budget); unresolved (in-operando molecular/atomic hydrogen state; Cu particle impact-energy localization; whole-reactor energy advantage); not claimed (new catalyst, new theorem, validated mechanism, or external novelty).

## Verification

`python3 source_calcs.py` ran successfully against the downloaded source archive. It reproduces the reported gas-jet power (0.342 W versus the paper's ~0.34 W), extracts the exact 500 K H₂*/H* coverage ratio, and independently recalculates all reported ratios and the particle atom count. The verification confirms the calculations and source-data extraction only; it does not establish the physical assumptions or the underlying mechanisms.
