# Conditional calculations and their premises

This file records the load-bearing derivations used in `REPORT.md`. None is presented as a new mathematical theorem or as external experimental validation.

## 1. Molecular-H₂ versus atomic-H branch condition

Let both candidate surface reactions consume the same substrate (X^*), with mean-field rates

\[
r_{H_2}=\nu_{H_2}\theta_{X^*}\theta_{H_2^*}
\exp\!\left(-\frac{B_{H_2}}{k_BT}\right),
\qquad
r_H=\nu_H\theta_{X^*}\theta_{H^*}
\exp\!\left(-\frac{B_H}{k_BT}\right).
\]

For positive coverages, divide the first rate by the second and cancel the common substrate term:

\[
\frac{r_{H_2}}{r_H}
=\frac{\nu_{H_2}}{\nu_H}
\frac{\theta_{H_2^*}}{\theta_{H^*}}
\exp\!\left(\frac{B_H-B_{H_2}}{k_BT}\right).
\]

Since the exponential is positive, (r_{H_2}>r_H) if and only if

\[
\boxed{\frac{\theta_{H_2^*}}{\theta_{H^*}}
>\frac{\nu_H}{\nu_{H_2}}
\exp\!\left(-\frac{B_H-B_{H_2}}{k_BT}\right).}
\]

At (T=500\,\mathrm K), (k_BT=0.0430866663\,\mathrm{eV}). The Materials Cloud MKM output at 500 K gives \(\theta_{H_2^*}=8.2708254\times10^{-5}\), \(\theta_{H^*}=0.3317565\), and ratio \(2.4930412\times10^{-4}\). The four source-reported DFT barrier pairs give equal-prefactor crossover thresholds (5.4295\times10^{-9}\), (2.3089\times10^{-5}\), (1.8645\times10^{-4}\), and (5.6322\times10^{-7}\); dividing the source coverage ratio by these thresholds yields (45916.2, 10.7976, 1.3371, 442.644).

**Scope.** The equation assumes effective first-order dependence on each co-reactant coverage, common substrate coverage, and comparable site molecularities. A prefactor ratio multiplies the rate ratio. Coverages above are model-predicted, not measured. The barrier values are calculations on Cu(111); no barrier for a different catalyst/support has been assigned.

## 2. DAR kinetic-power reconstruction and atom budget

### 2.1 Gas kinetic power

Conditionally interpret the reported 360 mL min(^{-1}) as standard flow at molar volume (22.414\,\mathrm{L\,mol^{-1}}). Then

\[
\dot n=\frac{0.360\,\mathrm{L\,min^{-1}}}{22.414\,\mathrm{L\,mol^{-1}}\times60}
=2.67690\times10^{-4}\,\mathrm{mol\,s^{-1}}.
\]

For a 3:1 H₂/CO₂ feed,

\[
\bar M=\frac{3(2.01588)+44.0095}{4}\,\mathrm{g\,mol^{-1}}
=12.5143\,\mathrm{g\,mol^{-1}}.
\]

Thus \(\dot m=3.34995\times10^{-6}\,\mathrm{kg\,s^{-1}}\). At the source's simulated 452 m s(^{-1}) gas speed,

\[
P_K=\tfrac12\dot m v^2=0.34220\,\mathrm W,
\]

reproducing the reported ∼0.34 W. The source does not explicitly state the volumetric reference conditions in the main text; this standard-flow basis is inferred because it reproduces the reported power.

The corresponding reversible isothermal ideal-gas compression work from 1 to 20 bar at 298.15 K is

\[
P_{\mathrm{comp,min}}=\dot nRT\ln(20)=1.98794\,\mathrm W.
\]

For an ideal-gas mixture heat capacity \(C_p=(3C_{p,H_2}+C_{p,CO_2})/4\) using 28.836 and 37.135 J mol(^{-1}) K(^{-1}), the sensible heating duty from 298.15 to 573.15 K is

\[
\dot Q=\dot n C_p\Delta T=2.27549\,\mathrm W.
\]

These are conditional lower-order process scales, not measured electrical draws. Because jet kinetic power is supplied by pressurized flow, it is not added independently to compression work.

### 2.2 Cu atoms in the SI's stated cylinder

The supplementary energy calculation describes diameter 20 nm, length 100 nm, density 4 g cm(^{-3}), and 40 wt% Cu. With (1\,\mathrm{nm}=10^{-7}\,\mathrm{cm}),

\[
V=\pi(10\,\mathrm{nm})^2(100\,\mathrm{nm})
=31415.93\,\mathrm{nm^3}
=3.14159\times10^{-17}\,\mathrm{cm^3}.
\]

The particle mass is (4V=1.25664\times10^{-16}\,\mathrm g). Its Cu mass is (0.4(4V)=5.02655\times10^{-17}\,\mathrm g). Therefore

\[
N_{Cu}=\frac{5.02655\times10^{-17}\,\mathrm g}{63.546\,\mathrm{g\,mol^{-1}}}
(6.02214076\times10^{23}\,\mathrm{mol^{-1}})
=4.76357\times10^5.
\]

The SI's ∼13,000-atom estimate is smaller by a factor of 36.6428 under the printed geometry/composition/density.

The SI states approximately 1,840 eV per such particle, half absorbed, and one-third of Cu atoms affected. On those assumptions and the geometry-derived atom count, energy delivered per affected atom is

\[
\frac{0.5(1840\,\mathrm{eV})}{(4.76357\times10^5)/3}
=0.005794\,\mathrm{eV\,Cu^{-1}}.
\]

The stated 0.17 eV Cu(^{-1}) DFT structural energy is about 29.3 times larger. Using the SI's stated cylinder and density in the kinetic-energy equation at 75 m s(^{-1}) gives 2,205.93 eV rather than the text's 1,840 eV; even that larger value gives only 0.006946 eV per affected Cu, about 24.5 times below 0.17 eV. To supply 0.17 eV to each affected atom with half of 1,840 eV, no more than 5,411.8 atoms may be affected, i.e. 1.136% of the geometry-derived Cu count. This arithmetic flags an inconsistency in the printed sufficiency argument. It does **not** account for impact-energy localization, and 0.17 eV per atom is a DFT structural total-energy difference, not a measured working-state free energy.

## 3. Barrier-error amplification

At 500 K, changing one TST barrier by 0.13 eV scales its rate by

\[
\exp\!\left(\frac{0.13}{0.0430866663}\right)=20.43.
\]

If two competing barriers shift in opposite directions by 0.13 eV, their predicted rate ratio scales by

\[
\exp\!\left(\frac{0.26}{0.0430866663}\right)=417.53.
\]

This is an exponential-sensitivity calculation only. A held-out-set MAE does not imply a ±0.13 eV error bound for each predicted reaction and does not give a posterior interval for a selected pathway.
