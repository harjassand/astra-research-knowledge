# Cu–Fe acetate atom mapping: unresolved and not identified by product labels alone

The earlier ideal atom-map proposal has been adversarially revised. The `0.2/0.8` example in [isotopomer_model.py](isotopomer_model.py) is an invented arithmetic fixture; it is not based on measured Cu–Fe precursor pools and does not establish that positional isotope analysis separates the actual routes.

The source graph in Fig. 2 of the inspected Cu–Fe preprint displays both `*CO + *CO` and `*CHO + *CO` coupling branches to shared `HCCO*`, followed by ketene. The abstract/discussion also assert a separate `*CO + *CH2` route to ketene, but the displayed graph does not show that C–C edge. No machine-readable atom-map or source-specific pool enrichment resolves the discrepancy.

For independent effective precursor pools, let `pM` and `pC` be the 13C fractions at product methyl and carboxyl positions. The product ratio is

`R = P(12M,13C) / P(13M,12C) = [(1-pM) pC] / [pM (1-pC)]`.

For direct coupling, these can be effective CH2 and CO enrichments. For a fixed-orientation CO-dimer route, they can be site-A and site-B CO enrichments. Therefore the same `R`, including `R > 1`, is attainable under both. Yang et al. 2026 report exactly such a positional preference while proposing post-dimer asymmetric hydrogenation on CuBi; this is a different catalyst and does not establish the Cu–Fe mechanism.

More strongly, there is an exact product-law overlap. For arbitrary time-varying effective enrichments `pCH2(t), pCO(t)`, set `pA(t)=pCH2(t)`, `pB(t)=pCO(t)`, and let A become methyl. The direct and dimer models then have identical probabilities for all four positional isotopomers at every time. If all pools equilibrate to one enrichment, equality holds for every dimer orientation probability. Common reversible exchange, isotope effects, and downstream product/detector kernels can be folded into the effective pools and preserve this overlap. This proves an intersection, not equality of the full physical attainable sets.

The exact algebraic check is [transient_identifiability.py](transient_identifiability.py), and the source reconstruction, SSITKA caveats, and discriminating intermediate-observation design are in [TRANSIENT_IDENTIFIABILITY.md](TRANSIENT_IDENTIFIABILITY.md). Product position alone is not a decisive topology test unless pool histories, exchange, KIEs, and orientation are independently constrained. A potentially decisive experiment must also observe and kinetically connect a route-specific intermediate such as the proposed CO–CH2/ketene branch versus hydrogenated CO dimer OCCOH on the actual Cu–Fe catalyst.
