# Source-data and observable map

## Provenance

The primary source is Dang et al., [“Self-propagating wave drives morphogenesis of skull bones in vivo”](https://doi.org/10.1038/s41467-025-59164-9), including the article’s [Methods and source-data statement](https://pmc.ncbi.nlm.nih.gov/articles/PMC12064835/). The authors’ code is pinned at [SkullWave commit `b2cbb61097cdc25bfff1e0a89ba690a31c2a4adc`](https://github.com/YitengDang/SkullWave/tree/b2cbb61097cdc25bfff1e0a89ba690a31c2a4adc).

The official source workbook is `work/agents/c8_morphogenesis_control/cycle9/deeper_attack/source_data/41467_2025_59164_MOESM10_ESM.xlsx`, 2,841,401 bytes, SHA-256 `80adcdbffca3162a21a75186e298c44c1c14226ac941867886d5dd3a8e915f45`. It has 25 visible worksheets; a complete structural inventory (sheet extent, nonempty-cell/row counts, formats, formulas, and sample values) is [source_workbook_map.json](source_workbook_map.json). No workbook cells were edited or exported. The read-only analysis script rechecks the hash before each run.

Companion author-repository files used here:

| File | SHA-256 | Contents used |
|---|---|---|
| `Velocities_all_videos.csv` | `cc08c35712b82fc99aeb9cf62ef64f76b43d03b015cd4e7d51b536c77455ba0c` | 366 per-cell velocity magnitudes with video/location, start coordinate, and time-index fields |
| `data_ex_vivo_tracked_cells_all.csv` | `d0d0e4143477f11fb49b98faa84c5a76d238561764ff07838df3ea2def52fbdb` | Four-dataset, three-location time series of mean signed x displacement, SEM and SD |
| `data_ex_vivo_videos_1_to_4_all_interfaces.csv` | `2228c179882d3658ca30efafaeb421efdf89bccc179d3e9431eedf58e653eecc` | Four ex-vivo interface-height trajectories |

The companion source [R Markdown](../c8_morphogenesis_control/cycle9/deeper_attack/source_refs/plot_results_with_data.Rmd) assigns model cell starts at x = 0, −200, and −400 μm, labels the measured x displacement in micrometres, and uses hours for time. Its Fig. 3C code directly overlays the measured `Velocity` column against the simulated `V` profile at the first output time. Article Methods define measured cell speed as the magnitude of a two-dimensional endpoint displacement divided by six hours. The direct overlay is the source’s comparison convention; it does not by itself establish identity between a nonnegative 2D speed norm and signed 1D Eulerian tissue velocity.

For that plot, `Time=1` is the first stored simulation column: the Rmd maps table indices 1, 51, 101 to 0, 3, 6 h in its profile export. Thus the Fig. 3C velocity overlay uses the model's initial instantaneous field, while the measured values summarize six-hour endpoint displacement. This is a temporal as well as directional observable-map assumption.

## Workbook grain and units

| Sheet and source range | Grain / what the values represent | Unit and provenance boundary |
|---|---|---|
| `Fig1H!A1:F14263` | Title row 1; field definitions A3:B8; header row 11; 14,252 records in rows 12:14263. There are 455 unique cell tracks across four videos and three locations; time indices 0–36, one frame every 10 min. | The sheet calls X and Y positions but supplies no spatial unit or scale factor. These coordinates are not converted into model micrometres here. |
| `Fig1I!A3:E93` | Mean-squared displacement by time and location, averaged over four images; MSD and SEM. | Axis labels indicate squared displacement, but workbook fields do not state the physical scale calibration. |
| `Fig2A!A1:ALL2226` | Ex-vivo osteogenic-front coordinates and cell-track records across videos/time; metadata describes positions relative to advancing Y. | Raw sheet coordinates are not used as physical lengths in this lane. |
| `Fig2B!A1:G192` | Rows 5:41 give tracked-cell relative displacement by video/timepoint, its four-video mean and SEM (title reports (N=4,n=199)); rows 45:192 contain per-video interface-height records and normalized heights. Relative displacement is normalized by the interface’s 6 h displacement. | Dimensionless normalized values; timepoint index 0–36. This sheet does not provide a minutes-per-index field. |
| `Fig2C!A1:E6` | One front and one tracked-cell expansion-rate value for each of four datasets. | The displayed panel is a rate comparison, but the workbook column labels do not state units; do not infer a unit from the bare cells. |
| `Fig2D!A1:EEW41` | Profile header row 4; 37 rows (time index 0–36) of mean GFP intensity over 3,532 spatial samples. | Axis metadata says pixel values; intensity is fluorescence. The workbook provides neither pixel-to-μm nor fluorescence-to-φ calibration. Its profile is not a directly measured model fraction φ or physical tail exponent. |
| `Fig3B!A1:H889` | Metadata rows 1:10, blank row 11, header row 12, and 877 records rows 13:889. Data include four-dataset cell-displacement means, a simulated front-origin cell path, ex-vivo interface series, an in-vivo size proxy and a simulated front line. | Rmd labels time in hours and x displacement in micrometres. In its final plot export, the experimental cell series pools locations while the model cell curve retained is only the `Bone Front` track; this is a plotting comparison, not a three-location held-out test. |
| `Fig3C!A1:E147` | Measured cell-speed summaries are rows 9:11 at front, about 208 μm in bone, and about 400 μm in bone. Row 14 is the simulated-profile header; rows 15:147 are the profile. | Article Methods: measured speed is the 2D endpoint-displacement norm divided by six hours. Raw CSV counts are front 171, in-bone 86, further-in-bone 109; their cell-level SDs are not between-video uncertainty. Model V is a signed 1D Eulerian field. |
| `Fig3D!A1:C402` | Simulated φ profile at three model times. | Model output, not an experimental profile. |
| `FigS4!A1:CNX80` | Ex-vivo front-interface positions over time in image coordinates. | Pixel-coordinate source values; not used for physical-speed fitting here. |

Other workbook sheets: `Fig1C A1:L124`, `Fig1K A1:I164`, `Fig1L A1:F876`, `Fig1M A1:F4`, `Fig1P A1:L594`, `Fig4H A1:F105`, `Fig4I A1:L139`, `Fig4L A1:K55`, `Fig4M A1:G104`, `Fig4N A1:E8`, `FigS1CD A1:AF9`, `FigS2A A1:C19`, `FigS2D A1:H47`, `FigS2F A1:Y28`, and `FigS3C A1:E12`. They are fully inventoried but not reanalyzed in this lane.

## Experimental observable used for the conditional comparison

`data_ex_vivo_tracked_cells_all.csv` contains one mean x-displacement curve for each dataset and each of three locations, sampled from 0–6 h. At 6 h, the four independent dataset means (in μm) are:

| Location | Dataset 170902 | 190305 | 190314 | 200120 | Mean | Between-dataset SD |
|---|---:|---:|---:|---:|---:|---:|
| Bone front | 82.55 | 34.43 | 47.05 | 31.74 | 48.94 | 23.38 |
| In bone | 74.47 | 36.34 | 45.57 | 33.55 | 47.48 | 18.71 |
| Further in bone | 43.66 | 27.82 | 35.18 | 30.99 | 34.41 | 6.86 |

These are four video-level/location means; repeated time rows and individual cell counts were not treated as independent replicates. The SD is between datasets, unlike the per-cell SD shown for the Fig. 3C speed magnitudes.
