# Failures, boundaries, and restart gates

## What the source files do not settle

- **GFP to phenotype fraction:** `Fig2D!A1:EEW41` contains intensity profiles on a pixel axis. The workbook has no pixel-to-μm or GFP-intensity-to-phi calibration. The article says GFP profiles enter its fit; this lane has not reconstructed the author's transformation.
- **Cell velocity to PDE field:** Fig. 3C speeds are two-dimensional endpoint norms over six hours. The source Rmd overlays them with the first model V slice (initial time). This assumes an unreported frame/direction/time map when interpreted as a quantitative field match. Do not re-use these values as signed V without a justified operator.
- **Cell-marker flux:** `v_B=V-D*phi_x/phi` follows from the phenotype PDE's conservative form. Its use for observed tracked nuclei assumes that the labeled population is the B-species flux represented by phi; no direct validation of this marker-to-flux identity was performed.
- **Small independent sample:** the 6 h trajectory comparison has four video/dataset means. The projected Student-t interval is descriptive and conditional; it omits measurement-model uncertainty and parameter fitting. It is not an independent validation because it reuses the source data and a chosen model pair.
- **Specific pair versus global identification:** the source curves discriminate the existing speed-alias pair under one explicit mapping. No broad likelihood/profile over `(a_rho, a_phi, alpha)` was fit. A tail family wider than `a_rho=a_phi` could change the conclusion.
- **Alpha units:** the previously documented SI/table and notebook units ambiguity is unchanged; see c8/c9. This lane does not resolve or restate the SI equation audit.
- **Scope:** no raw image or movie reanalysis, external experiment, wet lab, expert communication, publication, novelty check, or source-author communication was performed.

## Gates to close before claiming identified alpha/tail

1. Recover the exact authors' transformation from GFP intensity and pixel coordinates to the model's physical phi profile, including background, scale, alignment, and any parameter calibration. If unavailable, keep q0 in pixels and label physical q0 `UNKNOWN`.
2. State the actual observable map for tracked nuclei. Compare signed x displacement, 2D speed norm, model tissue V, and conditional B-species velocity on the same time window and in the same frame; do not mix them.
3. Fit the source data with video as the independent unit and a declared error/covariance model. Keep the four datasets together across locations; do not count 37 time rows or hundreds of cells as independent biological replicates.
4. Profile alpha jointly with plausible initial density/fraction steepnesses and the source-supported constraints. Report profile likelihood/identified sets, sensitivity to alpha units and viscosity alternatives, and a held-out condition only if one exists.
5. Preserve the currently discriminating two-pair projection as an in-sample diagnostic, not a holdout. A new prediction needs a predeclared condition and independently acquired matched profile, front, and material/cell trajectory observables.

## Prior scoped results carried forward, not re-audited

- c8 reproduces pinned source arrays and supplies the high-resolution speed-only pair and grid/time convergence.
- c9 independently records SI factor/sign/unit issues and its corrected claim scope.
- Prior backward-front/scalar-comparator claim was retracted because unmatched estimands confounded tissue flow. Do not revive it.
- Extremely steep negative relative-motion values are grid/window/cell-scale sensitive and do not define a robust threshold.

