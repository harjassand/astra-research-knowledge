# C12 session record

## Current state

Completed a read-only source workbook inventory and a conditional empirical observable check of the previously documented full-PDE speed alias. The most decisive result is that the four-video location-separated signed x-displacement data distinguish that *named* pair under the conditional phenotype-marker transport map, even though the two model front secants match. The global alpha/tail identification gate remains `UNKNOWN`.

## Artifacts

- `inspect_source_workbook.py` — read-only structural inventory; source SHA in output.
- `source_workbook_map.json` — 25-sheet extents, row/cell/formula/format counts and representative values.
- `analyze_observable_interface.py` — read-only raw workbook/CSV summaries; serial `Nx=800,Nt=3200` replay of both alias pairs; species-velocity characteristics; paired four-video projection.
- `observable_interface_results.json` — source hashes, per-video/per-location means, model outputs, and conditional comparison.
- `SOURCE_MAP.md` — source DOI/code pin, sheet/range/units/grain/provenance map.
- `PROOF.md` — conservative marker-velocity derivation and named-pair comparison.
- `CLAIMS.json` — scoped claims and status.
- `FAILURES_AND_GATES.md` — unresolved observables, statistical boundaries, and restart requirements.
- `FINAL_REPORT.md` — compact finding.

## Reproducibility and cost

The workbook's SHA-256 was `80adcdbffca3162a21a75186e298c44c1c14226ac941867886d5dd3a8e915f45` before and after read-only analysis. The official 2.7 MB workbook was read with `openpyxl` in read-only mode. The companion CSV hashes are in `SOURCE_MAP.md` and the JSON results. The PDE analysis reuses `work/agents/c8_morphogenesis_control/cycle9/deeper_attack/replay_coupled_fd.py`; each `Nx=800,Nt=3200` run was sequential, with roughly 62 MB for three saved double-precision fields per case. The prior `Nx=3200,Nt=25600` alias is referenced from c8 rather than rerun here.

Runtime: bundled workspace Python 3.12.14, NumPy 2.3.5, openpyxl 3.1.5; SciPy is not installed and was not required. The analysis script completed in about 1.5 s; both Python files passed `py_compile`. No external message, publication, experiment, or raw-media reanalysis occurred.

## Instruction resources

The parent task's spreadsheet requirements were followed: full `spreadsheets/SKILL.md`, `references/read_only_qna.md`, `domain_guidance/scientific_research.md`, `style_guidelines.md`, and `artifact_tool_docs/API_QUICK_START.md` were read from `/Users/harjas/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1007.11041/skills/`. `mcp__codex_app__load_workspace_dependencies` identified the bundled Python runtime. The workbook was never edited, resaved, or exported.

## Exact restart point

Do not repeat the c8 SI/unit or c9 hostile derivations. To advance alpha/tail identification, first reconstruct the authors' actual GFP-to-phi and pixel-to-physical-coordinate observation operator and define the tracked-cell-to-model-flux operator. Then fit/profile the joint source observables with video as the independent unit and an explicit covariance model, holding out a condition only if the source provides one. Preserve the current two-pair trajectory projection as an in-sample diagnostic, not validation. Keep alpha units and source eta discrepancy as open sensitivity gates from prior work.

