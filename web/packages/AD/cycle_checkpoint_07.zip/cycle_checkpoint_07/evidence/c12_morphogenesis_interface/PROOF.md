# Observable interface and named-alias test

## Question and scope

The earlier full-PDE pair matches the same finite-time front speed while changing both the assumed tanh profile steepness and alpha. This lane asks whether the *released non-speed observations* can distinguish that specific pair under an explicit model-to-measurement map. It does not repeat the SI derivation audit, claim that the authors' joint fit is wrong, or estimate a global confidence interval for alpha.

The calculations replay the pinned finite-difference PDE with the existing independent NumPy transcription, then compare its 0–6 h marker paths against the source's four-video x-displacement summaries at the three locations used by the model. The released workbook and CSVs remain read-only.

## A model-implied marker velocity

The phenotype equation in the pinned model has the form

```text
phi_t + V phi_x = D * (phi_xx + (rho_x/rho) phi_x) + R_phi.
```

Multiplying by rho rewrites the diffusion term as `D * (rho * phi_x)_x`. Thus the differentiated-species density `rho_B = rho * phi` has transport flux `rho * phi * V - D * rho * phi_x`, plus reaction/conversion sources. If that species is what the tracked-cell marker represents, its conditional 1D material velocity is

```text
v_B = V - D * phi_x / phi       (phi > 0).
```

This map follows from the PDE's conservative form; the biological assignment of tracked nuclei to this flux remains conditional. At the three source model starts, `v_B` and V are close for the released run, but the quantity measured by the velocity table is still a 2D norm averaged over six hours, not this instantaneous signed 1D field.

## Forward comparison

Two parameter pairs were replayed serially at `Nx=800, Nt=3200`, `dx=3.75 μm`, `dt=0.0025 h`:

| Pair | `a_rho=a_phi` | alpha | `phi=0.5` 0–8 h secant |
|---|---:|---:|---:|
| Released baseline | 4 | `3.5e-6` | 21.77463 μm/h |
| Existing speed alias | 8 | `1.934e-6` | 21.77482 μm/h |

The fine-grid c8 result remains the reference for the established speed match (`21.77502` vs `21.77423 μm/h` at `Nx=3200, Nt=25600`). The current `Nx=800` replay is used to generate marker paths, not to revise that convergence result.

Using the conditional B-species velocity above, the deterministic 0–6 h displacement from each model start is:

| Initial location | Source x start | Released prediction | Speed-alias prediction | Alias minus released |
|---|---:|---:|---:|---:|
| Bone front | 0 μm | 65.20 μm | 110.90 μm | +45.70 μm |
| In bone | −200 μm | 47.16 μm | 51.26 μm | +4.11 μm |
| Further in bone | −400 μm | 25.65 μm | 14.12 μm | −11.53 μm |

The source companion `data_ex_vivo_tracked_cells_all.csv` contains four dataset-level x-displacement curves per location, in micrometres over 0–6 h. At 6 h their means are `48.94`, `47.48`, and `34.41 μm` at the same three locations, with between-dataset SDs `23.38`, `18.71`, and `6.86 μm`. The independent unit is four videos/datasets; time rows and cell counts are not treated as independent replicates. The released prediction falls inside each location's descriptive t interval for the four-video mean; the named alias prediction is outside the front and further-in-bone intervals but inside the in-bone interval.

To keep the repeated locations paired within video, a single contrast was formed along the model-predicted difference vector. Let `m0` and `m1` be the three-location displacement vectors above, and `u=(m1-m0)/||m1-m0||`. Projecting each video's three displacement means onto `u` gives scores `75.57, 29.64, 40.84, 26.02 μm`; mean `43.02 μm`, between-video SD `22.60 μm`. A descriptive Student-t interval with 3 degrees of freedom is `[7.06, 78.98] μm`. The released and alias model projections are `60.83 μm` and `108.14 μm`. Under this explicit mapping and this named contrast, the current four-video data separate this particular speed-matched pair in-sample: the interval includes the released pair's projection and excludes the speed alias. The model outputs are deterministic and the interval does not cover model, mapping, or parameter uncertainty; this is not an independent holdout or a general alpha-identifiability theorem.

The front-only prediction is close to the author's exported `cells.sim` curve in `Fig3B` (65.20 μm from the conditional marker flux versus 65.06 μm at 6 h in the source export). That agreement checks the baseline trajectory scale. The source Rmd's final Fig. 3B plotting table pools experimental cell locations but retains only the model's `Bone Front` path, so the three-location contrast above is a new conditional comparison over the source curves, not the published panel's exact plotted estimand.

## What the source profile and velocity sheets identify

The official workbook has `Fig2D!A1:EEW41`: 37 time-indexed mean GFP intensity profiles over 3,532 pixel positions. Its axis is explicitly in pixels; the workbook does not supply pixel-to-micrometre calibration or an intensity-to-`phi` calibration. The profile can constrain the fluorescence shape after an observation model is specified, but the workbook values alone are not a physical `phi` tail exponent `q0=2*a_phi/L`. The authors describe using GFP intensity profiles in their joint parameter fitting, so this finding is a limit on our independent reconstruction from this data file, not a criticism of that fit.

The `Fig3C` workbook and `Velocities_all_videos.csv` report means `13.169`, `12.565`, and `9.077 μm/h` at front, in-bone, and further-in-bone locations. The raw CSV has 171, 86, and 109 cells respectively, nested within four videos; within-cell SDs are about 4 μm/h. The article's Methods define each value as a 2D endpoint-displacement norm divided by six hours. At the three nominal positions, the released model's initial V values are `11.918`, `9.392`, and `4.713 μm/h`; the speed-alias pair gives `23.832`, `9.575`, and `1.362 μm/h`. The companion Rmd overlays these different quantities at `Time=1`, the first solver output column (`t=0`). These numbers expose how much the named pair changes the plotted profile, but are not residuals under a defined observation likelihood. A justified direction/frame and time-aggregation map is needed before using that overlay as an independent quantitative alpha constraint. This lane does not equate these observables.

## Conclusion and remaining gate

Front speed alone still fails to identify alpha across the model family: the named pair has nearly the same secant while alpha differs by about 45% and `a_phi` doubles. But a matched multi-location, signed x-displacement observable is substantially more discriminating. Under the model-derived B-species transport map, the existing four-video trajectory summaries exclude this one alias in an exploratory paired contrast and are closer to the released pair. This means the old speed-only alias is not, by itself, evidence of non-identifiability from all the data.

What remains unestablished is global or statistical identification of alpha and the initial tail over plausible profile families. Closing that gate needs an explicit calibration from GFP intensity and pixels to `phi` and physical distance, a declared observation operator for tracked cells versus the model's species flux, and a joint likelihood/error model that treats videos as the independent units. Then profile the full `(a_rho, a_phi, alpha)` family (or the biologically justified constrained subfamily), including the source's alpha units ambiguity and model/measurement uncertainty. Only use the already source-reported fit as a control; a current-data refit would be in-sample. No external validation, wet-lab work, expert review, or nature-level claim was made.
