# C12 — empirical observable interface and alpha/tail gate

## Finding

The full-PDE speed alias from the earlier lane is real as a **speed-only** construction, but the released source data contain more informative observables. When the two parameter pairs are pushed through a model-derived differentiated-cell velocity and compared with the source's three-location, four-video x-displacement summaries, this particular alias is separated in-sample: the source means are closer to the released pair, and a paired one-contrast t interval excludes the speed alias. This is a conditional comparison over one named pair, not global identification of alpha or a criticism of the authors' joint fit.

The key limitation is the observation map. Fig. 3C cell “velocity” is a 2D endpoint-displacement norm averaged over six hours; the source plotting code overlays it against a signed, one-dimensional model V at the initial time slice. Fig. 2D gives GFP intensity versus pixel index but no workbook calibration to micrometres or to the model fraction phi. Neither panel alone supports a direct physical tail exponent or an unqualified V-to-cell-speed equality.

## Conditional matched-trajectory calculation

From the model's conservative phenotype flux, the candidate labeled-cell velocity is `v_B = V - D*phi_x/phi`, when phi is positive and tracked cells correspond to the B phenotype. At `Nx=800, Nt=3200`, `dx=3.75 μm`, `dt=0.0025 h`, the high-resolution front-speed alias is reproduced to `0.00019 μm/h` at this coarser check mesh. The pair's conditional 0–6 h displacements from model starts at 0, −200, and −400 μm are:

| Location | Four-video observed mean | Released pair | Speed alias |
|---|---:|---:|---:|
| Bone front | 48.94 μm | 65.20 μm | 110.90 μm |
| In bone | 47.48 μm | 47.16 μm | 51.26 μm |
| Further in bone | 34.41 μm | 25.65 μm | 14.12 μm |

The four independent video means have between-video SDs `23.38`, `18.71`, and `6.86 μm`, respectively. To respect pairing, a single contrast was projected along the vector difference between the two model predictions. Its video-level mean is `43.02 μm` (SD `22.60`); the descriptive t interval with 3 degrees of freedom is `[7.06, 78.98] μm`. The model projections are `60.83 μm` for the released pair and `108.14 μm` for the alias. Under the stated marker-velocity map, this source summary includes the released projection and excludes the named alternative. The interval treats four videos as independent and does not cover mapping, model, or parameter uncertainty; the result is in-sample.

The baseline model trajectory is also close to the author's exported front-initialized `cells.sim` curve at six hours (`65.20` versus `65.06 μm`). The author's final Fig. 3B export pools measured cell locations but retains only the front-initialized model path. The new comparison uses the source's location-separated x-displacements to ask whether more of the data can distinguish the pair; it is not the published panel's original estimand.

## Source integrity and limits

The official Nature source workbook is 2,841,401 bytes and remains at SHA-256 `80adcdbffca3162a21a75186e298c44c1c14226ac941867886d5dd3a8e915f45`. Its 25 visible sheets and actual ranges, row grain, units, and provenance boundaries are mapped in [SOURCE_MAP.md](SOURCE_MAP.md) and [source_workbook_map.json](source_workbook_map.json). Key data are Fig. 1H tracks (`A1:F14263`, 455 cells, four videos), Fig. 2B normalized cell/interface displacements (`A1:G192`), Fig. 2D GFP profiles (`A1:EEW41`), Fig. 3B position series (`A1:H889`), and Fig. 3C velocity summaries/profile (`A1:E147`). The workbook was loaded read-only; no cells were modified or exported.

The global identification gate remains open. A defensible alpha/profile reconstruction still needs a physical and biological observation operator for fluorescence-to-phi, an explicit tracked-cell-to-species-flux map, and a joint error model that respects four video-level units. The authors report fitting alpha with multiple experimental observables; this lane does not reconstruct or challenge that full fitting procedure. It does show that the source trajectory data are capable of breaking the specific front-speed alias under the model's conditional marker-velocity interpretation.

No external validation, new experimental data, wet-lab execution, expert review, or novelty/priority claim is made. Prior SI algebra findings, the retracted backward-front claim, and the high-resolution alias controls remain in c8/c9; they were not re-audited here.

