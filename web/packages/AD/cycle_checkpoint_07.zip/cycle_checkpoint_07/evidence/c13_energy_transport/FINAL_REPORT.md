# Interfacial proton transport: local disorder does not certify boundary throughput

## Verdict

I screened a current electrocatalysis bottleneck: whether a local spectroscopic summary of interfacial-water disorder is enough to certify proton-transfer capacity across the electric double layer (EDL). The result is a precise negative theorem for a reversible hopping-network model. Even the full histogram of local degrees and edge conductances does not determine the boundary conductance: two connected degree-two networks with identical edge-weight histograms can differ in conductance by an arbitrarily large factor because the weak links are arranged differently.

This is a useful falsification target for interpreting “isolated-water fraction” as a transport descriptor, but it is **not a new transport mechanism or priority claim**. Effective-resistance variational principles and network topology are established; the specific EDL transfer is a candidate interface, not an externally validated result. I did not obtain molecular trajectories or validate a model on a catalyst. The strongest outcome this round is a candidate quantitative diagnostic and a principled boundary on what local disorder data can imply.

## Scope and route

The exact question was: with a fixed potential, acid activity, and catalyst area, what can a local water-structure statistic alone guarantee about the rate at which protons cross the EDL? I read the task mandate and Astra start/core/workflow files, then the pinned Astra N60 and N58 cards. N60 is a probability/geometric transport record on log-concave transport; its summarized mechanism is not electrochemical transport. N58 concerns a three-gain PDE kinetic regularization. Neither supplies a bridge to interfacial proton hopping. The earlier C9 energy report already treats current/neutral-salt-flux ambiguity in nanopore heat transport, so that interface is excluded here.

The new source screen was routed to interfacial water and proton-transfer kinetics. The 2026 Chemical Science study of CdO–Co₃₋ₓCdₓO₄/Co₃O₄ reports an increase in the spectroscopically assigned isolated-water fraction from 15% to 47% as potential rises, a positive current correlation, EIS changes, and a kinetic isotope effect; its AIMD analysis is also part of the proposed mechanism. At 1.70 V vs RHE it reports a 125 mA cm⁻² current-density advantage over Co₃O₄ and ECSA-normalized activities of 7.5 versus 4.2 mA cm⁻². The article also reports a larger double-layer capacitance for the heterostructure (9.27 versus 4.03 mF cm⁻²), so raw current includes an active-area contribution even though the authors additionally report ECSA-normalized activity. These are source-reported study results, not independently replayed data.

The source hypothesis is not the only relevant one. Earlier primary studies already report that EDL hydrogen-bond-network connectivity can mediate proton transport and change electrocatalytic kinetics, including cation-dependent connectivity at Pt/water interfaces and network-assisted proton transfer in alkaline Fenton chemistry. The right comparison is therefore local water coordination versus spatial and temporal connectivity, not “ordered versus disordered” in isolation.

## Conditional theorem and derivation

Take a finite undirected graph (G=(V,E)) for reversible proton hops near equilibrium. Each edge (e) has conductance (g_e>0), in a common linear-response unit. Let boundary sets (A,B\subset V) be held at chemical-potential offsets 1 and 0. The effective conductance is

\[
  G_{AB}=\min_{\phi|_A=1,\,\phi|_B=0}\;\sum_{\{u,v\}\in E}g_{uv}(\phi_u-\phi_v)^2.
\]

The variational characterization is the finite-network Dirichlet principle. The linear-response flux is (J=G_{AB}\,\Delta\mu), where the displayed normalization sets Δμ=1. Its dissipated power is (J\Delta\mu\), and its entropy-production rate is (J\Delta\mu/T\). This is a model statement around equilibrium, not a high-overpotential law.

**Proposition.** For every even (N=2m\), with even (m\ge 4), and every (0<\epsilon<1), there are two connected cycle networks on the same (N) vertices with (i) degree two at every vertex, (ii) exactly (m) edges of conductance 1 and (m) edges of conductance ε, and (iii) the same pair of opposite boundary vertices, but their boundary conductances obey

\[
  G_A=\frac{1+\epsilon}{m},\qquad
  G_B=\frac{4\epsilon}{m(1+\epsilon)},\qquad
  \frac{G_A}{G_B}=\frac{(1+\epsilon)^2}{4\epsilon}.
\]

Hence the ratio is unbounded as ε tends to zero, despite identical local degree and edge-conductance histograms. For example, ε=0.01 gives ratio 25.5.

**Proof.** Put the terminals at opposite vertices of a (2m)-cycle. The terminals split the cycle into two length-(m) paths in parallel. In arrangement A, put all (m) unit edges on one path and all (m) ε-edges on the other. The path resistances are (m) and (m/\epsilon), so the conductances add to (1/m+\epsilon/m). In arrangement B, put (m/2) unit edges and (m/2) ε-edges on each path. Each path resistance is (\frac m2(1+1/\epsilon)); the two equal path conductances add to (4\epsilon/[m(1+\epsilon)]). The degree sequence, total edge count, conductance multiset, geometry (same cycle), and terminal separation are unchanged. Only the placement of weak edges relative to the source–sink cut changes. □

The proposition is stronger than a counterexample using only a mean “isolated-water” fraction: even knowing the full marginal edge-rate histogram does not give a robust positive lower bound on throughput without connectivity/cut information. It does not show that the 2026 catalyst has either graph, or that its current is proton-transport limited.

## Charge, mass, work, and regime boundary

For acidic oxygen evolution, (2H_2O\to O_2+4H^++4e^-). If the OER Faradaic efficiency is (f\), a steady current density (j\) requires proton production/removal flux (f j/F\) per area and oxygen flux (f j/(4F)\). Thus the reported 125 mA cm⁻² current-density difference corresponds, **if it is fully Faradaic OER**, to (1.30\times10^{-6}\) mol H⁺ s⁻¹ cm⁻², or (1.30\times10^{-2}\) mol m⁻² s⁻¹, and one quarter that O₂ flux. The paper's headline electrode potential of 1.70 V vs RHE is not the full-cell voltage, so it does not determine cell input power or efficiency. The kinetic-network expression charges chemical dissipation (J\Delta\mu); a device energy balance would additionally require the measured full-cell voltage, Faradaic efficiency, gas/product flows, crossover, and heat.

The graph theorem applies to a fixed finite network in linear response, with reversible hops and positive conductances. It does not cover high-potential, nonlinear proton-coupled electron transfer; dynamic bond rearrangement; bulk diffusion; surface reconstruction; or coupled electron, proton, and water transport. In particular, static snapshot connectivity is not automatically equal to dynamic Grotthuss transport. For that transfer one needs a time-resolved state graph with transition rates and a validated kinetic coarse-graining.

## Discriminating test and equally informed controls

The primary observable should be EDL-crossing proton throughput at controlled acid activity, temperature, electrode area, and potential, alongside O₂ production and terminal current. At minimum acquire: (1) Faradaic efficiency and O₂ flux; (2) an independent proton-transfer response or validated impedance decomposition; (3) local water coordination and EDL thickness; (4) time-resolved H-bond edges and their exchange rates from sufficiently long AIMD/validated reactive MD, with the bond definition, finite-size effect, and trajectory autocorrelation reported; (5) catalyst loading, ECSA, valence/reconstruction, and full-cell voltage. KIE alone establishes proton-transfer relevance, not a unique rate-limiting network path.

Compare two models with the same catalyst, potential window, ECSA, metal state, electrolyte, and measured isolated-water/coordination histogram. The local-statistic model predicts transport from those marginals alone. The topology model additionally uses source-to-bulk path conductance and bond persistence. A strong simulation control rewires edges within coordination/height bins while preserving every one-point count and edge-rate histogram; this tests whether connectivity adds predictive power without changing marginal disorder. A real experimental control would need a cation/field perturbation series matched for pH, ECSA, and catalyst state, with in-situ spectroscopy and proton-sensitive impedance or isotope-resolved flux. The perturbation is difficult to interpret because cations and field also change the double layer and surface kinetics.

The predeclared falsifier for the proposed topology diagnostic is: across held-out conditions, graph connectivity/time-correlation adds no predictive value over matched local coordination and local barrier distributions, within uncertainty and after accounting for catalyst area and Faradaic selectivity. That would reject this model extension. Conversely, a correlation in a small trajectory set would not establish a physical causal mechanism or external priority.

## Prior art and novelty boundary

Primary literature already covers the neighboring mechanisms: 2024 work uses AIMD to study cation-tuned EDL H-bond connectivity; a 2025 *Water Research* article reports network-mediated proton skipping in alkaline Fenton chemistry; and 2025 *Nature Communications* work relates cation-dependent alkaline hydrogen electrocatalysis to double-layer proton transfer and H-bond connectivity. The 2026 Chemical Science source already combines operando ATR-SEIRAS, EIS, KIE, and AIMD for interfacial water under high-potential acidic OER. Earlier graph and molecular-dynamics studies also use network topology for proton transport. Therefore I claim no novelty for “H-bond topology affects proton transport,” no discovery of the 2026 material mechanism, and no material recommendation. The proposition is a standard network-theory obstruction translated into a sharper measurement boundary for that interface.

The live research gap is narrower: whether a measured time-dependent connectivity statistic predicts EDL proton throughput across held-out potentials/materials after local barriers, active area, and surface state are controlled. I have not found a source proving that transfer, nor tested it on primary trajectories. The decisive next gate is access to the 2026 study's AIMD/operando data or a matched new trajectory set; without it, this remains a model-level counterexample and proposed test.

## Files and evidence state

- `conductance_counterexample.py` computes the exact ring-network values using only the Python standard library.
- `CLAIMS.json` records the proposition, scope, status, cost, falsifier, and next gate.
- External reports and prior art are linked below. Web text was read for the stated sections/results, not for global priority clearance or experimental reanalysis.

### Sources

- 2026 Chemical Science primary article, “Engineering the interfacial water microenvironment to accelerate proton transfer for acidic oxygen evolution at high-potential,” DOI [10.1039/d6sc01336h](https://doi.org/10.1039/d6sc01336h); full text at [PubMed Central](https://pmc.ncbi.nlm.nih.gov/articles/PMC12974597/). Results on current, ECSA, EIS, ATR-SEIRAS, isolated-water fraction, and KIE; methods/data are not independently replayed.
- 2024 Chemical Science primary article, “Tuning hydrogen bond network connectivity in the electric double layer with cations,” DOI [10.1039/d3sc06904d](https://doi.org/10.1039/d3sc06904d).
- 2025 Water Research primary article, “Hydrogen bonding network in the electrical double layer mediates fast proton skipping…,” DOI [10.1016/j.watres.2024.122612](https://doi.org/10.1016/j.watres.2024.122612).
- 2025 Nature Communications primary article, “Kinetic cation effect in alkaline hydrogen electrocatalysis and double layer proton transfer,” [article page](https://www.nature.com/articles/s41467-025-56966-9).
- 2025 Nature Communications primary article, “Pressure and bias dependence of the rate-limiting steps of the oxygen reduction reaction,” [article page](https://www.nature.com/articles/s41467-025-67494-x); neighboring evidence for dynamic, potential-dependent control and transport regimes, not the selected OER mechanism.
- Astra N60 and N58 pinned cards: [N60](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/N60-geometry-transport-ledger.txt), [N58](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/N58-three-gain-kinetics.txt).
