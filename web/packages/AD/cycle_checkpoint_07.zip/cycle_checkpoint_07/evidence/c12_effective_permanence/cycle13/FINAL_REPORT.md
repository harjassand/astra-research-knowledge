# C13 closure: rational N33 family construction remains open

## Result

This round found no counterexample to rational all-scale activity families, but it did not prove the all-dimensional rational-family construction or produce an end-to-end compiler. C12's exact supplied-family checker and final report remain unchanged.

For the rational diagram (0\leftrightarrow A), the hostile pass constructed a five-label family with rational slopes and finite negative rational-Puiseux offsets. Its exact line crossings are (h^{3/5},h^{2/5},h^{-2/5},h^{-3/5}), and every active exponent interval, including ties, lies strictly inside the corresponding (E_D) margin. C12's checker returns `CERTIFIED_ACTIVITY_CUTOFF` with conservative cutoff (2^{-80}). The input, result, and derivation are in [the reversible one-species fixture](counterexample/reversible_one_species_rational_family.json), [its result](counterexample/reversible_one_species_rational_family.result.json), and [the hostile report](counterexample/REPORT.md). Thus the rejected N50 plateau family is a family-specific failure, not a diagram-level obstruction.

For a rational finite comparison set (D), the exact zero-product strata of the hyperplane arrangement (r\cdot v=0) are rational faces. Rational slopes are dense within each face, preserve all zero products and nonzero signs, and (E_D) is continuous and positive relative to that face. This rationalizes any fixed finite set of slopes while preserving its tolerance data. The proof and limits are recorded in [the strata note](strata_construction/PARTIAL.md).

An exact boundary-layer witness shows why this stratum fact does not settle perturbation of the whole family. In the same (0\leftrightarrow A) diagram, the two lines (x-h^{3/5}) and (x/2-h^{3/5+1/n}) tie at scales (h_n=n^{-5}) with exponent (p_n\to4/5), outside the slope-(1/2) tolerance (E_D(1/2)=1/4). The exponent gap tends to zero while the bad active limit persists. It refutes uniform active-set continuity under exponent perturbation, not existence of a fixed rational family.

## Remaining gate

The N33 affine theorem supplies a finite real family through compactness choices. We still lack either (i) a proof that its recursive slices, local windows, offsets, and gluing can be selected rationally while preserving all-scale activity, or (ii) a rational diagram for which no such family exists. Positive radii at a dense set of rational centers alone do not ensure those centers cover the interval; the exponent-boundary-layer variable must also be controlled. The arbitrary-positive-(E) theorem cannot be used as an effective oracle.

Conditional on an accepted rational family, C12 already records how to compute the exact projected margin, rate cutoff, rational class-representative scale condition, and common absorber for a positive rational representative (c) and rational ([\kappa,K]). The absorber is uniform over the class and rate paths; entry-time bounds remain per initial point, with no uniform bound over an unbounded class. The (S=0) class is the singleton ({c}).

No shared Lean or source files were changed. This is partial internal progress, not external validation, an all-dimensional rational construction, or a completed promised-input semialgorithm.
