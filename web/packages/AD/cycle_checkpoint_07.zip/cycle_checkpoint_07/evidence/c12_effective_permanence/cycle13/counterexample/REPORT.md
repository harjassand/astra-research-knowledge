# C13 hostile audit: rational all-scale activity family

**Result:** no nonexistence counterexample found. The familiar rejected plateau family for \(0\leftrightarrow A\) is family-specific: the same rational endotactic diagram has an explicit five-label rational-Puiseux family satisfying the N33 activity condition at every \(0<h<1\). A separate exact boundary-layer construction shows that nearby rational offset exponents can move an active crossing by a fixed amount along scales \(h_n\to0\). It defeats a uniform-continuity shortcut for rationalization, but it does not refute existence of a rational family selected once and for all.

## Exact positive control: (0\leftrightarrow A)

Take sources (0,1), targets (1,0). The comparison directions reduce to (\{1,-1\}), and
\[
E_D(r)=\begin{cases}\tfrac12,&r=0,\\ \min(\tfrac12,|r|/2),&r\ne0.\end{cases}
\]
Use the slopes (1,\tfrac12,0,-\tfrac12,-1), in this order, and offsets
\[
\begin{aligned}
b_1&=-h^{-2/5}-h^{-3/5}-h^{2/5}-\tfrac12h^{3/5},\\
b_{1/2}&=-h^{-2/5}-h^{-3/5}-h^{2/5},\\
b_0&=-h^{-2/5}-h^{-3/5}-\tfrac12h^{2/5},\\
b_{-1/2}&=-\tfrac12h^{-2/5}-h^{-3/5}-\tfrac12h^{2/5},\\
b_{-1}&=-\tfrac12h^{-2/5}-\tfrac12h^{-3/5}-\tfrac12h^{2/5}.
\end{aligned}
\]
These are finite negative sums of rational powers, and every exponent is greater than (-1), so each offset is (o(h^{-1})). Consecutive line crossings occur exactly at
\[
x=h^{3/5},\quad h^{2/5},\quad h^{-2/5},\quad h^{-3/5},
\]
since every consecutive slope drop is (1/2) and the corresponding intercept rise is respectively (\tfrac12h^{3/5},\tfrac12h^{2/5},\tfrac12h^{-2/5},\tfrac12h^{-3/5}). These crossing points are strictly increasing for (0<h<1), so the lower-envelope active slope runs (1,1/2,0,-1/2,-1) as (x) increases. Writing (x=h^p), the active (p)-intervals are
\[
[3/5,1],\quad[2/5,3/5],\quad[-2/5,2/5],\quad[-3/5,-2/5],\quad[-1,-3/5],
\]
respectively. The corresponding tolerances are (1/2,1/4,1/2,1/4,1/2). On every interval, including both endpoints where ties occur, 
\[
|p-r|\le 2/5<1/2\quad(r=\pm1,0),\qquad
|p-r|\le 1/10<1/4\quad(r=\pm1/2).
\]
Thus the family satisfies strict all-scale activity throughout the closed exponent cube for every (0<h<1). The exact checker independently returns `CERTIFIED_ACTIVITY_CUTOFF`, with the conservative dyadic cutoff (h_{act}=2^{-80}). Inputs and output are in `reversible_one_species_rational_family.json` and `.result.json`.

This is a direct counterweight to the (N50) plateau fixture: rejection of that particular family is not evidence that the diagram has no acceptable family.

## Exact boundary-layer obstruction to a uniform perturbation argument

For the same diagram, consider just the two affine forms
\[
G_{n,h}(x)=\min\{x-h^{3/5},\;\tfrac12x-h^{3/5+1/n}\},\qquad h_n=n^{-5}.
\]
They tie at
\[
x_n=2h_n^{3/5}(1-h_n^{1/n})=2n^{-3}(1-n^{-5/n}).
\]
At this active tie, (p_n=\log_{h_n}x_n\) obeys
\[
x_n\sim 10(\log n)n^{-4},\qquad p_n\longrightarrow\frac45.
\]
For the slope (1/2), (E_D(1/2)=1/4), while 
\[
|p_n-1/2|\longrightarrow 3/10>1/4.
\]
So the tie is bad for all sufficiently large (n), despite the exponent perturbation (1/n\to0) and the scales (h_n\to0). The mechanism is the near-cancellation
\[
h^{3/5}-h^{3/5+1/n}=h^{3/5}(1-h^{1/n});
\]
when (h=n^{-5}), the factor in parentheses is asymptotic to (5\log(n)/n), which shifts the crossing exponent by an asymptotic (1/5).

Scope: (G_{n,h}) is a two-label comparison witness, not a full activity family, and (n) varies with the example. For each fixed exponent gap, its eventual asymptotics may settle after a gap-dependent cutoff. This disproves a proof step asserting uniform active-set closeness over all small (h) as exponents are perturbed; it does **not** prove that any fixed rational family fails or that rational families do not exist.

## Disposition

The proposed rational-family route survives this hostile pass at the stated existence level. The exact positive control shows existence in a nontrivial (though one-dimensional) rational diagram. The boundary-layer witness preserves the need for the missing proof to handle exponent gaps jointly with scale, including its cutoff dependence. No all-dimensional rationalization theorem or counterexample to that theorem is established here.
