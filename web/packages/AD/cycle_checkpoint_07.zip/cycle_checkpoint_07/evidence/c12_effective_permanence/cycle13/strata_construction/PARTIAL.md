# C13 strata construction: partial result and exact gap

## Proven stratum fact

Let (D\subset\mathbb Q^d\setminus\{0\}) be finite and let
\[
E_D(r)=\min\bigl(\{1/2\}\cup\{|r\cdot v|/(2\|v\|_1):v\in D,\ r\cdot v\ne0\}\bigr).
\]
Adjoin the rational cube-face hyperplanes (r_i=\pm1) to the arrangement (r\cdot v=0). Every relative face is a relatively open rational polyhedron. Its rational points are dense: the affine hull is the solution set of rational linear equations, hence has a rational point and a rational basis, and strict rational inequalities define a relatively open subset of that affine hull. Thus for every (r) in a face there are rational (r_n\to r) in the same face, preserving exactly the zero set \(\{v:r_n\cdot v=0\}=\{v:r\cdot v=0\}\) and every nonzero product's sign. On that face (E_D) is the minimum of finitely many positive continuous linear forms (with absolute values resolved by the fixed signs) and (1/2); hence (E_D(r_n)\to E_D(r)>0).

This only rationalizes a *given finite set of slopes*. It does not construct a family whose active-limit set has the required strict margin.

## Precise failures of two tempting steps

1. Positive radii at rational centers do not imply a finite rational-center cover. For any irrational (x_0\in(a,b)), set (\rho(q)=|q-x_0|/3>0) for every rational (q\in[a,b]). Then (x_0\notin\bigcup_{q\in\mathbb Q\cap[a,b]}(q-\rho(q),q+\rho(q))). Consequently, the real local-window proof plus “choose rational centers densely” is insufficient unless one proves a structural/effective lower bound on the windows or proves stability of the family under rationalizing its center.

2. Ordinary joint compactness in exponent and scale is invalid. With (h_n=e^{-n}\), (\beta_n=\beta+1/n\), one has (h_n^{\beta_n}/h_n^\beta=e^{-1}); with (\beta_n=\beta-1/n\), the ratio is (e). At fixed nonzero (\delta), however, (h^{\beta+\delta}/h^\beta\to0) and (h^{\beta-\delta}/h^\beta\to\infty). Therefore closeness of exponents alone gives no uniform all-small-scale comparison. Any rational-offset perturbation lemma must explicitly retain the boundary-layer variable \((\beta_n-\beta)|\log h_n|\) (and its finite/infinite limits), with tie-inclusive activity.

These are obstructions to the shortcuts, not counterexamples to existence of rational activity families for (E_D).

## Exact open lemma needed

For each rational finite reaction diagram (D), prove either of the following sufficient gates:

- **Family gate:** the arbitrary-tolerance N33 affine construction for (E_D) can be carried out with finitely many rational slopes (r_j\in[-1,1]^d\) and offsets (b_j(h)=-\sum_{\ell=1}^{L_j}c_{j\ell}h^{\gamma_{j\ell}}), (c_{j\ell}\in\mathbb Q_{>0}), \(\gamma_{j\ell}\in\mathbb Q\), \(\gamma_{j\ell}>-1\), such that there exists (h_*>0) for every (0<h<h_*), every (p\in[-1,1]^d), and every (including tied) active label (j\),
\[
 |p_i-r_{ji}|<E_D(r_j)\qquad(1\le i\le d).
\]
- **Stability gate:** starting from the real finite Puiseux family supplied by the N33 lemma, prove that its active-limit sets are upper-semicontinuous under rational parameter perturbations which preserve all zero products (r_j\cdot v=0\), all relevant coefficient zero/sign data, and exponent equality/order classes; the proof must include every exponent boundary layer and yield strict margin below the new (E_D(r_j')\).

Neither gate is proved here. The fixed-family exact checker from C12 only decides a supplied rational family; it cannot discharge this existence/stability lemma. No source or Lean files were changed.
