# N33 effective-permanence audit: exact fixed-family bounds

**Status:** the all-scale activity cutoff is now an exact, executable finite procedure for any *supplied rational family*. The promised-input compiler is still open: the missing theorem is that the family produced nonconstructively by the affine argument can be chosen rational while retaining its all-scale activity property. The available package summary asserts such a rationalization but does not contain the proof or audit it cites. This report does not claim an end-to-end effective N33 theorem.

## Interface and exact tolerance

The proposed chemical interface is a finite rational reaction diagram, rational rate bounds kappa and K with 0 < kappa <= K, and a positive rational representative c of the stoichiometric class. A diagram supplies rational sources y_e, targets yprime_e, and reaction vectors nu_e = yprime_e - y_e. Form the finite comparison list

\[
D=\{e_i\}_i\cup\{\nu_e:\nu_e\ne0\}\cup\{z-y:y,z\text{ are sources},\ z\ne y\},
\]

Dropping zero vectors. For a rational slope r in [-1,1]^d, compute exactly

\[
E_D(r)=\min\left(\{1/2\}\cup
 \left\{\frac{|r\cdot v|}{2\|v\|_1}:v\in D,\ r\cdot v\ne0\right\}\right).
\]

No margin oracle is needed at rational r. Zero products must be omitted exactly: E_D jumps upward on comparison hyperplanes. For the reversible A <-> B diagram, r_n=(1/2,1/2+1/n) has E_D(r_n) <= 1/(4n), tending to zero, whereas the limiting slope (1/2,1/2) has zero source-difference product and positive tolerance. Thus taking a positive minimum over the whole cube is invalid.

## A terminating checker for one candidate family

Input is a finite list of rational slopes r_j in [a,b]^d and offsets b_j(h)=sum_l a_jl h^gamma_jl, with rational coefficients and exponents gamma_jl > a (after combining equal powers).

\[
F_h(x)=\min_j(r_j\cdot x+b_j(h)).
\]

The checker decides whether a computable positive h_act exists such that, for every 0 < h < h_act, every p in [a,b]^d, and every active label j,

\[
|p_i-r_{ji}|<E_D(r_j)\quad\text{for every }i.
\]

It uses only exact rational arithmetic, finite linear algebra, and sparse-polynomial sign tests; it does not call QE or use floating point.

For each label (j), coordinate (i), and side, encode a bad active point as a polytope in (x_i=h^{p_i}):

\[
h^b\leq x_i\leq h^a,
\qquad (r_j-r_k)\cdot x\leq b_k(h)-b_j(h)\quad(k\ne j),
\]

and either x_i <= h^(r_ji + E_D(r_j)) or x_i >= h^(r_ji - E_D(r_j)). All active comparisons are weak, so ties are checked. A feasible point is exactly one where this active label violates the strict activity bound by at least the tolerance.

Let N be an even common denominator of the rational exponents in the box, thresholds, and offsets; put h=u^N. Choose an integer M large enough that y=u^M*x makes every right-hand side a sparse polynomial in u with nonnegative integer powers. Each bad-point question is now

\[
A y\leq c(u),
\]

Here A is a constant rational matrix, the right-hand side is a sparse-polynomial vector, and the feasible region is bounded. Enumerate all d-row subsets of A with nonzero determinant. For each basis B, the candidate vertex is y_B(u)=A_B^(-1)c_B(u); it is feasible exactly when every residual polynomial c_l(u)-A_l*y_B(u) is nonnegative. A nonzero sparse polynomial has fixed sign for all sufficiently small positive u, given by its lowest-power nonzero coefficient. A zero residual is harmless. Hence:

* if some basis has every residual eventually nonnegative, a bad active point exists for every sufficiently small scale and the family is rejected;
* otherwise each basis has an eventually negative residual, so the polytope is empty below a computable positive dyadic (u), and the event is discharged.

The second case also handles lower-dimensional feasible polytopes: every nonempty compact polytope has a vertex with (d) linearly independent active constraints. To make the cutoff exact, for (P(u)=a_0u^{e_0}+\sum_{j>0}a_ju^{e_j}) after clearing denominators, the bound

\[
0<u<\min\!\left(\frac12,\frac{|a_0|}{2\sum_{j>0}|a_j|}\right)
\]

preserves the leading sign (with the tail-free case immediate). Taking minima over all bases and bad events yields the cutoff. The returned (h_{\rm act}) is represented symbolically as (2^{-NT}), avoiding expansion of a potentially huge denominator.

The implementation is [fixed_family_activity.py](fixed_family_activity.py); its rational JSON input format is exemplified by [n50_plateau_activity_counterexample.json](n50_plateau_activity_counterexample.json). `python3 -m py_compile` succeeds. The exact checker returns `NO_CUTOFF` on that file and exhibits the bad active label, coordinate, side, basis, and residuals.

The candidate family checker covers only the closed exponent cube. This suffices for the N33 scale box B_h=[h,h^(-1)]^d, because each x in B_h has a unique representation x_i=h^(p_i) with p in [-1,1]^d. It need not decide the stronger affine lemma's outside-cube sequential formulation.

### Exact adversarial fixture

For the diagram 0 <-> A,

\[
F_h(x)=\min\{0,\ x-2h^{1/2},\ \tfrac12h^{-1/2}-x\}.
\]

The lower label has slope r=1, and E_D(1)=1/2. At x=sqrt(h), its value is -sqrt(h), while the other labels have values 0 and (1/2)h^(-1/2)-sqrt(h); hence it is active for every sufficiently small h. Its exponent is p=1/2, so |p-r|=1/2=E_D(r), violating the required strict inequality at every scale. The script reconstructs this witness exactly. This plateau certificate is valid for its direct inward-drift proof, but it cannot be reused as the missing affine-activity family.

## Conditional compiler and exact cost boundary

Suppose the following missing lemma were proved: for every promised rational endotactic input, there exists a finite activity family with rational slopes and finite rational-power offsets b_j(h)=o(h^(-1)), satisfying the checked condition above for the actual E_D. Then a countable search over finite rational encodings, running this checker on each candidate, would halt on every promised input. This is a genuine semidecision procedure, not a polynomial-time claim. A bounded implementation returns UNKNOWN on budget exhaustion. No black-box arbitrary-positive E, R_exp, or QE oracle is involved.

For a checked rational family, the remaining numerical choices are exact. Compute the finite rational margin

\[
H=\min\bigl(\{1\}\cup\{|r_j\cdot v|/2:r_j\cdot v\ne0,\ v\in D\}\bigr)>0,
\]

Then choose a common even denominator q for the Puiseux exponents and H. With h=z^q and dyadic z=2^(-T), the activity cutoff, K*L*h^H <= kappa*H, and the class condition

\[
h^H\max_i\{c_i,c_i^{-1}\}<1
\]

are exact rational comparisons. The original weighted-drift and plateau arguments then produce the final rational polytope K_P = K_hP intersect (c+S). It is one common absorber for all initial points in the class and all measurable rates. An entry-time bound is computed separately for each initial point; no bound uniform over an unbounded class follows. If S=0, the class is the singleton {c} and no search is needed.

The entry-time distinction is necessary even for the one-species diagram 0 <-> A with both rates fixed at 1. Its positive class is the unbounded half-line, and x(t)=1+(x0-1)e^(-t). For any compact absorber with upper endpoint U>1, an initial x0>U first reaches U at time log((x0-1)/(U-1)), which tends to infinity with x0. Thus a class-common absorbing set is possible while a uniform entry-time bound over the unbounded class is not.

For a family with L_f labels and dimension d, each of at most 2*d*L_f bad events has O(2*d+L_f) constraints and at most binom(2*d+L_f,d) bases. The basis count is exponential in dimension. Rational exponent LCMs may be exponentially large as integers in their bit-length encoding; the cutoff exponent and intermediate coefficient heights must be charged. The exact procedure gives finiteness, not useful precision, conditioning, runtime, or output-size bounds. QE is unnecessary for this fixed-family gate, but the rational-family existence proof is not supplied by the checker.

## The unresolved rationalization gate

The N33/OA149 affine argument gives a finite real family by choices involving positive pointwise tolerances, compact bad-limit sets, radii, and a finite interval cover. For the actual (E_D), values at rational slopes are computable, but (E_D) is discontinuous where comparison products vanish and has no positive minimum on the cube. Approximating every real slope by a nearby rational without preserving its zero products can collapse the tolerance. A possible route is to stratify the rational hyperplane arrangement, keep all zero-product equalities, choose rational centers inside strata, and certify an exact strict box cover; however, this still has to be joined to affine-family construction and gluing.

The package summary work/agents/systems_metabolism/astra/d-cfb13618e402da57.txt reports that a separate reconstruction lets all proof-tree parameters move jointly with h tending to zero, preserves zero products, and uses enlarged compact active-limit sets to obtain robust neighborhoods. The cited reconstruction and critic audit are absent from the checkout, so the assertion could not be replayed. There is a concrete obstruction to treating this as ordinary continuity: for beta_n=beta+1/n and h_n=exp(-n),

\[
\frac{h_n^{\beta_n}}{h_n^\beta}=e^{-1};
\]

With beta_n=beta-1/n the same ratio is e; at fixed beta it is 1. Thus nearby exponent choices are not uniformly close over all small scales; compactness in (beta,h) alone does not control active-label limits. Any successful joint argument must explicitly cover the boundary-layer variable (beta_n-beta)*|log h_n|, show that every resulting profile preserves the strict E_D margin, and verify that rationalized cuts and all recursive zero-product constraints still glue. This observation attacks a proof shortcut, not the possibility that a stronger rationalization theorem is true.

The arbitrary-(E) affine theorem cannot supply this gate algorithmically: an arbitrary positive function on real slopes may be uncomputable. The specialization to finite rational (D) is essential and promising, but its rational-family lemma and termination proof remain unverified here.

## Prior art boundary

Johnston–Pantea–Donnell give a mixed-integer linear programming method for deciding endotactic and strongly endotactic network structure; that addresses the diagram promise, not the rational all-scale affine family or classwise absorber compiled here ([arXiv:1412.4662](https://arxiv.org/abs/1412.4662)). Craciun–Deshpande embed endotactic systems into toric differential inclusions, a structural dynamical result rather than this effective quantitative interface ([arXiv:1906.08384](https://arxiv.org/abs/1906.08384)). Brunner–Craciun prove permanence for two-dimensional tropically endotactic polynomial and power-law systems, including time-dependent parameters; this is a stronger concrete route in that specialized dimension, not a general all-dimensional rational compiler ([arXiv:1705.06785](https://arxiv.org/abs/1705.06785)).

The sources actually audited for this task are `work/agents/permanence_hostile/endotactic_permanence.tex`, `work/agents/permanence_hostile/OA149/affine.tex`, and `work/agents/c4_rational_hostile/formalization/dynamics/WeightedDrift.lean`. `work/agents/c4_rational_hostile/formalization/project/N33Affine/GlobalAffineComposition.lean` and `UniformActivity.lean` formalize the real, noncomputable family and its fixed-family cutoff; they do not provide rational encodings or bit bounds. This report makes no new permanence-theorem, novelty, or external-validation claim.
