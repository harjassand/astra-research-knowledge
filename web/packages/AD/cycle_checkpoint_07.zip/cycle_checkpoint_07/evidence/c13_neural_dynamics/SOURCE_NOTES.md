# Source and retrieval ledger

## Campaign constraints and prior routing

- Campaign mandate: `work/ROOT_MANDATE.txt`; Astra entry/core: `work/astra_prior/00_START_HERE.txt`, `work/astra_prior/01_CORE.txt`; workflow: `work/astra_prior/RESEARCH_WORKFLOW.txt`.
- Astra pinned commit: `8ede33c2f09a8abe07b430892b3ac4bb71c27c83`; route inspected: `work/astra_prior/topics.txt`, `work/astra_prior/agent/topics/methods.tsv` (`W-frontier-dynamics`) and `acquisition.tsv`/`methods.tsv` (`N28-transfer-controls`); local N25: `work/astra_prior/cards/N25-acquisition-interface-tests.txt`.
- Pinned source URLs: [W-frontier-dynamics card](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/W-frontier-dynamics.txt), [N28-transfer-controls card](https://raw.githubusercontent.com/harjassand/astra-research-knowledge/8ede33c2f09a8abe07b430892b3ac4bb71c27c83/cards/N28-transfer-controls.txt).
- Both raw cards were read only as compact navigation/research extracts. W is explicitly a selected incomplete report extract (families 143–154); N28 is explicitly a source-derived, internally audited but externally unvalidated compact report. Neither contains a neural mechanism, and neither supports the QIF conclusions. No neuroscience-specific card was found in the supplied 186-card topic route. This records route scope, not proof no such source exists in the full Astra repository.
- Local N25 SHA-256: `286da7bd83b18c256b086a61c9c1a041bc8c0732450a78ca232ff8cd6fe35e36`; used only as an interface/accounting reminder, not as a neuron result.

## Primary neural sources

1. Christian Klos and Raoul-Martin Memmesheimer, “Smooth Exact Gradient Descent Learning in Spiking Neural Networks,” *Physical Review Letters* 134, 027301 (2025), DOI `10.1103/PhysRevLett.134.027301`; arXiv `2309.14523v2` (28 Jan 2025). Primary version PDF downloaded from `https://arxiv.org/pdf/2309.14523`; SHA-256 `3290d446182a892d4a63d66f97f06c9781cdbb5528760843a35a54a72f45c816`; text extraction is via pypdf into `sources/klos_memmesheimer_2025.txt`. Opened/arXiv text route: `https://arxiv.org/abs/2309.14523`, especially main-text sections “Non-disruptive (dis-)appearance of spikes and smooth spike timing,” “Pseudodynamics and pseudospikes,” “Gradient descent learning,” and “Discussion”; local extraction includes supplemental material. The article is peer-reviewed; no proof was independently formal-checked here.
2. Carlo Wenig, Raoul-Martin Memmesheimer, and Christian Klos, “Quadratic integrate-and-fire neurons exhibit less fragmented loss landscapes and outperform leaky integrate-and-fire neurons in spike-based gradient descent,” arXiv `2606.03935v1`, posted 2 June 2026. PDF downloaded from `https://arxiv.org/pdf/2606.03935`; SHA-256 `ce78f1d8f18f9e67b1981222e4b3674d3ed453be507c03bf66b8c154c18e7b03`; body extracted to `sources/wenig_etal_2026.txt`. Source is a preprint. Main-text body and supplementary methods were read locally; reported results/limitations are source-reported, not rerun.

## Prior art searched (not exhaustive)

- Wunderlich and Pehle, “Event-Based Backpropagation can compute Exact Gradients for Spiking Neural Networks,” arXiv `2009.08378`; source-reported EventProp computes exact event-based gradients under its model/interface.
- Stochastic spiking exact-gradient literature: NeurIPS 2024, “Exact Gradients for Stochastic Spiking Neural Networks Driven by Rough Signals,” proceedings source. This is direct prior art for gradients in stochastic event-driven networks and narrows any possible novelty claim about smooth expected losses.
- DelGrad, Nature Communications 2025: exact event-based gradient learning of weights and delays in hardware-oriented LIF networks; relevant comparator, not evidence for the current extension.
- Searches used: “spiking neural network expected spike count loss timing jitter differentiable event based exact gradient,” “QIF spiking neural network energy regularizer exact spike gradient noise expected spike count,” and “spiking neural network probabilistic spike latency jitter expected firing rate gradient energy regularization.” This was bounded discovery, not a complete priority search.
