# C13 neural dynamics — checkpoint report

## Verdict

**Unfinished candidate; no discovery or priority claim.** The strongest current lead is the 2025 exact, smooth spike-based gradient method for QIF networks and its 2026 follow-up controlled QIF/LIF comparison. These remove an important optimization pathology in a named model class. The load-bearing unresolved interface for energy-efficient deployment is that a smooth timing objective need not be a smooth objective for physical event count: an event crossing a finite trial boundary changes the charged count discontinuously.

I derived a narrow consequence: under calibrated, additive Gaussian event-time jitter, expected finite-window event energy has an explicit smooth gradient. This is a straightforward mathematical extension, not yet checked against full prior art, a device, or a benchmark. It should be treated as a concrete research question and experiment gate, not a scientific advance.

## Goal and interface

Scoped task: find a theoretical/computational neural-dynamics mechanism that can remove a major learning or energy bottleneck under measurable resource accounting. The present candidate has input: a finite spike-time record or differentiable event-time model, window `[0,T)`, per-event cost `c`, and repeated hardware event-time measurements. Output: a differentiable *expected* event cost and gradient under an explicitly fitted timing-noise model. Parameters and candidate event times are supplied by the trained/modelled network; device jitter distribution and per-event energy must be acquired. Costs not yet measured: calibration trial count, compute/training energy, reset energy, hidden-neuron event energy, and device-specific timing variance.

## Primary mechanism reconstructed

Klos and Memmesheimer, “Smooth Exact Gradient Descent Learning in Spiking Neural Networks,” PRL 134, 027301 (2025), DOI [10.1103/PhysRevLett.134.027301](https://doi.org/10.1103/PhysRevLett.134.027301), arXiv:2309.14523v2. The paper replaces LIF dynamics with QIF dynamics whose voltage self-amplifies toward an infinite threshold. For temporally extended exponential synaptic input, a spike time moves continuously as parameters change; a spike can appear/disappear only at the simulation horizon, where it cannot affect later in-trial dynamics. The separate pseudodynamics construction continues neurons past the horizon, generates pseudospike times, and lets gradients reach initially silent neurons. This restores a path by which gradient descent may add events. For the exponential-current model the paper notes an analytically solvable case at synaptic time constant half the membrane time constant. The source states the exploding-gradient/long-memory limitation and restricts examples to at most ten membrane time constants.

The paper's event-time smoothness is not a proof that every operational objective is smooth. Proposition 1 in [the derivation](proofs/boundary_energy_obstruction.md) shows that a positive hard cost per in-window event jumps when that event crosses `T`. Proposition 2 derives a smooth expected per-event energy objective only after adding and calibrating a specific Gaussian timing-jitter model. This expectation-level smoothing does not remove its `1/σ` conditioning near the horizon or establish a device model.

Wenig, Memmesheimer, and Klos, “Quadratic integrate-and-fire neurons exhibit less fragmented loss landscapes and outperform leaky integrate-and-fire neurons in spike-based gradient descent,” arXiv:2606.03935v1 (2 June 2026), is a preprint, not independently reviewed here. Its abstract and extracted body report a controlled SHD comparison: best small QIF model 90.1±0.9% test accuracy vs best LIF 79.2±1.3%; a selected asynchronous LIF variant reaches 29 ms output distinctness but only 50.8±4.0%. Large exploratory models report 91.3±0.8% QIF and 85.2±1.3% LIF. The authors disclose selecting hyperparameters against test-set accuracy, and that they did not maximize accuracy. Their analyzed conditions use oscillating neurons with instantaneous input jumps, 64 temporal bins for input event preprocessing, and a task-specific pseudo-spike penalty. They report that QIF loss is continuous but can have sharp transitions and discontinuous gradients at event-order boundaries. Accordingly, neither a smooth-loss guarantee for the earlier extended-current model nor a universal hardware advantage transfers automatically to this later setting.

## Candidate mathematical result

For a differentiable event time `t(θ)`, the hard energy `c 1{0≤t(θ)<T}` is discontinuous whenever `t(θ0)=T` and `t'(θ0)≠0`. With additive timing jitter `η~N(0,σ²)`, expected event energy is

`c[Φ((T-t)/σ)-Φ(-t/σ)]`,

with derivative

`(c/σ)[φ(t/σ)-φ((T-t)/σ)] t'(θ)`.

The formula, proof, Gaussian tail margin bound, and experiment falsifier are recorded in [boundary_energy_obstruction.md](proofs/boundary_energy_obstruction.md). This is an internally derived conditional proposition. I have not completed a novelty search for this exact objective, established that real QIF hardware timing noise satisfies the model, or implemented/benchmarked the optimizer.

## Astra prior boundary

The Astra pinned commit is `8ede33c2f09a8abe07b430892b3ac4bb71c27c83`. I read `00_START_HERE.txt`, `01_CORE.txt`, and `RESEARCH_WORKFLOW.txt`. The supplied topic catalog has no neuroscience/neuromorphic route. I followed the general dynamics route `methods.tsv → W-frontier-dynamics` and the measurable-interface/control route `methods.tsv/acquisition.tsv → N28-transfer-controls`; these are broad reports, not neuron-specific proof premises. `W-frontier-dynamics` (raw pinned card, source extract only) concerns reaction-network dynamics and makes no neural-training claim. `N28-transfer-controls` is a compact 37-report control ledger, explicitly source-derived/unreviewed and not blanket validation. Local `N25-acquisition-interface-tests.txt` reinforces complete energy/query charging but concerns noncommutative matrix-oracle tasks, so it was not transferred as a neural theorem. No neural source mechanism or proof in Astra was adopted.

Raw pinned cards and current primary sources are indexed with paths, URLs, and hashes in [SOURCE_NOTES.md](SOURCE_NOTES.md). The downloaded primary PDFs and extracted text are preserved in `sources/`; their SHA-256 values appear below in CLAIMS.json.

## Strongest blockers and next gate

The mathematical extension is easy; its novelty and relevance are not established. Search prior work on energy/count losses, escape-noise models, EventProp/EventSDE, and QIF pseudospikes before making any claim. The decisive experimental gate is a blinded, device-level comparison using repeat-measured jitter and energy, matched for task accuracy, output timing margin, and latency. First establish that the fitted jitter distribution predicts held-out event probabilities and costs. Then compare the convolved objective with matched-information task-only QIF, hard-count/nonsmooth, and discretized surrogate baselines. If measured cost predictions fail or no energy reduction occurs at matched task quality, reject this extension. No experiments were run in this checkpoint.
