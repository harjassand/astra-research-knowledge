# Trial-boundary obstruction for event-count energy

## Scope

This note isolates an objective mismatch in exact spike-time training. It does not claim a new neuroscience result or priority. The calculation uses a fixed finite list of differentiable candidate event times; it is independent of how those event times were obtained.

## Proposition 1: hard event cost is discontinuous at the trial boundary

Let an event have time `t(θ)`, with `t(θ0)=T` and `t'(θ0) != 0`. The energy charged for an event emitted during `[0,T)` is

`E(θ) = c 1{0 <= t(θ) < T}`, with `c > 0`.

Then `E` has a jump of magnitude `c` at `θ0`; it has no derivative there. Thus continuity of `t(θ)` alone does not make a per-event resource penalty differentiable. In particular, a mechanism that makes QIF spikes enter or leave only at the trial end can smooth spike-time losses while leaving exact emitted-spike count discontinuous.

Proof: since `t'(θ0) != 0`, for sufficiently small positive and negative perturbations of `θ0`, `t(θ)-T` has opposite signs. The indicator therefore has opposite one-sided values, whose costs differ by `c`. □

## Proposition 2: calibrated additive timing noise smooths expected event cost

Suppose the measured hardware event time is `t(θ)+η`, where `η ~ Normal(0, σ²)`, `σ>0`, and charge `c` if the perturbed event lies in `[0,T)`. Its expected cost is

`Eσ(θ) = c [ Φ((T-t(θ))/σ) - Φ(-t(θ)/σ) ]`.

If `t` is continuously differentiable, then

`dEσ/dθ = (c/σ) [ φ(t/σ) - φ((T-t)/σ) ] t'(θ)`,

where `φ, Φ` are the standard normal density and CDF. Hence `Eσ` is continuously differentiable for each positive `σ`. If the lower boundary is many `σ` away (`t >> σ`), its contribution is negligible and the terminal-boundary term is approximately `-(c/σ) φ((T-t)/σ)t'(θ)`.

Proof: integrate the Gaussian density over `-t <= η < T-t`, then differentiate the closed form. □

## Quantitative margin statement

For an event whose unperturbed time is at least `m` from both boundaries, `m>0`, the expected event cost differs from its deterministic cost by at most `2c Φ(-m/σ)`. For an event at least `m` outside `[0,T)`, its expected cost is at most `c Φ(-m/σ)`. These follow from the two Gaussian tail probabilities. The exact cost-gradient magnitude at the terminal boundary scales as `c |t'|/(σ sqrt(2π))`; therefore the smoothing is not uniformly well-conditioned as `σ -> 0`.

## Consequence and limits

This gives a candidate way to train against *expected* spike energy when repeat measurements support an additive Gaussian timing-jitter model. It does not optimize worst-case energy, does not establish that device noise is independent Gaussian jitter, and does not cover parameter drift, event-dependent variance, correlated jitter, or changes to hidden network state. The theorem only concerns the charged event itself. It also does not establish that the gradient can be estimated cheaply on a particular neuromorphic device.

## Decisive experiment

On the same device and trials, repeatedly measure each candidate neuron's event time and energy. Fit `σ` using calibration repeats only. Compare (i) the published QIF time-loss objective, (ii) a direct hard event-count penalty with a disclosed nonsmooth optimizer, and (iii) the Gaussian-convolved event cost above. Hold task accuracy and output first/second-spike margin fixed; evaluate energy and timing on held-out inputs and repeated hardware runs. The mechanism is falsified for the intended interface if the calibrated Gaussian model fails to predict held-out event probabilities/cost, or if (iii) does not lower measured energy at matched accuracy and margin. Charge repeated acquisition trials, training event count, latency, device energy, and any reset cost.
