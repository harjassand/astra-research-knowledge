# Reprogrammable domain-wall resonance in architected materials

## Result

The 2026 domain-wall-lattice work gives a concrete static mechanism: proportional biaxial strain reshapes a quartic Landau potential and globally programs motif-rotation walls in one architected material. I derived a conditional dynamic extension with a precise response: on the symmetric double-well branch, an isolated wall in an inertial one-field material has an exact localized shape resonance at `sqrt(3)/2` of the uniform-phase continuum threshold. Its frequency survives any additive local tangent-stiffness disorder of norm below one-half in the natural dimensionless Hessian. This is a complete mathematical result for a declared continuum model, and a useful go/no-go design worksheet.

The physical material transfer is **UNKNOWN**. The source's pseudo-dynamics treat position as a mathematical parameter and explicitly do not model time evolution. No source demonstrates that its motif-rotation field has the inertial law needed here, and the 10-cell experimental device is too short to satisfy the proposed 53-cell continuum-resolution gate. The high-upside consequence is a load-rewritable, wall-localized vibration/sensing mode; it is not yet a verified metamaterial capability.

## Source mechanism and exact construction

Zhang et al. (2026) give a static functional with gradient penalty and a load-dependent quartic `V_L(phi)`, where `phi` is motif rotation. Their first integral maps a static profile to a fictitious-particle trajectory; they emphasize that this coordinate is not physical time. Biaxial-load ratio changes the potential symmetry and global compatibility constraint, creating, moving, inverting, and annihilating domain walls. The paper compares continuum theory, simulation, and experiment for selected patterns, reports a critical system length `N_x^p=4` for its design, and demonstrates encoded displays. It also identifies finite-size effects, material nonlinearity, fabrication imperfections, and competing modes near regime boundaries. Those are the static source results, not validation of the spectral prediction below. [Primary article](https://www.nature.com/articles/s41467-026-73096-y).

Specialize the symmetric double-well branch to

```text
E[phi] = integral [kappa/2 * phi_x^2 + lambda/4 * (phi^2-v^2)^2] dx,
rho * phi_tt = -delta E/delta phi,
```

where `kappa, lambda, v, rho > 0`. The exact minimizing wall is
`phi_K(x)=v tanh((x-x0)/ell)`, with `ell=sqrt(2*kappa/(lambda*v^2))`. The energy is `2*sqrt(2*kappa*lambda)*v^3/3`. Linearizing the inertial equation around this static solution and setting `y=(x-x0)/ell` produces

```text
H = -d^2/dy^2 + 4 - 6 sech(y)^2,
E psi = H psi,     E = 2 rho omega^2/(lambda*v^2).
```

Factorization gives spectrum `{0,3} union [4,infinity)`: the zero mode moves the wall; the unique positive bound mode has `E=3`; uniform phases have bulk spectrum starting at `E=4`. The derivation and its bound-state/scattering proof are in [the proof note](proofs/phi4_wall_mode.md).

The source's symmetric quartic can be written `V_L=f0+(f2/2)phi^2+(f4/4)phi^4`, with `f2<0<f4`. Under the extra inertial assumption, this gives the measurable design formulas

```text
ell = sqrt(2*kappa/(-f2)),
omega_wall^2 = -3*f2/(2*rho),
omega_bulk_edge^2 = -2*f2/rho,
omega_wall/omega_bulk_edge = sqrt(3)/2 = 0.8660254...,
omega_wall * ell = sqrt(3*kappa/rho).
```

So tuning toward the bifurcation softens the predicted resonance like `sqrt(-f2)` while widening the wall like `1/sqrt(-f2)`. The product law exposes a physical design tradeoff: a low-frequency wall mode needs a broad wall and enough material length to resolve it.

For the ideal scalar continuum, the same factorization maps plane waves to exact Jost states and gives zero reflection above the bulk threshold. The wall also carries the subgap mode, which could serve as a reconfigurable mechanical resonance or defect-sensitive readout. Ordinary displacement acoustics may couple to other cell motions, so this scattering prediction remains model-conditional.

## Disorder certificate and scale gate

Let a real bounded perturbation `W(y)` act additively on the dimensionless squared-frequency Hessian. If `||W||_infinity < 1/2`, the radius-`1/2` Riesz contour around `E=3` remains in the resolvent set. Its spectral projection retains rank one, placing the perturbed resonance in `[3-delta,3+delta]`; all other spectrum is contained in the `delta`-neighborhood of `{0} union [4,infinity)`. The wall mode remains isolated from the bulk spectrum by at least `1-2delta` in squared-frequency units. This is disorder robustness with respect to one explicit operator norm. A geometric tolerance does not automatically yield that norm bound, and disorder in gradient stiffness, inertia, or coupling to other fields is outside the theorem.

At `delta=0.1`, the model predicts `E_wall in [2.9,3.1]` and the remaining continuum begins no lower than `3.9`. Frequencies divided by the clean bulk-edge frequency therefore put the wall resonance in `[0.85147,0.88034]`, with the bulk edge at or above `0.98742`. The minimum remaining separation is `0.10708` times the clean bulk edge. These numbers are reproduced in [the calculation](code/wall_mode_calculation.py) and [its output](code/wall_mode_calculation_output.json).

For a finite specimen, requiring less than 1% wall-amplitude tail at each end needs `D >= 5.2933 ell`. A proposed continuum-resolution gate of at least ten cells per wall width requires `h <= 0.1 ell`, where `h` is cell pitch. Together these imply `D/h >=52.94`, hence at least 53 cells across the wall-normal direction. The recent paper's 10-cell phase-diagram specimens do not meet this conservative continuum gate; a discrete-lattice spectrum may still exist, but it needs its own derivation. The 53-cell figure is a declared engineering tolerance, not a theorem about all discrete metamaterials.

Uniform viscous damping further needs charging. In a low-loss oscillator approximation, the wall peak has `Q≈rho*omega_wall/eta`; to keep its full linewidth below the clean wall-to-bulk frequency separation requires `Q>omega_wall/(omega_bulk_edge-omega_wall)≈6.46`. This is a proposed measurement gate; the published static response contains no such loss data.

## Falsification and experiment

Use one metamaterial geometry in a load region where the measured static profile is close to an isolated symmetric wall and away from competing phase boundaries. Fit the static motif-rotation profile and quartic potential to obtain `ell`, `v`, and `f2`; calibrate cell inertia independently; and measure the loaded local tangent Hessian to bound `delta`. Then apply a low-amplitude chirp and record cell rotations with high-speed imaging or laser vibrometry. Compare the wall state with the same specimen in a uniform phase at the same material batch and fixture. Sweep the global load through wall creation and annihilation and test whether the localized peak appears and disappears with it.

The proposed model is rejected for the specimen if (i) the peak is not localized at the wall, (ii) its frequency ratio disagrees with `sqrt(3)/2` beyond measured parameter and finite-size errors, (iii) the supposedly additive Hessian perturbation cannot be bounded below `1/2`, or (iv) damping prevents resolving the peak. Before interpreting that rejection as failure of the material, first check that the loaded field really is scalar, the walls are separated, and `ell/h` is large enough; otherwise the test needs a discrete coupled-cell model. Required acquisitions are static geometry/profile metrology, force-displacement curvature, effective modal mass, local stiffness-variation mapping, full sample length/cell pitch, loss/ringdown, and boundary-condition checks. No lab time, specimen cost, or instrument cost is reported by the sources; these remain uncosted.

## Counterexample and scope boundary

Static equilibria do not fix dynamics. Adding a different mass density, viscoelastic loss, or coupling from motif rotation to a separate displacement field leaves the same static `E[phi]` and kink but changes its resonance or removes the simple scalar spectral formula. The 2026 article explicitly uses a spatial pseudo-time analogy, and it does not claim a measured inertial resonance. Thus neither its experimental patterns nor its static phase diagram licenses this new response in nature. No source-reported response is being relabeled as a theorem.

Earlier mechanical-metamaterial audits in this workspace covered topology versus edge stiffness, passive cycle work, Li-anode interface behavior, fracture-flow survival, and matched-port thermal reciprocity. This report uses none of their mathematical results and does not repeat their measurement interfaces. The source article itself cites earlier “programmable and robust static topological solitons,” so the generic existence or robustness of static walls is not a novelty claim. The exact `phi^4` fluctuation operator is classical; the candidate contribution is only the conditional design composition with recent strain-programmed walls. Priority remains `UNKNOWN`.

## Evidence status

- **Source-reported:** the 2026 paper's static functional, Landau coefficients/load control, pseudo-time distinction, finite-size effects, and measured static patterns/displays.
- **Internally derived:** kink minimization, exact Hessian spectrum, internal-mode/continuum ratio, reflectionless scalar scattering, additive-Hessian disorder margin, near-transition frequency/width tradeoff, and the 53-cell scale gate.
- **Conditional model prediction:** a load-rewritable subgap motif-rotation resonance in a material whose actual small-signal inertia and Hessian match the stated scalar field.
- **UNKNOWN:** physical inertial law, local constitutive acquisition, damping, finite-size/discrete-lattice correction, cross-field coupling, fabrication tolerance, external validation, and novelty/priority.

Read `source_notes/ROUTE_AND_SOURCES.md` for scoped Astra retrieval, prior-output boundary, source read depth and uninspected supplementary/data boundaries. The complete claim ledger is [CLAIMS.json](CLAIMS.json).
