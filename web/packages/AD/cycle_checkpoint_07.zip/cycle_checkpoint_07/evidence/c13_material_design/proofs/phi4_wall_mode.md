# Exact wall-mode result and disorder margin (conditional field model)

## Interface

Assume a one-dimensional internal order parameter `phi(x,t)` has energy and inertial dynamics

```text
E[phi] = integral_R [kappa/2 * phi_x^2 + lambda/4 * (phi^2-v^2)^2] dx,
rho * phi_tt = -delta E/delta phi,
```

with `kappa, lambda, v, rho > 0`, no damping, and far-field phases `phi(-infinity)=-v`, `phi(+infinity)=+v`. This is an explicit specialization of the symmetric quartic-gradient continuum model in Zhang et al. (2026); the paper's static calibration does not establish this inertial law.

## Static wall

The Euler--Lagrange equation is `-kappa phi_xx + lambda phi(phi^2-v^2)=0`. Put

```text
ell = sqrt(2*kappa/(lambda*v^2)),
phi_K(x) = v*tanh((x-x0)/ell).
```

Since `(tanh y)''=-2*tanh(y)*sech(y)^2` and `tanh^2-1=-sech^2`, substitution verifies the equation exactly. The energy identity

```text
kappa/2 * phi_x^2 + lambda/4*(phi^2-v^2)^2
= 1/2 * (sqrt(kappa)*phi_x - sqrt(lambda/2)*(v^2-phi^2))^2
  + sqrt(kappa*lambda/2)*phi_x*(v^2-phi^2)
```

shows that every finite-energy path from `-v` to `+v` costs at least the integral of the last term, `(2*sqrt(2*kappa*lambda)/3)*v^3`; the kink attains equality. This proves it minimizes energy in that topological sector. Its tails satisfy `1-|phi_K|/v = 1-tanh(|x-x0|/ell)`, so a 1% phase-amplitude tail requires `|x-x0|/ell >= atanh(0.99)=2.64665`; this is a geometric truncation calculation, not a boundary-value error estimate.

For the symmetric quartic specialization of the recent source, write `V_L(phi)=f_0+(f_2/2)phi^2+(f_4/4)phi^4`, with `f_2<0<f_4`, and use gradient energy `kappa phi_x^2/2`. Then `lambda=f_4`, `v^2=-f_2/f_4`, and the response parameters satisfy

```text
ell = sqrt(2*kappa/(-f_2)),
omega_shape^2 = -3*f_2/(2*rho),
omega_bulk_edge^2 = -2*f_2/rho,
omega_shape * ell = sqrt(3*kappa/rho).
```

Thus load-softening (`f_2 -> 0-`) lowers the model resonance as `sqrt(-f_2)` but broadens the wall as `1/sqrt(-f_2)`. This inverse frequency/width law is exact within the stated one-field model; `f_2(load)` and `rho` must be independently acquired for a specimen.

## Linear mode calculation

Set `phi=phi_K+eta(x) exp(-i omega t)` and keep terms linear in `eta`. With `y=(x-x0)/ell`, the eigenproblem becomes

```text
H psi = E psi,
H = -d^2/dy^2 + 4 - 6 sech(y)^2,
E = 2*rho*omega^2/(lambda*v^2).
```

For `A_m=d/dy+m*tanh(y)`, `A_m^dagger=-d/dy+m*tanh(y)`,

```text
A_2^dagger A_2 = -d^2/dy^2 + 4 - 6 sech(y)^2 = H,
A_2 A_2^dagger = A_1^dagger A_1 + 3,
A_1^dagger A_1 = -d^2/dy^2 + 1 - 2 sech(y)^2.
```

The first factorization gives the zero mode `psi_0=sech(y)^2`. The partner operator has ground state `sech(y)` at eigenvalue 0 and continuous spectrum starting at 1; mapping its ground state through `A_2^dagger` gives `psi_1=sinh(y)*sech(y)^2` at `E=3`, while its continuum maps to `[4,infinity)`. These exhaust the spectrum. Far from the wall, the dispersion is `omega(q)^2=(kappa*q^2+2*lambda*v^2)/rho`, whose edge is `omega_b=sqrt(2*lambda*v^2/rho)`. Hence the localized mode is

```text
omega_1 = sqrt(3*lambda*v^2/(2*rho)) = (sqrt(3)/2)*omega_b.
```

The relative gap from this mode to the bulk threshold is `1-sqrt(3)/2 = 0.1339746...` of `omega_b`. Applying the same Darboux operators to a plane wave gives the Jost state and transmission coefficient `t(p)=((p+i)(p+2i))/((p-i)(p-2i))` for `p=q*ell`; the left/right asymptotic factors give `|t|=1` and zero reflection. This is a property of the scalar, lossless continuum model, not a claim of transparency for ordinary acoustic displacement waves in a printed coupon.

## Bounded tangent-stiffness disorder certificate

Let fabrication or constitutive error enter the *linearized* dimensionless operator additively as a self-adjoint multiplication operator `W(y)` with `||W||_infinity <= delta`. The unperturbed spectrum is `{0,3} union [4,infinity)`. The circle centered at `3` with radius `1/2` is at distance at least `1/2` from this spectrum. For `delta<1/2`, the resolvent Neumann series keeps that circle in the resolvent set along `H+sW`, `0<=s<=1`; therefore its Riesz projection has constant rank one. There remains exactly one simple eigenvalue in that circle. The spectral perturbation bound places it in `[3-delta,3+delta]`; the rest of the spectrum is contained in the `delta`-neighborhood of `{0} union [4,infinity)`. Thus the mode remains isolated from both the low band and bulk continuum, with dimensionless upper separation at least `1-2*delta` from the continuum. No spatial-independence assumption on `W` is needed, but the model must keep the gradient coefficient and inertia fixed; coefficient disorder in those terms is outside this certificate.

For `delta=0.1`, the unique mode satisfies `E in [2.9,3.1]`; the perturbed continuum cannot begin below `3.9`. Frequencies normalized by `omega_b` therefore obey `omega_1/omega_b in [sqrt(2.9/4),sqrt(3.1/4)] = [0.85147...,0.88034...]`, while the bulk edge is no lower than `sqrt(3.9/4)=0.98742...`. The squared-frequency perturbation is a *measurable model input*: it must bound the local tangent stiffness error after the wall is loaded. A bound on geometric fabrication error alone does not imply it.

## Stability and finite-device qualifications

The whole-line kink minimizes the stated energy in its topological sector, modulo translation. The spectrum includes a neutral translation mode, so arbitrary disorder can move/pin the wall; the theorem above certifies the shape-mode frequency, not a fixed wall center or the stability of a finite coupon under all boundary loads. A finite sample needs boundary conditions that support/pin the wall, and its measured Hessian must be checked separately. A simple 1%-tail truncation needs about `5.30 ell` of total length. To keep a continuum discretization parameter `a/ell` at or below `0.1` (a proposed convergence gate, not a theorem), that span needs at least about 53 unit cells. If the reported `N_x=10` specimens do not meet the measured width ratio, this continuum mode prediction cannot be transferred without a discrete-lattice derivation.

More explicitly, let `h` be cell pitch and `D` specimen length along the wall-normal direction. The two proposed gates `h/ell<=0.1` and `D>=2 atanh(0.99) ell` are jointly feasible only if `D/h >= 2 atanh(0.99)/0.1 = 52.933...` (53 cells after rounding). For a chosen `D`, they require `56.0*kappa/D^2 <= -f_2 <= 0.02*kappa/h^2`. This is a transparent continuum-scale design window, not a universal minimum cell count for discrete metamaterials.

## Counterexample to an unqualified material claim

Static energy and equilibrium do not determine small-signal spectra. Two specimens may share `E[phi]` and the exact same `phi_K` while having different kinetic density `rho`, damping `eta`, or coupling to an additional displacement field; they then have different resonance frequencies, widths, or hybridized modes. In particular, the source paper's static pseudo-dynamic variable uses space as a mathematical parameter, explicitly not physical time. Therefore its reported phase diagram, wall patterns, and mechanical display do not imply the predicted internal resonance. Observing no localized peak, a peak outside the certified interval, or a local measured Hessian error `delta>=1/2` rejects this proposed design certificate for that specimen/model.
