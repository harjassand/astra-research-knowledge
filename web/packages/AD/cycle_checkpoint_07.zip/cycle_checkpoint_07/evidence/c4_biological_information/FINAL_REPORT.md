# Cycle 4: dynamic release nuisance and the clone-measurement boundary

## Verdict

I did not find a defensible new plasma-only capability for recovering whole-tumour clone growth when clone-specific release is an unrestricted time-varying nuisance. A known clearance kernel, arbitrarily deep sequencing, many mutations per clone, and exact mass balance recover the *molecular source flux* `release × copy number × cell abundance`; they do not split that product. A direct accessible-cell channel can identify local relative clone growth despite unknown *constant* marker copy number, but the resulting conditional odds-ratio argument is standard and closely adjacent to published single-cell clone-fitness and competition work. Its boundary is precise and useful; novelty remains `UNKNOWN` and should not be reported as a new theorem or clinical capability.

The best defensible experimental design is an accessible-compartment, randomized split-culture / organoid assay with cell-associated genomic counts at matched endpoints, a sample-wide extraction spike-in, and a small single-cell copy-number check. It estimates a treatment's effect on relative net growth in the sampled population. It does not infer absolute cell fractions, separate birth from death, validate an inaccessible lesion, or recover a whole-tumour trajectory from plasma.

**Provenance.** The inherited information-starvation statements are taken from the selective Astra refresh at `work/astra_refresh/0132f3d37f9ba3b0ab0de07779ef3e17e5768e30/state/2026-10-08-information-starvation-frontier/RESULT_AND_RESTART.md` and the local prior `work/agents/cancer_evolution/cycle4_information_starvation_attack.md`. Earlier-cycle cancer observations come from `work/agents/cancer_evolution/CYCLE3_REPORT.md`. The Astra source pins named by the current mandate are original commit `8ede33c2f09a8abe07b430892b3ac4bb71c27c83` and refresh `0132f3d37f9ba3b0ab0de07779ef3e17e5768e30`; no broad index card is used as a proof premise here.

## The exact plasma-only obstruction

For clone `j`, let `X_j(t)>0` be cell abundance, `c_{jℓ}` the stable copy multiplicity of marker `ℓ`, and `q_j(t)` the clone-specific molecule-release/recovery rate per cell. Even granting exact mass-balance recovery of the molecular source flux, the best-case model is

```text
F_{jℓ}(t) = c_{jℓ} q_j(t) X_j(t).
```

If plasma concentration is observed rather than source flux, allow any common clearance kernel `K`:

```text
Z_{jℓ}(t) = integral_0^t K(t-s) F_{jℓ}(s) ds.
```

For any continuously differentiable `φ_j`, define

```text
X'_j(t) = exp(φ_j(t)) X_j(t),
q'_j(t) = exp(-φ_j(t)) q_j(t).
```

Then every source flux and every concentration trajectory are unchanged, for every marker and every sequencing depth, while the per-capita net rate changes from `r_j(t)=d log X_j/dt` to `r'_j(t)=r_j(t)+φ'_j(t)`. Choosing `φ_R-φ_S = a t` shifts relative clone fitness by any constant `a` with no change in the observation law. This is an exact non-identifiability, not a low-signal approximation. Unknown clearance makes the inverse problem harder; measuring clearance exactly does not remove this release-abundance symmetry.

The same argument applies to arbitrarily many private variants if they share a clone-level release factor. Within-clone marker ratios can identify relative marker copy profiles, but all such channels retain the common multiplier `q_j(t)X_j(t)`. A stable normal-cell or total-cfDNA reference does not bound clone-specific release. If the treatment can change clone-specific release or its lag profile, treatment perturbations alone do not act as an instrument: the nuisance can change with the treatment history and preserve the same output law.

If the relative release drift is bounded, the identified set becomes quantitative. For source fluxes (or fluxes recovered under a justified mass-balance model), put

```text
z(t) = log(F_R(t)/F_S(t))
     = constant + log(X_R(t)/X_S(t)) + log(q_R(t)/q_S(t)).
```

If `|d log(q_R/q_S)/dt| <= L` over an interval of length `T`, then the interval-average relative net growth lies in

```text
[(z(T)-z(0))/T - L, (z(T)-z(0))/T + L].
```

With a finite-sample confidence interval `[a,b]` for the measured slope, expand it to `[a-L,b+L]`. The sign is certified only if this interval excludes zero. Without an independently measured/controlled bound `L`, the identified set is all of `R`. A common time-varying release factor cancels (`L=0`), but clone-differential release does not.

This statement is intentionally about the molecular signal and local population. It makes no claim about a refuge with zero sampling probability.

## The strongest accessible design and its exact interface

For a preclinical organoid, perfused culture, or repeatedly accessible lesion, take matched cell-associated samples at baseline and after a preregistered perturbation/control interval. Fully lyse each aliquot under the same protocol; sequence clone-specific private markers with UMI/duplex counting; add a sample-wide exogenous recovery standard; and use a small single-cell DNA/FISH panel to check whether marker copy multiplicities changed. Randomize sister aliquots from the same initial culture to treatment and control. Plasma/supernatant can be collected in parallel to measure how release changes, but it is not the state-identifying channel.

For two clones `R,S`, suppose the measured marker count at time/arm `k` has mean

```text
E[Y_{j,k}] = a_k d_j X_{j,k},
```

where `a_k` is an arbitrary sample-wide amount/library factor and `d_j` is an unknown but time/arm-invariant product of clone marker multiplicity and clone-specific assay recovery. Conditional on the total clone-marker count in sample `k`,

```text
Y_{R,k} | M_k ~ Binomial(M_k, p_k),
logit(p_k) = log(d_R/d_S) + log(X_{R,k}/X_{S,k}).
```

Therefore

```text
logit(p_1) - logit(p_0)
  = log(X_{R,1}/X_{S,1}) - log(X_{R,0}/X_{S,0}),
```

with no need to know copy number, extraction scale, or extracellular shedding. Under constant per-capita net rates during a duration `T`, this equals `T(r_R-r_S)`. In randomized sister cultures, the treatment-minus-control contrast of these log-odds changes equals

```text
T{(r_R^T-r_S^T) - (r_R^C-r_S^C)}
```

when the starting split is balanced. With imperfect balance, include an acquired baseline sample and block/random-effect term; the endpoint contrast remains estimable from replicated randomized wells. A 2-by-2 clone-by-condition table has the usual log odds ratio; Fisher's exact test gives finite-sample inference for the null of no relative response. A multinomial/logistic model handles more clones and times, with sample effects conditioning out `a_k`.

The theorem fails exactly when `d_j` changes differentially across time or arms. Then the measured contrast equals cell selection plus `Δ log(d_R/d_S)`. A copy-number shift, treatment-dependent allele dropout, or genotype-specific extraction change can imitate any relative-growth effect. A reference spike removes common extraction variation, not genotype-specific variation; single-cell CN/FISH is a paid stability check, not a universal guarantee. If its finite-data bound on differential marker/recovery drift over the interval is `B`, expand a confidence interval for the observed log-odds change by `[-B,+B]`. If no finite bound is justified, report `UNKNOWN`.

This is local to the tissue/culture aliquots actually sampled. The sampling frame must be stated, and spatial inclusion must be measured rather than assumed. It cannot repair a sanctuary compartment with unknown or zero inclusion.

## Finite-sample price and falsifiable prediction

The count likelihood is exact conditional on input totals; it does not grant a noiseless log derivative. For one clone under exponential dynamics and equal assay factors at two times, independent counts `Y_0~Pois(A)` and `Y_1~Pois(A exp(gT))` satisfy

```text
Y_1 | (Y_0+Y_1=m) ~ Binomial(m, logistic(gT)),
```

which removes the unknown amplitude `A`. This conditioning is useful for one clone's rate only when the sample-wide factor is known or removed; for clone selection the within-sample multinomial log-odds contrast above is the appropriate nuisance cancellation. At low clone-marker fraction `p`, two equally sized samples have local variance approximately `2/(M p)` for the log-odds change. A two-sided 5% test with 80% power therefore needs roughly

```text
M >= 15.7 / (p β^2) independent marker opportunities per arm,
```

for a small target log-odds shift `β`. For example, at molecule fraction `p=10^-4` and shift `β=0.4`, the approximation gives about 981,110 opportunities per arm; 5,531 opportunities still give a 57.5% probability of zero molecules, and about 29,956 are needed just for 95% probability of at least one. `p` is the measured *molecule-weighted marker fraction*, not an assumed cell fraction; unknown copy number prevents converting `p` to a cell fraction. Error/background molecules increase this cost and can restore quadratic low-signal scaling. For a single-locus marker, even seeing one molecule with 95% probability requires about `3/p` independent opportunities; this is the physical zero-count floor.

The falsifiable preclinical test is to preregister a resistant and a susceptible lineage marker, split one baseline organoid culture randomly into matched treatment/control wells, take blinded cell-associated genomic samples after the same duration, and estimate the log odds ratio from UMI counts. Add a single-cell CN/FISH subset and exogenous spike-in; collect supernatant in parallel. The prediction is that cell-associated log-odds contrasts remain invariant to arbitrary *common* sample recovery and to static unknown clone copy, while supernatant-based estimates move with the measured clone-specific release/fragmentation response. Failure of cell-associated contrasts to agree with independent viable-cell or barcode counts after the predeclared CN/recovery checks falsifies the assay model. The paired supernatant comparison tests whether the reset assumptions hold; it does not turn plasma into a whole-tumour cell counter.

## Baseline comparison and novelty boundary

- **Branching-process baseline:** For finite populations, endpoint clone counts are random and extinction/overdispersion matter. A fully informed multitype birth-death or Wright–Fisher likelihood with the same clone markers, arms, and sampling budget is the strongest baseline. The log-odds method estimates net relative response in the large-count/short-window regime; it does not separately identify birth and death or beat a fully specified branching model.
- **CTMDP baseline:** A CTMDP with known state and treatment transitions is a clairvoyant control upper bound. With observed cell-associated counts, use a partially observed CTMDP with the same posterior and measurement cost. Neither solver resolves an unidentifiable observation map; the release nuisance must be constrained or an independent cell-associated observation acquired first.
- **ctDNA deconvolution baseline:** Standard copy-aware deconvolution can recover clonal fraction under its copy, purity, and transfer assumptions. It cannot infer relative cell growth under arbitrary differential release. The proposed contrast avoids an absolute copy-number calibration only by switching to matched cell-associated samples and assuming marker copy/recovery stays constant; it gives up noninvasive whole-tumour coverage.
- **Prior art:** Serial single-cell clone-fitness inference and experimental clone competition are already established, and recent ovarian-cancer work tracks clone-specific structural variants in serial cfDNA. The conditional multinomial/odds-ratio calculation is standard statistics. I claim no new biological mechanism, theorem priority, or clinical utility.

## Primary evidence and data boundary

The biological threat to a stable plasma transfer factor is observed directly. A 2026 in-vitro primary study reports that chemotherapy increases per-cell cfDNA release and that cisplatin-sensitive and resistant cells have distinct release kinetics and fragment distributions ([PubMed record](https://pubmed.ncbi.nlm.nih.gov/42738856/)). SPRINTER's matched NSCLC study calculated clone-specific ctDNA shedding indices and found them correlated with inferred S-phase fractions, evidence that clone shedding can track proliferation itself rather than only clone size ([Nature Genetics paper](https://doi.org/10.1038/s41588-024-01989-z)).

The 2025 ovarian CloneSeq-SV study had serial cfDNA for 18 recurrence-tracked patients (mean 7.9 time points; range 3–13), but only three cases with second-timepoint single-cell tissue. It normalized inferred clone frequencies to sum to one at each time and explicitly discusses unobserved clones, tumor-site heterogeneity, and drug penetration as limitations. One case had both clones B and E in interval tissue while only B was detectable in contemporaneous cfDNA; E appeared in later cfDNA ([primary Nature article](https://www.nature.com/articles/s41586-025-09580-0), especially its Results and Methods). The paper's Synapse processed analyses are listed at `syn66399325`; raw sequencing is controlled at dbGaP `phs002857.v3.p1`. I did not download controlled raw data.

Direct clone-fitness inference from serial single-cell genomes and validation by competitive mixtures predates this design ([Nature 2021](https://doi.org/10.1038/s41586-021-03648-3)). A 2026 primary sampling-limit study combined 5,238 plasma samples and reported median input 5,531 genome equivalents; at 0.01% molecule VAF fewer than 10% of samples supported its stated 95%-detection criteria ([Journal of Liquid Biopsy](https://doi.org/10.1016/j.jlb.2026.100480)). These sources support the assay boundary and finite-input warning, not novelty.

## Compact continuation / failed routes

1. **Mass balance plus known clearance:** rejected as a separator of cells from release. It recovers `q_j X_j`; the gauge symmetry remains. A tracer can pay for `K`, but cannot measure clone-specific `q_j` without an independent channel.
2. **More private variants / fragmentomics / common cfDNA reference:** rejected as a uniform solution. Markers sharing clone-level release add precision or reveal copy/fragment patterns, but retain the `q_j X_j` gauge. A normal-tissue reference is not a clone-specific release reference.
3. **Treatment switching with plasma-only slopes:** rejected without repeatable reset kernels. Treatment can alter release and fragmentation in a clone- and history-dependent way; an AB/BA symmetry is valid only if the same per-cell release kernel recurs at matched switch phase. That is a measured premise, not free.
4. **Accessible cell-associated assay:** retained as a preclinical design boundary, not a novelty claim. It identifies local relative net growth if clone marker copy and extraction response are stable or bounded. To continue, obtain a small public processed paired series or run an accessible organoid experiment and audit copy/recovery drift against a fully informed branching likelihood. Stop any whole-tumour/cfDNA claim if a finite spatial-inclusion or transfer-drift bound is absent.

## Status

Exact conditional identifiability theorem for the accessible cell-associated model; exact plasma-only non-identifiability under unrestricted clone-specific release; finite-count design approximation; primary-source support for the nuisance. No external mathematical review, formal proof assistant, empirical reanalysis, wet-lab validation, clinical recommendation, or priority clearance.
