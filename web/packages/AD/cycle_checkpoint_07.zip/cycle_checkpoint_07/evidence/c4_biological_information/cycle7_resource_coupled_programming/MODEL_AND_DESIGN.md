# Model, architecture, and cost ledger

## Architecture change

The candidate controller is a CAR-T cell expressing the *Neurospora crassa* cellobiose transporter CDT-1 and intracellular β-glucosidase GH1-1. Cellobiose enters the engineered T cell and is hydrolyzed into glucose units; the intended control advantage is that selected tumor cells cannot use the same extracellular substrate. This replaces a shared-resource capture strategy with a nominally private substrate channel. The relevant resource is still finite: engineered T cells consume it, concentration may decay or diffuse away, and transporter/enzyme expression can impose burden.

The architecture is anchored to a published primary result: Miller et al. (2026) report cellobiose-supported viability, proliferation, cytokine production, and cytotoxicity under glucose withdrawal, plus improved tumor control in mouse models. The report does not treat that source-reported result as an externally reproduced experiment or as evidence for every tumor type.

## Why this target survives the branch stop

The prior recombinase route had an already published high-cardinality parallel/series device, unverified product independence, and direct Bxb1 product inhibition. The source article itself attributes multi-device outputs to a product rule; the 2022 Bxb1 study documents intact attachment sites sequestering recombinase after another event. This cycle stops that route instead of trying to rescue its conditional compiler.

Nutrient orthogonalization changes the resource interface. The target-cell population can have unbounded or context-varying glucose uptake in the model without entering the cellobiose mass balance, provided the empirical exclusivity gate passes. Myeloid cells also take up substantial tumor glucose, so an ordinary shared-glucose model has competitors beyond the tumor cell itself. The 2026 cellobiose article reports the key biological premise in its studied systems; each new target model still requires its own uptake assay.

## Exact interface and control library

Use a finite dose grid selected from pilot uptake and kill curves. At each dose, culture the same engineered CAR-T product with the same antigen-positive targets, media volume, glucose level, oxygen, and assay horizon. To certify a finite target-reduction trajectory, measure or conservatively bound rates across the target/effector-density and activation range encountered during that reduction; do not transfer a single initial E:T slope across the whole trajectory without a check. Estimate:

1. The total cellobiose input rate needed to hold the concentration, including consumption and loss in the joint culture.
2. The viable target-cell log-count slope in the same well, with matched target-only and CAR-negative controls to separate baseline target growth from the treatment-specific net effect.
3. Residual cellobiose and labeled-carbon incorporation, so an apparent output effect can be checked against actual uptake.
4. Cellobiose use by target-only cells. Treat a nondetection as an upper bound, not as exact zero.

Direct paired outputs make expression heterogeneity and construct burden part of the measured response. A fluorescent cotransduction marker can aid sorting but is not used as a sufficient activity statistic. Context variation enters as a finite set (z\in\mathcal Z), and the LP takes the worst measured context at each schedule.

The robust formulation in [PROOF.md](PROOF.md) accepts a budget in substrate amount or carbon-equivalent amount. If carbon-equivalent budgets are used, one cellobiose molecule counts as two glucose-unit equivalents; this is bookkeeping only and does not assert equal ATP yield. The kinetic rates already charge uptake and biological conversion. Rate bounds must cover the full target/effector density and activation envelope that the schedule can reach; a point estimate at the initial E:T ratio does not certify a tenfold target reduction.

## Baselines receiving equal information

The same donors, target panel, E:T ratios, assay horizon, nutrient concentration grid, concentration monitoring, and biological replicate count should be used for:

- ordinary CAR-T under the declared shared-glucose levels;
- GLUT1-overexpressing CAR-T, which can improve glucose uptake but still draws from a pool used by other cells;
- GLUT5 CAR-T with fructose, where the target-panel fructose-uptake gate is measured rather than presumed;
- CDT-1/GH1-1 CAR-T with cellobiose;
- target-only and CAR-negative controls to estimate nutrient use, target growth, and nonspecific effects.

The comparison is a resource-versus-net-target-suppression frontier, not just a fluorescence or cytokine comparison. Report both total administered carbon equivalents and actually consumed substrate. The GLUT1 and GLUT5 alternatives have different vector sizes and metabolic costs; list those separately rather than falsely equalizing them by nutrient amount alone.

## Finite-noise acquisition cost

For (J) dose-context points and two bounded normalized endpoints (uptake fraction and target suppression fraction), (n) independent biological blocks per point give the conservative simultaneous Hoeffding radius

\[
\epsilon_n=\sqrt{\frac{\log(4J/\delta)}{2n}}.
\]

For (J=9), familywise failure probability (\delta=0.05), and absolute endpoint error (\epsilon=0.25), this bound requires (n=53) independent biological blocks per point. At (\epsilon=0.10), it requires (n=329). These are conservative sample counts; individual cells or technical wells within one donor are not independent donor blocks. A paired donor design may be analyzed more efficiently, but then its covariance model and variance estimates must be acquired and charged.

Total bench cost includes paired engineered/control constructs, viral production and transduction efficiency, cell expansion, target-cell culture, repeated nutrient concentration measurement, isotope tracing or equivalent uptake measurement, target-cell live/dead counting, donor blocks, and any concentration-clamp or medium-replacement setup. The theorem does not hide any of those inside (r) or (s): those are outcomes to measure, while the experimental resource required to learn them is separate.

## Context and memory gates

The steady-rate occupation model is allowed only if:

- pulse-order swap experiments at identical dose-time totals produce equivalent target-count and uptake outcomes within a preregistered margin;
- concentration settling is fast relative to each schedule segment, or transition segments are included as additional measured modes;
- cellobiose uptake by each target in the panel stays below its declared upper bound;
- the relevant CAR-T count and activation distribution stays within the assay's declared range;
- the kinetic response is measured in the same engineered construct, not transferred from a separate transporter-only strain.

If any gate fails, return `UNKNOWN` for the static certificate. An appropriate next model is a measured finite-state controlled process with states taken from direct antigen-activation or metabolic readouts; it is not justified to add latent states until such readouts and transition data exist.

The principal candidate stateful interface is now specified in [TEMPORAL_STATE_CONTROL.md](TEMPORAL_STATE_CONTROL.md). It treats the early methionine/TCR pulse as a state transition and later cellobiose provision as a separate control phase. Use the robust finite-state dynamic program there when pulse order changes output and direct state bins can be acquired. If state is only observed destructively, it can support model checking and open-loop schedule comparison, but not within-culture feedback.

## Evidence status

Theorems in [PROOF.md](PROOF.md) are internally proved under their displayed mathematical assumptions. The candidate biology and selected baseline results are source-reported from primary papers. No external proof review, wet-lab assay, public-data reanalysis, or novelty/priority search has established biological validity or originality of this application-specific certificate.
