# Cycle 7 result: a measured state-transition controller for staged T-cell metabolism

## Main result

The recombinase branch is stopped. An et al. (2026) already demonstrate parallel and sequential cell-ratio branching, and Zhang et al. (2022) establish Bxb1 product inhibition from intact attachment-site decoys. The earlier branching compiler therefore does not survive the source check.

The fresh control target is a staged T-cell nutrient program. A 2025 *Nature Immunology* primary study reports that methionine availability during the first 30 minutes of TCR engagement changes later signaling and T-cell exhaustion-related state through KCa3.1 R350 arginine methylation and Ca2+/NFAT1 control. A separate 2026 *Cell* primary study reports that CDT-1/GH1-1-engineered T cells use cellobiose under glucose withdrawal. Together these motivate an untested candidate: a short early methionine state-write, followed by cellobiose support under glucose limitation.

The mathematical result is a finite-state robust dynamic program using directly measured state transitions, per-stage nutrient-input vectors, and lower bounds on target log suppression. Backward induction yields the exact robust reachability value for an exact finite interface and a sufficient guarantee under simultaneous confidence bounds. A two-stage counterexample shows why equal total nutrient exposure cannot be compressed to dose-occupation fractions once early nutrient exposure writes state: methionine-then-fuel and fuel-then-methionine can have the same exposure counts yet different output. This counterexample is mathematical only, not a T-cell parameterization.

The controller does not use a linked fluorescent marker as an activity oracle. Candidate state coordinates are directly assayed KCa3.1 R350 methylation or NFAT1 localization, paired with viable effector/target counts and direct labeled-cellobiose uptake. If the state readout is destructive, only the open-loop schedule is credited. An adaptive policy is implementable only after validation of a non-perturbing measurement at the decision time.

## Decisive experiment

Within independent donor blocks, compare 30-minute antigen/TCR activation at 0.1 versus 0.03 mM methionine, then restore methionine and apply the same cellobiose/glucose-limited fuel schedule. Include reversed, constant, and cellobiose-only schedules with matched total nutrient input and exposure time. Measure the marker distribution after priming, whole-product carbon flux, effector viability, and serial target counts. Train on a preregistered subset, freeze the dynamic program and policy, and test held-out donors. The 0.1/0.03 mM and 30-minute contrast is source-anchored from Sharma et al.; applying it to CAR-T/cellobiose is an explicit experiment, not an assumed effect.

Falsifiers include no reproducible post-pulse state shift, no relationship between the early state and later cellobiose-supported suppression, equal outcomes for order permutations, failure of expression/context bounds to transfer, or held-out target suppression outside the frozen robust bound. The combined architecture is not established by either source and receives no clinical/safety interpretation.

## Evidence and scope

The 2026 correction to Sharma et al. fixes the Fig. 4d x-axis label, replaces the Fig. 5j survival data, and adds a missing Extended Data Fig. 10e axis label. The corrected Fig. 5j must be used for that result. No source data from either the methionine or cellobiose study were downloaded or reanalyzed in this cycle.

The static occupation LP and scalar resource barrier in [PROOF.md](PROOF.md) remain valid conditional tools but are standard; they are not presented as a novel capability. The dynamic-program theorem is also a standard robust finite-horizon construction applied to a proposed stateful T-cell interface. Application novelty and priority are `UNKNOWN`. See [TEMPORAL_STATE_CONTROL.md](TEMPORAL_STATE_CONTROL.md), [SOURCES.md](SOURCES.md), and [FALSIFIER_PROTOCOL.md](FALSIFIER_PROTOCOL.md) for the interface and costs.

## Verification

The state-DP toy tests check order sensitivity, optimizer recovery, and worst-case treatment of unresolved transitions. The existing static-frontier tests check only arithmetic and sampling formulas. Neither test suite provides biological evidence.
