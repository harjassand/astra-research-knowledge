# Candidate cycle-7 extension: two-phase immune-cell nutrient control

## Why this is the next mechanism

The parallel/serial recombinase compiler is stopped: An et al. (2026) already report parallel Bxb1 and serial Bxb1/TP901 cell-fate branching, and Zhang et al. (2022) show that unreacted attP can sequester Bxb1 after another module recombines. Neither reporter expression nor independent marginal recombination probabilities is treated as a same-cell activity oracle here.

The strongest dynamic clue in the immunometabolism sources is that the nutrient control input can write cell state early. Sharma et al. (2025) compare 0.1 mM with 0.03 mM methionine during the first 30 minutes of TCR engagement, then restore 0.1 mM methionine for 24 hours; the early condition changes later T-cell signaling/fate and is mechanistically linked to KCa3.1 R350 arginine methylation, Ca2+ influx, and NFAT1. The article received a 2026 correction: an x-axis label in Fig. 4d, the Fig. 5j survival dataset, and a missing Extended Data Fig. 10e axis label were corrected. The first-30-minute pulse experiment is not among the stated corrections.

Separately, Miller et al. (2026) report that CDT-1 plus GH1-1 lets mouse and human CAR T cells use cellobiose during glucose withdrawal. The proposed combination is therefore a falsifiable staged design, not a source-reported result: an adequate methionine pulse during activation to write an early state, followed by private-fuel cellobiose to support later function. No claim is made that these two interventions synergize; the combination must be measured directly.

## Finite state-transition interface

Use stages chosen before data collection. One candidate is a 30-minute cognate-antigen activation stage followed by two or more fixed-duration effector stages in glucose-limited co-culture. At every decision boundary, the state bin must be directly acquired from the same construct and donor block. Candidate state coordinates are KCa3.1 R350 methylation and nuclear NFAT1, plus directly observed viable effector/target counts and residual nutrient concentrations. A fluorescent cotransduction marker is not sufficient. State assays that destroy cells must be performed on a randomized sister aliquot; they do not enable single-cell feedback on the assayed cells.

An interface row is indexed by stage t, measured state bin x, nutrient action a, and declared context z (donor, antigen density/target line, oxygen, and activation protocol). For each row, record a fixed charged input vector c+ obtained by taking the componentwise upper bound over contexts hidden from the controller, and a finite set O(t,x,a) of possible paired outcomes (x', r-). Here x' is the next directly measured state bin and r- is a lower target log-suppression increment, log(U_t/U_(t+1)), consistent with that outcome. The pair preserves measured correlation between hidden context, state transition, and response; it is not the Cartesian product of separate coordinate extremes. The vector c+ is the upper external substrate amount required for the action, including concentration-clamp make-up; derive it from the measured balance of cell uptake, loss, and residual concentration so those terms are not charged twice. Pair the output with viable effector counts and direct cellobiose-carbon uptake so expression and metabolic burden enter through whole-product measurements.

The uncertain context is adversarial unless it is measured and available to the controller. If context is observable, include it in x. A policy must choose the same action across states that cannot be distinguished at the decision boundary. If marker measurement is only destructive, compare open-loop schedules; do not credit the theoretical value of an unobservable feedback policy. If a validated non-perturbing live marker is later available, add it as an observation coordinate and charge its acquisition/construct cost. In the initial implementation, the budget charge c+ is a known upper charge for each state/action row, so remaining budget is tracked from chosen actions rather than inferred from unobserved intracellular flux.

## Theorem: robust finite-horizon state reachability

Fix a finite stage set, finite state bins, finite action library, and a declared initial state bin. For each (t,x,a), let c+_(t,x,a) be a known charged upper cost vector and O_(t,x,a) the set of possible paired next-state/lower-reward outcomes after hidden contexts and simultaneous uncertainty are included. For a deterministic observed-state controller with nutrient budget vector b, define the guaranteed value recursively:

\[
V_T(x,b)=0,\qquad
V_t(x,b)=\max_{a:\ c^+_{t,x,a}\le b}
\min_{(x',r)\in\mathcal O_{t,x,a}}
\left[r+V_{t+1}(x',b-c^+_{t,x,a})\right],
\]

where every comparison/subtraction is componentwise for methionine and cellobiose budgets; the paired outcome set already includes all contexts not observed by the policy. If the best value is at least L=log(1/rho), the returned policy guarantees U_T/U_0 <= rho within the measured interface and charged nutrient budgets. If the finite interface's outcome set is exact and each cost charge equals the defined resource cost for that abstraction, the recursion exactly characterizes robust reachability on it. Taking a componentwise upper cost charge or conservative confidence envelope makes feasibility a sufficient certificate; failure is `UNKNOWN` unless an optimistic transition/reward/cost relaxation also fails.

**Proof.** Backward induction on the remaining stages. At T there is no remaining log-suppression increment. At stage t, an action is feasible only when its charged vector fits the remaining componentwise budget. The joint paired outcome can be any element of the measured set, so its guaranteed value is the minimum of the observed lower reward plus the continuation value at the paired next state and reduced budget. Maximizing over feasible actions gives the largest lower guarantee achievable from x. Induction proves the finite-interface statement; enlarging the outcome set and upper-bounding costs can only reduce the certificate, so a passing confidence-bounded result remains sufficient.

This is a state-transition compiler, not a dose-occupation LP. It does not assume schedule order is irrelevant, nor does it treat mean expression as an enzyme-activity oracle. It is exact only for its finite, directly measured state/action interface. The outer biological reachability question remains open until transition and reward bounds are actually acquired.

## Order is a real control variable

The smallest counterexample to an occupation-only summary has two stages and two actions, M (early methionine pulse) and F (later private fuel). State x=0 is unwritten, x=1 is written. M costs one unit, gives no immediate suppression, and changes x=0 to x=1; F costs one unit and gives one log-suppression unit only when x=1. Then M-then-F and F-then-M have identical action counts, total methionine/cellobiose use, and total exposure times, but guarantees 1 and 0 respectively. This algebraic example only proves that state memory invalidates occupation fractions; it is not a parameterization of T cells.

For the biological test, freeze at least the schedules M-high -> F, M-low -> F, F -> M-high, F -> M-low, and the best constant/simultaneous mixture. Use equal total doses and equal time, and compare the state marker, total cellobiose uptake, effector survival, and tumor log-count trajectory. A direct difference in later output after the same total inputs is the decisive observation that the memoryless LP cannot explain.

For a preregistered 48-hour pilot target of tenfold tumor-cell reduction, the state-DP must return \(V_0\ge\log 10\approx2.302585\), equivalent to average net suppression at least \(0.04797\,\mathrm h^{-1}\). This is an engineering pass/fail target chosen for the experiment, not an efficacy reported by either primary source.

## Falsifiers and stops

- If the corrected primary source or its source data do not support a reproducible 30-minute methionine write effect in the chosen CAR-T activation protocol, remove the methionine phase.
- If the molecular marker distributions after high/low pulse overlap enough that no preregistered state bins have reproducible transitions, the state-aware compiler has no usable state interface.
- If later cellobiose uptake/function is unchanged by the early state, the combined two-resource program offers no temporal advantage over cellobiose-only.
- If order permutations with identical total inputs are equivalent within the prespecified margin, use the simpler occupation model for that assay and do not claim a dynamic-control advantage.
- If donor/context variation eliminates the lower reward bounds, return `UNKNOWN`; do not substitute a linked fluorescent marker or a post hoc latent state.
- In held-out donors, a target ratio above the frozen robust bound after marker, uptake, and mass-balance gates pass falsifies the state-transition model-to-biology map.

The strongest equal-information control is a schedule selected from the same measured two-phase action library, same independent donor blocks, and same dose-order panel, then frozen on held-out donors. Compare open-loop optimal ordering with adaptive state feedback only if the measured state is non-destructively observable in the operational system. GLUT1, GLUT5, ordinary CAR T, and cellobiose-only remain architecture comparators, but they do not replace the same-dose order control.

## Costs and evidence status

This candidate adds distinct costs beyond the earlier private-fuel assay: controlled TCR stimulation timing; methionine-free/low/adequate media and rapid medium exchange; paired early and late sampling; targeted KCa3.1-R350 methylation analysis (or a validated lower-cost assay), nuclear NFAT1 imaging/flow; donor-block replication; direct labeled-cellobiose uptake; and serial target/effector counts. As a conservative scale example, nine state/action/context rows, five bounded endpoints (two state markers, uptake, target suppression, and effector viability), familywise \(\delta=0.05\), and Hoeffding radius \(\epsilon=0.25\) require 60 independent donor blocks per row; \(\epsilon=0.10\) requires 375. This is a conservative bound, not an asserted practical sample size; infeasible acquisition means `UNKNOWN`. The 2025 source used 0.1 versus 0.03 mM methionine during the first 30 min with antigen, then restored 0.1 mM for 24 h; this is a source-anchored starting contrast, not a prescribed CAR-T dose. The cellobiose source does not establish this combined sequence.

The DP and order counterexample are mathematical results conditional on direct measurements. The current code implements a rectangular special case with a fixed upper cost charge per state/action row and a finite set of paired (next-state, suppression) outcomes. No cellobiose or methionine source data were independently downloaded/reanalyzed here, and no claim of novelty, therapeutic benefit, clinical timing, or safety is made. Novelty status: `UNKNOWN`.
