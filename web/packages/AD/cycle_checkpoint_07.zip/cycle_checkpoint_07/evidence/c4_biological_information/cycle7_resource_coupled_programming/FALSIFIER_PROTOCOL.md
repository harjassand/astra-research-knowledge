# Paired kinetic assay and falsifier

## Goal

Test whether an exclusive-fuel CAR-T construct creates a robust, resource-accounted target-reduction region in a named in-vitro model. This protocol tests the conditional result in [PROOF.md](PROOF.md); it does not test clinical efficacy.

## Design

Use primary CAR-T cells from independent donors and one antigen-positive tumor line for the first screen. Lock one CAR construct, effector:target ratio, cellobiose-dose grid, glucose background, oxygen condition, culture volume, assay horizon, and viability definition before collecting outcome data. Use a small pilot to set the dose grid around the uptake and lysis transition; keep those pilot data out of the held-out decision test.

Randomize within each donor block to:

- CDT-1/GH1-1 CAR-T plus cellobiose;
- the same CAR-T vector backbone with matched control genes plus cellobiose;
- GLUT1 CAR-T and ordinary CAR-T under the same measured glucose-supply grid;
- if the chosen target line's fructose uptake is characterized, GLUT5 CAR-T plus fructose;
- target-only and CAR-negative controls.

Keep transduction process and effector:target ratio fixed. Measure viable target counts serially and count viable engineered effector cells at the same times. Measure cellobiose concentration over each assay interval and use labeled cellobiose or another validated direct uptake readout. Report the construct's full uptake/lysis response, not only average expression of a linked fluorescent marker.

## Stateful two-phase arm

The candidate arm uses a 30-minute antigen/TCR stimulation stage at 0.1 mM or 0.03 mM methionine, followed by restoration of 0.1 mM methionine and a common glucose-limited cellobiose schedule. Include reversed, constant, and simultaneous/constant-total-exposure controls; pair total methionine/cellobiose inputs and exposure time where feasible. Measure KCa3.1 R350 methylation and nuclear NFAT1 in randomized sister aliquots at the first-stage boundary and later endpoint, plus effector/target counts, direct cellobiose-carbon uptake, and residual extracellular nutrients. A destructive marker assay is not treated as feedback on the cells that were sampled.

The strongest same-information baseline uses the full two-stage action library, identical donor blocks, and identical endpoint allocation, then freezes its best open-loop schedule on training blocks. State feedback is considered only if a non-perturbing readout is validated at the decision boundary. If pulse order has no reproducible effect, stop the dynamic branch and use the simpler stationary model. The methionine source's Fig. 5j survival data were corrected in 2026; use the corrected figure if citing that result.

For every dose, independently measure target-only substrate use. A nondetection is recorded as an assay-specific upper confidence bound, not as zero. Include a condition with a deliberately high target burden or a second target line to measure whether the supply requirement changes as the competitor population grows.

## Finite-noise rule

The biological replicate is a donor block containing the paired constructs and target conditions. Do not count flow events, wells, or repeated time points from one donor as independent donors. For (J) dose-context-stage points and (K) total bounded endpoint means used to freeze the interface (including state-bin frequencies, uptake, and target suppression), use the conservative simultaneous Hoeffding radius

\[
\epsilon_n=\sqrt{\log(2JK/\delta)/(2n)}.
\]

Translate consumption-fraction intervals into nutrient-rate intervals using the known starting amount, well volume, cell count, and assay time. Use suppression-fraction intervals directly, or estimate the log-count increment only where target counts remain above the assay's quantification floor. If the necessary donor count is infeasible, report `UNKNOWN`; do not replace donor replication with individual cells.

Before the held-out assay, freeze (r^+_{zj}), (s^-_{zj}), the nutrient budget (B_{\max}), and target-reduction fraction (\rho). Then test linear feasibility. A certifying schedule must be specified as concentration levels and durations ((c_j,\pi_jH)).

## Assumption checks and rejection criteria

1. **Cellobiose exclusivity:** if target cells consume cellobiose above the prespecified limit, retain that measured upper bound in (r^+_{zj}). If it is unbounded in the intended target population, the private-resource advantage is not certified.
2. **Clamp and conservation:** concentration measurements must reconcile with input, effector consumption, target consumption, and nonspecific loss within a declared mass-balance residual. Unresolved mass-balance error is charged as additional loss or returns `UNKNOWN`.
3. **Stationarity/order:** compare schedules A-then-B and B-then-A with the same cumulative nutrient-time. If their target suppression or state marker differs by more than the preregistered margin, reject the occupation-only controller and fit a directly measured state-augmented model.
4. **Expression/context:** repeat the same construct across donor blocks and at least two activation/transduction contexts. If the lower suppression envelope or upper consumption envelope does not transfer, narrow the context panel; do not extrapolate.
5. **Held-out prediction:** if a feasible schedule predicts (U(48\,\mathrm h)/U(0)\le0.10) but the held-out coculture's simultaneous interval lies entirely above 0.10 after all assay gates pass, reject the claimed robust rate map.

The (0.10) target is an assay design choice. The mathematical threshold is a measured net suppression of at least \(\log 10/48=0.04797\,\mathrm h^{-1}\), with enough nutrient supplied to cover the measured upper consumption/loss rate.

## Acquisition costs and boundaries

The design requires vector construction/packaging, separate transduction and viability controls, repeated medium-concentration measurements, isotope tracing or another validated direct uptake assay, serial target/effector counts, and independent donor blocks. An in-vivo extension adds animal, dosing, tissue concentration, and pharmacokinetic costs; it is not implied by the in-vitro certificate. Systemic cellobiose availability, local delivery, immunogenicity of fungal proteins, and microbiome use require separate studies.
