# Primary-source and scope notes

## Candidate immune-cell capability

**Miller, Thauland, Nagarajan, Zuo, Moreno Lastre & Butte (2026), “Fungal-derived cellobiose metabolic pathway fuels T cells to bypass intratumoral glucose competition,” *Cell* 189, 1717–1730.e16.** DOI: [10.1016/j.cell.2026.01.015](https://doi.org/10.1016/j.cell.2026.01.015). Primary article: [Cell Press](https://www.cell.com/cell/fulltext/S0092-8674(26)00102-9). The authors report expressing the fungal cellobiose transporter CDT-1 and β-glucosidase GH1-1 in primary mouse T cells and human CAR-T cells. Their abstract and article summary report that cellobiose under glucose withdrawal restores T-cell viability, proliferation, cytokine production, and cytotoxicity; the engineered cells also improved tumor control in mouse models. The paper states that selected tumor cells cannot use cellobiose, enabling an exclusive-fuel interpretation in the tested systems.

The full-text endpoint returned HTTP 403 to this run's browser. Primary-source search indexing exposed the abstract, main summary, and data-availability statement. The article says its non-sequencing data are in the article/STAR Methods and links sequencing data to [Figshare](https://figshare.com/s/d70355c2b27c06fd78b5), DOI [10.6084/m9.figshare.28185641](https://doi.org/10.6084/m9.figshare.28185641). No data were downloaded or independently reanalyzed. The paper reports patent applications; this package makes no commercial or clinical claim.

## Strong shared-fuel baselines

**Guerrero et al. (2024), “GLUT1 overexpression in CAR-T cells induces metabolic reprogramming and enhances potency,” *Nature Communications* 15, 8658.** [Primary article](https://www.nature.com/articles/s41467-024-52666-y), DOI [10.1038/s41467-024-52666-y](https://doi.org/10.1038/s41467-024-52666-y). The primary article reports increased glucose consumption, glycolytic and oxidative capacity, altered exhaustion/memory-associated phenotypes, and improved tumor control/persistence in mouse models. This is the strongest direct shared-glucose engineering comparator. Its transporter enhancement does not remove other cells' access to glucose.

**Schild et al. (2025), “Metabolic engineering to facilitate anti-tumor immunity,” *Cancer Cell* 43, 552–562.e9.** [Primary article](https://www.sciencedirect.com/science/article/pii/S153561082500056X), DOI [10.1016/j.ccell.2025.02.004](https://doi.org/10.1016/j.ccell.2025.02.004). The primary report shows that GLUT5-engineered T cells, macrophages, and CAR-T cells use fructose and improve effector outcomes in glucose-limited in-vitro models and mouse models. Fructose may be preferentially available to immune cells in many tumors, but this is a measured target-panel gate; do not claim universal exclusivity.

**Hu et al. (2024), “Selective Refueling of CAR T Cells Using ADA1 and CD26 Boosts Antitumor Immunity,” *Cell Reports Medicine*.** DOI [10.1016/j.xcrm.2024.101530](https://doi.org/10.1016/j.xcrm.2024.101530); transcript data accession [GSE262447](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE262447). This supplies a distinct inosine-based metabolic-refueling baseline. It changes the nutrient pathway and should receive the same coculture and resource measurements if included.

## Why shared nutrients are a real coupled resource

**Reinfeld et al. (2021), “Cell-programmed nutrient partitioning in the tumour microenvironment,” *Nature* 593, 282–288.** [Primary article](https://www.nature.com/articles/s41586-021-03442-1), DOI [10.1038/s41586-021-03442-1](https://doi.org/10.1038/s41586-021-03442-1). Using PET tracers and cell-specific analysis, the authors report myeloid cells had the greatest capacity to take up intratumoral glucose, followed by T cells and cancer cells, across their cancer models; cancer cells had the highest glutamine uptake. This means a glucose-sharing baseline must count non-tumor competitors and context-specific allocation.

**Chang et al. (2015), “Metabolic competition in the tumor microenvironment is a driver of cancer progression,” *Cell* 162, 1229–1241.** [Primary article](https://pmc.ncbi.nlm.nih.gov/articles/PMC4574250/), DOI [10.1016/j.cell.2015.08.016](https://doi.org/10.1016/j.cell.2015.08.016). This primary mouse-sarcoma study reports that tumor glucose consumption can restrict T-cell glycolysis and effector function. **Ho et al. (2015), “Phosphoenolpyruvate Is a Metabolic Checkpoint of Anti-tumor T Cell Responses,” *Cell* 162, 1217–1228.** DOI [10.1016/j.cell.2015.08.012](https://doi.org/10.1016/j.cell.2015.08.012). These are primary biological antecedents for charging the shared-fuel competition term.

## State/history warning

**Sharma et al. (2025), “Early methionine availability attenuates T cell exhaustion,” *Nature Immunology* 26, 1384–1396.** DOI [10.1038/s41590-025-02223-6](https://doi.org/10.1038/s41590-025-02223-6). The primary article reports that limiting methionine to 0.03 mM rather than 0.1 mM during the first 30 minutes of antigen/TCR engagement increases Ca2+ influx and NFAT1 activation and changes later T-cell state; in the pulse experiment, methionine is restored to 0.1 mM for 24 hours. The authors link the mechanism to KCa3.1 R350 arginine methylation. They also report acute peritumoral methionine effects and a CAR-T adoptive-transfer experiment. These results support measuring dose order and a direct state readout; they do not establish that early methionine plus later cellobiose is synergistic.

The paper received a 2026 author correction, DOI [10.1038/s41590-026-02534-2](https://doi.org/10.1038/s41590-026-02534-2). The correction fixes the x-axis label of Fig. 4d (0.1 mM versus 0.03 mM, not versus 0 mM), replaces the incorrect Fig. 5j survival dataset, and adds a missing y-axis label to Extended Data Fig. 10e. The corrected Fig. 5j survival panel must be used for any reliance on that specific experiment. The correction does not identify a change to the 30-minute pulse comparison; no source data were independently reanalyzed here.

## Stopped recombinase route

**An et al. (2026), “Synthetic circuits for cell ratio control,” *Nature* 653, 587–598.** [Primary article](https://www.nature.com/articles/s41586-026-10259-3), DOI [10.1038/s41586-026-10259-3](https://doi.org/10.1038/s41586-026-10259-3). The primary article describes parallel Bxb1 devices whose predicted combinatorial fates are products of individually measured probabilities, and also demonstrates serial branching with Bxb1 and TP901. This is prior art against presenting the earlier branching compiler as a new architecture.

**Zhang et al. (2022), “Model-guided engineering of DNA sequences with predictable site-specific recombination rates,” *Nature Communications* 13, 4152.** [Primary article](https://www.nature.com/articles/s41467-022-31538-3), DOI [10.1038/s41467-022-31538-3](https://doi.org/10.1038/s41467-022-31538-3). The primary article directly describes product inhibition: an intact attP site can still bind Bxb1 after another module recombines, acting as a decoy that lowers effective enzyme availability and alters total expression. The branch route was not extended here.

## Astra route

The local `work/astra_prior` router exposes mathematical analysis, probability, and acquisition topics and cards including N25 and N54, but no cell-biology or immunometabolism source route. Those cards are navigation only and are not used as biological evidence or premises.

## Combined staged program: evidence boundary

The methionine timing and cellobiose-fuel claims above are separate primary results. The proposed two-phase combination in [TEMPORAL_STATE_CONTROL.md](TEMPORAL_STATE_CONTROL.md) is an untested architecture hypothesis. The finite-state dynamic-program theorem is conditional on directly measured transitions, state readouts, uptake/input costs, and target-count changes. It is not a result reported by either source.
