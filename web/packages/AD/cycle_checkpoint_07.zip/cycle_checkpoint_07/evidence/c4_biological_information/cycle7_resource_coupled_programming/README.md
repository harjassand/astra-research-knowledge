# Cycle 7: temporal, resource-coupled immune-cell control

## Finding

The recombinase branching compiler is preempted for this cycle. An et al. (2026) already report parallel and serial Bxb1/TP901 branching, and Zhang et al. (2022) document Bxb1 product inhibition. The higher-ceiling target is stateful nutrient control in engineered T cells.

Two primary studies provide separate mechanisms for a staged candidate. Sharma et al. (2025; corrected in 2026) report that methionine availability during the first 30 minutes of TCR engagement alters later T-cell signaling and exhaustion-related state. Miller et al. (2026) report that CDT-1/GH1-1-engineered T cells can use cellobiose during glucose withdrawal. This cycle proposes, but does not demonstrate, an early methionine state-write followed by later cellobiose fuel-maintenance program.

The main new mathematical interface is in [TEMPORAL_STATE_CONTROL.md](TEMPORAL_STATE_CONTROL.md): a robust finite-state dynamic program over directly measured state transitions, distinct nutrient budgets, and target log-suppression increments. Its theorem is exact for the measured finite interface if bounds are exact; confidence bounds make successful feasibility a sufficient certificate. It handles dose order and state memory without assuming stationary rates. It refuses to use a marker as feedback unless that marker is directly observable at the decision boundary.

The earlier static dose-occupation LP and mass-balance barriers remain in [PROOF.md](PROOF.md) as useful conditional results, but they are standard methods and are not the cycle's novelty claim. The biological architecture remains untested. No therapy, safety, or clinical claim is made; novelty and priority are `UNKNOWN`.

## Evidence and limitations

The 2026 *Nature* recombinase paper preempts a new parallel/serial branching claim. The 2022 Bxb1 paper documents product inhibition from intact attP decoy sites. A linked fluorescent marker is not assumed to report active-enzyme or metabolic flux. For the candidate immune program, cellobiose flux, CAR-T expression heterogeneity, activation state, target density, and methionine effects must all be directly measured in the paired product/context.

The methionine paper received a 2026 correction to the Fig. 4d label, Fig. 5j survival dataset, and an Extended Data Fig. 10e axis label. Any reliance on that survival panel must use the corrected version. No source data from the methionine or cellobiose papers were independently reanalyzed here. The combined program is not tested in either source.

## Package contents

- [TEMPORAL_STATE_CONTROL.md](TEMPORAL_STATE_CONTROL.md): staged candidate, finite state-transition interface, dynamic-program theorem, order counterexample, baselines, costs, and falsifiers.
- [PROOF.md](PROOF.md): conditional static occupation frontier and nutrient mass-balance theorem.
- [MODEL_AND_DESIGN.md](MODEL_AND_DESIGN.md): assay interface and matched architecture baselines.
- [SOURCES.md](SOURCES.md): primary-source findings, correction note, and evidence boundaries.
- [FALSIFIER_PROTOCOL.md](FALSIFIER_PROTOCOL.md): paired donor-block assay design and rejection gates.
- [CLAIMS.json](CLAIMS.json): machine-readable claim/status ledger.
- [FAILURES.md](FAILURES.md): rejected routes and restart conditions.
- [code/robust_frontier.py](code/robust_frontier.py): static dose-mixture frontier arithmetic.
- [code/test_robust_frontier.py](code/test_robust_frontier.py): static arithmetic checks only.
- [code/robust_state_dp.py](code/robust_state_dp.py): robust schedule/state-feedback dynamic program for a finite measured interface.
- [code/test_robust_state_dp.py](code/test_robust_state_dp.py): state-memory/order counterexample and code checks, not biological evidence.
