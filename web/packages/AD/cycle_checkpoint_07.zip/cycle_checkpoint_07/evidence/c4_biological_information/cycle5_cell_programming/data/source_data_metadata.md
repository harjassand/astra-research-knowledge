# Source workbook metadata

- Study: An et al., “Synthetic circuits for cell ratio control,” Nature (2026), DOI 10.1038/s41586-026-10259-3.
- Source data page: https://www.nature.com/articles/s41586-026-10259-3#Sec44
- Direct workbook: https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41586-026-10259-3/MediaObjects/41586_2026_10259_MOESM11_ESM.xlsx
- Local file: source_data_fig3.xlsx
- SHA-256: fbfeabd4895106e409ce27c95bf33870be2cdcf7c6359868d8f353ce1274dfe2
- Workbook tabs used: Figure 3 a-c; Figure 3 e-g; Figure 3 i-k.
- Measurement available: eight biological-replicate flow-cytometry percentages per plotted state.
- Measurement not available in this workbook: event-level FCS, per-cell Bxb1 abundance/activity or iRFP proxy readout, or matched per-cell module outcomes conditioned on activity.
- Analysis: code/analyze_parallel_cassettes.py reads this workbook in read-only mode with openpyxl and writes source_data_analysis.json. The descriptive TV calculations compare the published single-device marginal means' product law with the published joint-culture state means. They do not have event-level counts or replicate-paired state vectors, so no uncertainty test or mechanistic attribution is claimed.
- Download scope: only this small processed public source workbook was used; no controlled raw dataset was downloaded.
