# Cycle 5: shared-exposure cell-fate laws and a conditional branching compiler

**Scope.** This report is a separate cell-programming branch. It leaves the earlier plasma/cancer gauge report and all other workers' files untouched. I revisited the earlier cell-control, programmable-biology, and biomolecular-design reports and the routed Astra topic/card pointers. Those materials supplied scope and known baselines, not proof premises. The local Astra router points to N33/N34/N35/N50/N76 cards that are absent from this checkout; the available N25 and N54 cards and the cycle-3 information-starvation refresh do not validate a recombinase mechanism. No claim below depends on them.

## Result

The work gives two exact, conditional results for the parallel Bxb1 architecture in An et al. (2026), plus an idealized sequential compiler. It does **not** establish that the biological assumptions hold in that study's yeast strains, and it makes no novelty or clinical claim.

For the general mixture theorem, the scalar can be an observed proxy Z rather than a molecular assay of active enzyme, provided the module outcomes are conditionally independent given the *measured* Z. The 2026 article reports an iRFP co-reporter in its inducible Bxb1 vector for mammalian cells, so same-cell iRFP plus fate-reporter flow cytometry is a concrete candidate paid assay. The paper uses iRFP for enrichment; it does not show that iRFP measures catalytic activity or is a sufficient statistic. The sufficiency test is conditional factorization of the fate bits given that readout. The Laplace/hazard specialization below does require Z to be calibrated to integrated active exposure.

1. If modules are independent conditional on a measured scalar readout Z in [0, Zmax], then the complete 2^m-fate law is exactly the convex hull of a one-dimensional curve of product-Bernoulli laws. Under first-order hazards p_i(a)=1-exp(-κ_i a) with integrated active-enzyme exposure A, every fate probability is a finite signed sum of values of the same Laplace transform L(t)=E[exp(-tA)]; a single L must be completely monotone and satisfy L(0)=1. A paid sample of the proxy distribution, plus response calibration, can identify/approximate the entire high-dimensional law as a compact mixture representation without collecting every fate as a separate category. Explicitly listing all 2^m entries still takes exponential output space.

2. If the response curves p_i(z) are nondecreasing in the same measured scalar Z, any pair of parallel fate bits has nonnegative covariance. An equal one-hot target on m=10 fates has pairwise joint probability zero and pairwise covariance -0.01, so it is outside this parallel model. A staged binary decision tree can encode that law: at each node, set the left branch probability to the target mass in its left subtree divided by the mass at that node. Competing hazards λL(t)=kL u(t) and λR(t)=kR u(t) give a dose-invariant conditional split q=kL/(kL+kR). A K-leaf Huffman compiler uses K−1 branch nodes and minimizes expected decision depth. For ten equal fates it uses nine nodes, mean depth 3.4, maximum depth 4.

The exact biological invariant is cause-of-first-event invariance under hazards that share a multiplicative activity waveform. In a finite induction window, no reaction is a real third outcome with probability (e^{-(k_L+k_R)A(T)}). The code and report retain this mass as `UNRESOLVED`. With incomplete node reactions, each resolved leaf has mass at most its target π_i, and the TV distance from the target law extended with zero unresolved mass equals the unresolved probability. Conditioning the observed terminal population on resolution can still bias the target if completion probabilities differ by path. A measured resolution gate or additional induction is therefore part of the design, not free completion.

## Model and proofs

For module i, let X_i given Z=z be Bernoulli(p_i(z)), conditionally independent across i. For a fate bit vector x in {0,1}^m, define

\[
v_x(z)=\prod_{i:x_i=1}p_i(z)\prod_{i:x_i=0}(1-p_i(z)),\qquad Q_F(x)=\int v_x(z)\,dF(z).
\]

As F ranges over probability measures on the bounded readout interval, Q_F ranges over the closed convex hull of v([0,Zmax]) in the 2^m-state simplex. One direction follows because every integral is a mixture of curve points; the reverse follows because every finite convex combination is the law of a discrete F, and arbitrary mixtures are limits of such combinations. Carathéodory gives a representation with at most 2^m support points, though this is not the recommended estimator. This is an exact model-level characterization, not evidence that a current cell-fate system has a sufficient scalar readout.

In the first-order hazard case, write S={i:x_i=1} and L(t)=integral exp(-t a) dF_A(a), where F_A is the distribution of integrated active exposure. Then

\[
Q_F(x)=\sum_{U\subseteq S}(-1)^{|U|}L\!\left(\sum_{j\notin S}\kappa_j+\sum_{i\in U}\kappa_i\right).
\]

This follows by expanding each active factor 1-exp(-κ_i a). The representation couples all fate probabilities through a *single* transform. By Bernstein's theorem, L is completely monotone on t≥0, with L(0)=1, exactly when it is the Laplace transform of a probability measure on nonnegative exposure. If exposure is bounded, the support restriction imposes additional moment constraints; complete monotonicity alone does not encode the finite Amax bound.

**Polynomial-in-m full-law estimation theorem (conditional).** Let each known response p_i(z) be L_i-Lipschitz. Draw n iid same-cell scalar-proxy measurements Z_1,...,Z_n from F, and let F_n be their empirical distribution. For product Bernoulli laws, total variation obeys

\[
\operatorname{TV}(v(z),v(z'))\le\sum_i|p_i(z)-p_i(z')|\le L|z-z'|,\qquad L=\sum_i L_i.
\]

Couple the two proxy laws optimally in one-dimensional Wasserstein distance. Then TV(Q_F,Q_Fn) ≤ L W1(F,Fn) ≤ L Zmax sup_z |F(z)-Fn(z)|. The Dvoretzky–Kiefer–Wolfowitz inequality gives, with probability at least 1−δ,

\[
\operatorname{TV}(Q_F,Q_{F_n})\le L Z_{\max}\sqrt{\frac{\log(2/\delta)}{2n}}.
\]

It suffices to take n ≥ (Zmax L)^2 log(2/δ)/(2 ε^2) for full-law TV error at most ε. If Zmax and the per-module slopes are bounded independently of m, this is polynomial, O(m^2 ε^-2 log(1/δ)), despite 2^m output entries. The empirical measure F_n plus the response curves is an O(n+m) compact representation; querying a single fate probability costs O(nm), while printing all entries costs exponential space. For m=10, Zmax L=10, ε=.05, δ=.05, the scalar-readout sample bound is 73,778 single-cell scalar-readout measurements under iid sampling. These must be independent biological observations for the DKW confidence statement; 73,778 flow events from a few correlated cultures do not automatically count as 73,778 iid samples. Replicate-level clustering, sensor saturation and instrument noise must be measured or incorporated in an adjusted design. The general theorem needs a calibrated and sufficient scalar readout such as same-cell iRFP, not an unmeasured enzyme-activity oracle. To interpret the readout as integrated active Bxb1 exposure still requires an independent activity calibration.

The costs omitted by that scalar-readout sample count remain explicit. If calibrated response curves have uniform errors η_i, the output-law TV error adds at most sum_i η_i. If a sensor estimates an underlying scalar with certified W1 error σ, it adds at most Lσ. In the hazard model, rate errors Δκ_i and exposure W1 error σ contribute at most Amax sum_i |Δκ_i| + σ sum_i κ_i. Estimating m rates from binary outcomes also costs assays: at a calibrated activity a0, if the response is bounded away from 1 by γ, then a response-probability error η implies rate error at most η/(a0 γ); Hoeffding requires O(η^-2 log(m/δ)) assay cells per module for this accuracy. Exposure samples and response curves must be acquired in the same joint-circuit genotype and induction conditions; single-device background cultures do not automatically transfer. If the aim is to infer molecular exposure from a proxy with an unknown sensor-error law, deconvolution is an additional inverse problem and is not solved here. If no measured scalar readout is sufficient for conditional independence, the proxy theorem is not operationally available.

**Parallel one-hot obstruction.** Conditional independence gives Cov(X_i,X_j)=Cov(p_i(Z),p_j(Z)). For independent copies Z,Z',

\[
2Cov(p_i(Z),p_j(Z))=E[(p_i(Z)-p_i(Z'))(p_j(Z)-p_j(Z'))].
\]

If both responses are nondecreasing, the integrand is nonnegative. Equal one-hot marginals p_i=1/m require P(X_i=X_j=1)=0 but every admissible parallel law has P(X_i=X_j=1)≥p_i p_j=1/m^2. At m=10 the separating event has a 0.01 probability gap. This obstruction uses a common *scalar* readout, monotone responses and conditional independence. It is not a theorem about arbitrary multivariate enzyme states, nonmonotone response pairs, or cross-module interaction.

**Sequential tree theorem.** For any finite positive target vector π on K fates, choose a binary tree with those leaves. At node v with left/right subtree masses ΠL, ΠR, set q_v=ΠL/(ΠL+ΠR). If its two possible recombination events have competing hazards kL u(t), kR u(t), then

\[
P(L\mid\text{an event by T})=\frac{k_L}{k_L+k_R},\quad
P(\text{no event by T})=e^{-(k_L+k_R)A(T)},\quad A(T)=\int_0^T u(t)dt.
\]

The cause ratio follows by integrating the cause-specific hazard against the shared survival (e^{-(k_L+k_R)A(t)}); it does not assume a known activity derivative or death-rate oracle. If every selected node eventually reacts, setting the measured rate ratio to q_v makes every leaf's path probability telescope to π_i. In a finite window, each node may fail to react; those paths are explicit unresolved outcomes, and the resolved terminal fractions can be biased by branch-specific completion. Exact K-fate output therefore requires complete resolution or measured feedback that advances only after a node event. Otherwise measure the full node transition matrix, include unresolved mass, and recompile or mark the target `UNKNOWN`.

The model is falsifiable at the mechanism level: bin or continuously condition single-cell recombination outcomes on a calibrated activity readout, and test (i) whether outcome bits are conditionally independent; (ii) whether each single-module p_i(A) is monotone; (iii) whether the shared-exposure model predicts held-out full fate vectors within its predeclared TV bound; and (iv) whether a branch-node left:right outcome ratio stays constant across activity bins while unresolved fraction changes as predicted. Product inhibition or competing DNA-site occupancy that makes one module's rate depend on other module states fails gate (i) and invalidates the convex-mixture compiler for those modules.

## Data check and equally informed baselines

I analyzed the published, processed Fig. 3 source workbook from An et al. (2026), with 8 replicate-level flow-cytometry percentages. Separate single-device culture marginals yield a product prediction whose descriptive TV distance from the joint-culture mean vector is **0.03298** for two modules and **0.04731** for three. The pairwise covariances calculated within the three-device joint-culture mean vector are positive: G–R 0.00449, G–B 0.00336, R–B 0.00090. The two-device joint mean covariance is 0.01049. These are arithmetic diagnostics on rounded summary percentages, not inferential statistics. Single-device marginal yields differ from the joint-culture marginals, so these numbers cannot distinguish shared cell-to-cell activity from context effects, growth, gating, or construct differences. The workbook lacks event-level FCS and any per-cell Bxb1 activity readout; it does not establish the shared-exposure mechanism.

Baselines are compared at equal information and cost boundaries:

| Design/inference | Information used | What it can establish | Limitation / cost |
|---|---|---|---|
| Published parallel product rule | Single-device marginal proportions | Predicts all bit combinations by multiplying marginals | Assumes independent recombination; source data gives small descriptive mismatches; cannot make one-hot mixtures under the monotone common-dose model |
| Shared-readout parallel law here | Same architecture plus calibrated F_Z and each p_i(Z) | Predicts the whole joint law; can need polynomial scalar-readout samples under the theorem | Requires same-cell scalar-readout measurement and conditional independence; does not expand the parallel reachable set |
| Direct joint-state assay | Genotype/phenotype categories on single cells | Estimates the realized joint law with minimal structural assumptions | The rare-fate detection burden is n ≥ log(1−c)/log(1−ρ); a fate at ρ=.001 needs 2,995 cells just to be observed with 95% probability. Relative-error estimation is more costly, O(1/(ρ ε_rel^2)) |
| Published sequential branching | Conditional lineage-specific activation | Already experimentally demonstrates two sequential layers and three/four output types in the 2026 paper | Not a new architecture class; higher-cardinality target compilation, rate-ratio invariance, failure accounting and one-hot reachability have not been validated as a combined design |

The exact constructed stress test is deliberately not mislabeled as measured biology. With m=10 and A=0 for 90% of cells, A=aH for 10%, and p_i(0)=0, p_i(aH)=.99, each marginal is .099. The true all-on probability is .1(.99)^10=0.0904382, while multiplying the marginals gives .099^10=9.04382×10^-11, an underprediction by 10^9. This is a precise prediction if those measured activity bins and conditional response curves are observed; the Nature workbook does not supply them.

## Biological applicability gates and stop conditions

- An et al. explicitly calculate multi-module fates by multiplying independently measured single-device outcomes, and call the recombination events independent. Their single-copy integration and orthogonal attachment variants are relevant controls, but DNA-site orthogonality alone does not prove conditional statistical independence after conditioning on the measured scalar readout.
- Zhang et al. (2022) directly model and validate **product inhibition**: a residual attP site can bind Bxb1 after another recombination event and sequester enzyme, thereby changing another module's flip rate. That is direct evidence against treating a shared total expression proxy as sufficient exposure in arbitrary constructs. The compiler therefore requires either a free-activity measurement or a fluorescent proxy demonstrated to be sufficient by conditional factorization; it does not assume that any fluorescent Bxb1 marker is sufficient.
- Bxb1 recombination is a multi-step synapsis, cleavage, rotation and ligation process, with rate depending on att sequence. Single-molecule work reports multiple rotations and sensitivity to crossover sequence, torsional stress and salt. The 2026 study uses a five-ODE white-box model including cleavage, transcription recruitment and steric constraints, with reported fit (R^2=0.887). These sources support kinetic tunability but do not validate constant proportional competing hazards in the cellular branch node.
- The 2026 paper already reports differential growth changing measured composition over time (including strong enrichment for one recombinase payload). A target over terminal genotype probabilities is not automatically the later culture fraction. Validate shortly after decision or pay to estimate genotype-specific growth and apply a population-balance correction; otherwise leave final culture-ratio claims `UNKNOWN`.
- Gate to proceed: measure same-cell iRFP (or another scalar proxy) with all fate outputs in the exact joint-circuit genotype; calibrate p_i(proxy); assay conditional joint frequencies and dose-binned branch causes; quantify unresolved recombination and growth; retain independent biological replicates and estimate culture-level clustering. Reject this model if conditional factorization or constant cause-ratio tests fail. No route here infers inaccessible cell states or treats total Bxb1 expression as ground truth.

## What is and is not new

Convex-mixture representation, complete monotonicity, DKW, Huffman coding, monotone association, and competing-risks cause invariance are standard mathematical ingredients. The contribution here is their explicit combination into (a) a full-law sample bound for this cell-fate interface, (b) a quantitative one-hot separation for the parallel common-driver architecture, and (c) a target-law-to-staged-branch compiler with an unresolved-mass output and physical measurement gates. I found direct published prior art for two-layer sequential circuits and tunable Bxb1 rates. I therefore make no priority claim; the high-cardinality biological build, active exposure sensor, and validation experiment remain open. If the parent requires only an experimentally supported new biological capability, this branch does not meet that threshold.

## Reproduction

Run `code/shared_exposure_compiler.py` for seven exact finite checks and `code/analyze_parallel_cassettes.py` for the source workbook arithmetic. The bundled Python runtime with `openpyxl` was used for the workbook. Outputs are `source_data_analysis.json`; metadata and hash are in `data/source_data_metadata.md`. These checks validate the stated arithmetic and finite compiler examples, not biological assumptions or external novelty.
