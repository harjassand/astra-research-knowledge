# Primary-source notes

These notes separate what the literature reports from what is derived in this branch.

## Cell-fate branching, source model, and existing sequential baseline

An, B. et al. “Synthetic circuits for cell ratio control.” Nature 653, 587–598 (2026). https://doi.org/10.1038/s41586-026-10259-3

- Primary article: https://www.nature.com/articles/s41586-026-10259-3
- The binary branching device uses one Bxb1 attP site flanked by two identical Bxb1 attB sites; recombination with one side or the other produces alternative states. Main article describes single-copy integration, confirmed by ddPCR.
- The parallel architecture uses att-site dinucleotide variants for functionally orthogonal modules and predicts the 2^n fates by multiplying separate single-module probabilities. The two- and three-module designs were measured by flow cytometry with n=8 biological replicates; the plotted source data is replicate-level percentages.
- The paper already demonstrates sequential branching using Bxb1 followed by TP901 and reports two-layer circuits making three and four terminal types; it also gives a three-layer design with four types. Sequential conditional recombination is prior art, so this report makes no claim to invent sequential recombination.
- The paper fits a five-ODE Bxb1 white-box model incorporating differential cleavage, transcription recruitment, and steric constraints, reporting R²=0.887. That model warns against treating the real device as a validated single-step exponential hazard.
- In its mammalian methods, the inducible Bxb1 or DHFR–Bxb1 vector includes an iRFP reporter and cells are enriched by iRFP fluorescence. This makes a same-cell scalar expression proxy experimentally accessible in that chassis. It is a co-reporter, not a demonstrated measure of active catalytic enzyme or a demonstrated sufficient statistic for the multi-module fate bits.
- It reports payload-dependent growth shifts in cell-type fractions. A fate-probability target at recombination time is not automatically a final-culture composition target.
- Data link and details for the small processed workbook are recorded separately in data/source_data_metadata.md.

## Bxb1 sequence-rate tuning and cross-module sequestration

Zhang, Q., Azarin, S.M. & Sarkar, C.A. “Model-guided engineering of DNA sequences with predictable site-specific recombination rates.” Nature Communications 13, 4152 (2022). https://doi.org/10.1038/s41467-022-31538-3

- Primary article: https://www.nature.com/articles/s41467-022-31538-3
- The study develops a sequence model for Bxb1 attP-dependent inversion rates and checks predictions in vitro and in E. coli. This supports the plausibility of rate tuning, but does not establish a rate library in the yeast context of the 2026 paper.
- In its two-event plasmid circuit, the study explicitly models product inhibition: an intact attP site after the other event can bind Bxb1 as a decoy, sequester enzyme, and change effective rates. It experimentally tests predictions for nine rate combinations. This is a direct conditional-independence failure mechanism and is why total expression is not accepted here as a sufficient exposure measurement.

## Bxb1 molecular kinetics

Keenholtz, R.A. et al. “Crossover-site sequence and DNA torsional stress control strand interchanges by the Bxb1 site-specific serine recombinase.” Nucleic Acids Research 44(18), 8921–8931 (2016). https://doi.org/10.1093/nar/gkw724

- Primary article: https://pmc.ncbi.nlm.nih.gov/articles/PMC5062993/
- Single-molecule and ensemble experiments report multiple rotation events and show rotation behavior depends on crossover-site sequence, DNA torsional stress, and salt. This is a mechanistic caution against asserting a constant, context-free hazard from Bxb1 abundance alone.

## Mathematical ingredients and limits

- Convex hull of product distributions follows directly from mixing over the shared exposure law.
- The Laplace-transform representation in the first-order-hazard specialization follows by expanding the product; complete monotonicity is Bernstein's classical characterization for Laplace transforms of positive measures.
- The full-law empirical bound is DKW plus the one-dimensional W1/CDF identity and a product-Bernoulli TV coupling. It is a result of this model analysis, not an experimental result.
- The monotone association witness for the one-hot obstruction is elementary covariance algebra.
- Huffman coding, competing-risks cause-of-event invariance, and binary decision trees are standard. The compiler's contribution is their explicit target-law interface and unresolved-outcome accounting for this cell-fate setting; novelty is unknown.

## Source coverage boundary

The earlier cell-control, programmable-biology, and biomolecular-design reports were read as scoped by the parent task. Astra topic routes N33/N34/N35/N50/N76 were inspected, but those card files are not present in this workspace snapshot. The available N25 and N54 cards and the cycle-3 information-starvation refresh supplied adjacent frontier context only; none was used as a biological premise. No other worker files were edited.
