# Cycle 5 cell-programming branch

Start with FINAL_REPORT.md for the conditional theorem, architecture comparison, biological failure gates, and claim status. Primary-source notes are in source_notes.md. Machine-readable claims are in CLAIMS.json.

## Reproduce

From the workspace root, run the bundled Python runtime with these scripts:

    /Users/harjas/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 work/agents/c4_biological_information/cycle5_cell_programming/code/shared_exposure_compiler.py
    /Users/harjas/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 work/agents/c4_biological_information/cycle5_cell_programming/code/analyze_parallel_cassettes.py

The first command runs exact finite model/compiler assertions and prints a compact result. The second reads the public processed workbook in read-only mode and regenerates source_data_analysis.json. Workbook provenance and hash are in data/source_data_metadata.md.

## Claim boundary

All mathematical results are conditional on the stated model. The cited papers establish rate-tunable Bxb1 cassettes, already-published sequential branching, and product-inhibition as a real interaction mechanism. They do not establish the active-exposure sensor, conditional independence, constant competing-cause ratios, or a validated ten-fate build. No experimental or novelty claim is made.
