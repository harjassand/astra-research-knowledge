# Exact finite-amplitude relaxation-curvature bound (candidate)

## Model and interface

Let (dX_t=F(X_t)dt+\sqrt{2T}\,dW_t) on a domain where integrations by parts are valid. Assume a smooth strictly positive stationary density \(\rho\), current velocity
\[
u=F-T\nabla\log\rho,\qquad \nabla\cdot(\rho u)=0,
\]
and steady entropy-production rate
\[
\sigma=T^{-1}\langle |u|^2\rangle_\rho.
\]
The equilibrium reference dynamics has drift \(F_{\rm eq}=T\nabla\log\rho\) and the same \(T,\rho\). Both processes start from the same density \(p_0=\rho f\), where \(f>0\), \(\langle f\rangle_\rho=1\). The experiment must resolve the full spatial density, including the initial profile and the short-time relative-entropy curvature for both dynamics.

Define
\[
L_0f=T\big(\Delta f+\nabla\log\rho\cdot\nabla f\big),\qquad
D(f)=\langle f\log f\rangle_\rho,\qquad
I(f)=\left\langle\frac{|\nabla f|^2}{f}\right\rangle_\rho.
\]
The exact ratio dynamics are
\[
\dot f_{\rm neq}=L_0f-u\cdot\nabla f,\qquad \dot f_{\rm eq}=L_0f.
\]
These follow by writing the Fokker–Planck current as \(\rho f u-T\rho\nabla f\) and using \(\nabla\cdot(\rho u)=0\).

## Theorem (internal derivation)

For any smooth strictly positive normalized \(f\) for which the displayed derivatives and integrals exist, let
\[
\xi(f)=\left.\frac{d^2}{dt^2}D(f_{\rm neq}(t))\right|_{t=0}-
\left.\frac{d^2}{dt^2}D(f_{\rm eq}(t))\right|_{t=0},
\]
where both relative entropies are measured to the common \(\rho\). Set
\[
G_f=-\frac{2L_0f}{Tf}+\frac{|\nabla f|^2}{f^2},\qquad
Q_f=\left\langle G_f^2|\nabla f|^2\right\rangle_\rho.
\]
Then
\[
\boxed{\quad \sigma\ge \frac{\xi(f)^2}{T^3Q_f}\quad}
\]
when \(Q_f>0\). If \(Q_f=0\), the identity below forces \(\xi=0\), so the observation gives no positive lower bound.

### Proof

Normalization gives \(D'(f)=\langle \dot f\log f\rangle_\rho\). For either process, integration by parts and stationarity of \(\rho u\) give
\[
D'=-T\left\langle\frac{|\nabla f|^2}{f}\right\rangle_\rho=-T I(f).
\]
The advection term vanishes because \(\langle u\cdot\nabla(f\log f-f)\rangle_\rho=0\). For a direction \(v\), the first variation is
\[
DI_f[v]=\left\langle\frac{2\nabla f\cdot\nabla v}{f}-\frac{|\nabla f|^2}{f^2}v\right\rangle_\rho
=\langle G_fv\rangle_\rho,
\]
where the second equality is one integration by parts. Since \(D''=-TDI_f[\dot f]\), subtracting the equilibrium curvature yields the exact identity
\[
\xi(f)=TDI_f[u\cdot\nabla f]
=T\langle G_f\,u\cdot\nabla f\rangle_\rho
=T\langle u\cdot(G_f\nabla f)\rangle_\rho.
\]
Cauchy–Schwarz and \(\langle|u|^2\rangle_\rho=T\sigma\) prove the boxed bound.

## Relation to the 2025 local result

Set \(f=1+\epsilon\phi\), \(\langle\phi\rangle_\rho=0\), and \(\alpha=\Delta\phi+\nabla\log\rho\cdot\nabla\phi\). Then
\[
G_f=-2\epsilon\alpha+O(\epsilon^2),\quad
\xi=-2T\epsilon^2\langle\alpha\,u\cdot\nabla\phi\rangle_\rho+O(\epsilon^3),\quad
Q_f=4\epsilon^4\langle\alpha^2|\nabla\phi|^2\rangle_\rho+O(\epsilon^5).
\]
Thus the finite-amplitude inequality tends to Auconi's 2025 bound
\(\sigma\ge\xi^2/[4T^3\langle\alpha^2|\nabla\phi|^2\rangle]\).
The candidate changes the amplitude interface: it does not require \(\|f-1\|_\infty\ll1\), but still requires a full, smooth, positive density ratio and its derivatives. This does not solve coarse-grained inference.

## Exact blind-probe calculation

Take \(T=1\), \(\rho=N(0,I_2)\), \(R=\begin{psmallmatrix}0&-1\\1&0\end{psmallmatrix}\), and \(F(x)=-(I+\omega R)x\). Then \(u=-\omega Rx\) and \(\sigma=2\omega^2>0\) for \(\omega\ne0\). With initial \(p_0=N(m,I_2)\),
\[
f(x)=e^{m\cdot x-|m|^2/2},\qquad D(t)=\tfrac12|m|^2e^{-2t}
\]
under both the driven process and its equilibrium reference \(F_{\rm eq}=-x\), because rotation changes only the direction of the mean, not its norm. Hence \(\xi(f)=0\) despite positive steady dissipation. This is a probe-visibility obstruction, not a counterexample to the inequality. The 2026 Guo–Huang source independently records zero curvature correction for the isotropic rotational Gaussian model (their Sec. VII.2, lines 367–370), so this obstruction is prior art, not a novelty claim.
