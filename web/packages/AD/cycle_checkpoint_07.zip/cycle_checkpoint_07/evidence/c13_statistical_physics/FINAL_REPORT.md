# C13: finite-amplitude relaxation curvature as a dissipation witness

## Frozen result

The strongest result from this round is a complete internal derivation of an exact finite-amplitude extension of the short-time Fokker–Planck relaxation inequality. For a diffusion with stationary density \(\rho\), current velocity \(u=F-T\nabla\log\rho\), and entropy-production rate \(\sigma=T^{-1}\langle|u|^2\rangle_\rho\), prepare any smooth strictly positive initial density \(p_0=\rho f\). Compare its initial relative-entropy curvature to \(\rho\) under the driven dynamics and the equilibrium reference drift \(F_{eq}=T\nabla\log\rho\). With
\[
G_f=-\frac{2T(\Delta f+\nabla\log\rho\cdot\nabla f)}{Tf}+\frac{|\nabla f|^2}{f^2}
=-\frac{2L_0f}{Tf}+\frac{|\nabla f|^2}{f^2},\qquad Q_f=\langle G_f^2|\nabla f|^2\rangle_\rho,
\]
and \(\xi=D''_{NESS}(0)-D''_{eq}(0)\), the exact identity is
\[
\xi=T\langle u\cdot(G_f\nabla f)\rangle_\rho,
\]
so \(\sigma\ge \xi^2/(T^3Q_f)\) whenever \(Q_f>0\). The full statement and proof are in [DERIVATION.md](DERIVATION.md).

For \(f=1+\epsilon\phi\), it recovers the published 2025 small-perturbation bound in the \(\epsilon\to0\) limit. The potential advance is limited to removing the small-relative-density-perturbation restriction for classical nondegenerate overdamped diffusions. It still requires full-field density access, differentiable positive profiles, a matched equilibrium comparator and noiseless curvature in the theorem. It does not establish practical finite-data inference, coarse-grained identifiability or novelty/priority.

## Source mechanism reconstructed

Auconi's primary 2025 article writes the Fokker–Planck equation as a continuity equation with local velocity, defines \(\sigma=T^{-1}\langle|u|^2\rangle\), perturbs \(p=\rho(1+\phi)\), and obtains \(\dot\phi=L_0\phi-u\cdot\nabla\phi\) (arXiv:2403.16631, Eqs. 2–7). The leading relative entropy is \(D\simeq\frac12\langle\phi^2\rangle\); its first derivative is the same for driven and equilibrium-reference dynamics. The second-derivative difference is \(\xi=-2T\langle\alpha u\cdot\nabla\phi\rangle\), where \(\alpha=\Delta\phi+\nabla\log\rho\cdot\nabla\phi\); Cauchy–Schwarz gives Eq. 12, \(\sigma\ge\xi^2/[4T^3\langle\alpha^2|\nabla\phi|^2\rangle]\). This is a source-derived, internally checked reconstruction of a published theorem, not the new result.

The key extension is to retain exact \(D=\langle f\log f\rangle\) and exact Fisher-information dissipation \(D'=-T\langle|\nabla f|^2/f\rangle\), then differentiate without a small-\(\phi\) expansion. The calculation is recorded line by line in the derivation artifact. All claims and assumptions are machine-readable in [CLAIMS.json](CLAIMS.json).

## Adversarial check and practical limit

For rotational OU with \(\rho=N(0,I_2)\), \(F=-(I+\omega R)x\), the steady current gives \(\sigma=2\omega^2\). A shifted Gaussian probe \(N(m,I_2)\) has KL \(|m|^2e^{-2t}/2\) under both the driven system and its equilibrium reference. Thus its curvature signal is exactly zero at positive dissipation. This does not refute the bound; it shows probe visibility is a load-bearing condition. The close 2026 Guo–Huang preprint independently identifies zero signal for an isotropic rotational Gaussian model, so this is retained as a known failure mode rather than novelty.

An implementation would have to measure or reconstruct \(\rho\) and \(f\), evaluate derivatives in \(Q_f\), prepare the same initial density under both the driven and equilibrium reference dynamics, and estimate two short-time curvature values. Finite precision, boundary truncation, small values of \(f\), spatial resolution and rare-tail sampling are uncharged in the mathematical inequality. No such estimator or experiment was implemented in this round. The immediate decisive gate is to determine whether a bounded, experimentally accessible probe class can guarantee a nontrivial angle/visibility to \(u\) without already measuring the current field, and to derive finite-sample error bars for \(\xi,Q_f\).

## Novelty and status

Auconi's 2025 PRL is direct primary prior art for the local inequality. Guo and Huang's September 2026 arXiv preprint generalizes the local curvature construction to quantum Markov generators via the BKM metric; its conclusion lists finite perturbations as future work. The current classical extension therefore has a plausible narrow novelty boundary, but only an internal proof. Status: **candidate theorem, exact derivation, novelty UNKNOWN, empirical capability untested**. The derivative extension is mathematically elementary once the exact Fisher-information identity is written; no claim is made that it rises to a major field-level advance.

No children were spawned. No downloads or external messages were made. This round stops here per parent steering.
