# Hostile audit: paid slow-read HMM acquisition

## Verdict

The fixed-sample model construction is repairable and its central conditioning idea is sound: if an unknown but shared full-rank emission matrix stays constant while a state is held with high probability, repeated categorical reads identify its columns up to one common permutation at a read count proportional to \(\kappa^{-2}\). Independent founders then supply the transition rows for one of two *specified* candidate kernels.

The theorem is conditional on a strong action interface: for every relevant hidden generator, a calibrated positive control can scale all transition rates to \(\rho Q_b\), with \(\rho\) selectable down to order \(1/R\), while preserving the same emission matrix and meeting a very small ramp-jump budget. This is an effective near-freeze primitive at the requested confidence scale. It is paid in frames, elapsed time, ramps, calibration and actuator use, but it is not derived from the cited cryo protocols. The biological application remains UNKNOWN.

There is a parameter-count mismatch in the written proof: its coordinatewise frequency radius gives \(R=O(K\kappa^{-2}\log)\) frames per block, while the report multiplies founder blocks as though \(R=O(\kappa^{-2}\log)\). Taken literally, the displayed bounds yield \(O(K^2/(p_*\gamma^2)\,\kappa^{-2}\,\mathrm{polylog})\) total frames. A dimension-free Euclidean concentration bound for the categorical frequency vector repairs this factor and recovers the reported \(K\) prefactor. The \(\kappa^{-2}\) exponent is sound either way.

The unknown-\(\kappa\) doubling rule also needs an anytime-confidence schedule; the fixed-\(R\) tail bound alone does not survive stopping at the first successful epoch. This is a standard repair with confidence spending or a time-uniform boundary, at a logarithmic cost. No no-reset, hidden-label, or ordinary normalization defect was found in the fixed-budget construction.

## Supplied, acquired, and assumed

| Quantity | Status in the proof |
|---|---|
| State count \(K\), read alphabet size \(K\), and the two candidate transition kernels \(P_0,P_1\) | Supplied/known. This is a fixed-pair test, not general unknown-HMM discovery. |
| Permutation-orbit gap \(\gamma=\min_S\|P_0-S^{-1}P_1S\|_F>0\) | Determined from the supplied pair (or must be supplied as a certified lower bound). If kernels are uncertain, a profiled gap is needed; this theorem does not provide it. Computing/minimizing over permutations can cost up to \(K!\) by direct enumeration. |
| Emission matrix \(E\) | Unknown and learned from repeated categorical frequencies. It is assumed square, column-stochastic, shared across all blocks/actions/hypotheses, constant within and between blocks, and full rank. |
| \(\kappa=\sigma_{\min}(E)\) | Unknown to the read-count algorithm. It appears in the theorem's bound, not the stopping rule. Unknown-\(\kappa\) adaptation needs the confidence repair below. |
| Hidden state names | Never supplied. Emission clusters choose one common arbitrary permutation; all probe endpoints are classified against the same calibration centers. |
| Initial law \(\pi\) | Unknown, but common across founders and hypotheses. A known/certified lower bound \(\pi_i\ge p_*>0\) is used for finite founder caps. A pilot or sequential rule is possible, but its confidence and realized founder cost must be included. |
| Rate bound \(\Lambda\), fixed positive read duration \(\Delta\), action factor \(\rho\), and per-block ramp-jump bound \(q_{\rm ramp}\) | Must be physically calibrated/certified. The theorem is not an acquisition procedure for these control quantities. |
| Slow action | Assumes a family of controls \(S_\rho\) with \(Q_b^{S_\rho}=\rho Q_b\), \(0<\rho<1\), or an equivalent certified exit-rate envelope, for every candidate \(b\). It must preserve \(E\). |

The probe word's pulse and switching-ramp kernels are part of \(P_b\). Slow-read blocks additionally have their own entry/exit ramps. Independent native founders provide independent starting states; no state reset, free labels, or repeated independent samples from one lineage are assumed.

## Reconstructed fixed-budget statistical argument

For state \(i\), let \(e_i=E_{\cdot i}\). Full rank gives

\[
 \|e_i-e_j\|_2=\|E(\mathbf e_i-\mathbf e_j)\|_2
 \ge \sqrt2\,\kappa=:d_0\quad(i\ne j).
\]

During a block of \(R\) frames with no hidden transition, the empirical category-frequency vector \(\widehat e\) is the mean of \(R\) iid one-hot vectors with mean \(e_i\). If every calibration and endpoint block is pure and its frequency vector is within \(r\) of its state column, then two blocks from one state are within \(2r\), while distinct-state blocks are at least \(d_E-2r\) apart. With \(r\le d_E/16\), thresholding pairwise block distances at \(4r\) creates exactly one component per occupied state. A component average is within \(r\) of its true emission column. Classifying every later endpoint against the same centers recovers one global state ordering; it does not independently relabel each block.

The proof's displayed coordinatewise Hoeffding bound is valid:

\[
 \Pr(\|\widehat e-e_i\|_2\ge r)
 \le 2K\exp(-2Rr^2/K).
\]

For \(B=N_c+2N_t\) total blocks, it yields \(r_R=\sqrt{K\log(8KB/\alpha)/(2R)}\) and sufficient

\[
 R\ge 64K\kappa^{-2}\log(8KB/\alpha).
\]

This is the bound actually used in PROOF.md. It entails a factor \(K\) in frames *per block*.

That factor is not necessary. A dimension-free Euclidean bound follows directly for the same frequency vector. If \(Z_s\) are iid one-hot vectors, then

\[
 \mathbb E\|R^{-1}\textstyle\sum_s Z_s-e_i\|_2^2
 =\frac{1-\|e_i\|_2^2}{R}\le R^{-1},
\]

and changing one observation changes the norm by at most \(\sqrt2/R\). McDiarmid therefore gives

\[
 \Pr\!\left(\|\widehat e-e_i\|_2>
 R^{-1/2}+\sqrt{\frac{\log(1/\delta)}R}\right)\le\delta.
\]

Union-bound over \(B\) blocks with \(\delta=\alpha/(4B)\). A sufficient radius is

\[
 r_R^{\rm vec}=R^{-1/2}+\sqrt{\frac{\log(4B/\alpha)}R},\qquad
 R\ge C\kappa^{-2}\bigl(1+\log(4B/\alpha)\bigr),
\]

for a universal constant \(C\). This keeps the same clustering proof and removes the extraneous \(K\) from \(R\).

For the probe cohort, let \(m_{\rm row}=C K\gamma^{-2}\log(K/\alpha)\). For each empirical row vector, \(\mathbb E\|\widehat p_i-p_i\|_2^2\le1/m_{\rm row}\), and changing one endpoint changes its norm by at most \(\sqrt2/m_{\rm row}\). McDiarmid's inequality and a union bound over the \(K\) rows show every row error is at most \(\gamma/(8\sqrt K)\) with that sample count; hence \(\|\widehat P-P_b^{(S)}\|_F\le\gamma/8\) for the common unknown permutation \(S\). A nearest-orbit test then has distance at most \(\gamma/8\) to the true candidate orbit and at least \(7\gamma/8\) to the other orbit. The row estimator does not require estimating \(\pi\), but the founder cap does require \(\pi_i\ge p_*\).

Coupon-collector and binomial lower-tail bounds support

\[
 N_c=O\!\left(p_*^{-1}\log\frac K\alpha\right),\qquad
 N_t=O\!\left(\frac{m_{\rm row}+\log(K/\alpha)}{p_*}\right),\qquad
 B=N_c+2N_t.
\]

The reported \(N_t\) is an independent-founder cap. A sequential implementation that stops after seeing \(m_{\rm row}\) pre-state labels in every class must return UNKNOWN on cap failure and report its realized cost.

## Slow-action and jump accounting

With per-block jump probability \(q_R\le q_{\rm ramp}+\rho\Lambda R\Delta\), the union bound over all \(B\) slow blocks is at most \(Bq_R\). The proof allocates \(\alpha/4\), so it requires

\[
 q_{\rm ramp}<\frac{\alpha}{4B},\qquad
 0<\rho\le \min\!\left\{\tfrac12,
 \frac{\alpha/(4B)-q_{\rm ramp}}{\Lambda R\Delta}\right\}.
\]

This includes every pre-, post-, and calibration-block ramp and the entire held interval. On the joint no-jump event, each frequency vector is sampled from one state-specific column. If the ramp floor exceeds the threshold, there is no theorem guarantee. Because \(B\) grows like \(K/(p_*\gamma^2)\), the per-block ramp requirement can be demanding even though it does not worsen with \(\kappa\) for a fixed pair.

For any fixed positive hardware floor \(\rho_{\min}\), the requested \(R\asymp\kappa^{-2}\) eventually violates the hold bound as \(\kappa\to0\). Thus the asymptotic exponent presumes no such floor in its stated range, or a declared finite \(\kappa\) range with a compatible \(\rho_{\min}\). Choosing \(\rho=O(1/R)\) makes the hidden state nearly static at the target error scale. It is not a mathematical zero-time freeze: each read lasts \(\Delta>0\), and all hold/ramp time is paid. It is nevertheless the load-bearing near-freeze action, not a consequence of passive imaging.

Physical elapsed time includes at least \(BR\Delta\) plus every ramp, nominal pulse, culture, exposure, viability/recovery, reporter-calibration, actuator-calibration, and failed-track cost. If lowering \(\rho\) makes the control cost per time diverge, the all-in cost need not scale as \(\kappa^{-2}\). The proof establishes a read/frame exponent (and bounded per-frame wall-time exponent), not a universal assay-cost exponent. Calibrating \(q_{\rm ramp}\), \(\Lambda\), \(\rho\), and emission stability needs data or a mechanistic certificate; no sample count for that calibration is derived.

## Total frame-count audit and repaired statement

Using the bounds literally printed in PROOF.md,

\[
 B=O\!\left(\frac{K}{p_*\gamma^2}\log\frac K\alpha\right),\qquad
 R=O\!\left(K\kappa^{-2}\log\frac{KB}{\alpha}\right),
\]

so their product is

\[
 BR=O\!\left(\frac{K^2}{p_*\gamma^2\kappa^2}
 \log\frac K\alpha\,\log\frac{KB}{\alpha}\right),
\]

not the reported explicit \(K\)-linear bound. The \(O(K/(p_*\gamma^2)\kappa^{-2}\,\mathrm{polylog})\) bound is recoverable by replacing the coordinatewise block-frequency inequality with the dimension-free Euclidean inequality above. If one does not make that proof repair, the theorem report should state the \(K^2\) prefactor. Both versions have \(\kappa^{-2}\) for fixed \(K,p_*,\gamma\).

The remaining fixed-budget error allocations are coherent: occupancy for calibration and probe cohorts costs \(\alpha/8\) each; all-block frequency concentration costs \(\alpha/4\); all-block state changes cost \(\alpha/4\); transition-row estimation costs \(\alpha/4\). Their sum is \(\alpha\). This accounts for the finite-sample event provided the stated inputs and no-jump bounds hold.

## Unknown \(\kappa\): adaptive-confidence repair

The fixed-radius tail bound does not, by itself, justify stopping at the first doubling epoch whose observed graph has \(K\) components. The stopping event is data-dependent, and an \(\alpha/4\) guarantee at each fixed \(R_j\) cannot be reused across arbitrarily many epochs.

One finite repair is to declare a maximum epoch \(J\) and maximum block length \(R_J\), select a positive \(\rho\) from that maximum so the all-block jump budget holds even if the procedure reaches \(R_J\), and spend concentration error \(\alpha_j\) across epochs with \(\sum_{j=0}^J\alpha_j\le\alpha/4\). Use the dimension-free (or coordinatewise) radius with \(\alpha_j/(B)\) at epoch \(j\). On the simultaneous event, stopping at the first valid \(K\)-component certificate is safe; if no certificate appears by \(J\), return UNKNOWN. This adds only a logarithm of the epoch count to the radius. An anytime multinomial confidence sequence is another repair. If \(\rho\) is changed by epoch instead, every epoch's extra blocks and ramps must be included in the global \(B\) and jump allocation.

To avoid assuming \(p_*\), a separate sequential pilot can use known \(K\), certified clusters, and time-uniform multinomial bounds to return a lower confidence bound on all \(K\) state frequencies. If a class has not appeared or its lower bound is zero, the fixed-cap theorem cannot be invoked; continue with a declared sequential cost rule or return UNKNOWN. The proof's optional pilot statement is a proposal until this confidence schedule and cost are specified.

## Equally informed likelihood control and scope

For the explicit uniform stationary cycle pair and \(E_\kappa=\kappa I+(1-\kappa)\mathbf1\mathbf1^T/3\), the two-read law satisfies

\[
 J_0-J_1=\frac{\kappa^2}{3}(P_0-P_1)^T,\qquad
 D_{\rm KL}(J_0\|J_1)=\frac{\kappa^4}{2}\|P_0-P_1\|_F^2+o(\kappa^4).
\]

For this fixed passive pair-law experiment, KL adds over independent founders and the two-point testing inequality gives \(\Omega(\kappa^{-4})\) pairs for any fixed error below \(1/2\). This lower bound still holds for an optimal likelihood-ratio test that is told \(E\) and \(\pi\), so it is a strong equally informed passive control. It does **not** lower-bound every passive multi-time trajectory method or every action policy.

The slow-read estimator receives the new near-freeze action and the specified candidate transition pair. An optimal likelihood-ratio/composite-likelihood test given the same active read data and the same candidate family is at least as informed as clustering plus nearest-orbit comparison. No minimax or strict advantage over that active likelihood control is proved. The defensible comparison is only: a constructive active upper bound versus an optimal passive *two-read pair-law* lower bound on the named witness.

The current \(\gamma\) is separation between two known finite matrices, not the profiled gap between two unknown HMM parameter families. Unlike the prior Cycle 3 word-law interface, this theorem neither profiles over unknown transition/rate parameters nor solves general model identification. It also assumes \(K\) supplied; if \(K\) is unknown, the stopping and occupancy statements need additional model-order certification.

## Evidence boundary and disposition

- **Internally reconstructed, conditional:** fixed-pair transition discrimination from unknown but stable full-rank emissions, with positive calibrated slow action, full-support initial law, and per-block ramp/hold jump bounds.
- **Frame exponent:** \(\kappa^{-2}\) is supported for fixed \(K,p_*,\gamma\). The printed proof gives explicit \(K^2\); a dimension-free vector concentration lemma repairs the claimed explicit \(K\) factor.
- **Adaptive algorithm:** repairable, but epochwise confidence allocation and a rate choice safe through the declared budget must be included.
- **Action interface:** the arbitrary-positive \(\rho\) rate multiplier and emission invariance are the load-bearing near-freeze assumptions. Physical cryo-arrest references establish selected repeated-imaging protocols only; they do not establish those assumptions for arbitrary fate states.
- **No biological validation or novelty clearance:** transition/emission calibration, ramp floor, actuator lower-rate floor, and all-in cost remain UNKNOWN for a named fate-state assay.
- **Finite computation:** the saved witness is explicitly floating-point, not interval-certified; I did not rerun it because the task is proof/interface audit.
