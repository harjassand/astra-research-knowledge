# C13: intervention-faithful mesoscopic models of developmental signaling

## Result

I found a precise first gate for mesoscopic intervention models: the candidate macrostate must have action-indexed transition rates that are nearly constant over every hidden microstate fiber. The strongest source-specific obstacle is nonlinear ligand–inhibitor pairing in the 2025 BMP temporal-relay mechanism. A two-cell exact counterexample shows that pooled BMP and inhibitor means can be identical while the initial pSMAD drift differs by 25 percentage points of the normalized response rate. The controlled lumpability theorem and a finite-horizon terminal-distribution bound are complete under finite CTMC assumptions; these are established Markov aggregation mathematics, not new priority claims.

No calibrated organoid model or intervention capability follows. The biology-facing result remains UNKNOWN until paired spatial signaling, transport, and lineage measurements identify the relevant state and generator.

## Primary mechanism and scope

Lehr et al. (Developmental Cell, 2025; DOI 10.1016/j.devcel.2024.10.024) report a fast BMP-to-pSMAD response, BMP-induced inhibitor feedback, then delayed LMX1A/WNT/endogenous-BMP positive feedback. The paper measures pSMAD and LMX1A half-lives of about 0.43 h and 4.7 h, respectively, and uses a radial reaction-diffusion model for ligand/inhibitor signaling. That source model is the biological mechanism used here. It does not include stochastic cell movement; movement and lineage memory would need to be added and measured for a moving-organoid model.

The cycle checkpoint also records a separate SkullWave morphogenesis model lane; this report does not reuse that source packet. Contemporary human brain-organoid light-sheet work (Jain et al., Nature 2025) shows matrix-associated coordinated cell/tissue flow and WNT/YAP1/WLS-linked regionalization, motivating measurement of cell transport as a potentially load-bearing state variable, but it is not used as a BMP rate premise.

## Mathematical result

For a finite controlled CTMC, exact intervention-faithful aggregation holds iff every action gives every pair of hidden states in a macro fiber the same rate into each macrostate. If a candidate coarse generator has uniform generator-intertwining row-l1 defect at most `delta`, the terminal macro distribution under a fixed piecewise-constant intervention schedule is within TV `delta*T/2` at horizon `T`. See [PROOF.md](PROOF.md) for complete statements and derivation.

The source-specific counterexample uses the first-phase Hill response with `h=1`, `K_i=1`: `g(b,i)=b/(b+i)`, and `g(0,0)=0`. Microstate A has cells `(1,0),(0,1)`; microstate B has `(1,1),(0,0)`. Both have mean BMP and inhibitor equal to `1/2`, yet mean pSMAD production is `1/2` in A and `1/4` in B. Thus means alone fail even before adding the slower relay. Exact rational calculation is in [nonclosure_witness.py](nonclosure_witness.py).

## Prior art and novelty boundary

Exact Markov lumpability and stochastic reaction-network reduction predate this work. Formal transient error bounds for reduced Markov chains were published in 2025. The criterion and residual bound are therefore application-oriented restatements/specializations. Nonlinear moment non-closure is also standard. The candidate contribution is a concrete missing-state witness for the particular fast-inhibitor/slow-autocrine BMP mechanism and a usable intervention-specific certificate interface, not a novelty or priority claim.

## Costs and evidential boundary

For a finite enumerated CTMC, a sparse residual calculation is `O(|A|*|E_Q|)` in actions and generator edges; the underlying state space can be exponential in cell count and molecular copy-number cutoffs. A tissue application additionally needs repeated live BMP/pSMAD/inhibitor/LMX1A/WNT measurements, cell positions and exchanges, lineage/fate tracking, dose and blockade schedules, and parameter uncertainty bounds. The published source provides time-course perturbations and fixed-time signaling/fate assays but not all paired trajectories needed to estimate this generator. No external experiment, code replay of the article, parameter fit, or biological prediction was performed here.

## Decisive next gate

Compare matched-mean BMP pulse conditions with different measured local ligand–inhibitor pairing, while recording pSMAD and delayed LMX1A/WNT/fate response and tracking cell movement. If response drift and downstream fate distributions agree after conditioning on the proposed macrostate across those intervention schedules, the specific covariance witness is not material in that regime. If they differ, retain local pairing or add a spatial/temporal state and recompute the action-indexed defect. This requires a live signaling reporter or repeated time-resolved fixation with spatial registration; marker panels, sample counts, and achievable uncertainty are not yet specified by the cited work.

## Artifacts

- [PROOF.md](PROOF.md): exact theorem, finite-horizon error bound, counterexample, status, costs.
- [CLAIMS.json](CLAIMS.json): machine-readable claim ledger, assumptions, status, falsifiers, and next gates.
- [SOURCES.md](SOURCES.md): primary sources, prior-art boundaries, read locations, and Astra route.
- [nonclosure_witness.py](nonclosure_witness.py): exact rational finite diagnostic.
