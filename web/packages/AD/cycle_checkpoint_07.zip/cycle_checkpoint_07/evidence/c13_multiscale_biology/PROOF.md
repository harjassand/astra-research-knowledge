# Controlled aggregation criterion and BMP mean-closure witness

## Interface

Let `X_t` be a finite-state continuous-time Markov model of a tissue. A microstate may include, for each cell, molecular copy counts or discretized activity states, fate/lineage state, local neighborhood, and position, together with extracellular ligand and inhibitor states. Cell movement and molecular transport are transitions of this same chain. A fixed intervention `a` (for example, BMP pulse, BMP-receptor blockade, or a genetic knockout) selects a generator `Q^a`. Let `phi : X -> Z` map microstates to a proposed mesostate, such as spatial-bin counts and field averages.

For a microstate `x`, define the projected rate measure on macrostate `z'` by

`Q^a_phi(x,z') = sum_{y: phi(y)=z'} Q^a(x,y)`.

The diagonal entry is the negative sum of off-diagonal entries.

## Exact all-intervention criterion

The projection `Z_t = phi(X_t)` is a Markov chain with an action-specific generator `Qbar^a`, for every point-mass initial condition and every piecewise-constant open-loop intervention schedule, if and only if

`Q^a_phi(x,.) = Q^a_phi(x',.)`

for every action `a` and all microstates `x,x'` with `phi(x)=phi(x')`. If this holds, the common row defines `Qbar^a(z,.)`.

**Proof.** For sufficiency, take any function `f` on `Z`. The micro-generator applied to its pullback satisfies

`Q^a(f o phi)(x) = sum_{z'} Q^a_phi(x,z') f(z') = (Qbar^a f)(phi(x))`.

Thus the generator maps every pulled-back macro-observable to a quantity depending only on the current macrostate. The projected semigroup therefore has generator `Qbar^a`; composing the semigroups over the intervals of a piecewise-constant schedule proves the schedule claim. For necessity, start at either `x` or `x'`, hold `a` constant, and differentiate at time zero the probability of being in any macrostate `z'`. The derivative is `Q^a_phi(x,z')` or `Q^a_phi(x',z')`; a single macro generator for both initial conditions forces equality. This is controlled strong lumpability, an established Markov-chain criterion stated with one generator per intervention. It is not a new general theorem.

## Finite-horizon approximate criterion

Choose any candidate coarse generator `Qbar^a`. Suppose the generator intertwining defect satisfies

`sup_{a,x} sum_{z'} |Q^a_phi(x,z') - Qbar^a(phi(x),z')| <= delta`.

For a fixed piecewise-constant open-loop intervention schedule, and initial coarse law matched to `phi# mu_0`, the terminal macro laws at every `t <= T` obey

`TV(phi# Law(X_t), Law(Zbar_t)) <= min(1, delta*t/2)`.

Here `TV(p,q)=1/2 sum_z |p(z)-q(z)|`. To see this, write the forward equations for the projected microscopic law and the coarse law. Their difference has a forcing term `mu_s (Q^a P - P Qbar^a)` and a homogeneous term propagated by a Markov semigroup. The latter contracts the `l1` norm; the forcing has `l1` norm at most `delta`. Integration gives an `l1` error at most `delta*t`, hence the displayed bound. The argument composes across a piecewise-constant schedule. This certifies only terminal-state distributions for prescribed schedules; path laws and feedback policies need an augmented-state or separate coupling argument.

This residual certificate charges the complete action-indexed micro-to-macro transition rates, including molecular noise, fate changes, cell exchange, and extracellular transport. If memory is omitted, hidden inhibitor/LMX1A/WNT states appear as within-fiber rate variation. If transport is omitted, boundary-crossing transitions appear in the same defect. The bound is only as useful as the supplied microscopic rate model and a justified finite-state truncation.

## Non-closure in the 2025 BMP mechanism

Lehr et al.'s primary model uses local BMP `b`, BMP inhibitor `i`, pSMAD `s`, and LMX1A `l`; BMP and inhibitor diffuse, while pSMAD production is a nonlinear local function of `b` and `i`. In its first-phase reduction, the activation factor is

`g(b,i) = b^h / (b^h + (i/K_i)^h)`,

with production restricted to the colony and degradation proportional to `s`. This is the source-reported model structure, not a claim that the generic inhibitor is one molecular species. The authors report a fast pSMAD half-life of `0.43 +/- 0.03 h`, an LMX1A half-life of `4.7 +/- 0.5 h`, and a slow positive relay involving LMX1A/WNT and endogenous BMP production. Their radial PDE does not include stochastic cell movement; those transitions must be added and measured before applying a tissue-level intervention certificate to moving organoids.

Set `h=1`, `K_i=1`, zero initial pSMAD, and use two equal-volume cells. Extend `g(0,0)=0`, consistent with no BMP signal when ligand is absent. Consider two microstates:

| State | Cell 1 `(b,i)` | Cell 2 `(b,i)` | mean `b` | mean `i` | mean pSMAD production |
|---|---|---|---:|---:|---:|
| A | `(1,0)` | `(0,1)` | `1/2` | `1/2` | `1/2` |
| B | `(1,1)` | `(0,0)` | `1/2` | `1/2` | `1/4` |

Both states have identical spatially pooled ligand, inhibitor, pSMAD, and fate summaries. Yet the average pSMAD-production derivative differs by `1/4` rate units. Equivalently, total first-order pSMAD-on rates are `1` versus `1/2`. This violates the necessary exact-lumpability equality for the pooled-mean projection, even before the hidden slow relay is activated. The cause is the within-bin pairing of ligand and inhibitor: the nonlinear local response depends on their joint distribution, which the means discard. Adding nonzero diffusion or cell-motion transitions does not change this instantaneous reaction-rate witness; those transitions must themselves be represented in the macro generator for later times.

This is a mathematical counterexample in a two-cell discretization of the published response function. It does not show that the published in-vitro patterning results are wrong, or that the source's measured spatial profiles realize these particular microstates. It rejects only the claim that ligand and inhibitor means alone are universally sufficient for controlled dynamics.

## Minimal practical repair and remaining gate

For a finite-cell model, the immediate repair is to retain local (or spatial-bin) ligand/inhibitor pairing and the slow relay state, then represent cell and ligand transport as explicit transitions. If rates are available, compute the action-indexed defect above; split bins or add state coordinates where the defect exceeds `2 epsilon/T` for a desired terminal TV tolerance `epsilon` over horizon `T`. A complete biology-facing version still needs a defensible microstate model, parameter uncertainty intervals, and a measured connection from signaling trajectories to downstream fate fractions. None is supplied by the two-cell counterexample.

## Cost and status

For an explicitly enumerated finite chain, calculating the defect costs `O(|A| * |E_Q|)` using sparse generator edges plus aggregation by macrostate; the state space can be exponential in cell number and molecular copy cutoffs. No rate inference, noise calibration, cell-tracking, or external experiment was performed here. The theorem is established mathematics under its stated finite-state assumptions; its usefulness and any biological intervention conclusion remain `UNKNOWN` pending the missing model/data gate.
