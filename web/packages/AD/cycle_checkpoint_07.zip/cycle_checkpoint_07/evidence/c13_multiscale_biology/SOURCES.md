# Source ledger

## Primary developmental mechanism

Stefanie Lehr, David B. Brückner, Thomas George Minchington, Martina Greunz-Schindler, Jack Merrin, Edouard Hannezo, and Anna Kicheva. “Self-organized pattern formation in the developing mouse neural tube by a temporal relay of BMP signaling.” *Developmental Cell* 60(4), 567–580 (2025). DOI: https://doi.org/10.1016/j.devcel.2024.10.024 . Open article/PDF: https://cytoo.com/wp-content/uploads/2025/06/Self-organized-pattern-formation-in-the-developing-mouse-neural-tube-by-a-temporal-relay-of-BMP-signaling.pdf . Open-access source repository cited by article: https://github.com/dbrueckner/NeuralTubeColonies ; Zenodo snapshot: https://doi.org/10.5281/zenodo.13335390 .

Read in the primary article: abstract and main-text summary (PDF pp. 1–2); perturbation windows and first/second pSMAD phases (pp. 3–5); LMX1A/WNT positive-feedback mechanism and measured degradation half-lives (pp. 5–8); model equations and boundaries (STAR Methods, pp. 22–27). The article reports (a) local BMP and inhibitor diffusion, (b) pSMAD activation through a Hill response to BMP/inhibitor, (c) a delayed LMX1A/WNT/endogenous-BMP positive relay, (d) pSMAD half-life `0.43 +/- 0.03 h`, and (e) LMX1A half-life `4.7 +/- 0.5 h`. It also reports that the model is radially symmetric and contains reaction-diffusion for molecular fields; its listed equations do not include stochastic cell motion.

## Contemporary organoid transport context

Akanksha Jain et al. “Morphodynamics of human early brain organoid development.” *Nature* 644, 1010–1019 (2025). DOI: https://doi.org/10.1038/s41586-025-09151-3 . Primary article: https://www.nature.com/articles/s41586-025-09151-3 . Long-term light-sheet tracking reports matrix-associated coordinated cell/tissue flows, lumen expansion, and regionalization correlated with WNT/YAP1/WLS signaling. This is separate evidence motivating explicit motion measurements; it is not used as a rate premise in the BMP counterexample.

## Prior art limiting novelty

1. “Formal error bounds for the state space reduction of Markov chains.” *Performance Evaluation* 167 (2025), 102464. DOI: https://doi.org/10.1016/j.peva.2024.102464 . This directly establishes formal transient-distribution error bounds for reduced CTMC/DTMC state spaces and approximate aggregations. The finite-horizon residual bound here is an elementary generator-intertwining specialization, not a priority claim.
2. A. Cardelli et al., “Exact maximal reduction of stochastic reaction networks by species lumping.” *Bioinformatics* 37(15) (2021), 2175–2182. https://academic.oup.com/bioinformatics/article/37/15/2175/6126804 . This addresses exact stochastic reaction-network reduction through species equivalence for arbitrary initial states. Its established scope blocks novelty claims for exact stochastic lumping itself.
3. Kemeny–Snell strong lumpability, and subsequent continuous-time Markov-chain lumping literature, provide the classical criterion restated in `PROOF.md`. The action-indexed version is required because interventions change the generator; it is not presented as a new theorem.

## Astra route and boundaries

Pinned prior revision is `8ede33c2f09a8abe07b430892b3ac4bb71c27c83`. Read `work/ROOT_MANDATE.txt`, `work/astra_prior/00_START_HERE.txt`, `work/astra_prior/01_CORE.txt`, `work/astra_prior/AGENTS.md`, `work/astra_prior/RESEARCH_WORKFLOW.txt`, and `outputs/research/cycle_checkpoint_06/CYCLE10_PROGRESS.txt`. The local topic index contains no specific organoid/BMP card. Nearby `N54-spatial-permanence` is a different reaction-diffusion permanence result and is not a premise here. The cycle checkpoint identifies a separate SkullWave morphogenesis lane, which this work does not reuse.
