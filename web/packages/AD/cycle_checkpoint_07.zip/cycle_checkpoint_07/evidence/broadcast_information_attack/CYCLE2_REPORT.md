# Cycle 2: Bayesian information-theoretic attack on bounded-Holevo broadcasting

## Verdict

The general bounded-Holevo, vanishing-broadcast-error implication is still **UNKNOWN**: this cycle proves neither the full implication nor a qualifying counterexample. It does produce a quantitative, dimension-free theorem for every finite experiment. For a family of N states with Holevo capacity at most C, a permutation-invariant K-receiver extension of T has one full-domain entanglement-breaking (EB) marginal approximation with worst-state half-trace error at most

\[
  \frac{N}{2}\sqrt{\frac{2C}{K}}.
\]

The proof uses Brandão–Harrow's local-measurement de Finetti chain argument, sharpening the proof's final \(\ln N\) entropy cap to the actual output Holevo information. The conversion from one common measurement to statewise trace distance uses a single randomized Helstrom-test POVM and pays the explicit factor N. This is not a capacity-only theorem: C does not bound N, even for commuting families.

For a two-output broadcaster with worst marginal half-trace error b, recursive iteration and output twirling therefore give

\[
  e_{\rm EB}(\mathcal E)\le t b+\frac{N}{2}\sqrt{\frac{2C}{2^t}},
  \qquad t\in\mathbb N.
\]

Thus `b log N -> 0` is a sufficient complexity condition when C is uniformly bounded. Independently, the general permutation-invariant finite de Finetti theorem of Chiribella gives the complementary all-family bound $e_{\rm EB}\le tb+d^2/2^t$ for receiver dimension d; consequently `b log d -> 0` suffices. The d^2 dependence is essential to this cited theorem's interface: a tree-twirled output is permutation invariant, not necessarily supported on the Bose-symmetric subspace.

## Interface and inherited evidence

At each sequence index all spaces are finite-dimensional. The input family is $\mathcal E=\{\rho_x:x\in[N]\}$, with capacity

\[
  C(\mathcal E)=\sup_{p\in\Delta_N}\chi(\{p_x,\rho_x\}).
\]

A full-domain CPTP two-output channel is allowed to produce correlated outputs; b bounds the half-trace error of each one-receiver marginal on every promised state. The decoder is one full-domain EB CPTP channel. There are no uncharged physical side registers. The Choi reference below is a proof representation, not an extra output of either the broadcaster or the decoder.

Cycle 1's [report](FINAL_REPORT.md) records the exact corrected N93 reductions, the N61 copy-ladder and capacity calculation, and the N92 supplied-instrument theorem. The pieces relevant here are:

- N93 reduces the bounded-capacity family problem, at fixed smoothing tolerance and capacity bound, to a faithful fixed sandwich \(\sigma/2\le\rho_x\le3\sigma/2\), retaining \(\sigma\) and the same broadcaster. Compatible smoothing has fixed-parameter transport \(O(b^{1/4})\), with constants growing rapidly in the capacity and smoothing tolerance. The corrected Petz step makes the common marginal preserve \(\sigma\), with a full-domain compatible correction and residual \(b'=O(b^{1/4})\). These are internally audited source-derived reductions, not an efficient compiler and not the missing EB conclusion.
- N61's faithful pure-copy ladder has marginal broadcast error \(b_2\le1/L\) and EB error tending to one for \(d=L2^{L-1}\), but its Haar-prior Holevo information obeys \(\chi\ge L^{-1}\log\binom{m+d-1}{m}=\Omega(2^L\log L/L)\), \(m=2^{L-1}\). It therefore does not contradict the bounded-capacity target. Exact finite moment designs retain the source theorem's family interface but their cardinality/acquisition cost is large and not efficient.
- N92 proves a dimension-free EB rounding for an explicitly supplied bistochastic Kraus instrument. For \(L(A)=\sum_yK_yAK_y^*\), \(\Psi(A)=\sum_y\tau(M_yA)M_y/\tau(M_y)\), \(C=(L+\Psi)/2\), and \(\Phi=C^*C\), the exact SOS identity is
  \[
  2(I-\Phi)-(I-\Psi)=(I-L^*L)+(\Psi-\Psi^2)+\tfrac12(L-\Psi)^*(L-\Psi)\ge0.
  \]
  This gives the stated EB residual bound on that class, but no representation theorem covers every positive selfadjoint self-compatible marginal. Full N92/N93 interfaces, proof spans and source hashes are retained in `FINAL_REPORT.md` and `SOURCE_NOTES.md`.

The information-theoretic argument below does not need the N93 sandwich: it applies directly to any finite family with bounded Holevo capacity. The N93 reduction remains useful for the separate unrestricted-operator route.

## Finite-family theorem

Let \(\mathcal B_K:A\to B^{\otimes K}\) be a full-domain CPTP channel whose output is invariant under receiver permutations. Let \(T:A\to B\) be its common one-receiver marginal. For every finite input family \(\{\rho_x\}_{x=1}^N\) with Holevo capacity at most C, there is one full-domain EB channel \(\Psi:A\to B\) such that

\[
  \max_{x\in[N]}\frac12\|T(\rho_x)-\Psi(\rho_x)\|_1
  \le \frac N2\sqrt{\frac{2C}{K}}. \tag{1}
\]

This is an internal extension of the Brandão–Harrow proof, not a theorem stated in their paper. The primary paper is [arXiv:1210.6367](https://arxiv.org/abs/1210.6367), Theorem 1, proof Eqs. (49)–(60), PDF pp. 21–23. The stated theorem has \(\sqrt{2\ln|\widetilde A|/K}\). In the proof's singleton classical-operation case, the only use of \(\ln|\widetilde A|\) is the upper bound on the final measured chain mutual information. That term can be replaced by actual \(I(X:B^K)\) by data processing. The proof works for ordinary K-extendibility/permutation invariance; it does not assume Bose-symmetric support.

### Proof

Fix any prior \(p\) on the family and write \(\bar\rho=\sum_xp_x\rho_x\). Use the canonical purification of \(\bar\rho\) on a reference R and the input A, then apply \(\mathcal B_K\) to A. This gives the normalized Choi-type state \(\omega_{RB^K}\), whose receiver systems are permutation invariant. On \(R\), the HJW POVM

\[
  F_x=p_x\bigl(\bar\rho^{-1/2}\rho_x\bar\rho^{-1/2}\bigr)^T
\]

is defined on \(\operatorname{supp}\bar\rho^T\) and sums to its support projector. Its classical outcome X prepares the unnormalized receiver block \(p_x\mathcal B_K(\rho_x)\). Therefore

\[
  I(X:B^K)_\omega
    =\chi\bigl(\{p_x,\mathcal B_K(\rho_x)\}\bigr)
    \le\chi(\{p_x,\rho_x\})\le C. \tag{2}
\]

The first inequality is Holevo data processing for the physical channel \(\mathcal B_K\).

Apply the chain argument in Brandão–Harrow, Theorem 1 proof, to the fixed reference measurement \(F\). Their Eq. (49) writes the information obtained by local measurements \(\Lambda_1,\ldots,\Lambda_K\) on the K receivers as a sum of conditional mutual informations. Their Eqs. (52)–(57) condition on the first K-1 receiver outcomes and form a separable comparison

\[
  \sigma_{RB}=\sum_iq_i\,\omega_R^{(i)}\otimes\omega_B^{(i)}.
\]

The conditional states average back to \(\omega_{RB}\), so \(\sigma_R=\omega_R=\bar\rho^T\). Thus every comparison state used by the proof belongs to the constrained separable set \(\{\sigma\in\mathrm{Sep}(R:B):\sigma_R=\omega_R\}\); restricting the minimization to this set preserves the proof's lower bound. The resulting chain inequality is

\[
  \frac K2\left[
    \inf_{\substack{\sigma\in\mathrm{Sep}(R:B)\\\sigma_R=\omega_R}}
    \sup_{\Lambda_B\ \mathrm{POVM}}
    \| (\mathcal M_F\otimes\Lambda_B)(\omega_{RB}-\sigma_{RB})\|_1
  \right]^2
  \le \sup_{\Lambda_1,\ldots,\Lambda_K} I(X:Y_1\cdots Y_K)
  \le I(X:B^K)_\omega.
\]

The last step is data processing for the product receiver measurement. Combining with (2), a separable \(\sigma_{RB}\) with the same reference marginal exists for which every *single common* receiver POVM has joint classical \(L^1\) gap at most

\[
  \epsilon=\sqrt{2C/K}. \tag{3}
\]

Write \(\sigma_{RB}=\sum_iq_i\alpha_i^R\otimes\tau_i^B\). Since its reference marginal is \(\bar\rho^T\), Choi inversion gives a POVM on the input support,

\[
  E_i=q_i\bigl(\bar\rho^{-1/2}\alpha_i\bar\rho^{-1/2}\bigr)^T,
  \qquad \sum_iE_i=P_{\operatorname{supp}\bar\rho},
\]

and the full-domain EB channel \(\Psi_p(A)=\sum_i\operatorname{Tr}(E_iA)\tau_i\). Add the complementary effect \(I-P_{\operatorname{supp}\bar\rho}\) and any fixed output state to make it trace preserving on the whole input algebra. On every \(\rho_x\), the HJW block of its Choi state is \(p_x\Psi_p(\rho_x)\), while the broadcaster's block is \(p_xT(\rho_x)\).

For each x, let \(\{Q_{x,z}\}_z\) be a Helstrom POVM for \(\Delta_x=T(\rho_x)-\Psi_p(\rho_x)\), so \(\sum_z|\operatorname{Tr}(Q_{x,z}\Delta_x)|=\|\Delta_x\|_1\). Do **not** choose these as separate receiver measurements in the de Finetti bound. Instead form one receiver POVM that first chooses \(j\) uniformly from \([N]\), applies \(\{Q_{j,z}\}_z\), and reports \((j,z)\); its effects are \(Q_{j,z}/N\). This is one common POVM, so (3) applies. Its joint gap has nonnegative block contributions, including the j=x Helstrom contribution for every reference label x:

\[
  \epsilon\ \ge\sum_{x,j,z}\left|\operatorname{Tr}\left[(F_x\otimes Q_{j,z}/N)(\omega-\sigma)\right]\right|
  \ge\frac1N\sum_xp_x\|T(\rho_x)-\Psi_p(\rho_x)\|_1. \tag{4}
\]

Thus every prior has some full-domain EB channel with average half-trace loss at most \(N\epsilon/2\).

Finally let \(\ell_x(\Psi)=\frac12\|T(\rho_x)-\Psi(\rho_x)\|_1\). The full-domain EB channels form a compact convex set in finite dimension; \(L(p,\Psi)=\sum_xp_x\ell_x(\Psi)\) is linear in p and convex in \(\Psi\). Finite-dimensional minimax gives

\[
  \inf_{\Psi\in\mathrm{EB}}\max_x\ell_x(\Psi)
  =\sup_{p\in\Delta_N}\inf_{\Psi\in\mathrm{EB}}L(p,\Psi)
  \le\frac N2\sqrt{\frac{2C}{K}},
\]

which is (1). If a prior has non-full support, the complement-to-support effect above still yields a full-domain channel; zero-prior states simply do not enter its Bayes loss.

### Binary-copy iteration and physical costs

Given a two-output broadcaster, average it with its receiver swap. The resulting full-domain channel has a common marginal T and does not increase the worst marginal error b. Recursively apply this same two-output channel to each current leaf. At depth t this uses $2^t-1$ channel invocations and produces $K=2^t$ physical receiver systems. Each leaf marginal is T^t. Averaging the final output over all receiver permutations gives a permutation-invariant K-output channel with the same leaf marginals; this is a CPTP mixture and does not assume Bose-symmetric support.

For every promised state, trace-distance contraction gives

\[
  \frac12\|T^t(\rho_x)-\rho_x\|_1
  \le\sum_{s=0}^{t-1}\frac12\|T^s(T(\rho_x)-\rho_x)\|_1
  \le tb.
\]

The K-output family has Holevo information at most C by data processing. Apply (1) to its common marginal T^t, then use the triangle inequality, to obtain

\[
  e_{\rm EB}(\mathcal E)\le tb+\frac N2\sqrt{\frac{2C}{2^t}}. \tag{5}
\]

For fixed C>0, choosing `2^t >= C N^2/(2b^2)` makes the second term at most b. Hence $e_{\rm EB}\le b[1+O(\log N+\log(1/b)+\log(1+C))]$. In particular, `b log N -> 0` suffices for bounded C. The resource cost is exponential in the chosen depth: `K on the order of C N^2/b^2` receiver leaves and K-1 two-output channel calls. The proof is existential and does not provide an efficient search for $\sigma$ or $\Psi$.

### Complementary dimension bound; symmetry hypothesis checked

The input/output dimension-dependent route is source-backed. Chiribella, [arXiv:1010.1875](https://arxiv.org/abs/1010.1875), Theorem 5 (PDF pp. 10–11, Eq. (16)) states that for any symmetric broadcast channel with **permutation-invariant output**, a common measure-and-prepare K-output channel has k-receiver diamond error at most $2kd^2/K$. At $k=1$, the EB marginal approximates T^t in half trace by at most $d^2/K$. The proof purifies the output using a local \(\mathbb C^d\otimes\mathbb C^d\) environment and invokes its Bose-supported theorem at local dimension d^2; it entails no postselection and gives one full-domain EB channel. Therefore

\[
  e_{\rm EB}(\mathcal E)\le tb+\frac{d^2}{2^t}.
\]

Choosing `2^t >= d^2/b` yields \(e_{\rm EB}\le b\lceil\log_2(d^2/b)\rceil+b\), so `b log d -> 0` suffices. The Bose-supported version (Theorem 4, bound (2kd/K)) is **not** applicable merely because the output was twirled: permutation invariance does not imply support in the Bose-symmetric subspace. This report uses Theorem 5, not that invalid substitution.

## Why the finite theorem does not settle bounded capacity

Capacity alone does not bound trace-packing size. Let d be even and $s\in\{\pm1\}^d$ be balanced. For fixed 0<a<1, define commuting states

\[
  \rho_s=\frac1d\bigl(I+a\,\mathrm{diag}(s)\bigr).
\]

Each is a state and

\[
  D(\rho_s\|I/d)=c(a):=\tfrac12[(1+a)\ln(1+a)+(1-a)\ln(1-a)].
\]

For every prior, \(\chi(\{p_s,\rho_s\})\le\sum_sp_sD(\rho_s\|I/d)\le c(a)\). Yet a greedy constant-weight binary code contains at least \(2^{d(1-h_2(\delta))}/(d+1)\) balanced signs with pairwise Hamming distance at least \(\delta d\), for fixed $0<\delta<1/2$. The corresponding states have pairwise half-trace distance at least $a\delta$. Thus fixed Holevo capacity permits exponentially many constant-separated family elements. These states commute and are exactly broadcastable/EB, so this is only a refutation of replacing N by a function of capacity in the packing argument; it is **not** a counterexample to approximate broadcasting implying EB reconstruction.

The N61 ladder provides the opposite control: it has vanishing marginal broadcasting error and nonvanishing EB error, but its capacity diverges at least as \(\Omega(2^L\log L/L)\) in the stated \(d=L2^{L-1}\) regime. N93's bounded-capacity Clifford family has positive collective broadcast error, and the bounded-capacity mixed bosonic cloning orbit has \(b_2\to a/8>0\). The retained flagged EPR/antisymmetric extensions with vanishing broadcast error have EB replacements with vanishing error. No source package or this cycle produced the required bounded-capacity, vanishing-b2, positive-EB-error sequence.

## Exact unresolved gate

The finite-N proof loses N when it converts one common receiver measurement into trace norm for each HJW label. A capacity-only conclusion would need a further theorem exploiting noncommutativity or the channel-generated extension to remove this factor, or a construction where it is necessary. The BH paper explicitly separates \(\max_{\Lambda}\mathbb E_m\) (its Theorem 1) from \(\mathbb E_m\max_{\Lambda}\) (Conjecture 5); its conjecture is not assumed here. The randomized Helstrom POVM does not reverse those quantifiers; it pays the finite label count.

The exact remaining target is a modulus $g_C(b)\to0$, independent of d and N, such that every full-domain two-output broadcaster with family Holevo capacity $\le C$ and marginal error b admits one full-domain EB map with worst-family half-trace error $\le g_C(b)$. Equivalently after N93\'s fixed-sandwich reduction, the N92 maximum-prior joint-measurement variance must tend to zero under the broadcast residual with a dimension-free modulus. Small CMI and quantum recoverability do not supply this measurement/EB conclusion: Fawzi–Renner recovery outputs a quantum channel; the earlier CMI route in `FINAL_REPORT.md` remains an open bridge.

## Evidence boundary and decisive next attack

The finite-family theorem and its constants above are internally reconstructed from the primary Brandão–Harrow proof. No large-dimensional computation, solver result, or expert proof review was performed. The Chiribella all-family dimension bound is source-derived from its primary theorem. N61/N92/N93 formulas retain their source-derived/unreviewed status as described in cycle 1. Novelty and priority are unassessed.

The decisive next theoretical attack is to characterize the noncommuting families for which the randomized Helstrom-test factor N can be replaced by a complexity of incompatible discrimination tests, then use the broadcast extension to bound that complexity from the *same* Holevo capacity. The balanced-sign example is the control: any proposed complexity must ignore its exponential packing, since it has an exact EB broadcaster. A falsifier of the full target still requires an actual full-domain symmetric broadcaster, bounded C, b2->0, and a positive global EB lower bound.

## Primary-source handles

- Brandão and Harrow, *Quantum de Finetti Theorems under Local Measurements with Applications*, arXiv:1210.6367, Theorem 1 and proof Eqs. (49)–(60): https://arxiv.org/abs/1210.6367
- Chiribella, *On quantum estimation, quantum cloning and finite quantum de Finetti theorems*, arXiv:1010.1875, Theorems 4–5, especially Theorem 5 and Eq. (16): https://arxiv.org/abs/1010.1875
- N93 source-derived proof records and N61/N92 cards: linked from [cycle 1 report](FINAL_REPORT.md) and [source notes](SOURCE_NOTES.md).
