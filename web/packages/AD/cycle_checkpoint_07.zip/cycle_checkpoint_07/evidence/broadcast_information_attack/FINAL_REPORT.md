# Bayesian / information-theoretic attack on bounded-Holevo broadcasting

All logarithms below are natural unless marked base two. Every system is finite-dimensional at each sequence index; dimensions and family cardinalities may grow.

## Verdict

I did not prove the general implication and did not find a bounded-capacity counterexample. I did derive a dimension- and label-count-free Bayesian reduction: after the corrected fixed-sandwich reduction, every finite prior on a broadcast experiment produces an output state whose two receivers have small conditional mutual information in both directions. This isolates the unresolved step as a robust two-way sufficiency-to-one-measurement theorem. Existing recoverability theorems give a quantum recovery channel, which is not an entanglement-breaking decoder; known approximate-Markov counterexamples also rule out the naive claim that small conditional mutual information means closeness to an exact Markov state.

The alternate route worth pursuing is a Bayesian de Finetti / predictive-sufficiency lemma: a symmetric many-receiver extension with bounded Holevo information should admit a measurement on earlier receivers whose classical outcome predicts one later receiver in trace norm. The derivation below makes the required statement precise. Its proof is still open.

## Exact interface and inherited reductions

For each finite-dimensional system, let E={rho_x} be the promised family and let sigma in E be faithful. The broadcaster is a full-domain CPTP map from the input algebra to two copies of its output algebra; each marginal acts within half-trace error b=sup_{x,i}(1/2)||B_i(rho_x)-rho_x||_1 on E. Correlated outputs are allowed. The desired decoder is one full-domain entanglement-breaking channel with worst-state half-trace error tending to zero. All output flags and direct-sum sectors count as physical output dimensions; there are no uncharged side registers.

The retrieved N93 package reduces the bounded-Holevo problem to the fixed sandwich sigma/2 <= rho_x <= 3sigma/2, with sigma included in the experiment. It uses an information-radius center, a substate smoothing step, and compatible smoothing that preserves a common broadcaster. The smoothing constants depend on the uniform Holevo-capacity bound and are not efficient-construction claims. This is an internally audited reduction, not a proof of the remaining channel statement. Evidence: the N93 reduction audit (d-b4ddaa96b233287d.txt), especially §§5–6.

The quantitative inputs to that reduction are important. First, a finite-prior information-radius center sigma can be chosen as a finite mixture of family states, with D(rho||sigma)<=C for every rho; the support condition needed by the substate theorem follows from center optimality. For any smoothing tolerance epsilon, the substate factor can be taken

    M = (1-eta)^(-1) exp((C+ln 2)/eta),  eta=epsilon^2/8.

The fidelity-Q optimizer with lambda=eta/M, normalized to trace one, yields a common faithful family rho_hat with rho_hat<=2M sigma and half-trace distance at most epsilon from rho; the same sigma is retained. Compatible smoothing transports the same broadcaster. The sharper audited transport bound is

    ||T G-G||_1
      <= (1+sqrt(2))*sqrt(xi/lambda) + 2M sqrt(d_s) + M d_s,
    xi = sqrt(d_r)+(sqrt(M)+2lambda M^2)sqrt(d_s)+(M/2)d_s.

At fixed M,lambda and d_r,d_s<=2b, this is O(b^(1/4)); the earlier generic-continuity route gave O(b^(1/8)). To reach a fixed sandwich, set U=2M, choose any fixed theta in (0,1), a=theta/(U-1), and replace each rho_hat by tau=(1-a)sigma+a rho_hat. Then (1-theta)sigma<=tau<=(1+theta)sigma, sigma remains included, b_2 does not increase, and e(E_hat)<=((2-a)/a)e(F). The factor M is exponential in C/epsilon^2. Thus this is a uniform mathematical reduction for each fixed C and epsilon, not a practical compiler or a uniform formula with free smoothing cost.

The next exact correction is also load-bearing. Symmetrize the broadcaster, let T be its common marginal, and apply the Petz recovery map for (sigma,T) to both outputs. For rho satisfying (1-theta)sigma <= rho <= (1+theta)sigma, if d_r=||T rho-rho||_1 and d_s=||T sigma-sigma||_1, the corrected channel S=R_sigma,T T satisfies

    S sigma=sigma,
    ||S rho-rho||_1 <= sqrt(2 theta(d_r+d_s)+6 theta^2 sqrt(d_s)).

It remains self-compatible, and its likelihood map is positive, unital and selfadjoint in the KMS inner product. At theta=1/2, the corrected half-trace broadcast error is at most

    b' <= (1/2) sqrt(4b+(3/2)sqrt(2b)) = O(b^(1/4)).

The exact fixed-point projection is EB, but replacing S by that projection is not a solution: classical modes can mix arbitrarily slowly, so no dimension-free convergence rate follows. N93 further centralizes the reference with a finite flagged CPTP encoder (at most d+1 spectral-bin flags) and decoder, transferring both broadcast and EB errors with no family-label factor. The equivalent final object is a positive, trace-preserving, selfadjoint, self-compatible Markov map on a finite tracial algebra. Evidence: the full corrected reduction and flagged centralization (d-c851b6e4ba719edf.txt), §§1–4, 9.

## New Bayesian derivation: broadcast residual controls both conditional mutual informations

Work after that correction in the fixed sandwich. Write the common marginal as T, assume T sigma=sigma, and put

    alpha sigma <= rho_x <= beta sigma,  alpha=1/2, beta=3/2,
    r = sup_x ||T rho_x-rho_x||_1.

The same order interval holds for T rho_x because the likelihood-picture adjoint is unital and positive. The following entropy-continuity estimate is dimension-free. If alpha sigma <= rho,nu <= beta sigma, then

    |D(rho||sigma)-D(nu||sigma)|
      <= (1/2) log(beta/alpha) ||rho-nu||_1.                 (A)

Proof: for rho_t=(1-t)rho+t nu, differentiate D(rho_t||sigma). Operator monotonicity of logarithm gives

    log(alpha) I <= log(rho_t)-log(sigma) <= log(beta) I.

Since rho-nu is traceless, subtract the midpoint (log(alpha)+log(beta))/2 inside the trace derivative. Its operator norm is at most (1/2)log(beta/alpha); integration proves (A). This is the continuity calculation independently recorded in N92/N93 source d-48ed31af9b1d38fd, §5.

Fix any finite prior p on E, set rho_bar=sum_x p_x rho_x, and define chi_p(E)=I(X:A) for the associated cq state. Since the same identity holds with any reference,

    chi_p(E)=sum_x p_x D(rho_x||sigma)-D(rho_bar||sigma).

Apply this to the output ensemble T(E). Both rho_bar and T rho_bar remain in the sandwich. Applying (A) to every rho_x,T rho_x and to rho_bar,T rho_bar, and using data processing, gives

    0 <= chi_p(E)-chi_p(T E) <= log(beta/alpha) r.           (B)

Now let omega_XBC=(id_X tensor B)(omega_XA). Data processing gives I(X:BC)<=I(X:A)=chi_p(E). The two marginals both equal T(E), so

    0 <= I(X:C|B)
      = I(X:BC)-I(X:B)
      <= chi_p(E)-chi_p(T E)
      <= log(beta/alpha) r,

and, symmetrically,

    0 <= I(X:B|C) <= log(beta/alpha) r.                     (C)

For the N93 half-sandwich constants, this is <= log(3) r, with r<=sqrt(4b+(3/2)sqrt(2b)) after Petz correction. Thus the original broadcast error b->0 implies both conditional mutual informations are O(b^(1/4)), uniformly over dimension, finite-prior support size and prior. This route charges every output register and does not assume product outputs.

There is also a useful many-receiver version. If a symmetric K-receiver broadcaster has common marginal residual r_K, then for every j>=2,

    I(X:B_j | B_1...B_{j-1})
      = I(X:B_1...B_j)-I(X:B_1...B_{j-1})
      <= chi_p(E)-I(X:B_1)
      <= log(beta/alpha) r_K.                               (D)

The first inequality uses data processing for the whole output and the fact that the prefix contains B_1. Equation (D) is a Bayesian “each later receiver adds little new label information” statement. It remains true for arbitrarily many correlated receivers, provided the charged full-domain extension exists.

## The missing information-theoretic lemma

Let q(E,p) be the common-measurement Bayes variance from N92/N93. In a tracial likelihood representation with states rho_x=sigma(I+H_x),

    q(E,p) = sum_x p_x tau(H_x^2)
             - sup_M sum_y w_y sum_x p_x <psi_y|H_x|psi_y>^2,

where the same POVM M is used for every label. N92 proves q(E)=sup_p q(E,p) by finite-dimensional convex minimax, and an attaining POVM gives one full-domain EB decoder with e_EB <= (1/2)sqrt(q(E)).

The desired new bridge would be a dimension-free modulus g_C(delta)->0 such that, for every finite prior p and every channel-origin symmetric broadcast extension satisfying chi_p(E)<=C,

    I(X:C|B), I(X:B|C) <= delta
       ==> q(E,p) <= g_C(delta).                            (E)

Because (E) holds for every prior, N92 minimax would then produce one POVM and one EB channel for the whole experiment; no label-count factor is introduced. In a fixed sandwich, C<=log(beta) relative to the included reference, so a bound with fixed C,alpha,beta would settle the target. In the original bounded-Holevo problem, N93 smoothing first supplies the fixed sandwich with constants determined by its uniform capacity bound.

I have not proved (E). Fawzi-Renner recovery only supplies a quantum channel from B to BC reconstructing the joint state in fidelity; it does not supply a POVM or an EB decoder. The Ibinson-Linden-Winter examples show that small quantum conditional mutual information need not mean closeness to an exact Markov state, with dimension-dependent separation. Those examples do not directly refute (E), which additionally has identical receiver marginals, a channel-origin extension and bounded Holevo information. They do invalidate the shortcut “small CMI, therefore close to a classical/Markov state.”

An equivalent route is a bounded-Holevo Bayesian predictive lemma: from a symmetric K-receiver extension and chi_p(E)<=C, find a POVM on the first K-1 receivers and prepared states tau_y such that the last receiver's state is o_{K->infinity}(1)-close, in prior-average trace norm, to sum_y p(y|x)tau_y, uniformly in dimension and prior support size. Composing that measurement with the first broadcast channel gives an EB map on the original input. The missing point is precisely the measurement step: conditional mutual information controls quantum recoverability, while a quantum recovery channel may retain nonclassical information.

## Copy-ladder control and why it does not refute bounded capacity

N61’s full-domain finite experiment is

    H = direct_sum_{j=0}^{L-1} Sym^(2^j)(C^d),
    rho_psi = (1/L) direct_sum_{j=0}^{L-1} (|psi><psi|)^(tensor 2^j),
    m = 2^(L-1).

The splitter reads the sector flag, splits each non-bottom symmetric tensor power in half, and replaces the bottom sector. Its actual one-receiver marginal error is exactly 1/L on the displayed pure-direction family. The Haar-estimation lower bound is

    e_EB >= 1-(1/L) sum_{j=0}^{L-1} (2^j+1)/(2^j+d)
         >= 1-(m+1)/(m+d).

With d=Lm, this gives b_2<=1/L->0 and e_EB->1; the optimal multi-receiver scale is b_K approximately min(log_2(K)/L,1) when d/m->infinity. These are source-derived candidate theorems; the large Hilbert spaces and moment designs were not materialized by the supplied diagnostics.

This ladder is not a bounded-Holevo counterexample. For Haar prior (or an exact moment design reproducing the sector averages),

    chi(E_L) = (1/L) sum_{j=0}^{L-1} log D_j,
    D_j = binomial(2^j+d-1,2^j).

The identity follows because S(rho_psi)=log L, while its Haar average has entropy log L+L^(-1)sum_j log D_j. The top-sector term alone gives

    chi(E_L) >= (1/L) log binomial(m+d-1,m)
             >= (m/L) log((d+m-1)/m)
             = Omega(2^L log(L)/L),   d=Lm,

so the capacity diverges rapidly. This establishes why the copy-ladder cannot falsify the bounded-capacity claim. The finite-design replacement is required to make the family finite and preserve its Haar moment calculations; its acquisition/cardinality cost grows and is not efficient. No independent cloning, purification preservation or free side register is claimed. Evidence: the N61 result card (../quantum_physics/sources/N61-broadcast-copy-ladder.txt) and N67 receiver-growth card (../quantum_physics/sources/N67-receiver-growth-classicality.txt).

## Counterexample attacks that do not meet the target

The corrected N93 evidence also blocks three nearby routes:

- The flagged Clifford/Pauli family has fixed capacity
  \[
  C(a)=\frac{(1+a)\ln(1+a)+(1-a)\ln(1-a)}2\le\ln2,
  \]
  vanishing pairwise fidelity-affinity gap as the number of qubits grows, and EB error tending to \(a/2\). Its collective SOS lower bound is nevertheless
  \[
  b_2\ge\frac a2(1-1/\sqrt2)>0.
  \]
  Thus neither bounded capacity nor small pair gaps alone supplies the missing bridge; the family does not have b_2->0.
- The full mixed bosonic universal-cloning orbit at k=d has bounded Holevo capacity \(C\le\ln3\), \(e_{EB}\to a/4\), and \(b_2\to a/8\). It shows that a bounded-capacity mixed family can remain nonclassical, but its broadcast error stays positive.
- N93’s random flagged disjoint-EPR and normalized antisymmetric extension ladders allow arbitrary bounded steering contractions on the full reference and admit actual full-domain broadcasters with error 1/L. However, explicit EB replacements also have error O(1/L). The EPR/antisymmetric constructions therefore do not yield a bounded-capacity counterexample, even with global steering effects.

These are useful controls for the proposed CMI route: any claimed modulus must use the small broadcast residual in addition to Holevo capacity, and any counterexample needs a positive global EB lower bound rather than a pair-gap or extension witness. Evidence: N93 card and the complete scoped records d-6ca375d9fdc3c59d.txt and d-94c17c39256434dc.txt.

## N92 instrument theorem: exact reach and non-representation gap

The N92 instrument construction is a valid dimension-free EB theorem on an explicit class. In a finite tracial algebra, supply Kraus operators K_y with

    sum_y K_y* K_y = sum_y K_y K_y* = I,
    L(A)=sum_y K_y A K_y*,  M_y=K_y* K_y,

and define p_y=tau(M_y) and

    Psi(A)=sum_y [tau(M_y A)/p_y] M_y.

The physical Schrödinger map is the full-domain EB measure-and-prepare channel rho -> sum_y Tr(M_y rho) sigma M_y/p_y. Form C=(L+Psi)/2 and Phi=C* C. The instrument-append channel plus its receiver swap is a physical compatible extension of C; Petz correction on both outputs gives a compatible marginal Phi. The exact SOS identity is

    2(I-Phi)-(I-Psi)
      = (I-L*L)+(Psi-Psi^2)+(1/2)(L-Psi)*(L-Psi) >= 0.     (F)

For a likelihood I+H, ||H||_infinity<=theta, and residual r=sup_H ||Phi H-H||_(1,tau),

    <H,(I-Phi)H>_tau <= theta r,
    ||(I-Psi)H||_(1,tau) <= ||(I-Psi)H||_(2,tau)
                         <= sqrt(2 theta r).

Thus this explicit Psi reconstructs the entire likelihood family with half-trace error at most (1/2)sqrt(2 theta r). The proof is exact in all dimensions and covers mixtures, tensor closure and the stated block-internal instruments. It does not show that every positive selfadjoint self-compatible Phi is C*C for such a supplied instrument with the same relevant likelihood family. That representation/equivalence is absent, so (F) does not close the general case. Evidence: the full N92 proof record (d-48ed31af9b1d38fd.txt), §§3–3A.

## Prior-art boundary and decisive next check

Barnum–Caves–Fuchs–Jozsa–Schumacher establish exact broadcasting iff the states commute. Fawzi–Renner establish recovery from small CMI, but recovery is quantum. Ibinson–Linden–Winter show small CMI alone need not give dimension-free closeness to the set of exact quantum Markov states. Lemm–Wilde’s information-theoretic approximate-broadcast bounds concern a setting where one fixed state is broadcast while another is product-cloned; the present hypothesis has only marginal accuracy for every family member, so that theorem cannot be inserted as stated.

The next check that can change the research decision is to attack (E) first on a finite flagged Clifford family and on a two-state qubit family, using exact cq CMI and N92’s joint-variance q(E,p). A violation would refute this route immediately; agreement would not prove a dimension-free theorem. The stated falsifier is a sequence with C<=C_0, both CMI ->0, and sup_p q(E,p)>=q_0>0, together with an actual full-domain CPTP broadcaster generating the extensions. A merely small pair-fidelity gap, abstract symmetric state extension, SDP feasibility, or approximate Markov example without channel-origin broadcast does not meet that falsifier.

No numerical check was run in this subtask; the CMI inequalities and ladder capacity calculation above are analytic. Scientific correctness of the source-derived N61/N92/N93 packages and any novelty claim remain externally unreviewed.

### Primary-source handles

- Barnum et al., Noncommuting mixed states cannot be broadcast, https://arxiv.org/abs/quant-ph/9511010.
- Fawzi and Renner, Quantum conditional mutual information and approximate Markov chains, https://arxiv.org/abs/1410.0664.
- Ibinson, Linden and Winter, Robustness of quantum Markov chains, https://arxiv.org/abs/quant-ph/0611057.
- Lemm and Wilde, Information-theoretic limitations on approximate quantum cloning and broadcasting, https://arxiv.org/abs/1608.07569.
