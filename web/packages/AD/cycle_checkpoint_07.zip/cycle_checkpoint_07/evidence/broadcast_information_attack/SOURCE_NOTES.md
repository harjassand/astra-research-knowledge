# Source route and evidence hashes

The source cards were read from the local Astra evidence tree after the task-specific prior files and workflow. The W-package HTML files are local retained source snapshots; each was extracted through its preformatted text body into the adjacent d-*.txt note in this directory so section and equation spans are searchable. Hashes below are SHA-256. These hashes identify the retrieved material; they do not validate its mathematics or priority.

| Record | Local source | Read scope | SHA-256 |
|---|---|---|---|
| N93 bounded-Holevo gates | work/agents/measurement_inverse/astra/cards/N93-bounded-holevo-gates.txt | Entire 14-line compact card | 353744f1fd70543f1564543f54de5ab63cb61a8ce34ff7e5f5dcdca0eb301cd2 |
| N93 center/substate and compatible smoothing audit | work/agents/quantum_physics/sources/d-b4ddaa96b233287d.html | Extracted d-b4ddaa96b233287d.txt, lines 1-243; §§1-6 quantify information radius, M, compatibility transport, and dilution | 7d083a87b26be1ac95a7529a08b466a352a761530ccd69774079ba9a6365e52c |
| N93 Petz correction and exact fixed-sandwich equivalence | work/agents/quantum_physics/sources/d-c851b6e4ba719edf.html | Extracted d-c851b6e4ba719edf.txt, lines 1-206; Petz identity, residual bound and equivalence; lines 350-560 finite flagged centralization; lines 561-635 CP-range commutator bound | 435d67427e02642ab3d589cb0587eaf38bb8d389f57439b28d08576546b4a259 |
| N93 failed flagged steering / antisymmetric ladders | work/agents/quantum_physics/sources/d-6ca375d9fdc3c59d.html | Extracted d-6ca375d9fdc3c59d.txt, lines 1-189; exact bounded steering contraction and EB upper bounds | b0e820fd26273c6df285f428882cb753bd83297050bb8bb6957e680f6f5884fb |
| N93 mixed bosonic cloning and capacity counterexample attempt | work/agents/quantum_physics/sources/d-94c17c39256434dc.html | Extracted d-94c17c39256434dc.txt, lines 1-180; exact mixed orbit broadcasting/EB formulas and constant-capacity regime; lines 182-217 rejected routes | e8098490941b89555a47fa73931b867377382773e99891a939339b2696ed6ef2 |
| N61 pure-copy ladder | work/agents/quantum_physics/sources/N61-broadcast-copy-ladder.txt | Entire 13-line result card; exact interface, splitter, EB lower bound, faithful perturbation and finite moment design scope | 5aec550aa7a6f44f4ca50c86d2e6591c46ee3ad44a5e1c1c6a96e45862770386 |
| N67 receiver-growth refinement | work/agents/measurement_inverse/astra/cards/N67-receiver-growth-classicality.txt | Entire compact card; arbitrary-K law, fixed-K constants and family-covering consequence | 90765e737c0525667acfe11f207298948625e4dc0cf23f916d213abb990863c8 |
| N92 explicit instrument theorem | work/agents/measurement_inverse/astra/cards/N92-instrument-channel-classicalization.txt | Entire 10-line compact card | bec6e99c1ae65269142c40ce0593707ee52000e57c1f8f9a5b9f6e2ed72677eb |
| N92 detailed SOS proof | work/agents/quantum_physics/sources/d-48ed31af9b1d38fd.html | Extracted d-48ed31af9b1d38fd.txt, lines 208-321; POVM/Luders and arbitrary bistochastic instrument, exact SOS; lines 350-420 continuity and information-chain boundary | 711789eb2a5129d8d12d962eb8751bb8ab50ccbaee036471da06a2cc3f935355 |

The corrected source cards identify these as source-derived/internal results. Their formulas and interfaces were reconstructed for this handoff, but no external proof review, priority search, or large-space channel computation was performed here. The only newly derived result in this workstream is the finite-prior CMI bound (A)-(D), proved in FINAL_REPORT.md.

## Primary literature checked

- Barnum et al., arXiv:quant-ph/9511010: exact no-broadcasting for noncommuting mixed states; https://arxiv.org/abs/quant-ph/9511010.
- Fawzi–Renner, arXiv:1410.0664: small conditional mutual information implies a quantum recovery channel; the recovery is not restricted to measurement-and-prepare; https://arxiv.org/abs/1410.0664.
- Ibinson–Linden–Winter, arXiv:quant-ph/0611057: CMI and distance to an exact quantum Markov state can differ dimension-dependently; this blocks the naive Markov-proximity step but is not itself a counterexample to the narrower channel-origin statement; https://arxiv.org/abs/quant-ph/0611057.
- Lemm–Wilde, arXiv:1608.07569: approximate broadcasting bounds with the extra product-cloning condition for a comparison state; not the marginal-only interface here; https://arxiv.org/abs/1608.07569.

The sources are linked as primary-paper handles; the local W package contains only its retained evidence, not full third-party manuscripts. Browser output was used to check abstracts and theorem interfaces; no proof from these papers was imported except the cited recoverability/no-broadcasting boundary.
