# Kernel-checked real-power separation and raised-coordinate contradiction

## Result

Proved both varying-exponent sequence limits and their reusable raised-coordinate consequence in Lean. Given real sequences `h p : ℕ → ℝ`, `h → 0+` as `Tendsto h atTop (nhdsWithin 0 (Set.Ioi 0))`, and `p → p₀` with unrestricted sequence values:

- `q < p₀` implies `Real.rpow (h n) (p n) / Real.rpow (h n) q → 0`;
- `p₀ < q` implies the same ratio tends to `atTop`.

The additional theorem `no_eventually_le_of_rpow_ratio_atTop` takes `p₀ < q`, a fixed `c > 0`, and a real bump `bump =o[nhdsWithin 0 (Set.Ioi 0)] (fun x => Real.rpow x q)`. It proves there cannot be an eventual inequality `c * Real.rpow (h n) (p n) + bump (h n) ≤ Real.rpow (h n) q`. Its proof composes the little-o quotient limit with `h`, divides by the eventually positive `h^q`, and compares the ratio-to-infinity term against the bump-to-zero term.

The public declarations are in [RpowScaleSeparation.lean](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-2/work/agents/c4_lean_rpow_separation/RpowScaleSeparation.lean:13) and [RaisedCoordinateContradiction.lean](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-2/work/agents/c4_lean_rpow_separation/RaisedCoordinateContradiction.lean:10).

## Kernel and environment evidence

`verify.sh` directly invokes installed Lean 4.28.0 with the existing compiled mathlib v4.28.0 cache. It writes only task-local outputs. No package download, Lake setup, or external-project compilation was run. `compile.exit`, `raised_compile.exit`, and `kernel_audit.exit` all record exit code 0. `kernel_audit.log` prints the full elaborated theorem types and reports dependencies `[propext, Classical.choice, Quot.sound]` for all three declarations; no `sorryAx` appears. The `.lean` sources contain no `sorry`, `newaxiom`, or explicit `axiom` declarations.

## Scope and next gate

These are formalized asymptotic components of the affine approximation proof, not a formalization of its slice-family induction, compact bad-limit argument, interval gluing, or final uniform approximation theorem. They make no novelty or application claim. The next gate is importing the contradiction theorem into the shared candidate development at each raised-coordinate comparison and compiling the integrated development.
