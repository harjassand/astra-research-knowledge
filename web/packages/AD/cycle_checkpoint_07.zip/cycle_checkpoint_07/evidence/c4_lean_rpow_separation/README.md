# Varying-exponent real-power separation

This task-local Lean development provides the scale lemmas and the raised-coordinate contradiction used by the affine approximation candidate.

For real sequences `h p : ℕ → ℝ`, assume `h → 0+` in the exact sense `Tendsto h atTop (nhdsWithin 0 (Set.Ioi 0))` and `p → p₀`. No cube or boundedness assumption is imposed on the values `p n`.

- If `q < p₀`, `rpow_ratio_tendsto_zero_of_lt` proves `Real.rpow (h n) (p n) / Real.rpow (h n) q → 0`.
- If `p₀ < q`, `rpow_ratio_tendsto_atTop_of_lt` proves that ratio tends to `atTop`.
- `no_eventually_le_of_rpow_ratio_atTop` proves that when `p₀ < q`, `c > 0`, and `bump =o[nhdsWithin 0 (Set.Ioi 0)] (fun x => Real.rpow x q)`, it is impossible for `c * Real.rpow (h n) (p n) + bump (h n) ≤ Real.rpow (h n) q` to hold eventually.

The ratio lemmas are in `RpowScaleSeparation.lean`; the contradiction theorem is in `RaisedCoordinateContradiction.lean` and imports the first module. For the contradiction, `IsLittleO.tendsto_div_nhds_zero` makes the normalized bump tend to zero along `h`; the ratio lemma makes the leading term tend to infinity. Since the denominator is eventually positive, normalization contradicts the assumed eventual inequality.

## Verification

The no-download environment is Lean 4.28.0 and the already compiled mathlib v4.28.0 build at `/Users/harjas/Documents/Codex/2026-07-14/i-want-you-to-look-at/work/tmp/erdos-1005-lean/.lake`. `lean.sh` sets `LEAN_PATH` to that build and invokes the installed Lean binary directly. Source, `.olean` files, and logs are all under this task folder; the external project and cache are read-only in this workflow.

From the research workspace root, run:

```sh
./work/agents/c4_lean_rpow_separation/verify.sh
```

The script compiles both modules to task-local `.olean` files, then imports them and runs `#print axioms` and `#check` on all three public theorems. The three `*.exit` files record exit code 0. `kernel_audit.log` reports `[propext, Classical.choice, Quot.sound]` for each theorem and prints the full elaborated signatures. No source declaration uses `sorry`, `newaxiom`, or explicit `axiom`; no `sorryAx` dependency appears.
