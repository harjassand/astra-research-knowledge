# Proof note: input protocols preserve an exact hidden-state mirror

## Interface

State row vector `p(t)` evolves under `p'(t)=p(t)Q_theta(c(t))`, with `Q_theta(c)` a finite-state CTMC generator and a controlled, common ligand concentration `c(t)`. The measured scalar is `y(t)=p(t)g_theta`; for a stochastic current measurement, conditional emission/noise depends only on the state current represented by `g_theta`. The hidden-state model has a permutation matrix `P` mapping one orientation to its mirror.

## Theorem

Assume for each ligand concentration in the allowed domain:

1. `Q_{theta^M}(c)=P^{-1}Q_theta(c)P`;
2. `p_{theta^M}(0)=p_theta(0)P`;
3. `g_{theta^M}=P^{-1}g_theta`.

Then, for every common time-varying input `c(t)`,

`p_{theta^M}(t)=p_theta(t)P` and `y_{theta^M}(t)=y_theta(t)` for all `t`.

The entire current-path law is equal under the two models when the state-path transition law and emissions obey the same permutation. This includes finite time-sampling, interval averages, and current-only noise models. The claim is exact; it is not a small-noise or asymptotic statement.

## Proof

On any interval with a fixed input value, define `q(t)=p_theta(t)P`. Then

`q'(t) = p_theta(t)Q_theta(c)P = p_theta(t)P P^{-1}Q_theta(c)P = q(t)Q_{theta^M}(c)`.

By assumption 2, `q(0)=p_{theta^M}(0)`. Uniqueness of the finite-dimensional linear ODE gives `q(t)=p_{theta^M}(t)`. Concatenating constant-input intervals proves the statement for piecewise-constant schedules. Approximation by piecewise-constant schedules and continuity of the finite-state forward equation gives bounded piecewise-continuous schedules; equivalently, the same derivative identity holds almost everywhere for measurable bounded `c(t)`.

The output equality is

`p_{theta^M}(t)g_{theta^M}=p_theta(t)P P^{-1}g_theta=p_theta(t)g_theta`.

For path distributions, use the path bijection `X^M(t)=P^{-1}X(t)`. Generator conjugacy preserves the initial-state probability, every holding rate, and every transition probability; emission equivariance preserves the observed current. Therefore the pushforward laws on all finite current records coincide. Any downstream deterministic time averaging and any shared current-conditioned noise kernel preserve that equality.

With equal prior probability on the two mirror hypotheses, `Pr(data | theta)=Pr(data | theta^M)` for every data record, so Bayes' rule leaves the posterior probability at `1/2`. No estimator can achieve worst-case orientation success above `1/2` from this observation interface. ∎

## Model-specific obligation

The P2X2 Scheme IX article reports precisely a left/right mirror ambiguity in binding–rotation couplings under scalar macroscopic-current data and its released code uses a mirror-state mapping. The theorem's application to *all possible* ATP waveforms requires checking the three equations above for every rate and conductance term in the 24-state model, not just observing a two-mode fit on the published pulse panel. That full symbolic check is open in this packet. In particular, verify the initial-state calculation at zero ATP and any patch/inactivation augmentation, then verify the current emission is invariant under the same state permutation.
