# Fixed-time folding occupancy is a separate design target from equilibrium

## Finding

An equilibrium sequence-to-ensemble score cannot, by itself, certify native-state occupancy at a fixed finite assay time. The missing quantity is kinetic: transition-state barriers can slow a reversible folding process without changing its Boltzmann distribution. This gives an exact counterexample and a usable assay-time gate.

The result is a conditional mathematical theorem using a standard Markov model, not a claim of a new general folding theory. The biological motivation is unusually concrete: Top7 was designed into a novel fold and crystallized close to its design, yet primary kinetic studies found multiple folding phases and stable nonnative states. A later polar-core redesign remained highly stable and still retained multiphasic folding. These data do not prove the theorem; they show why the theorem’s omitted kinetic input matters in real design.

**Bounded novelty verdict: reject a claim of a new Top7 cooperativity-design principle.** Yadahalli and Gosavi already computationally altered Top7 packing to increase folding cooperativity, including amino-acid mutations that mimic the model changes ([Proteins, 2014, DOI 10.1002/prot.24393](https://doi.org/10.1002/prot.24393)). The direct gap is narrower: the cited mutation design has no retrieved experimental fixed-time native-occupancy validation. A later primary review of Top7 folding states that no published Top7 mutants showed cooperative, intermediate-free folding by 2022. The equilibrium-preserving rate-rescaling argument and spectral-gap bound below are standard Markov results, so they do not by themselves establish a new scientific advance.

## Mechanistic model and exact gate

First use the smallest coarse-grained model that can separate equilibrium from target occupancy at a sampling time. Let `I` be the prepared, non-target basin and `N` the defined native target basin. At fixed temperature, buffer, denaturant, concentration, and construct, suppose the resolved exchange is a homogeneous continuous-time Markov chain

\[
I \mathrel{\mathop{\rightleftarrows}^{k_f}_{k_u}} N,
\]

where `k_f` is the `I -> N` rate and `k_u` is the `N -> I` rate. Detailed balance gives

\[
\pi_N=\frac{k_f}{k_f+k_u}
 =\frac{1}{1+\exp[-\Delta F/(k_BT)]},\qquad
\Delta F=F_I-F_N=k_BT\log(k_f/k_u).
\]

Write `lambda = k_f + k_u` for the relaxation rate. Starting in `I`, the target-basin population at assay time `t` is exactly

\[
p_N(t)=\pi_N(1-e^{-\lambda t}).
\]

For a required target fraction `q < pi_N`, the sampling-time occupancy requirement `p_N(t) >= q` is equivalent to

\[
\lambda t\ge \log\!\left(\frac{\pi_N}{\pi_N-q}\right).
\]

Thus the equilibrium margin and the relaxation rate answer different questions. Under this model, a design meets a prespecified sampling-time occupancy threshold only when both its equilibrium occupancy and measured kinetic rate pass the corresponding gate. This is not a first-passage probability of having visited the native basin before sampling. If a single-exponential, state-resolved exchange model does not fit the data, this two-state gate returns `UNKNOWN`; fitting it anyway is not justified.

## Exact equilibrium-only counterexample

Fix any equilibrium occupancy `pi_N` and multiply both rates by an arbitrary `a > 0`:

\[
(k_f,k_u)\longmapsto(a k_f,a k_u).
\]

The rate ratio and hence the entire stationary distribution are unchanged, but `lambda` is multiplied by `a`. For fixed sampling time `t`, as `a -> 0`, `p_N(t) -> 0` when preparation starts in `I`. More generally, for any finite reversible conformational-state generator `Q` with Boltzmann stationary law `pi`, `aQ` has the same stationary law for every `a > 0`, while `e^{taQ} -> I` as `a -> 0`. Therefore no fixed-time occupancy lower bound above the initial target occupancy follows from equilibrium energies alone unless a kinetic lower bound is also supplied.

This construction has a transition-state interpretation. In an Eyring-style model with common prefactor,

\[
k_f=\nu e^{-\beta(F^\ddagger-F_I)},\qquad
k_u=\nu e^{-\beta(F^\ddagger-F_N)}.
\]

Raising the transition-state free energy `F^ddagger` multiplies both rates by the same factor and preserves `pi_N`. A barrier increase of `k_BT log 100` makes exchange 100 times slower while preserving the same equilibrium target probability. The rescaled-generator argument is exact; the Eyring interpretation is illustrative and assumes unchanged prefactors.

### Numerical design gate

At 298 K, a 95% equilibrium target population requires `Delta F = kBT log(19) = 1.74 kcal/mol`. That same energy margin can pass or fail a 10-minute refolding assay:

| Case | `pi_N` | `lambda` | `p_N(600 s)` | 90% at 10 min? |
|---|---:|---:|---:|---|
| Faster exchange | 0.95 | `0.005 s^-1` | 0.9027 | Pass |
| 100× slower exchange | 0.95 | `0.00005 s^-1` | 0.0281 | Fail |

Both cases have the same `Delta F`; the rate pairs are `(0.00475, 0.00025) s^-1` and `(0.0000475, 0.0000025) s^-1`, respectively. Starting from `I`, to have 90% occupancy at `t=600 s` with `pi_N = 0.95`, the exact two-state gate requires `lambda >= log(19)/600 = 4.91e-3 s^-1`. The 100-fold rate change corresponds to a barrier shift of `RT log(100) = 2.73 kcal/mol` under the equal-prefactor illustration. These are constructed values, not measurements on Top7.

## Finite-state theorem when more than two conformations matter

Let `Q` be an irreducible finite reversible generator with stationary Boltzmann law `pi` and spectral gap `gamma > 0`. For initial law `mu`, define

\[
c_\mu=\left(\sum_x\frac{\mu(x)^2}{\pi(x)}-1\right)^{1/2}.
\]

Reversibility and the spectral-gap contraction in `L^2(pi)` imply

\[
\left|\Pr_\mu(X_t\in A)-\pi(A)\right|
\le \|\mu e^{tQ}-\pi\|_{TV}
\le \tfrac12c_\mu e^{-\gamma t}
\]

for every target set `A`. Consequently, if the equilibrium design model gives `pi(A) >= 1-delta`, the finite-time sufficient condition for `Pr_mu(X_t in A) >= 1-epsilon`, with `epsilon > delta`, is

\[
\gamma t\ge \left[\log\!\left(\frac{c_\mu}{2(\epsilon-\delta)}\right)\right]_+.
\]

This makes the acquisition boundary explicit: the model must supply the initial distribution and a justified lower bound on the slowest relaxation rate. Neither is encoded by an equilibrium target-versus-off-target free-energy gap. In a large conformational network, a finite set of observed relaxation modes need not certify that no slower hidden mode exists; without that certificate, the bound is `UNKNOWN`.

## Primary biological reconstruction: Top7

Kuhlman et al. designed Top7 as a 93-residue `alpha/beta` protein by iterating sequence design and structure prediction. The reported crystal structure is within 1.2 Å RMSD of the design model, and the protein was experimentally folded and unusually stable ([Science, 2003, DOI 10.1126/science.1089427](https://doi.org/10.1126/science.1089427)). Those are structural and stability successes; they do not alone establish how quickly a prepared chain reaches the target basin.

Watters et al. measured Top7 folding with stopped-flow fluorescence, circular dichroism, and NMR ([Cell, 2007, DOI 10.1016/j.cell.2006.12.042](https://doi.org/10.1016/j.cell.2006.12.042)). After dilution from 7.0 M to 4.1 M guanidine hydrochloride, most refolding traces required three exponential phases. Below 4 M denaturant, the two slower rates were approximately denaturant-independent, consistent with rearrangements between collapsed states rather than additional surface burial. The rates and phase amplitudes were independent of protein concentration in the reported check, arguing against aggregation as the source of the multiple phases. At below 2 M denaturant, more than 80% of the native circular-dichroism signal appeared within the 2 ms instrumental dead time, even though slower fluorescence phases remained. A compact or secondary-structure reporter therefore cannot be treated as an atomic-level native-state assay without validation. The authors also found a stable nonnative conformation and stable isolated fragments.

The mutation results stress the sequence-design interface. Eleven tested mutation constructs retained the three observed phases; the A64G/A65G construct required a fourth phase at low denaturant. The rates changed differently across substitutions. The data support the claim that stability/target-structure optimization does not determine a simple kinetic route for this protein; they do not establish that all de novo proteins behave this way.

Basanta et al. replaced five Top7 core residues with a designed hydrogen-bond network and incorporated a Cys12–Cys45 disulfide in the expressed Top7_PC construct ([Protein Science, 2016, DOI 10.1002/pro.2899](https://doi.org/10.1002/pro.2899)). The polar-network structure placed three of its five residues and their hydrogen bonds close to the design model, while two more solvent-exposed residues sampled variable conformations. Top7_PC remained very stable: the paper reports an unfolding free energy of 10.3 kcal/mol in oxidizing conditions and 8.9 kcal/mol in reducing conditions for the tested variant. Yet the variant retained multiphasic folding. Tryptophan fluorescence gave a nearly single-exponential major response of 1–4 s^-1, while ANS exposed additional phases, including 105–137 s^-1, 3–11 s^-1, and a component below 1 s^-1 at or below 2.2 M guanidine. This is a direct warning that one reporter can make a multistate sequence appear kinetically simple.

These Top7 studies are stress tests and motivation, not a fitted instance of the two-state formula: the reported data violate its single-mode premise, and their denaturant/refolding conditions are not a universal assay environment. No Top7 equilibrium occupancy or 10-minute native fraction is inferred here.

## Prior-art attack and the remaining test

The exact sequence-level route is already in the literature. Yadahalli and Gosavi (2014) report two simulated ways to reduce the populated C-terminal intermediate: improve packing in the N-terminal half so it proceeds to fold, or reduce C-terminal packing to destabilize the intermediate. Their contact-map modifications preserve the Top7 topology, and the paper reports coarse-grained model simulations showing increased cooperativity after amino-acid changes intended to mimic the packing edits. A later primary study lists the six-substitution sequence `V6I-L29F-I40F-F71V-I79V-F83V` as a Top7 repacking candidate linked to that earlier work ([Frontiers in Molecular Biosciences, 2022, DOI 10.3389/fmolb.2022.849272](https://doi.org/10.3389/fmolb.2022.849272)). These are computational design/model results, not measured experimental rates or finite-time native yields for that six-mutant construct. The 2007 Top7 experiments tested other individual mutation constructs; none removed the observed multiphasic folding.

Accordingly, the actionable prospective test is validation of this prior sequence, not a novel sequence proposal. Compare WT, the N-terminal triple `V6I-L29F-I40F`, the C-terminal triple `F71V-I79V-F83V`, and the six-mutant combination. For one fixed refolding condition, measure equilibrium stability and direct native-basin occupancy at a frozen assay time `t*` using a state-specific structural readout validated against an orthogonal structure measurement. Include at least two probes because the published Top7-PC study found that Trp fluorescence looked nearly single-exponential while ANS reported additional phases. The quantitative primary endpoint is the difference in native fraction at `t*`; also report the equilibrium fraction and all resolved relaxation rates. A result where the six-mutant's equilibrium occupancy is similar to WT but its native fraction at `t*` is higher would support the prior kinetic prediction. A result with no finite-time gain, a changed topology, or unresolved hidden states rejects or leaves `UNKNOWN` the proposed mechanism. No exact finite-time gain is predicted from the retrieved papers, so do not attach a numeric yield estimate to this sequence before measuring it.

For direct validation, set a prespecified occupancy threshold and sampling time for the intended application. If the threshold is 90% occupancy at `t*`, 29 independent all-success trials give a one-sided 95% lower confidence bound of 90% for one frozen genotype; if all four genotypes are to be certified simultaneously at that threshold with Bonferroni correction, use 42 all-success trials per genotype. These are statistical sufficiency counts, not proposed folding rates. The intended application must determine `t*` before data collection.

## Practical design and assay gate

1. Freeze the construct, buffer, temperature, denaturant, initial preparation, target basin definition, and sampling time `t*`. Define “native” with a state-specific structural reporter or a validated combination of probes; Top7 shows why CD or intrinsic fluorescence alone may confuse an early compact intermediate with the target.
2. Rank candidates first by the supplied equilibrium model, but do not use that score as the assay-time endpoint. On the same candidate set, compare the equilibrium-only ranking with a kinetic-aware ranking by `p_N(t*)` under the two-state model.
3. Measure refolding and unfolding rates at the actual assay conditions. Use stopped-flow traces with at least two probes sensitive to distinct structural features and a protein-concentration series. Pre-register that a one-exponential, state-resolved model must fit both directions before using the two-state equation. If multiple phases remain, return `UNKNOWN` for the reduced model and either fit a validated multistate model with a lower confidence bound on `gamma`, or directly assay native-basin occupancy at `t*`.
4. Propagate rate uncertainty conservatively. For `k_f` in `[k_f^-, k_f^+]` and `k_u` in `[k_u^-, k_u^+]`, the two-state target fraction from initial `I` increases with `k_f` and decreases with `k_u`; the lower confidence prediction is therefore `p_N^L(t*) = f(k_f^-, k_u^+; t*)`. Report a pass only if this lower bound exceeds the predeclared threshold.
5. For direct finite-time validation, count independent refolding molecules or independent preparations that occupy the target basin at `t*`. With no observed failures among `n` independent trials, the exact one-sided `1-alpha` lower confidence bound on success probability is `alpha^(1/n)`. Thus 29 all-success trials suffice for a 95% confidence lower bound of 90% for one frozen candidate; 59 suffice for a 95% lower bound of 95%. For a simultaneous 90% threshold across 12 candidates using Bonferroni `alpha/12`, 53 all-success trials per candidate suffice. These counts assume a calibrated, sufficiently specific target-state assay and independent trials; repeat reads of one trajectory do not increase `n`.

For the rate-interval rule in step 4, `f(k_f,k_u;t)=k_f/(k_f+k_u)(1-e^{-(k_f+k_u)t})` is increasing in `k_f` and decreasing in `k_u`: its derivatives have signs `∂f/∂k_f > 0` and `∂f/∂k_u ∝ -1+(1+x)e^{-x} <= 0`, where `x=(k_f+k_u)t` and `e^x >= 1+x`. Thus the stated lower corner of the rectangular rate interval is conservative.

The strongest controls are (i) an equilibrium-only sequence ranker, (ii) the same ranker plus measured kinetic rates, and (iii) direct native-state occupancy at the prespecified sampling time. Give all candidates the same sequence/structure inputs, buffer and temperature, and assay budget. Match or stratify designs on predicted equilibrium target probability so the experiment tests whether kinetic information changes fixed-time occupancy rather than merely restating the stability ranking.

### Decisive falsifier and remaining gate

For a two-state claim, the decisive failure is a reproducible second relaxation phase, probe-dependent rate, or concentration-dependent kinetics that changes the predicted native fraction at `t*`; that rejects the reduced model and forces `UNKNOWN` or a multistate reconstruction. For the general design claim, the test is whether measured finite-time native fraction is ordered by the kinetic-aware prediction among stability-matched sequences, against the equilibrium-only baseline. A result where the rates fail to improve held-out `p_N(t*)` prediction would reject the practical value of the kinetic-aware ranking for that panel. External novelty and priority are open; the Markov and spectral-gap results are standard mathematics applied to a protein-design interface.

## Evidence, costs, and limits

- **Reconstructed here:** the two-state formula, exact energy/rate counterexample, barrier-shift interpretation, and reversible-chain spectral-gap sufficient bound.
- **Source-reported:** Top7 structure/model agreement, multiphasic folding and mutation behavior, and Top7_PC stability/kinetic phases. These are different assays and variants; they are not pooled as a single parameter fit.
- **Not established:** that a particular modern design platform’s equilibrium score causes finite-time failures; that a coarse-grained two-state model applies to a chosen protein; or that observed relaxation modes bound every unobserved slow state.
- **No wet lab, simulations, or new sequence panel were run.** The numeric table is an exact evaluation of the stated two-state model, not experimental data. A prospective study pays for protein expression/constructs, stopped-flow or single-molecule time traces, two orthogonal structural probes, concentration controls, equilibrium calibration, and enough independent validation trials. Dollar cost depends on the assay and facility and is not estimated.
- **Astra retrieval:** read the mandated start/core/workflow files. The static Astra topic router has mathematical topic files but no protein-folding/allostery route; the broad probability/methods cards did not supply a relevant biological theorem. Primary evidence was therefore taken from the original Top7 design, folding, and polar-core studies cited above. No Astra navigation result is treated as scientific evidence.

## Primary sources consulted

1. Kuhlman et al., “Design of a novel globular protein fold with atomic-level accuracy,” *Science* (2003), [DOI 10.1126/science.1089427](https://doi.org/10.1126/science.1089427). Original 93-residue Top7 design and crystal validation.
2. Watters et al., “The highly cooperative folding of small naturally occurring proteins is likely the result of natural selection,” *Cell* (2007), [DOI 10.1016/j.cell.2006.12.042](https://doi.org/10.1016/j.cell.2006.12.042). Primary Top7 kinetic phases, denaturant dependence, concentration controls, mutations, and nonnative states.
3. Basanta et al., “Introduction of a polar core into the de novo designed protein Top7,” *Protein Science* (2016), [DOI 10.1002/pro.2899](https://doi.org/10.1002/pro.2899). Polar-network redesign, structure comparison, stability and probe-dependent multiphasic kinetics.
4. Hsu et al., “Single molecule force spectroscopy reveals the context dependent folding pathway of the C-terminal fragment of Top7,” *Chemical Science* (2021), [DOI 10.1039/D0SC06344D](https://doi.org/10.1039/D0SC06344D). Consulted as a corroborating primary mechanistic study of Top7 fragments; force-dependent fragment kinetics are not used as equilibrium or full-protein estimates here.
5. Yadahalli & Gosavi, “Designing cooperativity into the designed protein Top7,” *Proteins* (2014), [DOI 10.1002/prot.24393](https://doi.org/10.1002/prot.24393). Direct prior art for simulated Top7 pathway/packing optimization and mutation-based cooperativity design.
6. Yadahalli et al., “A Method for Assessing the Robustness of Protein Structures by Randomizing Packing Interactions,” *Frontiers in Molecular Biosciences* (2022), [DOI 10.3389/fmolb.2022.849272](https://doi.org/10.3389/fmolb.2022.849272). Primary source listing the six-mutant Top7 repacking candidate; not an experimental finite-time validation of that sequence.
