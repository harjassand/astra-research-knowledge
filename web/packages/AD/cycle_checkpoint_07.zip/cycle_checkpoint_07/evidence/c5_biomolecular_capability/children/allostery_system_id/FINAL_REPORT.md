# P2X2 mirror symmetry: a protocol-level limit for kinetic allostery

## Verdict

I found a useful, exact experiment-design corollary for the 24-state P2X2 kinetic-conformational model: if its reported left/right mirror parameter modes are exact state relabelings, then **no globally applied ATP concentration waveform and no amount of scalar macroscopic-current data can decide which interface flank receives the stronger coupling**. The result extends the paper's ambiguity beyond its particular pulse grid. A subunit-resolved output or an intervention that breaks the mirror symmetry is required.

This is an internally reconstructed conditional theorem, not a new biological mechanism or a priority claim. Moffatt and Pierdominici-Sottile already report the left/right ambiguity in the posterior and use molecular dynamics to assign the stronger coupling. My result formalizes the consequence for every uniform input protocol. I have not independently enumerated and checked all 24 generator states, so the model-specific conjugacy remains the decisive verification gate.

## Model and data interface

The primary model is P2X2 Scheme IX: ATP binding/unbinding at three inter-subunit pockets is coupled to subunit rotations, with macroscopic current as the output. The paper fits outside-out patch recordings from rat P2X2 channels, including 0.2-ms ATP pulses at 0.1, 0.2, 0.5, 1, 2, and 10 mM, interleaved 10-ms pulses, and post-pulse deactivation. It reports that the ATP-binding/rotation coupling posteriors have two mirror modes because macroscopic currents cannot tell which of the two subunits framing a binding pocket gets the stronger effect. The source calls this an ambiguity preserved by the kinetic data and resolves the label using closed-state, single-ATP molecular-dynamics simulations.

The relevant experimental interface is therefore: common spatially uniform ATP input `c(t)`; ligand-binding and subunit-rotation hidden states; a permutation-invariant scalar current readout, including time averages; and no chain-resolved signal. The paper's pulse panel is a subset of this interface. The result does not cover site-selective ligand delivery, a subunit-specific initial condition, or chain-resolved observation.

## Exact symmetry theorem

Let `S` be a finite hidden-state space, `Q_theta(c)` the row-generator of a kinetic model at ATP concentration `c`, `pi_theta` its initial row distribution, and `g_theta` its vector of state currents. Suppose there is an involutive permutation matrix `P` and a mirror parameter vector `theta^M` such that, for every `c >= 0`,

```
Q_{theta^M}(c) = P^{-1} Q_theta(c) P,
pi_{theta^M} = pi_theta P,
g_{theta^M} = P^{-1} g_theta.
```

Then for every bounded, piecewise-continuous, spatially uniform ATP protocol `c(t)`, the two models induce the same law for the scalar current path. In particular they give identical expected current at every time, identical finite-dimensional distributions of current samples, and identical distributions of interval-averaged current measurements.

**Proof.** For a constant-concentration segment, if `p_theta(t)` is the hidden-state row distribution, then `p_theta'(t) = p_theta(t) Q_theta(c)`. Set `p_{theta^M}(t) = p_theta(t)P`. Its derivative is

```
p_theta(t) Q_theta(c) P
  = p_theta(t) P [P^{-1} Q_theta(c) P]
  = p_{theta^M}(t) Q_{theta^M}(c),
```

and the initial condition agrees by hypothesis. Thus `p_{theta^M}(t)=p_theta(t)P` throughout that segment. The same identity composes across every change in `c(t)`, so it holds for the entire protocol. The output agrees because

```
p_{theta^M}(t) g_{theta^M}
  = p_theta(t) P P^{-1} g_theta
  = p_theta(t) g_theta.
```

For the full path law, map every hidden path `X(t)` to `P^{-1}X(t)`. The generator conjugacy preserves each holding-time and jump probability, while the output map preserves the current along the relabeled path. Hence the pathwise current laws agree, not only their means. Any measurement noise whose conditional law depends only on that current also preserves the equality. ∎

With equal prior odds on the two orientations, identical likelihoods leave posterior odds equal to one for every possible dataset. Any decision rule that names one orientation has prior-averaged success at most `1/2`. Additional ATP doses, tighter time sampling, more patches, or a more accurate current-noise likelihood cannot change this structural limit. Those additions can reduce uncertainty about other parameters or model selection, but they cannot label the mirror pair.

## Application, evidence status, and boundary

The P2X2 paper directly reports the mirror-mode ambiguity under its multi-concentration, time-resolved current data and identifies the source as homotrimer symmetry. It also uses a chain-state mirror map in the released analysis code. The theorem above shows what follows if that source-reported mirror is a generator conjugacy at every common ATP concentration: no uniform-input scalar-current protocol can resolve the orientation, even with ideal noiseless data.

Evidence status:

- **Source-reported:** the 24-state Scheme IX fit has mirror posterior modes; the kinetic data alone do not assign stronger coupling to a particular side; the authors use single-ATP MD to orient the modes.
- **Internally reconstructed conditional theorem:** any exact generator/output permutation symmetry remains observationally exact under arbitrary common time-varying ligand input and current-only observation.
- **Not verified here:** explicit symbolic conjugacy for every Scheme IX transition-rate expression, initial-condition calculation, and current assignment. The open repository is available, but I did not rerun its model engine or independently reconstruct the full 24-state generator.
- **Not established:** external novelty, priority, or experimental validation of the inferred allosteric pathway.

This is distinct from the prior biomolecular reports' equilibrium 2x2 cycle no-go, PDZ3 extension/mutation analysis, reversible riboswitch CTMC, absorbing exposure-law, and target-versus-decoy ensemble argument. It still remains close to the P2X2 paper's own reported ambiguity, so the right claim is a protocol-level corollary with a new experiment-design consequence, not a new identifiability theory.

## Next gate: break the hidden permutation

First reconstruct Scheme IX's state graph and confirm `Q_{theta^M}(c)=P^{-1}Q_theta(c)P` symbolically for every transition class, including the zero-ATP initial distribution and current map. The paper's exact mirror posterior and its released mirror-state analysis make this a focused check. If even one transition, prior, or emission fails the conjugacy, revise the theorem to the parameter/input subset for which equality holds.

If conjugacy holds, stop spending experimental budget on additional uniform ATP/current traces to resolve orientation. The minimal information change is an observation or intervention that is not invariant under `P`, for example a chain-tagged rotation reporter in a P2X2 concatemer, paired with the same ATP-pulse protocol and a label-swapped control. The mirror models predict the same total current but opposite assignment of the larger rotation response to the tagged flank. A chain-specific perturbation can serve instead if its effect on that subunit's transition rates is independently calibrated. Readouts must include both the current and the subunit-resolved signal; a mutation whose effect is unconstrained simply adds new unknown rates.

The current paper reports 5–12 patch recordings per ATP concentration and 12–52 days of sampling per model on 16–32 CPU cores; it also deposits the processed recordings, posterior samples, and modeling code. Those are source-reported costs for the existing analysis, not a cost estimate for the proposed labeled construct. Labeling, concatemer validation, patch recordings, and calibration of the reporter's effect are additional and unpriced. A decisive falsifier of the current no-go would be a reproducible likelihood difference between the exact mirror pair under a uniform ATP waveform and the same permutation-invariant current emission, after checking the full conjugacy; such a difference means one of the stated symmetry premises fails.

## Primary sources and reproducibility

- Moffatt & Pierdominici-Sottile, “Bayesian inference of functional asymmetry in the homotrimeric ligand-gated ion channel P2X2,” *Communications Biology* 8, 1740 (2025), [article](https://doi.org/10.1038/s42003-025-09056-x). Relevant primary-text locations: Results on mirror posterior ambiguity and MD relabeling; Discussion on alternatives and the need for single-channel recording, targeted mutagenesis, and time-resolved cryo-EM; Methods for ATP pulse concentrations and sample counts.
- The authors' [kinetic-model code and data](https://github.com/lmoffatt/macro_dr_submission), including nine schemes and MacroIR/MacroINR; repository head inspected locally: `b4a0e28d917dc7ad5f9dd1a328b20eb1614a1f2c`. The paper lists [Zenodo posterior samples](https://doi.org/10.5281/zenodo.15085038) and [archived MacroIR package](https://doi.org/10.5281/zenodo.17162475).
- White, Rottschäfer & Bridge, “Classical structural identifiability methodology applied to low-dimensional dynamic systems in receptor theory,” *J. Pharmacokinet. Pharmacodyn.* 51, 39–63 (2024; published online 2023), [DOI](https://doi.org/10.1007/s10928-023-09870-y). This already derives how dose curves, washout, and multiple time courses restore or fail to restore kinetic-parameter identifiability in monomer, competition, and pre-dimerized GPCR binding models.
- White, Rottschäfer & Bridge, “On the structural identifiability of nonlinear models of ligand binding dynamics,” *J. Pharmacokinet. Pharmacodyn.* 53, 42 (2026), [DOI](https://doi.org/10.1007/s10928-026-10040-z). This analyzes ligand-depletion and ligand-induced-dimerization models; the latter's global identifiability depends on calibration of the output scale. This further limits any broad novelty claim for generic ligand/time-course identifiability.
- Vogt & Di Cera, “Conformational selection or induced fit? A critical appraisal of the kinetic mechanism,” *Biochemistry* 51, 5894–5902 (2012), [DOI](https://doi.org/10.1021/bi3006913). This proves concentration-dependent relaxation slopes do not generally identify one mechanism class: conformational selection can yield either increasing or decreasing `k_obs` as ligand concentration rises.

The Astra bootstrap was read as required; its static topic routes contain mathematical topics but no biomedical/allostery card used here. The biological mechanism and limits above come from primary papers and their public model package.
