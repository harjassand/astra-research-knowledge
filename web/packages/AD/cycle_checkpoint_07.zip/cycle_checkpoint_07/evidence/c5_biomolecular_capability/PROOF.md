# Equilibrium occupancy does not certify native occupancy at a fixed time

## Interface

Consider the reversible two-state continuous-time Markov model with unfolded state `U`, native state `N`, folding rate `k_f > 0`, and unfolding rate `k_u > 0`. Start from `U`. Let `tau > 0` be a fixed assay time and let `Y(t)=1{X_t=N}` indicate occupancy of the native state at that sampling time. This is a timepoint occupancy, not the first-passage probability of having visited `N` by `tau`.

The stationary native probability is

`pi_N = k_f/(k_f+k_u)`.

The exact finite-time native probability is

`P(Y(t)=1) = pi_N (1 - exp(-(k_f+k_u)t))`.

## Proof

Writing `p(t)=P(X_t=N)`, the forward equation is

`p'(t) = k_f(1-p(t)) - k_u p(t) = k_f - (k_f+k_u)p(t)`, with `p(0)=0`.

Solving this scalar linear ODE gives `p(t)=k_f/(k_f+k_u) * (1-exp(-(k_f+k_u)t))`.

For any `s>0`, replace both rates by `s k_f` and `s k_u`. The stationary probability remains `pi_N`, so the equilibrium free-energy difference inferred from the two-state distribution is unchanged. But the native occupancy at assay time becomes

`p_s(t) = pi_N (1 - exp(-s (k_f+k_u)t))`,

which tends to zero as `s -> 0`. Therefore equilibrium native occupancy alone yields no strictly positive lower bound on native occupancy at a fixed finite time, even when the entire two-state equilibrium law is known exactly.

For a requested target occupancy `y` with `0 <= y < pi_N`, a necessary and sufficient kinetic gate in this model is

`k_f+k_u >= -log(1-y/pi_N)/tau`.

If `y >= pi_N`, no finite rate can meet the target from `U` at the specified equilibrium occupancy.

## Evidence and limits

This is an exact model theorem, not a protein law. It assumes two resolved conformational basins and time-homogeneous reversible rates. It does not map amino-acid substitutions to rates, identify real basins, or show that any particular protein has a two-state pathway. A multistate model requires its acquired generator or a valid reduction of it. The included `finite_time_yield.py` evaluates the exact formula for one finite witness: the fast and slow rate pairs have identical `pi_N=0.95`, but at `tau=1` their native-state occupancies are approximately `0.600515` and `9.5e-9`.
