# Cycle 4: Acquiring detector scale after full-outcome symmetrization

## Verdict and scope

The full completed instrument supplies a state-independent scalar calibration observable even when every physical detector has its own unknown, stable efficiency and dark rate. Rotate **all** (M=m+d) completed outcomes through all (M) detector channels for equal durations, then aggregate counts by instrument outcome. The source-click total has mean (N\bar\eta), independent of the unknown state, while each row has the same additive dark mean. A source-on/source-off confidence sequence therefore learns a lower bound on average efficiency and an upper bound on total dark rate without a trusted quantum reference state or channel-by-channel efficiency calibration. An independent pilot can stop adaptively; it then chooses one fixed main dose before any tomography records are taken.

Composing this acquired scalar calibration with the inherited HLN Theorem 4 transfer gives a sufficient dose, for (m=\Theta(d)), of

\[
N=O\!\left(\frac{d}{\bar\eta\,\varepsilon^2}
  +\frac{d\,\Gamma}{\phi\,\bar\eta^2\varepsilon^2}\right),
\qquad \Gamma=\sum_{i=1}^M b_i,
\]

up to source-theorem constants, where (b_i) is detector (i)'s dark rate and (\phi) is a calibrated launched-photon rate. This is an acquired-device guarantee conditional on the known optical frame and ideal Poisson/detector model, not a hardware result or a new phase-retrieval estimator. The leading (O(d/\varepsilon^2)) signal term is established prior art. The *averaging idea* is also prior art in detector-efficiency symmetrization for QKD. The narrow quantitative contribution here is the complete-(M)-outcome Poisson reduction plus an anytime, reference-free scalar efficiency/background pilot and its cost relative to the tomography dose.

Exact global Poisson conditioning also gives a fixed-(N) version, but only for a source protocol that randomly allocates the (N) launches among equal-duration detector-permutation windows. Fixed balanced quotas (N/M) per window are a different experiment and do not inherit the single $O(\sqrt N)$ conditioning factor.

## Instrument and exact symmetrized law

Use the Cycle 3 frame (B=[\sqrt aG;R]\in\mathbb C^{M\times d}), (a=1/(4m)), (R=(I-aG^*G)^{1/2}), (M=m+d), on its good event. Its row effects (E_j=b_jb_j^*) obey $\sum_{j=1}^M E_j=I$. The first (m) rows have (E_j=a g_jg_j^*), with iid complex-Gaussian (g_j); the last (d) rows are the completion. The frame is assumed known exactly by the estimator.

There are (M) physical detector channels with unknown constant quantum efficiencies $\eta_i\in[0,1]$ and unknown constant independent Poisson dark rates $b_i\ge0$. Define

\[
\bar\eta=M^{-1}\sum_i\eta_i>0,\qquad
\bar b=M^{-1}\sum_i b_i,\qquad \Gamma=M\bar b.
\]

During a source-on block of duration (T), hold the prepared unit state (x) and calibrated source flux $\phi$ constant. Use (M) equal windows (s=0,\ldots,M-1) and cyclic output-to-detector assignment $\pi_s(j)=j+s\pmod M$. In the Poissonized reference experiment, each window launches an independent $\operatorname{Pois}(\phi T/M)$ number of copies. Let (Y_{js}) count clicks attributed to outcome (j) in window (s), and set (Y_j=\sum_sY_{js}). Poisson thinning gives independent counts

\[
Y_{js}\sim\operatorname{Pois}\!\left(\frac{\phi T}{M}\eta_{\pi_s(j)}p_j(x)
                         +\frac{T}{M}b_{\pi_s(j)}\right),
\quad p_j(x)=x^*E_jx.
\]

Summing over the full cycle proves, exactly,

\[
Y_j\ \text{independent},\qquad
Y_j\sim\operatorname{Pois}\bigl(N\bar\eta p_j(x)+\beta\bigr),
\quad N=\phi T,\quad \beta=T\bar b=\frac{N\Gamma}{\phi M}.
\tag{1}
\]

This includes the residual ports. Since $\sum_jp_j(x)=1$, the source part of the all-port click total is $\operatorname{Pois}(N\bar\eta)$, independent of (x); the dark part is independent $\operatorname{Pois}(T\Gamma)$. The complete frame, equal source flux and time in every setting, stable state over the full cycle, and detector-only scalar response are load-bearing assumptions. An unknown launch flux leaves only the product $\phi\bar\eta$ observable: independent calibrated flux metrology or a heralded launch count is required.

Without cycling, arbitrary unknown detector efficiencies can exactly mask the state even with zero background. For any generic pair of states x,y with all p_j(x),p_j(y)>0, choose 0<c<=min_j{p_j(x),p_j(y)}. In one world set eta_j=c/p_j(x), and in the other set eta'_j=c/p_j(y). Both are valid efficiencies in [0,1], and every fixed-setting source count has the same mean Nc in both worlds. This is a static no-reference identifiability obstruction; the full cycle replaces it by the common multiplicative factor eta_bar times a known row probability, and its all-port total identifies that factor once flux is known.

For an independent source-off block of duration (rT) run through the same cycle, its row counts satisfy

\[
Z_j\ \text{independent},\qquad Z_j\sim\operatorname{Pois}(r\beta).
\tag{2}
\]

Thus rowwise blank subtraction (Y_j-Z_j/r) is exactly the common-background iid-noise model used in the Cycle 3 transfer, although the underlying (b_i) are heterogeneous. The main blank is independent of both the pilot and main signal and costs (rT) detector exposure, (M) settings, and expected (rT\Gamma) dark clicks across all channels. For (r=1), the prior CYCLE3_REPORT gives

Two equal-duration source-on levels also cancel the additive dark **mean**: if their launched means are (N_H,N_L), then (D_j=Y^H_j-Y^L_j) has mean $(N_H-N_L)\bar\eta p_j(x)\$. Its centered noise is the difference of independent Poisson noises with fourth moment $\lambda_H+\lambda_L+3(\lambda_H+\lambda_L)^2\$, so dark shot noise remains and the lower-flux block still costs launches. Setting (N_L=0) recovers the independent blank. Under the stated additive Poisson model, flux modulation does not remove the background variance term; it only cancels the offset in the mean. The exact confidence sequence and dose theorem above use an independent blank rather than this alternate difference estimator.

\[
d_\phi(\hat x,x)\le C\!\left[
\sqrt{\frac d{N\bar\eta}}
+\frac{\sqrt{\beta dm}}{N\bar\eta}
+\frac{\sqrt{dm}}{N\bar\eta}(\beta^{1/4}+\sqrt\beta)\right]
\tag{3}
\]

with its HLN Theorem 4 tail probability, assuming its oversampling and high-energy conditions. For (m=\Theta(d)), the first term dominates the beta terms when $\beta\le1$; when $\beta\ge1$, they are bounded by the $d\sqrt\beta/(N\bar\eta)$ term. A sufficient dose is therefore

\[
N\bar\eta\ \ge C\left(\frac d{\varepsilon^2}
                  +\frac{d\sqrt\beta}{\varepsilon}\right).
\]

Substitute $\beta=N\Gamma/(\phi M)$ and solve the quadratic inequality in $\sqrt N$:

\[
N\ge C\left(\frac d{\bar\eta\varepsilon^2}
           +\frac{dm\Gamma}{M\phi\bar\eta^2\varepsilon^2}\right).
\tag{4}
\]

Because (m/M\le1), the signal-dominated pilot term below adds only a constant multiple of the first term to this dose. With (m,d,M=\Theta(d)), (4) is (O(d/(\bar\eta\varepsilon^2)+d\Gamma/(\phi\bar\eta^2\varepsilon^2))), or (O(d/(\bar\eta\varepsilon^2)+d^2\bar b/(\phi\bar\eta^2\varepsilon^2))).

## Adaptive scalar calibration, independent of state and main data

At pilot look $\ell=0,1,\ldots$, use cumulative equal source-on and source-off exposure (t_\ell=t_0 2^\ell). The on block runs the complete (M)-permutation cycle; the off block needs only one fixed detector assignment because its **total** dark count is invariant to assignment. Let the sums over all detectors be (C^+_\ell,C^-_\ell). Under the stable model,

\[
C^+_\ell\sim\operatorname{Pois}(t_\ell u),\quad
C^-_\ell\sim\operatorname{Pois}(t_\ell\Gamma),\quad
u=\phi\bar\eta+\Gamma.
\]

Construct exact two-sided Garwood intervals $[u_L,u_U]$ and $[\Gamma_L,\Gamma_U]$ for the two rates at look $\ell$, each with failure probability at most $\delta_\ell=3\alpha/[\pi^2(\ell+1)^2]$. A union bound over the two streams and all looks gives simultaneous coverage at least (1-\alpha), without treating cumulative looks as independent. Set

\[
\eta_L=\max\{0,(u_L-\Gamma_U)/\phi\},\qquad
\eta_U=\max\{0,(u_U-\Gamma_L)/\phi\}.
\]

Stop at the first look satisfying

\[
\eta_L>0,\qquad \eta_U\le2\eta_L,\qquad
\Gamma_U\le2\Gamma_L+\phi\eta_L.
\tag{5}
\]

On the simultaneous-coverage event, (5) implies $\eta_L\ge\bar\eta/2$ and $\Gamma_U\le2\Gamma+\phi\bar\eta$. For any fixed $\bar\eta>0$ and finite $\Gamma$, the exact Poisson interval widths vanish and the stop is almost surely finite. A standard Poisson/Garwood radius bound gives the high-probability pilot order

\[
n_{\rm pilot}=\phi t_{\rm stop}
=O\!\left(\frac{\phi\bar\eta+2\Gamma}{\phi\bar\eta^2}
             \left[\log\frac1\alpha+
                    \log\log\!\left(e+\frac{\phi\bar\eta+2\Gamma}
                                      {\phi^2\bar\eta^2t_0}\right)\right]\right)
\tag{6}
\]

More explicitly, a sufficient dyadic checkpoint \(\ell_*\) obeys
\[
t_{\ell_*}\ge C\frac{\phi\bar\eta+2\Gamma}{\phi^2\bar\eta^2}
\log\!\left(\frac{C(\ell_*+1)^2}{\alpha}\right).
\]
Poisson Bernstein bounds and the Garwood endpoint widths then put both rate intervals within a small multiple of \(\phi\bar\eta\) at that look with high probability; this implies all three stop conditions in (5). Solving this implicit dyadic condition gives (6), including its iterated-log term.

launched pilot photons, up to constants and the next dyadic checkpoint; the off pilot takes the same time but launches no photons. The logarithm-logarithm is the cost of time-uniform monitoring. A direct local Fisher-information calculation shows this order is sharp up to confidence logarithms: for equal on/off exposure (t), the Fisher information for $\bar\eta$ after eliminating the nuisance $\Gamma$ is

\[
I_{\rm eff}(\bar\eta)=\frac{t\phi^2}{\phi\bar\eta+2\Gamma}.
\tag{7}
\]

Thus relative-constant accuracy requires (t=\Omega((\phi\bar\eta+2\Gamma)/(\phi^2\bar\eta^2))) for regular estimators. Because the source-click total is state-independent, the pilot does not use a known quantum probe. It still requires calibrated source flux, a prepared state stable during every on cycle, stable detector rates, (M) on-settings per cycle, and one independent off exposure. Scalar pilot records are not used as tomography rows.

After stopping, set a deterministic main dose before collecting main data:

\[
N_{\rm main}=\left\lceil C\left[
\frac d{\eta_L\varepsilon^2}
+\frac{dm\Gamma_U}{M\phi\eta_L^2\varepsilon^2}
\right]\right\rceil.
\tag{8}
\]

Use a **fresh independent** main signal block at this dose and a fresh row-resolved source-off blank of relative duration (r=1). Conditional on the pilot record and its coverage event, (8) is a fixed dose and the main Poissonized record satisfies the Cycle 3 theorem. The pilot is independent of main signal and blank records; no stopping on main counts is allowed in this transfer. The calibration launched-photon overhead relative to (8) is (O(\varepsilon^2 L/d)) for (m=\Theta(d)), where (L) is the time-uniform log factor in (6), when (d) is large compared with that logarithm. The pilot and main dark exposure, blank clicks, time, and all source launches are charged separately.

With a valid fallback on a bad frame, the combined Poissonized failure probability is at most the pilot coverage error (alpha), plus the bad-frame probability, plus the inherited HLN Theorem 4 tail. Under the randomized-window fixed-(N) protocol, apply (9) to the HLN tail conditional on a good frame, giving a bound (alpha + Pr{G bad} + C sqrt(N_main) delta_HLN). The fixed-(N) factor is a transfer bound and may be loose.

### Local lower bound for the main dose

The background-sensitive calculation below uses only the Gaussian block, because the transferred estimator discards residual counts. It is a matched lower bound for that information channel, not a full-device minimax result: residual outcomes might improve constants, particularly at high background, and the corresponding full-device bound is open. The universal shot-noise order also follows from pure-state quantum Fisher information.

This is a local regular-estimation lower bound under the *easier* control that (\bar\eta) and the common background (\beta) are known. For one Gaussian row, write (s=N\bar\eta a=N\bar\eta/(4m)), (U=|g^*x|^2\sim\mathrm{Exp}(1)). Along a unit tangent (h\perp x), (g^*h) is an independent standard complex Gaussian and

\[
\mathbb E\,\mathcal I_{j,h}
=2s^2\mathbb E\!\left[\frac U{sU+\beta}\right]
=\Theta\!\left(\frac{s^2}{s+\beta}\right).
\]

Summing (m) independent rows gives tangent information $\Theta((N\bar\eta)^2/(N\bar\eta+m\beta))$. A local Cramér–Rao/van-Trees risk bound in (\Theta(d)) tangent directions therefore requires

\[
N\bar\eta=\Omega\!\left(\frac d{\varepsilon^2}
                    +\frac{\sqrt{dm\beta}}{\varepsilon}\right),
\]

which matches the sufficient HLN transfer in (3) at order. Substituting $\beta=N\Gamma/(\phi M)$ yields the same two terms as (4). This is not a finite-sample minimax lower bound for every state or detector model; it is a local comparison establishing that the dose law is not merely an artifact of subtraction.

## Fixed photon number: one global conditioning, with a different source protocol

The Poissonized reference has independent per-window source totals (K_s\sim\operatorname{Pois}(N/M)). Their global sum (K\sim\operatorname{Pois}(N)). Conditional on **only** (K=N), the allocations are (\operatorname{Multinomial}(N;1/M,\ldots,1/M)). This is exactly the fixed-(N) randomized-window protocol: independently assign each of the (N) photons a uniformly random setting (s), then deliver the assigned photons during the (M) equal-duration windows. Given a photon assigned to (s), its detector-click outcome (j) has probability $\eta_{\pi_s(j)}p_j(x)$; marginalizing the uniform setting label gives

\[
\Pr\{\text{detected source outcome }j\}
=\frac1M\sum_s\eta_{\pi_s(j)}p_j(x)
=\bar\eta p_j(x).
\]

The complementary no-detection/loss outcome is retained, so the full (M+1)-category source law is normalized and the total detected source probability is (\bar\eta), independent of (x). Dark counts are independent of (K_s); with detectors active through each equal-duration window they remain independent Poisson variables under conditioning, and cyclic mapping gives the same row background mean. Therefore, for any failure event (F) formed from the aggregated main row counts and an independent blank,

\[
\Pr_{\rm fixed\ N}(F)
=\Pr_{\rm Pois}(F\mid K=N)
\le\frac{\Pr_{\rm Pois}(F)}{\Pr\{\operatorname{Pois}(N)=N\}}
\le C\sqrt N\,\Pr_{\rm Pois}(F).
\tag{9}
\]

This is one global factor, irrespective of (M). It assumes the launch-to-window allocation is randomized multinomially, the source flux monitor knows (N), time windows remain equal, and detectors collect independent dark counts for full windows without dead time, saturation, or flux-dependent gating. A deterministic balanced schedule (K_s=N/M) is not obtained by this conditioning: its Poisson representation conditions on all (M) window totals separately and can incur a much worse product probability. Random allocation can cause variable instantaneous window flux; rate-dependent detector effects or source/state changes would violate the model and must be tested. The pilot can be run as its own Poissonized calibration exposure; (9) applies only to the independently chosen fixed-(N) main block.

## Settings lower bound and approximate randomization

Suppose the only permitted control is a mixture of (K) port permutations with nonnegative exposure weights summing to one. To average arbitrary vectors $\eta\in[0,1]^M$ and $b\in[0,\infty$^M) exactly at every outcome, each row must see every detector for exactly (1/M) of exposure. The assignment matrix must be (J_M/M). Each permutation matrix has (M) nonzero cells, while (J_M/M) has (M^2); hence (K\ge M). The cyclic shifts attain this bound. This is a worst-case lower bound within permutation-only symmetrization, not across arbitrary optical designs or detector-sharing hardware.

With (K<M) independent uniformly random permutations and a fixed unknown vector (\eta_i\in[0,1]), each row's empirical detector efficiency is an iid sample average across settings. Hoeffding plus a union bound gives

\[
\Pr\!\left\{\max_j|\hat\eta_j-\bar\eta|>q\right\}
\le2M e^{-2Kq^2},
\]

and similarly $\max_j|\hat b_j-\bar b|\le b_{\max}\sqrt{\log(2M/\delta)/(2K)}$ with probability (1-\delta) if (b_i\le b_{\max}). This suggests (K=O(\log(M/\delta)/q^2)) settings for fixed-device *approximate averaging*. It does not prove a tomography law: the realized rows have correlated heterogeneous gains and offsets, so the iid HLN hypotheses fail. No perturbation theorem transferring this deviation to phase error was found or established here. Randomized settings below (M) are therefore a research lead, not an asserted capability.

## Drift extension is separate and conditional

For detector-specific affine drift (\eta_i(t)=a_i+c_it) and (b_i(t)=d_i+e_it) within one measurement block, replace the (M)-setting order by the (2M)-setting palindrome

\[
0,1,\ldots,M-1,M-1,\ldots,1,0,
\]

with equal-duration windows. Each outcome-detector pair appears in two windows whose time centers are symmetric about the block midpoint. Its integrated affine response is exactly its midpoint response, so the aggregated row law has (\bar\eta(t_{mid})) and $\bar b(t_{mid})$; the extra setting factor of two is charged. For rowwise blanks, use equal pre- and post-signal blanks whose block midpoints average to the signal midpoint; their combined counts give the corresponding midpoint dark mean under the affine model. Constant source flux and stable (x) throughout each block remain necessary; a product of drifting flux and drifting efficiency is not affine.

This within-block identity does **not** transport a pilot bound to a later main block. If known bounds $|\dot{\bar\eta}|\le L_\eta$, $|\dot\Gamma|\le L_\Gamma$ and the pilot/main midpoint gap is $\Delta t$, replace $\eta_L$ by $\max(0,\eta_L-L_\eta\Delta t)$ and $\Gamma_U$ by $\Gamma_U+L_\Gamma\Delta t$ in (8). Without such bounds, use a contemporaneous/epoch-specific independent pilot, or mark calibration transfer unknown. Optical frame drift is outside this extension.

## Matched controls and prior-art boundary

- **Calibrated-detector control.** With the same known frame (B), source flux, launch budget, and row blank, a control supplied the per-channel $\eta_i,b_i$ can use one unpermuted setting and its exact heterogeneous Poisson likelihood. It avoids the (M)-setting symmetrization and pilot. Our theorem removes the need to acquire the channelwise detector vector, at the cost of cyclic switching, scalar pilot photons, and a fresh symmetric blank. It does not beat this better-informed control's sample order.
- **Classical QDT control.** Lundeen et al. (Nature Physics 5, 27–30, 2009) define detector tomography using trusted known probe states to reconstruct each POVM effect. A complete unknown (M)-outcome POVM has (\Theta(Md^2)) unconstrained real parameters before structure; a detector-only diagonal efficiency/dark model is much smaller. Such probes can characterize the detector vector, but their photons/state-preparation quality and solver cost must be charged. Our construction instead assumes the optical frame exactly and acquires only average efficiency and dark rate.
- **Self-calibrating tomography control.** Sim et al., Phys. Rev. A 100, 022333 (2019), jointly estimate a BB84 double-crosshair state and detector-efficiency parameters with joint error regions. This is direct prior art for estimating state and detector parameters from one dataset in a restricted detector/state geometry. The present pilot uses a different invariant (all-outcome source-click total) and avoids using the state-dependent row counts for the scalar efficiency CS; there is no claim that joint self-calibration is generally impossible or inferior.
- **Self-consistent measurement/process tomography.** Self-consistent measurement tomography (e.g. Phys. Rev. Research 5, 033154 (2023)) can fit state preparations and POVM effects jointly; self-consistent quantum process tomography by Merkel et al. (Phys. Rev. A 87, 062119, 2013) addresses gate libraries with imperfect preparation/measurement gates. These methods target broader SPAM/process recovery and have gauge freedoms. Their source papers do not imply this specific per-photon Poisson row law, anytime scalar calibration cost, or efficiency-independent complete-frame invariant. They remain stronger model-characterization baselines when their trusted controls and gauge-fixing data are available.
- **Detector symmetrization.** Symmetrization/randomization is established QKD practice. Taylor et al., Phys. Rev. Applied 25, 054029 (2026), experimentally implemented the four-state countermeasure against detector efficiency mismatch in a gigahertz-clocked prototype; earlier theory and experiments are cited there. Thus cycling detector assignments is not itself novel. The distinction here is extending exact averaging over every completed tomography outcome, including residual outcomes, to obtain iid Poisson phase-retrieval rows and a state-independent scalar calibration statistic.
- **Tomography rate.** HLN arXiv:2510.00551v1 Theorems 1 and 4 already supply the estimator and error transfer; the Cycle 3 report reconstructs that interface. The inherited $O(d/\varepsilon^2)$ pure-state copy order is also matched by single-copy tomography bounds. No new estimator, universal rate, or hardware advantage is claimed.

## Remaining boundaries and decisive test

This model still assumes known exact (G) and Parseval completion, known source flux/launch allocation, stable preparation during every block, detector response depending only on physical channel, independent Poisson dark events, no afterpulsing/dead time/saturation, and lossless known permutation controls. The first (m) row coefficients are (md=\Theta(d^2)); the residual completion and generic optical unitary synthesis retain their separate precision and component costs. The symmetrization does not calibrate or remove those optical coefficients.

The decisive test is a held-out complete-frame run with intentionally heterogeneous detector efficiencies and dark rates. Before revealing state labels, validate that (i) across each full (M)-cycle the row count means agree with $N\bar\eta p_j+\beta$, (ii) the total source-click pilot is independent of prepared state within statistical intervals, and (iii) source-off row means match (r\beta). Then compare achieved phase risk and total launches with the predeclared (3)–(8) prediction and with a fully channel-calibrated likelihood using the same photons. State-dependent aggregate click yield, channel-mode interactions, drift beyond bounds, setting-dependent insertion loss, saturation, or a failed independent blank falsifies this interface. No physical experiment was run here.

## Sources

Primary references refreshed for this audit:

1. Huang, Li, Needell, *Stable Phase Retrieval: Optimal Rates in Poisson and Heavy-tailed Models*, arXiv:2510.00551v1, Theorems 1 and 4: https://arxiv.org/html/2510.00551v1
2. Taylor et al., *Practical countermeasure against attacks exploiting detection-efficiency mismatch in quantum key distribution*, Phys. Rev. Applied 25, 054029 (2026), published 12 May 2026 and corrected 29 June 2026: https://doi.org/10.1103/7zhl-5vv1
3. Sim et al., *Proper error bars for self-calibrating quantum tomography*, Phys. Rev. A 100, 022333 (2019): https://doi.org/10.1103/PhysRevA.100.022333 ; preprint https://arxiv.org/abs/1904.11202
4. Lundeen et al., *Tomography of quantum detectors*, Nature Physics 5, 27–30 (2009): https://doi.org/10.1038/nphys1133
5. Innocenti et al., *Self-consistent quantum measurement tomography based on semidefinite programming*, Phys. Rev. Research 5, 033154 (2023): https://doi.org/10.1103/PhysRevResearch.5.033154
6. Merkel et al., *Self-consistent quantum process tomography*, Phys. Rev. A 87, 062119 (2013): https://doi.org/10.1103/PhysRevA.87.062119 ; preprint https://arxiv.org/abs/1211.0322
7. Lowe and Nayak, *Lower bounds for learning quantum states with single-copy measurements*, arXiv:2207.14438v3, Theorems 4.11–4.12: https://arxiv.org/html/2207.14438v3

The external source results are prior-art statements, not independent audits of their proofs. The reduction, confidence-sequence protocol, information calculations, setting lower bound, and global-conditioning identity are internally derived here; only finite matrix/algebra checks are executable evidence. The optical and detector model remains unvalidated.
