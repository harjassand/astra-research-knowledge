# Selective primary-source map

## Direct statistical theorem

- Huang, Li, Needell, *Stable Phase Retrieval: Optimal Rates in Poisson and Heavy-tailed Models*, arXiv:2510.00551v1, [HTML](https://arxiv.org/html/2510.00551v1), [abstract](https://arxiv.org/abs/2510.00551). The inherited measurement-inverse report identifies Theorems 1 and 4, assumptions, estimator, and row-count interface. Here this is used only after exact symmetrization restores iid Gaussian-block Poisson means. The source theorem does not cover unknown per-detector gains, setting drift, finite-bit SDP accuracy, or hardware.

## Symmetrization prior art

- Taylor et al., *Practical countermeasure against attacks exploiting detection-efficiency mismatch in quantum key distribution*, Phys. Rev. Applied 25, 054029 (2026), [DOI](https://doi.org/10.1103/7zhl-5vv1). APS lists publication on 12 May 2026 and a correction on 29 June 2026. Its abstract reports experimental implementation of the four-state countermeasure in a gigahertz-clocked QKD prototype. This establishes that detector efficiency symmetrization/randomization is not novel as an operation. Its security/key-rate interface differs from the all-outcome Poisson tomography theorem here.
- The Taylor paper cites Ferreira da Silva et al., *Safeguarding Quantum Key Distribution Through Detection Randomization*, IEEE J. Sel. Top. Quantum Electron. 21, 159 (2015), and M. A. Ruhul Fatin and S. Sajeed, *Generalized efficiency mismatch attack to bypass the detection-scrambling countermeasure*, Opt. Express 29, 16073 (2021). These are source trails for earlier theory and adversarial boundaries, not claims that this tomography model was previously established.

## Detector calibration and self-calibration controls

- Lundeen et al., *Tomography of quantum detectors*, Nature Physics 5, 27–30 (2009), [DOI](https://doi.org/10.1038/nphys1133). Primary QDT reference. The usual interface probes an unknown detector/POVM with known input states and reconstructs effects. The present interface assumes the optical frame known and acquires only average efficiency and dark rate without a trusted state probe.
- Sim et al., *Proper error bars for self-calibrating quantum tomography*, Phys. Rev. A 100, 022333 (2019), [DOI](https://doi.org/10.1103/PhysRevA.100.022333), [arXiv](https://arxiv.org/abs/1904.11202). Primary self-calibrating tomography paper. Its abstract describes joint state/device error regions and a BB84 double-crosshair example estimating detector efficiencies from the same dataset. It is direct prior art against any broad claim that simultaneous state/detector estimation is impossible.
- Innocenti et al., *Self-consistent quantum measurement tomography based on semidefinite programming*, Phys. Rev. Research 5, 033154 (2023), [DOI](https://doi.org/10.1103/PhysRevResearch.5.033154). Primary SDP QMT source. It describes self-consistent recovery of input states and POVM effects under informational completeness without assuming known input states. This is a broader model-fitting control, not the same acquired count law.
- Merkel et al., *Self-consistent quantum process tomography*, Phys. Rev. A 87, 062119 (2013), [DOI](https://doi.org/10.1103/PhysRevA.87.062119), [arXiv](https://arxiv.org/abs/1211.0322). Primary SPAM/process-calibration source. It reconstructs a library of gates self-consistently when preparation and measurement gates carry systematic error. It does not directly provide the detector-permutation Poisson reduction or its flux/blank acquisition law.

## Sample-complexity lower control

- Lowe and Nayak, *Lower bounds for learning quantum states with single-copy measurements*, arXiv:2207.14438v3, [HTML](https://arxiv.org/html/2207.14438v3), Theorem 4.11 for rank-one pure states. The primary lower bound supports the established \(\Omega(d/\varepsilon^2)\) copy order. It does not include this detector calibration interface, its dark-rate term, or switching costs.

## Internal derivations and evidence boundary

The exact cyclic row law, scalar source-on/off rates, anytime alpha-spending construction, nuisance-adjusted Fisher information, permutation support lower bound, affine within-block palindrome identity, and one-global-total conditioning calculation are reconstructed in `REPORT.md`. `symmetrization_check.py` checks exact finite rational instances only. It is not a proof of detector hardware behavior, the imported HLN theorem, physical source scheduling, or novelty.
