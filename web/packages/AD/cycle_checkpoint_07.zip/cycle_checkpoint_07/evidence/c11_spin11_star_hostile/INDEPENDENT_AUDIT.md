# Independent Spin(11) star audit

## Verdict

I found no representation, dual-action, output-swap, Clifford-sign, or support-ray contradiction in `cycle10_spin11_probe`. The four attained seeds are sufficient for the claimed common-comparator result; the argument does not need the exact support body of all canonical entanglement-breaking channels. This is a conditional internal audit, not an external proof review: I independently reconstructed the representation and swap bookkeeping, replayed the seed moments from a separate bit-mask implementation, checked exact full-space trace invariants of the supplied reduced star blocks, and independently recomputed the four-seed support cones and their PSD gaps. I did not independently rebuild every star block from the full 32768-dimensional action.

## Representation, dual, and swap audit

Let (V) be the 11-dimensional vector representation and (S) the 32-dimensional spinor. The Clifford identification gives
\[
S^*\otimes S\cong \operatorname{End}(S)\cong\bigoplus_{j=0}^{5}\Lambda^j V,
\qquad \sum_{j=0}^{5}\binom{11}{j}=1024=32^2.
\]
The usual gamma-trace/Pieri decomposition is
\[
\Lambda^j V\otimes S\cong\bigoplus_{r=0}^{j}T_r,
\quad \lambda(T_r)=(\tfrac32^r,\tfrac12^{5-r}),
\quad \dim T_r=32\left(\binom{11}{r}-\binom{11}{r-1}\right).
\]
Summing over (j) gives multiplicity (6-r) for (T_r). The dimensions are (32,320,1408,3520,5280,4224), and the weighted total is (32768). This independently supports the candidate's ordinary-tensor decomposition.

The dual on the reference factor matters. With the candidate's computational-basis weights, the reference factor contributes the negative spinor weights; its Lie-algebra raising action is (-E^T), while the two output factors use (E). For a target highest weight with (r) coordinates equal to (3/2), those (r) coordinates force all three signs to (+1/2). Each of the other (5-r) coordinates has three assignments with sum (+1/2). Thus the target weight-space dimensions are (3^{5-r}=243,81,27,9,3,1), exactly the source-space sizes recorded by the extractor. The asserted kernel dimensions (6-r) agree with the representation decomposition.

The output-swap signs can be derived without the extractor. In the five-qubit Clifford realization, six gamma matrices are transpose-symmetric and five are transpose-skew. Let (C) be the product of the five skew gamma matrices. Then (C^T=-C) and Γ\(_a^T C=-C\Gamma_a) for every (a). The invariant spinor bilinear form is therefore alternating, and its adjoint obeys
\[
\Gamma_A^{\sharp}=(-1)^{j(j+1)/2}\Gamma_A \quad (|A|=j).
\]
Swapping the two spinors in the bilinear tensor (B(x,\Gamma_Ay)) contributes sign
\[
\epsilon_j=-(-1)^{j(j+1)/2}=(-,+,+,-,-,+),\qquad j=0,\ldots,5.
\]
Consequently, the symmetric/antisymmetric multiplicities of (T_r) are obtained by counting ε\(_j\) for (j\ge r): ((3,3),(3,2),(2,2),(1,2),(1,1),(1,0)). Their dimensions are (16896) and (15872), equal to (32\dim\operatorname{Sym}^2S=32\cdot528) and (32\dim\Lambda^2S=32\cdot496). This matches the candidate and confirms it did not impose Bose support.

## Independent exact computations

`independent_seed_replay.py` uses a separately written bit-mask Pauli convention (P=i^pX^xZ^z); it imports no candidate Python module. Replaying all 1023 nonidentity Clifford words gives the four moments
\[
(1,5,5,10,10),\ (0,2,7,8,14),\ (1,1,1,14,14),\ (0,0,5,10,16),
\]
with each vector summing to 31. Irreducibility gives the full-domain Haar orbit POVM (32|U_g\psi\rangle\langle U_g\psi|dg), and its grade-(k) transfer is (s_k/\binom{11}{k}). Thus the four vectors really give attained canonical-EB comparators, not merely outer support points.

`independent_trace_invariants.py` contracts the reported block matrices with their exact Gram metrics and checks 35 full-space traces against direct Clifford orthogonality. It verifies all five zero first moments, all 25 second moments
\[
\operatorname{Tr}(H_kH_\ell)=\delta_{k\ell}\,2\binom{11}{k}32^3,
\]
and the five cubic moments. The grade-5 cubic is a useful odd-dimensional sign check: three 5-subsets can have symmetric difference equal to all 11 indices because the volume element is scalar in the spin representation. The number of such ordered triples is \(\binom{11}{2}\binom{9}{3}\binom{6}{3}=92400\), giving \(\operatorname{Tr}(H_5^3)=2\cdot92400\cdot32^3=6055526400\). The reported blocks match it exactly. Grades 1 and 3 have zero cubic trace; grades 2 and 4 match the empty-symmetric-difference counts.

`independent_support_replay.py` re-enumerates the support cones from the four seed vectors, without importing the candidate checker. It recovers cone sizes (10,10,9,9) and 17 distinct rays. For every ray it rebuilds (bG-\sum_k\alpha_kB_k) from the supplied exact blocks and checks every principal minor: all 187 block/ray gaps and 629 minors are nonnegative. The isotropic cap 1054 is PSD in all 11 blocks and singular in at least one, independently confirming the stated isotropic top for those blocks.

## Why the lower-support argument is enough

For (w_k=\binom{11}{k}\alpha_k\ge0), a normalized broadcaster Choi state has both output marginals (I/32), and the star expectation is (2\sum_k w_k\lambda_k). The checked star bound therefore gives
\[
w\cdot(2\lambda-\mathbf1)\le\max_i w\cdot\mu^{(i)},
\qquad \mu^{(i)}_k=s^{(i)}_k/\binom{11}{k}.
\]
Positive-normal separation implies (2\lambda-\mathbf1\in\operatorname{conv}\{\mu^{(i)}\}+\mathbb R_-^5). A single convex mixture of the four attained orbit channels then satisfies Ψ ≽ (2\Phi-\mathrm{id}). The full canonical-EB support set is only bounded above elsewhere in the source report; neither this check nor the theorem treats the four seeds as its exact orbit body.

## Scope and costs

Files produced here: `independent_seed_replay.py/.json`, `independent_trace_invariants.py/.json`, `independent_support_replay.py/.json`, and this report. The three replays took under two seconds each in this environment and used exact integer/rational arithmetic. The trace replay and support replay consume the candidate's reduced matrices; they do not certify that every such matrix was correctly extracted from the full representation. That remains the principal audit limitation. The candidate's own extractor does provide the source-to-kernel/action construction, and its ordinary/dual/swap conventions agree with the independent derivations above.

A quick primary-source search found general work on covariant channel compatibility, especially Weyl-covariant compatibility, but it does not settle this Spin(11) statement. I make no novelty or priority claim; an actual priority review remains open. For general context only: [Compatibility of covariant quantum channels with emphasis on Weyl symmetry](https://arxiv.org/abs/1901.06113).
