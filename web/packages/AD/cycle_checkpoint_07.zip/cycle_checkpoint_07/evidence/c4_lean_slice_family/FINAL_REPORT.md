# B1 finite slice-family construction

## Result

`SliceFamily.lean` is a Lean 4.28 kernel-checked B1 component for the N33 affine approximation argument. Given a `SliceOracle` that supplies the lower-dimensional induction outputs, it constructs the finite history of raised-coordinate stages, chooses the descending thresholds against the finitely many earlier slope tolerances, and maps each current stage family into one terminal family while preserving labels. The source has no `sorry`, `admit`, or custom axiom.

The construction handles arbitrary pointwise-positive, potentially discontinuous `E`: its only use of `E` is to take a positive minimum over the finite set of old slopes at each step. The lower-dimensional tolerance is the exact restriction `s ↦ E (liftPoint t e s)` for each coordinate embedding `e`. `SliceInput.approx` keeps arbitrary approximating points unrestricted and uses the weak all-label `Active` relation from `AffineCore`, so ties are included.

## Interface and proof structure

`SliceInput k β b E` packages a nonempty finite lower family with slopes coordinatewise in `[β,b]`, offsets `LittleO β`, and the full lower-dimensional sequential approximation property on that cube. `SliceSystem m k t β b E` supplies such data for every embedding `Fin k ↪ Fin m`, with the restricted tolerance above. Each lifted label uses slope `s` on the embedded coordinates and baseline `t` elsewhere, and offset `d(h) - h^β`; `lifted_bump_littleO_for` proves this is `LittleO t` when `t < β`.

`stageFamily` tags all lower labels over all coordinate embeddings, so it is finite and nonempty and includes every k-coordinate subset. `exists_next_threshold` chooses `β` with `t < β < upper` and `β - t < E r` for every old slope `r`. `exists_stage_history` iterates this from `k=1` up to `m`, yielding descending cuts. The terminal-family lemmas preserve old labels and provide a common embedding of the complete current stage family into the terminal family; `stageIndex` then selects the input label for any fixed embedding.

## Source-contract repair

The first compiled version had a Lean elaboration defect in `SliceInput.approx`: its activity premise wrote `∀ᶠ n in atTop` without opening `Filter`, so Lean introduced an unintended implicit `{atTop : Filter ℕ}` parameter. That kernel-checked declaration did not match the intended eventual-activity interface. The preserved pre-repair file and SHA-256 are recorded in the rational-hostile task's `formalization/repair/FILTER_ATTOP_REPAIR.md`. The current source states `(∀ᶠ n in Filter.atTop, ...)` explicitly. A `#print`/`#check` audit confirms that the public `SliceInput.approx` signature has no arbitrary-filter binder; the inspected public dependent interfaces likewise contain no implicit `Filter` parameter.

The local-slice input remains an explicit premise, not a theorem proved by this file. In particular, no concrete `SliceOracle` has yet been derived here from a base case plus the original induction hypothesis. The global B2 active-label comparison and the final outer finite-cover integration are separate proof obligations, so this file alone does not establish the original arbitrary-`E` theorem. The API correction establishes that the conditional component now has the intended `Filter.atTop` source contract; it does not upgrade this component to the full affine lemma or permanence theorem.

## Verification

From `work/agents/c4_rational_hostile/formalization/project`, run:

```sh
lake env lean /Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-2/work/agents/c4_lean_slice_family/SliceFamily.lean
```

The local Lake package points at the existing Lean 4.28 builtMathlib checkout specified for this task. The command exited successfully after the interface repair. `LEAN_COMPILE.log` records the axiom audit for `exists_next_threshold`, `exists_stage_history`, `exists_complete_stage_family`, and `exists_step_lower_label_embedding_to_terminal`; each depends only on `[propext, Classical.choice, Quot.sound]`. `API_AUDIT.log` contains the fully elaborated public activity premise, fixed to `Filter.atTop`, and repeats the axiom audit. The separate B1 whole-stage embedding theorem is in the same checked source. These compiler and signature checks validate this component's formal interface; they do not establish the downstream induction hypotheses or the full N33 theorem.

## Next gate

Instantiate `SliceOracle` with the actual lower-dimensional N33 theorem and compile the composition against the shared B2 mechanism. Then prove the outer interval-family activity transfer. Until those interfaces are composed and checked, report this result as a conditional proof component, not a full formal proof of N33.
