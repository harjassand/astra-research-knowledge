# c12 driven chemistry: source audit, exact boundary, next decisive gate

## Verdict

No new driven-chemistry capability or theorem is established in this lane. The strongest concrete source is Sreekumar et al.'s 2025 AC-driven sequential partial reduction, which already provides the selectivity mechanism, finite-element model, `k1>k2` evidence, and `ΔE_FOW` heuristic. It is mechanistically distinct from c9's parallel BET commitment gate, but its core result is preempted by its primary source.

The 2026 JACS Floquet follow-up suggests a possible phase-selective reversible reaction-network state. An exact cycle balance shows that the illustrative reversible product edges have zero net product-formation extent over each complete period. Their phase-conditioned inventory can be selective, but a usable harvested yield requires an explicit capture/quench process with its own rates, timing, reagent, and work. At the paper's faster reverse rate of 100 s^-1, an unquenched aliquot loses 10% in about 1.05 ms; that is the scale any retained-inventory claim must beat. This is a precise scope boundary and experimental target, not a claim that the modeled phase state is unreal.

The most consequential unresolved model audit is a 1000-fold volume discrepancy in that 2026 paper: Table 2 lists `4×10^-3 m^3`, while Methods specify `4.0 mL = 4×10^-6 m^3`. Applying the published solver's stated mass-transfer coefficient gives a reservoir-exchange timescale of about 2.31 days versus 199.9 seconds. An independent reconstruction of its ideal square-wave rate matrix produces intermediate-2 yield 2.8–4.3% after 3 h with the tabulated 4-L volume, but 99.97% with the Methods' 4-mL volume; at 3 days the tabulated-volume run produces 49.8–65.4%, while the 4-mL run is 99.22%. The paper itself reports a roughly three-day simulated time to appreciable product against a three-hour experiment. The generic public repository lacks the Figure-5 run input, so the table may be a typo; this is an unresolved inconsistency, not a confirmed code error. The independent script omits smooth waveform edges and capacitance and is a sensitivity reconstruction, not a validated Figure-5 reproduction.

## Exact work completed

- Derived and coded the one-period identity `∫(k+ Ox_i − k− P_i)dt=0` for reversible product edges on a periodic orbit.
- Built a rational harmonic-response counterexample: equal equilibrium constants can yield a phase snapshot branch ratio about `0.0390` while period-mean branch inventories remain exactly equal. It is labeled a clamped-precursor toy, not a reproduction of the paper network.
- Recomputed the published code's bulk-exchange coefficient under both reported volumes; both exact calculations and the toy response are in the runnable script.
- Independently propagated the stated Table 2 first-order model to 3 h and 3 days under both volumes; mass balance was numerically conserved within `2×10^-8`.
- Retrieved the exact local N76 card but did not use it as a premise. The source's event-chain result does not supply a physical-time selectivity claim.
- The independent exact aggregate-thermodynamics no-go is preserved in `children/theory_attack.md`; its rational checker is `children/theory_attack.py`.

## Decisive next step

First establish the actual Figure-5 volume and rerun the pinned Floquet solver at both `4e-3` and `4e-6 m^3`; compare held-out frequency curves and reaction progress in physical time, not only Floquet phase. If the volume mismatch is a typo, test whether the revised model still has the reported sigmoidal frequency response and three-hour trajectory without refitting unrelated kinetic parameters. For the reversible product example, add an independently calibrated irreversible capture step and predict collected material. For the experimental thiophene case, report measured `V(t)`, `I(t)`, cathodic Faradaic charge, material balance, and selectivity at matched conversion and charge, with phase-resolved products and the already-existing base challenge used as a control.

## Durable artifacts

- [Exact proof and experiment/falsifier](proof/floquet_inventory_vs_product_flux.md)
- [Rational/exact audit script](code/floquet_boundary.py)
- [Table-parameter volume sensitivity reconstruction](code/floquet_volume_sensitivity.py)
- [Structured claim ledger](CLAIMS.json)
- [Primary source locators](SOURCES.md)
- [2025 primary-paper PDF/text](sources/sreekumar_jacs_2025.pdf)
- [Pinned public Floquet solver](sources/ac_electrochemistry_repo/)
- [Independent source/control scan](children/primary_search.md)
- [Hostile prior audit of network sensitivity](children/network_prior.md)
- [Aggregate-law identifiability no-go](children/theory_attack.md)
