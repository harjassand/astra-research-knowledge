# c12 driven chemistry source ledger

## Primary sources used

1. **Sreekumar, Beeler, Mal, White & Luo (2025), JACS 147, 26917–26925**, [DOI 10.1021/jacs.5c08873](https://doi.org/10.1021/jacs.5c08873). Full primary text/PDF: [author-hosted PDF](https://luo.chem.utah.edu/_resources/documents/sree_jacs_2025.pdf); [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC12579538/); SI record: [ACS Figshare](https://acs.figshare.com/articles/journal_contribution/Origin_of_Selectivity_in_Alternating_Current-Enabled_Partial_Reduction_of_Hetero_Arenes_A_Case_Study_of_Two_Consecutive_Irreversible_Electrochemical_Steps/29608327), SI DOI `10.1021/jacs.5c08873.s001`.
   - Main paper pp. 2–3, Fig. 1: AC/DC yield comparison, methoxide, and product stability context.
   - Main paper pp. 3–4, Fig. 2: fast-scan CV evidence `k1>k2`; p. 4, Eqs. (1)–(2), Fig. 3: sequential irreversible COMSOL model with phenomenological parameters.
   - Main paper pp. 5–6, Fig. 4: simulated frequency and potential trends; p. 6, Eqs. (5)–(6), Fig. 5: `ΔE_FOW` proxy and 80 mV heuristic.
   - SI §2.1: 0.50 mmol 1, 1.5 mmol iPr2NH, 0.264 mmol Et4NBF4 in 4 mL MeOH; ~2 cm² glassy-carbon area, ~1 mm gap, room-temperature stirring, 3.6 V square wave, 1–50 Hz, fixed 3 h, NMR workup.
   - SI §5: bulk methoxide measured after 10 min; §6: static TBAOMe challenge of authentic 1 and 2 (so a product/base stability control already exists); §8: fitted kinetic parameter discussion; RC analysis in SI Eq. S1/Fig. S5.

2. **Poh, Sreekumar, Luo & Yuen-Zhou (2026), JACS 148, 21776–21786**, [DOI 10.1021/jacs.6c02569](https://doi.org/10.1021/jacs.6c02569), [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC13285001/), [official ACS page](https://pubs.acs.org/doi/10.1021/jacs.6c02569). This is direct primary follow-up and preempts treating the Floquet representation or the reversible two-branch example as an original result here.
   - Main text Eqs. (1)–(13): first-order sequential kinetics and eigenmode decomposition.
   - Main text Eqs. (15)–(20), Fig. 4: illustrative reversible chemical product branches; branch ratio is a phase-resolved Floquet concentration distribution and reaches about 0.2 in the modeled example.
   - Main text Eqs. (21)–(22), Fig. 5, Table 2: irreversible thiophene reduction, frequency model, and listed parameters. Table 2 states `V=4×10^-3 m^3`; Methods state 4.0 mL electrolyte. The inconsistency is unresolved.
   - Main text Methods: 0.50 mmol substrate, 4.0 mL MeOH, two carbon plates, ~2 cm² active area, 3.6 V square wave at 1–60 Hz, fixed 3 h, isolated/worked-up yield.
   - Main text says the bulk Floquet model required about three days to show appreciable intermediate versus the three-hour experiment and suggests measuring reaction progress to refine model rates; it also states the simulated double-layer and surface effects are omitted.

3. **Poh, Sreekumar, Luo & Yuen-Zhou public solver**, [GitHub repository](https://github.com/pohyongrui/ac_electrochemistry), pinned here at commit `9a5c459a7859b238c662d7a4e2e86fee855ea5b2` under `sources/ac_electrochemistry_repo/`. In `objects.py`, the diffusion matrix uses bulk exchange coefficient `A*D/((V-A*x_d)*x_d)`. The checkout has generic solver files but no Figure-5 parameter/result file, so it does not settle whether Table 2's volume is a typo or was used in the published run.

## Supplementary comparative/control sources

- Baran group prior AC partial reduction: [2021 JACS DOI 10.1021/jacs.1c06572](https://doi.org/10.1021/jacs.1c06572) and [2022 JACS DOI 10.1021/jacs.2c02102](https://doi.org/10.1021/jacs.2c02102). These predate the 2025 mechanistic study and show AC partial reduction itself is prior art.
- Sreekumar et al. report `k1>k2`, frequency selectivity, and `ΔE_FOW` heuristic; the exact primary mechanism is not novel to this report. The paper's high-frequency experimental yield drop is attributed to voltage loss from RC charging, which must be included in energy/work accounting.

## Non-use boundary

The exact N76 local card was retrieved to check scope. No N76 result is used as a premise: it concerns an event-chain potential and does not establish physical-time recurrence, selectivity, or this electrochemical mechanism. The c9 parallel BET setpoint was screened as a nearby but distinct model; the sequential 1→2→3 chemistry is not recast as a new parallel-channel theorem.
