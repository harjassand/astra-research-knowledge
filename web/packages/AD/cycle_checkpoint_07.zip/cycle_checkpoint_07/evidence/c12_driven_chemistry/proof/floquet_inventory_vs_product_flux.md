# Periodic product inventory is not sustained product flux

## Source model and question

Poh, Sreekumar, Luo, and Yuen-Zhou (JACS 2026, DOI [10.1021/jacs.6c02569](https://doi.org/10.1021/jacs.6c02569)) model an AC-driven network with two electrochemical branches, `Re ⇌ Ox_i + e`, followed by reversible chemical steps `Ox_i ⇌ P_i`. In their numerical example the chemical rates are `(k+_1,k-_1)=(100,1) s^-1` and `(k+_2,k-_2)=(10,000,100) s^-1`, so both chemical steps have the same equilibrium ratio 100. The reported branch ratio is the instantaneous concentration ratio `(Ox_2+P_2)/(Ox_1+P_1)` on a periodic orbit; it reaches about 0.2 under some AC conditions, whereas every DC potential gives 1 in that parameterized symmetric electrochemical model. The paper does not experimentally implement this illustrative reversible-product network.

The exact boundary below separates a phase-conditioned inventory from a sustained isolated-product flux.

## Exact cycle-balance lemma

Suppose `P_i` participates only in the reversible edge `Ox_i ⇌ P_i`, with forward and reverse rates `k+_i Ox_i` and `k-_i P_i`. On any `T`-periodic solution,

```text
P_i(T) - P_i(0)
  = integral_0^T [k+_i Ox_i(t) - k-_i P_i(t)] dt
  = 0.
```

Thus **the net chemical production extent of each `P_i` over a full cycle is exactly zero**. This is independent of the AC waveform, electrochemical rates, precursor trajectory, and whether the phase-resolved branch inventory is strongly selective. The product inventory can be nonzero and phase-dependent, but a nonzero net isolated-product flux requires a sink, irreversible trap, or removal step. Once such an intervention is added, the harvested amount is controlled by its rate and timing; it is not determined by the source model's branch ratio alone.

For example, adding a first-order irreversible trap `P_i → T_i` with rate `κ_i P_i` changes the periodic balance to `n(T_i; one period)=κ_i integral_0^T P_i(t)dt`. This output is an integral of the trapped trajectory, not the instantaneous `P_i/Ox_i` ratio. The trap reagent, its `κ_i`, and the phase/clock used to actuate it must be measured and charged.

This is a conservation identity for the stated network, not a new thermodynamic law. It does not say the phase-specific distribution is false. It says that translating that distribution into a synthetic yield requires an explicitly modeled and costed capture/quench protocol.

## Exact phase-lag counterexample

To isolate the measurement issue, prescribe identical precursor histories `x_1(t)=x_2(t)=x_0+a cos(ωt)` to two reversible product edges,

```text
P_i' = u_i x_i(t) - v_i P_i,
u_i/v_i = q = 100,
```

with rates matching the JACS example: `(u_1,v_1)=(100,1) s^-1` and `(u_2,v_2)=(10,000,100) s^-1`. The unique periodic response is

```text
P_i(t) = q x_0
       + q a [v_i^2 cos(ωt) + v_i ω sin(ωt)]/(v_i^2+ω^2).
```

Set `x_0=51/100 M`, `a=1/2 M`, and `ω=1 s^-1`; the prescribed precursor stays positive (`x_min=1/100 M`). At its trough, `t=π/ω`, exact values are

```text
x = 1/100 M,
P_1 = 26 M,
P_2 = 10051/10001 M,
(x+P_2)/(x+P_1) = 112789/2890289 ≈ 0.039023.
```

Across the full period, however, `mean(x)=51/100 M` and `mean(P_1)=mean(P_2)=51 M`, so both mean branch inventories equal `5151/100 M` and their mean ratio is exactly 1. The waveform period is `2π s` (wall-clock exposure); these equations prescribe precursor modulation and do not provide its electrochemical actuator or work for free. A phase-gated collection protocol would additionally need a quench/trap, a calibrated assay, and timing precision. At the trough, the log branch-ratio slope is about `0.469 s^-1`, so even this toy's 10% local relative-ratio tolerance requires sampling within roughly `0.20 s` of the chosen phase. If a sampled aliquot is left unquenched, 90% survival against the reverse chemical edge alone requires a delay below `−ln(0.9)/v_i`: about 105 ms for branch 1 and 1.05 ms for branch 2 at the source's reverse rates. A real capture protocol must acquire and report its own dead time.

This counterexample is intentionally a clamped-precursor transfer stage, not a reproduction of the paper's coupled five-species simulation. The preceding zero-net-edge-flux lemma applies directly to the paper's reversible `Ox_i ⇌ P_i` edges without the clamp assumption.

## A separate model-input consistency check

The 2026 paper's Methods specify a 4.0 mL reaction volume, `V=4×10^-6 m^3`. Its Table 2 lists `V=4×10^-3 m^3`. The authors' public code (`objects.py`, pinned repository commit `9a5c459a7859b238c662d7a4e2e86fee855ea5b2`) implements bulk exchange with

```text
k_bulk = A D / ((V - A x_d) x_d).
```

Using the source's `A=2×10^-4 m^2`, `D=10^-9 m^2 s^-1`, and `x_d=10^-5 m`, the tabulated volume gives `k_bulk≈5.0000×10^-6 s^-1` (`1/k_bulk≈2.31 days`); the Methods volume gives `k_bulk≈5.0025×10^-3 s^-1` (`1/k_bulk≈199.9 s`). The ratio is about 1000.5. This reservoir-scale exchange time is not the full Floquet eigen-time, but it directly controls bulk concentration exchange in the published rate matrix. The paper separately reports that its bulk model needed about three days to show appreciable product versus a three-hour experiment, and suggests rate-constant refinement.

The inconsistency is material, but its cause is **unresolved**: the table could contain a unit typo, or the literal table value could have been used in the computation. The public repository contains the generic solver, not the figure-specific run file or saved input. Do not state that the paper's result is invalid until the authors' actual value is established.

An independent parameter-sensitivity run is included in `code/floquet_volume_sensitivity.py`. It uses the public rate-matrix transport formula, Table 2 kinetic parameters, reduction-only `1→2→3`, the exact tabulated two-level square potential (+0.8 V / −2.8 V), initially unit substrate concentration in surface and bulk, and volume-weighted product amounts. The two constant-potential half-period propagators are matrix exponentials; the period map is powered to the source's three-hour experiment and its stated three-day model horizon. Weighted mass balance is checked to `2×10^-8`. It intentionally omits smooth-edge waveform interpolation, double-layer capacitance, and unmodeled side products; this is a parameter-sensitivity reconstruction, not a validated Figure-5 reproduction.

At 3 h, the Table 2 volume gives intermediate-2 yield 2.83% at 1 Hz and 4.33% at 60 Hz; substituting the Methods volume gives 99.968% at both endpoints, with essentially complete substrate conversion. At 3 days, the Table 2 volume gives 49.79% at 1 Hz and 65.40% at 60 Hz, while the Methods volume gives 99.223% at 1 Hz and 99.223% at 60 Hz. The listed 4-L reservoir therefore creates both the multi-day wall-clock scale and a large frequency-dependent yield profile in this idealized model. This sensitivity makes resolving the source's actual volume input a decisive gate; it does not establish which value was used in the original run or explain remaining experimental side chemistry.

## Decisive experiment and falsifier

For the reversible-branch example, record branch inventories at several AC phases and after averaging over complete cycles; then add a separately calibrated rapid irreversible capture step and measure its product flux. The prediction is: phase-selective inventory may occur without net `P_i` formation over full cycles, while captured yield depends on capture kinetics and phase. Failure of the integrated identity after a full cycle means either the system has not reached a periodic state or an unmodeled product source/sink exists.

For the experimentally demonstrated thiophene reduction, use the 2025 JACS recipe, record true interfacial potential/current, and compare frequency arms at fixed elapsed time, matched substrate conversion, and matched cathodic Faradaic charge. Take phase-resolved aliquots and quantify substrate 1, intermediate 2, tetrahydrothiophene overreduction product, and decomposition products; measure methoxide over time. Fit transport and hazards from independent controls, including the already-published static 1.6 mM TBAOMe product-stability challenge, and predict held-out frequencies. The mechanism is not a sufficient account if the measured pathway-resolved trajectory or material/charge balance misses the preregistered uncertainty interval after measured waveform, conversion, and methoxide exposure are accounted for. Meter `∫V(t)I(t)dt`, passed charge, phase/timing precision, reagent use, and workup; the source's fixed-voltage/fixed-time comparison does not supply an energy or charge-normalized frontier.

## Claim boundary

- **Source reported:** AC-frequency-dependent intermediate yield in the irreversible thiophene reduction; `k1>k2`; a semiquantitative COMSOL model; the `|ΔE_FOW|>80 mV` heuristic; the 2026 Floquet representation and an illustrative reversible network with phase-dependent composition.
- **Exact derivation here:** the zero net cycle flux across each isolated reversible product edge; the harmonic phase-response formula and numeric phase-vs-period counterexample; the transport-coefficient consequence and independent parameter sensitivity of the table/Methods volume discrepancy.
- **Not established:** a new catalytic mechanism, a general selectivity law, a validated harvested yield from the reversible Floquet example, energy superiority, external novelty/priority, or whether Table 2's volume is a typo or the actual model input.
