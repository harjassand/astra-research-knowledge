# c12 theory attack: aggregate thermodynamics cannot determine product selectivity

## Verdict

The attack yields an exact **no-go for inferring or certifying product selectivity from cycle affinity, expected chemical work, total physical traffic, finite observation time, and total catalyst count alone**. In a two-product reversible catalytic module satisfying local detailed balance (LDB), the target share can be any prescribed θ in (0,1) while the *entire aggregate finite-horizon law* of total forward events, total reverse events, total net product, total chemical work, and event times stays identical. Only the unresolved allocation of kinetic prefactors between channels changes. Consequently every estimator using only these aggregate observations has zero information about θ: pairwise KL divergence is exactly zero, equal-prior testing between θ=0.1 and θ=0.9 has error 1/2, and minimax absolute-error risk over θ in [0,1] is exactly 1/2. Channel labels (or equivalent channel-resolved kinetic assays) are necessary.

This is a conditional model obstruction, not a new dynamic selectivity mechanism or a claim that catalyst variants can be exchanged at zero cost. A change in channel allocation may require different chemistry, catalyst synthesis, or an actuator. Its physical cost is an independent acquired quantity, denoted below by C_cat(θ) or W_act; no LDB identity computes it. The obstruction therefore rules out an affinity-only or aggregate-work-only selectivity theorem, while leaving open a calibrated, channel-resolved control design. That design starts from the acquired kinetic hazards already needed by the c9 commitment/BET setpoint model.

## Exact finite-horizon model

Take one catalyst C, held in one catalytic state, and two reversible chemostatted reaction channels

\[
C+F_i \rightleftharpoons C+P_i,\qquad i=1,2.
\]

Each forward event makes one molecule of P_i and consumes one F_i; the reverse event undoes that conversion. Product labels are resolved. Both reservoir pairs have the same chemical-potential drop

\[
\mu_{F_i}-\mu_{P_i}=A k_B T_{bath}, \qquad A>0.
\]

The channel event intensities, per catalyst, are

\[
r_i^+(t)=\theta_i\Gamma h(t)e^{A/2},\qquad
r_i^-(t)=\theta_i\Gamma h(t)e^{-A/2},
\quad \theta_1=\theta,\quad\theta_2=1-\theta,
\tag{1}
\]

where Gamma has units s^-1, h(t)\ge0 is a specified dimensionless common drive, and 0<theta<1. Every channel obeys LDB exactly:

\[
\log(r_i^+(t)/r_i^-(t))=A.
\]

This is a marked-reaction CTMC: catalyst state is unchanged at an event, while the chemostat/product counters receive the signed stoichiometric jump. For a finite horizon T, define the charged drive exposure

\[
H=\int_0^T h(t)\,dt\quad\text{(seconds)},\qquad z=\Gamma H.
\]

Then the four product-direction counts are independent Poisson variables

\[
N_i^+\sim\operatorname{Pois}(\theta_i z e^{A/2}),\qquad
N_i^-\sim\operatorname{Pois}(\theta_i z e^{-A/2}).
\tag{2}
\]

No event count is supplied as an oracle: (2) charges the finite horizon and gives the random event budget it produces. The total gross forward and reverse counts satisfy

\[
N^+=N_1^++N_2^+\sim\operatorname{Pois}(z e^{A/2}),\quad
N^-=N_1^-+N_2^-\sim\operatorname{Pois}(z e^{-A/2}),
\]

independently of theta. The all-direction event count is Poisson with mean and rate integral

\[
\mathbb E[N_{all}]=z(e^{A/2}+e^{-A/2}).
\tag{3}
\]

The superposition of all events has time-dependent intensity \(\Gamma h(t)(e^{A/2}+e^{-A/2})\), also independent of theta. Therefore its event-time law and every holding-time cost depending only on the shared clock/event stream are identical across theta. At h(t)=1 the inter-event waits are iid exponential with mean \([\Gamma(e^{A/2}+e^{-A/2})]^{-1}\); at h(t)\ne1 they are the corresponding common nonhomogeneous-Poisson waits.

Let \(X_i=N_i^+-N_i^-\) be the signed net product count. The expected channel flux, physical traffic, and net product selectivity are

\[
J_i=\frac{\mathbb E X_i}{H}=\theta_i\Gamma(e^{A/2}-e^{-A/2}),\qquad
\mathcal T_i=\frac{\mathbb E(N_i^++N_i^-)}H=\theta_i\Gamma(e^{A/2}+e^{-A/2}),
\]

\[
S_1:=\frac{J_1}{J_1+J_2}=\frac{\mathbb E X_1}{\mathbb E(X_1+X_2)}=\theta.
\tag{4}
\]

The same fraction is the target share among gross forward product-formation events in expectation. Thus a common periodic modulation h(t) changes total throughput and event timing through H, but it cannot change selectivity: the channel mark probability is theta at every time and direction.

The chemical-work/entropy-flow random variable is

\[
W_{chem}=A k_B T_{bath}(X_1+X_2).
\]

Its *full distribution*, not just its mean, is theta-independent, since its forward and backward count components have the fixed Poisson laws above. In particular,

\[
\mathbb E W_{chem}=A k_B T_{bath}\,z(e^{A/2}-e^{-A/2}),\quad
\operatorname{Var}(W_{chem})=(A k_B T_{bath})^2z(e^{A/2}+e^{-A/2}).
\tag{5}
\]

The identifiability statement is exact. Let Y_T consist of unlabelled forward/reverse event times and signed aggregate work/count. By Poisson superposition, its law P_theta is the same for every theta, so \(D_{KL}(P_{0.1}\Vert P_{0.9})=0\) and \(TV(P_{0.1},P_{0.9})=0\). No test based on Y_T beats equal-prior error 1/2. For any estimator \(\hat\theta(Y_T)\), its distribution is also theta-independent; since \(|x-0|+|x-1|\ge1\), its worst-case expected absolute error over theta in [0,1] is at least 1/2, attained by the constant estimator 1/2. If theta is restricted to (0,1), the same 1/2 is the supremum over the open interval.

If all four channels use the same external clock and label detector, its duration bill C_clock(T,H), expected event-detection bill \(c_{evt}z(e^{A/2}+e^{-A/2})\), and forward-product-label bill \(c_+ze^{A/2}\) are also theta-independent. A real implementation must still acquire those costs, finite-reservoir corrections, label-confusion matrix, and product workup cost. The catalyst count is one in either network. A difference in theta is a difference in channel-specific microscopic prefactors, so any synthesis/reprogramming bill C_cat(theta), actuator work W_act, or catalyst fatigue must be measured separately; it is not declared zero.

## Sharp counterexample with rational rates

Set \(A=\log 4\), so \(e^{A/2}=2\), \(e^{-A/2}=1/2\), take Gamma=1 s^-1, h=1, and T=1 s. Compare theta=1/10 against theta=9/10. In the first system, target/competitor forward rates are (1/5, 9/5) s^-1 and reverse rates are (1/20, 9/20) s^-1. The second system swaps the channel allocations. In both:

- every channel affinity is exactly \(\log 4\);
- total forward and reverse rates are 2 and 1/2 s^-1;
- total net product flux is 3/2 s^-1, and total physical event traffic is 5/2 s^-1;
- one-second expected net chemical work is \((3/2)\log 4\,k_BT_{bath}\);
- total forward, reverse, and all-direction event counts have exactly the same laws, respectively \(\mathrm{Pois}(2)\), \(\mathrm{Pois}(1/2)\), and their independent sum;
- yet target net product selectivity is exactly 10% versus 90%.

The script [theory_attack.py](theory_attack.py) checks these equalities using rational arithmetic; its only non-rational object is the symbolic affinity log 4. This is a finite algebra check of the specified model, not empirical chemistry or an external proof review.

The construction is sharp in theta: for any desired target share s in (0,1), set theta=s. At fixed A, z, total event law, net flux, chemical-work distribution, horizon, shared clock, and catalyst count, (4) attains every interior share. The endpoints are limits theta\to0 or theta\to1 while the total current and total event traffic remain fixed; strictly positive channel rates only give interior shares.

## Precision is an acquired count, not a free margin

If selectivity is inferred from gross forward labels, then conditional on the actually realized forward count m,

\[
N_1^+\mid N^+=m\sim\operatorname{Binom}(m,\theta).
\]

For any proposed absolute precision epsilon, the exact conditional tail is

\[
\Pr(|N_1^+/m-\theta|\ge\epsilon\mid N^+=m)
=\sum_{k:|k/m-\theta|\ge\epsilon}{m\choose k}\theta^k(1-\theta)^{m-k}.
\tag{6}
\]

At finite horizon, m is itself random with \(\mathrm{Pois}(ze^{A/2})\); for example, the exact probability that fewer than m_0 forward marks arrive is

\[
e^{-ze^{A/2}}\sum_{m=0}^{m_0-1}\frac{(ze^{A/2})^m}{m!}.
\tag{7}
\]

If all event labels are measured, the event count is \(N\sim\mathrm{Pois}(\Lambda)\), \(\Lambda=z(e^{A/2}+e^{-A/2})\), and conditional on N the channel labels are iid Bernoulli(theta). The labeled trajectory's Fisher information is exactly

\[
I_T(\theta)=\frac{\Lambda}{\theta(1-\theta)}.
\tag{8}
\]

For theta versus theta-prime, its KL divergence is exactly \(\Lambda D_{KL}(\mathrm{Ber}(\theta)\Vert\mathrm{Ber}(\theta'))\). Thus a precision guarantee requires acquired channel marks and finite exposure; unlabelled total counts give zero KL regardless of time or traffic. Per-event label cost c_label implies expected assay cost \(c_{label}\Lambda\), before detector calibration and any instrument setup.

To turn (6)-(8) into a precision guarantee, an experiment must measure theta, choose epsilon/delta, calibrate label error, and choose H so the Poisson-binomial tail meets the declared failure probability. Neither an event count nor a selectivity margin is supplied for free. For net product counts instead of gross forward events, (2) gives exact independent Skellam laws; their exact likelihood is the corresponding finite-sample comparator. The aggregate work and clock observations alone carry no information about theta because their likelihood is identical under all theta values. Product labels (or channel-specific hazard measurements) are necessary.

## Driven variant and exact scope

Equation (1) already permits an arbitrary common deterministic stimulus h(t), including a periodic on/off or oscillatory schedule. The time-ordered drive does not create a hidden selectivity advantage in this one-state model: the exact time-integrated intensities are just \(\theta_i\Gamma H e^{\pm A/2}\). If one instead uses channel-specific nonnegative stimuli h_i(t), then

\[
S_1(T)=\frac{\theta\int_0^T h_1(t)dt}{\theta\int_0^T h_1(t)dt+(1-\theta)\int_0^T h_2(t)dt}.
\tag{9}
\]

This can steer selectivity, but the steering is exactly an allocation of integrated channel exposure. At fixed \(\sum_i\theta_i\int h_i\), total event exposure, net current, and chemical work are unchanged while (8) can range across (0,1). Any claimed improvement now rests on the differential actuator's measured work, switching time, bandwidth/clock, and acquisition of \(h_i\), plus selectivity readout and catalyst cost. The kinetic allocation is load-bearing; affinity and total work do not price it.

This model is intentionally minimal. It has no intermediate occupancy, conformational memory, substrate depletion, interaction, mass transport, or catalyst-state cycle. Dynamic catalysis with state memory can couple phase to pathway and produce genuine driven selectivity; this counterexample does not rule that out. It establishes the narrower no-go that aggregate LDB thermodynamics and total activity are insufficient statistics for product split. A real candidate must provide and validate a multi-state, channel-resolved rate model before a dynamic-control theorem can be tested.

## Relation to known pump results and c9

Rahav, Horowitz & Jarzynski derive a finite integrated-flow formula and no-pumping theorem for cyclic stochastic systems with thermally activated transitions; the source abstract explicitly describes those results. Their no-pumping domain is closed, instantaneously detailed-balanced state transitions under restricted driving (e.g. fixed barriers or fixed wells). Equations (1)-(5) instead contain nonzero chemostat affinity and self-loop product marks, so there is a static baseline chemical current at fixed parameters. No-pumping cannot bound away that current or identify its branch allocation. Conversely, this marked one-state model is not an RHJ stochastic pump and does not claim a new pump theorem. See the primary source [Rahav, Horowitz & Jarzynski, PRL 101, 140602 (2008)](https://doi.org/10.1103/PhysRevLett.101.140602).

The prior dynamic-catalysis packet in `outputs/research/cycle_checkpoint_06/evidence/chemistry_dynamic_catalysis/CYCLE2_REPORT.md` already reconstructs RHJ's endpoint identity, separates its nonzero-affinity stationary-current term, derives an N-ring drive witness, and leaves product coupling plus barrier-controller, clock, and measurement energy unresolved. This attack closes no such gap: it shows why internal circulation or an affinity/current pair alone does not imply selectivity. Its application value would come only after specifying product-coupled transitions and every competing product cycle.

The c9 record `outputs/research/cycle_checkpoint_06/evidence/c9_reaction_selectivity/PROOF.md` already exposes the required channel-resolved quantities in its static model: capture flux \(\alpha_i\), commitment hazard \(c_i\), and BET hazard \(b_iA\), giving \(v_i=D\alpha_i c_i/(c_i+b_iA)\). Its interval-robust setpoint theorem requires acquired intervals and an ordering of channel commitment scales; it refuses to promote an unknown ordering. The present obstruction supports that acquisition boundary: even equal affinities and matched aggregate work/traffic/time leave theta unidentified until channel-specific kinetics or product labels are measured. It adds no stronger chemistry capability than c9.

For broader dynamic-catalysis context, recent primary sources already treat conformational selection and oscillatory stimulation as routes to rate/selectivity changes. A 2026 ACS Catalysis abstract on dynamic fluctuations says it studies inhibition and selectivity in a discrete-state framework; the publisher page was inaccessible to the web reader (403), so no theorem or quantitative result from it is used here. This confirms only that broad novelty claims require a much deeper prior-art comparison. The current source scan also returned the 2026 Nature Communications paper *A principled basis for nonequilibrium network flows*; the local chemistry reports already identify its equal-traffic bound as established and explicitly warn not to equate physical traffic with unweighted rate-constant sums.

## Exact claim, falsifiers, and next gate

**Conditional theorem / no-go.** For two parallel reversible marked reaction channels with common LDB affinity A>0 and rates (1), for every fixed finite horizon T and common deterministic stimulus h(t), varying theta changes target expected net product selectivity over all of (0,1) while leaving the full aggregate laws of total forward count, total reverse count, aggregate net chemical work, and all event times unchanged. Proof: independent Poisson superposition gives (2); sums erase theta; dividing the channel current in (4) cancels the common positive factor. The same proof gives zero aggregate-data KL and the exact finite-time precision laws (6)-(8). No novelty/priority claim is made for Poisson thinning, LDB, or no-pumping.

**Falsifier inside the model:** any computation that finds theta-dependence in the total forward/reverse event laws or work law, or target net flux share different from theta under common h, contradicts (2)-(5). The attached Fraction script checks the exact A=log4, T=1 rational-rate instance only.

**Experiment-facing decisive test:** in a named catalyst with two labeled products, measure the two forward and reverse channel rates under matched chemostat activities, catalyst abundance, temperature, and drive. Hold the total measured forward/reverse rates fixed across candidate conditions while changing channel allocation. Record total product/work/traffic and event-time histograms as blinded controls. Confirm (or reject) the Poisson model from full count likelihoods, not only mean rates; include detector confusion, finite reservoir depletion, catalyst aging, and non-Markov memory in the likelihood if present. If aggregate observations systematically identify channel allocation after those variables are controlled, this minimal no-go model is rejected as a description and a richer state/memory mechanism is indicated. The required catalyst pair and rate data are not currently supplied, so no physical prediction or design claim follows.

**Cost ledger for a future real comparison:** charge wall time H, all forward/reverse events (3), net chemical-potential work (5), feed/reservoir maintenance, one catalyst's synthesis/assay/fatigue cost, any channel-specific actuator work and switching energy, detector calibration/confusion, and workup costs. Clock/intervention rates and energy, actual channel parameters, and their uncertainty are **UNKNOWN** until measured. The mathematical counterexample matches aggregate stochastic costs but does not assert equal total lifecycle cost when the channel-prefactor intervention differs.
