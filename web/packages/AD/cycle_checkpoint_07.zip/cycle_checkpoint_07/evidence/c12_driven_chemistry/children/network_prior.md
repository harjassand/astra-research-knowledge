# Hostile prior audit: finite-time reversible-edge catalysis

**Verdict.** A generic finite-horizon product-sensitivity formula for multiplying both rate constants of one reversible edge is standard reaction-network sensitivity analysis. The variational/sensitivity ODE and its integral solution already appear in general stoichiometric-network work; stochastic chemical-reaction-network work explicitly treats expected terminal observables at a fixed time. Those formulas do not yield a universal sign theorem. Preserving an equilibrium constant does not determine whether a named product rises or falls at finite time. A defensible new result would therefore need a sharper, assumption-explicit graph/kinetic sign criterion, bound, or experiment beyond the generic derivative.

The empirical phenomenon also has direct prior art. The 2026 *Chemistry Letters* article by Abe and Hiraoka is explicitly an **account** and says it is not introducing a new catalytic phenomenon. It reviews the earlier experimental and modeled *Chem* study in which perrhenate gives a high-yield **metastable, finite-protocol** assembly state. The paper does not claim that this is the equilibrium product distribution.

## Source record and experimental status

1. **Account:** Tsukasa Abe and Shuichi Hiraoka, “Network catalysis: a principle emerging through reaction networks,” *Chemistry Letters* 55(9), upag162 (2026), [doi:10.1093/chemle/upag162](https://doi.org/10.1093/chemle/upag162). Its abstract identifies the paper as an account, and its text expressly says it is not introducing a new catalytic phenomenon but organizing the behavior as a general principle. This makes the label “network catalysis” a framing/terminology claim, not a new theorem or newly discovered phenomenon.

2. **Underlying experiment/model:** Tsukasa Abe, Satoshi Takahashi, Runyu Chai, Hirofumi Sato, and Shuichi Hiraoka, “Catalytic manipulation of reversibility and irreversibility in a supramolecular reaction network to control the self-assembly outcome,” *Chem* 12, 102741 (2026; online 2025), [doi:10.1016/j.chempr.2025.102741](https://doi.org/10.1016/j.chempr.2025.102741). The article reports a M₆L₄ square-based pyramid (SP): ReO₄⁻ changes a minor-product outcome into an almost quantitative one. Its abstract attributes this to stronger acceleration of late-stage elementary reactions and local SP-associated loops that prevent global equilibration, creating a metastable state.

3. **Finite-time qualification:** the 2026 account reports 47% SP for nitrate and 96% for the weaker overall ligand-exchange catalyst ReO₄⁻. It says the reaction is held at 100 °C, the SP yield peaks after about one hour, and the mixture is then cooled to room temperature. It explicitly calls the 96% state a long-lived kinetic trap and a transient metastable state before thermodynamic equilibrium, not an equilibrium distribution. Read the result as a protocol-specific finite-time yield. Do not cite the 96% as a changed equilibrium constant or infinite-time selectivity.

4. **Earlier conceptual/chemical precedent:** Satoshi Takahashi, Tsukasa Abe, Hirofumi Sato, and Shuichi Hiraoka, “Pathway bias and emergence of quasi-irreversibility in reversible reaction networks: Extension of Curtin–Hammett principle,” *Chem* 9 (2023), 2971–2982, [doi:10.1016/j.chempr.2023.06.015](https://doi.org/10.1016/j.chempr.2023.06.015). This is a direct antecedent for pathway bias and transient quasi-irreversibility emerging from networks whose elementary steps are reversible. It is prior art for the broad mechanism, not a proof of the edge-sensitivity result below.

## The generic finite-horizon formula is prior art

Let a deterministic mass-action network be

\[
\dot x=F(x,\alpha)=N v(x,\alpha),\qquad x(0)=x_0,
\]

and let \(\alpha\) multiply both the forward and reverse constants of one reversible edge. If the model is smooth and \(x_0\) is independent of \(\alpha\), the state sensitivity \(S(t)=\partial_\alpha x(t)\) satisfies

\[
\dot S(t)=D_xF(x(t),\alpha)S(t)+\partial_\alpha F(x(t),\alpha),\qquad S(0)=0.
\]

For terminal product observable \(G(x(T))\), its derivative is \(\nabla G(x(T))^\top S(T)\). A cumulative product count is handled by adjoining a state \(Y\) with \(\dot Y=r_{\rm prod}(x,\alpha)\), then differentiating the augmented system. This is standard sensitivity calculus; the model-specific work is identifying valid rate laws and evaluating the resulting derivative.

The most exact network-level prior is Brian P. Ingalls and Herbert M. Sauro, “Sensitivity Analysis of Stoichiometric Networks: An Extension of Metabolic Control Analysis to Non-equilibrium Trajectories,” *Journal of Theoretical Biology* 222 (2003), 23–36, [doi:10.1016/S0022-5193(03)00011-0](https://doi.org/10.1016/S0022-5193(03)00011-0), [author version](https://arxiv.org/abs/physics/0206075). It treats general stoichiometric networks and time-varying trajectories:

- **Eq. (7)** is the differentiated time-varying sensitivity ODE for reduced species coordinates.
- **Eq. (8)** is the variation-of-parameters integral solution.
- **Eqs. (10) and (12)** specialize that integral to parameters affecting reaction rates and then to the full species vector.
- **§5.1, Figs. 2–3** show transient concentration effects that can disappear or reverse in the steady-state response. The paper explicitly cautions that sensitivity varies along the trajectory.

An especially concise older pointer is Tamás Turányi, “Sensitivity analysis of complex kinetic systems: Tools and applications,” *Journal of Mathematical Chemistry* 5 (1990), 203–248, [doi:10.1007/BF01166355](https://doi.org/10.1007/BF01166355), [author PDF](https://garfield.chem.elte.hu/Turanyi/pdf/15_Turanyi_JMC_1990.PDF): **§2.1.3, Eq. (5)** gives \(d(\partial c/\partial k_j)/dt=J(t)(\partial c/\partial k_j)+\partial f(t)/\partial k_j\) and describes this as the direct method. Seigneur, Stephanopoulos, and Carr’s primary 1982 article, “Dynamic sensitivity analysis of chemical reaction systems: A variational method,” *Chemical Engineering Science* 37(6), 845–853, [doi:10.1016/0009-2509(82)80172-3](https://doi.org/10.1016/0009-2509(82)80172-3), already develops time-dependent reaction/objective sensitivity, including arbitrary objectives and perturbations at arbitrary times.

The same objection holds for a stochastic network. Muruhan Rathinam, Patrick W. Sheppard, and Mustafa Khammash, “Efficient computation of parameter sensitivities of discrete stochastic chemical reaction networks,” *Journal of Chemical Physics* 132 (2010), 034103, [doi:10.1063/1.3280166](https://doi.org/10.1063/1.3280166), [full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC2821153/), defines sensitivity of \(\mathbb E[f(X(T,c))]\) to kinetic parameters at a fixed terminal time in **§4 / Eqs. (7)–(9)**; **Eqs. (1)–(4)** give its reaction-channel random-time-change representation. For finite-state CTMCs the same transient-generator perturbation is established in Markov-model sensitivity work, e.g. Ramesh and Trivedi (1993), [doi:10.1145/166955.166998](https://doi.org/10.1145/166955.166998). Thus a finite-time expected product count, concentration, or yield is squarely within standard transient sensitivity analysis.

## Why equilibrium preservation gives no sign criterion

Multiplying both directions by \(\alpha\) leaves that edge’s ratio \(k^+/k^-\) unchanged; under the usual detailed-balance consistency assumptions it preserves the equilibrium point/distribution. It does not fix the sign of a finite-time response.

Counterexample: take only \(A\rightleftarrows B\), with rates \(\alpha u\) and \(\alpha v\), where \(u,v>0\). The equilibrium fraction in B is \(u/(u+v)\) for every \(\alpha\). Starting in A,

\[
P_B(T)=\frac{u}{u+v}\left(1-e^{-\alpha(u+v)T}\right),\quad
\partial_\alpha P_B(T)=uT e^{-\alpha(u+v)T}>0.
\]

Starting in B instead,

\[
P_B(T)=\frac{u}{u+v}+\frac{v}{u+v}e^{-\alpha(u+v)T},\quad
\partial_\alpha P_B(T)=-vT e^{-\alpha(u+v)T}<0.
\]

So an equilibrium-preserving pair acceleration can either raise or lower the target’s finite-time amount depending on the initial state. In a larger network, sign depends on topology, rates, initial composition, target observable, and horizon. A useful theorem must expose those assumptions and prove an additional structural condition; the generic variational formula itself is not such a criterion.

There is one exact baseline control: if **every** reaction rate in an autonomous model is multiplied by the same factor \(\alpha\), then \(F(x,\alpha)=\alpha F_0(x)\) and \(x_\alpha(t)=x_1(\alpha t)\). That changes only the clock. Accelerating one edge pair is not equivalent to a uniform clock rescaling and can redistribute route fluxes.

## Prior dynamic-catalysis literature

M. Alexander Ardagh et al., “Catalytic resonance theory: parallel reaction pathway control,” *Chemical Science* 11 (2020), 3501–3510, [doi:10.1039/C9SC06140A](https://doi.org/10.1039/C9SC06140A), [full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC8152411/), studies oscillatory changes to surface binding energies to steer competing parallel products. **Figures 3–5 and §4** report simulated selectivity control through pathway-rate resonance and surface coverage; the modeled conversion is held at 1%. This is not the same proposition as a passive, equilibrium-preserving static catalyst: it uses externally imposed time-dependent surface dynamics, and any real comparison must charge actuator power/work and switching.

## What a credible matched comparison must report

- **Matched clock and protocol:** identical starting composition, catalyst loading, temperature history, stirring, solvent, counterions/ionic strength, sampling schedule, and quench/cooling. Compare at the same elapsed time and publish the full time course. For this system, report the one-hour, 100 °C peak and cooled yield as protocol endpoints, alongside longer-time behavior; do not compare each catalyst only at its separately selected peak.
- **Global-speed null:** include uniform scaling of all relevant forward and reverse rates, or overlay the uncatalyzed trajectory at a rescaled time. If this explains the result, the catalyst only advances the reaction clock. To support a route-reorganization effect, identify departures from this common time-rescaling baseline.
- **Traffic/progress matching:** report both net flux and gross bidirectional traffic, \(\sum_r\int_0^T(v_r^++v_r^-)\,dt\), resolved by edge where possible. Compare selected conditions at matched integrated gross traffic (and separately at matched conversion/progress), in addition to matched wall-clock time. Equal net product or equal total forward rate alone does not equalize reversible event exposure.
- **Thermodynamic checks:** independently establish the long-time equilibrium distribution and relevant free-energy/association ratios for each condition. Verify that anion addition changes the intended forward/reverse kinetics without changing species stabilization, template binding, ionic-strength effects, or equilibrium constants. A short-time yield trace cannot establish the thermodynamic endpoint.
- **Energy and reagent accounting:** report catalyst/anionic additive amount, preparation/recovery or regeneration burden, and the actual heat supplied for the 100 °C hold and cooling. If a proposed variant dynamically modulates rates, meter actuation and switching energy and compare at matched total supplied energy/chemical work. A passive catalyst is not automatically a free intervention; its synthesis/recovery burden is a distinct acquired cost.
- **Mechanism resolution:** fit one shared, channel-resolved reversible network to all conditions, quantify rate uncertainty, and validate against held-out timepoints or trajectories. End-product measurements alone do not identify which edges were accelerated. If forward/reverse edge rates, occupancy, or event traffic are unavailable, state that limitation as `UNKNOWN` rather than inferring them from yield.

## Novelty boundary

The bounded prior scan is decisive against novelty of (i) the generic finite-horizon product-sensitivity equation, (ii) calling its computation a new edge-acceleration theorem, and (iii) the broad claim that selective kinetic control in reversible reaction networks can yield metastable, high-yield products. It does **not** establish that no restricted graph-specific monotonicity theorem exists. A candidate result remains potentially novel only if it proves a nontrivial sign/bound under explicit structural and kinetic hypotheses, handles a realistic catalyst-induced pair-scaling perturbation rather than a generic parameter derivative, and survives the matched-clock, traffic, equilibrium, and work controls above.
