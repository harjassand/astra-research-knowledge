# Primary-source notes for the C10 audit

## Gopalkrishnan, Miller, and Shiu (2013)

Manoj Gopalkrishnan, Ezra Miller, and Anne Shiu, “A geometric approach to the
Global Attractor Conjecture,” arXiv:1305.5303v2 (2013),
[primary text](https://arxiv.org/html/1305.5303v2).

The source distinguishes the ordinary essential-source set from the strong
condition. Definition 3.9 (lines 287–294) defines `w`-essential reactions by
nonzero projected flux and the ordinary `w`-support as maximal among those
essential-source reactants. Definition 3.14(4) (lines 337–345) says strong
endotacticity also requires, for every direction not orthogonal to the
stoichiometric subspace, at least one inward reaction whose source is
globally maximal among **all** reactants. Thus neutral sources may block the
strong witness, as the C9 two-module fixture says.

Lemma 4.5 of Craciun–Nazarov–Pantea, cited at GMS lines 368–369, states weakly
reversible networks are endotactic. GMS Corollary 3.19 (lines 371–376) says
that if each linkage class of a weakly reversible network has the same
stoichiometric subspace as the whole network, then it is strongly endotactic.
This directly covers the rank-one lift. GMS Theorem 1.1 (lines 97–100) states
strongly endotactic reaction networks are permanent. The source allows
arbitrary real complexes (Remark 3.3, lines 221–233) and frames its result in
mass-action differential inclusions that include power-law systems (abstract
and lines 113–114), so rational nonnegative exponents in this lift are
within the cited setting.

This source establishes the expanded-network consequences, not the
factor-list input representation or a polynomial-time implicit recognizer.

## Liebermeister, Uhlendorf, and Klipp (2010)

Wolfram Liebermeister, Jannis Uhlendorf, and Edda Klipp, “Modular rate laws
for enzymatic reactions: thermodynamics, elasticities and implementation,”
*Bioinformatics* 26(12), 1528–1534 (2010),
[DOI and publisher page](https://doi.org/10.1093/bioinformatics/btq141).

The publisher's primary article describes the common-modular reversible
`A+B <-> 2C` law. Its scaled concentrations are `a'=a/k_A^M`,
`b'=b/k_B^M`, `c'=c/k_C^M`; the denominator is
`1+a'+b'+a'b'+c'+c'+c'^2`. Each denominator term represents an enzyme
binding state, and only `AB00` and `00CC` contribute the two endpoint
numerator terms, while all seven binding states contribute to the
denominator. The fixture combines the repeated `c'` term to `2c'` and sets
the unreported scale and forward/reverse constants to one for a structural
test. This is source-faithful at support/form level, not a fitted model.

The same paper discusses broader modular laws and regulation. Such a rate law
belongs to the audited interface only if each module's two directions
actually have endpoint numerator orders, the same positive shared numerator
factor, and the same positive denominator. Source papers about modular rates
do not establish that every modular or regulated law satisfies those
syntactic constraints.

## Schnell and Mendoza (2000)

Santiago Schnell and Claudio Mendoza, “Enzyme kinetics of multiple
alternative substrates,” *Journal of Mathematical Chemistry* 27, 155–170
(2000), [DOI](https://doi.org/10.1023/A:1019139423811).

Equations (18)–(21) give
`S_i'=S_i/K_i`,
`dS_i'/dt=-kappa_i*S_i'/(1+sum_j S_j')`, and
`kappa_i=kcat_i E0/K_i`; the substrate/product pair totals are conserved in
the stated reduced scheme. Equation (38) gives the smallness condition
`max_i E0/[K_i(1+sum_j S_j'(0))] << 1`. The exact exponential envelope in
the C9 fixture is derived for this reduced ODE. For its chosen synthetic
values, `sum_j S_j'(0)=2` and the three ratios are `1/3`, `1/6`, `2/9`, so
the maximum is `1/3`; the fixture does not establish a good QSSA regime.
There is no comparison to the unreduced ODE and no QSSA error estimate.

## Johnston, Pantea, and Donnell (2014)

“A computational approach to persistence, permanence, and endotacticity of
biochemical reaction systems,” [primary arXiv text](https://arxiv.org/html/1412.4662).
The article presents a mixed-integer linear programming framework for
recognizing endotacticity and strong endotacticity of explicit finite
reaction diagrams (abstract and Sections 4.1–4.3). This is a fair baseline
after the factorized module lift has been materialized. It does not, in the
targeted inspection, provide a representation-size result for an implicit
cross-module denominator product.

## Search boundary

Searches for primary work combining endotactic recognition with rational
positive denominators, modular enzyme laws, and implicit/factorized reaction
diagrams found the above structural results and explicit-diagram MILP work,
but no exact statement of the same explicit-factor-list algorithm. This
bounded search is source cartography, not a proof that the algorithm is
novel. The mathematical novelty claim should remain `UNKNOWN` until a broader
priority review.
