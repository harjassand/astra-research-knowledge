# Independent hard audit: paired reversible rational modules

## Decision

The ordinary endotactic theorem is correct for the exact parser schema. Its
load-bearing condition is genuinely the per-module matched pair: both
directions have the same positive numerator factor and the same positive
denominator, with numerator endpoint exponents equal to the two reaction
complexes. Clearing the product denominator preserves every source ordering
up to one common additive support offset, and each expanded term tuple gives
an opposite-edge pair. This proves all active essential-source maxima point
inward, including every tied top edge. The implementation checks this
syntactically and need not expand the lift.

The one-dimensional strong gate is also correct for the parser's no-self-loop
schema, and is a sufficient test rather than a complete one. In rank one every
lifted linkage class has the same nonzero stoichiometric subspace, so the gate
also follows from Gopalkrishnan–Miller–Shiu Corollary 3.19. At higher rank,
`UNKNOWN` is appropriate. The primary strong-endotactic criterion does use a
global maximum over all reactant sources for its existence clause; neutral
reactions remain in that maximum. The neutral-top fixture correctly blocks
promotion from weak reversibility.

I found two audit qualifications. First, the reported global upper rate bound
`K` is a bound on each labeled term-tuple edge, but not necessarily on a
simple-graph edge formed by merging collisions across modules. Two identical
modules with unit rates return `K=1`, while their common lifted directed edge
has merged coefficient `2`. Use a labeled multigraph convention throughout,
or change the simple-graph bound to `sum_r local_max_r`; the lower bound remains
valid. This affects only the conditional coefficient-box/N33 route, not the
endotactic or rank-one strong proof. Second, the Python executable is not
total on every valid input admitted by its abstract bit-length claim: Python's
default 4,300-decimal-digit integer conversion limit rejects both valid long
rational strings and the decimal rendering of a valid large lift-count
integer. This is an implementation defect, not a counterexample to the
polynomial-time structural theorem.

The novelty boundary is narrow. Weak reversibility implies endotacticity in
standard reaction-network theory, and the strong rank-one conclusion is a
direct instance of the published same-linkage-subspace criterion. The actual
specialized contribution, if independently reviewed, is an expansion-free
certificate for a factor-list encoding of a particular rational-rate
interface. I found no primary source in the targeted search that already
states this exact implicit factor-list recognition algorithm, but the source
pass does not establish priority. It is best described as a useful standard
compilation of the expanded weak-reversibility fact, not a new geometric
principle. Permanence is prior theorem transfer at rank one; the higher-rank
N33 route remains conditional.

## Reconstructed theorem and proof audit

For module `r`, write its channels as

\[
 c_r^+x^{\alpha_r}A_r(x)/Q_r(x):\alpha_r\to\beta_r,
 \qquad
 c_r^-x^{\beta_r}A_r(x)/Q_r(x):\beta_r\to\alpha_r,
\]

where `c_r^+,c_r^->0`, `alpha_r != beta_r`, every listed polynomial factor
has finite explicitly listed support and strictly positive rational
coefficients, numerator exponents and complexes are nonnegative rationals,
and each denominator factor contains a positive constant term. Put
`D=product_s Q_s` and `H_r=product_{s != r} Q_s`. Then `D F` has the
forward/reverse pair multiplied by the *same* positive polynomial `A_r H_r`.

For every direction `w`, support functions add under these positive
polynomial products. Hence

\[
 h_{A_rH_r}(w)=h_{A_r}(w)+h_D(w)-h_{Q_r}(w),
\]

and the lifted forward source score is

\[
 \langle w,\alpha_r\rangle+h_{A_rH_r}(w)
 =h_D(w)+\langle w,\alpha_r\rangle+h_{A_r}(w)-h_{Q_r}(w).
\]

The reverse expression replaces `alpha_r` by `beta_r`. The last two terms
are exactly the numerator-minus-denominator source scores of the original
rational channels. Thus one common offset `h_D(w)` preserves ordering,
maximizers, and ties across the complete channel family. This part is valid
even when different modules have unrelated denominators; using one common
denominator is essential to the shared offset.

Pick any term tuple in `A_r H_r` with total exponent `eta`. It contributes
`alpha_r+eta -> beta_r+eta` and `beta_r+eta -> alpha_r+eta`, both with
positive coefficients. If an active forward edge at the highest active
source score pointed outward, its reverse source would be its target and
would have strictly greater score, contradiction. The reverse argument is
the same. Therefore every active edge at the maximal active-source score is
inward, not merely one selected edge. Neutral pairs have `w dot nu=0` and
are both omitted from this ordinary essential-source maximum. A collision of
term tuples adds positive coefficients, so it cannot delete the reverse
edge or change support heights.

For standard strong endotacticity, if all nonzero `nu_r` span one line `S`,
then every lifted edge remains a translate of a nonzero `nu_r`; each
linkage class contains an edge and has stoichiometric subspace exactly `S`.
All linkage classes therefore have the full stoichiometric subspace. The
published same-subspace corollary implies strong endotacticity. Directly,
for any `w` not orthogonal to `S`, every nonzero module jump is active, and a
global maximum source has a reverse-paired edge pointing inward. The parser
rejects `alpha=beta`, so every valid module has nonzero jump; the rank-zero
branch in `rank_one_or_zero` is unreachable on valid inputs. It does not
create a hidden exception in the theorem.

The rate formulas and proof do not cover a forward-only modifier, different
forward/reverse denominators, signed polynomial factors, arbitrary succinct
arithmetic circuits, or data-acquired factors not included in the input
length. Exact counterexamples below show why the first two matching
requirements cannot simply be dropped.

## Strong-source, tie, and collision checks

The standard strong condition is not the ordinary essential-source test with
the same maximum: it asks for an inward reaction whose reactant is globally
maximal among all reactants. A neutral reaction can set that maximum. For
the two-module fixture `A <-> A+B`, `0 <-> C`, the direction `(1,0,-1)` puts
the neutral `A <-> A+B` sources at score `1` and the active `0 <-> C` sources
below them. The all-source strong witness fails although ordinary
endotacticity follows from the paired proof. This is a correct boundary case.

The independent exact replay compares original rational source scores with
the expanded lift on all 27 directions in `{-1,0,1}^3` for the distinct-
denominator fixture. It verifies support-offset equality, including ties
and neutral directions. This finite test is only a regression check; the
support-function proof handles all real directions.

If the syntax were extended to permit neutral self-loops, the rank-one strong
gate would need to change. For example, add a self-loop `2Y -> 2Y` to the
reversible pair `0 <-> X`. Its stoichiometric rank is one, but at `w=(1,1)`
the self-loop is the unique global-max source and no active inward edge is
there. The present parser rejects self-loops, as required for the claimed
rank-one argument.

## Coefficients and complexity

Let `a_r` be the product of factorwise minimum coefficients in `A_r`, and
`Abar_r` the product of factorwise coefficient sums. For each denominator
factor of module `s`, let `q_s` be its factorwise-minimum product and
`Qbar_s` its product of term-coefficient sums. Each individual tuple edge
from module `r` has coefficient between

\[
 \min(c_r^+,c_r^-) a_r\prod_{s\ne r}q_s
 \quad\text{and}\quad
 \max(c_r^+,c_r^-) Abar_r\prod_{s\ne r}Qbar_s.
\]

All these exact rational products and sums have polynomial bit length in
the explicitly listed coefficient bits. Collisions within one module's
expanded positive polynomial are bounded above by the product of coefficient
sums and below by one included tuple. Across different modules, however, the
program computes global `K=max_r local_max_r`. If a simple reaction diagram
merges coincident same-direction edges across modules, the merged coefficient
can be as high as `sum_r local_max_r`, not `max_r local_max_r`. Two identical
unit-rate modules with denominator `1` already give a merged coefficient
`2` and returned `K=1`. Keep the lifted edges labeled as parallel terms, or
replace the upper bound with the sum if the downstream theorem's rate box is
on merged simple reactions. This fix is polynomial-bit and does not affect
endotacticity.

For input size `L`, the parser receives every factor term, endpoint
coordinate, exponent bit, and rational coefficient bit explicitly. Tuple
counts are products of listed factor support sizes, so their binary
representation length is bounded by the sum of input support-size logarithms
and is polynomial in `L`. The code does not enumerate those tuples or the
common denominator product. A compact 24-module replay has a 402,653,184-edge
lift and the normal executable computes its summary without expansion. The
lift itself remains exponential output; the exact integer count is a compact
summary, not an expanded-edge output.

The advertised encoding is a list of explicit positive polynomial factors,
not a general arithmetic DAG. For example, a squaring circuit with `n` gates
can encode `(1+x)^(2^n)`, whose total coefficient sum is `2^(2^n)` and whose
explicit binary integer representation has exponentially many bits in the
circuit size. A circuit extension might still certify paired-edge
endotacticity if it admits syntactic positivity and constant-term checks,
but it cannot emit the same exact ordinary-binary rational coefficient box
in polynomial output length on this family. No arithmetic-circuit complexity
claim follows from the current explicit-factor compiler.

### Python integer-formatting defect

The schema accepts any positive rational strings and any finite number of
explicit factors, and the complexity claim is in input bit length. Under the
default Python 3.11+ integer conversion limit, a valid 5,001-digit `k_forward`
string fails inside `Fraction`; the CLI reports it as `INVALID_INPUT`. A
separate valid input with 15,000 explicit `(1+x_i)` factors in one module's
denominator has a tuple-count summary involving `2^15000`; `certify` reaches
`str(pair_count)` and raises `ValueError: Exceeds the limit (4300 digits) for
integer string conversion`. The same limitation can affect output rational
strings. This is easy to fix by making the input/output conversion policy
explicit (`sys.set_int_max_str_digits(0)` after the interface is trusted, or
safe chunked conversion) and adding a regression, but the current executable
does not implement the abstract full-bit-length promise.

## Biological and permanence boundary

The Liebermeister–Uhlendorf–Klipp common-modular example is faithfully
represented at the **support/form** level: its `A+B <-> 2C` numerator has
the two endpoint monomials, and its denominator is
`1+a'+b'+a'b'+c'+c'+c'^2`; combining the duplicate `c'` states produces the
fixture's coefficient `2 c'`. The fixture's `k_forward=k_reverse=1` and
unit scaling are synthetic regression placeholders. They are not reported
experimental constants or a fitted model. The primary source's rate also
has an enzyme-level prefactor and scaled concentrations, here absorbed/set
to one for the structural fixture. This supports a legal instance of the
schema, not a claim that every modular law/regulator is accepted.

The Schnell–Mendoza reduced alternative-substrate law is faithfully compiled
from its source equations: `S_i'=S_i/K_i`,
`dS_i'/dt=-kappa_i S_i'/(1+sum_j S_j')`, and
`kappa_i=kcat_i E0/K_i`. In original concentrations it is
`dS_i/dt=-(kcat_i E0/K_i)S_i/Q`, with
`Q=1+sum_j S_j/K_j`; each pair total `S_i+P_i` is conserved. The reported
upper exponential envelope follows directly from
`Q <= 1+sum_i(S_i(0)+P_i(0))/K_i` and Gronwall. This exactly analyzes the
stated reduced ODE, not the unreduced enzyme-complex kinetics. For the
synthetic fixture, the source's Eq. 38 QSSA ratios are `1/3`, `1/6`, and
`2/9`; their maximum `1/3` does not demonstrate the required `<<1` regime.
The package correctly disclaims an approximation-error guarantee and
reports no measured parameters.

For rank one, published strong-endotactic permanence applies to the finite
lift (the primary theorem permits real complexes/power-law systems). If
`G=D F`, a trajectory `y(s)` of `G` gives the original time
`t(s)=integral_0^s D(y(u)) du`; differentiating yields
`dy/dt=G(y)/D(y)=F(y)`. Every denominator factor has a positive constant
term and nonnegative exponents, so `D(x)` has a uniform positive lower bound
on the nonnegative orthant. Therefore `t(s)` tends to infinity whenever
`s` does; on the eventual compact positive set it also has a finite upper
bound, and the orbit remains the same. This preserves global continuation
and the eventual compact positive set. The N33 all-endotactic higher-rank
permanence claim remains internal/conditional. Its use additionally needs a
correct uniform coefficient box for whichever edge-merging convention it
uses.

## Prior-art assessment

Published CRNT supplies the central structural implications: every weakly
reversible finite network is endotactic, and GMS Corollary 3.19 says a
weakly-reversible network whose linkage classes all have the same full
stoichiometric subspace is strongly endotactic. The compiler's paired
argument and rank-one corollary are direct proofs/specializations of these
facts. Johnston–Pantea–Donnell give MILP recognition for explicit finite
reaction diagrams. The primary enzyme paper supplies the CM mechanism and
binding-polynomial model, but not implicit endotactic recognition. A targeted
search did not locate a primary publication for precisely this explicit-
factor-list, distinct-module-denominator algorithm; absence in this search
is not a priority result.

Consequently, the strongest defensible claim is a specialized
polynomial-input-time compilation/certificate that avoids a potentially
exponential positive-denominator lift for one natural reversible kinetic
interface. It is practically useful and mathematically correct under the
schema, but the universal fact after expansion is standard. There is no
scientific acquisition capability, parameter fitting, experimental
validation, formal proof-assistant validation, external theorem review, or
novelty clearance in this evidence package.

## Validation performed

I reran `replay_canonical.py` and `py_compile`; both passed. The replay
confirmed the CM support/form fixture, activation factor case, 27 exact
source-height directions for distinct denominators, the exact weak-but-not-
strong witness, the 24-module count, and the Schnell–Mendoza decay bounds.
I also independently checked the two counterexamples and the merged-edge
rate-box collision with exact integer/rational arithmetic. Those are finite
checks; the source-offset and paired-edge arguments above are the proof.

See `CLAIMS.json`, `PRIMARY_SOURCES.md`, and `VALIDATION.md` for the scoped
claim status, source anchors, and compact reproductions.
