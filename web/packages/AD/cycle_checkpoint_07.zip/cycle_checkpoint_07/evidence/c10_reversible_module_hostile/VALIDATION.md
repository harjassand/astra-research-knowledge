# C10 audit validation and counterexamples

## Commands independently rerun

```text
python3 work/agents/cycle9_canonical_kinetics/replay_canonical.py
python3 -m py_compile work/agents/cycle9_canonical_kinetics/recognize_reversible_modules.py work/agents/cycle9_canonical_kinetics/replay_canonical.py
```

Both completed successfully. The replay output includes the 24-module
402,653,184-edge count, CM support fixture, activation factor, 27 directions
for distinct-denominator support-offset identities, neutral-top strong
counterexample, and Schnell–Mendoza reduced-model decay check.

## Exact matching-condition counterexamples

These are counterexamples to broadening the audited theorem beyond its
matched per-module factors; they are not valid inputs to the paired-schema
parser.

### Different forward/reverse numerator modifiers

Take endpoint pair `0 <-> X` with unit denominator. Let the forward channel
be `x^2` multiplying the `0 -> X` jump and the reverse channel be `x`
multiplying the `X -> 0` jump. In its expanded source diagram the edges are
`2X -> 3X` and `X -> 0`. At direction `w=1`, both are active, the maximal
active source is `2X`, and its only edge points outward. Thus the network is
not endotactic. A common matched shift would add the same `eta` to both
endpoints; these unequal modifiers do not.

### Different forward/reverse denominators

Take `0 -> X` at rate `1` and `X -> 0` at rate `x/(1+x)`. Clearing the
common denominator `1+x` gives edges `0 -> X`, `X -> 2X`, and `X -> 0`.
For `w=1`, the top active source `X` has the outward edge `X -> 2X`, so the
ordinary endotactic condition fails. The pair shares no common denominator,
and multiplying one module in both directions by the same `H_r` cannot
produce opposite pairs.

## Merged coefficient-box check

Two identical modules with `0 <-> X`, `k_forward=k_reverse=1`, and the
constant denominator `Q=1` produce two labeled copies of each directed
reaction after denominator clearing. The executable returns `K=1`. If the
reaction graph merges equal source-target pairs, the coefficient is `2`.
The per-module tuple box is sound; a simple-graph global upper bound needs
the sum over modules or an explicit multigraph convention.

## Self-loop extension check

The valid schema forbids equal endpoints. If it were extended to permit the
self-loop `2Y -> 2Y` alongside `0 <-> X`, then `rank_one_or_zero` would pass
the rank-one gate, but at `w=(1,1)` the neutral self-loop is the only
globally maximal source and no active inward edge occurs there. This
confirms that rejection of self-loops is a theorem assumption, not merely a
parser convenience.

## Integer conversion failure reproductions

On the current Python environment (`sys.get_int_max_str_digits()==4300`):

1. A valid input whose positive rational `k_forward` is a decimal string of
   5,001 digits fails in `Fraction(str(raw))` and is converted to
   `INVALID_INPUT` by the CLI.
2. Two valid modules with 15,000 explicit two-term factors `(1+x)` in one
   denominator have exact tuple count `2^15000`; `certify` fails when it
   executes `str(pair_count)` to produce the summary.

These failures are caused by Python's default integer conversion safeguard,
not by exponential lift enumeration. Both decimal input and decimal output
need an explicit policy if the implementation is intended to cover all
input lengths promised by the theorem.
