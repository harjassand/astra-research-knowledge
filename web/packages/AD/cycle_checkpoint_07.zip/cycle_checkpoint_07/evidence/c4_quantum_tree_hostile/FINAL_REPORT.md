# Independent hostile audit: iterated-broadcast tree lift

## Verdict

I found no decisive defect in the main operator-order theorem. Under the stated finite-dimensional interface—Φ is CPTP, unital, Hilbert–Schmidt self-adjoint, and has a supplied two-output CPTP extension with both marginals Φ—the tree, frame, and cone-separation steps give one canonical EB channel Ψ with

\[
 I-\Psi\preceq 2\lceil\log_2(d^2)\rceil (I-\Phi).
\]

This is an internal reconstruction, not external proof review or a novelty result. The result is dimension-dependent and the witness construction can be exponentially large in its output register. I found a repair to the report's compactness wording and a normalization clarification for its likelihood corollary; neither invalidates the main theorem.

## Exact interface and canonical map

Set \(\tau=\operatorname{Tr}/d\) and use \(\langle A,B\rangle_\tau=\tau(A B)\) on Hermitian matrices. For any POVM \(M=(M_z)\), omit zero effects and define

\[
 \Psi_M(X)=\sum_z \frac{\tau(M_zX)}{\tau(M_z)}M_z.
\]

All normalizations check against the ordinary channel trace. The usual measure-and-prepare form is \(\sum_z\operatorname{Tr}(M_zX)\,M_z/\operatorname{Tr}(M_z)\), exactly the same expression. Thus it is CP and EB; \(\operatorname{Tr}\Psi_M(X)=\sum_z\operatorname{Tr}(M_zX)=\operatorname{Tr}X\); and \(\Psi_M(I)=\sum_zM_z=I\). It is Hilbert–Schmidt self-adjoint, and its quadratic form is

\[
 \langle A,\Psi_M(A)\rangle_\tau=
 \sum_z \frac{\tau(M_zA)^2}{\tau(M_z)}\ge 0.
\]

So every such \(\Psi_M\) is also a positive semidefinite HS operator. The formula does not accidentally introduce a factor of \(d\): the prepared conventional density is \(M_z/\operatorname{Tr}M_z\), not \(M_z/\tau(M_z)\) viewed as a conventional density.

## Tree and simultaneous score inequality

If the supplied extension is not swap-invariant, replace it by its average with its output swap. Both marginals remain exactly \(\Phi\). Let \(T_j\) be the depth-\(j\) binary tree channel. Applying the extension to every current leaf makes each child marginal \(\Phi\) composed after its parent's marginal. Induction therefore gives every leaf marginal \(\Phi^j\), even though the leaves can be correlated. At depth \(m=\lceil\log_2(d^2)\rceil\), this gives \(K=2^m\) receivers.

For a Hermitian observable \(A=\sum_y a_yP_y\), measure its spectral PVM on one receiver. The induced input POVM has effects \(E_y=(\Phi^m)^*(P_y)=\Phi^m(P_y)\), where the final equality uses HS self-adjointness. Since \(\Phi^m\) is trace-preserving, \(p_y:=\tau(E_y)=\tau(P_y)>0\) for every nonzero spectral projector. Direct expansion gives

\[
\begin{aligned}
 \sum_y\frac{\tau(E_yA)^2}{p_y}
 -\left(2\langle A,\Phi^m(A)\rangle_\tau-\|A\|_{2,\tau}^2\right)
 &=\sum_y\frac{(\tau(E_yA)-a_yp_y)^2}{p_y}\ge0.
\end{aligned}
\]

Here \(\sum_y a_y\tau(E_yA)=\tau(A\Phi^m(A))\) and \(\sum_y a_y^2p_y=\tau(A^2)\). This includes traceful \(A\), in particular the identity direction.

For any list \(A_1,\ldots,A_r\), with \(r\le K\), measure \(A_i\)'s spectral PVM on receiver \(i\) and identity on unused receivers. The product PVM pulled back through \(T_m\) is one input POVM \(M\). For each \(i\), the marginal PVM on receiver \(i\) is a coarse-graining of \(M\). If \(E_y=\sum_{z\in C_y}M_z\), weighted Cauchy–Schwarz gives

\[
 \sum_z\frac{\tau(M_zA_i)^2}{\tau(M_z)}
 \ge \sum_y\frac{\tau(E_yA_i)^2}{\tau(E_y)}.
\]

Thus this *one* canonical map satisfies the score inequality simultaneously for every member of the list. No orthogonality of the \(A_i\) is needed. For an arbitrary positive HS operator \(Q\), use its spectral decomposition \(Q=\sum_{i=1}^r w_i|A_i\rangle\langle A_i|\), with orthonormal Hermitian \(A_i\), positive eigenvalues \(w_i\), and \(r\le d^2\). Weighting and summing the simultaneous inequalities gives a single measurement \(M_Q\) such that

\[
 \operatorname{Tr}_{HS} Q\bigl(\Psi_{M_Q}-(2\Phi^m-I)\bigr)\ge0.
\]

Arbitrary positive frame weights are therefore covered; the decomposition can always be chosen orthogonal, but the construction itself works for a nonorthogonal frame too.

## Spectral inequality and order direction

For Hermitian \(A\), Kadison–Schwarz and trace preservation give

\[
 \|\Phi(A)\|_{2,\tau}^2\le \tau(\Phi(A^2))=\|A\|_{2,\tau}^2.
\]

HS self-adjointness makes the spectrum real, so \(\sigma(\Phi)\subset[-1,1]\). With \(m\ge2\) for every \(d\ge2\), each eigenvalue obeys \(\lambda^m\ge1-m(1-\lambda)\): Bernoulli's inequality handles \(0\le\lambda\le1\), while for \(-1\le\lambda<0\) the right side is at most \(1-m\le-1\) and \(\lambda^m\ge-1\). Hence

\[
 \Phi^m\succeq I-m(I-\Phi),\qquad
 2\Phi^m-I\succeq I-2m(I-\Phi).
\]

Combining with the frame inequality yields, for every \(Q\succeq0\), some canonical measurement channel with

\[
 \operatorname{Tr}_{HS}Q\bigl(\Psi_M-[I-2m(I-\Phi)]\bigr)\ge0.
\]

The order sign is consistent: the target is \(\Psi\succeq I-2m(I-\Phi)\), equivalent to the reported \(I-\Psi\preceq2m(I-\Phi)\). Since \(I-\Phi\succeq0\), the right side is positive semidefinite.

## Compactness and the separation step

The separating argument is sound once compactness is made explicit. The report's phrase “rank-one refinement ... give a finite-outcome representative” should not be read as saying refinement preserves the same map. It generally changes the map. For example, the one-effect POVM \(\{I\}\) gives \(\Psi(X)=\tau(X)I\); refining it to a rank-one projective measurement gives dephasing, not that depolarizing map.

The needed repair is favorable: spectral refinement \(M_z=\sum_jR_{zj}\) gives a canonical rank-one-outcome channel \(\widetilde\Psi\) with \(\widetilde\Psi\succeq\Psi_M\) as HS operators. For every Hermitian \(A\), this is exactly weighted Cauchy–Schwarz applied within each outcome block. Thus each support inequality above still holds for a rank-one canonical channel.

Now let \(\mathcal P_1=\{\rho\succeq0:\operatorname{rank}\rho=1,\ \tau(\rho)=1\}\), a compact set. A rank-one POVM can be written \(M_z=t_z\rho_z\), where \(t_z=\tau(M_z)\), \(\sum_zt_z=1\), and \(\sum_zt_z\rho_z=I\). Its HS operator is \(\Psi_M=\sum_zt_z|\rho_z\rangle\langle\rho_z|\). Probability measures on \(\mathcal P_1\) with barycenter \(I\) form a compact convex set in the weak topology; their second-moment image \(\mathcal C_1\) is compact and convex. In finite dimensions, Carathéodory applied to \(\rho\mapsto(\rho,|\rho\rangle\langle\rho|)\) shows each such first/second moment pair has a finite atomic representative, hence an actual finite rank-one POVM. This gives exactly the compact convex channel set needed, without claiming that refinement preserves the original map.

Let \(B=I-2m(I-\Phi)\) and \(\mathcal K\) be the PSD cone of real self-adjoint operators on the Hermitian HS space. The support condition says \(\sup_{C\in\mathcal C_1}\langle Q,C-B\rangle_{HS}\ge0\) for every \(Q\in\mathcal K\). If \(\mathcal C_1\) were disjoint from \(B+\mathcal K\), strong separation of the compact convex set from the closed convex set would give a functional \(Q\) with

\[
 \sup_{C\in\mathcal C_1}\langle Q,C\rangle_{HS}
 <\inf_{Y\in B+\mathcal K}\langle Q,Y\rangle_{HS}.
\]

The infimum is finite only if \(Q\in\mathcal K^*=\mathcal K\); then it equals \(\langle Q,B\rangle_{HS}\), contradicting the support condition. Therefore one \(\Psi\in\mathcal C_1\) satisfies \(\Psi-B\succeq0\), proving the asserted comparator. This even gives a rank-one-outcome comparator, although the tree's raw POVM need not have rank-one effects.

The identity/trace eigendirection is included throughout. Since \(\Phi(I)=I\), the right side vanishes on \(I\), and any resulting comparator fixes \(I\) by unitality. More generally, the order forces the comparator to fix every \(+1\) eigenoperator of \(\Phi\): its quadratic form there is at least the squared norm, while the HS contraction bound gives the reverse inequality.

## Likelihood corollary: normalization repair

For state-valued likelihoods one must state \(H=H^*\), \(\tau(H)=0\), and \(\|H\|_\infty\le\theta<1\); then \(\rho_H=(I+H)/d\) is a density matrix. Let \(r=\sup_H\|\Phi(H)-H\|_{1,\tau}\). The order and canonical positivity give, with \(D=I-\Psi\), \(D^2\preceq D\), and hence

\[
 \|\Psi(H)-H\|_{2,\tau}^2
 \le \langle H,(I-\Psi)H\rangle_\tau
 \le 2m\langle H,(I-\Phi)H\rangle_\tau
 \le 2m\theta r.
\]

The last step is Hölder applied to \(\tau(H(H-\Phi(H)))\), which is nonnegative by \(I-\Phi\succeq0\). Since \(\|X\|_{1,\tau}\le\|X\|_{2,\tau}\), the conventional physical trace distance obeys

\[
 \frac12\|\Psi(\rho_H)-\rho_H\|_1
 =\frac12\|\Psi(H)-H\|_{1,\tau}
 \le \sqrt{m\theta r/2}.
\]

The original report writes \(\|\Psi(\rho_H)-\rho_H\|_{1,\tau}\) instead. That is a normalized trace norm of a trace-one-scale matrix, so it is smaller than the conventional norm by another factor \(d\); the stated upper bound remains valid but is loose by \(d\). If “half-trace error” means the usual quantum trace distance, replace that norm by \(\|\cdot\|_1\). The corollary remains dimension-dependent and does not turn bounded Holevo information alone into an EB reconstruction theorem.

## Resource and evidence boundary

For full HS dimension \(d^2\), \(K=2^m<2d^2\) receivers and \(K-1<2d^2\) broadcaster invocations suffice. The raw product measurement can have up to \(d^K\) outcomes. The compactness/Carathéodory step gives finite existence, not an efficient algorithm to find the comparator. The argument assumes exact finite-dimensional channels and exact operations; it does not charge representation precision or supply a physical implementation. No numerical test was needed to audit these finite-dimensional identities. I did not consult external sources; prior-art novelty remains UNKNOWN.

## Claim ledger

- Main theorem: internally reconstructed under the exact supplied-broadcaster interface; no counterexample found; external correctness and novelty remain open.
- Likelihood consequence: valid with the stated normalization repair and \(\tau(H)=0\); dimension-dependent.
- Wording defect: rank-one refinement is a domination step, not an equality-preserving representation step. The moment-set argument repairs compactness and supports the separation proof.
