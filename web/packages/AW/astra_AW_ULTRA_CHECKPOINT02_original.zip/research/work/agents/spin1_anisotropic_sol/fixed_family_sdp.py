"""Frozen spin-one family; reduced legal broadcaster SDP, with exact support QP."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations, permutations
import hashlib, json, platform, time
import numpy as np
import sympy as sy
import cvxpy as cp

OUT = Path(__file__).resolve().parent

def e(a,b,c):
    x=np.zeros(27); x[9*a+3*b+c]=1; return x

def basis():
    blocks=[]; names=[]
    for i in range(3):
        j,k=[u for u in range(3) if u!=i]
        blocks.append(np.column_stack([e(i,i,i),e(i,j,j),(e(j,i,j)+e(j,j,i))/np.sqrt(2),e(i,k,k),(e(k,i,k)+e(k,k,i))/np.sqrt(2)]))
        names.append(f"parity{i+1}_BCplus")
        blocks.append(np.column_stack([(e(j,i,j)-e(j,j,i))/np.sqrt(2),(e(k,i,k)-e(k,k,i))/np.sqrt(2)]))
        names.append(f"parity{i+1}_BCminus")
    blocks.append(np.column_stack([(e(i,(i+1)%3,(i+2)%3)+e(i,(i+2)%3,(i+1)%3))/np.sqrt(2) for i in range(3)]))
    names.append("odd_BCplus")
    blocks.append(np.column_stack([(e(i,(i+1)%3,(i+2)%3)-e(i,(i+2)%3,(i+1)%3))/np.sqrt(2) for i in range(3)]))
    names.append("odd_BCminus")
    U=np.column_stack(blocks)
    assert np.linalg.norm(U.T@U-np.eye(27))<1e-14
    return blocks,names

def spin_matrices():
    js=[]
    for i in range(3):
        x=np.zeros((3,3),complex)
        for a,b in permutations(range(3),2):
            if len({i,a,b})==3:
                inv=sum(u>v for p,u in enumerate((i,a,b)) for v in (i,a,b)[p+1:])
                x[a,b]=-1j*(-1)**inv
        js.append(x)
    assert all(np.linalg.norm(x-x.conj().T)==0 for x in js)
    return js

def support(a):
    # A z >= b, with active-row KKT z=A_active.T*lambda, lambda>=0.
    A=sy.Matrix([[0,1,1],[1,0,1],[1,1,0],[1,0,0],[0,1,0],[0,0,1]])
    b=sy.Matrix([2*sy.Rational(x.numerator,x.denominator) for x in a]+[0,0,0])
    candidates=[]
    for count in range(4):
        for ids in combinations(range(6),count):
            if not count:
                z=sy.zeros(3,1); lam=sy.zeros(0,1)
            else:
                Aa=A[list(ids),:]; bb=b[list(ids),:]
                if (Aa*Aa.T).det()==0: continue
                lam=(Aa*Aa.T).inv()*bb; z=Aa.T*lam
            if all(x>=0 for x in lam) and all(x>=0 for x in A*z-b):
                k=(z.T*z)[0]/3
                candidates.append((k,z,ids,lam))
    k,z,ids,lam=min(candidates,key=lambda x:x[0])
    return {"k_exact":str(k),"k":float(k),"z_exact":[str(x) for x in z],"z":np.array(z,float).reshape(3),"active_rows":list(ids),"multipliers_exact":[str(x) for x in lam]}

def ptrace1(R,reg):
    t=R.reshape((3,)*6)
    if reg==0:return np.einsum("abcdbc->ad",t)
    if reg==1:return np.einsum("abcaec->be",t)
    return np.einsum("abcabf->cf",t)

def validate(R,W):
    swapBC=np.zeros((27,27)); swapAB=np.zeros((9,9))
    for a,b,c in permutations(range(3),3): pass
    for a in range(3):
        for b in range(3):
            swapAB[3*b+a,3*a+b]=1
            for c in range(3):swapBC[9*a+3*c+b,9*a+3*b+c]=1
    AB=np.einsum("abcaec->abde",R.reshape((3,)*6)) if False else np.einsum("abcdec->abde",R.reshape((3,)*6))
    AB=AB.reshape(9,9)
    return {"min_eig":float(np.linalg.eigvalsh(R).min()),"trace":float(np.trace(R)),"marginal_residuals":[float(np.linalg.norm(ptrace1(R,r)-np.eye(3)/3)) for r in range(3)],"BC_swap_residual":float(np.linalg.norm(R-swapBC@R@swapBC.T)),"AB_selfadjoint_residual":float(np.linalg.norm(AB-swapAB@AB@swapAB.T)),"objective_recomputed":float(np.trace(R@W))}

def run():
    blocks,names=basis(); js=spin_matrices(); I=np.eye(3)
    Ws=[np.real(np.kron(j.T,np.kron(j,I))+np.kron(j.T,np.kron(I,j))) for j in js]
    cases=[("isotropic",(F(1),F(1),F(1))),("single",(F(1),F(0),F(0))),("zero",(F(0),F(0),F(0)))]
    cases += [(f"axial_{str(t).replace('/','_')}",(t,F(1),F(1))) for t in [F(0),F(1,2),F(3,4),F(1),F(5,4),F(3,2),F(2)]]
    cases += [(f"triaxial_{str(t).replace('/','_')}",(1+t,F(1),1-t)) for t in [F(1,8),F(1,4),F(1,2)]]
    metadata={"prereg_sha256":hashlib.sha256((OUT/"PREREGISTRATION.txt").read_bytes()).hexdigest(),"python":platform.python_version(),"numpy":np.__version__,"cvxpy":cp.__version__,"sympy":sy.__version__,"solver":"CLARABEL","installed_solvers":cp.installed_solvers(),"blocks":names,"block_dims":[T.shape[1] for T in blocks],"cases":[]}
    for name,a in cases:
        w=np.array([float(x*x) for x in a]); W=sum(wi*Wi for wi,Wi in zip(w,Ws))
        X=[cp.Variable((T.shape[1],T.shape[1]),symmetric=True) for T in blocks]
        R=sum(T@x@T.T for T,x in zip(blocks,X))
        diag=cp.diag(R)
        constraints=[x>>0 for x in X]
        # All constraints below are literal original computational-basis constraints.
        for reg in range(3):
            for i in range(3):
                ids=[9*aa+3*bb+cc for aa in range(3) for bb in range(3) for cc in range(3) if (aa,bb,cc)[reg]==i]
                constraints.append(cp.sum(diag[ids])==1/3)
        for i,j in combinations(range(3),2):
            constraints.append(cp.sum(diag[[9*i+3*j+c for c in range(3)]])==cp.sum(diag[[9*j+3*i+c for c in range(3)]]))
        objective=sum(cp.trace((T.T@W@T)@x) for T,x in zip(blocks,X))
        p=cp.Problem(cp.Maximize(objective),constraints)
        started=time.perf_counter()
        opt=p.solve(solver="CLARABEL",tol_gap_abs=1e-10,tol_gap_rel=1e-10,tol_feas=1e-10,max_iter=300)
        elapsed=time.perf_counter()-started
        Rn=np.array(R.value); sp=support(a); z=sp.pop("z")
        V=2*np.sum(w)/3; threshold=V+sp["k"]
        G=np.diag(z*z); L=sum(wi*(j@j).real for wi,j in zip(w,js))
        D=np.kron(L,np.kron(I,I))+(np.kron(I,np.kron(G,I))+np.kron(I,np.kron(I,G)))/2-W
        output={"name":name,"sqrt_w_exact":[str(x) for x in a],"w_exact":[str(x*x) for x in a],"support":sp,"V_exact":str(F(2,3)*sum(x*x for x in a)),"V":float(V),"threshold":float(threshold),"status":p.status,"opt":float(opt),"gap":float(opt-threshold),"reverse_dual_min_eig":float(np.linalg.eigvalsh(D).min()),"seconds":elapsed,"num_iters":p.solver_stats.num_iters,"validation":validate(Rn,W),"eigenvalues_by_block":[np.linalg.eigvalsh(x.value).tolist() for x in X],"diagonal_constraint_duals":[np.array(c.dual_value).tolist() for c in constraints[len(X):]]}
        np.savez(OUT/(name+".npz"),R=Rn,W=W,D=D,**{f"block_{i}":x.value for i,x in enumerate(X)})
        metadata["cases"].append(output)
        (OUT/"fixed_family_results.json").write_text(json.dumps(metadata,indent=2)+"\n")
        print(json.dumps({k:output[k] for k in ["name","status","opt","threshold","gap","reverse_dual_min_eig","seconds"]}),flush=True)

if __name__=="__main__":run()
