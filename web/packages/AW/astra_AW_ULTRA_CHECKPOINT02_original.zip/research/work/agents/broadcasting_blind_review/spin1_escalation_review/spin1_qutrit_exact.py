"""Exact finite identities for the blind covariant qutrit proof."""
from pathlib import Path
import hashlib
import json
import sympy as s

I = s.eye(3)
kron = s.kronecker_product
J = [s.Matrix(3, 3, lambda j,k: -s.I*s.LeviCivita(i,j,k)) for i in range(3)]
phi = (1+s.sqrt(5))/2
c = s.sqrt(1+phi**2)
axes = [s.Matrix(v)/c for v in [(0,1,phi),(0,1,-phi),(1,phi,0),
                               (1,-phi,0),(phi,0,1),(-phi,0,1)]]
simp = lambda mat: mat.applyfunc(s.simplify)
real = [simp(n*n.T) for n in axes]
circular = []
for n in axes:
    jn = simp(sum((n[i]*J[i] for i in range(3)),s.zeros(3)))
    pn = I-n*n.T
    assert simp(jn*jn-pn) == s.zeros(3)
    for sign in [1,-1]:
        pi = simp((pn+sign*jn)/2)
        assert simp(pi.H-pi) == s.zeros(3) and s.simplify(pi.trace()) == 1
        assert simp(pi*pi-pi) == s.zeros(3)
        circular.append(pi)
assert simp(sum(real,s.zeros(3))/6-I/3) == s.zeros(3)
assert simp(sum(circular,s.zeros(3))/12-I/3) == s.zeros(3)
for i in range(3):
    for j in range(3):
        for k in range(3):
            for l in range(3):
                moment=sum(n[i]*n[j]*n[k]*n[l] for n in axes)/6
                target=s.Rational(int(i==j)*int(k==l)+int(i==k)*int(j==l)
                                  +int(i==l)*int(j==k),15)
                assert s.simplify(moment-target) == 0

def ptr_a(mat):
    return s.Matrix(3,3,lambda b,c: sum(mat[3*i+b,3*i+c] for i in range(3)))

def ptr_b(mat):
    return s.Matrix(3,3,lambda b,c: sum(mat[3*b+i,3*c+i] for i in range(3)))

swap = s.Matrix(9,9,lambda ij,kl: int(ij//3==kl%3 and ij%3==kl//3))
sym = (s.eye(9)+swap)/2
for i in range(3):
    for j in range(3):
        e=s.zeros(3);e[i,j]=1
        gr=simp(sum((pi*(pi*e).trace() for pi in real),s.zeros(3))/2)
        gc=simp(sum((pi*(pi*e).trace() for pi in circular),s.zeros(3))/4)
        assert gr == (e.trace()*I+e+e.T)/5
        assert gc == (3*e-2*e.T+3*e.trace()*I)/10
        out=sym*kron(e,I)*sym/2
        target=s.Rational(5,8)*e+e.trace()*I/8
        assert out.trace()==e.trace()
        assert ptr_a(out)==target==ptr_b(out)

omega_vec=s.Matrix([int(i==j) for i in range(3) for j in range(3)])/s.sqrt(3)
omega=omega_vec*omega_vec.T
a,b=s.symbols('a b',real=True)
choi=(1-b)*s.eye(9)/9+(a+b)*omega/2+(b-a)*swap/6
r0=(1+3*a+5*b)/9;r1=(2+3*a-5*b)/18;r2=(2-3*a+b)/18
assert simp(choi-r0*omega-r1*(s.eye(9)-swap)/2-r2*(sym-omega))==s.zeros(9)

P=kron(omega,I)
Q=s.zeros(27)
for k in range(3):
    v=s.zeros(27,1)
    for i in range(3):
        v[9*i+3*k+i]=1/s.sqrt(3)
    Q+=v*v.T
t=s.symbols('t')
star=sum((kron(ji.T,ji,I)+kron(ji.T,I,ji) for ji in J),s.zeros(27))
starpoly=s.factor(star.charpoly(t).as_expr())
expected=t**3*(t-2)*(t-1)**8*(t+1)**5*(t-3)**3*(t+2)**7
assert s.expand(starpoly-expected)==0
projectorpoly=s.factor((P+Q).charpoly(t).as_expr())
assert s.expand(projectorpoly-t**21*(t-s.Rational(4,3))**3*(t-s.Rational(2,3))**3)==0

out={"status":"PASS","scope":"finite exact formula audits, not theorem certification",
     "pure_endpoint_states":[6,12],"canonical_basis_directions":9,
     "fourth_moment_components":81,"spin_star_polynomial":str(starpoly),
     "two_projector_polynomial":str(projectorpoly),"cloner_matrix_units":9,
     "proof_sha256":hashlib.sha256(Path(__file__).with_name('QUTRIT_THEOREM_FIRST_BASELINE.txt').read_bytes()).hexdigest()}
Path(__file__).with_name('QUTRIT_EXACT_REPLAY.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
