COMMON ENTANGLEMENT-BREAKING COMPARATORS: SCOPED THEOREMS
Local research output,9October2026. Foundational10/10 objective not achieved.

For the channel classes below, one canonical pure-ensemble EB channel Psi
satisfies the sharp quadratic comparison
 tau(A^2)-tau(A Psi(A)) <=2[tau(A^2)-tau(A Phi(A))]
simultaneously for every Hermitian A in the stated domain. tau=Tr/d.
A single comparator is fixed before the observable is selected.

FULL ALGEBRAS
- Every defining-O(d)-covariant unital self-compatible channel, d>=3:
  Phi_ab(X)=tau(X)I+a(X-X^T)/2+b[(X+X^T)/2-tau(X)I].
  orthogonal/PROOF.txt proves a stronger absolute-spectrum domination,
  using two explicit pure-state orbits. Finite signed tensor products,
  mixtures and supplied bistochastic adjoint sandwiches inheritC2.
- Every tensor product of arbitrary unital self-compatible qubit channels,
  including non-selfadjoint channels: tensor/NONSELFADJOINT_MIXED_SPAN_THEOREM.txt.
- The full covariant qutrit special case has a completely explicit21-atom
  comparator in tensor/FULL_QUTRIT_TENSOR_THEOREM.txt. Independent review
  supplies an18-atom alternative. These factors may be mixed with qubits.

RESTRICTED SPANS
The nonselfadjoint tensor theorem also applies to arbitrary supplied
Clifford spans and vector-spin1 spans, allowing leakage outside them and
entangled linear combinations. General qutrit quadrupole directions are
not included unless the full covariant-family hypotheses above hold.
The new proof takes a half mixture of TWO global product ensembles,
constructed from the left and right singular spaces. A retained exact
counterexample shows that naively tensoring valid local symmetric-part
comparators can fail by1/40.

PROOF STATUS AND DEPENDENCIES
Complete internal proofs, independently reconstructed before proof
exposure, with separate exposed audits and exact arithmetic evidence.
The spin-one signed-star step imports the internally audited all-weight
certificate in the adjacent spin1-proof packet. The all-d orthogonal
proof uses elementary contraction-star algebra and does not need that
certificate or an imported Brauer-state classification.
Read orthogonal/CLARIFICATION.txt for the explicit denominator placement
in the scalar tensor formula (a wording clarification only).
Frozen proof texts retain their original pre-review labels; the separate
exposed audits and current STATUS.txt determine the latest review status.
No proof-assistant kernel replay, external expert review, or peer review
is claimed. Historical novelty remains UNKNOWN. PRIOR_ART.txt identifies
published exact extendibility/separability regions; these channel families
and orbit geometries are established antecedents. The specific spectral
comparison/tensor implication is not assigned priority by a bounded search.

REPLAY
Python with assertions enabled and SymPy is sufficient:
  python3 orthogonal/exact_replay.py
  python3 tensor/verify_full_qutrit.py
  python3 tensor/verify_nonselfadjoint.py
The portable qutrit checker uses the adjacent spin1-proof folder for its
supplied-theorem hash; this is a path-only adaptation of the frozen worker
checker, whose arithmetic is unchanged.
Run from this directory, or use full paths. Each script writes its own
replay JSON. They check exact symbolic identities and specified algebraic
witnesses. The quantified theorems also use the analytic proofs, compact
convex separation and tensor arguments; script PASS alone is not a formal
proof of everything. The adjacent spin1-proof offers two standard-library
exact polynomial checkers with no SymPy requirement.

INTERFACE AND LIMITS
Local channels, their legal equal-marginal broadcasters, generators and
factorizations/encodings are supplied. The theorem does not acquire them.
Spin covariance separation is an existence argument, not an efficient
unknown-channel measurement algorithm. Explicit qutrit ensembles cost21
local atoms; general O(d) ensembles have a conservative d^4 existence
bound. Listed global product ensembles can be exponential in factor count.
Dense dimensions, precision, rotations and sandwich maps retain their costs.

The universal finite-C arbitrary-channel/frame theorem remains UNKNOWN.
The most consequential unresolved obligation is a general common-ensemble
rounding or local-dual theorem, or a genuine legal-channel counterexample.
No result has been merged into either source repository or published.
