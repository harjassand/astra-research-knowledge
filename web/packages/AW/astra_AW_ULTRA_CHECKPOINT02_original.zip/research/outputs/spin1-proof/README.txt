SPIN-ONE APPROXIMATE CLASSICALITY: EXACT SCOPED PROOF

For every unital CPTP channel Phi on M3 with a CPTP two-output broadcaster
whose two marginals are Phi, there exists ONE canonical entanglement-breaking
channel Psi satisfying
  tau(A^2)-tau(A Psi(A)) <= 2[tau(A^2)-tau(A Phi(A))]
for every Hermitian A in span_R{I,J1,J2,J3}. Here Ji are the vector spin-one
matrices (Ji)jk=-i epsilon_ijk and tau=Tr/3. Phi need not be self-adjoint
or rotation covariant. The comparator can use at most15 pure states.
Constant2 is sharp. The five quadrupole directions are not covered.
The arbitrary-frame/dimension finite-constant problem remains UNKNOWN.

Read SPIN1_ALL_WEIGHTS_THEOREM.txt for the complete proof, including the
exact tracial ensemble support, four-cone covering, block decomposition,
strict-interior Sylvester argument, boundary limits and separation theorem.
Read POST_EXPOSURE_FULL_AUDIT.txt for independent adversarial reconstruction.
BLIND_FULL_WEIGHTS_BASELINE.txt preserves the reviewer's pre-exposure proof.
ROOT_TRACE_COROLLARY.txt gives the approximate-state consequence and scope.

Two different exact determinant replays need only standard Python:
  python3 verify_coefficients_stdlib.py
  python3 check_full_weights_fraction.py
Use Python with assertions enabled (do not pass -O).
The first regenerates32 optimized certificate polynomials and writes
independent_coefficient_replay.json. The second independently regenerates
all108 leading-minor polynomials of the complete block decomposition.
These are exact rational polynomial identities over entire parameter cones,
not a finite sampling of weights. The proof text supplies the reduction from
the identities to the operator theorem. exact_block_audit.py additionally
requires SymPy; its saved result covers full matrix/sign/permutation and
sharpness identities. The full research archive contains its independent
counterpart and all raw diagnostic data.

Status: internally derived mathematical proof with independent theorem-first
reconstruction and exact arithmetic replay. No proof-assistant kernel replay,
external expert validation, peer review, or historical priority clearance.
A targeted source comparison found close isotropic and single-state
antecedents, which do not by themselves establish the all-weight statement.
No foundational10/10 resolution or efficient channel-acquisition procedure
is claimed. Nothing has been published or merged into the source repositories.
