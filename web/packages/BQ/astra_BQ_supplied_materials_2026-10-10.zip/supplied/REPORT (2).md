# Snapshot-only dynamical identification: construction, comparison, and rejection

**Research date:** 9 October 2026  
**Mission status:** No foundational applied breakthrough established.  
**Scientific status:** Self-contained mathematical derivations and executable numerical checks; historical novelty and independent correctness review not established. No laboratory experiment or consequential real-world benchmark is reported.

## 1. Outcome

The main candidate was a protocol for recovering every entry of an unknown linear stochastic network from stationary snapshots, using bounded, binary-coded noise interventions and added damping. The proposed advantage was robust acquisition of directed interactions, without trajectories, sparsity, a known background diffusion matrix, or a favorable eigenvalue-spacing assumption.

A precise conditional reconstruction theorem survives. Its inverse problem has a dimension-independent lower singular-value bound with logarithmically many noise settings. An exact counterexample rules out one tempting two-setting shortcut. A matrix-free implementation removes the unnecessary fourth-order storage of the small dense reference decoder.

However, a stronger comparison prevents promotion to the requested breakthrough. For a local, fully observed Ornstein–Uhlenbeck model with known isotropic background noise, **recorded randomized mean shifts using one-quarter the added stationary second moment have at least as much Fisher information as an arbitrary positive-semidefinite noise intervention, in every real drift direction simultaneously**. The quarter factor is sharp. This is a local information result, not a claim that the mean-control hardware is equally cheap or universally available.

Raw-snapshot experiments also favored the mean-shift comparator. At 860,000 snapshots for each protocol, the candidate's root-mean-square Frobenius reconstruction error was 0.20038 versus 0.03785 for mean-shift regression. These are synthetic four-variable tests, not biological or engineering validation.

The mathematical constructions remain worth preserving as scoped research results. They do not establish a new foundational practical capability.

## 2. Opportunity screen and research capital

The initial screen considered rare-transition simulation, quantum electronic structure/measurement, and causal inference from destructive snapshots. The snapshot route received the main derivation and implementation effort. Rare-event and quantum opportunities were screened rather than developed into complete competing inventions.

Existing committor-learning work already couples guide estimation with enhanced sampling [P3]. A new sampler would therefore need to improve acquisition of relevant reactive paths, not merely assume a useful guide. The electronic-structure screen included fermionic neural-network states [P4]; no new mechanism for acquiring an accurate fermionic state and establishing a competitive end-to-end advantage was obtained.

Snapshot inference was selected because stationary observations can hide dynamically important directed couplings. Existing work already uses Lyapunov-equation reconstruction [P2] and studies shift-intervention identifiability of linear and restricted nonlinear stochastic models [P1]. Neither covariance inversion itself nor intervention-based identifiability was treated as new.

A later route examined exact deferred simulation of dense Gaussian matrices, motivated in part by the Gaussian-query mechanism in the pinned OpenAI source. The headline space/time reduction was found in **Householder Dice** [P5]. Its O(nT) memory and O(nT²) simulation cost are prior work, not an invention of this investigation. A low-rank-update wrapper was not established as a fundamentally new capability, so no synthetic neural-training speedup was presented as one.

### Pinned repository reads

- Astra: `7c6e44433b245490aad482f93b8f2bbeed34002a`.
- OpenAI math: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

Astra was entered through `00_START_HERE.txt`. Selected routes, the N185 hidden-metastability card, and the N277 Clifford-comparison status/card and original proof text were examined. The latter explicitly distinguishes a finite-matrix construction from physical measurement compilation. The original Clifford proof was inspected as intellectual capital; none of its unverified claims is a premise of the results proved below.

For OpenAI, selected source was read from the low-temperature SK Glauber manuscript, including lines 1–240 of `build/sections/proposal.tex`. The adaptive revelation of fresh Gaussian directions was the useful mechanism; the full manuscript was not independently verified. Its equilibrium-start theorem was not treated as an acquired general-purpose equilibrium sampler. Exact paths and Git blob hashes are recorded in `SOURCE_MANIFEST.json`.

This was selective retrieval, not an audit of either entire repository.

## 3. Candidate's exact interface

Let X take values in R^n. Under experimental setting s, suppose

\[
 dX_t=(A-\gamma I)X_t\,dt+B_0\,dW_t+
             (2\gamma D_s)^{1/2}\,d\widetilde W_t.
\]

The unknown target is the real n-by-n matrix A. The background diffusion Q0=B0 B0^T is unknown but unchanged across settings. The two Brownian drivers are independent. The damping gamma and added diffusion designs D_s are calibrated controls, not estimated by the decoder.

The theorem assumes a supplied, valid bound ||A||_2 ≤ B and gamma ≥ 9B, with gamma>0. This implies stability. Full-state observations are required. Independent, additive, zero-mean measurement noise may have an unknown covariance R, provided R is the same in every setting and independent of the state and interventions.

Let Ω_s denote the observed stationary covariance and Ω_0 the observed baseline covariance without the added diffusion. Define C_s=Ω_s−Ω_0. Linearity of the stationary covariance equation and cancellation of R give

\[
 (A-\gamma I)C_s+C_s(A-\gamma I)^T+2\gamma D_s=0,
\]

or equivalently

\[
 \boxed{AC_s+C_sA^T=2\gamma(C_s-D_s).} \tag{1}
\]

The unknown background covariance is not an input to this equation. The covariance matrices must still be measured: an algebraic cancellation is not a free covariance oracle.

The output is an estimate of all n² entries of A. This is a full-state linear model, not a general gene-regulatory-network theorem, nonlinear causal discovery method, or hidden-state reconstruction result.

## 4. Exact failure of a two-setting shortcut

It is not sufficient to give one forcing matrix a simple spectrum and assume the resulting two covariance equations identify every drift.

Set

\[
 C_0=I_3,\quad C_1=\operatorname{diag}(1,1,2),
\]

\[
 A_0=-5I_3+
 \begin{pmatrix}0&0&1\\0&0&0\\-1&0&0\end{pmatrix},\quad
 J=\begin{pmatrix}0&1&0\\-1&0&0\\0&0&0\end{pmatrix}.
\]

For every real theta, let A_theta=A0+theta J. Its symmetric part is −5I, so it is stable. Both J C0+C0 J^T and J C1+C1 J^T vanish. Consequently all these distinct drifts have the same stationary covariances C0 and C1 under

\[
 Q_0=10I_3,\qquad
 Q_1=\begin{pmatrix}10&0&-1\\0&10&0\\-1&0&20\end{pmatrix}.
\]

Q1 is positive definite and has three distinct eigenvalues: 10 and 15±sqrt(26). Thus the simple spectrum of the forcing is not a universal identification certificate. The ambiguity is exact for all theta, not a small-noise numerical artifact.

`research_gate.py` checks several theta values against independent Lyapunov solves. Maximum numerical covariance replay error was approximately 1.11×10^-15. The proof is the displayed exact algebra, not the finite replay.

## 5. Binary-coded covariance acquisition

### 5.1 Acquiring the code

Assign each coordinate i a sign word h_i in {−1,+1}^m. Require every pair of words to differ in at least delta m positions, with delta ≥ 1/4. For every row h_s, use the two complementary diagonal designs

\[
 D_{s,+}=I+\operatorname{diag}(h_s),\qquad
 D_{s,-}=I-\operatorname{diag}(h_s).
\]

Every design is positive semidefinite, has entries 0 or 2, and has operator norm at most 2. There are 2m noise settings and one baseline.

One explicit acquisition procedure draws all signs independently, checks every pairwise Hamming distance, and rejects a failed code. For

\[
 m=\max\{8,\lceil8\log(n(n-1))\rceil+1\},
\]

Hoeffding's inequality and a union bound show that a draw succeeds with probability greater than 1/2. Thus the expected number of draws is less than two. Each check costs O(n²m); code storage is O(nm). The implementation caps retries at 100 and reports failure rather than assuming success. This bound has conservative constants: the small tests use more settings than variables.

### 5.2 Uniform conditioning theorem

For a collection C=(C_s) with k=2m, define the linear map

\[
 \mathcal L_C(E)=k^{-1/2}(EC_s+C_sE^T)_{s=1}^k,
\]

with the ordinary Frobenius norm on E and the stacked Euclidean norm on the output.

**Theorem 1.** Under the interface in Section 3 and the checked code above,

\[
 \sigma_{\min}(\mathcal L_C)
 \ge 2\sqrt\delta-\frac{4r}{1-r},
 \qquad r=\|A\|_2/\gamma.
\]

In particular, gamma≥9B and delta≥1/4 give

\[
 \boxed{\sigma_{\min}(\mathcal L_C)\ge\tfrac12.} \tag{2}
\]

Hence equation (1) uniquely determines A, without sparsity or eigenvalue-spacing assumptions.

**Proof.** First replace C_s by D_s. Write E=S+K, where S is symmetric and K is skew-symmetric. For a coordinate pair i<j write S_ij=s and K_ij=k. If a code row has signs h_i,h_j, the off-diagonal output entry for the two complementary settings is

\[
 2s\ \pm\big((h_i+h_j)s+(h_j-h_i)k\big).
\]

Averaging its square over the two signs cancels the first cross term. The remaining cross term vanishes because
(h_i+h_j)(h_j−h_i)=h_j²−h_i²=0.
If the relative Hamming distance of these two words is d_ij, the two matrix entries contribute

\[
 (16-8d_{ij})s^2+8d_{ij}k^2
 \ge 8\delta(s^2+k^2).
\]

Their contribution to ||E||_F² is 2(s²+k²). A diagonal entry contributes 8E_ii² to the average output norm. Summing gives

\[
 \|\mathcal L_D(E)\|^2\ge4\delta\|E\|_F^2.
\]

Next, equation (1) gives ||C_s−D_s||_2≤r||C_s||_2. Since ||D_s||_2≤2 and r<1,

\[
 \|C_s\|_2\le\frac2{1-r},\qquad
 \|C_s-D_s\|_2\le\frac{2r}{1-r}.
\]

Therefore

\[
 \|(\mathcal L_C-\mathcal L_D)(E)\|
 \le 2\max_s\|C_s-D_s\|_2\,\|E\|_F
 \le\frac{4r}{1-r}\|E\|_F.
\]

Apply the reverse triangle inequality. At r≤1/9 and delta≥1/4, the lower bound is at least 1−1/2. QED.

### 5.3 A restricted lower bound on the number of settings

The logarithmic count is order-optimal within the following narrow design class: diagonal forcings with all entries in a fixed interval [0,M], RMS normalization over settings, and a uniform positive lower singular-value requirement s0 at A=0.

At A=0, C_s=D_s. Testing a skew matrix supported on a single pair i,j requires

\[
 k^{-1}\sum_{s=1}^k(d_{si}-d_{sj})^2\ge s_0^2.
\]

Partition [0,M] into L=ceil(2M/s0)+1 intervals of width less than s0. Two column words in the same one of the L^k boxes violate the displayed separation. Thus n≤L^k, implying k≥log(n)/log(L). For fixed M and s0 this is Ω(log n).

This is not a lower bound for arbitrary non-diagonal noise, arbitrary dynamic control, recorded mean shifts, or unbounded forcing amplitudes. It is a packing argument, not a claimed new general coding theorem.

## 6. Decoder and error propagation

The decoder minimizes

\[
 \|\mathcal L_{\widehat C}(E)
       -2\gamma k^{-1/2}(\widehat C_s-\widehat D_s)_s\|.
\]

The small reference code explicitly constructs a k n²-by-n² matrix. Its O(k n⁴) storage and O(k n⁶) conventional dense least-squares cost are not hidden. It is capped at n≤24.

`matrix_free_decoder.py` instead evaluates the operator and its adjoint:

\[
 \mathcal L_C^*(R)=k^{-1/2}\sum_s(R_s+R_s^T)C_s.
\]

It uses LSMR, O(k n²) covariance storage and O(k n³) ordinary dense arithmetic per iteration. No n²-by-n² normal matrix is formed. With exact inputs from Theorem 1, sigma_max≤4/(1−r)≤4.5 and sigma_min≥0.5, so the operator condition number is at most 9. Generic Krylov least-squares convergence then has a dimension-independent condition factor; this is an application of standard iterative linear algebra, not a new solver primitive.

### Deterministic perturbation certificate

Suppose actual covariance errors obey

\[
 \max_s\|\widehat C_s-C_s\|_2\le\epsilon,
 \qquad
 \big(k^{-1}\sum_s\|\widehat D_s-D_s\|_F^2\big)^{1/2}\le\xi.
\]

Let r_fit be the displayed least-squares residual at Ahat, and let shat be a rigorous lower bound for sigma_min(L_Chat). When shat>2epsilon,

\[
 \boxed{
 \|\widehat A-A\|_F\le
 \frac{r_{\rm fit}+2\epsilon\|\widehat A-\gamma I\|_F+2\gamma\xi}
 {\widehat s-2\epsilon}.} \tag{3}
\]

Indeed, substituting the two equations leaves a residual consisting of the fitted residual, (Ahat−gamma I) times the covariance error plus its transpose, and the calibrated forcing error. The actual operator's lower singular value is at least shat−2epsilon. This proves (3).

One data-dependent lower bound is

\[
 \widehat s\ge2\sqrt\delta-2\max_s\|\widehat C_s-D_s\|_2
\]

when D_s are exact. Obtaining epsilon and xi is part of measurement and calibration. The numerical singular values in the JSON outputs are not directed-rounding certificates, and no formal finite-bit implementation of (3) is asserted.

## 7. End-to-end acquisition costs and assumptions

The protocol does not create control actuators or independent stationary replicas. Its relevant resources are the ability to impose a common damping term, program n independent noise intensities per setting, maintain a common background, measure all n state coordinates, and obtain sufficiently accurate second moments. Measurement-noise cancellation fails when measurement error is state dependent or changes with interventions.

With N_s independent observations in setting s, reading the data costs Ω(n sum_s N_s), and direct dense covariance accumulation costs O(n² sum_s N_s). Storing the k covariance differences costs O(k n²). The candidate cannot claim an end-to-end complexity based solely on the final linear solve.

There is an explicit way to *charge*, rather than assume away, equilibration when additional physical bounds and resetting are genuinely available. Suppose ||A||_2≤B, ||Q0||_2≤qmax are certified, each replica can be reset to X0=0, and gamma>B. Then

\[
 \|e^{(A-\gamma I)t}\|_2\le e^{-(\gamma-B)t}.
\]

For every coded noise setting, the covariance difference between a sample taken at time T and its stationary limit is at most

\[
 \frac{q_{\max}+4\gamma}{2(\gamma-B)}
 e^{-2(\gamma-B)T}. \tag{4}
\]

Thus a requested covariance bias eta requires at least the explicit burn-in obtained by solving (4)≤eta, with T replaced by zero when the resulting logarithm is negative. The two covariances in a baseline difference can contribute twice this bias. Independent resets/noise realizations, their setup cost, and the total replica time sum_s N_s T must be counted. No procedure in this package acquires the physical norm/diffusion bounds or reset capability.

A deliberately conservative finite-sample accounting can be made without assuming exact covariance access. For a zero-mean Gaussian sample with covariance bounded by V I, an uncentered covariance estimate from N independent samples satisfies

\[
 \mathbb E\|\widehat\Sigma-\Sigma\|_F^2
 =\frac{\operatorname{tr}(\Sigma^2)+(\operatorname{tr}\Sigma)^2}{N}
 \le\frac{n(n+1)V^2}{N}.
\]

Markov's inequality and a union bound over K settings give a simultaneous Frobenius error epsilon0 with probability at least 1−alpha whenever

\[
 N\ge\frac{K n(n+1)V^2}{\alpha\epsilon_0^2}.
\]

This bound is loose and is not claimed optimal. V must include bounded measurement covariance as well as process covariance. Combined with (4), baseline differencing and (3), it makes explicit how a valid but potentially expensive confidence guarantee could be assembled. The raw-sample tests below do not assert this conservative coverage guarantee; they measure empirical error.

Without known envelope bounds, demonstrated control calibration, or a valid independence/reset interface, these costs remain unresolved. In particular, a stationary Gaussian simulator used to validate an inverse formula is not evidence that stationarity was cheaply acquired in a laboratory.

## 8. A sharp local comparison with recorded mean shifts

The following result is stronger than the initial skew-direction comparison. It is derived here from the Gaussian likelihood and checked in `quarter_variance_test.py`. Historical novelty is not established.

### 8.1 Two experiments

Fix gamma>0 and consider the local family

\[
 B_\theta=-\gamma I+\theta E
\]

for an arbitrary real matrix E. For sufficiently small theta this is stable. The known background diffusion covariance is 2gamma I in both experiments. Let Q be any positive-semidefinite matrix and C=I+Q.

**Noise experiment:** Add diffusion covariance 2gamma Q; obtain one independent stationary snapshot. At theta=0 its law is N(0,C).

**Quarter-variance mean experiment:** Independently draw and record Z~N(0,Q). Apply constant force u=gamma Z/2 throughout preparation; observe one independent stationary snapshot and its Z label. At theta=0, X|Z~N(Z/2,I).

At theta=0, the noise experiment adds stationary second moment tr(Q), while the mean experiment adds tr(Q)/4. This compares displacement variance, not physical actuator power, bandwidth, experimental switching cost, or accessibility.

### 8.2 Simultaneous information identity

**Theorem 2.** The scalar Fisher information in every direction E satisfies

\[
 \boxed{
 \mathcal I_{\mathrm{mean},1/4}(E)-\mathcal I_{\mathrm{noise}}(E)
 =\frac1{4\gamma^2}
 \left\|Q^{1/2}C^{-1/2}E C^{1/2}\right\|_F^2\ge0.} \tag{5}
\]

Because this holds for every E, it is a positive-semidefinite comparison of the full n²-parameter local Fisher matrices. No skew-symmetry, diagonalizability of E, or full rank of Q is required.

**Proof.** Differentiating the Lyapunov equations at theta=0 gives

\[
 \dot\Sigma_{\rm noise}=\frac{EC+CE^T}{2\gamma},\qquad
 \dot\Sigma_{\rm base}=\frac{E+E^T}{2\gamma}.
\]

The conditional stationary mean is −B_theta^{-1} gamma Z/2, whose derivative at zero is EZ/(2gamma).

For a Gaussian with covariance V and derivative Vdot, covariance Fisher information is one-half the squared Frobenius norm of V^{-1/2} Vdot V^{-1/2}. The mean score and covariance score are orthogonal: their cross moment is a centered Gaussian third moment. Consequently

\[
 \mathcal I_{\rm noise}(E)
 =\frac1{8\gamma^2}
 \left\|C^{-1/2}(EC+CE^T)C^{-1/2}\right\|_F^2,
\]

\[
 \mathcal I_{\rm mean,1/4}(E)
 =\frac1{8\gamma^2}\|E+E^T\|_F^2
   +\frac1{4\gamma^2}\operatorname{tr}(E Q E^T).
\]

Diagonalize Q orthogonally, writing its eigenvalues q_i≥0 and the rotated entries of E as e_ij. The cross terms e_ij e_ji cancel between the two covariance-information expressions. Subtraction leaves

\[
 \frac1{4\gamma^2}\sum_{i,j}
 \frac{q_i(1+q_j)}{1+q_i}\,e_{ij}^2,
\]

which is exactly the squared norm in (5). QED.

### 8.3 Sharpness of the resource factor

Take n=2, gamma=1, Q=diag(0,2) and E_12=1 with all other entries zero. Noise information is 3/4. If the mean displacement has covariance alpha Q rather than Q/4, its information is 1/4+2alpha. Thus every alpha<1/4 fails to dominate this noise experiment. The universal fraction 1/4 is sharp.

### 8.4 Relation to the first rotational comparison

For E=K skew-symmetric, the baseline covariance derivative vanishes. With a full-variance recorded mean intervention u=gamma Z, rather than the quarter-variance one,

\[
 \mathcal I_{\rm noise}(K)
 =\frac1{4\gamma^2}\sum_{i<j}
 \frac{(q_i-q_j)^2}{(1+q_i)(1+q_j)}k_{ij}^2,
\]

\[
 \mathcal I_{\rm mean,1}(K)
 =\frac1{\gamma^2}\sum_{i<j}(q_i+q_j)k_{ij}^2.
\]

The inequality (q_i−q_j)²/[(1+q_i)(1+q_j)]≤q_i+q_j gives a factor-four information advantage at equal added stationary second moment. The factor is approached with one eigenvalue large and the other zero. For a balanced two-coordinate design with q_i independently 0 or 2, the average full-variance mean/noise information ratio is 12. This balanced-mask calculation is not asserted for every particular finite code.

### 8.5 What the comparison does not prove

It is local at uniform damping with a known isotropic background. It is not a global Blackwell comparison, not a finite-sample risk theorem for all estimators, and not a result for hidden variables, nonlinear dynamics, unknown nuisance diffusion, or state-dependent readout noise. It assumes the mean label is recorded.

It rules out a universal local information advantage of noise injection under the stated access and variance budget. It does not rule out a useful noise-only protocol where controllable mean shifts are unavailable or where setting-switching dominates cost. No such hardware-specific end-to-end superiority was established here.

## 9. Executed tests

### Exact covariance reconstruction

The dense decoder received covariance differences and calibrated noise designs, not the true A or background diffusion. The test harness, explicitly separate from that decoder, supplied exact stationary covariances.

| Variables | Noise settings + baseline | Frobenius reconstruction error |
|---:|---:|---:|
| 3 | 33 | 2.34e-14 |
| 5 | 51 | 3.76e-14 |
| 8 | 69 | 4.78e-14 |
| 12 | 83 | 7.76e-14 |

This validates the algebraic decoder, not acquisition efficiency.

### Matrix-free checks

Five sizes 3, 5, 8, 12 and 32 were tested. The operator/adjoint numerical identity error was at most 3.08e-15. The largest test used 114 noise settings, converged in 27 Krylov iterations, and had Frobenius reconstruction error 2.03e-10. Covariance-array storage was 933,888 bytes; an explicit design would require 956,301,312 bytes. These are array sizes, not total peak process memory. The avoided explicit design is a deliberately weak implementation baseline, not a claim against contemporary best solvers.

### Fisher-identity checks

Theorem 2 was evaluated on 300 random cases, including arbitrary non-skew drift directions, rotated interventions and singular Q. Maximum scaled identity error was 3.95e-15. Thirty finite-difference checks against perturbed stationary Lyapunov solutions had maximum information error 2.82e-8.

An independent raw-score check used 600,000 Gaussian samples per experiment in the sharp two-dimensional example. Theoretical information was 0.75 for both. Observed score second moments were 0.75385 and 0.75229.

The earlier skew-only check covered 180 PSD/direction pairs. A separate balanced-mask experiment with 600,000 samples per protocol measured information ratio 11.986 versus the exact value 12.

### Raw-snapshot reconstruction

A four-variable skew-coupled system with ||A||_2=1 and gamma=9 was tested with 43 noise conditions including baseline. Each protocol used the same total number of stationary snapshots. For this model the mean protocol's average added stationary second moment was 3.88079, below the noise protocol's 3.90698; no true-A-dependent tuning was used to achieve that bound.

| Snapshots for each protocol | Independent repeats | Coded-noise RMS Frobenius error | Recorded-mean RMS Frobenius error |
|---:|---:|---:|---:|
| 86,000 | 6 | 0.66444 | 0.13107 |
| 860,000 | 6 | 0.20038 | 0.03785 |

Projecting both estimates onto skew matrices also favored the mean protocol: errors 0.26075 versus 0.08475, and 0.06253 versus 0.02082.

These experiments actually generate raw observations and estimate sample moments; they do not replace those moments by their expectations. Nevertheless, they use a known stationary Gaussian test simulator. They contain no acquired laboratory mixing certificate, actuator calibration or measurement-model validation. The noise least-squares estimator is not asserted statistically optimal; Theorem 2, rather than this particular implementation, supports the local information comparison.

## 10. Claims and omissions

**Proved by the derivations in this report:** the exact two-setting counterexample; the conditional binary-code conditioning bound; the restricted logarithmic setting-count lower bound; the deterministic error-propagation inequality; the sharp local quarter-variance Fisher-information identity.

**Executed:** four Python test programs, exact-covariance inverse checks, matrix-free adjoint/reconstruction checks, arbitrary-direction Fisher checks, finite-difference checks, raw-score simulations and raw-snapshot comparisons.

**Not established:** a foundational practical invention; historical novelty of the scoped mathematical results; independent or formal verification; competitive real-world performance; a biological noise-control implementation; a general nonlinear/hidden-state extension; a universally dominant experiment; a new dense Gaussian simulation primitive.

The output is a rejected breakthrough candidate with reusable, scoped mathematics and reproducible evidence. Its failure of the declared objective is not being relabeled as a successful applied breakthrough.

## 11. Reproduction

Use Python 3.10 or later with NumPy and SciPy. The executed environment used Python 3.13.5, NumPy 2.3.5 and SciPy 1.17.0. `requirements.txt` records those numerical package versions. From this directory:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python research_gate.py --output replay_gate.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python quarter_variance_test.py --output replay_quarter.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python raw_snapshot_comparison.py --output replay_raw.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python matrix_free_decoder.py --output replay_matrix_free.json
```

Random seeds are fixed in each program. Floating-point outputs can differ across numerical libraries and machines. Assertions check tolerances, not byte-identical results. `MANIFEST_SHA256.json` hashes the supplied package files.

## 12. Primary literature and source boundaries

[P1] Zweig, Lin, Azizi and Knowles. *Towards Identifiability of Interventional Stochastic Differential Equations*, arXiv:2505.15987v5 (10 July 2026). Main setup and results inspected; not all appendix proofs independently checked. https://arxiv.org/html/2505.15987v5

[P2] *Sparse dynamic network reconstruction through L1-regularization of a Lyapunov equation*, arXiv:2403.05457v1. Existing covariance/Lyapunov reconstruction method; not an implementation baseline replayed here. https://arxiv.org/html/2403.05457v1

[P3] *Approximating committor functions: Objective functions and enhanced sampling*, arXiv:2607.21425v2. Primary enhanced-sampling comparator consulted; not implemented or comprehensively benchmarked. https://arxiv.org/html/2607.21425v2

[P4] Pfau et al. *Fermionic neural-network states for ab-initio electronic structure*, arXiv:1909.12852. Abstract/overview screen only; not a claim of a full current electronic-structure benchmark survey. https://arxiv.org/abs/1909.12852

[P5] Yue M. Lu. *Householder Dice: A Matrix-Free Algorithm for Simulating Dynamics on Gaussian and Random Orthogonal Ensembles*, arXiv:2101.07464v2; IEEE Transactions on Information Theory 67(12), 8264–8272 (2021). Full HTML was accessed; the mechanism, interface and complexity were examined. https://arxiv.org/html/2101.07464v2

Repository sources and original-proof locations are in `SOURCE_MANIFEST.json`. No upstream manuscript is bundled, and reading a manuscript is not treated as independent certification.
