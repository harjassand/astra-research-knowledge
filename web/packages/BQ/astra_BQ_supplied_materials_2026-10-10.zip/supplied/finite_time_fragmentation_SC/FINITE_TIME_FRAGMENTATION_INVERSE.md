# Finite-time fragmentation inversion through a renewal conjugacy

Research candidate, 2026-10-09. The stated inverse theorem passed one focused
AI-assisted mathematical check, not external expert review or formal
certification. Its priority remains provisional, and this is not a validated
experimental instrument. The spectral conjugacy mechanism is
prior art; the candidate contribution is its endpoint-driven inverse use.

## Precise capability and completion criterion

Recover a nonparametric, self-similar daughter law from a single finite-time
fragment-size distribution, after arbitrarily many generations, with known
power-law fragmentation rate. The proposed advance is a reduction of the
nonlinear inverse to **two linear causal integral equations**. On a geometric
grid these become two O(N^2)-arithmetic, O(N)-storage recurrences. No temporal
differentiation, PDE solve, nonlinear optimization, or small-time approximation
is needed for this inverse.

The intended success criterion is: (1) an exact continuous-model statement,
(2) a constructive uniqueness/stability proof with its actual restrictions,
(3) agreement with an independent forward solver, (4) useful recovery under
noise and off-lattice data, and (5) comparison against full finite-time fitting,
not only the biased short-time formula. Novelty remains conditional on a
focused independent prior-art assessment. No claim of experimental validation.

## 1. Physical observation and necessary assumptions

The number measure mu_t of fragments obeys pure, independent fragmentation:

    d mu_t(x)/dt = -alpha x^gamma mu_t(x)
                  + alpha integral_{y >= x} y^(gamma-1) kappa(x/y) mu_t(y) dy.

Assume alpha > 0, gamma > 0, no coagulation/growth, and a time-independent,
self-similar daughter measure kappa on (0,1) satisfying integral z kappa(dz)=1.
The initial population is monodisperse at x=1, with its initial mass normalized
to 1. A binary law additionally has number mass 2 and reflection symmetry;
neither extra constraint is needed for the inverse theorem.

Use log size s=-log x and **mass weighting**:

    P_t = pushforward of x mu_t(dx) under x -> -log x,
    K   = pushforward of z kappa(dz) under z -> -log z.

K is a probability measure on (0,infinity), the jump law of a mass-tagged
fragment. This recovers the mean daughter measure kappa, not the joint law of
all daughters produced in an individual split. For densities,
k(s)=exp(-2s) kappa(exp(-s)). The density of P_t
has the same exp(-2s) conversion from the number density. It is NOT a
number-weighted fragment histogram.

To convert actual measurements, one needs individual sizes or suitable size
bins and a valid mass normalization. A COMPLETE unbiased normalized number
law Q can be converted as P(dx)=x Q(dx)/integral x Q(dx), without knowing the
original specimen count. A normalized,
number-weighted, lower-size-truncated histogram with unknown detector scale
does not automatically provide these data; independent initial-mass/count
calibration suffices, and known alpha plus a resolved intact atom can provide
another scale reference. The intact parent atom must be
distinguished from daughters almost as large as the parent. Instrument blur,
unknown detection efficiency, or an unknown initial spread are not covered by
the basic monodisperse theorem.

The required small-chipping condition is

    integral_{(0,1]} K(ds)/s < infinity.                         (SC)

Equivalently, near z=1, integral z kappa(dz)/(1-z) is finite. A positive minimum
log-jump suffices. Smooth daughter densities vanishing like (1-z)^beta with
beta > 0 suffice. A uniform number-daughter density near z=1 does NOT satisfy
this condition. The method below does not silently extend its continuous
conjugacy to that excluded case.

## 2. Convolution conjugacy: exact continuous proof

Fix lambda > 0 and let M_lambda be locally finite signed measures on
[0,infinity), allowing infinite unweighted mass, with finite norm

    ||nu||_lambda = integral exp(-lambda s) |nu|(ds).

This is a unital Banach convolution algebra with identity delta_0. Write
C_K nu = K * nu and D nu(ds)=exp(-gamma s) nu(ds). D is a bounded convolution
algebra endomorphism: D(nu*eta)=Dnu*Deta. The forward generator is the bounded
operator

    L_K = alpha (C_K - I) D.                                  (1)

Because K has no atom at 0, ||K||_lambda < 1. Condition (SC) gives

    sum_{j >= 0} ||D^j K||_lambda
      = integral exp(-lambda s)/(1-exp(-gamma s)) K(ds) < infinity.

Consequently the following product and its convolution inverse converge in
M_lambda:

    W = convolution-product_{j >= 0} (delta_0 - D^j K)^(-1),
    V = convolution-product_{j >= 0} (delta_0 - D^j K),
    W * V = delta_0.                                          (2)

Each inverse factor is its convergent nonnegative renewal series. W is
nonnegative and has atom 1 at zero, so write W=delta_0+w. Shifting the product
index proves

    (delta_0-K)*W = DW,
    K*W = (I-D)W = (I-D)w.                                    (3)

The identity C_{DW} D = D C_W then yields the exact operator relation

    C_W L_K = -alpha D C_W.                                   (4)

Since the operators are bounded on M_lambda, exponentiating (4) is legitimate:

    W * P_t = E_t W,
    E_t(s) = exp(-alpha t exp(-gamma s)).                       (5)

This is a convolution similarity between the fragmentation semigroup and a
known multiplication semigroup, a mechanism already present in the
Patie-Sarkar/Bernstein-gamma spectral literature. Equations (2)-(5) are
identities in the
continuous measure-valued model, not consequences of a finite-bin approximation.

## 3. Inverting one endpoint

Let a=alpha T and observe P_T=exp(-a) delta_0+f. Set

    d_T(s) = exp(-a exp(-gamma s)) - exp(-a),  s>0.

The first linear Volterra equation is

    d_T w = f + f*w.                                          (6)

Once w is found, the second is

    K + K*w = (1-exp(-gamma s)) w.                             (7)

Thus both stages are linear in their respective unknowns. The unknown K is
absent from (6); the recovered w is a known coefficient in (7).

### Existence and uniqueness of the reconstruction

Let g=f/d_T and T_f nu=(f*nu)/d_T. Since d_T is increasing,

    |T_f nu| <= (|f|/d_T)*|nu|.

For compatible data, (6) and nonnegativity imply g <= w, so g is locally
finite and belongs to M_lambda. Increasing lambda makes ||g||_lambda as small
as desired because g has no atom at zero. Choose ||g||_lambda < 1. Then

    w = (I-T_f)^(-1) g = sum_{j >= 0} T_f^j g                  (8)

converges and is unique in M_lambda. Choosing lambda still larger also gives
||w||_lambda < 1, making the standard convolution-Neumann inverse of delta_0+w
available for (7). Therefore K is uniquely determined by this endpoint within
the stated model class.

### Exact observation truncation property

All operations in (6)-(8) are causal in s. Data on [0,L] alone determine K on
[0,L]. Fragments with size x<exp(-L) and daughter ratios z<exp(-L) can be
unobserved without biasing the reconstruction above that threshold. Their
detailed law is NOT reconstructed. This follows either by restricting every
operation to the truncated convolution algebra, or by uniqueness on each
prefix. This is distinct from discarding near-parent daughters, which occur at
the causal entrance s=0 and can affect every later size.

### An explicit, conditional stability bound

On [0,L], take two potentially signed observations f and f_tilde with

    max(||f/d_T||_lambda, ||f_tilde/d_T||_lambda) <= rho < 1/2,
    epsilon = ||(f-f_tilde)/d_T||_lambda.

The operator bound above and a resolvent identity give

    ||w-w_tilde||_lambda <= epsilon/(1-rho)^2.

Writing r=rho/(1-rho), both ||w|| and ||w_tilde|| are at most r<1. Applying
the convolution inverse identity to (7) gives

    ||K-K_tilde||_lambda <= epsilon/(1-2rho)^2.                (9)

For unweighted error on [0,L], multiply the right side by exp(lambda L).
If the data/noise have no support below c>0, epsilon is at most
||f-f_tilde||_lambda/d_T(c). The constants may be poor, and the division by
d_T(s) ~ a gamma exp(-a) s near zero is a real restriction on the admissible
noise. Equation (9) does not promise uniform stability for arbitrarily long
times, vanishing gamma, or arbitrary near-parent measurement contamination.

## 4. Geometric-grid algorithm

For log-size points s_n=n h, let q=exp(-gamma h), K=sum_{n>=1} k_n delta_{nh},
and observe P_T=sum f_n delta_{nh}. Then

    w_0=1, k_0=0,
    w_n = [sum_{j=1}^n f_j w_{n-j}]
          /[exp(-a q^n)-exp(-a)],
    k_n = (1-q^n)w_n - sum_{j=1}^{n-1} k_j w_{n-j}.            (10)

Each n uses only earlier coefficients; this is O(N^2) arithmetic and O(N)
storage. expm1 forms avoid loss of significance in the denominator. A discrete
kernel is an exact instance of the continuous theorem, but approximating a
continuous histogram by these atoms creates a separate binning/model error.
The off-lattice test measures rather than hides that error.

For a general KNOWN initial lattice distribution g with g_0>0, replace the
first recurrence by

    w_n = sum_{j=1}^n [f_j - exp(-a q^n) g_j] w_{n-j}
          / {g_0 [exp(-a q^n)-exp(-a)]}.                       (11)

This follows from W*P_T = E_T (W*P_0). It handles known spread on this lattice;
it is not a stability theorem for arbitrary unknown continuous initial spread.
Even a known lattice spread with small g_0 can make this recursion severely
ill-conditioned; the monodisperse bound (9) does not cover that extension.
A continuous initial density with no leading atom instead gives a first-kind
linear Volterra equation and needs separate regularization.

## 5. Rate identifiability and explicit no-go boundary

If the monodisperse intact mass is calibrated, alpha can be obtained as
-log P_T({0})/T. gamma must be known independently for this result. On a finite
observed prefix, changing q and applying (10) can yield another strictly
positive daughter law with exactly the same endpoint. In the saved example,
q=0.925, 0.930, 0.935 produce positive kernel prefixes of mass about
0.79356, 0.80000, 0.80734 respectively, all matching the same endpoint to
3e-17. An unobserved tail can complete each to a probability law. Joint
unknown-exponent recovery is therefore not claimed. These aliases are in the
unconstrained probability-kernel class; they do not establish the same no-go
after imposing binary symmetry or a known full daughter support.

## 6. Numerical stability is separate from statistical conditioning

W can have huge coefficients when gamma is small or near-parent jumps dominate.
Subtracting large terms in (10) can catastrophically fail in floating point,
even when the underlying inverse is statistically well-conditioned. One saved
q=0.999 test gave double-precision error 5.9e4, whereas 100-decimal-digit
evaluation of the SAME double-precision endpoint recovered K to 3.2e-17.
This is representation cancellation, not a reason to conceal the failure.

The prototype includes an explicitly callable arbitrary-precision fallback,
not an automatic precision-selection or failure-detection system. Its cost and required
precision grow with the intermediate coefficient magnitudes; no uniformly
fast/stable claim is made over this regime. The gamma=0 case should use the
classical compound-Poisson convolution logarithm, not this singular formula.

## 7. What the current numerical evidence establishes

Reproducible scripts and full raw outputs are in this directory.

- `fragment_inverse.py`: proposed inverse; arbitrary-precision fallback;
  independent matrix-exponential and classical uniformization forwards;
  exact Frechet-adjoint and uniformization-adjoint nonlinear likelihood fits.
- `test_fragment_inverse.py`: random kernels, independent exponential checks,
  adjoint finite-difference check, matched noise, prefix truncation.
  Its saved results explicitly retain adverse floating-point failures.
- `continuum_test.py`: exact event-driven, continuous-size mass-tag process;
  replicated noisy comparisons; exponent aliases; precision repair.
- `fast_baseline_test.py`: classical matrix-free uniformization baseline,
  gradient check, matched-data likelihood comparison and cost scaling.

The stability bound (9) is not, by itself, a statistical consistency theorem:
atomic empirical samples of a continuous law do not converge in total variation.
Histogram/density estimation and bandwidth selection need separate analysis.
The independent-tag and Poissonized noise assumptions also do not account for
correlations among actual fragments sharing an ancestor.

The off-lattice run used 4 million independent mass tags with a symmetric
binary number-daughter law 2 Beta(3,3), alpha T=2, gamma=1.3. The mass-tag jump
ratio is Beta(4,3). About 38.12% of tags underwent two or more breaks. At
log-bin width h=0.08, the recovered mass-daughter histogram had L1 error
0.00408, versus 0.6632 for the short-time estimate. These are ideal, calibrated
mass-tag observations, not a claim about unprocessed laboratory counts.

Across 20 replicates for each of six matched Poissonized count settings,
the direct positive-clipped inverse and full nonnegative Poisson fitting had
closely similar errors. At alpha T=2 and sample scale 100,000, mean L1 error
was 0.02232 versus 0.02222. This is a computational/direct-inversion result,
not a statistical superiority claim. Fitting is allowed nonnegativity just as
the direct output is clipped; no artificial complete-tail normalization is
given to one method alone. Both use identical endpoint bins and known rates.
The likelihood baseline receives the direct inverse as a warm start, making it
a strong comparison for likelihood quality but not an independent initializer.

The faster classical uniformization comparison is the relevant timing test;
the dense matrix-exponential timings alone should NOT be promoted as the final
speedup. No new large simulation is needed to assess priority of the inverse.

## 8. Focused primary prior-art comparison

1. Doumic, Escobedo & Tournus, *An inverse problem: recovering the fragmentation
   kernel from the short-time behaviour of the fragmentation equation*,
   Annales Henri Lebesgue 7 (2024), 621-671, DOI 10.5802/ahl.207.
   https://www.numdam.org/item/10.5802/ahl.207.pdf
   Original introduction and main-result descriptions were read. Sections
   1.1-1.2 expressly give a short-time approximate kernel reconstruction with
   known power-law rate and error estimates; a separate Mellin reconstruction
   is likewise short-time. This is the closest precise reconstruction baseline.

2. Alomari & Dubovski, *Recovery of the integral kernel in the kinetic
   fragmentation equation*, Inverse Problems in Science and Engineering 21
   (2013), 171-181, DOI 10.1080/17415977.2012.677446.
   https://www.tandfonline.com/doi/full/10.1080/17415977.2012.677446
   Its primary abstract/introduction describe a nonlinear inverse transformed
   to source recovery, solved with direct/adjoint/control equations. Its data
   are c(x,0) and c(x,T): the SAME known-initial-plus-terminal observation
   pattern as this candidate. No novelty claim rests on using fewer snapshots.
   The distinction is its perturbative/source-recovery variational method and
   kernel parameterization versus the exact two-Volterra construction here.
   The 2024 primary paper describes its perturbative linearization.
   The full 2013 equations were not all accessible in the browser extraction;
   this is a limitation of the present prior-art check, not evidence of absence.

3. Doumic, Escobedo & Tournus, *Estimating the division rate and kernel in the
   fragmentation equation*, Ann. IHP C 35 (2018), 1847-1884.
   https://www.numdam.org/articles/10.1016/j.anihpc.2018.03.004/
   Uses long-time self-similar profiles and Mellin inversion, including rate
   identification. It is a different observation regime and does not supply
   the two finite-time Volterra equations above in its stated main result.

4. Hoffmann & Krell, *Statistical analysis of self-similar conservative
   fragmentation chains*, Bernoulli 17 (2011), 395-423.
   https://arxiv.org/abs/0803.0879
   The original abstract/introduction specify terminal sizes at a screening
   threshold, not a fixed-time population endpoint. Tagged-fragment and renewal
   ideas are established foundations and are not claimed as new here.

5. Patie & Sarkar, *Weak similarity orbit of (log)-self-similar Markov semigroups
   on the Euclidean space*, Proc. London Math. Soc. 126 (2023), 1522-1584.
   https://arxiv.org/abs/2301.06656v1
   Original introduction and spectral-representation statements were read.
   General semigroup intertwining, Fourier multipliers, and spectral similarity
   are substantial existing theory. A claim that convolution/spectral conjugacy
   itself is new would be unjustified. The candidate novelty is the data-driven
   reconstruction of the intertwiner from ONE endpoint through (6), then (7),
   its causal truncation property, and the resulting direct algorithm. A focused
   checker has additionally confirmed that their spectral representation uses
   the same exponential multiplication semigroup. Accordingly, the conjugacy
   itself is prior art; only the inverse reconstruction consequence is a
   candidate for novelty.

6. *Physics-Constrained Neural Identification of Fragmentation Kernels: From
   Synthetic Recovery to Effective Daughter-Volume-Fraction Estimation in
   Droplet Breakup* (2026).
   https://www.mdpi.com/2297-8747/31/4/142
   Primary numerical-method section uses parametrized rate/daughter laws,
   repeated forward integration, and regularized optimization. It carefully
   separates effective daughter-law fitting from joint rate recovery. This
   supports the importance of that distinction, but is not a priority verdict.

No repository sources or external paid compute were used. Search coverage is
focused rather than exhaustive. A specialist prior-art check remains required
before describing this as a genuinely new scientific method.
