# Focused proof and primary-prior audit

2026-10-09. One focused AI-assisted mathematical check, not external expert
review or formal certification, of `FINITE_TIME_FRAGMENTATION_INVERSE.md`, the inverse implementation, the saved experiments, and the nearest identified primary literature. No additional reviewers or large simulations were used.

## Verdict

**The exact monodisperse inverse passes this check under the stated small-chipping assumption.** The generator order, bounded similarity, two reconstruction equations, prefix uniqueness, and stated conditional stability constant are correct. I found no fatal mathematical error in that theorem.

**A narrowly framed inverse-method novelty claim remains plausible, not established.** I did not locate the two endpoint-driven Volterra reconstruction equations as an existing stated theorem. The underlying spectral similarity is already explicit in primary literature, and its infinite-product multiplier belongs to established Bernstein-gamma theory. The potentially new contribution is reconstructing that multiplier from a known-initial-state, finite-time observation, with the causal inverse and its restricted stability statement. Calling the conjugacy itself new, or claiming an established scientific discovery, would exceed the evidence.

**One prior-art comparison needs correction:** Alomari–Dubovski (2013) formulates its data as the initial distribution plus a terminal distribution. Its “two times” must not be contrasted with this proposal as though it necessarily required two *post-initial* observations. The meaningful distinctions are the model class and exact constructive inverse versus their perturbative/source-recovery variational construction.

## 1. Load-bearing proof

Use the Banach algebra of locally finite signed Radon measures with finite exponentially weighted total variation. Explicitly permitting infinite *unweighted* mass is important: the intertwiner need not be an ordinary finite measure. This is a definitional clarification, not a failure of the argument.

1. **Generator order.** At log-size s, the mass tag jumps by a K-distributed increment at rate alpha exp(-gamma s). Thus the forward measure generator is alpha(C_K-I)D, with the rate multiplier on the right. Reversing this order would be wrong.
2. **Convergent products.** Put b_j=||D^j K||_lambda. Since K is supported on (0,infinity), b_0<1 and b_j<=b_0. SC gives sum b_j<infinity, hence sum ||(delta-D^j K)^(-1)-delta|| <= sum b_j/(1-b_0)<infinity. Both products converge in the algebra; continuity of convolution proves W*V=delta. Their finite-product zero-atoms are respectively 1, and norm convergence preserves this. Positivity of W follows from the renewal factors.
3. **Similarity.** Shifting factors gives (delta-K)*W=DW. Consequently

       C_W L_K = alpha C_(W*K-W) D
               = -alpha C_(DW) D
               = -alpha D C_W.

   The last identity uses D(W*nu)=DW*Dnu, not commutation of D with convolution. All operators are bounded on the selected algebra, and C_W has bounded inverse C_V, so exponentiating is legitimate. Applying it to delta yields W*P_T=E_T W.
4. **Endpoint equation.** Substitute P_T=exp(-a)delta+f and W=delta+w. The zero-atoms cancel, giving exactly d_T w=f+f*w. The factor equation gives K*(delta+w)=(I-D)w. These are genuinely linear in their successive unknowns.
5. **Uniqueness.** Define division only on (0,infinity), and assign zero atom to g=f/d_T and T_f nu=(f*nu)/d_T. Monotonicity of d_T gives ||T_f||<=||g||_lambda. For compatible data, 0<=g<=w. Increasing lambda makes both norms arbitrarily small, by dominated convergence and absence of a zero atom. A contraction solves the first equation uniquely; convolution inversion solves the second. For two compatible kernels, choose one sufficiently large common lambda. Restriction to any [0,L] proves prefix uniqueness in exactly the same way.
6. **Stability.** With the report's rho<1/2 assumption, ||w||,||w_tilde||<=r=rho/(1-rho), and the resolvent identity gives ||Delta w||<=epsilon/(1-rho)^2. Set R=(delta+w)^(-1). Since ||R||,||R_tilde||<=1/(1-r), the difference of K=(I-D)w*R is bounded by ||Delta w||/(1-r)^2. Combining gives epsilon/(1-2rho)^2, as claimed.

SC is a structural restriction of this positive atom-one intertwiner, not merely a convenient estimate. Indeed, (I-D)w=K*(delta+w)>=K implies w>=K/(1-exp(-gamma s)). A locally finite positive w therefore requires SC near zero. This does not prove that *other* inverse methods fail without SC.

## 2. Observation and noise qualifications

- The recovered object is the mass-tag jump distribution K, equivalently the mean daughter measure kappa. A first-moment fragment-size equation does not identify the joint distribution of all daughters produced in an individual split.
- The theorem concerns exact mass-calibrated endpoint measures, or signed errors small in the displayed weighted variation norm after division by d_T. Arbitrary near-parent contamination need not belong to that class.
- Empirical atomic samples from a continuous law do not converge to it in total variation. Therefore (9) alone is not a continuum statistical consistency theorem. Histogram or density-estimation error and bin-width selection need a separate argument. The saved off-lattice experiment is useful numerical evidence, not that missing theorem.
- The simulation uses independent mass tags. Physical fragments descending from common ancestors have correlations; the reported Poissonized count model is not automatically a laboratory-count noise model.
- Absolute calibration is needed for a truncated histogram unless it can be recovered from other information. The note is slightly too restrictive if read as requiring the original specimen count in every setting: a *complete*, unbiased normalized number law Q can be converted by P(dx)=xQ(dx)/integral xQ(dx). With known alpha and a resolved intact atom, that atom can also provide a scale reference for a truncated number histogram. Detection bias and blur remain unaddressed.
- The unknown-gamma aliases establish nonidentifiability on a finite observed prefix within the unconstrained probability-kernel class. They do not establish the same claim after imposing additional binary symmetry or a known full daughter support.

## 3. Code and numerical spot check

The implemented recurrence matches equations (10), including the `expm1` denominator. The matrix generator uses the correct origin-state rate. The code's high-precision routine is an explicit alternative call; it is not an automatic precision-selection or failure-detection system. Its conversion of inputs through Python floats deliberately preserves only the supplied double-precision endpoint.

I independently built Toeplitz convolution matrices and dense matrix exponentials for three new seeded cases. Results are saved in `FOCUSED_AUDIT_NUMERICS.json`:

- n=13, q=.73, a=.3: operator residual 7.98e-17; semigroup residual 1.11e-16; inverse error 5.55e-17.
- n=35, q=.94, a=2.7: corresponding residuals 1.05e-15, 1.64e-15, 8.36e-16.
- n=22, q=.99, a=3.1: corresponding residuals 1.80e-11, 7.36e-12, 6.75e-13, with max W about 2261. This retains the expected cancellation deterioration.

The known-initial-spread formula (11) is algebraically correct and was independently verified with 90-digit forward and inverse calculations. It can nevertheless strongly amplify floating-point errors: one new case with g_0=.01255 produced a .00130 error in W using doubles, versus 1.33e-80 using a 90-digit endpoint and arithmetic. This extension deserves its own conditioning warning; the monodisperse theorem's stability estimate does not cover it.

I inspected, rather than reran, the expensive Monte Carlo and repeated fitting outputs. The stated severe q=.999 double-precision failure and precision repair are present in the saved results. The full-likelihood comparison is appropriately described as a computational comparison, not statistical superiority. On a fixed grid, a positive exact inverse fits all measured endpoint bins exactly, so near-agreement with a saturated likelihood fit is unsurprising. Clipping is a practical modification, not an exact compatibility certificate.

## 4. Closest primary prior art

### Doumic, Escobedo and Tournus (2024)

The primary abstract, introduction and main-result summary explicitly distinguish short-time kernel approximation from exact forward series representations. Their near-monodisperse short-time reconstruction, TV/BL error analysis, and generic-initial-data Mellin approximation do not state this exact arbitrary-finite-time pair of Volterra inverses. This remains the closest direct inverse-problem comparator. Its broader treatment of initial spread and weaker observation metrics should not be erased by the finite-time advantage claimed here.

Source: [Annales Henri Lebesgue 7, 621–671, DOI 10.5802/ahl.207](https://www.numdam.org/item/10.5802/ahl.207.pdf), introduction and main-result summary, journal pp. 625–628.

### Alomari and Dubovski (2013)

The publisher's primary indexed first page states data c(x,0) and c(x,T), and first restricts the binary kernel to F(x,y)=F(x+y), i.e. a parent-size-dependent factor with uniform daughter splitting. The primary summary explicitly describes linearization, source recovery, and direct/adjoint/control equations. This is materially different from the proposed exact nonparametric daughter-law inverse, but it already uses initial-plus-terminal observations. Full equation-level access remained incomplete: direct publisher opens returned 403, while indexed primary first-page and conclusion text were available. Accordingly, no blanket exclusion of every construction in that paper is warranted.

Sources: [publisher PDF](https://www.tandfonline.com/doi/pdf/10.1080/17415977.2012.677446), p. 171; [publisher article](https://www.tandfonline.com/doi/full/10.1080/17415977.2012.677446), Section 6.

### Patie and Sarkar (2023), with Patie and Savov (2018)

Patie–Sarkar's Theorem 2.4 and equation (4.4) explicitly conjugate suitable log-self-similar semigroups to multiplication by exp(-t exp(-x)), using Fourier multipliers. This is substantially closer than a generic citation to “intertwining.” Their Bernstein-gamma machinery also connects directly to the present product: if phi(z)=1-K_hat(gamma z) and H(p)=W_hat(p), then H(gamma z)/H(gamma) satisfies F(z+1)=phi(z)F(z), F(1)=1. It is a Mellin transform, hence the normalized Bernstein-gamma function. This identification is my comparison, not a theorem claiming their exact function-space assumptions automatically cover every candidate kernel, particularly lattice laws.

The primary results construct spectral transforms from a known generator. I did not find a theorem reconstructing an unknown daughter kernel from one delta-initial endpoint by the two causal equations. Once the similarity is known, deriving those equations is short; priority should therefore be framed around the inverse formulation and its consequences.

Sources: [Patie–Sarkar primary preprint](https://arxiv.org/pdf/2301.06656), equations (1.10), (2.8), (4.4); [Patie–Savov primary preprint](https://arxiv.org/abs/1604.05960), later Electronic Journal of Probability 23 (2018).

### Doumic, Escobedo and Tournus (2018)

Theorems 1–2 recover parameters and the daughter measure from the long-time self-similar profile using a Mellin quotient and inversion. This establishes important earlier exact inversion, but under a different observation regime. The proposal must not advertise itself as the first exact fragmentation-kernel inverse without that qualification.

Source: [Ann. IHP C 35, 1847–1884](https://www.numdam.org/item/10.1016/j.anihpc.2018.03.004.pdf), Section 2.3 and Theorems 1–2.

## Bottom line

Retain this as a mathematically sound, restricted applied-inverse candidate. Before any outward novelty description, correct the 2013 observation-count comparison and explicitly attribute the multiplication-semigroup/Bernstein-gamma mechanism. The supported contribution is an exact, causal, computationally direct finite-time inverse under SC with known rate law and calibrated monodisperse data. This focused audit is sufficient to avoid rejecting the candidate for a proof error; it is not a certification of priority or experimental readiness. No further review loop is implied.
