# Matched full-likelihood comparison

2026-10-09. Targeted computational check, not a statistical-efficiency theorem.

## What is matched

`positive_fit_benchmark.py` uses the same fixed-seed observations, known rates,
log grid, density cap M=2, observation window L=4, time-rate product a=2,
and optional prefix mass repair for every method. Data are Poisson counts with
exposure 100,000 from the same finite-lattice forward model. The continuous
binning/noise test is separate; these timings isolate numerical computation.
No specimen preprocessing or instrument calibration is being benchmarked.

The nonlinear comparator minimizes the full finite-time Poisson objective
under exactly the same coordinate bounds [0,Mh]. Its positive uniformization
forward and analytic reverse adjoint share a single stored forward table.
There is no finite-difference gradient and no redundant second forward sweep.
It uses a parameter-adaptive rigorously bounded tail order (usually 20), while
the direct inverse uses a conservative cap-based order 64. L-BFGS-B receives
both a cheap first-generation initializer and the proposed inverse as a warm
start. Initialization time is counted for both. Rate setup, repair and the
optional independent forward-defect check are separately recorded.

The optimizer reports relative-objective convergence, not necessarily its
strict projected-gradient target; the latter residual is recorded explicitly.
No global optimum is claimed. Both starts reach very similar objectives.
The benchmark is a strong implemented full-likelihood comparator, not proof
that every possible optimizer, preconditioner or regularizer is inferior.

## Observed outcomes

All times below are single-run wall-clock seconds on the included CPU with
one BLAS thread. They exclude package imports, truth generation and evaluation
of oracle errors. See the raw JSON for every timing component and iteration.

| bins including zero | gamma | direct seconds | direct repaired L1 | best fitted repaired L1 | cheap-start seconds to direct oracle error | warm-start converged total seconds |
|---:|---:|---:|---:|---:|---:|---:|
|101|1.3|0.00554|0.0314113|0.0314038|0.05609|0.05953|
|101|0.02|0.00491|0.0727826|0.0715180|0.01400|0.02521|
|501|1.3|0.02706|0.0772786|0.0771255|0.13726|0.39100|
|501|0.02|0.03217|0.1364422|0.1334471|0.03437|0.10854|

The last-but-one column is an ORACLE retrospective diagnostic, not an
implementable stopping rule: it uses the known synthetic truth. A fit starting
at the direct inverse already meets that error at time zero of optimization.
In the final case the cheap-start fit reaches the same error almost as quickly
as the direct sweep. There is no uniform same-error speedup claim.

Full likelihood lowers the observed repaired L1 error by approximately
0.02% to 2.2% in these four realizations. This small experiment does not rank
expected statistical risk. It shows that avoiding optimization does not
require a conspicuously worse reconstruction in these cases, but likelihood
refinement can improve it.

For both 101-bin cases, the positive sweep and the 100-digit causal renewal
inverse agree within 2.6e-16 in coefficient l1. At gamma=.02 the renewal
transform reaches 2.7e40; the positive sweep never forms that transform.
The prior precision-failure examples remain in `no_sc_noise_results.json`.

The advance substantiated here is stable constructive evaluation of the
causal estimator with an explicit truncation/error budget, including nearly
constant rates. It is not a universal fitting speed advantage.

## Validation and reproduction

The new baseline forward was compared with an independently formed dense
matrix exponential (maximum difference 1.4e-16); four central finite-difference
gradient checks differed by at most 6.3e-10 at step 1e-6.

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python positive_fit_benchmark.py

Raw observations, truth, direct and both fitted estimates are retained in
`positive_fit_raw_arrays.npz`. All iteration traces, projected gradients,
settings, environment versions and outcomes are in `positive_fit_results.json`.
`positive_fit_log.txt` preserves the unabridged run summaries.
