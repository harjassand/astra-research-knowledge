# No-SC noisy recovery by causal clipping and log-bin quantization

New mathematical continuation, 2026-10-09. This note is separate from the
checked SC archive. It has not received another independent check or external
expert review. The assertions below have derivations and targeted tests, not
formal certification. Novelty remains provisional.

## Result and why the singular-intertwiner issue is avoidable

The finite-time forward map contains a directly observed one-jump term. Its
coefficient never vanishes at a fixed positive time. The other generations are
causal convolutions. This gives a noise-stability route that does NOT require
the small-chipping condition, a value of the density at zero, or differentiation
of an estimated density. The fast lattice inverse can enforce a density bound
during its causal sweep, making this stability argument apply to noisy output.

Under the assumptions below, the resulting estimator satisfies an explicit
expected L1 error bound of order N^(-1/3) when the log-bin width is of order
N^(-1/3). This is an upper bound, not a claim here of a proved minimax lower
bound or a useful numerical value for its pessimistic constants.

## 1. Model, target, and observations

- Known alpha>0, gamma>0, and observation time T>0; put a=alpha T.
- The log-size mass-tag process starts at 0 and, at state s, jumps by an
  independent K-distributed positive increment at rate alpha exp(-gamma s).
- K has a probability density k on (0,infinity). Its extension by zero to
  negative s has finite total variation V, and 0<=k(s)<=M. M is a known cap.
  A positive k(0+) is allowed; SC need not hold.
- Observe N independent mass-tag endpoint samples, or exactly that
  multinomial sampling model. Physical descendant correlations, detector bias,
  or unknown size blur are NOT silently included.
- Only the intact-atom category, log-size bins in (0,L], and their counts need
  be retained. Samples beyond L may be a single unmeasured-tail category.
  Counts are normalized by N, not renormalized after deleting the tail.
- The target is k restricted to (0,L], equivalently the mean mass-weighted
  daughter law above size ratio exp(-L). Neither the tail shape nor the joint
  law of all daughters from an individual break is identified.

Choose h=L/m for integer m. A positive log increment u is quantized UPWARD:
Q_h(u)=h ceil(u/h). Set k_h,j=P((j-1)h<U<=jh), j>=1. Thus k_h,j<=Mh and there
is no artificial zero-jump atom. The endpoint bins use the SAME ceiling rule;
Q_h(0)=0. This differs from the earlier midpoint-grid numerical demonstration.

## 2. Path expansion and the unsmoothed diagonal

For r jumps with increments u_1,...,u_r, let s_i=u_1+...+u_i, s_0=0. The
coefficient of the ordered jump-density product is

    H_r(u) = integral_{0<t_1<...<t_r<T}
       [product_{i=0}^{r-1} alpha exp(-gamma s_i)]
       * exp(-sum_{i=0}^r alpha exp(-gamma s_i)(t_{i+1}-t_i)) dt,

where t_0=0 and t_{r+1}=T. Nonexplosion follows from the rate bound alpha.
The endpoint law is the sum over r of the pushforward of H_r(u) product K(du_i)
under u -> sum u_i, together with exp(-a)delta_0 for r=0. In particular,

    0<=H_r<=a^r/r!.

For one jump the coefficient is

    A_T(s) = [exp(-a exp(-gamma s))-exp(-a)]/[1-exp(-gamma s)],
    A_T(0)=a exp(-a),  A_T(s)>=A_min:=a exp(-a).               (N1)

Hence the density forward map has the form

    f_K(s)=A_T(s)k(s)+G_K(s),                                 (N2)

where G contains at least two jumps. The same identities hold for the lattice
with ordinary convolutions of coefficient sequences. On the lattice the n-th
coefficient of G depends STRICTLY on k_1,...,k_{n-1}.

## 3. Difference bound: continuous and lattice versions

Let k and ell both be bounded by M. Telescoping a product of r densities,
then bounding the other r-1 factors by M, gives

    |G_K(s)-G_L(s)| <= integral_0^s B(s-u)|k(u)-ell(u)|du,

where

    B(v)=sum_{r>=2} [a^r/(r-1)!] M^(r-1) v^(r-2)/(r-2)!.

The factor r from telescoping changes r! to (r-1)!. No symmetry of H_r is
needed: use its scalar upper bound separately for each summand. All series
converge on compact intervals by their factorial bounds.

For the exponentially weighted L1 norm, the kernel has the exact bound

    ||B||_lambda = a [exp(a M/lambda)-1].                      (N3)

On the lattice put U_j=Mh, j>=1. The analogous convolution majorant is

    B_h = sum_{r>=2} [a^r/(r-1)!] U^(*(r-1)),
    ||U||_lambda = Mh/(exp(lambda h)-1) <= M/lambda.

Thus (N3) is a bound UNIFORM IN h. This is the key distinction from bounds
based on the diverging auxiliary intertwiner.

Choose lambda>0 such that

    rho = exp(a)[exp(a M/lambda)-1] < 1.                      (N4)

For example lambda=aM/log(1+exp(-a)/2) gives rho=1/2. The constants below can
be very large; this proves continuity/consistency, not uniformly favorable
conditioning for late observation times or arbitrary caps M.

For two compatible continuous laws bounded by M, (N1)-(N4) imply

    ||k-ell||_L1(0,L)
       <= C_inv ||f_K-f_L||_L1(0,L),
    C_inv = exp(lambda L)/[a exp(-a)(1-rho)].                  (N5)

No SC or endpoint-density value is needed. This bound explains why numerical
divergence of a unit-atom intertwiner need not indicate intrinsic loss of
information in the finite-time inverse.

## 4. The actual estimator: causal clipping, then optional mass repair

Let Y_n be the observed endpoint mass in bin n, divided by N. Let F_h(k) be
the exact geometric-lattice endpoint map, and write

    F_h(k)_n = A_n k_n + G_n(k_1,...,k_{n-1}),
    A_n=A_T(nh).

Compute sequentially

    raw_n = [Y_n-G_n(khat_1,...,khat_{n-1})]/A_n,
    khat_n = min(Mh, max(0,raw_n)).                            (N6)

This is NOT the exact unconstrained linear inverse followed by clipping at
the end. Each clipped value is fed into every subsequent coefficient. Since
the true k_h,n lies in [0,Mh], projection onto this interval cannot increase
its scalar estimation error. The discrete difference inequality therefore
gives, for arbitrary signed endpoint perturbation eta=Y-F_h(k_h),

    sum_{n<=m} |khat_n-k_h,n| <= C_inv sum_{n<=m}|eta_n|.      (N7)

Proof: apply the projection inequality at each n; replace A_n by A_min; use
the strictly causal B_h convolution majorant; take the weighted l1 norm and
absorb its factor rho<1. Remove the weight by exp(lambda L).

Per-bin clipping ensures nonnegativity and the density cap, but need NOT
ensure sum khat_n<=1. Do not hide this. If a probability-submeasure estimate
is desired, set

    kbar_n = khat_n / max(1,sum_{j<=m}khat_j).                 (N8)

This preserves the cap and makes the prefix mass at most one. Since the true
prefix mass is at most one, ||kbar-k_h||_1<=2||khat-k_h||_1. The missing mass
can be assigned to the unobserved tail without identifying its shape. The
post-repair estimate generally no longer has the same fitted endpoint as the
pre-repair causal sweep; any reported residual must use the final estimate.

### O(m^2) implementation using the algebraic inverse

Let q=exp(-gamma h), w_0=1, p_0=exp(-a), z_n=1-q^n and
d_n=exp(-a q^n)-exp(-a). With previously CLIPPED coefficients, form

    T_n = sum_{j=1}^{n-1} khat_j w_{n-j},
    S_n = sum_{j=1}^{n-1} p_j w_{n-j},
    A_n = d_n/z_n,
    raw_n = (Y_n+S_n)/A_n-T_n,
    khat_n = clip_[0,Mh](raw_n),
    w_n = (khat_n+T_n)/z_n,
    p_n = A_n(khat_n+T_n)-S_n.                                (N9)

The sequence p is the exact endpoint generated by the pre-repair khat, in
exact arithmetic. Every finite lattice has a positive minimum jump, so the
previous algebraic identities apply even when its continuous limit violates
SC. Equation (N9) uses O(m^2) arithmetic and O(m) storage.

Finite-precision cancellation remains a separate issue. This is not a theorem
that double precision always suffices. An arbitrary-precision implementation
and comparison to an independent forward evaluator are appropriate when W is
large. The statistical bound controls data error, not roundoff in (N9).

### A posteriori numerical defect and a practical precision policy

For ANY computed pre-repair vector x in [0,Mh]^m, evaluate p=F_h(x) with an
independent, nonnegative uniformization forward calculation. Define

    delta_n = p_n-Y_n                    if 0<x_n<Mh,
              min(0,p_n-Y_n)             if x_n=0,
              max(0,p_n-Y_n)             if x_n=Mh.            (N9a)

Then x is EXACTLY the causal clipped estimator (N6) for data Y+delta. This is
the scalar clipping optimality condition at every coordinate, and G_n uses
the same x-prefix. Thus the numerical error enters (N7) simply as an extra
endpoint perturbation ||delta||_1. A small residual at an active bound is not
required in the wrong direction; (N9a) uses the correct one-sided violation.

Uniformization here uses the nonnegative matrix

    P=I-D+C_x D,
    F_h(x)=exp(-a) sum_{r>=0} a^r P^r e_0/r!.

Even if the pre-repair prefix mass exceeds one, ||P||_1<=R=max(1,sum x_n).
Truncating at r=J has l1 error at most

    exp(a(R-1)) P(Poisson(aR)>J).                             (N9b)

The forward calculation therefore avoids the subtractive renewal cancellation
and has an explicit series-tail bound. Floating-point roundoff in this check
must still be budgeted; an ordinary double computation is a diagnostic, not a
formally certified enclosure. Interval evaluation or a justified nonnegative-
summation rounding bound could provide such an enclosure.

An implementable policy is to run (N9), inspect the defect with this separate
forward calculation, and increase arithmetic precision until the defect is
negligible relative to the sampling/modeling budget. Fixed-grid convergence
as precision increases follows from continuity of finitely many arithmetic
operations and clipping. This is NOT a uniform O(m^2) BIT-complexity theorem:
required precision and multiplication cost remain explicit computational
qualifications, especially for small gamma or dense near-parent jumps.
The current prototype accepts q as a supplied double-precision number and
preserves that input when increasing internal precision. It does not recover
digits already lost when q was formed. For extremely fine grids, q should be
formed from gamma*h at the working precision (or passed as a logarithm); the
present interface does not promise that refinement. Error in supplied q is
equivalently a rate-parameter error, covered only when its size is bounded.

There is at least a useful intermediate-size bound. If lambda>=2M and every
coefficient is capped by Mh, write b_j=K_hat_h(lambda+j gamma). Then
b_j<=M/(lambda+j gamma)<=1/2 and

    sum_j b_j <= M/lambda
                  +(M/gamma) log(1/(1-exp(-lambda h))),
    sum_j b_j^2 <= M^2[1/lambda^2+1/(gamma lambda)].

The first inequality follows by summing each positive log-bin geometric series
and using 1/(1-exp(-x))<=1+1/x; the second follows from integral comparison.
Since -log(1-b)<=b+b^2 for 0<=b<=1/2, the exact renewal norm satisfies

    ||W||_lambda <= exp(M/lambda+M^2/lambda^2+M^2/(gamma lambda))
                    * (1-exp(-lambda h))^(-M/gamma).

Thus, at fixed positive gamma and fixed cap M, its growth is at most polynomial
in 1/h, rather than a proof of exponential-in-grid-size blowup. This bound
alone is NOT a backward-error analysis of the full clipped program and is NOT
used to claim a bit-complexity guarantee. The forward-defect check remains
the practical safeguard.

## 5. Continuous-to-lattice endpoint bias: a direct coupling bound

Let P_T be the continuous endpoint law, B_h P_T its ceiling-bin probability
sequence, and F_h(k_h) the exact endpoint of the process whose jumps were
individually quantized. Quantizing a sum is NOT the same as summing quantized
jumps, so these two distributions cannot simply be identified.

The path coefficient obeys the uniform derivative bound

    |partial H_r/partial u_i| <= gamma(r+a) a^r/r!.            (N10)

Indeed, differentiating the product of pre-jump rates contributes at most
gamma r in logarithmic derivative, and differentiating the survival factor
contributes at most gamma a because its waiting intervals sum to T.

Compare each r-jump contribution in two steps:

1. Replace H_r(u) by H_r(Q_h u_1,...,Q_h u_r). The increments each move by at
   most h, so the l1 error is at most

       h r gamma(r+a) a^r/r!.

2. Compare Q_h(sum u_i) with sum Q_h(u_i) while keeping the continuous weight.
   Condition on the first r-1 increments. Their summed rounding displacement
   is at most (r-1)h. The weighted density of the final increment is
   g(v)=k(v)H_r(u_1,...,u_{r-1},v), extended by zero for v<0. Its total
   variation is bounded by

       TV(g) <= (a^r/r!)[V+gamma(r+a)].

   Translation of a BV density by delta changes its L1 norm by at most
   |delta| TV(g), and binning is a contraction of total variation. Therefore
   this step costs at most

       h (r-1)(a^r/r!)[V+gamma(r+a)].

Integrate over the earlier increments (their joint probability mass is one),
sum r>=1, and note that the r=0 atom is identical. This proves

    ||B_h P_T-F_h(k_h)||_l1 <= h C_forward,

    C_forward = gamma[4a^2 exp(a)+a]
                + V[(a-1)exp(a)+1].                          (N11)

The formula follows by summing the elementary exponential-series moments of
r and r^2. It is deliberately conservative. Restricting to observed bins only
decreases the bound. This accounts for both rate changes after rounding and
the noncommutation of binning with addition; it is not an inverse-crime
assumption.

## 6. Sampling error and the statistical statement

For independent tags, bin counts are multinomial. If p=B_h P_T, then

    E sum_{n=1}^m |Y_n-p_n|
       <= sum sqrt(p_n(1-p_n)/N) <= sqrt(m/N).                 (N12)

This is a finite-vector histogram bound. It does NOT claim that empirical
atomic measures converge in total variation to a continuous density.

Let kbar_h(s)=kbar_n/h on ((n-1)h,nh]. The exact cell-average density differs
from a BV density by at most h V in L1. Equations (N7), (N8), (N11), (N12)
therefore imply the fully stated risk bound

    E ||kbar_h-k||_L1(0,L)
      <= h V + 2 C_inv [sqrt(m/N)+h C_forward].               (N13)

Choose m of order N^(1/3), h=L/m. For fixed a,gamma,L,M,V this is
O(N^(-1/3)). The factor 2 can be removed if no mass repair is requested.
The sample size N here is an independent calibrated mass-tag count, not an
unqualified number of correlated physical daughter fragments.

### Rate misspecification is an additional bias, not identified away

Suppose the true rates use alpha,gamma but inversion uses alpha',gamma', all
positive. On the observed prefix [0,L],

    sup |alpha exp(-gamma s)-alpha' exp(-gamma' s)|
       <= epsilon_rate := |alpha-alpha'|
                          +max(alpha,alpha') L |gamma-gamma'|.

Couple the two processes with the same dominating Poisson proposal clock and
the same proposed increments. While their states agree in [0,L], their
acceptance decisions differ at rate at most epsilon_rate. Once both have left
the observed prefix, treat them as one absorbing tail category. This gives

    ||B_h P_true-B_h P_assumed||_l1 <= 2T epsilon_rate.

Accordingly, use the constants for the ASSUMED rate in (N13) and add
2T epsilon_rate inside its square brackets. This is a sensitivity bound given
a rate-error bound, not a procedure identifying alpha or gamma from these
data. The earlier finite-prefix unknown-gamma aliases remain relevant.

## 7. Exact scope of the broader capability

This continuation covers bounded-BV kernels with positive near-parent density,
and avoids estimation of the boundary value b. It supplies a direct quadratic
arithmetic algorithm, a nonnegativity/density-cap policy, a transparent mass
repair, explicit error propagation, a continuous/lattice modeling bound, and
a histogram sampling bound. It does not identify unknown gamma, undo unknown
instrument blur, remove ancestor correlations, or give a uniform floating-
point guarantee. Constants are pessimistic and numerical validation is not
experimental validation. Preserve these restrictions in any presentation.

## 8. Targeted implementation checks

`causal_clipped_inverse.py` implements the exact recurrence, optional explicit
precision escalation, mass repair, and the separate classical-forward defect.
`no_sc_noise_test.py` and its JSON output use a fixed seed. This is a small
targeted continuation, not a new broad benchmark or independent audit.

- The closed expression for C_forward agrees with direct summation of its
  path-series bound to 2.9e-14 in the three checked parameter settings.
- A half-uniform/half-Beta(3,3) binary daughter law has k(0+)=1, violates SC,
  and fits the prescribed M=2 density cap. Its continuous forward density is
  calculated by classical uniformization with fine trapezoidal quadrature,
  then integrated over the actual CEILING bins. The measured continuous/lattice
  endpoint discrepancies were 0.00868, 0.00440, 0.00221 at h=0.08,0.04,0.02.
- Multinomial histograms of this independent continuous forward model were
  recovered without supplying or estimating k(0+). At N=100,000, h=0.08,
  mean prefix L1 error against true cell masses was 0.02535 over 12 replicates.
  Finer bins had higher sampling error, as the risk decomposition predicts.
  These cell-mass errors do not include the separate density histogram bias hV.
- In a small-gamma lattice stress test, double-precision clipping produced a
  plausible bounded vector but a large independent numerical defect: 3.575 at
  gamma=0.02. Forty decimal digits still failed (defect 0.876); 80 digits
  reduced the diagnostic to 9.5e-17. The intermediate W maximum was 1.3e40.
  This explicitly demonstrates why clipping alone cannot certify numerics.
- At gamma=0.1, 40 digits sufficed; at gamma=1.3, doubles sufficed. The reported
  precision choices are empirical for those cases. No uniform bit-complexity
  or formally certified interval enclosure is claimed.

The checks used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, and mpmath 1.3.0.
Run from this directory:

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python no_sc_noise_test.py

The original checked SC archive has not been changed by this continuation.
