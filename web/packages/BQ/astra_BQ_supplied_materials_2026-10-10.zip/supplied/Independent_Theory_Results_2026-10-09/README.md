# Independent theoretical results, 9 October 2026

Two complete mathematical arguments with reproducible checks are preserved here. Each received one focused AI-assisted mathematical check. These are not external expert reviews or formal certification. Historical novelty remains provisional after targeted primary-literature comparisons. Neither result is claimed to meet the programme's historic foundational objective.

## 1. A counterexample to Han's auxiliary Boolean split question

The explicit balanced monotone 4-bit gate, recursively composed to depth d, has 4^d variables and every coordinate satisfies A_i/I_i >= d/2, with equality for some coordinate. This gives a negative answer to the universal coordinate-selection bound in Han's Question 3.1, arXiv:2312.08271v2. The full Fourier Entropy–Influence conjecture remains open: this very family satisfies H/I=6(1-(2/3)^d)<6. Balanced composition itself is established mathematics; the claimed contribution is this explicit all-coordinate counterexample, subject to priority verification.

Start with boolean_split/PROOF.md. Both Python checks use exact integer Walsh arithmetic; run them from their directory. The focused check clarifies the current primary-source comparison and the distinct normalizations in the 2026 follow-up paper.

## 2. Quantitative reconstruction from one-dimensional Gaussianity tests

For centered isotropic distributions in dimension d>=2 with fixed two-sided potential-Hessian bounds mI <= Hess V <= MI and m<1<M, let S be the average one-dimensional marginal relative entropy to a standard Gaussian. The proof bounds full joint relative entropy by a power of S, with logarithmic factors. The supremal uniform pure-power exponent is min(1/2,4/(d+3)): every strictly smaller exponent works, and every larger exponent fails. The log-free bound at the endpoint exponent remains unresolved. In dimension one S equals the joint relative entropy, so that case is separate.

Start with entropy_reconstruction/PROOF.md, especially the final full-class theorem (C15). Earlier compact-perturbation results and exploratory counterfamilies are preserved with their narrower scopes. The harmonic script is a numerical sanity check of a redundant analytic obstruction, not a proof substitute. Presentation corrections after the focused check do not change the checked theorem; the check records the exact source hash it inspected.

## Status and provenance

Both constructions were pursued independently of Astra/OpenAI manuscripts. Primary literature is linked in the proofs. No publication, repository push, or researcher contact has occurred. SHA256SUMS.txt records the exact included files.
