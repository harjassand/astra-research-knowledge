# Precise boundaries and finite optimizer counterexamples

The stated T1/T2 inequalities survive. These counterexamples distinguish them from stronger claims that the wording "extremizing family" might suggest, or that a mean-Casimir replacement would incorrectly permit.

## The proposed family is not the exact optimizer at r=2: even N

Let `v=(1-2a_N/N)/(N-1)>0` and p1 be the exact white probability of spin j=1. The proposed sectorwise ±j mixture has b=0, pair C=diag(-v,-v,2v), and chi(r=2)=6v^2.

Change only its spin-one sector to the pure state `(|1,1>+|1,-1>)/sqrt(2)`. Its mean is still zero. Its second moments change from `(1/2,1/2,1)` to `(1,0,1)`, with zero symmetrized cross moments. Thus the total pair C changes to

`diag(-v+e,-v-e,2v)`, where `e=2p1/[N(N-1)]>0`.

At b=0 the Gram is I and, for r=2, there are no higher-degree terms. Consequently the chi-square increases by exactly `2e^2>0`. The modified state retains every white sector weight and the identity on multiplicity spaces. At N=256 its exact rational increase is approximately `2.1986720564107873e-14`. N=512 is another tested legal instance. The exact fractions are retained in `independent_checks.json`.

## The proposed family is not the exact optimizer at r=2: odd N

Let p_half be the white spin-j=1/2 probability. Change only that sector from its maximally mixed ±1/2 mixture to the pure +x spin state. A spin-one-half state's symmetrized second moments are always delta_ab/4, so this changes no global symmetrized second moment or c_ab. It creates `b=(t,0,0)`, with `t=p_half/N>0`.

Accordingly `C=diag(-v-t^2,-v,2v)`. The correct complex Gram gives

`chi(r=2)=[6v^2+2v t^2+t^4+4v^2t^2]/(1-t^2)^2`.

Its difference from the proposed family's value 6v^2 is exactly

`t^2[2v+16v^2+t^2(1-6v^2)]/(1-t^2)^2>0`.

For the stated range, v<=1/(N-1), hence 1-6v^2>0. All other factors are strictly positive. At N=257 the increase is approximately `2.564293663643409e-13`; N=513 is another tested legal instance. Exact four-by-four rational reference inversion and matrix products verify the formula independently of the inverse-Gram derivation.

These corrections do not contradict P12, which states an exact contribution of the displayed family and a lower bound on the supremum. In a manuscript use "asymptotically extremizing family" or "sharpness witness" unless a finite optimizer is proved separately.

## A mean-Casimir promise cannot replace white sector weights

For even N, assign weight `alpha=3/(N+2)` to the spin-N/2 sector, in its ±N/2 mixture, and all remaining weight to spin zero with its multiplicity identity. This is a legal permutation-invariant state but has nonwhite sector weights. Its one-body state is I/2 and its exact Casimir is

`alpha*(N/2)(N/2+1)=3N/4`.

Its pair tensor is `diag(-1,-1,2)/(N+2)`, so its two-body contribution at r=4 is `36/(N+2)^2`.

In the spin-zero sector, J_z=0. The symmetrized four-site z product is the elementary symmetric polynomial B4 in the ±1 local z observables, evaluated at total sum zero. Its value is exactly `3/[(N-1)(N-3)]`, obtained from the fourth coefficient of `(1-z^2)^(N/2)`. In the highest/lowest cat sector that product is one. Therefore

`d_zzzz=3(N-2)/[(N+2)(N-3)]`.

With G=I, nonnegativity of all support contributions gives

`chi(r=4)>=36/(N+2)^2 +9(N-2)^2/[(N+2)^2(N-3)^2]`.

Thus `liminf N^2 chi(r=4)>=45`, whereas the white-law target is 3*4*3=36. This is a proof-level failure of the weakened premise, not a finite-sample inference.

There is also an exact finite violation of the proposed remainder under this weakened premise at N=100000000, r=4. The square root of N is exactly 10000. Exact rational arithmetic shows that the lower bound minus `36/N^2` is strictly larger than `42*16/[N^2*10000]+900000*64/N^3`. The state is supplied by only two explicit sectors; no Hilbert-space matrix of that dimension is materialized. The certificate is recorded in `independent_checks.json`.

The new covariance bound uses only the Casimir mean, as the report correctly says. The cubic tail and the final sharp theorem still require the full white law. A proof that silently replaced it by the moment condition would be false.

## Fixed r and growing r are different limits

The reviewed theorem gives `M(N,r)/(r/N)^2 ->3(1-1/r)` for fixed r. In particular r=2 has limit 3/2, not 3. The coefficient 3 in q^2 requires r->infinity as well as q->0. The report includes both conditions correctly. A claim of 3 for every sequence r=o(N), allowing fixed r, would be false.

Sharpness of the Petz chi-square upper envelope does not by itself show that its KL upper bound, an associated trace-distance estimate, or an operational testing constant is attained. Those stronger conclusions are explicitly outside this audit and are not established by any of the examples above.
