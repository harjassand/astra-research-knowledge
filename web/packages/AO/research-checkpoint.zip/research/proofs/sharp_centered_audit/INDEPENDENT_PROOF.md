# Reconstruction of the new sharp step

The frozen report is exposed to this auditor. Its new covariance bound, cubic tail calculation, lower construction, and limiting quantifiers were reconstructed independently. The earlier centered coefficient/Gram lemma remains a dependency with the exact previously audited hashes in `frozen_inputs.json`. No candidate check code or integration comment was used before verdict freeze.

## Covariance and the pair contribution

Let S_ab denote the real symmetrized expectation of J_a J_b, and let mu=Tr rho J. For a real vector u, `u^T(S-mu mu^T)u=Tr rho [u.(J-mu)]^2>=0`. Thus V=S-mu mu^T is a real positive semidefinite matrix. Permutation invariance gives `b=2mu/N`, real symmetric c_ab, and

`4S=N I+N(N-1)c`.

The local terms use `{sigma_a,sigma_b}/2=delta_ab I`; the N(N-1) ordered distinct-site terms all have the same expectation c_ab. There is no unsymmetrized imaginary collective covariance in this equation.

Put `X=4V/N` and `Z=X+b b^T`. Direct substitution yields

`Z=I+(N-1)(c-b b^T)=I+(N-1)C`.

Both X and Z are positive semidefinite. Exactly white weights imply `Tr rho J^2=3N/4`; this also follows from the normalized full Hilbert-space trace of J^2. Hence

`Tr X=3-N|b|^2`, `Tr Z=3-(N-1)|b|^2`, and `|b|^2<=3/N`.

Write s=Tr Z. It lies in [0,3]. Its nonnegative eigenvalues satisfy `Tr Z^2<=s^2`; therefore

`||Z-I||_F^2<=s^2-2s+3<=6`.

The last convex quadratic has endpoint values 3 and 6 on [0,3]. Consequently `T_2=||C||_F^2<=6/(N-1)^2`. This argument depends only on permutation invariance and that mean Casimir value. It does not by itself control higher centered tensors.

For N>=256, `t=|b|<=sqrt(3/N)<1/9`, so tau=(I+b.sigma)/2 and every tensor product reference have full support. In the correct conjugate-linear-first operator inner product `Tr tau U^dagger V`, the local Gram is

`G_ab=delta_ab-b_a b_b+i epsilon_abc b_c`.

It has eigenvalues 1-t,1+t,1-t^2. The centered Parseval identity previously audited is exact even when rho_r does not commute with tau^tensor r. It uses `R=(rho_r-tau^tensor r)(tau^tensor r)^(-1)`, zero constant and one-body coefficients, and inverse complex Gram matrices on each support. Thus

`chi_2=binomial(r,2) d_2^dagger(G^(-1) tensor G^(-1))d_2`

is at most `3r(r-1)/[(N-1)^2(1-t)^2]`. Both the factor 3 and r(r-1) come from multiplying the pair norm bound 6 by the number of unordered supports r(r-1)/2.

As an additional direct check, with `B_ab=epsilon_abc b_c`, one has `B^2=b b^T-t^2 I`, hence

`G^(-1)=(I-iB)/(1-t^2)`.

The imaginary antisymmetric part cannot be replaced by the inverse of the real covariance. For diagonal C and b=(t,0,0), the exact pair form is

`[C_xx^2+C_yy^2+C_zz^2-2t^2 C_yy C_zz]/(1-t^2)^2`.

The fresh odd-parity counterexample in `COUNTEREXAMPLES.md` verifies this identity using exact four-by-four rational matrices.

## Uniform higher-degree remainder

The preserved centered coefficient lemma is

`T_k<=36k^2 4^k(2k+1)!!/[k! binomial(N,k)]`.

Its full-white-weight transfer, polynomial-grid bound, and real symmetric sphere contraction were previously reconstructed in this auditor's `centered_audit` package. The present argument does not substitute a mean-spin or mean-Casimir promise for that lemma. Combining it with the exact centered Gram decomposition and `binomial(r,k)/binomial(N,k)<=(r/N)^k` gives, with `x=4(r/N)/(1-t)`,

`chi_(>=3)<=36 sum_(k>=3) k^2 (2k+1)!! x^k/k!`.

All coefficients are nonnegative and x<=9/256<1/2, so extending the finite support sum to the absolutely convergent power series is uniform over all legal states, N and r. Starting from `(1-2x)^(-3/2)` and applying `(x d/dx)^2` gives

`36 sum_(k>=3) k^2(2k+1)!!x^k/k! =108x[g(x)-1-10x]`,

where `g(x)=(1+3x)(1-2x)^(-7/2)`. The removed terms are exactly 108x and 1080x^2. Direct differentiation gives

`g'(x)=(10+15x)(1-2x)^(-9/2)`,

`g''(x)=105(1+x)(1-2x)^(-11/2)`.

On the full interval, `g''(x)<=(105*265/256)(128/119)^6<180`. The last comparison is rational. Integral Taylor remainder about zero now proves

`chi_(>=3)<=9720x^3<=9720(9/2)^3(r/N)^3=885735(r/N)^3`.

This is a finite uniform tail estimate, not an exchange of a state-dependent or N-dependent asymptotic expansion. For r=2 the actual tail is empty; the nonnegative cubic allowance is harmless.

## Legal lower family, both parities

Use the white weights and within each spin sector the equal mixture of extremal z weights ±j. For j=0 the two identical terms form the same normalized projector. For half-integer j, including j=1/2, the two states are distinct and the mixture is valid. Every sector mean is zero, so b=0 and G=I.

In a spin-j highest/lowest weight state, the second moments are `(j/2,j/2,j^2)`. Cross symmetrized moments vanish. For `a_N=sum p_j j`, the white Casimir identity gives `sum p_j j^2=3N/4-a_N`. Hence

`C=v_N diag(-1,-1,2)`, `v_N=(1-2a_N/N)/(N-1)`.

Its pair contribution is exactly `3r(r-1)v_N^2`. All higher support contributions are nonnegative, proving the stated lower bound on M. Cauchy-Schwarz gives `a_N<=sqrt(sum p_j j^2)<=sqrt(3N/4)`, so `1-2a_N/N>=1-h_N>0`. No parity-dependent approximation, distributional limit, or exchange of maximization and limit is needed.

The family is asymptotically extremizing for the two limits below. It is not an exact finite-N optimizer: there are explicit improvements at r=2 in both parities. The report only uses it for a lower bound, so those improvements do not invalidate the theorem.

## Finite remainder and limit quantifiers

Set `A0=3r(r-1)/N^2`, h=sqrt(3/N), q=r/N. The lower bound implies `M/A0>=(1-h)^2>=1-2h`. For the upper pair bound,

`(1-1/N)^(-2)(1-h)^(-2)<=(1-h)^(-4)<=1+8h`.

Here 1/N<=h, h<1/9, and the derivative `4(1-h)^(-5)` is at most `4(9/8)^5<8` on [0,1/9]. Thus

`M-A0<=24sqrt(3)q^2/sqrt(N)+885735q^3`,

while `A0-M<=6sqrt(3)q^2/sqrt(N)`. Since `24sqrt(3)<42`, their combination gives the proposed absolute remainder `42q^2/sqrt(N)+900000q^3` exactly as stated.

There is an explicit relative bound `|M/A0-1|<=28/sqrt(N)+600000q` for every r>=2 in the range. The large numerical constants make this bound loose at q=1/128; they do not affect its uniform validity or the two asymptotic conclusions.

For fixed r>=2, multiplying the remainder by N^2 gives terms of order `r^2/sqrt(N)` and `r^3/N`, both tending to zero. The unscaled remainder is O_r(N^(-5/2)). This holds along even and odd N.

For r_N->infinity and r_N=o(N), the sequence eventually satisfies 2<=r_N<=N/128. Divide by q_N^2. The remainder becomes at most `42/sqrt(N)+900000q_N`, tending to zero, while the leading coefficient is `3(1-1/r_N)->3`. The condition r_N->infinity is essential: at fixed r the coefficient of q^2 is `3(1-1/r)`, not 3. At r=1 rho_1 equals its own reference exactly and the centered divergence is zero, including its support-defined zero extension.

The class is compact for every fixed N, and the references have a uniform positive lower eigenvalue there, so the supremum actually has a maximizer. The proof establishes its leading constant by a uniform upper bound and a legal asymptotic lower family; it does not identify that finite maximizer. No sharp KL, trace-distance, testing, or certification constant follows merely from this sharp Petz bound.
