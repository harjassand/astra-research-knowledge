# Adversarial audit of the sharp centered white-law constant

**Verdict: the exact T1/T2 theorem and both stated limits pass this internal proof-level audit.** No failing inequality or overstrong limiting quantifier was found under exactly white Schur weights, N>=256, and 2<=r<=N/128. There is a concrete correction to any finite-optimizer interpretation: the displayed ±j mixture is asymptotically extremizing but is not an exact finite-N optimizer, even at r=2, for either parity.

Target SHA-256: `6b6e44d0261f096a652bf2d984b3d1a6711aca31c8c90e3da7f385075b7dadce`. The earlier centered coefficient and complex-Gram theorem remain explicitly preserved dependencies, with target hash `e652080b59e07a58fa091f2e7b769c14376d49f90482cf6fc227a38cd80c7e2a` and its prerequisite `6a80aa93ea2097a34d2338b9327cca75378c30e0532d98e8e8b4eaae1d8d1645`. These hashes were rechecked. This audit reconstructs the new step; it does not treat internal agreement as proof or reclassify the dependency as externally validated.

## Load-bearing conclusions

- **Frozen lines69-107, covariance and trace: valid.** The real symmetrized V is positive semidefinite; `Z=4V/N+b b^T=I+(N-1)C` is also positive. White Casimir gives trace Z=3-(N-1)|b|^2 in [0,3]. Nonnegative eigenvalues prove `||Z-I||_F^2<=6`, including nonzero means and arbitrary sector coherences. This bound itself only uses the mean Casimir.
- **Lines111-144, complex Gram: valid.** Its minimum eigenvalue is 1-t, reference support is uniform, and inverse-Gram Parseval gives the pair coefficient `3r(r-1)`. There is no commutation assumption. Fresh valid noncommuting four-by-four cases separately confirm the formula; a real-Gram substitution changes the answer.
- **Lines148-222, tail dependency: preserved.** Its previously audited full-white-law transfer remains required. The new moment-only covariance estimate cannot replace that distributional premise.
- **Lines226-249, cubic remainder: valid.** Reconstructing the generating function removes exactly 108x and 1080x^2. The second derivative is `105(1+x)/(1-2x)^(11/2)`; its rational bound is below180 on the whole interval. Taylor gives9720x^3, and `9720(9/2)^3=885735` exactly. The positive power series is uniformly convergent for x<=9/256.
- **Lines256-278, lower witness: valid for both parities.** The extremal-weight mixtures give b=0 and C=v diag(-1,-1,2). Their pair contribution is exactly P12. The bound on a_N needs no spin-distribution limit.
- **Lines282-300, finite bound and limits: valid.** The factor correction is at most1+8h, with `24sqrt(3)<42`. Fixed r has coefficient3r(r-1) and remainder O_r(N^(-5/2)); growing r requires both r->infinity and r=o(N). All parity sequences are covered by the same inequalities.

An explicit relative bound is `|M/[3r(r-1)/N^2]-1|<=28/sqrt(N)+600000r/N`. The finite cubic constant is large; the coefficient3 is an asymptotic conclusion as stated, not a tight numerical approximation at the endpoint r=N/128. The report correctly makes no sharp KL, testing, or certification claim.

## Fresh counterexamples and independent checks

`COUNTEREXAMPLES.md` gives exact legal finite optimizer improvements. At even N, replacing the spin-one ±1 mixture by its coherent equal superposition keeps b=0 and raises chi(r=2) by `2[2p1/(N(N-1))]^2>0`. At odd N, making the spin-one-half sector pure along x changes no collective second moment, creates t=p_half/N, and raises the correct centered chi by

`t^2[2v+16v^2+t^2(1-6v^2)]/(1-t^2)^2>0`.

Exact rational matrix checks certify the increases at N=256,257,512,513. The N256/257 increments are about2.20e-14 and2.56e-13; their positivity is exact, not a floating-point claim. These do not refute T1: the theorem uses the mixture only as a lower witness. Rename the section at frozen line254 to "asymptotically extremizing family" if a finite optimizer could otherwise be inferred.

A second exact counterexample shows that the full white premise is essential. For even N, a spin-N/2 cat mixture of weight3/(N+2), with all remaining weight at spin zero, is PI with b=0 and mean Casimir3N/4. It has `liminf N^2 chi(r=4)>=45`, while the white-law leading coefficient is36. At N=100000000, r=4, exact rational arithmetic even violates the proposed finite remainder under this weakened premise. This state is outside C_N and is not a counterexample to the actual theorem.

The newly written `independent_checks.py` imports no target code. It checks the two strict optimizer improvements by exact four-by-four rational products, verifies the tail-series coefficients and rational constants, and independently constructs12 valid white-sector cases over N=256,257,384,385,512,513. The maximum numerical Parseval residual is1.16e-19; a noncommuting case has commutator norm7.90e-6, and invalid real Gram substitution differs by2.10e-7. These support finite arithmetic and normalization only; the supremum and uniform bounds follow from `INDEPENDENT_PROOF.md`.

## Scope and provenance

The own verdict was frozen before any integration comment was read. Original target and dependency files were preserved; no descendants were spawned. The proof was visible, so this is an exposed internal adversarial reconstruction, not a new blind discovery, formal replay, external validation, or priority audit.

No mathematical repair of T1/T2 is required. The exact finite maximizer, an optimized remainder, external correctness, historical priority, and any sharp relative-entropy or operational-testing constant remain UNKNOWN. The proposed lower family is a valid asymptotic sharpness witness despite its demonstrable finite suboptimality.
