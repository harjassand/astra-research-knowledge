# Pre-exposure self-audit

This is an independent reconstruction, not an independent human or formal audit.
The candidate and audit directories named in the assignment have not been read.

The load-bearing source tests were rechecked directly:

* With A+2B absent and 2A+B present, (1,2) has value 4 exactly at 2A+B and 2B,
  then value 3 at 3A and A+B, then value 2 at 2A and B. Tier descent only occurs
  after every arrow at an earlier tier is individually known to conserve weight.
* With both mixed cubic sources absent and 2B present, (2,3) has value 6 at 3A
  and 2B, 5 at A+B, and 4 at 2A. The direction (1,2) is used only when 2B is
  absent and A+B present. Direction (1,3) is used only when both quadratic
  B-containing sources are absent and B is a source.
* Cubic products have total at most three. At 3A every nonidentity arrow
  decreases A. At A+2B, e_B gives B nonincrease; if its aggregate B drift is
  zero, all its arrows are exactly (-1,0). At 2A+B, (1,2) zero-weight cubic
  arrows are exactly (-2,+1).

Possible coefficient cancellations are handled at the correct individual or
aggregate level. A zero aggregate of individually nonpositive weighted drifts
implies all individual weighted drifts vanish, because all constants are
positive. No such implication is used without an earlier directional sign.
All parameter choices are sequential: geometry and positive rates fix angular
collars and epsilon; then K fixes the finite-A correction; then its exterior
multiple L can be chosen uniformly because the exterior error is C(1+K)N^3.
In the written proof L is first set from the K-independent C, and K afterwards.

The discrete estimates were checked as follows. For the fixed-A cutoff,
Delta(a-K)_+<=max(d_A,0) and it vanishes for both endpoints if a<=K-D.
The exact increment of q(a^2+b^2)+2b f(a) has its only leading b term equal to
2b[q d_B+Delta f]; all remaining terms are bounded for bounded a. Multiplication
by a b(b-1) consequently gives the stated cubic b^3 coefficient, with bounded
a times b^2 error. The source 2B's positive b^3 coefficient occurs only on the
strip a>K-D, where K is chosen to pay it using the mixed cubic source.
The product cannot have a negative coordinate when the source is enabled.

For the angular interpolation, the sign of the derivative correction is
chi' >=0, D(a/b)<0, and W0-W1>=0. The function is exactly diagonal on a full
angular neighborhood of the B axis. Bounded jumps from its deeper collar stay
inside this neighborhood for large N, so there is no uncontrolled N^3 Taylor
error in the discrete boundary strip. The remaining exact diagonal error has
the mixed form a^3+a^2 b+ab^2; pure b^3 is excluded by B nonincrease at 2B.
At a=0 the mixed cubic is disabled, and all positive remaining terms are only
O(1+b^2). At b=0 or b=1, exact factorial corrections are included in the
polynomial remainder and the A-axis pure cubic controls large a.

The most valuable external checks are: verify every polynomial Lyapunov branch
in Case I, verify the Hessian/finite-jump argument in Case II.2, and verify the
uniform exterior constant in Case II.1. These are audit targets, not asserted
gaps. No probabilistic holding-time construction is needed after Foster is
proved, because bounded total rates on finite sets rule out explosion there.

No conclusion is made for three or more species, for time-varying rates, or for
networks that are endotactic only in the positive orthant. Only full directional
endotacticity justifies the essential-source tier tests used here.
