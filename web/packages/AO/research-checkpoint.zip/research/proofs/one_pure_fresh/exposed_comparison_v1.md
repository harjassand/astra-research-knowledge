# Exposed comparison after the independent freeze

The independent proof, self-audit and provenance were hashed at 11:58:48 UTC
before reading `cubic_one_pure_blind/proof_v1.md` or its self-audit. Their hashes
are in freeze_manifest_v1.json. Neither independent frozen file was changed.
The present comparison is argument-exposed and is not another blind proof.

The original candidate has the same theorem and source-face classification.
Its Case I uses a particularly economical degree-one piecewise ellipse/linear
Lyapunov function for A+2B present. The fresh proof instead uses degree-two
fixed-A truncation or angular interpolation. The original's Case II uses
entropy estimates on tangent fast-transfer faces; the fresh Case I supplies a
complete polynomial replacement for all those configurations.

Exact reusable lemma: if 3A is present, 3B and A+2B are absent, then full
endotacticity and source order <=3 imply a norm-like polynomial Foster function
from the linear weights a+2b, 2a+3b, a+3b and their squares with a small or large
diagonal perturbation. The necessary sign and rate branches are written in
fresh proof Case I. No logarithmic flux balance, ratio-subsequence argument,
or entropy correction is required. This lemma replaces original IIa--IId.

The original A+2B-present function was checked directly. Its values and first
derivatives agree at both joins. Its Hessian is O(1/N) on each piece, hence
the gradient is Lipschitz across joins and finite-jump Taylor error is O(1/N).
In the B collar, its A derivative is O(a/b), suppressing positive pure 2B
births; their exact contribution is O(ab+b). Cubic factorial/Taylor errors
are O(ab+a^2+a^3/b), which are O(ab) in that collar. The strict transition-band
argument in self_audit_v1.md resolves the point where the gradient ratio reaches
one: total cubic loss supplies the required negative drift there. Disabled
rates at a=0 and b=0 are treated exactly. I find no gap in original Case I.

The original tangent-source enumerations and entropy alignment factors were
also checked. At (1,2), zero-weight 2A+B arrows are exactly (-2,+1), and 2B
zero-weight arrows are (+2,-1) or (+4,-2). At (2,3), the only zero-weight top
transfers are 3A <-> 2B. The entropy shift in each face aligns the weighted
aggregate forward/backward flux. I found no contradiction in the displayed
outer-ratio estimates. The complete independent polynomial replacement makes
those estimates unnecessary for the conclusion, so this bounded comparison
should not be described as a line-by-line independent audit of every entropy
limit in original Case II.

A shorter synthesis is therefore available: original Case I's degree-one
piecewise ellipse for A+2B present, followed by the fresh polynomial lemma for
A+2B absent. This conclusion does not assume any result from the separate
argument-exposed audit. External validation and novelty remain UNKNOWN.
