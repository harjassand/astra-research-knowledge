# Fresh one-pure cubic nonexplosion argument

Status: independently reconstructed proof candidate, frozen before access to either
`cubic_one_pure_blind` or `cubic_one_pure_audit`. It is not external validation.
The derivation uses the author's earlier no-pure and both-pure analyses only for
general Foster and falling-factorial bookkeeping, not their one-pure successors.

## Statement and conventions

A finite two-species fully endotactic reaction network with source order at most
three, a nonidentity source 3A, and no source 3B is nonexplosive for every finite
initial state and every choice of fixed positive finite mass-action constants.
Products are arbitrary nonnegative integral vectors. Delete identity arrows.
All constants below may depend on this finite network and its rates.

Write x=(a,b), N=a+b and d=(d_A,d_B) for an arrow increment. The generator is
L V(x)=sum k_r a_(s_A) b_(s_B) [V(x+d_r)-V(x)]. Negative coordinates are never
entered because an enabled reaction consumes its source. D bounds all absolute
increments. Essential-source endotacticity means that, for a direction w, arrows
with w.d=0 are omitted and an arrow with w.d>0 cannot have a maximal w.source.
In particular, every arrow at a source maximizing w.source has w.d<=0.
After removing all zero-w arrows at higher tiers, the same rule applies below.

It suffices to construct a norm-like nonnegative V with LV<=C(1+V).
The usual stopped Dynkin estimate then gives
P_x(tau_R<=t)<=exp(Ct)(V(x)+Ct)/inf_{N>=R}V,
up to an immaterial alteration of C. Letting R tend to infinity rules out escape
from finite sets in finite time. On every finite set the total jump rate is
bounded, so infinitely many jumps without escape also have probability zero.
All constructed functions are comparable to 1+N or 1+N^2.

The direction (1,1) forces every cubic arrow to have d_A+d_B<=0. If all cubic
arrows have equality, they are omitted in this direction; consequently every
quadratic arrow also has d_A+d_B<=0. Then V=1+N works, since sources of order
zero or one contribute at most C(1+N). Hence assume some cubic has strict loss.

Denote aggregate cubic increment vectors, including their constants, by g at
3A, u at 2A+B, v at A+2B; use zero if a mixed source is absent. Every 3A arrow
has d_A<0 and d_B>=0, so g_A=-alpha<0, g_B>=0 and g_A+g_B<=0.

## Bookkeeping lemmas

For a fixed quadratic form, its exact increment is its gradient times d plus
the fixed quadratic expression in d. Cubic falling-factorial propensities
differ from their homogeneous monomials by degree at most two. Thus exact
cubic drift is its homogeneous degree-four drift plus O(1+N^3).
More specifically, when only cubic sources 3A and 2A+B occur, the error is
bounded in absolute value by C(1+a^3+a^2 b+ab^2).
Quadratic-source upper contributions have the same bound plus C(1+N^2),
provided any potentially positive pure-b^3 term is either excluded by its
leading sign or accounted for explicitly. Lower-order sources give C(1+N^2).

The following absorptions will be used with arbitrarily small positive epsilon:
a^3+a^2 b+ab^2 <= epsilon(a^4+a^2 b^2)+C_epsilon(1+a^2+b^2),
and also
a^3+a^2 b+ab^2 <= epsilon(a^4+b^3)+C_epsilon(1+a^2+b^2).
For the second inequality use a^2 b <= epsilon a^4+C_epsilon b^2 and
ab^2 <= epsilon b^3+C_epsilon a^3, then absorb a^3 by a^4.
If ab^2 is absent, a^4 alone suffices. These are global inequalities.

## I. The source A+2B is absent

### I.1 The source 2A+B is present

The direction w=(1,2) has top source value 4 at 2A+B and, if present, 2B.
Hence each of their arrows satisfies d_A+2d_B<=0. Let W=a+2b. In particular
u_W=u_A+2u_B<=0. Every nonidentity 2B arrow has d_B<0, because its d_A>=0.
Let j be the aggregate vector at 2B and z that at A+B, again zero if absent.
If 2B is absent, the direction e_B forces every 2A+B and A+B arrow to have
d_B<=0. If u_B>0, therefore, 2B must be present.

(i) If u_B<0, put beta=-u_B>0 and use V=alpha a^2+beta b^2. Its homogeneous
cubic drift divided by 2a^2 is
Q=-alpha^2 a^2+(beta g_B+alpha u_A)ab-beta^2 b^2
 =-(alpha a-beta b)^2-eta ab,
eta=beta(alpha-g_B)+alpha(beta-u_A)>0.
The inequalities defining eta follow from cubic total loss; strictness follows
because some cubic loses total mass and there are only these two sources.
Consequently Q<=-c(a^2+b^2). Any 2B source has negative B drift, so its upper
contribution has no positive b^3. The bookkeeping and first absorption give
LV<=C(1+N^2).

(ii) If u_B=0, then u_A<0. Indeed u_A<=0; if also zero all 2A+B arrows would
have w.d=0, whose only nonidentity integral cubic possibility is (-2,+1),
contradicting u_B=0. Choose p,q>0 with q g_B+p u_A<=0, and V=p a^2+q b^2.
Its leading cubic drift is at most -c a^4. If 2B is present it contributes
-c' b^3 plus C(ab^2+b^2), so the second absorption applies. If 2B is absent,
each 2A+B arrow has d_B<=0 and their aggregate B drift is zero; hence all have
d_B=0. All A+B arrows also have d_B<=0. There is then no positive ab^2 term,
and -c a^4 alone controls the remainder by the final bookkeeping observation.

(iii) Suppose u_B>0, so u_A<=-2u_B<0 and 2B is present. Use
V=W^2+epsilon a^2. Its cubic homogeneous drift divided by 2a^2 has coefficients
g_W+epsilon g_A at a^2,
2g_W+u_W+epsilon u_A at ab,
2u_W at b^2.
If u_W<0, choose epsilon large enough to make the first coefficient negative
and the second nonpositive. This gives -c(a^4+a^2 b^2). At 2B the W^2 leading
drift is nonpositive and the a^2 perturbation produces only ab^2, so the first
absorption closes. If u_W=0, every 2A+B arrow is exactly (-2,+1).
If j_W<0, the same large-epsilon choice gives -c a^4 and the 2B source supplies
-c' b^3; use the second absorption.

It remains that u_W=j_W=0. All arrows at these sources conserve W. Essential
tier descent in direction w now gives g_W<=0 and z_W<=0, individually for all
arrows at 3A and A+B (which tie at source value 3).
If g_W<0, the linear W has negative cubic drift -c a^3, nonpositive A+B and
2B contributions, and its possible positive quadratic 2A drift is O(a^2).
Thus LW<=C(1+W).
If g_W=0 and z_W<0, use W^2+epsilon a^2 with epsilon sufficiently small.
The 3A and 2A+B sources conserve W exactly and their A decreases give
-epsilon c a^4-epsilon c' a^3 b up to degree-three errors.
The A+B radial term is -2|z_W| W ab, including -4|z_W| ab^2.
The 2B perturbation has positive leading term at most 2epsilon j_A ab^2.
Choose epsilon so this is absorbed by half the preceding negative ab^2.
All other positive terms are C(a^3+a^2 b)+C(1+N^2), absorbed by -epsilon c a^4.
Finally if g_W=z_W=0, all four higher sources conserve W. Any positive-W 2A
arrow would now be at a maximal essential source and is forbidden. Thus all
sources of degree at least two have nonpositive W drift; linear W works.

### I.2 The source 2A+B is absent as well

Only the pure source 3A is cubic. If 2B is present, use w=(2,3), W=2a+3b.
The sources 3A and 2B tie at maximal value 6, so g_W<=0 and j_W<=0, and every
2B nonidentity arrow has d_B<0.
If g_W<0, choose V=W^2+epsilon b^2 with epsilon small: the negative radial
cubic drift controls a^4 and a^3 b despite the perturbation. The 2B b^2 term
supplies -c epsilon b^3, while its radial term is nonpositive. The second
absorption closes.
If g_W=0 and j_W<0, use V=W^2+a^2: pure cubic A decrease supplies -c a^4,
and the 2B radial term supplies -c' b^3. Again absorb the remaining degree-three
terms. If both equal zero, their arrows conserve W; tier descent gives every
A+B arrow W drift <=0. If z_W<0 use W^2+epsilon a^2 with epsilon small enough
to absorb the 2B positive perturbative ab^2 by the A+B negative radial ab^2.
The cubic -epsilon c a^4 absorbs the remaining a^3+a^2 b terms.
If z_W=0, tier descent further forces nonpositive W drift for 2A, so linear W
works.

If 2B is absent but A+B is present, w=(1,2) makes 3A and A+B top sources of
value 3. Both have nonpositive W drift. Use W^2+a^2: the cubic A decrease gives
-c a^4; upper errors and possible 2A contributions contain only a^3+a^2 b,
since there is no quadratic source 2B and the A+B radial leading term is
nonpositive. Absorption closes.
If 2B and A+B are absent but B is a source, w=(1,3) makes 3A and B top sources
of value 3. It forces g_W<=0. Again W^2+a^2 gives -c a^4 and the only quadratic
source 2A contributes at most C(a^3+a^2 b); sources of degree one contribute
C(1+N^2). If B is absent from every source, direction e_B forces every arrow
to have d_B=0. Then B is constant and a^2+b^2 has LV<=C(1+N^2).

## II. The source A+2B is present

Direction e_B forces every arrow at A+2B or 2B to have d_B<=0.
Use the homogeneous cubic field F(a,b)=g a^3+u a^2 b+v ab^2. Define on x=a/N
ell(x)=-F_total(x,1-x)>=0 and h(x)=2[x F_A(x,1-x)+(1-x)F_B(x,1-x)].
The strict cubic loss assumption gives ell(x)>0 for 0<x<1.
At x=1, h(1)=2g_A<0. At x=0, h(0)=0.

### II.1 v_B<0: fixed-A truncated cross term

Here h(x)/x tends to 2v_B<0 as x decreases to zero. Choose small endpoint
collars where h<0 at the A endpoint and h/x<0 at the B endpoint. On their
compact intervening interval ell has a positive minimum. Consequently one
can choose epsilon>0 and c>0 such that
-2ell(x)+epsilon h(x)<=-c x throughout [0,1].
For W0=N^2+epsilon(a^2+b^2), its homogeneous cubic drift is therefore at most
-c a N^3.

Put q=1+epsilon, f_K(a)=(a-K)_+, and
V_K=q(a^2+b^2)+2b f_K(a).
For a>=K+D this equals W0-2K b, including at all possible destinations.
There, exact cubic and quadratic drift is bounded above by
-c a N^3+C(1+K)(1+N^3), where C is independent of K>=1.
Choose L>=2+3C/c. For a>=LK and K>=D+1 this is at most C(1+N^2), increasing
C if necessary for N small. The coefficient of N^3 is nonpositive.

For a<LK, every non-leading term from fixed-A increments is O_K(1+b^2), except
the leading b^3 terms from sources A+2B and 2B. In particular the source 3A
has bounded rate and increment O_K(1+b), and 2A+B has rate O_K(b) and increment
O_K(1+b). For an A+2B arrow, total loss gives d_A<=-d_B whenever d_A>0.
Also Delta f_K<=max(d_A,0). Thus
q d_B+Delta f_K<=q d_B+max(d_A,0)<=epsilon d_B.
Define kappa=sum_(A+2B) k[q(-d_B)-max(d_A,0)]>0.
The exact total contribution of this source is bounded by
-2kappa a b^3+O_K(1+b^2).
For 2B put T=2 sum k max(q d_B+d_A,0). Its possible positive b^3 contribution
is at most T b^3, and is absent when a<=K-D, since then both cross terms vanish
and d_B<=0. Choose K>D+T/kappa+1 as well. On the strip where this term can be
positive, kappa a>T, so the cubic source absorbs it. For a=0 or b=0,1 the same
bounds remain valid: the disabled cubic terms are paid for by O_K(1+b^2).
This proves LV_K<=C_K(1+N^2) globally.

### II.2 v_B=0: pure A-death and a monotone angular interpolation

Every A+2B arrow has d_B=0. Cubic total nonincrease and nonidentity then force
the exact increment (-1,0). Write v=(-kappa,0), kappa>0.
Now ell(x)=kappa x+O(x^2), h(x)=O(x^2) near zero. Using the A collar and compact
middle interval as above, choose epsilon,c>0 with
L3_hom W0<=-c a N^3, W0=N^2+epsilon(a^2+b^2).
Let q=1+epsilon and choose M>q with M kappa>q max(u_B,0)+1.
For W1=M a^2+q b^2 its exact homogeneous cubic drift is
2M g_A a^4+2(M u_A+q g_B)a^3 b+2(q u_B-M kappa)a^2 b^2.
Consequently there exist delta,c1>0 such that this is at most -c1 a^2 b^2
whenever 0<=a/b<=delta. Shrink delta so W0-W1=2ab+(q-M)a^2>=ab there.
The projective cubic drift of rho=a/b is
D rho=(F_A-rho F_B)/b=b^2[-kappa rho+O(rho^2)]<0 for 0<rho<=delta,
after shrinking delta again.

Choose a smooth nondecreasing chi with chi=0 for rho<=delta/2 and chi=1 for
rho>=delta. Set V=(1-chi(rho))W1+chi(rho)W0, using W0 at b=0 and V(0,0)=0.
Its homogeneous cubic drift is
(1-chi)L3_hom W1+chi L3_hom W0
 +chi'(rho)(D rho)(W0-W1).
The final term is nonpositive. Thus this drift is at most -c2 a^2 b^2 in the
B collar, and at most -c3 N^4 on any closed angular region a/b>=delta/4.
V is comparable to N^2 and has a globally bounded Hessian away from the
origin; its gradient extends Lipschitz-continuously to the origin. Hence the
exact finite-jump Taylor remainder is O(1) per increment, and replacing cubic
falling factorials by monomials gives total error O(1+N^3).
Away from the deeper B collar, -c3 N^4 absorbs this error and all quadratic
sources. For a/b<=delta/4 and sufficiently large N, bounded jumps remain in
a/b<=delta/2. Thus both the starting and all destination values are exactly
W1, with no angular interpolation error. Its exact generator is bounded by
-c2 a^2 b^2+C(a^3+a^2 b+ab^2)+C(1+N^2).
Here pure 2B cannot produce positive b^3 because d_B<=0. On this collar
a^3<=delta a^2 b, and the first absorption with only a^2 b^2 gives a global
C(1+N^2) upper bound: separately absorb a^2 b by a^2 b^2+C a^2, and ab^2 by
a^2 b^2+C b^2. This includes a=0, where all cubic rates vanish. The excluded
small-N set is finite and has bounded generator values. This proves the
required global Foster inequality.

## Conclusion and scope

Cases I and II exhaust all mixed cubic source configurations when exactly one
pure cubic source is present. Each has a norm-like Foster function, with every
disabled boundary rate, finite strip, falling-factorial correction and bounded
jump accounted for. Nonexplosion follows for all finite states, without an
irreducibility or reachability assumption. The proof is specific to two species;
it makes no claim about the minimum order in arbitrary dimension.
