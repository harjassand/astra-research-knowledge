# Post-freeze cross audit

**Scope and status:** complete internal cross audit of `work/agents/chemistry/ORDER5_BROAD_CONE_ALMOST_SURE.md`, read in full only after our own `broad_cone/report.md` was frozen. No load-bearing gap was found. Both reconstructions used the coordinator's Foster/renewal hint, and matching chemistry messages arrived before our freeze. This audit does not establish external validation, formal replay, novelty, or a new blind-independence claim.

## Gates checked

1. **Coefficient mapping and cone.** The five exact rates match. `d>3k2,2k4<d` is precisely `d>3k2,k3>k4`. Arbitrary fixed positive k0,k1 are admitted through a finite higher A boundary.
2. **Low-A activation.** At a=0,1 only I occurs; at a=2 only I and U occur. Active A>=3 is reached in at most two jumps, increasing B by at most one. D1 can only lower A as far as 2. A reset following a marked death increases B by at most one, so the grouped death decreases B by at least one. The macro stops at B=0 before taking a reset.
3. **Neutral inputs.** At every active positive-B state, input probability is bounded by z=k0/(k0+6k2)<1. Its runs are geometrically finite. The exact birth upper bound and D0 lower bound survive averaging over the state before the first B-changing reaction; no fixed-A assumption is used.
4. **Foster return outside a finite B set.** With birth probability <=1/4 and each death decreasing B by at least one, conditional B drift is <=-1/2. Stopping and truncating a nonnegative B-coordinate bounds expected compact-set hitting index by 2B_initial. Its finite stopped increments are integrable. B need not be Markov by itself.
5. **Compact absorption word.** D0 has a uniform positive lower probability over all A>=3 and 2<=B<=M. Its reaction leaves A unchanged. The mandatory birth at B=1 repairs odd parity. The claimed word length `ceil(M/2)+1` is sufficient: if M is even, the largest odd starting value M-1 needs M/2+1 steps; if M is odd, starting at M needs (M+3)/2 steps. B stays <=M because M>=2.
6. **Retries after failed compact blocks.** A fixed-length failed block ends at B<=M+L. The outside drift recovers the finite set almost surely in finite macro count. A uniform conditional absorption probability gives geometrically bounded failed block count, without independence.
7. **Physical time and premature explosion.** Finite total full reaction count implies finite physical recovery time, because each finite-state total rate is positive and finite. Thus recovery is reached before explosion almost surely. This establishes recurrence directly from the embedded chain rather than assuming nonexplosion. Our own report additionally proves finite expected reaction count and finite expected physical return time.
8. **High-A episode premise.** The already frozen positive-cone proof yields uniform positive cycle drift, a complete-reaction exponential tail, an exponential ruin bound, and almost-sure finite holding-time sum on no ruin. Failure has finite reaction count and ends at A=A_*-1. The modified boundary preserves the exact final-reaction marking argument.
9. **Uniform axis boosts.** The low axis A-values are a finite set; their finite input words have a uniform strictly positive probability. Any interruption is a finite failure followed by global axis recovery. Large A-values have a common positive no-ruin bound. All constants depend only on the fixed coefficients and finite A boundary.
10. **Renewal stopping times.** Failed trials are observed at finite reaction/physical stopping times; recovery times are also finite. The probability of n successive failures is bounded by (1-delta)^n, proving eventual successful episode almost surely. No irreducibility inference or independent-trial premise is used.

## Minor terminology clarification

The last section of the chemistry report calls the first input from A=0 or 1 an 'activation'. From A=0 this reaches 2, which is valid trial eligibility at the axis; an active macro state A>=3 can need its next jump. The global lemma already explicitly allows two initial jumps. Interpreted in its local context, this wording is not a mathematical gap.

## Outcome

The broader-cone almost-sure theorem is supported by complete internal reconstructions and this post-freeze audit. The original independently frozen order-five positive-probability theorem and its earlier almost-sure open-region proof remain unchanged. External validation, formalization, geometric class verification and novelty remain separate unresolved gates.
