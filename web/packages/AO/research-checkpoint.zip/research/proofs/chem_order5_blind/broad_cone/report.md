# Almost-sure explosion throughout the broader frozen rate cone

**Status:** internally reconstructed extension. The minimal CTMC explodes almost surely from every finite state whenever all five rate constants are positive and

`d=k3+k4>3k2`, `k3>k4`.

The input and order-two rate constants `k0,k1` are arbitrary fixed positive numbers. These conditions are exactly the broader positive-explosion cone supplied in `work/agents/chemistry/ORDER5_ROBUST_RATE_COROLLARY.md`, read for this extension. This report does not replace or modify the original independently frozen proof. The other worker's new almost-sure report was not read before this report was frozen. Before this freeze, messages from that worker communicated a matching route. The coordinator also supplied the Foster/renewal outline. This is a reconstruction of that extension, rather than a new blind-independence claim.

## Exact chain and conclusion

The five reactions have jumps and rates

| Reaction | Jump | Rate |
|---|---|---|
| I | `(+2,0)` | `k0` |
| U | `(+1,+1)` | `k1(a)_2` |
| V | `(0,+1)` | `k2(a)_3 b` |
| D0, unmarked death | `(0,-2)` | `k3(a)_3(b)_2` |
| D1, marked death | `(-1,-2)` | `k4(a)_3(b)_2` |

Here `(a)_j` is the falling factorial, interpreted as zero when `a<j`. Every coefficient is fixed, finite and strictly positive. Put `d=k3+k4`, `s=d/k2`, and `q=k4/d`.

**Theorem.** If `s>3` and `q<1/2`, then, for every finite state `(a,b) in N_0^2`,

`P_(a,b)(T_infinity<infinity)=1`.

We first establish a global axis-return lemma that needs only positivity of the coefficients. Its proof is given directly on the exact embedded reaction chain, without assuming nonexplosion. Thus no inference from irreducibility and positive explosion probability is made.

## 1. Global axis return for arbitrary positive coefficients

**Lemma.** For arbitrary fixed positive `k0,...,k4`, the chain started from a finite state with `b>0` hits `b=0` after finitely many full reactions almost surely. In fact the expected number of these reactions and the expected physical axis-hitting time are finite. This occurs before explosion almost surely.

At `a=0`, only I can occur and it reaches `a=2`. At `a=1`, only I can occur and it reaches 3. At `a=2`, only I and U can occur, with rates `k0` and `2k1`; either reaches `a>=3`, while B increases by at most one. Thus reaching an active state `a>=3` initially takes at most two reactions and increases B by at most one. After `a>=2` is first reached, A can never fall below 2.

From a state `a>=3,b>0`, define a macro step by ignoring input reactions until the first B-changing reaction. If that reaction reaches `b=0`, stop immediately. Otherwise, if D1 leaves `a=2`, include its next I or U reaction to restore `a>=3`.

Every input-only run is finite almost surely. The conditional probability of I at each active positive-B state is at most

`z=k0/(k0+6k2)<1`,

because the V rate is at least `6k2`. The number of preceding inputs therefore has conditional tail at most `z^j` and conditional mean at most `z/(1-z)`. A macro step contains at most one additional low-A reset.

Let `Y_n` be the B-coordinate at the active macro states, killed upon reaching zero. A birth has increment `+1`. A pair death either reaches zero at `b=2`, or has increment `-2` or `-1`, after its possible low-A reset. Conditional on the beginning of a macro step, its birth probability is at most

`p_b=(k2 b+k1)/(k2 b+k1+d b(b-1))` for `b>=2`.

At any intermediate input state, the exact probability conditional on a B-changing reaction replaces `k1` by `k1/(a-2)<=k1`. Averaging over the almost surely finite input-only run preserves the displayed bound. At `b=1`, the next B-changing reaction is necessarily a birth to 2.

### Return to a finite B set

Choose a finite integer `M>=2` such that

`d b(b-1)>=3(k2 b+k1)` for every integer `b>M`.

Such an M exists because the left side is quadratic with positive leading coefficient. For an explicit choice, let

`R=[d+3k2+sqrt((d+3k2)^2+12d k1)]/(2d)`

and take `M=max(2,ceil(R))`. Then `p_b<=1/4` for `b>M`. Since a death decreases B by at least one,

`E[Y_(n+1)-Y_n | macro history] <= p_b-(1-p_b)<=-1/2`

outside `K={0,...,M}`.

For the first macro hitting index `tau_K`, apply this drift inequality to the process stopped at `n wedge tau_K`. Nonnegativity gives

`E[n wedge tau_K] <= 2Y_0`.

Letting n increase proves `E[tau_K]<=2Y_0`, in particular almost-sure hitting of K. The argument is conditional on the full macro history; B alone need not be a Markov chain. Its increments are bounded, so each finite stopped calculation is integrable.

### Uniform absorption chance inside K

For `2<=b<=M`, the probability that the next B-changing reaction is an unmarked death, after any ignored inputs, is at least

`e_b=k3 b(b-1)/(k2 b+k1+d b(b-1))`.

Let `e=min_(2<=b<=M)e_b>0`, `L=M+2`, and `epsilon=e^L>0`.

From any active state with `1<=b<=M`, a prescribed word reaches B=0 using at most L macro steps: take unmarked deaths until B reaches 0 when b is even; when b is odd, take unmarked deaths until B reaches 1, then its mandatory birth to 2, then one unmarked death. Unmarked deaths preserve A, so no low-A reset occurs anywhere in this prescribed word. B never exceeds M because `M>=2`. The mandatory birth at 1 has probability one; every required unmarked death has conditional probability at least e. Therefore

`P(hit B=0 within L macro steps | any active state in K\{0}) >= epsilon`.

This lower bound is uniform over the unbounded A-coordinate and over the entire past.

Try this fixed-length absorption block whenever K is reached. If it fails, B is at most `M+L`, because each macro step increases B by at most one. Return to K using the outside-drift estimate, and try again. Each return has conditional expected length at most `2(M+L)`. Each block has success probability at least epsilon. Thus k consecutive failed blocks have probability at most `(1-epsilon)^k`, and the number of blocks until absorption is finite almost surely.

For a quantitative bound, each block plus its failed recovery has conditional expected macro length at most

`C_K=L+2(M+L)`.

Summing over the geometrically bounded block count shows that the expected macro length after the first return to K is at most `C_K/epsilon`. The initial low-A activation has resulting B-coordinate at most `b+1`, so a uniform bound from any initial finite `(a,b)` is

`E[macro steps to the axis] <= 2(b+1)+C_K/epsilon`.

The conditional expected number of full reactions in a macro step is at most

`C_I=1/(1-z)+1`.

The first term includes the ignored inputs and the B-changing reaction; the second allows its optional reset. Including at most two initial activation reactions gives

`E[full reactions to the axis] <= 2+C_I[2(b+1)+C_K/epsilon] <infinity`.

Every total CTMC rate is at least `k0`. In the standard independent-unit-exponential construction, the mean physical axis-hitting time is consequently at most this expected reaction-count bound divided by `k0`.

This calculation does not assume the axis is reached in an already nonexplosive process. The embedded reaction chain has an almost surely finite axis-hitting index. The finite prefix of its holding times is finite almost surely, and the next holding time is strictly positive almost surely. Hence that axis time precedes any explosion. This proves the lemma.

## 2. A uniformly successful high-A episode

For completeness, the frozen positive-cone mechanism gives more than an unspecified positive explosion chance. Set

`r=min(1,2s/3-2)>0`,

and choose an integer `A_*>=3` so that `k1/[k2(A_*-2)]<=r`. For instance,

`A_*=max(3,2+ceil(k1/(k2 r)))`

works. Stop each excursion from B=1 upon reaching B=0 or A=`A_*-1`. At pre-stopping states the normalized B-birth rate is `b+rho`, with `rho=k1/[k2(a-2)]<=r<=1`, and the pair-death rate is `s b(b-1)`.

Use

`H(0)=0`, `H(b)=(3/2)ceil(b/2)+(1/2)1_{b=1}`.

At b=1 a birth contributes `-1/2`; at b=3 a pair death contributes `-1+1=0` after adding its death count; at odd b>=5 it contributes `-3/2+1=-1/2`. Births at odd b>=3 leave H unchanged. At even b>=2 the unnormalized H increment plus pair-death count is

`(3/2)(b+rho)-(s/2)b(b-1)<=0`.

At b=2 this is precisely `rho<=2s/3-2`. At even b>=4 it follows from `rho<=1,s>3`. Neutral input leaves H unchanged. Summing this budget to a truncated stopping index and using terminal H>=0 yields expected pair-death count at most H(1)=2. The marked-death conditional probability is exactly q, including the terminal reaction, so expected A losses are at most 2q.

Starting at an axis state `a>=A_*`, a return cycle has initial I increment +2 or initial U increment +1 followed by such a stopped excursion. Its expected A increment is therefore at least

`mu=1-2q>0`.

For an excursion's full reaction-count tail, use `F(0)=0,F(1)=5,F(b)=2^b` for b>=2, killed also at the low-A boundary. Conditional on a B-changing reaction its contraction ratios are at most `4/5` at b=1; `1/2` at b=2; `7/8` at b=3; and `15/32` at b>=4. At b=2 the H inequality gives birth probability at most 1/4. At b=3 its birth probability is at most `4/(4+18)=2/11`. At b>=4 it is at most 1/8 because `7(b+1)<=3b(b-1)` for all b>=4. These checks account for the exceptional value F(1)=5.

Input has probability at most

`z_*=k0/[k0+k2(A_*)_3]<1`.

Thus the full reaction contraction factor is `gamma=z_*+(1-z_*)(7/8)<1`, and the number N of post-initial reactions in a stopped cycle satisfies

`P(N>m | cycle history)<=(5/4)gamma^m`.

Each cycle A increment Delta obeys `|Delta|<=2(N+1)`. Hence there is a constant theta>0, depending only on the fixed coefficients and A boundary, such that

`E[exp(-theta Delta) | cycle history] <=1-theta mu/2<1`

before ruin. Explicitly, one can take the same exact formula as in the blind proof, with this gamma and mu:

`eta=-(1/4)log(gamma)`, `u=sqrt(gamma)`,

`C=4gamma^(-1/2)[1+(5/(4gamma))((1+u)/(1-u)^3-1)]`,

`theta=min(eta,mu/C)>0`.

Let sigma be the first cycle reaching `a=A_*-1`. The nonnegative exponential supermartingale gives

`P_(a,0)(sigma=infinity)>=1-exp[-theta(a-(A_*-1))]`

for every `a>=A_*`.

On no ruin, the square-integrable martingale-difference strong law gives `liminf A_n/n>=mu`, because the cycle increments have uniformly bounded second moments. The uniform exponential tail and Borel-Cantelli give `N_n=O(log n)`. Every pre-reaction A-coordinate in a cycle is at least `A_n-N_n`, hence eventually at least a positive multiple of n. The axis rate is at least `k1(a)_2` and the positive-B rate at least `k2(a)_3 b`. Therefore the sum of reciprocal rates is bounded by a summable sequence of the form `C'/n^2+C'N_n/n^3`. Conditional independent unit exponential clocks then have a finite sum almost surely. Consequently no ruin implies finite-time explosion almost surely.

If ruin occurs, it does so after finitely many cycles, each containing finitely many full reactions almost surely by the exponential-tail bound. Its state is finite with A=`A_*-1`, and its physical time is finite almost surely. The global axis-return lemma then provides a finite recovery.

## 3. Uniform renewed trials from every axis state

At an axis state `(a,0)` with `a>=2`, boost A with consecutive inputs until it reaches `A_*` if it was initially below that threshold. Declare this trial failed immediately if a U reaction interrupts that finite input word; then recover to the axis using the global lemma. When A is already at least `A_*`, or when the input word succeeds, launch the stopped high-A episode just established. No ruin is success; ruin is failure followed by axis recovery.

Define

`J=ceil((A_*-2)/2)`,

`p=k0/[k0+k1(A_*-1)(A_*-2)]>0`,

and `delta=p^J(1-exp(-theta))>0`.

For any starting axis A>=2, the boost requires at most J inputs. Each pre-input A-coordinate is below A_*, so the conditional probability of I is at least p. The resulting high-axis state is at least A_* and the subsequent no-ruin episode has probability at least `1-exp(-theta)`. States already above the threshold satisfy the same lower bound since `p^J<=1`. Thus every trial, conditional on its full past, succeeds with probability at least delta.

Every failed trial ends at a finite state after finitely many full reactions almost surely, and every failed recovery reaches another valid axis state in finite reaction count and finite physical time. The recovered A-coordinate remains at least 2. Initial states with A=0 or A=1 reach A>=2 after one input; if their B-coordinate is positive, recover by the axis lemma. This initialization is also finite almost surely.

Use the strong Markov property at the finite failed-trial recovery times. Inductively,

`P(first n trials all fail)<=(1-delta)^n`.

Therefore a successful trial occurs after finitely many failures almost surely. Their accumulated time is finite, and that successful high-A episode explodes at finite time almost surely. This proves the theorem for every finite initial state throughout the broader cone.

Any explosion occurring during a proposed preparation or recovery would itself already prove the desired outcome. The global axis lemma actually establishes that such recovery-time explosion has probability zero, because recovery uses finitely many full reactions almost surely. No assumption about explosion is smuggled into a recurrence argument.

## Evidence, preservation, and remaining status

The frozen positive-cone report was read completely. Its high-A estimates were reconstructed above. The reset-macro/Foster/finite-block argument is also complete above and applies to arbitrary positive coefficients. It preserves exact reaction marking and includes arbitrarily many neutral input reactions through uniform geometric bounds. Actual physical time is handled by the independent exponential construction and a global lower bound k0 on total rates.

Original blind and open-box almost-sure artifacts are preserved. Exact finite diagnostics check representative broad-cone choices and the displayed local arithmetic; the proofs cover every admitted fixed tuple and all integer states. Formal replay, external validation, geometric strong-endotacticity, maximality of the cone, and novelty/priority remain UNKNOWN in this report. The next decisive gate is an adversarial audit of the global-axis Foster/block lemma and the high-boundary renewed-trial construction.
