# Almost-sure explosion and an open parameter region

**Status:** internally reconstructed strengthening of the frozen independent positive-probability proof. The exact supplied process explodes almost surely from every finite state `(a,b) in N_0^2`. No irreducibility argument is used. The original proof files are preserved unchanged. Geometric endotacticity and external novelty remain outside this report.

## Theorem for the exact fixture

Retain the five rates from the original report:

`I:1`, `U:(a)_2`, `V:(a)_3 b`, `D0:4(a)_3(b)_2`, `D1:(a)_3(b)_2`,

and the corresponding jumps `(+2,0)`, `(+1,+1)`, `(0,+1)`, `(0,-2)`, `(-1,-2)`.

**Theorem.** The minimal CTMC's explosion time satisfies

`P_(a,b)(T_infinity<infinity)=1`

for every finite initial state `(a,b)`.

The proof has two ingredients: a global return-to-axis lemma that includes low-A resets, and uniformly successful renewed explosion trials.

## 1. Global axis-return lemma

**Lemma.** Starting from any finite state with `b>0`, the embedded reaction chain hits `b=0` after finitely many full reactions almost surely. Consequently the CTMC hits that axis at a finite time almost surely, before any possible explosion.

When `a=0`, only I is active and sends it to 2. When `a=1`, only I is active and sends it to 3. When `a=2`, the only active reactions are I and U, with rates 1 and 2; either sends `a` to at least 3, and their effect on `b` is respectively zero or plus one. Thus a state with `a<3` reaches `a>=3` within at most two reactions and increases `b` by at most one. After this initial activation, the A-coordinate can never fall below 2.

Now define a macro step from a state with `a>=3,b>0`:

1. Ignore input reactions I until the first reaction that changes `b`.
2. If that reaction reaches `b=0`, stop immediately at the axis.
3. Otherwise, if it was D1 and reached `a=2`, include the next reaction I or U that restores `a>=3`.

Input-only runs in step 1 are finite almost surely: at every active state with `b>0`, the probability of I is at most `1/7`, since the total rate of B-changing reactions is at least `(a)_3 b>=6`. The conditional tail of the number of consecutive I reactions is therefore bounded by `(1/7)^j`.

The B-coordinate at consecutive active macro states will be denoted `Y_k`, with `Y=0` absorbing. A B-birth macro step changes `Y` by `+1`. A pair-death macro step either hits 0 (when `Y=2`) or changes `Y` by `-2` or `-1`; the latter possibility includes a subsequent U reset from `a=2`.

Ignoring I does not invalidate the birth-probability bounds. At every possible pre-reaction active state the B-birth probability conditional on a B-changing reaction is

`p_b(a)=(b+1/(a-2))/(b+1/(a-2)+5b(b-1))`.

Average this inequality over the state before the first non-I reaction. Because the input-only run is almost surely finite, the probabilities that its possible terminal reaction indices are selected sum to one. Thus, conditional on the beginning of a macro step,

`p_2<=3/13`, `p_3<=2/17`, and `p_b<=1/13` for `b>=4`.

The last bound follows from `12(b+1)<=5b(b-1)`, equivalently `(b-4)(5b+3)>=0`. At `b=1`, a birth is mandatory.

Use exactly the same nonnegative function as in the frozen report:

`F(0)=0`, `F(1)=5`, `F(b)=2^b` for `b>=2`.

It contracts uniformly at each macro step:

`E[F(Y_(k+1)) | macro history] <= (4/5)F(Y_k)`.

The complete check, including reset reactions, is:

* At `b=1`, the next macro state has `b=2`, so the ratio is `4/5`.
* At `b=2`, a pair death hits the axis before any low-A reset is taken. The ratio is therefore at most `2p_2<=6/13`.
* At `b=3`, a pair death leads to `b=1` or `b=2`, whose largest F-value is 5. Hence the ratio is at most `(5+11p_3)/8<=107/136<4/5`.
* At `b>=4`, a pair death's largest possible F-value is `2^(b-1)`. The ratio is at most `2p_b+(1-p_b)/2<=8/13<4/5`.

Every surviving macro state has `F>=4`. If `tau` is the macro-step hitting index of the axis and its initial active B-coordinate is `b_*`, iteration yields

`P(tau>k | initial active state) <= [F(b_*)/4](4/5)^k`.

Thus `tau` is finite almost surely. Each of its finitely many macro steps contains an almost surely finite input run, one B-changing reaction, and at most one reset. The optional initial low-A activation contains at most two reactions. The total number of full reactions to the axis is therefore finite almost surely. Their holding times are finite almost surely because all their total rates are finite and at least one positive rate is present. This proves the lemma for every finite initial state.

The lemma is a statement about the exact embedded chain, so it also rules out an explosion occurring before axis return on a set of positive probability. It does not assume that the CTMC was already known to be nonexplosive.

## 2. Uniformly positive explosion trials at the axis

The frozen report established the following exact stopped-episode result. From `(a,0)` with `a>=3`, run its return cycles until the first cycle that reaches `a=2`, or forever if no such cycle occurs. Let `sigma` be the ruin index. For the explicit positive constant `theta` in that report,

`P_(a,0)(sigma=infinity) >= 1-exp(-theta(a-2))`.

On `{sigma=infinity}`, the episode explodes almost surely: return-cycle A-coordinates have asymptotic lower growth at least `3n/5`, excursion reaction counts are `O(log n)`, and the sum of reciprocal holding rates is finite. If `sigma<infinity`, it is reached after finitely many full reactions and leaves the process at a finite state with `a=2`; the B-coordinate may be positive. The axis-return lemma brings such a state back to the axis after finitely many further reactions almost surely.

Define a trial at an axis state `(a,0)` with `a>=2`:

* If `a>=3`, launch that stopped episode directly. Success is `sigma=infinity`; failure is `sigma<infinity`.
* If `a=2`, take one reaction. With probability `1/3` it is I and reaches `(4,0)`; launch the stopped episode there. If it is U, declare the trial failed and use the axis-return lemma to recover. If a launched episode fails, likewise recover to the axis.

Every failed trial and its recovery ends after finitely many reactions and at a finite time almost surely. Every successful trial explodes at a finite time almost surely.

Every trial's conditional success probability, given its entire past, is bounded below by the same constant

`delta=(1/3)(1-exp(-2theta))>0`.

For `a>=3`, the lower bound is at least `1-exp(-theta)`, which is no smaller than `delta`: writing `x=exp(-theta)` gives `(1-x^2)/3<=(1-x)` because `(1+x)/3<=1`. For `a=2`, the bound follows from the input jump and the frozen episode starting at 4.

Once `a>=2`, no reaction can reduce it below 2. Thus the axis recovered after every failed trial is another valid trial state. Starting at `a=0` or `a=1`, one input reaction first reaches `a>=2`; if `b>0`, use the lemma to recover to the axis. This initialization uses finitely many reactions almost surely.

## 3. Renewal proves almost-sure explosion

Use the strong Markov property at the finite trial-start and recovery stopping times. Conditional on `k` failed trials, the next trial fails with probability at most `1-delta`. Induction yields

`P(first k trials all fail) <= (1-delta)^k`.

The probability that all trials fail is therefore zero. Almost surely a successful trial occurs after a finite number of failed trials. Those earlier trials and recoveries take finite time, and the successful trial's explosion time is finite. This establishes almost-sure explosion from every finite state.

The trials do not have to be independent. Their states and their durations may vary. What is used is the uniform conditional success bound, together with the fact that every failure produces another trial after a finite stopping time.

## 4. An explicit open parameter region

The same argument proves almost-sure explosion for the unchanged reaction jumps with positive rate constants

`I:c0`, `U:c2(a)_2`, `V:c3(a)_3 b`,

`D0:c4(a)_3(b)_2`, `D1:c5(a)_3(b)_2`.

Put `d=c4+c5`. The following strict inequalities define an explicit open region containing the exact fixture `(c0,c2,c3,c4,c5)=(1,1,1,4,1)`:

`c0,c2,c3,c4,c5>0`,

`3(2c3+c2)<2d`,

`8(3c3+c2)<7d`,

`2c5<d`.

Here are the precise changes needed in the proof.

At `a>=3`, the unnormalized B-birth rate after dividing by `(a)_3` is `c3 b+c2/(a-2)<=c3 b+c2`, while the pair-death rate is `d b(b-1)`. For the original H-function, the even-b drift plus pair-death count is nonpositive whenever `3(c3 b+c2)<=d b(b-1)`. The first displayed strict inequality implies this for every `b>=2`, since the ratio `(c3 b+c2)/(b(b-1))` is largest at 2. All the original odd-b and b=1 checks are unchanged. Hence expected pair deaths remain at most 2, expected D1 deaths are at most `2c5/d`, and cycle drift is bounded below by

`mu=1-2c5/d>0`.

For the F inequalities, the first condition implies `p_2<1/4`. The second condition gives `p_3<7/55`, exactly the threshold for `(5+11p_3)/8<4/5`. At `b>=4`, use

`c3 b+c2 <= (b/2)(2c3+c2) < bd/3`,

so the birth-to-death rate ratio is below `1/[3(b-1)]<=1/9` and `p_b<1/10`. The original stopped-excursion F-ratio is then below `1/4+(7/4)(1/10)=17/40<4/5`; the global reset-macro F-ratio is below `1/2+(3/2)(1/10)=13/20<4/5`. At `b=1` the F-ratio is still exactly `4/5`. Thus both F contractions continue to hold.

The probability of an input-only reaction at an active positive-B state is at most

`z=c0/(c0+6c3)<1`.

Consequently full stopped-excursion reaction counts have the exponential-tail constant `gamma=z+(1-z)(4/5)<1`. Repeat the frozen exponential-increment argument with this gamma and the new positive mu to obtain a positive theta. Holding-rate bounds become `q(a,0)>=c2(a)_2` and `q(a,b)>=c3(a)_3 b`, which still give a summable total on survival. At `(2,0)` the input jump now has probability `c0/(c0+2c2)>0`; take the uniform trial probability lower bound

`min(1-exp(-theta), [c0/(c0+2c2)](1-exp(-2theta)))>0`.

The same renewal argument therefore proves almost-sure explosion throughout the open region.

A simple contained box is: arbitrary `c0>0`; each of `c2,c3,c5` is in `(0.95,1.05)`; and `c4` is in `(3.95,4.05)`. Indeed the worst first inequality is `9.45<9.8`, the worst second is `33.6<34.3`, and `2.1<4.9` verifies the third. These bounds are exact decimal rationals, not empirical parameter trials.

## Audit scope and next decisive gate

This is a mathematical strengthening reconstructed from the specified CTMC and the frozen blind proof. The original positive-probability report, checks, and provenance files were not edited. No outside chemical proof or other worker report was consulted. The local script tests the new macro-step arithmetic with exact fractions; the displayed case argument covers all B-values.

The next decisive gate is an independent audit of the macro-step stopping construction and the renewed-trial argument, with particular attention to stopping immediately on `b=0` before taking a low-A reset. External verification, formal replay, and novelty remain UNKNOWN.
