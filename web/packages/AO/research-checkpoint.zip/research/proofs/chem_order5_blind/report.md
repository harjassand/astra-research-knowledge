# Independent exact CTMC explosion proof

**Status:** internally reconstructed proof. The specified process has a positive probability of finite-time explosion from `(0,0)`. The proof below includes all five reactions and does not forbid the small-probability extra reactions at infinitely many stages. No other chemistry derivation or explosion report was read. Geometric endotacticity, external verification, formal replay, and novelty are outside this proof and remain unverified here.

## Exact statement

Write `(a)_k=a(a-1)...(a-k+1)`, with value zero when `a<k`. Consider the minimal continuous-time Markov chain on `N_0^2` with reactions

| Label | Jump | Rate |
|---|---|---|
| I | `(a,b)->(a+2,b)` | `1` |
| U | `(a,b)->(a+1,b+1)` | `(a)_2` |
| V | `(a,b)->(a,b+1)` | `(a)_3 b` |
| D0 | `(a,b)->(a,b-2)` | `4(a)_3(b)_2` |
| D1 | `(a,b)->(a-1,b-2)` | `(a)_3(b)_2` |

**Proposition.** If its explosion time is `T_infty`, then

`P_(0,0)(T_infty<infinity)>0`.

Every rate is finite at every finite state. We use the exact embedded reaction chain and independent unit exponential variables for its holding times. Choosing the next reaction with probability equal to its rate divided by the total rate, and then waiting an independent unit exponential variable divided by the total rate, constructs the minimal chain up to its explosion time.

## 1. Excursions with all reactions included

For an excursion with `b>0`, stop at the first reaction after which either `b=0` or `a<3`. Thus every state before stopping has `a>=3`. Put

`rho=(a)_2/(a)_3=1/(a-2)`, so `0<rho<=1`.

Conditional on the next reaction changing `b`, its probability of a birth is

`p_b=(b+rho)/(b+rho+5b(b-1))`.

At `b=1` this probability is one. At `b>=2` the two pair-death reactions together have relative rate `5b(b-1)`, and the D1 reaction has precisely one fifth of that death rate. The input reaction I leaves `b` unchanged, increases `a` by two, and is included throughout.

### Expected pair-death count

Define the nonnegative function

`H(0)=0`,

`H(b)=(3/2)ceil(b/2)+(1/2)1_{b=1}` for `b>=1`.

Let `D` be the number of pair-death reactions D0 or D1 in the stopped excursion. For every pre-stopping state,

`E[H(B_next)-H(b)+1_{next reaction is a pair death} | (a,b)] <= 0`.

Here is the full check. I has no effect on this expression. At `b=1`, a birth changes `H` from `2` to `3/2`, giving a nonpositive contribution. At `b=3`, a pair death changes `H` from `3` to `2`, so its change plus the death count is zero; a birth leaves `H` unchanged. At odd `b>=5`, the corresponding pair-death contribution is `-3/2+1=-1/2`, and births leave `H` unchanged. At even `b>=2`, births contribute `3/2` and pair deaths contribute `-1/2`. Their unnormalized weighted sum is

`(3/2)(b+rho)-(5/2)b(b-1) <= 0`,

because `(b+rho)/(5b(b-1)) <= 3/10`, while `(3/2)(3/10)<=1/2`. This covers every positive integer `b`.

Stopping after a reaction that reaches `a<3` causes no problem: use the actual nonnegative value of `H` at that terminal state in this inequality. Apply the inequality up to the excursion stopping time truncated at any deterministic number of reactions. Nonnegativity of the terminal `H` gives an upper bound on the expected deaths counted up to that truncation. Monotone convergence then gives

`E[D | excursion starts with b=1] <= H(1)=2`.

If `D1_count` counts D1 reactions, then

`E[D1_count]=E[D]/5 <= 2/5`.

To justify the equality despite the stopping rule, sum over individual pre-stopping reaction indices. The event that an index is included is determined before choosing that reaction, and at its pre-reaction state the conditional probability of D1 is exactly one fifth of the probability of any pair death. The final reaction is included in both counts.

### Uniform exponential tail for the number of reactions

Define

`F(0)=0`, `F(1)=5`, and `F(b)=2^b` for `b>=2`.

For a reaction conditioned to change `b`, and with absorption at `b=0`,

`E[F(B_next) | (a,b), b-changing reaction] <= (4/5)F(b)`.

Indeed:

* At `b=1`, the ratio is `F(2)/F(1)=4/5`.
* At `b=2`, `p_b<=3/13`, and the ratio is `2p_b<=6/13`.
* At `b=3`, `p_b<=2/17`, and the ratio is `(5+11p_b)/8<=107/136<4/5`.
* At `b>=4`, `p_b<=1/13`, and the ratio is `2p_b+(1-p_b)/4<=5/13`. The probability bound follows from `12(b+rho)<=12(b+1)<=5b(b-1)`, whose last inequality is `(b-4)(5b+3)>=0`.

At a pre-stopping state, the probability of the self-in-`b` reaction I is at most `1/7`: the total rate of b-changing reactions is at least `(a)_3 b>=6`. Consequently the same inequality for the next full reaction, including I, is

`E[F(B_next), killed on excursion termination | (a,b)] <= gamma F(b)`,

where `gamma=1/7+(6/7)(4/5)=29/35<1`.

Killing the function when `a<3` only decreases the left side. If `N` is the number of full reactions until termination of an excursion starting at `b=1`, then every surviving state has `F>=4`. Iteration gives

`P(N>m | initial a>=3,b=1) <= (5/4)gamma^m`, for every integer `m>=0`.

Thus `N` is finite almost surely and has uniformly bounded exponential moments of sufficiently small positive order. This is a bound on the complete reaction chain, including U and I. It is not a claim that those reactions are absent.

## 2. Return cycles have uniformly positive drift

Start at any state `(a,0)` with `a>=3`. A cycle comprises its first reaction and, if that reaction is U, the subsequent excursion from `b=1` stopped as above. If its first reaction is I, the cycle terminates immediately at `(a+2,0)`. If it is U, the initial jump adds one A and the excursion terminates at `b=0` or at `a=2`. The latter is declared ruin. Freeze the cycle chain after ruin.

Let `A_n` be the A-coordinate at the start of cycle `n`, including the terminal value `2` if ruin occurs. Set subsequent increments to zero after ruin. Let `Delta_n=A_(n+1)-A_n`, and write `sigma` for the first cycle index with `A_sigma=2`. For every `n<sigma`,

`E[Delta_n | cycle history] >= mu`, where `mu=3/5`.

If the first reaction is I, the increment is two. If it is U, the increment is one plus all upward changes during the excursion minus its D1 count. The preceding death-count bound gives `E[Delta_n]>=1-2/5=3/5`, even if the excursion terminates in ruin.

Let `N_n` denote the number of post-initial reactions in this cycle; it is zero for an I cycle and after ruin. Its conditional tail has the preceding uniform bound. Since every jump changes `a` by at most two,

`|Delta_n| <= 2(N_n+1)`.

In particular, cycle increments have a uniform exponential moment and a uniform second-moment bound.

## 3. There is positive probability of avoiding ruin forever

For completeness, explicit constants can be used. Set

`eta=-(1/4)log(gamma)>0`, `r=sqrt(gamma)`,

`K=4 gamma^(-1/2) [1+(5/(4gamma))((1+r)/(1-r)^3-1)]`,

and `theta=min(eta,mu/K)>0`.

The excursion tail and `|Delta_n|<=2(N_n+1)` imply, uniformly before ruin,

`E[Delta_n^2 exp(eta |Delta_n|) | history] <= K`.

To see this directly, use `P(N_n=0)<=1` and `P(N_n=j)<=(5/4)gamma^(j-1)` for `j>=1`, and sum the power series `sum_(j>=0)(j+1)^2 r^j=(1+r)/(1-r)^3`.

Taylor's inequality `exp(-theta x)<=1-theta x+(theta^2/2)x^2 exp(theta|x|)` therefore gives

`E[exp(-theta Delta_n) | history] <= 1-theta mu/2 <=1`.

It follows that `exp(-theta A_(n wedge sigma))` is a nonnegative supermartingale. On ruin its terminal value is `exp(-2theta)`. Fatou's lemma gives, from any initial `a0>=3`,

`P(sigma<infinity) <= exp(-theta(a0-2)) <1`.

Thus the exact embedded reaction chain has positive probability of never reaching the stopped boundary.

## 4. A grows linearly and excursions remain short on survival

Let `m_n=E[Delta_n | cycle history]` and `M_n=sum_(j<n)(Delta_j-m_j)`. Uniform bounded second moments imply

`M_n/n -> 0` almost surely.

A direct justification is to apply the L2 martingale convergence argument to `sum_(j>=0)(Delta_j-m_j)/(j+1)`, whose sum of expected squared increments is finite, then apply Kronecker's lemma. These are ordinary square-integrable martingales; no independence of different cycles is asserted or required.

On `{sigma=infinity}`, each `m_n>=mu`, and consequently

`liminf_(n->infinity) A_n/n >= mu` almost surely.

Also take `L=3/(-log(gamma))` and `k_n=ceil(L log(n+2))`. The uniform conditional tail gives

`P(N_n>k_n)<=(5/4)(n+2)^(-3)`.

The first Borel-Cantelli lemma yields `N_n=O(log(n+2))` almost surely. In any cycle, every A-coordinate before a reaction is at least `A_n-N_n`. On survival, for all sufficiently large `n` these coordinates are at least `mu n/4`. This last observation controls the rate even during a downward fluctuation inside a cycle.

## 5. The holding times sum to a finite value

Conditional on the full embedded reaction chain, the expected holding time at `(a,b)` is the reciprocal of its total rate. The initial state of cycle `n` has `b=0` and rate

`q(A_n,0)=1+A_n(A_n-1)`.

Every post-initial state before that cycle terminates has `b>=1` and total rate

`q(a,b)>= (a)_3 b >= a(a-1)(a-2)`.

On the survival event, the preceding almost-sure bounds therefore give, for sufficiently large `n`,

`sum of reciprocal rates within cycle n <= C/n^2+C N_n/n^3`,

for a finite constant `C`. Summing over cycles is finite since `N_n=O(log(n+2))`. The finitely many earlier cycles have finitely many jumps and positive finite rates, so their reciprocal-rate sum is finite as well.

The unit exponential holding variables are independent of the entire embedded reaction chain. Thus, conditional on every chain in this probability-one subset of survival, the nonnegative sum of holding times has finite expectation and hence is finite almost surely. There are infinitely many cycles, each with at least one reaction. Their finite accumulated holding time is therefore an explosion time.

## 6. Reachability from `(0,0)`

The first reaction from `(0,0)` is necessarily I and reaches `(2,0)`. At `(2,0)` the rates of I and U are `1` and `2`; with probability `1/3`, the next reaction is I and reaches `(4,0)`. Both of these holding times are finite almost surely. Applying the proof from `a0=4` after this event gives the explicit strictly positive bound

`P_(0,0)(T_infty<infinity) >= (1/3)(1-exp(-2theta)) >0`.

This completes the proof for the supplied exact rates.

For orientation only, the displayed constants evaluate to `gamma=29/35`, `eta≈0.04701306`, `K≈17520.20`, `theta≈3.4246184e-5`, and the final lower bound is approximately `2.2830007e-5`. Positivity follows from the exact formulas, not these rounded numbers.

## Evidence and next gate

The mathematical conclusion is reconstructed here from the supplied network. The separate source-order/endotacticity and 2026 frontier statements are supplied by the coordinator and were not used as premises or independently checked here. The only external files read were the programme charter, repository interface instructions, and session template. The script `exact_checks.py` checks the displayed local inequalities with exact rational arithmetic over a finite range; the report's case analysis establishes them for every integer `b`, independently of that finite check.

The next decisive action is an independent adversarial proof audit of (i) the stopped-excursion death-count estimate, (ii) the full-chain exponential-tail inequality, and (iii) the passage from positive cycle drift to a finite sum of holding times. If those survive and geometric endotacticity is separately established, this is a source-order-five candidate counterexample to stochastic nonexplosion for that geometric class. External novelty and theorem verification remain UNKNOWN.
