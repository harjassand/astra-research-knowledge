# Centered local Petz entropy from uniform collective concentration

8 October 2026, thermal scientific lead. Internally reconstructed proof candidate. This freezes the proof before reading the fresh target-only derivation. The parent/integration supplied the directional generating-polynomial and real-polarization route as shared guidance. The exact normalization, constants, full proof and operational scope below were derived here. No entanglement assertion or matching upper protocol is inferred. External correctness, formal validation and historical priority are UNKNOWN.

## 1. Theorem

Fix d>=2, kappa>0, A>=1 and B>=0. Let rho_N be a permutation-invariant state on (C^d)^tensor N and let tau_N=rho_{N,1} satisfy tau_N>=kappa I. Suppose, for every Hermitian one-site H with ||H||op<=1 and every real t,

    Tr rho_N exp[t sum_{i=1}^N(H_i-Tr(tau_N H)I)]
       <= A exp(BNt^2).

Set s=d^2-1, alpha=r/N, and

    x=2e^2(B+2)s alpha/[kappa(1-alpha)^2].

For 1<=r<N and x<1,

    chi_P^2(rho_{N,r} || tau_N^tensor r)
       :=Tr[rho_{N,r}^2(tau_N^tensor r)^-1]-1
       <=A^2 x^2/(1-x),
    D(rho_{N,r} || tau_N^tensor r)<=A^2 x^2/(1-x).

In particular, for

    alpha<=min{1/2,kappa/[16e^2(B+2)s]},

one has the fully explicit uniform bound

    chi_P^2, D <=128 A^2 e^4(B+2)^2 s^2 kappa^-2 (r/N)^2.

Every r_N=o(N) eventually satisfies this range. At r=1 both quantities are exactly zero, for every N with faithful tau, independently of the numerical range. The theorem permits fixed faithful marginals far from I/d. It makes no within-sector, exact-weight, singlet, energy-diagonal or noncommuting-factorization assumption. A negative B cannot hold for a nonempty class for all t: scalar Jensen makes the centered MGF at least one, while A exp(BNt^2) would tend to zero. Thus taking B>=0 loses no legal instance.

## 2. Normalized centered one-site basis and complex Gram

Choose Hermitian traceless T_1,...,T_s with

    Tr(T_a T_b)=delta_ab.

These are Hilbert-Schmidt normalized; there is no extra factor d in the convention. Write b_a=Tr(tau_N T_a) and B_a=T_a-b_a I. Then tau_N=I/d+sum_a b_a T_a, and Tr(tau_N B_a)=0.

For inner product <U,V>_tau=Tr(tau U^dagger V), the identity has norm one and is orthogonal to all B_a. Their complex Hermitian Gram is

    G_ab=Tr(tau B_a B_b).

For v in C^s put W=sum_a v_a B_a. Tr(W^dagger W)=|v|^2+d|b dot v|^2, by tracelessness and the chosen normalization. Hence

    v^dagger Gv=Tr(tau W^dagger W)
       >=kappa Tr(W^dagger W)>=kappa|v|^2.

Therefore G>=kappa I. It is the full complex Gram, not its real covariance part. No closeness of tau to I/d is used.

For T=tau^tensor r and R=rho_{N,r} T^-1,

    ||R||_T^2=Tr(rho_{N,r}^2 T^-1),
    <B_Q,R>_T=Tr(rho_{N,r} B_Q^dagger)

for every product of centered operators on a support Q. The second equality follows by cyclicity cancelling the adjacent T^-1 T; rho need not commute with T. Products of I and the B_a form a complete basis, and distinct supports are orthogonal. Weighted Parseval gives exactly

    chi_P^2=sum_{nonempty Q} c_Q^dagger (G^-1)^tensor |Q| c_Q
            <=sum_{k=2}^r binom(r,k) kappa^-k ||C_k||_F^2.

Here C_k is the tensor with entries Tr[rho_N B_{a_1}^{(1)}...B_{a_k}^{(k)}]. Its entries are real because the Hermitian factors act on distinct sites, and it is symmetric by permutation invariance. All degree-one tensors vanish because tau is the actual marginal. Gram conditioning is charged on each support size k.

## 3. A complex scalar generating polynomial along every real direction

Let u in R^s have |u|=1, H_u=sum_a u_a T_a and X_u=H_u-Tr(tau H_u)I. Then H_u is Hermitian, ||H_u||op<=||H_u||HS=1, and ||X_u||op<=2. The assumption therefore applies exactly to sum_i X_u,i with no rescaling factor.

Define the entire degree-N scalar polynomial

    F_u(z)=Tr rho_N product_{i=1}^N(I+zX_u,i),   z in C.

All X_u,i commute, since they act on distinct sites. Simultaneously diagonalize them. The diagonal entries of rho in this product eigenbasis are a probability distribution, regardless of any off-diagonal entries of rho. For real eigenvalues x_i in [-2,2],

    |product_i(1+zx_i)|
       <=exp[(Re z)sum_i x_i+|z|^2 sum_i x_i^2/2]
       <=exp[2N|z|^2] exp[(Re z)sum_i x_i].

The first inequality follows from |1+a|<=exp(Re a+|a|^2/2), valid for every complex a, including a=-1. Average with the nonnegative diagonal weights, then use the supplied real MGF:

    |F_u(z)|<=exp(2N|z|^2) Tr rho_N exp[(Re z)sum_i X_u,i]
             <=A exp[(B+2)N|z|^2].

This is not a factorization of expectations. Only the same-axis site operators were simultaneously diagonalized, and the bound holds when rho does not commute with them.

Let P_k(u)=C_k[u,...,u]=Tr rho_N X_u,1...X_u,k. Permutation invariance gives the exact coefficient identity

    [z^k]F_u(z)=binom(N,k) P_k(u)=(N)_k P_k(u)/k!.

Cauchy at radius R^2=k/[2(B+2)N] gives, uniformly over real unit u,

    |P_k(u)|^2
      <=A^2 [k!/(N)_k]^2 exp(k)[2(B+2)N/k]^k.

No Hermitian bound is assumed for a general complex linear combination of different T_a. The scalar complex parameter z is handled by the commuting spectral inequality above.

## 4. Real polarization controls the full symmetric tensor

For a real symmetric k-linear form C and P(v)=C[v,...,v], the exact real polarization identity is

    C(v_1,...,v_k)
      =[1/(2^k k!)] sum_{epsilon_i in {-1,1}}
          (product_i epsilon_i) P(sum_i epsilon_i v_i).

To verify it, expand the homogeneous polynomial: summing each epsilon_i kills every monomial unless each v_i occurs an odd positive number of times. Total degree k then forces each to occur exactly once; the surviving coefficient is 2^k k! C(v_1,...,v_k).

For |v_i|<=1, each argument has length at most k. Homogeneity therefore gives

    |C(v_1,...,v_k)|<=k^k/k! sup_{|u|=1}|P(u)|.

There are s^k coordinate entries, so

    ||C_k||_F^2 <=s^k(k^k/k!)^2 sup_{|u|=1}|P_k(u)|^2
       <=A^2 s^k k^(2k)/(N)_k^2 exp(k)[2(B+2)N/k]^k.

The polarization loss k^k/k! is at most e^k. Its factorial cancels the coefficient's k! before the support sum. This is why the final bound has exponential rather than factorial degree growth. We have controlled all weights through growing r, not merely any fixed k.

## 5. Sum the support weights

Substitute Section4 into weighted Parseval. For k<=r, (N)_k>=N^k(1-alpha)^k and binom(r,k)<=r^k/k!. Also k^k/k!<=e^k; for example log(k!)>=integral_1^k log t dt=k log k-k+1. Thus each weight obeys

    binom(r,k) kappa^-k ||C_k||_F^2
      <=A^2 [2e^2(B+2)s alpha/(kappa(1-alpha)^2)]^k
      =A^2 x^k.

All degree-one coefficients are exactly zero. Summing k>=2 proves chi_P^2<=A^2 x^2/(1-x) whenever x<1. For alpha<=1/2, x<=8e^2(B+2)s alpha/kappa. The stated smaller finite range makes x<=1/2, so chi_P^2<=2A^2[8e^2(B+2)s/kappa]^2 alpha^2, precisely the theorem's constant.

## 6. KL without commutation and scope

Diagonalize rho_{N,r} and T, with eigenvalues lambda_i>=0 and mu_j>0 and overlaps c_ij=|<i|j>|^2. The weights lambda_i c_ij form a probability law. Scalar Jensen yields

    D(rho||T)=sum_ij lambda_i c_ij log(lambda_i/mu_j)
       <=log sum_ij lambda_i^2 c_ij/mu_j
       =log Tr(rho^2 T^-1)<=chi_P^2.

Zero lambda_i have zero weight and cause no support issue. This proves the KL conclusion without requiring simultaneous eigenbases.

The fully separable global product tau_N^tensor N has identical one-body data and is a legal null for a test sound on ALLSEP. Under independent fresh preparations and at most r distinct-site exposures per copy, the usual exchangeability slot simulation and entropy data processing give output TV<=sqrt(m C/2)(r/N), with C the displayed constant. Therefore a fixed output bias requires m=Omega(N^2/r^2). This is a necessary cost conditional on target concentration; it is not an entanglement assertion, and no target-power or matching upper protocol has been supplied. At r=1 exact equality makes discrimination from this product null impossible for every number of preparations.

An acquired concentration guarantee, faithful-marginal guarantee and unknown tau are not silently free experimental data. The theorem's premises are supplied mathematical/model conditions unless a separate measurement protocol acquires them. Arbitrary correlations across target preparations, non-PI access, coherent global-address queries and unrestricted stopping budgets are outside this conclusion.
