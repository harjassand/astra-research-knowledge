# Collective concentration gives centered local entropy at faithful marginals

The assigned theorem has a complete frozen internal proof in CONCENTRATION_PROOF_FROZEN.md. It was frozen before reading the independent target-only derivation. The directional generating/polarization route was supplied by the parent/integrator and is attributed as shared guidance. External correctness, formal validation and historical novelty remain UNKNOWN.

Let d>=2 be fixed, rho_N permutation invariant, tau=rho_1>=kappa I, and assume every Hermitian H with operator norm at most one obeys, for every real t,

    Tr rho_N exp[t sum_i(H_i-Tr(tau H)I)]<=A exp(BNt^2).

For s=d^2-1, alpha=r/N and x=2e^2(B+2)s alpha/[kappa(1-alpha)^2]<1, the proof gives

    chi_P^2(rho_r||tau^tensor r), D(rho_r||tau^tensor r)
       <=A^2 x^2/(1-x).

For alpha<=min{1/2,kappa/[16e^2(B+2)s]}, this is at most

    128 A^2 e^4(B+2)^2 s^2 kappa^-2 alpha^2.

Thus every subextensive r=o(N) is covered uniformly with explicit constants. The r=1 value is exactly zero without any size restriction. The marginal can stay a fixed distance from I/d.

The decisive proof uses Hilbert-Schmidt normalization Tr(T_a T_b)=delta_ab. Faithfulness makes the full complex centered Gram at least kappa I, on each support. A real unit direction defines a Hermitian H_u of operator norm at most one; its centered X_u has norm at most two. Simultaneous sitewise diagonalization bounds the scalar complex generating polynomial by A exp[(B+2)N|z|^2]. This does not factor expectations or assume rho commutes with the field. Cauchy controls each homogeneous directional coefficient. Exact real polarization has loss k^k/k!; its factorial cancels the generating coefficient factorial, and the support sum becomes geometric. All degrees through growing r are included. Weighted Petz Parseval and spectral-overlap Jensen handle noncommuting references.

The fixed matched product is a fully separable global comparator and implies a necessary Omega(N^2/r^2) fresh-preparation bound for any test that actually has a fixed target-versus-ALLSEP acceptance gap, under at most r distinct-site access per independent fresh copy. Arbitrary joint quantum processing and classical adaptive labels are allowed. The theorem does not assert that a concentration-class state is entangled, or supply any matched upper. Supplied concentration and faithfulness conditions are not free acquired experimental constraints.

Four finite d2/d3,N6,r2/r3 population fixtures check complex support Parseval and polarization through order four. The qutrit state/reference commutator norm is about .01518, so simultaneous diagonalization of that pair was not silently used. Two N300000,r2 fixtures satisfy the displayed finite range and have fixed faithful marginals away from white, with analytically valid A=1,B=1/2 concentration. Their N^2-scaled Petz chi-square values are approximately 1/3 and 2. All fixtures are fully separable, and the small N6 checks lie outside the theorem's finite range. The code uses double-precision matrices and does not constitute formal or all-state validation.

The fixtures are permutation twirls of fixed heterogeneous product populations. Conditional on an array, each H measurement has independent bounded outcomes with a fixed total mean; product Hoeffding proves the MGF for every H, and twirling preserves it. No finite direction grid is credited as proving the uniform MGF assumption. Their nontrivial local corrections show the result is applicable beyond a zero-error iid example.

The source repository was not edited. This folder contains only the frozen derivation, independently written finite diagnostics, result record, report and provenance. Fresh independent proof/audit comparison is coordinator-owned and was not read or assumed completed here.
