# Independent centered qudit correlation theorem

This proof was developed from the exact assigned statement and elementary Schur–Weyl inputs. No thermal-qubit, spin-tail, qudit-candidate, or integration-route proof was read. Historical novelty and external correctness remain unestablished.

## Statement with explicit, deliberately coarse constants

Fix an integer `d>=2`. Suppose a permutation-invariant density matrix `rho_N` on `(C^d)^tensor N` has Schur-sector weights `w_lambda`, and let

`K(lambda)=N-d lambda_d`.

Assume, for constants `A>=1`, `B,C>=0`,

`E exp(t K/sqrt(N)) <= A exp(B t^2+C t)` for every real `t>=0`.

The density matrix inside each unitary irrep can be arbitrary. Put `tau=rho_1` and define

`L=log(A)+B+C`,

`c0=A exp(B+1+C+2L)`,

`Gamma=2d(d^2-1)e^3 c0^2`,

`N0=max(4,ceil(4L^2))`.

Then, for `N>=N0`, `tau>=I/(2d)`. For every integer `1<=r<=N/4`,

`chi_P^2(rho_r || tau^tensor r) := Tr[rho_r^2 (tau^-1)^tensor r]-1`

`<= sum_{k=2}^r (Gamma r/N)^k`.

In particular, whenever `Gamma r/N<1`,

`chi_P^2 <= (Gamma r/N)^2/(1-Gamma r/N)`.

Consequently, in the finite range `1<=r<=N/(2Gamma)`,

`chi_P^2 <= 2Gamma^2(r/N)^2`.

The latter range automatically implies `r<=N/4`, because the displayed `Gamma` exceeds two. Thus the desired `O_{d,A,B,C}((r/N)^2)` holds uniformly along every sequence `r=o(N)`. For `r=1` the divergence is exactly zero. The quantum relative entropy satisfies the same bound, and more precisely

`D(rho_r || tau^tensor r) <= log(1+chi_P^2)`.

All logarithms are natural.

## 1. The determinant twist and the one-site marginal

Write `m=lambda_d` and `mu=lambda-m(1,...,1)`. Then `mu` is a partition of `K=N-dm` with at most `d` rows and nonnegative entries. The Schur representation identity is

`pi_lambda(G) = det(G)^m pi_mu(G)`

up to a unitary intertwiner, for every invertible complex `d` by `d` matrix `G`.

Here and below the intertwiner is suppressed without changing operator norms or density-matrix traces. This identity follows directly from the highest-weight classification: tensoring the irreducible `pi_mu` by the one-dimensional character `det^m` preserves irreducibility and adds `(m,...,m)` to its highest weight. For completeness, the unitary intertwiner also intertwines the polynomial extensions to `GL_d(C)`. Differentiate its equality on `exp(itH)` for Hermitian `H`, extend the generator identity by complex linearity, and exponentiate to get the equality on `exp(H)`. Polar decomposition `G=U exp(H)` then gives it on all invertible `G`.

By Schur–Weyl duality, `pi_mu` has an isometric copy inside `(C^d)^tensor K`. Restricting `G^tensor K` to that invariant copy gives

`||pi_mu(G)|| <= ||G||^K`.

Neither statement requires a highest-weight density matrix. They apply to every state on the irrep.

For a Hermitian one-site observable `H`, the collective generator `J_H=sum_{i=1}^N H^(i)` acts on the `lambda` sector as

`J_H = m Tr(H) I + J_H^(mu)`.

Transport any sector state to `pi_mu` and embed it into `K` tensor factors, taking the identity on the multiplicity if desired. Its average one-site marginal is a density matrix `theta_lambda`, so

`N tau_lambda = m I+K theta_lambda`.

For `K=0`, the second term is zero and `theta_lambda` may be chosen arbitrarily. Averaging over sectors, and putting `q=E K/N`, gives the exact identity

`tau=(1-q)I/d+q theta`

for some density matrix `theta`. Thus

`tau >= (1-q)I/d`, and `||tau-I/d||_1 <= 2q`.

Jensen applied at `t=1` yields `E K/sqrt(N)<=L`. Hence `q<=L/sqrt(N)`. For `N>=4L^2` this proves `tau>=I/(2d)`, including the case `L=0`.

## 2. An exact generating function for centered moments

For any complex matrix `X` satisfying `Tr(tau X)=0`, define

`p_X(z)=Tr[rho_N (I+zX)^tensor N]`.

Permutation invariance gives the exact polynomial identity

`p_X(z)=sum_{k=0}^N binom(N,k) z^k T_k(X,...,X)`,

where the symmetric complex multilinear form is

`T_k(X_1,...,X_k)=Tr[rho_k (X_1 tensor ... tensor X_k)]`.

This symmetry concerns tensor positions; it does not assert that the matrices `X_i` commute.

Let `M=||X||` and `u=|z|M<=1/2`. The preceding marginal identity gives

`|Tr(X)|/d = |Tr[(I/d-tau)X]| <= 2L M/sqrt(N)`.

The convergent matrix-logarithm expansion gives

`log|det(I+zX)| <= |z| |Tr(X)| + d sum_{j>=2} u^j/j`.

For `u<=1/2`, the last series is at most `u^2`, because

`sum_{j>=2}u^j/j <= u^2/(2(1-u)) <= u^2`.

Since `m<=N/d`, each sector therefore satisfies

`|det(I+zX)|^m <= exp(2L sqrt(N)u+Nu^2)`.

Also `||I+zX||<=1+u<=exp(u)`, so its nonrectangular representation factor has norm at most `exp(Ku)`. For any sector density matrix `D_lambda`, even when it does not commute with that factor,

`|Tr[D_lambda pi_lambda(I+zX)]| <= |det(I+zX)|^m exp(Ku)`.

Sum the sector weights and use the assumed MGF at `t=s=sqrt(N)u`. The result is the uniform complex-circle bound

`|p_X(z)| <= A exp((B+1)s^2+(C+2L)s)`.

This is the only point using the MGF for values of `t` that grow with correlation order.

For `1<=k<=N/4`, choose the Cauchy radius

`R=sqrt(k)/(M sqrt(N))`.

Then `u=sqrt(k/N)<=1/2`, so the above estimate is valid. If `X=0`, the conclusion below is immediate and no radius is needed. Cauchy's coefficient bound gives

`binom(N,k) |T_k(X,...,X)|`

`<= A exp((B+1)k+(C+2L)sqrt(k)) (M sqrt(N)/sqrt(k))^k`.

Using

`binom(N,k)=product_{j=0}^{k-1}(N-j)/(k-j) >= (N/k)^k`,

and `A exp((B+1)k+(C+2L)sqrt(k)) <= c0^k`, we obtain

`|T_k(X,...,X)| <= (c0 ||X|| sqrt(k/N))^k`.  (1)

Every bound is uniform over all irrep density matrices and all allowed sector-weight distributions.

## 3. Mixed centered moments

Suppose `Tr(tau X_i)=0` and `||X_i||<=M0`, for `i=1,...,k`. Each signed sum remains centered. The exact polarization identity for a symmetric complex multilinear form is

`T_k(X_1,...,X_k)`

`=1/(2^k k!) sum_{epsilon in {+1,-1}^k} (product_i epsilon_i) T_k(sum_i epsilon_i X_i,...,sum_i epsilon_i X_i)`.

To verify it, expand each diagonal value. Summing the signs kills every monomial except one in which each of the `k` arguments occurs an odd number of times. Since total degree is `k`, every argument occurs exactly once, producing the factor `2^k k!`.

Apply (1) to each signed sum, whose norm is at most `k M0`. The elementary inequality `k^k/k!<=e^k` gives

`|T_k(X_1,...,X_k)| <= (e c0 M0 sqrt(k/N))^k`.  (2)

The polarization cost is exponential in `k`, with a constant independent of `N`; it does not add an uncontrolled factorial growth.

## 4. The legal noncommuting weighted basis

On the space of all complex `d` by `d` matrices, choose an orthonormal basis

`A_0=I, A_1,...,A_D`, with `D=d^2-1`,

for the genuine complex Hilbert inner product

`<A,B>_tau = Tr(tau A^dagger B)`.

Thus `Tr(tau A_a)=0` for `a>=1`. Since `tau>=I/(2d)`,

`||A_a|| <= ||A_a||_HS <= sqrt(2d)=M0`.

Put `B_a=A_a tau`. These matrices need not be Hermitian. They are an orthonormal basis for the equally genuine density-matrix Hilbert inner product

`<Y,Z>_{tau,-1}=Tr(Y^dagger Z tau^-1)`.

Indeed,

`Tr(B_a^dagger B_b tau^-1)=Tr(tau A_a^dagger A_b)=delta_ab`.

For an arbitrary matrix `Y`, its coefficient against this basis is exactly

`<B_a,Y>_{tau,-1}=Tr(A_a^dagger Y)`.

This uses cyclicity of the trace, with `tau^-1 tau` adjacent after cycling. It makes no commutation assumption on `Y` and `tau`.

Tensor these bases on `r` sites. The coefficient of `rho_r` at `alpha=(a_1,...,a_r)` is

`c_alpha=Tr[rho_r (A_{a_1}^dagger tensor ... tensor A_{a_r}^dagger)]`.

The product state `sigma=tau^tensor r` has coefficient one at the all-zero multi-index and zero elsewhere. For exactly one active position, `c_alpha=Tr(tau A_a^dagger)=0`. Therefore the centered divergence has the exact Parseval expansion

`||rho_r-sigma||_{sigma,-1}^2 = sum_{alpha with at least two active positions}|c_alpha|^2`.

The left side is exactly the assigned quantity:

`Tr[(rho_r-sigma)^2 sigma^-1]=Tr(rho_r^2 sigma^-1)-1`.

The two cross terms each equal one by trace cyclicity. This identity remains valid when `rho_r` does not commute with `sigma`.

## 5. Summing the correlation orders

There are `binom(r,k) D^k` multi-indices with exactly `k` active positions. For each, the active observables are `A_a^dagger`, which are centered and satisfy the same norm bound `M0=sqrt(2d)`. Equation (2) gives

`|c_alpha|^2 <= (e^2 c0^2 M0^2 k/N)^k`.

Consequently,

`chi_P^2 <= sum_{k=2}^r binom(r,k) D^k (e^2 c0^2 M0^2 k/N)^k`.

Use `binom(r,k)<=r^k/k!` and `k^k/k!<=e^k` once more. The `k`th term is at most

`(D e^3 c0^2 M0^2 r/N)^k = (Gamma r/N)^k`.

This proves the finite-sum bound, the geometric-series bound, and the requested uniform centered rate.

## 6. Quantum relative entropy, without a commutation assumption

For any density matrices `rho` and full-rank `sigma`, diagonalize them separately as

`rho=sum_i p_i |u_i><u_i|`, `sigma=sum_j q_j |v_j><v_j|`.

The nonnegative numbers `w_ij=p_i |<u_i,v_j>|^2` sum to one. Terms with `p_i=0` have zero weight. Hence

`D(rho||sigma)=sum_{ij} w_ij log(p_i/q_j)`.

Scalar Jensen gives

`D(rho||sigma) <= log(sum_{ij} w_ij p_i/q_j)`

`=log Tr(rho^2 sigma^-1)`.

Apply this to `rho_r` and `tau^tensor r`. This proves the asserted KL corollary directly, without importing monotonicity of quantum Rényi divergences.

## Dependencies, independent scope and limitations

The only representation-theoretic inputs are unitary Schur–Weyl decomposition, classification of unitary irreducibles by dominant highest weights, and their tensor realization. The determinant twist and its complex extension were derived above. Cauchy's coefficient inequality, matrix-logarithm power series, finite-dimensional Gram–Schmidt, polarization, Jensen and elementary factorial estimates are the remaining ordinary inputs.

The primary [Christandl–König–Mitchison–Renner paper](https://arxiv.org/pdf/quant-ph/0602130v4), Section II.A, printed p.2, states the highest-weight classification used here; Section III.A, printed p.6, equations (10)–(11), gives the unitary tensor Schur–Weyl decomposition. Its de Finetti approximation theorem is not used. The polynomial matrix-action interface was also checked in [A Quantum Method of Types](https://arxiv.org/html/2606.27442v1), Section II.2, equation (4) and the following display. No conclusion from that paper is used to establish the centered rate.

This is an independent complete candidate derivation, not a formal proof certificate or external specialist validation. The constants are intentionally coarse and make no optimal finite-fraction assertion. The full MGF assumption is substantive; first or second moment control alone does not supply the high-order Cauchy estimate. No historical-novelty or priority claim is made.
