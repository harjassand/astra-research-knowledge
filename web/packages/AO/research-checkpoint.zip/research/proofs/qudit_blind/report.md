# Independent qudit theorem attack

The stated theorem has a complete independent candidate proof. No counterexample or missing lemma was found. The derivation covers every density matrix inside every unitary irrep, and uses the stipulated sector MGF exactly. It does not assume sector states are coherent, diagonal, thermal, or commuting with their one-site marginal.

Let

`L=log(A)+B+C`, `c0=A exp(B+1+C+2L)`,

`Gamma=2d(d^2-1)e^3 c0^2`, `N0=max(4,ceil(4L^2))`.

For `N>=N0`, the one-site marginal satisfies `tau>=I/(2d)`. For every integer `1<=r<=N/4`,

`Tr[rho_r^2 (tau^-1)^tensor r]-1 <= sum_{k=2}^r (Gamma r/N)^k`.

Thus if `Gamma r/N<1`, the upper bound is `(Gamma r/N)^2/(1-Gamma r/N)`, and for `r<=N/(2Gamma)` it is at most `2Gamma^2(r/N)^2`. This proves the requested uniform centered order for all `r=o(N)`, with deliberately coarse finite constants. The quantum relative entropy is at most the logarithm of one plus this divergence, by a direct noncommuting spectral-basis Jensen argument.

The original derivation is in `proof.md`. Its mechanism is:

1. Remove the rectangle: `lambda=m(1,...,1)+mu`, `|mu|=K`. The unitary highest-weight classification gives the determinant twist, including its polynomial complex extension. Schur–Weyl tensor realization yields `||pi_mu(G)||<=||G||^K`.
2. Differentiating the same identity gives the exact marginal decomposition `tau=(1-EK/N)I/d+(EK/N)theta`. The MGF at one bounds `EK<=L sqrt(N)`, proving eventual invertibility and a uniform local norm bound.
3. The exact generating polynomial `p_X(z)=Tr rho_N(I+zX)^tensor N` encodes all equal-direction moments. For `Tr(tau X)=0`, determinant power-series bounds and the MGF give `|p_X(z)|<=A exp((B+1)s^2+(C+2L)s)` on the complex circle, with `s=sqrt(N)|z| ||X||`. Cauchy gives order-k moments bounded by `(c0 ||X|| sqrt(k/N))^k`.
4. Exact polarization costs only an exponential constant per order. A complex weighted observable basis with density duals `B_a=A_a tau` is legal without commutation. Its tensor Parseval expansion removes orders zero and one exactly. Counting the remaining subset orders produces the geometric series in `r/N`.

The determinant identity, noncommuting Parseval expansion, polarization cost, and binomial denominator were checked directly after deriving the proof. Two finite noncommuting matrix diagnostics agree with the Parseval identity; an independently constructed `N=4`, `d=2`, `lambda=(3,1)` state also agrees with the determinant twist and marginal identity. Their errors are below `3e-16`. These finite checks validate those interfaces only, not the uniform theorem or general representation classification.

The primary [Christandl–König–Mitchison–Renner source](https://arxiv.org/pdf/quant-ph/0602130v4), printed pp.2 and 6, was opened for highest-weight classification and the tensor Schur–Weyl decomposition. The actual PDF is retained, SHA256 `5cce8eaa19b93b5a17fdabc2a09fb4f93d27ae960bdc51863b081419e109e55d`. The polynomial matrix-action interface was checked in [A Quantum Method of Types, Section II.2](https://arxiv.org/html/2606.27442v1). Neither paper's de Finetti or approximation proof supplies the centered estimate.

No excluded thermal-qubit, spin-tail, qudit-candidate, marginal-blind, or integration-route proof was read. The only supplied data were the exact statement and established Schur–Weyl inputs. `freeze_v1.json` records the completed proof's frozen hash, and `source_manifest.json` records sources and finite diagnostics.

Status: **independently reconstructed candidate theorem**, complete under the ordinary representation inputs stated in the problem. No formal replay, external expert validation, or historical-novelty clearance. No claim of optimal constants. The next decisive action is an independent adversarial read of `proof.md`, especially the complex determinant twist and the tensor weighted Parseval step; preserve this frozen proof before exposing it to another route.
