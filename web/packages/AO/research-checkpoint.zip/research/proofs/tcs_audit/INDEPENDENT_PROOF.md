# Independent reconstruction of the observation-branch lemma

Audit target: the frozen `work/agents/tcs/PROOF.md`, SHA-256 `6b2ff5ad9c172f3bfda5dd1f261ce6a42b7b3be16843b602474932cbc0852e1b`. The candidate derivation was visible before this reconstruction. This is an adversarial internal audit, not a blind audit, formal proof, external review, or priority determination.

## Exact finite interface and conventions

All variables below have finite support; zero-mass states are removed. Let `S` contain `(X,Y,U,V)`. Its additional registers can have an arbitrary joint law with these variables. The marginal factorization required is

`law(X,Y,U,V) = law(X,Y) law(U) law(V)`.

Write `rho_*` for the maximal correlation of `(X,Y)`: the supremum of `|E[a(X)b(Y)]|` over centered local functions with unit second moment. If either local centered space is zero-dimensional, set `rho_*=0`. A supplied certificate `rho` satisfies `rho_* <= rho < 1`; it need not be sharp.

For each side `i`, a selector `L_i` is independent of `S`. Two disjoint branches `A` and `B` have probabilities `p_iA,p_iB >= eta`, where `0 < eta <= 1/2`. Conditional on branch `A`, the observation is a channel from `(X,U)` using randomness independent of `S`; conditional on `B`, it is a channel from `(Y,V)` using such randomness. The remaining branches are arbitrary channels from `S`. Assume the actual observations `Q_0,Q_1` are conditionally independent given `S`.

These hypotheses include observable branch labels, arbitrary independent local coins, unequal branch probabilities and side-dependent remaining channels. The proof does not need to append channel coins or assume the enriched observations remain conditionally independent. It uses conditional independence only for the original observations.

The pair-resampling chain is the positive self-adjoint operator `T=(P_Q0+P_Q1)/2` on `L2(law(Q_0,Q_1))`. Here `P_Qi` is conditional expectation onto the corresponding local observation. On a non-singleton connected pair support, its gap is `1-||T||` on the centered space. On a singleton, use the explicit convention `gap=1`.

## 1. The local correlation estimate survives auxiliary blocks

For centered `a(X,U)` and `b(Y,V)`, independence gives

`E[ab] = E[E[a|X] E[b|Y]]`.

The conditional means are centered and conditional expectation contracts the second moment. Therefore

`|E[ab]| <= rho ||a||_2 ||b||_2`.

This uses only the specified marginal factorization. Correlated hidden registers in `S` do not enter this calculation.

Set `P_A f=E[f(S)|X,U]` and `P_B f=E[f(S)|Y,V]`. For centered `f`, write `a=P_A f`, `b=P_B f`, and `D=||a||^2+||b||^2`. Then

`||a+b||^2 <= D+2rho||a||||b|| <= (1+rho)D`,

and orthogonal projection gives

`D=<f,a+b> <= ||f|| sqrt((1+rho)D)`.

For `D=0` the desired inequality is immediate. Otherwise division yields

`||P_A f||^2+||P_B f||^2 <= (1+rho)||f||^2`.       (A)

Equivalently, the sum of the two conditional-variance losses is at least `(1-rho)||f||^2`.

## 2. Bound each observation by conditioning on its selector

Fix one side. Conditioning on an additional variable can only increase the squared norm of a conditional mean, so

`||E[f|Q_i]||^2 <= ||E[f|Q_i,L_i]||^2`.

The independence of `L_i` and `S` means that the unconditional law of `S` is the same on each branch. On branch `A`, the Markov property gives

`E[f|Q_i,L_i=A] = E[P_A f|Q_i,L_i=A]`,

whose squared norm is at most `||P_A f||^2`. Similarly branch `B` costs at most `||P_B f||^2`; any remaining branch costs at most `||f||^2`. Consequently

`||E[f|Q_i]||^2 <= p_iA||P_A f||^2 + p_iB||P_B f||^2 + (1-p_iA-p_iB)||f||^2`

`<= eta(||P_A f||^2+||P_B f||^2) + (1-2eta)||f||^2`

`<= [1-eta(1-rho)]||f||^2`.                     (B)

The middle step follows directly from `p_iA,p_iB >= eta` and projection contraction; no branch-splitting construction is needed. Put `lambda=1-eta(1-rho)`.

## 3. Conditional independence gives the maximal-correlation bound

Let `C_i g=E[g(Q_i)|S]`; its adjoint is `C_i^* f=E[f(S)|Q_i]`. Both preserve centering. Inequality (B) gives `||C_i^*|| <= sqrt(lambda)`, and hence `||C_i|| <= sqrt(lambda)` on the centered spaces.

For centered functions `g_0(Q_0),g_1(Q_1)`, conditional independence gives

`E[g_0 g_1] = E[C_0 g_0 C_1 g_1]`.

Cauchy-Schwarz and (B) now yield

`|E[g_0g_1]| <= lambda ||g_0|| ||g_1||`.

Thus `rho_max(Q_0,Q_1) <= 1-eta(1-rho) < 1`. This proves the candidate's central bound without enlarging the pair observations.

## 4. Gap and connectedness, including degenerate spaces

For any centered pair function `f(Q_0,Q_1)`, repeat (A) with local projections `P_Q0,P_Q1` and their actual maximal correlation `rho_out`. The result is

`<f,Tf> <= (1+rho_out)||f||^2/2`.

Since `T` is positive self-adjoint,

`sigma_out >= (1-rho_out)/2 >= eta(1-rho)/2`.

The bipartite positive-mass question-support graph is connected: otherwise its component identifier is a nonconstant function of both observations, giving maximal correlation one. The corresponding resampling chain is connected for the same reason. A singleton output support has the conventionally assigned gap one and obeys the lower bound as well.

For any non-singleton connected finite original pair law, the exact identity is

`sigma_in = (1-rho_*)/2`,

not `(1-rho)/2` for an arbitrary upper certificate. To see equality when `rho_*>0`, choose maximizing unit singular vectors `a(X),b(Y)` with `E[b|X]=rho_*a` and `E[a|Y]=rho_*b`; then `a+b` is a resampling eigenfunction with eigenvalue `(1+rho_*)/2`. If `rho_*=0`, a nonconstant local function on either nondegenerate marginal is an eigenfunction with eigenvalue `1/2`. This also covers a constant variable paired with a nonconstant one. A singleton original pair has gap one by convention and `rho_*=0`, so it is the exception to the displayed identity.

Instantiating the theorem with `rho=rho_*` proves the convention-safe comparison

`sigma_out >= eta min(sigma_in,1/2)`.

## 5. Sharpness from a covariance witness

Let `X,Y` be signs with `Pr(X=x,Y=y)=(1+rxy)/4`, `0<=r<1`; their maximal correlation is exactly `r`. Take independent branch selectors with probabilities `(eta,eta,1-2eta)`, tagged outputs `A:X`, `B:Y`, and `F:(X,Y)`. Independent `U,V` and arbitrary extra registers may be appended in the full branch without changing this witness.

Let `f=X+Y`, so `Var(f)=2(1+r)`. The conditional mean `g(Q)=E[f|Q]` is `(1+r)X` on `A`, `(1+r)Y` on `B`, and `X+Y` on `F`. Hence, with `lambda=1-eta(1-r)`,

`E[g(Q)|S]=lambda f`,

`Var(g)=lambda Var(f)`,

`Cov(g(Q_0),g(Q_1))=lambda^2 Var(f)`.

The last equality uses conditional independence. Therefore this pair of local witnesses has correlation exactly `lambda`. The upper bound is attained. Moreover `E[g(Q_1)|Q_0]=lambda g(Q_0)` and its reverse, so `g(Q_0)+g(Q_1)` is a pair-resampling eigenfunction with eigenvalue `(1+lambda)/2`. Thus the gap bound is also attained, including `eta=1/2` where the full-disclosure branch has probability zero.

The constants `eta` and `1/2` are consequently optimal for this interface.

## 6. Premises that cannot be silently dropped

* **An upper bound is not the exact correlation.** Independent nonconstant signs have `rho_*=0` and original gap `1/2`, but also satisfy the input estimate with the supplied bound `rho=1/2`. The formula `(1-rho)/2` then equals `1/4`, not the gap. This falsifies frozen line 23 as an equality under its initial use of `rho`, while leaving the main inequalities intact.
* **The singleton convention needs the cap.** Let `(X,Y)` be constant, but let independent `U,V` be signs. Use `A:U`, `B:V`, `F:(U,V)` with the same branch probabilities. The sharpness calculation with `r=0` gives output gap `eta/2`. Since the original singleton gap is one, the uncapped assertion `sigma_out>=eta sigma_in` is false.
* **Seed-dependent selectors can transmit hidden information.** Let independent signs `(X,Y)` have `rho_*=0`. On both sides choose branch `A` iff `X=1` and branch `B` otherwise, and retain the tag. Each branch has mass `1/2`; its content can be restricted to `X` or `Y` as named. Both outputs nevertheless reveal `X` from the tag, so maximal correlation is one. These selectors are not independent of `S`.
* **Point outputs cannot carry a common extra register.** If a hidden uniform sign `R` is appended to every branch on both sides, then `R` is a common observation and maximal correlation is one. Arbitrary hidden registers are harmless only because the specified clear branches exclude them.
* **Pairwise auxiliary independence is insufficient.** With independent uniform bits `X,Y,U`, set `V=U xor X xor Y`. The random objects `U`, `V`, and `(X,Y)` are pairwise independent, but not mutually independent. Both `(X,U)` and `(Y,V)` reveal the common bit `X xor U=Y xor V`, so even legal-looking point-only outputs have correlation one. The explicit marginal factorization at the start of this reconstruction, which is the intended reading of frozen line 11's “factorization,” excludes this example.
* **Postselection changes the law.** Starting with independent signs, condition successful execution on `X=Y`. Every `A` or `B` point view then reveals the same sign, so output correlation is one. The original bound `rho_*=0` no longer applies to the conditional input law. A timeout/error exclusion must hold almost surely for the fixed regime, or the resulting conditional law must be audited separately.

The exact fixture script checks the sharp covariance witness, its resampling eigenfunction, the singleton cap and these premise failures using rational arithmetic. Those checks are scoped evidence, not a substitute for the general proof above.
