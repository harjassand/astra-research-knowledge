# Audit verdict

The finite observation-branch theorem is **internally reconstructed and passes this adversarial audit**. Its maximal-correlation bound `rho_out <= 1-eta(1-rho)` and gap bound `sigma_out >= eta(1-rho)/2` are correct and sharp under the stated finite-law interface. I supplied a conditional-variance proof that avoids enlarging both observations by their channel coins; see `INDEPENDENT_PROOF.md`.

This audit saw the original derivation before reconstructing it. It is not blind, formal, external validation, or evidence of historical novelty. The inherited L02 theorem and full compression theorem were not audited or certified.

## Corrections to the frozen statement

The target SHA-256 is `6b2ff5ad9c172f3bfda5dd1f261ce6a42b7b3be16843b602474932cbc0852e1b`; a snapshot is retained as `PROOF_frozen.md`.

1. **Frozen line 23 is false as an equality with a merely supplied upper bound.** Independent fair signs have actual maximal correlation zero and gap `1/2`, but satisfy the input certificate with `rho=1/2`; `(1-rho)/2=1/4`. Write the identity using actual `rho_max`. The theorem's inequalities remain correct. The convention-safe gap comparison is `sigma_out >= eta min(sigma_in,1/2)`.
2. **Frozen line 94's equality `=(sigma_mu)/9` needs non-singleton input support.** Its preceding `(1-rho_mu)/18` lower bound is correct with `rho_mu` equal to actual correlation. For a singleton input, keep `min(sigma_mu,1/2)/9`; frozen Section 1 already recognizes this convention but Section 5 must carry it forward.
3. **Frozen line 100's universal `>=1/36` assumes `t>=1`.** State that assumption explicitly. The `t=2` arithmetic `>=1/24` is correct.
4. **Successful execution must exclude fallback almost surely, not merely condition on an arbitrary success event.** The original law and selector independence can be destroyed by data-dependent postselection. The fixed large-`n` regime must have no fallback for any positive-mass seed, or a fresh law proof is needed. This is the intended reading of frozen line 104, not an automatic consequence of saying “in the no-error branch.”

The intended auxiliary independence must be the joint factorization `law(X,Y,U,V)=law(X,Y)law(U)law(V)`. Pairwise independence of the random objects `(X,Y),U,V` is insufficient; the exact XOR fixture in the reconstruction exhibits a common point-view bit under that weaker interpretation. This clarification is consistent with frozen line 11's express reference to marginal factorization.

## Exact source application boundary

I independently downloaded [Lin's arXiv v1 source](https://arxiv.org/src/2510.07162v1). Its three relevant TeX files match the candidate's local copies byte-for-byte; hashes are in `source_manifest.json`. I read the exact sampling figure, answer-reduction contract, CL definition, actual detyping construction, and low-degree import. This establishes source identity and scoped reading; it does not validate all of the paper.

For the **literal idealized sampling figure**, with the intended independent uniform role and test labels, valid disjoint point blocks, and almost-sure successful execution, the two clear views are exactly `(Prover A,Point,x,s_0)` and `(Prover B,Point,y,s_1)`. Each has mass `1/9`. The base questions are separately sampled from `mu` and the point blocks are mutually independent and independent of them. Conditional on a pre-sampled seed containing the point blocks and all potential line randomness, local independent selectors generate conditionally independent observations. Every remaining branch may be bounded by full-seed disclosure. Therefore the **question-law** bound

`sigma_Figure >= (1-rho_max(mu))/18`

is proved by the general lemma. Low-degree soundness, answer predicates and commuting strategies do not enter that assertion. Bit-versus-field encoding does not affect this finite-law calculation once the point blocks are valid disjoint independent variables, but it does matter to the claimed low-degree/CL implementation.

The actual named CL sampler has a decisive unresolved interface mismatch:

* `CondLineardist.tex` **107–113** defines a CL law as the deterministic output of a uniform finite seed in `F_{2^ell}^m`. Every event therefore has probability `k/2^(ell m)`, a dyadic rational.
* `Answerreduction.tex` **588, 592** gives the recognizable `Prover A` role probability `1/3` in the no-fallback Figure. This event alone is not dyadic. The `A/Point` mass `1/9` is another obstruction under uniform test labels.
* Consequently **no finite CL sampler in the cited definition can realize that literal Figure law exactly**. Merely asserting series composition at `Answerreduction.tex` **683** cannot establish equality of these laws.
* The source itself introduces a different dyadic oracularization at `Answerreduction.tex` **200–211**: independent two-bit role labels with an added `11` free-win label, and an Ora view revealing the entire input seed. This confirms that the implemented law can differ from the Figure. Its four roles do not give the Figure's `1/3` role masses.
* The low-degree source import is also a different law: `CondLineardist.tex` **161–208, 425–428** detypes the typed test and exposes extra prefix/neighbor-mask/gate registers. The source explicitly uses this CL version for subsequent low-degree tests. These are not simply iid Point/DLine/ALine labels with point-only contents. The fully composed answer-reduction wires and their actual clear subbranch probabilities are not supplied by the one-paragraph level claim.

This is an exact **failure of a Figure-equals-CL identification**, not a counterexample to the finite probability theorem and not a refutation of the paper's global result. A corrected dyadic implementation may still have a substantial gap, potentially by identifiable erasure branches, but it needs its own exact-law reconstruction.

Thus `(8)` is internally proved for the idealized Figure. Combining its `eta=1/9` with the named `max{k+2,6}` CL level for one verified implementation remains **UNKNOWN/conditional**. The arithmetic of `(9)` and the sufficient repetition coefficients is correct if their separate premises hold. The current audit does not accept the claimed saved CL level/six coordinates as a realized end-to-end advantage, and does not certify L02, answer-reduction soundness, global compression, or novelty.

## Evidence and next decisive action

`exact_checks.py` uses rational arithmetic for sharpness and failure fixtures; `exact_checks.json` records the results. It checks a covariance witness and the corresponding resampling eigenfunction, rather than inferring an exact theorem from floating-point eigenvalues. The archive/file hashes establish provenance only.

The next decisive obligation is to provide the actual dyadic final sampler: every register, every local gate and role label, its probability, the full point/erasure outputs, and the predicate used on all extra/dummy cases. Prove that its positive-mass clear subbranches are independent of the remaining shared seed and contain only one legal base question plus independent local randomness. Apply the present theorem with that sampler's actual `eta`; separately retain its soundness and CL-level proof obligations. Until then, the named CL application remains conditional.
