# Exact CL law cannot equal the displayed answer-reduction law

Status: elementary exact arithmetic obstruction reconstructed here. It concerns the equality of two specified sampler laws, not the validity of Lin's complexity-class theorem.

## Finite dyadic law lemma

A (k,m,p)-CL sampler in Lin Definition 5.5 draws one seed uniformly from F_(2^p)^m and returns deterministic conditionally linear maps L^A(seed), L^B(seed). For any recognizable output event E,

    Pr[E] = |{seed : output(seed) in E}| / 2^(p m).

Every such probability is dyadic. The CL levels and the conditional linear maps do not alter this counting fact.

For all integers N>=0 and K, K/2^N cannot equal 1/3: equality would imply 3K=2^N, contradicting unique prime factorization. Thus no exact finite CL sampler has a recognizable event of probability 1/3.

## Apply to the printed source

Lin arXiv:2510.07162v1, Answerreduction.tex lines 587-602 / Figure 12 / PDF page index 102 (printed page 102) says each prover's role is selected uniformly from {Prover A,Prover B,Ora}. Only Ora is subsequently refined; the probability that the final output role is Prover A is still exactly 1/3. The role appears explicitly in the output label. In the promised successful, no-timeout regime, this event is recognizable and has probability 1/3.

Therefore no finite CL sampler exactly realizes that displayed law. This does not depend on the details of the low-degree sampler, field-versus-bit padding, or the corrected detyping predicate.

The source itself exposes the intended different implementation: Answerreduction.tex lines 200-211 implements the oracularization selector by four uniform bit labels 00,01,10,11, and explicitly gives label 11 a free win. Prover A and Prover B then each have marginal mass 1/4, not 1/3. The paper acknowledges a constant-factor soundness change at this earlier stage. Its final line-683 CL-composition paragraph calls the Figure 12 law 'essentially' an oracularization plus a low-degree test, but does not give the complete modified final law or propagate every modified register and predicate there.

The correct conclusion is a required interface correction: the final literal Figure 12 probability law cannot be the exact CL law. A four-label implementation may be perfectly usable, but its complete output law, predicate, completeness/soundness losses, and independent low-degree register structure must be stated and audited. No conclusion is drawn that such a repair is impossible, or that MIPco=coRE is false.

## Consequence for the new gap comparison

PROOF.md's sigma_AR >= sigma_input/9 applies exactly to the displayed 1/3-by-1/3 independent view law. It must not be asserted as a certified gap of the unnamed CL implementation.

The proved comparison survives dyadic repairs. If an explicit CL implementation gives both protected observations (x,private salt) and (y,private salt) independent selector probabilities at least eta on each side, then sigma_out >= eta sigma_input. Example: a four-label role selector gives each role mass 1/4; if a separately detyped low-degree subtest has a private invalid-prefix probability at least 1-q_LD, and its invalid branch erases all low-degree shared outputs while retaining no extra common register, then

    eta = (1/4)(1-q_LD),
    sigma_out >= (1/4)(1-q_LD) sigma_input.

This last formula is a conditional wire certificate, not a statement that the source implements those exact wires. Private invalid prefix salts are local randomness, independent of the old shared seed, so in the proof one uses the projection onto X or Y alone. All other branches can disclose all the old and low-degree shared seed. The precise additional checks are selector independence, no cross-prefix leakage, actual erasure of all shared subtest outputs on the protected branches, and preservation of their masses through the series composition.

For t_LD types, an already reconstructed valid detyping prefix has q_LD <= 2^(-t_LD). If the explicit implementation meets this wire contract, its gap follows algebraically without listing its support; proving a full game-soundness theorem still requires the acceptance-predicate and PCPP obligations separately.
