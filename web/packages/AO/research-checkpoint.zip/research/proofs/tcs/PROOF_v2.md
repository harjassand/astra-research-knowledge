# Resampling gap through independently selected observation branches

Version 2. Scientific status: new internal derivation of a finite classical probability lemma and its explicitly conditional application. Version 1 is preserved unchanged as PROOF.md. This is not an externally validated compression theorem. The probability lemma is an elementary conditional-expectation comparison; its historical novelty is UNKNOWN and no novelty claim is made for the operator facts.

## 1. Exact interface

Let (X,Y) have a finite law mu with connected support. Suppose for all centered local real functions a(X), b(Y),

    |E[a(X)b(Y)]| <= rho ||a||_2 ||b||_2,   0 <= rho < 1.       (1)

Let U and V be finite auxiliary variables independent of one another and of (X,Y). Let S include (X,Y,U,V), together with arbitrarily many other registers. These other registers may be correlated with all four; only the specified marginal factorization is required.

Generate Q_0 and Q_1 by two channels that are conditionally independent given S. Each channel uses an independent selector, independent of S. On each side two specified branches each have probability at least eta, 0 < eta <= 1/2. On branch A the output is a function only of (X,U) and local independent randomness; on branch B it is a function only of (Y,V) and local independent randomness. All other branches may reveal all of S and may differ between the two sides. Local selector bits can also be sent. The essential restriction is that the A/B outputs do not contain any other shared register.

**Claim.** The maximal correlation of Q_0 and Q_1 is at most

    rho_out <= 1 - eta(1-rho).                               (2)

Consequently their pair-resampling chain (P_{Q_0}+P_{Q_1})/2 has connected support and gap

    sigma_out >= eta(1-rho)/2.                              (3)

If rho is the actual maximal correlation rho_max of a nondegenerate connected original pair law, sigma_in=(1-rho_max)/2 and sigma_out >= eta sigma_in. With only an upper bound rho, use the certified lower bound (1-rho)/2 instead of claiming equality with sigma_in. If the original law is a single atom with the conventional sigma_in=1, use min(sigma_in,1/2). This prevents a false factor-two claim in the degenerate case.

A selector probability exceeding eta only improves the comparison: split its branch into an eta subbranch with independent local coin, and treat the remainder as arbitrary.

## 2. Adding independent point blocks preserves the correlation bound

Take centered a(X,U), b(Y,V). Put a_bar(X)=E[a|X] and b_bar(Y)=E[b|Y]. Independence of U,V gives

    E[a b] = E[a_bar b_bar].

Both conditional means are centered and contractions in L2. Therefore (1) implies

    |E[a b]| <= rho ||a||_2 ||b||_2.                         (4)

Let P_A and P_B be the conditional-expectation projections on L2(S) onto functions of (X,U) and (Y,V). For any centered f(S), put a=P_A f, b=P_B f, and D=||a||^2+||b||^2. By (4),

    ||a+b||^2 <= (1+rho)D,
    D = <f,a+b> <= ||f|| sqrt((1+rho)D).

If D=0 there is nothing to divide; otherwise division yields D <= (1+rho)||f||^2. Hence, on the centered space,

    (P_A+P_B)/2 <= (1+rho)I/2,
    (I-P_A)+(I-P_B) >= (1-rho)I.                            (5)

No enumeration of S or its hidden registers occurs.

## 3. Every remaining observation can be maximally informative

For side i define C_i:L2(Q_i)->L2(S) by C_i g=E[g(Q_i)|S]; its adjoint is C_i^* f=E[f(S)|Q_i]. Append the local selector and local channel coins to Q_i if necessary, producing a more informative observation. This can only increase maximal correlation, so it suffices to prove the bound for that enriched observation.

Conditional on a fixed selector branch, the corresponding observation operator K_{i,l}=C_{i,l}C_{i,l}^* is a positive contraction. On A it is <=P_A, because the observation is a local channel from (X,U); on B it is <=P_B. Independent selectors give an orthogonal direct sum of the observation spaces and

    K_i=C_i C_i^* = sum_l p_{i,l} K_{i,l}
        <= eta P_A + eta P_B + (1-2eta) I
        = I - eta[(I-P_A)+(I-P_B)]
        <= [1-eta(1-rho)] I                                (6)

on centered L2(S). This remains valid if all other branches reveal the complete S.

Conditional independence of Q_0,Q_1 given S gives their cross conditional-expectation operator exactly as C_0^* C_1. Its centered norm is bounded by

    ||C_0^* C_1|| <= ||C_0|| ||C_1||
                   <= 1-eta(1-rho).                        (7)

The operator norm equals maximal correlation by directly optimizing E[g(Q_0)h(Q_1)] over unit centered local functions. This proves (2).

To derive (3), for a centered pair function f(Q_0,Q_1), put a=P_{Q_0}f, b=P_{Q_1}f and repeat the calculation leading to (5), with rho_out in place of rho. This proves

    <f, (P_{Q_0}+P_{Q_1})f/2> <= (1+rho_out)||f||^2/2.

The absence of any nonconstant eigenvector with eigenvalue one implies connectedness of the finite positive-mass pair support. Thus sigma_out >= (1-rho_out)/2 >= eta(1-rho)/2.

## 4. Sharpness: full seed disclosure cannot improve the universal constant

Let X,Y be uniform signs with E[XY]=rho >=0 and full support; let U,V and an extra bit R be independent uniform bits. Both players independently select A=(X,U) with probability eta, B=(Y,V) with probability eta, and F=S with probability 1-2eta. Retain the branch label.

On centered f=X+Y, P_A f=(1+rho)X and P_B f=(1+rho)Y. Therefore

    K f = [eta(P_A+P_B)+(1-2eta)I] f
        = [1-eta(1-rho)] f.

For this symmetric channel, the cross observation operator has the same nonzero eigenvalues as K=C C^*. The upper bound is attained: rho_out=1-eta(1-rho) and sigma_out=eta(1-rho)/2. This is an exact analytic fixture, not an inference from floating-point eigenvalues.

## 5. Named application to Lin's answer-reduction Figure

Primary source acquired live: Lin, MIPco=coRE, arXiv:2510.07162v1, source archive downloaded 2026-10-08; Answerreduction.tex lines 587-602 describe the sampler. Seqandcompression.tex lines 446-482 give Proposition 6.17's answer-reduction contract; Answerreduction.tex line 683 claims CL level max{k+2,6}.

In the no-error/no-timeout branch of the displayed sampling procedure, let S=(x,y,s,all line randomness), where (x,y)~mu and the separately sampled coding seed s has disjoint independent blocks s_0,s_1,... . Each prover independently selects its role in {Prover A,Prover B,Ora} and low-degree label in {Point,DLine,ALine}.

The (Prover A,Point) branch has probability 1/9 and sends only the role/test labels, x and s_0. The (Prover B,Point) branch likewise has probability 1/9 and sends only the labels, y and s_1. Their point blocks are independent. The other branches, including Ora branches that disclose (x,y), can be regarded as arbitrary full-seed observations in the comparison. Thus eta=1/9 and

    sigma_AR >= (1-rho_mu)/18 = sigma_mu/9.                 (8)

This applies to the question law only, independent of the answer predicate, low-degree soundness, commuting strategies, or the correctness of a compression theorem.

For an input law satisfying the internally reconstructed detyping correlation certificate rho_mu<=q<=2^{-t},

    sigma_AR >= (1-2^{-t})/18 >= 1/36,                     (9)

and t=2 gives sigma_AR>=1/24. The previously retained warning that the Ora branches can reveal extra shared information is therefore insufficient by itself to defeat the gap: the two positive-probability independent point views control it.

**Exact source boundary.** The theorem establishes (8) for the displayed independently selected view law with valid disjoint point registers. SOURCE_INTERFACE_FAILURE.md proves that the displayed role probability 1/3 cannot be realized by any finite CL sampler: all CL event masses are dyadic. The earlier four-binary-label implementation in Answerreduction.tex 200-211 changes this law. Thus (8) is not a certified gap of the source's final CL implementation. It does not prove that the claimed CL implementation realizes precisely that law. The source's CL-realization paragraph imports the detyped low-degree distribution and contains format/bit-versus-field ambiguities. If implementation replaces independent role/test selectors by a correlated wire law, changes their probabilities, or sends additional shared registers on point branches, its wire law must be checked anew. Source timeout/error fallbacks are excluded by the promised sufficiently-large-n successful runtime regime; arbitrary data-dependent mixing with a rejecting game is not silently covered.

## 6. Conditional direct repetition and charged comparison

Assume separately: (i) a valid h-level CL implementation of the law in Section 5, (ii) soundness omega_co(H)<=1-epsilon_H, (iii) perfect globally synchronous/oracularizable yes strategies, and (iv) the inherited L02 connected commuting all-wins theorem.

For answer alphabet A_H and B_H=1+2 ln|A_H|, (9) then yields

    omega_co(H^{tensor r})
       <= exp[-epsilon_H^3 r/(36864 B_H)].                 (10)

For L>=1, r=ceil(36864 B_H L/epsilon_H^3) suffices for exp(-L). Direct parallel repetition retains h CL levels, uses r copies of the full seed/question/answer registers, r evaluations of the H predicate, and r sampler calls. If seed length is b_s, each question length b_q and answer length b_a, costs are r b_s random bits, r b_q question bits per side, r b_a answer bits per side, sampling time r T_s and verification time r T_v plus O(r(b_q+b_a)) parsing. No acquisition of epsilon_H or answer-reduction soundness is claimed.

Matched existing baseline: N11's same-answer independent 1/8-erasure wrapper receives the same H, epsilon_H, B_H and L. It has h+1 CL levels, six extra field coordinates per copy, same answers, value loss (49/64)epsilon_H, sigma>=1/16, and sufficient r_J=ceil(2^32 B_H L/(117649 epsilon_H^3)). Its repetition coefficient is about 36506.620. The universally certified new coefficient 36864 is about 0.979% larger. The benefit is saving one CL level and six field coordinates per copy at essentially the same conservative cubic repetition count. For the t=2 certified input, use sigma_AR>=1/24 and coefficient 24576, about 32.68% fewer copies than that comparator. These are sufficient-bound comparisons, not measured runtime speedups or optimality of repetition.

The original Lin anchored theorem has an epsilon^{-17} sufficient schedule, but N11 already improves that to cubic. Claiming the full exponent improvement as new here would misattribute inherited work.

## 7. Remaining obligation

The decisive next audit is a wire-by-wire reconstruction of the final CL sampler, including its imported low-degree detyping, proving the actual law has independent recognizable A/Point and B/Point subbranches at the claimed masses, with no other shared outputs on those subbranches. If this obligation fails, apply the proved general lemma with its actual eta if possible; otherwise (8)-(10) remain conditional. The complete answer-reduction soundness proof and global compression theorem have not been reconstructed here.

## Version and checking notes

Version 1 is frozen. Version 2 fixes the distinction between a supplied upper bound on rho and actual rho_max, and promotes the dyadic Figure/CL mismatch from a generic caveat to a proved scoped failure. Nine bounded float64 SVD diagnostics passed in view_gap_diagnostics.json, including six sharp full-seed cases, an asymmetric richer-view case, and two deliberate assumption violations. The analytic proof does not depend on these finite diagnostics. A separate internal adversarial agent reported that the main finite-law constant and sharpness appear valid; that agent is not an external or formal verifier.
