# Finite verification of the B-chain pair-death functional

## Scope and result

This package checks only the proposed expected number of pair-death transitions for the specified one-dimensional chain, started at \(B=1\): birth \(b\to b+1\) at rate \(\beta b\), pair death \(b\to b-2\) at rate \(b(b-1)\), with state 0 absorbing. It makes no claim that a frozen A approximation applies to the original five-reaction network, and it is not a proof about that network’s CTMC.

For each \(\beta\in\{1/5,1,3,5\}\), the checker solves exact rational finite-state truncations at \(N=2,3,5,10,20,40\). The upper boundary is explicit: from state \(N\), a birth exits to a reward-free absorbing cemetery; a pair death from \(N\) is still counted and moves to \(N-2\). Coupling each truncation to the unbounded chain up to its first upward exit shows that these finite expected rewards are **lower bounds** on the unbounded expected reward. They are monotone nondecreasing with \(N\). No upper bound on the infinite expected reward is supplied here.

The table compares the exact finite rational values (shown as decimals) with the proposed gamma expression evaluated numerically. The exact numerator and denominator for every finite value are retained in `results.json`.

| \(\beta\) | exact truncation at \(N=20\) | exact truncation at \(N=40\) | proposed formula, numerical |
|---:|---:|---:|---:|
| \(1/5\) | 1.20114797100426670396813470456 | 1.20114797100426670396813470457 | 1.201147971004266703968134704566168354 |
| 1 | 2.09726402473266254350439102996 | 2.09726402473266255680760686514 | 2.097264024732662556807606865143752 |
| 3 | 5.75595546369563107791044743863 | 5.75595546517687670289426639643 | 5.755955465176876702894266396435948 |
| 5 | 13.3292739378213702175524300906 | 13.3292794768840299101744694368 | 13.329279476884029910174740387170547 |

The exact finite lower bounds and the high-precision special-function evaluations agree closely at \(N=40\). This is numerical agreement plus one-sided finite evidence, not a proof that the proposed expression equals the infinite-chain expected reward. In particular, the finite computation cannot rule out additional reward after the process first exceeds \(N\).

## Exact truncation recurrence

Let \(f_b^{(N)}\) be the expected number of pair deaths before absorption at 0 or the killed upper boundary, starting at \(b\). For \(\beta>0\), state 1 has only its birth transition, so \(f_1^{(N)}=f_2^{(N)}\). For \(2\le b<N\), first-step analysis gives

\[
(\beta+b-1) f_b^{(N)}
=\beta f_{b+1}^{(N)}+(b-1)\bigl(1+f_{b-2}^{(N)}\bigr),
\qquad f_0^{(N)}=0.
\]

At \(b=N\), the birth term is killed with no later reward, so

\[
(\beta+N-1)f_N^{(N)}=(N-1)\bigl(1+f_{N-2}^{(N)}\bigr).
\]

The code represents every \(f_b^{(N)}\) as an affine function of the unknown \(f_1^{(N)}=f_2^{(N)}\), propagates using `fractions.Fraction`, and solves the final boundary equation exactly. Thus the finite values are rational without numerical linear algebra.

## Occupation-generating-function comparison

Let \(T_n\) denote expected time spent in state \(n\) before absorption, starting at 1, if the infinite-chain occupation measure exists with the needed finite moments. Its integrated forward balance for \(n\ge1\) is

\[
\beta(n-1)T_{n-1}+(n+2)(n+1)T_{n+2}
-\bigl(\beta n+n(n-1)\bigr)T_n=-\mathbf 1_{\{n=1\}}.
\]

For \(G(z)=\sum_{n\ge1}T_nz^n\), summing these balances yields

\[
(1-z^2)G''(z)+\beta(z^2-z)G'(z)-2T_2=-z.
\]

If \(G'\) and \(G''\) are finite at \(z=1\), this identity gives \(T_2=1/2\), and division by \(1-z\) gives the proposed ODE

\[
(1+z)G''(z)-\beta zG'(z)=1.
\]

The expected pair-death count, when finite, is \(h_1=G''(1)=\sum_{n\ge2}n(n-1)T_n\). To select the claimed solution of the ODE, additionally require \(G'\) to remain finite at \(z=-1\). With integrating factor \(\mu(z)=e^{-\beta z}(1+z)^\beta\),

\[
(\mu G')'=e^{-\beta z}(1+z)^{\beta-1},\qquad
G'(1)=e^{2\beta}(2\beta)^{-\beta}\gamma(\beta,2\beta).
\]

Evaluating the ODE at \(z=1\) then gives

\[
h_1=G''(1)=\frac{1+\beta G'(1)}2
=\frac{1+\beta e^{2\beta}(2\beta)^{-\beta}\gamma(\beta,2\beta)}2.
\]

This independently recovers the proposed expression **conditional on existence, convergence, finite moments, and regularity at \(z=-1\)**. The finite truncations do not prove those conditions for the infinite chain, so this ODE comparison is not an infinite-chain proof.

## Limits and default drift

As \(\beta\downarrow0\), \(\gamma(\beta,2\beta)\sim (2\beta)^\beta/\beta\) and \(e^{2\beta}(2\beta)^{-\beta}\to1\); hence the proposed expression tends to 1. The numerical checks at \(\beta=10^{-3},10^{-6},10^{-9}\) give respectively 1.0010000001665279156, 1.00000100000000000017, and 1.00000000100000000000. This is the right limit through positive \(\beta\); at \(\beta=0\) the chain started at 1 has no birth and is a different, stuck process.

From the proposed expression,

\[
1-\tfrac15 h_1(\tfrac15)
=0.75977040579914665920637305908676632917\ldots
\]

The exact \(N=40\) lower bound at \(\beta=1/5\) gives only the corresponding upper bound \(1-\tfrac15 h_1\le 0.759770405799146659206373059087\ldots\), if the unbounded expected reward is defined. Since no upper bound on \(h_1\) was established, the sign of the actual infinite-chain drift is not certified by this package.

## Replay

Run `./work/agents/excursion_exact/finite_check.py` from the workspace root. It uses `Fraction` for every finite calculation and the already-installed `mpmath` package for special-function comparisons. It writes all exact fractions and comparison data to `results.json`.
