# Matching the one-qubit marginal: centered purity and certification lower bounds

Thermal second-stage derivation, 8 October 2026. The argument below was developed without reading the independent marginal worker's proof. The root subsequently reported that another candidate has a better constant; no candidate proof or argument was supplied. This file preserves this worker's generating-polynomial/Gram derivation separately. Status: internally reconstructed candidate theorem; independent audit pending, external correctness and priority UNKNOWN.

## 1. Exact theorem

Let \(\rho_N\) be permutation invariant and have the exact maximally-mixed-input Schur weights \(w_{N,M}\) displayed in growing_relative_entropy.md. Let \(\tau=\rho_{N,1}=(I+b\cdot\sigma)/2\), and write \(\rho_r=\rho_{N,r}\). For \(1\le r\le N/1024\),
\[
 \boxed{\chi^2_{\rm P}(\rho_r\|\tau^{\otimes r})
 :=\operatorname{Tr}[\rho_r^2(\tau^{\otimes r})^{-1}]-1
 \le 2\cdot10^9(r/N)^2,}
\]
and hence
\[
 \boxed{D(\rho_r\|\tau^{\otimes r})\le2\cdot10^9(r/N)^2.}
\]
The constant is intentionally loose. Every subextensive sequence \(r_N=o(N)\) satisfies the size restriction eventually. The theorem holds uniformly over arbitrary states inside each conserved Schur sector, so it holds at all times/occupations of the specified collective bath. For \(r=1\), the quantities are exactly zero rather than merely bounded.

The reference \(\tau^{\otimes N}\) is fully separable and exactly matches all one-body data. It generally DOES NOT have the target's conserved Casimir or Schur law. Thus its use as a hard alternative requires soundness against the unrestricted fully separable set. A trusted promise that the null has the same Casimir changes the certification problem and is treated separately below.

## 2. Weighted centered basis and the support-wise conditioning issue

Set \(B_a=\sigma_a-b_aI\). Under the one-qubit inner product
\(\langle A,C\rangle_\tau=\operatorname{Tr}\tau A^\dagger C\), these operators are orthogonal to the identity and have Gram matrix
\[
 G_{ab}=\delta_{ab}-b_ab_b+i\epsilon_{abk}b_k.
\]
Its eigenvalues are \(1-|b|,1+|b|,1-|b|^2\). The conserved Casimir implies
\[
 |b|^2=4|\langle J\rangle|^2/N^2\le3/N,
\]
so \(\tau\) is full rank and \(G\succeq(1-|b|)I\succeq I/2\) for the stated range.

For the product reference \(T=\tau^{\otimes r}\), let \(L=\rho_rT^{-1}\). Then
\(\|L\|_T^2=\operatorname{Tr}\rho_r^2T^{-1}\). Its coefficient against a product of centered basis operators on support \(S\) is exactly
\[
 \langle B_S,L\rangle_T=\operatorname{Tr}\rho_r B_S^\dagger.
\]
The last equality uses cyclicity to cancel the adjacent \(T^{-1}T\); it does not assume \(\rho_r\) commutes with \(T\). Orthogonal decomposition by supports and finite-dimensional Parseval give
\[
 \chi^2_{\rm P}
 =\sum_{S\ne\varnothing} C_S^\dagger(G^{-1})^{\otimes|S|}C_S
 \le\sum_{w=2}^r2^w\sum_{|S|=w}\sum_{a_1,\ldots,a_w}|C_{a_1\ldots a_w}|^2.
\]
All weight-one coefficients vanish because \(\tau\) matches the marginal. Conditioning is charged by support weight \(w\), not by the total register size \(r\). Paying a single factor \((1-|b|)^{-r}\) would spoil the mesoscopic theorem and is unnecessary.

## 3. Centered generating polynomial

For \(z\in\mathbb C^3\), \(u=|z|_2\), define
\[
 F_N^b(z)=\operatorname{Tr}\rho_N
 [(1-b\cdot z)I+z\cdot\sigma]^{\otimes N}.
\]
Its constant coefficient is one; its degree-one coefficients are zero. The coefficient of a count triple \(n=(n_x,n_y,n_z)\), of weight \(w\), is
\[
 [z^n]F_N^b=\frac{(N)_w}{n_x!n_y!n_z!}C_n.
\]
The exact Schur norm from audit_addendum.md applies to this complex two-by-two matrix \(A\). With \(\beta=|b|\),
\[
 |\det A|\le1+2\beta u+(1+\beta^2)u^2,
 \qquad\|A\|\le1+(\beta+\sqrt2)u.
\]
Consequently
\[
 |F_N^b(z)|\le
 e^{N\beta u+N(1+\beta^2)u^2/2}
 \mathbb E_w e^{(\beta+\sqrt2)Mu}.
\]
For \(N\ge128\), \(\beta+\sqrt2\le2\). The exact Rademacher-derivative MGF bound in growing_relative_entropy.md therefore gives
\[
 \mathbb E_w e^{(\beta+\sqrt2)Mu}
 \le6(1+4Nu^2)e^{2Nu^2}.
\]
Also \(N\beta u\le\sqrt{3N}u\le Nu^2/2+3/2\), and \(\beta^2\le3/N\). Hence
\[
 \boxed{|F_N^b(z)|\le6e^{3/2}(1+4Nu^2)e^{13Nu^2/4},\quad N\ge128.}
\]

## 4. Cauchy coefficients and the quadratic sum

Use a common polydisc radius \(R^2=2w/(39N)\). Then \(u^2=3R^2\), and multivariate Cauchy yields
\[
 |[z^n]F_N^b|^2
 \le36e^3(1+w)^2e^w\left(\frac{39N}{2w}\right)^w.
\]
The support-wise factor \(2^w\) from Section 2 cancels the denominator \(2^w\) in the last radius expression. There are at most \((w+1)^2\) count triples and each factorial product is at most \(w!\le w^w\). For \(r\le N/1024\), \((N)_w\ge[N(1023/1024)]^w\), so
\[
 \chi^2_{\rm P}\le36e^3\sum_{w=2}^r(w+1)^4q^w,
 \quad q=110r/N,
\]
because \(39e(1024/1023)^2<110\). Here \(q<1/5\), and
\[
 \sum_{w\ge2}(w+1)^4(1/5)^{w-2}=173.3203125<174.
\]
Thus
\[
 \chi^2_{\rm P}\le36e^3\cdot174\cdot110^2(r/N)^2
 <2\cdot10^9(r/N)^2.
\]
To obtain relative entropy without a commutation assumption, diagonalize \(\rho_r\) and \(T\), with eigenvalues \(\lambda_i,\mu_j\) and overlaps \(c_{ij}=|\langle i|j\rangle|^2\). Jensen gives
\[
 D(\rho_r\|T)=\sum_{i,j}\lambda_ic_{ij}\log(\lambda_i/\mu_j)
 \le\log\sum_{i,j}\lambda_i^2c_{ij}/\mu_j
 =\log\operatorname{Tr}\rho_r^2T^{-1}\le\chi^2_{\rm P}.
\]
This completes the internal proof.

## 5. Consequence for black-box certification against ALLSEP

There are \(m\) independent fresh target preparations. A protocol may access at most \(r\) distinct sites per prepared copy, select physical labels using classical earlier outcomes, retain arbitrary quantum memory, and make joint measurements on all accessed registers. As in audit_addendum.md, exchangeability reduces this to a channel of \(\rho_r^{\otimes m}\). The comparator \((\tau^{\otimes N})^{\otimes m}\) has identical site marginals and is globally fully separable. Hence output TV is at most
\[
 \min\{1,\sqrt{10^9m(r/N)^2}\}.
\]
Any test with a fixed gap between true acceptance and uniformly bounded acceptance on ALL fully separable alternatives needs
\[
 \boxed{m=\Omega(N^2/r^2),\qquad r_N=o(N).}
\]
This is a necessary bound for genuine entanglement certification, rather than target-versus-white discrimination. It allows arbitrary joint quantum processing. With \(r=1\), certification is impossible for any number of such preparations, because the accessed target and comparator states coincide exactly.

The physical cost at this lower scale is \(\Omega(N^3/r^2)\) prepared qubit instances and \(\Omega(N^2/r)\) local readouts. If all N readouts from a single prepared copy are pooled, the per-copy access budget is N and this lower theorem does not apply.

## 6. Trusted promise changes the task

If a null is trusted to obey \(\langle J^2\rangle=3N/4\), every fully separable null has \(|\langle J\rangle|\le\sqrt N/2\), equivalently \(|b|\le1/\sqrt N\). The polarized target has \(|b|\sim\sqrt{8/\pi}/\sqrt N\), violating this promise-aware mean bound. One-body estimation on \(O(N)\) fresh copies can then certify entanglement using the supplied global Casimir promise. The product-marginal comparator violates that promise and cannot support the quadratic certification lower bound in that interface.

Acquiring or validating the global Casimir experimentally is part of black-box certification and is not free. Exact initial state/coupling/model guarantees can supply it mathematically, but this is a separate, promise-aware inference. The unrestricted-ALLSEP theorem above must not be presented as a limitation on such trusted-model reasoning.

## 7. Upper bound status

A sound \(O(N^2)\)-preparation protocol using two random sites per copy is available from the tangent spin-variance witness; it is given separately. This matches the quadratic order when r is any fixed integer at least two. A matching uniform \(O(N^2/r^2)\) black-box certification protocol for growing r has not yet been proved in this file. Centered mean discrimination against only the product-marginal comparator would be insufficient to establish such an upper bound.
