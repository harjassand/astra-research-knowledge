# Centered local entropy from a uniform collective-spin tail

Thermal structural extension, 8 October 2026. Internally reconstructed proof candidate, not externally validated. It replaces the exact-white Schur law by a quantitative tail condition. Historical priority is UNKNOWN.

## Theorem

Let rho_N be any permutation-invariant N-qubit state, and let M=2j have its total-spin-sector probability law. Suppose constants A>=1, B>=0 and C>=0 independent of N satisfy

    E exp(t M/sqrt(N)) <= A exp(Bt^2+Ct),   for every t>=0.

Set K_2=A exp(B+C), L=sqrt(K_2)+2C, and S=3/2+4B. Let tau=rho_{N,1} and alpha=r/N. For

    N>=4K_2,   alpha<=min{1/2,1/(240eS)},

the Petz centered chi-square and relative entropy satisfy

    chi_P^2(rho_{N,r} || tau^tensor r)
      <=14 A^2 exp(L^2)(48eS)^2 alpha^2,
    D(rho_{N,r} || tau^tensor r) <= same bound.

The statement is uniform over arbitrary sector states and every subextensive r_N=o(N). For r=1 both quantities are zero. It therefore yields the same Omega(N^2/r^2) preparation lower bound for unrestricted-ALLSEP certification through at most r distinct sites per fresh copy. The exact-white Schur law is a sufficient example, not a necessary premise of this centered order.

## Proof

Since x^2<=exp(x) for x>=0, the t=1 assumption gives E M^2/N<=K_2. The mean spin obeys |<J>|<=E j, so the marginal Bloch length beta=|b| satisfies beta<=sqrt(K_2/N)<=1/2. The centered basis Gram matrix and weighted Parseval are exactly those in centered_relative_entropy_FROZEN.md; in particular the degree-one terms vanish and each support of size w costs at most a conditioning factor 2^w.

For complex z, u=|z|, form F_N^b(z)=Tr rho_N[((1-b dot z)I+z dot sigma)^tensor N]. The singular-value Schur norm proof in audit_addendum.md gives

    |F_N^b(z)|
      <=exp[N beta u+N(1+beta^2)u^2/2]
         E exp[(beta+sqrt(2))Mu].

Since beta+sqrt(2)<=2, apply the tail premise at t=2sqrt(N)u:

    |F_N^b(z)|
      <=A exp[(sqrt(K_2)+2C)sqrt(N)u
              +Nu^2/2+K_2u^2/2+4BNu^2]
      <=A exp(L^2/2) exp(SNu^2).

The last step uses Lsqrt(N)u<=L^2/2+Nu^2/2 and N>=K_2. Choose the common multivariate Cauchy radius R^2=w/(6SN). Then

    |[z^n]F_N^b|^2 <=A^2 exp(L^2) exp(w)(6SN/w)^w.

Exactly as in the frozen centered proof, multiply by the support conditioning 2^w, the falling-factorial coefficient relation, at most (w+1)^2 count triples and n_x!n_y!n_z!<=w^w. Since (N)_w>=N^w(1-alpha)^w,

    chi_P^2 <=A^2 exp(L^2) sum_{w>=2}(w+1)^2 q^w,
    q=12eS alpha/(1-alpha)^2<=48eS alpha<=1/5.

The degree-two-and-higher sum is at most 14q^2. This proves the chi-square bound. The spectral-overlap Jensen argument already preserved in centered_relative_entropy_FROZEN.md gives D<=log(1+chi_P^2)<=chi_P^2 without assuming commutation.

The same proof without centering gives a white Pauli weight-three-and-higher norm O(alpha^(3/2)), with constants determined by A,B,C. Hence the bounded_heat_upper_FROZEN.md argument transfers to this tail class whenever the target violates the collective spin-variance inequality by a fixed fraction of N:

    liminf [2-4(<J^2>-|<J>|^2)/N] > 0.

For that extension, keep the same effect and field calibration. The target two-body trace is no longer zero; its exact value is [4<J^2>-3N]/[N(N-1)]. The resulting target-minus-ALLSEP low-degree gap is

    kappa_r r/[6(N-1)] * [N|b|^2-4<J^2>/N+2]
      =kappa_r r/[6(N-1)] * [2-4 sum_a Var(J_a)/N].

The remaining compactness proof concerns null product arrays only and is unchanged, with the finite field bound H replaced by a constant depending on K_2. This gives an O(N^2/r^2) bounded local upper whenever that strict spin-variance margin is present. This paragraph records the exact transfer interface; the full separately frozen upper proof supplies its remaining lemmas. A tail condition alone does not assert that the target is entangled or has this margin.

## Why a mean-only replacement is false

Integration supplied an independent counterexample, preserved here with attribution. For even N let S_N be the permutation twirl of N/2 singlet pairs and let

    rho_N=(1-p)S_N+p|0><0|^tensor N,  p=3/(N+2).

Then <J^2>=p(N/2)(N/2+1)=3N/4 exactly. Its one-qubit marginal is tau=(I+p sigma_z)/2. The event that all r accessed spins are 0 has target probability P between p and p+2^-r: under a singlet-pair component it is zero if both members of one pair are selected and is 2^-r otherwise. The product-marginal null event probability is Q=[(1+p)/2]^r. Data processing and binary entropy give

    D(rho_r||tau^tensor r)>=P log(1/Q)-h(P).

For log N << r=o(N), log(1/Q)=r(log 2-O(1/N)), while h(P)=O(log N/N), so the lower bound is Omega(r/N). It contradicts a universal O((r/N)^2) theorem from the Casimir mean alone. The tiny all-up component has M=N with probability about 3/N and violates every fixed subGaussian M/sqrt(N) tail bound. A genuine sector-tail condition is therefore load bearing.

This extension is source-derived mathematical progress, not a historical novelty assertion. It includes singlet-sector MMIS as a simple case, so it must be compared with known MMIS local-hiding results rather than claiming the hiding concept or the quadratic exponent as new.
