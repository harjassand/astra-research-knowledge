# Finite randomness and classical cost accounting for the asymptotic upper

8 October 2026. This addendum makes the bounded heat protocol a finite precision protocol; it does not improve its enormous universal constants.

Let alpha=r/N and let c alpha be the guaranteed target-minus-null gap after the independent calibration phase. Allocate errors below c alpha/16 each for axis discretization, Bernoulli-probability rounding and sound-threshold arithmetic. Their aggregate loss leaves a fixed positive fraction of the gap, so the Hoeffding preparation order remains O(alpha^-2 log(1/eta)).

For g(x)=exp(-x^2), its Gaussian Fourier representation and the Duhamel inequality imply

    ||g(X)-g(Y)|| <=(2/sqrt(pi))||X-Y||

for finite-dimensional self-adjoint X,Y. Indeed the first absolute moment of the Fourier density exp(-t^2/4)/(2sqrt(pi)) is 2/sqrt(pi). With X_n=J_n/sqrt(r)-h_N sqrt(r)(n dot v)/2 and |h_N||v|<=H/sqrt(N),

    ||W_n-W_m|| <=2sqrt(r)|n-m|

when N>=H^2. Couple a uniform sphere direction to a quantized direction of Euclidean error Delta<=c alpha/(32sqrt(r)). This changes the averaged effect by at most c alpha/16. It is enough to draw a uniformly quantized cosine at mesh O(Delta^2) and an independently uniformly quantized azimuth at mesh O(Delta): the square root in the transverse coordinate is Holder continuous, so the resulting vector error is at most Delta after fixed geometric constants are included. This needs O(log(r/alpha^2)+log(1/c)) shared random bits per preparation and the same order of bits in the axis descriptor. No infinite-precision continuous random variable or exponentially large precomputed axis table is required.

Round the Bernoulli pass probability to an integer multiple of 2^-k with k>=ceil(log2(16/(c alpha))). An independent k-bit uniform integer implements that coin and changes acceptance by at most c alpha/16. Evaluate its bounded Gaussian argument to sufficient absolute precision; underflow can be replaced by zero once the value is below the allocated rounding error. These operations use finite precision depending logarithmically on N and on the fixed inverse margin c. Ideal local measurement settings must achieve the stated axis error; physical control or gate costs are extra resources, not inferred from a copy count.

The calibration constants T_r,q_r are r+1 explicit binomial sums. A stable recurrence or log-probability method uses O(r) scalar terms. The baseline A_0 is a one-dimensional integral of the white binomial heat expectation, depending only on |v|. Its integrand has Lipschitz constant O(Hsqrt(alpha)); a Riemann rule with O(H/(c sqrt(alpha))) points therefore gives certified absolute error O(c alpha). Straight summation charges O(r/sqrt(alpha))=O(sqrt(Nr)) scalar terms, with constants depending on the fixed margin. Monotone upper and lower Riemann sums or a Lipschitz correction provide a sound rounded threshold. Binomial and elementary-function rounding precision is selected to keep the total error below c alpha/16, including every term; term count requires O(log N+log(1/c)) extra precision bits. Faster closed-error-function evaluation is optional and not needed for the cost claim.

Certification consumes m global independent preparations, mr local spin readouts and O(mr) outcome additions, plus the shared random bits, scalar coin arithmetic and O(sqrt(Nr)) threshold preprocessing above. This is an explicit arithmetic accounting, not a bound on laboratory wall time. Known target-state preparation cost is not absorbed into free classical calibration: charge mN prepared qubit instances and m bath/preparation procedures. The separate target calibration costs O(N/r log(1/eta)) preparations, O(N log(1/eta)) local readouts and the corresponding global qubit instances.

The lower theorem already allows arbitrary joint quantum operations across all accessed registers; imposing no such quantum computation in the upper is an additional feature, not an assumption of the lower. Strong adversarial correlations are covered only when the global null is separable across laboratories or each conditional fresh-copy state is fully separable. Independent target preparations are still required for the stated power bound. Unconditional separability of individual marginals alone does not define the claimed correlated-null interface.
