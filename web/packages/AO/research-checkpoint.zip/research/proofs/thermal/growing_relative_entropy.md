# Frozen escalation: a uniform relative-entropy bound removes the local-access logarithm

Thermal worker second derivation, 8 October 2026. Original derivation is preserved in original_derivation.md. This text was derived without seeing the independent marginal worker's result. Status: internally reconstructed proof candidate, awaiting adversarial mathematical audit. The constants deliberately favor a short transparent proof. No historical novelty claim.

**Exact statement.** Let \(\rho_N\) be a permutation-invariant \(N\)-qubit state whose total-spin law is the maximally mixed input law
\[
 w_{N,M}=\frac{(M+1)^2}{N/2+M/2+1}
 2^{-N}\binom{N}{(N-M)/2},\quad M\equiv N\pmod2.
\]
No purity or coherent-state assumption is made within a sector. For every \(1\le r\le N/128\),
\[
 \boxed{2^r\operatorname{Tr}\rho_{N,r}^2-1
       \le 50\,000\,r/N,\qquad
 D(\rho_{N,r}\|I/2^r)\le50\,000\,r/N.}
\]
Thus for every subextensive sequence \(r_N=o(N)\), the bound applies eventually. For \(m\) independent fresh preparations, arbitrary collective quantum measurement of the accessed \(r\)-qubit registers has output total variation at most
\[
 \sqrt{25\,000\,mr/N}.
\]
Together with the magnetization protocol in original_derivation.md, the requisite number of fresh preparations is \(\Theta(N/r_N)\) for constant discrimination accuracy at the polarized subcritical entangled time. This is a sharp asymptotic preparation-versus-access tradeoff, with conservative constants. Extension of this numerical bound to every \(r\le N/2\), e.g. \(C r/(N-r)\), remains unproved here.

## 1. A generating polynomial controls every Pauli weight simultaneously

For complex \(z\in\mathbb C^3\), put \(A(z)=I+z\cdot\sigma\), \(u=|z|_2\), and
\[
 F_N(z)=\operatorname{Tr}\rho_N A(z)^{\otimes N}.
\]
The exact Schur action of any two-by-two matrix is
\[
 A^{\otimes N}\big|_{M}
 \simeq (\det A)^{(N-M)/2}\operatorname{Sym}^{M}(A)\otimes I_{\rm mult}.
\]
The intertwiner is unitary for the Hilbert spaces inherited from tensor powers. Hence
\(\|\operatorname{Sym}^{M}(A)\|\le\|A\|^M\). Since
\(\det A=1-z\cdot z\), \(|\det A|\le1+u^2\), and
\(\|z\cdot\sigma\|\le\|z\cdot\sigma\|_2=\sqrt2u\),
\[
 |F_N(z)|\le e^{Nu^2/2}\,\mathbb E_w e^{\sqrt2Mu}.
\]
This bound handles nonnormal complex matrices and arbitrary sector states. There is no inference from weak convergence to trace-norm convergence.

## 2. The Schur moment-generating function has a uniform exact bound

Let \(S_N\) be the sum of \(N\) iid Rademacher variables, so
\(\Pr(S_N=M)=2^{-N}\binom N{(N-M)/2}\). The displayed exact weights give
\[
 w_{N,M}\le\frac{2(M+1)^2}{N}\Pr(S_N=M).
\]
For \(a\ge0\), adding the nonnegative negative-\(S_N\) contributions yields
\[
 \mathbb E_w e^{aM}\le\frac2N\mathbb E(S_N+1)^2e^{aS_N}.
\]
Differentiate \(\mathbb E e^{aS_N}=\cosh(a)^N\) twice:
\[
 \mathbb E(S_N+1)^2e^{aS_N}
 =\cosh(a)^N\big[N\operatorname{sech}^2a
       +N^2\tanh^2a+2N\tanh a+1\big].
\]
Using \(\tanh a\le a\) and \(\log\cosh a\le a^2/2\), with \(a=\sqrt2u\), gives
\[
 |F_N(z)|\le
 2\big[1+N^{-1}+2Nu^2+2\sqrt2u\big]
 e^{3Nu^2/2}
 \le6(1+Nu^2)e^{3Nu^2/2},\qquad N\ge2.
\]
For the last step, \(2\sqrt2u\le1+2u^2\le1+Nu^2\) and \(N^{-1}\le1/2\). All inequalities are finite-size identities or elementary scalar inequalities.

## 3. Multivariate Cauchy coefficient bound

For a triple of nonnegative counts \(n=(n_x,n_y,n_z)\), of weight \(w=n_x+n_y+n_z\), let \(C_n\) be the expectation of the corresponding Pauli string on \(w\) distinct sites. Permutation invariance gives the exact polynomial coefficient
\[
 [z_x^{n_x}z_y^{n_y}z_z^{n_z}]F_N
 =\frac{(N)_w}{n_x!n_y!n_z!}C_n.
\]
Apply the Cauchy integral formula on the three-dimensional polydisc with common radius
\(R^2=w/(9N)\). On its distinguished boundary, \(u^2=3R^2=w/(3N)\), so
\[
 |[z^n]F_N|^2
 \le36(1+w/3)^2 e^{w}\left(\frac{9N}{w}\right)^w.
\]
This simultaneously bounds every weight, including growing weights; it avoids the crude collision-tuple estimate whose constants do not support a growing-size relative-entropy theorem.

## 4. Sum the full Pauli purity expansion

Orthogonality of Pauli strings yields exactly
\[
 \chi_r^2=2^r\operatorname{Tr}\rho_{N,r}^2-1
 =\sum_{w=1}^r\frac{(r)_w}{(N)_w^2}
   \sum_{n_x+n_y+n_z=w}n_x!n_y!n_z!\,|[z^n]F_N|^2.
\]
There are \(\binom{w+2}{2}\le(w+1)^2\) count triples; each factorial product is at most \(w!\le w^w\). For \(r\le N/128\),
\((r)_w\le r^w\) and \((N)_w\ge[N(127/128)]^w\). Therefore
\[
 \chi_r^2\le36\sum_{w=1}^r(w+1)^4 q^w,
 \quad q=25r/N,
\]
because \(9e(128/127)^2<25\). Here \(q\le25/128<1/5\). The elementary generating-function identity
\[
 \sum_{w\ge1}(w+1)^4q^{w-1}
 =\frac{16+q+11q^2-5q^3+q^4}{(1-q)^5}
\]
and positivity of its series imply it is at most its value at \(q=1/5\), which is \(50.6640625<51\). It follows that
\[
 \chi_r^2\le36\cdot51\cdot25\,r/N
 =45\,900\,r/N<50\,000\,r/N.
\]
Finally \(D(\rho\|I/d)=\log d-S(\rho)\le\log[d\operatorname{Tr}\rho^2]\) because von Neumann entropy dominates order-two Renyi entropy. This proves the relative-entropy statement.

## 5. The operational conclusion and its interface

Fix a target sequence at the inherited subcritical time, with
\(-\langle J_z\rangle/\sqrt N\to P=\sqrt{2/\pi}\), and white alternative \(I/2^N\). There are \(m\) independent fresh preparations. At most \(r_N\) distinct sites of each copy can be accessed. Physical site labels may be selected using classical previous outcomes; arbitrary quantum memory and joint operations on accessed registers are allowed. Exchangeability lets the protocol be represented on canonical \(r_N\)-site marginals. A coherent superposition that physically queries every site is not covered by a small-distinct-access budget.

Additivity of relative entropy and data processing bound output total variation by \(\sqrt{25\,000\,m r_N/N}\). A fixed positive output-TV requirement forces \(m=\Omega(N/r_N)\), whenever \(r_N=o(N)\).

Conversely, local \(z\)-measurement, classical pooling of its \(r_N\) outcomes per copy, and thresholding the mean over fresh copies has error sum at most \(4N/(m r_N P_N^2)\). Thus \(m=O(N/r_N)\) reaches any fixed error target. This proves the sharp order for discrimination against the white comparator. Since white is fully separable, the lower bound also applies to any entanglement test requiring a uniform false-positive guarantee over all separable alternatives. The matching upper protocol is not by itself such a complete entanglement test.

Resource costs: \(mN=\Theta(N^2/r_N)\) physical qubit instances, \(m\) independent collective-bath preparations, \(mr_N=\Theta(N)\) individual readouts, shared calibration and classical averaging. Measuring all \(N\) sites from one prepared copy and pooling outcomes lies outside a budget \(r_N=o(N)\) and remains compatible with the inherited global LOCC-compatible witness.

## 6. Remaining obligations

The load-bearing audit is the unitary Schur realization for complex \(A\), the coefficient multiplicity in Section 3, and the common trace-distance/relative-entropy conventions. The proof uses exact conserved Schur weights for its MGF; merely fixing \(\langle J^2\rangle=3N/4\) does not supply the exponentially controlled moment-generating function. Rare very-high-spin sectors can obstruct this approach under the weaker premise.

The bound for finite fractions such as \(r\le N/2\) is not obtained. Improving constants or deriving the full \(Cr/(N-r)\) inequality remains a real mathematical gate. Historical priority for the generating-polynomial argument and the resulting locality/preparation tradeoff is UNKNOWN. General mean-field and constrained de Finetti entropy results are relevant comparators; the recent Singh-Cerf arXiv:2604.09410v1 has stronger EPU invariance and different diagonal energy-shell assumptions, so it is not directly applicable to these Schur states.
