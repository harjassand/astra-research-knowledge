# Thermal lead report

8 October 2026. Pinned repository 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce remains clean. No descendants. Status: internally reconstructed mathematical candidates, exact finite diagnostics, awaiting independent audit; external correctness and historical priority UNKNOWN.

**Strongest result: the preparation/locality tradeoff closes, for every subextensive access budget.** For an arbitrary permutation-invariant state with the exact white-input Schur weights, at every time and bath occupation in the specified collective dynamics,
\[
 2^r\operatorname{Tr}\rho_{N,r}^2-1\le50\,000\,r/N,
 \quad D(\rho_{N,r}\|I/2^r)\le50\,000\,r/N,
 \quad1\le r\le N/128.
\]
For every r_N=o(N), any apparatus touching at most r_N distinct sites of each of m independent fresh preparations, even with joint quantum measurements and classical adaptive label selection, has output TV against white at most sqrt(25,000 m r_N/N). Constant accuracy therefore needs m=Omega(N/r_N). At the inherited strongly entangled subcritical time, simple z-readout averaging achieves O(N/r_N), so this discrimination scaling is sharp. Costs: Theta(N^2/r_N) prepared physical-qubit instances, Theta(N) collected single-qubit readouts, and Theta(N/r_N) independent bath evolutions. The upper protocol distinguishes white; only the lower bound automatically transfers to entanglement certification against every separable alternative.

The actual proof uses the complex generating polynomial Tr rho (I+z·sigma)^tensorN, exact Schur block norms, a Rademacher derivative bound for the Schur MGF, multivariate Cauchy coefficients, and the full Pauli purity sum. This replaces the initially obtained entropy argument's logarithmic loss. See growing_relative_entropy.md, frozen SHA256 b35b2209794c63dd25a500c73753328bfeedb668b6ee6b25debe0d28b5ec934c; the SVD clarification in audit_addendum.md avoids any ambiguity about a nonnormal complex Schur operator.

**Second result: sharp subsystem growth boundary from a weaker premise.** Every permutation-invariant state with merely Tr rho J^2=3N/4 obeys
\[
 D_T(\rho_{N,r},I/2^r)
 \le\min\{1,6r/(N+1)+6\sqrt{(\log2)r/(N+1)}\}.
\]
This extends fixed-r all-time and o(sqrt N) stationary source records to every o(N) subsystem, uniformly in time and nu. At the subcritical near-unit-entangled time, r_N/N->alpha>0 instead gives liminf marginal distance >=alpha/(3pi), proved by a bounded clipped-magnetization effect. Thus the exponent boundary is sharp for this family. The common CKMR Husimi measure is essential: independently choosing de Finetti measures for r and 2 would not justify the proof. See original_derivation.md, separately frozen SHA256 15a5db0a9295d3762cf5b0234d6610d534751961e585cd0f5bc142476dc0657b.

**Comparators and scope.** The old all-time local record asserts only fixed-r invisibility and explicitly leaves growing r open. N130 gives stationary o(sqrt N). Current square-root-bath Theorem A supplies polarized, near-unit-distance transient states for nu_N=o(sqrt N); that entanglement theorem remains inherited rather than independently fully audited here. CKMR (primary original PDF opened) is the established approximation mechanism, so the first local theorem is a source-derived corollary, not a historical-first claim. Singh-Cerf 2604.09410v1 is adjacent primary literature with EPU invariance and different diagonal energy-shell assumptions. Exact distance-to-SEP in the critical bath window is still unresolved: N179's separable approximant tail and N180's heat-effect lower bound do not close an intrinsic boundary.

**Actual finite evidence.** exact_purity.py passed four exact-rational full Pauli-purity calculations at (128,1),(256,2),(512,4),(1024,8); N*chi-square/r=2.2816,2.3653,2.4252,2.4676 (rounded display). check_local_access.py passed 39 full small-N density/marginal fixtures and 19 large-N z-readout fixtures. All are scoped computations, not formal theorem validation. Large-N classical distances substantiate the macroscopic boundary; they lower-bound quantum distance only.

**Important missing obligation and next action.** Independently attack the generating-polynomial coefficient normalization, the uniform Schur MGF inequality, and the adaptive-access interface. Root has dispatched that audit, but no report has been read here. If correct, sharpen constants and test the stronger C r/(N-r) inequality through r<=N/2. The current proof handles all subextensive sizes eventually; it does not establish that finite-fraction entropy inequality. Priority review remains necessary before presenting a scientific breakthrough.

**Failure/provenance preservation.** The original fixed-r and entropy-log-loss route remains intact, superseded by the second derivation. The attempted direct entropy-continuity transfer from de Finetti fails to remove the logarithm because dimension introduces an r^2/N loss. Repository knowledge.py/object-path access failures were bypassed using exact HTML source text, with matching hashes, and recorded in audit_addendum.md. Session/source_manifest and all scripts/results are retained locally in this folder.
