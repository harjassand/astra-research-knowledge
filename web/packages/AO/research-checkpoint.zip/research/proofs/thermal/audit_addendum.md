# Audit clarifications after the two derivations were frozen

8 October 2026. This supplements, and does not overwrite, original_derivation.md and growing_relative_entropy.md.

The complex Schur norm can be established without choosing an explicit polynomial intertwiner. Take a singular-value decomposition \(A=UDV^\dagger\), with singular values \(s_1\ge s_2\ge0\). Identical tensor powers of \(U,V\in U(2)\) preserve total spin and are unitary on each spin block. On the spin-\(j=M/2\) block, diagonal \(D^{\otimes N}\) has eigenvalues \(s_1^{N/2+m}s_2^{N/2-m}\), \(-j\le m\le j\). The largest is
\[
 s_1^{(N+M)/2}s_2^{(N-M)/2}
 =|\det A|^{(N-M)/2}\|A\|^M.
\]
Continuity covers zero singular values. This proves the operator-norm step in Section 1 directly from the usual spin weights of a diagonal one-qubit operator.

The local-access resource theorem permits classical adaptive choices of site labels. At any branch, operations on already accessed registers commute with all permutations of unaccessed sites in each prepared copy. Thus those unaccessed sites remain exchangeable, including when accessed registers from several copies are entangled by the apparatus. Relabel a newly selected site to the next canonical site in that copy, retaining the relabeling in classical memory. By induction every branch of the protocol has an equivalent implementation on the initially supplied canonical r-site marginals. A quantum superposition of accesses to arbitrarily many different physical sites is outside the specified small-distinct-site interface.

The lower preparation bound is valid for entanglement testing because the white comparator is fully separable. The O(N/r) magnetization upper protocol discriminates this particular comparator; it is not asserted to reject all separable alternatives. Therefore the matched Theta(N/r) statement is a discrimination theorem, with a necessary-only consequence for full entanglement certification.

Independent finite computation: exact_purity.py calculates every Pauli correlator through r using the stationary zero-temperature polynomial
\[
 F_N(x,y,z)=\sum_M w_{N,M}(1-x^2-y^2-z^2)^{(N-M)/2}(1-z)^M.
\]
For (N,r)=(128,1),(256,2),(512,4),(1024,8), exact rational chi-square values give N*chi-square/r approximately 2.2816, 2.3653, 2.4252, 2.4676. These are exact finite arithmetic evaluations of the model formula, with rounded display values, not all-size proof certification. Their constants are much smaller than the deliberately loose 50,000 theorem constant.

The double-precision check_local_access.py separately constructs 39 small density-matrix marginal fixtures, and 19 hypergeometric z-readout fixtures up to N=4096. At N=4096, classical measurement distance to white is about .0791 for r=64, .3181 for r=1024, and .4554 for r=2048. Floating sums differ from one at about 10^-12; this computation is not a certified interval bound.

Source access limitation preserved: the repository's agent/local-tools/knowledge.py fails because it resolves agent/frontier/retrieve.py, which is absent. Source-object paths advertised by N179/N180 notices are absent in the clean clone. Their exact UTF-8 proof text remains readable in web/pages HTML; extracting its pre block and unescaping HTML reproduces the notice hashes exactly. No repository file was changed to repair either navigation issue.

Priority screen: CKMR quant-ph/0602130v4 directly supplies the common de Finetti measure and symmetric purification. Singh-Cerf arXiv:2604.09410v1, opened in primary HTML, has energy-preserving-unitary invariance and diagonal energy-shell states, which are stronger/different premises; main theorem and definitions were read, not its whole proof. Other broad search results were not used as scientific evidence. Historical novelty of the generating-polynomial purity bound and charged discrimination consequence is UNKNOWN.
