# Acquired calibration and a static target independent of bath asymptotics

8 October 2026. This addendum supplies explicit calibration accounting for bounded_heat_upper_FROZEN.md and a concrete state sequence. The state construction and asymptotic polarization are internally reconstructed here; the suggestion to separate static existence from inherited bath dynamics came from the integration auditor after the upper proof froze.

## Calibration without a supplied true Bloch vector

Fix a strict target margin N|b_true|^2>=1+epsilon. The target still obeys the exact-white-Schur premise and independent fresh-preparation assumption. On independent preliminary copies, measure r uniformly selected sites in each of the three Cartesian axes. Each pooled outcome Xbar=2J_R,a/r has mean b_true,a and variance at most

    1/r+2/(N-1)<=2/r,   for r<=N/128.

The two-body bound follows directly from <J_a^2><=<J^2>=3N/4. For m_c copies per axis, coordinate means have variance at most 2/(m_c r). Consequently

    Pr(||b_hat-b_true||>delta/sqrt(N)) <=18N/(m_c r delta^2).

For fixed confidence this charges O(N/(r delta^2)) preparations per axis. Median-of-means with O(log(1/eta_cal)) independent groups gives total O(N/(r delta^2) log(1/eta_cal)) preparations with the same Euclidean accuracy. The three-axis constant and all local readouts are charged. No global Casimir measurement is credited for free as experimental evidence; the variance bound here is a target-model condition for calibration power only.

Project b_hat onto the known ball |v|<=sqrt(3/N); Euclidean projection cannot increase its distance from the legal target b_true. Freeze this vector v before certification. Use v in beta_n=h_N n dot v, in A_0(v), and in the sound threshold

    U_N(v)=A_0(v)+kappa_r r(N|v|^2+1)/[6(N-1)]+C_K(r/N)^(3/2).

The ALLSEP upper is sound for every v in that ball, whether the calibration was accurate or was performed on an arbitrary separable null. Thus a false-positive bound does not presume that null calibration data came from the target model.

For the target, the exact first two Pauli supports now give target-minus-ALLSEP gap

    kappa_r r/[6(N-1)]
       * [N|b_true|^2-N|v-b_true|^2-1]
      -2C_K(r/N)^(3/2).

If delta^2<=epsilon/2, the gap is at least (kappa_* epsilon/24)(r/N) eventually. This supplies a power guarantee on the calibration-confidence event. Combining eta_cal with the certification Hoeffding error gives total error at most their sum. The calibration cost O(N/r log(1/eta)) is below the O(N^2/r^2 log(1/eta)) certification cost for r=o(N). The required polarization margin must be specified or independently bounded with confidence; an unproved supplied true parameter is not hidden inside the protocol.

The protocol computes finite-r binomial moments and a scalar angular integral, and stores/averages r outcomes per preparation. To acquire q_r,T_r without r+1 enormous binomial coefficients, stable log probabilities or the binomial recurrence suffice. A numerical threshold requires rigorously rounded calibration/integration errors below a fixed fraction of the certified O(r/N) gap. The displayed universal constants are enormous, so this is an asymptotic preparation theorem rather than a moderate-N implementation claim.

## Static existence with no inherited dynamical asymptotic

For each N define explicitly

    rho_N^down = direct_sum_M w_NM |j,-j><j,-j| tensor I_mult/d_mult,
    j=M/2,
    w_NM=(M+1)^2/[N/2+M/2+1] * Pr(S_N=M),

where S_N is the sum of N iid Rademacher variables and M>=0 has N's parity. Schur-Weyl multiplicities make these weights a probability law exactly. The state is permutation invariant, its Casimir mean is exactly 3N/4, and b_N=-(E_w M/N)e_z. This is the selected zero-occupation stationary collective-bath state, but its mathematical definition and the following limit do not require that dynamical interpretation.

Let X_N=S_N/sqrt(N). On any bounded positive interval, the weight multiplier converges uniformly to 2X_N^2. The Rademacher CLT therefore yields the truncated limit of E_w M/sqrt(N) as 2 E[Z^3 1_{Z>=0}], with Z standard normal. Removing the truncation is justified explicitly: w_NM<=2(M+1)^2 Pr(S_N=M)/N and E X_N^4=3-2/N<=3. Thus the leading positive third-moment tail is at most 6/R beyond X_N>R; the extra lower-degree terms from (M+1)^2 vanish with N or obey the same uniform tail control. Consequently

    sqrt(N)|b_N| -> 2 E[Z^3 1_{Z>=0}]
                    =2sqrt(2/pi)=sqrt(8/pi),
    N|b_N|^2 ->8/pi>1.

The centered entropy lower and bounded ALLSEP upper hence apply to this explicit static sequence independently of the older bath-time asymptotic proof. The strict spin-variance ratio is 3/4-2/pi<1/2. This establishes a mathematical concrete example of the matching preparation order; it does not assert that its laboratory preparation is free, fast or robust.

## Cross-copy null wording

Soundness is against inputs that are conditionally fully separable across the N laboratories at each round, or against a global multi-copy state fully separable across laboratories whose within-laboratory systems may be arbitrarily correlated. The local readouts and classical pooling preserve this condition under conditioning. Merely requiring every unconditional N-qubit marginal to be fully separable is insufficient to imply the martingale soundness claim, and is not the null model used here.
