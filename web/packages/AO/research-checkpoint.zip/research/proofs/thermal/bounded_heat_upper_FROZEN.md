# A bounded local heat test attains the quadratic ALLSEP preparation order

Thermal independent derivation, 8 October 2026. This is an internally reconstructed theorem candidate. It has not been externally validated and historical novelty is UNKNOWN. This file freezes the upper proof after the centered lower proof was preserved. The constants below establish an asymptotic theorem; they are deliberately enormous and do not constitute a practical finite-size experiment.

## Statement and resource interface

Let rho_N be permutation invariant with the exact white-input Schur weights in growing_relative_entropy.md, let b_N be its one-qubit Bloch vector, and assume liminf N|b_N|^2>1. The inherited polarized thermal sequence has N|b_N|^2 tending to 8/pi. For every r_N=o(N) with r_N>=2, genuine entanglement certification against ALL fully separable N-qubit states is possible with

    m = O((N/r_N)^2 log(1/eta))

independent fresh preparations, at most r_N sampled sites per preparation, product spin measurements on those sites, shared classical randomness and classical pooling. False positive and false negative probabilities are each at most eta. Together with centered_relative_entropy_FROZEN.md, this gives the sharp preparation order Theta(N^2/r_N^2), for fixed error, in this interface. At r=1 certification is impossible. All-site same-copy pooling is charged as r=N and lies outside the lower theorem.

The upper test is sound without any Schur or Casimir promise on the null. The target law and target polarization are used only for its power guarantee and parameter calibration. A null may be heterogeneous, non-permutation-invariant, mixed, and arbitrary fully separable. Its labels must be fixed before the random subset and axis are chosen. The product measurements preserve separability across laboratories, so sequential conditional soundness also holds for arbitrary within-laboratory correlations across fresh preparations. The matching lower theorem allows arbitrary joint quantum measurements on the accessed registers.

For bounded r the two-site protocol in blackbox_pair_upper.md already gives this order, uniformly over any fixed finite set of r's. The proof below treats r>=16384; its bounds are uniform in r, so these two protocols cover all r>=2.

## 1. The implementable bounded effect

On each fresh copy choose r distinct sites uniformly without replacement after preparation, and choose n uniformly on the unit sphere. Measure sigma_n at those sites and form J_n=(sum_i X_i)/2. Set V_n=exp(-J_n^2/r). White binomial moments are

    T_r = E_white exp(-J_z^2/r),
    q_r = E_white (J_z^2/r) exp(-J_z^2/r),
    kappa_r = T_r-4q_r,
    h_N = kappa_r N/[2q_r(N-1)],
    beta_n = h_N n dot b_N.

Pass a classical Bernoulli coin with probability

    W_n = exp[-J_n^2/r + beta_n J_n - beta_n^2 r/4]
        = exp[-(J_n/sqrt(r)-beta_n sqrt(r)/2)^2].

This probability is between zero and one for every outcome and input. Let W be the averaged r-site effect, and let A_0=Tr[(I/2^r)W]. All these finite-r calibration values depend on an explicit binomial sum and a one-dimensional spherical integral. They do not require a quantum collective measurement. Uniform sphere randomness can equivalently be approximated to o(r/N) total operator error, with that approximation charged to the threshold.

Write x=J_z/sqrt(r), Y=x^2. Under white input EY=1/4, EY^2<=3/16, EY^3<=15/64. Thus T_r>=exp(-1/4) and q_r>=EY-EY^2>=1/16. For r>=2,

    kappa_r = -4 Cov(Y,exp(-Y)) > 0.

A useful fully explicit lower bound is kappa_r>=kappa_*=exp(-12)/8. To see this, use an independent Y':

    kappa_r = 2 E[(Y-Y')(exp(-Y')-exp(-Y))].

E(Y-Y')^2=2 Var(Y)>=1/8. The contribution to E(Y-Y')^2 from Y>12 or Y'>12 is at most 3/(4*12)=1/16: for one tail bound (Y+Y')^2 using EY^3/12 +2EY^2 EY/12 +EY EY^2/12 <=3/(8*12), then double. On the retained region the exponential divided difference is at least exp(-12). This proves the stated lower bound. Also kappa_r<=1. Therefore N|b_N|^2<=3 and N>=2 imply |h_N|sqrt(N)|b_N|<=28=:H. The limiting white moments are T_infty=sqrt(2/3), q_infty=T_infty/6, kappa_infty=T_infty/3, by the elementary binomial CLT; the explicit proof does not require a CLT error rate.

## 2. Exact low-degree effect expansion

Let a_1 be W's Pauli coefficient vector on one site, and a_2 its coefficient matrix on two distinct sites. Permutation invariance of W gives these same coefficients at every support. Direct binomial identities give

    a_1 = (2q_r h_N/3)b_N + E_1,
    a_2 = -kappa_r I/[3(r-1)] + E_2,
    |E_1| <= r(|h_N||b_N|)^3/4,
    ||E_2||_F <= h_N^2 |b_N|^2.

Here is a uniform derivation that does not exchange uncontrolled series. Put g(x)=exp(-x^2), delta=beta sqrt(r). The one-site coefficient at axis n is (2/sqrt(r)) E_white[x g(x-delta/2)]. Symmetry removes the constant and quadratic Taylor terms; sup|g'''|<=12 and E|x|<=1/2 bound the remaining error by |beta|^3 r/4. The two-site coefficient is E_white[(4x^2-1)g(x-delta/2)]/(r-1). Its linear term vanishes. Since sup|g''|<=2 and E|4x^2-1|<=2, its change from -kappa_r/(r-1) is at most beta^2. Average n_i n_j=delta_ij/3 and use ||nn^T||_F=1. These establish all displayed bounds.

The same Taylor inequality gives |A_0-T_r|<=H^2(r/N)/12, since the averaged white linear term vanishes. In particular A_0>=T_r-H^2(r/N)/12.

## 3. Uniform higher-degree control for the target and bounded-mean products

Use the white Pauli norm ||A||_white^2=Tr(A^dagger A)/2^r. Since 0<=W<=I, ||W||_white<=1. The generating bound in growing_relative_entropy.md, summed only over degrees w>=3, gives for alpha=r/N<=1/128

    sum_{w>=3} ||target Pauli coefficients at weight w||_2^2
      <=259875000 alpha^3.

For a product array with Bloch vectors u_i, let g_N=N^-1 sum_i u_i, D=sqrt(N)|g_N|, Q=N^-1 sum_i u_i u_i^T. Permutation twirling is exactly the uniformly sampled-site marginal. Its generating function satisfies, for complex z and u=|z|,

    |prod_i (1+u_i dot z)|
      <=exp(sqrt(N)D u+Nu^2/2)
      <=exp(D^2/2+Nu^2).

The inequality |1+a|<=exp(Re a+|a|^2/2) proves the first bound for all complex a. Multivariate Cauchy at common radius squared w/(6N), followed by the same count/factorial calculation as the frozen lower proof, gives

    sum_{w>=3} ||product-twirl Pauli coefficients||_2^2
      <=112999 exp(D^2) alpha^3.

Indeed the weight-w bound is exp(D^2)(w+1)^2(17alpha)^w; the degree-three tail sum at 17alpha<=1/5 is at most 23*(17alpha)^3. Cauchy-Schwarz against W therefore bounds all omitted high-degree expectation terms by a constant times alpha^(3/2), uniformly when D<=K for any fixed K. This controls every degree through r rather than truncating a growing-degree expansion informally.

The target's two-body coefficient matrix has trace zero, because <J^2>=3N/4, and Frobenius norm at most 3/(N-1). A product twirl has exactly

    C_1=g_N,   C_2=(N g_N g_N^T-Q)/(N-1),   Tr Q<=1.

Combining these exact moments with Section 2 yields, uniformly for D<=K,

    E_target W = A_0 + kappa_r r N|b_N|^2/[3(N-1)] + O_K(alpha^(3/2)),
    E_product W = A_0 + kappa_r r[2N b_N dot g_N-N|g_N|^2+Tr Q]/[6(N-1)]
                    +O_K(alpha^(3/2)).

The quadratic expression is at most N|b_N|^2+1, by completing the square. One explicitly valid common error constant is

    C_K = sqrt(259875000)+sqrt(112999)exp(K^2/2)
          +H^3 max(K,sqrt(3))/4 +H^2 max(K^2+1,3),

for alpha<=1/128. The alpha^2 errors from the first two supports have been bounded by alpha^(3/2). This constant is finite and specified, although exceptionally large for the conservative K below.

## 4. Larger product means cannot maximize the test

This is necessary: the bounded-mean expansion alone is not a sound ALLSEP upper bound.

First suppose |g_N|<=1/2. Centering the product generating function at g_N cancels its linear term and gives

    |prod_i[1+(u_i-g_N) dot z]|<=exp(N|z|^2/2),

because sum_i(u_i-g_N)=0 and sum_i|u_i-g_N|^2<=N. The centered one-site Gram matrix has smallest eigenvalue at least 1/2. The support-wise Parseval argument in centered_relative_entropy_FROZEN.md, now using radius squared w/(3N), proves

    chi_P^2(product-twirl_r || tau_g^tensor r)
      <=sum_{w>=2}(w+1)^2(17alpha)^w<=4046 alpha^2.

Consequently its half trace distance from tau_g^tensor r is at most 32alpha, uniformly over all such product arrays.

Let mu^2=r|g_N|^2. The unshifted axis-averaged heat effect V on the identical product state has the exact quadratic expansion

    E_tau_g V = T_r-kappa_r mu^2/6+R,
    |R|<=mu^4 exp(mu^2/2)/sqrt(24).

This follows by pairing even Pauli supports, bounding the weight-four-and-higher coefficient norm by sum_{w>=4} binom(r,w)|g_N|^(2w), and using ||V||_white<=1. If mu^2<=kappa_r/24, then E_tau_g V<=T_r-kappa_r mu^2/12. For mu^2>=kappa_r/24, monotonicity in |g_N| instead gives E_tau_g V<=T_r-kappa_r^2/288. The monotonicity is exact: the law of |J_n| under binomial bias has likelihood proportional to cosh(2 atanh(|g_N dot n|)|J_n|), an increasing-likelihood-ratio family in |J_n|, while the heat function decreases in |J_n|. Angular averaging preserves monotonicity.

The field cannot offset an arbitrarily large mean at the small-mu scale. Uniform Taylor remainder gives

    ||W_n-V_n-beta_n J_n V_n||<=beta_n^2 r/4.

For a biased identical product, |E J_n V_n|<=r|g_N dot n|/2. To verify this, condition on |J_n|: its signed mean is |J_n| tanh(2 atanh(|g_N dot n|)|J_n|), increasing in |J_n|; its covariance with the decreasing heat function is nonpositive. Thus the field's averaged linear contribution is at most H alpha D/6, and its remainder is at most H^2 alpha/12. For product twirls include the 32alpha comparison error. Safe combined bounds are

    E_product W <= T_r-kappa_* alpha D^2/12+H alpha D/6+(2H^2+32)alpha
           when mu^2<=kappa_r/24,
    E_product W <= T_r-kappa_*^2/288+H sqrt(alpha)+(2H^2+32)alpha
           otherwise.

Set L_0=H^2+1 and choose, explicitly,

    K=4H/kappa_*+sqrt(96(H^2+12)/kappa_*)+1.

Then the first bound is below T_r-L_0 alpha for D>=K. The second is also below T_r-L_0 alpha whenever alpha is sufficiently small, uniformly; for example impose

    alpha <= min{1/128, (kappa_*^2/(1152H))^2,
                 kappa_*^2/[1152(3H^2+33)], 1/(8L_0)}.

Next suppose |g_N|>1/2. For a uniformly sampled r-site product twirl,

    Var(J_n/sqrt(r))
      =[1-(r-1)Q_nn/(N-1)-(N-r)(g_N dot n)^2/(N-1)]/4<=1/4.

The centered heat argument has mean sqrt(r)n dot(g_N-h_N b_N)/2. Its vector magnitude A is at least sqrt(r)/8 when N>=16H^2. Chebyshev and the bound exp(-x^2)<=1_{|x|<=sqrt(R)}+exp(-R) show

    E_product W <=2(1/2+sqrt(R))/A+exp(-R).

For completeness, the small-ball probability is bounded by min{1,(1/2+sqrt(R))^2/d_n^2}; this follows from Chebyshev when |d_n|>1/2+sqrt(R), and is trivial otherwise. Integrating min{1,c^2/(A^2 cos^2(theta))} over the uniform absolute cosine bounds it by 2c/A. With R=3 and r>=16384 the displayed expectation is less than 1/2. Meanwhile the proposed low-mean bound is at least T_r-L_0alpha>1/2 under the previous alpha restriction. Thus these large means also cannot maximize it.

These three exclusions close uniformity over all product arrays, not merely sequences with bounded collective means.

## 5. Sound threshold, target gap and preparation cost

By convexity, every fully separable null satisfies, for the finite parameter restrictions above,

    E_SEP W <= U_N
      :=A_0+kappa_r r(N|b_N|^2+1)/[6(N-1)]+C_K alpha^(3/2).

The target expectation exceeds this by at least

    kappa_r r(N|b_N|^2-1)/[6(N-1)]-2C_K alpha^(3/2).

If N|b_N|^2>=1+epsilon, this is at least c alpha eventually, with c=kappa_* epsilon/12>0. Accept entanglement when the observed Bernoulli pass fraction exceeds U_N+c alpha/2. Hoeffding gives each error at most exp(-m c^2 alpha^2/2). Therefore m>=2 log(1/eta)/(c^2 alpha^2) suffices. Conditional Hoeffding proves false-positive soundness under conditional fully separable inputs; random subset/axis choices and the local readouts must remain inaccessible to the preparation adversary before preparation.

The charged saturated resources are m fresh N-qubit preparations, mN=O(N^3/r^2) prepared qubit instances, and mr=O(N^2/r) local readouts, plus classical randomness, binomial calibration and arithmetic. The constants in this fully explicit certificate are not practical. The exponent is an asymptotic upper theorem; improved constants or a moderate-N executable witness remain separate obligations.

The vector b_N can be supplied by a verified target model. A preliminary independent data phase can also estimate it to small constant relative error with O(N/r) preparations and r-site pooled spin readouts, under the same target-law variance bound. Freeze the calibration vector before the certification phase and clip its norm to sqrt(3/N); soundness holds for every frozen vector. For target power, an error ||b_cal-b_N||<=c_0/sqrt(N) with c_0 depending on the strict B-1 margin suffices by the same completed-square formula. A claimed model-free guarantee must include this calibration confidence and its charged cost. No trusted null Casimir is used.

The bounded-r pair protocol and this bounded heat protocol together close the honest upper gate at the preparation-order level. They do not prove robustness to symmetry-breaking dynamics, unknown polarization margin, correlated target preparations, or a practical finite-N implementation at the constants displayed here.
