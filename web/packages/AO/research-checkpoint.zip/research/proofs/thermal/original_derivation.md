# Subextensive invisibility and charged local-access discrimination

Thermal worker original derivation, 8 October 2026. This was written before exposure to the independently dispatched marginal auditor. Status: internally reconstructed candidate mathematics; no external correctness, proof-assistant replay, experimental validation, or historical priority clearance.

## 1. Exact contract and comparison

Let \(\rho_N\) be any permutation-invariant state of \(N\ge2\) qubits, with \(J_a=\frac12\sum_i\sigma_a^{(i)}\), satisfying
\[
\operatorname{Tr}\rho_NJ^2=3N/4.
\]
Write \(\rho_{N,r}\) for its marginal on any \(r\) sites and \(D_T=\frac12\|\cdot\|_1\). The maximally mixed comparator is \(\omega_r=I/2^r\). The theorem below needs only permutation invariance and this single Casimir expectation, rather than preservation of the complete spin-sector law.

For the ideal collective bath from the maximally mixed input, both properties hold at every time and every bath occupation, including arbitrary \(N\)-dependent occupations. Thus the conclusions are uniform in time, occupation, and selected subset. No unequal-coupling or local-noise-during-preparation assumption is made.

The current repository proves fixed-size all-time invisibility, and previously gives stationary invisibility for \(r=o(\sqrt N)\). The reconstruction here reaches every \(r=o(N)\).

## 2. The common-measure issue is essential

The usual finite de Finetti theorem, applied separately at sizes two and \(r\), would not suffice: the two measures could differ. The CKMR proof supplies the same measure for all sizes.

Use the symmetric purification \(|\Psi_{\rho_N}\rangle\in\operatorname{Sym}^N(\mathbb C^2\otimes\mathbb C^2)\) from CKMR Lemma II.5. For a Haar-random unit vector \(\phi\in\mathbb C^4\), set
\[
dm_N(\phi)=\dim\operatorname{Sym}^N(\mathbb C^4)
\,|\langle\phi^{\otimes N}|\Psi_{\rho_N}\rangle|^2d\phi.
\]
This is a probability measure, independent of \(r\). Push it forward to the qubit state \(\tau_\phi=\operatorname{Tr}_{\rm anc}|\phi\rangle\langle\phi|\), and denote the resulting measure by \(\mu_N\). CKMR Theorem II.2, its explicit measure in its proof, and trace-norm contractivity give, simultaneously for all \(1\le k\le N\),
\[
 D_T\left(\rho_{N,k},M_{N,k}\right)\le\epsilon_{N,k},
\quad M_{N,k}=\int\tau^{\otimes k}\mu_N(d\tau),
\]
where
\[
\epsilon_{N,k}=2\left[1-
\frac{\binom{N-k+3}{3}}{\binom{N+3}{3}}\right]
\le\frac{6k}{N+1}.
\]
Bounds may be capped at one. CKMR uses half trace norm, so the convention matches exactly. The last inequality follows from
\(\prod_{i=1}^3(1-k/(N+i))\ge1-3k/(N+1)\).

## 3. Conservation forces the de Finetti measure toward the white state

Write \(\tau=(I+u\cdot\sigma)/2\), \(|u|\le1\), and let
\(B=\sum_{a=x,y,z}\sigma_a\otimes\sigma_a\). Its eigenvalues are \(1\) on the triplet and \(-3\) on the singlet, hence \(\|B\|_\infty=3\). Permutation invariance and the exact Casimir condition give
\[
 \operatorname{Tr}\rho_{N,2}B
 =\frac{4\operatorname{Tr}\rho_NJ^2-3N}{N(N-1)}=0.
\]
Meanwhile \(\operatorname{Tr}\tau^{\otimes2}B=|u|^2\). Because the measure in Section 2 is common to all sizes,
\[
 \int |u|^2\mu_N(d\tau)
 \le 2\|B\|_\infty\epsilon_{N,2}
 \le\frac{72}{N+1}.
\]
This conclusion does not follow by applying two unrelated de Finetti approximations.

For a qubit, with natural logarithms,
\[
 D(\tau\|I/2)=\tfrac12[(1+t)\log(1+t)+(1-t)\log(1-t)]
 \le(\log2)t^2,\quad t=|u|.
\]
One proof expands the left side as
\(\sum_{n\ge1}t^{2n}/[(2n)(2n-1)]\); since \(t^{2n}\le t^2\), the coefficient sum is its value at \(t=1\), namely \(\log2\).
Quantum Pinsker, convexity of trace distance, tensor additivity of relative entropy, and Jensen now give
\[
 D_T(M_{N,r},\omega_r)
 \le\int\sqrt{\tfrac r2D(\tau\|I/2)}\,d\mu_N
 \le6\sqrt{\frac{(\log2)r}{N+1}}.
\]
Consequently the exact finite-size inequality is
\[
 \boxed{D_T(\rho_{N,r},\omega_r)
 \le\min\left\{1,\frac{6r}{N+1}
       +6\sqrt{\frac{(\log2)r}{N+1}}\right\}.}
\]
Thus \(r_N=o(N)\) implies trace-distance invisibility. The numerical constants are conservative; the scale, rather than these constants, is the point.

## 4. Sharp growth boundary at the subcritical entangled time

The inherited subcritical theorem supplies a sequence of states with
\(D_T(\rho_N,\operatorname{SEP}_N)\to1\), and with excitation fraction tending to zero in typical spin sectors. The conserved Maxwell spin law then gives
\[
 P_N=-\langle J_z\rangle/\sqrt N\longrightarrow
 P=\sqrt{2/\pi}.
\]
The last step follows by uniform integrability of \(M/\sqrt N\) and
\(J_z=M(y-1/2)\). It is separately valid for the zero-temperature selected stationary state.

Let \(r_N/N\to\alpha\in(0,1]\), set \(T_N=J_{R,z}/\sqrt{r_N}\), and define a bounded observable
\(f_L(T)=\max\{-1,\min\{1,T/L\}\}\). Permutation invariance gives
\[
 -\langle T_N\rangle=\sqrt{r_N/N}\,P_N\to\sqrt\alpha P,
\]
and the exact two-site sampling identity yields
\[
 \langle T_N^2\rangle
 =\frac14+\frac{r_N-1}{N-1}
 \left(\frac{\langle J_z^2\rangle}{N}-\frac14\right)
 \le\frac14+\frac{r_N-1}{2(N-1)}\le\frac34.
\]
The white state has \(\langle f_L(T_N)\rangle=0\) by symmetry. Also
\(\left|T-f_L(T)L\right|\le T^2/L\), so, putting \(\mu=\sqrt\alpha P\),
\[
 \liminf D_T(\rho_{N,r_N},\omega_{r_N})
 \ge\frac12\left(\frac\mu L-\frac{3}{4L^2}\right).
\]
Choose \(L=3/(2\mu)\), obtaining
\[
 \boxed{\liminf D_T(\rho_{N,r_N},\omega_{r_N})
 \ge\frac{\alpha P^2}{6}=\frac{\alpha}{3\pi}>0.}
\]
No unbounded expectation is directly converted into a trace-distance witness. The clipped magnetization can be implemented by \(r_N\) local \(z\)-measurements and classical summation. Hence the universal subextensive scale cannot be extended to a positive fraction of the system for this family.

## 5. Resource theorem for fresh preparations

Now require the complete Schur weights selected by the maximally mixed input, rather than only its second moment. A permutation-invariant state has the form
\(\bigoplus_j w_{Nj}\tau_j\otimes I_{m_j}/m_j\). Preserving these weights gives the exact entropy defect
\[
 D(\rho_N\|\omega_N)=\sum_jw_{Nj}[\log(2j+1)-S(\tau_j)]
 \le\mathbb E\log(M+1)
 \le\tfrac12\log(3N+1),
\]
where \(\mathbb E(M+1)^2=3N+1\) follows from the Casimir expectation. Strong subadditivity makes the symmetric entropy increments nonincreasing; therefore \(S(\rho_{N,r})/r\ge S(\rho_N)/N\), and
\[
 \boxed{D(\rho_{N,r}\|\omega_r)
 \le\frac{r}{2N}\log(3N+1).}
\]

Consider \(m\) independent fresh preparations of the target or of \(\omega_N\). A protocol accesses at most \(r\) distinct physical sites of EACH prepared copy, and may retain quantum memory, measure jointly across the accessed sites/copies, and adapt to earlier outcomes. Exchangeability permits relabeling newly accessed sites to a canonical \(r\)-site register, because all unaccessed labels remain equivalent conditional on the protocol history. Thus this protocol is a channel of \(\rho_{N,r}^{\otimes m}\) versus \(\omega_r^{\otimes m}\). Pinsker and data processing imply
\[
 \boxed{\operatorname{TV}(\text{target output},\text{white output})
 \le\min\left\{1,\sqrt{\frac{mr\log(3N+1)}{4N}}\right\}.}
\]
For variable per-copy budgets \(r_i\), replace \(mr\) by \(\sum_i r_i\). Constant discrimination bias therefore needs \(mr=\Omega(N/\log N)\). This is a bound on total distinct readouts across fresh preparations, not a bound merely on single-qubit measurement locality. Pooling all \(N\) outcomes from one copy has per-copy budget \(r=N\) and is permitted by the existing global witness.

### Fixed-size access removes the logarithmic gap

For every fixed \(r\), the initial Schur law has \(\mathbb E M^w=O_w(N^{w/2})\). The source local-moment argument can be reconstructed uniformly over all states within the conserved sectors:
\[
 |C_{a_1\ldots a_w}|\le
 \frac{\mathbb E M^w+\binom w2N^{w-1}}{(N)_w}
 =O_w(N^{-w/2}+N^{-1}).
\]
The numerator uses the norm of the ordered collective product and a union bound for colliding site tuples. For one-site strings, the squared Bloch norm obeys
\(\sum_a C_a^2=4|\langle J\rangle|^2/N^2\le3/N\).
By the Pauli expansion,
\[
 \chi^2(\rho_{N,r}\|\omega_r)
 :=2^r\operatorname{Tr}\rho_{N,r}^2-1
 =\sum_{P\ne I}C_P^2\le\frac{3r}{N}+O_r(N^{-2}).
\]
Since relative entropy is bounded by its order-two Renyi counterpart,
\[
 D(\rho_{N,r}\|\omega_r)\le\log(1+\chi^2)
 \le\frac{3r}{N}+O_r(N^{-2}).
\]
Thus every fixed \(r\) demands \(\Omega_r(N)\) independent preparations for constant output discrimination bias, even with joint quantum measurements of all accessed registers. This also obstructs a uniformly valid entanglement test: the white alternative is itself fully separable.

At the inherited strongly entangled subcritical time, this scaling is achievable. Measure \(z\) on \(r\) sites per preparation. Target magnetization mean is \(-rP_N/\sqrt N\), white mean is zero; target variance is at most \(3r/4\), white variance is \(r/4\). Threshold the average of \(m\) preparations at \(-rP_N/(2\sqrt N)\). Chebyshev bounds the sum of both errors by
\[
 \frac{4N}{mrP_N^2}.
\]
For fixed \(r\), \(m=O_r(N)\) suffices for any chosen constant error, matching the lower scaling. Preparation uses \(mN=\Theta_r(N^2)\) physical qubit instances, \(mr=\Theta(N)\) local readouts, and \(m\) independent bath evolutions. This operational claim is state discrimination/necessary entanglement-test resources, not a complete entanglement certification protocol against every separable alternative.

## 6. Scope, failed escalation, and next decisive gates

The all-\(r\) upper bound is a corollary of established finite quantum de Finetti mathematics plus the model's conservation law. It changes the accessible subsystem scale within the repository. Historical novelty is UNKNOWN and likely substantially overlaps general mean-field/local-equivalence results.

The fixed-\(r\) preparation scaling is matched against an equally informed white comparator and an executable magnetization measurement. For growing \(r\), the entropy method leaves a logarithmic gap: \(\Omega(N/(r\log N))\) necessary versus \(O(N/r)\) sufficient. I did not prove the tempting stronger all-size relative-entropy estimate \(D(\rho_{N,r}\|\omega_r)=O(r/N)\). Applying entropy continuity to the de Finetti approximation pays dimension \(2^r\) and yields an \(r^2/N\) penalty, so it does not remove the gap.

No exact critical-bath distance-to-SEP or intrinsic separability boundary is derived. The existing critical window's separable upper bound and heat-effect lower bound remain distinct, unclosed claims. No inference of cryptographic hiding against unrestricted LOCC, entanglement depth above two, physical bath-engineering efficiency, or robustness to symmetry-breaking noise follows.

Next decisive gate: independent check of the common measure, the fixed-\(r\) Renyi calculation, and adaptive relabeling interface; then either establish the uniform growing-\(r\) relative-entropy estimate or produce a conserved-sector counterexample with a logarithmic entropy excess.

## 7. Provenance

Primary external source actually opened: Christandl, Koenig, Mitchison, Renner, *One-and-a-half quantum de Finetti theorems*, arXiv:quant-ph/0602130v4, https://arxiv.org/pdf/quant-ph/0602130, Theorem II.2 and its measure in the proof, pp. 2-3; Corollary II.3, p. 3; Lemma II.5 and Theorem II.7, p. 4. Their trace-distance convention is half norm. A local PDF snapshot is retained under sources/.

Pinned repository commit: 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce. Task sources: state/2026-10-08-local-invisibility-corollary.md; state/2026-10-08-square-root-bath-occupation-threshold.md; state/2026-10-08-far-from-equilibrium-near-unit-entanglement.md. Current notices N120, N130, N179, N180 were read. N179/N180 exact proof text is retained in web/pages/d-095e9993aec693cc.html and web/pages/d-e875aa79835b9153.html; content availability does not imply proof correctness.
