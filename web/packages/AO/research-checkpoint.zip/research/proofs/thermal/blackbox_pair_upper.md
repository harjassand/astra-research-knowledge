# Honest fixed-access certification upper bound and resource clarification

8 October 2026. This supplies a complete sound upper protocol using two sampled sites and preserves the growing-access upper as a separate proof obligation.

For any chosen vector \(v\in\mathbb R^3\), define the tangent witness
\[
 H_N(v)=J^2-2v\cdot J+|v|^2I-NI/2.
\]
Every fully separable state obeys
\[
 \langle H_N(v)\rangle
 =\sum_a\operatorname{Var}(J_a)-N/2+|\langle J\rangle-v|^2\ge0.
\]
This is the established spin-variance inequality, with its mean frozen to obtain a linear witness. Its soundness does not require a Casimir or Schur-law promise for the null.

For each prepared copy, sample ordered distinct sites i,j uniformly after preparation, sample axis a uniformly from x,y,z, and measure sigma_a on those two sites, obtaining X_i,X_j in {-1,1}. Set
\[
 Y=\frac14+\frac{|v|^2}{N}
   +\frac{3(N-1)}4X_iX_j-3v_aX_i.
\]
For every input state, \(\mathbb EY=\langle H_N(v)\rangle/N\). Its range has width at most
\(L_N=3(N-1)/2+6|v|\), independent of the input. Thus with m fresh preparations, accept entanglement if the average Y is at most -delta_N/2, where the target has \(\langle H_N(v)\rangle/N=-\delta_N<0\). The false-positive probability for every fully separable null and the false-negative probability for the target are each at most
\[
 \exp[-m\delta_N^2/(2L_N^2)].
\]
This follows from Hoeffding; conditional Hoeffding gives the same false-positive guarantee for a sequence of conditional fully separable inputs. The local product measurements also preserve full separability across laboratories if a multi-copy null contains arbitrary within-laboratory quantum correlations. Classical site/axis randomness is chosen after preparation.

For the polarized thermal target, v=<J> gives
\(\delta_N=|\langle J\rangle|^2/N-1/4\to2/\pi-1/4>0\). Alternatively choose v=-sqrt(2/pi)sqrt(N)e_z from the supplied asymptotic model; its target margin tends to the same positive number. Consequently m=O(N^2 log(1/eta)) preparations make total error at most eta using two sites each. This matches the centered lower bound's N^2 order for every fixed r>=2. It does not yet exploit a growing r budget optimally.

At r=1, ALLSEP certification is impossible through this interface for any m, since the matching product-marginal null reproduces the entire accessible state. This is stronger than a finite sample lower bound.

The means, margin and threshold may be supplied by a certified model, or estimated in a separate calibration phase. The parameter v can be frozen from data; the witness remains sound for every frozen v. A model-free target-power guarantee needs a confidence bound on its negative expectation, whose measurements are part of the charged protocol. No supplied global Casimir is silently credited as acquired experimental evidence.

## Deterministic variable budgets and actual readouts

The centered entropy theorem also gives, for deterministic per-copy access caps r_i<=r satisfying the theorem's size range,
\[
 D(\bigotimes_i\rho_{r_i}\|\bigotimes_i\tau^{\otimes r_i})
 \le(2\cdot10^9/N^2)\sum_i r_i^2.
\]
Constant output discrimination bias therefore requires \(\sum_i r_i^2=\Omega(N^2)\). Since \(r_i^2\le r r_i\), it follows that \(\sum_i r_i=\Omega(N^2/r)\). This is an actual total-readout lower bound when r_i records the deterministic distinct-site budget charged for each copy.

With only a common maximum r, the theorem m=Omega(N^2/r^2) directly implies Omega(N^3/r^2) prepared qubit instances. The expression Omega(N^2/r) readouts is then the saturated-budget cost, not a deduction about the actual number read by a protocol that touches fewer than r sites. Random stopping budgets require additional accounting; no expected-readout theorem is inferred here.

Preserved finite-check failure: exact_centered_purity.py initially hit Python's 4300-digit display limit on trusted exact fractions. Its bounded display limit was increased to 50,000 digits, then the same cases reran successfully. No pass/fail depended on a rounded value. It produced 25 small matrix-versus-rational cross-checks and five exact cases through N1024,r8, including exactly zero centered chi-square at r1.
