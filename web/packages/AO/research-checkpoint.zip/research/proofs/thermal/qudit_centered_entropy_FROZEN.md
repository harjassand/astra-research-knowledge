# Fixed-dimension qudit centered local entropy under a Young-sector tail

Thermal proof extension, 8 October 2026. This file freezes an internally reconstructed candidate theorem. No independent proof was read before this freeze. The parent/integration supplied the intended Young-sector interface and the useful one-body decomposition; the representation, Gram, determinant and coefficient proof is fully written below. External correctness, formal validation and historical priority remain UNKNOWN. This theorem does not claim a matching qudit certification upper protocol.

## 1. Statement with explicit finite ranges

Fix an integer d>=2. Let rho_N be a permutation-invariant state on (C^d)^tensor N. Its Schur-Weyl sectors are indexed by legal partitions lambda of N with at most d rows, padded with zeros. Write

    K(lambda)=N-d lambda_d.

Sector probabilities are p_lambda, and the normalized state within every U(d) irrep may be arbitrary. Suppose constants A>=1, B>=0, C>=0 independent of N satisfy

    E_p exp[t K/sqrt(N)] <= A exp(Bt^2+Ct),   for every t>=0.

Let tau=rho_{N,1}, s=d^2-1, K_2=A exp(B+C), a=sqrt(d)+1,

    L=sqrt((d-1)K_2)+aC,   S=3/2+B a^2,
    C_d=25(s-1)! (5/4)^s A^2 exp(L^2)(16eS s)^2.

For N>=4dK_2 and

    1<=r<=N min{1/2,1/(80eS s)},

tau is full rank and

    chi_P^2(rho_{N,r} || tau^tensor r)
      :=Tr[rho_{N,r}^2 (tau^tensor r)^-1]-1
      <=C_d (r/N)^2,
    D(rho_{N,r} || tau^tensor r)<=C_d (r/N)^2.

Every subextensive r_N=o(N) satisfies the displayed range eventually for fixed d,A,B,C. At r=1 both quantities are exactly zero. The theorem covers noncommuting sector states and references; no diagonal-in-energy or singlet-sector assumption is made.

Consequently, a certifier sound against ALL fully separable N-qudit global states and with at most r distinct sites accessed on each of m independent fresh preparations requires m=Omega_{d,A,B,C}(N^2/r^2) for fixed discrimination bias. Arbitrary joint quantum measurements, memory, and classically adaptive physical labels are allowed. The fully separable hard null is tau^tensor N. At r=1 the entire accessible input is exactly identical for every m, so certification is impossible. A trusted null sector constraint can exclude this hard null and changes that conclusion.

## 2. Schur blocks, residual tensor realization, and the one-body state

Schur-Weyl decomposition is

    (C^d)^tensor N = direct_sum_lambda V_lambda^(d) tensor M_lambda^(S_N).

Permutation invariance makes rho_N exactly direct_sum_lambda p_lambda rho_lambda tensor I_mult/dim(M_lambda). The inequivalent S_N irreps forbid intersector coherence, while rho_lambda may have arbitrary coherence within its U(d) irrep.

Put mu=lambda-lambda_d(1,...,1). It is a legal partition of K with last row zero. The U(d) representation is V_lambda=det^lambda_d tensor V_mu, and V_mu has an isometric unitary intertwining realization inside (C^d)^tensor K. The inner product can be chosen so this equivalence is unitary, since these are finite-dimensional irreducible unitary representations. Transport rho_lambda to this residual realization, and average its K one-body marginals to a density matrix gamma_lambda (choose any gamma when K=0).

For every Hermitian H, differentiating the representation at exp(tH) gives the collective identity

    N Tr(tau_lambda H)=lambda_d Tr H+K Tr(gamma_lambda H).

Both sides are linear in H; equality follows from the determinant derivative lambda_d Tr H and the residual sum of K copies of H. Therefore exactly

    tau_lambda=(lambda_d/N) I+(K/N)gamma_lambda
              =(1-K/N)I/d+(K/N)gamma_lambda.

Averaging sectors yields tau>= [1-EK/N]I/d. Also, in Hilbert-Schmidt norm,

    ||tau-I/d||_HS <= (EK/N)sqrt(1-1/d),

by convexity and ||gamma-I/d||_HS<=sqrt(1-1/d).

Since x^2<=exp(x) for x>=0, the t=1 tail premise gives EK^2/N<=K_2. Thus EK/N<=sqrt(K_2/N), and N>=4dK_2 gives tau>=I/(2d).

Choose a Hermitian traceless basis T_1,...,T_s with Tr(T_a T_b)=d delta_ab. Write

    tau=(I+sum_a b_a T_a)/d,   b_a=Tr(tau T_a),
    beta=|b|,   beta^2=d||tau-I/d||_HS^2
                            <=(d-1)K_2/N<=1/4.

These exact normalizations prevent an extra uncharged d in the generating polynomial or Gram matrix.

## 3. The centered Gram and support-wise Petz Parseval

Set B_a=T_a-b_a I. With inner product <X,Y>_tau=Tr(tau X^dagger Y), the identity is orthogonal to each B_a. The complex Hermitian Gram is

    G_ab=Tr(tau B_a B_b).

For every v in C^s, W=sum_a v_a B_a satisfies

    v^dagger Gv=Tr(tau W^dagger W)
      >=Tr(W^dagger W)/(2d)
      =[|v|^2+|b dot v|^2]/2 >=|v|^2/2.

The middle identity uses tracelessness and the normalized Hilbert-Schmidt orthogonality of T_a. In particular no replacement of this complex Gram by its real covariance part is made.

For T=tau^tensor r and R=rho_{N,r} T^-1, its weighted norm is ||R||_T^2=Tr(rho_{N,r}^2 T^-1), and its coefficient against a centered support operator is

    <B_support,R>_T=Tr(rho_{N,r} B_support^dagger).

Cyclicity cancels T^-1 T; commutation of rho with T is unnecessary. Products of I and the B_a form a complete basis, and different supports are orthogonal. Weighted Parseval therefore gives

    chi_P^2 =sum_{nonempty supports Q} c_Q^dagger G^-1 tensor |Q| c_Q
            <=sum_{w=2}^r 2^w sum_{|Q|=w} sum_{a_1,...,a_w}|c_{a_1...a_w}|^2.

All weight-one coefficients vanish because tau is the actual marginal. Gram conditioning is paid on support size w, not as a factor exponential in r.

## 4. Complex Schur norm including singular matrices

For any complex d by d matrix A, the sector action obeys

    pi_lambda(A)=(det A)^lambda_d pi_mu(A),
    ||pi_lambda(A)||<=|det A|^lambda_d ||A||^K.

For invertible A this is the polynomial highest-weight representation identity, and the norm bound follows either by the residual tensor embedding or by singular-value decomposition: the unitary factors act unitarily, and all residual diagonal weights are monomials of total degree K in nonnegative singular values. The bound is therefore valid for nonnormal A. Polynomial continuity extends the identity and inequality to singular A. If lambda_d=0 the determinant factor is defined as 1, including det A=0. If lambda_d>0 and det A=0, both the representation factor and pi_lambda(A) are zero. No logarithm of a zero determinant is needed.

We will use the determinant inequality, valid for every complex W,

    |det(I+W)| <=exp[Re Tr W+||W||_HS^2/2].

Indeed |det(I+W)|^2=det[(I+W)^dagger(I+W)]. If the positive matrix is invertible, log det <=Tr(matrix-I) by scalar log x<=x-1 on its eigenvalues. This trace equals 2Re Tr W+||W||_HS^2. If it is singular the determinant is zero and the inequality is immediate. There is no small-norm hypothesis and no use of a noncommutative logarithm expansion.

## 5. Centered generating polynomial and fixed-d Cauchy bound

For z in C^s, u=|z|, define Z=sum_a z_a T_a and

    F_N^b(z)=Tr rho_N [I+Z-(b dot z)I]^tensor N.

Tr Z=0, ||Z||_HS^2=d u^2, and for W=Z-(b dot z)I,

    Re Tr W <=d beta u,
    ||W||_HS^2=d(u^2+|b dot z|^2)<=d(1+beta^2)u^2,
    ||I+W||<=1+(sqrt(d)+beta)u<=1+a u.

The Schur bound and d lambda_d<=N give

    |F_N^b(z)|
      <=exp[N beta u+N(1+beta^2)u^2/2] E exp(aKu)
      <=A exp[L sqrt(N)u+Nu^2+Ba^2Nu^2]
      <=A exp(L^2/2) exp(SNu^2).

Here beta sqrt(N)<=sqrt((d-1)K_2), beta<=1/2, and Young's inequality absorbs the linear term. The finite N range supplies all these facts. Sector states enter only through positivity, unit trace and their operator-norm bound, so their coherences cause no exception.

For a count vector n=(n_1,...,n_s), weight w=sum n_a, permutation invariance gives exactly

    [z^n]F_N^b=(N)_w c_n/(prod_a n_a!).

Use the common polydisc radius R^2=w/(2SsN). Its boundary has u^2=sR^2 and the squared generating bound becomes A^2 exp(L^2) exp(w). Cauchy's coefficient inequality yields

    |[z^n]F_N^b|^2
      <=A^2 exp(L^2) exp(w)(2SsN/w)^w.

There are binom(w+s-1,s-1)<=(w+1)^(s-1) count vectors and prod n_a!<=w!<=w^w. After the exact support multiplicities from Parseval, for alpha=r/N<=1/2,

    chi_P^2 <=A^2 exp(L^2) sum_{w>=2}(w+1)^(s-1) q^w,
    q=4eSs alpha/(1-alpha)^2 <=16eSs alpha<=1/5.

For completeness, (w+1)^(s-1)<=(s-1)! binom(w+s-1,s-1), so

    sum_{w>=2}(w+1)^(s-1)(1/5)^(w-2)
      <=25(s-1)!(5/4)^s.

This gives precisely C_d alpha^2 as claimed. All degrees through growing r were controlled together.

## 6. Relative entropy and access consequences

Diagonalize rho_{N,r} and T with eigenvalues lambda_i and mu_j>0, and use overlap probabilities c_ij=|<i|j>|^2. Then lambda_i c_ij form a probability law. Scalar Jensen gives

    D(rho||T)=sum_ij lambda_i c_ij log(lambda_i/mu_j)
       <=log sum_ij lambda_i^2 c_ij/mu_j
       =log Tr(rho^2 T^-1)<=chi_P^2.

Zero lambda_i have zero probability and pose no problem. The fully separable product null tau^tensor N exactly matches all one-body data. Permutation invariance gives the same canonical-slot CPTP simulation of classically adaptive distinct-site access as in the qubit proof; it does not depend on local dimension. Additivity and data processing give output TV<=sqrt(m C_d/2)(r/N). A fixed positive bias forces m=Omega(N^2/r^2).

Charge m fresh global N-qudit preparations and mN prepared physical systems. The saturated upper exposure cap is mr sites; an actual readout lower follows for deterministic per-copy budgets r_i from sum_i r_i^2=Omega(N^2), and hence sum_i r_i=Omega(N^2/r_max). Coherent global-address operations and gates on unvisited sites are excluded by the distinct-site interface. Correlated target copies or unbounded stopping budgets require another theorem.

No qudit bounded-witness upper has been supplied. A matching upper would need a separately proved separable geometry and target-power margin, which are not consequences of the tail condition alone. The qubit heat construction is not automatically carried over by replacing Pauli dimension three with s.
