# Thermal certification theorem package, second stage

8 October 2026. Original proofs, failures and first-stage session are preserved unchanged. This report records the stronger centered entropy, genuine certification upper, and fixed-d extension. All mathematical results are internally reconstructed candidates; several have received exposed internal audits. External correctness, formal replay and historical priority remain UNKNOWN.

The strongest qubit result is a matching preparation-versus-access theorem for genuine entanglement certification against ALL fully separable N-qubit alternatives. Under exact-white Schur weights, every subextensive r>=2 needs and permits Theta(N^2/r^2) fresh global preparations for fixed error, for targets with liminf N|b|^2>1. The lower allows arbitrary collective quantum processing across accessed registers. The upper uses r randomly selected local spin readouts, a shared random axis and classical pooling. It is an asymptotic result with enormous displayed constants; no useful moderate-N finite certificate has been obtained.

The strongest structural extension is fixed local dimension d>=2: a uniform subGaussian tail for K=N-d lambda_d implies Petz chi-square and relative entropy O_{d,A,B,C}((r/N)^2) to the actual one-body product, for arbitrary U(d) sector states and every r=o(N). This proves the same necessary ALLSEP preparation cost in that class. A matching qudit upper has not been proved.

## Exact claims and proof files

| Claim | Assumption and conclusion | Internal status |
|---|---|---|
| Centered qubit entropy | PI and exact white Schur weights; tau=rho_1; Petz chi-square and KL <=2e9(r/N)^2 for r<=N/1024 | Own generating proof frozen before competing argument exposure; exposed integration audit found no gap |
| Centered independent constant | Same exact-weight class; competing proof <=34992(r/N)^2 for r<=N/128 | Parent-reported independent candidate subsequently adversarially reconstructed in centered_audit; this worker's proof preserved separately |
| ALLSEP preparation lower | Independent fresh target preparations; <=r distinct sites each; arbitrary joint quantum instruments; product-marginal null legal | Omega(N^2/r^2); r=1 exact impossibility |
| Qubit bounded upper | Exact-weight target, liminf N|b|^2>1; independent target preparations | O(N^2/r^2 log(1/eta)); exposed integration audit found no fatal gap; fresh target-only upper audit pending |
| Qubit spin-tail entropy | E exp(tM/sqrt(N))<=A exp(Bt^2+Ct), all t>=0 | Complete proof frozen; independent target-only derivation pending |
| Fixed-d Young-tail entropy | PI d-qudits; arbitrary irrep states; E exp(tK/sqrt(N))<=A exp(Bt^2+Ct), all t>=0 | Complete proof frozen; explicit finite range and constants; independent target-only derivation pending |
| Mean-only replacement | <J^2>=3N/4 without a spin tail | Refuted by integration's rare all-up plus twirled-singlet-pair example; centered KL Omega(r/N) for log N<<r=o(N) |

The proofs are in centered_relative_entropy_FROZEN.md, bounded_heat_upper_FROZEN.md, subgaussian_spin_tail_FROZEN.md and qudit_centered_entropy_FROZEN.md. The latter includes the exact residual one-body decomposition, complex Gram, arbitrary nonnormal/singular matrix Schur norm, determinant-square trace inequality, and fixed-d coefficient sum. The final d-qudit constant and range are fully displayed there. Nothing promotes a competing proof by agreement alone.

## What closes the operational gap

White-state discrimination costs Theta(N/r) at the polarized thermal time, but is not a complete entanglement test. The centered null tau^tensor N is globally fully separable and has identical one-body data. Removing all degree-one information makes its local relative entropy quadratic and forces the larger cost.

The honest qubit upper uses the probability exp[-(J_n/sqrt(r)-h_N sqrt(r)(n dot b)/2)^2]. Finite white binomial moments fix h_N. Its target-minus-ALLSEP gap is

    kappa_r r(N|b|^2-1)/[6(N-1)] + o(r/N).

The proof bounds all Pauli supports and separately excludes large collective means of heterogeneous product arrays. Convexity covers every fully separable null. A bounded-mean calculation alone would not have sufficed. The readouts are local and the same-copy outcomes are explicitly pooled and charged as r-site access.

Known b may be supplied by a verified target model. Otherwise independent pooled three-axis calibration costs O(N/r log(1/eta)) preparations at fixed strict margin. Freeze and clip its estimate v; soundness holds for every frozen v, while the target gap loses exactly N||v-b||^2. See calibration_and_static_example.md for confidence allocation. Finite axis randomness, coin rounding, threshold accuracy and arithmetic are charged in finite_randomness_and_costs.md.

The upper is sound for arbitrary identical fully separable inputs on independent fresh copies. Conditional/adversarial soundness additionally covers a global null separable across physical laboratories with arbitrary within-laboratory correlations, or conditional full separability of each round. Unconditional separability of each copy marginal alone is not the correlated-null model. Target preparations remain independent for power.

At the saturated scale, charge m global preparations, mN=Theta(N^3/r^2) prepared qubit instances and mr=Theta(N^2/r) local readouts. With deterministic variable budgets r_i, the lower proves sum r_i^2=Omega(N^2), hence total actual exposures Omega(N^2/r_max). A common cap by itself is not an actual readout lower bound for a protocol that does not use that cap. Unbounded stopping/expected-budget versions remain unproved.

Trusted null Casimir changes the problem: a separable state with <J^2>=3N/4 has |b|<=1/sqrt(N), whereas the polarized target exceeds it. Promise-aware one-body inference can cost O(N) preparations. The centered product null violates that trusted constraint, so the quadratic black-box theorem must not be applied there. Acquiring global constraints experimentally is charged separately.

## Static concrete example and finite diagnostics

The explicit state rho_N^down=direct_sum_M w_NM |j,-j><j,-j| tensor I_mult/d_mult has <J^2>=3N/4 and sqrt(N)|b| tending to sqrt(8/pi). The limit is proved directly from Rademacher CLT and uniform fourth-moment tails in calibration_and_static_example.md. This example removes dependence on archived bath-time asymptotics for existence of a legal polarized sequence. Its mathematical definition does not imply cheap or robust laboratory preparation.

Exact centered-purity diagnostics cover 25 matrix/rational small cases and five exact rational cases through N1024,r8. The selected r=1 value is exactly zero. local_heat_diagnostics.py checks eight finite binomial moment/Taylor fixtures through r16384, five selected exact-Schur measurement laws through N2048,r16, direct hypergeometric reconstruction, and quadrature doubling. Its 161 signed-axis product arrays per case are a restricted comparator family, not a finite ALLSEP certificate. At N1024,r8, the target heat expectation is .8144729054 and the best tested restricted array .8139900645, agreeing with the predicted gap to the stated finite precision.

qudit_normalization_check.py constructs the qutrit (2,1,1) sector from a determinant singlet and coherent residual fundamental state. Eight complex/singular Schur trace tests agree within 5e-15; the weighted Gram Parseval gives Petz chi-square 2/3. This N4,r2 fixture lies outside the theorem's finite range and checks normalization only. It does not test all arbitrary qudit states or validate an all-size theorem.

Preserved failure: exact_centered_purity.py first hit Python's decimal display limit for trusted exact fractions. Raising the bounded display limit and rerunning repaired the output issue; the arithmetic and pass criteria were unchanged. No finite output is a formal proof replay.

## Primary comparators and priority limits

[Moharramipour et al.](https://arxiv.org/pdf/2406.08542), Theorem III.2 p8, already gives local trace hiding for MMIS, including O(k/N) for semisimple Lie groups. Its introductory result and appendix frame fixed k; its conclusion asks for sampling-complexity analysis. Our class permits arbitrary spin-sector states and uniform tails, compares to the fixed matched product, and gives an ALLSEP fresh-copy lower with a sound qubit upper. Hiding itself is not a novelty claim.

[Johnson, Gavalakis and Kontoyiannis](https://arxiv.org/html/2404.06632v1), Eq(6) and Corollary1.4, records the Stam classical quadratic KL bound for sampling without replacement and finite de Finetti. The exponent is therefore established classically. [Singh and Cerf](https://arxiv.org/html/2604.09410v1), Lemma3 Eq(54), transports that bound for diagonal energy-shell mixtures under energy-preserving-unitary invariance. Neither displayed premise directly covers arbitrary coherent U(d) sector states with the present K-tail interface.

[Ye, Bergh and Datta](https://arxiv.org/pdf/2609.40343), 30Sep2026, Theorem1 pp3-4, gives general PI-state operator domination by an iid mixture with epsilon<=d^2 k/n. It yields O(k/n) max-relative entropy to a mixture. It does not directly imply the quadratic Petz/KL bound to rho_1^tensor r, but is an essential recent comparator; only its theorem and remarks were read here, not its full proof.

[Toth et al.](https://arxiv.org/pdf/quant-ph/0702219), Eq(2b), gives the established collective spin-variance inequality used by the two-site tangent witness and credits Toth PRA69,052327(2004). The spin criterion is not newly claimed. The possible source-scope advance is the uniform growing-access entropy/certification interface and its tail-controlled coherent-sector extension. Historical novelty needs a dedicated broader primary-source review and remains UNKNOWN.

## Unclosed gates

The intrinsic critical bath threshold and the finite-fraction local entropy bound r<=N/2 remain open. No robustness to symmetry-breaking preparation noise or imperfect tails is established. Universal witness constants are unusably large; obtaining a practical finite-N threshold is separate work. A matched d-qudit upper, external specialist validation and formal proof replay are not completed. The independent fresh qudit/spin-tail/upper audit results are owned by the coordinator and were not awaited or silently assumed here.
