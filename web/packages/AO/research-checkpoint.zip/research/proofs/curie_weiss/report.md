# Critical isotropic Curie–Weiss local window

The beta=2 application closes the requested window and both sides of its trace/KL crossover. The result is an internally reconstructed proof candidate. No external validation, formal verification, entanglement conclusion or historical priority is claimed.

For rho_N proportional to exp(2J^2/N), the centered reference is exactly white, since rho_1=I/2. The exact Schur law has M=2j of order N^(3/4), but the consequential local threshold is r of order sqrt(N): all three quantities Petz chi-square, KL and trace distance vanish **if and only if r=o(sqrt(N))**. For r>=2 in that window, with mu_2=sqrt(12)Gamma(5/4)/Gamma(3/4),

    chi_P = [mu_2^2 r(r-1)/(6N)](1+o(1)),
    half trace = Theta(r/sqrt(N)),
    KL = Theta(r^2/N).

For liminf r/sqrt(N)>0, trace and KL stay bounded away from zero. For r/sqrt(N)->infinity, the full trace norm tends to two and KL=Theta(r/sqrt(N)), including r=N. At finite bounded r/sqrt(N), KL stays bounded. No exact finite-a crossover distribution is claimed or needed for this sharp-window result.

The proof has three independent load-bearing pieces. First, exact multiplicities and Stirling give a uniform quartic envelope and M/N^(3/4) converges, with all fixed moments, to density proportional to x^2 exp(-x^4/12). Second, the unchanged general concentration support argument with variance proxy N^(3/2) bounds every local support order; absent odd orders make the exact two-body Petz term leading. Third, bounded heat and magnetization-threshold effects supply trace/KL lower bounds. The Petz lower alone is not used to infer these operational conclusions. Hypergeometric sampling accounts for the same-copy r-site pooling explicitly.

The proof is frozen in CRITICAL_PROOF_FROZEN.md, SHA256 55a256b8a7d90573bed614c844a3bbb3734cb4c0886a82716afe18b281467b07 at 12:03 UTC. It exposes the finite envelope and a deliberately conservative explicit finite-r upper. The previous general concentration and heat proofs are unchanged, and this proof was frozen before any independent critical-model derivation was read. Shared parent/integration suggestions are attributed in its opening paragraph.

The executable exact local-spin calculation passed 34 cases for N=64,256,1024,4096,16384; maximum normalization error was 2.353e-11. It uses the Clebsch–Gordan partial trace identity given in exact_marginals.json, not a Monte Carlo approximation. At N=16384,r=2, chi divided by its asymptotic leading term was 0.97846. At r=128=sqrt(N), half trace=0.29243 and KL=0.35100; at r=512=4sqrt(N), half trace=0.64978 and KL=2.88525. Degree-two purity, r=1 white marginal, Pinsker, Jensen and entropy upper checks passed. This is finite double-precision evidence, not a proof replay.

The measurement effects expose r one-site spins and pool their outcomes from one preparation. Each observation consumes one supplied N-qubit Gibbs preparation. Exact Gibbs preparation, unknown temperature/model acquisition, systematic error and acquisition of the assumptions are separate unsolved costs. White-noise discrimination is not sound entanglement certification against all separable states. All claims concern the exact beta=2 model; no mean-only Casimir transfer is asserted.

No outside priority search was performed during this tightly bounded application. The source is the parent-supplied exact model and the unchanged internally derived concentration/heat lemmas. Source repository commit 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce remains clean. The next decisive gate is adversarial independent reconstruction of the frozen finite-envelope and bounded-witness argument, followed by specialist validation and a primary-source priority comparison. There is no missing internal lemma presently identified.
