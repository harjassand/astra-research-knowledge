# Stronger, attributed proof: slow variation is unnecessary

This file was written after `derivation.md` was frozen and after inspecting the original Li-Wang paper. It is a direct adaptation of published machinery, not a claim of a new proof mechanism. The original blind cone-shell argument remains in its separate file.

## Strengthened scope

Let the smooth connected complete boundaryless 3-manifold have one entire exterior

\[
g=dr^2+f(r)^2H(\log r),\qquad f(r)/r\to a>0.
\]

Assume the angular metrics lie in a (C^\infty)-compact set (mathcal K) of positive definite smooth metrics on the fixed (S^2), each of total area (4\pi). No common pointwise area form and no estimate on (partial_tH) is required. The originally supplied hypotheses imply these stronger-proof hypotheses: fixed positive pointwise area plus precompactness prevents degenerate limits.

With the pointwise polynomial-growth definition from `derivation.md`,

\[
\limsup_{k\to\infty} h_k/k^2\leq9a^2/4.
\]

The family may vary arbitrarily quickly in (t), provided the resulting metric is smooth. No radial derivative estimate on (f) occurs.

## Published boundary trace lemma

For a smooth compact domain (Omega), a finite-dimensional space of harmonic functions containing no nonzero constant, and its Dirichlet inner product (D(u,v)=\int_\Omega\langle\nabla u,\nabla v\rangle), Li-Wang Lemma 1 states

\[
\sum_{i=1}^N\int_{\partial\Omega}|\nabla v_i|^2dA
\geq2\sum_{j=0}^{N-1}\sqrt{\sigma_j}
\tag{LW}
\]

for every (D)-orthonormal basis, where (sigma_j) are the boundary Laplacian eigenvalues including zero. Their proof chooses the basis so (v_i|_{\partial\Omega}) is orthogonal to the first (i-1) boundary eigenfunctions. Rayleigh then bounds (sigma_{i-1}\int v_i^2) by tangential energy. Green's identity gives (1=\int v_i\partial_\nu v_i); multiplying by (2\sqrt{\sigma_{i-1}}) and applying (2xy\leq x^2+y^2) proves the summand inequality. Summing proves (LW). The zero eigenvalue poses no division by zero.

## Application to the radial slices

Fix (p) inside (Omega_{r_0}), and let (V\subset\{u\in\mathcal H_k:u(p)=0\}) have arbitrary finite dimension (N). For all sufficiently large (R), the Dirichlet Gram matrix on a fixed basis (u_i) is

\[
D_{ij}(R)=\int_{\Omega_R}\langle\nabla u_i,\nabla u_j\rangle_gdV_g.
\]

It is positive definite: zero energy makes a combination constant on the compact domain, its value at (p) makes that constant zero, and smooth elliptic unique continuation extends zero to (M).

Because (|\nabla r|=1), domain differentiation gives

\[
D'_{ij}(R)=\int_{S_R}\langle\nabla u_i,\nabla u_j\rangle_gdA_R.
\]

Thus (partial_R\log\det D_R=\operatorname{tr}(D_R^{-1}D'_R)) is the left side of (LW), using any (D_R)-orthonormal basis of (V). The eigenvalues of (S_R) are exactly

\[
\sigma_j(R)=f(R)^{-2}\lambda_j(H(\log R)).
\]

It follows that

\[
\frac{d}{dR}\log\det D_R
\geq\frac{2}{f(R)}\sum_{j=0}^{N-1}\sqrt{\lambda_j(H(\log R))}.
\tag{12}
\]

This identity differentiates only the integration domain of a fixed energy integrand. There is no differentiated angular volume form and no use of (partial_tH).

Let

\[
A_N=\inf_{h\in\mathcal K}\sum_{j=0}^{N-1}\sqrt{\lambda_j(h)}.
\]

Ordinary Weyl law plus a finite metric net and min-max comparison gives uniformly (lambda_j(h)=j(1+o(1))), hence

\[
A_N=(2/3+o(1))N^{3/2}.
\tag{13}
\]

If angular volume forms differ, close metrics compare both Dirichlet numerators and (L^2) denominators multiplicatively. Their common total area still supplies the same leading Weyl coefficient. Integrating (12), using (f(R)/R\to a), gives for fixed (N)

\[
\liminf_{R\to\infty}\frac{\log\det D_R}{\log R}\geq\frac{2A_N}{a}.
\tag{14}
\]

## Growth bound with Caccioppoli

The exterior volume element is (f(r)^2dr\,dA_{H(\log r)}). Its angular integral is (4\pi f(r)^2dr), so (operatorname{Vol}(\Omega_R)=O(R^3)). Polynomial growth and the elementary distance bound (d(p,(R,\theta))\leq R+C) give (int_{\Omega_{2R}}u_i^2dV=O(R^{2k+3})).

Choose a radial cutoff (chi_R), equal to 1 on (Omega_R), zero outside (Omega_{2R}), and with (|\nabla\chi_R|\leq C/R). Testing (Delta u_i=0) against (chi_R^2u_i) gives

\[
\int_{\Omega_R}|\nabla u_i|^2dV
\leq4\int_Mu_i^2|\nabla\chi_R|^2dV
=O(R^{2k+1}).
\]

Hadamard's inequality therefore implies

\[
\log\det D_R\leq(2k+1)N\log R+O_V(1).
\]

Compare with (14) to obtain the explicit necessary inequality

\[
\boxed{(k+\tfrac12)N\geq A_N/a}
\tag{15}
\]

for every finite-dimensional (V) in the anchored space. Equation (13) first proves finiteness and then

\[
k+\tfrac12\geq(2/(3a)+o(1))\sqrt{h_k-1},
\]

which proves the claimed limsup. This proof also tolerates a compact interior of arbitrary topology.

## Prior-art judgment

The exact end formulation was not located verbatim in the bounded search. However, the upper bound is an immediate derived corollary of a published lemma and determinant method, together with standard Weyl and Caccioppoli estimates. The stronger removal of slow variation does not require a new analytic technique. It should be presented as an application of Li-Wang rather than as a consequential research advance.

Li-Wang's printed Corollary 3 is about divergence-form operators on (mathbb R^n), gives an integrated dimension bound and a sharp **liminf** estimate with an ellipticity ratio. It is not literally the present coefficient (9a^2/4) under the stated end hypotheses. The exact constant here comes from retaining the actual angular spectrum in their Lemma 1, rather than replacing it by an ellipticity-ratio comparison with the round sphere. These distinctions do not support a strong novelty claim: the derivation above is short and follows their proof.

## Source provenance

P. Li and J. Wang, *Counting dimensions of L-harmonic functions*, Ann. Math. **152** (2000), 645-658, <https://arxiv.org/pdf/math/0009254>. Original full text inspected: Lemma 1, pp. 649-650; determinant identity and integration, p. 652; Corollary 3, p. 657. Local SHA256: `88cab270c937eda8314044cca105b54d25610ce578280f1647e7266ee865cd2c`. This attribution applies to (LW) and the determinant method, not to a claim that the source prints this precise end statement. Weyl and unique continuation sources are recorded in `derivation.md`.

Status: source-read and analytically reconstructed. Formal replay, independent expert validation, and exhaustive priority coverage: UNKNOWN. This is an upper bound for a structured end class, not a resolution of the unrestricted nonunique-tangent-cone problem.
