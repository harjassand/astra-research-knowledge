# Blind derivation: an upper bound from boundary energy

Assigned 2026-10-08 10:02 UTC. This derivation uses the supplied target and standard spectral/elliptic facts. It does not use any other worker's derivation or any N175 argument. Status: independently reconstructed analytic proof; no formal replay or external validation; novelty UNKNOWN.

## Exact statement

Let (M) be a smooth, connected, complete, boundaryless Riemannian 3-manifold. Assume that for some compact domain its entire exterior is diffeomorphic to ((r_0,\infty)\times S^2), and in these coordinates

\[
g=dr^2+f(r)^2H(\log r),\qquad f(r)>0,\quad f(r)/r\longrightarrow a>0.
\]

Assume that (H(t)) is a jointly smooth family whose range is precompact in the (C^\infty) topology of tensors on the fixed (S^2); all these metrics have exactly the same positive area form (mu), with (mu(S^2)=4\pi); and, in a fixed smooth background norm,

\[
\|\partial_tH(t)\|_{C^0}\longrightarrow0\quad(t\longrightarrow\infty).
\]

For a fixed point (p\in M) and real (k\geq0), set

\[
\mathcal H_k(M)=\{u\in C^\infty(M;\mathbb R):\Delta_gu=0,\ 
|u(x)|\leq C_u(1+d_g(p,x))^k\text{ for every }x\in M\},
\qquad h_k=\dim_{\mathbb R}\mathcal H_k(M).
\]

Then each (h_k) is finite and

\[
\boxed{\limsup_{k\to\infty}\frac{h_k}{k^2}\leq\frac{9a^2}{4}.}
\]

No Ricci hypothesis, no limit of (H(t)), and no bound on (f') or higher radial derivatives is needed.

## 1. Compactness and uniform angular Weyl asymptotics

Write (mathcal K) for the (C^\infty) closure of the range of (H). This is a compact set of **positive definite** smooth metrics, not just possibly degenerate tensors. Indeed, precompactness gives a uniform upper bound on the eigenvalues relative to any fixed background metric, while the fixed positive area form fixes their product and bounds that product away from zero. Thus their smaller eigenvalue is uniformly positive. Every metric in the closure still has area form (mu).

For (h\in\mathcal K), list the spectrum with multiplicities as

\[
0=\lambda_0(h)<\lambda_1(h)\leq\lambda_2(h)\leq\cdots
\]

and define

\[
\gamma_j(h)=\frac{\sqrt{1+4\lambda_j(h)/a^2}-1}{2},
\qquad S_N(h)=\sum_{j=0}^{N-1}\gamma_j(h),
\qquad S_N^*=\inf_{h\in\mathcal K}S_N(h).
\]

The ordinary Weyl law on each smooth closed surface of area (4\pi) gives (lambda_j(h)/j\to1). Its leading asymptotic is uniform over (mathcal K), as follows without assuming a uniform remainder theorem. If (h') is sufficiently (C^0)-close to (h), their inverse tensors and hence their Dirichlet energies satisfy

\[
(1-\varepsilon)\int|\nabla_hv|^2d\mu
\leq\int|\nabla_{h'}v|^2d\mu
\leq(1+\varepsilon)\int|\nabla_hv|^2d\mu.
\]

The denominator (int v^2d\mu) is identical. The min-max principle gives the same comparisons for all eigenvalues, simultaneously. Cover (mathcal K) by finitely many such neighborhoods, apply the ordinary Weyl law to their finitely many center metrics, and let (arepsilon\to0). Consequently

\[
\lambda_j(h)=j(1+o(1)),\qquad
\gamma_j(h)=a^{-1}\sqrt j(1+o(1))
\]

uniformly in (h\in\mathcal K) as (j\to\infty). Summation gives

\[
S_N^*\ =\ \left(\frac{2}{3a}+o(1)\right)N^{3/2}.
\tag{1}
\]

The zero mode and finitely many initial terms do not affect this asymptotic.

## 2. An exact cone-shell computation

Fix (0<\eta<1) and (h\in\mathcal K). For prescribed outer boundary value (v), minimize

\[
Q_{\eta,h}(w)=\int_\eta^1\int_{S^2}
\left(a^2\rho^2|\partial_\rho w|^2+|\nabla_hw|^2\right)d\mu\,d\rho
\]

over (H^1) functions with (w(1,\cdot)=v), leaving the inner boundary free. Denote the minimum by (Q_{\eta,h}^{\min}(v)). The natural inner condition is Neumann: (w_\rho(\eta,\cdot)=0).

In an (L^2(\mu))-normalized angular eigenmode with eigenvalue (lambda=a^2\gamma(\gamma+1)), the minimizing radial function is

\[
w_\gamma(\rho)=\frac{\rho^\gamma+c\rho^{-\gamma-1}}{1+c},
\qquad c=\frac{\gamma}{\gamma+1}\eta^{2\gamma+1}.
\]

For (gamma=0) this is the constant function. It solves

\[
(\rho^2w')'-\gamma(\gamma+1)w=0,
\quad w(1)=1,\quad w'(\eta)=0.
\]

Integration by parts evaluates its minimum energy as (a^2w'_\gamma(1)). Put

\[
b_\eta(\gamma)=w'_\gamma(1)
=\frac{\gamma(1-\eta^{2\gamma+1})}
{1+\frac{\gamma}{\gamma+1}\eta^{2\gamma+1}}.
\]

Since (0\leq\eta^{2\gamma+1}\leq\eta),

\[
b_\eta(\gamma)\geq c_\eta\gamma,
\qquad c_\eta=\frac{1-\eta}{1+\eta}.
\tag{2}
\]

If (Gamma_h) is the angular self-adjoint operator with eigenvalues (gamma_j(h)), separation in the angular eigenbasis gives

\[
a^{-2}Q_{\eta,h}^{\min}(v)
\geq c_\eta\langle v,\Gamma_hv\rangle_{L^2(\mu)}.
\tag{3}
\]

This follows first for finite eigenfunction combinations and then by density. We use it only for smooth boundary data.

## 3. Comparison with the actual shell, with no (f') estimate

Let (Omega_R) be the compact domain obtained by deleting the end (r>R). Its only boundary is (S_R=\{r=R\}), the outward unit normal is (partial_r), and its boundary area form is (f(R)^2\mu).

For any smooth global harmonic function (u), Green's identity gives

\[
q_R(u):=\langle u(R,\cdot),R\partial_ru(R,\cdot)\rangle_\mu
=\frac{R}{f(R)^2}\int_{\Omega_R}|\nabla_gu|^2dV_g.
\tag{4}
\]

The volume form on the end is (f(r)^2dr\,d\mu). Therefore the energy on the shell (\eta R\leq r\leq R), after setting (r=R\rho) and (w(\rho,\theta)=u(R\rho,\theta)), is exactly

\[
\frac{E_{\mathrm{shell}}(u)}{R}
=\int_\eta^1\int_{S^2}
\left(\left(\frac{f(R\rho)}{R}\right)^2|w_\rho|^2
+|\nabla_{H(\log R+\log\rho)}w|^2\right)d\mu\,d\rho.
\tag{5}
\]

For fixed (eta), the first coefficient converges uniformly on this interval to (a^2\rho^2). Also, with (t=\log R) and (L=-\log\eta),

\[
\sup_{s\in[-L,0]}\|H(t+s)-H(t)\|_{C^0}
\leq L\sup_{\tau\geq t-L}\|H'(\tau)\|_{C^0}\longrightarrow0.
\]

Uniform positivity from Step 1 converts this into uniform multiplicative comparison of inverse angular tensors. Thus the functional in (5) is bounded below by ((1-o_R(1))Q_{\eta,H(\log R)}(w)), where the error is independent of (w). The actual shell restriction is one admissible function in the free-inner-boundary minimization. Dropping the nonnegative energy in (Omega_{\eta R}), using (R^2/f(R)^2\to a^{-2}), and then applying (3), yields

\[
q_R(u)\geq(1-o_R(1))c_\eta
\langle u(R,\cdot),\Gamma_{H(\log R)}u(R,\cdot)\rangle_\mu.
\tag{6}
\]

Every step uses coefficient values and energy, never (f'), (f''), or radial curvature.

## 4. Gram determinant and compressed trace

Take any (N) linearly independent functions (u_1,\ldots,u_N\in\mathcal H_k(M)). We do **not** assume in advance that (mathcal H_k(M)) is finite dimensional. For every sufficiently large (R), their restrictions to (S_R) are independent. Indeed, if a linear combination has zero boundary value, the maximum principle (or its integrated energy version) makes it zero on (Omega_R). Unique continuation for the smooth elliptic Laplace-Beltrami equation on the connected manifold makes it identically zero.

Let (t=\log R) and define the positive definite Gram matrix

\[
G_{ij}(t)=\int_{S^2}u_i(e^t,\theta)u_j(e^t,\theta)d\mu.
\]

Because (mu) is independent of (t), differentiating introduces only the derivatives of (u_i). The polarized Green identity from (4) shows that

\[
B_{ij}(t)=\langle u_i(R),R\partial_ru_j(R)\rangle_\mu
=\frac{R}{f(R)^2}\int_{\Omega_R}\langle\nabla u_i,\nabla u_j\rangle_gdV_g
\]

is symmetric and (G'(t)=2B(t)). Hence

\[
\frac12\frac{d}{dt}\log\det G(t)
=\operatorname{tr}(G^{-1}B)
=\sum_{i=1}^Nq_R(\phi_i),
\tag{7}
\]

where (phi_i) are any harmonic linear combinations whose restrictions form an orthonormal basis of the restriction space at this particular (R). No derivative of the orthonormalizing coefficients is taken in (7).

For any (N) orthonormal smooth functions (v_i\in L^2(\mu)), expansion in an angular eigenbasis gives the elementary trace inequality

\[
\sum_{i=1}^N\langle v_i,\Gamma_hv_i\rangle\geq S_N(h).
\tag{8}
\]

For completeness, the left side is (sum_j\gamma_j a_j), where (a_j=\sum_i|\langle v_i,e_j\rangle|^2\in[0,1]) and (sum_ja_j=N). The minimum is obtained by filling the first (N) entries. Applying (6)-(8), for every fixed (eta) and every (delta>0), there exists (t_0) such that for all (t\geq t_0)

\[
\frac12\frac{d}{dt}\log\det G(t)
\geq(1-\delta)c_\eta S_N^*.
\tag{9}
\]

## 5. Growth closes the estimate

There is a constant (C) independent of (R,\theta) with (d_g(p,(R,\theta))\leq R+C): connect (p) to the fixed compact slice and then follow the radial line. Therefore each diagonal Gram entry is at most (C_iR^{2k}). Hadamard's inequality gives

\[
\log\det G(t)\leq2kNt+C_{u_1,\ldots,u_N}.
\tag{10}
\]

Integrate (9) from (t_0) to (T), compare with (10), divide by (2T), and let (T\to\infty). This proves

\[
kN\geq(1-\delta)c_\eta S_N^*.
\]

First let (delta\downarrow0) and then (eta\downarrow0). The starting radius may depend on these parameters, but it has already disappeared after the limit (T\to\infty). We have proved the more precise finite-dimensional necessary inequality

\[
\boxed{kN\geq\inf_{h\in\mathcal K}\sum_{j=0}^{N-1}
\frac{\sqrt{1+4\lambda_j(h)/a^2}-1}{2}}
\quad\text{for every (N)-dimensional subspace of (mathcal H_k(M)).}
\tag{11}
\]

By (1), its right side divided by (N) diverges like (2\sqrt N/(3a)). Thus arbitrary finite-dimensional subspaces cannot have unbounded dimension: (h_k<\infty). If (h_k\to\infty) along a sequence, substitute (N=h_k) into (11) and (1) to obtain

\[
k\geq\left(\frac{2}{3a}+o(1)\right)\sqrt{h_k}.
\]

If (h_k) stays bounded along a sequence, the ratio (h_k/k^2) tends to zero there. These two cases give the claimed limsup.

## Assumption audit and limits of the conclusion

- The manifold is understood to have no boundary. A boundary requires specified conditions and an extra boundary term in (4); arbitrary unspecified boundary data would destroy the conclusion.
- The asserted exterior must be the entire exterior, hence one end. Extra ends contribute boundary traces and can change the leading coefficient.
- The coordinates identify one fixed (S^2) across radii. Precompactness only modulo arbitrary diffeomorphisms does not supply the pointwise shell comparison used here.
- Smoothness of (g) supplies Green's formula, smooth harmonic functions and local unique continuation. The displayed representation is assumed jointly smooth, with positive (f).
- The fixed area form is used exactly, not merely its fixed total area: it makes (5) and the identity (G'=2B) free of moving-density terms. There may be extensions allowing a slowly moving density, but no such extension is needed for this target.
- The condition (H_t\to0) can be weakened to fixed-log-annulus oscillation tending to zero: for every (L<\infty), (sup_{s\in[-L,0]}\|H(t+s)-H(t)\|_{C^0}\to0). No estimate on higher (t)-derivatives is used.
- No rate of (f(r)/r\to a) is needed, and even (rf'(r)/f(r)) need not converge or remain bounded.
- The constant (9/4) comes from the average of the first (N) growth exponents. It is not claimed optimal. On an exact cone the sharper leading coefficient is (a^2).
- This proves a structured subclass statement. It does not settle the general dimension problem for arbitrary nonunique tangent cones, establish novelty, or prove a construction satisfying nonnegative Ricci curvature.

## Original sources actually inspected

1. L. Hörmander, *The spectral function of an elliptic operator*, Acta Math. **121** (1968), 193-218. Original PDF: <https://archive.ymsc.tsinghua.edu.cn/pacm_download/117/6063-11511_2006_Article_BF02391913.pdf>. Read pp. 193-196; visually inspected p. 194, Theorem 1.1. Its smooth elliptic, symmetric, positive setup applies to (P=-\Delta_h+1) on a smooth closed surface; integrating its spectral asymptotic gives the fixed-metric Weyl law. The uniformity across metrics above is our elementary compactness/min-max argument, not an unverified assertion about a uniform Hörmander remainder. Local PDF SHA256: `a633994ce0c78c888636ca4dd5b2c0eab010a98a49427e60b442ef7cb1b35822`.
2. N. Aronszajn, *A unique continuation theorem for solutions of elliptic partial differential equations or inequalities of second order*, J. Math. Pures Appl. **36** (1957), 235-249. Original scan: <https://sites.math.washington.edu/~blwilson/Nodal/Aronszajn.pdf>. Read pp. 235-237; visually inspected pp. 236-237. The theorem includes principal coefficients (C^{2,1}), positive definite, locally bounded lower-order coefficients, and applies on differentiable manifolds. Smooth Laplace-Beltrami coefficients meet these local assumptions. Local PDF SHA256: `6ce7701b9cb2b5f4c204f39b6fad7110b3690b09676342142a8005626e22af61`.

All other inequalities and shell formulas were derived here. No numerical test is presented as proof. Priority remains UNKNOWN.
