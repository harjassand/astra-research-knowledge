# Geometry blind audit

**Target status: TRUE, analytically reconstructed.** Under the standard interpretation that (M) is boundaryless and the displayed product is its entire exterior, the supplied premises prove finiteness of every (h_k) and

\[
\limsup_{k\to\infty}h_k/k^2\leq9a^2/4.
\]

Polynomial growth means global pointwise (|u(x)|\leq C_u(1+d(p,x))^k), with (u) smooth and harmonic, and real dimension. No Ricci premise is used. No bound on (f'), (f''), higher radial derivatives, or higher (t)-derivatives of (H) is needed.

The **blind proof**, frozen before examining related dimension literature, is in `derivation.md`. It uses boundary (L^2) Gram determinants, Green's identity, a frozen cone shell with free Neumann inner boundary, and angular Weyl asymptotics. The cone-shell eigenvalue is exactly

\[
b_\eta(\gamma)=\frac{\gamma(1-\eta^{2\gamma+1})}
{1+\frac{\gamma}{\gamma+1}\eta^{2\gamma+1}}
\geq\frac{1-\eta}{1+\eta}\gamma.
\]

This controls the compressed boundary trace. Summing the first (N) cone exponents yields (2N^{3/2}/(3a)), while degree (k) permits only (kN); these imply the coefficient (9/4).

The **stronger attributed proof** is in `li_wang_derivation.md`. Li-Wang's published boundary trace lemma plus their determinant method and Caccioppoli give

\[
(k+\tfrac12)N\geq a^{-1}\inf_{h\in\mathcal K}
\sum_{j=0}^{N-1}\sqrt{\lambda_j(h)}
\]

for every (N)-dimensional subspace of harmonic functions vanishing at one basepoint. Uniform angular Weyl law yields the same limit. This proof requires only a compact positive definite family of angular metrics of total area (4\pi); it requires neither (H_t\to0) nor a common pointwise area form. The original common form and precompactness guarantee such a positive compact closure.

**Prior-art and significance verdict: LOW standalone research value.** The exact end theorem was not located verbatim, but it is an immediate derived corollary of established Li-Wang machinery and standard spectral/energy estimates. It must be described as an application of their method. The printed Li-Wang Corollary 3 is not literally this end statement; it supplies a different ellipticity-ratio liminf bound. This difference is insufficient to support a consequential novelty claim. The coefficient (9/4) is not proved sharp here.

**Missing assumptions:** no additional analytic decay or smoothness hypotheses are needed beyond the supplied smooth metric, interpreted joint smooth representation, and ordinary boundaryless one-end meaning. For the blind proof alone, fixed pointwise area and fixed-log-annulus oscillation are essential to its particular comparison; the stronger proof shows they are dispensable for the result. If a boundary were allowed without a condition, the Euclidean exterior of a ball would have infinitely many bounded harmonic functions (r^{-\ell-1}Y_{\ell m}); that is outside the standard boundaryless statement.

**Sources actually read:** original Hörmander pp.193-196, Theorem1.1 p.194 (Weyl), original Aronszajn pp.235-237 (smooth elliptic unique continuation), and original Li-Wang pp.646-650,652,656-658 (prior method and exact scope). PDFs, extracted text, selected rendered pages, URLs, and hashes are in `sources/` and `source_manifest.json`. No other worker's argument was read before proof freeze. After freeze, the stronger proof was shared with independent/integration at the coordinator's request. Agreement is not treated as theorem certification.

**Next decisive action:** verify `li_wang_derivation.md` equations (12)-(15), then move the research allocation to a statement not immediately implied by this published method. Exact sharp limsup, constructions attaining it, arbitrary nonunique tangent cones, and Ricci-compatible constructions remain UNKNOWN in this report.

No experiments, external validation, formal replay, publication, or outbound expert messages were performed. Acquisition cost: three freely retrieved original PDFs, bounded primary-source searches, and local text extraction/rendering. Deadline compliance: first report and full proof completed within the 25-minute assignment window.
