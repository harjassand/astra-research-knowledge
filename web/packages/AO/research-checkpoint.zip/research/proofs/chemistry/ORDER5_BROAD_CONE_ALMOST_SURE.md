# Almost-sure explosion on the broader open cone

Status: internally reconstructed strengthening, written after the
positive-probability cone was frozen and after reading the blind worker's
separate almost-sure argument. This proof has not yet had its own independent
audit. The original proof/status history is preserved in the frozen files.

Keep the five jumps and exact coefficient mapping

| Label | Jump | Intensity |
|---|---|---|
| I | `(2,0)` | `k0` |
| U | `(1,1)` | `k1(a)_2` |
| V | `(0,1)` | `k2(a)_3 b` |
| D0 | `(0,-2)` | `k3(a)_3(b)_2` |
| D1 | `(-1,-2)` | `k4(a)_3(b)_2` |

Every coefficient is fixed and strictly positive. Put `d=k3+k4`.

**Theorem.** If `d>3k2` and `2k4<d`, then the minimal CTMC explodes almost
surely from every finite initial state.

The stopped positive-drift episodes and finite physical explosion times in
`ORDER5_ROBUST_RATE_COROLLARY.md` are used here. That file was frozen before
the almost-sure proof below. Its sufficiently large finite boundary is
denoted `A_*>=3`. At any axis state `a>=A_*` it supplies a stopped episode
with success probability at least `1-exp[-theta(a-A_*+1)]` for a fixed
`theta>0`. Success gives finite-time explosion almost surely; failure ends
after finitely many full reactions at `a=A_*-1`.

## Global axis return requires only positive coefficients

In fact, for arbitrary positive `k0,...,k4`, starting at any finite state
with b>0 the embedded reaction chain hits b=0 after finitely many full
reactions almost surely. This statement does not assume regularity of the
CTMC and therefore also rules out an explosion before that return on any
set of positive probability.

If a=0 or 1, an input jump reaches a>=2. At a=2, the next reaction is I or
U, reaches a>=3, and increases b by at most one. Thus the initial activation
has at most two full reactions. After activation a cannot fall below two.

At an active state a>=3,b>0, define the same macro step as the blind worker:
ignore I reactions until a B-changing reaction; stop immediately if b=0;
otherwise, if a D1 reaction just reached a=2, include the next I or U
reaction to restore a>=3. Input-only runs are almost surely finite, since
at every active positive-B state their conditional probability is at most

`z=k0/(k0+6k2)<1`.

Let Y denote B at the consecutive active macro states, with zero absorbing.
Every macro birth has change +1. Every pair-death macro has change -2 or
-1, except a death from Y=2 which stops at zero before a reset. At every
possible active pre-reaction state the B-birth probability, conditional on
a B-changing reaction, is

`p_b(a)=[k2 b+k1/(a-2)]/[k2 b+k1/(a-2)+d b(b-1)]`.

Averaging over the finite input-only run preserves the bound

`p_b <= pbar_b=(k2 b+k1)/(k2 b+k1+d b(b-1))`.

Choose a finite integer M>=2 large enough that `pbar_b<=1/4` for b>M.
This is possible because pbar_b tends to zero. Until Y enters `[0,M]`,

`E[Delta Y | macro history] <= pbar_b-(1-pbar_b)<=-1/2`.

Stop this inequality at that hitting index and truncate at n macro steps.
The nonnegative stopped Y then gives expected truncated hitting index at
most `2Y_initial`. Monotone convergence implies finite expected hitting
index, hence almost-sure entry into `[0,M]`. This argument is uniform in A;
the macro chain need not be homogeneous or independent.

For any active state with 2<=b<=M, the probability that its next B-changing
reaction is the unmarked pair death D0 is at least

`e_b=k3 b(b-1)/(k2 b+k1+d b(b-1))>0`.

This bound also survives averaging over the input-only run. A D0 macro
decreases b by two, never needs an A reset, and preserves a. At b=1 the
next macro is necessarily a birth to b=2. Therefore from any active
1<=b<=M the prescribed word of unmarked pair deaths, with one intervening
birth if necessary to repair odd parity, hits zero in at most
`L=ceil(M/2)+1` macro steps. Its probability is uniformly at least
`alpha=(min_{2<=b<=M} e_b)^L>0`.

Run blocks of L macro steps from `[1,M]`, stopping sooner if zero is hit.
If a block fails, its B value is at most M+L because no macro increases it
by more than one. The drift argument returns it to `[0,M]` after finitely
many further macros almost surely. If it has not hit zero, another block
has conditional success probability at least alpha. The probability that
the first j blocks all fail is at most `(1-alpha)^j`; thus a successful
block occurs after finitely many blocks almost surely. Every block and
recovery uses finitely many macros, and every macro uses finitely many
full reactions almost surely. This proves global return to the axis in
finitely many reactions. Their finite-state holding times are finite
almost surely, proving the physical-time assertion too.

## Uniform explosion trials on the broader cone

At a recovered axis state a>=A_*, start the stopped episode immediately;
its success probability is at least `p_*=1-exp(-theta)>0`.

For an axis state 2<=a<A_*, prescribe input reactions until a>=A_*. This
requires a bounded finite number of jumps over a finite collection of axis
states. Each prescribed jump has probability
`k0/[k0+k1 a(a-1)]>0`, so their product has a uniform positive lower bound
beta independent of the particular initial a in this finite set. If any
U reaction occurs before completion, declare this trial failed and use the
global axis-return lemma. Once the input word is completed, start the
stopped episode. Such a trial succeeds with probability at least beta p_*.

An episode failure reaches a=A_*-1>=2 after finitely many reactions, and
the global lemma recovers the axis after finitely many further reactions.
Thus every trial has conditional success probability at least
`delta=min(1,beta)p_*>0`. Every failure and its recovery take finite physical
time almost surely. The CTMC cannot fall below a=2 after initial activation;
from a=0 or1, one I jump supplies that activation and the axis-return lemma
handles b>0.

Apply the strong Markov property at the finite failed-trial recovery times.
The probability that the first j trials all fail is at most
`(1-delta)^j`. Almost surely a successful episode therefore occurs after a
finite number of failures. The failed trials have taken finite time and the
successful episode explodes in finite time almost surely. This proves the
theorem. Trial independence is not asserted or needed.

## Provenance and scope

The higher-boundary positive-episode cone is our extension of the blind
original excursion proof. The macro-step reset and renewed-trial method
was learned from `work/agents/chem_order5_blind/almost_sure/report.md` at
11:07 UTC, after our positive cone was frozen. That read file's SHA256 was
`9fd15f4b749bc3fd29c5ce5a0d37cab45242e20a1346690b9eec70b622b929bf`.
The new global-return argument uses a drift outside a finite B set and a
uniform unmarked-death word inside it; unlike the fixed-tuple F contraction,
it works for arbitrary positive rate coefficients.

The sufficient cone `d>3k2, k3>k4` strictly contains the blind worker's
explicit open region: it permits arbitrary k0,k1>0, compensated by a higher
finite A boundary. No claim is made that this cone is the exact explosion
region. No claim is made about rates on its boundary, and no formal fast
limit is used. This strengthening needs an independent proof audit; the
already separately audited fixed tuple is not made dependent on it.
