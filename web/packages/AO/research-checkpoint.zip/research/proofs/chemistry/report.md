# Chemistry exploration checkpoint

Delivered 2026-10-08 10:19 UTC, within 25min of assignment. Status: internally reconstructed order-five explosive strongly-endotactic counterexample; independent mathematical audits pending. Historical priority UNKNOWN. No external validation or biological experiment.

The strongest result is a concrete order5 counterexample to stochastic nonexplosion under strong endotacticity. Current primary literature explicitly leaves the minimal molecular order open, with an order10 known example and order2 impossibility. Our exact model is

    0->2A; 2A->3A+B; 3A+B->3A+2B;
    3A+2B->3A; 3A+2B->2A,

with falling-factorial rate coefficients1,1,1,4,1. The full proof is ORDER5_FROZEN.md. Its three decisive interfaces are all-direction hull geometry, marked pair-death excursion drift, and physical-time summability. Exact geometry diagnostics accept every face (24 rational rays/open sectors). The proof includes slow reactions during excursions; no erroneous deletion of O(1/n) hazards occurs.

Value ranking: order5 construction first; preserved order6/7/8 versions are fallback advances and reusable proof mechanisms, not additional independent discoveries. If correct and historically new, the open interval becomes3<=minimum<=5. It does NOT settle the exact minimum, arbitrary weakly-reversible recurrence, every-initial-state explosion, or any physical chemistry model. Rates are fixed; no measurable arbitrary switching theorem is claimed.

The proof strategy begins at axis(n,0) and accepts a full return excursion after a prescribed R1. In an auxiliary chain clamp A>=floor(n/2). After erasing neutralB events, ceil(B/2) is dominated by a downward-biased nearest-neighbor walk with up probability<=1/4. Thus the total pair-death count D has an exponential tail and ED<=3/2. Only1/5 of pair-deaths decrease A, so mean axis gain is at least7/10. Accepted actual paths haveD<=n/2, making the clamp unused. Their probability is1-O(n^-2)-O(exp(-cn)). The normalized conditional axis chain has positive probability of linear escape; product acceptance weights retain positive probability. All holding rates grow at leastcn² and excursion event counts have uniform exponential moments, so total physical time is finite on that event.

Primary sources actually opened: Xu arXiv:2409.05340v2 full HTML, Definitions4.2–4.4, Theorem4.6 proof, Remark4.8; ACKN arXiv:1808.05328 PDF, Definition3.2 and Example3.2 at printedpp5–7 (PDFindices4–6), web lines327–334 and450–486. Xu's arXiv metadata reports9May2026, while the HTML manuscript reports24August2026; both retained. Targeted order5/6/7/8 and exact-complex searches found no equivalent published witness, but failed searches do not establish priority. Source_manifest.json records hashes and read depth.

N173 and original family149 affine proof were read. N173 assumes uniform logarithmic orders over all times, directions and kinetic paths plus strict all-face essential inwardness, and remains source-conditioned; no quick gap was found in its affine proof. It supplies no direct stochastic recurrence theorem. N76 controls upward factorial potential changes per reaction event, without negative recurrence drift or physical time. N77 is an intercomponent stationary-tightness obstruction, not an explosive-component theorem. The new result uses their warning about source availability and physical clocks but does not depend on their unverified claims.

Failure scopes are preserved in frozen derivations and geometry_results.json. Lowering the original final B stoichiometry without changing the diagram fails on nongeneric normals. The order7 chain0->2A->3A+B->4A+3B->3A fails at(2,-1). A direct order4 split version with source3A+B and B-only drain fails at(1,-1). These do not prove order3 or4 impossible. A finite four-source strict-chain enumeration through order10 found minimum8 only within that restricted geometry; splitting rates/drains escaped that restricted bound.

Next decisive action: audit ORDER5_FROZEN.md's accelerated-walk coupling, stopping/marking identity, auxiliary-to-actual path equality, and conditional clock transfer from scratch. Parent has requested independent audits. Then investigate order3/4 with the exact face obstruction explicit, and extend primary-source novelty checks under renamed species and alternative stochastic terminology. Do not promote a finite diagnostic or model agreement into external certification.

Resource charges: approximately25min wall time, local exact integer geometry on at most28 directions per model, bounded web/source downloads under1MiB before PDF, no cloud computation, no experiment or external messages, no repository edits. All work is under work/agents/chemistry/; the pinned repository was read-only.
