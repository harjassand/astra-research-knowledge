# Order-five explosive strongly endotactic stochastic mass-action system

Frozen version1, 2026-10-08 10:16 UTC. Internally reconstructed candidate; mathematical correctness and historical novelty require independent audit. This is a concrete counterexample and full argument, not a conditional transfer from OA149/N173. Earlier order8,7,6 derivations are preserved.

## Exact theorem

Consider five reactions on N_0^2 with population(a,b), fixed falling-factorial propensities, and rate tuple(k0,k1,k2,k3,k4)=(1,1,1,4,1):

| reaction | vector | propensity |
|---|---|---|
| R0: 0->2A | (2,0) | 1 |
| R1: 2A->3A+B | (1,1) | (a)_2 |
| R2: 3A+B->3A+2B | (0,1) | (a)_3 b |
| R3: 3A+2B->3A | (0,-2) | 4(a)_3(b)_2 |
| R4: 3A+2B->2A | (-1,-2) | (a)_3(b)_2 |

(z)_j is falling factorial, zero when disabled. Maximum reactant molecularity is FIVE. The graph is strongly endotactic. Its minimal CTMC explodes with positive probability from at least one sufficiently large axis state(n,0).

No weak reversibility is asserted; the graph is not weakly reversible. No physical implementation is asserted. The exact minimum order remains open. Coupled with Xu's order-two regularity theorem, this establishes a candidate interval 3<=minimum<=5, subject to independent correctness/priority audit.

## Geometry, all directions and faces

Source hull has counterclockwise vertices O=(0,0),P=(2,0),Q=(3,1),R=(3,2). Outward boundary normals, and projections of ALL arrows from their maximizing sources, are

    O-P (0,-1): R0=0, R1=-1;
    P-Q (1,-1): R1=0, R2=-1;
    Q-R (1,0):  R2=0, R3=0, R4=-1;
    R-O (-2,3): R3=-6, R4=-4, R0=-4.

All tied maximal arrows are nonpositive and at least one is strictly inward on every face. In each vertex's open normal cone, the arrow is nonpositive at the two bounding normals and strictly negative at at least one; every strictly positive linear combination is therefore inward. This proves strong endotacticity in all nonzero directions. At R the same statement applies separately to both outgoing arrows. R4, however small its positive rate, is necessary to supply strict inwardness at(1,0). Rates do not enter the unweighted graph property.

## Full excursions, including slower reactions

From axis(n,0), prescribe first R1; it moves to(n+1,1). Its event-choice probability is

    c_n=n(n-1)/(1+n(n-1))=1-O(n^-2).

At B>0 do NOT discard R1 or R0: they continue to operate. A full excursion ends when B first returns to zero. Let D be its number of pair-deaths (R3 or R4), D_A the number of R4 events, S the number of additional R1 events, I the number of R0 events, and F the number of R2 events. If the excursion is finite,

    1+F+S-2D=0,
    Delta A = 1+S+2I-D_A.

Every pair-death, conditional on occurring and its past, is marked R4 with EXACT probability epsilon=1/5, since R3 and R4 propensities share(a)_3(b)_2 with coefficients4 and1. Hence E D_A=(1/5)E D whenever the latter is finite; this identity uses predictable conditional marking and Tonelli, not independence between D and the marks.

## Auxiliary lower clamp and uniform excursion bounds

Fix large n. Analyze an auxiliary excursion process whose A coordinate is prevented from falling below m=floor(n/2). Replace an R4 decrement at A=m by a zero A decrement, retaining its B decrement and event identity. All other propensities and changes are identical. The auxiliary B process is absorbed when B=0.

Erase the R0 events, which leave B unchanged. For A=a>=m and B=b>=2, its up probability (R1 or R2) versus pair-death satisfies

    p_up(a,b) = [b+(a)_2/(a)_3]/[b+(a)_2/(a)_3+5b(b-1)]
              = [b+1/(a-2)]/[b+1/(a-2)+5b(b-1)]
              <= [1+1/(m-2)]/[6+1/(m-2)].

For sufficiently large m this is <=p_star=1/4. At B=1 no pair-death is enabled, so the next non-R0 event is a birth, with B becoming2.

Set V(b)=ceil(b/2), and erase zero V moves (births from odd b). A zero V move cannot occur twice consecutively. Every V update is +/-1, and conditional up probability is <=p_star: at even b this is the inequality above; at odd b>=3 an immediate pair-death is downward, while a zero birth can only be followed by an even-state update with up probability<=p_star. Starting B=1 gives V=1 and a forced zero move followed by the same bounded even update.

Couple this accelerated walk to a nearest-neighbor walk from1 with up probability1/4 and down probability3/4. The former's position is always <=the latter's under common uniform update draws, up to absorption. The latter has an exponentially tailed absorption-update count: with rho=sqrt3,

    E[rho^(Y_next-Y)] = sqrt3/2<1,
    P(H_Y>j)<=rho(sqrt3/2)^j.

Thus D and the number of non-R0 B events have uniform exponential tails, independently of n and all starting states admitted above. For the accelerated update count H and up count U, D-U=1 and H=2D-1. Conditional up probabilities give E U<=p_star E H; therefore

    E D <=(1-p_star)/(1-2p_star)=3/2.

At any B>0 auxiliary state, the chance the next reaction is R0 is bounded above by

    1/[1+(a)_3 b] <=1/[1+(m)_3],

which is <=1/2 for large n. The geometric runs of these neutral B events thus have uniform exponential moments. Combining this with the exponential B-event count gives a uniform exponential moment for the TOTAL excursion event count J. A direct conditional generating-function iteration justifies the combination; no independence of run lengths from the excursion skeleton is needed. In particular I,S,D_A,Delta and all required polynomial moments are uniformly bounded.

The auxiliary A increment from start(n,0), including the prescribed initial R1, is bounded below by1-D_A (clamping can only lessen a decrement). The exact marking identity gives

    E Delta_aux >=1-(1/5)E D >=7/10.

This is the positive drift absent from the unbranched low-order attempt. Additional slow R1 and R0 events increase A and have been fully included.

## Accepted actual macrocycles and quantitative survival cost

Accept an actual excursion if the initial reaction is R1, the excursion returns to B=0, and its total pair-death count D<=floor(n/2). On any accepted path A>=n+1-D>=m+1 throughout, so the auxiliary clamp is never used; actual and auxiliary event probabilities coincide exactly on these paths.

The auxiliary tail gives P(D>n/2)<=C e^{-c n}. Therefore the acceptance probability a_n satisfies

    a_n=c_n P_aux(D<=floor(n/2)),
    1-a_n<=C/n^2+C e^{-c n}.

The lost first moment is exponentially small by the uniform exponential J moment. Hence the conditional actual axis increment law K_n has

    E_{K_n} Delta >=7/10-o(1)>=d>0,
    sup_{n>=N} E_{K_n} exp(theta0 |Delta|)<infinity

for some fixed theta0>0. Note that conditioning on acceptance cancels the initial c_n factor; only truncation changes the auxiliary increment law. This avoids discarding the O(1/n) slower reaction hazards inside each excursion.

## Escape, path weighting and physical time

Let Z_j be the conditional axis chain with increment law K_n on n>=N, extended below N by deterministic+1 increments. Uniform positive mean and uniform exponential moments imply, for small theta>0,

    E[e^{-theta Delta}|n]<=1-theta d/2<1.

Stop at tau=first visit below N. The nonnegative stopped exponential process is a supermartingale; since Z_tau<=N-1,

    P(tau<infinity | Z0=z0)<=e^{-theta(z0-(N-1))}<1

for z0>N. Thus the event D_escape of staying above N has positive conditional-chain probability. Uniform second moments and the L2 martingale strong law give Z_j>=z0+d j+o(j) on D_escape, hence eventual linear growth.

Finite actual accepted path weights equal conditional-chain weights multiplied by product a_{Z_j}. On linearly escaping paths sum(1-a_{Z_j})<infinity, so this product is strictly positive. Dominated convergence then gives actual accepted escaping probability

    E_K[1_{D_escape} product_j a_{Z_j}]>0.

Throughout a macrocycle started at n, A>=m+1>=n/2, so total propensity q>=(a)_2>=c n^2. The event count J has a uniform exponential moment under K_n, and therefore a uniform finite mean. For every normalized path with eventual Z_j>=d j/2, the sum J_j/Z_j^2 is finite almost surely. To verify the last statement without assuming independence, fix each deterministic eventual-start index l and use

    sum_{j>=l} E[1_{Z_j>=d j/2} J_j/Z_j^2]<=C sum_{j>=l}j^-2<infinity;

then take the countable union over l. The actual accepted weighted law is absolutely continuous with density<=1, so the statement transfers to it.

Holding times at every state are independent exponentials with total rate q, independent of next-event choices. Conditional on almost every accepted escaping full event path, the sum of expected holding times is bounded by C sum_j J_j/Z_j^2<infinity. Its actual holding-time sum is therefore finite almost surely, although infinitely many events occur. Explosion has positive probability. This controls physical time explicitly, rather than only the embedded event count.

## Priority and scope

Primary current frontier actually opened: Xu arXiv:2409.05340v2, Definitions4.2–4.4, Theorem4.6 (order-two endotactic regularity), Remark4.8 (known order-ten explosive witness; minimum open). https://arxiv.org/html/2409.05340v2

Primary historical mechanism: Anderson–Cappelletti–Kim–Nguyen, SPA130(12),7218–7259(2020), Example3.2, order-ten boundary cycle. https://doi.org/10.1016/j.spa.2020.07.012

New mathematical interface: high-molecularity recurrence obstruction is achieved at order5 through a common fast A factor and independently marked pair-deaths; a small-rate inward arrow controls geometry, while a frequent B-only drain keeps expected A loss low. This direction was suggested by root and the full excursion proof derived here. Deterministic permanence is an established comparator, not an empirical chemistry claim. The strongest unresolved obligations are independent proof audit, primary-source priority search under renamed networks, and whether order3 or4 is possible. OA149, N173, N76 and N77 do not establish this result by themselves.
