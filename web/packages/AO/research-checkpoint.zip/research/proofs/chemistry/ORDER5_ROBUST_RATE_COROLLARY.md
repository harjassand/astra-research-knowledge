# An open cone of positive rates and every initial state

Status: internal extension of the independent direct excursion proof in
`work/agents/chem_order5_blind/report.md`, read only after our original
order-five proof was frozen. This does not replace that independently
reconstructed proof. It shows that the fixed integer tuple is not a singular
rate choice. No external review or priority conclusion is claimed.

Keep the exact order-five diagram from `ORDER5_FROZEN.md`, but give its five
reactions rates

`k0`, `k1(a)_2`, `k2(a)_3 b`, `k3(a)_3(b)_2`, `k4(a)_3(b)_2`,

respectively. All coefficients are fixed and strictly positive. Suppose

`s=(k3+k4)/k2>3` and `q=k4/(k3+k4)<1/2`.

**Claim.** Under these strict inequalities the minimal mass-action chain has
positive probability of finite-time explosion from every finite initial
state. The geometric strong-endotacticity statement is independent of the
rates. The concrete integer tuple `(1,1,1,4,1)` is inside this open cone.

Choose an integer `A_*>=3` sufficiently large that

`rho=k1/[k2(a-2)]<=r=min(1,2s/3-2)` whenever `a>=A_*`.

This is possible because `s>3`, so r is strictly positive. Stop a B excursion
upon reaching `b=0` or `a=A_*-1`. Conditional on a B-changing reaction its
birth probability is exactly

`p_b=(b+rho)/(b+rho+s b(b-1))`.

The pair-death marking probability is exactly q, also for the final reaction
of a stopped excursion. Use the same budget function as the blind proof:

`H(0)=0`, `H(b)=(3/2)ceil(b/2)+(1/2)1_{b=1}`.

At even `b>=2`, the unnormalized budget increment is

`(3/2)(b+rho)-(s/2)b(b-1)<=0`.

At `b=2` this follows from the definition of r. At even `b>=4` it follows
from `rho<=1` and `s>3`. At `b=1,3` and odd `b>=5`, the checks are exactly
the checks in the independent proof and do not depend on s. Consequently
the expected number D of pair deaths in an excursion starting from b=1 is
at most two. Summing pre-stopping reaction probabilities gives expected
marked A losses `E D1=q E D<=2q`. Thus each axis return cycle, including a
terminal ruined cycle, has expected A increment at least

`mu=1-2q>0`.

For a uniform complete-reaction tail, retain `F(0)=0`, `F(1)=5`,
`F(b)=2^b` for `b>=2`, killed when the A boundary is reached. The B-changing
contraction ratios are at most:

* `4/5` at b=1;
* `1/2` at b=2, since the H inequality gives `p_2<=1/4`;
* `7/8` at b=3, since `p_3<=4/(4+18)=2/11`;
* `15/32` at b>=4, since `p_b<=1/8`. The last inequality follows from
  `7(b+1)<=3b(b-1)` for every integer b>=4.

Hence a common contraction ratio is `7/8`. The B-neutral input reaction
has probability at most

`p_I=k0/[k0+k2(A_*)_3]<1`.

The complete reaction contraction ratio is therefore at most
`gamma=p_I+(1-p_I)(7/8)<1`. In particular, stopped excursion lengths have
uniform exponential tails. The positive-drift exponential-supermartingale
argument of the independent proof now applies at the boundary `A_*-1`,
with mu and gamma in place of its numerical constants. It gives positive
probability of no ruin from every axis population `a>=A_*`, linear growth
of cycle populations on survival, and logarithmic excursion lengths.

The axis total rate is at least `k1(a)_2`, and every post-initial excursion
state has rate at least `k2(a)_3 b`. Thus the same exact independent-clock
argument gives a finite sum of holding times on a positive-probability
survival event. This proves positive explosion from the sufficiently large
axis states without discarding any of the slower reactions.

**Reachability and the initial-state quantifier.** From any finite `(a,b)`,
take the input reaction a finite number of times until `a>=A_*`. Each step
has positive finite conditional probability. If b is even, take the
unmarked pair-death reaction repeatedly to reach b=0. If b is odd, first
reduce it to one using unmarked pair deaths, then take the B birth
`3A+B -> 3A+2B` once and an unmarked pair death once. These steps preserve A
and have strictly positive rates. The resulting finite path reaches a
large axis state with positive probability and finite holding time almost
surely. The explosion event just proved can follow it by the Markov
property. Therefore positive explosion holds from every finite initial
state. This is not a statement of probability-one explosion.

The corollary uses finite fixed constants throughout. Its uniform bounds
depend on those constants and the chosen finite A boundary; it does not
assert a uniform explosion probability as a coefficient approaches the
edge of the open cone.
