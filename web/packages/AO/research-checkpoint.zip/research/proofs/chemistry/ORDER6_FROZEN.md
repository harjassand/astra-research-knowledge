# Order-six explosive strongly endotactic mass-action system

Frozen version 1, 2026-10-08 10:12 UTC. Internally reconstructed candidate. Independent mathematical audit and historical priority remain UNKNOWN. The complete proof below is elementary and does not assume the unreviewed OA149 or N173 permanence results. This supersedes ORDER8_FROZEN.md and ORDER7_FROZEN.md only if the new fast-excursion proof passes audit; both earlier versions remain preserved.

## Exact theorem and network

Let k0,k1,k2,k3 be finite strictly positive constants with k3>2k2. Consider the minimal CTMC on N_0^2 with reactions and propensities

| reaction | population change | propensity at (a,b) |
|---|---|---|
| R0: 0->2A | (2,0) | k0 |
| R1: 2A->4A+B | (2,1) | k1(a)_2 |
| R2: 4A+B->4A+2B | (0,1) | k2(a)_4 b |
| R3: 4A+2B->3A | (-1,-2) | k3(a)_4(b)_2 |

Here (z)_j is the falling factorial, zero if z<j. The maximum source molecularity is SIX. For a concrete rational fixture use (k0,k1,k2,k3)=(1,1,1,4). The graph is strongly endotactic, its stoichiometric subspace is R^2, and the CTMC has positive probability of explosion in finite physical time from some sufficiently large axis state (n,0).

This is not a weakly reversible network and is not a counterexample to weakly reversible positive recurrence. It gives the source-reported open minimum a new upper bound six, if correct and historically new. Xu's established order-two regularity theorem then yields 3<=minimum<=6; orders3,4,5 remain unresolved.

## Complete all-direction geometry

Source hull is quadrilateral O=(0,0),P=(2,0),Q=(4,1),R=(4,2). The outward normals in hull order are

    O-P: (0,-1), P-Q: (1,-2), Q-R: (1,0), R-O: (-1,2).

Corresponding outgoing projections at the tied source endpoints are:

    (0,-1): R0=0, R1=-1;
    (1,-2): R1=0, R2=-2;
    (1,0):  R2=0, R3=-1;
    (-1,2): R3=-3, R0=-2.

Every maximal-source arrow is nonpositive, with a strictly negative arrow on every boundary normal. Each open vertex normal cone is the positive hull of its two adjacent boundary normals; its outgoing arrow is nonpositive at both bounds and strictly negative at at least one. Thus it is strictly inward throughout the open cone. This proves strong endotacticity in ALL nonzero directions, including the normal (1,0) where R2 is neutral. It also implies the essential-source definition of ordinary endotacticity. No generic-direction shortcut is used.

## Reference fast excursion and its exact cost

Starting at axis (n,0), first prescribe R1, which moves to (n+2,1). Consider then the reference event process permitting only R2 and R3 until B first hits zero. At any such state with a>=4 both rates share the EXACT factor (a)_4. Hence reaction-choice probabilities depend only on b:

    birth b->b+1, A unchanged: k2 b;
    pair-death b->b-2, A decreases by1: k3 b(b-1).

Starting B=1, write D for the number of pair-deaths before absorption at B=0, and F for the number of births. Every finite absorbed excursion satisfies

    1+F-2D=0, so F=2D-1 and event count J=3D-1.

Let p=k2/(k2+k3). Under k3>2k2, p<1/3.

### Exponential tail and mean bound, with proof

Set V(b)=ceil(b/2). A pair-death decreases V by1. A birth from even b increases V by1; a birth from odd b leaves V unchanged. A zero-increment move cannot be followed by another zero-increment move, since odd birth lands at even b. Erase the zero moves. The resulting update process starts V=1 and has nearest-neighbor +/-1 updates until it first reaches0. At even b>=2 the birth probability is

    k2/[k2+k3(b-1)] <= p.

At odd b>=3 the next update is an immediate downward pair-death or, after a zero birth, a +/-1 update from the resulting even state. Its up probability is therefore at most p as well. At b=1 a birth is forced, followed by an even-state update with up probability p. Thus EVERY accelerated update has conditional up probability <=p<1/2.

Couple the accelerated process to a simple nearest-neighbor walk Y starting at1 with up probability p and down probability 1-p, using the same fresh uniform variable for each update, until the accelerated process is absorbed. Because its up probability is bounded by p, its position is at most Y's position at every coupled time. Consequently its absorption-update count H is at most Y's absorption count H_Y.

For rho=sqrt((1-p)/p)>1, before absorption,

    E[rho^(Y_{j+1}-Y_j)] = 2 sqrt(p(1-p))=:q<1.

The killed walk therefore obeys P(H_Y>j)<=rho q^j (iterate E[rho^Y_j 1_{H_Y>j}]<=rho q^j, and rho^Y_j>=1 while alive). Hence H, D and J all have exponential tails. This supplies finite moments before any optional-stopping or expectation manipulation.

For the accelerated process, let U be up updates. Pathwise D-U=1 and H=D+U=2D-1. By conditioning each update on its past and Tonelli, E U<=p E H. Therefore

    E D <=1+p(2 E D-1),
    E D <=(1-p)/(1-2p)<2.

The reference axis increment Delta=2-D thus has mean at least

    mu0 = 2-(1-p)/(1-2p) = (1-3p)/(1-2p)>0.

For the concrete fixture p=1/5, E D<=4/3 and mu0>=2/3. Reference increments are bounded above by1 and have a uniform exponential lower tail.

## Accepting reference excursions in the real chain

For n sufficiently large, accept an event itinerary if its first reaction is R1 and every subsequent reaction until B=0 is R2 or R3, with D<=floor(n/2). Reject otherwise. This truncation makes A>=n+2-D>=n/2 throughout the excursion. Define a_n as the total probability of accepted itineraries, and K_n as their conditional axis increment distribution.

Reference excursions are sampled from the fast reaction-choice law just proved. Given a reference path, its probability under the real event chain is its reference probability multiplied by the initial R1 choice probability and, at every fast step, the factor

    fast_total/(fast_total + k0+k1(a)_2).

For a>=n/2 and b>=1, fast_total>=(a)_4 k2 b>=(a)_4 k2. Thus the total relative slow competition is bounded by C/n^2, uniformly over every fast holding state on a truncated path. The initial R1 factor is also 1-O(n^-2), since at B=0 only R0 competes. The rejected reference tail P(D>n/2) is exponentially small. A finite-product union bound and E J<infinity give

    1-a_n <= C/n^2 + C exp(-c n).

More strongly, the lost first-moment weight is O(n^-2): the finite-product loss on a path is at most C(1+J)/n^2; multiply by |Delta|<=2+D and integrate, using E[(1+D)(1+J)]<infinity. The truncated tail likewise has exponentially small first moment. Consequently

    E_{K_n} Delta >= mu0-O(n^-2) >=d>0

for n>=N. Conditioning divides by a_n>=1/2. The same comparison also yields a uniform exponential moment of |Delta| under K_n. These are proved estimates for the normalized chain; they do not assert probability-one acceptance in the actual system.

## Positive-probability linear escape of the normalized macrochain

Let Z_j be the conditional chain K_n on n>=N and extend it below N by +1 transitions. Choose theta>0 small. Uniform exponential moments and uniform mean >=d give by Taylor's theorem

    E[e^{-theta Delta}|Z_j=n] <=1-theta d/2<1, n>=N.

Let tau be its first visit below N. The stopped process e^{-theta Z_{j wedge tau}} is a nonnegative supermartingale. At a downward exit, Z_tau<=N-1 (overshoots do not invalidate this inequality). Optional stopping at tau wedge j gives, from z0>N,

    P(tau<infinity) <=exp[-theta(z0-(N-1))]<1.

Thus D_escape={tau=infinity} has positive probability. The martingale differences Delta_j-E[Delta_j|past] have uniformly bounded second moments. The martingale strong law follows from sum_j E[(Delta_j-E[Delta_j|past])^2]/j^2<infinity by the L2 martingale convergence theorem followed by Kronecker's lemma. On D_escape,

    Z_j >=z0+d j+o(j),

so Z_j>=d j/2 eventually. This part uses elementary martingale facts, with explicit moment hypotheses supplied by the fast-excursion proof.

## Acceptance weighting, physical clock and explosion

Finite actual accepted macrochain path weights equal normalized K-path weights multiplied by product a_{Z_j}. On a linearly escaping normalized path,

    sum_j(1-a_{Z_j})<infinity, and product_j a_{Z_j}>0.

Dominated convergence of finite path weights therefore gives actual probability

    E_K[1_{D_escape} product_{j>=0} a_{Z_j}]>0.

Along each accepted macrocycle begun at n, all states have A>=n/2, so q(a,b)>=k1(a)_2>=c1 n^2 for large n. The accepted number of fast events is J=3D-1, and its conditional expectation under K_n is uniformly bounded because its law is dominated by the reference law divided by a_n>=1/2. Hence the conditional mean physical duration of a macrocycle is <=C/n^2.

For clarity about conditioning: given the sequence of axis increments, D=2-Delta and J=3D-1 are determined. The full fast-word holding-time mean is bounded by C(1+D)/n^2. Under the K-chain, the nonnegative sum over j of this quantity, restricted to paths with eventual Z_j>=d j/2, is finite almost surely: for each deterministic eventual-start index m, sum_{j>=m} E[1_{Z_j>=d j/2}(1+D_j)/Z_j^2]<=C sum_{j>=m}j^-2<infinity. Taking the countable union over m proves finiteness on linearly escaping paths. The actual weighted law is absolutely continuous with density <=1 relative to the normalized path law, so this remains true after acceptance weighting.

Finally holding times are independent exponentials of total rate q, independent of next-reaction choices. For each almost-sure accepted escaping event path just obtained, its sum of conditional mean holding times is finite. The physical holding-time sum is therefore finite almost surely conditional on that path. Yet infinitely many reactions occur and A escapes to infinity. This proves finite-time explosion on a positive-probability event.

## Frontier and claim status

Current primary source: Xu, arXiv:2409.05340v2, Definitions4.2–4.4, Theorem4.6, Remark4.8. The theorem proves order-two endotactic regularity; the remark records an order-ten explosive example and leaves the minimum open. ArXiv revision metadata9May2026; manuscript HTML internal date24August2026. https://arxiv.org/html/2409.05340v2

Historical mechanism: Anderson–Cappelletti–Kim–Nguyen (2020), Example3.2, 0->2A->4A+B->6A+4B->3A. https://doi.org/10.1016/j.spa.2020.07.012

Our improvement changes the fast-cycle mechanism: common-factor birth/pair-death excursions replace prescribed finite paths. Lowering final order without accounting for repeated fast reactions would not be a proof. This construction does not settle the exact minimum, all-rate explosivity, every-initial-state explosion, a physical molecule mechanism, or a new deterministic permanence theorem. Independent audit and exact numerical diagnostics are distinct from external proof validation and historical novelty.
