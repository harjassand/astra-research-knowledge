# Coordinate compression gives order three, but not explosion

Status: internally reconstructed all-rate nonexplosion proof for one actual
strongly endotactic order-three diagram. This is a rejected construction,
not a proof of regularity for every order-three endotactic system.

The invertible complex map `(A,B) -> (A-B,B)` sends all complexes and products
of the order-five diagram to nonnegative integer complexes. The resulting
diagram is

`0 -> 2A`,
`2A -> 2A+B`,
`2A+B -> A+2B`,
`A+2B -> 3A`,
`A+2B -> 2A`.

Its maximum reactant order is three. Endotacticity is invariant under this
invertible linear map of diagrams (directions transform by the transpose).
It is also checked directly: the source hull vertices are `(0,0)`, `(2,0)`,
`(2,1)`, `(1,2)` and the outward normals are `(0,-1)`, `(1,0)`, `(1,1)`,
`(-2,1)`. At each face all arrow projections are nonpositive and one is
strictly negative. The vertex cones complete the all-direction proof.

Mass-action propensities are not invariant under this complex map. The
actual new mass-action rates, with any fixed positive coefficients, are

| Jump | Rate |
|---|---|
| `(2,0)` | `k0` |
| `(0,1)` | `k1(a)_2` |
| `(-1,1)` | `k2(a)_2 b` |
| `(2,-2)` | `k3 a(b)_2` |
| `(1,-2)` | `k4 a(b)_2` |

**Proposition.** Every such positive rate tuple defines a nonexplosive
minimal chain from every finite initial state.

Fix any `K>0` and write `n=a+b`. The proper nonnegative function

`V(a,b)=a+b+K a/(b+1)`

is comparable with `1+a+b`. Its exact finite differences are

| Jump | Change in V |
|---|---|
| `(2,0)` | `2+2K/(b+1)` |
| `(0,1)` | `1-Ka/((b+1)(b+2))` |
| `(-1,1)` | `-K(n+1)/((b+1)(b+2))` |
| `(2,-2)` | `2K(n+1)/(b^2-1)` |
| `(1,-2)` | `-1+K(2a+b+1)/(b^2-1)` |

The last two expressions apply only when `b>=2`, as their rates otherwise
vanish. In particular, for all `b>=1` and `a>=2`, with
`C=2K(k3+k4)`, the generator obeys

`LV <= 2k0(1+K)+k1 a^2+C a(a+b+1)`

`        -k2 K a^3/[4(b+2)]-k4 a b(b-1)`.

The pair bound uses `(b)_2/(b^2-1)=b/(b+1)<=1`; at `b=1` the pair terms
are zero and the same upper bound remains valid. The cubic negative bound
uses `(a)_2>=a^2/2`, `b/(b+1)>=1/2`, and `n+1>=a`.

We now show that the generator is globally bounded above. For `a` large
and `1<=b<=a^(2/3)`, the first negative term is at most
`-k2 K a^(7/3)/12`. The positive nonconstant terms are at most a fixed
multiple of `a^2`, because `b<=a`. Thus `LV` is bounded above in that region,
and tends to minus infinity as a tends to infinity.

For `b>a^(2/3)` and a large, `b>=2`, so the other negative term is at most
`-(k4/2) a b^2`. It dominates the positive multiple of `a(a+b+1)` uniformly
in this region. Indeed `b^2/(a+b+1)` tends to infinity uniformly: if `b<=a`
it is at least `a^(1/3)/3`, and if `b>a` it is at least `a/3`. The term
`k1a^2` is also included in a fixed multiple of `a(a+b+1)`.

At `b=0` the exact generator is

`LV(a,0)=2k0(1+K)+k1(a)_2(1-Ka/2)`,

which is bounded above. For each of the finitely many remaining a values,
the positive pair terms grow at most linearly in b while the negative
pair-loss term is `-k4 a b(b-1)`. At `a=0` all non-input rates vanish; at
`a=1` the same quadratic pair-loss bound controls large b. Hence these
remaining states also have a finite generator supremum.

Consequently `LV<=C_*` globally for a finite constant depending only on the
fixed rate tuple and K. The proper Lyapunov stopping argument in
`ORDER4_NONEXPLOSIVE_NEARMISS.md` then proves nonexplosion from every finite
state.

This rejects a serious order-reduction attempt without appealing to a
formal fast limit. The compressed diagram remains fully strongly endotactic,
but its pair-return rate has A exponent one, whereas its conversion rate
has A exponent two. These are the true polynomial rates; carrying over the
old exponent-three intensities would change the kinetic class and would not
resolve the mass-action minimum-order question.
