# Order-eight explosive strongly endotactic network — frozen derivation

Version 1, 2026-10-08 10:05 UTC. Derived from the boundary-cycle idea of Anderson–Cappelletti–Kim–Nguyen (2020), Example 3.2, with one-error repair replacing an error-free path. This is an internally reconstructed candidate; correctness and historical priority require independent review. No claim of solving the exact minimum molecular order.

## Exact network and claim

On N_0^2 with populations (a,b), use reactions

* R0: 0 -> 2A, vector (2,0), propensity k0.
* R1: 2A -> 4A+B, vector (2,1), propensity k1 (a)_2.
* R2: 4A+B -> 5A+3B, vector (1,2), propensity k2 (a)_4 b.
* R3: 5A+3B -> 3A, vector (-2,-3), propensity k3 (a)_5 (b)_3.

Every k_i is a fixed finite strictly positive constant. Here (z)_j=z(z-1)...(z-j+1), zero when z<j. There are no combinatorial binomial divisors; using binomial propensities simply rescales positive constants. Molecular order is the maximum reactant degree, 8. The stoichiometric span is R^2. The graph is not weakly reversible.

Claim: the graph is strongly endotactic, and the minimal CTMC has positive probability of infinitely many reaction events in finite physical time from (n,0) for every sufficiently large n. It is thus an explosive endotactic mass-action CTMC of order eight. The deterministic mass-action comparator is permanent by the already established strongly-endotactic theorem; neither OA149 nor N173 is needed here.

## All-direction strong endotacticity

The source points, in counterclockwise order, are O=(0,0), P=(2,0), Q=(4,1), R=(5,3). Their convex hull is a strictly convex quadrilateral. For each nonzero direction w, inspect the sources maximizing w dot y. In the open normal cone of each source, all its outgoing arrows have strictly negative projection; on a boundary normal, all arrows from the tied sources have nonpositive projection and at least one has negative projection.

The four outward edge normals, and projections of the corresponding outgoing vectors, are:

| Hull edge | outward normal | projections at tied sources |
|---|---|---|
| O-P | (0,-1) | R0: 0; R1: -1 |
| P-Q | (1,-2) | R1: 0; R2: -3 |
| Q-R | (2,-1) | R2: 0; R3: -1 |
| R-O | (-3,5) | R3: -9; R0: -6 |

At a source vertex its normal cone is the positive hull of the two adjacent normals. The outgoing vector has nonpositive projection against both adjacent normals, strictly negative against at least one; therefore its projection is strictly negative in the interior of that cone. This gives a complete analytic proof including every face. In particular the stronger definition based on all maximal sources is satisfied; the essential-source definition follows.

## Exact admissible macrocycle words

Start at (n,0), n>=5. Two disjoint event words are admitted:

* U = (R1,R2,R3): (n,0)->(n+2,1)->(n+3,3)->(n+1,0).
* S = (R1,R2,R2,R3,R2,R3,R2,R3):
  (n,0)->(n+2,1)->(n+3,3)->(n+4,5)->(n+2,2)->(n+3,4)->(n+1,1)->(n+2,3)->(n,0).

U advances the axis population by one. S is a stall, returning to the same axis population. S permits exactly one extra R2 at the first b=3 state. No prescribed reaction is disabled along either word for n>=5.

Let q(a,b) be the total propensity. Write

u_n = P(U | initial (n,0)), s_n = P(S | initial (n,0)), r_n=1-u_n-s_n.

These are exact finite products of desired propensity divided by q at the listed states. There exist constants C,N depending only on the four k_i such that for all n>=N,

    u_n >= 1-C/n,
    s_n <= C/n,
    0<=r_n<=C/n^2.

Proof of the last, load-bearing estimate: at (n,0), all competitors to R1 have relative rate O(n^-2) (only R0 is enabled). At (n+2,1), R2 has relative competing rate O(n^-2), since R3 is disabled and R1/R2=O(n^-2). At (n+3,3), R3 dominates; the relative R2 competition is O(n^-1), while R1 and R0 have relative rates O(n^-3) and O(n^-5). Denote p_n=P(R2 at this first b=3 state), so p_n=O(n^-1). If R3 occurs, the word U is complete. If R2 occurs, the five remaining prescribed reactions of S each have success probability 1-O(n^-1): at b=5,4,3 R3 dominates with R2/R3=O(n^-1); at b=2,1 R2 dominates with R1/R2=O(n^-2), and R3 is disabled. Thus the probability of failure AFTER the permitted error is p_n O(n^-1)=O(n^-2). Failure before that error is also O(n^-2). All estimates hold uniformly because a=n+j with j in {0,1,2,3,4} and b ranges over a fixed finite set. This proves the bounds with ordinary finite-product/union bounds, not an unproved asymptotic independence assumption.

## Positive probability of indefinite accepted progress

At axis level n, the chain can perform any number j>=0 of stalls S followed by U. This has total probability

    t_n = sum_{j>=0} s_n^j u_n = u_n/(1-s_n)
        = 1-r_n/(1-s_n) >= 1-C'/n^2.

Choose N large enough that s_n<=1/2 and C'/n^2<=1/2. Strong Markov at the successive axis returns gives the probability of an infinite accepted itinerary, visiting N,N+1,... in order with finitely many stalls at every level, as

    P(E_N)=product_{n=N}^infinity t_n >0,

because sum_n (1-t_n)<infinity. One may define E_N by intersecting the decreasing finite-level itinerary events; countable continuity of probability proves the infinite-product equality. Infinite stalls at a single level have probability zero because s_n<1.

This is the repair that an error-free infinite-cycle proof lacks: product u_n may vanish owing to the O(1/n) error rate, but product t_n is positive owing to O(1/n^2) residual failure.

## Physical clock and explosion

For a CTMC at a given state, holding time is Exp(q(a,b)) and is independent of the choice of next reaction. Conditional on ANY finite or infinite event itinerary, holding times have these exponential laws independently. Along each U or S word, a>=n and k1(a)_2 is enabled, so q(a,b)>=k1 n(n-1). Each macrocycle has at most eight events; therefore its conditional expected duration is at most 8/[k1 n(n-1)].

Conditional on the accepted stage n (any number of S, followed by U), the number J_n of stalls is geometric:

    P(J_n=j | accepted stage n)=(1-s_n)s_n^j,
    E[J_n+1 | accepted stage n]=1/(1-s_n)<=2.

The same conditional distribution holds under E_N, because acceptance of later stages depends only on reaching (n+1,0), which is the same for every j. Consequently

    E[total holding time | E_N] <= sum_{n=N}^infinity 16/[k1 n(n-1)] <infinity.

Thus total physical time is finite almost surely on E_N, yet infinitely many events occur and A tends to infinity. Since P(E_N)>0, the minimal CTMC explodes with positive probability. No event-count-only estimate has been mistaken for physical-time control.

## Exact scope and remaining questions

The proof establishes explosion from sufficiently large axis populations for every fixed positive rate tuple. That is sufficient for explosivity of the reaction system under Xu's definition. It does not assert explosion probability one, explosion from every initial population, uniqueness of an explosive extension, irreducibility of the whole state space, weakly reversible explosion, or minimal possible order. An elementary finite R1/R2/R3 path also lets any sufficiently large initial (a,b) drain to an axis state in a suitable residue class, but no such extra assertion is needed.

The established order-two regularity theorem gives a lower bound of three on the minimum order. If this construction is correct and historically new, the open interval improves from 3<=minimum<=10 to 3<=minimum<=8. General lower-order constructions remain open.

## Primary sources actually opened

* Chuang Xu, arXiv:2409.05340v2, “On the Regulary of Reaction Systems”, arXiv version dated 9 May 2026; live HTML opened 8 October 2026. Definition 4.2–4.4; Theorem 4.6; Remark 4.8 explicitly records known order-10 explosive example and open minimum. https://arxiv.org/html/2409.05340v2
* Anderson, Cappelletti, Kim, Nguyen, “Tier structure of strongly endotactic reaction networks”, SPA130(12),7218–7259 (2020), Example3.2. Primary accepted-manuscript web excerpt opened through search; direct web open returned internal error. Known network 0->2A->4A+B->6A+4B->3A; source mechanism uses summable event failures plus summable holding times. https://doi.org/10.1016/j.spa.2020.07.012

This derivation was frozen before root's independent geometric and CTMC audits returned.
