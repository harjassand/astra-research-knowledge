# A legal order-four near-miss is nonexplosive

Status: internally reconstructed all-state proof, not an exclusion of all
order-four endotactic networks. The exact directional diagnostic for this
network is `order4_largeburst_Areturn` in `phase2_geometry.json`.

Consider the mass-action chain with arbitrary fixed constants
`k0,k1,k2,k3,k4>0` and the five reactions

| Reaction | Jump | Intensity |
|---|---|---|
| `0 -> 2A` | `(2,0)` | `k0` |
| `2A -> 3A+B` | `(1,1)` | `k1(a)_2` |
| `3A+B -> 2A+2B` | `(-1,1)` | `k2(a)_3 b` |
| `2A+2B -> 4A` | `(2,-2)` | `k3(a)_2(b)_2` |
| `2A+2B -> 2A` | `(0,-2)` | `k4(a)_2(b)_2` |

Here falling factorials vanish below their reactant thresholds. This is a
strongly endotactic diagram of maximum source order four. In particular, it
is not rejected by geometry. The source hull has vertices `(0,0)`, `(2,0)`,
`(3,1)`, `(2,2)`. Its successive outward face normals may be taken as
`(0,-1)`, `(1,-1)`, `(1,1)`, `(-1,1)`. At each face all outgoing projections
are nonpositive and at least one is strictly negative; the vertex cones are
positive combinations of their incident normals. Thus the argument covers
every direction, including ties.

**Proposition.** For every fixed positive rate tuple above and every finite
initial state, the minimal chain is nonexplosive.

Choose any real `K>4` and define the proper nonnegative function

`V(a,b)=a+b+K/(b+1)`.

Write `L` for its infinitesimal generator. A birth of one B changes the last
term by `-K/((b+1)(b+2))`; removal of two B changes it by
`2K/((b-1)(b+1))`. Direct substitution gives

`LV(a,b) = 2k0 + k1(a)_2[2-K/((b+1)(b+2))]`

`             - k2(a)_3 b K/((b+1)(b+2))`

`             + (a)_2(b)_2[2K(k3+k4)/(b^2-1)-2k4]`,

where the last term is zero at `b=0,1`. All terms are exact polynomial
intensities times the displayed finite differences.

At `b=0`, the only nonconstant term is
`k1(a)_2(2-K/2)<0`, so `LV(a,0)<=2k0`.

For `b>=2`, use

`(b)_2 * 2K/(b^2-1) = 2K b/(b+1) <= 2K`.

With `C=2k1+2K(k3+k4)` and
`f(b)=Kb/((b+1)(b+2))>0`, this yields

`LV(a,b)<=2k0+(a)_2[C-2k4 b(b-1)-k2(a-2)f(b)]`.

Choose an integer `M>=2` with `2k4 M(M-1)>=C`. Since `a>=2` whenever
`(a)_2` is nonzero, the bracket is nonpositive for every `b>=M`.

For each of the finitely many states of the B coordinate `1<=b<M`, the
generator has the form

`2k0+(a)_2[c_b-k2(a-2)f(b)]`,

for a finite real constant `c_b`. Since `k2 f(b)>0`, this is nonpositive
above `2k0` for all sufficiently large a. The remaining a values in these
finitely many B levels form a finite set. At `a=0,1` all terms except the
input term vanish. Consequently there is a finite constant `C_*` such that

`LV(a,b)<=C_*` for every `(a,b) in N_0^2`.

For completeness, this proper Lyapunov bound implies regularity directly.
Stop the minimal chain upon leaving the finite sublevel set `{V<R}`. Dynkin's
formula, localized to a finite set and time t, gives
`E V(X_{t wedge tau_R})<=V(X_0)+C_* t`. At exit `V>=R`, hence
`P(tau_R<=t)<=[V(X_0)+C_*t]/R`. Each finite sublevel set has finite maximum
total rate, so infinitely many jumps cannot occur before exiting it. Letting
R tend to infinity proves that explosion by any fixed t has probability
zero. Taking integer t proves the proposition.

The mechanism explains the failed construction. The cubic conservative
A-to-B conversion prevents B from being cleared after a bounded number of
reactions. The fixed pair-loss branch, even when its coefficient is small,
controls large B. Removing that branch leaves a diagram with all the highest
total-order reactions orthogonal to `(1,1)`, and the lower quadratic growth
reaction then violates endotacticity. Taking `k4 -> 0` is not a counterexample
at any fixed strictly positive tuple.

This proof does not use a formal fast limit, averaged generator, bounded-B
assumption, or a simulation. It rules out this actual legal order-four
network for all finite initial states and all its positive mass-action rates.
It says nothing yet about other order-three/four networks or extra-species
constructions.
