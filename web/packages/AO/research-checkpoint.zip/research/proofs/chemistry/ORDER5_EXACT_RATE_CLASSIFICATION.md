# Exact rate classification, including the critical surface

Status: internally reconstructed extension of the separately frozen
`ORDER5_STRICT_RATE_PHASE.md`. The proof of the critical surface below was
suggested by root at 11:29 UTC and checked here afterward. It is exposed
collaborative work, not another independent derivation. Independent argument
audit of the full kernel and trace remains the next gate.

Use the same five fixed positive rate coefficients and indexing:

| Reaction | Jump | Intensity |
|---|---|---|
| `0 -> 2A` | `(2,0)` | `k0` |
| `2A -> 3A+B` | `(1,1)` | `k1(a)_2` |
| `3A+B -> 3A+2B` | `(0,1)` | `k2(a)_3 b` |
| `3A+2B -> 3A` | `(0,-2)` | `k3(a)_3(b)_2` |
| `3A+2B -> 2A` | `(-1,-2)` | `k4(a)_3(b)_2` |

Every k_i is a finite fixed strictly positive real number. Put

`d=k3+k4`, `beta=k2/d`, `q=k4/d`,

`h(beta)=[1+beta exp(2beta)(2beta)^(-beta)gamma(beta,2beta)]/2`,

`mu=1-q h(beta)`.

**Theorem.** For every finite initial state, the minimal CTMC explodes
almost surely if mu>0 and is nonexplosive if mu<=0. Thus this single
strongly endotactic order-five diagram has a completely specified rate
boundary. The inflow and quadratic-growth constants k0,k1 may be arbitrary
positive numbers. This theorem concerns this diagram; the minimal possible
order of an explosive endotactic mass-action system still lies among three,
four, and five.

The exact occupation calculation, the uniform full-reaction return bounds,
the coupling to the actual feedback process, and the proof for mu>0 are
given in the frozen strict-sign derivation. The two full-kernel facts used
below, established in its Sections 1 and 3, are

`m(a)=E[Delta A | axis start a]=mu+O(1/a)`,

`sup_{a>=2} E[(Delta A)^2 | axis start a]<infinity`.

That file proves these for the complete return cycle, with every U/I event,
low-A reset, and final marked death included. It also establishes global
return from positive B to the axis in finitely many full reactions almost
surely, for arbitrary positive coefficients. These are analytic proofs;
they are not inferences from finite truncation diagnostics.

## An accelerated trace with exact clocks

Define a cycle at `(a,0)` as its first reaction followed by the complete
return to the axis if that reaction was U. Let `P_a(c)` be the distribution
of its terminal A count, and retain an immigration-only cycle as a cycle.
Every cycle ends after finitely many full reactions almost surely, so this
is a probability kernel on the finite-state labels c in `N_0`. It is
defined from the embedded reaction chain before regularity is known.

At an axis state the total rate is exactly

`lambda(a)=k0+k1 a(a-1)`.

The initial holding time of that cycle is an independent unit exponential
divided by lambda(a). It is independent of the first reaction choice and
all subsequent embedded choices determining the return state. This follows
from the explicit CTMC construction using separate uniforms for reaction
labels and independent exponentials for holding times. All rates are
time-homogeneous functions of the state, so the elapsed holding time does
not enter the kernel.

Delete only the off-axis holding durations, retaining every axis cycle and
its initial exponential wait. This defines a marked pure-jump trace with
event rate lambda(a) and transition kernel P_a. Self-returns are retained
as events and are allowed. Its generator on a test function f is

`L_trace f(a)=lambda(a) sum_c P_a(c)[f(c)-f(a)]`.

The total original physical clock is pathwise at least this trace clock.
Therefore proving divergence of the sum of trace waits proves
nonexplosion of the original process.

## A proper quadratic Foster bound closes mu=0

Take `V(a)=1+a^2`. For each a its kernel expectation is finite because the
cycle increment has finite second moment. Its exact expected increment is

`E[V(a+Delta)-V(a)]=2a m(a)+E[Delta^2]`.

If mu<=0, the drift asymptotic and uniform second-moment bound give

`2a m(a)+E[Delta^2] <= C`

for all a>=2, after enlarging the fixed finite constant to include finitely
many small a values. At a=0 or1 the only axis reaction is I, so P_a is the
point mass at a+2 and this same type of bound holds after another finite
enlargement. Consequently

`L_trace V(a)<=C lambda(a)<=C'(1+a^2)=C' V(a)`

for every a in `N_0`.

Here is a direct regularity argument that also handles self-events. Stop
the trace at its first exit from the finite sublevel set `{V<R}`. Within
that set the event rate lambda is bounded, so infinitely many marked
events, including self-events, cannot accumulate before exit. The
localized Dynkin formula is valid: all expected destination V values are
finite. Gronwall gives

`E[V(Z_(t wedge tau_R))]<=V(Z_0)exp(C't)`.

Since V>=R on exit,

`P(tau_R<=t)<=V(Z_0)exp(C't)/R`.

Any finite-time accumulation of marked trace events would have to leave
every finite sublevel set, because their event rates are bounded. Letting
R tend to infinity therefore proves that the trace is nonexplosive. In
particular the sum of its independent axis waits diverges almost surely.
This argument does not discard self-returns or divide by a possibly small
probability of an actual state change.

The original process has those same axis waits plus nonnegative excursion
durations, so its clock also diverges. If its initial state is off the
axis, the already proved global return reaches an axis state after
finitely many reactions and finite time almost surely. Thus nonexplosion
holds from every finite initial state, including the entire surface mu=0.

## Consequences and audit boundary

The strict-sign file proved that h(beta) is continuous, strictly increasing
from one to infinity. For every q in (0,1) its unique threshold beta_c(q)
satisfies `q h(beta_c)=1`. The exact behavior is now

* `beta<beta_c(q)`: almost-sure finite-time explosion from every finite state;
* `beta>=beta_c(q)`: nonexplosion from every finite state.

At beta=1 the threshold is `q_c=4/(exp(2)+1)`. Thus the two fixed tuples
`(1,1,4,3,1)` and `(1,1,4,1,3)` lie respectively in the explosive and
nonexplosive regimes. The original tuple `(1,1,1,4,1)` lies in the
explosive regime, with exact limiting axis drift about 0.7597704058.

The original fixed-tuple witness, the independent direct proof, the exposed
a.s. strengthening, and the broader sufficient cone remain preserved as
separate versions. This rate classification makes the new result depend
on the full-kernel coupling and its moment estimates, which need their own
independent audit. It does not retrospectively label earlier derivations
as having proved the critical case. External mathematical validation,
formal replay, and historical priority remain UNKNOWN.
