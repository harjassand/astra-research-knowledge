# A precise boundary-word obstruction at order four

Status: internally proved combinatorial lemma. This excludes a specified
mechanism. It is not a theorem that all order-three/four endotactic CTMCs
are nonexplosive.

Let A be one species and let Z denote any finite collection of other
species. Write `M(z)=sum_j z_j` for their total molecular count. Assume a
finite fully endotactic reaction diagram satisfies:

1. Every reactant has total molecular order at most four.
2. Its maximum A coefficient among reactants is three.
3. The pure reactant `3A` is absent.

Every maximum-A reactant is therefore `3A+Z_j` for one auxiliary species.
At least one such reactant exists by assumption 2. Products need not satisfy
any separate molecular-order bound, and rate constants do not enter the
lemma.

**Lemma.** For every arrow with reactant `3A+Z_j`,

`Delta A<=0`, `Delta A+Delta M<=0`, and `Delta A-Delta M<=0`.

If `Delta A=0`, then `Delta M=0`, so the arrow only redistributes the single
auxiliary molecule. Every arrow with reactant `2A` satisfies
`Delta A-Delta M<=0` as well.

**Proof.** Endotacticity is applied to the maximal sources among arrows whose
projection is nonzero; an outward arrow at a globally maximal source always
violates that definition.

First use the direction with A weight one and every auxiliary weight zero.
The maximum source weight is three, so an arrow from a maximum-A source
cannot have `Delta A>0`.

Next use the all-ones direction. Each `3A+Z_j` source has total order four,
the largest possible source score. Its arrow cannot increase `A+M`.

Now give A weight one and every auxiliary weight `-epsilon`, where
`0<epsilon<1`. All maximum-A sources have score `3-epsilon>2`. Every other
source has A coefficient at most two and nonnegative auxiliary coefficients,
so its score is at most two. An A-neutral arrow which clears auxiliary mass
would have strictly positive projection `-epsilon Delta M` at one of the
globally maximal sources and is forbidden. Together with the preceding
all-ones inequality, this gives `Delta M=0` for A-neutral maximum-A arrows.

If a maximum-A arrow decreases A, its integer change obeys `Delta A<=-1`.
Its source has only one auxiliary molecule, so its product nonnegativity
implies `Delta M>=-1`. Hence `Delta A-Delta M<=0` in this case also.

Finally use the direction with A weight one and all auxiliary weights minus
one. Every `3A+Z_j` source has score two. No source has larger score: there is
no pure `3A`, and all remaining sources have A coefficient at most two. A
pure `2A` source, when present, is globally maximal with score two. Its
outgoing projection `Delta A-Delta M` cannot be positive. This proves all
claims.

**Exact consequence for proposed explosive words.** Consider any finite
reaction word which starts and ends with all auxiliary counts zero and uses
only arrows with reactant `2A` or `3A+Z_j`. Each arrow makes `A-M`
nonincreasing, so the final A population is at most its initial population.
This remains true with arbitrarily many extra `2A` events or arbitrary
auxiliary redistribution events. Thus accepting those extra events cannot
repair this particular order-four axis-cycle mechanism.

The order-five construction evades the hypothesis in a visible way. Its
`3A+B -> 3A+2B` arrow increases auxiliary mass at source order four, which is
allowed because the `3A+2B` sources have total order five. The pair-clearing
arrow from that higher gate can then be A-neutral. At order four these two
operations cannot both be placed at maximum A exponent three.

**Failure scope.** The lemma allows arbitrary dimension but forbids a pure
`3A` source, and its reaction-word consequence excludes all other reactant
types. It does not control trajectories with unbounded auxiliary counts,
multiple large species, auxiliary-dependent lower-A reactions, or active
pure cubic-A sources. It therefore does not establish the global minimum.
The state-space generator and all rate/clock quantifiers must be handled
separately before any broader nonexplosion statement could be made.
