# Phase-two chemistry checkpoint

Written 2026-10-08 11:15 UTC. Original 10:19 report and all frozen versions
are preserved. Phase two was explicitly authorized for up to sixty minutes
to pursue minimum order three/four, while parent-dispatched workers audited
order five. No descendants were spawned, no repository was edited, and no
message was sent outside the internal agent team.

## Main result and current status

The five-reaction diagram in `ORDER5_FROZEN.md` remains the strongest
construction. Its fixed integer rate tuple `(1,1,1,4,1)` has a separate,
independently reconstructed direct proof at
`work/agents/chem_order5_blind/report.md`. That proof includes every slower
reaction and replaces the original auxiliary-clamp proof with a simpler
stopped excursion. Separate exact geometry is at
`work/agents/chem_geometry/order5/`. The integration lead reported no fatal
gap in its exposed proof audit; these are internal independent checks, not
external validation or formal replay.

The blind worker subsequently proved almost-sure finite-time explosion
from every finite initial state, at
`work/agents/chem_order5_blind/almost_sure/report.md`. Parent reported an
integration audit pass and a fresh argument audit in progress. I first read
that strengthening at 11:07 UTC, after freezing my own positive-probability
rate-cone extension. Earlier files' statements that a.s. explosion was
unestablished describe their actual historical status and were not erased.

The newly reconstructed sufficient open cone is

`k0,k1,k2,k3,k4>0`, `k3+k4>3k2`, `k3>k4`,

where the indices mean input, quadratic U, B birth V, unmarked pair death
D0, and marked A-loss pair death D1 respectively. The positive episode proof
is in `ORDER5_ROBUST_RATE_COROLLARY.md`; its new a.s. strengthening is in
`ORDER5_BROAD_CONE_ALMOST_SURE.md`. They permit arbitrary input and quadratic
growth coefficients by moving the finite ruin boundary upward. The a.s.
extension uses the blind worker's macro/reset and renewed-trial method,
explicitly recorded as a dependency. Its distinct new global axis-return
lemma works for every positive rate tuple: negative B drift outside a
finite set, a uniformly probable finite unmarked-death word inside it, and
repeated blocks. This new cone proof is internally reconstructed and still
needs an independent audit. The independently audited fixed tuple is not
made dependent on it.

The primary-source frontier comparison is unchanged: Xu v2 Theorem 4.6
excludes order at most two, while Remark 4.8 leaves the minimum explosive
order open with an order-ten witness. Conditional on mathematical
correctness and absence of a prior witness, the new upper bound is five,
leaving possible minima three, four, or five. The exact minimum is not
resolved. The separate priority worker's bounded primary-source searches
found no earlier lower-order witness; this does not establish historical
priority.

## Actual lower-order attempts and failure proofs

1. **A legal strongly endotactic order-four near-miss.** The diagram
   `0->2A; 2A->3A+B; 3A+B->2A+2B; 2A+2B->4A; 2A+2B->2A` passes every
   direction. It is nevertheless nonexplosive from every finite state for
   every fixed positive rate tuple. The proper function
   `V=A+B+K/(B+1)`, K>4, has a globally bounded generator. The all-state
   proof is `ORDER4_NONEXPLOSIVE_NEARMISS.md`. This rules out the actual
   candidate rather than diagnosing it by an averaged fast limit.

2. **Coordinate compression to order three.** The invertible map
   `(A,B)->(A-B,B)` maps every source and product of the successful diagram
   to nonnegative integer complexes. It preserves strong endotacticity and
   reduces its source order to three. However its true mass-action rates
   change. The compressed diagram
   `0->2A;2A->2A+B;2A+B->A+2B;A+2B->3A;A+2B->2A` is nonexplosive for every
   fixed positive rate tuple. The proper function
   `V=A+B+K A/(B+1)`, any K>0, has globally bounded generator. The proof is
   `ORDER3_SHEAR_NONEXPLOSION.md`. Carrying over the old propensities would
   change the kinetic class and would not settle Xu's mass-action question.

3. **A dimension-independent restricted obstruction.** In any endotactic
   diagram of order at most four with maximum A-reactant coefficient three
   and no pure `3A` source, every maximum-A arrow has reactant `3A+Z_j`.
   It makes `A-(total auxiliary count)` nonincreasing. An A-neutral such
   arrow only redistributes its single auxiliary molecule. Every pure `2A`
   arrow makes that same quantity nonincreasing. Thus every axis-to-axis
   reaction word consisting only of those reactants has nonpositive A gain,
   even with arbitrarily many accepted extra quadratic events. Exact
   directions and quantifiers are in `LOW_ORDER_BOUNDARY_OBSTRUCTION.md`.
   This excludes our simplest multi-species repairs, not every order-four
   process.

4. **Three-species bounded-token resets fail a precise face.** For
   `0->2A+C; 2A+C->3A+B; 3A+B->3A+C; 3A+B->2A+C`, use direction
   `(A,B,C)=(1,0,1)`. Sources `2A+C` and `3A+B` both score three. The
   growth and A-loss arrows are orthogonal, while the A-neutral B-to-C reset
   has outward projection one at an essential maximal source. Adding a
   two-C inactive guard at source `2A+2C` does not repair every direction:
   `(1,0,2/5)` gives scores 2.4,3,2.8 for the growth, reset, and added guard
   sources; the reset is still outward at the sole maximal source.

5. **A lower-A auxiliary return also fails.** In
   `0->2A;2A->3A+B;3A+B->2A+C;2A+C->3A`, the direction `(1,-1,0)` makes
   the growth and B-to-C arrows orthogonal at score two and the final
   C-clearing A growth outward at score two. Its sole essential maximal
   outward arrow violates endotacticity. Adding a protective `3A+C` source
   activates another cubic single-token mechanism rather than a disabled
   pair gate; no finite-rate escape mechanism was found.

6. **Catalyst substitution did not yield a legal construction.** Replacing
   `3A` by `A+C` only saves molecular order if C grows faster than A. Pure
   cubic feedforward C creation needs a higher geometric protective source;
   fixed mass-action clearing then prevents the assumed scaling. Conserving
   A/C exchange can make C of order A squared, but then quadratic A births
   grow total population only linearly in that larger population. No
   explosion claim rests on quasi-equilibrium, a formal fast limit, or an
   unconstructed catalyst relation.

Exact two-dimensional diagnostics for all legal near-misses are preserved
in `phase2_geometry.json` and `phase2_new_geometry.json`. Every diagnostic
checks rays and open sectors of the complete source/projection hyperplane
arrangement, including ties. The all-direction face proofs and generator
bounds are separate mathematical evidence from these finite checks.

## Source and resource accounting

The initial primary-source reads, hashes, Xu metadata/internal-date
discrepancy, N173 assumptions, and N76/N77 failure scopes remain in
`source_manifest.json` and the original report. A further bounded web search
for order-three/four nonexplosion and minimum explosive molecular order
found the same Xu/ACKN frontier, not a stronger published theorem. No broad
corpus reread or bulk search was performed.

Phase two used approximately fifty-five minutes of one worker's local
analysis at this checkpoint, small exact integer geometry, existing local
primary documents, and bounded web queries. There was no experiment,
training, cloud computation, deployment, external communication, or
repository mutation. `PHASE2_MANIFEST.json` records the new proof hashes
and read dependencies. `phase2_session.json` preserves the revised status
and remaining unknowns.

## Next decisive action

Audit the broader-cone global-return and renewed-trial proof independently,
especially conditioning after input-only runs, the reset drop bound, and
the finite-set recovery argument. Use the separate simpler fixed-tuple a.s.
proof as the principal theorem if that extension's audit is incomplete.
Orders three/four now need a different mechanism involving unbounded
auxiliaries or multiple large species, or a global structural theorem;
the restricted boundary-word lemma alone cannot settle that question.
