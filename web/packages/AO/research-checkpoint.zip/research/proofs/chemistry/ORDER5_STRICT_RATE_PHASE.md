# Exact limiting excursion functional and strict rate classification

Status: internally reconstructed analytic theorem, frozen after the
broader-cone proofs. It uses the previously exposed macro/reset and renewal
method, and adds a new exact occupation calculation and a perturbation
coupling for the full return kernel. This version has not yet had an
independent argument audit. No claim is made on the critical surface.

Keep the five jumps and falling-factorial intensities

`I:(2,0), k0`; `U:(1,1), k1(a)_2`; `V:(0,1), k2(a)_3 b`;

`D0:(0,-2), k3(a)_3(b)_2`; `D1:(-1,-2), k4(a)_3(b)_2`.

All five coefficients are fixed and strictly positive. Set

`d=k3+k4`, `beta=k2/d`, `q=k4/d`,

`h(beta)=[1+beta exp(2beta)(2beta)^(-beta) gamma(beta,2beta)]/2`,

where `gamma(s,x)=integral_0^x t^(s-1)exp(-t)dt` is the lower incomplete
gamma function. Let `mu=1-q h(beta)`.

**Theorem, away from the critical surface.** If mu>0, the minimal CTMC
explodes almost surely from every finite initial state. If mu<0, it is
nonexplosive from every finite initial state. The case mu=0 is left
unresolved in this report. The reaction diagram is the same strongly
endotactic diagram of source order five in both regimes.

The inflow and quadratic-growth coefficients k0,k1 can be arbitrary
positive constants. They do not appear in this strict-sign classification.
They do affect finite-state behavior and the error constants below.

## 1. Uniform return estimates for the actual chain

The global macro construction from the broader-cone report works for any
positive coefficients. At active states a>=3,b>0, ignore input reactions
until a B-changing reaction; stop on b=0 before any reset; otherwise include
one I/U reset if D1 just reached a=2. Every macro birth increases B by one.
Every macro death decreases it by at least one. The conditional macro
birth probability satisfies

`p_b <= (k2 b+k1)/(k2 b+k1+d b(b-1))`.

Choose a finite M>=2 so that this is at most 1/4 whenever b>M. For
`F(b)=2^b`, including F(0)=1, the worst macro-death ratio is 1/2. Thus

`E[F(B_next)|history] <= (7/8)F(b)` outside `[0,M]`.

If tau is the first macro hitting index of `[0,M]`, the stopped
supermartingale `(8/7)^(n wedge tau)F(B_(n wedge tau))` gives

`E[(8/7)^tau] <= 2^b`.

For a recovery starting at b<=M+L this bound is uniform. Inside `[1,M]`,
the unmarked-death/parity-repair word in the broader-cone report hits zero
in at most `L=ceil(M/2)+1` macros with uniform probability alpha>0. A
failed block of length L stays below M+L, then recovers to `[0,M]`.

Here is the exponential-tail step explicitly. A complete failed block and
recovery has length R with a uniform exponential moment at some c>0. For
small t>0, uniformly over its initial active A state,

`E[exp(tR)1_{failure}] <= P(failure)+E[exp(tR)-1]`

`                            <=1-alpha+Ct<=1-alpha/2`.

The constant C is finite because the recovery moment above controls
`E[R exp(cR/2)]`. A successful block/recovery also has a uniform finite
exponential moment. Iterating the weighted failure bound and summing its
geometric series proves a uniform exponential moment for the number K of
macros until the axis, starting at b=1. This reasoning uses conditional
bounds and does not assert that successive blocks are independent.

The full reaction count has an exponential tail as well. During an active
input run the conditional input probability is at most
`z=k0/(k0+6k2)<1`. A macro has at most its input-run count plus two full
reactions. For sufficiently small t>0 its conditional moment is bounded by

`m(t)=exp(2t)(1-z)/(1-z exp(t))`.

The moment of the sum of the first j macro lengths is at most m(t)^j by
conditional iteration. Consequently, for any small fixed epsilon>0,

`P(N>n)<=P(K>floor(epsilon n))`

`          +exp(-tn)m(t)^floor(epsilon n)`.

Choose epsilon with `epsilon log m(t)<t/2`. The macro bound makes the first
term exponential too. Thus, starting at active b=1,

`P(N>n)<=C exp(-c n)`

uniformly over every a>=3, with fixed positive constants depending on the
rate tuple. The one/two initial low-A activation reactions do not affect
these claims.

We also need a bound from arbitrary initial b. The macro B drift outside
the finite set is at most -1/2, so its expected hitting index is at most 2b.
The compact block retries have bounded expected length and success
probability at least alpha. Input runs have uniformly bounded mean. Hence

`E[N | any finite initial a>=2,b] <= C(b+1)`.

These estimates concern the exact chain with all U/I reactions and low-A
resets. In particular every B excursion hits the axis after finitely many
full reactions almost surely, before any possible explosion.

## 2. The autonomous limiting B chain

Consider only the one-dimensional chain killed at zero with rates

`b -> b+1: k2 b`, `b -> b-2: d b(b-1)`.

Let D be its number of pair deaths before absorption, starting at b=1.
The same macro argument (without inputs or resets) proves finite expected
total reaction count, exponential tails from b=1, and an expected count
bounded by C(b+1) from arbitrary b. Its holding rate at positive b is at
least k2, so the expected absorption time is finite as well. Thus its
absorption and moment assertions are established before the generating
function calculation; none is inferred from a formal stationary solution.

Write `nu_b=E_1[integral_0^tau 1_{B(t)=b}dt]` and
`G(z)=sum_{b>=1}nu_b z^b`. Birth and death compensators give

`k2 G'(1)=E[number of births]<infinity`,

`d G''(1)=E D<infinity`.

Thus G and its first two derivatives converge absolutely on [-1,1]. For
the bounded test function z^b, Dynkin's identity is justified by the finite
expected total reaction count and gives

`1-z=k2(z-1)z G'(z)+d(1-z^2)G''(z)`.

For -1<z<1, cancel 1-z to obtain

`d(1+z)G''(z)-k2 z G'(z)=1`.

Put `F=G'` and `I(z)=exp(-beta z)(1+z)^beta`. Since F is bounded at -1
and beta>0, `I(z)F(z)->0` there. Solving the first-order equation yields

`F(z)=exp(beta z)(1+z)^(-beta)/d`

`           *integral_{-1}^z exp(-beta t)(1+t)^(beta-1)dt`.

At z=1 this gives

`k2 F(1)=beta exp(2beta)(2beta)^(-beta)gamma(beta,2beta)`.

Particle balance at absorption is `1+births-2D=0`. Therefore
`E_1 D=h(beta)` exactly. The finite boundary at z=-1 is essential; an
arbitrary homogeneous solution would not be an occupation measure.

## 3. Full axis-return drift, including feedback

Define a return cycle at `(a,0)`, a>=2: its first reaction, followed by the
complete excursion to b=0 if that reaction was U. Let Delta be its A
increment. The estimates above imply a uniform exponential tail for the
cycle's full reaction count and hence uniform exponential moments for
Delta. We claim

`E[Delta | start(a,0)]=mu+O(1/a)` as a tends to infinity.

Condition first on a U start; it adds one A and creates b=1. Up to the first
additional U reaction, the B-changing fast-reaction probabilities are
exactly those of the autonomous chain, independent of A. Interleaved inputs
do not change B. Couple these fast choices and their D0/D1 marks to the
autonomous B chain. A failure of that coupling is declared on the first
additional U or when the actual A-coordinate falls below a/2.

Before the latter event, the conditional probability of an additional U
at any full reaction is at most C/a, while that of I is at most C/a^3.
The low-A event requires at least order a marked deaths and thus order a
full reactions, so the uniform exponential tail makes its contribution
exponentially small. At the first extra U after j reactions, the current B
is at most j+1. The expected remaining number of reactions in both the
actual chain and the autonomous continuation is at most C(j+3), by the
linear-in-B estimate above. Their death counts had agreed before that
perturbation. Summing over j gives a death-count error bounded by

`(C/a) sum_{j>=0}(j+3)P(N>j)+C exp(-c'a)=O(1/a)`.

The same conditional sum bounds the expected number of extra U reactions
by O(1/a), and inputs by O(1/a^3) plus an exponentially small term. All
reactions after rare low-A feedback are included in these estimates.
Consequently the full excursion's expected pair deaths equal
`h(beta)+O(1/a)`.

At every pre-death state, including the final reaction of the excursion,
the D1 marking fraction is exactly q. Predictable inclusion of reaction
indices therefore gives `E D1=q E D` despite the feedback and stopping.
The actual cycle increment after a U start is

`1+(number of extra U)+2(number of I)-(number of D1)`.

Its expectation is `1-q h(beta)+O(1/a)`. A first input at the axis has
probability `k0/[k0+k1a(a-1)]=O(a^-2)` and increment two, so including that
case proves the claimed full-kernel drift asymptotic.

This calculation is not a frozen-A approximation. The autonomous chain
supplies a coupled reference law, with the actual feedback error bounded
by full-chain return estimates.

## 4. Positive drift gives almost-sure finite-time explosion

If mu>0, choose a finite R so the full axis drift is at least mu/2 whenever
a>=R. Uniform exponential increment moments give a theta>0 for which the
exponential-supermartingale escape argument applies to the axis chain
stopped upon entering a<R. From every sufficiently large axis state, the
probability of never entering that finite set is bounded below by a fixed
positive constant. Explicitly its ruin probability is at most
`exp[-theta(a-R+1)]`.

On survival the martingale strong law gives axis A at least a positive
constant times its cycle index n. The uniform reaction-count tail and
Borel-Cantelli give N_n=O(log n). Throughout a late cycle its A coordinate
is at least its initial A minus N_n, and is therefore also of order n.
The initial axis rate is at least `k1(a)_2`, and every post-initial
positive-B rate is at least `k2(a)_3 b`. Hence the sum of reciprocal rates
in cycle n is bounded by `C/n^2+C N_n/n^3`, summable over all cycles.
Independent exponential holding variables therefore accumulate finite
physical time almost surely on this positive-probability escape event.

Failures return to a finite axis state after finitely many reactions.
From the finitely many axis states below R, a finite prescribed input word
reaches a large axis with a uniform positive probability; if it fails,
global axis return recovers another trial after finitely many reactions.
Every renewed trial has a uniform positive conditional success probability.
Repeated failures have probability at most `(1-delta)^j`. A successful
finite-time explosive episode therefore occurs almost surely from every
finite initial state. This is the same exact renewal method as the earlier
almost-sure reports, with the newly proved full-kernel drift in place of
the conservative death budget.

## 5. Negative drift prevents explosion

If mu<0, choose a finite R and epsilon>0 so the full axis drift is at most
-epsilon for a>R. Stop the axis chain at its first entrance into `[2,R]`.
The nonnegative stopped A-coordinate and conditional drift inequality give
an expected hitting index at most a/epsilon. Thus it hits that finite set
almost surely from every finite axis population.

After any visit, the next cycle again ends at a finite axis state almost
surely; if it leaves the set, the same argument returns it. The embedded
chain consequently visits `[2,R]` infinitely often almost surely. At each
such axis visit its holding rate is at most
`Q=k0+k1R(R-1)<infinity`. Conditional on the entire embedded reaction chain,
the holding variables at those infinitely many distinct indices are
independent unit exponentials. Their total time is at least the sum of
those exponentials divided by Q, which diverges almost surely. Therefore
the total clock cannot explode. Initial low-A activation and off-axis
return take finitely many reactions as already proved, so the conclusion
holds from every finite initial state.

## 6. A genuine rate boundary and explicit examples

The expected births also have the representation

`2h(beta)-1=integral_0^1 exp[2beta(1-u^(1/beta))]du`.

For 0<u<1, put x=-log u. The derivative of
`beta(1-exp(-x/beta))` is
`1-(1+x/beta)exp(-x/beta)>0`. Thus h is continuous and strictly increasing.
It tends to one as beta decreases to zero, and to infinity as beta tends
to infinity, by monotone convergence to the nonintegrable function u^-2.
For every q in (0,1) there is a unique beta_c(q) with `q h(beta_c)=1`.
The two open sides of that surface have the behaviors just proved; the
surface itself is not classified here.

At beta=1, `h(1)=(exp(2)+1)/4`. Therefore the fixed rates
`(k0,k1,k2,k3,k4)=(1,1,4,3,1)` have mu>0 and almost-sure explosion, while
`(1,1,4,1,3)` have mu<0 and are nonexplosive. These conclusions follow from
the exact inequalities, not numerical trials. The former tuple lies
outside the earlier sufficient cone d>3k2.

At the original tuple beta=1/5,q=1/5, the limiting drift is approximately
0.7597704058. Independent finite rational truncations were performed by the
separate geometry worker in `work/agents/excursion_exact/`: these are
monotone lower bounds for h, numerically matching the formula. They are
diagnostics only. The analytic proof of the infinite-chain moments and
the z=-1 boundary appears above, and the transfer to the actual CTMC is
the separate coupling in Section 3.

## Provenance and remaining gate

This file was derived after reading both blind excursion and a.s. reports,
after freezing the original five-reaction witness and broad-cone versions.
Root specifically suggested the limiting functional and rare-feedback
audit interface. No independence claim is made for these exposed
extensions. No descendants were used. The minimum possible order three
or four remains unresolved; this classifies strict rate regimes of the
order-five witness rather than settling that minimum.

The next decisive action is an independent audit of the uniform exponential
return lemma, the first-perturbation coupling, and both physical-clock
arguments. In particular, the critical surface mu=0 must not be labeled
nonexplosive or explosive from this proof. External verification, formal
replay, and historical priority remain UNKNOWN.
