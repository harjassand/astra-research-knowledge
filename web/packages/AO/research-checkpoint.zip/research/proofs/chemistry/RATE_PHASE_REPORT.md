# Exact rate-phase checkpoint

Delivered 2026-10-08 11:37 UTC, within the additional twenty-five-minute
authorization. No descendants were spawned. All earlier versions and their
actual status history remain preserved.

The strongest new statement is an exact rate classification of the
order-five strongly endotactic witness, for every finite initial state and
every fixed strictly positive rate tuple. With

`d=k3+k4`, `beta=k2/d`, `q=k4/d`,

`h(beta)=[1+beta exp(2beta)(2beta)^(-beta)gamma(beta,2beta)]/2`,

the chain explodes almost surely exactly when `q h(beta)<1`, and is
nonexplosive when `q h(beta)>=1`. Here k0 is input, k1 is quadratic U, k2 is
B birth, k3 is unmarked pair death, and k4 is marked A-loss pair death. The
new proof is internally reconstructed and awaits independent argument
audit; external validation, formal replay, and priority remain UNKNOWN.

The full analytic kernel derivation is frozen in
`ORDER5_STRICT_RATE_PHASE.md`, hash
`45929c5e1b5ce9c34e06444b5f7e5594fa73e27438f6fb7f8c4725333d185b19`.
The separately versioned critical closure is
`ORDER5_EXACT_RATE_CLASSIFICATION.md`, hash
`71c3f04c967cdce715fe54dcf7d03dd762146ca878571dd1934a02c9684c5ea3`.

The occupation generating-function equation has a finite boundary at z=-1
because finite absorption reaction moments were first proved independently
of that equation. It gives the exact expected pair-death count h(beta),
not a finite diagnostic. Uniform exponential full-chain return tails and
a first-extra-U coupling then establish the actual axis kernel asymptotic
`E Delta A=1-q h(beta)+O(1/a)`, with uniformly bounded second moments.
Rare low-A feedback is charged through the full reaction-count tail; the
actual process is not replaced by a frozen-A chain.

Positive limiting drift gives linear axis escape, a finite sum of physical
holding times, and almost-sure explosion by renewed trials. For
nonpositive drift, root suggested deleting off-axis durations to form an
accelerated axis trace. Its exact rate is `k0+k1(a)_2`, its full return
kernel includes self-returns, and its axis exponential waits are independent
of that kernel. The proper function `1+a^2` has trace generator at most a
fixed multiple of itself, even when the limiting drift is zero. A localized
Foster/Gronwall proof handles marked self-events, and the original clock
is pathwise larger. Thus the critical surface is included in nonexplosion.
That idea's exposure and authorship history is explicit in the new file.

The same diagram therefore has both behaviors: `(1,1,4,3,1)` explodes almost
surely, while `(1,1,4,1,3)` is nonexplosive. At beta=1 the exact threshold
is `q=4/(exp(2)+1)`. The original integer tuple has limiting drift about
0.7597704058. Separate rational finite truncations match h numerically and
are identified only as monotone lower-bound diagnostics.

This improves the rate interface and closes its critical case. It does
not resolve minimum molecular order three/four; the candidate global
interval remains three through five. The earlier fixed-tuple direct proof
and its separate internal audits remain usable if this stronger kernel
classification fails audit. Parent has assigned a different worker to
genuinely different minimum-order mechanisms, so this worker does not
repeat the already closed single-auxiliary or shear attempts.

The next decisive gate is a fresh audit of the full-return tail, coupling,
and trace. All acquisition was bounded and primary-source provenance from
the original checkpoint is preserved. This extra phase used about
twenty-two minutes of one worker's local analysis, a small series
calculation, internal coordination, no cloud computation or experiments,
and no external messages. `RATE_PHASE_MANIFEST.json` and
`rate_phase_session.json` preserve claims and exposure history.
