# Order-seven explosive strongly endotactic network — frozen derivation

Version 1, 2026-10-08 10:08 UTC. This improves the order-eight construction by adding a source-sharing inward branch. The stochastic proof uses an accepted macrochain with uniform positive drift, rather than demanding nonnegative progress at every macrocycle. Internally reconstructed candidate; external correctness and historical priority UNKNOWN. This version is frozen before root's independent audits.

## Network, conventions and exact claim

State (a,b) in N_0^2. Fixed arbitrary constants k0,k1,k2,k3,k4>0. Falling factorial (a)_j=0 if a<j.

| reaction | vector | propensity |
|---|---|---|
| R0: 0->2A | (2,0) | k0 |
| R1: 2A->4A+B | (2,1) | k1(a)_2 |
| R2: 4A+B->5A+2B | (1,1) | k2(a)_4 b |
| R4: 4A+B->4A+2B | (0,1) | k4(a)_4 b |
| R3: 5A+2B->3A | (-2,-2) | k3(a)_5(b)_2 |

Maximum source degree is 7. Stoichiometric span is R^2, and graph is not weakly reversible. Claim: the graph is strongly endotactic, but its minimal CTMC explodes with positive probability from some sufficiently large axis state (n,0), for EVERY fixed strictly positive rate tuple. The source order-two regularity theorem and this construction would give 3<=minimal explosive endotactic order<=7; the exact minimum remains unresolved.

## Analytic geometry including all faces

Source hull is quadrilateral O=(0,0),P=(2,0),Q=(4,1),R=(5,2), with outward edge normals

    O-P: (0,-1); P-Q: (1,-2); Q-R: (1,-1); R-O: (-2,5).

At O-P projections of R0,R1 are 0,-1. At P-Q projections of R1 and Q's two arrows R2,R4 are 0,-1,-2. At Q-R projections of R2,R4,R3 are 0,-1,0. At R-O projections of R3,R0 are -6,-4. Thus every tied maximal arrow has nonpositive projection and at least one is strictly negative.

For a vertex's open normal cone, each outgoing vector has nonpositive projection against its two bounding normals, and is strictly negative at at least one bound, so it is strictly inward for any positive combination. This proves strong endotacticity for every nonzero direction. The extra R4 branch is load-bearing: without it all arrows from Q and R are neutral at (1,-1), and the lower essential source P has an outward arrow. A generic-sector-only check would wrongly accept that four-reaction order-seven graph.

## Macrocycle grammar and uniform estimates

Use L to denote either R2 or R4, and let delta(L)=1 for R2 and 0 for R4. Start at axis(n,0), n sufficiently large. Accept either grammar:

    G: R1,L1,R3                     [three events]
    H: R1,L1,L2,R3,L3,R3           [six events]

G has successive B values 0,1,2,0 and axis A increment delta1 in {0,1}. H permits a single extra L at the first B=2 state. It has successive B values 0,1,2,3,1,2,0 and axis increment

    Delta = delta1+delta2+delta3-2 in {-2,-1,0,1}.

All holding states along either word have A>=n; only the final returned axis population may be as low as n-2. No prescribed event is disabled for n>=5. The grammars give finitely many disjoint event words: two G words and eight H words. Define a_n as their total event-chain probability starting at (n,0), and define K_n(delta) as the conditional increment law given that one accepted word occurs.

There are C,N depending only on the rate tuple with, for all n>=N,

    a_n >= 1-C/n^2,
    K_n{Delta=1} >= p-O(1/n),  p=k2/(k2+k4)>0,
    K_n{Delta<0} = O(1/n),
    E_K[Delta | n] >= d>0,
    -2<=Delta<=1.

The probability estimates follow directly from ratios of exact propensities. At B=0 only R0 competes with R1, with ratio O(n^-2). At B=1 an L is desired; R3 is disabled and R1 competes at relative rate O(n^-2). Conditional on L, its type is exactly R2 with probability p and R4 with probability 1-p, because their source propensities are proportional. At the first B=2, R3 dominates and the total L relative rate is O(n^-1), while R1 is O(n^-3). The leading O(n^-1) L error is ACCEPTED. After it, the B=3 R3 choice and later B=2 R3 choice each fail with probability O(n^-1), and the intervening B=1 L choice fails with O(n^-2). Thus rejection after the permitted error is O(n^-1)*O(n^-1)=O(n^-2). All other rejections are already O(n^-2). H's total probability is O(n^-1); only H can decrease A. G gives increment one with probability p(1-O(n^-1)). Hence the uniform positive mean d may be chosen, for example, p/4 after increasing N. No independence of different rate competitions is assumed; these are finite conditional products and uniform bounds.

## Accepted-chain escape lemma, proved here

Let Z_j be the normalized chain with transition law K_n for n>=N. Below N extend it arbitrarily with deterministic +1 transitions. Choose d>0 so E[Z_{j+1}-Z_j | Z_j=n]>=d for n>=N, and jumps are in [-2,1]. Choose theta>0 so small that uniformly over such increment laws

    E[e^{-theta Delta}|n] <= 1-theta d/2 <1.

This follows by Taylor's theorem on the bounded increment interval: e^{-theta x}<=1-theta x+(theta^2/2)*4*e^{2theta}. Stop at tau=inf{j:Z_j<N}. Then e^{-theta Z_{j wedge tau}} is a nonnegative supermartingale. Starting at z0>N, optional stopping at tau wedge j and the bound Z_tau<=N-1 imply

    P(tau<infinity) <= exp[-theta(z0-(N-1))] <1.

Therefore D={tau=infinity} has positive probability. For the bounded martingale differences Delta_j-E[Delta_j|past], Azuma plus Borel–Cantelli gives M_j/j->0 almost surely (apply each rational epsilon>0). On D this yields

    Z_j >= z0+d j+o(j),

so in particular Z_j>=d j/2 eventually. This is an internal elementary proof of the required escape property; no recurrence classification theorem is imported.

## Transfer from normalized chain to real event paths

The actual accepted-word process is a sub-Markov chain with transition weights a_n K_n(delta). Its path probabilities on any finite sequence are those of Z multiplied by product a_{Z_j}. On D, the chain grows at least linearly eventually, so

    sum_j (1-a_{Z_j}) <= sum_j C/Z_j^2 <infinity,
    product_j a_{Z_j} >0,

after choosing N so a_n>=1/2. Countable continuity (or dominated convergence of the decreasing finite path weights) gives the actual probability of an infinite accepted trajectory with D as

    E_K[1_D product_{j>=0} a_{Z_j}] >0.

The strict positivity follows because D has positive normalized probability and the integrand is strictly positive on D. This step prevents treating normalization as a free or probability-one survival assumption.

## Physical clock

Along a macrocycle begun at n, all holding states have a>=n, and R1 is enabled. Hence total propensity q(a,b)>=k1 n(n-1). Each accepted macrocycle has at most six events. Its conditional expected holding time, given the complete event itinerary, is at most

    6/[k1 n(n-1)].

Holding times at successive states are independent exponentials with total rate q, independent of next reaction choices. On each accepted linearly escaping path, sum_j 6/[k1 Z_j(Z_j-1)]<infinity. Thus conditional expected total physical time is finite for that path, and the physical holding-time sum is finite almost surely. Infinitely many reaction events nevertheless occur. Integrating over the positive-probability accepted escaping event proves explosion.

## Scope, provenance and failure records

This is a counterexample to extending deterministic strongly-endotactic permanence to stochastic nonexplosion; it does not contradict any weakly reversible recurrence conjecture. No OA149/N173 assumption or unverified permanence proof is used in the explosion statement. Deterministic permanence is only a known comparator. No physical chemistry realization is claimed for these high-molecularity reactions.

Current primary frontier: Xu, arXiv:2409.05340v2, Theorem4.6 proves regularity for every order-two endotactic mass-action system; Remark4.8 reports the known order-ten example and open minimum. ArXiv revision metadata is 9May2026; HTML manuscript internal date is 24August2026 (version-date mismatch preserved). https://arxiv.org/html/2409.05340v2

Inherited mechanism: Anderson–Cappelletti–Kim–Nguyen (2020), Example3.2, known order-ten explosive source chain with summable path failures and holding times. https://doi.org/10.1016/j.spa.2020.07.012

Negative constructions retained: lowering the original final B coefficient to2 or3 without a branch fails strong/ordinary endotacticity. Proposed 0->2A->3A+B->4A+3B->3A fails at w=(2,-1): middle arrow neutral and final outward at tied maximal sources. An order-six collinear chain similarly fails on its lower-dimensional normal face. Order-seven without R4 fails at w=(1,-1); R4 repairs that exact face.

Next decisive action: independent exact all-direction geometric check and independent conditional-probability/clock audit of this frozen version. An exact arithmetic diagnostic is supplementary, not a substitute for the two proofs above. Exhaustive historical novelty and minimal-order lower bounds are UNKNOWN.
