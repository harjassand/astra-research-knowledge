# Chemistry priority check: minimum explosive order for endotactic mass-action CTMCs

**Status as of 2026-10-08:** the question is still explicitly recorded as open in Chuang Xu’s latest arXiv version, v2, revised 2026-05-09. Remark 4.8 says that Anderson–Cappelletti–Kim–Nguyen’s Example 3.2 is an explosive strongly endotactic stochastic mass-action system of order 10, and that the minimal order for an explosive endotactic stochastic mass-action system remains open. The current arXiv record has no version after v2. The source check found no later primary mathematical source that lowers the explosive endotactic upper bound. This is a bounded prior-art search, not priority clearance.

The relevant order convention is explicit in Xu, §2, p. 3: the molecularity of (y\to y'\) is \(\|y\|_1\), the sum of the **reactant/source** stoichiometric coefficients; for mass action this is also the polynomial order, and network order is the maximum over reactions. Explosion means infinitely many CTMC jumps during a finite time interval with positive probability from some initial state (Xu, §3, p. 4).

## Exact known explosive construction (source-reported, with order reconstructed)

Anderson et al., *Tier structure of strongly endotactic reaction networks*, arXiv:1808.05328v2, Example 3.2, pp. 5–6, gives

\[
0\to 2A\to 4A+B\to 6A+4B\to 3A.
\]

The source complexes have sizes \(0,2,5,10\), respectively, so the mass-action order is **10**, attained by the *source* \(6A+4B\) of the final reaction. The paper verifies strong endotacticity and proves explosion for every positive choice of the four rate constants: from an accessible state \((n,0)\), there is positive probability of repeating \(2A\to4A+B\to6A+4B\to3A\) indefinitely; each cycle raises the A-count by one, and the expected total duration is bounded by a convergent series whose leading term is \(\sum_n 1/(\kappa_{2A\to4A+B}n(n-1))\). This is an open network; the source does not assume mass conservation or a closed reaction graph.

## Lower bounds and near misses

- **No order at most 2:** Xu v2, Theorem 4.6, p. 9, proves every second-order endotactic mass-action system regular (non-explosive); it includes the lower-endotactic and strongly endotactic cases. Thus the minimum, if defined over all endotactic mass-action networks, is at least 3. The proof uses the fact that every order-2 reaction in a \(\mathbf 1\)-endotactic system cannot increase total molecule count. It does not assume a closed communicating class, a closed reaction graph, or a conservation law.
- **Order 3 is possible with only a weaker condition:** Xu v2, Example 4.11, p. 10, gives \(0\rightleftarrows S_1,\ 2S_1\to3S_1,\ 3S_2\to2S_2\), and calls it strongly \((1,1)\)-endotactic and explosive. The source orders are \(0,2,3\), so the full network has order 3. It is **not endotactic**: for \(u=e_1\), the maximal source among reactions with nonzero (u)-projection is \(2S_1\), and \(2S_1\to3S_1\) points outward. The paper proves explosion on the closed classes \(\{2,3,\ldots\}\times\{i\}\), (i=0,1,2); there \(3S_2\to2S_2\) is inactive, leaving the explosive one-dimensional subnetwork. This is a useful lower-order near miss, not a counterexample to Xu’s open question.
- **Order 2 also has non-endotactic explosive examples:** Xu v2, Example 4.10, p. 9, studies \(S_1\rightleftarrows2S_1\to3S_1\), whose source order is 2. It is explicitly not \(\mathbf 1\)-endotactic; the CTMC is explosive when \(\kappa_2>\kappa_{-2}\). This does not conflict with Theorem 4.6.
- **One-dimensional exclusion:** Wiuf–Xu, arXiv:2012.07954v3, Theorem 4.8, p. 12, proves non-explosivity on each stoichiometric compatibility class for 1D endotactic mass-action networks under H2–H5: one-dimensional stoichiometric subspace; at least one reaction in each of the two reaction-direction classes; positive integer gcd direction; and every species changes in at least one reaction. The non-explosion clause is stated for every class and does not require that the classes be closed. No conservation-law or closed-reaction-graph premise appears in H2–H5. This rules out candidates in that specified 1D regime, not higher-dimensional networks.
- **Transient is not explosive:** Xu v2, Remark 4.16, p. 11, cites a seventh-order transient strongly endotactic network. Agazzi–Mattingly’s source network is \(0\to A+B,\ 2A+B\to2A,\ 5A+2B\to3B\to2A\); its maximum source size is 7. Their paper classifies the example as transient; it does not offer it as a lower-order explosion construction. Transience alone does not lower the explosive-order upper bound.

## Strong-endotactic scope check

The order-10 construction is already strongly endotactic, so strengthening from endotactic to strong endotactic does not remove the known upper bound. Xu’s 2026 companion paper on first-order endotactic stochastic systems proves essentiality and exponential ergodicity at order 1; that is consistent with, but adds no lower-order explosive example to, the order-≤2 non-explosion result.

A possible apparent conflict is the older asiphonic strongly endotactic literature. Agazzi–Dembo–Eckmann, arXiv:1710.07240v2, Theorem 4.11, p. 12, proves a Lyapunov estimate for the **volume-scaled concentration process**: for each bounded concentration radius \(\rho\), the generator bound holds for \(\|x\|_1<\rho\) and volume \(v>e^\rho\). This is the compact-region estimate used for a large-deviation result; it is not a global non-explosion theorem for the fixed, unscaled count CTMC at arbitrarily large counts. Xu v2 Remark 3.8 also cautions that the older paper’s strong-endotactic convention is weaker/different from the one used there. These statements therefore do not contradict the order-10 fixed-count explosion example.

## Search boundary

I checked Xu v2’s version history, technical statements and examples; its cited 2018 explosion/transience sources; the primary 1D classification theorem; and the later 2026 first-order endotactic theorem. In these sources, the lowest verified explosive examples are order 3 under strong \(\mathbf 1\)-endotacticity alone but not full endotacticity, and order 10 under strong endotacticity. I found no verified example of order \(3\)–\(6\) that is fully endotactic, and no theorem ruling out all such higher-dimensional examples. Therefore the source-supported statement is: **minimum remains open in the latest located version; existing general bounds are 3 through 10, with the lower bound coming from the order-2 regularity theorem.** This does not assert novelty or priority for any proposed construction.

## Primary-source links and local copies

See [`source_manifest.json`](source_manifest.json) for version identifiers, exact page spans, provenance notes, and SHA-256 hashes. PDFs and extracted text are in [`sources/`](sources/).
