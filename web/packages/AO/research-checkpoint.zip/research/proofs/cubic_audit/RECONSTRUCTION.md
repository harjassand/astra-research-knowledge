# Exposed-argument audit: reconstructed load-bearing estimates

This is an adversarial proof audit of the named arguments, not an independent discovery. All original proof files were read before this reconstruction. No integration opinion was read. Symbols follow `no_pure_cubic_nonexplosion.md` and `both_pure_cubic_nonexplosion.md`.

## 1. The exact active-source convention

For direction (u), Xu defines the essential reactions to have (d_r\cdot u\ne0), and the essential source set consists of their reactants. An endotacticity violation is an arrow of positive projection from a source maximizing projection among those essential sources. Two facts used throughout the audited arguments follow:

* A positive arrow at an absolute maximum source score is a violation, whether other arrows at tied sources have zero or negative projection.
* If every arrow at the higher source scores has zero projection, they are omitted. One must then test the next essential score. A tied negative arrow never rescues a positive arrow at the maximum score.

These facts justify the coordinate signs, the cubic total signs, and the successive (w=(2,1)) tiers. The proofs do not use a stronger convention that keeps orthogonal arrows active.

## 2. A computable global envelope for the truncated cubic drift

Set (f(a)=(a-K)_+), with positive (p,q,r), (r<2q), and (D\ge\max_r|d_{r,A}|). For the sole cubic source ((1,2)), define

\[
g(a)=\sum_{r\text{ cubic}}k_r\{q d_{r,B}+r[f(a+d_{r,A})-f(a)]\},
\]
\[
R(a)=\sum_{r\text{ cubic}}k_r\{2pa d_{r,A}+p d_{r,A}^2+q d_{r,B}^2+2r d_{r,B}f(a+d_{r,A})\}.
\]

The exact generator, including every kink and factorial term, is

\[
\mathcal L_3V_K=a b(b-1)\,[2b g(a)+R(a)]. \tag{A}
\]

Coordinate and (w) geometry permit a positive (A) increment only for the integer vector ((1,-2)); every cubic (B) increment is nonpositive. Monotonicity and the one-Lipschitz property of (f) therefore give

\[
g(a)\le-\kappa,\qquad
\kappa=\sum k_r[q(-d_{r,B})-r\max(d_{r,A},0)]>0.
\]

Strict positivity needs (v_B<0), which is indeed proved before this lemma is used. Vectors with (d_B=0) may contribute zero to \(\kappa\); the proof does not incorrectly require every summand to be positive.

Write (C_A=pv_A+rv_B\le0), and choose \(\rho=-C_A\) when it is strict, or \(\rho=0\) otherwise. For (a\ge K+D),

\[
R(a)=2C_Aa+J(K),\quad
J(K)=\sum k_r[pd_A^2+qd_B^2+2rd_Ad_B-2rKd_B].
\]

For the remaining strip, the last term of (R(a)) is nonpositive. If

\[
B_0=\sum k_r(pd_A^2+qd_B^2),
\quad C_R=\max\{0,J(K),B_0+[2p\max(v_A,0)+\rho](K+D)\},
\]

then the explicit global envelope is

\[
R(a)\le-\rho a+C_R. \tag{B}
\]

For the outer region this follows from (R(a)+\rho a=-\rho a+J(K)\le J(K)); for the strip it follows from (a<K+D) and the preceding nonpositive term. Thus no enumeration of a potentially enormous strip is required even to make its constant concrete.

Multiplying (B) and the (g) bound by (a b(b-1)\ge0) proves

\[
\mathcal L_3V_K\le-\rho a^2b^2-2\kappa ab^3+\rho a^2b+(2\kappa+C_R)ab^2. \tag{C}
\]

This is the claimed estimate with an explicit constant. It is valid also at (b=0,1); the positive correction is sufficient to cancel the displayed negative terms there. At (a=0) the whole expression vanishes. Reaction increments need only be evaluated physically at enabled states; polynomial or positive-part extensions at disabled states are harmless because their propensity is zero.

## 3. The dangerous quadratic source and why the cutoff works

At source (2B), (d_A\ge0,d_B\le0). If (a\le K-D), both (f(a)) and (f(a+d_A)) vanish, so the coefficient proportional to (b) in the increment is nonpositive. Everywhere else that coefficient is at most (q d_B+r d_A). Moreover,

\[
2pa d_A+p d_A^2+q d_B^2+2r d_Bf(a+d_A)
\le2pa d_A+p d_A^2+q d_B^2.
\]

Consequently

\[
\mathcal L_{2B}V_K\le T_B b^3\mathbf1_{a>K-D}+
\left[2pj_Aa+\sum_{r:2B}k_r(pd_A^2+qd_B^2)\right]b^2,
\]

with the original (T_B=2\sum_{r:2B}k_r\max(qd_B+rd_A,0)), independent of (K). The prescribed (K>D+T_B/\kappa+1) guarantees (T_B\mathbf1_{a>K-D}\le\kappa a). Large product jumps change (D,T_B,K), but do not leave an unpaid (b^3) term.

This addresses a real failure of the untruncated alternative. For the allowed arrow (2B\to MA+2B), (M>0), an untruncated cross term (2rab) produces at (a=0)

\[
k\,b(b-1)[pM^2+2rMb],
\]

whose positive (b^3) term cannot be bounded by a constant times (1+V(0,b)). The exact stress networks below are fully endotactic despite this large jump. The cutoff is necessary for this proposed cross-term mechanism.

## 4. All other remainders have the claimed degree

Outside the strip the aggregate increment at (2A) is (2H_Aa+2H_Bb+J_h(K)). Multiplication by (a(a-1)) leaves, after (2H_Aa^3+2H_Ba^2b), only

\[
-2H_Aa^2-2H_Bab+J_h(K)a^2-J_h(K)a.
\]

At (A+B) it leaves only (J_z(K)ab) after the displayed leading terms. These have a global quadratic bound. In the finite-(a) strip, each exact increment is affine in (b); the (2A) rate is bounded and the (A+B) rate is affine in (b). Subtracting the claimed leading terms still leaves a finite constant times (1+b^2). This establishes the original global quadratic remainder; it does not assume differentiability across the kink.

For sources of order at most one, Lipschitzness of (f), (f(a+d_A)\le a+|d_A|), and fixed finite jump sizes imply (|\Delta V_K|\le C(1+a+b)). Their rates have the same bound, giving a quadratic generator bound. This covers arbitrarily large finite products of those sources.

## 5. Degenerate aggregates and the exhaustive no-pure classification

The no-pure possibilities are no cubic source, two mixed cubic sources, or one mixed cubic source. Swapping species covers the second one-source orientation. No pure-source case is smuggled into this classification.

For the one-source case, (v_A<0) supplies a negative (a^2b^2) coefficient with the diagonal function. Otherwise (v_A\ge0,v_B<0), and the remaining exhaustive tiers are:

* (G=2v_A+v_B<0): the chosen positive perturbation of (p=2) makes (C_A<0), while (H_A=H+\delta h_A\le0). Regime I applies.
* (G=0,H<0): positivity of all constants and the individual \(w\)-signs force every cubic arrow to be ((1,-2)). With (p=2,q=r=1), (C_A=0,H_A<0). The negative (a^3) coefficient pays for (a^2b), after which (ab^3) pays for (ab^2). Regime II applies.
* (G=H=0,Z<0): both upper source tiers are exactly orthogonal to (w), so the (A+B) arrows must have individual nonpositive (w)-projection. The supplied \(\epsilon\) gives (H_B+Z_A\le3Z/2<0) and (Z_B\le Z/2<0). The combined quadratic leading term is nonpositive. Regime III applies.
* (G=H=Z=0): each arrow in all three preceding tiers is orthogonal. A positive (w)-arrow at (2B) has an essential source of score two, and no remaining source can have a higher score. Even if a linear source ties it at score two, positivity at the maximum remains a violation. Thus all sources of order at least two have nonpositive (w)-drift, and the positive linear weight suffices.

If a lower source is absent its aggregate is zero, which does not invalidate any implication. Equalities of signed aggregates force individual equalities because the rate constants are strictly positive; this is not true for arbitrary cancelling projections, but all projections involved here already have the same sign.

The two-mixed dependency was read and checked separately. Its three branches \(\alpha>0,\beta>0\), \(\alpha=0\), and \(\alpha>0,\beta=0\) exhaust the aggregates, including both zero. The strict \(\eta\) in the first branch follows only after taking out the all-cubic-conservative case. Its exact factorial expansion and two global Young inequalities are valid on the axes and the (0,1) strips.

## 6. Both-pure coercivity and an explicit exact remainder constant

For both pure sources, total-direction endotacticity makes every cubic product have total degree at most three. Every nontrivial pure arrow therefore has a strictly negative own-coordinate increment; \(\alpha_A,\alpha_B>0\) follows for every fixed positive rate vector.

Write (m_i(t)=(1-t)^it^{3-i}). On \([0,1]\), \(|m_i|\le1\) and \(|m_i'|\le3\). For (\ell,h,S\) in the original proof this yields

\[
\ell\ge0,\quad |h|\le2S,\quad |h'|\le8S,\quad h(0)=-2\alpha_A,\quad h(1)=-2\alpha_B.
\]

The original \(\delta\) thus gives (h\le-\alpha_{\min}) in both closed collars. Any strictly lossy cubic reaction has monomial at least \(\delta^3\) throughout the closed middle interval, so \(\ell\ge\ell_0>0\) there. Since \(\epsilon H\le\ell_0\), the actual leading homogeneous generator satisfies

\[
\mathcal L_3^{\mathrm{lead}}V\le-c(a+b)^4,\qquad
c=\min(\ell_0,\epsilon\alpha_{\min})>0
\]

at every angle. The constants are uniform over states for each fixed reaction/rate vector. They are not uniform over all positive rate ratios, nor is that claimed.

An explicit bound makes the boundary correction particularly transparent. For every degree-three source at an integer state, with (N=a+b),

\[
|x^{\underline y}-x^y|\le5N^2,\quad x^{\underline y}\le N^3.
\]

This follows directly from the four factorial identities listed in the original proof, including disabled states (0,1,2). For \(\epsilon\le1\) and \(D_r=|d_{r,A}|+|d_{r,B}|\), the linear increment has absolute value at most \(4D_rN\), and its constant part at most \(2D_r^2\). Hence

\[
|\mathcal L_3V-\mathcal L_3^{\mathrm{lead}}V|
\le C_3N^3,\qquad C_3=\sum_{r\text{ cubic}}k_r(20D_r+2D_r^2).
\]

Every quadratic source similarly has absolute generator contribution at most (k_r(4D_r+2D_r^2)N^3) for (N\ge1), and zero for (N=0). Order-zero and order-one sources have a quadratic bound. Thus the original global (-cN^4+C(1+N^3)) estimate is valid without any boundary activation premise. Maximization gives exactly (27C^4/(256c^3)).

## 7. Foster conclusion

With \(W=1+V\), choose finite (C\ge0\) such that \(\mathcal LW\le CW\). Its sublevel sets in \(\mathbb N_0^2\) are finite. Before exiting one, the total rate is bounded; the set of possible first-exit states is also finite because there are finitely many fixed jump vectors. Thus the stopped process permits Dynkin and Gronwall without an integrability assumption on the un-stopped process:

\[
\mathbb E W(X_{t\wedge\tau_M})\le W(X_0)e^{Ct},\qquad
\Pr(\tau_M\le t)\le W(X_0)e^{Ct}/M.
\]

Explosion would require exit from every finite sublevel, because bounded total rate rules out infinitely many jumps within one in finite time. Sending (M\to\infty\) and then taking a countable union over integer (t\) proves nonexplosion. No irreducibility, stationarity, weak reversibility, or asiphonicity is needed. This matches Xu Proposition 3.5.
