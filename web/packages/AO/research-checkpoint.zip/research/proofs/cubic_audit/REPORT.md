# Both cubic target proofs pass this internal adversarial audit

**Verdict:** no counterexample, invalid geometric implication, missing sign, unpaid boundary term, or missing Foster hypothesis was found in either frozen target. The load-bearing estimates were reconstructed algebraically, including the discrete kink and disabled reactions. No substantive repair to either proof is required on this audit. This is an exposed-argument audit, not an independent derivation, a formal verification, an external review, or a novelty determination.

The audited conclusions are precisely:

1. Every finite fully endotactic stochastic mass-action network on two species with source order at most three and **neither** pure cubic source has a nonexplosive minimal CTMC for each fixed finite strictly positive rate vector and each finite initial state.
2. With **both** pure cubic sources present as sources of nontrivial arrows, the same conclusion holds assuming only total-direction endotacticity. Mixed cubic sources may be present or absent.

The exactly-one-pure-source class was not audited or solved. All constants in these arguments may depend on the network and its rate vector; no uniform bound over arbitrarily small positive rate constants is asserted. Product complexes at sources of order at most two may have arbitrary fixed finite sizes.

## Frozen inputs and source reconstruction

The entire 190-line no-pure proof and 132-line both-pure proof were read, together with the entire 190-line mixed-cubic dependency. Original inputs were preserved and their hashes verified before the verdict. Source details and final audit artifact hashes are in `MANIFEST.json`.

| Input | SHA-256 |
|---|---|
| `work/agents/chem_explosion_blind/phase2/no_pure_cubic_nonexplosion.md` | `d4f65969734a309df3fba2c227891ace65e7d7e8dd431cf69f7bc401c78f6c2d` |
| `work/agents/chem_explosion_blind/phase2/both_pure_cubic_nonexplosion.md` | `75c1dfe4a59b321eb14cb203edc65de662ce52c2502248e900e748f7e5bb3ab9` |
| `work/agents/chem_explosion_blind/phase2/mixed_cubic_nonexplosion.md` | `e7eb9b83091ba3577ac14b376c47e27a2a530075d8280929727cd968839110ae` |

[Xu, arXiv:2409.05340v2](https://arxiv.org/html/2409.05340v2), was downloaded from the primary versioned source. The saved HTML and extracted text are in `sources/`. The text preserves MathML `alttext` formulas. Relevant exact locations in the saved text are:

* Lines 45–68: falling factorials, reaction complexes, stochastic mass-action kinetics, and source molecularity/order.
* Lines 72–80: the exact generator, local existence, and explosion convention.
* Lines 112–119: Proposition 3.5, the nonnegative norm-like Foster criterion.
* Lines 206–218: Definitions 4.1–4.4, particularly omission of arrows orthogonal to the tested direction when forming the essential source set.
* Lines 261–271: Example 4.11, which demonstrates that total-direction endotacticity alone is insufficient for general cubic networks. It has only one pure cubic **source**, and therefore is outside both target classes; its cubic product does not count as another source.

An attempted download of the original Meyn–Tweedie 1993 paper from the author's University of Florida archive returned HTTP 500. The exact criterion was verified from Xu Proposition 3.5 and its discrete stopping argument reconstructed directly, so this failed retrieval leaves no unresolved mathematical premise in the present audit. Broader literature priority was not investigated during this bounded audit.

## What the adversarial reconstruction established

`RECONSTRUCTION.md` records the mathematical checks, rather than relying on the finite diagnostics:

* **Essential-source signs and ties.** A positive arrow from a source tied for the maximum essential score is forbidden even if another tied arrow is negative. When an entire higher tier is orthogonal, it really is omitted. This validates the coordinate bounds and the successive (G,H,Z) zero-projection cases.
* **Only possible positive-(A) cubic vector.** Total-direction geometry bounds cubic products to degree three; the coordinate and (w=(2,1)) signs then leave only ((1,-2)). The strict \(\kappa>0\) uses the already-established (v_B<0), not an unjustified strict sign for every summand.
* **The kink is accounted for exactly.** The cubic generator is (a b(b-1)[2b g(a)+R(a)]), with (g(a)\le-\kappa). An explicit finite envelope for (R(a)) gives the claimed global bound. It includes all cutoff crossings and the (b=0,1) factorial corrections.
* **Arbitrarily large quadratic products are paid for.** At source (2B), the dangerous coefficient of (b^3) vanishes for (a\le K-D); beyond that strip the chosen (K) guarantees (T_B\le\kappa a). This establishes the central interface that an ordinary untruncated cross term fails on the (B) axis.
* **The remaining degrees are correct.** The (2A) and (A+B) leading terms have only quadratic remainders outside the strip, and bounded-(a) strip corrections also have at most quadratic growth in (b). Lower-order reaction increments and rates yield at most quadratic growth globally.
* **Degenerate aggregates are covered.** The no-pure classification and all (G,H,Z) tiers are exhaustive. The mixed dependency's \(\alpha=0\), \(\beta=0\), and both-positive cases are valid, including both zero. Its all-cubic-conservative case is handled before strict coercivity is invoked.
* **Both-pure coercivity is uniform over states.** The pure-axis losses are strictly positive. The supplied derivative bound makes the two axis collars negative; any cubic total loss gives a positive loss bound over the closed middle interval. Choosing the stated positive perturbation gives a negative quartic term at every angle.
* **Disabled cubic reactions are included.** An explicit exact remainder constant (C_3=\sum_{r\text{ cubic}}k_r(20D_r+2D_r^2)), with (D_r=|d_{r,A}|+|d_{r,B}|), bounds the difference between the actual and leading cubic generator by (C_3N^3). Thus the negative quartic dominates all quadratic-source and discrete corrections, including coordinates zero, one, or two.
* **Foster applies to the minimal process.** Finite sublevels have bounded rate, and their possible first-exit states are finite because the reaction set and jump vectors are finite. Stopped Dynkin–Gronwall proves the required exit probability bound without assuming moments of the un-stopped chain. No irreducibility or boundary activation premise is needed.

## Exact finite challenges

`python3 work/agents/cubic_audit/exact_checks.py` passed. The script uses Python `Fraction` throughout. Its complete two-dimensional direction-fan check uses every source-order and jump-sign wall, plus representatives of every open sector, to verify that the three named cutoff stress networks are fully endotactic.

The three stress networks exercise Regimes I, II, and III, use products with 1,000 molecules, and include rate ratios as large as (10^{12}). There are 252 checked state pairs, including (a=0,1,2), both sides of (K-D), the kink (K), the outer edge (K+D), and large states. The largest cutoff is

`8000004004004002000001001002`.

All exact increment identities, cubic bounds, (2B) bounds, and payments by \(\kappa ab^3\) passed. This enormous cutoff illustrates parameter dependence; no claim of an efficient population simulation is made.

Two both-pure stress networks use conservative pure transfers, a small mixed cubic loss, and large lower-order products. They passed 270 exact angle checks, including the tiny collar endpoints, and 98 exact state checks, including disabled populations and large states. One uses pure-source rate constants (10^{-12}) and (10^{12}); its derived quartic coefficient remains strictly positive as a rational number.

Seven additional geometry controls cover a diagonal single-mixed case, all-zero (w) tiers, the two degenerate mixed aggregate cases, conservative mixed and pure cubic cases, and no cubic source. Xu Example 4.11 was also reconstructed: it passes total-direction endotacticity and fails full endotacticity in direction ((1,0)), as required. Results are saved in `exact_checks.json` and `exact_checks.stdout.txt`.

These finite checks are diagnostics and reproducible failure attempts. The universal verdict rests on the reconstructed inequalities, not extrapolation from a grid.

## Remaining status

Both target implications are internally audited as valid under their exact hypotheses. Exactly one pure cubic source, formal replay, external expert validation, and novelty/priority remain outside this result. No integration opinion was read before this report and its companion reconstruction were frozen. No descendants were used and no original proof file was changed.
