# Exact rate classification: target-only reconstruction

**Status:** complete internal reconstruction, frozen before reading chemistry's strict phase or exact-classification reports. The supplied classification is correct, including its critical equality. The lower incomplete gamma formula is derived from the exact pure-B chain. The full-network feedback is controlled by an exact Poisson-budget identity, not by assuming A is frozen.

## Statement

The five jumps and rates are

`I:(+2,0), k0`,

`U:(+1,+1), k1(a)_2`,

`V:(0,+1), k2(a)_3 b`,

`D0:(0,-2), k3(a)_3(b)_2`,

`D1:(-1,-2), k4(a)_3(b)_2`.

All coefficients are fixed, finite and strictly positive. Let

`d=k3+k4`, `beta=k2/d`, `q=k4/d`,

`gamma_low(beta,x)=integral_0^x t^(beta-1)exp(-t) dt`,

`h(beta)=[1+beta exp(2beta)(2beta)^(-beta)gamma_low(beta,2beta)]/2`,

and `mu=1-q h(beta)`.

**Theorem.** From every finite initial state, the minimal CTMC explodes almost surely if `mu>0`, and is nonexplosive almost surely if `mu<=0`.

The critical boundary does not require a recurrence classification of the embedded A-chain. Its finite-A drift is allowed to have either sign at order `1/a`; that order still rules out a finite physical lifetime.

## 1. Uniform full-axis excursion tails

The exact full network hits B=0 after finitely many full reactions almost surely from every finite state. We need the following stronger estimate for excursions starting at `(a,1)` with `a>=3`:

`P(N>n | a,1)<=C exp(-c n)`,

with fixed positive C,c uniform in a. Here N counts all full reactions, including all neutral inputs and all low-A resets.

### Macro steps

At a=0 or1, I reaches a>=2. At a=2, I or U reaches a>=3 and adds at most one B. After A first reaches 2, it cannot fall below 2. From an active state a>=3,b>0, ignore I until a B-changing reaction; stop immediately if B reaches zero. Otherwise, if D1 reaches a=2, include the next I or U reaction restoring a>=3.

Every macro birth has B increment +1. Every macro pair death has increment -2 or -1, except a death from b=2, which stops at 0 before any reset. Inputs at active positive-B states have probability at most `z=k0/(k0+6k2)<1`, so their runs are uniformly geometrically bounded. The macro birth probability is at most

`pbar_b=(k2 b+k1)/(k2 b+k1+d b(b-1))` for b>=2.

This follows by averaging the exact B-changing probability with `k1/(a-2)<=k1` over the finite input run. The unmarked-death probability is at least

`eb=k3 b(b-1)/(k2 b+k1+d b(b-1))`.

Choose M>=2 so that pbar_b<=1/4 for all b>M. Outside K={0,...,M}, macro B drift is at most -1/2. Stopping and truncating the nonnegative B-coordinate shows that the macro hitting time of K has expectation at most 2b from starting b.

Inside K\{0}, a word of unmarked deaths, with the mandatory birth 1->2 when needed to repair parity, reaches 0 in at most L=M+2 macro steps. Its conditional probability is at least `epsilon=(min_(2<=b<=M)eb)^L>0`, uniformly over A and the past. A failed L-step block ends at b<=M+L. Returning to K and retrying gives almost-sure absorption at zero, with finite expected macro count. This proves the preliminary global axis-return assertion without assuming nonexplosion.

More quantitatively, the expected macro count from active initial B=b is at most `2b+[L+2(M+L)]/epsilon`. The conditional expected full reaction count per macro is at most `1/(1-z)+1`. Thus its expected full reaction count is bounded by a constant times `1+b`, uniformly over A. The at-most-two initial low-A activation jumps preserve this linear bound.

### Exponential macro and full-reaction bounds

Outside K, because a death decreases B by at least one,

`E[2^(B_next) | macro history] <= [2pbar_b+(1-pbar_b)/2]2^b <= (7/8)2^b`.

Kill this function on entry to K. For a return beginning at b<=M+L, its macro hitting time tau has the uniform tail

`P(tau>n)<=C0(7/8)^n`, with `C0=2^(L-1)`.

Thus, for sufficiently small lambda>0,

`sup E[exp(lambda tau)]-1 <= D(lambda)=C0(exp(lambda)-1)/[1-(7/8)exp(lambda)]`,

and D(lambda) tends to zero as lambda tends to zero. A failed compact block plus its return consequently satisfies

`E[exp(lambda(L+tau))1_failure | starting compact history]`

`<=exp(lambda L)[1-epsilon+D(lambda)]`.

Choose lambda>0 so small that the latter bound is r<1. Iterating over successive failed blocks and summing over the final successful block bounds the macro absorption-time exponential moment by `exp(lambda L)/(1-r)`, uniformly over active starting A and starting B in K. In particular it applies at B=1.

If G_i is the full reaction count in macro step i, then `G_i<=J_i+2`, where J_i is its preceding input count. For small eta>0,

`E[exp(eta G_i) | pre-macro history] <= K_eta=exp(2eta)(1-z)/(1-z exp(eta))`.

After absorption extend the macro sequence with G_i=0. For m macros, iterated conditioning gives `E exp(eta sum_(i<=m)G_i)<=K_eta^m`. For m=floor(t n), with fixed sufficiently small t>0 satisfying `t log(K_eta)<eta/2`,

`P(N>n)<=P(macro absorption time>m)+exp(-eta n)K_eta^m`.

Both terms have an exponential tail. This proves the claimed uniform complete-reaction bound. In particular, all fixed moments of N are bounded uniformly over starting A.

The same Foster/block argument for the pure B chain below, with no input and no A resets, gives a uniform exponential jump-count tail from B=1, and an expected jump-count bound `C_beta(1+b)` from arbitrary initial b. The unmarked path can there be taken to be any pair-death path.

## 2. Derive h exactly from the pure B chain

Consider the absorbing continuous-time chain Z with birth rate beta*b, pair-death rate b(b-1), and jumps +1,-2. It starts at 1 and stops at its first hit of 0. Let D and C count its pair deaths and births. Let `u_b=E_1[integral_0^tau 1_(Z_t=b) dt]`, and `F(x)=sum_(b>=1)u_b x^b`.

The preceding jump-count bounds show all required expectations are finite. In particular,

`sum b^2 u_b <= C_beta E_1[jump count]<infinity`,

because `b^2/[beta b+b(b-1)]` is uniformly bounded for b>=1. Thus F' and F'' are continuous on [-1,1], with finite F'(-1).

Apply stopped Dynkin to x^b for -1<x<1. Its terminal value is 1 and initial value x, yielding

`1-x=beta x(x-1)F'(x)+(1-x^2)F''(x)`.

Consequently, for Y=F',

`(1+x)Y'(x)-beta xY(x)=1`.

An integrating factor is `m(x)=exp(-beta x)(1+x)^beta`. Since Y(-1) is finite and beta>0, `m(x)Y(x)->0` as x decreases to -1. Therefore

`m(x)Y(x)=integral_(-1)^x exp(-beta t)(1+t)^(beta-1) dt`.

At x=1 this gives

`F'(1)=exp(2beta)(2beta)^(-beta)gamma_low(beta,2beta)`.

Compensating the birth count gives `EC=beta F'(1)`. The pathwise population balance at absorption is `0=1+C-2D`, so

`ED=(1+EC)/2=h(beta)`.

This proves the supplied special-function expression as an exact expected reaction count. The calculation does not approximate the full network.

## 3. Exact feedback identity in the full network

Let `g(b)=E_b[D]` for the pure B chain, with g(0)=0. Its expected jump-count bound gives

`0<=g(b)<=C(1+b)`.

Its exact first-step equation is

`beta b[g(b+1)-g(b)]+b(b-1)[g(b-2)-g(b)]=-b(b-1)`.

At b=1 the pair-death term is omitted, and the equation reads g(2)=g(1); no value g(-1) is used.

Now start a full-network B excursion at `(a+1,1)`, immediately after an axis U reaction from `(a,0)`. Stop only at B=0; low-A resets and every input are included. Let D_full denote its pair-death count and U_int,I_int its internal U and I counts.

At every pre-reaction state `(A,B)`, even at A=2, the conditional increment identity is

`E[g(B_next)-g(B) | (A,B)]`

`=-P(next reaction is a pair death | A,B)`

`+P(next reaction is U | A,B)[g(B+1)-g(B)]`.

Indeed multiplying the pure-B equation by `d(A)_3` accounts exactly for V,D0,D1. The extra U is the only remaining B-changing reaction; I has zero effect on g. When A=2 the common multiplier is zero, and the identity still holds.

Sum this identity to the axis return. Its optional-stopping and integrability obligations follow from the uniform full-reaction exponential tail, `B_j<=1+j`, and the linear bound on g. Terminal g is zero and initial g is h. Hence the following identity is exact:

`E D_full = h(beta)+E sum_(internal U jumps)[g(B+1)-g(B)]`.

The marked death conditional probability is always q; summing predictable pre-reaction probabilities, including the final reaction, gives `E D1_full=q E D_full`. Therefore the conditional expected A increment for a cycle whose first reaction was U is

`m_U(a)=mu+E sum_(internal U jumps)[1-q(g(B+1)-g(B))]+2E I_int`.

This is the full-network feedback formula, with no frozen-A approximation.

### Quantitative error bound

For a sufficiently large starting axis a, in any excursion state with A>=a/2,

`P(U | A,B)<=k1/[k2(A-2)B]<=C/a`,

and `P(I | A,B)<=C/a^3`, because B>=1. The linear g bound gives `|g(B+1)-g(B)|<=C(1+B)`. All these weights are determined before the next reaction. Since B_j<=1+j and the complete excursion count N has uniformly bounded moments, summing their conditional probabilities gives an O(1/a) bound for the absolute internal-U correction.

States with A<a/2 require at least a/2 downward full reactions from the starting A=a+1. They thus lie on `{N>=a/2}`. Their contribution is bounded by a constant times `E[N^2 1_(N>=a/2)]`, exponentially small in a by the uniform tail. The same reasoning controls the input count. Consequently

`m_U(a)=mu+O(1/a)`.

At an axis state `(a,0)`, the initial I probability is `k0/[k0+k1a(a-1)]=O(1/a^2)` and its A increment is 2. Combining the two initial reaction types proves for the exact full-axis return chain

`m(a)=E[A_next-a | A_axis=a]=mu+O(1/a)`.

All constants are uniform in sufficiently large a and may depend on the fixed rate tuple. Cycle increments Delta also obey `|Delta|<=2(N+1)` and have a uniform exponential moment over all axis a>=2. This establishes the two exact estimates needed for every sign of mu.

## 4. Positive mu implies almost-sure explosion

Choose an integer R>=3 such that m(a)>=mu/2 for all a>=R. Run full-axis return cycles, stopping the axis chain at its first axis state below R. Uniform exponential increment moments give a fixed theta>0 with

`E[exp(-theta Delta) | axis a>=R] <=1-theta mu/4<1`.

Thus the exponential supermartingale gives positive no-ruin probability at least `1-exp[-theta(a-R+1)]` from every a>=R. Overshoot below R causes no problem: at ruin `exp(-theta A)>=exp[-theta(R-1)]`.

On no ruin, the martingale-difference strong law and the positive conditional drift give linear growth of axis A. Borel-Cantelli and the uniform excursion tail give N_n=O(log n). Within-cycle A is at least A_n-N_n, hence eventually grows linearly too. Axis rates are at least k1(a)_2 and positive-B rates at least k2(a)_3 B. The sum of reciprocal holding rates is consequently finite, with per-cycle bound `C/n^2+C N_n/n^3`. Conditional independent exponential clocks imply finite explosion time almost surely on no ruin.

Failed high-axis episodes return below R after finitely many complete cycles, each almost surely finite. They end on the axis. From each low axis state 2<=a<R, a finite consecutive-input word reaches a>=R with uniform probability at least p^J, where

`p=k0/[k0+k1(R-1)(R-2)]>0`, `J=ceil((R-2)/2)`.

If U interrupts the boost, return to the axis using the global excursion lemma. Every renewed trial therefore has conditional success probability at least `p^J(1-exp(-theta))>0`, and every failure and recovery takes finite physical time. Geometric conditional retry bounds imply almost-sure eventual success. Initial a=0 or1 is brought to a>=2 by an input, and positive initial B is cleared by the global lemma. Thus explosion is almost sure from every finite state.

## 5. Nonpositive mu, including equality, implies nonexplosion

After initialization, denote the infinite exact embedded axis chain by A_n>=2 and its cycle filtration by H_n. Set

`X_n=log A_n`, `xi_n=X_(n+1)-X_n`.

Concavity gives the global inequality `xi_n<=Delta_n/A_n`. With `m(a)=mu+O(1/a)` and mu<=0, there is a finite C such that

`E[xi_n | H_n]<=C/A_n^2`

for every A_n>=2, enlarging C to cover the finitely many small states.

Also

`E[xi_n^2 | H_n]<=C/A_n^2`.

For `|Delta|<=a/2`, use `|log(1+Delta/a)|<=2|Delta|/a` and the uniform second moment. Positive Delta obeys `log(1+Delta/a)<=Delta/a` without restriction. On the remaining negative tail, A_next>=2 gives `|xi|<=log a`, while the uniform increment exponential tail makes `(log a)^2 P(Delta<-a/2)` at most C/a^2. This proves the displayed second-moment bound.

Write `M_n=sum_(j<n)(xi_j-E[xi_j|H_j])`. Suppose the event

`S={sum_n 1/A_n^2<infinity}`

occurs. Then A_n tends to infinity, since any bounded subsequence would contribute infinitely many terms bounded away from zero. On S, the conditional quadratic-variation sum of M is finite, and M_n converges almost surely. This martingale convergence statement follows by localization: stop when the accumulated conditional variance first exceeds an integer v; stopped total expected squared increments are bounded by v plus a uniform single-increment bound, so the stopped martingale converges in L2 and almost surely. On finite total conditional variance, some such localization never stops.

On S the predictable positive drift is summable by the bound C/A_n^2. Thus

`X_n <=X_0+M_n+C sum_(j<n)1/A_j^2`

has a finite almost-sure upper bound, contradicting `X_n=log A_n ->infinity`. Therefore

`sum_n 1/A_n^2=infinity` almost surely.

At the initial axis state of cycle n, the total rate is exactly `Q_n=k0+k1 A_n(A_n-1)`. For A_n>=2, its reciprocal is bounded above and below by positive fixed multiples of `1/A_n^2`. Hence

`sum_n 1/Q_n=infinity` almost surely.

Conditional on the entire embedded reaction chain, these axis holding times are independent unit exponentials divided by Q_n. Their sum diverges almost surely. One direct proof uses their Laplace transform: for s>0 the N-term transform is `product_(n<N)(1+s/Q_n)^(-1)`, which tends to zero because `1/Q_n<=1/k0` and the reciprocal-rate sum diverges. The infinite nonnegative sum therefore has Laplace transform zero and is infinite almost surely.

All axis returns use finitely many full reactions almost surely. There are infinitely many such cycles in the embedded chain. The divergent sum of their axis holding times forces the CTMC lifetime to be infinite. This proves nonexplosion for mu<0 and for the exact critical equality mu=0.

## Provenance and remaining status

Only the exact target formula and the already established global-axis/open-cone methods were supplied. No chemistry strict-phase or exact-classification report was read before this reconstruction was frozen. The special-function identity, exact full-network Poisson budget, finite-feedback O(1/a) estimate, and critical logarithmic martingale argument were reconstructed here. Previous open-cone work used shared Foster/renewal hints; no claim that this target itself was newly discovered blindly is made.

The mathematical argument is complete internally. Remaining gates are an adversarial audit of the uniform exponential-axis-excursion lemma, the exact feedback identity and its weighted error bound, and the localized critical log-martingale step. External proof validation, formal replay, geometric strong-endotacticity, and novelty remain UNKNOWN.
