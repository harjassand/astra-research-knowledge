# Exact directional geometry check

## Result

For the frozen network

\[
(0,0)\to(2,0),\quad (2,0)\to(4,1),\quad
(4,1)\to(5,3),\quad (5,3)\to(3,0),
\]

the exact check finds it **endotactic and strongly endotactic in every nonzero direction** under Xu, arXiv:2409.05340v2, Definitions 4.2–4.4. No failure direction exists. The largest reactant molecularity is \(\|(5,3)\|_1=8\).

The nonzero-direction convention matters: Xu’s Definition 4.4 says “every \(u\in\mathbb R^d\),” while the strong part of Definition 4.2 asks for a strictly decreasing reaction. At \(u=0\), no reaction is strictly decreasing, so a literal inclusion of the zero vector would make strong endotacticity impossible for every network. The result above checks all actual directions, including all exceptional boundary rays and ties.

## Definitions encoded

For a direction \(u\), let \(q_i=(y_i'-y_i)\cdot u\), and let \(s_i=y_i\cdot u\) be the source score. Following Definitions 4.1–4.4 in the primary source:

- The active source set for endotacticity contains exactly reactants with \(q_i\ne0\). Endotacticity fails precisely when an active source maximizing \(s_i\) has \(q_i>0\). Tied maxima are all checked.
- Strong endotacticity additionally requires at least one reactant maximizing \(s_i\) over **all** reactants whose outgoing reaction has \(q_i<0\). Thus a zero-projection reaction is excluded from the first maximum but its reactant remains in the second maximum.

For \(u=(a,b)\), the four source scores and reaction projections are

\[
(s_0,s_1,s_2,s_3)=(0,2a,4a+b,5a+3b),\qquad
(q_0,q_1,q_2,q_3)=(2a,2a+b,a+2b,-2a-3b).
\]

Every comparison used by either definition is determined by signs of the four \(q_i\) and pairwise differences among the four \(s_i\). Their zero sets yield exactly these seven critical lines:

\[
a=0,\quad 4a+b=0,\quad 2a+b=0,\quad 5a+3b=0,
\quad a+b=0,\quad 2a+3b=0,\quad a+2b=0.
\]

They cut the direction circle into 14 rays and 14 open sectors. The checker evaluates each boundary ray as its own integer vector, then one exact integer vector strictly inside each open sector. The signs and source-score ordering are constant within an open sector, so these 28 evaluations cover all nonzero directions. The sector representatives are sums of adjacent ray generators; all adjacent angular gaps are less than \(\pi\), making each sum an interior point.

The hand-checkable certificate in `directional_certificate.txt` gives, for every stratum, (i) all active-source maximizers and their \(q_i\), and (ii) all global source maximizers and the subset with \(q_i<0\). In all 28 rows every active-max projection is negative, and the global-max decreasing subset is nonempty. This proves both claims for the checked directions and all directions in their respective open sectors.

## Replay and scope

Run `python3 work/agents/chem_geometry/check_endotactic.py` from the workspace root. It uses integer arithmetic only and writes `exact_results.json` and `directional_certificate.txt` beside the script. The JSON keeps every direction, score, projection, active set, and maximizer for independent inspection. The checker is a direct executable transcription of the cited definitions; no existing generic checker or chemistry derivation was used.

This establishes the graph property for the exact frozen four-reaction network. It does not establish a permanence, explosivity, or other kinetic claim.

## Primary source

Chuang Xu, “On the Regulary of Reaction Systems,” arXiv:2409.05340v2, Section 4, Definitions 4.1–4.4. The exact definition text is in the official arXiv HTML at lines 255–270; the downloaded v2 PDF is retained with SHA-256 in `source_manifest.json`.
