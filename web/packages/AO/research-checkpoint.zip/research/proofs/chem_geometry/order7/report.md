# Exact geometry check of the order-7 network

## Result

For

\[
0\to2A,\quad 2A\to4A+B,\quad 4A+B\to5A+2B,
\quad 5A+2B\to3A,\quad 4A+B\to4A+2B,
\]

the exact integer check establishes **endotacticity and strong endotacticity in every nonzero direction** under Xu, arXiv:2409.05340v2, Definitions 4.2–4.4. The largest source molecularity is \(5+2=7\). The checker evaluated all 14 critical rays and all 14 open sectors; there are no failures.

The term “direction” is taken to mean \(u\ne0\). If Definition 4.4’s phrase “every \(u\in\mathbb R^d\)” were read to include \(u=0\), its strict-decrease clause would make strong endotacticity impossible for every network. Definition 4.1’s claim that this relation induces a total order also presupposes \(u\ne0\).

## Exact directional certificate

Write \(u=(a,b)\), with source scores

\[
s_{(0,0)}=0,\quad s_{(2,0)}=2a,\quad
s_{(4,1)}=4a+b,\quad s_{(5,2)}=5a+2b.
\]

The reaction projections in listed order are

\[
q_1=2a,\quad q_2=2a+b,\quad q_3=a+b,
\quad q_4=-2a-2b,\quad q_5=b.
\]

The active-source set in Xu’s endotacticity definition consists of sources of reactions with \(q_i\ne0\). For endotacticity, every active source that maximizes its score must have all of its active outgoing reactions satisfy \(q_i\le0\). For strong endotacticity, at least one globally maximal source must have an outgoing reaction with \(q_i<0\). The checker handles each source as a set element, including the two outgoing reactions from \((4,1)\).

All tests depend only on signs of \(q_i\) and pairwise score differences. The critical lines are

\[
a=0,\; 4a+b=0,\; 5a+2b=0,\; 2a+b=0,\;
3a+2b=0,\; a+b=0,\; b=0.
\]

The executable checker evaluates each oriented boundary ray and one exact integer vector in every open sector. Its full row-by-row certificate is in `directional_certificate.txt`; each row lists all active-max sources and their outgoing projections, all global-max sources, and the globally maximal sources with decreasing reactions. In every row the active-max projections are negative and the set of decreasing reactions at globally maximal sources is nonempty. Integer signs and comparisons are constant within each open sector, so the certificate covers all nonzero directions.

## Face repaired by the added branch

Omitting the last reaction leaves the four-reaction chain. On the exceptional ray \(u=(1,-1)\), its source scores are \(0,2,3,3\) and its reaction projections are \((2,1,0,0)\). The last two chain reactions are orthogonal to \(u\), so their sources are excluded from the active-source set. The active maximum is then \((2,0)\), whose reaction 2 has projection \(+1\), an exact endotacticity violation. The globally maximal sources \((4,1)\) and \((5,2)\) have no decreasing outgoing reaction, so strong endotacticity also fails there. The full arrangement check finds this as the chain’s only failing stratum.

The added branch \((4,1)\to(4,2)\) has projection \(q_5=b=-1\) on this ray. It makes \((4,1)\) the active-source maximum, with a strictly decreasing reaction, and supplies a decreasing reaction at a globally maximal source (the score-3 tie with \((5,2)\)). Thus it repairs both failures on this exceptional ray. On the opposite ray, its projection is positive but its source is below the active and global maximum, so it creates no violation; that case is included in the full certificate.

## Replay and scope

Run `./work/agents/chem_geometry/order7/check_order7.py` from the workspace root. It uses integer arithmetic only and writes `exact_results.json` and `directional_certificate.txt` in this folder. The JSON includes the branched network, the unbranched chain comparison, every tested stratum, scores, projections, and maxima. This establishes the graph property only; no CTMC or kinetic claim is made.

The definition source is Chuang Xu, “On the Regulary of Reaction Systems,” arXiv:2409.05340v2, Section 4, Definitions 4.1–4.4. Exact official HTML locations and the paper hash are listed in `source_manifest.json`.
