# Exact geometry check of the order-6 network

## Result

For

\[
0\to2A,\quad 2A\to4A+B,\quad 4A+B\to4A+2B,
\quad 4A+2B\to3A,
\]

the exact check establishes **endotacticity and strong endotacticity in every nonzero direction** under Xu, arXiv:2409.05340v2, Definitions 4.2–4.4. The maximal source molecularity is \(4+2=6\). There are no failures among 12 critical rays or 12 open sectors.

The directional parameter is taken to be nonzero. A literal inclusion of \(u=0\) would make the strict-decrease clause of strong endotacticity impossible; the source’s Definition 4.1 also describes the projection relation as a total order, which presupposes \(u\ne0\).

## Exact certificate

Write \(u=(a,b)\). The source scores for the four distinct reactants and the reaction projections in listed order are

\[
(s_0,s_1,s_2,s_3)=(0,2a,4a+b,4a+2b),
\qquad
(q_1,q_2,q_3,q_4)=(2a,2a+b,b,-a-2b).
\]

For endotacticity, only sources of reactions with \(q_i\ne0\) enter the active-source maximum. Every reaction leaving an active-max source must have \(q_i\le0\). For strong endotacticity, at least one globally maximal source must have a reaction with \(q_i<0\). Tied maxima are all retained and tested.

The signs of the four projections and the order of source scores can change only on these six lines:

\[
a=0,\quad 2a+b=0,\quad b=0,\quad a+2b=0,
\quad 4a+b=0,\quad a+b=0.
\]

The checker evaluates each oriented boundary ray and one exact integer vector in each open sector. The integer signs and source-score ordering stay constant throughout each sector. The full certificate in `directional_certificate.txt` lists, for all 24 strata, the active-max reactions with their projections, all global-max sources, and decreasing reactions at global maxima. Every active-max reaction has negative projection, and the decreasing-global-max set is nonempty in every row.

## Replay and scope

Run `./work/agents/chem_geometry/order6/check_order6.py` from the workspace root. It uses integer arithmetic only and writes `exact_results.json` and `directional_certificate.txt` in this folder. The graph result does not establish a CTMC, stochastic-explosion, or kinetic claim.

The definitions are from Chuang Xu, “On the Regulary of Reaction Systems,” arXiv:2409.05340v2, Section 4, Definitions 4.1–4.4. Exact source locations and the hash of the retained official PDF are in `source_manifest.json`.
