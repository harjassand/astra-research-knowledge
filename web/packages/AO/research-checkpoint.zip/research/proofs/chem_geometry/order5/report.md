# Exact geometry check of the frozen order-5 network

## Result

For

\[
0\to2A,\quad 2A\to3A+B,\quad 3A+B\to3A+2B,
\quad 3A+2B\to3A,\quad 3A+2B\to2A,
\]

the exact check establishes **endotacticity and strong endotacticity in every nonzero direction** under Xu, arXiv:2409.05340v2, Definitions 4.2–4.4. The maximal source molecularity is \(3+2=5\). There are no failing directions.

## Exact all-direction certificate

Let \(u=(a,b)\). The source scores, in order of the distinct reactants \((0,0),(2,0),(3,1),(3,2)\), are

\[
(s_0,s_1,s_2,s_3)=(0,2a,3a+b,3a+2b).
\]

The five reaction projections in network order are

\[
(q_1,q_2,q_3,q_4,q_5)=(2a,a+b,b,-2b,-a-2b).
\]

For endotacticity, \(C_{u,+}\) contains the sources of reactions with nonzero projection. Any positive-projection reaction from a source maximizing its score in that active set would violate endotacticity; tied active maxima are all checked. Strong endotacticity additionally requires a strictly decreasing outgoing reaction from at least one source maximizing over all reactants. The checker handles the two outgoing reactions from \((3,2)\) separately while treating their source as one complex in the maxima.

All relevant signs and source-score orderings can change only on the six lines

\[
a=0,\quad 3a+b=0,\quad 3a+2b=0,\quad
a+b=0,\quad a+2b=0,\quad b=0.
\]

The checker evaluates all 12 oriented boundary rays and one exact integer vector in each of the 12 open sectors. The lines include every zero set of a reaction projection and every pairwise source-score tie. Within each open sector the signs and ordering are fixed. The full certificate in `directional_certificate.txt` lists every stratum, each active-max reaction with its source and projection, all globally maximal sources, and the decreasing reactions at global maxima. Across all 24 strata, every active-max reaction has negative projection and every globally maximal set has at least one decreasing outgoing reaction.

The zero vector is excluded as a direction; otherwise no network could meet the strict-decrease clause in the paper’s definition of strong endotacticity.

## Replay and scope

Run `./work/agents/chem_geometry/order5/check_order5.py` from the workspace root. It uses integer arithmetic and writes `exact_results.json` and `directional_certificate.txt` in this folder. The check establishes only the graph property; the rate fixture has no role in this calculation, and no explosion claim is made.

The definitions are from Chuang Xu, “On the Regulary of Reaction Systems,” arXiv:2409.05340v2, Section 4, Definitions 4.1–4.4. Exact source locations and the retained PDF hash are in `source_manifest.json`.
