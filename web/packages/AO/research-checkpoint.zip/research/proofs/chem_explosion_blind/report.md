# Blind audit result: explosive

For the exact order-eight network supplied in the assignment, I independently derived positive-probability explosion for **every fixed positive rate vector**, from **every finite initial state**. No candidate argument in `work/agents/chemistry` was read before the derivation was frozen.

The full proof is in `fresh_derivation.md`. It is frozen with SHA-256

    c24924b44b14e63cb3fcb2d411d74b98d0d2d39869b1c91aad2d7c221edb70f6

at 2026-10-08 10:08:20 UTC.

The accepted embedded-chain excursions from (a,0) are the growth word `R1,R2,R3`, ending at (a+1,0), and the stall word `R1,R2,R2,R3,R2,R3,R2,R3`, ending at (a,0). The latter repairs the nonsummable O(1/a) error that would invalidate an infinite prescribed-growth-word argument. Once it is admitted, the discarded block probability is O(1/a^2).

With the explicit constants M and D in the derivation, and a0 above the explicit parameter-dependent threshold, the probability of accepted growth through every level is at least exp[-4D/(a0-1)] > 0. Conditional on this event, expected physical explosion time is at most 16/[k1(a0-1)]. Finite expected time establishes almost-sure finite explosion time on that positive-probability event. All reaction marks, holding-time conditioning, infinite products and small-state accessibility are handled explicitly.

Self-audit found no gap in the proof. In particular:

- The growth and stall words contain 3 and 8 jumps respectively, with no intermediate B=0 state and the stated endpoints.
- The O(1/a) stall probability is not discarded, so no harmonic-series probability product is claimed positive.
- At a fixed level, repeated stalls give success probability q_a/(q_a+d_a), rather than q_a/(1-d_a).
- Conditioning on the infinite successful embedded-chain event preserves exponential holding-time means after the reaction marks are fixed.
- The total rate is bounded below by k1*a*(a-1) throughout accepted blocks, and the resulting reciprocal-rate sum telescopes.
- Rate constants may be arbitrarily unequal; only their positivity and finiteness are used.
- Initial A<5 or B<3 states are bypassed by finite legal paths, not fed into invalid asymptotic inequalities.

`check_blocks.py` passed 28 exact rational diagnostics over four substantially different parameter vectors. Those checks verify finite arithmetic and bounds; they are not formal or external validation of the infinite argument.

Xu arXiv:2409.05340v2, Remark 4.8 (HTML lines 319-321), was opened and read for context. Source novelty beyond that remark is UNKNOWN. Endotactic geometry is intentionally outside the blind CTMC audit and must be established separately before any order-eight upper-bound claim is made.

Exact status: independently derived and self-audited mathematical argument; finite exact arithmetic checked; formal proof replay and external expert validation UNKNOWN. Next decisive action: compare against the separately frozen argument and adversarially inspect any disagreement, then assess the separate lower-order construction supplied by the coordinator.
