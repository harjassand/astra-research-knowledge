# Phase2 obstruction result

The independently derived arguments prove nonexplosion for every two-species fully endotactic stochastic mass-action network of source order at most three in each of the following configurations:

1. No pure cubic source: neither 3A nor 3B occurs. This includes both mixed cubic sources, exactly one mixed cubic source, or no cubic source.
2. Both pure cubic sources: both 3A and 3B occur, with arbitrary mixed sources.
3. Every cubic arrow conserves total count, regardless of source configuration.

All finite strictly positive rate vectors, arbitrary finite products at lower-order sources, every finite initial state, and boundary-disabled reactions are covered. The both-pure theorem only needs total-direction endotacticity; the other proofs use explicit finite direction tests implied by full endotacticity.

Consequently, an explosive fully endotactic two-species example of order at most three would have to have **exactly one** of 3A and 3B as a source, and at least one cubic total-loss arrow. That is the remaining two-species configuration. The universal order-three theorem and all higher-dimensional order-three questions remain UNKNOWN. These subclass results do not improve the overall minimum-order lower bound by themselves.

The no-pure theorem uses an explicit diagonal quadratic Foster function when both mixed cubic sources occur. With one mixed source, it uses the exact discrete function

    V=p*a^2+q*b^2+2*r*b*(a-K)_+.

The truncated cross term avoids cubic-size positive drift from 2B->2B+A at A=0. Its exact increment is checked through the threshold strip. Only when A>K-D can a pure 2B reaction produce a positive b^3 term; choosing K above an explicit coefficient ratio lets negative cubic a*b^3 drift pay for it. The remaining weighted-loss cases close successively at the cubic, pure-quadratic, mixed-quadratic, or linear tier. No cusp term is omitted.

The both-pure theorem uses

    V=(a+b)^2+epsilon*(a^2+b^2).

Its leading cubic drift is uniformly negative of degree four: total-count loss controls interior angles, and the diagonal perturbation controls conservative transfers at both axes. Explicit positive constants account for arbitrarily small loss rates. Falling-factorial and discrete-curvature errors are O(1+N^3), so the exact generator has a global Foster bound.

The four-reaction example in the mixed-cubic proof is strongly endotactic and has quadratic positive total-count drift on both axes. Every positive linear function increases under one pure quadratic arrow, while the constructed quadratic Foster function succeeds. This demonstrates that the result does more than apply a linear total-count criterion.

Frozen files and SHA-256:

    mixed_cubic_nonexplosion.md
    e7eb9b83091ba3577ac14b376c47e27a2a530075d8280929727cd968839110ae

    both_pure_cubic_nonexplosion.md
    75c1dfe4a59b321eb14cb203edc65de662ce52c2502248e900e748f7e5bb3ab9

    no_pure_cubic_nonexplosion.md
    d4f65969734a309df3fba2c227891ace65e7d7e8dd431cf69f7bc401c78f6c2d

`check_phase2.py` passed 5,023 exact cutoff/jump checks, 2,000 mixed-weight checks and 105 angular-constant checks. These are finite algebra diagnostics, not formal proof certification. Independent argument-exposed proof audit is pending with the coordinator's separate auditor. A separate fresh agent is attacking the one-pure case; this worker stopped extensions as instructed.

Source handling: Xu arXiv:2409.05340v2 Definitions 4.2-4.4 and Proposition 3.5 were opened; the latter is also justified by the stopping argument in the first proof. No lower-order chemistry candidate proof was read. Literature novelty, formal replay and external validation remain UNKNOWN.

Next decisive action: adversarial review of the frozen no-pure and both-pure arguments, especially the exact truncated-cross strip and the tier-sign classification, followed by a fresh resolution or obstruction for the exactly-one-pure-source case. No overall order-three regularity conclusion is made.
