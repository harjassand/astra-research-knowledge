# Nonexplosion when both pure cubic sources are present

This is a second independent Phase2 lower-bound lemma. It does not assume or read any order-five-or-lower candidate argument.

## Theorem

Let a finite two-species stochastic mass-action network have every source of total degree at most three, fixed finite strictly positive reaction constants, and both 3A and 3B as sources of nontrivial reactions. If the network is endotactic in direction (1,1), its minimal CTMC is nonexplosive from every finite state.

Full endotacticity is unnecessary for this subclass. Mixed cubic sources may be present or absent, and all rate ratios are allowed. The proof provides an explicit quadratic Foster function and accounts for all falling-factorial and discrete curvature terms.

## Preliminary signs and the cubic-conservative case

Direction-(1,1) endotacticity implies that every cubic arrow has nonpositive total increment. A positive arrow from a cubic source would itself be maximal among essential sources, since no source has higher degree.

Every nontrivial cubic arrow at 3A therefore strictly decreases A: its product has total degree at most three, and a product with A count three would have to equal its source. Similarly, every arrow at 3B strictly decreases B.

If all cubic arrows conserve total count, the essential-source convention omits them in direction (1,1). A total-increasing quadratic arrow would then be maximal and violating. Thus all quadratic total increments are nonpositive, and W=1+a+b satisfies L W<=C W. This proves nonexplosion by the usual norm-like Foster argument.

Below assume some cubic arrow has strictly negative total increment.

## Cubic drift on the normalized interval

Write N=a+b, t=b/N for N>0. For a cubic reaction r with source y_r=(i_r,3-i_r), vector d_r and constant k_r, define its ordinary-monomial normalized vector field

    F(t)=sum_{r cubic} k_r*(1-t)^(i_r)*t^(3-i_r)*d_r.

This polynomial is used only to identify the leading homogeneous term of the exact generator. Define

    ell(t)=-(F_A(t)+F_B(t))>=0,
    h(t)=2*((1-t)*F_A(t)+t*F_B(t)).

Let

    alpha_A=-sum_{r:source=3A} k_r*d_(r,A)>0,
    alpha_B=-sum_{r:source=3B} k_r*d_(r,B)>0,
    alpha_min=min(alpha_A,alpha_B)>0.

Then h(0)=-2*alpha_A and h(1)=-2*alpha_B.

For explicit uniform bounds put

    S=sum_{r cubic} k_r*(abs(d_(r,A))+abs(d_(r,B)))>0,
    H=2*S,
    D_h=8*S.

For t in [0,1], |h(t)|<=H and |h'(t)|<=D_h. The derivative bound follows by differentiating each term

    2*k_r*((1-t)*d_A+t*d_B)*(1-t)^i*t^(3-i):

the linear factor's derivative is bounded by |d_A|+|d_B|, the degree-three monomial's derivative is bounded by three, and both undifferentiated factors are bounded by one or |d_A|+|d_B| respectively.

Choose

    delta=min(1/4,alpha_min/D_h)>0.

For t in [0,delta] or [1-delta,1], the derivative estimate gives

    h(t)<=-alpha_min.

Pick any one cubic reaction r_* with strictly negative total increment, and put

    k_loss=k_(r_*)*(-d_(r_*,A)-d_(r_*,B))>0,
    ell_0=k_loss*delta^3>0.

For t in [delta,1-delta], both normalized coordinates are at least delta. Each degree-three monomial is therefore at least delta^3, and

    ell(t)>=ell_0.

These constants remain positive when loss rates are arbitrarily small; their dependence is explicit rather than hidden in a uniformity claim.

## The explicit quadratic Foster function

Set

    epsilon=min(1,ell_0/(H+1))>0,
    c=min(ell_0,epsilon*alpha_min)>0,
    V(a,b)=(a+b)^2+epsilon*(a^2+b^2).

The leading degree-four cubic generator term is

    N^4*(-2*ell(t)+epsilon*h(t)).

In an axis collar, ell>=0 and h<=-alpha_min, so this is at most -epsilon*alpha_min*N^4. In the middle interval,

    -2*ell(t)+epsilon*h(t)
      <= -2*ell_0+epsilon*H <= -ell_0.

Hence the leading term is at most -c*N^4 throughout the normalized interval. At N=0 it is zero, so the same homogeneous inequality holds there.

The role of the diagonal perturbation is exact: a pure cubic conservative transfer can have zero total-count drift but still gives strictly negative drift of a^2+b^2 at its pure axis. The radial term controls every interior angle whenever any cubic total loss exists.

## Exact discrete remainder bounds

For one reaction vector d, the exact quadratic increment is

    Delta V=2*N*(d_A+d_B)+2*epsilon*(a*d_A+b*d_B)
             +(d_A+d_B)^2+epsilon*(d_A^2+d_B^2).

The last two terms are constants depending on the reaction vector and account for every discrete second difference.

For a source of degree three, its falling-factorial rate differs from the ordinary monomial rate by a polynomial of degree at most two. For example,

    a_(3)=a^3-3a^2+2a,
    a_(2)*b=a^2*b-a*b,
    a*b_(2)=a*b^2-a*b,
    b_(3)=b^3-3b^2+2b.

Therefore the propensity difference is bounded in absolute value by C*(1+N^2). Multiplying it by the linear part of Delta V contributes at most C*(1+N^3). Multiplying the constant part of Delta V by the exact cubic propensity contributes at most C*(1+N^3) as well. Summing the finite reaction set gives the exact cubic estimate

    L_3 V<=-c*N^4+C_3*(1+N^3).

This is valid at every nonnegative integer population, including a or b equal to zero, one or two. It never treats a disabled falling-factorial reaction as active: the difference from its monomial is explicitly charged to the remainder.

Quadratic rates are at most C*N^2, and the exact V increments at most C*(1+N); products of a quadratic source may be arbitrarily large but are fixed finite vectors. Thus

    L_2 V<=C_2*(1+N^3).

Order-zero and order-one reactions contribute at most C_1*(1+N^2). Consequently, for a finite C,

    L V<=-c*N^4+C*(1+N^3).

In particular the drift is bounded above globally by a finite constant. For example, maximizing -c*x^4+C*x^3 over x>=0 gives 27*C^4/(256*c^3), so

    L V <= C+27*C^4/(256*c^3).

V is nonnegative and norm-like. A Foster stopping/Gronwall argument therefore rules out explosion from every finite initial state. The exact stopping justification is given in the separately frozen mixed-cubic theorem and is the standard criterion of Xu Proposition 3.5.

## Scope

Together with the mixed-cubic theorem, this gives two rigorous source-geometry subclasses for order-three regularity. It is not a proof for networks having exactly one pure cubic source, or for networks having no pure cubic source but only one mixed cubic source. Those cases remain UNKNOWN here. Every cubic-conservative order-three endotactic network is covered independently by the linear total-count argument.

Status: independently derived exact argument with explicit parameter-dependent constants. Literature priority, formal proof assistant replay and external validation are UNKNOWN.
