# All two-species order-three networks with no pure cubic source

## Theorem

Every finite fully endotactic two-species mass-action network of source order at most three, with neither 3A nor 3B as a source, has a nonexplosive stochastic CTMC for every fixed finite strictly positive rate vector and every finite initial state.

The proof is a complete source-case classification. If both mixed cubic sources occur, the separately frozen `mixed_cubic_nonexplosion.md` supplies the explicit weighted diagonal quadratic Foster function. The missing case is exactly one mixed source; its discrete truncated-cross construction is proved here. With no cubic source, total-direction endotacticity makes every quadratic total increment nonpositive, and the linear total-count Foster function suffices.

This theorem does not cover exactly one pure cubic source. The separately frozen `both_pure_cubic_nonexplosion.md` covers two pure cubic sources. No order-five-or-lower candidate proof was read in obtaining this result.

## Exactly one cubic source: the geometric signs

By symmetry take the only cubic source to be A+2B. Write its reaction vectors d_r and aggregate

    v=sum_{r:A+2B} k_r*d_r=(v_A,v_B).

Absent 3A and 3B, endotacticity in the two coordinate directions gives:

    every arrow at an A-coordinate-two source has Delta A<=0;
    every arrow at a B-coordinate-two source has Delta B<=0.

In particular every cubic arrow has d_B<=0, every quadratic arrow at 2A has d_A<=0, and every quadratic arrow at 2B has d_B<=0.

Test the additional direction w=(2,1). Among all allowed sources its maximum score is four, attained at A+2B and possibly 2A. The other mixed cubic source 2A+B is absent. Thus every arrow at A+2B and every arrow at 2A satisfies

    2*d_A+d_B<=0.

Total-direction endotacticity also gives d_A+d_B<=0 for cubic arrows. In fact each nontrivial cubic arrow has strictly negative total increment. If its total increment were zero, d_B<=0 would imply d_A>=0, while 2*d_A+d_B<=0 would imply d_A<=0. The arrow would then have zero vector.

Every cubic A-increasing arrow is exactly

    A+2B -> 2A,       d=(1,-2).

This follows by listing the products of degree at most three with A>1: the other possibilities 2A+B and 3A have positive w projection and are forbidden.

For quadratic sources define the rate-weighted aggregates

    h=sum_{r:2A} k_r*d_r,
    z=sum_{r:A+B} k_r*d_r,
    j=sum_{r:2B} k_r*d_r,

with zero aggregate if a source is absent. The signs already obtained include h_A<=0, h_B>=0, j_A>=0, j_B<=0, and

    H=2*h_A+h_B<=0,
    G=2*v_A+v_B<=0.

All source sizes and jump vectors are finite. Products of quadratic reactions may have higher order; the proof charges their fixed finite sizes explicitly.

## Easy diagonal subcase

If v_A<0, take V=a^2+b^2. Its leading cubic term is

    2ab*[v_A*a*b+v_B*b^2] <= 2*v_A*a^2*b^2.

The falling-factorial/discrete remainder is O(a^2*b+a*b^2). The coordinate signs at 2A and 2B bound every quadratic contribution by O(a^2*b+a*b^2+a^2+b^2). This is the exact one-source specialization of the expansion in the frozen mixed-cubic proof. Absorbing the two degree-three mixed terms into the negative a^2*b^2 term gives L V<=C(1+V).

Henceforth assume v_A>=0. Since all cubic total increments are strictly negative, v_B<0.

## A discrete truncated-cross Foster lemma

Fix positive p,q,r with r<2q, and an integer K to be chosen. Set

    f_K(a)=(a-K)_+,
    V_K(a,b)=p*a^2+q*b^2+2*r*b*f_K(a).

This is nonnegative and norm-like on N0^2. Its exact one-reaction increment is

    Delta V_K
      =2*p*a*d_A+p*d_A^2
        +2*b*[q*d_B+r*(f_K(a+d_A)-f_K(a))]
        +q*d_B^2+2*r*d_B*f_K(a+d_A).

There is no differentiability assumption or omitted kink term.

Let D be a finite integer at least the absolute A increment of every reaction. For a>=K+D, the cross term is linear at both states. Define

    C_A=p*v_A+r*v_B,     C_B=r*v_A+q*v_B,
    H_A=p*h_A+r*h_B,     H_B=r*h_A+q*h_B,
    Z_A=p*z_A+r*z_B,     Z_B=r*z_A+q*z_B.

Then an aggregate increment at any source has linear coefficients 2a times its first coefficient and 2b times its second, plus a constant depending on K and the finite jump vectors. The exact remainder constant for one arrow is

    p*d_A^2+q*d_B^2+2*r*d_A*d_B-2*r*K*d_B.

### Uniform cubic control through the threshold strip

For a cubic arrow with d_A<=0, monotonicity of f_K gives Delta f_K<=0 and d_B<=0. For its only possible A-increasing vector (1,-2), Delta f_K<=1. Therefore, at every a,

    q*d_B+r*Delta f_K <= q*d_B+r*max(d_A,0).

Define

    kappa=sum_{r cubic} k_r*[q*(-d_B)-r*max(d_A,0)]>0.

Each summand is nonnegative. It is strictly positive whenever d_B<0, because r<2q covers (1,-2), and otherwise the A increment is nonpositive. At least one d_B is negative since v_B<0.

If C_A<=0, the remaining part of the aggregate cubic increment is bounded above by a finite C_K: it equals 2*C_A*a plus a fixed constant when a>=K+D, and a ranges over a finite set otherwise. Hence, globally,

    L_3 V_K <= -2*kappa*a*b^3+C_K*a*b^2.

The C_K has absorbed the positive b_(2) correction. If C_A<0, the same argument strengthens this to

    L_3 V_K <= -rho*a^2*b^2-2*kappa*a*b^3
                +C_K*(a^2*b+a*b^2),       rho=-C_A>0.

To see the strengthened bound even in the strip, bound the finite-a remainder by -rho*a+C_K before multiplying by a*b*(b-1). Its positive factorial correction is rho*a^2*b, already displayed.

### Quadratic control in and outside the strip

For a>=K+D, expanding the exact quadratic-source contributions yields the leading terms

    L_(2A) V_K:  2*H_A*a^3+2*H_B*a^2*b,
    L_(A+B) V_K: 2*Z_A*a^2*b+2*Z_B*a*b^2.

All their remaining terms are bounded above by C_K*(1+a^2+b^2). For a<K+D, A belongs to a finite set. The exact increment is O_K(1+b), the 2A rate is bounded, and the A+B rate is O_K(b). Both contributions, as well as the displayed leading terms restricted to this strip, are O_K(1+b^2). Consequently the two estimates with an upper remainder C_K*(1+a^2+b^2) hold globally. This explicitly charges all jumps across the cutoff.

At source 2B, d_A>=0 and d_B<=0. If a<=K-D then Delta f_K=0 and the coefficient of b in its exact increment is nonpositive. At every other a, Delta f_K<=d_A. Put

    T_B=2*sum_{r:2B} k_r*max(q*d_B+r*d_A,0).

Then

    L_(2B) V_K
      <= T_B*b^3*1_{a>K-D}+C*(a*b^2+b^2).

T_B is independent of K. Choose an integer

    K>D+T_B/kappa+1.

The possible positive b^3 term is then at most kappa*a*b^3. The cubic negative term pays for it. All remaining constants may depend on this finite K.

Reactions of order at most one contribute at most C_K*(1+a^2+b^2), because f_K is Lipschitz with constant one, f_K(a)<=a, and the rates are O(1+a+b).

The preceding exact estimates prove nonexplosion in each of the following three parameter regimes:

I. C_A<0 and H_A<=0. The negative rho*a^2*b^2 absorbs all finite multiples of a^2*b+a*b^2 by the two Young inequalities in the mixed-cubic proof. The b^3 term was already paid for by kappa*a*b^3. Hence L V_K<=C_K*(1+a^2+b^2)<=C'(1+V_K).

II. C_A=0 and H_A<0. The drift is bounded by

    -rho*a^3-kappa*a*b^3+C*(a^2*b+a*b^2)
       +C_K*(1+a^2+b^2),        rho=-2*H_A>0.

Use C*a^2*b<=(rho/2)*a^3+[C^2/(2*rho)]*a*b^2. The resulting multiple of a*b^2 is absorbed by (kappa/2)*a*b^3 plus C'*a, since the polynomial C''*b^2-(kappa/2)*b^3 is bounded above. Again the Foster bound follows globally.

III. C_A=H_A=0, H_B+Z_A<0, and Z_B<=0. The combined 2A and A+B leading drift is nonpositive and has a strictly negative a^2*b coefficient. After adding the exact strip/remainder estimates and paying for the 2B b^3 term, the only possibly positive cubic-size term is C_K*a*b^2. The negative kappa*a*b^3 absorbs it plus C'*a. This also gives L V_K<=C'(1+V_K).

Thus the lemma is a full discrete Foster argument in all three regimes, not merely a leading homogeneous sign calculation.

## Geometry selects one of the Foster regimes

First suppose G=2*v_A+v_B<0. Take q=r=1 and

    p=2+delta,
    delta=min(1,(-G)/(2*(max(v_A,0)+1)))>0.

Then C_A=G+delta*v_A<0 and H_A=H+delta*h_A<=0. Also r<2q. Regime I applies.

Now suppose G=0. Every cubic arrow has nonpositive w projection, so each must have projection zero. Together with d_B<=0 and nontriviality, this forces each cubic arrow to be (1,-2). Therefore

    v=(k,-2k),       k>0.

If H<0, set p=2,q=r=1. Then C_A=0 and H_A=H<0, so Regime II applies.

If H=0, every arrow at 2A also has w projection zero. All cubic and 2A arrows are now omitted from the w-essential sources. A w-increasing arrow at A+B, whose source score is three, would be maximal among remaining essential sources; hence every A+B arrow has nonpositive w projection. Put

    Z=2*z_A+z_B<=0.

If Z<0, choose

    epsilon=min(1,(-Z)/(2*(h_B+max(z_B,0)+1)))>0,
    p=4,       r=2,       q=1+epsilon.

Then r<2q, C_A=H_A=0, and

    H_B=epsilon*h_B,
    Z_A=2*Z,
    Z_B=Z+epsilon*z_B<=Z/2<0,
    H_B+Z_A<=3*Z/2<0.

Regime III applies. This remains valid with an absent 2A source (h=0) or with arbitrarily small lower-tier loss rates; constants and K simply change.

Finally, if Z=0, every A+B arrow also has zero w projection. A w-increasing arrow at 2B would then itself be maximal among essential sources of score two; lower-order sources have score at most two and cannot provide a strictly higher essential source. Thus every 2B arrow has nonpositive w projection. All reactions of order at least two now have nonpositive w increment, and the linear positive-weight function 1+2a+b satisfies L W<=C W.

This closes every single-mixed-source case. Interchanging A and B proves the case with only 2A+B. Along with the frozen two-mixed-source theorem and the no-cubic case, the stated no-pure-cubic theorem follows.

## Scope and status

The proof uses only the four finite geometric direction tests e_A,e_B,(1,1),(2,1) in the one-source orientation, or (1,2) after swapping species. It covers every fully endotactic network in the stated source class, every finite positive rate vector, arbitrary finite products at lower-order sources, all initial populations, and every boundary-disabled reaction via exact rates and threshold-strip estimates.

It does not prove the remaining exactly-one-pure-source case. Formal replay, external expert validation and literature priority are UNKNOWN. This result was derived without reading any lower-order chemistry candidate proof.
