# A two-species order-three nonexplosion theorem

This obstruction-first derivation is independent of all chemistry candidate arguments of order five or lower. It does not prove nonexplosion for every order-three endotactic network. Its exact proved subclass and the unclosed cases are stated below.

## Theorem

Consider a finite stochastic mass-action reaction network on two species A,B with fixed finite strictly positive reaction constants. Assume:

1. Every source has total degree at most three.
2. Neither 3A nor 3B is a source.
3. Both 2A+B and A+2B are sources of at least one nontrivial reaction.
4. The network is endotactic in the three directions e_A=(1,0), e_B=(0,1), and 1=(1,1), using the active-source convention of Xu Definition 4.2 (sources of arrows orthogonal to the tested direction are omitted).

Then the minimal stochastic mass-action CTMC is nonexplosive from every finite state, for every such positive rate vector. Consequently the theorem applies to every fully endotactic network satisfying conditions 1-3. Strong endotacticity, asiphonicity, weak reversibility, irreducibility and deterministic permanence are not assumptions.

If at least one cubic reaction decreases total molecule count, an explicit norm-like quadratic Foster function exists. If every cubic reaction conserves total count, the linear total-count function suffices.

## Geometry reduces to three sign constraints

All cubic reactions have nonpositive total increment. Otherwise a total-increasing cubic arrow would itself have a maximal essential source in direction (1,1), since no source has degree greater than three, contradicting condition 4.

Every reaction from an A-coordinate-two source has nonpositive A increment: absent 3A, no source has A coordinate greater than two. A positive A increment at such a source would itself be maximal among essential sources for e_A. Similarly, every reaction from a B-coordinate-two source has nonpositive B increment.

Define the rate-weighted aggregate cubic vectors

    u = sum_{r: source(r)=2A+B} k_r*v_r,
    v = sum_{r: source(r)=A+2B} k_r*v_r.

The preceding sign constraints give

    u_A <= 0,       u_A+u_B <= 0,
    v_B <= 0,       v_A+v_B <= 0.

Put alpha=-u_A>=0 and beta=-v_B>=0. The presence of each source implies the following useful nondegeneracy:

    alpha=0 implies u_B<0;
    beta=0 implies v_A<0.

Indeed, alpha=0 and positivity of all k_r imply that every outgoing arrow at 2A+B has A increment zero. Its total increment is nonpositive, hence its B increment is nonpositive. If the aggregate B increment also vanished, every arrow would have zero vector, contrary to the source being present with a nontrivial reaction. The argument for beta is symmetric.

The same source-coordinate sign constraint also gives Delta A<=0 for every quadratic arrow at 2A, and Delta B<=0 for every quadratic arrow at 2B. These signs are necessary to bound their high-axis drift below.

## If cubic total count is conserved

Suppose all cubic arrows have total increment zero. They are omitted from the essential sources in direction (1,1). Any total-increasing quadratic arrow would then itself have a maximal essential degree-two source and violate endotacticity. Thus every quadratic arrow has nonpositive total increment as well.

Only reactions of order at most one can increase total count. Their rates are bounded by C(1+a+b), so for W(a,b)=1+a+b,

    L W <= C W.

The nonexplosion conclusion follows from the elementary Foster argument at the end. This case does not require the quadratic construction.

## Positive quadratic weights when cubic loss exists

Assume now that some cubic arrow decreases total count. Positivity of the constants implies at least one strict aggregate inequality u_A+u_B<0 or v_A+v_B<0.

For positive weights p,q define

    V(a,b)=p*a^2+q*b^2,

and the quadratic form

    Q(a,b)=p*u_A*a^2+(q*u_B+p*v_A)*a*b+q*v_B*b^2.

We choose p,q so that Q(a,b)<=-eta*a*b for a,b>=0, with eta>0.

Case I: alpha>0 and beta>0. Set p=alpha, q=beta, and

    eta = beta*(alpha-u_B)+alpha*(beta-v_A)>0.

Both summands are nonnegative because u_B<=alpha and v_A<=beta; at least one is strictly positive by the cubic total-loss hypothesis. Then

    Q(a,b)=-(alpha*a-beta*b)^2-eta*a*b <= -eta*a*b.

Case II: alpha=0. Then gamma=-u_B>0. Set

    p=1,    q=(max(v_A,0)+1)/gamma,    eta=1.

The cross coefficient is q*u_B+p*v_A=v_A-max(v_A,0)-1<=-1. The a^2 coefficient is zero and the b^2 coefficient is nonpositive. Hence Q<=-a*b. This also covers alpha=beta=0.

Case III: alpha>0 and beta=0. Then delta=-v_A>0. Set

    q=1,    p=(max(u_B,0)+1)/delta,    eta=1.

Now q*u_B+p*v_A=u_B-max(u_B,0)-1<=-1, and both diagonal coefficients are nonpositive. Again Q<=-a*b.

Thus p,q,eta are explicit finite positive constants for every allowed rate vector, including arbitrarily small cubic loss constants and the degenerate aggregate-coordinate cases.

## Exact falling-factorial generator and its remainder

Define

    s_u=sum_{r:2A+B} k_r*(p*(Delta A_r)^2+q*(Delta B_r)^2),
    s_v=sum_{r:A+2B} k_r*(p*(Delta A_r)^2+q*(Delta B_r)^2).

They are finite and nonnegative. The exact cubic contribution is

    L_3 V
      = a(a-1)b*[2*p*a*u_A+2*q*b*u_B+s_u]
        +ab(b-1)*[2*p*a*v_A+2*q*b*v_B+s_v]
      = 2ab*Q(a,b)
        -2ab*[p*a*(u_A+v_A)+q*b*(u_B+v_B)]
        +s_u*a(a-1)b+s_v*ab(b-1).

This identity is valid at every nonnegative integer a,b, including zero and one: the falling-factorial rates there vanish exactly. The nonleading terms are bounded above by

    K_3*(a^2*b+a*b^2)

for a finite K_3. One explicit choice is

    K_3=2*p*abs(u_A+v_A)+2*q*abs(u_B+v_B)+s_u+s_v.

Therefore, with c=2*eta>0,

    L_3 V <= -c*a^2*b^2+K_3*(a^2*b+a*b^2).

No continuum approximation or ignored falling-factorial correction is used: all discrete second-difference terms are contained in s_u,s_v and the displayed exact remainder.

## Bounding the quadratic and lower-order reactions

For one reaction with vector d=(d_A,d_B),

    V(a+d_A,b+d_B)-V(a,b)
      = 2*p*a*d_A+2*q*b*d_B+p*d_A^2+q*d_B^2.

At source 2A, d_A<=0. Multiplying by its propensity k*a(a-1), and dropping its nonpositive A term, gives an upper bound C*a^2*(b+1). At source 2B the symmetric upper bound is C*b^2*(a+1). At source A+B the rate is k*ab, and its contribution is bounded above by C*(a^2*b+a*b^2+ab).

All products and reaction vectors are finite but need not have total degree at most three when their source is quadratic or lower. Their finite sizes only affect these constants. Summing the finitely many quadratic reactions and using ab<=(a^2+b^2)/2 gives

    L_2 V <= K_2*(a^2*b+a*b^2)+K'_2*(a^2+b^2).

Order-zero and order-one rates are bounded by C(1+a+b), and their V increments are bounded by C(1+a+b). Hence

    L_<=1 V <= K_1*(1+a^2+b^2).

Combining these estimates gives finite K,K_0 with

    L V <= -c*a^2*b^2+K*(a^2*b+a*b^2)+K_0*(1+a^2+b^2).

The mixed degree-three terms are absorbed globally, including all boundary states, by

    K*a^2*b <= (c/2)*a^2*b^2 + [K^2/(2c)]*a^2,
    K*a*b^2 <= (c/2)*a^2*b^2 + [K^2/(2c)]*b^2.

Both inequalities follow by maximizing K*t-(c/2)*t^2 over t>=0. Consequently

    L V <= [K_0+K^2/(2c)]*(a^2+b^2)+K_0
         <= C_1*V+C_2,

where C_1,C_2 are finite because p,q>0. The function V is norm-like. This is an explicit global discrete Foster bound, not an interior-only drift assertion.

## Elementary Foster-to-nonexplosion argument

Absorb constants into W=1+V and C so that L W<=C W. Stop at the first time W reaches level M. The stopped finite-state process permits Dynkin's formula and Gronwall, giving

    E[W(X_(t stopped at level M))] <= W(X_0)*exp(C*t).

Therefore the probability of hitting level M by time t is at most W(X_0)*exp(C*t)/M. Send M to infinity. Explosion before t would require exit from every finite sublevel set: each such set has bounded total rate, so infinitely many jumps inside it cannot occur in finite time. Thus the explosion probability before any fixed t is zero; a countable union over integer t proves nonexplosion. This is the usual norm-like Foster criterion, also recorded in Xu Proposition 3.5.

## Nontrivial example: total-mass drift fails on both axes

The four reactions

    2A -> 2A+B,
    2A+B -> A+B,
    A+2B -> A+B,
    2B -> A+2B

with arbitrary strictly positive constants k_P,k_Q,k_R,k_S satisfy the theorem. For N=a+b,

    L N=k_P*a(a-1)+k_S*b(b-1)
         -k_Q*a(a-1)b-k_R*ab(b-1).

On (a,0), L N=k_P*a(a-1); on (0,b), L N=k_S*b(b-1). Thus N does not give a linear Foster bound, and every positive linear function increases under at least one of the two pure quadratic arrows.

Nevertheless the explicit quadratic weights are p=k_Q,q=k_R, and the theorem gives a global Foster bound. This network has no source 0 and hence admits boundary-disabled reactions; no asiphonicity assumption is being smuggled in.

For completeness, it is strongly endotactic in all directions, not merely in the three used by the theorem. The sources P=(2,0), Q=(2,1), R=(1,2), S=(0,2) form a convex quadrilateral. Their outgoing vectors are (0,1),(-1,0),(0,-1),(1,0). The outward normals for edges P-Q,Q-R,R-S,S-P are respectively

    (1,0), (1,1), (0,1), (-1,-1).

At each tied edge the two outgoing projections are nonpositive, with at least one negative: respectively (0,-1),(-1,-1),(-1,0),(-1,-1). An interior normal cone is a positive combination of its adjacent edge normals, so at its maximizing vertex the outgoing projection is strictly negative. This checks every maximizing face and proves strong endotacticity, including the essential-source convention.

## What remains unresolved

This theorem does not cover a missing mixed cubic source, or the presence of 3A or 3B. In particular, removing one mixed source can remove the strict negative a^2*b^2 coefficient used for absorption. Positive mean drift or deterministic inward geometry cannot replace that missing generator bound.

All cubic-conservative networks of order at most three are covered by the linear argument, regardless of their source configuration. For cubic-loss networks outside the two-mixed-source class, universal order-three regularity remains UNKNOWN here. Pure cubic conservative transfers can protect a boundary coordinate while leaving total count unchanged; a further proof must control these together with the discrete curvature of any glued Lyapunov function.

The source definitions actually read were Xu arXiv:2409.05340v2, Definition 4.2-4.4 (HTML lines 258-267), and the known Foster criterion Proposition 3.5 (HTML lines 137-142). The present quadratic theorem was derived independently; literature priority and external validation are UNKNOWN.
