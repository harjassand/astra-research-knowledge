# Independent CTMC explosion proof

This derivation was made without reading `work/agents/chemistry` or any candidate argument there. The supplied network, charter, repository entry instructions and session template, and Xu arXiv:2409.05340v2 were the only inputs consulted before this file was written. Geometry is outside this audit. No literature novelty claim is made.

## Exact statement

For every four fixed constants k0,k1,k2,k3 > 0, the minimal stochastic mass-action CTMC on N0^2 with reactions

    R0: 0 -> 2A             v0=(2,0),   lambda0(a,b)=k0,
    R1: 2A -> 4A+B          v1=(2,1),   lambda1(a,b)=k1*a_(2),
    R2: 4A+B -> 5A+3B       v2=(1,2),   lambda2(a,b)=k2*a_(4)*b,
    R3: 5A+3B -> 3A         v3=(-2,-3), lambda3(a,b)=k3*a_(5)*b_(3)

explodes with positive probability from every finite initial state. Here falling factorials are zero when the molecule count is below their order. In particular, explosion occurs from (0,0), after a finite positive-probability path to a sufficiently large (a0,0).

The proof is wholly stochastic and does not use endotacticity or deterministic dynamics.

## Why the single prescribed cycle is insufficient

The growth cycle from (a,0) is R1,R2,R3:

    (a,0) -> (a+2,1) -> (a+3,3) -> (a+1,0).

At the third state, R2 has probability of order 1/a against R3. Demanding that it never occur gives a zero-probability infinite path. Thus a proof using only this cycle would have a genuine gap.

Instead, admit the following stall cycle, beginning with one extra R2:

    (a,0)
      --R1--> (a+2,1)
      --R2--> (a+3,3)
      --R2--> (a+4,5)
      --R3--> (a+2,2)
      --R2--> (a+3,4)
      --R3--> (a+1,1)
      --R2--> (a+2,3)
      --R3--> (a,0).

Every state and reaction above is legal for a >= 8. All intermediate B counts are positive, so these are excursions from B=0 until the last jump. The growth word has three jumps and increases a by one; the stall word has eight jumps and leaves a unchanged. A block accepts exactly these two words; it aborts at the first reaction incompatible with both words. An abort is simply excluded from the event used to prove positive-probability explosion. Nothing is asserted about its subsequent dynamics.

## Uniform one-step probability bounds

Write x for the A count in a block. Throughout either accepted block, a <= x <= a+4. Let p_i(x,b)=lambda_i(x,b)/lambda(x,b), where lambda is the sum of all four rates.

For a >= 8 define

    CB = 2*k0/k1,
    CL = (16*k0+4*k1)/k2,
    CR = k2/k3,
    CH = (16*k0+4*k1)/(3*k3),
    M  = max(1,CB,CL,CR,CH).

These constants are finite for every allowed parameter choice.

1. At (a,0), only R0 and R1 are active. The probability of a reaction other than R1 is at most

       lambda0/lambda1 <= CB/a^2 <= M/a^2.

2. At a block state with b=1 or b=2, R3 is inactive. A reaction other than R2 has probability at most

       (lambda0+lambda1)/lambda2
       = k0/[k2*x_(4)*b] + k1/[k2*(x-2)*(x-3)*b]
       <= 16*k0/(k2*a^4)+4*k1/(k2*a^2)
       <= CL/a^2 <= M/a^2.

   The inequalities use x-j >= a/2 for j=0,1,2,3 and a >= 8.

3. At a block state with b >= 3, all four reactions are active. In these blocks b is 3,4 or 5. The probability of R2 is at most

       lambda2/lambda3
       = (k2/k3)/[(x-4)*(b-1)*(b-2)]
       <= CR/a <= M/a,

   because (x-4)*(b-1)*(b-2) >= 2*(a-4) >= a.

   The probability of R0 or R1 is at most

       (lambda0+lambda1)/lambda3
       = k0/[k3*x_(5)*b_(3)]
         + k1/[k3*(x-2)*(x-3)*(x-4)*b_(3)]
       <= 16*k0/(3*k3*a^5)+4*k1/(3*k3*a^3)
       <= CH/a^3 <= M/a^3.

   Here x-j >= a/2 for j=0,...,4, and b_(3) >= 6. Hence a reaction other than R3 has probability at most M/a+M/a^3.

Bounds by a rate ratio are valid because the actual probability has the larger denominator lambda.

## Exact block probabilities and their bounds

Let q_a, s_a, d_a be the probabilities of growth, stall, and abort. They are nonnegative and sum to one. Their exact accepted-word probabilities are

    q_a = p1(a,0)*p2(a+2,1)*p3(a+3,3),

    s_a = p1(a,0)*p2(a+2,1)*p2(a+3,3)
          *p3(a+4,5)*p2(a+2,2)*p3(a+3,4)
          *p2(a+1,1)*p3(a+2,3).

A union bound for the growth word gives

    q_a >= 1-M/a-3*M/a^2.

The stall branch requires R2 at (a+3,3), so s_a <= M/a.

For the abort probability, the first two required reactions fail with total probability at most 2*M/a^2. At (a+3,3), R0 or R1 causes an immediate abort with probability at most M/a^3. R3 completes growth. R2 enters the stall branch with probability at most M/a. In that branch, three states require R3 and two states require R2. Conditional on entering, their total failure probability is at most

    3*(M/a+M/a^3)+2*M/a^2.

Thus

    d_a <= 2*M/a^2 + M/a^3
           + (M/a)*[3*(M/a+M/a^3)+2*M/a^2]
        <= D/a^2,      D = 3*M+8*M^2.

This is the load-bearing repair: the O(1/a) non-growing branch is accepted. A dangerous deviation after that branch has an additional O(1/a) factor, yielding a summable O(1/a^2) abort probability.

Fix any integer

    a0 >= ceil(max(8,8*M,2*sqrt(D))).

Then q_a >= 1/2, s_a <= 1/8, and 2*D/a^2 <= 1/2 for every a >= a0.

## Positive probability of infinitely many successful levels

At level a, repeat blocks after each stall until the first growth or abort. The Markov property at the returning state (a,0) makes their word probabilities identical each time. Infinite stalling at one level has probability zero because s_a < 1. Therefore the probability of growing to (a+1,0) before an abort is

    h_a = sum_{n>=0} s_a^n*q_a
        = q_a/(1-s_a)
        = q_a/(q_a+d_a).

Consequently,

    1-h_a = d_a/(q_a+d_a) <= d_a/q_a <= 2*D/a^2.

Let E be the embedded-chain event that every level a=a0,a0+1,... eventually grows without an abort. Applying the Markov property successively to finite prefixes, then taking their decreasing limit, gives

    P_(a0,0)(E) = product_{a=a0}^infinity h_a > 0.

For a quantitative lower bound, log(1-u) >= -2u for 0 <= u <= 1/2. Hence

    P_(a0,0)(E)
      >= exp[-4*D*sum_{a=a0}^infinity a^(-2)]
      >= exp[-4*D/(a0-1)] > 0.

This is a probability of an infinite set of allowed branching paths, not a probability assigned to one infinitely prescribed reaction sequence.

## Holding times: infinitely many jumps in finite physical time

For a countable-state CTMC with finite rates at each state, construct the embedded chain by the probabilities p_i, and attach holding times H_n=Z_n/lambda(X_n), where Z_n are independent unit-rate exponential variables, independent of the embedded chain. This defines the minimal process up to explosion, with explosion time tau=sum H_n.

Conditioning on the full embedded-chain event E does not change the conditional exponential holding-time distribution at any visited state, because E depends only on the reaction marks. Every accepted block at level a has at most eight jumps, and all its holding states have A count at least a. Since R1 is active there,

    lambda(x,b) >= k1*x*(x-1) >= k1*a*(a-1).

Let N_a be the number of blocks at level a, including the final growth block. Conditional on E, for n >= 1,

    P(N_a=n | E) = (1-s_a)*s_a^(n-1).

To justify conditioning on the infinite event explicitly: the numerator for n-1 stalls and growth at level a factors as s_a^(n-1)*q_a times the probability of earlier and later successful levels. Dividing by P(E) cancels those factors and divides by h_a, giving q_a/h_a=1-s_a. No independence of N_a across levels is needed for the expectation argument.

Thus E[N_a|E]=1/(1-s_a) <= 2, and by nonnegative summation,

    E[tau | E]
      <= sum_{a=a0}^infinity 8*E[N_a|E]/[k1*a*(a-1)]
      <= (16/k1)*sum_{a=a0}^infinity 1/[a*(a-1)]
      = 16/[k1*(a0-1)] < infinity.

Therefore tau is finite almost surely conditional on E. On E there is at least one growth block per level, so infinitely many jumps occur, and the states (a,0) tend to infinity. This is an explosion event with positive probability.

For an optional finite-time probability bound, Markov's inequality gives

    P_(a0,0)(tau <= 32/[k1*(a0-1)]) >= P(E)/2 > 0,

where the inequality counts only the subset of E satisfying the time bound. No finite simulation or asymptotic holding-time heuristic is used.

## Small states and accessibility from every finite state

The explosion construction deliberately starts above a0; none of its inequalities are applied to small A counts. At each finite state lambda0=k0>0, so the state is never absorbing, and a finite prescribed legal reaction path has strictly positive probability and finite elapsed time almost surely.

From (0,0), an even number a0 above the stated threshold is reachable by a0/2 copies of R0. The probability of that finite prefix is positive even though R1 competes after A reaches two. The Markov property then gives positive-probability explosion from (0,0).

More generally, take any finite state (u,b). Use finitely many R0 reactions to make the A count x as large as needed; this preserves b. If b=0, stop once x >= a0. If b>0, let j be 0,1 or 2 so that b+2j is divisible by three: j=0 for b=0 mod 3, j=1 for b=1 mod 3, j=2 for b=2 mod 3. Apply R2 exactly j times, then apply R3 exactly m=(b+2j)/3 times. Choose the preceding R0 births so that

    x+j-2*m >= a0,     x >= 8.

All R2 reactions are legal (positive B and A >= 4); all R3 reactions are legal (B >= 3 until the last one, and A >= a0+2 before the last one). The final state is (x+j-2m,0), above the explosion threshold. Every step has positive probability. Hence the same explosion mechanism is accessible from every finite initial state. This also covers initial A=0,1,2,3,4 and initial B=0,1,2 explicitly.

## Scope and provenance

The conclusion established here is the positive-probability explosion theorem for the exact supplied stochastic network and all positive rate constants. The proof was independently derived and written before any candidate-proof comparison. It is not a formal proof assistant replay or external expert validation. No geometry theorem or claim of literature priority is included.

Xu, *On the Regulary of Reaction Systems*, arXiv:2409.05340v2, HTML lines 58,70-73 define the falling-factorial convention; lines 94-95 define explosion. Lines 319-321 (Remark 4.8) state that the known order-10 endotactic example leaves the minimum explosive order open. These source facts are context only; none is a premise for the block proof. Source opened: https://arxiv.org/html/2409.05340v2 .
