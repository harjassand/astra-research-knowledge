# Independent order-seven CTMC explosion proof

This second derivation was made after freezing the independent order-eight proof. No chemistry candidate proof, including `work/agents/chemistry/ORDER7_FROZEN.md`, was read. The exact new five-reaction network was supplied by the coordinator. Geometry and literature priority are outside this audit.

## Statement and notation

Let k0,k1,k2,k3,k4 be fixed finite strictly positive constants. The reactions, jump vectors and stochastic mass-action rates are

    R0: 0 -> 2A              (2,0),   k0,
    R1: 2A -> 4A+B           (2,1),   k1*a_(2),
    R2: 4A+B -> 5A+2B        (1,1),   k2*a_(4)*b,
    R3: 4A+B -> 4A+2B        (0,1),   k3*a_(4)*b,
    R4: 5A+2B -> 3A          (-2,-2), k4*a_(5)*b_(2).

The minimal CTMC explodes with positive probability from every finite state of N0^2. In particular, it explodes from (0,0). The maximal reactant order is seven; applying this stochastic conclusion to an endotactic minimum-order problem also requires the independent geometry check.

Put K=k2+k3, theta=k2/K in (0,1), and epsilon=theta/16. Write F for either R2 or R3. Given that the reaction is F, it is R2 with probability theta and R3 with probability 1-theta, because these two reactions have identical reactants. Let delta=1 for R2 and delta=0 for R3.

## Accepted excursions from B=0

At (a,0), the direct accepted word is R1,F,R4. Its states are

    (a,0) -> (a+2,1) -> (a+2+delta1,2) -> (a+delta1,0).

It increases a by one if F=R2 and leaves it unchanged if F=R3.

At the B=2 state, accept one extra F instead of insisting on R4. The repaired word is R1,F,F,R4,F,R4, with states

    (a,0)
      --R1--> (a+2,1)
      --F-->  (a+2+delta1,2)
      --F-->  (a+2+delta1+delta2,3)
      --R4--> (a+delta1+delta2,1)
      --F-->  (a+delta1+delta2+delta3,2)
      --R4--> (a+delta1+delta2+delta3-2,0).

All choices delta_i in {0,1} are admitted. The repaired increment is in {-2,-1,0,1}. There are two direct words and eight repaired words. They each return to B=0 only at their last jump. Every intermediate holding state has A >= a and A <= a+4, with B in {0,1,2,3}. The final macrostate may have A=a-2; this is accounted for in the random-walk comparison below.

A macro is accepted if it follows one of these ten words, and aborts at the first incompatible reaction. Accepted macros have at most six jumps. Their legality is immediate for a >= 8; in particular every R4 has A >= 5 and B >= 2. An abort is excluded from the successful event, without any claim about the later CTMC path.

## Uniform probability bounds

At a holding state (x,b), let p_i=lambda_i/lambda, and let p_F=p2+p3. For a >= 8 and a <= x <= a+4 define

    CB = 2*k0/k1,
    CL = (16*k0+4*k1)/K,
    CR = 2*K/k4,
    CH = (16*k0+4*k1)/k4,
    M  = max(1,CB,CL,CR,CH).

All are finite.

At (a,0), only R0 and R1 are active, and

    1-p1(a,0) <= k0/[k1*a*(a-1)] <= M/a^2.

At a holding state with b=1, R4 is inactive, and

    1-p_F(x,1)
      <= (lambda0+lambda1)/lambda_F
      = k0/[K*x_(4)]+k1/[K*(x-2)*(x-3)]
      <= 16*k0/(K*a^4)+4*k1/(K*a^2)
      <= M/a^2.

At a holding state with b>=2 (here b is 2 or 3),

    p_F(x,b)
      <= lambda_F/lambda4
      = K/[k4*(x-4)*(b-1)]
      <= 2*K/(k4*a) <= M/a,

and

    p0(x,b)+p1(x,b)
      <= (lambda0+lambda1)/lambda4
      = k0/[k4*x_(5)*b_(2)]
        + k1/[k4*(x-2)*(x-3)*(x-4)*b_(2)]
      <= 16*k0/(k4*a^5)+4*k1/(k4*a^3)
      <= M/a^3.

These follow from x-j >= a/2 for j=0,...,4, and b_(2)>=2. Consequently, a reaction other than R4 at b>=2 has probability at most M/a+M/a^3.

Let d_a be the probability of an abort in one macro, and let q_a be the probability of the direct growth word R1,R2,R4. Since p2=theta*p_F at b=1,

    q_a >= theta*(1-M/a-3*M/a^2).

A union bound gives an explicit abort estimate. The initial R1 and the first F fail with total probability at most 2*M/a^2. At the first B=2 state, R0 or R1 contributes at most M/a^3; R4 completes a direct word, and F enters the repaired word with probability at most M/a. After entering repair there are two R4 requirements at B=3 and B=2, and one F requirement at B=1. Thus

    d_a <= 2*M/a^2+M/a^3
           +(M/a)*[2*(M/a+M/a^3)+M/a^2]
        <= D/a^2,           D=3*M+5*M^2.

Any negative accepted macro increment requires the repair branch, so its unconditioned probability is at most M/a.

Choose an integer threshold

    a_star >= ceil(max(8,8*M,2*sqrt(D),32*M/theta)).

For every a >= a_star:

    q_a >= theta/2,
    d_a <= 1/4,
    P(negative increment | accepted)
       <= (M/a)/(1-d_a) <= 2*M/a <= epsilon,
    P(increment=+1 | accepted) >= q_a/(1-d_a) >= theta/2=8*epsilon.

The conditional accepted increment is always in {-2,-1,0,1}. These estimates hold uniformly for arbitrary strictly positive rate ratios, with a parameter-dependent finite threshold.

## Accepted macroprocess dominates a growing random walk

Construct an auxiliary process A_n whose macro at A_n=a is sampled from the accepted-word distribution conditional on acceptance. Stop it if it goes below a_star; that stopped behavior is irrelevant on the event constructed below.

For comparison, let D_n be independent random variables with distribution

    P(D_n=-2)=epsilon,
    P(D_n=+1)=8*epsilon,
    P(D_n=0)=1-9*epsilon.

This is a probability distribution because 0<epsilon<1/16. At every a>=a_star the accepted increment stochastically dominates D_n. Indeed, its probability of either negative value is at most epsilon, while its probability of +1 is at least 8*epsilon. Checking the cumulative distributions at -2,-1,0 proves the stochastic order.

Use the same independent uniform variable for the inverse cumulative distributions of D_n and the accepted increment at A_n. Additional independent randomness chooses the particular accepted reaction word conditional on the endpoint. This couples them so that each accepted increment is at least D_n whenever A_n>=a_star.

Fix any integer L>=1 and set A_0=S_0=a_star+L, where

    S_n=S_0+sum_{j=0}^{n-1} D_j.

By induction, A_n>=S_n for as long as S_j>=a_star at all earlier times. This remains true even though the accepted increments depend on the current A count.

There is a positive-probability event on which S_n grows at least linearly from the start. The exact identity

    E[2^(-D_n)]
      = 4*epsilon+(1-9*epsilon)+4*epsilon
      = 1-epsilon

shows that

    Y_n=2^(a_star+epsilon*n-S_n)

is a nonnegative supermartingale, since

    E[Y_(n+1) | D_0,...,D_(n-1)]
       = Y_n*2^epsilon*(1-epsilon) < Y_n.

The strict inequality uses log(2)<1 and log(1-epsilon)<-epsilon. Also Y_0=2^(-L). The elementary maximal inequality for a nonnegative supermartingale gives

    P(some n has Y_n>1) <= 2^(-L).

It can be proved here by stopping at the first Y_n>1, applying optional stopping to the bounded stopping time truncated at N, and sending N to infinity. No unbounded-stopping equality is needed.

Consequently the event

    G={S_n >= a_star+epsilon*n for every n>=0}

has probability at least 1-2^(-L)>0. On G the coupling is valid forever and

    A_n >= S_n >= a_star+epsilon*n.

This explicitly controls occupation/revisits and avoids assuming that a merely positive mean drift implies pathwise linear growth.

## Restoring the genuine CTMC macro probabilities

The auxiliary process always accepts a macro. Restore the actual block law by attaching fresh independent uniforms V_n. At macrostate A_n=a, mark the macro as aborted if V_n<=d_a; otherwise use its already sampled accepted word. If an abort occurs, the rejected first-failure prefix can be sampled from its true conditional distribution and the original CTMC can continue; we only stop the proof's observation. Factoring the probability of an accepted word into (1-d_a) times its conditional accepted probability gives exactly the genuine embedded-chain macro law.

Let F be the event that none of these abort marks occurs. Conditional on the complete auxiliary path (and on its random-walk coupling),

    P(F | auxiliary path) = product_{n>=0}(1-d_(A_n)).

On G, define

    U = 1/a_star^2 + 1/(epsilon*a_star).

The integral estimate for a decreasing reciprocal-square function gives

    sum_{n>=0} 1/A_n^2
       <= sum_{n>=0} 1/(a_star+epsilon*n)^2
       <= U < infinity.

Since d_(A_n)<=D/A_n^2<=1/4, log(1-d_(A_n))>=-2*d_(A_n). Therefore on G,

    P(F | auxiliary path) >= exp(-2*D*U)>0.

The genuine successful event E=G intersect F thus has the quantitative bound

    P_(a_star+L,0)(E)
       >= (1-2^(-L))*exp(-2*D*U) > 0.

The coupling introduces auxiliary variables solely to describe a subset of the true CTMC's paths. The probability lower bound is for the true law, because the mark/word factorization reproduces every finite macro prefix.

## Physical holding times and explosion

As usual, generate reaction marks and attach independent unit-rate exponential variables divided by the total rate at each holding state. E depends only on reaction marks and auxiliary variables, so conditional on them the holding times retain their exponential means.

An accepted macro at a has at most six jumps and every holding state has A>=a. Hence its conditional expected physical duration is at most

    6/[k1*a*(a-1)].

On E, A_n>=a_star+epsilon*n and a_star>=8, so the total physical time tau for infinitely many accepted macros satisfies

    E[tau | E]
       <= (6/k1)*sum_{n>=0} 1/[(a_star+epsilon*n)*(a_star+epsilon*n-1)]
       <= (12/k1)*U < infinity.

The same bound holds after conditioning on each complete accepted path, and integrating over E preserves it. Thus tau<infinity almost surely on E. There are at least three jumps per macro, and A_n tends to infinity there. Infinitely many CTMC jumps therefore occur in finite physical time with positive probability.

For example,

    P_(a_star+L,0)(tau <= 24*U/k1)
      >= (1/2)*(1-2^(-L))*exp(-2*D*U)>0,

using Markov's inequality on E. This is an explicit finite-time explosion lower bound, with conservative constants.

## Accessibility and exceptional small states

From every finite state (u,b), repeated R0 births can raise A to any sufficiently large value of the same parity as u, with strictly positive finite-path probability. Let j be zero if b is even and one if b is odd. If j=1, apply R3 once; it is legal after raising A to at least eight, because then b>=1. It raises B to b'=b+j, an even number, without changing A. Apply R4 exactly b'/2 times. Choose the preceding births so that their resulting A count x satisfies x-b'>=a_star+1. The final state is (x-b',0), and all R4 steps are legal: B>=2 before each, and A>=a_star+3 before the last.

If b=0 this procedure simply uses births to a high B=0 state. Every finite prefix is legal and has positive probability, with finite elapsed time almost surely because all rates at each finite state are finite. The argument above applies with L=x-b'-a_star>=1, proving positive-probability explosion from every finite state, including (0,0). No large-a inequality was applied at an exceptional small state.

## Audit scope

This proof addresses exactly the supplied five-reaction CTMC with all five constants fixed strictly positive. It is an independent mathematical derivation, with neither endotactic geometry nor a novelty claim used as a premise. Formal replay, external validation and literature priority are UNKNOWN. The only imported general probability facts are the elementary quantile coupling for stochastic order, the bounded-stopping supermartingale maximal inequality, independent exponential holding-time construction, and nonnegative summation/Markov's inequality; their relevant applications are explicit above.
