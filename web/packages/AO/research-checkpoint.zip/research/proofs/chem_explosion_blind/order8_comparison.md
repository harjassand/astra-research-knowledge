# Post-freeze comparison with the chemistry order-eight argument

At the coordinator's explicit request, the chemistry order-eight frozen argument was first read after both of this worker's independent derivations had been frozen. Comparison completed 2026-10-08 10:18:56 UTC.

Files and SHA-256 at comparison:

    This worker fresh_derivation.md:
    c24924b44b14e63cb3fcb2d411d74b98d0d2d39869b1c91aad2d7c221edb70f6

    Chemistry ORDER8_FROZEN.md:
    9af73a909387daa08ff29a1bdd00d1661b23cce1ad52643fc1b156ff9801b7eb

The two derivations agree on the exact growth/stall words, all states and endpoints, O(a^-2) residual failure estimate, repeated-stall success probability, positive infinite product, and conditional geometric stall count. They also agree on the physical-time bound using at most eight jumps per block and the rate floor k1*a*(a-1).

No discrepancy or stochastic-proof gap was found. This worker's version additionally supplies explicit constants/thresholds and an all-finite-state accessibility proof. The chemistry argument's asymptotic constants are sufficient for its stated explosion claim. Its use of conditional holding-time laws is legitimate for the accepted event, which has positive probability and depends on reaction marks. No claim about conditioning on a zero-probability fixed infinite word is needed.

Geometry and deterministic statements in the chemistry file were not audited here and remain outside this comparison's conclusion. Reading and agreement are not formal or external validation. Neither chemistry's order-seven nor its lower-order candidate arguments was opened; the independent order-seven proof remains blind with respect to those arguments.
