# Blind order-seven audit: explosive

The exact five-reaction target has positive-probability explosion for every fixed strictly positive rate vector, from every finite initial state. The independent proof is preserved in `order7_fresh_derivation.md`. It was frozen at 2026-10-08 10:16:31 UTC with SHA-256

    5b4bafad2cb991a56d956bcc34b2614213ac9f2a54f24fd9fd2d884f2f4d3212

No file in `work/agents/chemistry`, including its order-seven candidate, was read before that freeze.

The accepted excursions are `R1,F,R4` and `R1,F,F,R4,F,R4`, where F is either of the two reactions with source 4A+B. The direct increment is zero or one; the repaired increment lies in {-2,-1,0,1}. All intermediate holding states have A>=a, and a macro has at most six jumps. The discarded macro probability is O(a^-2). Conditional on acceptance, negative increments have probability O(a^-1), while +1 has probability bounded below by half of theta=k2/(k2+k3)>0.

A quantile coupling above an explicit finite parameter-dependent threshold compares the accepted macroprocess with an independent walk having probabilities epsilon at -2, 8*epsilon at +1, and 1-9*epsilon at 0, where epsilon=theta/16. The exact exponential moment is 1-epsilon. A moving-boundary nonnegative supermartingale proves a positive-probability pathwise bound A_n>=a_star+epsilon*n for every macro index n. Restoring actual abort probabilities by independent coins preserves a positive probability because their total is bounded by a reciprocal-square sum. This also bounds the total expected physical holding time on that event.

Explicit quantitative bounds, with D and U defined in the proof, are

    P(success from (a_star+L,0)) >= (1-2^(-L))*exp(-2*D*U)>0,
    E(explosion time | success) <= 12*U/k1<infinity.

Thus finite-time explosion follows directly; no assumption that positive drift alone suffices is used.

The self-audit checked the following load-bearing points without finding a gap:

- All ten reaction words are distinct, legal, and first return to B=0 at their last jump.
- In a repaired word the final A may decrease by two, but every holding state within the word has A>=the starting a.
- Stochastic dominance requires and satisfies both the negative-tail and +1-tail inequalities; checking only the mean would be insufficient.
- The growing-cone event has positive probability by a bounded-stopping supermartingale argument, avoiding unproved occupation estimates or a transience assertion.
- The auxiliary always-accepted macrochain is restored to the true embedded-chain law by accepted/abort factorization. No CTMC propensity is changed.
- The event depends only on reaction marks and auxiliary randomness, so the physical exponential clocks retain their means when conditioned on it.
- Small states are handled by finite legal accessibility paths. All rate ratios are allowed; thresholds depend on them.

`check_order7.py` passed 28 exact rational macro-state diagnostics over four parameter vectors, with all ten words checked at each state. This is scoped finite arithmetic evidence, not formal or external validation of the infinite proof.

Exact status: new independent mathematical derivation and self-audit complete; exact finite arithmetic passed. Endotactic geometry is outside this audit. Formal proof assistant replay, external expert validation, and literature novelty/priority are UNKNOWN. The next decisive step is comparison with the separately frozen proof, followed by independent geometry and original-source novelty checks before an order-seven upper-bound claim.
