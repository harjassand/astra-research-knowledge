# Bounded primary-source priority pass: fixed Schur weights and local distinguishability

**Status:** `read` (primary sources opened and technical spans inspected; no candidate proof reconstructed). This is a first-pass search only. It does not establish novelty or priority.

## Target supplied by the coordinator

For an (N)-qubit permutation-invariant state in Schur-Weyl form
\[
\rho_N=\bigoplus_j p_j\,\rho_j\otimes I_{m_j}/m_j,
\qquad p_j=(2j+1)m_j/2^N,
\]
with arbitrary density matrices \(\rho_j\) on the spin irreps, the requested claim is a universal bound
\[
\chi^2(\rho_r\|I/2^r):=2^r\operatorname{Tr}(\rho_r^2)-1=O(r/N)
\]
for every \(r\le N/128\), followed by relative-entropy and fresh-preparation lower bounds of order \(N/r\), matched by polarized examples. A separate requested result is an exact trace-distance minimax asymptotic \(\sqrt{r/N}\), with the supplied \(\sqrt{3/(2\pi)}\) constant associated to mean \(J^2=3N/4\) and \(2/\pi\) associated to the white sector weights. These are treated here as coordinator-supplied targets, not verified results.

## Findings

The exact symmetry class is standard. Moroder et al., Proposition 5.1, state that every PI state is block diagonal in total spin, with an arbitrary density operator on each spin irrep and identity on the multiplicity space. Their preceding Schur-Weyl decomposition gives irrep dimension \(2j+1\) and multiplicity dimension \(m_j=\binom N{N/2-j}-\binom N{N/2-j-1}\) (arXiv HTML lines 212–244). Choosing \(p_j=(2j+1)m_j/2^N\) is exactly the maximally mixed state's sector distribution. This identifies the right parameterization but supplies no bound on a reduced state.

The closest general finite de Finetti theorems do not pin the representing mixture to the maximally mixed Schur weights. Christandl–König–Mitchison–Renner, Theorem II.7 (HTML lines 181–210), approximate the \(r\)-system marginal of any permutation-invariant state by a mixture of iid states, with trace-distance error \(2d^2r/N\) in their convention; the symmetric-subspace Corollary II.3 (lines 154–168) has \(2dr/N\). These are product-mixture approximations, not \(\chi^2\)- or relative-entropy closeness to \(I/2^r\). Ye–Bergh–Datta, Theorem 1 (HTML lines 131–144), give a stronger operator-order/max-relative-entropy-style finite de Finetti statement for arbitrary PI states, with a defect parameter and explicit \(\epsilon\); their standard trace-distance corollary (lines 227–230) again only approaches an unconstrained iid mixture. Neither theorem enforces the exact white sector distribution.

Singh–Cerf is the nearest relative-entropy analogue found. Their Theorem 1 (HTML lines 99–127) and Appendix D, Lemma 3 / Theorem 2 (lines 486–510), concern states invariant under every unitary commuting with a Hamiltonian, which makes each energy shell maximally mixed (definitions and shell structure at lines 52–72). Under those stronger energy-shell hypotheses they approximate local marginals by thermal-product mixtures and bound relative entropy for fixed \(k\ll\sqrt N\). The hypotheses and comparator differ: arbitrary states inside each SU(2) spin irrep are allowed in the target, and the target comparator is the maximally mixed qubit marginal.

Other adjacent results also miss the contract. Li–Smith, Theorem 1 (HTML lines 48–55), use a one-way-LOCC distinguishability norm, not unrestricted collective access to the retained subsystem. Koenig–Renner's finite symmetric-state representation (Theorem 5.3 / Corollary 5.6 region, HTML lines 694–785) is measurement-conditioned. Kossmann–Zeiss, Theorem 5.3 (HTML lines 886–891), constrain a one-sided extension through fixed-point channels and approximate separable bipartite structure. Eggeling–Werner (HTML lines 51–78, 89–120) give multipartite data hiding for Werner/permutation-invariant states with local-dimension and communication-pattern parameters; this is not the target's N-qubit, at-most-r-qubits-per-preparation model.

For exact reduced-density-matrix machinery, Popkov–Salerno (HTML lines 48–76, 90–145) compute marginals for fixed-magnetization eigenspace/projector families of a specific complete-graph spin model. The paper does not optimize over arbitrary \(\rho_j\) under the white sector weights. A supplementary adjacent source, Gao–Yan–van Enk, Eq. (18)–discussion (HTML lines 137–147), exhibits PI states \((1-p)|W\rangle\langle W|+pI/2^N\) that approach the global maximally mixed state while retaining genuine multipartite entanglement. It does not satisfy the fixed-sector-weight promise and does not contradict the target local-marginal claim; it is a useful warning that global trace proximity and entanglement are separate questions.

The targeted first-pass search did not identify a primary source with the conjunction of (i) exact white Schur-sector probabilities, (ii) arbitrary spin-irrep density operators, and (iii) the claimed local \(\chi^2\), relative-entropy, or exact trace-minimax bounds. Queries included Schur-Weyl/fixed-spin marginal purity, permutation-invariant Krawtchouk marginal bounds, symmetric data hiding, and finite quantum exchangeability. No direct Krawtchouk/local-purity theorem was opened. This is a bounded negative search, not evidence of novelty.

## What follows conditionally, and what remains open

If the supplied \(\chi^2\) bound is proved, then
\[
D(\rho_r\|I/2^r)=r\log 2-S(\rho_r)\le \log(2^r\operatorname{Tr}\rho_r^2)=\log(1+\chi^2),
\]
by the von Neumann/Rényi-2 entropy inequality. For independent fresh preparations, any protocol that accesses at most an \(r\)-qubit marginal per preparation has at most that per-copy relative-entropy distinguishability, by data processing and additivity; a constant-error lower bound then gives \(m=\Omega(N/r)\). The constants and error criterion in this reduction need to be stated precisely. This implication does not establish the supplied marginal \(\chi^2\) bound, a matching polarized-state upper bound, or the exact minimax trace constants.

**Next decisive source/proof gate:** obtain the proof or a precise construction for the arbitrary-\(\rho_j\) maximization under fixed \(p_j\), and compare its tensor-restriction coefficients with any local-purity/Krawtchouk identities. Then separately verify the two extremizers and their asymptotic constants. Until then the requested theorem, constants, and priority remain `UNKNOWN`.

## Primary sources inspected

1. Moroder et al., [Permutationally invariant state reconstruction](https://arxiv.org/html/1205.4941), Proposition 5.1, HTML 212–244.
2. Christandl, König, Mitchison, Renner, [One-and-a-half quantum de Finetti theorems](https://arxiv.org/html/quant-ph/0602130), Corollary II.3, Theorem II.7 and Theorem II.10, HTML 154–168, 181–210, 229–258.
3. Ye, Bergh, Datta, [Quantum de Finetti theorems for states and channels in any distance measure](https://arxiv.org/html/2609.40343), Theorem 1 and standard trace-distance form, HTML 131–144, 227–230.
4. Singh, Cerf, [Symmetry-driven thermalization via finite de Finetti theorems](https://arxiv.org/html/2604.09410), Theorem 1 and Appendix D Lemma 3 / Theorem 2, HTML 52–72, 99–127, 486–510.
5. Li, Smith, [Quantum de Finetti theorem under fully-one-way adaptive measurements](https://arxiv.org/html/1408.6829), Theorem 1, HTML 48–55.
6. Koenig, Renner, [A de Finetti Representation for Finite Symmetric Quantum States](https://arxiv.org/html/quant-ph/0410229), Theorem 5.3 / Corollary 5.6 region, HTML 694–785.
7. Kossmann, Zeiss, [Fixed points in de Finetti hierarchies](https://arxiv.org/html/2607.23689), Theorem 5.3, HTML 886–891.
8. Eggeling, Werner, [Hiding classical data in multi-partite quantum states](https://arxiv.org/html/quant-ph/0203004), model and security setup, HTML 51–78, 89–120.
9. Popkov, Salerno, [Reduced density matrix and entanglement entropy of permutationally invariant quantum many-body systems](https://arxiv.org/html/1112.6352), model scope and RDM formulas, HTML 48–76, 90–145.
10. Gao, Yan, van Enk, [On the permutationally invariant part of a density matrix and nonseparability of N-qubit states](https://arxiv.org/html/1401.4495), Eqs. (18)–(19) and discussion, HTML 137–147.
