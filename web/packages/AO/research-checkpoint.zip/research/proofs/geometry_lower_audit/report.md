# N175 lower-construction adversarial audit

The inherited one-metric lower construction survives this bounded, argument-exposed reconstruction. I found no counterexample or unresolved *global integration* obligation after working through the source's spectral, polar-geometric, whole-ball, matching and growth mechanisms. This is an internal mathematical audit of a candidate proof. It is not formal replay, external expert validation, or a historical-priority determination.

The exact conclusion remains: for each `4/9 < v < 1` and `1 < c < 9v/4`, there exists one complete smooth metric `g=g(v,c)` on `R^3`, Euclidean near the origin, with `Ric(g)>=0`, `AVR(g)=v`, and

`limsup_{k in N, k -> infinity} h_k(g)/(k+1)^2 > c`.

Consequently the lower construction supplies a supremum at least `9v/4` in the stated slow polar class. It does **not** supply one metric attaining the endpoint `9v/4`, nor a full-limit or all-degree lower bound. Replacing `(k+1)^2` with `k^2` does not change this limsup.

## Evidence and independent reconstruction

The authoritative status read was `N175_POST_SOURCE_STATUS.txt`, SHA256 `69a5c0c0311a18b68a9a8942655831a709425da248126d01712f15e9155bba9f`, together with all current N175–178 card notices. I did not use the older pending-source freeze as the current status. The argument audited was complete `N175_PROOF_v3.txt`, SHA256 `f3adfef248ab5a34ca6e12f1faf9231ea35abb48398092cce60553d3cc58e5b3`.

I directly read and reconstructed the load-bearing original source, *A Three-Dimensional Counterexample to Integer-Degree Harmonic Dimension Comparison*, pp. 5–37, pinned at [OpenAI/math commit fd4aeeb](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf), PDF SHA256 `6c7b86f0f59fcdb9da790ae15c943dc881e1ca4f758033611e84eca8dd93e4a2`. The preserved internal audits were used to identify the repaired interface and failure history, not as correctness premises. My direct reconstruction is recorded in `derivation.md`.

| Obligation | Reconstructed mechanism and verdict |
|---|---|
| Finite spectral inputs S1–S3 | Pair rank two plus countably many exact-block charts proves finite path avoidance, including higher multiplicity. Double retention uses a nodal-domain contradiction, not unsupported joint matrix surjectivity. The entire round block has trace-free control. Cross-block parity indices produce the adjacent exact double after removing the preliminary axial triple. Passed. |
| Countable compact angular library | Relative Baire spaces fix the crossing value and first jet, with no prematurely frozen neighborhood. Every selected band boundary is never designated as a crossing. Later detours converge smoothly to round; the common stem and each earlier finite loop are compact. This gives an individual positive global boundary gap for every fixed cutoff. Passed. |
| One metric, infinitely many collars | All loop, control, spatial-derivative and phase-derivative data can be selected before the radii. The `D_m` normalization supplies fixed all-order envelopes. Stage thresholds are finite requirements chosen afterward; `T_m>=2T_{m-1}` ensures local finiteness. Passed. |
| Ricci, fixed gauge and volume | Fixed pointwise angular area eliminates the trace term. I checked the exact normal, mixed and tangential Ricci formulas. A single integrable radial tail and a fixed Schur-complement buffer dominate every allowed control. The same radial factor works for the entire product. `f/r -> sqrt(v)` and area `4pi` give `AVR=v`. Passed. |
| Uniform whole-ball continuation | Positivity, constant preservation and exact mean preservation imply all-radius `L^2` contraction. Compact frozen half-cylinder limits identify the weak outer trace and rule out backward-growing roots. This gives a uniform operator modulus over the preassigned class, rather than a modulus acquired from the finished schedule. Passed. |
| Nonlinear countable matching | Fixed-cutoff graph transforms contract. The repaired entire local matrix error is `O_n(a_nu)`, with constants independent of the later stage. Birth-only columns assign exactly one mismatch to each control. Telescoping handles arbitrary off-plateau history; Gaussian weights give endpoint signs. Finite Brouwer plus diagonal extraction solves all coordinates of one countable product. Passed. |
| Global harmonic functions and degree | Exact compatible whole-ball traces glue by Dirichlet uniqueness. Weighted phase averaging includes completed and partial stages. Fixed-cutoff matrix and radial errors have zero Cesaro mean. Contraction and local ellipticity upgrade spherical `L^2` growth to pointwise degree. Passed. |
| Independence across birth graphs | A finite collection of normalized traces approaches distinct members of the same reference eigenframe. Its Gram matrix approaches the identity. Graph nesting and common birth radii are unnecessary. Passed. |

## Qualifications that are essential

1. The entire local matrix estimate in v3 cannot be weakened to a signed selected entry plus a global error bound. The preserved exact three-dimensional failure remains valid. The repaired estimate suppresses the graph error by requiring `D_m^(3/4) Omega_n(t)` to be small for every `n<=m` before starting stage `m`.
2. The axial sector crossing initially has at least three real eigenfunctions. It is not the final adjacent double. The even parity-list avoidance and indexed parity crossing are essential.
3. The double-slice Baire argument requires only point density within that slice. It does not require path avoidance while staying in the double slice. The later crossing-curve Baire argument takes place in the full parameter space with its value and first jet fixed.
4. Constants, spectral slopes, graph contractions and start thresholds are fixed-cutoff or fixed-band quantities. None is uniform in degree. The construction may require non-effective and arbitrarily large radii.
5. The slow polar class membership is actual: the link closure is `C-infinity` compact, the pointwise area form is fixed, `H_t=O_q(t^-3/4)` and `H_tt=O_q(t^-3/2)` for each fixed spatial order, and `b=f(e^t)e^-t -> sqrt(v)`. These are uniform over the selected common control product.

The repeated old loops give nonisometric cone links, so the unique-cone premise in [Huang, Theorem 1.6 and Corollary 1.9](https://arxiv.org/html/2109.07534v1) does not apply. This consistency check was made against the primary text, not merely its abstract.

## Ordinary imports and limits

The reconstruction uses compact elliptic spectra and regularity, smooth finite-cluster resolvents, finite/Banach implicit-function theory, scalar unique continuation, the classical Dirichlet theorem, local elliptic estimates, Baire and finite-dimensional Brouwer. Their hypotheses were checked where used. The primary scalar unique-continuation statement was read in [Aronszajn 1957, pp. 235–236](https://sites.math.washington.edu/~blwilson/Nodal/Aronszajn.pdf). The area restoration agrees with the primary [Moser 1965, Theorem 2, pp. 292–293](https://people.math.harvard.edu/~dafr/M392C-2018-MorseTheory/Readings/Moser.pdf), and was also derived directly. [Greilhuber–Kepplinger, Proposition 4.6 and Appendix C](https://arxiv.org/html/2312.16939v4) support the round product-space and resolvent interfaces; I independently checked the specific polynomial recurrence and the finite-cluster reduction. Gilbarg–Trudinger's [Theorem 6.14, Theorem 8.17 and Corollary 6.3](https://djvu.online/file/jxRRleAzbYjsl) were read from an OCR copy of the primary book and checked against its [official edition metadata](https://link.springer.com/book/10.1007/978-3-642-61798-0); the OCR is a provenance limitation. The imported general theorems were not formally replayed from their proofs in this audit.

The next decisive action is a specialist or formal review of the complete common-metric proof, especially the compact-family whole-ball operator argument and the countable projective matching map. The separate proposed upper bound is outside this audit. No new finite metric, numerical spectrum, runtime bound, publication, or dissemination was produced. External validity and priority remain `UNKNOWN`.
