# Comparison read only after the verdict was frozen

The own verdict and mathematical report were frozen at 2026-10-08 11:23:11 UTC in `VERDICT_FROZEN.json`. Only then were these integration files read: `order5_targeted_audit_v1.md`, `order5_blind_comparison_v1.md`, and `order5_almost_sure_audit_v1.md`. No target source or frozen audit report was edited after this comparison.

The later comparison changes no mathematical conclusion. Integration also identifies the original clamped proof's need for an explicit full-event tail argument and a full-excursion-word kernel carrying J as well as Delta. This audit independently supplied both, using a direct F-function contraction for the first and a countable full-path augmentation for the second. Integration's separate neutral-run Chernoff proof is another valid completion.

The stopped-cycle and all-state renewal analyses agree on every exceptional B value, the low-A activation grouping, finite failure witnesses, and the strict rate conditions. That agreement is internal corroboration only; the proof-level verdict rests on the reconstruction frozen before comparison.

Additional points in this audit are the source's zero-direction wording issue, the countably infinite state-space metadata correction, and explicit counterexamples to mark-count independence, forbidden slow reactions, irreducibility amplification, coefficient-boundary extensions, raw-power kinetics, and deterministic deadlines. The source definition was independently opened in the original primary paper, rather than inferred from the integration claim that the definitions match.

For presentation, the direct stopped-cycle plus global-reset and renewal argument is a clearer main proof than the original clamped path-weight construction. The latter remains a valid preserved alternative. Neither route certifies historical priority or exact minimum order.
