# Adversarial audit: order-five almost-sure explosion

**Verdict: no fatal proof gap found.** The exact fixture and the displayed strict parameter region admit a complete internal proof of almost-sure finite-time explosion from every finite state. The original positive-probability clamped construction also survives the audit. The three reports were read as frozen inputs; the arguments were reconstructed from the generator and independently checked. This is exposed internal review, not a blind proof, formal replay, external validation, or a priority determination.

The main reviewed theorem uses jumps `(2,0),(1,1),(0,1),(0,-2),(-1,-2)` with fixed falling-factorial rates `c0,c2(a)_2,c3(a)_3 b,c4(a)_3(b)_2,c5(a)_3(b)_2`, and the sufficient open conditions

`c_i>0`, `3(2c3+c2)<2(c4+c5)`, `8(3c3+c2)<7(c4+c5)`, `2c5<c4+c5`.

It includes `(1,1,1,4,1)` and the supplied open box. Constants are uniform over starting axis states for each fixed rate tuple. They are not asserted uniform over the entire unbounded parameter region. Necessity, the maximal region, and arbitrary positive rate tuples outside it remain UNKNOWN.

## Load-bearing proof audit

Line references below refer to the original paths, whose complete bytes and hashes were frozen in this folder.

| Target | Exact obligation | Result |
|---|---|---|
| `chem_order5_blind/report.md:25-61` | Stop at B=0 or A=2; retain terminal H; include the terminal death in predictable marking | Pass. `H(B_stopped)+D` has nonpositive mean increments at every truncated index. `E D<=2`, `E D1=(c5/d)E D`; no independence of total count and marks is required. |
| `chem_order5_blind/report.md:65-90` | Uniform tail of all events, including both slower reactions | Pass. The killed F-function contracts for B-changing events; mixing I gives `gamma=29/35` for the fixture. All integer B cases were proved directly. |
| `chem_order5_blind/report.md:94-130` | Positive cycle drift including ruin; exponential supermartingale | Pass. The terminal A=2 value is retained, upward changes are included, and the explicit K-series/Taylor bound is correct. |
| `chem_order5_blind/report.md:136-168` | Martingale growth, in-cycle downward fluctuations, independent clock | Pass. The martingale law is established before restricting to survival; `N_n=O(log n)` bounds every pre-event A from below. Axis holdings plus interior holdings have summable reciprocal rates. |
| `almost_sure/report.md:25-66` | All boundary states and low-A resets; finite full-event axis return | Pass. A<3 activates in at most two events. B=2 stops at the axis before a reset; B=3 uses max(F(1),F(2))=5; B>=4 permits the adverse -1 reset displacement. Ignored inputs give a finite convex mixture of statewise bounds. |
| `almost_sure/report.md:72-101` | Uniform trial success, finite failure recovery, legitimate Markov times | Pass. Failure has a finite witnessed event index, while success is the infinite no-ruin event. The Markov property is applied only at finite starts reached after failures. The bound `(1-delta)^k` does not require independent trials or an already nonexplosive chain. |
| `almost_sure/report.md:111-143` | All rate inequalities and open box | Pass. The first inequality controls H and p2; the second is exactly the p3 threshold; b>=4 follows algebraically. `mu=1-2c5/d>0`. The adverse box bounds are exact rational inequalities. |
| `chemistry/ORDER5_FROZEN.md:49-76` | Erased-update coupling, death-count bound, neutral input runs | Pass. Parity prevents walk-order crossings, and erased odd births cannot repeat. `E D<=3/2`. Full-chain F-contraction supplies a direct alternative to the informal neutral-run generating-function combination. |
| `chemistry/ORDER5_FROZEN.md:80-119` | Accepted-path law, conditioning, path weighting, physical-time transfer | Pass. D<=floor(n/2) keeps A strictly above the clamp. Exponential tails control discarded drift; acceptance deficits are summable on linear escape. Augmenting the axis kernel with its full accepted path law makes the absolute-continuity statement exact. Include the initial axis holding as well as excursion holdings. |

The independent proof in `INDEPENDENT_PROOF.md` spells out each step, including explicit constants, the countable event-chain construction, and all finite/infinite stopping distinctions. There is no remaining conditional mathematical lemma in the stated theorem, although correctness has only been internally reviewed.

## Geometry and source precision

The four exact source-face normals and their maximizing-arrow projections were reconstructed independently. The open vertex cones are positive combinations of adjacent normals, so the certificate covers every nonzero direction. The reaction vectors span R^2 and maximal reactant molecularity is five.

Use [Anderson-Cappelletti-Kim-Nguyen Definition 3.2](https://arxiv.org/pdf/1808.05328), which excludes directions orthogonal to the stoichiometric span. Here that means nonzero directions. [Xu v2 Definitions 4.2-4.4](https://arxiv.org/html/2409.05340v2) print a strong condition for all u without excluding u=0; a literal strict inequality at zero is impossible for every network. This is a source wording caveat, not a mathematical failure of the intended geometry. The network is not weakly reversible, and the target theorem makes no such claim.

One metadata correction is advisable: `chemistry/session.json` lists a "Finite CTMC" assumption. The state space is countably infinite N_0^2; the reaction list is finite. A finite-state chain with fixed finite rates cannot have this explosion. The actual theorem statements use the correct state space.

[Xu Theorem 4.6 and Remark 4.8](https://arxiv.org/html/2409.05340v2) were opened at the primary current source: they state order-two regularity and the minimal-order question alongside an order-ten example. This audit does not certify novelty, absence of an equivalent known order-five example, or the order-three/four boundary. The cited order-two bound plus the internally reviewed order-five example supports an interval 3 through 5, conditional on the ordinary source theorem and with priority still UNKNOWN.

## Independent checks and false extensions

`independent_checks.py` was written without reading the target check scripts. Exact rational diagnostics passed 36,864 active state/parameter cases across 49 rate tuples, including the fixture, every adverse corner of the stated closed parameter box, and c0=1/1000, 1, or 10^6. All 64 states with a,b in 0,...,7 passed jump-validity and boundary activation checks. The four face certificates and every vertex bounding-normal condition passed. The maximum checked B-event and reset-macro F ratios were exactly 4/5. These finite checks support arithmetic; the all-state argument is separate.

`COUNTEREXAMPLES.md` gives proof-level counterexamples to several false extensions:

- Stopped D1 marks need not be independent of D: from (3,3), D=1 forces D1_count=1, with positive-probability witness 36/205.
- Requiring the fast-only minimal excursion forever has probability zero because the excluded slow U hazard is harmonic.
- An explicit irreducible CTMC has explosion probability between 1/3 and 2/3. Positive explosion probability and irreducibility do not supply the audited renewal theorem.
- With c0=0, (0,0) is absorbing; with c2=0 an axis start is a nonexplosive constant-rate input process. If the zero-rate c5 arrow is removed, the active graph loses endotacticity.
- The strongly endotactic order-five network 0<->5A is nonexplosive. Order and geometry alone do not force explosion.
- Ordinary-power rates without falling-factorial disabling can jump to negative populations. Linear escape with rate n has infinite physical time. Almost-sure explosion gives no deterministic sure deadline.
- The exact network's product 3A lies outside the source hull; strong endotacticity tests maximal sources, not containment of every product.

## Provenance and next decisive gate

The verdict was frozen before reading any integration audit. Original artifacts and their hashes were preserved. No descendants, simulations, training, publications, outside messages, or physical experiments were used. The probability estimates and holding-time proof are mathematical arguments; agreement among internal agents is not external evidence.

Next gate: external probability/CRNT review or a formalized stopping-time/clock proof, plus a separate primary-source priority search. Minimality at order three/four and the largest permissible rate region remain open. Physical realizability, deterministic kinetic realization, and time-varying rate extensions were not established.
