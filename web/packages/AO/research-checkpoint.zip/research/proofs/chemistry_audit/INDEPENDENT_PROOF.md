# Independent reconstruction of almost-sure explosion

This reconstruction is an exposed adversarial audit: the three frozen target reports were read, but neither the integration audit nor another worker's verification code was read before the verdict. The estimates below were rederived from the generator. Internal review is not external validation or a formal proof replay.

## Exact contract

The state is `(a,b) in N_0^2`. The jumps I,U,V,D0,D1 are respectively `(2,0),(1,1),(0,1),(0,-2),(-1,-2)`. For fixed positive finite constants `c0,c2,c3,c4,c5`, their rates are

`c0`, `c2(a)_2`, `c3(a)_3 b`, `c4(a)_3(b)_2`, `c5(a)_3(b)_2`.

Put `d=c4+c5` and assume

`3(2c3+c2)<2d`, `8(3c3+c2)<7d`, `2c5<d`.

Then the minimal CTMC has `P_(a,b)(T_infinity<infinity)=1` for every finite state. The fixture `(1,1,1,4,1)` lies in this region. These are sufficient conditions; necessity and the maximal region are not claimed.

All rates are finite at finite states, and `q>=c0>0`. Construct the entire embedded event chain using fresh independent uniforms, even when its eventual physical time is finite. Independently attach iid unit exponentials `E_i`, and give jump i the holding time `E_i/q(X_i)`. This constructs the minimal CTMC until `T_infinity=sum_i E_i/q(X_i)`. It is permissible to prove statements about the entire event sequence first: doing so does not assume that its physical time is infinite.

## 1. A stopped excursion with all events included

Start with `a>=3,b>0` and stop after the first event reaching `b=0` or `a=2`. A reaches 2 only through a D1 event from 3; it never jumps below 2. At a pre-stopping state write

`s_b(a)=c3 b+c2/(a-2)`, `t_b=d b(b-1)`.

Conditional on a B-changing event, the birth probability is `p=s_b/(s_b+t_b)`. The input I leaves B unchanged. Since `a>=3`, `s_b<=c3 b+c2`.

Let `H(0)=0` and `H(b)=(3/2)ceil(b/2)+(1/2)1_(b=1)` for b positive. Add one to the H-increment for every pair death. At b=1 a birth contributes -1/2. At b=3 both possible contributions are zero: a birth leaves H unchanged; a death goes from H=3 to H=2 and the added count cancels the decrease. At odd b>=5 a birth contributes zero and a death contributes -1/2. At every even b>=2 the contributions are 3/2 for a birth and -1/2 for a death. Their unnormalized mean is

`(1/2)[3 s_b(a)-d b(b-1)] <=0`.

For integer b>=2 the ratio `(c3 b+c2)/(b(b-1))` decreases strictly with b: its difference between b and b+1 has positive numerator `c3(b+1)+2c2`. Its maximum is `(2c3+c2)/2`. The first region inequality therefore proves the displayed bound at every even b. An I event contributes zero.

At each deterministic truncation of the stopping index, `H(B_stopped)+D_count` has expected value at most its initial H. The terminal H is kept, including when the excursion terminates at A=2, and is nonnegative. Monotone convergence gives `E D<=H(b_initial)`. In particular from B=1,

`E D<=2`.

At every pre-stopping event index the D1 probability is exactly `epsilon=c5/d` times the pair-death probability. The indicator that this index is included is known before choosing its event. Summing these conditional equalities and using Tonelli gives

`E D1_count=epsilon E D<=2c5/d`.

This is an identity of expectations, not independence of D and its marks. The endpoint event is included. Conditioning on no ruin or on an accepted excursion would generally invalidate a fresh independence assertion; none is used here.

## 2. Uniform tail for the complete stopped excursion

Set `F(0)=0`, `F(1)=5`, and `F(b)=2^b` for b>=2. For a B-changing event its expected next F, divided by present F, is bounded as follows:

| B | Bound on the ratio |
|---|---|
| 1 | `4/5` |
| 2 | `2p`, where `p<1/4` |
| 3 | `(5+11p)/8`, where `p<7/55` |
| >=4 | `1/4+(7/4)p`, where `p<1/10` |

The first probability bound follows from `3(2c3+c2)<2d`. At b=3, `p<7/55` is precisely equivalent to `8(3c3+c2)<7d`. For b>=4,

`c3 b+c2 <=(b/2)(2c3+c2)<bd/3`,

so `s_b/t_b<1/[3(b-1)]<=1/9` and p<1/10. The last F-ratio is consequently below `17/40<4/5`. These bounds hold for all a>=3; killing F when a D1 event reaches A=2 only reduces its expected value.

The probability of I at any pre-stopping positive-B state is at most `z=c0/(c0+6c3)<1`, since `(a)_3 b>=6`. Thus the expectation of killed F after one full event is at most

`gamma F(b)`, where `gamma=z+(1-z)4/5<1`.

Iterate at deterministic event indices; on survival F>=4. If N counts the post-initial excursion events from B=1, then

`P(N>m | initial active state)<= (5/4)gamma^m`.

This proves termination a.s. and uniform small positive exponential moments for N, with every I and U included. There is no requirement that neutral-run lengths and the B-event skeleton be independent.

For the fixture the elementary values are `p_2<=3/13`, `p_3<=2/17`, `p_b<=1/13` for b>=4. One can use `z=1/7` and `gamma=29/35`. The b>=4 inequality is exactly `12(b+1)<=5b(b-1)`, with difference `(b-4)(5b+3)>=0`.

## 3. Axis cycles and a uniformly successful stopped episode

From `(A_n,0)` with A_n>=3, take the first event. If it is I, the cycle ends immediately with increment 2. If it is U, it adds one A and one B, then run the stopped excursion of Sections 1-2. End the cycle at B=0 or A=2; the latter is ruin even when B=0 simultaneously. Freeze the cycle chain at its terminal A=2 after ruin.

In a U-cycle the A-increment is one plus nonnegative upward increments minus D1_count, so before ruin

`E[Delta_n | history]>=mu=1-2c5/d>0`.

An I-cycle satisfies the same bound because mu<1. Let N_n be zero for I-cycles or after ruin, and otherwise the post-initial excursion count. Then `|Delta_n|<=2(N_n+1)`, and the preceding conditional tail holds uniformly. Consequently cycle increments have uniformly bounded second moments and some uniform exponential moment.

For an explicit choice retaining the target's constants, put

`eta=-(1/4)log(gamma)`, `r=sqrt(gamma)`,

`K=4 gamma^(-1/2)[1+(5/(4gamma))((1+r)/(1-r)^3-1)]`,

`theta=min(eta,mu/K)>0`.

Indeed `Delta_n^2 exp(eta|Delta_n|)<=4(N_n+1)^2 gamma^(-(N_n+1)/2)`. Bounding `P(N_n=0)<=1` and `P(N_n=j)<=(5/4)gamma^(j-1)` and summing `(j+1)^2 r^j` gives K exactly. Taylor's inequality now proves

`E[exp(-theta Delta_n)|history]<=1-theta mu/2` before ruin.

If sigma is the cycle ruin index, `exp(-theta A_(n wedge sigma))` is a nonnegative supermartingale. At a finite ruin index its value is `exp(-2theta)`. Applying the elementary truncated expectation bound, then taking the increasing union of finite ruin events, gives

`P_a(sigma<infinity)<=exp(-theta(a-2))`.

Thus every axis episode from a>=3 has success probability at least `1-exp(-theta(a-2))>0`. Success means the infinite event-chain episode avoids ruin. It is not a finite stopping time, and no Markov property at that success event is needed.

## 4. Every successful episode has finite physical time

On the original, unconditioned frozen cycle-chain probability space, write `m_n=E[Delta_n|history]` and `xi_n=Delta_n-m_n`. Uniform second moments give `sum E[xi_n^2]/(n+1)^2<infinity`. Orthogonality of martingale differences, L2 martingale convergence, and Kronecker's lemma imply `sum_(j<n)xi_j/n ->0` a.s. Therefore on no ruin,

`liminf A_n/n>=mu`.

This argument does not recompute drift after conditioning on no ruin; it restricts an a.s. result from the original law. The uniform excursion tail and the first Borel-Cantelli lemma also give `N_n=O(log(n+2))` a.s., for example with the cutoff `ceil(3 log(n+2)/(-log gamma))`.

Within a cycle, at most N_n events reduce A, each by one. Thus every pre-event A-coordinate is at least `A_n-N_n`, and on successful episodes it is at least `mu n/4` eventually. At the initial axis state `q>=c2(A_n)_2`, while at every post-initial positive-B state `q>=c3(a)_3 b`. The sum of reciprocal holding rates in cycle n is at most

`C/n^2+C N_n/n^3`

eventually. This includes the first axis holding time. Its sum over n is finite. Each earlier cycle contains only finitely many events a.s., with positive finite rates, so it contributes a finite reciprocal-rate sum.

Conditional on an event chain satisfying these bounds, the sum of attached exponential holding times is nonnegative with finite expectation `sum_i 1/q(X_i)`. It is therefore finite a.s. Each cycle contains at least one event, so there are infinitely many events in that finite time. This proves explosion on successful episodes. No unconditional finite expectation for T_infinity is asserted.

## 5. Global axis return, including every low-A reset

At A=0 only I is active and reaches 2. At A=1 only I is active and reaches 3. At A=2 only I and U are active; either restores A>=3, increasing B by at most one. Initial activation therefore takes at most two events. Once A>=2, it cannot fall below 2.

From active `a>=3,b>0`, ignore I events until the first B-changing event. Its input-only run is finite a.s. because the probability of another I is uniformly <=z<1. If that B-changing event reaches B=0, stop immediately. If it reaches A=2 while B stays positive, include one I/U reset and return to an active macro state. A birth macro changes B by +1; a death macro changes it by -2 or -1, or ends on the axis when B=2.

The terminal A after ignored I's is random, but every possible terminal active state satisfies the pointwise birth bounds of Section 2. The a.s.-finite input run gives a convex mixture of these same bounds, without an independence premise.

Use F from Section 2, with the axis absorbing at macro indices. At B=1 its macro ratio is 4/5. At B=2 it is at most 2p, because the process stops before any axis reset. At B=3 a death produces B=1 or 2, and `max(F(1),F(2))=5`, giving `(5+11p)/8`. At B>=4 a death's largest possible F is `2^(b-1)`, giving `1/2+(3/2)p<13/20`. Each ratio is <=4/5.

For every finite initial active B value, `P(no axis by k macro steps)<=F(b_initial)(4/5)^k/4`. The macro hitting index is finite a.s. Each of its finitely many steps has an a.s.-finite input run, one B-event, and at most one reset. The total full event count is therefore finite a.s. Every one of those finitely many holdings is finite a.s. Thus the axis is reached at a finite time before explosion, with no circular regularity assumption.

## 6. Finite failure and renewed trials

Begin a trial at any axis state with A>=2. For A>=3 launch the stopped episode. For A=2 require one I event, whose probability is `alpha=c0/(c0+2c2)>0`; it reaches `(4,0)` and launches the episode. An initial U is declared a failed trial and is recovered to the axis by Section 5. A ruined episode also ends after finitely many cycles, each with finitely many events a.s., at finite state `(2,B)`. Section 5 recovers it at a finite event index and finite time a.s.

Conditional on the finite history at any trial start, success probability is at least

`delta=min(1-exp(-theta), alpha(1-exp(-2theta)))>0`.

For the fixture one may use `delta=(1/3)(1-exp(-2theta))`, since `(1-exp(-2theta))/3<=1-exp(-theta)`. Delta is uniform in the trial's axis state for each fixed rate tuple; it need not be uniform as parameters approach the boundary or c0 tends to infinity.

Define future trial starts only on previous failures, or equivalently as event-chain stopping indices equal to infinity after success. On the event of k previous failures, each such start is finite a.s., so the ordinary Markov property at finite event stopping indices applies. Induction gives

`P(first k trials fail)<=(1-delta)^k`.

The all-failure event has probability zero. A success occurs after finitely many finite failures a.s.; its attached holding sum is finite by Section 4. Initialization from A=0 or 1 and arbitrary finite B is a finite activation plus Section 5 when needed. This completes the all-finite-state almost-sure theorem.

## 7. Independent geometry and exact order

The source complexes are O=(0,0), P=(2,0), Q=(3,1), R=(3,2). Their convex hull has outward normals `(0,-1),(1,-1),(1,0),(-2,3)` in cyclic order. All arrows at the tied maximizing sources have projections, respectively,

`(0,-1)`, `(0,-1)`, `(0,0,-1)`, `(-6,-4,-4)`.

Every entry is nonpositive and each face has a strictly negative entry. At O,P,Q each single outgoing arrow has nonpositive projections at the two bounding normals and a strict projection at one; at R this holds separately for both arrows. Each vector in an open vertex normal cone is a strictly positive combination of its bounding normals, so the required arrow projections are strict there. This covers every nonzero direction exactly, rather than sampling directions.

The reaction vectors span R^2. The original [Anderson-Cappelletti-Kim-Nguyen Definition 3.2](https://arxiv.org/pdf/1808.05328) therefore quantifies precisely these nonzero directions. Xu v2's Definitions 4.2-4.4 omit the exclusion of stoichiometrically orthogonal directions in the printed strong clause; interpreting a strict inward condition at u=0 literally would be impossible for any network. Use the original definition to avoid that source wording ambiguity. The endpoint product 3A need not belong to the source hull, and indeed does not; source maximality is the relevant geometric condition.

The maximal reactant degree is 3+2=5. The graph is not weakly reversible. Positive rates preserve the graph; c5>0 supplies the essential inward A decrement. The internal theorem establishes an explosive order-five strongly endotactic example under this precise definition. Xu's [Theorem 4.6 and Remark 4.8](https://arxiv.org/html/2409.05340v2) state order-two regularity and an open minimal-order question. A complete priority search and the order-three/four possibilities remain outside this audit.

## 8. Audit of the original clamped proof

The separate ORDER5_FROZEN argument also survives reconstruction. For m=floor(n/2)>=4 its displayed birth bound is <=1/4. After ignoring inputs and erasing odd-B births that leave `ceil(B/2)` unchanged, each accelerated update is +/-1 and its conditional up probability is <=1/4. From an odd B>=3 an up update requires both a zero birth and a subsequent even-state birth; from B=1 the first zero birth is forced. There cannot be two consecutive zero B-events. State dependence and erased I's preserve the pointwise bounds.

Couple to a 1/4-up nearest-neighbor walk using fresh common uniforms for update directions. Both positions have the same parity, so a positive gap is at least two and cannot cross in one update. When positions tie, the smaller up probability gives the order. Absorption of the actual accelerated walk is no later than that of the comparison walk. The killed exponential function `sqrt(3)^Y` contracts by `sqrt(3)/2`, giving the uniform tail. If D and U count down/up updates, `D-U=1`, `H_updates=2D-1`, and predictable conditional up bounds give `E D<=3/2`.

The informal combination of neutral-input runs and the skeleton can also be made immediate by Section 2's full-reaction F contraction, applied to the clamped process with a>=m>=3. Its B-decrements and event identities are identical, so this gives a uniform exponential moment for its entire event count without independence of neutral runs. Predictable death marking remains valid when an A decrement is clamped.

On accepted paths with D<=m, A is at least `n+1-D>=m+1`, so the clamp never operates. Equality of actual and auxiliary accepted finite path probabilities is exact. The acceptance loss is O(n^-2) for the initial U plus an exponential tail for D. Exponential moments control the discarded first moment. Conditional accepted drift remains positive for large n; its unconditioned martingale strong law yields eventual linear escape. The product of acceptance probabilities is positive on such paths because its deficits are summable.

To make the path-weight statement explicit, augment the axis increment kernel with its countable full accepted-excursion path law. For each finite accepted prefix the actual weight equals its normalized weight times the product of acceptances. Dominated convergence on decreasing prefix-survival events proves the corresponding infinite accepted-event formula, and the restricted actual law has density <=1 relative to the normalized full-path law. This transfers the a.s. summability of event-count-weighted reciprocal rates. The initial axis holding time must be included; adding one to the excursion count leaves the summability unchanged. Thus neither conditioning nor a hidden clock dependence produces a gap in the original positive-probability proof.
