# Concrete counterexamples to tempting extensions

These do not refute the audited theorem. They identify why its exact rates, finite-failure renewal, and physical-time argument are necessary. All constructions were independently derived for this audit.

## Stopped marks are not independent of their count

Use the actual stopped excursion from `(3,3)`, with termination at B=0 or A=2. On the event that its total pair-death count is D=1, B cannot reach zero: it starts at 3, births only increase it, and one death removes only 2. Its termination must therefore be at A=2. Since A started at 3 and every other A-changing event increases it, the sole death must be D1 and there can have been no A-increasing events before it. Hence

`P(D1_count=1 | D=1)=1`,

which differs from epsilon=1/5. The conditioning event has positive probability: the first event is D1 with probability `36/205`. Predictable marking still gives the unconditional identity `E D1_count=(1/5)E D`. Treating marks as an independent binomial count after stopping would be false.

## Excluding every slow birth destroys the fast-only path probability

Suppose a purported explosion construction prescribes, in every axis cycle, initial U, then V from B=1, then one pair death returning B=0, excluding all extra I and U events. At cycle start A=a, the post-U state is `(a+1,1)`. The probability that the next B-event is V rather than U is

`(a-1)/a=1-1/a`.

Forbidding I as well only reduces the actual prescribed-event probability. Such a minimal cycle changes A by either 1 (D0) or 0 (D1), so cycle j starts at `a_j<=a_0+j`. The probability of m prescribed cycles is therefore at most

`product_(j=0)^(m-1)(1-1/(a_0+j))=(a_0-1)/(a_0+m-1) ->0`.

Thus the infinite fast-only construction has probability zero even before accounting for other hazards. The audited proofs avoid this mistake by including full excursions.

## Positive explosion probability plus irreducibility is insufficient

Define an irreducible nearest-neighbor CTMC on Z. At 0 let the total rate be 1 and the two directions have probability 1/2. At each nonzero n, the probability of the outward move is 3/4 and of the move toward zero is 1/4. Set total rate `q(n)=n+1` for n>=1 and `q(n)=(|n|+1)^2` for n<=-1. Every adjacent transition rate is positive and finite, so the CTMC is irreducible.

After an initial step to +1 or -1, the probability never to return to zero is 2/3: this is the usual outward biased random walk, whose hitting probability is `(1/3)^|n|`, obtained by the stopped exponential harmonic function. Each sign's no-return event has probability `(1/2)(2/3)=1/3` from 0.

On negative no-return paths, coupling the outward moves to iid Bernoulli(3/4) variables and the strong law gives `|X_j|/j ->1/2`. The sum of reciprocal rates is then finite, and independent unit exponential holdings give finite-time explosion a.s. on these paths.

On positive no-return paths, `X_j<=j+1`, so the holding sum is bounded below by a tail of `sum_j E_j/(j+2)`. The centered random series `sum_j(E_j-1)/(j+2)` converges a.s. because its variances are summable, while the harmonic mean series diverges. This holding sum is infinite a.s. These paths do not explode.

Consequently from 0 the explosion probability is at least 1/3 and at most 2/3. The audited chemistry proof requires its uniform renewed success bound and finite failure recoveries; irreducibility cannot replace them.

## Boundary coefficients cannot be admitted automatically

If c0=0, `(0,0)` is absorbing, so the all-finite-state almost-sure conclusion is false. If c2=0 and the chain starts at B=0, V and both deaths remain disabled forever; it is a constant-rate `A->A+2` input process and is nonexplosive. These are concrete boundaries outside the positive open region.

If c5=0, removing that zero-rate arrow destroys the claimed geometry. For u=(1,0), the remaining arrows from A=3 sources are orthogonal to u. The u-essential maximal reactant is 2A and its arrow U has positive A projection, violating even endotacticity. It is invalid to retain an inactive edge solely to certify the active kinetic graph.

The stated inequalities are sufficient. Failure of one inequality, with all coefficients still positive, was not proved to imply nonexplosion. The maximal positive-rate region remains UNKNOWN.

## Reactant order and strong endotacticity alone do not force explosion

Consider the one-species reversible network `0 <-> 5A`, with constant positive input rate c0 and death rate `c5(a)_5`. It is strongly endotactic in one dimension: the maximal source in the positive direction is 5A with inward death; in the negative direction it is 0 with inward input. Its maximal reactant order is 5.

Nevertheless it is nonexplosive from every finite state. Its constant-rate birth count is a Poisson process. At every finite time, total deaths are at most `floor(a_initial/5)+birth_count`, because the state remains nonnegative. The total event count is therefore finite at every finite time. This also rules out an explosion before such a time by contradiction using the same count bound. The result concerns the specified five-reaction network, not every strongly endotactic order-five network.

## Ordinary powers and deterministic deadlines are different statements

Replacing falling factorials by untruncated ordinary powers is not a harmless convention. At `(a,b)=(1,1)`, the ordinary-power D0 propensity would be `4a^3 b^2=4`, yet its jump reaches `(1,-1)`. That is not a CTMC on N_0^2. Truncating ordinary powers separately would define another kinetics requiring a new audit.

Even the valid exact theorem gives no deterministic time by which explosion occurs surely. From `(0,0)` the first holding is Exp(1), so `P(T_infinity>t)>=exp(-t)>0` for every finite t>0. Almost-sure finiteness is the proved assertion.

Finally, linear escape of an event chain and unbounded rates alone do not prove explosion: a pure birth chain with rate n at state n tends to infinity but has holding sum `sum_n E_n/n=infinity` a.s., by the same centered-series argument. The audited polynomial lower rates and finite excursion counts are essential to physical-time summability.

## Geometry uses source maximality, not containment of every product

The exact audited network's product 3A=(3,0) is outside the source hull: the P-Q edge requires `b>=a-2`, which at (3,0) says `0>=1`. Strong endotacticity permits this; it tests arrows from directionally maximal sources. A claim that all reaction products belong to the source hull would be false for the exact fixture.
