# Fixed local dimension: qualified GO

Root requested a scientific go/no-go judgment after the qubit entropy and upper constructions froze. This is an internally derived proof route and scope judgment, not a completed qudit theorem or an independent audit of a future proof.

For fixed d, a Young partition lambda of N boxes has K=N-d lambda_d residual boxes after removing full d-columns. The polynomial U(d) representation factors as det(A)^lambda_d times the degree-K representation indexed by nu_i=lambda_i-lambda_d. A unitary Schur realization inside K tensor factors would give its operator norm at most ||A||^K, including nonnormal complex A. This is the correct analogue of the qubit residual spin degree M.

The exact one-body identity is useful. On each sector,

    tau_lambda = (lambda_d/N) I + (K/N) gamma_lambda,

where gamma_lambda is a d-dimensional density matrix derived from the residual tensor realization. Traceless collective generators annihilate the determinant contribution; a positive rank-one generator on the residual tensors is positive, proving gamma_lambda positivity and normalization. Consequently the mixture obeys

    tau_N >= (1-EK/N) I/d.

A uniform subGaussian K/sqrt(N) MGF makes EK=O(sqrt(N)), hence gives a well-conditioned own-marginal centered local Gram matrix. For a traceless Hermitian basis F_a normalized by Tr(F_a F_b)/d=delta_ab, choose A(z)=I+Z-(b dot z)I, Z=sum z_a F_a. The elementary matrix inequality

    log|det(I+W)| <= Re Tr W + ||W||_HS^2/2

follows from log det(P)<=Tr(P-I) with P=(I+W)^dagger(I+W), including singular matrices by a limit. It gives a determinant contribution exp[O(sqrt(N)|z|)+O_d(N|z|^2)]. The residual-degree MGF controls the other representation factor. Completing the square produces a dimension-dependent Gaussian generating bound.

There are d^2-1 coefficient variables. For fixed d the number of weight-w count vectors is polynomial in w. The same Cauchy, falling-factorial multiplicities and support-wise Gram method yields a convergent series starting at w=2 because one-body coefficients vanish exactly. This supports a uniform O_d((r/N)^2) centered Petz/relative-entropy theorem for r=o(N), subject to writing and independently auditing every representation and Gram step.

**Judgment:** GO for one bounded proof attempt and one target-only independent audit. It would clarify the actual quantum exchangeability principle and extend its scope beyond SU(2). It is a natural extension of the current generating method, so its existence does not separately certify novelty. Ordinary finite de Finetti approximation to some iid mixture does not directly imply this own-marginal quadratic result.

Permutation invariance excludes coherences between inequivalent symmetric-group/Young blocks. Arbitrary coherences inside each U(d) block are legal and should be stated that way. Fixed d is essential to this route's constants and coefficient count; no growing-d theorem is endorsed.

The matching qubit bounded heat upper is not automatically a qudit upper. This judgment concerns the structural entropy theorem and the resulting product-null preparation lower. A matched qudit ALLSEP certification theorem needs its own explicit target and sound measurement argument.
