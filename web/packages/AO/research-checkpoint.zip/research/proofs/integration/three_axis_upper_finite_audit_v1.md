# Exact-argument audit: finite three-axis ALLSEP upper

First complete verdict frozen at 2026-10-08 11:22:51 UTC. Scientific integrator Sol-max. This is an exposed adversarial audit of the separately blind originator's argument. My earlier heat-upper assessment remains unchanged; it was frozen before seeing this argument. I have not read another audit of this three-axis proof.

Audited ../heat_upper_blind/upper_FROZEN.md, SHA256 c975ab825d1026e5c053ca0ef7618dcc2ee73bb56d6b667b10bd09690a95d382. The complete file, including equations (6)-(21), was read and reconstructed. The earlier heat first-audit hash remains df8205c2768e759ddd9cff138b9de5de7aa0323c319477411c68577f589e4bfe.

## Verdict

No fatal mathematical gap found. The stated finite theorem holds for N>=4, integer 2<=r<=N/2, supplied exact b with delta=N|b|^2-1>0, and 0<eta<1. Its count ceil[24*10^9 delta^-2 ((N-1)/(r-1))^2 log(1/eta)] is a valid sufficient count, not an optimal numerical constant. It certifies against every independent identically supplied fully separable N-site null, without a Casimir, polarization or permutation-invariance promise on that null.

This is a complete internal exposed review, not formal replay, external validation or historical-priority clearance. Compared with the original heat proof, this is genuinely simpler and more useful: three axes; no spherical quadrature, growing-degree target expansion or compactness exclusion; and a finite range up to N/2 without an exponentially tiny alpha threshold. The supplied Bloch vector is still a charged interface if it must be acquired. The protocol retains a multioutcome score/eigenvalue; a binary coin replacement is not licensed by the proof.

## Exact means and finite parameter bounds

For c=N(r-1)/(N-1), t=r(r-1)/[N(N-1)] and d=t(N+N^2|b|^2), the supplied score T=(3X^2-3r-6c b_A X+d)/r has target expectation -(N|b|^2-1)(r-1)/(N-1). This uses random-subset pair identities and the average of the three collective squares, which is 4<J^2>/3.

For a product null with mean v and Q=average |v_i|^2, its expectation is exactly q'[1-Q+N|v-b|^2]. This is >=0 and >=L/2, where L=r|v-b|^2, because c>=r/2. All inequalities used in (10) hold over the stated finite range: c<=r, r-c=(N-r)/(N-1) in [0,1], a_A^2<=3r/N<=3/2 and d/r=q'(1+kappa)<=2. Thus T>=-8. Also delta<=2 and q'<=1/2, so 0<x=delta q'<=1.

The negative lower bound is uniform over arbitrarily polarized nulls. The score itself has a positive upper bound growing with r, so ordinary Hoeffding on its full range would lose the desired access gain. The one-sided mgf is the load-bearing replacement.

## Equations (7)-(14): all-product-array soundness

Equation (7) is exact for the sampling law. Conditional on a fixed product array and axis, the exponential moment is the rth elementary symmetric mean of positive a_i=cosh(lambda)+u_i sinh(lambda). Pair averaging at fixed sum increases e_r because its pair-product coefficient is e_(r-2) of the remaining positive entries. Therefore the elementary-symmetric mean is at most the rth power of its arithmetic mean. A tilted sign has variance at most one, giving the centered subGaussian bound for both signs of lambda. Tail integration gives E W^4<=16.

For (11), write T=3(W+D_A)^2+k_A, with |k_A|<=10 and D_A^2<=2L+2. Then E(W+D_A)^4<=8(16+D_A^4)<=192+64L^2, and T^2<=18(W+D_A)^4+200. The stated 3656+1152L^2 constant follows exactly. The final 4000(1+L^2) relaxation is valid.

For (12), Taylor's remainder is bounded by e^(8s)s^2 T^2/2, because T>=-8; for positive T the exponential remainder is even smaller. At s<=1/8 this coefficient is below 6000. For L<=1 the bound is <=1+12000s^2. For 1<L<=1/(24000s), the quadratic L contribution is at most sL/4 and is dominated by the negative mean term.

For the remaining L>1/(24000s), s<=s0=1/(6*10^9) implies L>250000. At least one of the three axes has |D_A|>=sqrt(L)/4. The subGaussian sample residual then has adverse probability <=2 exp(-L/128). On its complement T>=3L/64-8. Giving the two other axes only the universal e^(8s) bound yields exactly (13).

The high-field decrement is at least 1/(512*6000)=3.2552083e-7. The full exponential multiplier increases by at most 16s<=2.6666667e-9, and the adverse tail is below 1e-9. Hence (13) is strictly below one. The all-field bound E exp(-sT)<=1+12000s^2 follows. It is pointwise for every product array, including nonidentical mixed single-site states. Linearity of the fixed outcome function then covers every fully separable mixture; no fourth-moment bound for that mixture is assumed.

## Equations (15)-(19): target tail and completeness

The maximally mixed state's magnetic quantum numbers conditional on j are uniform. At least one third satisfy |J_z|>=j/2, including all small j cases. Thus its spin tail is bounded by three times its |J_z| tail. Hoeffding for the N unbiased signs 2J_z gives P(j>=u)<=6 exp(-u^2/(2N)). The target shares this spin law, and each collective Pauli sum has spectrum bounded by 2j inside a spin sector. Equation (16) therefore holds for arbitrary internal sector states and every axis.

Virtually measuring all sites along one axis is legitimate only as an analysis of the local measurement law: the projectors commute and summing unselected outcomes gives the actual selected-site law. Conditional on the full outcome population, the deterministic-population version of (7) applies. Splitting X/sqrt(r) into sampling residual and sqrt(q) times the global scaled sum gives (17) by a union bound. At q<=1/2, both exponent denominators relax to 16.

The score obeys |T|<=6Z0^2+10: use 6|a_A Z0|<=3Z0^2+3a_A^2 and the finite parameter bounds above. Integrating (17) gives the explicit upper 1.8681459<2 in (18). For V=T+x, one short omitted justification is E exp(|V|/2000)<=exp(1/2000) sqrt[E exp(|T|/1000)]<2. Hence E|V|^p<=2 p! 2000^p. Centering removes p=1; summing the remaining power series for |lambda|<=1/4000 gives exp(16*10^6 lambda^2). The choice lambda=x/(64*10^6) is admitted for x<=1 and yields the stated exponent m x^2/(256*10^6) in (19).

## Equations (20)-(21): rejection and copy count

On the rejection event, exp(-s sum T)>=exp(msx/2). For independent null copies, the all-SEP mgf bound multiplies. Since s<=x/(4C), Markov gives exp(-msx/4). The displayed e-value form is equivalent and has expectation at most one on each null copy.

The sufficient copy count is ceil[max{4/(sx),256*10^6/x^2} log(1/eta)]. Since 0<x<=1 and s0<=1/(4C), s>=s0 x. Thus the soundness coefficient is at most 4/s0=24*10^9, which dominates completeness. This verifies (1). As x tends to zero, the sharper completeness coefficient 256*10^6 dominates the soundness coefficient 16C=192000. Finally q'>=r/(2N), so the claimed N^2/r^2 preparation order is correct.

A finite grid of 9,801 scalar fixtures N=4..200 checked c, r-c and q' inequalities; it is only an arithmetic diagnostic. The inequalities above are analytic for every admitted N and r. No experiment or external validation is inferred from that finite check.

## Interface and comparison consequences

The bounded effect (4) is correctly in [0,I]. Retaining the polynomial score or its multioutcome eigenvalue supplies the proof's information. A randomized binary outcome would discard information and would require a separate rate proof. Classical implementation needs only a random subset, one of three axes, a pooled integer and ordinary arithmetic; there is no actual global Pauli measurement or Schur transform.

The proof's independent null-copy statement is sufficient. It also extends by conditional mgf to each conditionally fully separable copy, provided b, s and the threshold are fixed before testing. Cross-copy null states need laboratory separability to preserve that condition; unconditional per-copy separability alone is insufficient. The target completeness statement remains for independent fresh preparations.

For the theorem as written, b is supplied exactly. If acquired, the anchor error changes the target gap to q'[delta-N|b_anchor-b_true|^2]. Clipping a calibrated anchor to the legal norm ball preserves null soundness; power needs an independently justified gap and confidence. The count in (1) does not itself charge an acquisition phase. A separate calibrated statement can use the already preserved white-law O(r) pooled-variance bound.

An additional extension follows from this audited argument: its upper does not actually require target permutation invariance. Random-subset means and the target tail use only its average one-body Bloch vector and total-spin law. The finite upper is therefore valid for a general N-site target with the same spin weights and a strict average-mean margin. The centered lower and matched theorem still require their permutation-invariant/tail premises. This extra upper scope should be explicitly proved and labeled if incorporated; it is not a claim about a non-PI lower.

Overall this separately blind proof should replace the enormous-constant asymptotic heat proof as the main qubit upper spine. Preserve both frozen arguments and their independent provenance. The earlier heat proof remains a valid alternative, not a disproved result.
