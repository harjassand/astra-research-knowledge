# Dual exact-argument qudit audit

Checkpoint: 2026-10-08 11:28:59 UTC. Scientific integrator Sol-max. Both complete frozen proofs have now been read and reconstructed. This is an exposed audit of two originators, with their independent provenance retained. It does not claim that this integration audit was blind.

The originator file ../thermal/qudit_centered_entropy_FROZEN.md has SHA256 5191ed718cc7c57cb2a342784d1e5a6215c9616066ea734f3752d25c8bbcfd38. The independently target-only file ../qudit_blind/proof.md has SHA256 fa5907575916161b8cc048c795ce634857450a792b827975f66fa3b441602b85. My first originator verdict was frozen before reading the latter, in qudit_originator_first_audit_v1.md, SHA256 d7302e9f01da580f58eaf2e0672c83aafd1e4148a9a6ccf416beed1250ab9697.

## Verdict and exact scope

No fatal mathematical gap found in either derivation. Both prove a uniform own-marginal centered Petz chi-square and quantum relative-entropy bound O((r/N)^2) for fixed local dimension d and a fixed uniform subGaussian residual-Young-box MGF. Both handle arbitrary states inside the unitary irreps; permutation invariance excludes coherence between inequivalent symmetric-group blocks. Both references are full rank in their stated finite ranges. Neither proves that the tail condition implies entanglement or supplies a matching qudit certification upper.

The two proofs have genuinely different coefficient calculations: a multivariate generating polynomial with polynomial-in-weight count vectors, versus a one-variable centered-observable polynomial followed by exact polarization and a weighted orthonormal basis. The common representation-theoretic inputs are standard unitary Schur-Weyl realization and determinant/highest-weight twisting. Agreement is internal corroboration, not external specialist validation or priority clearance.

## Determinant twist and residual tensor realization

Writing m=lambda_d and mu=lambda-m(1,...,1), the residual partition has K=N-dm boxes. Tensoring its polynomial representation by det^m raises every highest-weight coordinate by m. Its U(d) equivalence can be chosen unitary. The blind proof supplies the complex extension explicitly: differentiate the unitary intertwining identity, extend complex-linearly on the Lie algebra, exponentiate positive Hermitian matrices, and use polar decomposition for every invertible complex matrix. This is sufficient for its Cauchy circles, where ||zX||<=1/2 makes I+zX invertible.

For a general singular matrix, polynomial continuity extends the identity from the dense invertible set. det^0 is one; a positive determinant exponent makes the action zero if the determinant is zero. The originator writes this case directly. There is no use of a normal-matrix eigenvalue estimate for a nonnormal matrix. The residual representation has an invariant isometric copy in K tensor factors, so its norm is <=||A||^K; the unitary intertwiner does not alter that bound.

## The one-body identity is a density identity

For every Hermitian H, the derivative of the determinant twist is m Tr(H), while the residual generator is the sum of K copies of H. Transporting a sector density matrix into its isometric tensor realization gives a positive normalized state; averaging its K one-site marginals gives a genuine d-dimensional density matrix gamma_lambda. Thus

    N tau_lambda = m I + K gamma_lambda.

This is an equality for all Hermitian H and therefore an exact density-matrix equality, not only a traceless mean bound. K=0 is harmless because gamma is multiplied by zero. Averaging gives tau=(1-EK/N)I/d+(EK/N)gamma for some density matrix gamma.

The originator bounds EK/sqrt(N) by sqrt(A exp(B+C)); the blind proof obtains the stronger simple Jensen bound log(A)+B+C. Their respective finite N thresholds imply EK/N<=1/2, so tau>=I/(2d). The originator additionally bounds its normalized traceless Bloch length by one half. All constants are independent of N for fixed d,A,B,C.

## Noncommuting weighted Parseval and normalization

The originator's basis T_a has Tr(T_aT_b)=d delta_ab. Its centered B_a=T_a-b_aI have a genuinely complex Hermitian Gram G. Positivity of tau gives G>=I/2 by the exact Hilbert-Schmidt identity for any complex coefficient vector. For R=rho T^-1, ||R||_T^2=Tr rho^2 T^-1, and its basis coefficient is Tr rho B^dagger by trace cyclicity. Separate supports are orthogonal; the identity and centered basis span every operator. The inverse conditioning factor is 2^w on support size w.

The blind proof instead chooses a complete operator basis A_a orthonormal for Tr(tau A^dagger B), with A_0=I. It need not be Hermitian. Each active A_a and its adjoint are centered and have operator norm <=sqrt(2d). B_a=A_a tau is orthonormal for Tr(Y^dagger Z tau^-1), and its coefficient against rho is exactly Tr(A_a^dagger rho). Tensoring gives Parseval for rho-tau tensor r. Expanding (rho-sigma)^2 inside its weighted trace gives Tr rho^2 sigma^-1-1, because each cross term has trace one. This argument is valid without any commutation assumption.

Both methods cancel every one-support coefficient exactly. Neither replaces a complex Gram by its real part, and neither pays an inverse-density norm exponential in the whole access size r.

## Cauchy and polarization counts

For the originator, the determinant-square trace inequality holds for every complex matrix, including singular ones. The centered generating bound is A exp(L^2/2) exp(SN|z|^2). Radius squared w/(2SsN), with s=d^2-1, gives coefficient bound exp(w)(2SsN/w)^w. Falling factorials and support conditioning yield q=4eSs alpha/(1-alpha)^2. The stated range gives q<=1/5. Count vectors are <=(w+1)^(s-1). The reverse majorization (w+1)^(s-1)<=(s-1)! binom(w+s-1,s-1) sums to at most 25(s-1)!(5/4)^s after shifting the weight-two tail. These give exactly the displayed C_d.

For the blind proof, a centered complex X has trace controlled by ||tau-I/d||_1, and the matrix-logarithm series is legal for ||zX||<=1/2. The radius sqrt(k)/(||X||sqrt(N)) is admitted for k<=N/4. The binomial inequality binom(N,k)>=(N/k)^k holds termwise. Its exponential prefactor is bounded by c0^k because A>=1 and sqrt(k)<=k. Thus the diagonal multilinear moment is <=(c0||X||sqrt(k/N))^k.

Exact sign polarization is valid for complex symmetric multilinear forms: only monomials in which every argument appears once survive the sign sum. The norm kM0 of each signed sum contributes k^k, divided by k! from polarization, and k^k/k!<=e^k. This leaves only a controlled exponential, not an extra factorial or a power of k. There are binom(r,k)(d^2-1)^k active basis strings. A second k^k/k! estimate gives the stated geometric majorant sum_(k>=2)(Gamma r/N)^k.

The blind finite sum is proved for r<=N/4. Its cleaner quadratic corollary r<=N/(2Gamma) lies within that range because Gamma>2. Its N0=max(4,ceil(4(log A+B+C)^2)) guarantees the reference lower bound. For fixed parameters every subextensive sequence eventually enters the quadratic range. No growing-d theorem is implied by either set of constants.

## Relative entropy and operational consequence

The separately diagonalized spectral-overlap probability law proves D<=log Tr rho^2 sigma^-1, with zero rho eigenvalues carrying zero weight. Both use a positive full-rank sigma, so the relative entropy is finite. The product tau tensor N is a legal unrestricted fully separable null. Additivity and the permutation-invariant canonical-slot simulation give the preparation lower for a fixed testing gap, allowing arbitrary joint quantum measurements on accessed registers and classically adaptive labels.

There is no matched qudit upper in these proofs. An arbitrary tail-bounded state can be separable, so a separate target-power margin is required. Correlated target preparations, coherent global-address queries, growing local dimension and adaptive expected-readout accounting remain outside the result. Deterministic charged site budgets give the stated square-budget lower; merely knowing a common cap does not identify actual adaptive readout consumption.

## Presentation recommendation

The one-variable/polarization derivation is a concise general fixed-d proof with a simple geometric majorant and a less restrictive reference-rank threshold. The multivariate derivation makes direct continuity with the qubit coefficient method and support-weight refinements transparent. Either can be the main proof after editorial consolidation; preserve both freezes and provenance. The result is a meaningful general quantum exchangeability principle beyond the original white-qubit subclass, while historical novelty remains UNKNOWN.
