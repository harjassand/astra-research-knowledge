# Collective-fluctuation premise: substantive GO

Root asked for a bounded scientific judgment at the Phase 3 checkpoint. This records an internally derived route, not an audit of a future full proof. Checkpoint: 2026-10-08 11:35:18 UTC.

The intended premise is fixed d, a permutation-invariant state with its own marginal tau>=kappa I, and a uniform MGF

    Tr rho exp[t sum_i(H_i-Tr(tau H)I)] <= A exp(B N t^2)

for all real t and every Hermitian H with operator norm <=1. Equivalently a fully specified sphere of all traceless directions can be rescaled. Bounds only at a finite list of basis directions are not the interface endorsed here.

For any centered Hermitian X, diagonalize it. Positivity of the joint measurement probabilities and the scalar inequality |1+a|<=exp(Re a+|a|^2/2) give

    |Tr rho (I+zX) tensor N|
      <=exp[N|z|^2||X||^2/2] Tr rho exp[(Re z) sum_i X_i]
      <=A exp[(B+1/2)N|z|^2||X||^2]

for every complex z. This is an entire scalar-polynomial bound; no matrix logarithm, determinant twist, Young-sector structure or small-|z| restriction is required.

Directional Cauchy then gives centered diagonal tensor moments O((constant ||X||sqrt(k/N))^k). Signed real polarization preserves Hermiticity and centering, and k^k/k! costs only an exponential per degree. Choose a normalized Hermitian traceless basis T_a and B_a=T_a-Tr(tau T_a)I. The genuinely complex Gram satisfies G>=kappa d I, while ||B_a||<=2sqrt(d). Thus arbitrary mixed centered coefficients are bounded, one-support coefficients vanish exactly, and weighted Parseval has a geometric support sum beginning at weight two. This supports centered Petz chi-square and relative entropy O((r/N)^2), with constants depending only on d,kappa,A,B.

**Judgment:** GO for one exact proof attempt and one target-only independent audit. It removes the near-I/d restriction and applies to faithful marginals with macroscopic polarization, provided every centered collective direction has a quantitative Gaussian tail. This is a substantive general quantum exchangeability principle rather than another cosmetic special case.

The premise is strong and must be supplied or independently verified. High-temperature concentrated states are plausible applications, not automatically certified members. The theorem still requires permutation invariance for arbitrary-label access lower bounds; random-subset twirling is a separate interface. It does not assert entanglement or provide a matching certification upper without a separately proved target-power margin. Historical priority remains UNKNOWN.
