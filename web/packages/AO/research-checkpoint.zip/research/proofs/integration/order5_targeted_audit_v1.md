# Targeted exposed audit of the order-five explosion proof

Checkpoint saved 2026-10-08 10:30:28 UTC, confirmed by the filesystem timestamp recorded in phase2_checkpoint_times.json. Auditor: integration, Sol-max. This audit read the chemistry lead's full `ORDER5_FROZEN.md` before reconstructing its interfaces. It is NOT a blind proof. Its conclusions were sent to root before reading `chem_order5_blind/report.md`; the latter remains unread at this checkpoint. No finite simulation, external review, or formal replay is being asserted. The initial manually estimated minute label was corrected; mathematical content is unchanged.

## Exact interface and verdict

The network is `0->2A`, `2A->3A+B`, `3A+B->3A+2B`, `3A+2B->3A`, `3A+2B->2A`, with falling-factorial rates `(1,1,1,4,1)`. Maximum source molecularity is five. The claim is strong endotacticity and positive-probability explosion of the minimal CTMC from a sufficiently large axis state `(n,0)`. This matches Xu's definition of explosive, which requires some initial state, rather than explosion almost surely or from every state.

I found no fatal gap in the frozen argument. Two technical steps should be written explicitly: the uniform exponential tail of the full event count, and the joint normalized kernel carrying both axis increment and excursion event count. These are repairable exposition obligations. The primary-source priority search is bounded and does not establish historical novelty. Exact minimal order remains open: even if this proof is correct and new, it gives `3 <= minimum <= 5`, not equality.

## Geometry and exceptional states

The source hull is the quadrilateral `(0,0),(2,0),(3,1),(3,2)`. All outgoing arrow projections on the four edge normals in the frozen proof are correct. At the vertical exposed edge, the B-only birth and B-only death are tangent; the A-losing death is strictly inward. Omitting that positive-rate reaction would invalidate strong endotacticity. On vertex normal-cone interiors, positive linear combinations of the adjacent edge-normal inequalities supply strict inwardness. The stoichiometric span is full, so every nonzero direction is covered.

No low-population state is used in the drift or clock argument. Choose `n>=N` with `m=floor(n/2)>=3`, then enlarge N so the upward bound and acceptance/drift constants hold uniformly. The auxiliary clamp suppresses only A loss at `A=m`, retaining the same death identity and B decrement. Every accepted actual path has `D<=floor(n/2)`, hence `A>=n+1-D>=m+1` at every event. The clamp never fires anywhere on that path. Every event probability of the actual and auxiliary embedded chains therefore agrees exactly there, including R0 and extra R1 events.

At B=1 no pair-death is enabled. Removing R0 still leaves a birth with positive rate. Auxiliary runs of R0 cannot be infinite because their conditional event probability is at most one half. At B>=2 the auxiliary birth probability is uniformly at most one quarter for large N. Nothing is being assumed about the actual process after a rejected excursion; the accepted path set alone has positive mass.

## Counting and conditional drift

Use `V=ceil(B/2)`. A birth from odd B is a zero V move, and two zero moves cannot be consecutive. At even B a V update moves upward with probability at most one quarter. At odd B>=3 an immediate death moves downward, while a zero birth followed by an upward update has probability at most one quarter (indeed no greater than its even-state conditional bound). Thus accelerated updates admit a common-uniform coupling to the biased nearest-neighbor walk with up probability one quarter. Both start at V=1; the coupled states have the same parity until the smaller walk is absorbed, which prevents the apparent distance-one crossing problem.

The comparison walk's positive-position exponential supermartingale gives an exponential absorption-count tail, so all stopped counting limits are integrable. For finite stopped excursions, conditional upward probabilities imply `E U <= (1/4) E H`. Passing to absorption uses the exponential tail. Since `D-U=1` and `H=2D-1`, `E D<=3/2` follows.

At every pair-death the conditional mark R4 has probability exactly one fifth, because its propensity and R3's share the same factor. Write `D_A=sum_k 1{the k-th death occurs} 1{mark_k=R4}`. The event that the k-th death is about to occur is measurable before its mark is drawn. Tonelli plus conditional expectation therefore yields `E D_A=(1/5)E D`, even though future stopping depends on earlier marks. The auxiliary increment includes the prescribed first R1 and satisfies `Delta>=1-D_A`; its expected value is at least seven tenths. Extra R0/R1 events only increase A and are not discarded.

Truncating at `D<=floor(n/2)` loses exponentially small probability AND first moment, because the total event count has an exponential tail and `|Delta|<=2J+1`. Conditioning on initial R1 cancels its probability in the normalized excursion law. Acceptance is `1-O(n^-2)-O(exp(-c n))` and the conditional increment retains uniform positive mean and an exponential moment.

## Explicit event-count-tail repair

Let L be the number of non-R0 events before absorption. The accelerated V update count H has a uniform exponential tail and `L<=2H`. Let G_i be the R0 count preceding the i-th non-R0 event. Sequentially use fresh uniforms to couple each neutral run to a geometric failure count with success probability one half. At every event, the conditional probability of an R0 is at most one half, even though its occurrence changes A and affects the later skeleton. This yields a pathwise bound by independent geometric variables for any predetermined number of runs; independence of the actual runs or of the skeleton is unnecessary.

For integer t, split `{J>t}` into `{L>floor(t/4)}` and `{sum_{i<=floor(t/4)} G_i > t-floor(t/4)}`. Extend the auxiliary run variables after absorption arbitrarily by zero if needed. The first event has exponentially small probability from the L tail. The second has exponentially small probability by the geometric-sum Chernoff bound; the threshold is roughly three times the number of terms, above its mean. This proves a uniform exponential tail and hence a uniform small positive exponential moment for J. It also establishes that the auxiliary embedded excursion cannot make infinitely many events before B absorption.

## Escape and full-word-kernel repair

Define a normalized kernel `L_n` on accepted finite reaction words, carrying both the resulting `Delta` and the total event count J. Its marginal axis-increment law is the frozen `K_n`. This avoids treating J as a function of Delta. Construct the normalized path law by drawing complete words from L_n at every axis visit; the axis marginal remains the K-chain.

Extend K below N by deterministic +1 increments solely for the normalized proof. Uniform positive mean and exponential moments yield a small-theta bound `E exp(-theta Delta)<=1-theta d/2`. The stopped exponential supermartingale gives a strictly subunit bound for hitting below N from a higher start. Overshoot below N does not cause a problem: nonnegativity allows bounded-time optional stopping followed by Fatou. On nonexit paths the martingale differences have uniformly bounded conditional second moments; convergence of their weighted sum with coefficients 1/j and Kronecker's lemma proves the stated martingale strong law and eventual linear growth.

For every finite sequence of accepted words, the true embedded-chain weight equals its normalized full-word weight times the product of the state-dependent acceptance probabilities. Monotone/dominated limiting arguments identify the accepted infinite path measure with density `product_j a_(Z_j)<=1`. On linearly escaping paths the sum of rejection probabilities is finite, so this density is strictly positive. Consequently the accepted escape event has positive true probability. This is a sub-Markov path measure argument; it does not substitute the conditioned chain for the physical chain.

## Physical clock

For an accepted word started at n, A remains at least n/2, so its total propensity is at least `(A)_2>=c n^2`. Under L_n the event count has uniform conditional mean. For each deterministic eventual-growth starting index l, Tonelli gives

`sum_(j>=l) E[1{Z_j>=d j/2} J_j/Z_j^2] <= C sum_(j>=l) j^-2 < infinity`.

Taking a countable union over l proves finite `sum J_j/Z_j^2` almost surely on linear escape. The true accepted path law has density at most one with respect to the normalized full-word law, so zero-probability failures remain zero. Conditional on the full infinite reaction word, the holding times retain independent exponential laws of the state-dependent total rates: this follows from the standard separate-uniform construction of event identities and exponential holding times. Their total conditional expectation is finite, so their nonnegative sum is finite almost surely. There are infinitely many accepted words and hence infinitely many events. This proves positive-probability explosion of the minimal CTMC; no independence between increments and J was used.

## Primary-source comparison checked in this phase

Xu, arXiv:2409.05340v2, submitted 9 May 2026, is still the latest arXiv version on the live abstract page. Section2 defines order by maximum reactant molecularity and section3 defines explosion at some initial state. Definitions4.2-4.4 match the graph premise, Theorem4.6 gives regularity for second-order endotactic systems, and Remark4.8 identifies an order-ten explosive witness and leaves the minimal order open. These are exact interface matches, not an analogy. URL: https://arxiv.org/html/2409.05340v2 ; version page https://arxiv.org/abs/2409.05340 .

Anderson-Cappelletti-Kim-Nguyen, arXiv:1808.05328, PDF pp6-7 (printed6-7), Example3.2, gives `0->2A->4A+B->6A+4B->3A`. It uses a prescribed cycle with summable missed-reaction probabilities and a finite sum of reciprocal rates. The new proof replaces that exact high-order word by complete noisy excursions with drift and summably small exit cost. The original source does not state the present lower-order branched/common-factor construction. URL: https://arxiv.org/pdf/1808.05328 .

Agazzi-Mattingly, Communications in Mathematical Sciences18(6),1605-1642(2020), abstract and initial model pages, treats positive recurrence, null recurrence, and transience. A full-text search for explosion found no occurrence. Its complete proof was NOT reconstructed here. Xu cites its order-seven examples separately for transience and null recurrence, not as the explosive witness. URL: https://archive.intlpress.com/site/pub/files/_fulltext/journals/cms/2020/0018/0006/CMS-2020-0018-0006-a005.pdf .

No publication or search result establishes novelty of the order-five network. A current primary open-problem statement and the failure of bounded exact-mechanism searches to find this construction support continued attack, but priority remains UNKNOWN.
