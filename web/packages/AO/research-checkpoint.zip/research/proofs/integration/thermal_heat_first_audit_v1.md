# First exposed audit of the bounded heat ALLSEP upper

Checkpoint: 2026-10-08 11:00:08 UTC, Sol-max scientific integrator. This assessment is frozen before reading any fresh quantum upper audit or derivation from the independent worker. It is exposed to the thermal lead's complete frozen candidate.

Audited `../thermal/bounded_heat_upper_FROZEN.md`, SHA256 `c0f85e6f39d4ac8be6089c2134dbe7c7cc99ed14ad7e94918906ac57aac7726a`, and its exact uncentered coefficient bound in `growing_relative_entropy.md`. I previously audited the centered lower proof separately.

**First decision:** no fatal mathematical gap found. The candidate establishes an asymptotic sound upper for every fully separable N-site null under the supplied target assumptions. Its unusually large constants do not invalidate the asymptotic statement, but this is not a practical finite-N certificate. Internal review and source comparison do not establish priority or external validation.

## Implementable effect and low-degree identities

The Bernoulli pass probability is exactly `exp[-(J_n/sqrt(r)-beta_n sqrt(r)/2)^2]`, hence is bounded in [0,1] without restricting the input. Site selection and the common measurement axis occur after preparation. It uses r local spin measurements and classical pooling.

The white moment inequalities `EY=1/4`, `EY^2<=3/16`, `EY^3<=15/64` hold for finite binomial sums. For r>=2, `2 Var(Y)>=1/8`. The two-tail estimate is at most `1/16` for `(Y-Y')^2`; on the retained Y,Y'<=12 region the divided difference is at least exp(-12). Thus `kappa_r>=exp(-12)/8` follows with the correct covariance factor two. Also q_r>=1/16, kappa_r<=1, and `|h_N||b_N|<=28/sqrt(N)` follow as stated.

The coefficient identity for a sampled site is `(2/sqrt(r)) E_white[x g(x-delta/2)]`; for two distinct sites it is `E_white[(4x^2-1)g(x-delta/2)]/(r-1)`. Parity eliminates exactly the listed Taylor terms. Bounds on the global second and third derivatives of g give the displayed uniform errors; there is no unbounded exponential expansion in beta. Averaging the sphere gives the required 1/3 factors. The first target term and the product quadratic expression consequently have the stated constants and signs.

The target's two-site coefficient trace is exactly zero from its Casimir expectation. Its Frobenius bound is valid: the symmetric spin moment matrix is positive semidefinite with trace 3N/4, and the distinct-site coefficient matrix is `[4 E sym(J_a J_b)-N delta_ab]/[N(N-1)]`.

## All Pauli supports, not fixed-degree truncation

For a product array, `|1+a|<=exp(Re a+|a|^2/2)` is valid for all complex a, so the generating function bound controls every degree. The mean-dependent prefactor is exp(D^2/2); common-radius Cauchy and coefficient multiplicities give a squared coefficient tail <=`112999 exp(D^2) alpha^3`.

The target tail constant `259875000 alpha^3` follows from the preserved uncentered bound: at q<=1/5, the degree-three tail factor of `sum (w+1)^4 q^w` is less than 462, and `36*462*25^3=259875000`. Thus the omitted expectation is O_K(alpha^(3/2)), uniformly over all degrees through r for bounded D. The two support Taylor errors are O_K(alpha^2), and the stated C_K bounds them by O_K(alpha^(3/2)).

## Uniform ALLSEP exclusion

The bounded-D calculation alone would be insufficient. The frozen proof supplies three complete exclusions.

1. When |g|<=1/2, centering the product generating polynomial removes the linear term. The sum of squared centered site Bloch vectors is at most N. The one-site Gram minimum is at least 1/2. The same support-wise Parseval method gives chi-square <=4046 alpha^2 and half trace distance <=32alpha. This comparison holds for every heterogeneous product array; it is not inferred from a one-body marginal.

2. The identical-product unshifted heat expectation is `T_r-kappa_r mu^2/6` plus a remainder bounded by `mu^4 exp(mu^2/2)/sqrt(24)`. Exact monotone likelihood ratio of the biased binomial |J| law proves monotonicity beyond the small-mu region. The field's linear expectation is bounded by `H alpha D/6`: conditioning on |J| gives an increasing signed conditional mean, whose covariance with the decreasing heat is nonpositive. The global shift Taylor remainder is <=H^2 alpha/12. The displayed K makes the negative quadratic dominate the field and comparison costs for all D>=K at small mu, and the explicit small-alpha restrictions handle the remaining mu region uniformly.

3. When |g|>1/2, the exact random-subset variance is at most 1/4 for J_n/sqrt(r). The heat-shifted mean vector has magnitude >=sqrt(r)/8. Chebyshev yields `min{1,c^2/(A^2 cos^2(theta))}` with c=1/2+sqrt(R), and integrating the uniform absolute cosine gives <=2c/A. For R=3 and r>=16384 this plus exp(-3) is less than 1/2. The low-mean benchmark remains greater than 1/2. Large means therefore cannot evade the bound by concentrating along a favorable axis.

All low-mean and large-mean null exclusions apply pointwise to product arrays. Convexity then covers all fully separable states. There is no supplied null Casimir or null Schur law in this soundness argument.

## Gap, resource scope and finite-size limits

The target minus the separable upper has leading term `kappa_r r(N|b_N|^2-1)/(6(N-1))`. A strictly positive liminf margin makes it at least c alpha eventually, after the O(alpha^(3/2)) errors. Hoeffding gives m=O(alpha^-2 log(1/eta)). For the finite set 2<=r<16384, the pair witness gives the same order with a larger uniform constant; no assumption that r_N grows is required.

For an acquired calibration vector, the completed-square target margin becomes `N|b_target|^2-1-N|b_cal-b_target|^2`. Clipping to the known target norm ball cannot increase calibration error. Independent target measurements have pooled variance O(r) from the white Schur two-body bound; Chebyshev plus median amplification gives the claimed O(N/r log(1/eta)) calibration cost, without requiring a Hoeffding range estimate that would lose the r gain. A model-free guarantee must explicitly include this phase and its confidence allocation.

The cost statement concerns independent fresh target preparations and deterministic maximum distinct-site access r. Saturated upper readouts are mr. The arbitrary-quantum lower holds against ALLSEP via the matching product marginal. A trusted Casimir promise changes the null class and admits a different linear order, so it must not be used to describe this quadratic cost as universal.

The broad cross-copy soundness wording is valid only when the multi-copy null is separable across the physical laboratories, with arbitrary correlations permitted inside each laboratory, or when each conditional fresh-copy input is fully separable. Merely imposing separability on each unconditional copy marginal would not imply conditional soundness. This qualification should be explicit in a final statement.

Quadrature and coin arithmetic can be approximated to error o(alpha); their precision and operations are extra classical costs. The proof claims the preparation order, not an optimized classical runtime or a moderate-N sample count. No robustness to imperfect white weights, unknown asymptotic margin, symmetry breaking, or correlated target preparations is established here.

## Promotion recommendation

If the fresh independent upper audit agrees, the exact quantum theorem plus this ALLSEP upper is a materially stronger result than white-state discrimination. Promote it as a scoped internally reconstructed preparation-versus-access theorem, preserving historical priority UNKNOWN and the supplied/acquired promise distinction. Provide an explicit static polarized Schur-sector family to remove dependency on an older unvalidated bath-time asymptotic for existence of examples.
