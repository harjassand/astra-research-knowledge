# Dual rate-phase audit: feedback and critical clocks

Checkpoint: 2026-10-08 11:57:25 UTC. The first originator-only verdict was frozen before this fresh report was opened. Both current integration reviews are exposed audits. The fresh worker's proof independence is limited to reconstructing a supplied exact target without reading the two originator phase arguments; it does not assert independent discovery of the proposed formula.

Inputs: originator strict and critical files recorded in `order5_rate_originator_first_audit_v1.md`; fresh `work/agents/rate_phase_blind/report.md`, SHA256 `7e2ff3d2079acf79a9b8cfe3d2fe300b753aa870d6f18f57545badb88f895a94`.

**Verdict: PASS for the fresh complete classification, independently of the originator's perturbation and accelerated-trace arguments.** The exact five-jump network with fixed finite positive coefficients is almost surely explosive from every finite state iff

    mu=1-[k4/(k3+k4)] h(k2/(k3+k4)) > 0,
    h(beta)=[1+beta exp(2beta)(2beta)^(-beta)gamma(beta,2beta)]/2.

It is nonexplosive for mu<=0, including equality. The gamma is lower incomplete gamma, and all intensities use falling factorials. Diagram geometry is a separate independently audited premise; this statement classifies rates of this diagram only.

## Uniform tails are genuine full-chain estimates

The macro birth/death bounds include every immigration run and the A=2 activation after a marked death. The killed F(B)=2^B estimate outside B<=M yields

    P(tau>n)<=2^(L-1)(7/8)^n

for an initial B<=M+L, because on survival B>=M+1. Thus the displayed C0 is correct, rather than missing an M factor. The integer-tail formula for E exp(lambda tau)-1 gives D(lambda) exactly. Conditional failure-weighted block moments are <1 for small lambda, so geometric iteration is legal even with history-dependent A states. Full macro lengths have conditional moment K_eta, and zero padding after absorption justifies the deterministic-macro-count sum used to derive the full-reaction exponential tail. All uniform moments concern the actual chain, including low-A resets.

The pure-B first-step and occupation arguments have finite expected jump counts before generating-function use. In its normalized time scale, b^2/[beta b+b(b-1)] is uniformly bounded, so F',F'' converge absolutely through both endpoints. Bounded F'(-1) removes the homogeneous solution. The lower-gamma expression for h follows as an actual expected death count, agreeing with the originator calculation; no frozen-A approximation appears.

## Exact Poisson budget is the cleaner feedback proof

Let g(b) be the pure-B expected death count, with g(0)=0 and 0<=g(b)<=C(1+b). Its first-step equation is

    beta b[g(b+1)-g(b)] + b(b-1)[g(b-2)-g(b)] = -b(b-1),

with the death term omitted at b=1. Multiplying by d(A)_3 and dividing by the actual complete reaction rate gives

    E[Delta g | pre-state] = -P(pair death | pre-state)
                              +P(U | pre-state)[g(B+1)-g(B)].

The identity remains exact at A=2, when the common fast multiplier vanishes; every activation U is charged. Immigration leaves g unchanged. Optional stopping at B=0 is justified by B_j<=1+j, linear g growth and the uniform full-event exponential tail, which supply an integrable O(N_events^2) bound on the summed absolute corrections. Hence

    E D_full = h(beta) + E sum_internal_U [g(B+1)-g(B)].

Predictable terminal-death marking gives E D1=q E D_full. The exact axis increment is therefore the stated Poisson-budget formula, not an expectation conditioned on successful excursions.

Before A<a/2, U and I hazards at every full event are O(1/a) and O(1/a^3); |Delta g|<=C(1+B)<=C(j+2). Conditional summation against P(N_events>j) gives O(1/a) for the weighted U correction and O(1/a^3) for immigration. Reaching A<a/2 requires order a downward events; all post-threshold corrections are bounded by C E[N_events^2 1_(N_events>=a/2)], exponentially small. Including the first axis immigration probability O(a^-2) proves the actual drift mu+O(1/a), with uniformly bounded exponential increment moments. This proof also makes explicit the immigration clarification noted in the first audit.

## The independent critical argument is properly localized

For the entire embedded axis chain A_n>=2, concavity gives log(A_(n+1)/A_n)<=Delta_n/A_n. Thus for mu<=0 its conditional log drift is <=C/A_n^2. The second-moment estimate is also valid: use 2|Delta|/a for moderate negative increments, Delta/a for all positive increments, and log a on the remaining negative tail, whose probability is exponentially small. The resulting E[xi_n^2|history]<=C/A_n^2 is uniform over small states after a finite enlargement.

Suppose S={sum A_n^-2<infinity}. Then A_n tends to infinity. On S the conditional variance sum of the centered log martingale is finite. Stopping when that predictable variance first exceeds an integer v gives stopped expected total squared increments <=v plus a uniform one-increment bound, so the stopped martingale is L2 bounded and converges almost surely. The countable family of stops establishes convergence on S without assuming that the variance sum is integrable on S.

The predictable log drift need not be absolutely summable or nonnegative: its upper bound is summable on S. Consequently log A_n is bounded above by a convergent martingale plus C sum A_n^-2, contradicting log A_n tending to infinity. Therefore sum A_n^-2 diverges almost surely. Exact axis rates Q_n=k0+k1A_n(A_n-1) have reciprocals comparable to A_n^-2. Conditional on the embedded reaction choices, axis clocks are independent exponentials divided by Q_n. Since 1/Q_n<=1/k0, divergence of sum 1/Q_n forces the product of their Laplace transforms to zero; the infinite clock sum is therefore infinite almost surely. The original clock contains all these axis waits. This proves equality and the negative side without a recurrence classification or premature conditioning on explosion.

## Positive side and all-state scope

The positive-drift no-ruin supermartingale includes overshoots. Globally defined complete cycles and uniformly bounded second moments permit the martingale strong law before restriction to survival. Exponential full-event tails give logarithmic cycle lengths, hence summable quadratic axis and cubic positive-B reciprocal rates on linear escape. The consecutive-immigration boost has a uniformly positive probability from the finitely many low axis states; interrupted boosts recover to the axis in finite full reactions. Uniform conditional episode success and geometric retry counting give all-state almost-sure explosion without independence of episodes or an irreducibility shortcut.

## Integration conclusion

Both proof spines survive: originator coupling plus accelerated quadratic Foster trace, and fresh exact Poisson budget plus logarithmic martingale/clock product. Agreement is not the reason for PASS; the localization, all-channel feedback and physical-clock obligations were checked separately. For a concise final proof, the Poisson-budget feedback argument and the accelerated-trace critical argument are the simplest combination, while both full frozen versions should remain available with accurate attribution.

This is a complete rate classification for a candidate order-five strongly endotactic network, a stronger scientific result than a single explosive tuple. The source-supported minimum-order interval remains {3,4,5}, not a solved minimum. Formal replay, external specialist validation and historical priority remain UNKNOWN.
