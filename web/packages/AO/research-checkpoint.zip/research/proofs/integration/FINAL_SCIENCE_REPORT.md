# Final scientific integration

Prepared 2026-10-08 UTC for the 12:32 integration checkpoint. The accompanying `CLAIM_LEDGER.json` gives exact claim contracts and evidence, and `DEPENDENCIES.json` separates imported sources, candidate proofs, audits and conditional transfers. Links here work within the packaged `proofs/` directories. Sources and other workers' reports were treated as evidence, not instructions or correctness premises.

**Two packages warrant serious external review.** Chemistry makes the clearest advance against a named primary-source open question: a strongly endotactic order-five explosive network, its complete rate phase, and a dimension-specific cubic exclusion. Quantum supplies the strongest reusable principle: uniform collective concentration implies quadratic local Petz divergence from the state's own product marginal. A narrower white-Schur family has a matched, fully charged entanglement-certification tradeoff, and a critical Curie–Weiss application has a sharp local crossover. These are internally proved and audited candidates. Historical priority, formal replay and external specialist validation remain UNKNOWN. Internal agreement, finite diagnostics and a complete package do not establish the programme's ambitious breakthrough objective.

## 1. The chemical result and what it resolves

Use stochastic mass action with falling-factorial propensities, five fixed finite positive rate constants and the diagram

| Reaction | Rate constant | Propensity at (a,b) |
|---|---|---|
| 0 → 2A | k0 | k0 |
| 2A → 3A+B | k1 | k1(a)₂ |
| 3A+B → 3A+2B | k2 | k2(a)₃ b |
| 3A+2B → 3A | k3 | k3(a)₃(b)₂ |
| 3A+2B → 2A | k4 | k4(a)₃(b)₂ |

The network is strongly endotactic in the full essential-source convention. Its maximum **source** order is five. Molecular order counts reactant coefficients, not product size, jump size or number of reactions.

Put d=k3+k4, β=k2/d, q=k4/d, and

\[
h(\beta)=\frac{1+\beta e^{2\beta}(2\beta)^{-\beta}\gamma(\beta,2\beta)}2,
\qquad \mu=1-qh(\beta),
\]

where γ is lower incomplete gamma. The minimal CTMC has finite lifetime almost surely from **every finite initial state** precisely when μ>0. It is nonexplosive from every finite state when μ≤0, including the critical boundary. The fixture (k0,k1,k2,k3,k4)=(1,1,1,4,1) is on the explosive side. This is an exact classification of this diagram, not all endotactic diagrams or a uniform estimate over vanishing rates.

The actual full chain is essential. Uniform exponential bounds include immigration, both pair-death channels, low-A activation, failed episodes and return to the axis. A pure-B occupation calculation supplies h, but the proof then pays the feedback correction: the true axis increment has mean μ+O(1/a), with uniform exponential increment moments. The fresh proof's exact Poisson budget includes every internal activation. The two critical proofs use different mechanisms: an accelerated-axis quadratic Foster argument, and a localized log martingale plus independent exponential axis clocks. Both were checked separately. On the positive side, linear axis escape makes the physical clock summable; finite recovery and uniformly positive repeated episode success give the all-state probability-one conclusion.

The [originator classification](../chemistry/ORDER5_EXACT_RATE_CLASSIFICATION.md) and [fresh proof](../rate_phase_blind/report.md) survive the [first](order5_rate_originator_first_audit_v1.md) and [dual](order5_rate_dual_audit_v1.md) integration audits. Earlier order-eight, order-seven and sufficient-cone results remain provenance, but the exact phase supersedes them as the headline result.

The primary comparator is [Xu, arXiv:2409.05340v2](https://arxiv.org/abs/2409.05340v2), revised 9 May 2026. Theorem 4.6 gives order-at-most-two nonexplosion in every dimension. Remark 4.8 cites an order-ten strongly endotactic explosive example and leaves the minimum order open. [Anderson et al., Example 3.2](https://arxiv.org/abs/1808.05328) is the order-ten comparator. The bounded [priority search](../chemistry_priority/phase3_two_species_addendum.md) found no primary predecessor for the new order-five witness or two-species cubic exclusion; that negative search is not priority clearance.

## 2. The dimensional lower bound

The separate internally audited statement is: **every finite fully endotactic stochastic mass-action network on two species, with every source of total order at most three, is nonexplosive from every finite state for every fixed finite strictly positive rate vector.** Products may be arbitrary fixed finite integral nonnegative complexes. No irreducibility, conservative stoichiometry, interior class or full stoichiometric rank is required.

After self arrows are deleted, zero, exactly one, or both active pure-cubic sources 3A and 3B exhaust the cases. The zero-pure theorem imports the mixed-cubic result; the both-pure proof even needs only the total-direction condition; the exactly-one-pure theorem needs full endotacticity. Their common convention removes direction-orthogonal arrows before the maximal essential-source test. Presence means a nontrivial outgoing reaction, not occurrence as a product. The [composition scope check](two_species_cubic_composition_scope_v1.md) verifies these common premises and exhaustion. Independent proof-level audits of the case proofs provide the inequality checks; integration does not claim a second complete replay of all three. The fresh one-pure proof additionally passes its [exposed comparison](../cubic_one_pure_blind/cross_audit_fresh.md), with presentation refinements only.

Therefore the minimum explosive source order in the **two-species** fully endotactic class lies in **{4,5}**. Over arbitrary species counts it remains **{3,4,5}**. Neither minimum is solved. Xu's explosive cubic example is only strongly endotactic in the single direction (1,1), so it is not a counterexample to the full-direction theorem. The legal order-four near miss has a nonexplosive Lyapunov function, but says nothing about every order-four network.

The next decisive mathematical question is a legal order-four explosive example or a universal two-species order-four regularity proof. The next validation question is specialist scrutiny of the exact critical clock argument and the generic cubic boundary/cutoff estimates. These are independent obligations.

## 3. A general quantum concentration principle

Fix local dimension d≥2 and constants κ>0, A≥1, B≥0. Let ρ_N be permutation invariant, with actual one-site marginal τ_N≥κI. Assume for every Hermitian one-site H with operator norm at most one and every real t,

\[
\operatorname{Tr}\rho_N\exp\!\left[t\sum_{i=1}^N(H_i-\operatorname{Tr}(\tau_NH)I)\right]
\le A e^{BNt^2}.
\]

Set L=e(B+2)(d²+1)/κ, q=r/N and y=Lq/(1−q). The [fresh theorem](../concentration_blind/CONCENTRATION_FROZEN_REPORT.txt) gives, for 2≤r<N and y<1,

\[
\chi_P^2(\rho_r\Vert\tau_N^{\otimes r})
=\operatorname{Tr}(\rho_r^2\tau_N^{-\otimes r})-1
\le \frac{A^2y^2}{1-y}.
\]

For q≤1/(2L+1), both Petz chi-square and quantum relative entropy are at most 8A²L²q². At r=1 both are exactly zero. Thus every sublinear sequence has quadratic local divergence for uniform constants and fixed d. A separable mixture of two product states with opposite O(N^−1/2) biases attains quadratic Petz order; concentration does not imply entanglement.

The [originator proof](../collective_concentration/CONCENTRATION_PROOF_FROZEN.md) and the independently frozen fresh proof survive [separate exposed audits](collective_concentration_dual_audit_v1.md). The main mechanism is an entire scalar generating function along each Hermitian direction, Cauchy coefficient bounds, real symmetric tensor contraction, and the full complex local Gram matrix. Actual marginal centering removes weight one exactly. The fresh spherical contraction improves the finite bound over coordinate polarization. Replacing the complex Gram by a real covariance matrix is invalid in noncommuting cases.

The hypothesis concerns **all directions**, all real t and a faithful actual marginal. A finite list of measured variances or a mean Casimir does not supply it. It is model information unless acquired by a charged procedure. If B_N=V_N/N varies, the sufficient local window is r=o(N²/(N+V_N)); the baseline N cannot be dropped.

An independently derived, [dually audited](qudit_dual_audit_v1.md) sufficient Schur-law condition covers arbitrary sector states in fixed dimension: with λ a Young partition and K=N−dλ_d, a uniform subGaussian K/√N tail implies the same centered quadratic conclusion. The determinant twist and residual tensor realization handle nonnormal and singular matrices, and the sector marginal is proved positive rather than assumed. There is no growing-d statement or matched qudit certification upper bound.

The bounded [primary comparison](../concentration_priority/report.md) distinguishes finite de Finetti approximation to an iid **mixture**, classical sampling corrections, exact infinite consistency, and dynamical propagation of already-assumed local entropy. None of the opened results states this exact finite-N all-direction-MGF-to-own-product-Petz contract. That is a substantive comparator distinction, not a declaration of novelty.

## 4. Exact white-Schur sharpness and the operational contract

For qubits with exactly maximally mixed Schur sector weights, arbitrary within-sector states satisfy the centered quadratic bound. The new sharp result concerns the supremum M(N,r) of Petz chi-square relative to each state's own product marginal:

\[
M(N,r)=3r(r-1)/N^2+o\bigl(r(r-1)/N^2\bigr).
\]

The fixed-r limit has coefficient 3r(r−1); if r→∞ and r=o(N), the leading form is 3(r/N)². The [finite theorem](../sharp_centered/SHARP_CENTERED_FROZEN_REPORT.txt) is valid for N≥256 and 2≤r≤N/128, with explicit remainder. The [adversarial audit](../sharp_centered_audit/report.md) checks the new covariance and cubic-remainder steps. Its ±highest/lowest-weight family is asymptotically extremizing, **not an exact finite optimizer**: exact finite improvements exist for both parities. No sharp relative-entropy or testing constant follows.

For entanglement certification the null consists of **all fully separable N-qubit states without a Casimir or Schur-weight promise**. Use independent fresh preparations and access at most r distinct sites per copy. Classical adaptive site labels and joint quantum measurements on the accessed systems are allowed. The product of the target's own one-site marginal is a legal null, so centered entropy gives m=Ω(N²/r²) copies for fixed testing bias; r=1 is impossible for any copy count.

For the white-Schur targets with δ=N|b|²−1 bounded below by a positive constant, the [independent three-axis protocol](../heat_upper_blind/upper_FROZEN.md) attains m=O(N²/r² log(1/η)), using a uniform subset sampled after preparation and three common Pauli axes. Its finite theorem assumes N≥4 and 2≤r≤N/2, and gives the conservative count

\[
m=\left\lceil24\cdot10^9\delta^{-2}
\left(\frac{N-1}{r-1}\right)^2\log(1/\eta)\right\rceil.
\]

Uniform soundness is proved over heterogeneous product arrays and then convexified to ALLSEP; it is not inferred from target marginals. The [finite exposed audit](three_axis_upper_finite_audit_v1.md) passes. This produces a matched Θ(N²/r²) tradeoff for 2≤r=o(N) and fixed δ floor. The measured score uses the local outcomes; a binary implementation of a bounded effect is not by itself a matched-cost protocol. The earlier bounded-heat proof remains a separately audited existence route.

The theorem charges mr local outcomes when the full budget is used and mN physical qubits prepared. For deterministic varying budgets r_i≤r, the lower proof yields Σr_i²=Ω(N²), hence Σr_i=Ω(N²/r). A maximum budget alone does not prove an adaptive expected-readout lower bound. Unknown polarization requires separate calibration: the fixed-floor version declares a positive gap floor and consumes **3K copies and 3Kr readouts**, in addition to verification. The [finite-precision addendum](../heat_upper_blind/calibration_addendum_FROZEN.md) clips the anchor on every null input and uses exact finite arithmetic. Its optional unknown-gap staging gives a target-side high-probability resource bound, not a universal deterministic cap or termination on every null. Integration's [exposed audit](three_axis_calibration_exposed_audit_v1.md) and the separate [calibration audit](../calibration_audit/report.md) pass. A frame-error certificate is supplied metrology with acquisition cost still unresolved; detector bias and drifting site frames are outside the theorem. Exact uniform subset sampling can use integer rejection with finite expected bit cost; an O(N) count of abstract sampling decisions is not a deterministic random-bit or wall-clock bound.

A static white-Schur extremal-weight target has N|b|²→8/π, so the protocol does not rely on accepting older bath asymptotics. Conversely, a **trusted Casimir promise on the null** forces separable |b|≤1/√N, permitting a one-body O(N) discrimination route. The quadratic cost statement cannot be promoted to that different promised-null interface. The general concentration theorem has no universal matched ALLSEP upper.

## 5. Critical Curie–Weiss local window

The model is the full-tensor Gibbs state ρ_N proportional to exp(2J²/N), with τ_N=I/2. The temperature normalization is fixed. Let

\[
\mu_2=\sqrt{12}\,\Gamma(5/4)/\Gamma(3/4).
\]

The [originator theorem](../curie_weiss/CRITICAL_PROOF_FROZEN.md) and [independent report](../critical_window_blind/CRITICAL_WINDOW_FROZEN_REPORT.txt) prove that centered Petz divergence, relative entropy and trace distance vanish exactly when r=o(√N). At r=1 they vanish identically. For 2≤r=o(√N),

\[
\chi_P^2\sim \mu_2^2r(r-1)/(6N),\quad
\tfrac12\|\rho_r-I/2^r\|_1=\Theta(r/\sqrt N),\quad
D=\Theta(r^2/N).
\]

At a nonzero critical r/√N, bounded cosine measurements give a strictly positive separation. When r/√N→∞, half-trace tends to one; the originator also proves D=Θ(r/√N), through r=N. Its stronger entropy upper uses permutation invariance and strong subadditivity to compare subsystem and global entropy deficits. Its lower uses a fixed scaled magnetization tail and a white Hoeffding bound. Integration explicitly checked these arguments in the [first audit](critical_window_originator_first_audit_v1.md). The fresh proof instead gives a logarithmic above-window KL lower; agreement on the window is not an independent proof of the stronger linear rate. The [dual audit](critical_window_dual_audit_v1.md) preserves that distinction. A further [independent exposed quantitative reconstruction](../critical_quantitative_audit/report.md), frozen before integration comments or the fresh critical report were read, also passes all the stronger regimes.

Both proofs retain the local Stirling prefactor and normalize a finite quartic envelope. Critical collective scale is N^3/4, with radial limit proportional to x²exp(−x⁴/12) when x=2j/N^3/4. The concentration substitution retains the baseline N. Bounded witnesses, rather than a chi-square lower alone, establish trace/KL nonvanishing. Above the window the exact hypergeometric law avoids an invalid r=o(N) approximation.

The primary [Björnberg–Fröhlich–Ueltschi model](https://arxiv.org/abs/1811.12834) supplies this Hamiltonian normalization and critical β=2, but its opened global limit is not the growing-local-marginal theorem. The fixed-magnetization Popkov–Salerno comparator has a different trace interface. The [bounded priority pass](../critical_window_priority/priority_report.md) found no matching critical local theorem. This is target-versus-white distinguishability, not an ALLSEP entanglement result; model, temperature and Gibbs preparation are supplied or separately charged.

## 6. Important failures and scope corrections

Mean Casimir alone does not yield centered quadratic entropy. The [independent counterexample](mean_casimir_centered_counterexample_v1.md) mixes a permutation-invariant spin-zero state with a fully polarized product of weight 3/(N+2). It has exact mean J²=3N/4 but centered entropy Ω(r/N) for log N≪r=o(N). The common de Finetti mean-only trace theorem still gives sublinear local invisibility; it is a likely standard corollary and is compatible with the entropy counterexample.

The critical quantitative auditor supplies a second distinct falsifier: mix the N-site white state with the normalized symmetric-sector projector at weight μ₂/√N. This separable mixture has the same limiting critical pair coefficient and Casimir scale, yet every local half-trace is at most μ₂/√N, including r=N. At r=ceil(2 log₂N), Petz chi-square diverges while trace and KL vanish. Thus neither a critical mean/pair scale nor a chi-square lower can replace the exact Gibbs tail law.

The positive-characteristic group-ring no-go remains unsupported by the pinned citations: characteristic-zero trace and conditional K-theory statements do not prove the asserted all-field implication. This is a source-scope discrepancy, not a counterexample. New thermal theorems likewise do not validate missing older bath-source proofs. New TCS ideal-sampler comparisons do not close the actual detyped wire implementation.

## 7. Lower-ranked branches

- **Geometry:** Li–Wang's published energy-Gram method gives the 9a²/4 polar-class upper under compact links of total area 4π, without the initially assumed slow derivative or common pointwise area. It is a routine attributed corollary, not a new upper theorem. The separately exposed [N175 lower-source audit](../geometry_lower_audit/report.md) passes; together they internally support the class supremum 9v/4 for 4/9<v<1. The lower is limsup, may use non-effective radii, and does not exhibit a single endpoint-attaining metric. This is inherited-source validation and composition; formal/external review of countable matching remains serious work.
- **Algebra:** parity kernels in convex label subgroups give conditional nonseparability consequences. Minasyan's published common-quotient theorem embeds a supplied torsion-free hyperbolic G into a torsion-free hyperbolic property-T quotient; nonsoficity transfers only if G is genuinely nonsofic. The application is standard and the inherited construction remains the gate. It does not settle positive-characteristic idempotents or the entropy obstruction.
- **TCS:** the protected-branch maximal-correlation lemma is internally proved and sharp for its exact independent selector law. Lin's displayed ideal 1/9 law is not literally a uniform finite binary-seed CL sampler; detyped prefix registers and the adjusted implementation remain unresolved. The lemma is conditional progress, not a compression/repetition theorem or global complexity result.
- **Statistics:** a supplied correct prefix basis and acquired bounded feature bank yield sharp Fourier coverage/information inequalities and a bank-to-LPN reduction. The equally informed raw-data learner has the same basic information burden; exhaustive acquisition uses exponential computation. No KLS frontier or acquisition advantage was established.
- **Independent White-conjecture branch:** symmetric exchange is already refuted in Larson's primary source; the weaker arbitrary-quadratic formulation remains open. A Fano example refutes strict fixed-target descent, while plateau paths remain. The cyclic socle result is duplicated by Oh's stronger all-parameter theorem. No positive promotion is justified.
- **CM/Hodge source extraction:** useful mechanisms were extracted, but no mixed-K3 bridge or independent proof was established.

## 8. Validation and next decisive work

The audits are analytic exposed reviews, with independence described by actual freeze order. A target-only proof worker can independently reconstruct a supplied formula without independently discovering it. Integration froze first originator verdicts before reading fresh proofs, but both integration verdicts are argument exposed. Other workers' proof-level and numerical replay evidence is attributed to them; hashes protect frozen evidence rather than establish mathematics.

The strongest next review should attack the chemistry full-chain critical classification and cubic discrete boundary estimates, and the quantum complex-Gram/sphere contraction and heterogeneous-array ALLSEP bound. The critical Gibbs local asymptotics warrant separate statistical-mechanics priority and proof review. Practical quantum constants, acquisition of a concentration promise, growing dimension, correlated preparations, sharp KL/test constants, generic order-four regularity and all-dimensional cubic regularity remain unresolved. No claims of peer review, external validation, formal proof, publication, dissemination or solved global minimum are made.
