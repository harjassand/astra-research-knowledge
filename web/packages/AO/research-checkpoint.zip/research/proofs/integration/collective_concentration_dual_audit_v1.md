# Dual argument audit: arbitrary faithful marginals

Checkpoint: 2026-10-08 11:49:19 UTC. The originator-first exposed audit was frozen before the fresh proof was opened. Both audits are argument-exposed; discovery independence belongs to the two frozen proof workers, subject to the recorded shared guidance on the originator route.

Inputs:

- Originator `work/agents/collective_concentration/CONCENTRATION_PROOF_FROZEN.md`, SHA256 `31b94cdf6e90bae592c373c557e9a0fd1b9ccfec51f9a3e943392eb0018de45e`.
- Fresh proof `work/agents/concentration_blind/CONCENTRATION_FROZEN_REPORT.txt`, SHA256 `4c84347664c901a831156402fa0bb598ff1ac6a2823bfacf931f7fab24d35037`, frozen 11:45:22 UTC before its author saw the originator or integration argument.
- Originator-first audit `collective_concentration_first_audit_v1.md`, SHA256 `49908e45ba5fc692eb8980dd453b6fa7c620dd97387a815db4471b9207154f48`.

**Verdict: PASS for both finite entropy theorems.** The fresh proof gives the cleaner finite range and constant. External correctness, formal validation and historical priority remain UNKNOWN.

## Exact stronger bound from the fresh proof

For fixed d>=2, tau_N>=kappa I, and the all-direction centered MGF A exp(B N t^2), put

    L=e(B+2)(d^2+1)/kappa,
    q=r/N,
    y=Lq/(1-q).

For every 2<=r<N with y<1,

    chi_P^2(rho_r || tau_N^tensor r) <= A^2 y^2/(1-y).

For q<=1/(2L+1), both Petz chi-square and relative entropy are bounded by 8 A^2 L^2 q^2. At r=1 both are exactly zero. This is a fixed-d uniform result through every sublinear sequence, provided kappa,A,B are uniform.

The genuinely independent part of the fresh derivation is the sphere contraction, replacing coordinatewise real polarization. For the real symmetric order-k moment tensor C, the 2k-th moment of a uniform vector on S^(s-1), s=d^2-1, expands over pairings with denominator alpha_(s,k)=s(s+2)...(s+2k-2). The k! entirely crossing pairings contribute k!||C||_F^2. In each other pairing, both copies have the same number of internal pairs; symmetry makes the contraction a squared norm of an iterated trace. Every term is nonnegative. Thus E C[u^k]^2 >= k!||C||_F^2/alpha_(s,k). This is legal for all the real tensor entries, including those arising from sector coherences.

The directional coefficient estimate is the same independently reconstructed elementary normal-product bound and Cauchy optimization. The exact coefficient is binom(N,k)C[u^k]. Inserting the sphere estimate into weighted Parseval, then using binom(r,k)/binom(N,k)<=q^k and binom(N,k)^-1<=k!/[N(1-q)]^k, cancels all factorials and yields

    A^2 alpha_(s,k) [2e(B+2)q/(kappa k(1-q))]^k.

For k>=2 and s>=3, alpha_(s,k)<= [k(s/2+1)]^k. The inequality is equivalent to (k-2)(s/2-1)>=0. This gives the stated y exactly. The explicit q range makes y<=1/2; the constant 8 A^2 L^2 follows. The complex Gram, cyclic trace identity, zero one-support coefficient and noncommuting KL Jensen step all agree with the first audit.

## Sharpness is structural, without an entanglement inference

The fresh family rho_N=[eta_+^tensor N+eta_-^tensor N]/2, eta_±=(I±diag(1,-1,0,...,0)/sqrt(N))/d, is a legal separable PI state for every N>=1 and has marginal I/d. For every Hermitian ||H||<=1, its branch-centered one-copy MGF is bounded by exp(t^2/2), because every exponentially tilted spectral distribution has variance at most one. The branch mean displacement gives a cosh factor; |Tr(D_0 H)|<=2 establishes A=1, B=1/2+2/d^2 for all directions and both signs of t.

Direct product traces give exactly

    chi_P^2=[(1+2/(dN))^r+(1-2/(dN))^r]/2-1
           >=2r(r-1)/(d^2 N^2).

The remaining even terms are O_d((r/N)^4); hence for growing sublinear r the leading coefficient is 2/d^2. This proves the Petz quadratic order cannot be improved for the general concentration class. It does not prove a universal sharp constant, a relative-entropy sharp constant, or any entanglement assertion. A general matched ALLSEP certification upper is still absent; the separate white-Schur protocol is a narrower result.

## Integration consequence

Promote this as an internally proved and multiply audited general quantum exchangeability theorem, while keeping historical novelty UNKNOWN. The admissible concentration premise is stronger than control of a finite list of axes or a mean Casimir. It is supplied model information unless acquired by a charged protocol. Fixed full-rank lower bound is essential for the uniform statement.

For varying B_N=V_N/N, the fresh version improves constants but retains the baseline term: y is proportional to (N+V_N)r/[N(N-r)]. The sufficient window is r=o(N^2/(N+V_N)). Any critical application must verify its actual MGF, and any claimed trace or KL crossover needs evidence beyond a nonvanishing Petz lower bound.
