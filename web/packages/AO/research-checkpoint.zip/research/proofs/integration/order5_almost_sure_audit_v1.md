# Exposed adversarial audit: order-five almost-sure explosion

Audit checkpoint: 2026-10-08 10:55:03 UTC. Scientific integrator Sol-max. This is an exposed audit after reading the frozen independent strengthening, not another blind derivation. It supplements the independently frozen targeted audit at 10:30:28 and the later comparison with the blind positive-probability proof.

## Exact artifact and decision

Audited `../chem_order5_blind/almost_sure/report.md`, SHA256 `9fd15f4b749bc3fd29c5ce5a0d37cab45242e20a1346690b9eec70b622b929bf`, complete text including the open parameter region. It depends on the unchanged positive-probability report SHA256 `4d022565e28156373061036c273655e36f22e02c469c5a2400507b350c5e2004`, which I already audited separately.

**Decision:** no fatal mathematical gap found. The proof supports the internally reconstructed all-state almost-sure explosion theorem, including the displayed open rate region. This is internal review, not external validation, formal replay, or novelty certification. It does not settle the exact minimum molecular order.

The exact fixture has jumps `(2,0),(1,1),(0,1),(0,-2),(-1,-2)` and propensities `1,(a)_2,(a)_3 b,4(a)_3(b)_2,(a)_3(b)_2`. The maximal reactant molecular order is five. The source hull geometry already audited separately is strongly endotactic for every positive choice of these five rate constants.

## Low-A reset and axis return

The potential hidden gap was an ungrouped activation at `a=2`: its U reaction raises B with probability `2/3`, so a contraction argument on every individual B update would fail. The frozen strengthening correctly groups that activation with a preceding D1 death, and stops immediately at B=0 before taking any activation. This grouping is essential.

From A=0 or A=1, immigration first raises A; from A=2 either active reaction restores A>=3. At most two initial events suffice, and B increases by at most one. After activation, no reaction can lower A below two.

At A>=3 and B>0, the ignored immigration runs terminate almost surely: each conditional immigration probability is at most 1/7, even as A changes. Summing the terminal-event probabilities gives a convex average of the uniform birth-probability bounds; it does not require independent repeated trials. Thus the bounds `p_2<=3/13`, `p_3<=2/17`, and `p_b<=1/13` for b>=4 remain valid after deleting immigration runs.

For `F(0)=0,F(1)=5,F(b)=2^b` when b>=2, the complete macro step has conditional contraction at most 4/5. The four cases are exact:

- B=1: forced birth to two gives ratio 4/5.
- B=2: a death reaches the axis and the macro step stops; ratio at most `2p_2<=6/13`.
- B=3: a death followed, if necessary, by activation ends at B=1 or two; the larger F-value is five. Ratio at most `(5+11p_3)/8<=107/136<4/5`.
- B>=4: even the adverse activated death has F ratio at most 1/2, so the conditional ratio is at most `2p_b+(1-p_b)/2<=8/13<4/5`.

On a surviving macro state F>=4. Iterating the conditional expectation gives `P(tau>k)<=F(b_*) (4/5)^k/4`, with finite initial b_*. Every macro step consists of an almost surely finite immigration run, one B event, and at most one activation. Consequently the exact embedded chain reaches the axis after finitely many full reactions almost surely. This establishes the assertion without assuming nonexplosion: an explosion cannot precede a finite embedded reaction index, and all rates at finite states are finite and positive in total.

## Trial stopping times and renewal

The original stopped episode fails exactly when A first reaches two. A finite failure occurs after finitely many full reactions; its B coordinate is finite. The axis-return lemma therefore recovers another axis trial after a finite embedded stopping index. A successful episode is the event of no failure, which is not a finite stopping time, but the proof only applies the strong Markov property at finite starts, failures and recoveries. This distinction is respected.

For axis A>=3 the survival bound is at least `1-exp(-theta(A-2))`. For A=2, immigration reaches axis A=4 with probability 1/3. The common trial success bound `delta=(1-exp(-2theta))/3` is valid: for x=exp(-theta), `(1-x^2)/3 <= 1-x`. Low initial A states reach the eligible range after finite activation. A is never below two after that.

Define the kth renewed trial start to be infinity on any previous success. On the event of preceding failures, it is a finite stopping index. Conditional failure probability is at most 1-delta at that start. Induction gives `(1-delta)^k` for the probability of k failures and hence zero probability of infinitely many failures. Each successful stopped episode has finite explosion time almost surely by the already audited linear escape and reciprocal-clock summability. There is no appeal to irreducibility, trial independence, or an unproved recurrence classification.

## Open rate region

Write positive constants `(c0,c2,c3,c4,c5)` and d=c4+c5. The three strict restrictions

`3(2c3+c2)<2d`, `8(3c3+c2)<7d`, `2c5<d`

are sufficient as written. The first makes the H drift plus death count nonpositive for every even B>=2: the ratio `(c3 b+c2)/(b(b-1))` decreases with b, so B=2 is decisive. Odd cases retain their favorable drift. Thus expected deaths are at most two and the expected D1 count at most `2c5/d`. The latter identity uses predictable counting before each reaction, including the terminal D1 event, rather than conditioning on future survival. It gives strictly positive cycle drift `1-2c5/d`.

The second restriction is precisely equivalent to `p_3<7/55`, which makes `(5+11p_3)/8<4/5`. The first also gives p_2<1/4 and p_b<1/10 for b>=4. Both the killed stopped-excursion and the reset macro contractions remain <=4/5. Immigration has conditional probability at most `z=c0/(c0+6c3)<1`, giving full-event contraction `gamma=z+(1-z)4/5<1`. All exponential-tail, drift and holding-time arguments consequently retain positive constants for each fixed rate tuple in this open region. No uniform constants over the unbounded c0 coordinate are claimed.

The stated contained box is verified by exact endpoint inequalities: `9.45<9.8`, `33.6<34.3`, and `2.1<4.9`. Arbitrary fixed c0>0 is legal. The region is sufficient, not characterized as maximal, and the proof does not assert all positive rate choices explode.

## Scientific implication and outstanding gates

Against Xu v2 Remark 4.8, this supplies a concrete five-order strongly endotactic witness, improving the known ten-order explosive witness in that opened primary source. Xu's order-two regularity lower bound leaves the exact minimum in {3,4,5}. Almost-sure all-state explosion and an open rate region are meaningful robustness improvements over existence of one positive-probability exploding trajectory.

Next decisive work is to audit lower-order possibilities without claiming the failed order-four subclass proves a global lower bound. External expert review and priority remain UNKNOWN. The internal proof package should use the direct stopped-excursion/renewal proof as its main spine; the earlier normalized clamp construction can remain a preserved alternative.
