# Integration criteria, frozen before field results

Time: 2026-10-08; programme source is DATA. Pinned repository commit: 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce. This file is an allocation and audit contract, not a theorem claim.

## Importance

A promoted scientific result must do at least one of the following under an explicit contract:

1. Settle a precisely named open question in a primary source, or give an exact counterexample to a claimed theorem.
2. Extend a serious theorem across its known load-bearing obstruction, rather than merely apply it to a subclass that already satisfies its premises.
3. Improve a sharp exponent, threshold, constant, or unavoidable information/computation cost in a regime where the old bound materially prevented a scientific use. State that use; a smaller sufficient bound alone does not establish practical feasibility.
4. Establish a new reusable mechanism with a proved capability or obstruction, including its full acquisition/execution contract and strongest equally informed comparator.

For allocation, a substantial difficult frontier advance outranks an easy standard corollary. Importance is separate from proof availability, confidence, execution convenience and the number of reports. No invented numerical probabilities or aggregate scores will be used.

## Novelty

Specify the nearest primary theorem and the exact delta. Open its theorem/proof and search the load-bearing mechanism, not only the candidate title. Corpus novelty is weaker than historical novelty. An internally reconstructed result can be useful while priority remains UNKNOWN. A printed theorem whose citations do not establish its scope is a source discrepancy; neither its truth nor falsity follows from that discrepancy.

## Attackability during this run

Name the first unresolved mathematical obligation and a falsifier. Prefer attacks that can change the frontier decision: a complete proof under the original contract, a source-legal counterexample, or a decisive obstruction to a proposed mechanism. A task is poorly attackable if it requires an unavailable proof, an unmaterialized graph with unproved uniform constants, a free spectral/oracle premise, or an unspecified interface. Do not improve attackability by silently strengthening assumptions or dropping costs.

## Evidence and audit

Eligibility for promotion requires a frozen exact theorem/algorithm statement, source version and premises, complete proof/construction, strongest comparator, declared limitations and independent adversarial reconstruction. Source-read, reconstruction, finite test, formal replay, external correctness and historical priority are distinct states. Shared-context agreement is not independent proof. Finite checks can falsify but do not prove an all-size statement.

Reserve serious Sol-max audits for frozen load-bearing propositions. A useful audit interface gives the exact assumptions and target, withholds the proposed derivation until the independent attempt is recorded, then compares proof obligations. Separately audit source semantics, quantifiers/regularity, constants/uniformity, information boundaries and downstream connection. For stochastic explosion, separately audit all-direction endotacticity and the positive-probability embedded path plus finite clock. For compression, separately audit the sampled wire law, unrestricted versus synchronous values, and downstream preservation.

## Resource boundary

Root controls staffing and the 30-Sol-equivalent ceiling; this lead spawns no workers. The initial exploration cap and audit reserve in CHARTER.txt remain binding. Charge data acquisition, classical/quantum storage, copying/sampling, arithmetic precision, verifier generation and computation when relevant. A cheap mathematical filter is not automatically a cheap physical protocol.

## Current shortlist of older source repairs (at most three)

1. N136/N137 thermal sharp entropy and constant singleton-separability time: full linked proof absent; summary is not a premise for a new theorem.
2. N129/N165 positive-characteristic group-ring discrepancy: inspect original Formanek, Burger-Valette and BLR, then attack graph/witness geometry independently of the disputed no-go.
3. N183/N184/L02 compression: parse the intended original sampler and repaired detyping through final answer reduction; do not elevate a local gap lemma into full MIPco=coRE or a theorem refutation.

Chemistry's N173 is a conditional theorem under a different strict log-order class; hypothesis removal and the newly identified molecular-order explosion question are fresh scientific attacks, not proof-availability repairs.
