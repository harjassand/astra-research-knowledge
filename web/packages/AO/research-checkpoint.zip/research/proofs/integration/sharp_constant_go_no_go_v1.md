# Sharp white-law centered chi-square: qualified GO

Root requested a bounded scientific judgment after the uniform centered order and tail extension froze. This is a proof route and go/no-go assessment, not a completed minimax theorem or an independent audit of a future proof.

For exact white Schur weights, write b for the one-site Bloch vector and Cov(J) for the real symmetric collective covariance. The exact distinct-site centered Pauli tensor is

    N C2_center = [N/(N-1)] [4 Cov(J)/N - I + b b^T].

Let X=4Cov(J)/N. It is positive semidefinite and Tr X=3-N|b|^2 is in [0,3], while |b|^2<=3/N. If t=Tr X, then

    ||X-I||F^2 <= t^2-2t+3 <=6.

The two-support contribution is binom(r,2) times the corresponding quadratic coefficient norm, with local complex Gram inverse equal to I+O(N^-1/2). Thus it is at most `(3+o(1))(r/N)^2` when r grows and r=o(N). The existing full centered coefficient proof gives the remaining weights >=3 an O((r/N)^3) bound, so they do not change the leading constant. These steps need a frozen uniform proof, especially the maximization over sector states.

The candidate extremizer is an equal mixture of highest and lowest weight vectors inside each spin sector, with the exact white sector probabilities. It has b=0. Since E M(M+2)=3N and E M=O(sqrt(N)), its scaled two-site tensor tends to diag(-1,-1,2), whose squared Frobenius norm is six. Its second-support contribution attains the leading constant three along r->infinity, r=o(N).

For bounded r the leading factor is `3(1-1/r)`, so the growing-r condition is material. No sharp KL constant or optimal hypothesis-testing constant follows merely from this chi-square calculation.

**Judgment:** qualified GO for a single bounded 20-minute proof target after the tail proof freezes. It yields a genuine minimax asymptotic and replaces an enormous conservative constant in the white-law subclass. The fixed-d extension is more conceptually significant, but if that proof is already frozen this sharp result is a useful completion. It is a natural consequence of the current coefficient machinery, not a new independent historical-priority credential.
