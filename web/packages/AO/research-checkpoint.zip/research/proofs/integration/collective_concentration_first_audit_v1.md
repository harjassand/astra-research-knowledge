# First exposed audit: collective concentration to centered local entropy

Checkpoint: 2026-10-08 11:46:08 UTC. This audit was completed after reading the originator's frozen proof and before reading any fresh independent derivation of this theorem. It is an argument-exposed mathematical audit, not an independent discovery or external validation.

Audited input: `work/agents/collective_concentration/CONCENTRATION_PROOF_FROZEN.md`, SHA256 `31b94cdf6e90bae592c373c557e9a0fd1b9ccfec51f9a3e943392eb0018de45e`.

**Verdict: PASS for the stated finite theorem and necessary-copy consequence.** Historical priority and external/formal validation remain UNKNOWN. The proof uses guidance shared by root/integration; do not describe the originator route as blind independence from that guidance.

The exact premise is permutation invariance, the actual marginal tau_N>=kappa I, and the all-real-t MGF bound A exp(B N t^2) for every Hermitian one-site H of operator norm at most one, centered by Tr(tau_N H). Fixed d,kappa,A,B give a uniform theorem. A finite list of directions or a merely qualitative concentration claim is insufficient.

## Load-bearing checks

1. **Noncommuting weighted Parseval is legal.** With T=tau^tensor r and R=rho_r T^-1, Tr(T R^dagger R)=Tr(rho_r^2 T^-1). The coefficient against a product B_Q is Tr(T B_Q^dagger rho_r T^-1)=Tr(B_Q^dagger rho_r), by cyclicity; no commutation with T is assumed. Distinct supports are orthogonal. The full complex Gram G_ab=Tr(tau B_a B_b) is required, and G>=kappa I follows from Tr(W^dagger W)=|v|^2+d|b dot v|^2. This avoids the previously refuted real-covariance substitution.

2. **The complex scalar bound follows from positive spectral probabilities.** Same-direction X_i commute across sites. In their joint eigenbasis the diagonal entries of rho form a probability law even when rho has coherences. The pointwise inequality |1+zx|<=exp[(Re z)x+|z|^2 x^2/2] holds for every complex z and real x. Since ||X||<=2, the generating polynomial obeys |F_u(z)|<=A exp[(B+2)N|z|^2] on the entire complex plane. There is no matrix logarithm, non-Hermitian MGF assumption, factorization, or small-radius gap.

3. **Coefficient and tensor normalizations agree.** The coefficient is binom(N,k) C_k[u^k]=(N)_k C_k[u^k]/k!. Cauchy at R^2=k/[2(B+2)N] gives the displayed factorial ratio. Real polarization bounds each symmetric-tensor coordinate by (k^k/k!) times the directional supremum. The s^k coordinate count is deliberately loose but correct. The polarization factorial cancels the coefficient factorial before the support count; k^k/k!<=e^k leaves geometric, rather than factorial, degree growth.

4. **All growing support sizes are controlled.** For k<=r<N, (N)_k>=N^k(1-r/N)^k and binom(r,k)<=r^k/k!. Thus support weight k is at most A^2 x^k with x=2e^2(B+2)(d^2-1)(r/N)/[kappa(1-r/N)^2]. Degree one vanishes exactly because tau is the actual marginal. The sum starts at degree two, giving A^2 x^2/(1-x) for x<1. The explicit alpha threshold and constant 128 A^2 e^4(B+2)^2(d^2-1)^2/kappa^2 follow without a missing dimension factor.

5. **Relative entropy does not assume commutation.** Spectral overlaps lambda_i |<i|j>|^2 form a probability law. Scalar Jensen gives D(rho||T)<=log Tr(rho^2 T^-1)<=chi_P^2. Zero rho eigenvalues have zero weight; faithful tau supplies finite support.

6. **Operational scope is conditional and precise.** The product tau_N^tensor N is a legal unrestricted ALLSEP null with identical one-body data. For independent fresh copies, classical adaptive distinct-site choices can be simulated by exchangeable slots using at most r sites per copy; arbitrary joint operations on those slots are then subject to relative-entropy data processing. A fixed output gap requires m=Omega(N^2/r^2). This does not assert that the target is entangled or that a test with target power exists. With r=1 the actual target and product marginals are identical for every number of independent preparations.

## Scientific interpretation and limits

This is the strongest structural quantum principle presently audited in the campaign: near-white Schur laws are sufficient mechanisms for collective concentration, whereas the theorem itself permits any faithful marginal. The theorem supplies a necessary acquisition cost; the separately audited white-Schur three-axis protocol supplies a matched upper only for its narrower polarized target class.

Fixed constants matter. Replacing B by B_N=V_N/N in the same proof gives x proportional to r/N + V_N r/N^2. The sufficient window is therefore r=o(N^2/(N+V_N)), not unconditionally r=o(N^2/V_N). The baseline N term remains even for states with very small collective fluctuations. Likewise kappa_N tending to zero must be charged through the displayed constants.

The premise is supplied mathematical/model information unless a separate procedure acquires it. Trusted global-spin promises can exclude the product null and change the testing task. Arbitrary correlations between preparations, coherent address queries, and uncontrolled stopping budgets are outside the necessary-copy statement. No novelty clearance is inferred from the internal proof or a bounded unsuccessful literature search.
