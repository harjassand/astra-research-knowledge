# Centered local information: exposed proof audit and two certification interfaces

Checkpoint saved 2026-10-08 10:38:15 UTC. Read `work/agents/thermal/centered_relative_entropy_FROZEN.md` after the lead independently froze it. Root had reported the existence and better constant of another candidate, but no derivation was read. This is an exposed audit of the lead's proof, not independent blind reconstruction.

## Mathematical check

For permutation-invariant N-qubit states with exactly white Schur weights and arbitrary density operators within each sector, the frozen statement is Petz chi-square and relative entropy at most `2e9(r/N)^2` against the product of the exact one-site marginal, for `1<=r<=N/1024`. The small-r case N<1024 is empty. Every r_N=o(N) is eventually covered.

The centered Gram matrix is correct, including the imaginary antisymmetric term. Its eigenvalues are `1-|b|,1+|b|,1-|b|^2`; the Casimir bound gives `|b|<=sqrt(3/N)`. For `L=rho T^-1`, the weighted norm is `Tr rho^2 T^-1`, and cyclicity makes its centered-basis coefficients exactly centered expectations. Orthogonality by support and finite-dimensional Parseval are legitimate even though rho and T need not commute. The support-wise inverse-Gram bound pays at most2^w for support size w. Weight-one coefficients vanish exactly. This is the decisive cancellation; bounding all-reference conditioning by an exponential in r would not prove the mesoscopic claim.

The complex two-by-two Schur norm, determinant bound, and weighted-sector MGF estimate lead to `|F_N^b(z)|<=6 e^(3/2)(1+4Nu^2)e^(13Nu^2/4)`. The chosen radius gives a coefficient square of `36e^3(1+w)^2e^w(39N/(2w))^w`. The support2^w factor cancels the radius denominator2^w. Exact permutation multiplicities give `(r)_w/(N)_w^2 sum_n (product n_a!) |coefficient_n|^2`. Count and factorial bounds yield q=110r/N and the sum begins at w=2. The geometric-series and final constant are conservative and consistent. Jensen in the eigenbases proves `D<=log Tr rho^2 T^-1<=chi-square` without commutation.

No fatal mathematical gap was found in these exposed checks. The exact Schur weights are essential; the theorem must not be relaxed to a mere mean-Casimir promise. The loose constant is asymptotic evidence, not a practical finite-N sample estimate.

## Unrestricted separable null

If soundness is required against every globally fully separable N-qubit state, the product state `tau^tensor N` is a legal alternative matching all one-site data. With at most r distinct sites on each fresh independent preparation, exchangeability and classical adaptive label choice reduce the accessible data to a channel of m copies of rho_r. Joint quantum memory and final measurements do not bypass data processing. A constant testing gap needs `m=Omega(N^2/r^2)`. For r=1, accessible states agree exactly, so no number of such preparations can certify entanglement in this model.

This is a lower bound only. A protocol distinguishing the target from its product-marginal comparator does not by itself certify entanglement against all separable alternatives. The lead reports a sound random-pair O(N^2)-preparation test, matching the order for each fixed r>=2; the growing-r matching upper is unresolved at this checkpoint.

Direct physical preparation cost is `mN=Omega(N^3/r^2)` qubit instances. The claimed `Omega(N^2/r)` readout cost needs either full r-site access on every copy or a separate variable-budget information bound. For deterministic budgets r_i<=r, additivity would give `sum r_i^2=Omega(N^2)`, hence `sum r_i>=Omega(N^2/r)`. I notified the lead of this distinction; the lead agreed to add the deterministic-budget version and label saturated-budget counting separately. Expected adaptive stopping/readout costs require additional justification.

## Trusted global spin promise

If the null is supplied with the same trusted `E J^2=3N/4`, the product-marginal alternative is generally excluded. For any mixture of product states, let v_i be each component's Bloch vectors. Then

`4 E J^2=3N+E|sum_i v_i|^2-E sum_i |v_i|^2`.

At the trusted value, `E|sum_i v_i|^2=E sum_i |v_i|^2<=N`. Jensen gives `|sum_i E v_i|<=sqrt N`, or mean Bloch norm at most `1/sqrt N`. The polarized target has norm asymptotic `sqrt(8/pi)/sqrt N`, a strict constant-factor violation. A single-site mean estimate on O(N) copies can therefore infer entanglement with this supplied promise.

The r-site resource refinement is also explicit. For a uniformly random size-r subset and a fixed z axis,

`E S_r^2=r+r(r-1)/(N(N-1)) (4 E J_z^2-N)`

`<=r+2r(r-1)/(N-1)`.

This bound uses `J_z^2<=J^2` and works for arbitrary nulls with the promise, with no permutation assumption if the subset is randomized. The target and null mean-gap is of order r/sqrt N. For r=o(N), the subset-sum variance is O(r), so a constant-error promised test uses O(N/r) preparations. At r=1 this is O(N). The exact target mean remains tied to the specified polarized regime or an explicitly constructed polarized sector state; acquiring the promise experimentally is not free.

The unrestricted quadratic certification lower bound and the trusted-promise mean test are both meaningful. They answer different legal null interfaces. No universal preparation barrier across both interfaces is established.
