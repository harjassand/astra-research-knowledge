# Decisive older-source repairs: three frozen interfaces

Read status is separate from correctness. Repository commit687dfc0640ee80654bcbdbe38cb13d6e1f1586ce is unchanged. The original-source summaries below were independently checked at the stated scope, not copied as proof validation from the repository.

## Positive-characteristic group rings

Formanek1973 primary PDF acquired, sha256195f1f5f5bb9208d43e63ba0b086b4a325645b9d0097cf61cf8bba1b57f63f9b. Read p366 / PDF1, Theorems1–3; text lines9–25. The no-idempotent theorem there assumes a torsion-free Noetherian group and characteristic0. Arbitrary-characteristic Theorem3 restricts trace to the prime subfield. URL: https://www.cambridge.org/core/services/aop-cambridge-core/content/view/25AF425E2069C808258EA860D2329372/S0008414X00050392a.pdf/idempotents-in-noetherian-group-rings.pdf

Burger-Valette1998 primary scanned PDF acquired, sha2564a80e0000b8b42fac420818dd96cb5b51472abc9e93fe62919a7031775d8cc5e. PDF8 rendered at150dpi and viewed in full. Lemma4.1 assumes characteristic p, no p-torsion and no relevant power-conjugacy, and concludes tau(e)=0 or1. Proposition4.2 concerns the complex group algebra, using characteristic0 trace positivity after reduction modulo primes. The original page does not convert the characteristic-p trace restriction into triviality of e. URL: https://people.math.ethz.ch/~burger/pub/1998_Idempotents.pdf

BLR2008 published Journal of Topology PDF acquired from academic mirror, sha2565028632393a6680a169fed740a75f28d0d2bd8f928512dcf01a81f3306ab0140. Read printedpp62–63 / PDF6–7, Theorem1.12 and cited paragraph; text lines250–316. The paper still prints the stronger all-field hyperbolic claim and attributes it to the sources above. Its separate K0 theorem adds stable finiteness, characteristic0 or soficity. This establishes a scope discrepancy in the printed attribution, not the truth or falsity of the stronger claim. URL: https://www.maths.ed.ac.uk/~v1ranick/papers/blr2.pdf ; publication DOI https://doi.org/10.1112/jtopol/jtm008

Independent elementary obstruction to the old no-go inference: in any unital ring with ab=1 and ba!=1, r=1-ba is a nonzero idempotent because (ba)^2=b(ab)a=ba. In a group ring, coefficient-at-identity is a trace, so tau(r)=1-tau(ba)=1-tau(ab)=0; augmentation(r)=0 as well. A theorem allowing trace0 therefore does not exclude this witness. Further, R=Rba directsum Rr as left modules, and right multiplication by a gives an injection R->R with image Ra=Rba, its inverse on that image being right multiplication by b. Thus [Rr]=0 in K0 despite r!=0. Rational K0 without positivity is not a cancellation certificate.

Status: relevant original hypotheses and the elementary inference failure reconstructed. No positive-characteristic idempotent theorem was established or refuted. Need a valid missing theorem/erratum, or a direct candidate geometric/witness failure.

## Thermal absent sharp proof

Read current reviewed wrappers N136,N137,N141 and the active availability gate. At the pinned version the full linked proof packet remains unavailable; only a summary and availability notice are supplied. The new local-marginal theorem cannot repair the separate entropy-regularization and sector-relative separability proofs. Status: source availability read only; no full sharp proof reconstructed. Pass condition remains immutable proof acquisition plus independent all-N reconstruction with unnormalized-jump time convention and cross-copy lab correlations intact.

## Detyping and current thesis

Official Lin thesis final published2026 acquired, sha2560e0740eac5a84c63278574249d49c5aa19d25e208e99c2522160a30b624bcfa3; award date8September2026. Read printedpp79–82 / PDF100–103: Definitions7.2.8,7.2.10 and Lemma7.2.11. Text5551–5784; PDF103 rendered and viewed. The wire formulas, equality fallback and completeness reasoning remain, including implicit conditions for the symmetric Bob function. The conditioning proof proceeds from a good detyped strategy to a good original strategy, while the stated near-perfect implication goes in the opposite direction. This source does not provide a newer repair of the scoped issue. The CHSH counterexample itself was not independently reconstructed by this lead.

Source URL: https://pure.uva.nl/ws/files/345058241/Thesis.pdf ; metadata https://dare.uva.nl/id/972474dc-bc07-4a5a-a075-7e62fb6d580b . Compare current actual CL registers with the final answer-reduction diagram before applying the independent-branch gap lemma. Do not infer the whole compression theorem is false from this local source issue.

## Failed source acquisitions retained

Web fetches for original Formanek, Burger-Valette and the FU-Berlin BLR PDF timed out. Direct acquisition succeeded for the first two. FU-Berlin BLR direct download also timed out; Bonn redirected author URL failed TLS validation. No TLS validation was disabled. The published BLR academic mirror succeeded. acquisition.json and blr_acquisition.json preserve exact outcomes.
