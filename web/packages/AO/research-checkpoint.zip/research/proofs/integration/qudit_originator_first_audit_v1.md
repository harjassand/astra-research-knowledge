# First qudit-originator exposed audit

Checkpoint: 2026-10-08 11:25:50 UTC. Complete read of ../thermal/qudit_centered_entropy_FROZEN.md, SHA256 5191ed718cc7c57cb2a342784d1e5a6215c9616066ea734f3752d25c8bbcfd38. This assessment is frozen before reading the separately target-only qudit proof ../qudit_blind/proof.md. The integration go/no-go route preceded the originator freeze and supplied its one-body decomposition; this is an exposed audit, not a blind reconstruction.

**First verdict:** no fatal gap found. The finite N/r statement, fixed local dimension, full-rank reference, complex weighted Parseval and entire coefficient sum check. No matching qudit upper is claimed.

Representation: mu=lambda-lambda_d(1,...,1) is a degree-K polynomial representation. A unitary copy inside K tensor factors supplies the bound ||pi_mu(A)||<=||A||^K. The determinant twist is an identity of polynomial representations on GL(d), transported by a unitary intertwiner because their U(d) representations coincide. Polynomial continuity covers every singular A; det^0 is one. This avoids a false appeal to a eigenvalue bound for nonnormal A.

Positivity: differentiating exp(tH) identifies the collective one-body functional as lambda_d TrH plus the K residual tensor sum. The averaged residual marginal is an actual density matrix, not only a traceless moment vector. Hence tau_lambda=(lambda_d/N)I+(K/N)gamma_lambda is positive, normalized and exact, with arbitrary gamma chosen for K=0. It gives tau>=(1-EK/N)I/d and beta^2<=(d-1)K2/N. N>=4dK2 supplies both tau>=I/(2d) and beta<=1/2.

Complex Gram: for W=sum v_a(T_a-b_aI), Tr W^dagger W=d(|v|^2+|b dot v|^2). Therefore G>=I/2 using tau>=I/(2d). For R=rho T^-1, ||R||_T^2=Tr rho^2 T^-1 and <B,R>_T=Tr rho B^dagger by cyclicity. Products of the identity and centered basis span the full operator space; distinct supports are orthogonal. There is no assumption that rho commutes with its reference. Weight one is identically zero, and 2^w conditioning is paid per support.

Determinant/generator: log det(P)<=Tr(P-I) for P=(I+W)^dagger(I+W) proves the determinant-square inequality directly, with singular cases handled by zero determinant. TrZ=0 and Hilbert-Schmidt orthogonality eliminate the scalar cross term in ||Z-(b dot z)I||^2. The residual MGF and the finite beta bound give A exp(L^2/2) exp(SN|z|^2), with the stated L,S; all relaxed constants are safe.

Counts: the common radius R^2=w/(2SsN) gives squared coefficient bound exp(w)(2SsN/w)^w. Exact falling-factorial multiplicities and the support factor 2^w give q=4eSs alpha/(1-alpha)^2<=16eSs alpha<=1/5. The number of count vectors is bounded by (w+1)^(s-1) because its first s-1 entries determine the last. The reverse factorial-binomial inequality used to sum the majorant also holds termwise. Its sum is at most 25(s-1)!(5/4)^s, yielding the stated C_d.

Entropy/access: spectral-overlap Jensen is valid for zero rho eigenvalues and positive reference eigenvalues. PI makes the adaptive distinct-site simulation dimension-independent. The product null tau tensor N is legal in unrestricted ALLSEP. The lower is a necessary cost for a fixed testing gap; a tail law alone does not assert entanglement. Fixed d,A,B,C is required, and every subextensive r sequence eventually enters the stated range. No growing-d result, correlated-target result or expected adaptive-readout theorem follows.

Full candidate comparison and a final verdict will follow only after reading the separately frozen target-only proof. External validation and historical novelty remain UNKNOWN.
