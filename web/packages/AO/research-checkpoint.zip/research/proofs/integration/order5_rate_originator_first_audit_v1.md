# First originator-only audit: exact order-five rate phase

Checkpoint: 2026-10-08 11:55:03 UTC. Completed before opening the fresh `rate_phase_blind/report.md`. This is an argument-exposed adversarial reconstruction, not blind discovery, formal replay, external validation or a historical-priority audit.

Inputs:

- `work/agents/chemistry/ORDER5_STRICT_RATE_PHASE.md`, SHA256 `45929c5e1b5ce9c34e06444b5f7e5594fa73e27438f6fb7f8c4725333d185b19`.
- `work/agents/chemistry/ORDER5_EXACT_RATE_CLASSIFICATION.md`, SHA256 `71c3f04c967cdce715fe54dcf7d03dd762146ca878571dd1934a02c9684c5ea3`.

**Verdict: PASS for the full parameter classification, including the critical surface.** All coefficients must be fixed, finite and strictly positive. The full-chain return and perturbation estimates support the accelerated-trace critical argument. One useful clarification of the immigration estimate is recorded below; it changes no statement or bound.

## Exact statement

The five jumps and falling-factorial intensities are

    I:(2,0), k0;
    U:(1,1), k1(a)_2;
    V:(0,1), k2(a)_3 b;
    D0:(0,-2), k3(a)_3(b)_2;
    D1:(-1,-2), k4(a)_3(b)_2.

Set d=k3+k4, beta=k2/d, q=k4/d, and

    h(beta)=[1+beta exp(2beta)(2beta)^(-beta) gamma(beta,2beta)]/2,
    mu=1-q h(beta).

From every finite initial state the minimal CTMC explodes almost surely exactly when mu>0. It is nonexplosive for mu<=0. The strong-endotactic source diagram has reactant order five independently of the rate tuple. This classifies this diagram, not the minimum order among all endotactic networks.

## Uniform full-reaction return estimates

The macro construction survives low-A feedback. It starts at active a>=3,b>0, ignores immigration until the first B-changing event, and includes at most one activation when a marked death reaches a=2. It stops at B=0 before a reset. A macro birth increases B by one and a macro death lowers it by at least one. At every active pre-event state k1/(a-2)<=k1, so its conditional birth probability is at most (k2 b+k1)/(k2 b+k1+d b(b-1)). This remains true after averaging the ignored immigration run.

For sufficiently large finite M, the birth probability is <=1/4 outside B<=M. F(B)=2^B then contracts by at most 7/8, including the worst marked-death reset. The stopped multiplicative supermartingale proves E[(8/7)^tau]<=2^b for the first macro entrance into {0,...,M}; F>=1 also establishes that entrance is finite without presupposing CTMC regularity.

Inside the finite B set, the all-unmarked-death/parity-repair word has length <=ceil(M/2)+1 and positive probability uniformly over unbounded A. A failed fixed-length block ends with B<=M+L. Its recovery has a uniform exponential moment. Hence for small t the weighted failure expectation E[e^(tR)1_failure] is <=1-alpha/2. The derivative remainder is uniformly bounded using the already available exponential recovery moment. Conditional iteration, not independence of trials, gives an exponential macro absorption tail.

Ignored immigration runs have uniform geometric parameter z=k0/(k0+6k2)<1, and a macro includes at most two other reactions. The conditional length moment m(t)=exp(2t)(1-z)/(1-z exp(t)) is correct. Padding lengths by zero after absorption makes the fixed-j sum bound m(t)^j legal. Splitting on K>floor(epsilon n) proves a full-reaction exponential tail from active B=1, uniformly over A. Negative macro B drift and the compact retry argument also give E N<=C(b+1) from arbitrary finite B, with at most two initial low-A activation reactions. Thus every excursion reaches the axis before any possible explosion; this is proved on the complete embedded chain.

## The occupation functional is an actual expectation

For the autonomous killed chain b->b+1 at k2 b and b->b-2 at d b(b-1), the same return estimates establish finite expected reaction count and physical absorption time before using a generating function. The occupation coefficients nu_b therefore satisfy sum b nu_b<infinity and sum b(b-1)nu_b<infinity. G,G',G'' converge absolutely through z=-1 and z=1.

Dynkin for bounded z^b gives 1-z=k2(z-1)zG'(z)+d(1-z^2)G''(z). The differential equation d(1+z)G''-k2 zG'=1 and integrating factor exp(-beta z)(1+z)^beta are correct. Bounded G' at -1 kills the arbitrary homogeneous solution. Substitution at z=1 gives E births=beta exp(2beta)(2beta)^(-beta)gamma(beta,2beta); pathwise particle balance yields E deaths=h(beta). This is not a formal stationary-measure inference.

## The actual feedback kernel has drift mu+O(1/a)

After the initial U event, couple the fast V/D0/D1 choices and death marks with the autonomous chain. Before an extra U event or A<a/2 the fast probabilities are independent of A, so the fast death counts agree. The probabilities of U and I at each full step before A<a/2 are respectively O(1/a) and O(1/a^3). A fall to A<a/2 requires order a marked deaths and hence order a full reactions, whose uniform tail gives an exponentially small contribution.

If the first additional U occurs after j full reactions, B<=j+1 before it and B<=j+2 afterward. Both actual and reference remaining expected event counts are <=C(j+3), uniformly over the current A. The probability-weighted sum (C/a)sum_j(j+3)P(N>j) is O(1/a). On the low-A failure the analogous sum begins at j of order a, so its polynomial factor is absorbed by a smaller exponential. This proves the claimed death-count expectation transfer and includes all future resets and feedback.

**Clarification:** the stronger O(1/a^3) immigration-count estimate is best proved by stopping only at A<a/2, not by treating everything after the first additional U as one perturbation. Before that low-A stop the immigration hazard is O(1/a^3) at every full reaction, including those after extra U events; the uniform expected full count then gives O(1/a^3). The post-low-A contribution is exponentially small. This supplies the displayed estimate directly and avoids a loose O(1/a) remainder from the first-U coupling. The weaker remainder would already suffice for the drift classification.

Predictable inclusion of the terminal death gives E D1=q E D, because the marked fraction q is exact at every eligible pre-death state. The initial axis immigration has probability O(a^-2) and increment two. Thus the complete return kernel indeed has m(a)=mu+O(1/a), uniformly bounded exponential increment moments and uniformly bounded second moments.

## Physical clock and the critical trace

When mu>0, the uniformly positive large-A kernel drift and exponential increment moments give an exponential no-ruin supermartingale with positive escape probability. The complete embedded axis chain exists for all cycle indices because every B excursion returns after finitely many reactions; its globally bounded second moments allow the martingale strong law before restricting to the survival event. This avoids conditioning drift estimates on future survival. On survival A_n grows linearly. Uniform full-count tails give N_n=O(log n) by Borel-Cantelli, so all late within-cycle A values are also linear. Axis reciprocal rates are O(n^-2), and off-axis totals are O(log n/n^3). Independent holding exponentials have a finite sum conditional on such an embedded path. Finite recovery and bounded immigration boosts make successful renewed episodes uniformly probable, implying all-state almost-sure explosion.

For mu<=0, retaining only each initial axis holding time defines a genuine accelerated marked trace. Its kernel is the complete axis-return probability kernel; its event rate is lambda(a)=k0+k1a(a-1). Those retained holding exponentials are independent of every embedded transition and the full return choice. Self-events remain events, so no division by a state-change probability is hidden.

V=1+a^2 has kernel drift 2a m(a)+E Delta^2<=C for all a, including a=0,1 after enlarging C. Hence L_trace V<=C'V. The direct finite-sublevel Dynkin localization is valid because rates inside the sublevel are bounded and each destination V has finite expectation. Overshoots are included in the stopped value. Gronwall gives P(tau_R<=t)<=V(a0)exp(C't)/R. Any finite-time accumulation of marked events must exit every finite sublevel, so this bound rules it out. Trace time diverges; the original clock contains all of it plus nonnegative excursion durations. Off-axis initial states reach the axis after finitely many reactions. This closes mu=0 without a recurrence assumption or circular regularity premise.

The monotonicity formula 2h-1=int_0^1 exp[2beta(1-u^(1/beta))]du is correct: h rises continuously from one to infinity. Thus for each q in (0,1) there is one threshold q h(beta_c)=1. At beta=1, h=(exp(2)+1)/4, so both displayed explosive/nonexplosive tuples satisfy their exact sign claims.

## Scientific status

The exact rate boundary materially strengthens the order-five construction beyond a sufficient cone: one strongly endotactic diagram realizes both a.s. explosion and nonexplosion with an explicit critical surface. The named minimum-order gap remains {3,4,5} in the opened primary source. Historical novelty, specialist validation and formal replay remain UNKNOWN. The fresh target-only phase proof has not been read at this checkpoint and must be audited on its own argument, rather than taken as agreement evidence.
