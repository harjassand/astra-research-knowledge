# Allocation correction after ranking v1

Time2026-10-08 10:15UTC. Preserve ranking_v1.md as the first frozen handoff; this addendum is the current scientific allocation.

Root reports that the independent geometry auditor, after freezing its own proof, located Li-Wang, Annals152(2000), Lemma1, whose energy-Gram trace method reproduces the9a²/4 coefficient and may weaken the new upper theorem's hypotheses. Exact primary theorem/contract comparison is pending. Consequently, prioritize chemistry's molecular-order optimization and thermal's exact local-information cost proof now. Geometry upper derivation remains useful, but a standard application of a known inequality is not a new frontier theorem. The matching lower construction and the precise optimality corollary may still matter, contingent on source validation and historical novelty.

Chemistry current target is3<=minimum<=7 if the frozen order7 proof survives its fresh audit. An order3 construction settles the primary question; order4–6 improve its upper range. Thermal now reports a stronger purity/relative-entropy bound and matching m=Theta(N/r) preparation complexity; this lead has not yet reconstructed that proof, so allocate proof and protocol audits before promotion.

Independent Minasyan application check found no gap. It is a published-method conditional envelope of any valid torsion-free hyperbolic G, not a new nonsofic source construction. All v1 source repairs and their scopes remain current.
