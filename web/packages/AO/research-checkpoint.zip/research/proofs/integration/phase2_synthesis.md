# Scientific integration: two scoped theorem packages

Current scientific checkpoint: 8 October 2026, Phase 2. Exact creation time, source hashes and read depths are recorded in SESSION_PHASE2.json and SOURCE_MANIFEST_PHASE2.json. This supersedes ranking_v3_phase2.md where the stronger claims below change its ranking. It does not erase earlier failures or frozen artifacts.

## Allocation judgment

Chemistry and quantum local access are the two serious candidates. Chemistry has the clearest named-frontier improvement in the opened primary source: the known explosive endotactic witness has molecular order ten, while the reconstructed witness has order five and is almost surely explosive from every finite state throughout an explicit open rate region. The quantum package now has a broad structural theorem and a sound upper that matches its lower, so its value is materially greater than the earlier white-state discrimination estimate.

Keep chemistry first for remaining molecular-order attack, and reserve serious independent review for the quantum upper and tail extension. There is no externally validated breakthrough or certified historical novelty. Short proofs, exact finite checks, or many reports do not supply those missing statuses.

## Chemistry: exact statement and dependency

Five reactions with positive fixed rates are

    0 -> 2A,
    2A -> 3A+B,
    3A+B -> 3A+2B,
    3A+2B -> 3A,
    3A+2B -> 2A.

The exact fixture uses constants (1,1,1,4,1). Its minimal stochastic mass-action CTMC explodes almost surely from every finite nonnegative integer state. The same is proved in the sufficient open region, with d=c4+c5,

    3(2c3+c2)<2d,
    8(3c3+c2)<7d,
    2c5<d,

and all constants positive. The source hull proves strong endotacticity for every positive rate tuple. The almost-sure theorem does not assert every such tuple explodes.

Dependency spine: exact all-direction source geometry; an actual stopped excursion containing all reaction channels; predictable expected-death counting and positive axis-cycle drift; a uniform full-event exponential tail; survival with linear escape; summable reciprocal holding rates; grouped low-A activation and axis return after finitely many full reactions; uniformly successful renewed episodes at finite failure/recovery stopping indices. The direct independent proof avoids the earlier normalized clamp kernel as a necessary premise.

Status: independently reconstructed positive-probability proof, strengthened by its author to all-state almost-sure explosion and open rates; exposed adversarial integration audit found no fatal gap. Earlier clamp ambiguity repairs and the later direct proof are distinguished in separate frozen artifacts. External verification, formal replay and priority remain UNKNOWN.

Strongest opened comparator: Xu arXiv:2409.05340v2, Theorem 4.6 and Remark 4.8; every order-two endotactic CTMC is regular, a known order-ten explosive witness is cited, and minimal molecular order is explicitly open. If current proofs and priority survive, the minimum is narrowed to {3,4,5}, not solved. The legal order-four near miss proved nonexplosive by the lead is a failure of one mechanism, not a lower bound for all order-four networks.

Decisive next observation: a legal order-three/four explosive example or a genuine all-network regularity theorem at one of those orders. A general catalogue of endotactic networks would not answer that gate.

## Quantum: structural information theorem

Let rho_N be any permutation-invariant N-qubit state. Write M=2j for its total-spin-sector label. Suppose fixed constants A>=1,B,C>=0 satisfy

    E exp(t M/sqrt(N)) <= A exp(Bt^2+Ct), all t>=0,

uniformly in N. No purity, coherent-state form or commutativity is imposed inside the sectors. Let tau_N=rho_{N,1}. Then

    Petz chi-square(rho_{N,r} || tau_N tensor r) = O((r/N)^2),
    D(rho_{N,r} || tau_N tensor r) = O((r/N)^2),

for every subextensive r_N=o(N); r=1 is exactly zero. Constants and finite ranges are explicit in subgaussian_spin_tail_FROZEN.md. Exact white Schur weights are one sufficient instance.

Dependency spine: unitary Schur realization for complex two-by-two matrices; collective-spin MGF control; a centered Hermitian one-site basis with its complex Gram matrix; exact weight-one cancellation; support-wise Gram conditioning, multivariate Cauchy coefficient bounds and all-weight summation; spectral-overlap Jensen for noncommuting quantum entropy. Paying Gram conditioning per support is essential; multiplying one global inverse-density norm would lose the growing-r result.

Status: original exact-white centered theorem independently reconstructed by a separate auditor without lead-proof exposure, reported PASS by root; integration's exposed check also finds no fatal gap. The wider tail theorem is newly frozen and passes the exposed arithmetic/structural check here. A fresh target-only tail audit is still pending, and its proof has not been read here. No historical novelty clearance.

## Quantum: ALLSEP matched operational theorem

The null class consists of all fully separable N-site states without a Schur law or Casimir promise. Each trial uses an independent fresh target preparation, and at most r distinct sites of that copy can be touched. Site and axis random choices follow preparation. Classical adaptive labels, quantum memory and arbitrary joint measurements on the accessed registers are allowed for the lower bound. Coherent addressing that physically touches all N sites is not an r-site protocol.

The matching product tau_N tensor N is a legal separable null, so the centered theorem forces m=Omega(N^2/r^2) preparations for any fixed testing gap. At r=1 certification is impossible for every m through this interface. The direct lower concerns independent copies of the target and this particular independent null; it already obstructs every uniformly sound ALLSEP test.

For targets in the tail class with a strictly positive collective spin-variance violation,

    liminf [2 - 4 sum_a Var(J_a)/N] > 0,

the bounded common-axis heat effect supplies a sound test with m=O(N^2/r^2 log(1/eta)). For exact white weights this extra condition is liminf N|b_N|^2>1. Its bounded outcome, post-preparation random subset, all-weight target control and uniform optimization over heterogeneous product arrays yield a gap of order r/N. Convexity handles mixed separable nulls. The separate two-site tangent witness covers every bounded r>=2. The result is asymptotic with enormous constants; no practical moderate-N experiment has been demonstrated.

Status: upper construction frozen before fresh independent upper work; integration's first exposed audit found no fatal gap and was frozen at 11:00:08 UTC, SHA256 df8205c2768e759ddd9cff138b9de5de7aa0323c319477411c68577f589e4bfe. Fresh target-only upper audit is pending and not read here. The broader-tail upper is an explicit transfer of the frozen effect proof under the spin-variance margin, rather than an inference that a tail bound implies entanglement.

For sequential soundness beyond independent null copies, require each conditional fresh-copy input to be fully separable, or a global multi-copy state separable across the physical laboratories with arbitrary within-laboratory correlations. Unconditional per-copy separability alone is insufficient. This correction is implemented in calibration_and_static_example.md.

With saturated upper access, mN=O(N^3/r^2) physical qubit instances and mr=O(N^2/r) readouts are charged. The lower directly bounds mN. Deterministic charged budgets r_i admit sum_i r_i^2=Omega(N^2) and sum_i r_i=Omega(N^2/r); no adaptive expected-readout theorem is inferred from a maximum cap. Classical calibration, randomness, arithmetic and approximation precision are additional resources.

An independent calibration phase estimates b to error delta/sqrt(N) with O(N/r log(1/eta)) preparations, using the target's O(r) pooled variance. It is charged and frozen before testing. Soundness holds for every clipped calibration vector, even if calibration input was a null. The power margin loses exactly N times its squared vector error. The polarization or spin-variance margin must be supplied or acquired with confidence.

Concrete existence no longer depends on an old bath-time assertion: the static state with exact white sector probabilities and each spin block in |j,-j> has N|b|^2 ->8/pi by a Rademacher CLT with uniform fourth-moment tail control. It is a mathematically explicit example; its physical preparation time is not declared free.

## Promise distinction and falsifier

A trusted null Casimir promise <J^2>=3N/4 excludes the matching product marginal in the polarized example. Fully separable states satisfying that promise have |b|<=1/sqrt(N), while the target has asymptotic norm sqrt(8/pi)/sqrt(N). Local mean sampling then admits O(N/r) preparations, and one-body access is sufficient. The quadratic ALLSEP theorem must not be described as a universal barrier across those different null classes. Acquiring a global Casimir promise experimentally is a charged task, not an automatic gift to the certifier.

The independent rare-sector counterexample satisfies the exact same Casimir mean but violates the centered quadratic order: a weight 3/(N+2) all-up component mixed with a permutation-twirled singlet state gives D=Omega(r/N) for log N << r=o(N). Thus some quantitative spin-sector tail condition is mathematically necessary for the claimed general structural bound. A mean-only extension is refuted.

## Prior art and other fields

centered_priorart_v1.md pins the nearest primary comparisons. Local hiding and global strong-symmetry entanglement are established, and Stam's classical fixed-type quadratic entropy bound is old. The recent EPU and mean-field results have different comparators or weaker local rates. The candidate should be judged on its full noncommuting own-marginal, uniform-tail, subextensive-access and ALLSEP operational contract. Priority remains UNKNOWN.

Geometry's proposed upper coefficient is a routine adaptation of Li-Wang's published method under weaker premises; only a conditional matching-lower consequence remains. Algebra's property-T transfer is a valid use of published Minasyan machinery conditional on the unvalidated source G's nonsoficity. TCS retains a conditional sampler-wire comparison and unresolved source detyping issues. Statistics has scoped sharp bank bounds and a classical extraction reduction. The independent White-conjecture bridge failed or duplicated primary prior art. None outranks the two theorem packages above on current evidence.

Do not treat this synthesis as a report-count achievement. Promotion requires the exact proof, its legal interfaces, decisive audits and candid priority status. The three older source repairs remain separate and are not silently validated by these newer candidates.
