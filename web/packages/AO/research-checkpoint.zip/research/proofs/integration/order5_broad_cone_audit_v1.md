# Exact exposed audit: broader order-five almost-sure cone

Checkpoint: 2026-10-08 11:35:18 UTC. Complete read and reconstruction of ../chem_order5_blind/broad_cone/report.md, SHA256 9da3dacdf102d3158125812c4f328d32c51f87bd7149d751ae49af51eb776a90. I have not read the originator's newer broad-cone almost-sure report or another broad-cone audit. This worker explicitly disclosed exposure to the positive-cone report and supplied outlines; its strengthening is not relabeled blind.

**Verdict:** no fatal gap found. The minimal order-five CTMC explodes almost surely from every finite state for fixed positive constants k0,...,k4 with d=k3+k4>3k2 and k3>k4. The same reaction geometry remains strongly endotactic by the separately audited rate-independent hull. The proof does not claim this sufficient cone is maximal or that all positive coefficients explode.

## Global B-axis return needs only positivity

The embedded-chain lemma is sound for every positive rate tuple. It activates A>=3 in at most two initial reactions. It groups a D1 death's possible A=2 activation, and stops immediately if B=0 before taking any reset. Each macro birth raises B by one; each death decreases it by at least one. Ignored immigration has a uniform geometric bound z=k0/(k0+6k2)<1.

The birth bound p_b=(k2 b+k1)/(k2 b+k1+d b(b-1)) survives averaging over the ignored runs because at every pre-event A>=3 the exact k1 term is k1/(A-2)<=k1. The stated positive quadratic root and M choice make p_b<=1/4 outside {0,...,M}. Consequently the stopped macro B process has drift <=-1/2 and E(tau_K)<=2B0. This conditions on the full history; B alone is never assumed Markov. B increments are bounded, so finite stopped calculations are integrable.

Inside K, an unmarked-death word reduces even B to zero and odd B to one, followed by its mandatory birth to two and one more unmarked death. All required B states stay <=M, since M>=2. Every required death has conditional probability >=e>0 uniformly in the unbounded A coordinate; the word length is at most L=M+2, so its success probability is >=e^L. Failed length-L blocks leave B<=M+L and recover to K in bounded conditional expected time. Geometric trial counting therefore yields both almost-sure and finite-expected macro absorption.

Summing conditional expected macro lengths gives a finite expected full-reaction count. A macro begins only before absorption, so its inclusion indicator is measurable before its random length; no conditioning on a future success event is used. In the independent exponential-clock construction, total rate >=k0 makes expected physical return time at most expected reaction count/k0. This establishes axis recovery before any explosion without assuming nonexplosion beforehand.

## High-A positive-drift episode

With s=d/k2>3, q=k4/d<1/2 and rho_cut=min(1,2s/3-2)>0, the stated A_* makes k1/[k2(A_*-2)]<=rho_cut. Stop actual excursions at B=0 or A=A_*-1. The H budget is valid at every active pre-state. At B=2 its condition is exactly rho<=2s/3-2; even larger B and odd cases are favorable. Expected total deaths are <=2. Predictable marked counting includes the terminal death and gives expected marked losses <=2q. An axis cycle therefore has mean A increment >=mu=1-2q>0.

The F checks include the exceptional F(1)=5. The ratios <=4/5,1/2,7/8,15/32 at B=1,2,3,>=4 are correct. The B>=4 bound follows from 7(b+1)<=3b(b-1). Input probability is uniformly <=z_* and every killed boundary value only decreases F. Thus the full-event exponential tail with gamma=z_*+(1-z_*)7/8<1 is valid, including every neutral input channel.

The displayed theta formula comes from the tail majorant for E[Delta^2 exp(eta|Delta|)]. Since |Delta|<=2(N_events+1) and eta=-log(gamma)/4, its series is exactly bounded by the stated C. Taking theta<=min(eta,mu/C) makes E exp(-theta Delta)<=1-theta mu/2. The nonnegative stopped exponential supermartingale gives the claimed no-ruin probability. A decreases only one at a time, so the low-A hitting value is exactly A_*-1.

For the martingale strong law, one may extend post-ruin increments deterministically by mu; on no ruin this changes nothing and supplies a globally defined uniformly square-integrable difference sequence. The proof must use this stopped/extended construction, not condition increments on eventual survival. Its uniform event-count tail yields N_events,n=O(log n) by Borel-Cantelli. Along no ruin, A_n grows linearly and the minimum A inside a cycle is >=A_n-N_events,n. Axis inverse rates are O(n^-2), and positive-B inverse rates sum to O(log n/n^3). Conditional independent exponential clocks then have a finite sum almost surely.

## Boost trials and renewal

An axis state below A_* can be boosted with at most J=ceil((A_*-2)/2) immigrations. Every pre-boost A is <A_*, so its input probability is at least k0/[k0+k1(A_*-1)(A_*-2)]. This lower bound is uniform and positive, including the no-boost case where p^J<=1. The resulting high episode has success probability >=1-exp(-theta). Their product is the stated uniform delta>0.

Every failed boost or episode stops after finitely many full reactions, at a finite state with A>=2; global recovery returns to an eligible axis state. Strong Markov applies at those finite failure/recovery starts, while a successful infinite embedded episode is used only as a terminal event with finite physical explosion time. Consecutive failure probability is <=(1-delta)^n. Thus a finite-number successful trial occurs almost surely. No trial independence or irreducibility shortcut is required.

## Scientific status

The broader cone is now exposed-audited as a valid sufficient parameter region. Its originator dependency and the separately reconstructed strengthening remain explicit. Geometry, internal proof review, finite diagnostics, formal replay, external specialist validation and historical priority are distinct statuses. The first three are available in scope; formal replay, external validation and priority remain UNKNOWN.

This strengthens robustness of the order-five witness, rather than changing the current {3,4,5} minimum-order gap. A failed legal order-four candidate remains a mechanism failure, not a universal order-four regularity theorem.
