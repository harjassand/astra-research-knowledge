# Integration's rejected short chains

These are actual failed construction attempts; the chemistry lead independently found the same order7 face failure. They are not claims about all termolecular or low-order networks.

## Order6 collinear chain

Candidate: 0->2A->3A+B->4A+2B->3A. The three high-rate jumps have vectors (1,1),(1,1),(-1,-2), so a normal boundary cycle appears to increase axis A by1, and the event/clock scale seems suitable for repaired path arguments. This does not establish endotacticity.

At u=(1,-1), both middle increments are neutral. Their sources are excluded from the essential-source set. The final vector has u projection+1; its source4A+2B has projection2 and is maximal among nonorthogonal sources (the origin has projection0). Thus the final arrow is an endotacticity violation. Candidate rejected.

## Order7 single chain

Candidate: 0->2A->3A+B->4A+3B->3A. Normal three-event cycle raises A by1. One extra first or middle event can be repaired by bounded B-state words, so path survival initially looked promising.

At u=(2,-1), source scores for0,2A,3A+B,4A+3B are0,4,5,5. The middle arrow(1,2) is neutral. The final arrow(-1,-3) has projection+1 at score5, hence is outward at a maximal essential source. Candidate rejected before any explosion promotion. The source-sharing extra inward branch in the chemistry lead's different network is precisely what avoids this kind of neutral-face failure; its stochastic proof is separate.

Decision: generic-direction tests or normal event-rate estimates cannot justify an endotactic counterexample. Every relevant lower-dimensional normal face must be checked exactly.
