# Mean Casimir does not imply quadratic centered local entropy

Checkpoint saved 2026-10-08 10:45:43 UTC. Independently derived by integration during Phase2, after auditing the exact-white-sector theorem. This is a scope counterexample, not a refutation of that theorem. No finite diagnostic or external theorem validation is claimed. The initial manually estimated minute label was corrected from the filesystem timestamp; mathematical content is unchanged.

Let N be even. Start with a tensor product of N/2 two-qubit singlet states and average its density operator over all permutations of the N sites. Denote the resulting permutation-invariant state by S_N. Each paired component is a global spin singlet, so `Tr S_N J^2=0`; its one-site marginals are exactly I/2.

Let `p=3/(N+2)` and

`rho_N=(1-p) S_N+p (|0><0|)^tensor N`.

The all-up product is in total spin N/2 and has Casimir `N(N+2)/4`. Consequently rho_N is permutation invariant and obeys EXACTLY `Tr rho_N J^2=3N/4`. Its one-site marginal is `tau=(I+p sigma_z)/2`.

Fix an r-site subsystem and measure every retained spin in the z basis. Let E be the event that every outcome is up. In each permuted singlet-pair component, E has probability zero if the retained subsystem contains both members of any pair; otherwise the retained one-spin marginals belong to distinct independent singlets and E has probability `2^-r`. Thus `0<=Pr_(S_N)(E)<=2^-r`, and the target event probability P satisfies

`p<=P<=p+2^-r`.

The product-marginal reference has event probability

`Q=((1+p)/2)^r`.

Quantum data processing and binary relative entropy give

`D(rho_r||tau^tensor r) >= d(P||Q)`

`=P log(1/Q)-h(P)-(1-P) log(1-Q)`

`>=P r[log2-log(1+p)]-h(P)`.

For a sequence `log N << r_N=o(N)`, eventually `2^-r<=p`, so `P<=2p<=6/N`; for sufficiently large N this is below1/2. The binary entropy bound `h(P)<=P log(e/P)` and its monotonicity near zero imply `h(P)<=C log N/N`. Also `log2-log(1+p)>=log2/2` for sufficiently large N. Therefore

`D(rho_r||tau^tensor r) >= (3 log2/2) r/(N+2)-C log N/N = Omega(r/N)`.

Since `(r/N)/(r/N)^2=N/r` diverges for every subextensive such sequence, no constant-C bound `D<=C(r/N)^2` can hold over all permutation-invariant states with only the mean-Casimir promise. For example, r=floor(sqrt N) gives a lower bound of order N^-1/2 rather than N^-1.

This state has a spin-N/2 sector of probability p~3/N. Such a rare macroscopic-spin sector is permitted by the mean constraint but excluded by the exact white Schur weights. The distinction is mathematically load bearing. A broader centered entropy theorem may replace exact weights by an appropriately uniform subGaussian spin-tail/MGF hypothesis, but a single second-moment condition cannot suffice. That broader theorem is not claimed here.
