# Scientific integration and allocation, version 1

Frozen 2026-10-08, first exploration interval. Pinned knowledge commit 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce. Criteria were frozen first in criteria_v1.md. This ranking selects next mathematical decisions; it predicts neither correctness nor breakthrough probability. No current lead is externally validated or priority-cleared.

## Next phase

Concentrate the serious frontier effort on two directions: the geometry constant and the minimum molecular-order explosion question. Keep the new thermal information-cost theorem as a strong quantitative alternate while its all-size proof and matched operational interface are checked. Close TCS's one source-wire question before funding broader compression claims. Published algebra transfers should remain conditional consequences of the unverified original G.

The value order can change only with a specific observation: a valid order-three explosive endotactic network would move chemistry decisively first; a matching geometry lower construction in the upper theorem's exact class plus prior-art clearance would make the geometry optimum the strongest currently complete scoped result; a new thermal information lower bound with an equally informed attainable protocol can outrank a routine local-invisibility corollary. A standard proof reproduced three times does not gain novelty from repetition.

## Two strongest frontier attacks

### 1. Sharp geometry optimum in a class with varying links

Exact new upper candidate: for an end g=dr²+f(r)²H(log r), f/r->a>0, H in a C-infinity compact family on a fixed connected closed surface, fixed POINTWISE area form of total4pi, and H_t->0 in C0, limsup h_k/k² <=9a²/4. No Ricci premise is required for the upper result. The load-bearing finite-dimensional inequality is p k >= inf_H sum_{j<p}(sqrt(1+4lambda_j/a²)-1)/2. Full internal proof is frozen at ../independent/UPPER_BOUND_FROZEN.md and has an independently assigned audit; this lead read that derivation, which is not an additional independent proof.

Importance: potential exact optimum for a natural nonunique-tangent-cone subclass, rather than another loose C_3 AVR estimate. The independent derivation gives a trace comparison for all boundary frequencies, then a Gram determinant growth inequality and uniform Weyl asymptotics. It keeps p,L fixed before t tends to infinity, avoiding an uncharged growing-cutoff approximation.

Decisive gates: (i) read the original Colding-Minicozzi 1998 Weyl-type proof and current primary literature to determine whether this exact constant and class are already covered; (ii) prove that N175's lower construction really has the same pointwise area form, compact link family and H_t decay, and independently audit its countable harmonic transfer. Matching lower optimality is not established by source-family agreement. A valid upper theorem alone is a scoped result, not the general nonnegative-Ricci frontier. The original general coefficient problem remains outside the supplied polar compact-link interface.

Audit interface: exact upper statement only to an analyst before derivation exposure; separately send the lower source plus membership checklist to another checker. Attack core removal/Neumann bracketing, normalized DtN form, trace and unique-continuation claims, fixed-volume Gram derivative, uniform Weyl onset, and all limit orders. Do not allocate more workers merely to reproduce the same proof.

### 2. Minimal reaction order for explosive endotactic mass action

Exact target was independently opened in Xu, arXiv:2409.05340v2: Theorem4.6 excludes order<=2; Remark4.8 gives the known order10 example and leaves the minimum open. Version metadata says9May2026, while the HTML manuscript is internally dated24August2026; retain both. Source order means maximum REACTANT molecularity, with fixed positive falling-factorial mass-action rates. Endotacticity quantifies all directions and essential-source faces; generic directions alone are insufficient.

Current frozen candidate is order7, not order3: 0->2A; 2A->4A+B; 4A+B->5A+2B; 4A+B->4A+2B; 5A+2B->3A. Its proof, read by this lead after freezing, is ../chemistry/ORDER7_FROZEN.md. It claims strong endotacticity and positive-probability explosion for every fixed positive rate tuple. The extra source-sharing B branch repairs a neutral face; accepted macrochains have bounded increments, uniform positive drift, summable O(n^-2) rejection and a finite quadratic-rate physical clock. A fresh audit was assigned to the exact network.

Importance: a genuine reduction10->7 of a primary paper's open upper range if the proof survives. It is not a determination of the minimum, not weakly reversible recurrence, and not physical realization. The newly proved boundary-repair mechanism may be more valuable than the numerical order improvement if it reaches lower molecularity. Continue optimization under the exact graph/rate contract; an order3 construction would settle the minimum, whereas order4–6 would sharpen only the upper bound.

This integration attempt proposed an order7 single-chain alternative, but it FAILED at w=(2,-1): the neutral middle arrow is discarded and the maximal final source points outward. The earlier order6 collinear chain likewise fails on a lower-dimensional normal. These negatives are preserved in chemical_attempts_v1.md. Do not erase failed faces by generic checking.

Audit interface: one exact all-direction source geometry proof; a separate event-chain/holding-time proof with no supplied derivation. The stochastic auditor must charge normalization: positive probability for the normalized escaping chain does not imply actual survival without the infinite-product factor. Uniform fixed-rate constants, all enabled events, disjoint accepted grammars, escape and finite clock must all be checked. Finite exact enumeration is diagnostic only.

## Other current leads

| Lead | Mathematical status and next value-changing obligation | Allocation judgment |
|---|---|---|
| Thermal local information cost | Lead reports a frozen all-size bound 2^r Tr(rho_r²)-1 <=50000r/N and relative entropy <=50000r/N, from exact initially white Schur weights, for r<=N/128 and arbitrary within-sector states. This plus an executable polarized readout claims m=Theta(N/r_N) preparations for every r_N=oN. This lead has not yet read/reconstructed that new proof. | Strong quantitative alternate; audit all-size harmonic/moment counting and clarify fixed number of iid preparations, touched sites, adaptive protocol and physical preparation costs. The earlier CKMR local trace result alone is likely a standard corollary. Historical novelty UNKNOWN. |
| TCS final-wire gap | Frozen internal general independent-branch comparison controls full Ora seed disclosure and gives sigma_final>=eta sigma_input. The source diagram's eta=1/9 case is conditional on actual wire law; the CL implementation references detyped low-degree registers. Repaired detyping also needs unrestricted-vs-synchronous value semantics. | One source implementation falsifier first. A local gap lemma is useful but not full compression, a new MIPco theorem, or a global theorem refutation. |
| Algebra hyperbolic property-(T) envelope | Independent application in minasyan_application_independent_v1.md passes: use L=G*P, F=P, Q=G and relators on generators. Exact smallness holds; G embeds quasiconvexly; eta(P)=K, hence property(T). Nonsoficity transfers only from an independently valid G. | Routine corollary of a published quotient theorem, already based on2005 machinery. Preserve stronger embedding interface but do not promote inherited unverified G or assign breakthrough status. |
| Statistics acquired parity bank | Exact finite bank-capacity and bit/sample lower bounds reported; a bank with a margin can feed a classical heavy-Fourier LPN solver. Known-secret basis is explicitly supplied; raw acquisition still has exponential compute at ordinary noise. | Useful obstruction and cost accounting; no KLS advance, unconditional efficient LPN learner, or capability separation. Await primary novelty comparison before promotion. |
| Release Hodge extraction | Extractor explicitly reports source extraction only and no established mixed-K3 bridge. | Do not change opportunity ranking from catalogue absence or theorem titles. |

## At most three older source repairs

1. **Thermal N136/N137.** The sharp1/4 regularized relative-entropy coefficient and size-independent singleton-separability time have only a supplied summary at their cited version; the linked full proof remains absent. Reconstructing a new local bound does not acquire these separate proofs. Pass condition is immutable full proof acquisition followed by normalization, regularization, sector-relative margin and all-N reconstruction. Do not use the summaries as premises. This is an evidence gate, not a reason to spend the remaining run looking for an unavailable archive.

2. **Group-ring N129/N165.** This lead independently acquired Formanek1973 and visually inspected Burger-Valette1998 p8, and acquired the published BLR2008 version. Formanek's relevant theorem is characteristic0 with a Noetherian group. Burger-Valette's characteristic-p lemma concludes trace0/1 and its next proposition concerns C[G]. Published BLR p63 still prints the stronger all-field hyperbolic assertion and attributes it to those sources; its Theorem1.12 separately requires stable finiteness, characteristic0 or soficity in addition to rational K0. Thus the discrepancy is real at the printed-source boundary, but neither validity nor falsity of the stronger assertion follows. Independently attack N129's uniform graph, outer-boundary disk surgery, torsion-freeness and nonzero-witness preservation; do not infer a no-go from zero trace. Exact primary audit is in source_repairs_v1.md.

3. **TCS N183/N184/L02.** Official Lin final2026 thesis was opened and downloaded. Printedpp79–82 / PDF100–103 retain the detyping wire formulas, implicit symmetric Bob completion, equality fallback and completeness argument. Lemma7.2.11 retains a soundness statement whose implication does not match its conditioning proof. It supplies no newer repair. Compare primary actual CL registers through answer reduction; keep the CHSH fixture's scope tied to the intended symmetric completion. Neither source age nor thesis status settles correctness. Full repetition proof, repaired local semantics and later compression stages remain separate obligations.

## Evidence boundary and reserve

criteria_v1.md defines promotion conditions. The parent controls budget and has reserved serious independent audits. Do not promote any result from a reported audit count; record whether the reviewer received only the exact statement, whether a proof was reconstructed, which inherited premises remain, and what external/priority checks are absent. No research effectiveness or breakthrough claim follows from current report volume.

Source hashes/read depths, exact failed acquisitions and memory-derived orientation will be recorded in SESSION.json/source_manifest.json. Repository untouched; all integration files are in this lead's assigned folder. The first25-minute handoff is satisfied by this version; subsequent versions must preserve it.
