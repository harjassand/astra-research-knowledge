# First originator-only audit: critical isotropic Curie–Weiss marginals

Checkpoint: 2026-10-08 12:09:13 UTC. Full exposed reconstruction of `work/agents/curie_weiss/CRITICAL_PROOF_FROZEN.md`, SHA256 `55a256b8a7d90573bed614c844a3bbb3734cb4c0886a82716afe18b281467b07`. Completed before opening the fresh critical-window proof. This is an internal argument audit, not independent discovery, formal replay, specialist validation or a priority conclusion.

**Verdict: PASS for the stated all-sequence window, small-window leading Petz coefficient, bounded-witness trace/KL orders and above-window regimes.** No stronger assertion needs trimming on this audit. The singular r=1 exception is correctly stated separately from the r>=2 Theta claims. The normalization is full trace, J=(1/2)sum sigma, beta=2 and omega_r=I/2^r.

## Statement checked

For rho_N=exp(2J^2/N)/(2^N Z_N), the actual one-site marginal is I/2. Write a=r/sqrt(N), delta=(1/2)||rho_r-omega_r||_1, and mu_2=sqrt(12)Gamma(5/4)/Gamma(3/4). For any integer sequence 1<=r<=N, each of centered Petz chi-square, D and delta vanishes iff r=o(sqrt(N)). For r>=2 below that window,

    chi=[mu_2^2 r(r-1)/(6N)](1+o(1)),
    delta=Theta(r/sqrt(N)),
    D=Theta(r^2/N).

If r/sqrt(N)->infinity, delta->1 and D=Theta(r/sqrt(N)), including r=N. At a positive finite crossover the distances are bounded away from zero; the proof does not supply a full finite-a crossover profile.

## Exact finite spin law, prefactor and quartic tails

The sector multiplicity difference equals 2(M+1)/(N+M+2) times the appropriate binomial; multiplying by spin dimension M+1 gives w_N(M)=2(M+1)^2 Pr(S_N=M)/(N+M+2). The dimension factor is essential. The quadratic tilt exp[(M^2+2M)/(2N)] cancels the quadratic term of the exact binomial rate I(M/N), leaving the quartic term.

For M/N<=1/2, Stirling retains a uniform N^-1/2 local prefactor, with the deliberately loose 1/2 and 2 constants legal for N>=256. Since (M+1)^2/N^(3/2)<=2(1+x^2), the resulting 14(1+x^2)e^(-x^4/12) bound is correct. For M/N>1/2, Chernoff without the local prefactor initially costs sqrt(N); x^4>=N/16 and sqrt(N)e^(-N/384)<=9 absorb this loss into the weaker quartic exponential and the displayed 200 constant. Thus the full-law envelope is valid through the endpoint M=N, rather than only on compact scaling ranges.

On 1<=x<=2, the lower local prefactor and at least N^(3/4)/3 parity points prove Z_N>=e^(-16/9)N^(3/4)/6. This yields the normalized envelope C0 N^-3/4(1+x^2)e^(-x^4/24). The exponential-square moment follows from x^2/48-x^4/24<=-x^4/48+1/192 and the unimodal grid-sum envelope. The integral I0 and factor one-half for the parity mesh are correctly normalized. Consequently E exp(sX_N)<=A0 exp(12s^2) is uniform for all real s.

Uniform compact Stirling expansion and this global envelope give the normalized radial density x^2 e^(-x^4/12)/I2, all fixed moment convergence and Z_N/N^(3/4)->sqrt(2/pi) I2. The residual tilt M/N and sixth-order entropy correction vanish uniformly on compact x intervals. Tail domination extends the Riemann sums and moments; no local Gaussian prefactor is lost.

## All supports and fixed-r coefficient

The collective centered observable on sector M has absolute eigenvalue at most M. Therefore the actual MGF scale is 12N^(3/2), and the generating-polynomial exponent keeps both 2N and 12N^(3/2), with total <=14N^(3/2). This is a legitimate varying-B_N application of the audited algebraic concentration proof, not an invocation of its fixed-B asymptotic conclusion. Its support majorant is exactly q_N=168e^2 r/[sqrt(N)(1-r/N)^2].

SU(2) symmetry kills the diagonal homogeneous polynomial for every odd support order; permutation symmetry and real polarization then kill every odd tensor. The remainder begins at weight four and is bounded by A0^2 q_N^4/(1-q_N). The pair tensor is c_N delta_ab with c_N=[E M(M+2)-3N]/[3N(N-1)], so its exact support weight is 3 binom(r,2)c_N^2. Since sqrt(N)c_N->mu_2/3, the pair term dominates the remainder uniformly for every r>=2 with r=o(sqrt(N)), including fixed r and both parity subsequences. This proves the stated leading coefficient, rather than merely an O upper.

## Bounded heat witness pays for trace and small-window KL

For white Y=J_z^2/r, EY=1/4, Var(Y)>=1/16 for all r>=2, and the displayed third moment implies E[(Y+Y')^2 1_bad]<=E(Y+Y')^3/12<=1/16 when bad means Y>12 or Y'>12. Thus kappa_r=-4Cov(Y,e^-Y)>=e^-12/8. This checks the uniform finite-r gap; r=1 is correctly excluded.

The pair coefficient of W=e^(-J_z^2/r) is -kappa_r/(r-1). Contracting it with the target pair tensor gives -kappa_r r c_N/2 exactly. All higher-support contributions are bounded by Cauchy-Schwarz using ||W||_(white,HS)<=1 and the weight-four Petz remainder, giving |R|<=A0 q_N^2/sqrt(1-q_N). Therefore the bounded effect gap is Omega(r/sqrt(N)), with remainder of smaller order, for every small-window r>=2. The trace upper is (1/2)sqrt(chi); Pinsker and D<=chi give the KL order. No sharp KL coefficient is inferred.

For arbitrary positive crossover size, choose a sufficiently small fixed epsilon and restrict to k=floor(epsilon sqrt(N)) sites. The displayed epsilon bounds leave a strictly positive limiting heat gap. Trace distance and relative entropy monotonicity under discarding sites then transfer that lower to every r>=k. On any subsequence outside the little-o window this supplies nonvanishing; the pair Petz lower separately supplies the chi conclusion.

## Above-window trace and entropy are stronger, but justified

Conditional on M, the all-site sigma_z sum S is uniform on the parity grid [-M,M], since the spin blocks are maximally mixed. Radial convergence and uniform conditional Riemann sums yield S/N^(3/4)=>XU, with U independent uniform[-1,1]. This law has no atom at zero. Permutation invariance makes the actual r-site readout hypergeometric conditional on the global sign count. Its exact mean is rS/N and conditional variance at most r, including r=N.

For Z=L_r/sqrt(r), one therefore has Z=sqrt(a)Y_N+E with conditional E E^2<=1. Taking threshold a^(1/4), weak convergence plus absence of a zero atom and Chebyshev show the target exceeds that threshold with probability tending to one. White signs exceed it with probability tending to zero. The bounded threshold effect proves delta->1; a nonvanishing Petz moment alone would not establish this.

For the stronger KL lower, a fixed threshold delta0 sqrt(a) has target probability bounded below by a positive radial-law tail, while white Hoeffding gives probability <=2exp(-delta0^2 a/2). Binary data processing then gives D=Omega(a), not just logarithmic divergence.

The matching upper is valid quantum entropy reasoning. Permutation invariance and strong subadditivity give 2S_k>=S_(k-1)+S_(k+1), hence decreasing entropy increments and S_r/r>=S_N/N. This yields D_r<=(r/N)D_N. The exact Gibbs formula D_N=2E J^2/N-log Z_N and radial moment asymptotics give D_N/sqrt(N)->mu_2/2. The o(1) multiplier is independent of r, so the bound applies uniformly up to r=N. It closes both bounded crossover KL and above-window Theta(a).

## Scientific boundary

This is a useful sharp application of the general concentration principle: the local independence window changes from sublinear size at fixed subcritical variance scale to square-root size at criticality. It is target-versus-white discrimination. It does not establish entanglement, a test sound against every separable alternative, Gibbs preparation cost, or temperature/model acquisition. The effects use r same-copy local readouts and classical pooling; hypothetical global measurements are used only to describe a distribution, not as free protocol access.

Primary model checking independently opened Björnberg–Fröhlich–Ueltschi arXiv1811.12834v2 Eqs2.3-2.4 and2.16-2.17/Theorem2.1; those fix this normalization and beta_c=2 but state a global normalized-spin transform rather than the growing-marginal distance theorem. Popkov–Salerno1112.6352v1 fixes global polarization and is a different ensemble. Their existence does not establish or exclude priority for the present local-window claim. The fresh proof has not been read at this freeze; another exposed audit of the stronger regimes is still pending.
