# The remaining one-pure cubic candidate passes this internal audit

**Verdict: INTERNALLY_AUDITED_PASS.** No counterexample, unpaid remainder, invalid essential-source inference, or missing Foster hypothesis was found. The three requested high-risk interfaces were reconstructed quantitatively. No substantive repair to the frozen candidate is required by this audit.

This is an exposed-argument adversarial audit, not an independent derivation, proof-assistant verification, external review, or literature-priority finding. No comparison opinion was read before the verdict was frozen.

## Exact target and consequence

The input is the full 151-line proof_v1.md in work/agents/cubic_one_pure_blind/, SHA-256

1957335656b2f66bad72a857c94472467c57991a5dfe348b1d6e76e8e20288dd.

It claims nonexplosion from every finite initial state for every finite fully endotactic stochastic mass-action network on two species, source order at most three, with exactly one pure cubic source, arbitrary fixed finite strictly positive reaction constants, and arbitrary finite integral product complexes.

The proof was read in full, all originals were preserved, and the hash was checked again after reconstruction. The source orientation \(3A\) present and \(3B\) absent is sufficient; exchanging species handles the other orientation.

Together with the previously internally audited no-pure and both-pure arguments, this completes the internal written proof for **every fully endotactic two-species network of source order at most three**. That conclusion remains an internally audited research result; formal verification, external expert validation, and novelty/priority are UNKNOWN.

## Three consequential checks

**I. Ellipse–linear–ellipse gluing and the B axis.** Both joins have exactly matching values and gradients. The specific ellipse pieces have Hessian norm at most a finite constant divided by \(a+b\), and gradient continuity allows this bound to be integrated across the joins. Enabled bounded-jump segments remain in the nonnegative orthant and, outside a finite set, have coordinate sum comparable to the starting sum. Thus the global finite-difference bound is valid across the joins and axes.

In the deep B region the actual cubic factorial and Taylor errors are bounded by

\[
C(ab+a^2+a^3/b)\le C'ab.
\]

The pure-cubic correction is \(O(a^2)\), both mixed corrections are \(O(ab)\), and the Taylor bound multiplies the actual rates by \(O(1/(a+b))\). All cubic terms vanish exactly at \(a=0\). The \(2B\) Taylor contribution is \(O(b)\), including arbitrarily large finite A-product jumps; its possible positive first-order contribution is \(O(ab)\). Explicit finite choices of \(K,H\) are provided in RECONSTRUCTION.md.

The remaining bounds are therefore the actual candidate inequalities

\[
\mathcal LW\le-\eta ab^2+C(a+1)b
\quad\text{or}\quad
\mathcal LW\le-\eta a^2b+C(a+1)b.
\]

Both have a global upper bound \(C'b\) in this region. The transition bands and A region have strict cubic dissipation absorbing their quadratic remainders. This closes the global Foster interface, including all disabled reactions and cutoff-crossing jumps.

**IIb. Essential-source hierarchy and extreme entropy ratios.** The exposed-face product lists are exact. When \(R=a^2/b\to\infty\), writing \(L=\log R\), \(Q=\log(b/a)\), and \(m=\min(L,Q)\) gives an exact negative \(21\) budget of order \(a^2bm\). The positive \(02,30,11,20\) drift ratios are bounded by fixed multiples of

\[
e^{-L}L/m,\quad e^{-Q}Q/m,\quad
e^{-L-Q}(L+2Q+1)/m,\quad
e^{-L-2Q}(L+2Q+1)/m.
\]

All vanish without requiring a relative growth rate for \(L,Q\). The opposite regime has similarly explicit vanishing factors after writing \(A=\log a\), \(T=-\log R\), and \(\log b=2A+T\). Keeping negative brackets at their exact propensities avoids a false logarithmic factorial error.

At compact positive \(R\), the aligned top monomial drift is nonpositive even at its balance root, and the actual corrections are \(O(b^{3/2})\). Any strictly negative lower exposed-face projection at \(30\) or \(11\) gives negative \(b^{3/2}\log b\). If those lower tiers are also entirely tangent, essential-source removal really does force every nonlinear \(u\)-projection to be nonpositive, giving the stated linear fallback. Tied linear sources cannot rescue a positive quadratic arrow at the maximum essential score.

**IIc. Critical \(a\asymp b^{2/3}\) corrections.** The top exact first-order correction to the aligned monomial drift is

\[
\{d(3a^2-2a)-eb\}\log(dR/e),\qquad R=a^3/b^2.
\]

On compact positive \(R\), this is \(O(b^{4/3})\). The entropy Taylor remainder is also \(O(b^{4/3})\). Full essential-source endotacticity makes every nontrivial \(11\) arrow strictly negative in \(u=(2,3)\): no integral complex other than \(11\) has weight five. It therefore contributes negative \(ab\log b\asymp-b^{5/3}\log b\), which pays for both fast corrections and the \(b^{4/3}\log b\) positive \(20\) drift. This works at the exact fast balance root.

There is a genuine obstruction to a simpler entropy proof: with only \(3A\rightleftarrows2B\), rates one, and \(a=n^2,b=n^3\), the aligned entropy drift is positive and asymptotic to \(9n^4+4n^3\); its drift divided by entropy grows without bound. The candidate does not rely on that entropy when \(11\) is absent; it uses conserved weight \(2a+3b\). With \(11\) present, the negative \(n^5\log n\) term supplies the necessary additional control.

## Other branches and globality

The remaining cases were also checked, rather than inferred from the three highlighted checks:

* The all-cubic-total-conservative case correctly removes orthogonal cubic sources before testing quadratic total growth.
* A missing \(12\) makes every nontrivial \(02\) arrow strictly decrease B; a small positive tilt of the B direction proves the strictness.
* IIa's entropy domination remains valid even when one coordinate diverges arbitrarily slowly.
* The bounded-coordinate and compact-positive-ratio entropy cases have the stated discrete estimates.
* Both linear-weight perturbation arguments use weighted aggregate source drifts. The required perturbation sign is correct, strict aggregate negativity survives by continuity, and all weights remain positive.
* IId's integer tangent-product classifications and essential-source fallbacks are valid.
* The source cases and extended ratio limits are exhaustive. Each entropy function and shift is chosen once for the network, rather than differently for different asymptotic paths.
* The subsequence argument proves one global finite Foster constant. Finite sublevels have bounded rate and finitely many possible first-exit states, so stopped Dynkin–Gronwall applies to the minimal process without un-stopped moment assumptions.

The detailed quantitative reconstruction, including all exponential ratios and the perturbation cases, is in RECONSTRUCTION.md.

## Evidence and reproducibility

The primary definition and criterion are [Xu, arXiv:2409.05340v2](https://arxiv.org/html/2409.05340v2), already downloaded and hash-pinned during the complementary audit. Copies are saved under sources/:

* HTML SHA-256: 06c9bc5c5c45edabc1dd10f25d1f282ed11a7f3668e89e007452f63e523daf9a.
* Extracted-text SHA-256: a344368bc43ba51cf008127ec68427e345c23ae1b0ac611ecb1bc94b8672c3dc.
* Saved text lines 112–119 give Proposition 3.5; lines 206–218 give Definitions 4.1–4.4. The exact stopping implication was reconstructed directly.

Six integral exposed-face enumerations passed with exact integer arithmetic. The replay code and results are exact_faces.py and exact_faces.json.

The critical replay uses 200-digit Decimal arithmetic at six states \(a=n^2,b=n^3\), up to \(n=10^{30}\). It confirms the positive fast-only entropy drift and the negative full critical-network drift. A test with \(11\)-loss rate \(10^{-12}\) and reverse \(20\)-rate \(10^{12}\) remains eventually negative, illustrating why constants and the finite exceptional region depend on the rates. These are numerical diagnostics, not interval-certified or universal evidence. The universal verdict rests on the reconstructed inequalities.

## Clarifications and limits

No substantive repair is required. Two wording refinements would improve a future exposition:

1. The finite-difference statement applies to the specifically constructed piecewise elliptic W; arbitrary C¹ homogeneous functions need not have Lipschitz gradients. The candidate later proves the needed Hessian property for its own W, so it does not rely on that false general inference.
2. A globally stated flux-error envelope can use \(C(a^2+b)(1+|\log R|)\). The candidate's \(|\log R|\)-only envelope is used in the outer regimes where \(|\log R|\to\infty\), so its actual use is valid.

Originals are unchanged; no descendants or comparison opinions were used. MANIFEST.json pins the source, input, and frozen audit artifacts. SESSION.json records exposure, timing, and the scope of the verdict. Formal replay, external validation, and priority remain UNKNOWN.
