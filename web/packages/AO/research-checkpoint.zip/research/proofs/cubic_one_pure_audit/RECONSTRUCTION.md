# Quantitative reconstruction of the one-pure-source argument

This reconstruction follows a full reading of proof_v1.md, SHA-256 1957335656b2f66bad72a857c94472467c57991a5dfe348b1d6e76e8e20288dd. It is an exposed-argument audit, not an independent discovery. No comparison opinion was read before freezing.

## 1. Source geometry and preliminary discrete bounds

Xu Definition 4.2 forms the essential source set from arrows whose tested projection is nonzero. A positive arrow at a maximum essential source is forbidden even if negative arrows tie it. If every arrow at a higher source score is orthogonal, all those arrows are removed. These are precisely the two rules needed for the candidate's hierarchy.

Every cubic arrow has nonpositive total increment. Thus its product has total degree at most three. Every nontrivial arrow at source \(3A\) strictly decreases \(A\); its \(B\) increment is nonnegative. Without source \(3B\), arrows at \(2B\) and \(A+2B\) have nonpositive \(B\) increments.

If \(A+2B\) is absent, every nontrivial \(2B\) arrow strictly decreases \(B\). To see the strictness quantitatively, take \(u=(\epsilon,1)\) with \(0<\epsilon<1/3\). Source \(2B\) has score two, whereas every other possible source has score strictly below two. A nontrivial \(B\)-conserving arrow from \(2B\) has positive \(A\) increment and hence positive \(u\)-projection, a violation. No rate assumption or aggregate cancellation is involved.

For an entropy summand \(\phi_c(n)=n\log n-n-cn\), and \(n\ge2J\), Taylor's integral formula gives

\[
|\phi_c(n+d)-\phi_c(n)-d(\log n-c)|\le d^2/n.
\]

The constant is independent of \(c\). For both coordinates at least six, every source-order-at-most-three falling factorial is between one half its ordinary monomial and that monomial. These explicit facts justify keeping a negative bracket at its exact rate, and bounding all entropy Taylor errors without a spurious logarithm.

The all-cubic-total-conservative case is valid: cubic arrows are removed in the total direction, so positive quadratic total increments are forbidden. Only order at most one can contribute positive total drift, giving the candidate's linear Foster bound.

## 2. Explicit choices and global finite differences for the ellipse construction

Let
\[
p_{30}=(-\alpha,\beta),\qquad
p_{21}=(u,v),\qquad p_{12}=(\gamma,-\delta),
\]
with \(\alpha>0,\beta\ge0,\delta\ge0\), and let \(r=a/b\). The leading cubic field has
\[
F_B/(ab^2)=-\delta+vr+\beta r^2,\qquad
F_A/(ab^2)=\gamma+ur-\alpha r^2.
\]

If \(\delta>0\), one sufficient finite choice is
\[
K\ge\max\{1,4v_+/\delta,\sqrt{4\beta/\delta}\}.
\]
Then \(F_B\le-(\delta/2)ab^2\) on \(r\le1/K\). Since \(F_A+F_B\le0\), gradients satisfying \(0\le W_A\le W_B\) give
\[
\nabla W\cdot F=W_A(F_A+F_B)+(W_B-W_A)F_B\le0.
\]
In the deep region \(r\le1/(2K)\), the left ellipse has \(W_A/W_B=Kr\le1/2\) and \(W_B\ge1/\sqrt2\). Hence the negative bound is at least a fixed positive multiple of \(ab^2\).

If \(\delta=0\), each \(12\) arrow has zero \(B\) increment and negative \(A\) increment, so \(\gamma=-g<0\). Take
\[
\eta=g/2,\quad M=v_++\beta,\quad
K\ge\max\{1,2u_+/g,(M+2)/\eta\}.
\]
Then \(F_A\le-\eta ab^2\), \(F_B\le M a^2b\), and
\[
\nabla W\cdot F
=W_B(KrF_A+F_B)
\le-W_B(K\eta-M)a^2b\le-\sqrt2\,a^2b
\]
throughout the left ellipse. Increasing \(K\) if desired is harmless.

Similarly, choose
\[
H\ge\max\{1,4u_+/\alpha,\sqrt{4\gamma_+/\alpha}\}.
\]
Then \(F_A\le-(\alpha/2)a^3\) when \(r\ge H\). The right ellipse has \(W_A\ge W_B\), and the total sign gives nonpositive cubic drift. When \(r\ge2H\), \(W_A-W_B\ge W_A/2\) gives a strictly negative multiple of \(a^3\).

The joins are exact. At \(a=b/K\), both the left ellipse and the line have value \(b\sqrt{1+1/K}\) and gradient \((c,c)\). At \(a=Hb\), both the line and the right ellipse have value \(c(H+1)b\) and gradient \((c,c)\). The function is positive, homogeneous of degree one, and comparable to \(a+b\).

For a quadratic norm \(\sqrt{x^\top Mx}\), the Hessian operator norm is at most \(\|M\|/\sqrt{x^\top Mx}\). On the left piece this is at most \(\sqrt2K/(a+b)\); on the right piece it is at most a finite constant times \(H/(a+b)\). The middle Hessian is zero. Because the gradients agree at the joins, integrating along a segment crossing those joins yields the same Lipschitz bound. At \(a+b\ge4J\), every bounded-jump segment has coordinate sum at least \((a+b)/2\). Consequently the exact finite-difference remainder is bounded by \(C_J/(a+b)\), globally across both joins and axes.

On any transition or middle ratio band the strict total loss gives a negative multiple of \((a+b)^3\): the normalized coordinates are bounded away from zero, every lossy cubic monomial is bounded below by a positive multiple of \((a+b)^3\), and the appropriate positive gradient component is bounded below. Falling-factorial and finite-difference errors there, or in the deep \(A\) region, have order at most \((a+b)^2\).

In the deep \(B\) region, the exact cubic errors are bounded by
\[
C\{a^2+ab+(a^3+a^2b+ab^2)/(a+b)\}
\le C'\{ab+a^2+a^3/b\}\le C''ab.
\]
The \(a^2\) term is the pure cubic factorial correction; the \(ab\) terms are the mixed corrections. Every term vanishes when \(a=0\).

The \(2B\) first-order positive drift is at most \(C\,a b\), because \(W_A=O(a/b)\) and \(d_B\le0\). Its finite-difference correction is at most \(Cb\). The \(2A\) and \(A+B\) contributions have upper bound \(C(a^2+ab)\le C'ab\), and lower-order reactions contribute at most \(C(a+b)\).

Thus the two candidate inequalities are actual global upper bounds outside a finite set:
\[
\mathcal LW\le-\eta ab^2+C(a+1)b,\quad\text{or}\quad
\mathcal LW\le-\eta a^2b+C(a+1)b.
\]
In the first, for \(b\ge2C/\eta\), the \(a\)-dependent part is nonpositive, leaving \(Cb\). In the second, \(-\eta a^2+C(a+1)\) has a finite maximum over \(a\ge0\), also leaving a constant times \(b\). The remaining finite states are covered by a finite constant. Hence \(1+W\) satisfies Foster.

For an arbitrary large allowed \(2B\to MA+2B\) jump, at \(a=0\) and sufficiently large \(b\) the exact left-ellipse increment is
\[
\sqrt{b^2+KM^2}-b
=\frac{KM^2}{\sqrt{b^2+KM^2}+b}
\le KM^2/(2b).
\]
Multiplying by \(k\,b(b-1)\) gives at most \(kKM^2b/2\), exactly the needed linear scale. This is the boundary interface that a quadratic untruncated cross term would fail.

## 3. Entropy regimes before the exposed-face subdivisions

If a coordinate remains bounded, the candidate's estimates hold uniformly over its finite range. In particular, with \(a\) bounded and \(b\to\infty\), a present \(2B\) source gives negative \(b^2\log b\); without it every \(b\)-dependent propensity has degree at most one. With \(b\) bounded and \(a\to\infty\), the pure cubic gives negative \(a^3\log a\), against at most \(a^2\log a\).

If \(a/b\) remains in a fixed compact positive interval, a strict cubic total loss gives negative \(N^3\log N\), while conservative cubic brackets are bounded and their rates have order \(N^3\). The other nonlinear terms and entropy remainders are smaller.

If \(a/b\to\infty\), write \(B=\log b\), \(Q=\log(a/b)\). Every \(30\) bracket is at most \(-Q+C\), so the pure source gives negative \(a^3Q\). Positive \(21\) brackets are at most \(CQ+C\), and their relative rate is \(b/a=e^{-Q}\). A quadratic positive envelope \(C a^2\log(a+b)\), divided by \(a^3Q\), is at most a constant times
\[
e^{-B-Q}(B+Q+1)/Q\longrightarrow0.
\]
This remains true when \(B\) grows much faster than \(Q\), since \(Be^{-B}\to0\). The discrete remainder ratios also vanish.

## 4. IIa: quantitative domination with \(21\) present and \(02\) absent

Take \(A=\log a\), \(Q=\log(b/a)\), both tending to infinity, and \(m=\min(A,Q)\). The \(21\) bracket is
\[
(d_A+d_B)A+d_BQ+\text{constant}.
\]
Both coefficients are nonpositive, and at least one is strictly negative for each nontrivial \(21\) arrow. Thus the negative exact \(21\) contribution is at least \(c a^2b m\) in magnitude eventually. The positive \(30\), \(11\), and \(20\) envelopes divided by this budget are bounded respectively by constant multiples of
\[
e^{-Q}Q/m,\qquad e^{-A}A/m,\qquad
e^{-A-Q}(A+Q+1)/m.
\]
Each tends to zero; eventually \(m\ge1\), so ordinary exponential-times-polynomial bounds suffice. The top entropy remainder has relative factor at most \(C(1/a+1/b)/m\to0\). The other remainders are smaller than the same positive envelopes. No slow-growth path for \(a\) escapes these inequalities.

## 5. IIb: top signs, logarithmic extremes, and the lower essential tier

The exposed normal is \(u=(1,2)\), with top sources \(21,02\) at score four. For \(21\), combining total degree at most three and \(u\)-projection at most four gives exactly the seven listed non-self products. At \(02\), \(B'\le1\) and \(A'+2B'\le4\). These lists were exhaustively checked with exact integer arithmetic.

For \(R=a^2/b\to\infty\), let \(L=\log R\), \(Q=\log(b/a)\), and \(m=\min(L,Q)\). Then
\[
\log a=L+Q,\quad\log b=L+2Q.
\]
A \(21\) bracket has coefficients \((d_A+d_B,d_A+2d_B)\) in \((L,Q)\), both nonpositive, with at least one at most minus one. Thus its negative budget is \(c a^2b m\). Every \(02\) bracket is at most \(2L+C\). The positive \(02,30,11,20\) envelopes, relative to the budget, are respectively
\[
e^{-L}L/m,\quad e^{-Q}Q/m,\quad
e^{-L-Q}(L+2Q+1)/m,\quad
e^{-L-2Q}(L+2Q+1)/m,
\]
up to fixed constants. All tend to zero with no restriction on the relative speeds of \(L,Q\). The top \(02\) remainder has relative factor \(e^{-L}(1/a+1/b)/m\), the \(21\) remainder factor \((1/a+1/b)/m\), and the other errors vanish by the same envelopes.

For \(R\to0\), set \(A=\log a\), \(T=-\log R\), both tending to infinity. Then \(\log b=2A+T\). Every \(02\) bracket is
\[
(d_A+2d_B)A+d_BT+\text{constant}\le-T+C,
\]
because \(d_A+2d_B\le0\) and \(d_B\le-1\). Its negative budget is \(c b^2T\). A positive \(21\) bracket is at most \(T+C\). The positive \(21,30,11,20\) envelopes relative to the budget are
\[
e^{-T},\quad
e^{-A-2T}(A+T+1)/T,\quad
e^{-A-T}(2A+T+1)/T,\quad
e^{-2A-2T}(2A+T+1)/T.
\]
They all tend to zero. The \(02\) entropy remainder has relative factor \(C(1/a+1/b)/T\to0\), and the other remainders again vanish.

On \(R\in[r_0,r_1]\subset(0,\infty)\), \((\log a,\log b)=\tfrac12(\log b)(1,2)+O(1)\), uniformly. Any strictly negative top \(u\)-projection gives negative \(b^2\log b\), dominating \(O(b^2)\) tangent brackets and all smaller terms.

If all top projections vanish, the exact tangent products are \(21\to02\), \(02\to21\), and \(02\to4A\). With the stated aligned entropy shift, their monomial contribution is nonpositive:
\[
(e b^2-d a^2b)\log(d a^2/(e b))\le0.
\]
On the compact-\(R\) regime, replacing these two propensities costs at most \(C(ab+b)=O(b^{3/2})\), and entropy Taylor errors have the same order. This remains true arbitrarily close to the balance root, where the leading expression vanishes.

After these top arrows are removed from the essential set, \(30,11\) are the remaining maximal possible score-three sources. Their \(u\)-projections are nonpositive. A strictly negative projection gives negative \(b^{3/2}\log b\), which dominates the \(b^{3/2}\) errors and the \(b\log b\) quadratic drift. If every arrow at both sources is orthogonal, a positive \(20\) arrow would be at a maximum remaining essential score two and is forbidden. A linear source tying score two cannot rescue it. Then every nonlinear \(u\)-drift is nonpositive, giving the candidate's linear Foster fallback.

## 6. IIc: the critical \(a\asymp b^{2/3}\) correction is paid

The exposed normal \(u=(2,3)\) puts \(30,02\) at score six. Negative aggregate drift at both gives the candidate's exact linear inequality: apply a small fraction of the negative \(b_{(2)}\) budget to \(Cab\) by Young, then absorb the remaining \(Ca^2\) by the negative \(a_{(3)}\). On bounded \(a=0,1,2\) or \(b=0,1\), leftover terms have at most linear growth in the other coordinate.

If one aggregate is zero and the other negative, its zero arrows are exactly \(30\to02\) or \(02\to30\). Their \(A\)-increments are respectively negative or positive, so a sufficiently small signed perturbation of the \(A\) weight makes the zero aggregate negative and preserves the already-strict aggregate. All weights remain positive. This uses aggregate drift, since arrows at one source share a propensity; individual perturbed projections need not all be negative.

If both aggregates vanish, the two top transfers are the only possibilities. With no source \(11\), the next score-four source \(20\) cannot have positive \(u\)-increment once the orthogonal top arrows are removed. With \(11\) present, every nontrivial \(11\) arrow has strictly negative \(u\)-increment: its source is maximal in the remaining essential set, and the Diophantine equation \(2i+3j=5\) has only the self complex \((1,1)\).

Use the candidate's aligned entropy. For \(R=a^3/b^2\), the top monomial contribution is nonpositive. When \(R\to\infty\), its negative magnitude is at least \(c a^3L\), \(L=\log R\), eventually. Write \(Q=\log(b/a)\); then
\[
\log a=L+2Q,\quad\log b=L+3Q.
\]
The \(11,20\) positive envelopes relative to this budget are
\[
e^{-L-Q}(L+3Q+1)/L,\qquad
e^{-L-2Q}(L+3Q+1)/L.
\]
The falling-factorial flux errors have relative factors \(O(1/a+b/a^3)\), and the top entropy remainder has relative factor
\[
C(1+e^{-L})(1/a+1/b)/L.
\]
All vanish.

When \(R\to0\), put \(A=\log a\), \(T=-\log R\); then \(\log b=(3A+T)/2\). The negative top budget is \(c b^2T\). The two lower envelopes relative to it are
\[
e^{-(A+T)/2}(3A+T+1)/(2T),\qquad
e^{-A-T}(3A+T+1)/(2T).
\]
Flux-error factors are \(O(a^2/b^2+1/b)\), and the entropy remainder factor is \(C(1+e^{-T})(1/a+1/b)/T\). These also vanish without a relative-speed restriction.

For \(R\) in a fixed compact positive interval, \(a\asymp b^{2/3}\). More precisely the top exact first-order drift differs from the monomial drift by
\[
\{d(3a^2-2a)-eb\}\log(dR/e),
\]
whose absolute value is \(O(b^{4/3})\). The top entropy Taylor error is
\[
O((a^3+b^2)(1/a+1/b))=O(b^{4/3}).
\]
Every strictly negative \(11\) projection has bracket \(\tfrac13(u\cdot d)\log b+O(1)\), so gives negative \(c ab\log b\asymp-c'b^{5/3}\log b\). This dominates both \(b^{4/3}\) fast errors and \(b^{4/3}\log b\) positive \(20\) drift. It also covers the exact fast balance root; no strict fast dissipation is needed there.

There is a real obstacle which the candidate handles: for the top transfers alone, at \(a=n^2,b=n^3,d=e=1\), the aligned entropy drift is positive and asymptotic to \(9n^4+4n^3\). Thus this entropy would fail Foster for the fast-only system, although \(2a+3b\) is exactly conserved. The candidate explicitly chooses the linear fallback when \(11\) is absent. When \(11\) is present, the negative source bracket supplies the missing \(n^5\log n\) dissipation.

## 7. IId and the global Foster conclusion

For \(u=(1,2)\), sources \(30,11\) are tied at score three. Zero arrows are exactly \(30\to11\) and \(11\to30\). If just one aggregate is zero, perturbing the \(A\) weight in the appropriate sign makes both aggregates strictly negative, while preserving positive weights and the already-negative aggregate. The drift \(-c a_{(3)}-c'ab+Ca^2+C(a+b+1)\) has a linear upper bound. If both are zero, the lower \(20\) positive projection is forbidden by the essential-source rule.

Without \(11\), \(u=(1,3)\) makes \(30\) maximal, possibly tied with a linear \(B\) source. Its zero arrows are exactly \(30\to B\), so a small increase of the \(A\) weight makes its aggregate strictly negative. The only quadratic rate is \(a_{(2)}\), which its cubic budget absorbs; all \(B\)-dependent propensities have degree at most one.

The entropy shift is chosen once per network, according to its source/face subclass, never per asymptotic sequence. Add a finite constant so that its entropy function is at least one; it is comparable to \(N\log(N+1)\) outside a finite set. Order-zero and order-one drift is bounded by \(CV\).

If the nonlinear drift divided by \(V\) had unbounded positive supremum, finite-state boundedness would force a sequence escaping all finite sets. Extract either a bounded-coordinate subsequence or one with both coordinates tending to infinity, then extract an extended ratio limit. In the latter case the ratio and critical-scale cases above are exhaustive, and each is bounded or eventually has negative nonlinear drift. This contradicts the unbounded supremum. Thus there is one finite global Foster constant for the chosen function.

For the minimal chain, finite sublevels have bounded total rate, and possible first-exit states are finite because there are finitely many fixed jumps. Stopped Dynkin and Gronwall give \(\Pr(\tau_M\le t)\le V'(X_0)e^{Ct}/M\) for \(V'=1+V\). Infinitely many jumps cannot occur while remaining in a finite sublevel. Sending \(M\) to infinity proves nonexplosion, exactly as in Xu Proposition 3.5.
