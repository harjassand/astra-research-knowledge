# Executable calibration adversarial audit

The frozen calibration layer passes this bounded audit. I found no sample-count, rounding, computed-gap, conditional soundness, completeness, or common-axis counterexample. The two supplied SHA256 hashes match. The unknown-gap variant retains a target-side high-probability resource guarantee; it supplies neither a universal deterministic copy cap nor guaranteed termination on every null.

This verdict was reached from the four assigned source files, with no integration comments read. It is an internal mathematical audit, not formal replay, external validation, or novelty clearance. The core upper theorem is treated as the previously audited interface; only its concentration and anchor-dependent constants needed by calibration were checked here.

## Exact fixed-floor contract

The finite executable protocol requires `N>=4`, integer `2<=r<=N/2`, rational `0<epsilon<=1`, rational `0<g_min<=1`, fresh iid copies of the same input state, independent exact uniform subsets, and the same ideal common orthonormal axes in both stages. On the target, the exact Schur weights and arbitrary sector states give `N|b|^2<=3` and the stated unit-axis tails. Under the null, no Schur or calibration-accuracy premise is used.

With `zeta=alpha=eta/2`, the declared counts are

`K=ceil[41472 N/(r epsilon) L_cal]`, `L_cal=ceil log2(6/zeta)`,

`m=ceil[24e9/(q' gamma)^2 L_ver]`, `L_ver=ceil log2(1/alpha)`.

Calibration really costs **3K copies and 3Kr local readouts**, not K copies. Verification costs m copies and mr local readouts. If the gate fails, no verification batch is acquired. If it opens, `gamma>=g_min`, so the claimed deterministic copy cap (C6) follows by monotonicity of the ceiling.

For literal finite execution, represent `eta` by a positive rational or supply a certified positive rational value below it. Integer upper logarithms can then be found by the exact comparison `2^L>=6/zeta` or `2^L>=1/alpha`, without logarithm evaluation. This is an operational input-format clarification, not a change to the mathematical confidence bound.

## Reconstructed checks

1. **Calibration concentration.** Integrating `8exp(-z^2/16)` gives `Eexp(Y^2/144)<=2`. Jensen against an independent copy and Cauchy give `Eexp[(Y-EY)^2/576]<=2`. The source's centered MGF proof yields `Eexp(lambda V)<=exp(864lambda^2)`. Chernoff for the K-copy mean therefore has denominator 3456. Using `h^2=epsilon/(12N)` gives the denominator 41472 in K. The three-coordinate union bound is `6exp(-L_cal)<=zeta`, because the base-two upper logarithm exceeds the natural logarithm. No variance-independence assumption within one N-qubit copy is made.
2. **Projection and downward rounding.** The true target b lies in the ball `R^2=3/N`. Euclidean projection onto that ball is nonexpansive relative to b. Rounding each coordinate magnitude downward gives `|v|<=R` for every possible datum and rounding error at most `sqrt(3)2^-p<=0.5sqrt(epsilon/N)`. Together with the raw-mean bound this proves (C2). Outside the ball, the squared rational inequality in the source is exactly equivalent to the nonnegative coordinate-floor comparison. Equality at a grid boundary is handled by the inclusive lower comparison; there is no square-root or sign ambiguity.
3. **Positive-gap computation.** Upward rounding `2sqrt(3epsilon)` gives a conservative rational u, and `gamma=N|v|^2-1-u` is exact. On calibration accuracy, `delta_eff=delta-N|v-b|^2>=gamma`. Independently, `gamma>=delta-(4sqrt(3)+1)sqrt(epsilon)>=delta-8sqrt(epsilon)`. Thus (C5) opens the gate and supplies the verification signal. Every anchor, including bad calibration outcomes, has `gamma<=2` and hence `0<q'gamma<1` whenever the gate opens.
4. **Arbitrary-calibration null soundness.** Conditional on the entire calibration history, v and the verification horizon are frozen. Clipping alone is sufficient for the previously audited null MGF, including nonidentical product factors and their fully separable mixtures. Fresh iid verification copies preserve that conditional null model. The false-certification bound is at most alpha for every preliminary outcome, and averaging therefore gives unconditional soundness. Calibration failure probability is not added to null error. On the target it is added to verification error, producing `zeta+alpha=eta`.
5. **Completeness after changing the anchor.** On the target, for every clipped v, `ET_v=q'[1+N|v|^2-2N v dot b]` has absolute value at most five. The pointwise bound `|T_v|<=6(X/sqrt(r))^2+10` and unit-axis target tail remain valid. Consequently the same centered exponential-moment and completeness exponent apply. The declared 24e9 coefficient dominates both the soundness coefficient 24e9 and the completeness coefficient 256e6; the base-two upper logarithm cannot reduce either count.
6. **Rational streaming score.** Multiplying the score by `D=N(N-1)r^2 2^(2p)` gives exactly numerator (C15). The displayed three terms and powers of r,N,2^p are correct. Summing those integers and clearing the threshold denominator is an exact implementation; it needs neither exponentials nor irrational coordinates. Its accumulator bit bound follows from `|X|<=r`, `N|v|^2<=3`, and the displayed polynomial numerator.

## Common orthonormal and slightly nonorthogonal frames

An unknown common orthonormal frame needs no absolute-orientation calibration: all identities use the same three coordinate labels, norm preservation, and `J^2`. This does not require rotational invariance of the target state.

For fixed unit directions `n_A` with a deterministic certified rational upper bound `||G-I||<=e<=1/10`, the slightly nonorthogonal extension also passes. The same directions must apply across all selected qubits and in both stages. The measured coordinates are `b_*`, the projection ball is `3(1+e)/N`, and the score correction **must be included**: `T_v^(e)=T_v+q'e`. The corrected null mean is exactly `q'[1+e-Q_*+N|a_*-v|^2]>=0`. For integer streaming, one may retain (C15) and shift the rejection threshold by `-mq'e`; this is equivalent to accumulating the corrected score. Reusing the unshifted orthonormal score would implement a different protocol.

The core null constants survive because `a_A^2<=1.65`, `K0=-3+d/r+q'e` lies in `[-3,-0.8]`, and the completed-square constant lies in `[-7.95,-0.8]`. The sampling lemma uses only that every actual direction is unit, while the large-field argument uses coordinate components and does not require orthogonality. On the target, the real symmetric spin matrix B is PSD with trace 3N, so `|d_G|<=3e`. The gap calculation gives

`Delta>=N|v|^2-1-2sqrt(3(1+e)epsilon)-4e>=gamma_e`,

and `gamma_e>=delta-7e-9sqrt(epsilon)`. The source's (C23) and its explicit choice using delta0 are therefore sufficient. The review note correctly restores the centered target moment bound for every clipped anchor, including calibration failure. Capping a gate at one preserves its floor and its target lower bound.

The metrological certificate is a **supplied physical premise with separately uncharged acquisition cost**. The theorem does not itself learn it from state calibration data. Drift, qubit-dependent axes, stochastic outcome errors and detector bias are excluded; their absence must be part of the physical measurement model. Store the finite representation of e and clear its denominator in the corrected threshold.

## Unknown-gap staging

The staged variant uses fresh groups at every stage, stops at the first positive declared floor, and runs exactly one final verification batch. Its calibration confidence sum is `eta*pi^2/24<eta/2`. For every finite target gap `0<delta<=2`, at `k0=max(4,ceil log2(16/delta))` the simultaneous confidence event guarantees an open gate; at any earlier stopping stage the floor is at least `delta/4`.

I checked both edge cases caused by the lower cutoff k=4 and the ceiling in k0. They give `8*2^-k0>=delta/4` and `4^k0<=1024/delta^2`. Summing the actual ceilings `3K_k` gives precisely

`169869312 N/(r delta^2) L0+3(k0-3)`.

The verification coefficient is `24e9*16=384e9`. Hence with probability at least `1-eta/2` on the target, its entire copy use is bounded by the declared gap-dependent calibration and verification quantities, and overall detection is at least `1-eta`. This is a probability bound, not an expectation bound or a deterministic cap outside that event.

For an iid separable null, disjoint finite calibration-stopping events each have conditional final-verification false-certification probability at most eta/2. Summing their probabilities proves soundness. A never-stopping calibration path never certifies, but need not return a final decision. No resource or null-termination guarantee is silently inserted. Adding a predetermined stage cutoff would change the completeness interface as the source states.

## Physical and computational accounting

Only r distinct qubits are read per consumed copy; the virtual all-axis-sign population in the tail proof is an analytical coupling, not an extra physical readout. Verification retains the multioutcome local score; a binary coin implementing the bounded effect alone is not the claimed rate. Calibration and verification copies must be independent and identically prepared for the two-error theorem. The null-only sequential extension is valid under the stronger conditional-separability premise stated in the source, with anchor and horizon frozen before verification. Unconditional single-copy separability in a cross-copy quantum state does not imply that premise.

The exact uniform subset sampler assumes fresh unbiased randomness. A scan uses N Bernoulli sampling decisions, but exact sampling from a denominator not a power of two can require rejection or an unbounded bit stream. Thus the source's `O(N)` random/comparison steps are abstract sampling decisions, not a deterministic worst-case random-bit or wall-clock bound. A conventional exact integer/rejection implementation gives finite expected random-bit cost, for example `O(N log N)` for the direct scan. This does not affect its deterministic state-copy/readout cap or stated storage bounds.

## Diagnostics and verdict freeze

An independently written exact-rational diagnostic passed 8,232 projected/downward-rounded anchors, 469,224 integer-score equalities, 24 unknown-gap resource cases, and nine nonorthogonal product-null mean cases. It includes clipping outside the ball, zeros, signs, grid equalities, corrected thresholds and rational unit axes with a certified Gram error. These finite checks are scoped diagnostics, not a proof substitute.

Verdict: **passes internally reviewed calibration interface**, with the execution clarifications above. There is no mathematical repair request. Preserve `freeze_v1.json` before exposing this verdict to integration comments. Prior art, formal validation, external validation and experimental metrology remain separate.
