# Raw acquisition of a conditioned predictive bank: exact parity interface

**Status:** self-contained derivation by this worker, with finite exact identity checks. Not independently reviewed, formally verified, externally validated, or established as historically new. The underlying Fourier, channel-capacity, noisy-parity, and maximum-likelihood mechanisms are classical. This note sharpens the supplied/acquired feature interface; it does not solve general HMM learning.

## 1. A supplied prefix basis, an acquired suffix bank

Fix a length L >= 1 and an unknown secret s in {0,1}^L. Let X be uniform on {0,1}^L, U be an independent fair bit, E an independent Bernoulli(eta) bit, and

    W = U XOR (s dot X) XOR E,    lambda = 1-2 eta in (0,1].

The observed reset block is (U,X_1,...,X_L,W), of length L+2. No conditional, membership, matrix-response, teacher, or state oracle is supplied. A raw noisy-parity sample (X,Y) produces this block by choosing an independent U and setting W=U XOR Y; conversely Y=U XOR W. Thus this augmentation neither adds nor removes target information.

An ordinary binary-emission homogeneous HMM realizes independent blocks with 4L+4 states: two leading states emitting U; states (i,a,z), 1<=i<=L and a,z in {0,1}, emitting z; and two label states. Leaving the leading state U initializes a=U and selects the first X bit fairly. Leaving (i,a,z) replaces a by a XOR s_i z and selects the next X bit fairly, except at i=L where it emits the noisy accumulated parity through the label state. Label states restart the leading state fairly. The fixed-time conditional future depends on a prefix only through the accumulated parity and the known clock, so its rank is at most two. At the cut after U, rank is exactly two for lambda>0. This is a finite-horizon cut-rank assertion, not a two-state homogeneous realization of the infinite clocked process.

The learner is even supplied the correct prefix basis

    f(U) = (1, (-1)^U).

It must acquire M suffix evaluators

    g_j : {0,1}^L x {0,1} -> [-1,1],  j=1,...,M,

from raw blocks, and obtain a true population singular-value margin

    sigma_2(H_s) >= kappa,    H_s = E_s[f(U) g(X,W)^T].       (1)

All unknown-target-dependent code, constants, random seeds, and retained data used by the evaluators are charged as stored output. For the computational reduction, each evaluator must be runnable on arbitrary supplied suffix inputs to a specified precision, with its time and bit costs charged. This is execution of the acquired program, not an oracle query to the unknown process.

The suffix marginal (X,W) is uniform for every s. Define

    mu_j = E_uniform g_j(X,W),
    h_j(x) = (g_j(x,0)-g_j(x,1))/2,
    beta_j(s) = E_uniform h_j(X) (-1)^(s dot X).

Direct averaging over U and E gives the exact matrix identity

    H_s = [ mu^T ; lambda beta(s)^T ].                        (2)

The ideal acquired bank g=(1,(-1)^W (-1)^(s dot X)) gives H_s=diag(1,lambda). Thus a two-feature bank with a constant population margin exists for every constant noise rate eta<1/2; what is missing is acquisition of the mask.

## 2. Sharp bank coverage, then stored-bit and sample debt

**Theorem 1 (coverage).** A fixed bank of M bounded suffix functions can satisfy (1) for at most

    floor[ lambda^2 (M-kappa^2) / kappa^2 ]                  (3)

secrets, provided it works for at least one secret. At the natural target kappa=lambda this bound becomes exactly M-1, capped by 2^L. The bound M-1 is attainable.

**Proof.** Write a_j(x)=(g_j(x,0)+g_j(x,1))/2. Orthogonality in W gives

    E g_j^2 = E a_j^2 + E h_j^2 <= 1,
    mu_j^2 <= E a_j^2.

Parseval for h_j, summed over j, therefore gives

    sum_s ||beta(s)||_2^2 = sum_j E h_j^2 <= M-||mu||_2^2.    (4)

If sigma_2(H_s)>=kappa, the 2x2 Gram matrix H_s H_s^T is at least kappa^2 I. Its diagonal entries imply

    ||mu||_2^2 >= kappa^2,
    lambda^2 ||beta(s)||_2^2 >= kappa^2.                       (5)

The first condition is common to every secret. If q secrets are covered, (4)-(5) yield q kappa^2/lambda^2 <= M-kappa^2, proving (3). At kappa=lambda, q<=M-lambda^2<M, so q<=M-1. For any selected M-1 distinct secrets, use a constant feature and one signed-label parity feature for each selected secret. For each selected secret, the rows of H are a unit constant-coordinate row and a lambda multiple of a distinct unit coordinate. Hence sigma_2(H)=lambda. This attains M-1 whenever M-1<=2^L. QED.

This is stronger than a mere fixed-dictionary obstruction: the next two statements allow arbitrary raw-sample processing, internal randomization, adaptation, and retention. The loss comes from the number of secrets the *output bank* can serve.

Let K be any common integer bound on the number of covered secrets, with 1<=K<=2^L; use K=min(2^L,M-1) at kappa=lambda. Suppose the learner succeeds with probability at least 1-delta for every s, where 0<delta<=1/2.

**Theorem 2 (stored output).** If, after fixing its independent public coins, the output has at most 2^B possible encoded banks, then

    B >= L - log_2 K + log_2(1-delta).                        (6)

**Proof.** Fix the coins. The union of the sets covered by all possible output banks has at most 2^B K secrets. A uniform secret can succeed only if it belongs to this union, irrespective of the data-dependent output rule. Averaging over the independent coins gives success probability at most 2^B K/2^L. Uniform success implies (6). QED.

For M=2 and kappa=lambda, this says B>=L+log_2(1-delta). Two predictive coordinates do not mean that their acquired evaluators can be specified with two stored bits. The ordinary direct mask baseline stores L bits and matches this bound to a constant.

**Theorem 3 (raw sample information).** For a fixed N reset blocks,

    N C(lambda) >= (1-delta)(L-log_2 K)-h_2(delta),            (7)
    C(lambda) = 1-h_2((1-lambda)/2).

The same bound holds with N replaced by E T for an adaptive stopping time T with finite expectation, if all observations are charged.

**Proof for fixed N.** Draw S uniformly from 2^L secrets, independently of the learner's coins R. Let D be the encoded bank and A(D) its covered-secret set. The event S in A(D) has probability at least 1-delta. Splitting conditional entropy by this event, with |A(D)|<=K, yields the elementary list-Fano inequality

    H(S|D,R) <= h_2(delta)+(1-delta)log_2 K+delta L.

Thus I(S;D,R)>=(1-delta)(L-log_2 K)-h_2(delta). Data processing bounds this by I(S;X^N,Y^N), where Y=U XOR W. Since X^N is independent of S and the independent label noise has entropy N h_2(eta),

    I(S;X^N,Y^N)
      = H(Y^N|X^N)-H(Y^N|S,X^N)
      <= N-N h_2(eta) = N C(lambda).

This proves (7). For adaptive stopping, expose one block at a time, and pad the transcript with a stop symbol after T. Conditional on the previous transcript and independent coins, the decision to continue conveys no additional secret information. A newly acquired X is uniform and independent; its noisy label is one use of a binary symmetric channel, whose conditional information is at most C(lambda) regardless of the posterior on S. Chain-rule summation gives I(S;transcript,R)<=C(lambda) sum_i Pr(T>=i)=C(lambda) E T. Finite truncations and the finite alphabet of S justify the limit. Apply the same list entropy bound. QED.

For polynomial M, inverse-polynomial kappa/lambda, and delta bounded away from one, the lower bound is Omega(L/C(lambda)). As lambda tends to zero, C(lambda)=lambda^2/(2 ln 2)+O(lambda^4), so the sample debt is Omega(L/lambda^2). The L+2 observed bits per block are charged separately: the physical observed-symbol count is (L+2)N. This is not an exponential raw-sample lower bound.

## 3. Any efficient acquired bank permits noisy-parity recovery

**Theorem 4 (computational reduction).** Suppose a bank satisfies (1) and has efficiently executable bounded evaluators. Then one can recover s with high probability using polynomial work in L, M, lambda/kappa and evaluator cost, plus O(lambda^-2 log(M lambda^2/(kappa^2 delta))) independent validation blocks. Therefore polynomial raw acquisition of such a bank with an inverse-polynomial margin solves LPN. This implication is unconditional; the consequent lower bound on acquisition time is conditional on the LPN assumption.

**Proof.** Equation (5) implies that some j satisfies

    |beta_j(s)| >= gamma = kappa/(lambda sqrt M).             (8)

Each h_j is a bounded efficiently evaluable real function. Recover all its Fourier coefficients of magnitude at least gamma using the following classical Kushilevitz-Mansour search; it does not query the unknown target.

For a k-bit coefficient prefix a, define

    E_k(a) = sum_b hat(h)(a,b)^2
           = E_{u,u',v} h(u,v) h(u',v) chi_a(u XOR u'),         (9)

where u,u' are independent uniform k-bit inputs and v is a common uniform (L-k)-bit suffix. The equality follows by Fourier orthogonality, or by squaring E_u h(u,v) chi_a(u) and averaging over v. The summand lies in [-1,1]. Thus O(gamma^-4 log(L/(gamma delta))) independent products estimate each queried energy to absolute error gamma^2/4.

Traverse the binary coefficient-prefix tree, keeping a node if its estimate is at least 3 gamma^2/4. Every coefficient with magnitude at least gamma survives, because all its ancestor energies are at least gamma^2. On the simultaneous estimation event, every retained node has true energy at least gamma^2/2. Parseval bounds the number retained at each level by 2/gamma^2, so at most O(L/gamma^2) energy estimates are made. Cap the retained width and return UNKNOWN if this cap is breached; this makes the resource budget finite even off the good event. Union bounds for adaptively chosen estimates use fresh internal random inputs at each call. The conservative total number of h evaluations is

    O(L gamma^-6 log(L/(gamma delta))),                      (10)

with polynomial bit overhead. Each h evaluation calls g at two label values. If g is approximate, uniform evaluation error O(gamma^2) makes the product bias O(gamma^2); reducing the sampling allowance by a fixed constant preserves the same argument. The required output precision is O(log(1/gamma)) fractional bits, not an uncharged exact real oracle. The exponent in (10) is a safe elementary bound, not an optimal KM implementation claim.

Run this search on every h_j. It returns at most 2M/gamma^2 candidates and includes s with high probability. On fresh raw data, estimate each candidate's signed-label correlation E[(-1)^Y chi_r(X)]. It is lambda for r=s and zero otherwise. Hoeffding with a union bound, using O(lambda^-2 log(M/(gamma^2 delta))) blocks, identifies s by the largest correlation. These observations, their lengths, candidate evaluations, precision, and storage are all paid. QED.

The important interface detail is that the correct prefix basis was supplied. Acquiring only a bounded suffix bank with one-cut conditioning is already sufficient for this reduction; a full predictive recurrence cannot be easier if it promises this bank as an output. An output that is only an oracle on already observed suffixes, a non-executable existence statement, an unbounded normalization, or a purported sampler without evaluable feature functions is outside this theorem and needs its own bridge.

The bank problem is computationally equivalent up to polynomial overhead to ordinary noisy-parity learning on this supplied family: recovery of s immediately gives the bank diag(1,lambda), and the reverse direction was just proved. Hence a separation from a competent retaining learner on the same data is not established.

## 4. Statistical positive counterpart: acquire and certify an unknown margin

An exponential-computation learner can acquire a true bank from raw noisy blocks without being supplied lambda or a singular-value margin, under the *supplied family promise* eta<1/2. This removes conditioning as a statistical oracle but does not remove its computational hardness.

At stage t>=1 retain N_t=2^t blocks. For every r in {0,1}^L compute the empirical integer-based correlation

    c_t(r)=N_t^-1 sum_i (-1)^(Y_i) chi_r(X_i).

Set delta_t=delta/[t(t+1)], and

    r_t = sqrt[2 ln(2^(L+1)/delta_t)/N_t].

Use a computable dyadic upper enclosure R_t of r_t with r_t<=R_t<=2r_t. If max_r c_t(r)>=4R_t, output its maximizing mask, the bank (1,(-1)^W chi_r(X)), and the certified lower margin c_t(r)-R_t; otherwise double the sample size. A finite external budget may return UNKNOWN at its cutoff.

For each t, Hoeffding and a union bound over all 2^L masks imply simultaneous correlation errors <=r_t with failure probability <=delta_t. Summing these probabilities bounds the total failure by delta. On that event all false masks have c_t(r)<=R_t. A stopping mask, with c_t(r)>=4R_t, is therefore the true mask. Its true Hankel matrix is diag(1,lambda), and

    lambda >= kappa_cert = c_t(s)-R_t >= lambda/3 > 0.

For the last inequality, stopping gives lambda>=3R_t, while c_t(s)>=lambda-R_t. Stopping occurs once R_t<=lambda/5, since then c_t(s)>=lambda-R_t>=4R_t. Consequently with probability at least 1-delta the acquired bank and margin use

    N = O(lambda^-2 [L+ln(1/delta)+ln ln(e/lambda)])           (11)

blocks. This follows by substituting t=O(log(L+ln(1/delta))+log(1/lambda)) into the displayed radius; the extra log(L) term is absorbed by L. Almost-sure termination follows from the law of large numbers on this finite class. After the radius is at most lambda/8, the probability of not stopping at size N is at most exp(-N lambda^2/8), by testing the true mask alone. Summing over the doubling sizes gives the same order for E N. Equations (7) and (11) match in their leading statistical order for a constant-size bank.

A direct implementation that scans all masks has O(2^L N L) bit work, O(NL) retained bits during acquisition, and stores L mask bits plus the finite certificate after acquisition. It does not need floating maximum likelihood: correlation maximization is integer Hamming-loss minimization. Bounds for the logarithm and square root used in R_t cost polynomial work at O(log N+log L+log(1/delta_t)) precision. Deployment stores the mask, clock, and parity bit and uses O(1) XOR work per symbol. Prediction probabilities need a noise estimate if eta was unknown; the margin certificate alone is not an exact known-noise probability model. An empirical confidence interval estimates lambda to a requested accuracy with its usual additional sample/precision cost.

`acquire_noisy_bank.py` implements this algorithm with a finite external budget and exact rational certificates. It uses the conservative integer upper bound K_t=L+1+ceil(log_2[t(t+1)/delta]) for the logarithm and chooses a dyadic R_t between sqrt(2K_t/N_t) and twice that value; the same proof and resource order apply. It accepts only a raw-block generator, L, delta and a cutoff, not the noise or mask.

The equally informed retaining baseline performs precisely the same empirical noisy-parity search and can export the same mask and certificate. This is a positive theorem for acquisition and certification, not an advantage over that baseline.

## 5. An efficient genuinely noisy regime, with its limited scope

The noiseless N189 escape extends to rare classification noise by ordinary consensus sampling. Suppose a supplied noise bound eta<=c ln L/L is available, with fixed c and L sufficiently large that eta<=1/4. The family is still noisy; it is not an arbitrary HMM promise.

Generate R independent batches of b=L+2 raw blocks. In each batch, Gaussian elimination of Xr=Y returns a mask only if the design is full rank and consistent, otherwise UNKNOWN. A clean batch is correct; it has full rank with probability at least 3/4 independently of its label noise. For eta<=1/2,

    p_correct >= (3/4)(1-eta)^(L+2)
              >= (3/4) exp[-2eta(L+2)]
              >= (3/4) L^(-4c),   L>=2.

Thus R=ceil[(4/3)L^(4c) ln(2/delta)] makes omission of the true mask at most delta/2. Some contaminated consistent batches can produce false masks; they are kept as candidates, not certified. A fresh validation sample of O(log(R/delta)) blocks separates the true correlation lambda>=1/2 from all false zero correlations with failure at most delta/2. After selection the exact population bank is diag(1,lambda). A further one-dimensional confidence interval can supply a data-derived margin.

The paid cost is O(RL+log(R/delta)) raw blocks, O(RL^3+RL log(R/delta)) straightforward bit work, and O(R[L+log log(R/delta)]+L^2) bits if batches are processed sequentially and candidate masks retained (including validation counters). At eta<=c/L, R can be O(exp(4c) log(1/delta)), yielding O(L log(1/delta)) acquisition blocks for fixed c. This is a RANSAC-type transfer, not a new noisy-parity algorithm. It gives a concrete polynomial regime beyond lambda=1; fixed eta>0 still makes the clean-batch route exponential.

## 6. What was and was not advanced

The sharp M-1 coverage lemma and its exact acquisition/description tradeoffs are a derived scoped result. The primary literature already establishes noisy-parity hardness for HMMs and probabilistic automata, and Fourier-heavy-coefficient recovery is classical. No novelty claim, general efficient noisy-HMM acquisition theorem, or consequence for KLS is made.

The specific unresolved frontier is an efficient positive acquisition theorem outside classical easy subclasses that permits raw reset access, removes supplied conditioning, returns an executable bounded feature bank with a valid population certificate, and accounts for an equally informed retaining baseline. A general theorem covering the family in Section 1 would solve LPN. This is the decisive computational obligation, rather than an additional moment-dictionary calculation.
