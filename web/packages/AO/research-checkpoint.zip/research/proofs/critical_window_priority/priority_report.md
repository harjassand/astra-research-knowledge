# Focused prior-art check: critical marginals of the isotropic mean-field Heisenberg Gibbs state

**As of:** 2026-10-08 (UTC)  
**Scope:** primary-source check only; no audit of the candidate marginal proof.  
**Status:** read; external priority and correctness are not established.

## Result

The exact target model is already explicit in the primary literature, but the sources opened here do not state the proposed growing-subsystem testing window. For $S_i=\sigma_i/2$, $J=\sum_i S_i$, and the full tensor-space trace, Björnberg–Fröhlich–Ueltschi use

$$
H_n=-\frac{2}{n}\sum_{i<j}S_i\cdot S_j=-\frac{J^2}{n}+\frac34 I.
$$

Thus their zero-field Gibbs state is exactly $Z^{-1}e^{\beta J^2/n}$, including the target at $\beta=2$. This identity is reconstructed directly from their Eq. (2.3) and the spin-$\frac12$ Casimir; their Eq. (2.4) specifies the full trace. Their Theorem 2.1 is a global magnetization Laplace-transform limit. It does not assert a trace-distance, relative-entropy, or Petz-$\chi^2$ threshold for an $r_N$-site partial trace.

The closest exact marginal result found is Popkov–Salerno’s block-diagonal RDM spectrum for a permutationally invariant Heisenberg state at **fixed total $S_z$**, including a thermal average over spin/Young sectors at that fixed polarization. It gives exact finite-size RDM eigenvalue formulas and a quoted entropy-density scaling, but its ensemble is not the full zero-field Gibbs trace over all magnetizations. Even its critical entropy formula at half polarization only reports the leading $r\log 2$ term; it does not imply an $o(1)$ entropy deficit, trace convergence, or a square-root testing window.

The recent Basso et al. Davies-gap source is also relevant to the static model’s sector law, but its Hamiltonian normalization must be handled carefully. Eq. (1.1) with the paper’s explicit $S_i^2=3I/4$ convention gives $H=3I/8-J^2/(2n)$ (Appendix A, Eq. (A.17)); its later Eq. (2.8) and Eq. (D.8) use the doubled spectrum $-s(s+1)/n$. The authors call this “up to a shift and rescaling.” Consequently, the stated $\beta=2$ in its gap theorem cannot be transferred to the target using Eq. (1.1) without tracking that factor. The full-Hilbert sector weight in Eq. (D.8) correctly uses $\dim\Pi_s=(2s+1)[\binom n{n/2-s}-\binom n{n/2-s-1}]$, not a lone binomial.

## Source-level mechanisms and remaining bridge

1. **Full-trace spin-sector/Laplace reduction (source-reported).** In arXiv:1811.12834v2, Theorem 2.1 and its Section 4 proof express the magnetization observable as a ratio of sums over total spin $J$. The multiplicity is $L_{J,n}-L_{J+1,n}$; Proposition 4.1 derives its asymptotic by a generating function and saddle point, then the proof applies an exponential-sum Laplace lemma. Assumptions: complete graph, isotropic Heisenberg interaction, fixed spin $S$, canonical full-trace Gibbs state, fixed $\beta$ and $h\in\mathbb C$. At spin $1/2$, the source identifies $\beta_c=2$. This handles a global order parameter only; the missing bridge is the spectrum or distance of $\operatorname{Tr}_{N-r}\rho_N$ for $r\to\infty$, uniformly through $r\asymp\sqrt N$.

2. **Exact fixed-polarization RDM eigenspaces (source-reported).** In arXiv:1112.6352v1, Eqs. (8), (17)–(18), and (26)–(27) reduce an $r$-site RDM to $S_r$-irreducible blocks and give eigenvalues as finite linear combinations of combinatorial block entries. Eqs. (36)–(40) thermally average those RDMs over permutation/Young sectors and state the block-entropy scaling. Assumptions: complete graph/permutation invariance, fixed $S_z=L/2-N$ and corresponding sector labels; the thermal formula sums the symmetry sectors at this fixed polarization. The full-Gibbs bridge must also sum over $N$ with the full-trace weights. The entropy formula is only a leading scaling statement and cannot supply the candidate $o(1)$ distinguishability result by itself.

## Repository boundary

The pinned knowledge repository is clean at 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce. Its current thermal gate is G-THERMAL-SQRT-WINDOW, still open. N179/N180 concern the stationary state from a specified collective bath and separable approximation/lower bound, not the static Gibbs marginal in this check; their status is source_derived_unreviewed, with external correctness and priority unverified. LA020-tracial-L2-thermal-lift is an authored candidate lemma for a different collective Gibbs component and a full-state trace approximation, not a growing marginal theorem for the present target. Repository status is routing evidence only.

## Search coverage and limits

Opened the original arXiv HTML and version-history pages for arXiv:2607.21798, 1811.12834, and 1112.6352; checked the theorem/proof spans listed in source_manifest.json. The current arXiv record for 2607.21798 lists v1 only (submitted 2026-07-23); the other records show 1811.12834v2 (last revised 2019-11-20) and 1112.6352v1 (submitted 2011-12-29). Targeted searches covered “mean-field Heisenberg / Curie–Weiss,” reduced density matrices, thermal subsystem entropy, and growing-subsystem distinguishability. This bounded search found no exact source theorem for the proposed $r\sim\sqrt N$ local testing window, but **does not establish novelty or priority**. No author contact, formal proof, numerical experiment, or independent validation was performed.
