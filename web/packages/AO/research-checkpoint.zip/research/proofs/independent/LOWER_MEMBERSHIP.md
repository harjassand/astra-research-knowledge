# Lower-construction membership and conditional optimality

The upper proof was frozen before this membership check.

## Geometry interface

The N175 common-metric candidate has exactly the upper theorem's end premises, AS WRITTEN in its pinned source. This checks the interface; it does not validate construction of the metric or harmonic functions.

- PROOF_v3.txt lines132-149: all controlled link images have a C-infinity compact closure; every fixed spatial order q has ||H_t||_Cq <= B_q t^-3/4. Hence the C0 derivative tends to zero.
- PROOF_v3.txt lines174-186: the radial factor satisfies a<=f'<=1 and f/r->a; the metric is dr^2+f^2H(log r), smooth complete on R^3 and Euclidean near zero; pointwise angular area is fixed.
- The current original family361 PDF, pinned by release_mechanisms to upstream fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb, p6 equation(2.4), gives dvol_h(w)=dvol_g0=4pi*dmu, where dmu is the normalized round measure. I rendered and inspected pages6-7 rather than infer the gauge from a summary.
- The source transversality report lines98-118 reconstructs the gauge: rho has mean one; rho_tau=1+tau(rho-1); Delta_0 phi=-(rho-1); X_tau=rho_tau^-1 grad(phi). Since div(rho_tau X_tau)=-partial_tau rho_tau, the flow obeys partial_tau Phi_tau^*(rho_tau mu)=0. Thus Phi_1^*(rho mu)=mu exactly. Area preservation is pointwise.
- The compactness and derivative conditions persist for every control in the countable fixed point by the explicit source envelopes. This is a reading of its quantifiers, not a new validation of the countable fixed-point/PDE construction.

## Exact conditional consequence

For fixed v in (4/9,1), let C_v be the class of metrics satisfying the upper premises with a^2=v, Ric>=0, smooth complete on R^3 and Euclidean near zero.

The upper proof gives
    sup_{g in C_v} limsup_{integer k->infinity} h_k(g)/k^2 <= 9v/4.

N175 CLAIMS that for each 1<c<9v/4 there is a g in this class with limsup h_k/(k+1)^2 > c. Since k^2 and (k+1)^2 have the same asymptotic ratio, IF that lower candidate is correct, it gives
    sup_{g in C_v} limsup h_k(g)/k^2 = 9v/4.

No metric attaining the endpoint is inferred. The metrics supplied for successively closer c can differ. No all-degree lower bound or full dimension limit is inferred.

The original release family361 gives metrics depending on k, not a fixed-manifold limsup statement. Its p2 explicitly disclaims an optimality/endpoint assertion. Consequently the original release alone is insufficient for this sharp fixed-manifold class supremum.

## What remains

N175's current POST_SOURCE_STATUS labels its spectral and analytic audits internally discharged, but retains UNKNOWN for external correctness and historical priority. The older pending-source paragraphs in PROOF_v3 are a preserved freeze, not current absence of reports. Neither internal agreement nor this simple interface check validates the lower construction.

The next lower gate is an independent audit of the countable harmonic-transfer construction with birth graphs, simultaneous matching and all-radius growth. The present upper theorem does not rely on that construction.

