# Frozen independent derivation: spectral-volume ceiling for slow compact-link ends

Frozen 2026-10-08 before receiving any independent audit derivation.
Work status: internally reconstructed; no formal replay, specialist validation, or priority clearance.

## Exact theorem

Let a smooth complete connected three-manifold have, outside a smooth compact core, one end
\[
g=dr^2+f(r)^2H(\log r),\quad r>R_0.
\]
Assume f>0 smooth, f(r)/r -> a>0; H(t) is smooth and contained in a C-infinity compact family K of metrics on one fixed connected closed surface; every H in K has the SAME POINTWISE area form mu, mu(Sigma)=4pi; and ||H_t||_C0 -> 0 in a fixed background metric. The compact core plus r<=R exhausts M. Polynomial growth in r agrees with geodesic polynomial growth since distance from a fixed point in the core is r+O(1).

For the real smooth harmonic functions of pointwise growth at most k, write h_k=dim H_k. Then h_k is finite for every k>=0 and
\[
\boxed{\limsup_{k\to\infty} h_k/k^2\le9a^2/4.}
\]
The normalized asymptotic volume ratio is a^2. Nonnegative Ricci curvature is not needed. No conclusion for arbitrary Ricci-nonnegative manifolds is asserted.

More precisely, any p independent members of H_k obey
\[
pk\ge C_p:=\inf_{H\in K}\sum_{j=0}^{p-1}\alpha_j(H),
\qquad
\alpha_j(H)=\frac{\sqrt{1+4\lambda_j(H)/a^2}-1}{2}. \tag{1}
\]
Eigenvalues include multiplicity and lambda_0=0. This finite-dimensional inequality is load-bearing.

## Finite collar comparison

Set t=log r, b(t)=f(e^t)/e^t -> a. The metric and end energy are
\[
g=e^{2t}(dt^2+b(t)^2H(t)),\quad
E(u;[t_1,t_2])=\int_{t_1}^{t_2}e^s
 \bigl(b(s)^2|u_s|^2+|\nabla_{H(s)}u|^2\bigr)d\mu\,ds. \tag{2}
\]
Let N_t v = partial_t u|_t for the harmonic extension into the enclosed compact domain Omega_{e^t}. Green's identity gives
\[
\langle N_tv,v\rangle_{L^2(\mu)}
=e^{-t}b(t)^{-2}E(u;\Omega_{e^t}). \tag{3}
\]
Thus N_t is nonnegative self-adjoint on the fixed Hilbert space. It is the radius-normalized Dirichlet-to-Neumann operator, with compact resolvent.

Fix L>0. Discard energy inside t-L and free the inner boundary trace. This gives, for every outer trace v,
\[
\langle N_tv,v\rangle \ge
\inf_{w(0)=v}b(t)^{-2}\int_{-L}^{0}e^s
 \bigl(b(t+s)^2|w_s|^2+
 |\nabla_{H(t+s)}w|^2\bigr)d\mu\,ds. \tag{4}
\]
The free inner trace imposes the natural Neumann boundary condition. The inequality direction is correct: discarding the core and freeing the inner boundary decrease the minimal energy.

For this fixed L, b(t+s)->a uniformly. Also
\[
\sup_{-L\le s\le0}\|H(t+s)-H(t)\|_{C^0}
\le L\sup_{\tau\ge t-L}\|H_t(\tau)\|_{C^0}\to0.
\]
Uniform ellipticity from K therefore yields delta_L(t)->0 such that (4) is at least
\[
(1-\delta_L(t))\inf_{w(0)=v}
\int_{-L}^{0}e^s
 \bigl(|w_s|^2+a^{-2}|\nabla_{H(t)}w|^2\bigr)d\mu\,ds. \tag{5}
\]
This is a quadratic-form comparison for EVERY trace and spatial frequency, not a fixed-cutoff approximation.

In the frozen Laplace eigenbasis, let alpha(alpha+1)=lambda/a^2, alpha>=0. The scalar minimizer solves
\[
w''+w'-\alpha(\alpha+1)w=0,\quad w(0)=1,\quad w'(-L)=0.
\]
For alpha>0 and z=exp(-(2alpha+1)L), it is
\[
w(s)=\frac{e^{\alpha s}+
 [\alpha/(\alpha+1)]z e^{-(\alpha+1)s}}
 {1+[\alpha/(\alpha+1)]z}.
\]
Integration by parts makes the minimum energy the derivative at zero:
\[
q_L(\alpha)=w'(0)=
 \alpha\frac{1-e^{-(2\alpha+1)L}}
 {1+[\alpha/(\alpha+1)]e^{-(2\alpha+1)L}}. \tag{6}
\]
For alpha=0, w=1 and q_L(0)=0. The multiplier increases with lambda by its variational characterization. Direct algebra gives
\[
0\le\alpha-q_L(\alpha)\le
2\alpha e^{-(2\alpha+1)L}. \tag{7}
\]
Consequently,
\[
N_t\ge(1-\delta_L(t))q_L(\alpha(-\Delta_{H(t)})) \tag{8}
\]
as quadratic forms.

For any p-dimensional boundary subspace W_t, min-max and the Ky Fan trace principle give
\[
\operatorname{tr}(N_t|_{W_t})\ge
(1-\delta_L(t))\sum_{j=0}^{p-1}q_L(\alpha_j(H(t))). \tag{9}
\]
Here p and L are held fixed before t->infinity. Compactness bounds the first p roots uniformly over H. Equation (7) then lets L->infinity AFTERWARD to obtain the trace floor C_p in (1). No growing-cutoff freezing estimate is used.

## Gram determinant

Choose independent u_1,...,u_p in H_k and set
\[
G_{ij}(t)=\int_\Sigma u_i(e^t,x)u_j(e^t,x)d\mu(x).
\]
G is positive definite: a linear combination vanishing on the boundary is zero in the enclosed compact domain by harmonic Dirichlet uniqueness and zero on M by smooth elliptic unique continuation.

Fixed pointwise mu gives G'_ij=2<N_t u_i,u_j>. Therefore
\[
\tfrac12(\log\det G)'=
 \sum_{i=1}^{p}\langle N_tv_i,v_i\rangle, \tag{10}
\]
where v_i is an orthonormal basis of the boundary span. This follows directly from tr(G^{-1}G').

Given epsilon>0, first choose L large so all sums of the q_L roots are >=C_p-epsilon; then choose t late so the factor 1-delta_L(t) loses at most another epsilon. Equations (9)-(10) yield
\[
\tfrac12(\log\det G)'\ge C_p-2\epsilon
\]
for all sufficiently late t. Pointwise growth and Hadamard give
\[
\det G(t)\le\prod_iG_{ii}(t)\le C e^{2pk t}.
\]
Integrate the lower derivative, compare this upper rate, then epsilon->0. This proves (1).

## Uniform Weyl and the constant

For each fixed smooth H of area 4pi, ordinary Weyl gives lambda_j(H)/j->1. The convergence is uniform over K, as follows. Choose a finite C0 metric net for K. Common pointwise area form makes all Rayleigh denominators identical. In a sufficiently small net neighborhood, inverse-metric Dirichlet forms compare within factors 1+-epsilon, hence ALL eigenvalues compare by min-max. Apply individual Weyl to finitely many net centers and take the largest onset index. Then epsilon->0. No unproved uniform-degree spectral assumption is needed.

Since
\[
\sqrt\lambda/a-\tfrac12\le
 [\sqrt{1+4\lambda/a^2}-1]/2
 \le\sqrt\lambda/a,
\]
uniform Weyl and sum_{j<p}sqrt(j)=(2/3)p^{3/2}+O(sqrt(p)) imply
\[
C_p=\frac{2}{3a}p^{3/2}+o(p^{3/2}). \tag{11}
\]
For fixed k, (1) precludes arbitrarily large finite independent subsets, proving h_k finite. With p=h_k, divide (1) by p and use (11):
\[
k\ge(2/(3a)+o(1))\sqrt p.
\]
This gives the advertised coefficient 9a^2/4; subsequences with bounded p contribute zero. Finally Vol(Omega_r) ~ (4pi/3)a^2r^3, giving normalized AVR=a^2.

## What is and is not closed

The upper derivation closes under its exact premises using standard smooth elliptic, min-max, unique continuation and Weyl facts. Those facts are imported; this is not a formal-kernel proof.

Matching optimality requires verifying that the repository N175 candidate satisfies these end premises and that its countable harmonic transfer is valid. That lower construction remains source-derived and externally unverified.

The missing structural input for arbitrary nonnegative-Ricci manifolds is a replacement for the all-trace collar comparison and uniform Weyl step without a smooth compact polar link family. The present proof does not supply it.

Priority is UNKNOWN. Standard collar bracketing, Gram determinants and Weyl tools have substantial prior art. Need to read the original Colding-Minicozzi 1998 proof before claiming the constant itself is new.

