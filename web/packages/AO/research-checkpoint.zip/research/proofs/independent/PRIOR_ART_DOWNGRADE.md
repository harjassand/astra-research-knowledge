# Prior-art downgrade: Li–Wang boundary-energy method

The frozen independent collar proof remains unchanged. Its coefficient 9a²/4
must not be promoted as a novel upper-bound mechanism.

I directly read the primary Li–Wang paper *Counting dimensions of
L-harmonic functions*, Annals of Mathematics 152 (2000), 645–658:
https://annals.math.princeton.edu/articles/11855
https://arxiv.org/abs/math/0009254

The PDF supplied by the blind auditor was then locally inspected. Lemma 1
is on printed pp.649–650 (PDF pp.5–6); the energy-Gram determinant
argument is on printed pp.652–653 (PDF pp.8–9), equations (2.4)–(2.5).
The lemma proves, for a p-dimensional space of nonconstant harmonic
functions orthonormal in interior Dirichlet energy,
\[
2\sum_{j=0}^{p-1}\sqrt{\eta_j(\partial B_R)}
\le \sum_{i=1}^p\int_{\partial B_R}|\nabla u_i|^2\,dA.
\]
Its proof uses a triangular boundary-eigenfunction orthogonality choice,
the boundary Rayleigh principle, Green's identity, and 2xy≤x²+y².

For g=dr²+f(r)²H(log r), boundary eigenvalues are
η_j=λ_j(H(log R))/f(R)². For a fixed independent family modulo constants,
let D_R be its interior energy Gram matrix. The same published
determinant argument therefore gives
\[
(\log\det D_R)'\ge
\frac{2}{f(R)}\sum_{j=0}^{p-1}\sqrt{\lambda_j(H(\log R))}.
\]
A C-infinity compact family of surface metrics each of total area 4π has
uniform Weyl law λ_j=j(1+o(1)). This conclusion does not need a common
pointwise area form: finite metric-net comparison controls numerator
and denominator of the Rayleigh quotient. Thus the eigenvalue sum is
(2/3)p^(3/2)+o(p^(3/2)) uniformly.

Since |u|=O(R^k), radial cutoff Caccioppoli and Vol(B_2R)=O(R³)
give D_R(u,u)=O(R^(2k+1)). After integrating, f/R→a yields
\[
p(2k+1)\ge \frac{4}{3a}p^{3/2}+o(p^{3/2}).
\]
This gives finiteness and limsup h_k/k²≤9a²/4, adding at most one constant
function to the nonconstant space. The result requires neither slow H_t
nor fixed pointwise area for this compact polar class.

This is an attributed application of established primary-source
machinery. The independent all-trace collar argument supplies a
lower-order finite-p cone-root inequality under stronger hypotheses,
but no consequential novelty claim is justified for that refinement.

The possible surviving contribution is the conditional matching
optimality corollary: if the source-derived N175 fixed-manifold lower
construction is valid, then for v∈(4/9,1) the supremum over the stated
Ricci-nonnegative compact polar subclass of limsup h_k/k² equals9v/4.
Class membership has been checked as written; countable harmonic
transfer and historical priority of the lower/matching statement remain
UNKNOWN. A class supremum does not assert one metric attains the endpoint.

Next decisive gate: independently validate N175's countable-transfer
construction or identify a failure. A standalone new-upper-theorem
publication should not be pursued on current evidence.

