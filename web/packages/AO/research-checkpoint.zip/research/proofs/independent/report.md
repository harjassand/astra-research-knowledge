# Independent geometric-PDE result

One opportunity retained. Updated status: **upper coefficient is an attributed application of Li–Wang (2000); standalone novelty downgraded.** See PRIOR_ART_DOWNGRADE.md for the exact primary-source lemma and simpler proof under weaker hypotheses. The matching lower-optimality corollary remains conditional; lower correctness and historical priority UNKNOWN. No descendants, publishing, external messages, training, or cloud compute.

For an end
\[
g=dr^2+f(r)^2H(\log r),
\]
with f/r->a>0, H(t) in a C-infinity compact family of smooth metrics on a connected closed surface, one fixed pointwise area form totaling4pi, and H_t->0 in C0, I derived
\[
\limsup_{k\to\infty}\frac{\dim\mathcal H_k(g)}{k^2}
\le\frac94a^2=\frac94\mathrm{AVR}(g).
\]
Nonnegative Ricci curvature is unnecessary for this upper theorem. The result is limited to this explicit slowly varying polar class.

The actual proof is frozen in UPPER_BOUND_FROZEN.md (SHA256 2ff5206cc9dfaf2bd294ffb5249f49bfc3ed6c5d386c892703edc8c5f471f139). Its key finite-dimensional inequality for p independent degree-k harmonic functions is
\[
pk\ge\inf_{H}\sum_{j=0}^{p-1}
\frac{\sqrt{1+4\lambda_j(H)/a^2}-1}{2}.
\]
Discarding the core and freeing an inner logarithmic boundary provides a Neumann collar lower energy. I solve this scalar collar exactly, compare its quadratic form to the full radius-normalized Dirichlet-to-Neumann operator for ALL boundary frequencies, apply Ky Fan to the harmonic boundary span, and integrate its Gram determinant. A finite C0 metric net makes ordinary smooth Weyl asymptotics uniform over the compact link family, yielding the constant9/4. No source crossing controls, fixed point, or fixed-cutoff harmonic graph is imported into the upper proof.

Thirty exact Fraction collar checks confirm the derivative/energy formula and sign/normalization; five exact round-spectrum sum checks confirm the2/3 spectral average. These finite checks are arithmetic sanity checks, not PDE or theorem certification.

The repository N175 lower candidate satisfies the subclass premises AS WRITTEN. LOWER_MEMBERSHIP.md records exact source spans, including the original current release's p6 equation(2.4), whose area form is pointwise fixed. N175 PROOF_v3 lines132-149 supplies smooth compactness and decay; lines174-186 supplies f/r->a. Thus, CONDITIONAL on N175's unvalidated lower construction, for each v in (4/9,1) the supremum over this Ricci-nonnegative subclass of the fixed-manifold harmonic-dimension limsup is exactly9v/4. Supremum does not imply endpoint attainment.

## Source comparison and priority

1. [Huang, arXiv:2109.07534](https://arxiv.org/abs/2109.07534), Theorem1.6 p4, proof pp15-16; Corollary1.9 p4 and proof p16; Proposition2.1 p8. Unique tangent cone gives exact normalized asymptotic coefficient AVR in3D. I opened the primary PDF and inspected its proof/Weyl spans. That unique-cone result does not give the present nonunique-link coefficient.
2. [Girouard-Polterovich, arXiv:1411.6567](https://arxiv.org/abs/1411.6567), Section4.1 p9 equation(4.1.2), for the standard variational Steklov interface; Section2.1 p4, for its square-root Laplace principal symbol. These are imported established tools. They do not assert this harmonic dimension theorem.
3. [Colding-Minicozzi, Weyl type bounds for harmonic functions](https://doi.org/10.1007/s002220050204), Invent. Math.131(1998),257-298. The original publisher page was opened, but full proof was inaccessible without subscription. Its C_n AVR general bound was then directly read in [Colding's 1998 ICM exposition](https://ems.press/content/book-chapter-files/27159), Theorem3.2, printed p306/PDF p8, with equation(3.3). The individual ten-page primary PDF was downloaded and inspected, not just its search snippet. The original1998 proof and its possible specialized constants/overlap remain UNKNOWN; do not claim absence.
4. [Current release family361](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf), Theorem1.1 p1 and comparison p2. The degree-dependent construction has the same range c<9v/4 but explicitly makes no optimality or endpoint claim. The PDF was supplied by release_mechanisms and then locally read/rendered here. Its proof is unvalidated source evidence.
5. N175 current POST_SOURCE_STATUS and PROOF_v3, exact local snapshots with hashes in source_manifest.json. Their current claim status is source-derived internally reconstructed, external validity/priority UNKNOWN.

The initial bounded searches missed the decisive comparator. The subsequent blind audit identified Li–Wang (2000); direct primary-source inspection establishes that its boundary-energy and determinant machinery yields the same leading coefficient with weaker hypotheses. The original unsuccessful search is not novelty evidence. See PRIOR_ART_DOWNGRADE.md.

## Value and next decisive gate

This is an attributed compact-polar corollary of established machinery. It explains the9v/4 ceiling, but provides no independently consequential new upper theorem. A matching optimality statement could survive if the unvalidated N175 fixed-manifold lower construction is correct; its significance and historical priority remain unverified.

Next decisive action: independently audit N175 countable harmonic transfer; historical priority of the matching lower-optimality statement also remains open. Original1998 prior-art acquisition would inform broader context but is unnecessary to justify the present upper-novelty downgrade. Root dispatched a blind Sol upper-bound audit. After the independent derivation was frozen, the auditor identified Li–Wang Lemma1. I then read the primary lemma and determinant spans and independently verified that they recover the same coefficient without the slow-variation/common-area premises. The original collar proof remains frozen. The upper coefficient now belongs to established machinery; validate the lower countable transfer as the next gate.

The major open extension is replacing the smooth compact polar link interface by a uniform geometric collar/Weyl statement for arbitrary nonnegative-Ricci manifolds. No such lemma is supplied. Other independent subjects were screened only at routes/cards; no second opportunity was promoted.

No numeric metric, certified spectrum, formal replay, or external validation was produced. Source reads, reconstruction, finite arithmetic, and prior-art gaps remain separate in session.json.
