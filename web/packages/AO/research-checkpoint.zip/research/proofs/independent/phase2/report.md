# Phase 2 independent combinatorial attempt

**Outcome: no justified promotion.** One opportunity was tested: transfer the
release CM proof's four-label switch-and-contraction mechanism to the remaining
quadratic-generation form of White's matroid conjecture. The attempt produced
two concrete obstruction gates and a finite replay of a previously released
stronger result.

The release mechanism was used at its technical interface, not by assuming the
claimed CM Hodge theorem. Its coordinate correction permits all odd sign rows;
matroid bases form a restricted row domain. Its auxiliary contraction returns
nonzero scalars, which can be divided out. Polynomial basis variables do not
have this property.

## Actual attacks

1. **Fixed-target correction is false.** In the Fano rank3 matroid, take
A={013,024,156} and B={016,025,134}, with label i representing binary vector
i+1. The multisets have equal incidence counts. Their minimum row-matching
deficit is3. All seven arbitrary two-base replacement neighbors have deficit
at least3, so no strictly decreasing quadratic move exists. A verified
3-step path has deficits3,3,2,0. This refutes the proposed greedy gate, not
quadratic connectivity itself.

2. **Auxiliary cancellation is false.** Reconstructing Larson's published
rank9 binary matrix gives14,848 bases and2,784 unordered complementary pairs.
The symmetric-exchange graph has two components of sizes864 and1,920.
For the published low/high relation f, exact cubic paths show every basis
variable y_N satisfies y_N f in J while f is outside J, where J is generated
by symmetric-exchange quadrics. Thus J:f is the irrelevant maximal ideal.
The same-context generator and a separate dense-binary/codeword certificate
checker agree on this complete finite statement. They do not constitute
external validation or formal kernel replay.

Historical checking then found the exact stronger prior art: Taeseok Oh's
July31,2026 cyclic-family socle theorem. Its primary proof already establishes
this annihilation for all parameters, including Larson's example. The finite
construction is a replay, not a new result.

## Exact source comparison

- Release CM paper, pinned source commit fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb:
hodge-02-tensors.tex lines388–401 (coordinate correction) and418–455
(auxiliary composition, scalar-unit return). The algebraicity of the
four-factor switch and the class-wide theorem were not validated or used.
- [Lasoń–Michałek, arXiv1302.5236](https://arxiv.org/abs/1302.5236):
Theorem3 and its proof, PDFpp3–6, Claim4 and Lemma5. The saturation result
already supplies auxiliary-buffer assembly; it does not authorize cancellation.
- [Larson, arXiv2607.02208](https://arxiv.org/abs/2607.02208):
Conjecture1.1pp1–2, Example1.4p3 and Theorem1.5 proofpp3–4. Symmetric-exchange
White is disproved; arbitrary-quadratic White is the surviving interface.
The exact matrix was visually checked against original PDFp3.
- [Oh, Zenodo21720652](https://zenodo.org/records/21720652):
Theorem1.1p2, Proposition2.1p3, endpoint adaptation Lemma5.1p10,
exchange-triangle Lemma6.1pp10–11, constructive Theorem7.1pp12–13,
socle Corollary7.3p13. These original proof sections were opened/read.
The all-parameter argument was not independently certified here.
- Backman et al., arXiv2606.13960, primary introductionpp1–2: the quadratic
Gröbner strengthening is already refuted. Its solver proof was not replayed.

The Fano witness's historical priority is UNKNOWN. It is a small gate
counterexample, not a consequential advance even if its particular labels are
new. The socle phenomenon has direct prior art.

## Artifacts, costs, and next gate

DERIVATION.md contains the exact statements, Fano neighbor table and
ideal-level interpretation. verify_fano.py checks all arbitrary pair moves.
buffer_all_variables_certificate.json and verify_certificate.py check full
basis/orbit coverage, code automorphisms, graph components and representative
paths. Both checks PASS. failures.json retains normalization and reporting
errors; the count was corrected from2,808 to2,784.

The computations used exact finite-field arithmetic, no sampling or precision
parameter, no cloud compute, and under a few seconds of recorded local script
time. Four primary PDFs were acquired. Source hashes, read depths, stored
bytes and provenance are in source_manifest.json; current status is in
session.json. Phase1 is preserved.

A serious next proof obligation would be an unsaturated, basis-preserving
global connectivity argument using arbitrary two-base replacements. Neither
the full-hypercube switch mechanism nor known buffer saturation supplies it.
No continued allocation to packaging these results as new foundational
mathematics is justified.

