# Calibration audit notes after the first freeze

The frozen addendum has SHA256 `ab0ab21e22d11651e1313217ed7080398dcab6201237a46653e8494c2930cd5d` and remains unchanged. The finite rational-arithmetic check passed 24,624 instances of the integer score identity (C15) and 432 clipped/rounded anchors. This is a finite diagnostic, not a proof substitute.

The common-axis extension preserves the target concentration constants explicitly. In the notation of (C18)–(C22), put $Z_0=X/\sqrt r$, $a=cv_A/\sqrt r$, and $K_0=-3+d/r+q'e$. Then

$$T_v^{(e)}=3Z_0^2-6aZ_0+K_0,
\quad |a|^2\le1.65,\quad -3\le K_0\le-0.8.$$

Consequently

$$|T_v^{(e)}|\le6Z_0^2+3a^2+3\le6Z_0^2+10.$$

Each actual axis is a unit direction, so its global spin sum on sector $j$ has absolute value at most $2j$. The frozen target tail for $Z_0$ therefore holds on each actual axis, regardless of their mutual angles. It follows that $\mathbb E\exp(|T_v^{(e)}|/1000)<2$ just as in the primary proof.

For every clipped anchor, even on a calibration failure, $N|v|^2\le3.3$ and $N|b_*|^2\le3.3$. By (C20)–(C21),

$$|\mathbb E T_v^{(e)}|
\le\tfrac12(1+3.3+6.6+0.3+0.1)<6.$$

Thus $\mathbb E\exp(|T_v^{(e)}-\mathbb E T_v^{(e)}|/2000)
\le e^{6/2000}\sqrt2<2$. This proves the centered moment bound used for the same completeness exponent. Capping a positive gate above by $1$ ensures its signal parameter $x=q'\gamma_e\le1$; the declared floor is at most $1$, so capping does not invalidate the floor condition.

The addendum does not purchase an external metrological certificate for (C18). It specifies exactly what that certificate must guarantee: common fixed unit axes across qubits and both stages, and a known Gram operator error. Its supplied-input status and separate acquisition cost are explicit. The resource theorem charges all state copies, local readouts, anchor bits, streamed score storage and a concrete subset sampler.

Target permutation invariance is retained in the theorem statement. The inspected proof mechanisms only use averaged Bloch coordinates and the global spin law, but any broader target statement should be separately admitted and compared with the matched lower bound.
