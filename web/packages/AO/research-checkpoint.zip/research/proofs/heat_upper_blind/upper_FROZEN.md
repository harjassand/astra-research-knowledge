# Blind upper-bound proof using a bounded e-value

Proof frozen without reading `work/agents/thermal/bounded_heat_upper_FROZEN.md` or any candidate upper argument. The only supplied scientific inputs were the target statement, exact Schur weights, and known Bloch vector. Status: analytic reconstruction, awaiting adversarial audit; no formal or external validation.

## Finite statement

Let (N\geq4), (2\leq r\leq N/2), and let (ho_N) be a permutation-invariant (N)-qubit state. Its total-spin weights are exactly

\[
p_j=\frac{(2j+1)m_j}{2^N}.
\]

Within each spin sector its state is arbitrary. Let its common one-qubit Bloch vector (b\in\mathbb R^3) be supplied, and set

\[
\kappa=N|b|^2,\qquad \delta=\kappa-1>0,
\qquad q=\frac rN,\qquad q'=\frac{r-1}{N-1},\qquad x=\delta q'.
\]

There is a protocol using

\[
m\leq\left\lceil\frac{24\cdot10^9}{\delta^2(q')^2}
\log\frac1\eta\right\rceil
\tag{1}
\]

fresh copies, with only (r) distinct qubits measured on each copy, such that

- for every fully separable (N)-qubit state (sigma_N), supplied identically and independently on the fresh copies, the probability of declaring entanglement is at most (eta);
- on (ho_N^{\otimes m}), that probability is at least (1-\eta).

Every quantum readout is a single-qubit Pauli measurement. No collective quantum measurement or measurement of an additional qubit is used. The numerical constant is deliberately conservative. More precise bounds below give a substantially smaller eventual constant.

For any target sequence with (liminf_N N|b_N|^2>1) and (2\leq r_N=o(N)), this proves

\[
m_N=O\!\left(\frac{N^2}{r_N^2}\log\frac1\eta\right)
\]

for all sufficiently large (N). The implicit constant depends on the positive asymptotic gap above 1. The statement is not uniform over targets whose gap approaches zero.

## 1. Explicit measurement and score

For each copy independently:

1. Choose a uniformly random (r)-element subset (S\subset[N]).
2. Choose (A\) uniformly from ({x,y,z}).
3. Measure (sigma_A) on every selected qubit. Write (X=\sum_{i\in S}z_i), where (z_i\in\{-1,+1\}).
4. Compute

\[
c=\frac{N(r-1)}{N-1},\qquad
t=\frac{r(r-1)}{N(N-1)},\qquad
d=t(N+N^2|b|^2),
\]

\[
T=\frac{3X^2-3r-6c\,b_A X+d}{r}.
\tag{2}
\]

Declare entanglement exactly when the average of the (m) scores is at most (-x/2).

The score has a universal lower bound (T\geq-8). To make the bounded operator/protocol explicit, choose

\[
C=12000,\quad s_0=(6\cdot10^9)^{-1},\quad
s=\min\{s_0,x/(4C)\},
\]

and define the outcome e-value

\[
Z=\frac{e^{-sT}}{1+Cs^2},\qquad
0<Z\leq\frac{e^{8s}}{1+Cs^2}.
\tag{3}
\]

For fixed (S,A), an actual bounded effect on the measured qubits is

\[
E_{S,A,s}=\sum_{z\in\{-1,1\}^r}e^{-s(T(z)+8)}
\bigotimes_{i\in S}\frac{I+z_i\sigma_A}{2},
\qquad 0\leq E_{S,A,s}\leq I.
\tag{4}
\]

It is diagonal in the ordinary single-qubit readout basis. Measuring that basis supplies the bounded eigenvalue (e^{-s(T+8)}\in[0,1]), and hence (Z). Retain the readout score or bounded eigenvalue; replacing it by a single randomized binary coin would be a different protocol and is not claimed to have the same rate. In implementation, accumulating the polynomial scores in (2) avoids numerical underflow from exponentials.

## 2. Exact mean identities

Let (J=(1/2)\sum_{i=1}^N\sigma^{(i)}). The Schur weights agree with the maximally mixed state, so

\[
\langle J^2\rangle_{\rho_N}=3N/4.
\]

Consequently (N^2|b|^2=|\langle2J\rangle|^2\leq\langle(2J)^2\rangle=3N), and (1<\kappa\leq3). Averaging both the subset and the three axes gives

\[
\mathbb E_{\rho_N} T=-\delta\frac{r-1}{N-1}=-x.
\tag{5}
\]

For a product null (sigma_N=\bigotimes_i\sigma_i), let (v_i\in\mathbb R^3), (|v_i|\leq1), be its Bloch vectors, and set

\[
v=N^{-1}\sum_i v_i,\qquad Q=N^{-1}\sum_i|v_i|^2\leq1.
\]

The exact identity is

\[
\mathbb E_{\sigma_N} T=q'\bigl(1-Q+N|v-b|^2\bigr)\geq0.
\tag{6}
\]

Indeed, the pair term is (t(N^2|v|^2-NQ)), the linear term is (-2cr\,b\cdot v=-2tN^2b\cdot v), and the constant is (d). This proves (6). It uses no claim that the null has the target's Bloch vector or spin weights. Mixtures are addressed by the stronger linear mgf statement below, rather than by imposing a product assumption on the unknown null.

These identities are the centered form of the familiar separable collective-variance inequality. The argument below supplies the sampling concentration needed for the mesoscopic rate.

## 3. A sampling lemma proved directly

Fix an axis and a product Bloch array. Put (u_i=(v_i)_A\in[-1,1]), (ar u=N^{-1}\sum_i u_i). For every real (lambda),

\[
\mathbb E e^{\lambda X}
=\frac{e_r(a_1,\ldots,a_N)}{\binom Nr}
\leq\left(\frac1N\sum_i a_i\right)^r
=(\cosh\lambda+\bar u\sinh\lambda)^r,
\quad a_i=\cosh\lambda+u_i\sinh\lambda>0.
\]

The elementary symmetric mean inequality follows by pairwise averaging: at fixed (a_i+a_j), (e_r) increases when their product increases; repeated averaging converges to the constant array. For a sign with mean (ar u), the second derivative of its tilted log-mgf is a variance, at most 1. Integrating from zero therefore gives

\[
\mathbb E e^{\lambda(X-r\bar u)}\leq e^{r\lambda^2/2}.
\tag{7}
\]

Thus (W=(X-r\bar u)/\sqrt r) has conditional tail

\[
\Pr(|W|\geq z\mid A)\leq2e^{-z^2/2},\qquad
\mathbb E(W^4\mid A)\leq16.
\tag{8}
\]

The fourth moment follows by integrating the displayed tail. The same result holds when the population signs are deterministic and the only randomness is sampling without replacement.

## 4. Uniform null mgf, including high polarization

Define the product component's field (L=r|v-b|^2). By (6),

\[
\mathbb E T\geq L/2,
\tag{9}
\]

since (c=N(r-1)/(N-1)\geq r/2).

Writing (a_A=cb_A/\sqrt r) and (D_A=\sqrt r\,(v-b)_A+(r-c)b_A/\sqrt r),

\[
T=3(W+D_A)^2-3+d/r-3a_A^2.
\tag{10}
\]

Here (c\leq r), (0\leq r-c\leq1), (a_A^2\leq r|b|^2\leq3q\leq3/2), and (d/r=q'(1+\kappa)\leq2). Hence (T\geq-8); also (|(r-c)b_A/\sqrt r|\leq1), (D_A^2\leq2L+2), and the final constant in (10) has absolute value at most 10. Using (8), ((u+v)^4\leq8(u^4+v^4)), and ((L+1)^2\leq2(L^2+1)), one gets

\[
\mathbb E T^2\leq3656+1152L^2\leq4000(1+L^2).
\tag{11}
\]

For (0<s\leq1/8), the lower bound (T\geq-8) and Taylor's formula imply

\[
\mathbb E e^{-sT}
\leq1-s\mathbb E T+\tfrac12e^{8s}s^2\mathbb E T^2
\leq1-\tfrac12sL+6000s^2(1+L^2).
\tag{12}
\]

For (L\leq1), this is at most (1+12000s^2). For

\[
1<L\leq\frac1{24000s},
\]

the term (6000s^2L^2\) is at most (sL/4), so the same bound follows.

Now let (L>1/(24000s)) and (s\leq s_0=1/(6\cdot10^9)). Then (L>250000). At least one of the three chosen axes satisfies (|(v-b)_A|\geq|v-b|/\sqrt3\geq|v-b|/2). On that axis, (|D_A|\geq\sqrt L/2-1\geq\sqrt L/4). Except on an event of probability at most (2e^{-L/128}), (8) gives (|W|\leq|D_A|/2) and therefore (T\geq3L/64-8). Averaging this axis, which has probability at least (1/3), and using (e^{-sT}\leq e^{8s}) for the others, gives

\[
\mathbb E e^{-sT}\leq e^{8s}
\left[\frac23+\frac13e^{-3sL/64}+\frac23e^{-L/128}\right].
\tag{13}
\]

Since (sL>1/24000), the decrement of the second term from (1/3) is at least

\[
\frac13\left(1-e^{-3/(256\cdot6000)}\right)
\geq\frac1{512\cdot6000}>3\cdot10^{-7}.
\]

Meanwhile (e^{-L/128}<2^{-30}<10^{-9}) and (e^{8s}\leq1+16s<1+3\cdot10^{-9}). The right side of (13) is strictly less than 1. Together the two field regimes prove, uniformly over every nonidentical product array,

\[
\boxed{\mathbb E_{\sigma_N}e^{-sT}\leq1+12000s^2
\quad(0<s\leq s_0).}
\tag{14}
\]

Expectation of this fixed bounded outcome function is linear in the state. Thus (14) holds for **all fully separable mixtures**, including arbitrary mixtures whose product components have very different global polarizations. No fourth-moment bound on the mixture itself was assumed.

## 5. Target tails from its spin weights only

Let (	au_N=I/2^N). It has the same (j)-distribution as the target. Conditional on (j), the (J_z) eigenvalues in (	au_N) are uniform on (-j,-j+1,\ldots,j). At least a third have magnitude at least (j/2). Since (2J_z) in (	au_N) is a sum of (N) independent unbiased signs, the elementary sign log-mgf bound gives

\[
\Pr_{\rho_N}(j\geq u)=\Pr_{\tau_N}(j\geq u)
\leq3\Pr_{\tau_N}(|J_z|\geq u/2)
\leq6e^{-u^2/(2N)}.
\tag{15}
\]

The global measured sum along any Pauli axis is (G=2J_A), whose magnitude on spin (j) is at most (2j). Hence, for every axis and arbitrary sector state,

\[
\Pr_{\rho_N}(|G|/\sqrt N\geq v)\leq6e^{-v^2/8}.
\tag{16}
\]

For analysis only, imagine measuring that axis on all (N) qubits and then selecting the random subset. Ignoring the unselected outcomes gives exactly the actual local measurement law. Conditional on those outcomes, (7)-(8) apply to sampling a deterministic sign population. Thus with (Z_0=X/\sqrt r), (q\leq1/2),

\[
\Pr(|Z_0|\geq z)
\leq2e^{-z^2/8}+6e^{-z^2/(32q)}
\leq8e^{-z^2/16}.
\tag{17}
\]

This argument performs no global measurement in the actual protocol and assumes no promise about the null.

Pointwise, (|T|\leq6Z_0^2+10). Integrating (17) yields

\[
\mathbb E_{\rho_N}e^{|T|/1000}
\leq e^{1/100}\left(1+\frac{128}{1000/6-16}\right)<2.
\tag{18}
\]

If (V=T-\mathbb E T=T+x), then (mathbb E|V|^p\leq2p!(2000)^p). Therefore, for (|\lambda|\leq1/4000), expanding the centered mgf gives

\[
\mathbb E e^{\lambda V}\leq\exp(16\cdot10^6\lambda^2).
\]

Since (x\leq1), Chernoff with (lambda=x/(64\cdot10^6)) proves

\[
\Pr_{\rho_N}\{\overline T>-x/2\}
\leq\exp\left[-\frac{mx^2}{256\cdot10^6}\right].
\tag{19}
\]

## 6. Soundness and copy count

With (s=\min\{s_0,x/(4C)\}), (14) and independent fresh copies imply

\[
\Pr_{\sigma_N}\{\overline T\leq-x/2\}
\leq e^{-msx/2}(1+Cs^2)^m
\leq e^{-msx/4}.
\tag{20}
\]

Equivalently, the product of the bounded e-values in (3) has expectation at most 1, and the rejection event makes that product at least (e^{msx/4}); Markov gives (20). Consequently the sharper explicit sufficient count is

\[
\boxed{m=\left\lceil\max\left\{\frac4{sx},\frac{256\cdot10^6}{x^2}\right\}
\log\frac1\eta\right\rceil.}
\tag{21}
\]

As (0<x\leq1) and (s_0\leq1/(4C)), (s\geq s_0x). Thus (21) is bounded by (1). For (x\leq4Cs_0), (s=x/(4C)) and the completeness constant (256\cdot10^6) dominates the soundness constant (16C=192000). Every admitted asymptotic sequence eventually enters this regime.

Finally (q'=(r-1)/(N-1)\geq r/(2N)), so the count is at most a constant times (delta^{-2}(N/r)^2\log(1/\eta)). This is a fully specified upper protocol; the supplied lower bound was not used.

## Scope, resources and remaining obligations

- The target's spin-weight promise enters only its mean and tail analysis. The null is unrestricted beyond full separability, and may have any mean, spin weights, anisotropy, nonidentical local states, or mixture decomposition.
- The protocol uses (mr) single-qubit readouts, three axis settings, fresh independent copies, and independent random subsets. It records one integer (X) per copy, needing (O(\log r)) bits, and a known coordinate (b_A). Score accumulation needs ordinary arithmetic; no Schur transform is performed.
- Exact known (b) is the supplied interface. If using an approximate anchor (	ilde b), the target gap becomes (q'[\delta-N|\tilde b-b|^2]). The proof tolerates (N|\tilde b-b|^2<\delta), with adjusted constants if (N|\tilde b|^2) remains bounded. Bloch-vector acquisition is not charged here because it is supplied.
- The finite theorem covers (N\geq4), (2\leq r\leq N/2), and (delta>0). A liminf promise alone gives these conditions only eventually. It does not certify early (N) with (delta\leq0).
- Effect (4) is explicit, but the rate proven is for retaining its multioutcome eigenvalue/readout, not for a fixed binary success-frequency test. This distinction is part of the measurement interface.
- The constants are conservative and should be checked during audit. The proof does not establish priority, experimental robustness, or an optimal numerical constant.

All estimates (6)-(21) were derived in this file. Prior art for the underlying collective-variance inequality is Tóth et al., *Optimal spin squeezing inequalities detect bound entanglement in spin models*, <https://arxiv.org/pdf/quant-ph/0702219>. No candidate heat argument, candidate upper proof, or inherited upper claim was used.
