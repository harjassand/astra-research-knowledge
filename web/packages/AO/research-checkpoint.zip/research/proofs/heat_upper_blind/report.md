# Blind quantum-inference upper-bound audit

**Verdict: the requested upper rate is analytically reconstructed.** The proof in `upper_FROZEN.md` was completed without reading any other worker's upper argument. It supplies a physical protocol with three Pauli settings, single-qubit readout on a uniformly random subset, a bounded diagonal effect, and uniform soundness against every fully separable null. It also supplies target completeness. Formal validation, external validation, and priority remain unestablished.

## Exact theorem and finite scope

For $N\ge4$, $2\le r\le N/2$, and a promised target with exactly maximally mixed Schur weights, set

$$\delta=N|b|^2-1>0,\qquad x=\delta\frac{r-1}{N-1}.$$

There is an explicit protocol using no more than

$$\left\lceil24\cdot10^9\delta^{-2}
\left(\frac{N-1}{r-1}\right)^2\log(1/\eta)\right\rceil$$

fresh independent copies, each with exactly $r$ distinct qubits read out. Its false-entanglement probability is at most $\eta$ for every fixed unknown fully separable $N$-qubit state; its detection probability on the target is at least $1-\eta$. Neither the target mean nor its Schur promise is imposed on the null. Different local factors and arbitrary separable mixtures are included.

For $\liminf N|b_N|^2>1$ and $2\le r_N=o(N)$, the premises hold eventually and the count is $O(N^2r_N^{-2}\log(1/\eta))$, with a constant depending on the positive gap. This is uniform for ordinary error parameters $0<\eta\le1/2$. For $\eta>1/2$ a zero-copy fair decision already meets both error conditions, or the displayed ceiling can be retained. A liminf assumption does not supply an early-$N$ certificate when $\delta\le0$.

## Concrete readout and rejection rule

Choose an axis $A$ uniformly from $x,y,z$, a uniform $r$-subset $S$, and measure $\sigma_A$ on its qubits. Let $X$ be the sum of their signs and compute

$$c=\frac{N(r-1)}{N-1},\quad t=\frac{r(r-1)}{N(N-1)},\quad
T=\frac{3X^2-3r-6cb_AX+t(N+N^2|b|^2)}r.$$

Reject the separable null iff the average score is at most $-x/2$. The exact target expectation is $-x$. For each product component with Bloch array $v_i$, average $v$, and $Q=N^{-1}\sum|v_i|^2$, the exact null expectation is

$$\mathbb E T=\frac{r-1}{N-1}\bigl(1-Q+N|v-b|^2\bigr)\ge0.$$

An expectation gap alone would not establish the rate. The load-bearing estimate is the uniform one-sided bound

$$\mathbb E_{\rm sep}e^{-sT}\le1+12000s^2,
\qquad0<s\le(6\cdot10^9)^{-1}.$$

Its proof first handles low and intermediate product polarizations using a fourth-moment bound, then handles large polarization using one of the three axes along which the displaced mean is large. The resulting fixed outcome function is linear in the state, so the bound passes to arbitrary separable mixtures. This step explicitly avoids assuming a uniform variance bound on all null mixtures.

The score satisfies $T\ge-8$. For $s=\min\{(6\cdot10^9)^{-1},x/(48000)\}$, the diagonal effect

$$E_{S,A,s}=\sum_{z\in\{-1,1\}^r}e^{-s(T(z)+8)}
\bigotimes_{i\in S}\frac{I+z_i\sigma_A}{2}$$

lies in $[0,I]$ and is computed from the local signs. Retain its eigenvalue or the original score. The proved rate is for this multioutcome readout and its e-value product; a binary coin obtained by randomizing the effect's eigenvalue is a different interface and has no rate claim here.

## Why the target promise suffices

The Schur weights fix $\langle J^2\rangle=3N/4$, hence $1<N|b|^2\le3$. They also imply a Gaussian upper tail for the total spin $j$ by comparison with $I/2^N$. On every spin-$j$ sector, every axial spin sum has absolute value at most $2j$, independently of its sector state. Conditional sampling without replacement then yields uniform exponential moments for $X^2/r$, and therefore a subexponential tail bound for the target's centered score. No rotational isotropy of the target sector states is assumed.

The sharper sufficient count is

$$m=\left\lceil\max\left\{\frac4{sx},\frac{256\cdot10^6}{x^2}\right\}\log(1/\eta)\right\rceil.$$

Every admitted asymptotic sequence eventually has $s=x/(48000)$, where the constant $256\cdot10^6$ suffices. Numerical constants were chosen for transparency, not efficiency.

## Source comparison and novelty limit

The collective-variance witness is old: Tóth's 2004 Eq. (8), proved from local spin uncertainty and variance concavity, contains the separable bound used here. Tóth et al. later present it as Eq. (2b) and explicitly credit the earlier work. [Tóth 2004](https://arxiv.org/pdf/quant-ph/0310039), [Tóth et al.](https://arxiv.org/pdf/quant-ph/0702219).

Random collective directions and recovery of this variance criterion are also established: Imai–Tóth–Gühne Observation 2 gives the collective randomized form and notes that finite designs can replace direction integrals. [Imai–Tóth–Gühne 2024](https://www.gtoth.eu/Publications/PRL24.pdf).

Bönsel et al. Sec. III C already use randomly selected pairs to estimate spin-squeezing parameters. Sec. IV C treats state-dependent variances with Cantelli's inequality; its worked preparation-count calculation explicitly assumes a Dicke state mixed with depolarizing noise. Those inspected results do not immediately supply the exact target promise, arbitrary mesoscopic subset size, and unrestricted-null exponential estimate proved here. This is a comparison of inspected statements, not a claim that no extension or other published theorem exists. [Bönsel et al. 2024](https://arxiv.org/pdf/2311.17845).

Cieśliński et al. provide a broad finite-statistics framework for entanglement witnesses and distinguish validity from detection power. Their inspected binomial-correlation framework does not state this particular Schur-promised subsampling rate. [Cieśliński et al. 2024](https://arxiv.org/pdf/2208.01983).

**Novelty status: UNKNOWN.** A bounded primary-source search did not locate the exact upper theorem. Do not describe the witness, three settings, randomized pairs, or hypothesis-testing framework as new. Any possible contribution would be the exact promised-target mesoscopic rate and its uniform null concentration argument, subject to further prior-art and adversarial review.

## Checks, resources and unresolved points

The analytic self-audit checked each coefficient in the means, the three null polarization regimes, the Schur-tail transfer, and both error exponents. `diagnostic.py` exhaustively enumerates local outcomes/subsets for 60 named product examples with $N=4,6,8$, and three explicit promised targets with $N=4,6$. The largest mean-identity residual was $5.51\times10^{-14}$. These are finite diagnostic checks only.

The protocol charges $m$ fresh copies and $mr$ single-qubit readouts, uses three settings, and records one integer $X$ per copy. Its classical per-copy arithmetic is elementary. The exact vector $b$ is supplied; obtaining or experimentally calibrating it is outside the stated resource interface. An approximate anchor changes the target gap to $(r-1)(\delta-N|\tilde b-b|^2)/(N-1)$ and requires a quantified accuracy margin.

Remaining review obligations are an independent proof audit, a broader novelty comparison, and any experimental noise/precision extension. No lower bound was used. No other-worker candidate upper file was read.
