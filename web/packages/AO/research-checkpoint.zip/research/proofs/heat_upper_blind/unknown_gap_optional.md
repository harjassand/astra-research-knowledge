# Optional calibration without a supplied numerical gap

This variant distinguishes a target-side probability bound on resource use from the deterministic fixed-copy cap proved in the frozen addendum. It must not be substituted for that cap without changing the stated interface.

For stages $k=4,5,\ldots$, use fresh calibration copies with

$$\varepsilon_k=2^{-2k},\quad g_{\min,k}=8\cdot2^{-k},\quad
\zeta_k=\frac{\eta}{4(k-3)^2}.$$

At each stage run (C1)–(C3) using $\varepsilon_k,\zeta_k$. Stop calibration at the first stage whose computed $\gamma_k$ is at least $g_{\min,k}$. Freeze that anchor and gap, then run one verification batch with allowance $\alpha=\eta/2$. Do not repeat the final verification after an unsuccessful verification result.

Since $\sum_{k\ge4}\zeta_k=\eta\pi^2/24<\eta/2$, all target calibration confidence events hold simultaneously with probability greater than $1-\eta/2$. For any finite target gap $0<\delta\le2$, define

$$k_0=\max\left\{4,\left\lceil\log_2(16/\delta)\right\rceil\right\}.$$

On the simultaneous confidence event, (C17) gives $\gamma_{k_0}\ge\delta-8\cdot2^{-k_0}\ge\delta/2$, so calibration stops no later than $k_0$. At every earlier stopping stage, its declared floor obeys

$$\gamma_k\ge8\cdot2^{-k}\ge8\cdot2^{-k_0}\ge\delta/4.$$

Thus its verification count on that event is at most

$$\left\lceil384\cdot10^9\delta^{-2}(q')^{-2}
\left\lceil\log_2(2/\eta)\right\rceil\right\rceil.$$

Writing $L_0=\lceil\log_2(24(k_0-3)^2/\eta)\rceil$, the total calibration count through stage $k_0$ is at most

$$169869312\,\frac{N}{r\delta^2}L_0+3(k_0-3).$$

This uses $4^{k_0}\le1024/\delta^2$ and the geometric sum of the calibration costs. Hence the target has, with probability at least $1-\eta/2$, a total resource bound of the desired mesoscopic order, with a gap-dependent constant. Combining this event with the one verification failure gives overall target detection probability at least $1-\eta$.

For a fixed iid fully separable null, any finite stopping stage leaves a clipped anchor. Conditional verification soundness is at most $\eta/2$, independently of which stage stopped; averaging over the disjoint stopping events proves the same unconditional soundness. If calibration never stops, no entanglement is certified. This procedure consequently has no guaranteed finite stopping time on every null and no deterministic universal resource cap under an unknown margin. Those limitations are explicit.

A predetermined maximum stage can make the protocol terminate on every input, returning “not certified” at its cutoff. Its deterministic cap is then the sum of the declared stage costs plus the verification cap from the smallest allowed floor; completeness holds for gaps whose $k_0$ is within the cutoff. Such a cutoff is a numerical margin choice in another form.
