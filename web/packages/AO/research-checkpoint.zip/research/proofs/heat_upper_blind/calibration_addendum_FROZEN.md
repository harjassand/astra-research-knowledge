# Acquiring, freezing and charging the Bloch anchor

This addendum leaves `upper_FROZEN.md` unchanged. The derivation below uses its sampling and Schur-tail arguments, but no other worker's calibration file. The collective-variance witness is established prior art; this is an analytic reconstruction of resource and confidence bookkeeping.

## 1. Finite executable statement with a declared gap floor

Let $N\ge4$, $2\le r\le N/2$, and let each fresh input copy be independently prepared in the same unknown $N$-qubit state. On the permutation-invariant target, assume the exact Schur weights from the frozen theorem, with arbitrary sector states. The true Bloch vector need not be supplied. Write $b$ for its averaged one-qubit Bloch vector and $\delta=N|b|^2-1$.

Choose rational accuracy $0<\varepsilon\le1$ and a rational floor $0<g_{\min}\le1$. For $0<\eta\le1/2$, use a calibration failure allowance $\zeta=\eta/2$ and verification allowance $\alpha=\eta/2$. Define integer upper logarithms

$$L_{\rm cal}=\left\lceil\log_2(6/\zeta)\right\rceil,
\qquad L_{\rm ver}=\left\lceil\log_2(1/\alpha)\right\rceil.$$

An explicit calibration uses $3K$ fresh copies, where

$$K=\left\lceil\frac{41472N}{r\varepsilon}L_{\rm cal}\right\rceil.\tag{C1}$$

It returns a finite dyadic vector $v$ satisfying $N|v|^2\le3$ for every input and every calibration outcome. On the target,

$$\Pr\{N|v-b|^2>\varepsilon\}\le\zeta.\tag{C2}$$

Next form a dyadic upper bound $u$ for $2\sqrt{3\varepsilon}$ with

$$2\sqrt{3\varepsilon}\le u\le2\sqrt{3\varepsilon}+\sqrt\varepsilon,
\qquad \gamma=N|v|^2-1-u.\tag{C3}$$

If $\gamma<g_{\min}$, return “not certified.” Otherwise freeze $v,\gamma$, acquire independent verification copies, and apply the frozen score with anchor $v$ and threshold $-q'\gamma/2$, where $q'=(r-1)/(N-1)$. Put $x=q'\gamma$ and take

$$m=\left\lceil\frac{24\cdot10^9}{x^2}L_{\rm ver}\right\rceil.\tag{C4}$$

The probability of falsely certifying any fully separable null is at most $\alpha\le\eta$, including all calibration outcomes. Target detection probability is at least $1-\eta$ whenever

$$\delta\ge g_{\min}+8\sqrt\varepsilon.\tag{C5}$$

The deterministic total copy cap is

$$3K+\left\lceil24\cdot10^9g_{\min}^{-2}
\left(\frac{N-1}{r-1}\right)^2L_{\rm ver}\right\rceil.\tag{C6}$$

Thus calibration costs $O(N/(r\varepsilon)\log(1/\eta))$ and verification costs $O(g_{\min}^{-2}N^2/r^2\log(1/\eta))$. For a class with a declared gap $\delta\ge\delta_0>0$, choose $g_{\min}=\delta_0/2$ and $\varepsilon\le\delta_0^2/256$ (taking a rational smaller value when necessary). This removes exact supplied $b$ while preserving the mesoscopic rate.

The finite gap floor is an honest additional operational input. A bare liminf promise asserts existence of a positive eventual gap but supplies no numerical margin or onset. One can use successive confidence stages to find a margin without an oracle, but a random stopping/resource guarantee must then be stated separately. No fixed worst-case cap for an unknown margin is claimed by this addendum.

## 2. Calibration tail and count

Use three independent groups of $K$ copies, one for each Pauli axis. In every copy choose a uniform $r$-subset and measure only its $r$ qubits. Let $X_A$ be the sign sum. The raw coordinate mean is

$$w_A=\frac1{Kr}\sum_{k=1}^K X_{A,k},\qquad\mathbb E w_A=b_A.\tag{C7}$$

This mean identity uses the averaged Bloch vector; no permutation invariance is needed for it. The Schur-tail argument in the frozen proof works separately for every unit axis and gives, for $Y=X_A/\sqrt r$,

$$\Pr\{|Y|\ge z\}\le8e^{-z^2/16}.
\qquad\mathbb E e^{Y^2/144}\le2.\tag{C8}$$

The exponential moment follows by integrating the tail: $1+128/(144-16)=2$. Centering costs a factor four in the squared scale. With an independent copy $Y'$ and Jensen's inequality,

$$\mathbb E e^{(Y-\mathbb EY)^2/576}
\le\mathbb E e^{(Y-Y')^2/576}
\le\left(\mathbb E e^{Y^2/288}\right)^2\le2.\tag{C9}$$

For completeness, a centered variable $V$ with $\mathbb E e^{V^2/a}\le2$ obeys

$$\mathbb E e^{\lambda V}\le e^{(3a/2)\lambda^2}
\quad\text{for every real }\lambda.\tag{C10}$$

Indeed $e^t\le1+t+t^2e^{|t|}/2$ and Young's inequality give

$$\mathbb E e^{\lambda V}
\le1+\frac{\lambda^2}2 e^{a\lambda^2/2}
\mathbb E\left[V^2e^{V^2/(2a)}\right]
\le1+\frac2e a\lambda^2 e^{a\lambda^2/2}
\le e^{3a\lambda^2/2}.$$

The middle bound uses $te^{t/2}\le(2/e)e^t$ for $t\ge0$; the last uses $e^z\ge1+z$. Taking $a=576$ and optimizing Chernoff yields

$$\Pr\{|w_A-b_A|>h\}\le2\exp\left[-\frac{Krh^2}{3456}\right].\tag{C11}$$

For $h^2=\varepsilon/(12N)$, (C1) and a union bound give

$$\Pr\{|w-b|>\tfrac12\sqrt{\varepsilon/N}\}\le\zeta.\tag{C12}$$

Only the target uses (C8)–(C12). Under a null there is no assertion about its calibration accuracy; the anchor is clipped for every input and uniform null soundness is proved conditional on whatever anchor results.

## 3. Exact clipping, bit rounding and threshold arithmetic

The three $w_A$ are rational, with denominator $Kr$. Let $R^2=3/N$ and conceptually set $y=P_{B_R}(w)$, Euclidean projection onto the closed ball. Since the true target $b$ belongs to that ball, projection cannot increase the distance to $b$.

Choose the integer $p$ by

$$2^{2p}\ge12N/\varepsilon,\qquad h=2^{-p}.\tag{C13}$$

For each coordinate, round the absolute value of $y_A$ down to a multiple of $h$, retaining its sign. Call the resulting vector $v$. This operation has

$$|v|\le|y|\le R,\qquad |v-y|\le\sqrt3h
\le\tfrac12\sqrt{\varepsilon/N}.\tag{C14}$$

It is computable exactly with integer/rational comparisons, even though $y$ may involve a square root. If $|w|\le R$, ordinary rational division determines the rounding. If $|w|>R$, the largest nonnegative integer $\ell_A$ with $\ell_Ah\le|y_A|$ is found by the rational comparison

$$(\ell_Ah)^2|w|^2\le w_A^2R^2.$$

Binary search therefore produces the dyadic coordinate without assuming exact irrational arithmetic. Equations (C12)–(C14) prove (C2).

To compute (C3), choose $p_\gamma$ with $2^{-p_\gamma}\le\sqrt\varepsilon$, and round $2\sqrt{3\varepsilon}$ upward to that grid, using squared rational comparisons. Then $\gamma$, the score constants, and the rejection threshold are rational. Taking integer upper logarithms in (C1)/(C4) avoids underestimating a copy count from rounded transcendental values.

The actual test can avoid exponentials entirely. Let $V_A=2^pv_A\in\mathbb Z$. For one readout define the integer

$$P=3N(N-1)r2^{2p}(X^2-r)
-6N^2r(r-1)2^pV_AX
+r^2(r-1)\left(N2^{2p}+N^2\sum_A V_A^2\right).\tag{C15}$$

Then $T=P/D$ with $D=N(N-1)r^2 2^{2p}$. Stream the integer sum of the $P$ values and compare it against the rational threshold $-mxD/2$. All decisions can be exact integer comparisons after clearing denominators. The bounded effect remains the one in the frozen proof; the physical implementation retains ordinary local signs and accumulates the polynomial score.

## 4. Root gap formula, target gate and null soundness

For any frozen anchor $v$, the target identity is exactly

$$\mathbb E_\rho T_v=q'\left[1-N|b|^2+N|v-b|^2\right],
\quad\delta_{\rm eff}=N|b|^2-1-N|v-b|^2.\tag{C16}$$

This independently confirms the requested gap formula. Equivalently,

$$\delta_{\rm eff}=N|v|^2-1+2N(b-v)\cdot v.$$

On (C2), $N|v|^2\le3$ implies $\delta_{\rm eff}\ge N|v|^2-1-2\sqrt{3\varepsilon}\ge\gamma$. Also

$$N|v|^2\ge N|b|^2-2\sqrt{3\varepsilon},\quad
\gamma\ge\delta-(4\sqrt3+1)\sqrt\varepsilon
\ge\delta-8\sqrt\varepsilon.\tag{C17}$$

Thus (C5) guarantees that the gate opens and that the target mean is at most $-x$. The target score retains the same exponential moment bound as before. Although $v$ may not equal $b$, its clipped norm gives $|\mathbb E T_v|\le5$; combining this bound with $\mathbb E e^{|T_v|/1000}<2$ again gives $\mathbb E|T_v-\mathbb ET_v|^k\le2k!2000^k$. The same completeness exponent $\exp[-mx^2/(256\cdot10^6)]$ follows.

For any nonidentical product null with averaged Bloch vector $a$ and $Q=N^{-1}\sum|a_i|^2$, regardless of how calibration behaved,

$$\mathbb E T_v=q'\left[1-Q+N|a-v|^2\right]\ge0.$$

The frozen null mgf proof needs only $N|v|^2\le3$, not accuracy of $v$ or a Schur promise on the null. Conditional on the entire preliminary data, therefore, every separable null obeys the verification bound with the selected $v,\gamma,m$. Calibration and verification are fresh independent groups under the iid input model. Averaging the conditional soundness gives unconditional soundness at most $\alpha$. On the target, union of calibration failure and verification failure is at most $\zeta+\alpha=\eta$.

## 5. Streaming storage and charged readouts

Calibration uses $3Kr$ individual readouts, verification at most $m_{\max}r$. Calibration keeps three signed integer sums, each at most $Kr$ in magnitude, requiring $O(\log(Kr))$ bits per sum. The anchor has three dyadic coordinates with $p=O(\log(N/\varepsilon))$ bits of denominator precision. The streamed verification numerator in (C15) needs

$$O(\log m+\log N+\log r+p)$$

bits; no readout history is required. A selected uniform subset can be drawn by a standard exact uniform sampler and stored using $O(r\log N)$ temporary bits, in addition to a running sign sum using $O(\log r)$ bits. A direct sequential sampler scanning the $N$ labels uses $O(N)$ classical random/comparison steps per copy and this same storage bound; faster uniform samplers are optional. Axis choice needs at most two unbiased bits with rejection of the fourth label. Computational counts are therefore explicit, without hiding a Schur transform or collective quantum gate.

## 6. Common measurement frame and axis precision

An unknown common orthonormal frame causes no error: calibration and verification refer to the same three axes, the Bloch vector is expressed in that frame, and $J^2$ is invariant under its common rotation. The target need not be rotationally invariant. There is no requirement to know the absolute laboratory orientation.

A quantified common nonorthogonality error can also be handled. Suppose each of the three actual unit directions $n_A$ is the same across selected qubits and across calibration/verification, and a deterministic certified bound is known:

$$G=\sum_A n_A n_A^{\mathsf T},\qquad
\|G-I\|_{\rm op}\le e\le1/10.\tag{C18}$$

Now let $b_*=(n_A\cdot b)_A$ be the three measured coordinates. Clip and round the anchor into the ball of squared radius $3(1+e)/N$; the same calibration tail and count apply. Use the corrected score

$$T^{(e)}_v=T_v+q'e.\tag{C19}$$

For a product null set $a_i^*=(n_A\cdot a_i)_A$, so $Q_*\le1+e$. The exact expectation is

$$\mathbb E T^{(e)}_v=q'[1+e-Q_*+N|a_*-v|^2]\ge0.\tag{C20}$$

The same null mgf constants remain valid: $N|v|^2\le3.3$, $c^2v_A^2/r\le1.65$, $d/r\le2.15$, $q'e\le0.05$, and the completed-square constant lies between $-7.95$ and $-0.8$. Thus the lower bound $-8$, the fourth-moment constant $4000$, and the three-axis large-field argument all survive unchanged. Conditional sign sampling still obeys (7) because every $n_A$ is unit.

Let $B$ be the real symmetric global spin second-moment matrix, $B_{kl}=\frac12\langle(2J_k)(2J_l)+(2J_l)(2J_k)\rangle$. It is positive semidefinite with $\operatorname{tr}B=3N$. Hence

$$d_G=\frac{\operatorname{tr}(GB)-3N}{N},\qquad |d_G|\le3e.$$

The exact target gap for (C19) is

$$\Delta=N|b_*|^2-1-N|v-b_*|^2-d_G-e
\ge N|v|^2-1-2\sqrt{3(1+e)\varepsilon}-4e.\tag{C21}$$

Use a rational upward rounding $u_e$ of $2\sqrt{3(1+e)\varepsilon}$ with error at most $\sqrt\varepsilon$, and replace the gate by

$$\gamma_e=N|v|^2-1-u_e-4e.\tag{C22}$$

The same null bound and target tails apply with threshold $-q'\gamma_e/2$ whenever the positive gate is reached. If necessary cap the gate above by $1$, ensuring $q'\gamma_e\le1$. The target is guaranteed to reach $g_{\min}$ if

$$\delta\ge g_{\min}+7e+9\sqrt\varepsilon.\tag{C23}$$

Indeed $N|b_*|^2\ge(1-e)N|b|^2$, so its gap is at least $\delta-3e$, while two anchor-error contributions cost at most $4\sqrt{3(1+e)\varepsilon}+\sqrt\varepsilon\le9\sqrt\varepsilon$. Every actual unit-axis global sum still has magnitude at most $2j$, so the target concentration proof remains valid. Taking, for example, $g_{\min}=\delta_0/4$, $e\le\delta_0/28$ and $\varepsilon\le\delta_0^2/1296$ leaves at least this margin for a class with $\delta\ge\delta_0$.

If each $n_A$ is within Euclidean distance $h_A$ of some fixed orthonormal reference $e_A$, then $\|G-I\|\le2\sum_A h_A$ by the rank-one projector estimate. In particular $h_A\le e/6$ suffices. This is a deterministic common-axis precision requirement; obtaining a metrological certificate for it has a separate experimental cost. Uncontrolled drift between calibration and verification, qubit-dependent readout axes, stochastic outcome errors, and detector bias are outside this extension.

## 7. Copy assumptions

The complete two-error statement is for iid fresh inputs, as requested. Soundness actually extends to a sequential model in which, conditional on all previous classical data, each next measured $N$-qubit copy is fully separable: the bounded e-value has conditional expectation at most one. To keep a conditional soundness statement with a random calibration-selected stopping time, freeze the anchor and the verification horizon before verification, or use the e-value product threshold directly. Merely knowing unconditional separability of each copy does not establish this conditional premise when copies carry cross-copy quantum correlations. No extension to arbitrary cross-copy states is asserted.

Status: finite analytic reconstruction. Confidence, rounding and integer-streaming details are proved above. Experimental axis calibration cost, external validation, formal validation and novelty are UNKNOWN or out of scope, as specified.
