# Adversarial centered-theorem audit

**Verdict: the frozen theorem passes this internal proof audit under its exact interface.** I reconstructed

`chi_P^2(rho_r || rho_1^tensor r) <=34992(r/N)^2`

and `D_rel<=log(1+chi_P^2)<=34992(r/N)^2` for `1<=r<=N/128`, for arbitrary permutation-invariant `N`-qubit states with exactly white Schur weights and arbitrary positive trace-one within-sector states. No failing mathematical line or counterexample to this theorem was found. See `INDEPENDENT_RECONSTRUCTION.md` for the proof and operational access channel.

The target hash is `e652080b59e07a58fa091f2e7b769c14376d49f90482cf6fc227a38cd80c7e2a`; the frozen prerequisite hash is `6a80aa93ea2097a34d2338b9327cca75378c30e0532d98e8e8b4eaae1d8d1645`. I started from the blinded artifact and its own prerequisite. The thermal proof and the candidate's verification scripts were not read. This is a proof-visible adversarial reconstruction, not a blind audit, external validation, formal replay, priority search or evidence from independent agreement.

## Load-bearing checks

* **Complex Gram / Parseval (frozen lines 61–95): valid.** With the conjugate-linear-first inner product and `R=delta sigma^{-1}`, the dual coefficients are exactly `Tr(A_S^dagger delta)`, and Parseval uses `d^dagger(G^{-1})^tensor k d`. The local eigenvalues are `1-t,1+t,1-t^2`. Different supports are orthogonal. The one-site term is genuinely zero because the reference is the actual one-body state. There is no hidden global inverse-norm factor.
* **Shifted Hilbert-Schmidt norm (103–128): valid.** The binomial shift expansion, distinct-degree orthogonality and factorial ratio give `4^k/C(N,k)`. Exact rational diagnostics check the normalizations independently.
* **Polynomial grid and white-weight transfer (132–165): valid.** The degree bound follows from the collective recurrence. Markov's inequality and the unit grid spacing yield the stated `36k^2` factor for integer and half-integer spin, with `j=0` handled separately. The crucial identity is `p_j/(2j+1)=m_j/2^N`; a mean-spin promise alone does not supply it. Arbitrary sector coherences are covered by the operator norm.
* **Sphere contractions (171–183): valid.** The tensors are real and symmetric. A pairing with `s` internal pairs in either copy contracts to a nonnegative squared Frobenius norm of `Tr^s d`. There are `k!` fully cross pairings. Exact signed, nontraceless tensor fixtures verify the complete contraction identity through order seven.
* **Finite sizes and constant (185–205): valid.** For `r>=2`, `N>=256` gives `t<1/9` and `x<=9/256`. The rational derivative bound is exactly `7381975040/487010951<16`, producing `34992`. For `r=1`, `N>=128` separately proves reference full rank, and the state/reference difference is exactly zero.
* **Entropy (209–219): valid without commutation.** The overlap eigenbasis weights form a probability law, and scalar Jensen gives the claimed Petz-order-two comparison. Zero eigenvalues of the tested state have zero weight. Only the reference must be invertible; its support is established above.

I independently downloaded the cited [Harris author PDF](https://www.ms.uky.edu/~larry/paper.dir/proof.pdf), obtained the same SHA-256 `808c2de21fcc4cb6ca9b254270f8d8996d445a1d4e92e30588054675125c692b`, and visually checked Theorem 1 on page 3. Its real scalar, first-derivative specialization supplies the needed Markov inequality.

## Independent diagnostics and counterexamples to invalid variants

`check_independent.py` is newly written for this audit and imports no candidate code. It passed 138 exact direct shifted-HS identities, 52 exact white-sector trace identities, 125 exact shifted bound checks, 28 exact sphere contraction fixtures, 56 numerical grid-leverage searches, and eight numerical quantum marginal cases in the legal range at `(N,r)=(256,2),(384,3),(512,4),(1024,4)`. The large-`N` states are explicitly supplied by Schur-sector pure vectors; local states are reconstructed from their collective polynomials. The matrices retain complex sector superpositions and have positive local spectra. These are diagnostic fixtures, not a proof covering all states.

The largest numerical Parseval residual was `5.83e-19`. A legal noncommuting case had commutator norm `1.91e-5`; using the real covariance inverse gave a different result, with discrepancy `2.10e-7` in that case. An exact small white-weight example independently isolates the same error: `tau=diag(3/4,1/4)` and `rho_2=tau^tensor2-(sigma_x^tensor2)/16` have true Petz chi-square `1/9`, whereas the real-Gram replacement gives `1/16`. This is a counterexample to that invalid substitution, not to the candidate, which uses the correct complex Gram.

## Operational scope and charging

The fresh-preparation result is valid for certifiers sound on **all fully separable global states**. The null is `rho_1^tensor N`, and the independent-input trace bound survives arbitrary joint processing of the exposed marginals. For classically adaptive physical-site selection, the report now has an explicit CPTP simulation: permutation symmetry of the unvisited sites lets each newly visited physical site be assigned the next canonical quantum slot. At most `r` distinct sites per preparation and at most `m` independent fresh preparations therefore reduce to one channel on `rho_r^tensor m`, applied identically to the product null. Joint instruments and retained quantum memory are covered.

Under that access and null contract, errors `alpha,beta` with `alpha+beta<1` require

`m >= log(1+4(1-alpha-beta)^2)/log(1+34992(r/N)^2)`.

For **`r=1`, certification is exactly impossible for every finite number of fresh preparations**: the two input states are identical, including under adaptive routing and joint measurements. The loose finite lower bound should not be presented as the strongest conclusion at this endpoint.

The all-separable-null condition cannot be dropped. If white sector weights or `<J^2>=3N/4` are trusted restrictions on the null class, the product reference is generally outside that class when `b!=0`. The exact `N=256` highest-weight construction has `b=0.09592657577046836...>1/16`, while every separable state with that trusted moment has `|b|<=1/16`; one-body data can therefore certify it under the restricted promise. `promise_null_counterexample.json` records an exact rational inequality. This is the candidate's stated qualifier, confirmed rather than repaired away.

Charge `m` fresh **global** preparations, hence `mN` prepared physical qubits. The interface permits at most `mr` distinct-site exposures, and repeated instruments/gates cost additional work. Do not infer an actual total-read lower bound from `m` unless the per-preparation read counts are specified. Global operations touching unvisited sites, coherent global-address access, acquisition of the sector promise, and unbounded stopping rules are not silently identified with this access channel.

## Status and next decisive gate

The centered theorem and stated all-separable-null consequence are internally reconstructed and adversarially reviewed. The finite diagnostics and source identity checks reinforce scoped normalization/provenance only. The full thermal derivation, any dynamical acquisition of these weights, external correctness, historical novelty and optimality of `34992` remain outside this audit.

No mathematical repair is required for the central theorem. The useful next gate is specialist or proof-assistant validation of this exact centered statement and its Gram/sector-transfer proof, followed by primary-source novelty checking. Preserve the exact white-weight premise and the null/access contracts in any manuscript or claimed application.
