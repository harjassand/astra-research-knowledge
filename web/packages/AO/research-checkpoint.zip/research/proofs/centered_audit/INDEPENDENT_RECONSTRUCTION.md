# Centered white-sector theorem: reconstructed proof and access channel

The frozen target is `CENTERED_REPORT.txt`, SHA-256 `e652080b59e07a58fa091f2e7b769c14376d49f90482cf6fc227a38cd80c7e2a`. I read the centered report and its own chi-square prerequisite, then reconstructed the steps below. I did not read the thermal derivation or the candidate's verification code. This audit is not blind with respect to the target proof and is not formal or external validation.

## 1. Input and support

Let `N,r` be positive integers, `1<=r<=N/128`, and let the permutation-invariant state have blocks `p_j rho_j tensor I_mj/m_j`, with `rho_j>=0`, `Tr rho_j=1` and exact white weights `p_j=(2j+1)m_j/2^N`. No restriction to coherent, pure, diagonal or thermal sector states is needed.

The normalized white trace gives `Tr(omega_N J^2)=3N/4`, so the weights fix `Tr(rho_N J^2)=3N/4`. Permutation invariance gives `b=2<J>/N`, hence `t^2=|b|^2<=3/N`. For `r>=2` the range forces `N>=256`, and `3/256<1/81`, so `t<1/9`. For `r=1`, `N>=128` and `t^2<=3/128<1`, which also proves that `tau=rho_1` is strictly positive. Thus all inverses in the stated range exist, including the case that was treated separately in the candidate's numerical estimate.

## 2. Complex Gram and Parseval, with order verified

Use the complex operator inner product `<U,V>_tau=Tr(tau U^dagger V)`, conjugate-linear in its first entry. For `A_a=sigma_a-b_a I`,

`G_ab=Tr(tau A_a A_b)=delta_ab-b_a b_b+i epsilon_abc b_c`.

The Gram matrix is Hermitian, not real symmetric. With `b=(0,0,t)` its `xy` block is `[[1,it],[-it,1]]` and its `zz` entry is `1-t^2`. Its eigenvalues are `1-t,1+t,1-t^2`, so `G >= (1-t)I >0`.

Products of `I,A_x,A_y,A_z` on different sites form a complex basis. Different supports are orthogonal because `Tr(tau A_a)=0`; the Gram block on a size-`k` support is `G^tensor k`. Each such basis operator is Hermitian, since its nonidentity factors occupy distinct sites. Its expectation is therefore real. Site-permutation invariance makes the coefficient tensor `d_k` symmetric.

Let `sigma=tau^tensor r`, `delta=rho_r-sigma`, and **right-multiply** `R=delta sigma^{-1}`. Direct cyclic trace identities give

`<R,R>_sigma = Tr(delta^2 sigma^{-1})`,

`<E,R>_sigma = Tr(sigma E^dagger delta sigma^{-1}) = Tr(E^dagger delta)`.

If `R=sum E_a c_a` in a Gram block, its coefficient vector satisfies `d=Gc`; hence its squared norm is `c^dagger Gc=d^dagger G^{-1}d`. This establishes the candidate's exact Parseval convention; no commutation between `rho_r` and `sigma` is required.

The constant coefficient is zero by trace normalization; all one-site coefficients are zero because `tau` is the actual one-body marginal. The exact formula is consequently

`chi_P^2 = sum_{k=2}^r C(r,k) d_k^dagger (G^{-1})^tensor k d_k`

`<= sum_{k=2}^r C(r,k)(1-t)^{-k} ||d_k||_F^2`.       (A)

Replacing `G` by its real covariance part is invalid. An exact permutation-invariant **white-weight** two-qubit example is

`tau=diag(3/4,1/4)`, `rho_2=tau tensor tau-(sigma_x tensor sigma_x)/16`.

Both `2x2` positivity blocks have positive determinant `1/32`. The singlet weight is `1/4`, so its two spin weights are precisely white. The state does not commute with its product reference. Its only centered degree-two coefficient is `d_xx=-1/4`. The correct chi-square is `1/9`; the real-Gram inverse would give `1/16`. This example is outside the final `r<=N/128` range, but the Parseval identity is an algebraic statement valid there as well. Numerical diagnostics also exhibit this mismatch in admissible large-`N` examples.

## 3. Shifted polynomial norm and exact white transfer

For real unit `u`, let `Q_i=u.sigma^(i)`, `beta=u.b`, and let `B_l` be the average of the `l`-site products of `Q_i`. Counting each subset inclusion gives exactly

`B_k^cent = sum_{l=0}^k C(k,l)(-beta)^{k-l} B_l`.

Under `omega_N=I/2^N`, distinct subset products are orthogonal, so the distinct-degree `B_l` are orthogonal and have squared norm `1/C(N,l)`. Therefore

`Tr(omega_N (B_k^cent)^2)=sum_l C(k,l)^2 beta^{2(k-l)}/C(N,l)`.

For `m=k-l`, use `beta^2<=3/N` and

`C(N,k)/C(N,l) <= N^m l!/k!`.

After multiplying each summand by `C(N,k)`, its upper bound is `C(k,m)3^m/m!`. Summing and dropping `1/m!<=1` proves

`Tr(omega_N (B_k^cent)^2)<=4^k/C(N,k)`.             (B)

For `E_l=C(N,l)B_l`, multiplication by `S=sum_i Q_i=2J_u` gives

`S E_l=(l+1)E_{l+1}+(N-l+1)E_{l-1}`.

Thus the shifted observable is a real degree-at-most-`k` polynomial of `J_u`. Its eigenvalues in spin `j` are polynomial evaluations at unit-spaced magnetic values `-j,...,j`.

The grid estimate is valid also at `j=0` and at half-integer `j`. If `j<4k^2`, the grid cardinality is at most `9k^2`, which directly bounds the maximum by that times the average. Otherwise Markov's derivative inequality on `[-j,j]` is `||P'||<=k^2||P||/j`. At a continuous maximum, an intersected interval of length at least `j/(2k^2)>=2` has absolute polynomial value at least half that maximum. Any such interval contains at least `j/(4k^2)` grid points. It follows that

`max_grid P^2 <=16k^2(2j+1)/j * mean_grid P^2 <=36k^2 mean_grid P^2`.

I independently downloaded Harris's cited author PDF, checked the file identity, and visually inspected Theorem 1 on PDF page 3. With real scalar spaces and derivative order one it supplies exactly the needed classical Markov bound; the degree parameter is `k`, and rescaling introduces `1/j`.

For arbitrary positive trace-one `rho_j`, `|Tr(rho_j B_j)|<=||B_j||`. Weighted Cauchy-Schwarz and the grid estimate give

`|Tr(rho_N B_k^cent)|^2 <=36k^2 sum_j p_j Tr_spin((B_k^cent)_j^2)/(2j+1)`.

The last sum is **exactly** the normalized full Hilbert-Schmidt norm in (B): `p_j/(2j+1)=m_j/2^N`. This transfer is the load-bearing use of the full white weights. It would not follow from the single mean-spin moment alone. Arbitrary within-sector coherences remain covered by the operator norm.

## 4. Sphere contractions and the numerical constant

The diagonal polynomial of the real symmetric tensor is `f_k(u)=d_k:u^tensor k=Tr(rho_N B_k^cent(u))`. The sphere moment formula in dimension three divides the sum over pairings by `(2k+1)!!`. Pairings with `s` internal pairs in the first tensor must have exactly `s` internal pairs in the second; their contraction is `||Tr^s d_k||_F^2`. Their number is

`C(k,2s)^2 ((2s-1)!!)^2 (k-2s)!`.

Every term is nonnegative. In particular, `s=0` contributes `k!||d_k||_F^2`, so

`E_sphere f_k^2 >= k! ||d_k||_F^2/(2k+1)!!`.

Combining this with (B), the grid transfer and (A), and using `C(r,k)/C(N,k)<=q^k`, gives

`chi_P^2 <=36 sum_{k=2}^infinity k^2 (2k+1)!! x^k/k!`,

where `x=4q/(1-t)<1/2`. The generating function is `(1-2x)^(-3/2)`. Twice applying `x d/dx` and removing its degree-one coefficient `3x` gives

`chi_P^2 <=108x[(1+3x)/(1-2x)^(7/2)-1]`.          (C)

For `r>=2` in the requested range, `x<=9q/2<=9/256`. The derivative of `g(x)=(1+3x)/(1-2x)^(7/2)` is `(10+15x)/(1-2x)^(9/2)`. On that interval,

`g'(x) <= (10+135/256)(128/119)^5 =7381975040/487010951 <16`.

The mean-value estimate `g(x)-1<=16x` in (C) proves

`chi_P^2 <=1728x^2 <=34992q^2`.

For `r=1`, `delta=0` exactly. No finite-size exception or inverse-support gap remains.

## 5. Noncommuting entropy and trace bounds

Let eigenpairs of `rho,sigma` be `(lambda_i,|i>)`, `(mu_j,|j>)`, with `sigma>0`. The numbers `lambda_i|<i|j>|^2` are probability weights. Jensen applied to the positive ratios `lambda_i/mu_j` proves

`D(rho||sigma) <= log sum_{ij}lambda_i^2|<i|j>|^2/mu_j`

`=log Tr(rho^2 sigma^{-1})=log(1+chi_P^2)<=chi_P^2`.

Zero eigenvalues of `rho` have zero weight and can be omitted. The expansion `Tr((rho-sigma)^2 sigma^{-1})=Tr(rho^2 sigma^{-1})-1` follows by cyclic trace, not by assuming commutation.

For Hermitian `delta`, choose its unitary sign `V`. In the same weighted operator inner product, `<V,R>_sigma=Tr(V delta)=||delta||_1` and `||V||_sigma^2=Tr sigma=1`. Cauchy-Schwarz proves `D_trace<=sqrt(chi_P^2)/2`, again without commutation.

## 6. Classical adaptive physical access is a valid channel

Fix the following access contract: the protocol receives at most `m` independent fresh preparations of the same `N`-qubit state; on each preparation its instruments touch at most `r` **distinct physical sites**, chosen by classical outcomes/randomness. Instruments may act jointly on any already exposed sites, freshly selected sites and arbitrary retained memory. Final processing may be joint across preparations. No operation touches the still-unexposed sites. Repeated access to an exposed site is permitted and is simulated on its retained quantum slot; repeated instrumental operations have their own execution cost.

For each classical history, relabel the first newly touched site as slot 1, the next as slot 2, and so on. A new batch of sites is assigned the next slots. This is a state-independent simulation rule. Inductively, the unnormalized conditional global state is invariant under every permutation of unvisited sites: the initial state is permutation-invariant, and all instruments so far act only on visited sites and memory. Thus any selected fresh physical sites have the same conditional joint state as the next unused canonical slots, while fixing the already visited slots. The simulator executes precisely the same local/joint instrument and emits the same address/history records.

It follows that the entire protocol, including classical control and outcomes, is a CPTP map `Lambda` acting on the fixed input `rho_r^tensor m`. The same map simulates it on the symmetric comparator `tau^tensor N`, using input `(tau^tensor r)^tensor m`. Reduction to the fixed marginal commutes with tracing out all untouched global qubits. This also covers joint instruments across different preparations and adaptive copy scheduling with a fixed maximum `m`.

This argument does not identify a coherent global-address query, a collective operation touching unvisited sites, or an unbounded random stopping rule with the stated finite marginal budget. A measurement that physically couples to all `N` spins is an `N`-site operation even when its observable is expressed using sums of few-body terms.

## 7. Certification and its charged scope

Petz chi-square multiplies before the channel:

`1+chi_P^2(rho_r^tensor m||(tau^tensor r)^tensor m)=(1+chi_P^2(rho_r||tau^tensor r))^m`.

Trace distance contracts through `Lambda`. A binary certifier with false-positive/false-negative errors `alpha,beta` against a fixed alternative and this null requires input trace distance at least `d_*=1-alpha-beta>0`. The necessary lower bound is therefore

`m >= log(1+4d_*^2)/log(1+34992(r/N)^2)`

`>= [log(1+4d_*^2)/34992] N^2/r^2`.

For `r=1`, the actual input states are identical for every finite `m`; thus **no protocol in this access model can have `alpha+beta<1`**, not merely a finite quadratic lower bound.

The comparator is globally fully separable. The certification implication requires soundness on **all fully separable global states**, so that it must remain a valid null. If exact white sector weights or the global spin moment are trusted restrictions on the null, this comparator is generally excluded when `b!=0`. Indeed its spin moment exceeds `3N/4` by `N(N-1)t^2/4`.

The scope failure is concrete: separable states satisfy `<J^2> >=N/2+|<J>|^2`, hence under the white moment they satisfy `|b|<=1/sqrt(N)`. At `N=256`, the white-weight highest-sector-vector state has `b=0.09592657577046836...>1/16` (the inequality is verified with exact rational weights). With that trusted global promise, one-body polarization can certify it. This does not contradict the all-separable-null impossibility because the matching product state is outside the promised null class.

The lower bound charges fresh global preparations: each preparation contains `N` physical qubits, so `mN` qubits are prepared. The access interface allows at most `mr` distinct-site exposures; if all blocks use their full quota, there are `mr` such exposures. A lower bound on `m` alone is not automatically a lower bound on actual total reads when preparations use different numbers of sites. Gate costs, repeated reads, acquisition of the exact sector promise and preparation dynamics are not made free or bounded by this information inequality.
