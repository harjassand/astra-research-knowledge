# Conditional geometry and whole-group transfer

This derivation separates the geometric premise of the family252 complex from the residual-kernel premise. The new arguments below are ordinary mathematical reconstructions, not formal or external validation. Source priority and the correctness of the entire inherited candidate remain UNKNOWN.

## A. Hypotheses and convex label trees

Let K be the compact family252 triangle complex with vertices O,V,W and, for each label i, edges x_(i,u,v):V→W, 1≤u,v≤r. Assume the specified block construction and incidence deletion have the following independently established consequences:

1. K has a piecewise hyperbolic CAT(-1) metric, with each triangle's angles 27π/50 at O and 9π/50 at V,W.
2. Distinct directions corresponding to two x-edges with the same label i have distance at least 14·9π/50>π in each of the V and W metric links.

These are statements about the actual complex, not just abstract girth statistics. The source's local incidence maps, lines146–159, give their combinatorial input; the piecewise metric link theorem then gives (1).

Let Θ_i⊂K comprise V,W and all x_(i,u,v) edges. Give its edges their induced lengths. Every reduced turn in this graph has link length greater than π in K. Thus Θ_i→K is a local isometry (at edge interiors this is immediate). By the CAT(0) local-isometry theorem, π₁Θ_i→π₁K is injective and the induced map of universal covers is an isometric embedding. An isometric embedded geodesic tree in a CAT(-1) space is convex: its intrinsic geodesic is also the ambient geodesic, which is unique.

Therefore H_i≅π₁Θ_i≅F_(r²−1). Its universal cover T_i is a convex tree in X=K̃ and H_i acts cocompactly on it. Since G=π₁K acts geometrically on X, the orbit of H_i is quasiconvex in X. The orbit quasi-isometry and the hyperbolic Morse lemma give quasiconvexity in a Cayley graph of G.

No residual-finiteness or nonsoficity premise was used in A.

## B. Malnormal family

Fix the lift T_i of Θ_i through a chosen lift of V. Its stabilizer in G is exactly H_i by covering-space theory. Distinct components of the preimage of the same Θ_i are disjoint. Trees for different labels have no common edge, because their edges project to differently labelled x-edges. Each is convex; hence two such trees intersect in at most one point. Otherwise the geodesic between two common points would be a nontrivial segment in both trees, containing an edge interior in each.

Suppose 1≠h∈H_j∩gH_i g⁻¹. On both T_j and gT_i, h is a nontrivial deck transformation of a metric tree covering a finite graph, and it has a translation axis. Those axes are ambient geodesic axes in X. CAT(-1) gives uniqueness of the axis for h (two distinct axes would produce a flat strip). Hence T_j∩gT_i contains an entire line. The intersection observations force i=j and gT_i=T_i, so g∈H_i. Thus {H_i} is a malnormal family.

This proof uses strict negative curvature, convexity, and the actual embedding of the graph. General local-convexity/malnormality results, including Cerocchi–Sambusetti Proposition C.1, are known precedent; this is not a claim of a novel malnormality theorem.

## C. Rectangles are primitive

For fixed i and u≠u′,v≠v′, write e₁=x_(i,u,v), e₂=x_(i,u′,v), e₃=x_(i,u′,v′), e₄=x_(i,u,v′). These are four distinct edges. The rectangle is

    w=e₁ e₂⁻¹ e₃ e₄⁻¹.

Choose e₄ as the spanning tree edge of Θ_i. A free basis consists of z_e=e e₄⁻¹ for all other edges e. Cancellation gives

    w=z_(e₁) z_(e₂)⁻¹ z_(e₃).

The map replacing z_(e₁) by z_(e₁)z_(e₂)⁻¹z_(e₃) while fixing the other basis elements is an automorphism: its inverse replaces z_(e₁) by z_(e₁)z_(e₃)⁻¹z_(e₂). Therefore w is primitive. It is nontrivial in H_i, hence in G by A. This proof also makes its nontriviality independent of the original local-geodesic rectangle argument.

## D. Explicit quasiconvex index-two subgroups

For an edge e of Θ_i, count occurrences of e, in either orientation, modulo2 in graph loops. Free cancellation changes the count by an even number, so this defines θ_e:H_i→C₂. It is surjective: e f⁻¹ has odd e-parity for any different edge f. Set J_e=ker θ_e.

An explicit graph cover for J_e has vertices V₀,V₁,W₀,W₁. Each edge other than e joins V_s to W_s; the two lifts of e join V_s to W_(s+1 mod2). This connected two-sheeted cover has 2r² edges and4 vertices, hence fundamental-group rank2r²−3. Since J_e has index2 in quasiconvex H_i, it is quasiconvex in G.

Assume now a rectangle w satisfies the separate premise:

    w≠1 in G, and ρ(w)=1 for every homomorphism ρ:G→finite group.

For each of its four edges e, θ_e(w)=1, so w∉J_e. But ρ(w)=1∈ρ(J_e) for every finite quotient. Consequently no finite quotient separates w from J_e, so each of these four explicitly defined subgroups is nonseparable. They are distinct: for e≠f one may choose a third edge a and use e a⁻¹, whose e-parity is1 and f-parity0. The construction has at least four edges.

If the source establishes instead that w is killed by every map to every sofic group, the same failure holds for all such homomorphisms. The source's finite-product argument chooses some rectangle from a finite list existentially; it does not identify which particular i,u,u′,v,v′ after all incidence data are materialized. No concrete selected w is claimed here.

Quasiconvex-subgroup separability for hyperbolic virtually special groups would exclude this situation in that class. K has not been proved virtually special, cubulated, or covered by a separability theorem. CAT(-1) alone supplies no such theorem. The family252 source thus has no contradiction from that result as presently stated.

## E. Entire torsion-free hyperbolic group embeds in a Kazhdan hyperbolic group

**Statement.** Let G be torsion-free hyperbolic and let P be torsion-free non-elementary hyperbolic with property (T). Then there exists a torsion-free non-elementary hyperbolic quotient K of L=G*P such that:

1. G→K is injective and its image is quasiconvex and malnormal.
2. P→K is surjective, so K has property (T).
3. Every quasiconvex subgroup of G has quasiconvex image in K.

The existence of P is a classical independent input (for example a torsion-free cocompact lattice in Sp(2,1)); the present derivation does not construct its lattice presentation or reprove property (T).

**Smallness.** L is torsion-free hyperbolic; Q=G is a quasiconvex subset and F=P is non-elementary. For every a,b∈L the set P∩aGb has at most one element. Indeed, if p₁≠p₂ belong to it, then

    p₁p₂⁻¹∈P∩aGa⁻¹.

Distinct free factors have trivial intersections even after conjugating one factor. This follows from the Bass–Serre tree: P fixes its P-vertex, aGa⁻¹ fixes a G-vertex of a different type, and an element fixing both fixes the path between them; edge stabilizers are trivial. Hence p₁p₂⁻¹=1, a contradiction. Since Q⁻¹Q=G, for finite A,B⊂L the intersection P∩A Q⁻¹Q B has size at most|A||B|. Infinite P is not contained in it. Thus Q is small relative to F, exactly in Minasyan's definition.

**Application of the 2005 theorem.** In a torsion-free hyperbolic L, any non-elementary subgroup P is an L-subgroup in the sense of the 2005 paper: E(P)=E(L)={1}, and the conjugation indices in Lemma1.1 are both1. Theorem1 applied to H₁=P and Q=G gives an epimorphism η:L→K with η(P)=K, injective/isometric on G, preserving quasiconvex subsets of G, centralizers and conjugacy on G. Its finite-order conjugacy-class bijection ensures K is torsion-free; its first conclusion makes K non-elementary hyperbolic. Property (T) passes to quotients, giving (2). The free factor G is malnormal in L; preserved conjugacy and centralizers give malnormality of η(G) by the 2021 Lemma2.8.

**Equivalent application of the 2021 theorem.** Use Theorem2.6 with U any finite generating set {u₁,…,u_n} for G. The output imposes u_j w_j=1 with w_j∈P. Thus η(u_j)=η(w_j)⁻¹∈η(P), so η(G)⊂η(P) and K=⟨η(G),η(P)⟩=η(P). The theorem supplies injection, quasiconvexity, torsion-freeness, hyperbolicity, centralizers and conjugacy; Lemma2.8 gives malnormality. This handles explicitly the fact that Theorem2.6 itself does not promise surjectivity on F for an arbitrary choice of U.

If G is nonsofic, so is K: otherwise its subgroup η(G) would be sofic. If w≠1 in G is killed by every map from G to a sofic group, η(w)≠1 and is killed by every map from K to a sofic group, by restriction. Statements A–D survive inside K (malnormality is transitive for a malnormal subgroup inside a malnormal subgroup, and quasiconvexity is transitive here).

**Scope and novelty.** This is a published Minasyan transfer applied to a free product, not a new construction theorem. N65 already obtains conditional hyperbolic property-(T) quotients preserving a finite list of rectangles, and further Tarski quotients. The conclusion here preserves all of G and its quasiconvex geometry. It does not remove the original family252 proof obligation, show property (T) for original G, or show that K has a two-dimensional CAT(-1) presentation. Exact corollary priority is UNKNOWN.
