# Algebra first bounded report — 2026-10-08

**Status: reconstructed conditional consequences; original candidate UNKNOWN.** Source handling is `source=DATA`. No formal replay, independent expert review, or external certification was obtained. The repository was read at commit `687dfc0640ee80654bcbdbe38cb13d6e1f1586ce` and was not edited.

The source triage did not produce an exact contradiction to the corrected positive-characteristic or entropy premises. The most useful attack was therefore a line-by-line reconstruction of the family252 incidence geometry. I found no failing premise in that reconstruction. It yields a precise geometric consequence, followed by a published embedding transfer that preserves the entire candidate group. Neither settles the original nonsoficity claim.

## 1. Exact geometric consequence of the incidence construction

Assume the family252 complex is constructed as specified in `construction.tex`, including the incidence girth and block hypotheses, and its CAT(-1) link bounds have been established. For label i, let Θ_i be the two-vertex graph consisting of V,W and the r² parallel edges x_(i,u,v). Then:

* H_i=π₁Θ_i embeds as a quasiconvex free subgroup of G=π₁K, of rank r²−1.
* The subgroups H_i form a malnormal family.
* Each nondegenerate four-edge rectangle is a primitive element of H_i.
* For each edge e of Θ_i the parity homomorphism θ_e:H_i→C₂ gives an explicit index-two quasiconvex free subgroup J_e of rank 2r²−3.
* If a rectangle w is nontrivial in G and is killed by every map from G to a finite group, the four J_e corresponding to its four edges are not separable in G. If the strengthened nonsofic rank conclusion holds, the same w is killed by every map to any sofic group.

This is more precise than the inherited statement that G is not residually finite: the obstruction lies in a primitive element of a specific malnormal quasiconvex free subgroup, and yields explicit finite-index free subgroups with failed separability. It is **conditional on the source construction and residual obstruction**. No incidence table, concrete prime, selected rectangle, or complete presentation was materialized. The statement is not an unconditional construction of a new nonsofic group. Priority for this particular extracted consequence is UNKNOWN; the local-convexity and malnormality mechanisms are classical.

The detailed proof is in `derivation.md`, sections A–D. The strongest applicable no-go is quasiconvex subgroup separability for hyperbolic virtually special groups. The source does not establish cubulation or virtual specialness, so that theorem does not yield a contradiction. Merely being a compact CAT(-1) triangle complex is insufficient for applying those hypotheses.

## 2. Published transfer preserving the whole candidate

For any torsion-free hyperbolic group G and any fixed torsion-free non-elementary hyperbolic group P with Kazhdan property (T), Minasyan's published theorem gives a torsion-free non-elementary hyperbolic property-(T) group K containing G as a malnormal quasiconvex subgroup. Every quasiconvex subgroup of G remains quasiconvex in K. A nonsofic G forces a nonsofic K because soficity passes to subgroups. A nontrivial w killed by all maps G→sofic groups remains nontrivial and is killed by all maps K→sofic groups.

The application uses L=G*P, Q=G, F=P. Smallness follows because each P∩aGb contains at most one element, so no finite union of aGb contains infinite P. The 2005 Theorem 1 directly gives a quotient surjective on P, injective on all G, preserving conjugacy and centralizers on G. The 2021 Theorem 2.6 instead imposes relators u_j w_j for a generating set of G, which also ensures that the image of P is the whole quotient. Lemma 2.8 preserves malnormality. Details are in `derivation.md`, section E.

This is a **standard published transfer**, with an elementary application reconstructed here. N65 already records a conditional property-(T) quotient preserving a finite rectangle set, and a further torsion-free Tarski quotient. Thus existence of a conditional property-(T) nonsofic group is not new to the repository. The refinement here preserves the *entire group G* and its quasiconvex subgroup geometry, rather than only selected words. Priority for a separately stated general corollary is UNKNOWN. The underlying Minasyan theorem is not newly proved or externally certified here.

## Source premise attack and findings

The primary family252 span is the pinned original [`construction.tex`](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/build/sections/construction.tex). Local lines 55–77 give incidence sampling, low-degree and short-cycle deletion, and the strict rank gap. Lines 84–112 give the block decomposition and triangle indexing. Lines 146–159 give local injections of V,W links into the punctured incidence graph. Lines 164–174 identify rectangle loops. Lines 185–231 give exact rank reduction and permutation moments; lines 239–288 give tensor interpolation and rank bounds; lines 289–296 perform the finite-product rectangle argument.

The local-injectivity concern is resolved: at an L_(b,u,j) direction and fixed label i, α_b(i)+v=j has at most one solution v; at an x_(i,u,v) direction and fixed point z, i belongs to a unique block and j is determined. A reduced closed link walk therefore maps to an internally nonbacktracking incidence walk. Even if its final/initial directions backtrack at the seam, the walk contains a simple cycle, giving length at least 14. Paths between distinct x-directions with the same label are covered by the same argument. No geometric contradiction was found.

The chosen hyperbolic triangle angles (27π/50,9π/50,9π/50) satisfy the source h=20 construction: O-link cycles have length at least 4 and V,W-link cycles at least 14, so all metric link loops exceed 2π; same-label turns exceed π. These bounds support A–D. They must not be transferred to an h=5 source without independently checking its parameters.

The exact rank mechanism was read and reconstructed to the extent of its interface: a positive strict gap Δ=Nr/4−2m−r|E| is opposed by approximate-permutation error terms r²(S_inc δ+Nλ/8), which vanish as the relator and nontrivial-rectangle defects δ,λ vanish. The Hadamard/prime-rank argument does not require D to be nonzero modulo q. The original construction and complete robust proof still require adversarial or formal verification. A complete proof, not a finite graph fixture or same-context agreement, is the decisive remaining obligation.

## Corrected algebra/entropy triage

N165 and the corrected audit supersede the stale session index. Formanek's noetherian theorem and trace-positivity theorem apply in characteristic zero. Burger–Valette Lemma 4.1 in characteristic p proves restricted trace values under absence of p-torsion and conjugacy to p-power iterates; it does not prove that a trace-zero idempotent is zero. BLR's printed all-fields assertion is stronger than the cited original premises reconstructed so far. Its rational K₀ theorem also has an additional stable-finiteness/characteristic-zero/sofic alternative. This is a citation/proof-scope discrepancy, not an established counterexample to direct finiteness.

For a supplied ab=1≠ba over F_q[G], r=1−ba remains a nonzero idempotent of trace zero. The corrected entropy consequence is 0≤h_sup^Rok(G)≤(1−1/|supp r|)log q. It does not force zero without an additional vanishing rank-density argument. The kernel is a mixing finitely-dependent algebraic factor; it has not been established Bernoulli. These currently unresolved gates were not replaced by the geometric transfer above.

## Primary sources and read depth

* Family252 original construction: full 296-line source read; incidence/link and rank interfaces reconstructed, no materialized instance or formal replay.
* Minasyan, *On residualizing homomorphisms preserving quasiconvexity*, [author PDF](https://www.personal.soton.ac.uk/am4x07/rs/gsbgps_f.pdf), 2005, Theorem 1 pp.2–3, Lemma 1.1 p.2 and remarks p.3: exact statement read; 42-page proof not replayed. Local PDF SHA256 `242e2d655d4fd13cfc2c0fa5458c423eb269814f3f10e66c22656a0e49f3098e`.
* Minasyan, *Some examples of invariably generated groups*, [author PDF](https://www.personal.soton.ac.uk/am4x07/rs/invar_gen.pdf), Theorems 2.6–2.7 p.5–6, Lemma 2.8 p.6: exact statements and local proofs read; elementary application reconstructed.
* Bridson–Haefliger, *Metric spaces of non-positive curvature*, [author-hosted PDF](https://webhomes.maths.ed.ac.uk/~v1ranick/papers/bridsonhaefligerx.pdf), II.4.13–II.4.14 pp.201–202 and link criteria II.5.2–II.5.6 pp.206–207: exact theorem spans read, not entire book proof replay.
* Cerocchi–Sambusetti, *Entropy and finiteness of groups with acylindrical splittings*, [journal PDF](https://ems.press/content/serial-article-files/30038), Proposition C.1, appendix C p.39: known malnormality precedent read. It precludes a novelty claim for that geometric mechanism.
* Burger–Valette, *Idempotents in complex group rings: theorems of Zalesskii and Bass revisited*, [author PDF](https://people.math.ethz.ch/~burger/pub/1998_Idempotents.pdf), Lemma 4.1 and Proposition 4.2: relevant characteristic distinction read; complete PDF downloaded.
* Bartels–Lück–Reich, [primary PDF](https://www.mi.fu-berlin.de/math/groups/top/members/publ/blr-appl.pdf), Theorem 0.12 printed p.8 and idempotent discussion printed p.9: exact statements read. No alleged characteristic-p proof was reconstructed from the characteristic-zero originals.

Bounded novelty searches for Minasyan/property-(T)/quasiconvex/malnormal embedding found adjacent published embedding and quotient results; they did not establish priority for this precise corollary. Non-primary search hits were not relied on as theorem evidence. Existing N65 was compared directly. Novelty, external review, and formal validation remain UNKNOWN.

## Resources and next decisive action

Local analytic derivation only; no training, cloud compute, exhaustive incidence graph, numerical floating-point evidence, or uncharged large matrix was used. Source PDF acquisition and storage are recorded in `source_manifest.json`; the Formanek download timed out and is retained as a failure. The existence proof's astronomical finite objects and Minasyan quotient relators were not acquired, and no cost bound for materializing them is claimed.

The next decisive action is an independently audited proof of the original family252 incidence/link and robust rank construction, preserving its quantifiers and characteristics. If that survives, A–D and the published transfer apply. If it fails, neither the source nonsofic claim nor its transferred examples should be promoted. A direct-finiteness conclusion would additionally require its own original ring witness and entropy gates; this report supplies neither.
