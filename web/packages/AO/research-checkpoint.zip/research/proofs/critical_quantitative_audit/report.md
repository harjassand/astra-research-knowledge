# Adversarial quantitative audit: critical isotropic Curie–Weiss

**Verdict: PASS of the stronger quantitative claims for the exact stated Gibbs
model, at the level of an argument-exposed internal mathematical reconstruction.**
No theorem-breaking inequality or counterexample to the exact model was found.
This is not formal verification, independent external review, historical
priority validation, or a claim that the supplied Gibbs preparation is free.

Frozen source: `work/agents/curie_weiss/CRITICAL_PROOF_FROZEN.md`, SHA-256
`55a256b8a7d90573bed614c844a3bbb3734cb4c0886a82716afe18b281467b07`.
The source was preserved byte-for-byte; its snapshot is in this audit folder.
No integration comments or independent critical-model report were read before
the verdict was frozen. The audit had access to the target's argument.

## Exact scope of acceptance

For rho_N proportional to exp(2J²/N) on the **full N-qubit tensor space**,
the one-body marginal is white. As N tends to infinity:

| Claim | Target lines | Audit result |
|---|---:|---|
| For every sequence 2<=r=o(sqrt N), chi_r ~ mu_2² r(r-1)/(6N) | 24–30, 169–181 | Reconstructed from exact pair tensor and uniform weight>=4 tail |
| In that range, half trace distance Theta(r/sqrt N), KL Theta(r²/N), with absolute constants for bounded/growing r | 187–217 | Bounded heat effect reconstructed; no use of chi lower alone |
| Nonvanishing trace and KL at each positive crossover, and all three vanish iff r=o(sqrt N) | 22–32, 219–224 | Valid by a small fixed crossover marginal and subsequence argument |
| If r/sqrt N->infinity, full trace norm ->2 | 228–246 | Actual r-site magnetization threshold reconstructed; works through r=N |
| In that range, KL Theta(r/sqrt N) | 250–272 | Binary rare-event lower bound plus uniform entropy upper reconstructed |
| For bounded r/sqrt N, KL bounded | 261–272 | Follows uniformly from D_r<=(r/N)D_N and D_N/sqrt N->mu_2/2 |
| Conservative finite small-window bound | 40–46, 155–165 | Constants and applicability checked; no practical finite-size guarantee inferred |

Here chi is Petz chi-square to I/2^r, delta is **half** trace norm, D uses
natural logarithms, and mu_2=sqrt12 Gamma(5/4)/Gamma(3/4).
For r=1 all three distances are exactly zero. No sharp KL constant or full
crossover profile has been established or claimed.

## Load-bearing issues attacked

**Schur/Stirling and parity.** The spin multiplicity, full tensor dimension,
tilt (M²+2M)/(2N), parity spacing 2/N^(3/4), both central prefactors, outer
Chernoff region, lower partition function and exponential-square moment
were rederived. The quartic envelope provides uniform polynomial moment
tails. Compact asymptotics alone would not justify the conclusion, but the
source supplies the missing uniform tail estimate. Both parity offsets work.

**Complex/real support conventions.** The real Pauli tensors are symmetric
by permutation invariance and real because distinct-site observables commute.
The polynomial uses a complex scalar without requiring expectation
factorization. White Gram inverse is 2I in the sigma/sqrt2 basis. Cauchy,
real polarization and Parseval give the advertised 168e² constant. Odd
degrees vanish by a rotation sending each directional H to -H, followed by
polarization. This is what makes the leading pair coefficient uniformly
sharp even at fixed r.

**Bounded heat effect.** I supplied the deleted-tail calculation omitted from
the source's short prose: it is exactly 1335/32768<1/16. The coefficient
-kappa/(r-1), the pair gap -kappa*r*c_N/2, the factor in half trace distance,
and the high-support remainder all check. The fixed-r=2 marginal was also
computed directly. The floor in line 224 is best written as a liminf bound,
or with a smaller constant; its existing asymptotic conclusion has a strict
margin and is unaffected. This is a rounding clarification, not a failing
line in the theorem.

**Above-window witness.** The latent all-site count is used only to express
the r-site marginal law; it is not an extra physical read. Conditional
hypergeometric noise need not be independent of the global magnetization.
Weak convergence to a zero-atom-free law controls the shrinking interval.
The r=N endpoint has zero conditional sampling noise. Trace saturation
does not by itself give the stated growing KL lower bound; the separate
white rare-event bound in Section 8 does.

**Entropy transfer.** Strong subadditivity on overlapping subsets gives
2S_k>=S_(k-1)+S_(k+1). Decreasing entropy increments imply S_r/r>=S_N/N,
including when later increments are negative. The resulting upper bound
D_r<=(r/N)D_N uses one N-dependent error for all r. The exact Gibbs
formula and log Z_N=O(log N) prove D_N/sqrt N->mu_2/2. No restriction
r/N->0 is hidden in this step.

Full details are in `INDEPENDENT_PROOF.md`.

## Fresh finite diagnostics and their limits

`check_critical.py` was written without inspecting the source diagnostic code.
All assertions passed for N=256,257,512,513,4096,4097,16384,16385,65536,65537,
1048576,1048577 and for nine white heat laws with r from 2 through 4096.
It evaluates exact combinatorial formulas in floating point, checks the
finite envelopes, central Stirling ratios, normalization, moment bound,
fixed-r=2 full marginal, and actual global-r=N bounded event probabilities.
This is neither interval arithmetic nor a theorem proof; the analytic
reconstruction above carries the unbounded-N claims.

For N=1048576, sqrt N*c_N=0.8529309645 versus limiting mu_2/3=0.8540959383;
the exact two-body chi divided by its predicted leading term is 0.9972738911.
D_N/sqrt N=1.2702611116 versus limiting mu_2/2=1.2811439074. The displayed
above-window threshold effect has finite expectation gap 0.8630920393;
this finite diagnostic does not claim saturation is already complete.
The adjacent odd N gives the same trends. Detailed output is
`verification_results.json`.

The parent separately reported replaying the script in an isolated copy.
Its first harness lacked the required proof-hash dependency; after providing
that file, the assertions passed. That is a parent-reported harness issue,
not a mathematical assertion failure and not new independent theorem proof.

## Concrete false extension and operational boundary

`INDEPENDENT_PROOF.md` constructs eta_N=(1-epsilon)omega_N+epsilon
Pi_sym/(N+1), epsilon=mu_2/sqrt N. It has the same limiting pair coefficient
and critical Casimir mean scale as the audited Gibbs law, yet every local
half trace distance is <=epsilon->0, even at r=N. At r=ceil(2log_2 N),
chi diverges while both trace and KL tend to zero. Thus neither the critical
pair/Casimir mean nor a chi lower bound can replace the exact Gibbs-tail
assumption. This is a counterexample to a tempting extension, not to the
frozen theorem. The mixture is itself separable, reinforcing the source's
target-versus-white scope.

The effects need r one-site product readouts from the same supplied N-qubit
Gibbs preparation, plus classical pooling/calibration. One fresh preparation
per observation and all r exposed sites are charged. Measuring M or the
unexposed N-r sites is not part of the actual protocol. Preparation, model
acquisition, temperature error, and systematic effects remain unsolved
input costs. The result is not entanglement certification against all
separable nulls.

**Next decisive action:** external expert criticism or formal verification
of the exact mathematical proof, and a separately specified physical
preparation/error model if operational claims are pursued. Independent
agent agreement and finite replay do not supply either validation.
