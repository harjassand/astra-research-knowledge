# Sharp local window at the isotropic qubit Curie–Weiss critical point

Thermal scientific lead, 8 October 2026. This is an internally reconstructed proof candidate, frozen before comparison with any independent critical-model derivation. The parent/integration supplied the critical radial-law and bounded-witness route as shared suggestions. The exact finite envelope, support estimates, leading Petz term and trace/KL regimes below were derived here. Historical priority, external correctness and formal validation are UNKNOWN. No entanglement conclusion is asserted.

## 1. Exact statement and conventions

Let J=(1/2) sum_i sigma^(i), let

    rho_N=exp(2 J^2/N)/(2^N Z_N),
    Z_N=2^-N Tr exp(2 J^2/N),
    omega_r=I/2^r,
    rho_{N,r}=Tr_{N-r} rho_N.

The one-body marginal is exactly I/2, by SU(2) invariance. Thus omega_r is exactly the centered product reference. Write

    chi_r=Tr(rho_{N,r}^2 omega_r^-1)-1,
    D_r=D(rho_{N,r}||omega_r),
    delta_r=(1/2)||rho_{N,r}-omega_r||_1,
    a_N=r/sqrt(N),
    mu_2=sqrt(12) Gamma(5/4)/Gamma(3/4).

For every integer sequence 1<=r<=N:

1. Each of chi_r, D_r and delta_r tends to zero if and only if r=o(sqrt(N)). For r=1 they are identically zero. Along every sequence r>=2 and r=o(sqrt(N)),

       chi_r = [mu_2^2 r(r-1)/(6N)](1+o(1)),
       delta_r = Theta(r/sqrt(N)),
       D_r = Theta(r^2/N).

   The Theta constants can be taken absolute, independently of whether r is bounded or growing.

2. If liminf r/sqrt(N)>0, then liminf delta_r>0 and liminf D_r>0. If r/sqrt(N) stays bounded, D_r stays bounded. This gives the nonvanishing critical crossover; no full finite-a crossover profile is claimed.

3. If r/sqrt(N)->infinity, then delta_r->1, equivalently the full trace norm tends to 2, and

       D_r=Theta(r/sqrt(N)).

   These conclusions include r comparable to N and r=N.

The upper small-window theorem also has an explicit finite range. Constants defined in Section 2 obey, for N>=256, r<=N/2 and

    r/sqrt(N)<=1/(1344 e^2),

the bound

    chi_r, D_r <=2 A_0^2 (672 e^2)^2 r^2/N.

These conservative constants establish a uniform theorem, not a practical experiment. Preparation of each N-qubit Gibbs state is an input resource; nothing here supplies it at no cost.

## 2. Exact critical Schur law and a uniform quartic envelope

Put M=2j, with M>=0 and parity M=N mod 2. If S_N is the sum of N independent unbiased signs, the white Schur weight is exactly

    w_N(M)=2(M+1)^2/(N+M+2) Pr(S_N=M).

This follows from the multiplicity

    m_N(M)=binom(N,(N-M)/2)-binom(N,(N-M)/2-1)
          =2(M+1)/(N+M+2) binom(N,(N-M)/2)

and the spin dimension M+1. The Gibbs sector blocks remain maximally mixed. At beta=2 define

    g_N(M)=w_N(M) exp[(M^2+2M)/(2N)],
    p_N(M)=g_N(M)/Z_N,
    x=M/N^(3/4), u=M/N.

For 0<=u<=1 set

    I(u)=((1+u)log(1+u)+(1-u)log(1-u))/2.

Its nonnegative series gives

    I(u)-u^2/2 >=u^4/12,
    I(u)-u^2/2 <=u^4/[12(1-u^2)]<=u^4/9   (u<=1/2).

The last bound uses that every coefficient after the quadratic is at most 1/12. Chernoff gives Pr(S_N=M)<=exp[-NI(u)] at every legal M. The elementary factorial Stirling bounds give, for N>=256 and u<=1/2,

    (1/(2 sqrt(N))) exp[-NI(u)]
       <=Pr(S_N=M)<= (2/sqrt(N)) exp[-NI(u)].

For example apply sqrt(2 pi n)(n/e)^n <=n!<=sqrt(2 pi n)(n/e)^n exp(1/(12n)) to N!/(k!(N-k)!), with k,N-k>=N/4. This gives the displayed, deliberately weaker constants.

For u<=1/2 the quadratic exponential cancels exactly, and

    g_N(M)<=14(1+x^2) exp(-x^4/12).

For u>1/2, M>=1 and the Chernoff bound instead gives

    g_N(M)<=8e x^2 sqrt(N) exp(-x^4/12)
            <=200 x^2 exp(-x^4/24).

Indeed x^4>=N/16 and sqrt(N) exp(-N/384)<=9 for N>=256. Therefore the global envelope is

    g_N(M)<=200(1+x^2) exp(-x^4/24).                 (2.1)

On x in [1,2], u<=1/2 for N>=256. The lower Stirling bound and denominator N+M+2<=2N give g_N(M)>=exp(-16/9)/2. There are at least N^(3/4)/3 legal parity points in this interval. Consequently

    Z_N>=exp(-16/9) N^(3/4)/6,
    p_N(M)<=C_0 N^(-3/4)(1+x^2) exp(-x^4/24),
    C_0=1200 exp(16/9).                             (2.2)

The same estimates supply an explicit exponential-square moment. Let

    I_0=[48^(1/4) Gamma(1/4)+48^(3/4) Gamma(3/4)]/4,
    A_0=C_0 exp(1/192)(I_0/2+8).

Young's inequality x^2/48-x^4/24<=-x^4/48+1/192, and the unimodal function (1+x^2)exp(-x^4/48) has supremum at most 4. Its parity-grid sum, multiplied by N^(-3/4), is at most its integral/2+8: a mesh-rectangle error is at most two mesh lengths times the supremum, and the mesh is 2/N^(3/4)<=2. Thus

    E_p exp(X_N^2/48)<=A_0,   X_N=M/N^(3/4),
    E_p exp(s X_N)<=A_0 exp(12s^2)   (s real).      (2.3)

The second line follows from s x<=x^2/48+12s^2, and also bounds E exp(|s|X_N).

## 3. Limiting radial law and moments

Stirling on every compact x-interval yields, uniformly there,

    g_N(M)->2 sqrt(2/pi) x^2 exp(-x^4/12).

Here NI(u)=M^2/(2N)+M^4/(12N^3)+O(M^6/N^5); the additional tilt M/N tends to zero on compact x-intervals. The mesh is 2/N^(3/4). The uniform envelope (2.1) controls the tails of the Riemann sums and of all fixed polynomial moments. It follows that

    Z_N/N^(3/4)->sqrt(2/pi) I_2,
    I_2=int_0^infinity x^2 exp(-x^4/12) dx
       =12^(3/4) Gamma(3/4)/4,
    X_N => X,   f_X(x)=x^2 exp(-x^4/12)/I_2   (x>=0),
    E X_N^k ->mu_k=12^(k/4) Gamma((k+3)/4)/Gamma(3/4)

for every fixed k>=0. In particular mu_2 is as in Section1. All limiting and uniform-tail claims have thus been derived from the exact finite Schur weights, not from an informal saddle-point substitution.

## 4. Entire-polynomial control of all local supports

The previously frozen general concentration proof is used only as an algebraic lemma; its full support and polarization argument is reproduced in the following specialization. Choose T_a=sigma_a/sqrt(2), a=1,2,3, so Tr(T_a T_b)=delta_ab. The centered basis is T_a itself and its white complex Gram is G=I/2.

For a real unit u, H=sum_a u_a T_a has norm at most one. More generally a one-site Hermitian H with norm at most one has H-Tr((I/2)H)I=h dot sigma with |h|<=1. The centered collective sum has absolute eigenvalues at most M in every spin-M/2 block. Equation (2.3) therefore proves

    Tr rho_N exp[t sum_i(H_i-Tr((I/2)H)I)]
       <=A_0 exp(12 N^(3/2)t^2).

For F_u(z)=Tr rho_N product_i(I+zH_i), diagonalizing the same-axis commuting site operators gives

    |F_u(z)|<=exp(2N|z|^2)
                Tr rho_N exp[(Re z)sum_i H_i]
             <=A_0 exp(L_N |z|^2),
    L_N=2N+12N^(3/2)<=14N^(3/2).

The loose 2N is sufficient; no expectation factorization is made. With C_k the real symmetric support tensor of the T_a,

    [z^k]F_u(z)=binom(N,k) C_k[u,...,u].

Cauchy at |z|^2=k/(2L_N) gives

    sup_|u|=1 |C_k[u,...,u]|^2
      <=A_0^2 [k!/(N)_k]^2 exp(k)(2L_N/k)^k.

Exact real polarization bounds every coordinate by k^k/k! times this directional supremum; there are 3^k coordinates. Weighted support Parseval conditions each support by G^-1=2I. Using binom(r,k)<=r^k/k!, (N)_k>=N^k(1-r/N)^k and k^k/k!<=e^k shows

    weight_k(chi_r)<=A_0^2 q_N^k,
    q_N=168 e^2 r/[sqrt(N)(1-r/N)^2].             (4.1)

All degree-one supports are zero. Moreover every odd support tensor is zero: SU(2) rotation takes H to -H, so its odd diagonal homogeneous polynomial is zero; real polarization then kills every tensor entry. For q_N<1,

    chi_r<=A_0^2 q_N^2/(1-q_N),
    chi_(weights>=4)<=A_0^2 q_N^4/(1-q_N).        (4.2)

The second bound also uses the absent odd degrees. For r<=N/2, q_N<=672 e^2 a_N. The finite range in Section1 makes q_N<=1/2 and proves its explicit upper. Since the reference is white, scalar Jensen gives D_r<=log(1+chi_r)<=chi_r directly.

## 5. Exact two-body tensor and the leading Petz coefficient

SU(2) and permutation invariance force

    Tr rho_N sigma_a^(i) sigma_b^(j)=c_N delta_ab   (i!=j),
    c_N=[E_p M(M+2)-3N]/[3N(N-1)].

The normalization follows from J^2=3N/4+(1/2)sum_{i<j}sum_a sigma_a^(i)sigma_a^(j). Section3 gives

    sqrt(N)c_N ->mu_2/3.

The weight-two contribution is exactly 3 binom(r,2)c_N^2. Since all other nonzero supports have weight at least four, (4.2) proves, for every r>=2 with a_N->0,

    chi_r=3 binom(r,2)c_N^2+O(a_N^4)
         =[mu_2^2 r(r-1)/(6N)](1+o(1)).

This also gives chi_r>=3 binom(r,2)c_N^2 for every r; consequently chi cannot vanish outside the stated window. A Petz lower bound alone would not prove the trace or KL crossover. Those require the following bounded measurements.

## 6. A bounded heat witness closes trace and KL below and at the window

Measure sigma_z on r sampled sites and set J_{R,z}=(1/2)sum_i X_i. The implementable effect

    W_r=exp(-J_{R,z}^2/r),    0<=W_r<=I,

is equivalent to accepting a classical coin with this probability after the product readout. For white input put Y=J_{R,z}^2/r and

    T_r=E_white exp(-Y), q_r=E_white Y exp(-Y),
    kappa_r=T_r-4q_r=-4 Cov_white(Y,exp(-Y)).

For every r>=2, kappa_r>=kappa_*=exp(-12)/8>0. Here is the finite proof, also present in the earlier frozen heat derivation: EY=1/4, EY^2<=3/16, EY^3<=15/64 and Var(Y)>=(1/16). For an independent Y',

    kappa_r=2 E[(Y-Y')(exp(-Y')-exp(-Y))].

E(Y-Y')^2>=1/8; removing Y>12 or Y'>12 costs at most 1/16, using (Y+Y')^2 and the displayed third moment. On the retained region the exponential divided difference is at least exp(-12). The displayed lower bound follows. Also kappa_r<=1, and the binomial CLT gives kappa_r->sqrt(2/3)/3 as r->infinity.

The white Pauli coefficient of W_r on any z,z pair is exactly

    Tr(omega_r W_r sigma_z^(1)sigma_z^(2))
       =(4q_r-T_r)/(r-1)=-kappa_r/(r-1).

This is obtained by multiplying by sum_{i!=j} X_i X_j=4J_{R,z}^2-r and using exchangeability. The target's constant term equals the white one. Its weight-two term and Cauchy-Schwarz against all higher supports therefore give the exact estimate

    Tr(rho_{N,r} W_r)-Tr(omega_r W_r)
       =-kappa_r r c_N/2+R_N,r,
    |R_N,r|<=A_0 q_N^2/sqrt(1-q_N)   (q_N<1).    (6.1)

The effect has white Hilbert-Schmidt norm at most one, so the last inequality follows from (4.2), without bounding any unbounded observable. When a_N->0 and r>=2, the negative leading term has magnitude at least a fixed positive constant times a_N, while R=O(a_N^2). Since delta_r is the maximum expectation gap of a bounded effect,

    delta_r>=|Tr((rho_{N,r}-omega_r)W_r)|=Omega(a_N).

Together with delta_r<=(1/2)sqrt(chi_r), this proves delta_r=Theta(a_N). Pinsker D_r>=2 delta_r^2 and (4.2) prove D_r=Theta(a_N^2). No leading KL constant is claimed from the Petz expansion.

For clarity the same witness proves nonvanishing at every fixed positive crossover size, even though our conservative upper constant only permits a small finite a. Let L=672e^2 and select a fixed epsilon>0 satisfying

    epsilon<=1/(2L),
    epsilon<=kappa_* mu_2/[48 sqrt(2) A_0 L^2].

At k=floor(epsilon sqrt(N)), c_N>=mu_2/(6sqrt(N)) for all sufficiently large N. Equation (6.1) then has a strictly positive limiting absolute gap, since its leading lower bound is kappa_*mu_2 epsilon/12 and its remainder upper bound is sqrt(2)A_0 L^2 epsilon^2. If liminf r/sqrt(N)>0, reduce epsilon further to fit k<=r. Trace distance and KL decrease under discarding sites, so the same positive lower holds at r. Along any sequence for which r/sqrt(N) does not tend to zero, this argument applies on a subsequence. It proves the claimed if-and-only-if statements for trace and KL.

## 7. Above the window: a magnetization threshold makes the full trace norm tend to 2

Let S=2J_z be the outcome of the hypothetical all-site z readout. Conditional on M, S is uniform on -M,-M+2,...,M, because every spin block is maximally mixed. Section3 and Riemann sums in S/M imply

    Y_N=S/N^(3/4) => Y=XU,

where U is independent uniform[-1,1]. This limit has no atom at zero: X has the continuous positive-axis density of Section3, and U is continuous. Its density, if desired, is

    f_Y(y)=(1/(2I_2)) int_|y|^infinity x exp(-x^4/12) dx.

The hypothetical all-site measurement is used only to describe the distribution; the actual protocol exposes r sites. Permutation invariance makes their measured bitstring uniform conditional on the global count S, so the measured L_r=sum_{i=1}^r X_i is exactly a hypergeometric sample. Its moments are

    E(L_r|S)=rS/N,
    Var(L_r|S)=r(N-r)/(N-1)(1-S^2/N^2)<=r.

Consequently Z_r=L_r/sqrt(r)=sqrt(a_N)Y_N+E_N, with E(E_N|S)=0 and E(E_N^2|S)<=1. If a_N->infinity, let T_N=a_N^(1/4). Chebyshev gives

    Pr_target(|Z_r|<=T_N)
      <=Pr(|Y_N|<=2 T_N/sqrt(a_N))+1/T_N^2 ->0.

The limit follows from weak convergence and the absence of a zero atom; the threshold for Y_N tends to zero. Under omega_r, Var(Z_r)=1 and thus Pr_white(|Z_r|>T_N)<=1/T_N^2->0. The bounded threshold effect 1_{|Z_r|>T_N} therefore has expectation gap tending to one. This proves delta_r->1 using only r product readouts and classical pooling on the same preparation.

## 8. The KL rate above the window and a global upper at every r

Fix any delta>0 for which p=Pr(|Y|>2delta)>0; for example delta=1/2 is legal since f_X has positive tails. For a_N->infinity,

    P_N=Pr_target(|Z_r|>delta sqrt(a_N))
          >=Pr(|Y_N|>2delta)-1/(delta^2 a_N) -> p>0,
    Q_N=Pr_white(|Z_r|>delta sqrt(a_N))
          <=2 exp(-delta^2 a_N/2).

The first inequality gives liminf P_N>=p, which is all that is needed; no equality limit for P_N is asserted. Hoeffding's sign-sum bound gives the second. Binary data processing and h(P)<=log 2 yield

    D_r>=P_N log(1/Q_N)-h(P_N)=Omega(a_N).

For the matching upper, strong subadditivity and permutation invariance make the increments S(rho_{N,k})-S(rho_{N,k-1}) decrease with k. Averaging the first r increments gives

    S(rho_{N,r})/r>=S(rho_N)/N,
    D_r<= (r/N)D(rho_N||omega_N).

The exact Gibbs expression and Section3 give

    D(rho_N||omega_N)=2 E J^2/N-log Z_N,
    D(rho_N||omega_N)/sqrt(N)->mu_2/2,
    D_r<=(mu_2/2+o(1)) a_N.                    (8.1)

This proves the upper for arbitrary r<=N, the bounded-KL assertion at finite a_N, and D_r=Theta(a_N) above the window. The entropy normalization is natural logarithms.

## 9. Scope, resources and status

This is target-vs-white discrimination. The null omega_N is fully separable, but detecting this target against white noise is not entanglement certification against all separable alternatives. No entanglement premise or certification theorem follows. The proof requires the exact isotropic Gibbs model at beta=2, permutation invariance and the supplied global preparation; it is not an assertion for arbitrary spin laws with only a Casimir mean.

All lower bounds on trace/KL use effects in [0,1]. The local threshold and heat effects need r one-site product measurements, pooling all same-copy outcomes, and one fresh N-qubit Gibbs preparation per observation. Selecting sites is free by permutation invariance only as an abstract symmetry; r exposed sites are charged. Computing finite white binomial calibration is classical work. Exact Gibbs preparation, temperature/model acquisition, and systematic errors are separate costs not solved here. A threshold's eventual power is not a finite practical precision guarantee.

The proof preserves the general concentration manuscript unchanged. No outside sources have been used as an unstated premise. The exact spin multiplicity, Stirling estimates, polarization, support Parseval, Pinsker, hypergeometric variance and entropy monotonicity are exposed here or in the earlier frozen general/heat derivations. Independent audit and historical priority remain UNKNOWN.
