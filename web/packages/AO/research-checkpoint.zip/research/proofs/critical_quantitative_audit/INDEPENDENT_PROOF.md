# Independent reconstruction of the quantitative critical regimes

Audit target: `work/agents/curie_weiss/CRITICAL_PROOF_FROZEN.md`, SHA-256
`55a256b8a7d90573bed614c844a3bbb3734cb4c0886a82716afe18b281467b07`.
This is an argument-exposed internal audit, not a blind derivation, formal
verification, outside review, or priority claim. No integration comments or
independent critical-model report were read before freezing this reconstruction.

## 1. Exact sector law and uniformity, including both parity lattices

The full tensor space, rather than only its symmetric subspace, decomposes as
spin j=M/2 with multiplicity

    m_N(M)=2(M+1)/(N+M+2) binom(N,(N-M)/2).

The dimension is M+1 and J²=M(M+2)/4. Therefore the normalized critical
sector law is exactly

    p_N(M) = g_N(M)/Z_N,
    g_N(M) = 2(M+1)²/(N+M+2) Pr(S_N=M) exp[(M²+2M)/(2N)].

Every M is nonnegative and has the parity of N. This is the source's formula,
with no missing multiplicity or factor in the Gibbs exponent.

Write x=M/N^(3/4), u=M/N. The rate function has series

    I(u)=u²/2 + sum_{ell>=2} u^(2ell)/[(2ell)(2ell-1)].

Hence u⁴/12 <= I(u)-u²/2 <= u⁴/[12(1-u²)] for u<1. The
quadratic in the Gibbs tilt cancels N u²/2. On u<=1/2, factorial Stirling
gives

    Pr(S_N=M) = sqrt[2/(pi N(1-u²))] exp[-NI(u)] exp(E),
    -1/(12k)-1/(12(N-k)) <= E <= 1/(12N),
    k=(N-M)/2 >= N/4.

For N>=256 these bounds imply the source's weaker prefactors 1/(2sqrt N)
and 2/sqrt N. Its central envelope follows since

    4(M+1)²/N^(3/2) exp(M/N)
      <= 8 exp(1/2)(1+x²) < 14(1+x²).

In the outer region use the Chernoff point bound. Because M>=1,
(M+1)²<=4M² and exp(M/N)<=e, giving

    g_N(M)<=8e x² sqrt N exp(-x⁴/12).

Here x⁴>N/16. The function sqrt N exp(-N/384) decreases for N>=256,
and its maximum there is 16 exp(-2/3)<9; 72e<200. Thus the global bound

    g_N(M)<=200(1+x²) exp(-x⁴/24)

is valid including the endpoint u=1, where the central Stirling formula is
not used. On x in [1,2], u<=1/2, N+M+2<=2N, and the lower prefactor gives
g_N(M)>=x² exp(-x⁴/9)/2>=exp(-16/9)/2. A lattice of spacing
2/N^(3/4), with either offset, has at least N^(3/4)/2-1 >= N^(3/4)/3
points in this interval. This proves the claimed partition-function lower
bound and normalized quartic envelope for both parities.

For fixed compact x, Stirling and the rate series have uniform errors:

    NI(u)=M²/(2N)+x⁴/12+O(N^(-1/2)x⁶),
    M/N=O(N^(-1/4)x),
    g_N(M)=2sqrt(2/pi)x² exp(-x⁴/12)+o(1).

This remains uniform at x=0: (M+1)²/N^(3/2) differs from x² by a
uniformly vanishing quantity. For every fixed power x^k the global bound
has an integrable polynomial-times-quartic envelope. For sufficiently large
x it is decreasing, so its tail lattice sums are bounded by the corresponding
tail integral plus one mesh rectangle. This supplies uniform Riemann-sum
tails; merely pointwise saddle-point asymptotics would not suffice. Consequently

    Z_N/N^(3/4) -> sqrt(2/pi) I_2,
    X_N=M/N^(3/4) => X,
    f_X(x)=x² exp(-x⁴/12)/I_2,
    I_2=12^(3/4) Gamma(3/4)/4,
    E X_N^k -> 12^(k/4) Gamma((k+3)/4)/Gamma(3/4).

The source's moment-generating bound also follows uniformly. In fact
x²/48-x⁴/24 <= -x⁴/48+1/192. The unimodal envelope
(1+x²)exp(-x⁴/48) has supremum below 4. With mesh h=2/N^(3/4),
its normalized lattice sum is at most integral/2+8 using the two-sided
rectangle error and h<=2. Thus E exp(X_N²/48)<=A_0, followed by
E exp(s X_N)<=A_0 exp(12s²). The constants are loose but valid.

## 2. Real support tensors, complex polynomial bound, and the sharp pair term

For a real unit direction choose H=u dot sigma/sqrt2. It is traceless,
Hermitian, and has norm <=1. On spin M/2 the absolute eigenvalues of
sum_i H_i are <=M. The moment bound gives

    Tr rho_N exp(t sum_i H_i)<=A_0 exp(12 N^(3/2)t²).

In F(z)=Tr rho_N product_i(I+zH_i), all site factors commute. In their
joint eigenbasis the diagonal entries of rho_N are nonnegative probabilities.
The scalar inequality

    |1+z lambda| <= exp(Re(z)lambda + |z|² lambda²/2)

holds for real lambda, including a zero left side. It follows from 1+v<=e^v
applied to the squared modulus. This actually gives N|z|²/2 as the
quadratic prefactor; the source's 2N is therefore safe. There is no
factorization of expectations and no assumption that rho_N commutes with
all individual site operators.

Each C_k coordinate is real, since its observable is a product of commuting
Hermitian operators on distinct sites. Permutation invariance makes the
tensor symmetric. Exact real polarization bounds its coordinates by
(k^k/k!) times the diagonal supremum. Cauchy's estimate at
|z|²=k/(2L), L=2N+12N^(3/2), gives

    B_k² <= A_0² [k!/(N)_k]² e^k(2L/k)^k.

The white Gram of sigma_a/sqrt2 is I/2; its inverse is 2I. Hence each
support's chi-square contribution is exactly 2^k sum |C_k|². Summing
the 3^k entries and binom(r,k) supports yields

    weight_k <= A_0² binom(r,k)(12eL)^k k^k/(N)_k²
             <= A_0² [12e²Lr/(N²(1-r/N)²)]^k
             <= A_0² [168e²r/(sqrt N(1-r/N)²)]^k.

SU(2) contains a rotation sending any fixed traceless H to -H. Therefore
every odd diagonal polynomial vanishes; symmetric real polarization implies
every odd tensor entry vanishes. This addresses possible odd or complex
noncommuting conventions: the measured tensor entries concern distinct
sites, and the complex polynomial variable does not make the tensor complex.

For q_N as in the source, chi_(weight>=4)<=A_0²q_N⁴/(1-q_N). In any
sequence r=o(sqrt N), q_N=O(r/sqrt N) and this is O(r⁴/N²), uniformly
in r. The exact two-body coefficient is

    c_N=[E M(M+2)-3N]/[3N(N-1)],
    sqrt N c_N -> mu_2/3,
    chi_(weight2)=3 binom(r,2)c_N².

For r>=2 its leading term is bounded below by a positive absolute multiple
of r²/N, because (r-1)/r>=1/2. Thus the tail divided by the leading
term is O(r²/N)->0, and

    chi_r ~ mu_2² r(r-1)/(6N)

holds for bounded as well as growing r. The finite stated upper bound
follows from r<=N/2 and q_N<=672e²r/sqrt N<=1/2. White scalar Jensen
gives D_r<=log(1+chi_r)<=chi_r.

## 3. A genuinely bounded witness for trace and KL

Let the white sign sum be L and Y=L²/(4r). For W=exp(-Y), its kappa is

    kappa=E exp(-Y)-4E Yexp(-Y)=-4Cov(Y,exp(-Y)).

The exact white moments are

    EY=1/4,
    EY²=3/16-1/(8r),
    EY³=15/64-30/(64r)+16/(64r²),
    Var(Y)=(r-1)/(8r).

For r>=2, E(Y-Y')²>=1/8. The mass of this square removed by Y>12
or Y'>12 is bounded above by

    2*(15/64)*(1/12 + (1/2)/12² + (3/16)/12³)
      = 1335/32768 < 1/16.

To see this, expand (Y+Y')² on Y>12, use independence, and bound
E[Y²;Y>12]<=EY³/12, E[Y;Y>12]<=EY³/12² and
Pr(Y>12)<=EY³/12³. On the retained event the divided difference
of exp(-y) has magnitude at least exp(-12). Therefore
kappa=2E[(Y-Y')(exp(-Y')-exp(-Y))]>=exp(-12)/8.

Exchangeability under white input gives the exact coefficient

    Tr(omega_r W sigma_z^1 sigma_z^2)=-kappa/(r-1).

Only the z,z component of the pair tensor contributes to this diagonal
effect. Its pair expectation gap is therefore -kappa*r*c_N/2. The remaining
gap is at most sqrt(chi_(weight>=4))*sqrt(Tr omega_r W²), and the last
factor is <=1. Thus

    Tr((rho_r-omega_r)W)=-kappa*r*c_N/2+O(r²/N).

For r>=2 and r=o(sqrt N) the leading magnitude is an absolute positive
multiple of r/sqrt N, while the error is smaller by a factor r/sqrt N.
Since 0<=W<=I, delta_r is at least this absolute expectation gap.
Conversely delta_r<=sqrt(chi_r)/2. Pinsker in nats then gives

    delta_r=Theta(r/sqrt N), D_r=Theta(r²/N).

No trace or KL lower bound here is inferred from chi-square alone.

Fixed r=2 provides an exact check. The marginal has singlet eigenvalue
(1-3c_N)/4 and three triplet eigenvalues (1+c_N)/4. Hence

    chi_2=3c_N²,
    delta_2=3|c_N|/4,
    D_2=(1-3c_N)log(1-3c_N)/4 +3(1+c_N)log(1+c_N)/4
       ~3c_N²/2.

This directly validates the claimed orders at the smallest permitted r;
r=1 instead has kappa=0 and all three distances exactly zero, as the source
explicitly states.

At a positive crossover take k=floor(epsilon sqrt N), with epsilon small
enough that the positive linear heat term dominates the quadratic error.
Discarding sites transfers this lower bound to any r>=k. The rounding
in the source's line 224 is harmless: the displayed leading bound can
be read as a liminf, or one can halve its constant. Indeed k/sqrt N->epsilon
and sqrt N c_N->mu_2/3 give a stronger limiting lower bound than the one
displayed. For a sequence that is not o(sqrt N), apply this on a positive
crossover subsequence. This proves the iff statements without demanding
a positive liminf on the full oscillating sequence.

## 4. Above-window trace: control of the actual exposed-site law

The commuting spectral law of J² and J_z gives conditional S=2J_z uniform
on -M,-M+2,...,M. Since X_N=>X with no atom at zero, M diverges in
probability. The conditional grids S/M tend to uniform[-1,1] uniformly
when M tends to infinity. Bounded continuous test functions, first on a
compact X interval and then using the quartic tail, show

    Y_N=S/N^(3/4) => XU,

where U is independent uniform[-1,1]. This limit is continuous, in
particular without a zero atom. Its density is the one displayed in the
source. This latent representation is a mathematical coupling: no physical
measurement of M or all N sites is required by the protocol.

The actual r-site z readout is the marginal of the full z bitstring law.
Its permutation invariance makes the bitstring uniform conditional on S.
Consequently its sign sum L_r obeys

    E(L_r|S)=rS/N,
    Var(L_r|S)=r(N-r)/(N-1)(1-S²/N²)<=r.

Put a=r/sqrt N. Then Z_r=L_r/sqrt r=sqrt a*Y_N+E_N, with
conditional mean zero and conditional second moment <=1 for E_N. No
independence of E_N and Y_N is used. For a->infinity, T=a^(1/4) gives

    Pr_target(|Z_r|<=T)<=Pr(|Y_N|<=2a^(-1/4))+a^(-1/2)->0.

For the shrinking interval, fix any b>0, apply weak convergence to
[-b,b], then let b decrease to zero. Under white input Chebyshev gives
Pr_white(|Z_r|>T)<=a^(-1/2)->0. The bounded event effect has gap
tending to one. Thus delta_r->1, i.e. full trace norm ->2, for every
a->infinity, including macroscopic r and r=N. At r=N the conditional
noise is exactly zero; no r/N->0 approximation occurs.

## 5. KL lower bound and the global-to-subsystem entropy upper

Take fixed d=1/2. Since Pr(|XU|>2d)>0, conditional Chebyshev gives

    liminf Pr_target(|Z_r|>d sqrt a)>=Pr(|XU|>2d)>0.

The corresponding white probability is at most 2 exp(-d²a/2) by
Hoeffding. Binary measurement data processing gives

    D_r>=P log(1/Q)-h(P)=Omega(a).

Only a positive liminf for P is required, not equality of its limiting
probability with the lower bound. Trace tending to one alone would only
give a constant Pinsker bound, so this rare white event is a necessary
additional argument for the stated KL order.

For the upper, let S_k be the entropy of a k-site marginal and S_0=0.
Strong subadditivity applied to two k-site subsets overlapping in k-1
sites gives 2S_k>=S_(k-1)+S_(k+1), by permutation invariance. Thus the
increments decrease. The average of the first r increments is at least
the average of all N increments, even if late increments are negative:

    S_r/r>=S_N/N,
    D_r=r log2-S_r <= (r/N)(N log2-S_N).

The exact Gibbs logarithm yields

    D_N=2E J²/N-log Z_N,
    D_N/sqrt N -> mu_2/2.

The moment limit gives the first term's leading constant, and
log Z_N=(3/4)log N+O(1)=o(sqrt N). Therefore

    D_r <= (mu_2/2+o(1)) r/sqrt N

with one error depending only on N, uniformly for all 1<=r<=N. This
proves bounded KL at finite a and Theta(a) above the window, including
the entire macroscopic range. It does not claim a sharp local KL constant.

## 6. Concrete false extension: critical pair/Casimir mean is insufficient

Let sigma_N be the maximally mixed symmetric-spin state Pi_sym/(N+1),
and, for sufficiently large N, set

    eta_N=(1-epsilon_N)omega_N+epsilon_N sigma_N,
    epsilon_N=mu_2/sqrt N.

This is permutation invariant and SU(2) invariant with one-body marginal
I/2. It satisfies c_N=epsilon_N/3 and
E_eta M²/N^(3/2)->mu_2, matching the leading critical pair coefficient
and Casimir scale. The r-site marginal of sigma_N is exactly
Pi_sym,r/(r+1), for instance by its Haar pure-product representation.
Nonetheless, for every r<=N,

    delta(eta_r,omega_r)=epsilon_N[1-(r+1)/2^r]<=epsilon_N->0,
    chi(eta_r||omega_r)=epsilon_N²[2^r/(r+1)-1].

Thus at r=N the source's strong above-window trace conclusion would
fail if extended to arbitrary laws with the same pair mean. Moreover,
at r=ceil(2 log_2 N), chi diverges like N/log N whereas trace tends
to zero and convexity gives

    D(eta_r||omega_r)<=epsilon_N[r log2-log(r+1)]->0.

This is a concrete obstruction to inferring trace/KL lower bounds from
large chi alone. It does not counterexample the audited exact Gibbs model,
whose quartic tail and uniform support control exclude this rare-sector
mixture. No entanglement certification against all separable nulls follows
from any target-vs-white discrimination statement.
