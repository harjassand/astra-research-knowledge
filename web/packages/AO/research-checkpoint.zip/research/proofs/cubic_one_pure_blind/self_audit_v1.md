# Post-freeze self-audit (before comparative reading)

The frozen proof SHA remains `1957335656b2f66bad72a857c94472467c57991a5dfe348b1d6e76e8e20288dd`. This addendum clarifies an estimate without changing the proof, scope, or blinded inputs. Same-context self-audit is not independent validation.

In §I, the upper part of the B-axis join band deserves an explicit strict-drift argument. When p12,B<0, F_B≤−ηab² and W_A≤W_B. If F_A<0, then ∇W·F≤W_BF_B≤−η′ab². If F_A≥0, use

    ∇W·F=W_B(F_A+F_B)+(W_A−W_B)F_A≤W_B(F_A+F_B).

On a/b∈[1/(2K),1/K], the strict total-loss arrow yields F_A+F_B≤−η_K(a+b)³, and W_B is bounded below. Thus this entire transition band has a uniform negative cubic drift. If p12,B=0, the already stated−ηa²b estimate directly gives the same conclusion on that band. The A-axis join band uses F_A<0,W_A≥W_B, so the same displayed identity immediately bounds it by W_B(F_A+F_B).

Discrete boundary checks: at a=0 a B-conserving02 birth changes the left ellipse by O(1/b), so its b(b−1) propensity costs O(b); at b=0 every enabled30 arrow has ΔA≤−1, giving negative order-a³ drift in the right ellipse, while its finite B-product changes contribute only O(a²). At a=0,1,2 the missing30/21 propensities are exactly zero, rather than approximated. The entropy cases with bounded coordinates use exact finite increments, not singular log0 expressions.

The active-source face enumeration was rechecked: zero21 arrows at normal(1,2) are exactly21→02; zero02 arrows there are02→21 or02→4A. Zero30 and02 arrows at normal(2,3) are30→02 and02→30. The displayed entropy shifts align the aggregate stoichiometric flux including the factor2 for02→4A. Arbitrary lower-source products remain charged through the fixed finite jump bound J.

No chemistry phase2 or chem_explosion_blind proof files were read in this self-audit. Independent correctness, formal/external validation, and priority remain UNKNOWN.
