# Argument-exposed audit of the fresh exactly-one-pure proof

Audit started 2026-10-08 11:59:53 UTC. This is a bounded comparison after reading
the independent fresh proof, not a second blind discovery, external validation,
or a novelty certification. The auditor's original blind proof remains unchanged.
No descendant agents were used.

## Frozen inputs and scope

SHA256 values at the beginning of this audit:

- `../one_pure_fresh/proof_v1.md`:
  `08aa4b0f30d05630616a504e2033f400a858e26bcf104260e276c34ca618c8fa`.
- `../one_pure_fresh/self_audit_v1.md`:
  `f94961db0b68befd9034ccc6c5a68e1bc7a48de1bae6beec82a5a902ab1cb8a5`.
- Auditor's `proof_v1.md`:
  `1957335656b2f66bad72a857c94472467c57991a5dfe348b1d6e76e8e20288dd`.
- Auditor's `self_audit_v1.md`:
  `4941659dad3209932a9deaee8ce66d4d863c65b2531b923a0aeaaebfc04cb648`.
- Xu primary PDF, `../chemistry_priority/sources/xu-2409.05340v2.pdf`:
  `19878242451113a736a44c316664d63ae13036f99cfff5e2c9271e383b286fda`.
- Its extracted text:
  `3f603703a59f53634088e62f92fa51831630bee297719b920b338f8f4e055016`.

The source convention is Xu, [arXiv:2409.05340v2](https://arxiv.org/abs/2409.05340v2),
Definition 4.2, printed page 8: sources of arrows with zero directional increment
are omitted before the maximal essential source test. The mass-action generator
is equation (2.1), printed page 3; the nonexplosion Lyapunov interface is
Proposition 3.5, printed pages 5--6. Full endotacticity is Definition 4.4 on
printed page 8. This audit does not use another chemistry
worker's phase-2 proof.

The target is a finite two-species network, all sources of total order at most
three, nonidentity source 3A present, source 3B absent, arbitrary finite integral
nonnegative products, and arbitrary fixed strictly positive finite rates. All
initial states, including boundary states, are included. Constants may depend
on the network and rates; no uniform estimate over vanishing rate constants is
claimed or needed.

## Verdict

**PASS as an internally reconstructed proof candidate.** I found no exact
counterexample, omitted source configuration, positive-rate degeneracy, or
unresolved discrete boundary/crossing estimate in the frozen fresh proof.
Its arguments give a coercive Foster function with `LV <= C(1+V)` in every
one-pure case. This is an argument-exposed mathematical review, not formal or
external certification. Novelty and priority remain **UNKNOWN**.

The fresh proof genuinely avoids the logarithmic/entropy obligations of my
blind proof. In the A+2B-absent case it constructs linear or quadratic functions
using weighted conservation tiers and perturbations. In the A+2B-present case
it uses a truncated quadratic cross term or a smooth angular interpolation,
then computes the exact quadratic generator in the dangerous boundary collar.
Neither mechanism needs to infer a global discrete bound from an entropy
asymptotic along a balanced ray.

## 1. Active tiers, strictness, and exhaustive degeneracies

The total direction gives each cubic arrow nonpositive total increment, not
merely a nonpositive aggregate. If all cubic increments have zero total, every
cubic arrow is inactive in that direction. The quadratic sources then become
the maximal possible active tier, so each quadratic total increment is
nonpositive; the linear Foster function is valid. This is exactly where the
active-source convention is essential (fresh lines 32--35).

Every nonidentity 3A arrow has negative A increment: its B increment is
nonnegative, and total nonincrease excludes either A growth or A constancy.
Thus `alpha=-g_A>0` for every allowed positive-rate choice. Every zero aggregate
weighted drift used for tier descent is a sum of individually nonpositive
terms with positive coefficients; it therefore implies that each arrow at
that source has zero weighted increment. Cancellation of inward and outward
arrows cannot invalidate the descent.

When A+2B is absent and 2A+B is present, `(1,2)` has top value 4 precisely at
2A+B and 2B, if the latter is present. A nonidentity 2B arrow must decrease B
since its A increment is nonnegative and its weighted increment is nonpositive.
If 2B is absent, `e_B` puts 2A+B and A+B at their highest possible B tier, so
each of their B increments is nonpositive. Consequently the aggregate
`u_B>0` case necessarily has a 2B source (fresh lines 65--70).

For `u_B<0`, the displayed `eta` is strictly positive: its summands are
`beta*(-g_total)` and `alpha*(-u_total)`, and some cubic total loss exists.
The quadratic expression `Q=-(alpha*a-beta*b)^2-eta*a*b` is strictly negative
on the nonnegative unit quarter circle. Hence the claimed uniform negative
bound on that quadrant follows by compactness; a negative-definite matrix on
the entire real plane is unnecessary (lines 72--81).

For `u_B=0`, the subtle assertion in lines 83--85 is valid. If also `u_A=0`,
the top weighted increment would vanish arrow by arrow. The integer products
of weighted value 4 are 4A, 2A+B, and 2B. Cubic total nonincrease excludes 4A,
and deletion of identity arrows excludes 2A+B. The only remaining increment
is `(-2,+1)`, which has strictly positive aggregate B increment. Thus `u_A<0`.
When 2B is absent, zero aggregate B drift gives zero B increment arrow by
arrow at 2A+B, removing the positive `a*b^2` error that `a^4` alone would not
control. The separate 2B-present branch supplies a negative `b^3` term.

For `u_B>0`, `u_A<=-2u_B<0`; choosing the quadratic perturbation large is
legitimate. If `u_W<0`, the quartic drift supplies both `a^4` and `a^2*b^2`.
If `u_W=0` but `j_W<0`, it supplies `a^4` and the 2B radial drift supplies
`b^3`. If both top weighted drifts vanish, the next active tier is 3A/A+B.
The subsequent three cases are exhaustive: `g_W<0` gives a linear drift;
`g_W=0,z_W<0` gives a small A-square perturbation whose positive 2B `a*b^2`
term is absorbed by the A+B negative radial term; and both zero make the
2A tier nonpositive by active descent (lines 92--119).

If both mixed cubic sources are absent, `(2,3)` is the correct top tie at
3A and 2B. The three weighted-drift branches in lines 123--137 have the
claimed negative `a^4`, `b^3`, or A+B `a*b^2` reserves. If 2B is absent,
the successive `(1,2)` tie at 3A/A+B and `(1,3)` tie at 3A/B are correct.
In these branches no positive `a*b^2` quadratic contribution remains; the
only potentially positive cubic-sized errors are `a^3+a^2*b`. If B occurs
in no source, `e_B` forces every arrow to conserve B (lines 139--148).
There is no omitted source pattern in this classification.

The polynomial absorptions in lines 53--59 are global. In particular,
`a*b^2 <= eps*b^3+C_eps*a^3` followed by absorption of `a^3` into `a^4`
justifies the mixed `a^4+b^3` reserve. Also
`a^2*b <= eps*a^4+C_eps*b^2`. Thus the estimates do not assume a relation
between A and B counts or a continuum interior limit.

## 2. Truncated cross term: exact discrete crossings

This is the branch `v_B<0` in fresh lines 158--190. Its angular preparation is
sound. Near B, `h(x)/x -> 2v_B<0`; near A, `h(1)=2g_A<0`; in the compact
middle, the nonnegative cubic loss polynomial `ell` is strictly positive.
A sufficiently small fixed epsilon therefore gives the stated
`L3_hom W0 <= -c*a*N^3` throughout the quadrant.

For `f(a)=(a-K)_+`, the exact jump formula, with no differentiability
assumption at the cutoff, is

`Delta V_K = 2q*a*d_A + q*d_A^2 + 2b*(q*d_B+Delta f)`
`             + q*d_B^2 + 2*d_B*f(a+d_A)`.

On `a<LK`, the terms not displayed as `2b*(...)` are bounded by a constant
depending on K. Thus only A+2B and 2B can produce leading `b^3` terms;
every other source contributes at most `O_K(1+b^2)`. This covers the entire
cutoff crossing strip, not merely the two smooth sides.

For an A+2B arrow, `Delta f <= max(d_A,0)` and
`q*d_B+max(d_A,0) <= epsilon*d_B`. Hence

`kappa=sum k*(q*(-d_B)-max(d_A,0)) >= epsilon*(-v_B)>0`.

Its exact aggregate upper contribution is `-2*kappa*a*b^3+O_K(1+b^2)`.
At 2B, `d_A>=0` because its A reactant count is zero; this explains why
the proof's T uses `q*d_B+d_A`, rather than `q*d_B+max(d_A,0)`. The upper
positive coefficient is at most T. For `a<=K-D`, both cutoff values vanish,
so this positive term is absent. For `a>K-D`, choosing
`K>D+T/kappa+1` gives `kappa*a>T`. The strictly negative cubic coefficient
then absorbs every positive 2B `b^3` coefficient, even at a crossing.

The choice ordering is consistent: the exterior error constant C is
independent of K; take L from C,c, then K sufficiently large for D,T,kappa.
For `a>=LK` the entire jump remains in `a>=K`, and the function is exactly
`W0-2K*b`. The error `C(1+K)(1+N^3)` is then absorbed by `-c*a*N^3`.
Constants on the finite-A strip may grow with K; this is permitted.

At `a=0`, the dangerous cubic source is disabled, but so is the positive
2B leading coefficient because K>D. At `b=0,1`, the A+2B and 2B propensities
are zero. Their replacement by leading monomials changes the upper estimate
by only `O_K(1+b^2)` on the strip. No boundary cancellation is being assumed.

## 3. Angular interpolation: the diagonal collar is essential

This is the branch `v_B=0` in fresh lines 192--229. Since every A+2B arrow
has nonpositive B increment, zero aggregate B drift gives zero B increment
for each arrow. Total cubic nonincrease and nonidentity force `(-1,0)`.
Thus `v=(-kappa,0)` with `kappa>0`; no rate cancellation is hidden here.

The displayed leading drift of `W1=M*a^2+q*b^2` is correct. The choice
`M*kappa>q*max(u_B,0)+1` makes its `a^2*b^2` coefficient strictly negative;
a sufficiently small angular collar absorbs its `a^3*b` term. The
inequalities `W0-W1>=a*b` and `D rho<0` hold after independently shrinking
the same positive delta. Consequently the interpolation contribution
`chi'(rho)*(D rho)*(W0-W1)` is nonpositive. The weighted homogeneous drift
is uniformly negative on every projectively closed region
`rho>=delta/4`, including the A axis.

The degree-two interpolated V has uniformly bounded Hessian on the quadrant
away from the origin: it is exactly a quadratic near both axes, and its
transition lies in a compact angular interval. Homogeneity extends this
bound radially. Its gradient tends to zero at the origin, so it extends as
a Lipschitz gradient. The finite-jump Taylor remainder is therefore uniformly
`O(|d|^2)`, giving `O(1+N^3)` after summation of cubic propensities. This bound
alone would be insufficient near the B axis, and the proof does not use it
there.

In the deep B collar `a/b<=delta/4`, all jumps lie in the exact W1 region
once, for example,

`b >= 4D/delta+2D`.

Indeed `(a+D)/(b-D)<=delta/2` under that inequality. Because `b` is a
fixed positive fraction of N in this collar, excluding smaller N excludes
only finitely many states. The generator is therefore computed with the
exact quadratic at both endpoints; there is no discrete chi crossing error.

Its remaining errors are precisely bounded by
`C(a^3+a^2*b+a*b^2)+C(1+N^2)`. The pure 2B source cannot produce positive
`b^3` because each B increment is nonpositive. The negative reserve is
`-c2*a^2*b^2`. On the collar, `a^3<=delta*a^2*b`, and the elementary bounds

`a^2*b <= eps*a^2*b^2+C_eps*a^2`,
`a*b^2 <= eps*a^2*b^2+C_eps*b^2`

absorb all the remaining errors. These are valid at fixed a, including a=0.
At a=0 all cubic rates vanish; 2B A-production contributes only `O(b^2)`
to this exact quadratic, which is within the Foster bound. Fixed positive
rates merely change M, delta and the constants.

## 4. Nonexplosion interface and presentation refinements

The stopped-Dynkin conclusion in lines 24--29 is valid for the minimal chain.
Every finite set has bounded total propensity, so explosion cannot occur
without leaving every finite set. Coercivity of V and the stopped estimate
exclude that escape in finite time. No irreducibility or special initial
communicating class is required.

The following expansions would improve the proof's presentation but are not
missing proof obligations:

1. Say that Q's strict negative bound is on the nonnegative quadrant, not a
   claim about a negative-definite form on all of R^2.
2. Explicitly cite cubic total nonincrease when excluding the W-conserving
   product 4A in the `u_B=0` branch.
3. Explain `d_A>=0` for 2B beside the definition of T.
4. Give an explicit collar-jump threshold such as the one above.
5. Add 1 to the displayed nonnegative functions when claiming comparability
   with `1+N` or `1+N^2`; this leaves their generator unchanged.

The fresh proof is a shorter replacement route for the one-pure theorem,
subject to the same internal-candidate status. This comparison supplies no
external certification and makes no claim about arbitrary dimension or
priority.

As a direct adverse source control, Xu's Example 4.11, printed page 10, has
one pure cubic decay source and a quadratic autocatalytic explosive component.
It is strongly `(1,1)`-endotactic, but fails full endotacticity: in the direction
of the autocatalytic species, its quadratic birth arrow is at the maximal
active source. Thus it does not falsify this theorem, and it demonstrates why
the full directional hypothesis cannot be replaced by total endotacticity.
Example 4.19, printed page 11, warns that cubic weakly reversible systems may
require nonlinear Foster functions; it is nonexplosive and has no pure cubic
source. Neither example supplies a counterexample within this audit's scope.

Audit completed 2026-10-08 12:11 UTC, within the 15-minute bound.
