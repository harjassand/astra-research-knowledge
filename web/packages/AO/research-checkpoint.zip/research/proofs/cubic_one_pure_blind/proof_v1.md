# Blind proof candidate: exactly one pure cubic source

Frozen independently on 2026-10-08. No `chem_explosion_blind` proof files were read. Status: internally reconstructed proof candidate, awaiting independent adversarial review; no formal or external validation or priority claim.

## Statement

Consider a finite two-species stochastic mass-action network on N₀² with propensities κ_y (a)_(y_A)(b)_(y_B), arbitrary fixed κ_y>0 and finite integral products. Every nontrivial reaction has source total at most3. Assume full endotacticity with Xu2409.05340v2 Definition4.2: maximality is taken among sources of reactions whose reaction vectors are not orthogonal to the direction. Assume3A is a source and3B is not. Then the minimal CTMC is nonexplosive from every initial state.

All constants below may depend on the finite network, its product jumps, and its fixed rates. No singular rate limit is used. The proof constructs a global discrete Foster bound LV≤C V for a nonnegative norm-like V, using Xu Proposition3.5.

Write30,21,12,02,11,20 for sources3A,2A+B,A+2B,2B,A+B,2A. A source is present only if it has a nontrivial outgoing reaction. Self arrows can be discarded. Duplicate arrows can be combined.

## Preliminary facts and discrete estimates

For direction(1,1), any positive total increment at a cubic source is itself active and has maximal possible active-source total3, so is forbidden. Consequently every cubic arrow has ΔA+ΔB≤0. Every nontrivial30 arrow has ΔA<0: its product has total≤3 and cannot retain A-coordinate3 unless it is a self arrow.

If all cubic arrows conserve total, the active-source convention excludes them in direction(1,1). A positive quadratic total increment would then be maximal among the remaining active sources and is forbidden. Thus V=1+a+b gives LV≤C V in that case. In the remainder assume at least one cubic arrow strictly decreases total.

Direction(0,1) implies ΔB≤0 at both02 and12 whenever present: source B-coordinate2 is maximal since03 is absent. If12 is absent, every nontrivial02 arrow has ΔB<0. Indeed a B-conserving nontrivial02 arrow must increase A; for direction(ε,1) with ε>0 sufficiently small,02 is the unique maximal source among all sources except possibly other B-coordinate2 sources, and none exist. Its arrow would violate endotacticity.

Let J bound the absolute jump coordinates of all arrows. Any C¹ positively homogeneous function W used below has gradient Lipschitz with constant C/(a+b) on bounded-jump segments outside a fixed finite set. Hence, for enabled jumps v and a+b large,

    W(x+v)−W(x)=∇W(x)·v+O(1/(a+b)).                 (E1)

The implicit constant is uniform over the finite reaction set. All jump segments remain in the nonnegative orthant. Reactions disabled by falling factorials contribute exactly zero.

For entropy, set φ_c(n)=n log n−n−cn for n≥1 and φ_c(0)=0. For n≥2J,

    φ_c(n+d)−φ_c(n)=d(log n−c)+O(1/n).             (E2)

On a fixed bounded coordinate the increment is bounded, and on any coordinate it is O(log(n+1)+1). Adding a finite constant makes V=φ_cA(a)+φ_cB(b)+constant≥1. It is norm-like and V is comparable to(a+b)log(a+b+1) outside a finite set. Order≤1 arrows have generator contribution bounded above by C V.

For both coordinates diverging, (E2) gives the exact entropy drift

    Σ κ_y (a)_(yA)(b)_(yB) [ΔA(log a−cA)+ΔB(log b−cB)]
       + O(Σ κ_y (a)_(yA)(b)_(yB)(1/a+1/b)).       (E3)

For inequalities with a negative reaction bracket, its exact propensity is retained and is between a fixed positive fraction of its monomial and that monomial once both coordinates diverge. Falling-factorial replacements are made only for the explicitly balanced top transfers below; their errors are charged separately. This avoids an unjustified O(ab log b) error in regimes where a grows slowly.

## I. Source12 present: a smooth boundary Foster function

Let p30,p21,p12 be the rate-weighted sums of cubic reaction vectors at those sources, with p21=0 if absent. Let F=p30 a³+p21 a²b+p12 ab². Then F_A+F_B≤0 everywhere, p30,A<0, and p12,B≤0. The strict total-loss assumption makes F_A+F_B strictly negative whenever a,b>0.

Choose K≥1 sufficiently large. On r=a/b≤1/K, there are two possibilities.

* If p12,B<0, choose K so F_B≤−η ab². For any gradient with0≤W_A≤W_B, the cubic drift is nonpositive. On r≤1/(2K), if W_A/W_B=K r, it is at most−η′ab²: if F_A≤0 this is immediate; otherwise F_A≤−F_B and W_A≤W_B/2.
* If p12,B=0, every12 arrow conserves B and strictly decreases A, so p12,A<0. Choose K so F_A≤−η ab² and F_B≤M a²b on r≤1/K, and also Kη>M+1. A gradient ratio W_A/W_B=K r then gives cubic drift≤−η′a²b.

Such choices follow directly from the finite coefficients. The p30,A a³ term is negative; the other terms have one extra factor r in the stated region.

Choose H≥1 large enough that F_A≤−η a³ for r≥H. For gradients with W_A≥W_B≥0, the cubic drift is nonpositive. If r≥2H and W_A/W_B=r/H, it is≤−η′a³. On every fixed ratio interval bounded away from0 and infinity, strict total loss gives F_A+F_B≤−η(a+b)³.

Define c=(1+1/K)^(-1/2), and

    W(a,b)=sqrt(b²+K a²),                       a/b≤1/K;
           c(a+b),                            1/K≤a/b≤H;
           c sqrt(1+1/H) sqrt(a²+H b²),        a/b≥H.

Use the natural endpoint definitions on the axes. The pieces have equal values and gradients at the joins: both tangent gradients are(c,c). Thus W is C¹ off the origin, positive homogeneous, and comparable to a+b. Its Hessians on each piece are O(1/(a+b)); its gradient is Lipschitz across the joins, establishing(E1). On the left W_A/W_B=K a/b; on the right it is a/(H b).

The continuous cubic drift is therefore nonpositive everywhere. It is bounded above by−η(a+b)³ on both transition ratio bands[1/(2K),1/K] and[H,2H], and on the middle interval. It is≤−η′a³ in the deep A-axis region. There, exact falling-factorial corrections and(E1) contribute O((a+b)²), as do all quadratic arrows; these are absorbed for large states.

In the deep B-axis region a≤b/(2K), all gradients are bounded, W_A=O(a/b), and W_B is bounded below. Quadratic02 arrows have ΔB≤0; hence their first-order positive contribution is O(ab), and their Taylor contribution is O(b). Other quadratic arrows contribute O(ab+a²), which is O(ab) in this region. Linear arrows contribute O(a+b).

If p12,B<0, the exact cubic leading bound is−η ab²; its falling-factorial/Taylor errors are O(ab+a²+a³/b)=O(ab). Therefore

    LW≤−η ab²+C(a+1)b≤C′b

outside a finite set, including a=0 where the cubic rates are zero. If p12,B=0, the leading bound is−η a²b. The same errors, plus quadratic terms, give

    LW≤−η a²b+C(a+1)b≤C′b.

For the latter inequality separate a above a fixed constant, where the negative quadratic-in-a coefficient absorbs the error, from bounded a, where the whole remainder is O(b). For the former separate large b from its finite complement. Thus V=1+W satisfies LV≤C V globally. This completes the case12 present, including arbitrary21 presence, every discrete boundary, and arbitrary finite product jumps.

## II. Source12 absent: entropy and exposed-source faces

Here02 arrows, when present, strictly decrease B. The entropy boundary estimates are immediate. If a is bounded and b→∞,02 gives a negative term of order b²log b if present; otherwise all propensities involving b have degree≤1 and LV=O(b log b). If b is bounded and a→∞,30 gives−η a³log a, dominating the other propensities O(a²log a). Thus only a,b→∞ need be considered.

If a/b stays in a compact positive interval, the strict total-loss cubic arrow contributes−η(a+b)³log(a+b). Total-conserving cubic entropy brackets and constant shifts are O(1); all other cubic brackets are nonpositive at their leading log(a+b) order. Quadratic drift and entropy Taylor errors are smaller. If a/b→∞, every positive cubic bracket is O(log(a/b)), while30 gives−η a³log(a/b) (or a stronger negative total-loss term). Mixed cubic positive rates are smaller by b/a; quadratic positive rates are O((a²+ab+b²)log(a+b)), which are smaller than the30 dissipation. Hence the only remaining direction is a/b→0.

The following sequence arguments prove a global bound: if sup LV/V were infinite, one could choose a sequence with LV/V→∞, extract bounded-coordinate or a,b→∞ subsequences, and then extract the indicated ratio limits. Every such subsequence has been bounded or has eventually negative nonlinear drift. Finite states have finite generator values. Linear reactions have already been bounded by C V.

### IIa. Source21 present and02 absent

Direction(0,1) gives ΔB≤0 at21 and11, since maximal source B-coordinate is1. Every nontrivial21 arrow has either ΔB<0 or ΔB=0,ΔA<0. In the B-dominant regime, its entropy bracket is strictly negative, of magnitude at least a constant times either log(b/a) or log a. The exact21 rate is comparable to a²b. Positive30 brackets are O(log(b/a)); their rates are O(a³). Positive11 brackets are O(log a); their rates are O(ab). Positive20 drift is O(a²log(a+b)). These are smaller than the21 negative contribution:

    (a/b) log(b/a)/log a→0,
    log a/(a log(b/a))→0,
    log(a+b)/(b min(log a,log(b/a)))→0.

The first uses log q/q→0 with q=b/a; the others use both coordinates and log(b/a) diverging. The entropy remainder at21 is O(ab+a²), also smaller. Its negative exact bracket is not replaced by a monomial plus a log-amplified error. Therefore the nonlinear entropy drift is eventually negative.

### IIb. Sources21 and02 both present

Use the exposed face normal u=(1,2). Sources21 and02 have projection4, all other sources projection≤3. Thus every21 and02 arrow has u·Δ≤0. At21, the additional total constraint leaves only the following possible products:

    0, A, 2A, 3A, B, A+B, 2B  (and the excluded self product21).

At02, products satisfy A′+2B′≤4 and B′≤1, apart from the excluded self product. Put R=a²/b and consider a/b→0.

If R→∞, set L=log R and Q=log(b/a); both diverge. Every21 entropy bracket is negative with magnitude at least a constant times min(L,Q), after fixed shifts. Positive02 brackets are O(L), positive30 brackets O(Q), and positive lower-order brackets O(log(a+b)). Their propensity ratios to a²b are respectively1/R, a/b,1/a or1/b. Writing a=R exp Q proves all resulting ratios vanish: for example L/[R min(L,Q)]→0 and Q/[exp Q min(L,Q)]→0. The(E3) remainder also vanishes relative to the negative21 term.

If R→0, put T=−log R. Every02 entropy bracket is negative with magnitude at least a constant times T. The tangential zero-weight arrows give−T or−2T; a strictly negative u-weight gives at least−(log b)/2, and T≤log b. Positive21 brackets are O(T), but their rate is R b². Positive30 and lower-order rates are smaller than b² by powers of a/b or R; explicitly a³/b²=exp(−log a−2T), ab/b²=exp(−log a−T). These powers absorb all logarithms. Entropy remainders are smaller as well.

It remains that R tends to a finite positive limit (or remains in a compact positive interval after subselection). Then a is comparable to sqrt b and

    (log a,log b)=(log b/2,log b)+O(1).

If any21 or02 arrow has strictly negative u-weight, it gives−η b²log b. Tangential top arrows contribute only O(b²), lower nonlinear sources O(b^(3/2)log b), and the exact falling-factorial and entropy remainder corrections O(b^(3/2)); hence the drift is negative.

Otherwise every top arrow is tangent to this face. The only nontrivial21 product is02; the only02 products are21 and4A. Let d be the total rate constant of21→02 and let e be the sum of rates of02→21 plus twice the rates of02→4A. Both are positive. Choose cB=0,cA=(1/2)log(e/d). The top monomial entropy drift is exactly

    (e b²−d a²b) log(d a²/(e b))≤0.

On the present compact-R regime, replacing monomials by falling factorials and using(E2) costs O(b^(3/2)). Full active-source endotacticity in u excludes the top tangent arrows, so30 and11, both at projection3 when present, have u·Δ≤0. If either has a strictly negative u-weight, its rate is comparable to b^(3/2), giving−η b^(3/2)log b and absorbing the fast-transfer errors, tangential lower arrows O(b^(3/2)), and20 drift O(b log b).

If neither30 nor11 has any negative u-weight, all those arrows are tangent too. A positive20 u-increment would now be maximal among active sources, of projection2, and is forbidden. All nonlinear reactions therefore have u·Δ≤0, and V=1+a+2b is already a linear Foster function. This completes IIb.

### IIc. Source21 absent and02 present

The exposed face normal is u=(2,3):30 and02 have projection6;11 has projection5 and20 projection4. Thus every30 and02 arrow has u·Δ≤0. If the aggregate u-drifts at both are strictly negative, V=1+u·x gives

    LV≤−d₁(a)_3−d₂(b)_2+C(a²+ab+a+b+1)≤C′V.

The last inequality uses Young's inequality to absorb ab in b² plus a², and then absorbs a² in a³. If exactly one aggregate drift is zero, perturb the A-weight slightly: zero30 arrows are all30→02, and zero02 arrows all02→30. Choose the sign that makes the zero aggregate negative; continuity preserves negativity of the other aggregate. This gives the same linear bound. The weights remain strictly positive.

If both aggregate drifts vanish, the only top arrows are30→02 and02→30. Let their rate sums be d,e>0. If11 is absent, positive20 u-increments are forbidden by active-source maximality, so u·x is a Foster function. If11 is present, every nontrivial11 arrow has strictly negative u-weight: positive is forbidden after excluding the top tangent arrows, and the only integral complex at weight5 is11 itself.

Choose cB=0,cA=(1/3)log(e/d). Put R=a³/b². The top monomial entropy drift is

    (e b²−d a³) log(d a³/(e b²))≤0.

For R→∞ or R→0, this negative term dominates all lower nonlinear positive drift and the exact corrections. For example when R→∞, ab/a³=1/sqrt(aR), a²/a³=1/a; when R→0, a/b=R^(1/3)b^(-1/3). These powers absorb the logarithms. Falling-factorial flux errors are O(a²|log R|+b|log R|), and(E3) adds O((a³+b²)(1/a+1/b)); these are smaller than the fast dissipation in the outer regimes.

For R in a compact positive interval, a is comparable to b^(2/3), and the fast corrections are O(b^(4/3)). The11 negative u-weight gives−η ab log b=−η′b^(5/3)log b, whereas20 positive drift is O(b^(4/3)log b) and tangential top drift is nonpositive after alignment. Thus the entropy drift is eventually negative. This completes IIc.

### IId. Sources21 and02 both absent

If11 is present, use u=(1,2);30 and11 are the maximal sources of projection3, so their u-increments are nonpositive. If at least one of their aggregate drifts is negative, perturb the A-weight slightly to make both strictly negative, if needed: zero30 arrows are30→11 and zero11 arrows11→30. The resulting linear drift is bounded above by

    −d₁(a)_3−d₂ab+C(a²+a+b+1)≤C′V.

If both aggregate drifts vanish, positive20 u-increments are forbidden after the top tangent arrows are excluded, so u·x is already Foster.

If11 is absent too, use u=(1,3). Source30 is maximal at projection3, tied only with a possible linear B source. Its u-increments are nonpositive. If its aggregate drift is zero, its arrows are all30→B; increasing the A-weight slightly makes its aggregate strictly negative. Otherwise retain u. The only quadratic source is20, whose O(a²) drift is absorbed by the negative30 cubic drift; all B-dependent propensities are linear. This is a linear Foster bound.

## Conclusion and review obligations

The cases are exhaustive:12 present; or12 absent with each combination of21 and02 presence. All-cubic-total-conservation was handled first. In each case a norm-like, nonnegative, globally defined V has LV≤C V. Xu Proposition3.5 implies nonexplosion.

This is a complete written candidate proof, not an external or formal certification. The highest-value adversarial checks are: (i) the C¹ homogeneous boundary function and its exact left-region error estimates in I; (ii) the active-source removal argument in the tangent-face subcases; (iii) the entropy domination estimates in IIb's extreme-ratio subsequences. No finite experiment could replace those universal estimates. Novelty and priority are UNKNOWN; only Xu's definition and published Foster criterion were imported.
