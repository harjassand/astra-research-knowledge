# Exactly-one-pure-cubic blind checkpoint

**Candidate theorem:** every finite fully-endotactic two-species stochastic mass-action network with source totals≤3,3A present and3B absent is nonexplosive for every fixed positive rate vector. Products may be arbitrary finite integral complexes. Symmetry covers the opposite pure source.

`proof_v1.md` supplies a global discrete Foster proof candidate. It is independent of the chemistry phase2 proof files, which were not read before freezing. Status is internally reconstructed, requiring fresh adversarial review; formal/external validation and priority are UNKNOWN.

The proof uses a C¹ homogeneous ellipse–linear–ellipse potential when A+2B is present. Its B-axis gradient vanishes in the A-direction, so order-b² A-immigration contributes only O(b) at bounded A. Cubic A+2B death controls larger A, and an A-axis branch controls3A conversions. Falling-factorial corrections and bounded product jumps are charged globally.

When A+2B is absent, full endotacticity forces every2B arrow to decrease B. Exposed source faces then give either a positive weighted linear Foster function or a rate-adjusted entropy potential. The difficult tangent transfers are2A+B↔2B along(-2,1), and3A↔2B along(-3,2). Entropy shifts align their aggregate fluxes; lower active-face reactions supply the missing drift. All A=0,1,2 and B=0,1 boundaries are explicitly included.

The remaining obligation is independent proof review, particularly the homogeneous boundary drift and tangent-face hierarchy. No explosive counterexample was found. No claim of external correctness or new priority is made.

Primary source: Xu, *On the Regulary of Reaction Systems*, arXiv2409.05340v2, Definition4.2 p8 (active reactant convention), stochastic mass-action equation(2.1) p3, Proposition3.5 pp5–6 (norm-like Foster criterion). Exact source PDF and text hashes are recorded in `source_manifest.json`.
