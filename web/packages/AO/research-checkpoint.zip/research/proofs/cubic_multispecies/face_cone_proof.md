# Cubic source-face guard and a localized nonexplosion theorem

Status: internally derived proof; no external review or novelty claim. This is a scoped exclusion, not a proof that all cubic endotactic networks are nonexplosive.

## Interface

Let a finite network on d species have integral source/product complexes y,y' in N_0^d, every source satisfy |y|_1 <= 3, and every stochastic mass-action rate be

    lambda_r(x) = kappa_r product_j (x_j)_(y_j),   0 < kappa_r < infinity.

Products are unrestricted finite integral vectors. The constants are fixed, with no limiting or externally supplied clocks.

For a nonempty species set I, put n_I(x)=sum_{i in I} x_i and u=1_I. The only geometric assumption needed below is u-endotacticity in the **active-source** sense of Xu, Definition 4.2, arXiv:2409.05340v2, PDF p.8. Reactions with u dot (y'-y)=0 are omitted before source maximization. Full endotacticity implies this assumption for every I.

## Lemma 1: the pure-face cubic guard

Write m_I(y)=sum_{i in I} y_i and Delta_I(r)=sum_{i in I}(y'_i-y_i).

1. A reaction with m_I(y)=3 has Delta_I(r)<=0.
2. If any reaction has m_I(y)=2 and Delta_I(r)>0, there exists a reaction r_* with m_I(y_*)=3 and Delta_I(r_*)<0. Its source is supported entirely in I.
3. Consequently, if no negative reaction has m_I(y)=3, every reaction increasing n_I has m_I(y)<=1.

Proof. All sources have m_I<=3. A positive reaction with m_I=3 would be u-active and maximal among the active sources, violating u-endotacticity. If a positive reaction has m_I=2, it cannot be maximal among the active sources. A strictly larger active source therefore has m_I=3. Every active reaction from such a maximal source has negative Delta_I. Total source order <=3 implies that this source has no coordinate outside I. This proves all three assertions. No strong endotacticity, weak reversibility, or rate choice is used.

Taking I to be all species proves in particular that **all cubic reactions have nonpositive total-count increments**. Positive total-count drift is therefore carried only by sources of order <=2.

## Theorem 2: nonexplosion before leaving a comparable face region

Fix I, an integer K>=0, and 0<epsilon<=1/|I|. Define

    D(I,K,epsilon) = {x: x_j<=K for j outside I,
                         x_i>=epsilon n_I(x) for every i in I}.

Kill the chain at its first jump out of D. This killed chain is nonexplosive. Equivalently, the original chain has probability zero of exploding while never leaving D.

Proof. On D use V(x)=1+n_I(x), and assign V=0 at the cemetery state. This is norm-like on D plus the cemetery: bounded V bounds all coordinates in I, and all remaining coordinates are bounded by K. Killing can only lower the generator relative to the unrestricted linear function 1+n_I, since every unrestricted destination has nonnegative V.

If there is no negative pure-I cubic source, Lemma 1 shows that all positive terms have m_I(y)<=1. On the slab x_{I^c}<=K, their rates are at most C_K(1+n_I), where C_K is finite and absorbs all fixed reaction constants and all finite product increments. Negative terms may be discarded for an upper bound. Hence L_D V<=C_K V.

Otherwise choose one reaction r_* with m_I(y_*)=3 and Delta_I(r_*)<0. Every positive term has m_I(y)<=2, so its contribution is bounded above by C_K(1+n_I^2). For n_I>=6/epsilon, each source coordinate appearing in r_* is at least 6. For each multiplicity a<=3, (x_i)_a >= (x_i/2)^a. Thus

    lambda_*(x) >= kappa_* (epsilon n_I/2)^3.

Since Delta_I(r_*) is a negative integer,

    L_D V(x) <= C_K(1+n_I^2) - kappa_* (epsilon/2)^3 n_I^3.

This polynomial is bounded above. There are only finitely many states of D with n_I<6/epsilon, so the bound extends to all states. In particular L_D V<=C V for a finite constant C. Apply the usual norm-like Foster criterion (Xu, Proposition 3.5, PDF p.5) to the killed chain. The cemetery is harmless and absorbing. This proves the result.

## Corollaries and exact limits

For I={i}, the comparability condition is automatic. Thus **a cubic fully endotactic chain cannot explode while all species other than i remain bounded**. This rules out every fixed finite-catalyst construction with one unbounded species, in any dimension.

The same exclusion holds if the chain eventually remains in D, rather than remaining there from time zero: apply the killed-chain assertion after each finite jump time, and take a countable union over jump indices. Consequently any explosion would require at least two coordinates to be unbounded on the pre-explosion path, and cannot eventually stay in a region with a comparable unbounded block and bounded complement.

This does not exclude a hierarchical escape such as A>>B>>C with all three counts unbounded. It also does not exclude paths switching among the regions infinitely often before a putative explosion. Individual stopped Foster bounds cannot simply be concatenated into a global theorem.

## Lemma 3: a pure cubic source suppresses its dominant coordinate

Suppose a nontrivial reaction with source 3S_i exists. For a sufficiently small fixed epsilon>0, depending only on the finite network and its fixed constants, the chain killed outside

    D_i(epsilon) = {x: x_j <= epsilon x_i for every j != i}

is nonexplosive. No bounded complement is assumed here.

Proof. Lemma 1 for I=all species gives nonpositive total increment for every cubic reaction. Lemma 1 for I={i} also gives nonpositive i-increment for every pure 3S_i reaction. A pure 3S_i reaction with zero i-increment must have product 3S_i itself: otherwise the total count would increase. Thus any nontrivial one has i-increment at most -1, and its negative contribution to L x_i is at most -kappa_*(x_i)_3.

Every cubic reaction with positive i-increment uses at least one source molecule of another species. On D_i(epsilon), with epsilon<=1, its propensity is at most kappa_r epsilon x_i^3. Summing the finite positive cubic terms gives at most C_3 epsilon x_i^3. All lower-order positive terms are at most C_2(1+x_i^2). For x_i>=4, (x_i)_3>=x_i^3/4. Choose epsilon so that C_3 epsilon <= kappa_*/8 (if C_3=0 there is no restriction). Then

    L x_i <= C_2(1+x_i^2) - (kappa_*/8) x_i^3.

This is bounded above. The function 1+x_i is norm-like on D_i(epsilon); assigning cemetery value zero lowers the generator. The same stopped Foster argument proves the assertion.

Hence if one species eventually dominates every other coordinate by ratios tending to zero, and that species has a nontrivial pure cubic source, explosion is impossible. The hierarchy gap is restricted further to missing pure cubic sources of the dominant species, or infinitely many changes of dominant species.

## Primary-source comparison

Xu's Theorem 4.6 (PDF p.9) uses direction 1 and source order <=2 to make every nonlinear positive total-count term vanish, then applies a linear Foster criterion. Lemma 1 is an elementary source-face extension of that argument; Theorem 2 additionally compares pure-face cubic negative rates with the at-most-quadratic positive rates on a restricted region. It should be treated as a scoped corollary of published machinery, not a major novelty claim.

Xu, arXiv:2409.05340v2, https://arxiv.org/abs/2409.05340v2:
- PDF p.3, equation (2.1): stochastic mass action and source-order convention;
- PDF p.5, Proposition 3.5: Foster criterion;
- PDF p.8, Definitions 4.1-4.2: active-source endotacticity;
- PDF p.9, Theorem 4.6 and Remark 4.8: order-two nonexplosion and the open minimum-order question.

Pinned local PDF SHA256: 19878242451113a736a44c316664d63ae13036f99cfff5e2c9271e383b286fda.
