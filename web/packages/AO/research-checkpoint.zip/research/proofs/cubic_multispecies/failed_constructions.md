# Three-species cubic construction attempts

Status: construction routes rejected by exact conservation or an exact rational endotacticity witness. No explosive construction is claimed.

All species coordinates are ordered (A,B,C); every listed source has total order <=3. Set all rates to 1, or to any fixed finite positive constants: the geometric rejections do not depend on those constants.

## A strongly endotactic cycle with a hidden resource

    2A -> A+2C -> 2A+B -> 2A.

This is weakly reversible with one linkage class, hence strongly endotactic in the usual convention that ignores directions orthogonal to the stoichiometric subspace. The comparator is Anderson-Cappelletti-Kim-Nguyen, arXiv:1808.05328v2, Proposition 3.1, PDF p.5.

The apparent amplifier fails because every reaction preserves 2A+C. In the class 2A+C=R, A and C are bounded. Only the middle reaction births B; its rate kappa_2 A(C)_2 is bounded by a constant depending on R. The final reaction removes B at rate kappa_3 (A)_2 B. Therefore V=1+B has bounded-above drift and is norm-like on the class. The chain is nonexplosive. The entire cycle has zero net stoichiometric increment.

## Increasing the resource yield violates a source face

    2A -> A+3C,
    A+2C -> 2A+B,
    2A+B -> 2A.

The desired extra C is not free. For u=(2,-1,1), the source projections are 4,4,3 and the reaction projections are +1,-1,+1. Every reaction is u-active. The first reaction is therefore a positive reaction from a maximal active source: an exact violation of Xu's Definition 4.2. Adding 3C->2C would give source projection 3 and would not repair this witness.

## Fast token switching does not shield the resource direction

    2A -> 3C,
    A+2C -> 2A+C,
    2A+C -> 2A+B,
    2A+B -> 2A+C,
    3B -> 2B,
    3C -> 2C.

The heuristic was to birth C at rate order A^2, convert it back into A at rate order A C^2, and move the B/C tokens rapidly with A^2(B+C) switching. A balance C approximately sqrt(A) would give superlinear amplification if the cubic token deaths were the only suppressors. This was a heuristic only; it was rejected before an explosion proof.

For any u=(s,1,1) with 1<s<2, the two token-switching reactions are orthogonal to u and are **omitted** from the active source set. The converter A+2C->2A+C has source projection s+2 and positive reaction projection s-1. This is strictly larger than the remaining active source projections 2s and 3. It is the unique maximal active source and violates endotacticity. In particular u=(3/2,1,1) is an exact rational witness; the first reaction is also orthogonal at that u.

The seemingly higher source points 2A+B and 2A+C cannot shield this direction: both arrows preserve the resource sA+B+C. To repair the violating resource direction one needs a genuinely inward reaction. A pure 3A guard fires at order A^3; an active 2A+token guard fires at order A^2(B+C). Either destroys the proposed rate hierarchy when tokens have order sqrt(A). This observation is a route obstruction, not a universal nonexplosion proof, because other source/product geometries have not been excluded.

## Next decisive proof obligation

The remaining high-value gate is a global nonexplosion bound for separated unbounded scales. In three species an essential unresolved sector is

    A -> infinity, B -> infinity, C -> infinity,
    B/A -> 0, C/B -> 0,

together with its coordinate permutations and boundary versions. A useful finite analysis would partition the logarithmic scale triangle 0<=gamma<=beta<=1 by the source monomial exponents i+beta*j+gamma*k, for i+j+k<=3, and retain only directions after removing orthogonal reactions. The missing step is a proper stochastic Lyapunov function or an integrated stopping argument valid uniformly across these sectors and their interfaces. Source-tier inwardness alone is not that function, and bounded rates/noise estimates on separate sectors do not prove the global result.

No lower bound of four on the minimum explosive source order follows from the present work.
