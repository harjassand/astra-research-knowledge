# Bounded cubic multispecies attack

Outcome: **no justified promotion; no cubic explosive construction and no general cubic nonexplosion theorem.** Three actual stopped nonexplosion results were derived. They remove fixed-catalyst escape, balanced face escape, and dominant escape with a pure cubic source, but leave separated-scale paths with inactive boundary reactions and missing pure sources.

The assignment was restricted to three or more species and fixed finite positive stochastic mass-action constants, with source order at most three and unrestricted finite integral products. No two-species classification or the parent order-five proof was read. No descendants were spawned.

## Precise results

1. **Pure-face guard.** For any nonempty species set I, full endotacticity forces a negative pure-I cubic source whenever a source containing two I-molecules increases the I-count. With all species outside I bounded and all I-counts comparable, the negative rate is at least c n_I^3 while positive I-drift is at most C(1+n_I^2). The chain killed at the first exit of that region is nonexplosive. In particular explosion with only one unbounded coordinate and fixed bounded catalysts is impossible in any dimension.

2. **Dominant pure cubic guard.** If a species has a nontrivial pure source 3S_i, then for a sufficiently small fixed epsilon the chain killed outside {x_j<=epsilon x_i for all j!=i} is nonexplosive. The inward pure-cubic rate dominates the positive cubic terms, each of which contains a nondominant source molecule. This removes hierarchical escape with a pure source at the dominant coordinate, even when all other counts are unbounded.

3. **Fully enabled strong-endotactic region.** In a strongly endotactic network of any finite source order, put M_i=max_source y_i. On each fixed stoichiometric class, the chain killed outside {x_i>=M_i for every i} is nonexplosive. In this region all propensities are uniformly comparable to source monomials above and below. The published tier domination and stochastic entropy bound give entropy drift at most -1 outside a finite set. Thus any putative strong-endotactic explosion must encounter a disabled source reaction arbitrarily late. In a cubic system those thresholds are at most three.

Exact proofs and their limits are in `face_cone_proof.md` and `fully_active_stopping_proof.md`. These are internally reconstructed, unreviewed mathematical arguments, not formal proof or independent validation.

## Construction attacks

The weakly reversible one-cycle 2A->A+2C->2A+B->2A is strongly endotactic, but preserves 2A+C, so A,C are bounded and B has bounded inflow. Increasing the first C-yield violates endotacticity in direction (2,-1,1).

A distinct token-switching amplifier used 2A->3C, A+2C->2A+C, rapid 2A+C<->2A+B switching, and cubic B/C deaths. It fails in direction (3/2,1,1): the rapid switches are orthogonal and must be omitted. The converter is then the unique maximal active source and points outward. `verify_certificates.py` verifies both rational witnesses and the first cycle's conservation exactly with Python Fractions. Its checks passed; they verify only those finite certificates.

## Primary-source and novelty comparison

Xu, [arXiv:2409.05340v2](https://arxiv.org/abs/2409.05340v2), PDF p.3 equation (2.1), p.5 Proposition 3.5, p.8 Definitions 4.1-4.2, p.9 Theorem 4.6 and Remark 4.8. The source explicitly makes source order, rather than product order, the kinetic degree; it proves all second-order endotactic systems nonexplosive and leaves the minimal explosive order open. Our source-face and domination arguments are scoped extensions of its proof and the classical Foster criterion, not a strong novelty candidate.

Anderson-Cappelletti-Kim-Nguyen, [arXiv:1808.05328v2](https://arxiv.org/abs/1808.05328v2), PDF p.5 Proposition 3.1, p.10 Theorem 4.2, pp.15-17 Lemma 4.5, p.30 Lemmas 7.4-7.5, and pp.30-35 proof of Theorem 7.2. These primary theorem-proof sections were read. The fully enabled stopped assertion is an application of their machinery; their global Theorem 7.2 has additional reaction assumptions that are not asserted here.

Bounded web searches for third-order/cubic endotactic nonexplosion found these primary lines of work, not an identified general cubic theorem. That absence is not a novelty proof. Earlier unpublished duplication or a broader applicable theorem has not been ruled out. No grand release theorem is assumed validated or used to bootstrap a claim.

## Next decisive gate

For the strong-endotactic target, study the trace of the three-species chain near a low-count strip, for example C<max_source y_C<=3, while A,B are both unbounded and A/B->infinity, with no nontrivial pure 3A source. Excursions into the fully enabled region must be charged explicitly; a supplied fast-equilibration clock would not be valid.

The finite tropical source arrangement has exponents i+beta*j+gamma*k, i+j+k<=3, on 0<=gamma<=beta<=1. Orthogonal reactions must be removed in each direction. The missing load-bearing step is a proper stochastic Lyapunov function or an integrated excursion bound valid across all these regions and their interfaces. A trial correction B^2/(A+1) can match A B^2 conversion against A^2 B inward guards, but it does not yet control all lower-degree A B feedback or all low-C excursions; it is not a completed proof.

The present arguments therefore do **not** improve the universal minimum-order lower bound from three to four. They identify where a genuine cubic counterexample would have to evade the stopped estimates, and preserve exact failed constructions rather than reporting a false solution.

## Artifacts and provenance

- `face_cone_proof.md`: source-face, comparable-region and dominant-pure-source proofs;
- `fully_active_stopping_proof.md`: primary-tier-method reconstruction;
- `failed_constructions.md`: three explicit finite-kinetics routes and their failures;
- `verify_certificates.py`, `certificates.json`: reproducible exact finite certificates;
- `session.json`: sources, hashes, scope and status.

Started 2026-10-08 11:19:21 UTC. Bounded deliverable finalized before 11:54:21 UTC. No public claims, external messages, commits, or new task threads were created.
