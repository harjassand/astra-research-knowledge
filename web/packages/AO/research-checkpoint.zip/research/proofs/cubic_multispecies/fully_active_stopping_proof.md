# A published-tier-method restriction for strongly endotactic explosion

Status: internally reconstructed application of primary lemmas; no external review or novelty claim. This result is local to a stopped region. It does not prove global nonexplosion.

## Statement

Let a finite strongly endotactic reaction network have fixed finite positive stochastic mass-action constants. There is no source-order restriction in this paragraph. Put

    M_i = max_{source complexes y} y_i,
    D_active = {x in N_0^d: x_i >= M_i for every i}.

On any fixed stoichiometric class, the chain killed at its first exit from D_active is nonexplosive. Therefore an explosive path cannot eventually remain in D_active. In particular, in a cubic strongly endotactic system it must repeatedly encounter a state where some species count is below its source multiplicity threshold, which is at most three. The species that is low may vary along the path.

Use the conventional definition of strong endotacticity for directions outside the orthogonal complement of the stoichiometric subspace. Anderson-Cappelletti-Kim-Nguyen, arXiv:1808.05328v2, Definition 3.2, PDF p.5, gives this convention.

## Reconstruction

Use the source's entropy function U from equation (4.6), PDF p.14, with the continuous convention at zero; explicitly one may take

    U(x) = 1 + sum_i [x_i log x_i - x_i + 1],  0 log 0 = 0.

U is nonnegative and norm-like. Killing with cemetery value zero only lowers its generator.

Assume there were an unbounded sequence x_n in one fixed stoichiometric class intersected with D_active for which L U(x_n)>=-1. By Remark 4.1 (PDF p.8), pass to a subsequence for which z_n=x_n vee 1 is a tier sequence. Lemma 7.5 (PDF p.30) makes it transversal because all x_n lie in the same stoichiometric class. Theorem 4.2 (PDF p.10) then makes it tier descending.

Every source reaction is enabled throughout D_active. Uniformly for x in this region and for each source y there are positive finite constants a_y,b_y such that

    a_y z^y <= product_i (x_i)_(y_i) <= b_y z^y.

Indeed, where y_i>0, x_i>=M_i>=y_i and the ratio (x_i)_(y_i)/x_i^(y_i) is bounded below by its strictly positive value at x_i=M_i. Where y_i=0 the factor is one; zero coordinates with M_i=0 cause no problem. The fixed reaction constants can be absorbed into a_r,b_r. This uniform **positive lower bound** is exactly what fails when a source reaction switches off.

Lemma 7.4 (PDF p.30) supplies a constant C such that

    L U(x_n) <= sum_r lambda_r(x_n)
                         [log(z_n^(y'_r-y_r)) + C].

Partition reactions into descending reactions, whose logarithm tends to -infinity, and non-descending reactions, whose product/source ratio has a finite positive limit or tends to infinity. For a descending reaction the bracket is eventually negative, so the rate comparison gives the upper bound

    a_r z_n^(y_r) [log(z_n^(y'_r-y_r)) + C].

For every non-descending reaction, increase its additive constant if necessary to make the bracket nonnegative eventually. Its contribution is then bounded above using b_r rather than a_r.

Lemma 4.5 (PDF pp.15-17), equations (4.7)-(4.8), says that each non-descending contribution with any fixed positive coefficient and additive constant can be dominated by a descending contribution. Allocate to each such comparison an equal sufficiently small fraction of the available negative coefficients (for example 1/(2|R|)); this uses at most half of every descending coefficient. Along z_n>=1 every descending source monomial is bounded below by one, so equation (4.8) sends each paired expression to -infinity. The tier-descending property guarantees at least one descending reaction, and its remaining negative fraction also tends to -infinity. Thus the entire generator upper bound tends to -infinity, contradicting L U(x_n)>=-1.

Consequently, on this fixed class, L U<=-1 outside a finite set in D_active. Inside that finite set the generator is finite. A norm-like Foster bound follows, and it also holds for the killed chain. Standard nonexplosion follows from Xu's Proposition 3.5 (arXiv:2409.05340v2, PDF p.5). Applying the stopped assertion after each jump time gives the eventual-region claim.

## Attribution and limitation

This is an application of published tier and stochastic-generator lemmas, not a new major theorem. The proof does not apply to full endotacticity alone: Theorem 4.2 characterizes the stronger property. It also does not handle infinitely many exits from and re-entries into D_active. Those exits can occur arbitrarily late before a proposed explosion, and separately stopped chains do not establish a global Foster bound.

Primary comparator: https://arxiv.org/abs/1808.05328v2, especially Theorem 4.2, Lemma 4.5, Lemmas 7.4-7.5 and the proof of Theorem 7.2. Theorem 7.2 itself is a global positive-recurrence theorem with additional reaction assumptions; those additional assumptions are not claimed here.

Pinned PDF SHA256: 32ffcf9ede6c0bbb3bd0fa0276fb3e9bd44b438fde59d1757097493c46d59a76.
