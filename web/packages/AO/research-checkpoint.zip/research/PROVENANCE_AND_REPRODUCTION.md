# Provenance and reproduction

This is the checkpoint package for the research run begun on 8 October 2026 at 09:51:22 UTC. The user requested approximately three hours, then a checkpoint. The scientific status of each claim belongs in `CLAIM_LEDGER.json` and `REPORT.md`; an older proof or status note is retained as history and does not supersede that ledger.

The research corpus was pinned at [`687dfc0640ee80654bcbdbe38cb13d6e1f1586ce`](https://github.com/harjassand/astra-research-knowledge/tree/687dfc0640ee80654bcbdbe38cb13d6e1f1586ce). Work began with `00_START_HERE.txt`, then scoped reviewed cards, current frontier records, proof files and original papers. The source checkout remained unchanged. The OpenAI release was separately refreshed at commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`. Its release metadata listed 719 manuscripts in 372 families; neither that inventory nor retrieval coverage is proof validation. Older source versions remain identified in individual manifests.

## Models and resources

The configured proof, synthesis and adversarial-audit workers were `gpt-6.1-sol` at `max`. Scoped source extraction and finite-check workers used `gpt-6-luna` at `max`. Seventeen threads participated over the run: thirteen Sol workers, three Luna workers and the coordinator. These are reused workers, not seventeen simultaneous proof attempts. Assignments and exposure histories are recorded in session files.

The coordinator's observed configuration was `gpt-6-astra / ultra`; it was not silently represented as Sol. Model and effort were verified from the available runtime configuration records, which are not an independent attestation of backend identity.

For conservative concurrency accounting, every descendant—including each Luna worker—was reserved as one Sol equivalent, and the coordinator was reserved as ten. Even all descendants active together would use 26 of the permitted 30 reservation units. This deliberately does not equate twenty Luna workers with one Sol proof. Actual token snapshots and standard-rate-card estimates are in [the resource table](process/resource_usage.md) and [machine-readable records](process/resource_usage.json). Cached input and reasoning output are subsets, not additional tokens. Estimates are not billing records or a direct measurement of instantaneous token throughput.

## Evidence levels

- A written proof and an argument-exposed reconstruction are distinct from a fresh, target-only derivation. The relevant freeze times, hashes and exposures are preserved.
- Reproduced exact arithmetic, numerical matrix checks and finite examples support only their recorded scopes. They do not certify an infinite-state stochastic proof, an all-state quantum theorem or historical priority.
- No proof-assistant certification or external expert review is claimed.
- Bounded primary-literature searches identify comparators and scope differences. Failure to find an exact match does not establish novelty.

The diagnostics were rerun from isolated copies under `work/replay/`; frozen research inputs were not executed in place or modified by those replays. Each [verification run](verification/) records script hashes, exit status, wall time, stdout, stderr and generated results. The runner is retained in `process/replay_diagnostics.py`. After extracting the ZIP, run `python3 research/process/replay_diagnostics.py` to rerun the complete selected batch, or append one or more paths relative to `proofs/` to select scripts. In a packaged layout it writes its scratch copies and results to a newly created temporary directory, whose path it prints; it does not modify the sealed package. Use a fresh scratch directory when rerunning individual scripts because some write result files alongside themselves. Python, NumPy and mpmath support the retained diagnostic code; plotting additionally uses matplotlib. The recorded environment is in the replay metadata and `verification/environment.json`.

The phase diagram uses the proved candidate formula for the expected pair-death functional and ordinary finite-precision evaluation. Its data and plotting code are provided for reproduction. A picture is not independent proof evidence.

## Package integrity and history

`ARTIFACT_INVENTORY.json` identifies included research files and excluded acquired sources. Copies of retained proofs, diagnostics, failed approaches, superseded results and provenance are byte-preserving. Full acquired papers, PDF images, book extracts and downloaded source archives are not redistributed; their URLs, versions and hashes remain in source manifests. Acquired originals remain in the local work directory.

`PACKAGE_MANIFEST.json` and `SHA256SUMS` describe the final package. The ZIP was checked against those same bytes. Hash and ZIP checks establish packaging integrity only. The pinned corpus, source-reported checks, newly reproduced diagnostics, internal mathematical reviews, formal validation and external review are not interchangeable evidence categories.

The first replay of `critical_quantitative_audit/check_critical.py` failed because the runner had not copied its read-only proof-hash dependency into the isolated tree. The runner was corrected to include that dependency. Both the failed attempt and the subsequent result are preserved; this was a reproduction-harness failure, not a failed mathematical assertion.

The final portable package replay passed all 23 selected diagnostic scripts, with every script hash matching its packaged source and no stderr output. Its complete results are in `verification/packaged-replay/REPLAY.json`. The two PNG figures were also reproduced byte-for-byte from the packaged plotting scripts. These checks do not change the analytic, formal, external or priority status of any theorem.
