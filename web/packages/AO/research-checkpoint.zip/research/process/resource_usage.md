| Thread / task | Configured model / effort | Input | Cached | Output (reasoning subset) | Est. USD |
|---|---|---:|---:|---:|---:|
| root | gpt-6-astra / ultra | 24,014,487 | 23,673,088 | 106,596 (35,493) | $32.4169 |
| algebra | gpt-6.1-sol / max | 12,932,876 | 12,500,096 | 119,200 (72,353) | $3.3076 |
| chem_explosion_blind | gpt-6.1-sol / max | 6,226,562 | 5,996,288 | 126,869 (78,094) | $2.3289 |
| chem_geometry | gpt-6-luna / max | 9,286,821 | 8,985,856 | 85,525 (52,484) | $0.1627 |
| chem_order5_blind | gpt-6.1-sol / max | 3,194,162 | 3,091,584 | 86,875 (54,450) | $1.3831 |
| chemistry | gpt-6.1-sol / max | 8,957,081 | 8,683,264 | 134,786 (80,972) | $2.7638 |
| geometry_blind | gpt-6.1-sol / max | 10,727,298 | 10,221,696 | 105,622 (59,569) | $3.0896 |
| geometry_lower_audit | gpt-6.1-sol / max | 8,559,230 | 8,196,480 | 94,949 (48,920) | $2.4946 |
| independent | gpt-6.1-sol / max | 17,021,275 | 16,497,536 | 108,062 (46,456) | $3.7779 |
| integration | gpt-6.1-sol / max | 26,348,286 | 25,619,328 | 203,661 (74,970) | $6.0565 |
| marginal_blind | gpt-6.1-sol / max | 7,671,745 | 7,259,392 | 160,761 (97,185) | $3.1583 |
| release_mechanisms | gpt-6-luna / max | 41,893,092 | 40,061,440 | 228,304 (126,018) | $0.6979 |
| resources | gpt-6-luna / max | 22,706,353 | 21,504,000 | 137,091 (74,644) | $0.4038 |
| statistics | gpt-6.1-sol / max | 5,408,141 | 5,240,064 | 34,334 (16,331) | $1.2035 |
| tcs | gpt-6.1-sol / max | 9,721,462 | 9,220,096 | 108,228 (57,667) | $3.0070 |
| tcs_audit | gpt-6.1-sol / max | 11,138,466 | 10,622,592 | 167,794 (82,033) | $3.7719 |
| thermal | gpt-6.1-sol / max | 13,332,694 | 12,881,792 | 154,615 (70,845) | $3.7361 |
| **Total, root included** | 17 threads | 239,140,031 | 230,254,592 | 2,163,272 (1,128,484) | $73.7601 |

Usage is the latest cumulative thread snapshot per log, never the sum of repeated snapshots. Cached input is a subset of input; reasoning output is a subset of output. USD values apply the supplied standard rate card and are estimates, not billing records. `turn_context` records the configured runtime model and effort; it does not attest backend identity.
