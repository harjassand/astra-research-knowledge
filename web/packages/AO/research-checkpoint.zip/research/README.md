# Research checkpoint — 8 October 2026

The strongest results are internally proved and audited candidates in stochastic reaction networks and quantum information. No externally established major breakthrough, formal certification or cleared historical priority is claimed.

Start with the [scientific report](REPORT.md). The [claim ledger](CLAIM_LEDGER.json) is the current status record; older statements in the preserved proof history do not supersede it. The [dependency graph](DEPENDENCIES.json) records which premises, proofs and audits support each result.

The leading results are:

- A strongly endotactic order-five reaction network with an exact all-positive-rate explosion boundary, together with nonexplosion for every fully endotactic two-species network of source order at most three. The internal minimum-order bounds are **four or five in two species**, and **three, four or five in arbitrary dimension**.
- A fixed-dimension quantum theorem converting uniform collective concentration into quadratic local Petz divergence and relative entropy from the actual product marginal. A narrower white-Schur family admits a matched, charged entanglement-certification tradeoff.
- A sharp square-root subsystem window for the exact critical isotropic Curie–Weiss Gibbs state, including bounded measurement witnesses and quantitative entropy bounds.

Full arguments, genuinely fresh target-only derivations, argument-exposed audits, counterexamples and superseded routes are preserved in [proofs/](proofs/). The scientific report identifies the most useful entry points and unresolved obligations.

For the model configuration, resource accounting, pinned commits, source provenance and evidence distinctions, read [provenance and reproduction](PROVENANCE_AND_REPRODUCTION.md). This package was produced with language-model assistance throughout; internal review is not external expert review.

After extracting the archive, reproduce the selected diagnostics with:

```sh
python3 research/process/replay_diagnostics.py
```

The runner uses a fresh temporary directory and prints its results location. Dependencies and versions are recorded in [environment.json](verification/environment.json). Exact and floating-point diagnostics have distinct scopes; neither certifies the analytic theorems. Prior run records are indexed in [REPLAY_SUMMARY.json](verification/REPLAY_SUMMARY.json).

From inside the extracted `research` directory, check archive-file integrity with:

```sh
shasum -a 256 -c SHA256SUMS
```

Full acquired papers are excluded from the distributable archive. Their exact versions, locations and hashes remain in source manifests and [the artifact inventory](ARTIFACT_INVENTORY.json).
