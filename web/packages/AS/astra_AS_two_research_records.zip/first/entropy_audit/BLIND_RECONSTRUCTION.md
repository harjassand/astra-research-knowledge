# Blind reconstruction of the factorial relative-entropy candidate

Recorded before opening the originating candidate file. Date: 2026-10-08.

## Finding
The stated two-sided all-copy estimate appears provable. A direct reduction-criterion argument avoids any subtle asymptotic interchange or appeal to a distillation theorem.

Let N=2n, a_J=1/(2J+1)!!, and m_{r,j}=binom(r,r/2-j)-binom(r,r/2-j-1). Logs can be natural (change constants/base together).

## Upper bound
Take the uniform mixture of all computational basis product strings with n up and n down spins, then twirl by the collective SU(2) action. This is fully N-lab separable. Its eigenvalue on every copy of the spin-J irrep is [binom(2n,n)(2J+1)]^{-1}. Thus R_N <= [binom(2n,n)/Z_N] sigma <= (n+1) sigma, since Z_N >= m_{2n,0}=binom(2n,n)/(n+1). The first inequality uses (2J+1)a_J=1/(2J-1)!! <=1. Consequently D(R_N||sigma)<=log(n+1), and tensor powers give the desired upper bound for every k. Here (-1)!!=1.

## Lower bound: local Schur flags
Group the first n labs into A, the other n into B. Measure each half's Schur spin j,l, communicate both outcomes to both halves, and discard multiplicity registers. The resulting flagged state has probability p_{jl}=m_{n,j}m_{n,l}t_{jl}/Z_N and spin state rho_{jl}=t_{jl}^{-1} sum_{J=|j-l|}^{j+l} a_J P_{jl,J}, where t_{jl}=sum_J(2J+1)a_J (only admissible J). Both marginal spin states are maximally mixed; in particular S((rho_{jl})_B)=log(2l+1). The flags must be copied to both parties to obtain an average, rather than lose a flag conditional entropy.

The mean spin entropy has an absolute upper bound:
S(rho_{jl})=log t_{jl}+sum_J q_{J|jl} log(1/a_J).
Set T=sum_{J>=0}(2J+1)a_J<infinity. Since m_{2n,J}/m_{2n,0}<=2J+1 and Z_N>=m_{2n,0}, global total-spin probabilities satisfy q_J<=(2J+1)^2 a_J. Thus mean S(rho_{jl}) <= log T + sum_{J>=0}(2J+1)^2 a_J log(1/a_J), an absolute finite constant.

## Mean irrep dimension
Elementary central-binomial estimates give, for n>=1,
m_{n,j} <=2 sqrt(2) 2^n(2j+1)/(n+1)^(3/2),
Z_N>=m_{2n,0}>=4^n/[2(n+1)^(3/2)].
Let A0=sum_{J>=0}(2J+1)^2 a_J<infinity. Using the SU(2) dimension identity sum_{j admissible in l tensor J}(2j+1)=(2l+1)(2J+1), extending past the half-size cut-off when needed, gives
Pr(l) <=16 A0 (2l+1)^2/(n+1)^(3/2).
Consequently Pr(2l+1 <= x sqrt(n+1)) <=C0 x^3 for an absolute C0 (with zero probability below the smallest allowed dimension). Layer-cake integration yields
E log(2l+1) >= (1/2)log(n+1) - (log(max(C0,1))+1)/3.
This implies E log(2l+1) >= (1/2)log(N+1)-an absolute constant.

## Every copy number directly
For any separable omega_AB, omega_AB <= I_A tensor omega_B. Operator monotonicity of log gives D(tau_AB||omega_AB) >= S(tau_B)-S(tau_AB). This extends by continuity/support conventions when necessary. Apply it to the output of the same flagged LOCC map independently on k copies, noting that any state separable across the N original lab blocks is separable across A^k:B^k, even if each original lab entangles its k local registers. Data processing and additivity of coherent information on the output tensor product yield
D(R_N^tensor k||sigma) >= k E_{jl}[log(2l+1)-S(rho_{jl})] >= k[(1/2)log(N+1)-C].
No limit in k, distillation rate, or regularization exchange is required. The LOCC map may operate jointly within a half because it only needs to preserve the coarser A:B separability.

## Checks to perform against the originating proof
- Exact multiplicity and projector normalization, including parity for odd half-size n.
- Flags must be shared at both sides for coherent information.
- Entropy bound must average under actual spin-J probabilities, not factorial weights alone.
- Lower tail estimates should be uniform in n, not merely a central-limit asymptotic.
- Claimed all-copy bound must use A^k:B^k grouping, not copywise separability.
- Upper comparator must be fully original-lab separable, not only bipartite separable.
