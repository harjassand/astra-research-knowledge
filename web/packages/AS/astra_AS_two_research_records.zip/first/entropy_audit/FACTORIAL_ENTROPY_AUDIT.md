# Independent adversarial audit: factorial all-copy entropy bound

Date: 2026-10-08. Audit target: `../frontier/FACTORIAL_REGULARIZED_ENTROPY_CANDIDATE.md`.

## Verdict

**Pass.** The precise candidate theorem is correct under its stated conventions. I found no invalid operation, asymptotic inference, copy-factorization assumption, normalization error, or limit exchange. A blind proof reconstruction was written to `BLIND_RECONSTRUCTION.md` before opening the candidate. Its mechanism independently agrees with the candidate's proof.

This is a mathematical correctness assessment, not an assessment of novelty or historical importance. No N-party distillation claim follows. The proof establishes a lower bound against N-party-separable alternatives by operations local only for a coarser balanced bipartition.

## Step-by-step audit

### Scope and exact state

For N=2n, all J are integers in 0,...,n. The full projector P_(2n,J) has rank (2J+1)m_(2n,J), so the stated Z and p_J are correctly normalized. The positive double-factorial weights make the factorial state full rank. FULLSEP_(N,k) allows arbitrary entanglement among each laboratory's k registers; nothing in the proof forbids this.

### Grouped operation and conditional law

Each original-laboratory-separable alternative is separable across A^k:B^k. The grouped local Schur transforms, spin measurements, discarding of multiplicity spaces, and communication/copying of classical outcomes preserve that coarser separability. They need not preserve the original N-partition, and the proof does not assume otherwise.

The Schur decomposition and multiplicity-one Clebsch-Gordan rule give the stated q_ab and rho_ab exactly. For odd n, both a and b are half-integral and their admissible J values remain integral. Discarding multiplicity systems introduces their dimensions m_(n,a)m_(n,b), with no missing irrep-dimension factor. The (2J+1) factor is already in z_ab.

Schur's lemma gives the B marginal I/(2b+1), since rho_ab is invariant under the simultaneous irrep action and its partial trace commutes with the irreducible B action. Both sides retain the identical joint flag (a,b), so the flag Shannon entropy cancels exactly. Merely retaining each local flag on its own side would not justify the stated coherent information; the candidate explicitly does the correct shared-flag operation.

Summing admissible m_(n,a)m_(n,b) recovers m_(2n,J); this is the correct multiplicity identity. The conditional total-spin label is a spectral-analysis device, not an additional global measurement in the physical map.

### Conditional entropy

The formula S(rho_ab)=log z_ab+E[log(1/f_J)|a,b] includes the spectral degeneracy correctly. The ratio m_(2n,J)/m_(2n,0) is exact, and its bound by 2J+1 holds all the way to J=n. Hence p_J <= (2J+1)^2 f_J is valid uniformly in N. Summing the entropy moment is legitimate and finite. This is stronger than merely asserting tightness of total spin, which alone would not control entropy.

### Local-spin lower tail

The multiplicity upper and singlet multiplicity lower bounds are uniform, not central-limit approximations. C_0=4 and c_0=1/2 are safe, including n=1 and either parity. The factor 2J+1 counting possible local a values is safe even for half-integral a,b. The candidate's cubic moment in A is conservative but correct.

An optional sharpening replaces that counting argument with the exact dimension identity

    sum_(a in b tensor J) (2a+1) = (2b+1)(2J+1).

Extending beyond the physical a<=n/2 cutoff can only enlarge the sum. Thus A may be replaced by (C_0^2/c_0) sum_J (2J+1)^2 f_J. No sharpening is necessary for the theorem.

In summing the marginal bound, the allowed dimensions 2b+1 form a subset of the positive integers. For y>=1, their square sum up to y is at most floor(y)^3<=y^3; for y<1 it is zero. Thus the candidate can take A'=max(1,A) directly. The layer-cake integral and its value (log A'+1)/3 are correct. The passage from n to N=2n loses only (log 2)/2, since (N+1)/(n+1)<2.

An explicit valid final constant is

    C = B + (log A'+1)/3 + (log 2)/2.

With the candidate's stated C_0,c_0 and cubic A, the displayed defining series numerically give C approximately 14.4457 nats. This decimal is only a diagnostic; the exact series expression is already rigorous and avoids any interval-certification issue.

### Every copy count

For any A:B-separable normalized sigma, sigma <= I_A tensor sigma_B. Operator monotonicity of logarithm therefore gives D(omega||sigma) >= S(omega_B)-S(omega), with the additional nonnegative marginal relative entropy correctly included in the intermediate equality. Singular cases are covered by the support convention or by mixing sigma with an arbitrarily small full-rank product state and taking a limit.

The independent preprocessing map on the k input copies maps every admissible alternative to an A^k:B^k-separable state. It does not assert independence of that alternative between copies. Relative-entropy data processing, the separable reduction inequality on the entire output, and additivity of coherent information for the actual product output omega^tensor k prove the lower bound for every integer k. There is no distillation theorem, de Finetti theorem, multiplicative overlap assertion, or illicit rearrangement of original laboratory copies hidden in this argument.

### Fully separable upper comparator

Permuting the balanced product string uniformly produces the normalized projector onto the computational magnetization-zero subspace. In each spin-J irrep this is |J,0><J,0| tensor identity on the multiplicity space. Collective SU(2) twirling replaces the rank-one irrep factor by I/(2J+1). This proves the claimed tau exactly and preserves full original-laboratory separability.

The eigenvalue ratio bound uses (2J+1)f_J=1/(2J-1)!!<=1, with (-1)!!=1, and Z>=m_(2n,0). It is correct at J=0 and J=1 as well as all larger J. Operator monotonicity, or direct diagonal comparison, gives the relative-entropy bound. Tensoring the comparator keeps it separable across the N laboratories, including the allowed k-register laboratory blocks.

### Limits and stated consequences

At fixed N, the optimized k-copy sequence is subadditive because product comparators remain N-party separable. Fekete's lemma gives existence of its per-copy limit. The established bounds already hold uniformly in k, so subsequent N asymptotics require no interchange of limits. The Theta(log N) conclusion and coefficient bracket [1/2,1] are valid. An exact leading coefficient, noise robustness, efficient implementation, and N-party distillation remain unproved, as the candidate correctly states.

The optional grouped hashing corollary is consistent with the coherent information obtained. It is not needed for the mathematical theorem audited here.

## Numerical and finite checks

The candidate's finite-check script and output were inspected after the blind proof was recorded. Its cutoff calculations concern a normalized truncated state and are appropriately labeled as diagnostics rather than certified bounds on the untruncated answer. The analytical factorial tail dominates the omitted global mass; a quantitative certified entropy error would require an additional continuity/tail-entropy estimate if numerical intervals were later claimed. No such claim is currently made.

`independent_checks.py` independently verifies:

- Exact rational factorial flag normalization and global-spin recovery for every even N=2,...,48.
- Exact magnetization-twirl normalization and spin-sector eigenvalue ratios in the same range.
- Exact integer fixed-sector local-spin normalization for n=1,...,128 and every global J.
- Numerical checks of the uniform multiplicity, cubic-tail, and conditional log-dimension inequalities, including both half-size parities.

All assertions passed. Full results are in `independent_results.json`. They supplement, and do not replace, the analytic proof.

## Reusable mechanism

A stronger proven generalization, including N-dependent central mixtures with uniformly bounded logarithmic total spin, is provided separately in `GENERAL_CENTRAL_ENTROPY_THEOREM.md`. The generalization also has the exact same universal upper bound. These extensions are mathematical consequences of the mechanism, not claims of historical priority.
