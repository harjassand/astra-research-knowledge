# Targeted prior-art comparison: central low-spin mixtures

Checked 2026-10-08 against primary texts. This is a scope/overlap check, not proof certification or an exhaustive novelty search.

## Finding

The singlet logarithmic law, the representation-space distillation mechanism, ordinary-LOCC interpretation, and its implication for relative-entropy lower bounds are established prior art. Nonzero total spin is also treated in a fixed magnetic sector in the 2024 paper. The proposed extension must therefore be stated narrowly: a uniform quantitative estimate for **unflagged, fully irrep-averaged central mixtures**, controlled by the global-spin logarithmic moment, with the specified original-lab separability set. No inspected theorem yet supplies precisely that estimate.

The candidate being compared is, for N=2n,

ρ_N = Σ_J p_{N,J} P_{N,J}/[(2J+1)m_{N,J}],

k[½ log(N+1) − C − 4 Σ_J p_{N,J}log(J+1)] ≤ E_R^{FULLSEP_N}(ρ_N^{⊗k}) ≤ k log(n+1).

Here FULLSEP_N at copy number k is the convex hull of ⊗_{i=1}^N τ_i, where τ_i is an arbitrary state on the k qubits held by original laboratory i. It is not separability over Nk individual qubits. Constants/log bases must be fixed consistently in the proof.

## Primary sources and actual statements

### 1. Livine–Terno (2005)

[Entanglement of zero angular momentum mixtures and black hole entropy, quant-ph/0502043v2](https://arxiv.org/pdf/quant-ph/0502043), especially Eqs. (19), (28)–(30), (33)–(36), pp. 3–5.

For the normalized global-singlet projector, the balanced-cut entanglement is

E_D = E_F = Σ_j [m_{n,j}²/m_{2n,0}] log(2j+1) ∼ ½ log n.

The proof locally resolves representation/multiplicity labels and distills the resulting spin-j singlet; a matching formation decomposition proves equality. The final proposition permits arbitrary weights on states of the form |Φ_j⟩⟨Φ_j|⊗|a_j⟩⟨a_j|⊗|b_j⟩⟨b_j|. Its displayed scope is narrower than arbitrary density operators in the entire singlet multiplicity space, despite broad wording in the abstract. It does not mix nonzero global J sectors. Operations and entanglement are ordinary bipartite LOCC, not a symmetry-restricted operational resource.

### 2. Moharramipour–Lessa–Wang–Hsieh–Sahu (2024)

[Symmetry enforced entanglement in maximally mixed states, 2406.08542v2](https://arxiv.org/html/2406.08542v2), PRX Quantum 5, 040336; §§IV.1–IV.3.1 and VI.1.

Equation (16) gives E_D=E_F and the intervening bipartite measures for the maximally mixed invariant sector of any compact group. Section IV.1 explicitly includes relative entropy against ordinary bipartite separable states; §VI.1 supplies the SU(2) half-cut ½ log N+O(1) law.

Important additional overlap: §IV.3.1, Eq. (17), gives an exact average Clebsch–Gordan pure-state entropy for E_D=E_F of each **fixed global (J,M)** maximally mixed multiplicity sector, including J≠0. Local subsystem spins and multiplicities identify its pure components. Averaging over M produces a different state: those magnetic labels are not supplied as local flags. The paper therefore already covers more than singlets, but the displayed nonzero-J result is not the candidate central mixture theorem.

### 3. Zeng (2026), latest version

[Thermal Activation of Divergent Distillable Entanglement under Non-Abelian Strong Symmetry, 2607.12710v2](https://arxiv.org/html/2607.12710v2), 30 July 2026. The v1 title was different.

Theorem 1 proves Y_N=½ log₂N+O_β(1), E_D≥Y_N, on a finite high-temperature interval for reflection-symmetric, finite-period, bounded finite-range, locally SU(2)-invariant chains constrained to global J=0. The dimer model gives E_D=E_F=Y_N for every size and logarithmic growth at every fixed positive temperature.

Equation (4), Methods §4.2, and Appendix A, Lemma A.1 explicitly allow arbitrary singlet-sector multiplicity states and coherences between subsystem-spin sectors. Local representation measurement, then discarding multiplicities, yields Y_N=Σ_j p_j log₂(2j+1). These are standard LOCC operations, potentially collective within each half. The theorem estimates subsystem-spin fluctuations of noncentral singlet Gibbs states; it does not allow leakage into nonzero global J.

### 4. Mo–Altman–Garratt (2026)

[Thermal entanglement transitions from strong SU(2) symmetry, 2610.00826v1](https://arxiv.org/html/2610.00826v1), submitted 30 September 2026.

Equation (2) fixes the state to Π₀e^{−βH}/Z. Section III explicitly extends its information-theoretic bounds to every singlet state. Equations (9)–(10) give E_D≥Σ_s p(s)log₂(2s+1); Eqs. (14)–(15) give a separate logarithmic-negativity lower bound log₂Σ_s p(s)(2s+1). Local representation/multiplicity measurements prove the first bound. When the state is diagonal in the displayed locally distinguishable singlet basis, the distillation bound is exact (§III.1).

Its main physical advance concerns finite-temperature ferromagnetic ordering and changes in entanglement scaling, developed via semiclassical theory and numerics. Centrality is not required, but exact global J=0 is. Negativity is not relative entropy, although its separate standard-LOCC distillation bound already implies relative-entropy lower bounds. This paper is not a nonzero-global-spin robustness theorem.

### 5. Li–Pollmann–Read–Sala (2024/2025)

[Highly-entangled stationary states from strong symmetries, 2406.08567](https://arxiv.org/abs/2406.08567), [Phys. Rev. X 15, 011068](https://journals.aps.org/prx/pdf/10.1103/PhysRevX.15.011068).

Published §V.C, Eqs. (37)–(39), and Appendix E.2 study nonzero-J mixtures with fixed total magnetization M=0, rather than full-irrep-averaged central states. Their diagnostic there is bipartite logarithmic negativity. Analytic logarithmic results cover J=0 and maximal J with M=0; other fixed-density sectors and generic mixtures are investigated numerically. The introduction identifies persistence for finitely many sectors as an expectation. The commutant-dimension upper bound, Eq. (13), concerns the singlet stationary state and negativity, not FULLSEP relative entropy.

Source-verification caveat: the arbitrary-mixture expression at Eq. (39)/(E10) has an unresolved extracted-text rendering issue and is not relied on here. No claim of a published error is made. The distinction from the candidate's state class holds independently of this caveat.

## Consequences for positioning (mathematical comparison, not source quotations)

1. **The all-copy lower-bound format alone does not rescue singlet novelty.** For any balanced cut, FULLSEP_N^(k)⊂SEP(A^k:B^k), even with arbitrary within-lab cross-copy entanglement. Thus E_R^{FULLSEP_N}(ρ^{⊗k})≥E_R^{A^k:B^k}(ρ^{⊗k})≥kE_D^{A:B}(ρ). The old singlet distillation law already gives a uniform-in-k logarithmic FULLSEP lower bound.
2. **Neither exact bipartite formulas nor their upper bounds give a FULLSEP upper bound.** That requires an original-N-lab separable comparator. A universal k log(n+1) bound for the stated central class remains a separate claim to justify.
3. **Centrality is substantive.** SU(2) commutation alone allows arbitrary states in multiplicity spaces. A tensor product of N/2 two-qubit singlets is globally J=0 but has FULLSEP relative entropy (N/2)log 2; therefore an O(log N) upper bound cannot extend to arbitrary singlet or weakly SU(2)-invariant states. It is also permutation noncentral.
4. **Global and subsystem spin must not be conflated.** The proposed penalty concerns global J. The old singlet formula concerns subsystem j≈√N while global J=0 exactly.
5. **The most relevant antecedent for the new estimate is Eq. (17) of the 2024 paper.** Combining its fixed-(J,M) result with entropy-of-mixing inequalities is a natural alternate route to investigate. This comparison does not establish that the explicit coefficient 4 or the desired uniform finite-N estimate follows immediately.

## Defensible claim boundary

Conditional on a valid proof, describe the result as an explicit low-global-spin robustness bound for central qubit states, yielding Θ(log N) regularized relative entropy to original-lab FULLSEP when sup_N E_{p_N}log(J+1)<∞. This permits N-dependent spin distributions without an N-independent support cutoff, subject to the moment condition.

Do not claim the first logarithmic mixed-state law, first nonzero-spin entanglement theorem, first ordinary-LOCC interpretation, first arbitrary-singlet multiplicity bound, or first logarithmic singlet regularized-FULLSEP lower bound. The targeted check establishes a remaining **candidate quantitative extension**, not priority, independent discovery, or mathematical validity.
