# A central-state generalization with a logarithmic total-spin condition

Date: 2026-10-08. Proven consequences of the balanced-half Schur method. Historical priority is not assessed.

All logarithms are natural. Let N=2n>=2. Let m_(r,j) denote spin multiplicity, P_(2n,J) the entire spin-J projector, and d_J=2J+1. Consider an arbitrary central state

    rho_N = sum_(J=0)^n p_(N,J) rho_(N,J),
    rho_(N,J) = P_(2n,J)/(d_J m_(2n,J)),

where p_(N,J) is any probability law. Here central means scalar on every full spin-J isotypic component; arbitrary states commuting only with collective SU(2) but acting nontrivially on multiplicities are not covered.

## Theorem

Set M_N=sum_J p_(N,J) log(J+1). There is an absolute constant C_* such that, for every N and k>=1,

    k[ (1/2)log(N+1) - C_* - 4 M_N ]
       <= inf_(sigma in FULLSEP_(N,k)) D(rho_N^tensor k || sigma)
       <= k log(N/2+1).

Consequently, any family of central states satisfying sup_N M_N<infinity has the same [1/2,1] logarithmic-order bracket, uniformly in k. Neither a positive singlet weight nor N-independent spectral weights are required.

A more informative finite-N lower bound is

    k[ (1/2)log(N+1) - C_dim - H(p_N)
       - E_p log(2J+1) - E_p log(J+1) ],

where C_dim is absolute. This formula separates local-irrep dimension loss from the entropy of mixing total-spin sectors.

One explicit choice is

    A_*=64 e^2,
    C_tail=(log A_*+1)/3,
    C_dim=C_tail+(log 2)/2,
    C_*=C_dim+log(2 zeta(2)).

These constants are intentionally conservative.

## 1. Uniform conditional local-spin dimension

Fix total spin J. The joint law of the two local half-spins a,b is

    q_(ab|J) = m_(n,a)m_(n,b)/m_(2n,J)

on admissible Clebsch-Gordan triangles. No d_J appears here: the d_J factor in the projector rank cancels in conditioning on J.

Use the uniform multiplicity estimates

    m_(n,a) <= 4*2^n*(2a+1)/(n+1)^(3/2),
    m_(2n,0) >= (1/2)*4^n/(n+1)^(3/2).

For J<=sqrt(n),

    m_(2n,J) >= (e^(-2)/2) (2J+1) m_(2n,0).       (A)

To prove (A), write

    m_(2n,J)/[(2J+1)m_(2n,0)]
       = (n+1)/(n+J+1)
          * product_(r=0)^(J-1) (n-r)/(n+r+1).

For n>=4 and J<=sqrt(n), put x_r=(2r+1)/(n+r+1). Then 0<=x_r<=1/2: indeed r<=sqrt(n)-1 gives 3r+1<=n. The elementary log bound log(1-x)>=-2x for 0<=x<=1/2 yields

    log product >= -2 sum_r (2r+1)/n = -2J^2/n >= -2.

The prefactor is at least 1/2. The finitely many cases n=1,2,3 satisfy (A) directly.

Now the exact CG dimension identity, after allowing all a in b tensor J, is

    sum_a (2a+1) = (2b+1)(2J+1).

The physical upper cutoff a<=n/2 only reduces this sum. Applying the two multiplicity upper bounds and (A) gives, uniformly for J<=sqrt(n),

    q_(b|J) <= A_* (2b+1)^2/(n+1)^(3/2).

Both integer and half-integer local-spin parities are included. Summing over dimensions up to x sqrt(n+1), then integrating the logarithmic lower tail, gives

    E[log(2b+1)|J] >= (1/2)log(n+1)-C_tail

for J<=sqrt(n).

For J>sqrt(n), integer J obeys J^2>=n+1, and the trivial bound E[log(2b+1)|J]>=0 implies

    E[log(2b+1)|J]
       >= (1/2)log(n+1)-C_tail-log(J+1).

The same weaker inequality holds for the low-J range as well. Averaging therefore gives

    E log(2b+1) >= (1/2)log(n+1)-C_tail-M_N.       (B)

This step is why a uniform logarithmic moment, rather than a fixed positive low-spin mass alone, suffices for a full one-half coefficient with only constant loss.

## 2. Conditional spin entropy

Use the same grouped Schur operation as for the factorial state, with the joint classical flag (a,b) retained on both sides. Conditional on (a,b), the spin state has orthogonal spin-J blocks, each maximally mixed within its d_J-dimensional irrep. Hence exactly

    average_(a,b) S(rho_ab)
       = H(J|a,b) + E_p log(2J+1)
       <= H(p_N) + E_p log(2J+1).                 (C)

This is valid with zero weights and needs no formula involving log f_J.

Combining (B) and (C) gives the stated informative coherent-information lower bound. For the simpler logarithmic-moment condition, compare p_N to the probability law

    r_J = 1/[zeta(2)(J+1)^2], J>=0.

Nonnegativity of classical relative entropy gives

    H(p_N) <= 2M_N + log zeta(2),
    E_p log(2J+1) <= M_N + log 2.

Thus average conditional spin entropy is at most 3M_N+log(2 zeta(2)), while the dimension term loses at most one further M_N. Replacing n+1 by N+1 costs at most (log 2)/2.

## 3. All-copy lower bound

For any bipartite separable sigma, sigma<=I_A tensor sigma_B, which implies D(omega||sigma)>=I(A>B)_omega. Apply grouped preprocessing separately to every copy. An alternative separable across the original N laboratory blocks, despite arbitrary within-laboratory cross-copy entanglement, maps to an A^k:B^k-separable state. Data processing and additivity of the output coherent information multiply the bound by k. This is a finite-k argument; no asymptotic distillation theorem or exchange of limits is needed.

## 4. Universal upper bound for every central state

The upper requires no restriction on p_N. For each integral J in 0,...,n, take a computational-basis product string of magnetization J, average over all site permutations, and twirl by the common SU(2) action. Call the resulting fully separable state tau_(N,J). The permutation average is the normalized projector onto magnetization J, whose Schur form is

    [binom(2n,n-J)]^(-1)
       direct_sum_(L=J)^n |L,J><L,J| tensor I_(M_(2n,L)).

SU(2) twirling therefore gives exactly

    tau_(N,J)
       = [binom(2n,n-J)]^(-1) sum_(L=J)^n P_(2n,L)/(2L+1).

Normalization follows from sum_(L>=J)m_(2n,L)=binom(2n,n-J). On the spin-J support,

    (eigenvalue rho_(N,J))/(eigenvalue tau_(N,J))
       = binom(2n,n-J)/m_(2n,J)
       = (n+J+1)/(2J+1) <= n+1.

On all other sectors rho_(N,J) vanishes, so this is the operator inequality rho_(N,J)<=(n+1)tau_(N,J). With

    tau_N = sum_J p_(N,J) tau_(N,J),

we obtain the fully separable comparator rho_N<=(n+1)tau_N. Therefore D(rho_N||tau_N)<=log(n+1), and tau_N^tensor k proves the all-copy upper. Collective SU(2) and site permutations preserve single-copy original-laboratory separability; no independent cross-copy permutation is used.

Joint convexity also gives the optional sharper single-copy upper

    E_R(rho_N) <= E_p log[(n+J+1)/(2J+1)].

## 5. Fixed spectral-weight corollary

Suppose f_J>=0 is independent of N, f_0>0, and

    sum_(J>=0) (2J+1)^2 f_J (1+|log f_J|) < infinity,

with 0|log 0| interpreted as zero. For rho_N proportional to sum_J f_J P_(N,J), the original direct proof works: the CG dimension identity requires only the quadratic moment; the same weighted logarithmic sum bounds conditional entropy. Thus the user's proposed sufficient condition is valid, and the exact universal upper remains k log(n+1).

An alternative sufficient condition, directly from the more general theorem, is

    f_0>0 and sum_J (2J+1)^2 f_J log(J+2) < infinity.

Indeed p_(N,J) <= (2J+1)^2 f_J/f_0, so M_N is uniformly bounded. This condition controls the state family's logarithmic spin moment without requiring an absolute log-weight entropy moment. These two sufficient conditions should not be silently conflated; the proof under each is given explicitly.

## 6. What is not sufficient or not established

- Bounded Shannon entropy H(p_N) alone is insufficient. Let p_(N,J) be concentrated at J=n. Then H(p_N)=0, but rho_N=P_sym/(N+1) is fully separable: it is the SU(2) twirl of |up>^tensor N. Its relative entropy of entanglement vanishes.
- Bounded entropy H(p_N)+E log(2J+1) of the direct-sum total-spin state is sufficient, since it controls M_N. Bounded ordinary positive moments E[J^alpha], alpha>0, are also sufficient. The logarithmic moment is the weakest condition proven here among these named options.
- No necessity claim for bounded M_N is made. States whose total spin grows with N may still have logarithmic entanglement; this theorem does not characterize all such families.
- Mere tightness of p_N is not used as an entropy bound and is not asserted sufficient.
- The theorem does not cover arbitrary noncentral states with a similar p_N, does not establish an exact leading coefficient, and does not yield distillation by the original N separate laboratories.
- All conclusions here are proved sufficient conditions or explicit counterexamples. No new conjectural extension is needed.
