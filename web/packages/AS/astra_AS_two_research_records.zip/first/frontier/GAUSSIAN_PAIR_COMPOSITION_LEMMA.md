# Pairwise composition certificate for the admitted Gaussian channels

Status: elementary internally reconstructed extension of the source's same-channel square argument. No historical novelty claimed. The existence of channels satisfying the source's simultaneous CP/PPT/non-EB events is not re-proved here. The assertion below is deterministic and conditional on the explicit hypotheses, so it does not require independence or any Gaussian distribution.

## Exact statement

Fix dimension d and a Hilbert-Schmidt orthonormal family {S_a}_{a=1}^h of real symmetric traceless d-by-d matrices: Tr(S_a S_b)=delta_ab. It need not span all traceless complex matrices. Let g_1,g_2 be real h-by-h matrices obeying

    ||g_i||_op <= 8d,       ||g_i||_F <= d^2.

Define Delta(X)=Tr(X)I/d and

    R_i(X) = (1/(6d^2)) sum_ab (g_i)_ab Tr(S_a X) S_b,
    Lambda_i=Delta+R_i.

Assume Lambda_i are channels (CP and trace preserving); the source additionally imposes PPT, but PPT is not needed for the conclusion. Then Lambda_2 composed with Lambda_1 is entanglement breaking. This holds for arbitrary correlated g_1,g_2 satisfying the norm bounds, including adversarial alignment and g_1=g_2.

## Proof

Tracelessness gives Delta R_i=R_i Delta=0, while Delta^2=Delta. Hence

    Lambda_2 Lambda_1=Delta+R_2 R_1.

Applying the two maps and using orthonormality gives

    R_2 R_1(X)
      = (1/(36d^4)) sum_ac (g_1 g_2)_ac Tr(S_a X) S_c.

This product order follows the coefficient convention R_i(X)=sum_ab g_i,ab Tr(S_aX)S_b; representing the transfer matrix on coordinate column vectors instead gives the transposed order.

Use the unnormalized input-first Choi operator

    J(T)=sum_uv |u><v| tensor T(|u><v|).

For a rank-one superoperator X -> Tr(S_a X)S_c its Choi operator is S_a^T tensor S_c. Since S_a are real symmetric, S_a^T=S_a. Also J(Delta)=I_(d^2)/d. Consequently

    d J(Lambda_2 Lambda_1) = I_(d^2)+E,
    E=(1/(36d^3)) sum_ac (g_1 g_2)_ac S_a tensor S_c.

E is Hermitian because all coefficients are real and each tensor basis element is Hermitian. Orthonormality yields

    ||E||_F = ||g_1 g_2||_F/(36d^3)
       <= ||g_1||_op ||g_2||_F/(36d^3)
       <= 8d*d^2/(36d^3)=2/9<1.

The Gurvits-Barnum bipartite identity-ball theorem says every Hermitian I+E with ||E||_F<=1 is separable as an unnormalized positive operator. Apply it to dJ. Positive scalar rescaling preserves separability, so J(Lambda_2 Lambda_1) is separable. The Choi characterization of entanglement-breaking channels now proves the assertion.

No inference was made from merely failing a separable-ball test. This is a positive separability certificate. CP/PPT existence and non-EB of each individual Lambda remain separate source assertions and are not needed to compute the composition norm.

## General norm formulation

For bistochastic channels Delta+R_i with Delta R_i=R_i Delta=0, Choi reshuffling preserves Frobenius norm. Therefore

    d ||J(R_2 R_1)||_F <= d ||R_2||_(2->2) ||R_1||_F <=1

is a sufficient EB-composition criterion, with ||R_1||_F denoting the Frobenius norm of its full superoperator matrix in an orthonormal operator basis. The displayed family has ||R_i||_(2->2)<=4/(3d) and ||R_i||_F<=1/6, giving the same 2/9 bound. This formulation must not confuse operator norm of a Choi reshuffle with superoperator norm; only Frobenius norm is automatically preserved.

## Provenance and implication for selection

- Source same-channel square argument: https://github.com/harjassand/astra-research-knowledge/blob/39cdea532f19217f633f70315d92c314a6ce5e3e/web/pages/d-e9e8f965433b2806.html , section1; read in full and preserved locally.
- Imported identity-ball theorem: Gurvits and Barnum, Physical Review A66,062311 (2002), Theorem1; https://arxiv.org/abs/quant-ph/0204159 . Exact theorem scope is reported in the inspected source; no new full external proof audit was performed in this pass.
- Standard Choi criterion for entanglement-breaking channels is used.

This rules out a proposed escape within these exact norm events: replacing a square by a composition of two separately sampled or specially aligned ensemble channels. It does not rule out any structured PPT channel outside the stated norm ball and does not resolve a universal PPT-composition conjecture. A new attempt must change the structural/norm regime and then supply a real entanglement witness for the actual composition.
