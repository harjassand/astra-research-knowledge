# Balanced-half Schur processing of the factorial state

Date: 2026-10-08. Original analysis during the present research session.
Status: original internally reconstructed candidate theorem. A complete later internal audit is included at ../entropy_audit/FACTORIAL_ENTROPY_AUDIT.md and a broader theorem at ../entropy_audit/GENERAL_CENTRAL_ENTROPY_THEOREM.md. No external certification or historical-priority clearance is claimed. Finite computations are separate evidence, not an asymptotic proof.

## Result and exact scope

For N=2n qubits define P_(N,J) as the entire total-spin-J projector, including multiplicities,

    m_(N,J) = binom(N,N/2-J)-binom(N,N/2-J-1),
    f_J = 1/(2J+1)!!,
    Z_N = sum_J (2J+1)m_(N,J)f_J,
    R_N = Z_N^(-1) sum_J f_J P_(N,J).

Let FULLSEP_(N,k) mean states separable across the N original laboratories, with each laboratory owning its k copy registers and allowed arbitrary entanglement within those registers. The claim is that an absolute C exists such that, for every even N>=2 and every integer k>=1,

    k[ (1/2) log(N+1) - C ]
       <= inf_(sigma in FULLSEP_(N,k)) D(R_N^tensor k || sigma)
       <= k log(N/2+1).

The negative lower bound at small N can be replaced by zero. Logs are natural. Consequently E_R^infinity(R_N; FULLSEP)=Theta(log N), with coefficient bracket [1/2,1]. This does NOT establish E_R^infinity=log N+O(1), the exact leading coefficient, noisy-channel survival of this rate, N-laboratory distillation, or an efficient physical protocol. The lower bound already holds before regularization.

The ordinary single-copy upper was in Astra N199. The new candidate step here is a balanced-bipartition lower bound valid against all cross-copy alternatives. It avoids the invalid single-copy-overlap multiplicativity route.

## 1. Legal grouped preprocessing and exact law

Group the first n laboratories as A and the remaining n as B. An N-party-separable state is A:B separable, including with k copy registers in each laboratory. Thus any operation local to the two grouped halves preserves A:B separability, although it need not preserve the finer N-party partition. That weaker preservation is all that is used.

For each copy measure the local Schur spin a at A and b at B, discard the local multiplicity registers, and communicate both classical outcomes so that both sides retain the flag (a,b). These are legitimate A:B LOCC operations. We never measure global total spin in the protocol and never independently permute the original laboratories across copies.

Local Schur decomposition is

    (C^2)^tensor n = direct_sum_a V_a tensor M_(n,a),
    dim V_a=2a+1, dim M_(n,a)=m_(n,a),

where a runs in steps of one, with a integer for n even and half-integer for n odd. On the (a,b) block the global spin projectors act only on V_a tensor V_b and as identity on both multiplicity registers. Clebsch-Gordan decomposition has multiplicity one:

    V_a tensor V_b = direct_sum_(J=|a-b|)^(a+b) V_J.

Therefore the exact flag probability and normalized conditional state are

    z_ab = sum_(J=|a-b|)^(a+b) (2J+1)f_J,
    q_ab = m_(n,a)m_(n,b) z_ab / Z_(2n),
    rho_ab = z_ab^(-1) sum_(J=|a-b|)^(a+b) f_J P_J^(a,b).

For the factorial sequence z_ab>0. SU(2) invariance and Schur's lemma imply (rho_ab)_B=I_(V_b)/(2b+1). Write omega for the flagged output. Its coherent information is exactly

    I(Aflag > Bflag)_omega
      = sum_ab q_ab [ log(2b+1)-S(rho_ab) ].              (1)

Both flags contain identical classical labels, so the Shannon entropy of q cancels in this difference. The label-weighted conditional total-spin law equals the original global law

    p_J = (2J+1)m_(2n,J)f_J/Z_(2n).

This also follows by summing m_(n,a)m_(n,b) over the admissible triangles, the standard tensor-product multiplicity identity.

## 2. Uniform bound on conditional spin entropy

Since rho_ab has eigenvalue f_J/z_ab with multiplicity 2J+1,

    S(rho_ab) = log z_ab + E[log(1/f_J)|a,b].

Let F=sum_(J>=0)(2J+1)f_J<infinity. Then z_ab<=F. Also Z_(2n)>=m_(2n,0), and

    m_(2n,J)/m_(2n,0)
      = (2J+1)(n+1)/(n+J+1)
          * binom(2n,n-J)/binom(2n,n)
      <= 2J+1.

Consequently p_J<=(2J+1)^2 f_J. Thus

    sum_ab q_ab S(rho_ab)
       <= log F + sum_(J>=0)(2J+1)^2 f_J log(1/f_J)
       =: B < infinity.                                (2)

The double-factorial tail makes both displayed sums converge. This is an entropy-moment bound, not an inference from tightness alone.

## 3. The local spin has logarithmic mean dimension

Elementary central-binomial estimates give absolute C_0,c_0>0 such that, for every legal half-spin a and n>=1,

    m_(n,a) <= C_0 2^n (2a+1)/(n+1)^(3/2),
    m_(2n,0) >= c_0 4^n/(n+1)^(3/2).                  (3)

For example universal enlarged constants C_0=4 and c_0=1/2 suffice. To see the upper, write m_(n,a)=(2a+1)binom(n,n/2-a)/(n/2+a+1), bound the binomial coefficient by the central one and its standard O(2^n/sqrt(n+1)) estimate. The lower follows from binom(2n,n)>=4^n/(2sqrt n), n>=1.

For fixed b and J, at most 2J+1 local spins a satisfy |a-b|<=J<=a+b, and each satisfies

    2a+1 <= 2b+2J+1 <= (2b+1)(2J+1).

Changing summation order in q_b=sum_a q_ab, applying (3), and using Z_(2n)>=m_(2n,0), yields

    q_b <= A (2b+1)^2/(n+1)^(3/2),                    (4)

where A=(C_0^2/c_0) sum_(J>=0)(2J+1)^3 f_J is absolute and finite. The triangle constraint J<=a+b only reduces the sum. Both parities of n are covered.

Summing (4) over b with 2b+1<=x sqrt(n+1) gives, for a new absolute A'>=1,

    P[2b+1 <= x sqrt(n+1)] <= min(1,A' x^3).

When the threshold is below the smallest legal dimension the probability is zero. For thresholds at least one, bounding the sum of integer squares by a constant times the cube proves the display.

Integrating the logarithmic lower tail gives

    E[(log(sqrt(n+1)/(2b+1)))_+]
      <= integral_0^infinity min(1,A'e^(-3t)) dt
      = (log A'+1)/3.

Therefore

    sum_b q_b log(2b+1) >= (1/2)log(n+1)-C_1.          (5)

Combining (1),(2),(5) proves I(Aflag>Bflag)_omega >= (1/2)log(n+1)-C_1-B.

## 4. Relative entropy lower bound for every copy count

For any normalized A:B-separable sigma, sigma<=I_A tensor sigma_B, because each density operator on A is bounded above by I_A. Operator monotonicity of log implies

    D(omega||sigma)
      >= -S(omega)-Tr omega_B log sigma_B
      = S(omega_B)-S(omega)+D(omega_B||sigma_B)
      >= I(A>B)_omega.                                (6)

Singular cases follow by regularization or the usual support convention for relative entropy. Apply the grouped preprocessing independently to each of the k copies. Any sigma in FULLSEP_(N,k) maps to an A:B-separable state on the enlarged grouped registers. Data processing for quantum relative entropy and (6) imply

    D(R_N^tensor k || sigma)
      >= E_R^(A:B)(omega^tensor k)
      >= I(A^k>B^k)_(omega^tensor k)
      = k I(A>B)_omega.

There is no assumption that the alternative sigma factors between copies. This establishes the claimed copy-uniform lower bound directly; a hashing theorem is unnecessary for this part.

Optional operational corollary: the standard hashing inequality (Devetak-Winter) applied after the grouped LOCC preprocessing yields A:B distillable entanglement at least the same coherent information. This needs joint operations inside each half and asymptotically many copies, so it is not N-party LOCC distillation.

## 5. Single-copy upper and asymptotic order

The common SU(2) plus all-site-permutation twirl of a balanced product of n up/n down qubits is fully separable and has coefficient

    tau_N = sum_J [1/((2J+1)binom(2n,n))] P_(2n,J).

Its spin probability is m_(2n,J)/binom(2n,n), because the balanced product lies in magnetization zero and permutations act transitively on its computational basis. For each J,

    (eigenvalue R_N)/(eigenvalue tau_N)
       = (2J+1) f_J binom(2n,n)/Z_(2n) <= n+1,

since max_J (2J+1)f_J=1 and Z_(2n)>=m_(2n,0)=binom(2n,n)/(n+1). Hence R_N<=(n+1)tau_N, and D(R_N||tau_N)<=log(n+1). The product comparator tau_N^tensor k remains separable across N laboratories, proving the upper for every k.

Take k->infinity at fixed N to define the regularized relative entropy (existence by subadditivity), then N->infinity. The bounds are actually uniform in k, so no illicit exchange of limits is needed.

## Sources, imported facts, and novelty boundary

Astra pinned revision: 39cdea532f19217f633f70315d92c314a6ce5e3e.

- Definition and source claims: frontier/review_cards/N195-universal-factorial-noise-probe.txt; authored proof at web/pages/d-53f13b1249155c76.html. The state definition and ordinary upper are reconstructed above; universal-noise claims are not premises.
- Existing single-copy law and stated regularization gap: web/pages/d-23019220fc90f2f0.html, especially section D3; N199.
- Existing Bell cross-copy overlap obstruction: web/pages/d-3a11e894cc10e7fb.html, section 4; N224. It is not used as a proof premise.
- Standard imported mathematics: finite SU(2) Schur/Clebsch-Gordan decomposition, Schur's lemma, central-binomial bounds, operator monotonicity of logarithm, and quantum relative-entropy data processing. No unpublished release theorem is imported.
- Optional hashing: Devetak and Winter, https://arxiv.org/abs/quant-ph/0306078 .
- Crucial prior art: Livine and Terno (2005), https://arxiv.org/abs/quant-ph/0502043 ; Moharramipour et al. (2024), https://arxiv.org/html/2406.08542v2 . The pure singlet-sector version and its logarithmic balanced-cut entanglement are established prior work. The present bounded-total-spin-entropy extension to the specific factorial mixture may be a modest bridge, and its priority is UNKNOWN. No foundational breakthrough is claimed.

## Falsification and numerical checks

Fresh script: check_factorial_grouped_entropy.py. Exact rational checks verify q_ab normalization and recovery of p_J for N=2,4,...,16. Larger diagnostics compute (1) using reduced spin blocks only, with total J cutoff 40. The omitted global mass is bounded by sum_(J>40)(2J+1)^2 f_J; floating outputs are not certified interval values. Recorded output: factorial_grouped_entropy_results.json.

Decisive mathematical falsifiers would be: an incorrect conditional block after discarding multiplicities; a failure of the triangle multiplicity identity; an error in (4); or a map claimed A:B local that is not. The all-copy lower does not rely on independent per-copy laboratory permutations, overlap multiplication, or conditioning on a global entangled measurement.

## Why Bell overlap does not give a reverse upper

The local inter-copy Bell product is separable across N labs and has unusually high overlap with two singlet projectors. Projecting it onto the two singlet supports produces a maximally entangled vector between multiplicity spaces, not the maximally mixed product target. Independent S_N permutations on each copy would break the laboratory grouping: a Bell pair originally contained in one lab can be moved across labs. Synchronous permutations do preserve laboratory separability but leave a nontrivial tensor-product multiplicity commutant. Thus the single-copy twirl-to-scalar argument cannot be reused to identify an optimal regularized relative-entropy comparator.
