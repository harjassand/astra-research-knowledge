# Uniform vector-valued Hamming cofilling from KOW

Audit date: 2026-10-08. Primary source pinned to Kaufman–Oppenheim–Weinberger, *Coboundary expansion of coset complexes*, arXiv:2411.02819v1 (5 November 2024), https://arxiv.org/html/2411.02819v1. The theorem numbering below is this version's numbering. This report is a mathematical consequence/audit, not a claim that its corollary is separately stated in the paper.

## Verdict

**Yes.** There is one bounded-vertex-degree, locally spectrally expanding family and one positive 1-coboundary expansion constant that work simultaneously for all coefficient groups `(F_2)^b`, with group-valued support/Hamming norm, for every finite `b`. The same conclusion holds for `(F_q)^b` for any fixed finite field `F_q`, provided the fixed construction prime `p` differs from `char(F_q)`. In particular the `F_3` route does not require a new complex family or a gadget change just to obtain this analytic estimate.

The source-level quantifiers are already strong enough. The dependence on `|Lambda|` in informal Theorem 1.1/formal Theorem 6.3 is introduced only as a sufficient way to ensure that `Lambda` has no element of order `p`. It is not a dependence in the local-to-global estimates or the missing-relator argument.

This establishes the joint-support cofilling input. It does **not**, by itself, establish a choiceless definability theorem, an equivariant choice of minimizers, the full support theorem for a particular gadget construction, or a computational resource lower bound. Those need their separate reduction/implementation arguments.

## 1. Exact quantified corollary

Fix an integer `n >= 3`. There exist an odd prime `p`, constants `c > 0` and `L < infinity`, and the infinite family

`X_s = X_(n,p)^(s),  s > 3n`,

such that:

1. `X_s` is a finite, pure `n`-dimensional complex. Every vertex lies in at most `L` top-dimensional simplices, and hence has graph degree at most `nL`.
2. `X_s` has one-sided local spectral expansion parameter `lambda = 1/(sqrt(p)-n) < 1`, uniformly in `s`.
3. For **every** finite `b >= 1` and every `A in C^1(X_s;(F_2)^b)`, there is `U in C^0(X_s;(F_2)^b)` with

   `|| A - delta U ||_1 <= c^(-1) || delta A ||_2`.

The norm on a vector cochain is the total weight of simplices on which the **whole vector is nonzero**. Thus it measures the union of coordinate supports, not a sum or average of coordinate norms. Both the family and `c,L` are independent of `b` and `s`.

More generally the same fixed `n,p,c,L` work for every coefficient group `Lambda` without nontrivial elements of order `p`, using the multiplicative version of the displayed inequality. For the additive field statement replace `(F_2)^b` by `(F_q)^b` and require `p != char(F_q)`.

### Proof, including constants

Let `beta = beta(n) > 0` be KOW Theorem 2.10's vertex-link lower bound. Decrease it to `min(beta,1)` if necessary. Its quantifier order is

`for every n >= 3, there exists beta > 0, for every odd prime p, every group Lambda, every s, every vertex v ...`.

In particular `beta` is independent of `p`, `Lambda`, and `b`. Choose one sufficiently large odd prime `p` so that

`lambda = 1/(sqrt(p)-n) <= beta / (2(beta+24e))`.

For the `F_3` application also choose `p != 3`; there is no difficulty because arbitrarily large primes exist. KOW Theorem 2.8 supplies items 1 and 2. Theorem 2.4 gives, simultaneously for every group `Lambda`,

`h^1_cosys(X_s;Lambda) >= (1-lambda)beta/24 - e lambda >= beta/48 =: c`.

KOW Theorem 6.2 gives `H^1(X_s;Lambda)=0` whenever `Lambda` has no nontrivial element of order `p`. Every nonzero element of `(F_2)^b` has order 2, and every nonzero element of the additive group `(F_q)^b` has order `char(F_q)`. Thus the same fixed `p` works for all `b`. Since `Z^1=B^1`, the cosystolic distance equals the coboundary distance, giving item 3.

The threshold choice can equivalently be ensured by

`sqrt(p) >= n + 2 + 48e/beta`.

No numerical value of `beta(n)` is needed for the existential statement. If explicit numerical degree/cofilling bounds are needed, one must additionally extract the cone-size constant in the earlier KO proof. This audit does not claim an optimized numerical constant.

## 2. Independent vanishing transfer, requiring only the scalar KOW conclusion

For vector groups one need not strengthen KOW's cohomology theorem at all. Choose one sufficiently large `p` for the scalar group `F_2` using the paper's main theorem, so that `H^1(X_s;F_2)=0` for every `s`. If `A=(a_1,...,a_b)` is a vector cocycle, every `a_i` is a scalar cocycle, hence `a_i=delta u_i`. Therefore `A=delta(u_1,...,u_b)` and

`H^1(X_s;(F_2)^b) = 0`.

Combining this elementary coordinatewise vanishing with the **group-uniform cosystolic** estimate above proves the result again. This is useful for separating the quantifier-transfer corollary from a full independent re-proof of the published algebraic construction.

Crucially, applying scalar cofilling independently to the coordinates is *not* this proof: that naive approach can pay a factor `b` in the union of correction supports. Coordinatewise reasoning is used only for exact vanishing, where there is no quantitative loss; quantitative correction is done once with the full vector as one group label.

## 3. Joint-support correction, in the exact form needed

Let `a_1,...,a_b in C^1(X_s;F_2)` and suppose

`union_i supp(delta a_i) subseteq F_0 subseteq X_s(2)`.

Bundle them into `A(e)=(a_1(e),...,a_b(e))`. Then

`supp(delta A) = union_i supp(delta a_i) subseteq F_0`.

Choose `U=(u_1,...,u_b)` by the vector inequality and define

`r_i = a_i - delta u_i`,

`T = supp(A-delta U) = union_i supp(r_i)`.

Every coordinate has the original curl, `delta r_i=delta a_i`, while **one common edge set** supports all the `r_i`:

`w_1(T) <= c^(-1) w_2(F_0)`.

No factor of `b` appears.

### Conversion from KOW weights to ordinary cardinality

Write `M=|X_s(n)|`, and let `q_sigma` be the number of top-dimensional simplices containing `sigma`. KOW's weight is

`w_k(sigma)=q_sigma / (binom(n+1,k+1) M)`.

Purity gives `q_e >= 1` for every edge, while the degree bound gives `q_tau <= L` for every triangle. Consequently

`|T|/(binom(n+1,2) M) <= w_1(T)`

and

`w_2(F_0) <= L |F_0|/(binom(n+1,3) M)`.

Thus

`|T| <= kappa |F_0|`,

`kappa := 3L / ((n-1)c)`.

This constant is independent of the number of vectors, vector dimension, and member of the family. It remains valid when working with the 2-skeleton; edges and triangles are unchanged. If one changes to normalized counting weights on the 2-skeleton, only fixed comparison factors change.

## 4. Additional support-union lemma

This is an elementary useful companion to vector cofilling, and does not rely on KOW.

Let `W` be a finite-dimensional vector space over `F_q`, and let `D:W -> F_q^F` be linear. Suppose `|supp(Dw)| <= a` for every `w in W`. Let

`F_0 = union_(w in W) supp(Dw)`.

For each `f in F_0`, evaluation `w -> (Dw)(f)` is a nonzero linear functional. A uniform random `w in W` therefore has `(Dw)(f) != 0` with probability `1-1/q`. By linearity of expectation,

`(1-1/q)|F_0| = E_w |supp(Dw)| <= a`.

Hence

`|F_0| <= q a/(q-1)`.

In particular the factors are `2` for `F_2` and `3/2` for `F_3`. Apply the vector correction to a basis of `W` to get a common correction support of size at most `kappa q a/(q-1)`. Every linear combination then has a representative supported on that same set.

The hypothesis is a bound for **all** members of `W`. A bound only for the selected basis does not imply this union bound. Equally, this lemma establishes existence and size, not a canonical basis or a canonical correction support.

## 5. Where the group enters the missing-relator argument

Here is the dependency audit of the global vanishing proof.

- Section 3, Theorem 3.1: descent of vanishing under a rigid quotient uses only `Hom(N,Lambda)=1`. The proof constructs a homomorphism from the quotienting group to `Lambda`; no counting over `Lambda` occurs.
- Corollary 3.3: if `N` is generated by elements whose orders divide `p` and `Lambda` has no nontrivial element of order `p`, every homomorphism `N -> Lambda` kills the generators. Normal generation is sufficient because all conjugates of the generators also have order dividing `p`.
- Theorem 4.3 is wholly about construction groups and the odd prime `p`. It iteratively turns a pre-chamber group into a chamber group by quotienting by normal subgroups generated by `p`-torsion. It does not involve `Lambda`.
- At the final inductive stage the additional relator is

  `z=[x_(1,j)(r_1),x_(j,n+1)(r_2)] x_(1,n+1)(-r_1 r_2)`.

  The relations already present show that the second factor commutes with the commutator, and that the commutator commutes with the first root generator. Root additivity gives `x_(i,j)(r)^p=1`, so the commutator identity yields `z^p=1`. This proof does not assert that an arbitrary product of `p`-torsion elements has order `p`; it proves the required commutation for these particular relators.
- Theorem 4.4 applies the Section 3 descent lemma successively. Its sole coefficient hypothesis is the absence of elements of order `p`.
- Theorem 5.1's two rounds of Weyl-chamber propagation are combinatorial in `A_n`, again independent of `Lambda`.
- Theorem 6.1 starts with the simply connected universal coset complex, where `H^1` vanishes for every group. It then uses Theorem 4.4 for the two chamber rounds and the finite Steinberg presentation to reach the infinite polynomial-ring complex. Its coefficient hypothesis is exactly no `p`-torsion.
- Theorem 6.2 passes to the truncated polynomial quotient using a congruence kernel generated by order-`p` elementary matrices and their conjugates; again the same hypothesis is sufficient.
- Only in Theorem 6.3 does the paper choose `p_1=max(p_0,|Lambda|+1)`. This uses Lagrange's theorem to guarantee no `p`-torsion for an arbitrary finite `Lambda`. For an exponent-2 group the replacement is simply `p != 2`, and for additive characteristic-`ell` groups it is `p != ell`.

There is therefore no first hidden dependence on `b` in this chain.

## 6. Upstream quantitative checks

The group-uniform assertion is not obtained by reading only the abstract or the word “any.”

1. KOW Theorem 2.10 explicitly places the existential `beta` before both the prime and coefficient-group quantifiers.
2. KOW Theorem 2.4 states the numerical local-to-global bound. Its displayed vertex-link hypothesis contains a missing subscript in v1 (`X` where context requires `X_v`). The cited source confirms the intended local hypothesis.
3. Dikstein–Dinur, APPROX/RANDOM 2024, Theorem 8, takes **any group** and gives `h^k >= (product beta_i)/(4(k+2)!)-e lambda`. For `k=1`, take `beta_1=beta` for vertex links and `beta_0=1-lambda` for the graph links. The result is precisely KOW's formula. The correction and estimates have no alphabet-size factor.
4. The graph-link bound is itself group-independent. If a graph labeling has color-class masses `mu_i` and its normalized random walk has spectral gap `g`, spectral expansion gives disagreement probability at least `g(1-sum_i mu_i^2) >= g(1-max_i mu_i)`. The latter is `g` times distance from a constant labeling. This works for any number of labels. One need not rely on v1 Remark 2.3's overly terse identification with a binary Cheeger constant.
5. Dikstein–Dinur, *Swap cosystolic expansion*, Section 4, defines nonabelian cone contractions. Claim 4.1.1 says that a decoded edge is correct whenever all triangles in its contraction have trivial curl. Lemma 4.3 then takes a union bound over at most `R` contraction triangles, giving a lower bound `rho/R` (where `rho` is the smoothness parameter). The group is used only for multiplication, inverses, and testing identity; there is no sum over possible group labels. This explains why adapting the KO link cones does not insert a `|Lambda|` factor.

## 7. Source audit: the truncated-ring Steinberg shortcut

A correct caution is that, for arbitrary rings, `St_m(R)=SL_m(R)` does **not** alone imply that the kernel of `SL_m(R)->SL_m(R/I)` is normally generated by the elementary matrices with entries in `I`. The presentation quotient directly gives `St_m(R/I)`, and an additional `K_2(m,R/I)` obstruction could remain.

KOW v1's proof of Theorem 6.2 compresses this identification. In the **specific ring used here**, it can be supplied without altering any coefficient quantifiers:

- Let `A=F_p[t]/(t^s)` and `J=(t)`. Hesselholt–Madsen, *Cyclic polytopes and the K-theory of truncated polynomial algebras*, Theorem A, gives `K_2(A,J)=0` because `F_p` is perfect and the positive even relative groups vanish.
- The augmentation `A -> F_p` is split, and `K_2(F_p)=0`, so `K_2(A)=0`. The finite-field fact is classical; alternatively obtain the finite-rank statement from KOW's polynomial-ring Steinberg isomorphism by the split constant-inclusion/evaluation maps, then use local stability.
- Van der Kallen–Maazen–Stienstra, *A presentation for some K_2(n,R)* (1975), Theorem 1 in §2.4, identifies `K_2(m,A)` with the same Dennis–Stein group for local `A` throughout the stable ranks including our `m=n+1>=4` and the stable group. Therefore `K_2(m,A)=0`.
- Over the local ring `A`, elementary row reduction gives `E_m(A)=SL_m(A)`. Consequently `St_m(A)->SL_m(A)` is an isomorphism.
- Thus the kernel in Theorem 6.2 really is the normal closure of the elementary matrices `e_(i,j)(r)` with `r in (t^s)`. Each nonidentity generator, and each conjugate, has order `p`.

The displayed monomial range `k>s` in KOW v1 must be `k>=s`; otherwise it omits `e_(i,j)(t^s)`. This is a boundary-index typo, not a coefficient-size obstruction.

This supplementary check repairs the generic logical shortcut for the particular truncated finite-field rings. It is not a claim to have independently reconstructed every theorem used in KOW (for example the full finite presentation and the earlier KO cone construction). The coefficient-uniform corollary is already valid as an import of the paper's formal theorem statements, and the coordinatewise alternative in §2 avoids requiring a new vanishing theorem beyond the scalar case.

## 8. Verified source map

### Main primary source

Kaufman, Oppenheim, Weinberger, arXiv:2411.02819v1:

- Construction and bounded degree: https://arxiv.org/html/2411.02819v1#S2.SS5 ; Theorem 2.8: https://arxiv.org/html/2411.02819v1#S2.Thmtheorem8
- Group-valued support norms: https://arxiv.org/html/2411.02819v1#S2.SS3
- Local-to-global estimate: https://arxiv.org/html/2411.02819v1#S2.Thmtheorem4
- Uniform vertex links: https://arxiv.org/html/2411.02819v1#S2.Thmtheorem10
- Group-uniform cosystolic family: https://arxiv.org/html/2411.02819v1#S2.Thmtheorem11
- Quotient vanishing: https://arxiv.org/html/2411.02819v1#S3.Thmtheorem1
- Torsion-generated quotient corollary: https://arxiv.org/html/2411.02819v1#S3.Thmtheorem3
- Missing-relator iteration: https://arxiv.org/html/2411.02819v1#S4.Thmtheorem3 and https://arxiv.org/html/2411.02819v1#S4.Thmtheorem4
- Infinite-complex vanishing: https://arxiv.org/html/2411.02819v1#S6.Thmtheorem1
- Finite-complex vanishing: https://arxiv.org/html/2411.02819v1#S6.Thmtheorem2
- Where `|Lambda|` enters: https://arxiv.org/html/2411.02819v1#S6.Thmtheorem3

### Independently checked upstream primary sources

- Yotam Dikstein and Irit Dinur, *Coboundary and Cosystolic Expansion Without Dependence on Dimension or Degree*, APPROX/RANDOM 2024, LIPIcs 317, article 62, Theorem 8, printed page 62:15. DOI https://doi.org/10.4230/LIPIcs.APPROX/RANDOM.2024.62 . PDF https://drops.dagstuhl.de/storage/00lipics/lipics-vol317-approx-random2024/LIPIcs.APPROX-RANDOM.2024.62/LIPIcs.APPROX-RANDOM.2024.62.pdf
- Yotam Dikstein and Irit Dinur, *Swap cosystolic expansion*, arXiv:2312.15325v2, Section 4, especially Claim 4.1.1 and Lemma 4.3: https://arxiv.org/html/2312.15325v2#S4
- Lars Hesselholt and Ib Madsen, *Cyclic polytopes and the K-theory of truncated polynomial algebras*, Invent. Math. 130 (1997), 73–97, Theorem A, printed page 74. Author-hosted primary PDF https://web.math.ku.dk/~larsh/papers/007/polytope.pdf ; author summary https://web.math.ku.dk/~larsh/papers/007/
- Wilberd van der Kallen, Hendrik Maazen, Jan Stienstra, *A presentation for some K_2(n,R)*, Bull. Amer. Math. Soc. 81 (1975), 934–936, Theorem 1, §2.4, printed page 935. Author-hosted primary PDF https://webspace.science.uu.nl/~kalle101/maazenStK.pdf

Full external source files are excluded from this archive. The primary-source map above records their versions and locations.

## 9. Recommended statement for the larger argument

> Fix a sufficiently large odd construction prime `p`. The KOW complexes form one bounded-degree family that is uniformly 1-coboundary expanding with coefficients in every finite-dimensional `F_2`-vector space, using the nonzero-vector support norm. Consequently, any finite collection of scalar 1-cochains whose coboundaries are jointly supported on `F_0` has cohomologous representatives jointly supported on a single edge set of size at most `kappa |F_0|`, where `kappa` is independent of the collection size and the complex size.

For an `F_3` argument use the same sentence with `F_3` and choose `p != 3`. Cite KOW Theorems 2.4, 2.10, 6.2; if minimizing algebraic dependencies, cite scalar vanishing plus coordinatewise exactness instead of invoking the general no-`p`-torsion statement.
