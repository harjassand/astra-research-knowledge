# A characteristic-two coisoperimetric support mechanism

Research record, 2026-10-08. This is an original derivation from sampled source mechanisms, not a claim of a newly resolved famous conjecture or of established novelty.

Superseded quantitative target: see `EXPONENTIAL_INTERPRETATION_SPACE_CANDIDATE.md` for the later collective-cofilling and maximum-state-size refinement. This file retains the fully proved characteristic-two core and its audit trail.

## Evidence and status

The source collection is pinned to openai/math commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`, retrieved successfully through the GitHub connector. The README expressly distinguishes verification stages. We have read actual proof source; we have not rebuilt Lean solutions or run Comparator. The ComparatorChallenges files contain statement placeholders, so their `sorry` is neither a proof certificate nor evidence that the actual solutions are incomplete.

Source 243:
- [Structures](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/02-structures.tex)
- [Support proof](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/03-support.tex)
- [Base counting and homogeneity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/04-base-logic.tex)
- [Abstract HF transfer](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/05-hf-transfer.tex)
- [Interpretation encoding](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/06-coding.tex)

Source 177:
- [Exact theorem and weights](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-degree-coboundary-expanders-in-every-dimension-September-24-2026/build/source/sections/introduction.tex)
- [Degree and weight comparisons](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-degree-coboundary-expanders-in-every-dimension-September-24-2026/build/source/sections/expansion.tex)

The source 243 already claims full CPT-with-counting noncapture of PTIME over F3. A characteristic-two field change would not newly establish noncapture. The target here is a quantitative resource barrier and a reusable mechanism separating cohomological filling from symmetry breaking.

The core group-theoretic lemma below is proved directly and has an independent reconstruction made without consulting this derivation or source243. The global quantitative interpretation lower bound is a theorem candidate, with the model-translation audit still a gate.

## 1. Minimal support lemma, valid in characteristic two

Let p be prime and let C2 --∂2--> C1 --∂1--> C0 be a finite Fp chain complex with fixed bases E of C1 and F of C2. Put K=ker ∂1 and c_f=∂2(f). Assume the coisoperimetric hypothesis

  for every ℓ∈C1*, there exists φ∈C0* with
  |supp(ℓ−∂1*φ)| ≤ κ |supp(∂2*ℓ)|.                 (CF)

Let V=(Fp²)^F. Write a_f=(x_f,y_f), and define

  B(a,a′)=Σ_f x_f y′_f c_f,
  H=V×K,
  (a,k)(a′,k′)=(a+a′,k+k′+B(a,a′)).

For an arbitrary H-set and a point ξ whose H-orbit has size p^h, there is a set T⊆E with

  |T| ≤ κ floor(h²/4)

such that every k∈K satisfying k_e=0 for all e∈T fixes ξ. This statement is about coordinate control of K-stabilizers. Turning T into an atom support additionally requires atoms whose central stabilizers are the coordinate kernels; the gadget below provides them.

Proof. Bilinearity of B gives the cocycle identity, and ∂1c_f=0 ensures B has values in K. The inverse is (−a,−k+B(a,a)). The commutator is

  [(a,k),(a′,k′)] = (0, Σ_f (x_f y′_f−x′_f y_f)c_f).

Let S=Stab_H(ξ), U=projection_V(S), and K0=S∩K. These last two groups are vector subspaces over Fp, including when H itself has exponent four. Set a=codim_V U and b=codim_K K0. The exact sequence for S gives a+b=h.

For λ∈K* annihilating K0, choose a lift ℓ∈C1*. For u,u′∈U choose arbitrary lifts in S. Their commutator belongs to K0, so U is isotropic for the alternating form

  β_λ(u,u′)=Σ_f λ(c_f)(x_f y′_f−x′_f y_f).

If t coefficients λ(c_f) are nonzero, this form has rank 2t: its nonzero 2×2 blocks occupy disjoint coordinates. This remains true at p=2. An isotropic subspace in a form of rank 2t has codimension at least t, hence t≤a. The source's face-boundary vectors need not be independent.

By (CF), λ has a representative supported on at most κa edge coordinates. Choose these representatives for a basis of the b-dimensional annihilator of K0, and let T be their support union. Then |T|≤κab≤κ floor(h²/4). A k vanishing on T is annihilated by the entire annihilator of K0, so belongs to K0. QED.

## 2. Characteristic-two warning and negative control

In characteristic two, (a,k)²=(0,B(a,a)); the group need not have exponent two. A center-fixing linear gauge lift must preserve the quadratic map Q(a)=B(a,a), not merely the alternating commutator. On one face, the shear (x,y)↦(x+y,y) preserves the commutator but changes Q at (0,1) from zero to c_f. It therefore cannot lift as a center-fixing group automorphism.

No such gauge lifts are used above, or in the sampled source243 support proof. The needed symmetries are the actual left translations by H; stabilizer arguments choose elements already in S. The counting game later uses only central additive K flows. Thus the exponent-four issue is real but does not obstruct this specific mechanism. It must not be silently ignored in a broader proposed transfer.

## 3. Why cosystolic expansion alone is insufficient

(CF) forces ker ∂2*=im ∂1*: put ∂2*ℓ=0. Equivalently, the relevant H¹ vanishes. If a nontrivial cohomology class λ survives, it annihilates every c_f. Then S=V×ker λ is an index-p subgroup of H, hence H/S is an orbit-p H-set. Here h=1, so the claimed κ floor(h²/4) bound would require empty support, which is false because K acts nontrivially on H/S.

More precisely, the minimum coordinate support for this orbit equals the minimum support size of a representative of λ modulo im ∂1*. Large cosystoles can make the failure worse, not repair it. A 5-cycle with no faces is the smallest simple negative control used in the test script: orbit size two, minimum support one, false predicted bound zero.

## 4. Exact source177 hypotheses meet the local algebraic requirements

Source177's main theorem states: fixed d≥3, connected pure simplicial X, every vertex contained in at most D top-dimensional d-faces, and weighted F2 coboundary expansion ε in degrees 0 and 1 (in fact every i<d). Its weights are

  w_i(σ)=#top faces containing σ / (binom(d+1,i+1) · number of top faces).

Purity and the D bound put the numerator between 1 and D. Thus degree-one expansion implies unweighted (CF), with the explicit sufficient constant

  κ = [D/ε] binom(d+1,2)/binom(d+1,3)
    = 3D/[ε(d−1)].

Proof: take a weighted-distance minimizing representative; convert its support using the minimum weight on edges, and bound the weighted curl by the maximum triangle weight. Both normalizing top-face counts cancel.

Degree-zero expansion gives graph edge expansion

  |δ_G U| ≥ α min(|U|,|V\U|),  α=εd/(2D).

The graph has maximum degree Δ≤dD. Each edge is in at most (d−1)D triangles, and each vertex in at most binom(d,2)D triangles. These bounded incidences, not just a cochain inequality, are essential to keep the relational gadget linear-size.

Only the 2-skeleton is used. Consequently the higher-dimensional novelty of source177 is not logically needed for this consequence: established bounded-degree two-dimensional F2 coboundary expanders can supply the same input if their degree-zero expansion and comparable weights are checked. A primary independent source is Chapman–Lubotzky, Theorem 1.9 and Section 5: https://arxiv.org/html/2311.06706v3 . We have verified the stated theorem, not independently reconstructed its arithmetic construction.

## 5. Fixed-vocabulary local atom gadget over F2

For each edge e, use the group P_e=(F2²)^{F(e)}×F2 with

  (u,z)(u′,z′)=(u+u′, z+z′+Σ_{f∋e} c_fe x_f y′_f).

Its inverse is (u,z+Σ c_fe x_f y_f), and the central coordinate of g^{-1}g′ is

  z′−z + B_e(u,u)−B_e(u,u′).

Use one edge atom for each state. At each vertex, configuration atoms choose one state per incident edge, require identical face-coordinate pairs on the two edges of each incident triangle, and require the signed sum of z_e to equal a prescribed vertex charge b_v. Over F2 signs become equal, but each face boundary still has zero divergence.

The vocabulary has seven binary relations: Ed,Cf,EB,VB,I,Z_0,Z_1. Ed/Cf tag atom types; EB/VB identify edge/vertex blocks; I gives selected-state incidences; Z_δ tests the central coordinate of g^{-1}g′. These are exactly the source243 conventions with the corrected characteristic-two group difference.

H acts by simultaneous left translation through the restriction homomorphisms H→P_e. Face compatibility is preserved; the bilinear correction cancels at each vertex because ∂1c_f=0. Group differences g^{-1}g′, hence every Z relation, are invariant under common left multiplication. Central k fixes an edge atom exactly when k_e=0. No arbitrary gauge, ordering, or symplectic action is required.

If n=|V|, the universe size N is between n and Cn for a fixed constant determined by Δ and face incidence. Its Gaifman degree is uniformly bounded as well: every block and each local incidence fibre has bounded size. The bounds are enormous but independent of n.

## 6. An all-input polynomial-time query with opposite charge answers

The source243 query can be defined over F2 on every structure in this seven-symbol vocabulary. It assigns variables λ_a to configuration atoms and μ_y to edge atoms. For each configuration block X_t, require Σ_{a∈X_t}λ_a=1. For every incident edge-block test and every edge atom y, require

  μ_y=Σ_{a∈X_t}λ_a C(y,a),

where C(y,a) is the sum of δ over selected incident edge states x for which Z_δ(y,x) holds. These definitions remain total when atom types overlap or the relations are malformed. They yield an ordinary linear system with O(N²) equations and O(N) unknowns; ordinary Gaussian elimination decides consistency. Therefore the query is isomorphism-invariant and polynomial-time on all inputs.

For the zero-charge gadget, give unit λ weight to the all-zero state configuration at every vertex and zero to all other configurations. The correction from the triangular cocycle means the correct assignment is μ_(e,u,z)=−z+B_e(u,u), not merely −z as in the source's alternating cocycle. This explicitly fixes the main characteristic-two formula that would otherwise be easy to miss.

Conversely choose the zero edge atom y_e. Then C(y_e,a)=z_e(a). Weighted divergence and Σλ=1 give ∂μ=b. Summing over all vertices forces Σ_v b_v=0. Hence zero charge is accepted and a unit charge at one vertex is rejected. The argument does not assume Boolean λ weights or a selected single configuration.

The query can be expressed in FPR₂ by equality of the ranks of its coefficient and augmented matrices. However FPR₂ noncontainment is only a corollary if the complete CPT lower-bound bridge is verified; no formal FPR₂ separation is claimed by this record.

## 7. Quantitative base equivalence and homogeneity

Let G be the base graph with edge expansion α and maximum degree Δ, and put

  M=floor(αn/(4Δ)).

Deleting at most ΔM edges leaves a unique component larger than n/2. Indeed the sum of sizes of components at most n/2 is at most 2|T|/α≤n/2. The unique giant is nested under further allowed deletions.

Exactly as in source243, expand the atom structures for analysis only by a total preorder of local face patterns and raw central-difference relations. This is not given to the algorithm. For M assigned atoms, at most ΔM edges are touched. A charge defect can be moved within the giant along an untouched path. For the next selected atom, add its edge or vertex star to the deleted set, move the defect into the new giant, and translate that whole atom block. This yields one bijection of the entire universes that extends all retained positions and preserves each possible next partial assignment. Therefore the two analytic expansions are C^M-equivalent.

For homogeneity, two r-tuples of the same type prescribe a common central shift σ on at most Δr touched edges. Such a partial shift extends to K iff each component U of the untouched graph has zero net prescribed boundary flow. If it fails, at least two components fail, so choose one of size ≤n/2. Expansion gives |U|≤Δr/α. The source's witness formula has at most

  r + (Δ+1)|U| + Δr + 1 ≤ C r + 1,
  C=(Δ+1)(1+Δ/α),

variables. It compares configurations throughout U with the prescribed tuple-boundary differences. Thus equal C^M types imply equal K-orbits whenever Cr+1≤M. This replaces the grid's O(r^{3/2}) homogeneity cost by O(r).

## 8. Quantitative target and exact remaining audit gate

Source243's abstract hereditary transfer theorem needs:
- C^M equivalence of the atom expansions;
- K-orbit homogeneity for tuples up to max{2,m}s;
- max{4,m+1}s≤M.

All objects and their recursive members must have K-support length at most s. Their hereditary ranks are unrestricted. Combining the preceding bounds, these conditions hold if

  L_m s + 1 ≤ M,
  L_m=max{4,m+1,C max{2,m}}.

For a fixed pair-interpretation program P with one initialization, one repeated step, and fixed halt/output formulas, the source coding gives a transitive H-invariant family of at most 9B³ objects, provided B bounds input size, stages to halt, and each intermediate state size. The coding is a combinatorial count and does not require B to be polynomial. The source free-variable substitution lemma gives a fixed m=m(P), independent of stages, even though the expanded comparison formulas can be extremely long. Thus we may set

  s=max{1,ceil[(κ/4)(log₂(9B³))²]}.

If the quantitative hereditary and interpretation-encoding bridges apply exactly as stated, any P producing opposite answers on the two charge structures must violate L_m s+1≤M. In particular,

  log₂ B ≥ c_X sqrt(n/L_m)−O(1),
  B ≥ exp(Ω_X(sqrt(n/(m(P)+1)))).

Since atom size N=Θ_X(n), for a fixed P this is exp(Ω_P(sqrt N)) time-plus-state resource on at least one input of every sufficiently large pair in the expander sequence. A safe asymptotic sufficient contradiction constant is c=(1/8)sqrt[α/(ΔκL_m)] in the hypothesis log₂B≤c√n; the additive log₂9 and rounding terms are absorbed for large n.

This is stronger than a polynomial/nonpolynomial statement but remains a model-specific bound. The ordinary solver is Gaussian elimination in polynomial time. It is not a P-vs-NP lower bound, nor a lower bound for arbitrary algorithms.

Important unresolved audit gate: the published polynomial-time equivalence between CPT, DeepWL, and interpretations alone does not automatically supply an arbitrary-resource simulation with the same exponential exponent. The present quantitative candidate can be stated directly for the explicit interpretation model; extending it to standard CPT run measures or DeepWL requires tracking simulation overhead and syntax width. We must not infer that overhead from a qualitative equivalence. The source's new abstract HF transfer/encoding proofs also need independent scrutiny before a full separation claim.

Historical comparison: CFI counting lower bounds control fixed-variable logic; some CFI queries are solvable by CPT using higher-rank sets. The source243 mechanism controls polynomial-size orbits at every HF rank. The new quantitative proposal couples this with bounded-degree coboundary expansion to require exponentially many symmetry-sensitive intermediate objects, with a visible square-root exponent arising from the exact codimension product ab. This is the credible foundational angle; historical novelty of this quantitative bound is unverified.

## 9. Executed falsification tests

`check_char2_support.py` ran successfully using exact finite operations only. On the two-triangle disk its H has order 64. Tests exhausted all 389 subgroups and verified their minimum-coordinate-support bounds with κ=1. It also checked 262,144 associativity triples, 4,096 commutator pairs, 34,816 local group-difference invariance cases, and 18,432 vertex-configuration translation cases. Both exponent-four/shear and nonzero-H¹ negative controls behave as predicted. Results are in `char2_support_test_results.json`.

These tests are not a proof of asymptotic statements. They do kill common sign, inverse, support, and characteristic-two mistakes. Next decisive falsification: inspect the exact interpretation/HF encoding against a small symmetric program exploiting quotient sets, then independently verify the weighted expander-to-gadget mapping and the parameter-uniform type-transfer theorem. A failure in either blocks the global lower-bound claim while leaving the core support lemma valid.

Additional executed query check: the full specialized linear system on the two-triangle disk has 132 equations and 208 variables. The zero-charge ranks are 76/76 and the unit-charge ranks are 76/77. The corrected witness satisfies all equations. The uncorrected source assignment fails 40 equations. These exact computations are included in the same script and result file.
