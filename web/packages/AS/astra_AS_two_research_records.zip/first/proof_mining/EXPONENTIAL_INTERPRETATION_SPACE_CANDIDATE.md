# Exponential invariant-state candidate from commutators and collective cofilling

Research record, 2026-10-08. This supersedes the square-root-exponent target in `CHARACTERISTIC_TWO_EXPANDER_TRANSFER.md`. It is an end-to-end mathematical derivation for a specified interpretation model and has passed independent first-pass AI mathematical checks of the support, coefficient-uniformity, HF-transfer, and maximum-state-size steps. It has not received external expert review or formal certification, and historical novelty remains unverified.

## Current conclusion

The strongest proposed statement is:

> There is a fixed, isomorphism-invariant, ordinary-polynomial-time linear-consistency query on finite structures in a fixed binary vocabulary, and an infinite family of opposite-answer pairs of size N, such that every fixed parameter-free two-dimensional interpretation program correctly distinguishing these pairs must use an intermediate universe of size exp(Ω_P(N)) on at least one input. No bound on its finite running time is assumed.

The model is the binary two-dimensional interpretation model of Grohe–Schweitzer–Wiebking, with FO plus Härtig initialization/step and halt/output tests, least equivalence closure for the quotient, and existential representative semantics for output relations. The subscript P charges the fixed syntactic width. This is a lower bound for this explicit invariant model, not unrestricted computation and not automatically a quantitatively identical lower bound for every model polynomially equivalent to CPT.

The field-three version uses the original source243 gadget unchanged. The characteristic-two version has been independently reconstructed and exactly tested, including the necessary correction to its group-difference query. It is useful as a verified general mechanism but is not necessary for the cleanest quantitative consequence.

Source243 already claims full CPT-with-counting noncapture of PTIME. The contribution sought here is an exponential maximum-state-size barrier, not another claim to resolve that same qualitative question.

## Dependency ledger

1. Source243 is pinned at openai/math `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`. We read its actual group-support, base-logic, HF-transfer and interpretation-encoding proofs. We have not rebuilt its Lean solutions or run Comparator. [Source243 support](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/03-support.tex), [HF transfer](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/05-hf-transfer.tex), [encoding](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/06-coding.tex).
2. The core support lemma has an independent reconstruction. The abstract HF transfer and arbitrary-finite-resource encoding passed a separate mathematical audit. Exact quantifier and model-scope statements matter more than repository-level verification labels.
3. The required bounded-degree expansion is available from prior work; the unverified higher-dimensional source177 is unnecessary. The coefficient-uniform KOW consequence passed an independent audit against the published DD24a theorem, including the no-p-torsion/cohomology gate and a truncated-ring K₂ justification. The result retains the ordinary dependence on these imported theorems.
4. The improved maximum-orbit bound is a new refinement of the source's total-trace count and must be distinguished from its original 9B³ bound. Its strongest state-size formulation passed independent mathematical audit, conditional on the stated base/support inputs. Unrestricted finite running time is permitted.

## Primary expansion input and the quantifier issue

Kaufman–Oppenheim–Weinberger, [arXiv:2411.02819v1](https://arxiv.org/html/2411.02819v1), Theorems 2.8, 2.10, 2.11 and 6.2 are the relevant input. The complexes have bounded vertex degree and group-independent local spectral/cofilling estimates. Theorem 6.2 requires that the coefficient group have no nontrivial element of the construction prime's order. Thus one sufficiently large odd construction prime p works for every additive group (F₂)^b simultaneously; for field three choose p≠3. The informal restriction p>|Λ| is sufficient but not necessary for these fixed-exponent groups. Their norm records whether the entire group label is nonidentity, so vector-valued support is union support, not a sum of coordinate supports.

This quantifier order is essential. A theorem allowing the construction prime or degree to grow with b would not close the argument. The uniform local-to-global bound stated there is ((1−λ)β/24)−eλ; β is independent of the coefficient group. Fixing the construction prime sufficiently large makes this positive once and for all.

The same required simultaneous control is known under the name collective cofilling; see Kaufman–Tessler, [arXiv:2008.09495, Definition 2.1](https://arxiv.org/html/2008.09495). We do not claim to have invented collective cofilling or infer it from scalar expansion alone.

## Exact collective support lemma

Use the notation of the characteristic-two record, but let r be the coefficient prime, to distinguish it from construction prime p. Let K be the edge-cycle space and H the central Heisenberg-type extension with one two-dimensional face coordinate for each triangle. Suppose every finite collection ℓ₁,…,ℓ_b of edge cochains has representatives ℓ′_j modulo gradients satisfying

  |⋃ supp ℓ′_j| ≤ κ |⋃ supp δℓ_j|.                  (CCF)

For an H-set point ξ, let S=Stab_H(ξ), U its projection to face coordinates, K₀=S∩K, a=codim U, b=codim K₀, and |H·ξ|=r^h. Then a+b=h. For every λ∈W=ann(K₀), the commutator/isotropic-rank argument gives |supp δλ|≤a.

Let F₀ be the union of these supports over W. A uniformly random λ∈W is nonzero at any active face functional with probability (r−1)/r. Therefore

  [(r−1)/r]|F₀| = E_λ |supp δλ| ≤ a.

Choose a basis of W and cochain representatives. Their tuple-valued cochain has curl support exactly F₀. By (CCF), representatives can be selected with common support T satisfying

  |T| ≤ κ [r/(r−1)] a ≤ κ [r/(r−1)] h.           (1)

Any central k vanishing on T annihilates all of W and fixes ξ. Hence an orbit of size r^h has an atom support of length at most θκh, with θ=r/(r−1). This removes the product ab that gave a squared logarithm in the scalar argument.

(CCF) follows directly from KOW's coefficient-uniform coboundary expansion applied to the tuple group (F_r)^b, after converting weighted norms to unweighted supports. If a pure d-complex has at most D top faces at each vertex and weighted expansion ε, a sufficient conversion is κ=3D/[ε(d−1)]. The graph has expansion α=εd/(2D) and degree Δ≤dD. All are fixed constants independent of b and of complex size.

## Base logic constants

Let n be the number of base vertices and N=Θ(n) the atom universe size. Bounded graph degree and bounded triangle incidence ensure this linear relation and bounded Gaifman degree of the fixed-vocabulary gadget.

Set

  M=floor[αn/(4Δ)],
  C=(Δ+1)(1+Δ/α).

The zero-charge and unit-charge analytic expansions are C^M-equivalent. The proof moves a single discrepancy through the giant component after at most ΔM edge deletions. Graph expansion bounds the total size of small components by 2|T|/α.

Within either expansion, equal C^M types of r₀-tuples imply that they lie in the same K-orbit when Cr₀+1≤M. A failed partial central flow has a component of size at most Δr₀/α, and the source's witness formula uses at most r₀+(Δ+1)|U|+Δr₀+1 names. These constants do not use group size beyond its fixed local gadget size.

If m names suffice for translated program formulas, put

  L_m=max{4,m+1,C max{2,m}},
  t=floor[(M−1)/L_m].

The rank-independent HF-transfer theorem compares the entire hereditarily s-supported domains whenever s≤t. This includes all finite HF ranks and the countably infinite domain. Exact finite counts are transferred via equal sizes of finite stabilizer orbits, so replacing the HF domain by a bounded-rank one is neither needed nor allowed.

## Maximum-state size controls every constituent orbit

Let A₀,A₁,…,A_h be a halting run of the specified interpretation program and define

  S=max_j |A_j|, including input A₀.

Use the source's codes e_j(C)=⟨[j],S_C⟩, where S_C contains the ordered pairs of previous vertex codes representing quotient class C. Each input automorphism induces a permutation of every state, preserving all definable domain pairs and quotient classes.

The following orbit bounds apply to every object recursively occurring in these codes:

- an input atom has orbit at most |A₀|≤S;
- a stage-j vertex code, its payload S_C, and the wrappers involving [j] and S_C have orbit at most |A_j|≤S, since C↦that object is equivariant;
- an ordered pair of two stage-(j−1) vertex codes, or one of its singleton/doubleton wrappers, has orbit at most |A_{j−1}|²≤S²;
- pure ordinal tags and their constituents have orbit one;
- any remaining recursive member is a constituent generated at an earlier stage and obeys the same bound.

Thus every recursive constituent has orbit at most S². This reasoning uses only equivariant maps from actual states or state-pair sets. It does not require the entire accumulated trace to contain only S² objects. A very long computation may have many such objects, all with individually bounded orbits.

By (1), the entire run is hereditarily s-supported for

  s=max{1,ceil[2θκ log_r S]}.

There is no dependence on h, the nesting depth, or the size of ordinal tags.

## Fixed-width encoding and the lower bound

For the two runs being compared, choose an arbitrary finite B bounding both halt stages and all their state sizes. The source's exact translation uses this B only in finite expansions: Härtig comparisons become disjunctions of exact counts 0,…,B, and quotient reachability is unrolled to B². Formula length may be enormous; it does not enter bounded-variable indistinguishability. Capture-avoiding substitution retains a fixed width m(P), independent of B. Pure ordinals and all pair witnesses needed by the true trace lie in the supported HF domain.

If s≤t, the same translated halt and output formulas hold in both supported domains. At the earlier halt time, both halt; their outputs agree. Consequently a program with opposite answers must have s>t. For t≥1 this forces

  2θκ log_r S > t,
  S > r^[t/(2θκ)].                                (2)

For r=3, (2) is S>3^[t/(3κ)]. For r=2 it is S>2^[t/(4κ)]. Since t=Ω(n/(m(P)+1)) and N=Θ(n), this gives the claimed exp(Ω_P(N)) maximum-state lower bound.

The maximum-orbit refinement has passed mathematical audit. The original total-trace count 9B³ also yields exp(Ω_P(N)) for the weaker time-plus-state resource B under the same collective-cofilling input. The state-size result is strictly the stronger formulation and does not rely on bounding the accumulated trace by S².

## Scope and falsification controls

The ordinary query solver is Gaussian elimination; this is an invariance/symmetry-resource barrier. It does not imply P≠NP, general circuit lower bounds, or exponential lower bounds for ordinary Gaussian elimination. It also does not settle whether all polynomial time can be captured by an entirely different logic.

The parameter m(P) is charged. A family of programs whose descriptions or variable width grows with N is not covered by a uniform constant exponent without carrying that dependence explicitly.

Characteristic two requires the triangular cocycle and corrected μ_y=−z+B_e(u,u). Exact tests demonstrate that the uncorrected witness fails. The field-three route avoids this change.

Nonzero H¹ cannot be ignored: an index-r coset action already violates a linear-in-h support theorem if h=1 and the purported cochain representatives are only controlled modulo all cocycles rather than gradients. KOW's global no-p-torsion vanishing theorem is therefore doing essential work.

## Novelty screen and research priority

The pinned source243 main paper and its witnessed-symmetric-choice companion were searched in full for expansion, cofilling, exponential-resource and quantitative-strengthening discussion. Both give grid-based support estimates and qualitative separations; no collective-cofilling or expander exponential-state theorem was found in those texts. Catalogue family244 concerns the Partition Principle and is not this companion.

A targeted primary-source sweep found related but different results: [Pago 2023](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.MFCS.2023.73) restricts its circuit/CFI lower-bound connection, and [Pakusa–Schalthöfer–Selman 2016](https://logic.rwth-aachen.de/pub/schalthoefer/PaScSe16.pdf) explains how higher-rank HF objects can succinctly handle certain CFI instances. [Lichter–Schweitzer 2021](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CSL.2021.31) provides positive CPT canonization for particular bounded dihedral color classes. None of the material checked states this exact exponential maximum-state bound for the proposed all-input linear query. This is a limited negative literature result, not proof of novelty.

Assessment: the mechanism is mathematically concrete and plausibly substantial. Its clean endpoint is an exponential cost of retaining full symmetry in this model, with unbounded HF rank and unlimited time allowed. It does not currently provide a credible route to a new historic general complexity-class separation beyond source243's claim. Preserve and audit this result as a strong intermediate theorem; do not inflate it into a P-vs-NP, proof-complexity, or universal-logic conclusion without a genuinely new bridge.

## Executed checks retained with this record

`check_char2_support.py` and `char2_support_test_results.json` contain exact exhaustive checks of the core gadget on a two-triangle disk: all 389 subgroups of an order-64 group, group laws, relation invariance and vertex translations. The complete query has 132 equations and 208 variables. Ranks are 76/76 for zero charge and 76/77 for unit charge. The corrected zero-charge witness passes all equations; the uncorrected one fails 40. These are falsification tests for finite mechanisms, not validation of the asymptotic lower bound or historical novelty.
