# Blind reconstruction: stabilizer support lemma, including characteristic two

Status: independent AI reconstruction, completed before consulting the originating proof or source-family mechanisms. This is a mathematical argument, not external certification.

## Statement and convention

Let p be prime, let C2 --d2--> C1 --d1--> C0 be a finite-dimensional chain complex over F_p, and fix bases E of C1 and F of C2. Put K = ker(d1), and c_f = d2(f) in K. Assume κ >= 0 and that every ℓ in C1* has a representative r modulo im(d1*) satisfying

    |supp(r)| <= κ |supp(d2* ℓ)|.

Let V = (F_p^2)^F, with v = ((x_f,y_f))_f, and define

    B(v,v') = Σ_f x_f y'_f c_f.
    H = V × K,
    (v,k)(v',k') = (v+v', k+k'+B(v,v')).

If a point in any H-set has an orbit of size p^h, then for its stabilizer L there is T ⊆ E with

    |T| <= κ floor(h²/4),
    { k ∈ K : k_e = 0 for every e ∈ T } ⊆ L ∩ K.

Here K is identified with the central subgroup {(0,k):k∈K}. The proof gives the sharper bound |T| <= κab, where a is the codimension of the image of L in V, b is the codimension of L∩K in K, and a+b=h.

## 1. Group construction in every characteristic

B is bilinear. Consequently

    B(u,v)+B(u+v,w) = B(v,w)+B(u,v+w),

which proves associativity. The identity is (0,0), and

    (v,k)^(-1) = (-v, -k+B(v,v)).

The subgroup K is central, and projection π:H→V is a surjective group homomorphism with kernel K. In particular, |H|=p^(2|F|+dim K), so H is a finite p-group.

With the commutator convention [g,g']=gg'g^(-1)g'^(-1), direct calculation gives

    [(v,k),(v',k')] = (0, B(v,v')-B(v',v))
                       = (0, Σ_f (x_f y'_f-x'_f y_f)c_f).

All these identities hold for p=2. H need not be an elementary abelian group, and L need not be a vector subspace of the underlying set V×K. Neither assertion is needed below.

## 2. Two vector spaces obtained from an arbitrary stabilizer

Let L be the stabilizer. Put W=L∩K and U=π(L). Both are additive subgroups of F_p-vector spaces, and therefore F_p-linear subspaces. The restricted exact sequence

    1 → W → L → U → 1

implies |L|=|W||U|. Write

    a=codim_V(U),   b=codim_K(W).

Orbit–stabilizer then gives

    p^h = [H:L] = p^(a+b),   hence h=a+b.

For any u,u'∈U, select arbitrary lifts in L. Their commutator lies in L∩K=W, so

    Σ_f (x_f y'_f-x'_f y_f)c_f ∈ W.

This uses only the subgroup property, and does not require a linear or homomorphic section U→L.

## 3. Isotropy bounds the face support of each annihilator

Let φ∈K* vanish on W, and define

    S_φ = { f∈F : φ(c_f)≠0 },   s_φ=|S_φ|,
    ω_φ(v,v') = Σ_f φ(c_f)(x_f y'_f-x'_f y_f).

The preceding commutator inclusion says that U is isotropic for ω_φ. Relative to the face-coordinate decomposition of V, the matrix of ω_φ is a direct sum of blocks

    [ 0      φ(c_f)]
    [-φ(c_f) 0     ].

Each nonzero block has rank two, also in characteristic two. Thus rank(ω_φ)=2s_φ and its radical R has dimension 2|F|-2s_φ. The quotient V/R is a nondegenerate alternating space of dimension 2s_φ. The image (U+R)/R is isotropic in that quotient, so its dimension is at most s_φ: indeed an isotropic space I satisfies I⊆I^⊥ and dim I+dim I^⊥=2s_φ.

It follows that

    dim U = dim(U∩R)+dim((U+R)/R)
          <= (2|F|-2s_φ)+s_φ
          = 2|F|-s_φ.

Therefore

    |S_φ| = s_φ <= codim_V(U) = a.

No division by two, classification of subgroups, group-exponent assumption, or lift of a symplectic automorphism is used.

## 4. Apply the support hypothesis and intersect kernels

Choose a basis φ_1,...,φ_b of W^⊥ in K*. Extend each φ_i to some ℓ_i∈C1*. This is possible because K is a subspace of C1. In face coordinates,

    (d2*ℓ_i)(f) = ℓ_i(c_f) = φ_i(c_f),

so |supp(d2*ℓ_i)|=|S_{φ_i}|<=a. By hypothesis choose r_i congruent to ℓ_i modulo im(d1*) with

    |supp(r_i)| <= κ |S_{φ_i}| <= κa.

Every element of im(d1*) vanishes on ker(d1)=K. Hence r_i|_K=φ_i. Set

    T = ⋃_(i=1)^b supp(r_i) ⊆ E.

Then |T|<=Σ_i |supp(r_i)|<=κab. If k∈K vanishes on all coordinates in T, then r_i(k)=0 for every i, hence φ_i(k)=0 for every i. The common kernel in K of a basis of W^⊥ is precisely W. Thus k∈W=L∩K, proving the containment.

Finally, a,b are nonnegative integers with a+b=h, so

    ab <= floor((a+b)²/4) = floor(h²/4).

Since κ>=0, the desired numerical bound follows.

## Degeneracies and hypothesis checks

- b=0: W=K, use the empty basis and T=∅.
- a=0: U=V. Every φ∈W^⊥ has zero face support, so the hypothesis supplies r=0 and forces φ=0; hence b=0. The construction remains valid.
- h=0: L=H, T=∅ works. For h=1, the proof gives ab=0, so T=∅ and W=K.
- K=0: take T=∅ for every stabilizer; the result is immediate for nonnegative κ.
- F=∅ or d2=0: the hypothesis implies K=0. To see this, any ℓ has zero face support and must belong to im(d1*); hence C1*=im(d1*), so ker(d1)=0.
- More generally, the hypothesis implies im(d2)=K: any φ∈K* annihilating im(d2) extends to ℓ with d2*ℓ=0; then its supplied representative is zero and φ=0. Thus the annihilator of im(d2) in K* is zero.
- Repeated, dependent, or zero boundary vectors c_f cause no difficulty. Rank is computed on the separate two-dimensional coordinate block for each f after scalar evaluation by φ.
- κ need not be an integer. The cardinalities themselves are integers and the displayed real inequalities are sufficient. If κ=0 the hypothesis forces K=0.
- Nonnegativity of κ should be made explicit if it is not already part of the meaning of a support/cofilling constant. Without it the literal statement is false in a vacuous degenerate example: take C1=K=0, C2=F_p, d2=0, κ=-1. The support hypothesis is 0<=0. Then H=F_p² has its regular orbit with h=2; the asserted bound |T|<=-1 is impossible even though E=∅. This is only a sign-convention defect, not a characteristic-two obstruction.

## Characteristic two: what fails and what does not

The group always exists. For p=2, its square map is

    (v,k)² = (0,q(v)),   q(v)=B(v,v)=Σ_f x_f y_f c_f.

Thus H can have exponent four. If L is a subgroup, its projection U additionally satisfies q(U)⊆W. This extra necessary condition only restricts possible stabilizers; it does not weaken the commutator-based proof.

An automorphism preserving the distinguished subgroup K, acting on K by g and inducing s on V, must preserve the square map in the sense

    q(sv)=g(q(v)).

In particular, if it fixes K pointwise then q(sv)=q(v). Preserving the alternating commutator form alone is insufficient in characteristic two.

Explicit counterexample to arbitrary symplectic lifting: let p=2, F={f}, K=F_2 c with c_f=c≠0. Then H has eight elements (it is the dihedral group of order eight), and q(x,y)=xy c. The linear shear s(x,y)=(x+y,y) is symplectic for ω((x,y),(x',y'))=(xy'+x'y)c. But q(0,1)=0 while q(s(0,1))=q(1,1)=c. Consequently s cannot be induced by any automorphism of H fixing K. The obstruction is also visible in element orders: the entire fiber above (0,1) consists of involutions, while the fiber above (1,1) consists of elements of order four.

This failure is logically separate from the support lemma, whose proof above only uses alternating-form rank and isotropic-dimension bounds.
