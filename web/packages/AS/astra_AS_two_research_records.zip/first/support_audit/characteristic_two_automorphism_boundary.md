# Exact boundary for linear automorphism lifts

This supplementary calculation is independent of the originating source proofs.

Let V,K be finite-dimensional F_p-vector spaces and let B:V×V→K be bilinear. Give H=V×K the product (v,k)(w,l)=(v+w,k+l+B(v,w)). Define ω(v,w)=B(v,w)-B(w,v). For p=2 also define q(v)=B(v,v).

Fix s∈GL(V) and g∈GL(K). A group automorphism of H restricting to g on K and inducing s on H/K=V has the form

    α(v,k) = (sv, gk+t(v)),

where t(0)=0 and

    t(v+w)-t(v)-t(w) = D(v,w),
    D(v,w)=B(sv,sw)-gB(v,w).

Necessity of the displayed equation follows by applying α to a product. Conversely, any solution t gives a group automorphism, with inverse obtained from the bijectivity of s and g.

For p odd:

Such a lift exists if and only if ω(sv,sw)=gω(v,w) for every v,w. Necessity follows from commutators. Under this condition D is symmetric, and

    t(v) = (1/2)D(v,v)

solves the equation by bilinearity and symmetry.

For p=2:

Such a lift exists if and only if q(sv)=gq(v) for every v. Necessity follows from squares. This condition implies commutator preservation by polarization and makes D symmetric with D(v,v)=0. Choose a basis e_1,...,e_n of V, write v=Σ_i v_i e_i, and put

    t(v) = Σ_(i<j) v_i v_j D(e_i,e_j).

Its polarization is D, so it gives the required lift. Thus the exact liftable linear group in characteristic two preserves the K-valued quadratic map q, rather than merely its alternating polarization ω.

In the single-face example K=F_2 c, B((x,y),(x',y'))=xy'c, the symplectic shear s(x,y)=(x+y,y) is excluded because it changes q(0,1)=0 to q(1,1)=c. Coordinate interchange s(x,y)=(y,x) does preserve q and lifts with t(x,y)=xy c.

The proof of the support lemma does not invoke any such lifting statement.
