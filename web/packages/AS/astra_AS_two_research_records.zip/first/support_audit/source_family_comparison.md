# Post-reconstruction comparison with families 243 and 177

Status: source-file comparison and independent algebraic verification by an AI. The blind proof was saved first in `blind_characteristic_two_support_lemma.md`; only afterward were the source files below consulted. No external certification of either source family's full theorems is claimed.

## Sources inspected

- `/workspace/shared/astra_programme/proof_mining/243_03-support.tex`
- `/workspace/shared/astra_programme/proof_mining/243_02-structures.tex`
- `/workspace/shared/astra_programme/proof_mining/177_main.tex` (checked the coefficient-field macro `\F=\mathbb F_2`)
- `/workspace/shared/astra_programme/proof_mining/177_introduction.tex`
- `/workspace/shared/astra_programme/proof_mining/177_expansion.tex`

This comparison uses excerpts from the pinned source collection. It checks the theorem-to-support bridge, not the complete source existence theorem; provenance and source-verification limits are recorded in the accompanying research reports.

## 1. Exact correspondence with family 243

The proof of source243 Proposition `prop:small-orbit-support` uses exactly the mechanism reconstructed independently:

1. Let S be an arbitrary object stabilizer, U its image in the face-coordinate quotient, and K0=S∩K.
2. Set a=codim(U), d=codim(K0), and use |S|=|U||K0| to obtain a+d=log_p[H:S].
3. Each annihilator λ of K0 gives a block-diagonal alternating form on face coordinates.
4. Commutators of lifts in S show that U is isotropic.
5. Rank 2t forces t<=a, independently of linear dependencies among face boundary vectors.
6. Choose a sparse edge representative for each member of a basis of the annihilator; take the union of supports.
7. Vanishing on that union places a flow in K0 by finite-dimensional duality.

The source proof already treats arbitrary HF rank, since it uses the object only through its stabilizer. The proposed lemma abstracts that argument to arbitrary finite chain complexes and any prime field. The numerical optimization ad<=floor((a+d)^2/4) sharpens the source's looser estimate ad<=(a+d)^2.

In the original source, κ=2L is supplied by Lemma `lem:sparse-cochain`. Its displayed proof actually concludes support <=Lt and then weakens to <=2Lt. Thus the family243 grid also fits the abstract hypothesis directly.

The source uses the odd-characteristic cocycle

    B_alt(v,w) = (1/2) Σ_f (x_f y'_f-y_f x'_f)c_f.

It does not assert a lift of all symplectic automorphisms. Its needed action is left multiplication by the resulting central-extension group, plus central flow translations. The alternate cocycle

    B_tri(v,w) = Σ_f x_f y'_f c_f

has the same commutator for every odd prime and remains defined in characteristic two. Over an odd prime the two extensions are isomorphic by

    (v,k) in H_alt ↦ (v,k+(1/2)Σ_f x_f y_f c_f) in H_tri.

The polarization of the central correction is B_tri−B_alt. In characteristic two the triangular presentation should be used directly, without any division by two or assumption of exponent two.

## 2. Characteristic-two gadget edits actually needed

For the source243 edge group, replace its cocycle by

    B_e(u,u')=Σ_(f∈F(e)) c_e^f x_f y'_f.

The inverse and difference formulas become

    (u,z)^−1 = (−u,−z+B_e(u,u)),
    last((u,z)^−1(u',z')) = z'−z+B_e(u,u)−B_e(u,u').

In particular, one must not retain the original source's simpler inverse or difference formulas.

The global H action restricts to each edge by a homomorphism and is still left multiplication:

    (u,z) ↦ (u+a, z+k_e+B_e(a,u)).

At a vertex, compatible states share the same u_f on the two face edges. Hence the additional divergence is

    (d1 k)_v + Σ_f x_(a,f)y_(u,f) Σ_(e incident to v) ε_ve c_e^f = 0.

Thus configurations remain configurations of the same charge, and all relations based on left-invariant group differences remain preserved. This applies to triangles in a simplicial complex as well as square grid faces: every face meets a vertex in two boundary edges, and d1c_f=0.

For the zero-charge positive query witness in source243 Proposition `prop:opposite-answers`, give weight one to the all-zero configuration at each vertex, as before. The correct value for the edge variable is now

    μ_(e,u,z) = −z+B_e(u,u),

because this is the last coordinate of (u,z)^−1(0,0). Retaining μ=−z would be incorrect in general in characteristic two.

For the negative direction, the proof's chosen zero atom y_e=(e,0,0) still gives

    last((0,0)^−1(u',z')) = z'.

Hence C(y_e,a)=z_e(a), and summing the weighted divergence equations still forces total charge zero. The stated opposite-answer argument therefore survives with the corrected positive witness.

No additional symplectic automorphism is needed for any of these checks. The explicit shear obstruction and exact lifting boundary are recorded separately in `characteristic_two_automorphism_boundary.md`.

## 3. Family177 gives the exact unweighted hypothesis, conditional on its theorem

Suppose X is one of the complexes in family177's stated main theorem, of fixed pure dimension d>=3. Let m=|X(d)|, let every vertex lie in at most D top-dimensional simplices, and let ε be the stated weighted coboundary-expansion constant. Use the 2-skeleton chain complex over F_2:

    C2(X;F_2) --d2--> C1(X;F_2) --d1--> C0(X;F_2).

The family177 degree-one inequality says

    ||δ1ℓ||_2 >= ε min_(b∈im δ0) ||ℓ−b||_1.

Select a minimizer r=ℓ−b (the space is finite). By purity every edge belongs to at least one top simplex. Every triangle belongs to at most D top simplices because each of its vertices does. The defined weights therefore give

    |supp r| <= binom(d+1,2) m ||r||_1
             <= [binom(d+1,2) m/ε] ||δ1ℓ||_2
             <= [D binom(d+1,2)/(ε binom(d+1,3))] |supp δ1ℓ|
             = [3D/((d−1)ε)] |supp δ1ℓ|.

Thus κ=3D/((d−1)ε) is a valid uniform unweighted constant. Here δ0=d1* and δ1=d2*. No comparison to unweighted distance to cocycles is sufficient by itself: the actual inequality against coboundaries (and thus H^1=0) is essential. Family177's stated main theorem supplies precisely that stronger property.

For clarity, family177 uses an odd prime field for its auxiliary group construction, but its cochain coefficient field in the theorem is F_2. It therefore supplies the support hypothesis for the characteristic-two triangular central extension, not directly an odd-coefficient version.

As a further conditional quantitative consequence of the same stated theorem, its degree-zero inequality gives ordinary edge expansion of the 1-skeleton:

    |∂_E S| >= [ε d/(2D)] min(|S|, |V\S|).

Indeed, vertex weights are at least 1/((d+1)m), edge weights at most D/(binom(d+1,2)m), and distance to constants is the minimum weight of S and its complement. The graph maximum degree is at most dD, and the number of triangles at an edge is at most (d−1)D. These degree bounds make the local edge/configuration gadget sizes uniformly bounded for fixed d,D.

This comparison verifies the stated theorem-to-support-hypothesis bridge. It does not independently establish family177's coboundary-expander existence theorem, nor the complete HF transfer or quantitative program-resource theorem suggested downstream.
