# Audit of hereditary transfer and interpretation encoding

Audit date: 2026-10-08. Scope: the mathematical bridge in source family 243, plus exact conditional quantitative consequences. This is a proof reconstruction and falsification audit, not a Lean certificate, independent validation of the base gadgets/expanders, or a historical-novelty certification.

## Verdict

The abstract **Transfer through small supports** theorem and the fixed pair-interpretation encoding pass this audit under their stated hypotheses. No gap was found concerning unbounded finite hereditary rank, infinite-domain counting, representation multiplicities, generated quotients, or variable width independent of the run length.

A stronger encoding lemma also passes: if `S` bounds the input universe and each intermediate state universe, **every individual recursive encoding object has automorphism orbit at most S², independently of the number of stages**. Consequently these arguments yield a **maximum-state-size lower bound for any two finite halting runs**, even with no a priori runtime bound. Using a valid linear-logarithmic support law gives an exponential state-size lower bound; the original quadratic-logarithmic law gives a stretched-exponential one.

The resource conclusion is directly about the explicit, fixed, parameter-free, binary, two-dimensional FO+H interpretation model. A qualitative CPT–interpretation equivalence does not by itself establish an arbitrary-resource CPT or DeepWL simulation with a specified exponential exponent. Nothing here is a lower bound on unrestricted algorithms.

## Sources and provenance

Source revision: `openai/math` commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

- [243 HF transfer](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/05-hf-transfer.tex)
- [243 encoding](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/06-coding.tex)
- [243 support](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/build/sections/03-support.tex)
- [Grohe–Schweitzer–Wiebking, arXiv:2003.10935v1, §6, printed p.22, Theorem 18](https://arxiv.org/pdf/2003.10935v1#page=22)
- [Grädel–Pakusa–Schalthöfer–Kaiser, 2015, Theorem 1](https://www.logic.rwth-aachen.de/pub/schalthoefer/GKPS15.pdf)

The GSW definitions were checked directly. They use binary vocabularies, two-dimensional FO+H interpretations, generated equivalence, existential choice of relation representatives, one initialization and one repeated step, fixed halt/output sentences, and polynomial resource `h + Σ_j |A_j|`. Their Theorem 18 asserts polynomial-time expressive equivalence with CPT. The original GKPS theorem states the corresponding PIL–CPT equivalence and includes counting. This confirms the model used by 243, while leaving quantitative nonpolynomial simulation overhead outside the stated theorem.

## 1. Precise abstract hereditary transfer

Let `A_0,A_1` be nonempty finite structures in a common binary relational vocabulary, with `K_i ≤ Aut(A_i)`. Fix positive integers `s,m,M`. Suppose:

1. `A_0 ≡_{C^M} A_1`.
2. In either base, equal complete `C^M` types of tuples of length at most `max{2,m}s` imply membership in the same `K_i` orbit.
3. `max{4,m+1}s ≤ M`.

Let `D_i` contain precisely the atoms and hereditary finite sets `x` for which `x` and every recursive member have a `K_i` support of at most `s` atom coordinates. Equip it with actual membership, the atom predicate, and base relations made false on non-atoms. Then `D_0 ≡_{C^m} D_1`.

No uniform rank bound is assumed. `D_i` is countably infinite, but each of its sets and each support molecule is finite. The theorem uses ordinary finitary formulas and exact finite cardinality quantifiers.

### 1.1 Atom type extension counts

For matching prefixes `P,P'` and `|P|+d≤M`, every realized complete `C^M` extension type has the same number of `d`-tuple extensions over each prefix.

For one coordinate, isolate the type among all tuples in the two finite bases by a finite conjunction of distinguishing formulas. Count its realizations with one exact-count quantifier. This still uses only the original `M` names. For multiple coordinates, induct: count prefix-type realizations and multiply by the common number of last-coordinate extensions. All products and sums are finite. Repetitions concern tuple *values*, not variable positions, and are recorded by equality formulas. Projection/permutation of positions preserves types.

Counterexample attempt addressed: a general logic cannot necessarily count arbitrary tuple sets with unary counting. Here the complete extension-type partition makes the one-coordinate multiplicities constant; the induction therefore is justified. It does not assert unrestricted tuple-count definability in the same number of variables.

### 1.2 Forms and arbitrary rank

A molecule is an `s`-tuple of atoms. Atomic forms select its coordinates. Set forms are finite collections of pairs `(subform, joint 2s-type)`, evaluated by ranging over molecules with the specified joint type. All values are finite. Equivariance follows by induction, so the molecule supports the value and its recursively represented members have small supports.

Conversely, for a supported set `x`, choose a supporting molecule `α`; represent each of its finitely many members by a form and molecule. Record their joint types with `α`. Any new molecule of such a type is carried to the old one by a `K_i` element fixing `α`, using `2s` homogeneity. Hence evaluating the resulting form adds no element outside `x`. Induction is on the finite rank of the particular object, not on any global rank ceiling.

### 1.3 Equality and membership transfer

For two matching molecule blocks, equality of form values transfers by induction on the sum of their depths. To transfer a member of one set, first match a third molecule block. To find and transfer its equal witness in the other set, use a fourth block. This is the precise `4s≤M` requirement. The inductive equality comparison is between strictly lower-depth member forms. Membership then uses only three blocks plus the already proved equality result.

Atoms cannot equal sets; atomhood is determined by the form constructor. Binary input relations on atom values are in the joint base type, and are false when either argument is a set. Empty sets and repeated arguments cause no exception.

### 1.4 Quotienting representations really counts objects

Retain `r≤m−1` assigned values represented by common forms and matching support concatenations `P,P'`. For a label `(φ,τ)`, where `τ` is an `(r+1)s`-type, consider the values `φ*γ` of molecules extending `P` to `τ`.

Each nonempty label set is one finite stabilizer orbit. Homogeneity on `(r+1)s≤ms` coordinates proves transitivity, and equivariance proves closure. Thus any two label sets coincide or are disjoint. Their overlap pattern agrees across the two bases by extending to `(P,γ,ζ)`, using `(r+2)s≤(m+1)s≤M`, and transferring equality.

Let `n` be the number of molecules realizing a label and `h` the size of a fibre of `γ↦φ*γ`. Stabilizer transitivity makes all fibres equally large. To compare fibre sizes across the bases, partition candidate `ζ` by complete types of `(P,γ,ζ)`. Equality transfer makes the fibre condition constant on each type; the extension lemma gives the same number of realizations of each type. Thus both finite orbit sets have size `n/h`.

This division is essential. A form for the set of all atoms can have `n=|A|` representing molecules but just one value, with `h=n`. Equating molecule counts alone would be false.

There are countably many labels. Their common overlap equivalence classes partition each domain into matching finite sets of equal cardinality. External enumerations supply a bijection on every class and hence a genuine bijection of the entire domains. It maps retained values correctly by equality transfer, and adjoining any matched new pair preserves the represented-alike condition.

### 1.5 Counting over infinite domains

For a bound variable, drop its previous value and retain the other at most `m−1` variables. The bijection just constructed maps the entire satisfying-value set of the formula body bijectively onto its counterpart. This preserves all finite exact cardinalities and also whether the set is infinite. There is no illicit sum of infinitely many finite counts or inference that a countably infinite domain is finite.

The structural induction is on each finite formula. The domains need not be isomorphic, and no single global bijection has to preserve all relations simultaneously; the bijection may depend on the retained assignment.

## 2. Exact interpretation encoding

The input vertices are urelements. For an interpretation stage `j`, every quotient vertex is a class `C` of domain pairs from stage `j−1`. With already injective previous codes, put

- `pair(a,b)={{a},{a,b}}`;
- `S_C={pair(a,b):(a,b)∈C}`;
- `e_j(C)=pair([j],S_C)`.

Kuratowski pairing is injective for atoms as well as sets, even when `a=b`. Classes are disjoint nonempty sets of pairs, so their payloads and codes are distinct. Stage tags separate code vertices of different stages. Possible collisions with auxiliary wrappers are harmless: formulas also recognize the stage tag and complete payload.

### 2.1 The source's 9B³ invariant family

If `B≥2` bounds input size, halt stages, and each state universe, stage `j` contributes at most `3B²` domain-pair objects/wrappers, `B` class payloads, and `3B` tagged-code objects/wrappers. Earlier vertices' constituents were already counted. All ordinal tags and their constituents add at most `B+1` objects, and input atoms at most `B`.

Total: `B(3B²+4B)+2B+1≤9B³`. Membership closure introduces no omitted categories: members of pair wrappers are earlier codes; members of payloads are pair codes; members of tag wrappers are payloads and pure ordinals. Collisions only decrease the size. The family is invariant under every input automorphism because the fixed, parameter-free interpretation formulas, generated equivalence, and quotient relations are invariant. In the source application `H` acts on the input reduct; it need not preserve the extra analytic relations. Only `K` needs to preserve that analytic expansion.

This count is valid for arbitrary finite `B`, not just polynomial `B`. Polynomiality appears in the source only when converting `9B³` to `N^q` for its qualitative separation.

### 2.2 Extensional recognition in the supported domain

The formulas for singleton, doubleton and ordered pair are exact because `D` is transitive: universally testing members in `D` cannot overlook an actual member outside `D`. Atomhood separates the empty set from atoms. The same observation makes ordinal formulas exact by induction.

The symmetric reflexive link relation on domain pairs generates the least equivalence relation. With at most `S²` domain pairs, the unrolled reachability formula through `S²` rounds suffices. Its source indexing yields paths of length at most `t+1`; the extra one is harmless. No assumption that the original `η` was already symmetric, transitive, or an equivalence is needed.

A payload is required to contain *all and only* ordered-pair codes of the equivalence class. Existence comes from the actual supported payload; extensionality gives uniqueness. Relations existentially quantify representatives, matching the chosen quotient convention even if `ρ_R` is not class-invariant. Choosing one representative instead would generally fail.

Härtig comparisons are translated as a disjunction of exact-count tests from `0` through the common state-size bound `S`. The counted sets are subsets of that finite state, even though the ambient `D` is infinite. The translation handles empty states and parameters in counted formulas.

### 2.3 Uniform variable width, with an explicit safe constant

Let `v_P` bound the number of distinct variable symbols in each fixed FO+H formula of the program, including its displayed argument positions. Write `fw(θ)` for the largest number of free variables in any subformula, relative to that subformula.

Capture-avoiding substitution of formulas with the displayed argument interface takes the **maximum**, rather than sum, of template width and inserted width. Bound variables can be freshly renamed before insertion. Repeated actual arguments identify variables, and an inserted formula has no extra free parameters. Renaming a formula of width `w` uses at most `w+1` names by processing its syntax tree with a palette and retaining the names of currently free variables.

The largest fixed encoding interfaces have width six:

- link: 4; reachability recurrence: 6;
- singleton/doubleton: 3/4; ordered pair: 5;
- ordinal recurrence: 2;
- payload and representative templates: at most 5;
- state relation template with two codes and two representative pairs: 6.

Replacing Härtig by up to `S+1` disjuncts does not increase the width with `S`. Restricting quantifiers to the preceding state uses only their own bound variable. Expanding stage formulas recursively takes repeated maxima. Thus

`w_P=max{6,v_P}`, `m_P=w_P+1=max{7,v_P+1}`

is a safe explicit bound for all fully expanded state, halt, and output formulas, regardless of the stage index, universe bound, or formula length. This is a sufficient bound, not an optimized minimum.

The finite comparison formula can be extremely long and depend on the chosen pair of runs. No claim that it can be efficiently constructed, or that the original program receives this nonuniform information, is needed for logical indistinguishability.

## 3. Strengthening: individual orbits cost at most S²

### Lemma

Let a fixed interpretation program run through any finite number of stages on an input `A`, and let `H≤Aut(A)`. Let `S≥max{2,|A|,|A_1|,…,|A_h|}`. Every vertex code and every recursive constituent in the above encoding has `H`-orbit of size at most `S²`. The bound is independent of `h`.

### Proof

Induct on stages. The previous coded state carries an `H` action by state automorphisms. The interpretation's domain is invariant under this action; truth of `η` is preserved, hence so is its generated equivalence relation. Therefore `h·C={h·p:p∈C}` is a well-defined action on the new quotient universe. The existential-representative relation convention is also preserved. The quotient action is a genuine group action because it is induced by the previous one.

All relevant families at each *fixed stage* are equivariant images of the following finite `H`-sets:

| Object category | Invariant indexing set | Orbit bound |
| --- | --- | --- |
| input atom | input universe | `|A|≤S` |
| previous-pair singleton `{a}` | previous universe | `≤S` |
| previous-pair doubleton `{a,b}` | ordered domain pairs, or all previous pairs | `≤S²` |
| pair code `pair(a,b)` | ordered domain pairs | `≤S²` |
| class payload `S_C` | new quotient universe | `≤S` |
| code `pair([j],S_C)` | new quotient universe | `≤S` |
| tag wrapper `{[j],S_C}` | new quotient universe | `≤S` |
| tag singleton `{[j]}` | one fixed pure object | `1` |
| ordinal and its recursive pure members | fixed pure objects | `1` |

Equivariance of payloads is literal set-image equivariance, with no selected representative. Code equivariance follows since `[j]` is fixed. Taking recursive members introduces only other rows of this table or earlier-stage constituents. The induction therefore covers the entire recursive closure. An object coinciding with an object from another stage still has its orbit contained in any one fixed-stage invariant family in which it occurs; such a collision cannot enlarge the orbit. QED.

### Why no global trace-size hypothesis remains

A pointwise, rank-independent small-orbit support theorem applies separately to every object in the table. The abstract `D` requires those individual supports, not a bound on how many objects occur across the run. The number of distinct fixed ordinals may grow without bound as a function of the input, but their supports are empty. None of the formulas quantifies a code for the complete trace or requires the whole trace to fit in one small invariant family.

Replace `B` by `S` in the Härtig expansion and domain-pair reachability bound. Those uses required only state size. Leave the actual finite stage number `j` in the ordinal formula. Width remains fixed independently of `j`. Hence the only role formerly played by a runtime bound was the unnecessary global `9B³` estimate.

### First-halt argument

Use common `S` and the same syntactic formulas on both inputs. If both runs halt, take the earlier halt stage. Both state encodings are exact through that stage. Hereditary `C^{m_P}` equivalence transfers the halt sentence, so the other run halts at that same stage; output equivalence follows. In particular, opposite finite outputs are impossible whenever the support/width conditions hold, regardless of the two originally proposed runtimes.

A nonhalting run is not covered by the phrase “two finite halting runs.” No upper runtime bound is asserted.

## 4. Exact conditional resource theorems

Assume the relevant analytic atom expansions are `C^M` equivalent and that same-type `r`-tuples are `K`-conjugate whenever `Cr+1≤M`, for a fixed real constant `C>0`. Let

`L_P=max{4,m_P+1,C·max{2,m_P}}`,

`t=floor((M−1)/L_P)`.

For any support bound permitting a common positive integer `s`, the explicit sufficient indistinguishability condition is

`L_P s+1≤M`.

This simultaneously implies both hereditary type-extension width and the required atom homogeneity. In what follows assume `t≥1`, merely to remove the irrelevant small-width corner case.

### 4.1 Quadratic-logarithmic support law

Assume each object with `H`-orbit at most `R` has support at most `(κ/4)(log_2 R)²`, with `κ>0` uniform in input size. The stronger group bound `κ floor(h²/4)` for orbit `2^h` implies this law.

The individual-orbit lemma permits

`s=max{1,ceil[κ(log_2 S)²]}`.

Thus two finite runs with opposite outputs must satisfy

`S > 2^{sqrt(t/κ)}`.

Indeed otherwise `κ(log_2 S)²≤t`, hence its ceiling is at most the integer `t`, and `L_P s+1≤M`.

For the base estimate `M=floor(α n/(4Δ))`, this yields, for any fixed constant

`0<c<(1/2)sqrt[α/(ΔκL_P)]`,

`S>2^{c sqrt(n)}` for all sufficiently large `n`. If input atom size `N≤c_A n`, replace `sqrt(n)` by `sqrt(N/c_A)`. Since eventually this exceeds `N`, an intermediate state on at least one input must actually attain the lower bound; it is not merely the input term in the definition of `S`.

For comparison, the original `9B³` argument with `B` also bounding runtime gives

`s=max{1,ceil[(κ/4)(log_2(9B³))²]}`,

`B > 9^{−1/3}·2^{(2/3)sqrt(t/κ)}`.

Both bounds are correct, but the state-only version is stronger. Under a support law written instead as `κ(log_2 R)²` without the factor `1/4`, replace `κ` in the state inequality by `4κ`.

### 4.2 Linear-logarithmic support law from collective cofilling

Assume independently that every object has support at most

`κ·q/(q−1) · log_q |H·x|`,

where `q>1` and `κ>0` are fixed. The support theorem itself is a separate algebraic/expansion input to this audit. The individual-orbit lemma permits exactly

`s=max{1,ceil[(2κq/(q−1))·log_q S]}`.

Therefore opposite finite outputs force

`S > q^{ [(q−1)/(2κq)] · floor((M−1)/L_P) }`.

This retains all ceilings/floors, requires no runtime bound, and is the requested conditional exponential maximum-state theorem. In the concrete base regime `M=floor(α n/(4Δ))`, it gives

`ln S > [(q−1) ln q/(2κq)] · (α n/(4ΔL_P)−O(1))`.

For `q=3`, the exact exponent is `t/(3κ)`. When `N≤c_A n`, every fixed exponent constant below

`(q−1) α ln q / (8κqΔL_P c_A)`

is valid in `S>exp(c_P N)` for sufficiently large inputs in the family.

### Field warning

The abstract theorem above only assumes a proved support law. For its proposed central-extension derivation, keep `q` **prime**, in particular `q=3`, unless a separate argument handles extension fields. Arbitrary additive stabilizer subgroups of an `F_{p^e}` vector space are only automatically `F_p`-linear. They need not be `F_{p^e}`-subspaces, so simply measuring their codimensions over `F_{p^e}` is invalid. This audit does not endorse that unproved extension-field generalization.

### 4.3 What is and is not established about CPT

- Directly established, conditional on the support and base hypotheses: the fixed pair-interpretation program state lower bounds above.
- Qualitatively supported by the published characterization: a polynomial-resource CPT program would yield a polynomial-resource interpretation program, so such a state lower bound obstructs polynomial CPT definability.
- Not established here: an identical exponential state or active-object lower bound for an arbitrary chosen standard CPT machine, BGS syntax, or DeepWL program. That needs an explicit simulation/resource theorem or a separate direct encoding argument.
- Not justified: treating input-dependent formulas/width as one fixed program, choosing a growing coefficient group without a uniform expansion constant, or treating the original 243 grid support coefficient as uniform. The original grid coefficient grows with `L`; the stated quantitative exponents rely on a genuinely uniform cofill constant.

## 5. Falsification work and limitations

The companion script `test_encoding.py` tests:

1. Pair injection with both atom and set arguments, including repetitions.
2. Every directed generating relation on every subset of a two-atom ordered-pair domain, comparing generated equivalence to the exact bounded-path semantics.
3. Quotient relations that are deliberately not constant on representative classes.
4. Multistage symmetric quotient encodings, empty-state transitions, membership closure, the `9B³` family bound, and automorphism invariance.
5. The strengthened individual-orbit bound for every recursively present object, explicitly enumerating symmetric-group automorphisms on small atom sets.
6. A negative control where many molecules denote the same set, showing the need for fibre division.

These finite tests cannot certify the abstract theorem or asymptotic base hypotheses. The report's positive judgment rests on the reconstructed arguments above. The corrected script completed successfully: 49 pair-injection cases; 67,689 exhaustive domain/directed-generating-relation cases; 24 symmetric multistage/empty-state runs (up to eight stages and four atoms); every recursive-object orbit bound passed; four molecule-count negative controls behaved as expected. The largest tested transitive family contained 325 objects. Results are in `encoding_test_results.json`.
