ASTRA: FIRST PRIVATE RESEARCH RECORD
9 October 2026, Brisbane / 8 October 2026, UTC

PURPOSE AND STATUS

This is a private first-pass research record: original mathematical deductions,
proof reconstructions, adversarial checks, and reproducible finite experiments.
The leading result is a candidate exponential maximum-state-size lower bound
for a precisely specified invariant interpretation model. Its strongest audit
status is recorded below and in the accompanying reports.

No 10/10 breakthrough, established historical novelty, general complexity-class
separation, external certification, or proof-assistant verification is claimed.
“Independent”, “blind”, “reviewer”, and “audit” in these reports refer to separate
internal AI reconstructions/checks, not independent human specialist review.
Agreement among these checks is useful evidence, not external validation.

The archive contains original reports/code/results only. Downloaded full papers,
repository source files, credentials, and unrelated operational records are
excluded. No public repository write, publication, external outreach, or paid
computation is part of this record.

READING ORDER

1. proof_mining/EXPONENTIAL_INTERPRETATION_SPACE_CANDIDATE.md
   Current leading mathematical mechanism and exact model boundary.
2. hf_audit/HF_TRANSFER_AND_ENCODING_AUDIT.md
   Hereditarily finite-set transfer, fixed-width encoding, and state-size audit.
3. vector_cofilling/uniform_vector_cofilling_audit.md
   The coefficient quantifiers and published expansion input.
4. entropy_audit/GENERAL_CENTRAL_ENTROPY_THEOREM.md
   The generalized central-state theorem, not only its factorial special case.
5. entropy_audit/PRIOR_ART_COMPARISON.md
   Precise overlap with established entanglement results and remaining novelty
   uncertainty. An unresolved source-rendering issue is not an erratum claim.
6. contact_audit/AUDIT_REPORT.md and contact/CONTACT_REPORT.md
   A finite logarithmic-contact obstruction with two exact certificates.

Earlier scalar-cofilling and characteristic-two files remain as derivations and
negative controls. Their square-root exponent and original family177 expansion
input are superseded for the main candidate. The current route uses published
Kaufman–Oppenheim–Weinberger input and can work over F_3, avoiding characteristic-
two gadget changes. The Gaussian-channel report is a separate elementary route
exclusion, not the current lead.

1. LEADING INTERPRETATION-SPACE CANDIDATE

Consider a fixed parameter-free binary two-dimensional interpretation program P
with FO plus Härtig initialization/step/halt/output tests, least-equivalence-
closure quotienting, and existential-representative relation semantics. The
candidate supplies an isomorphism-invariant linear-consistency query decidable
in ordinary polynomial time and opposite-answer input pairs of size N. Every
fixed P correctly distinguishing those pairs would require maximum intermediate
universe size S >= exp(c_P N) on at least one input, for all sufficiently large
pairs. The input is included in S; finite runtime is otherwise unrestricted.

The route is coefficient-uniform vector cofilling -> support length linear in
log orbit size -> rank-independent HF transfer -> fixed-width interpretation
encoding. It is not a lower bound for arbitrary computation or for Gaussian
elimination. A growing-width/program family must retain its width dependence.
Qualitative polynomial equivalence to CPT/DeepWL does not, by itself, transfer
this arbitrary-resource quantitative bound.

Exact intermediate statement: for a prime r and uniform collective-cofilling
constant kappa, let H be the face-coordinate central extension and K its central
cycle subgroup. Every H-set point with orbit r^h has a coordinate K-support T
with |T| <= kappa*r/(r-1)*h. “Support” means central flows vanishing on T fix that
point; the atom gadget converts coordinates to ordinary atom supports.

For graph expansion alpha, maximum degree Delta, n base vertices, and fixed
translated program width m=m(P), set
  M=floor(alpha*n/(4*Delta)), C=(Delta+1)*(1+Delta/alpha),
  L_m=max(4,m+1,C*max(2,m)), t=floor((M-1)/L_m).
Every recursively occurring object in the actual state encoding has orbit at
most S^2. The claimed exact consequence, for t>=1, is
  S > r^((r-1)*t/(2*kappa*r)).
For r=3 this is S>3^(t/(3*kappa)); bounded local gadgets give N=Theta(n).

The support mechanism, abstract HF transfer, fixed-width encoding, and stronger
S^2 constituent-orbit estimate passed separate internal first-pass mathematical
checks. A safe explicit width is m(P)=max(7,v_P+1), where v_P bounds distinct
variable names in the fixed program formulas. KOW's formal theorem package
supplies coefficient-uniform vector cofilling for one fixed sufficiently large
construction prime p different from r. In particular r=3 is available.

The result still depends on imported KOW/upstream expansion theorems and the
stated expander-to-gadget base equivalence/homogeneity arguments. The vector
audit tracks the quantifier order and supplies a truncated-ring K_2/stability
check for a compressed source step; it does not re-prove every upstream input.
The HF theorem is explicitly conditional on those base/support hypotheses.
No complete source repository was formally verified here. No quantitative
arbitrary-resource CPT/DeepWL simulation or exhaustive novelty review is supplied.

2. CENTRAL-STATE ENTROPY THEOREM

Let N=2n>=2, all logarithms natural, m_(N,J) the spin-J multiplicity, and P_(N,J)
the full spin-J projector. For an arbitrary probability law p_(N,J), define
  rho_N=sum_(J=0)^n p_(N,J)*P_(N,J)/((2J+1)*m_(N,J)),
  M_N=sum_J p_(N,J)*log(J+1).
For an absolute C_* and every integer k>=1,
  k*[0.5*log(N+1)-C_*-4*M_N]
    <= inf_(sigma in FULLSEP_(N,k)) D(rho_N^tensor k || sigma)
    <= k*log(n+1).
FULLSEP_(N,k) is the convex hull of products across the N original laboratories;
each laboratory may entangle its own k registers. Thus bounded M_N gives a
uniform all-copy Theta(log N) bracket with coefficient between 1/2 and 1.
The report supplies explicit conservative constants and the analytic proof.

The upper bound holds for every central state. Centrality means scalar on each
full spin-J isotypic component, a stronger condition than merely commuting with
collective SU(2). This is a sufficient condition, not a characterization. An
exact leading coefficient and distillation by the N separate laboratories are
not established. The earlier factorial example is a special case.

The singlet logarithmic law, representation-space distillation mechanism,
ordinary bipartite LOCC interpretation, and resulting all-copy FULLSEP lower
bound have substantial prior art. Fixed nonzero (J,M) sectors are also already
treated. The candidate extension is the explicit quantitative low-global-spin
robustness estimate for unflagged, full-irrep-averaged central mixtures and its
original-lab comparator. The targeted literature comparison is not exhaustive
and does not certify novelty.

3. EXACT FINITE CONTACT OBSTRUCTION

For ell_i(z)=log(1+z/i), i=1,...,4, the primitive integer multiaffine polynomial
P4 in contact/extremal_multiaffine_4.json is, up to scale, the unique nonzero
polynomial with its first 15 Taylor coefficients zero. Its contact is exactly
15. It cannot equal det(A0+sum_(i=1)^4 x_i*A_i) over C when each rank(A_i)<=1,
at any matrix size. Consequently it has no read-once determinant expression;
a nonzero determinant in this restricted class has contact at most 14.

Independent exact arithmetic reproduced the fixture, jet ranks, the finite-free
quotient norm 17 mod 101, and the universal Nanson certificate 5 mod 101. The
quotient-unit argument justifies exclusion over C; this is not an inference
from lack of points over a single finite field. Finite fixtures n=2,3,4,5 have
contacts 3,7,15,31. They do not demonstrate a uniform small circuit family.
General determinants, general circuits, and the size-sensitive logarithmic
contact conjecture remain unresolved.

4. WHAT WAS RULED OUT OR CORRECTED

- Scalar cofilling alone yields a quadratic-in-log-orbit support estimate.
  The stronger linear estimate needs simultaneous vector/union-support control.
- Expansion only modulo cocycles cannot silently replace expansion modulo
  gradients. A nonzero H^1 class produces an index-prime small-orbit obstruction.
- In characteristic two, the extension may have exponent four. Preserving the
  alternating commutator alone does not guarantee a center-fixing automorphism.
  A tested shear is a counterexample. The triangular-cocycle query requires
  mu_(e,u,z)=-z+B_e(u,u); the uncorrected witness fails finite checks.
- Bounded Shannon entropy of total spin alone does not imply logarithmic
  entanglement: the normalized maximal-spin projector is fully separable.
  Arbitrary noncentral singlet states also invalidate a universal logarithmic
  FULLSEP upper bound; products of pair singlets provide the obstruction.
- The maximal-contact P4 fixture has no rank-one-variable/read-once determinant
  compression. This is a narrow finite obstruction, not a general circuit bound.
- Any two admitted Gaussian-ensemble channels satisfying the report's norm
  events have entanglement-breaking composition, even with correlated draws.
  A Frobenius separability certificate of 2/9 rules out this proposed escape.
  No universal PPT-composition conjecture is resolved.

EVIDENCE, REPRODUCTION, AND PACKAGING

EVIDENCE_PINS.txt records the immutable repository revisions and primary-paper
versions/theorem locations. Report citations point to full external sources,
which are deliberately not redistributed here. Earlier reports sometimes refer
to those excluded local source copies or to unbundled replay directories.

SHA256SUMS.txt hashes every included file other than itself. PACKAGE_PROVENANCE.json
records original and packaged file hashes and the small packaging-only edits.
The original successful results remain archived. PACKAGING_CHECKS.json records
reruns of the contact, entropy, support, and HF checks in temporary copies. The
contact certificates reproduce exactly, and all mathematical fields of the
independent result agree. Final HF checks passed 67,689 exhaustive quotient
cases, 49 pair injections, 24 multistage/empty-state runs, all tested individual
orbit bounds, and four molecule-count negative controls.

Use Python 3. The independent contact, Nanson, support, HF, and entropy audit
scripts use the standard library; some entropy diagnostics are floating point.
The original contact generator needs SymPy; the earlier factorial numerical
diagnostic needs SciPy. Exact fixture/certificate checks are distinguishable
from numerical sanity tests. Experiments do not prove asymptotic statements.

Run REPRODUCE.py for bundled core checks in a temporary copy, leaving archived
results unchanged. It does not install packages or contact external services.
The optional comparison against the downloaded Astra fixture is not rerun
unless that excluded source is supplied separately; its original successful
comparison and source hash remain in the saved result.

NEXT DECISIVE GATE

External specialist scrutiny of the exact exponential-state theorem and its
source dependencies, an independent proof-assistant development where useful,
and a broader targeted novelty search are still needed before promotion beyond
a carefully scoped internally audited candidate. No external review or outreach
has been commissioned by this record.
