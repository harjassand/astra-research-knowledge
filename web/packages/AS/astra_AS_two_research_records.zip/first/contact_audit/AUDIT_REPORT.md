# Independent audit: four-log contact fixture and restricted determinants

Audit date: 2026-10-08 UTC.

## Outcome and scope

**PASS within the stated finite scope. No decisive flaw was found.** The primitive integer polynomial P4 in the supplied fixture has logarithmic contact exactly 15, is uniquely determined up to scale by the first 15 vanishing conditions, and has no representation over C as a determinant with a rank-one coefficient matrix for each of its four variables, in any matrix size. Consequently it has no read-once determinant representation under the usual convention that each variable occurs in at most one matrix entry.

This audit independently reconstructs the computation and the necessary algebra. It is not proof-assistant verification, external specialist review, or a novelty assessment. It does not establish an asymptotic circuit lower bound, a general determinant lower bound, a PIT breakthrough, or the proposed general size-sensitive contact bound. The original report's unrelated general Wronskian/contact discussion was outside this audit.

An immediate finite corollary is that a nonzero four-variable rank-one-variable determinant has contact **at most 14** on log(1+z), log(1+z/2), log(1+z/3), log(1+z/4). This follows from uniqueness of the order-15 multiaffine polynomial and its exclusion. Attainment of 14 was not investigated.

## Evidence files and reproducibility

- `independent_audit.py`: stdlib-only independent reconstruction using exact `Fraction` arithmetic, rational row reduction, elementary quotient recurrences, and determinants. It imports neither SymPy nor the original generator.
- `independent_results.json`: complete machine-checkable results, including the exact nonzero rational quotient norm.
- `audit_nanson.py`: independent sparse-polynomial expansion proving the supplemental universal identity over the integers, plus its evaluation on this fixture.
- `nanson_independent_results.json`: supplemental certificate result.
- The original SymPy certificate was replayed with only the fixture/output directory changed; its certificate JSON was identical. The summary is included below; duplicate replay files are omitted from this archive.
- `original_replay_result.json`: replay details and source-script SHA-256.

Run:

    python independent_audit.py
    python audit_nanson.py

The input coefficient fixture SHA-256 is:

    8cb32d0f28bcea2e390b08515ee73ab3f9f0116eef0f0e3f9eb7fe45deb788cc

The independent script compares all terms against the preserved Astra source fixture `../frontier/d-de03f8ff1da7598d.txt`, whose provenance was supplied as `updates/AP/package/pit/contact_examples.json` at pinned revision `39cdea532f19217f633f70315d92c314a6ce5e3e`. Term equality was verified locally. This audit did not independently refetch that GitHub revision. The preserved-source SHA-256 is recorded in the result JSON.

## 1. Contact polynomial reconstruction

Use mask bit i-1 for variable xi. Independently build each product of the four formal series using exact rational convolution and coefficients

    [z^k] log(1+z/i) = (-1)^(k+1)/(k i^k), k >= 1.

The matrix with rows indexed by z^0 through z^14 and columns by the 16 squarefree monomials has rank 15; its first 15 columns are pivot columns. With the coefficient of x1*x2*x3*x4 normalized to 1, its unique kernel vector matches the originally reconstructed fixture and the preserved Astra source term by term. Adding row z^15 raises the rank to 16. Thus the pullback map has no nonzero multiaffine polynomial with order at least 16, and the order-15 polynomial is unique up to scale.

For the primitive integer normalization, the first nonzero coefficient is exactly

    [z^15] P4(logs) = 106094131743479867224150599577643825 / 144618323705856.

The full-monomial coefficient is c = 3216992424277409444056193764900, and c mod 101 = 45. Define q=P4/c.

## 2. Principal minors and gauge: no missing branch

Suppose q=det(diag(x)+A). For I subset {1,2,3,4}, its coefficient of the complementary squarefree monomial is the principal minor m_I=det A[I,I]. There is no sign change in this complementary-coefficient convention.

Define

    a_i=m_{i},
    r_ij=a_i*a_j-m_{ij},
    t_ijk=m_{ijk}-a_i*a_j*a_k+a_i*r_jk+a_j*r_ik+a_k*r_ij.

Direct expansion of the 2-by-2 and 3-by-3 determinants gives r_ij=Aij*Aji and t_ijk equal to the sum of the two oriented 3-cycle products. Independently recomputed reductions modulo 101 are

    a = (51,9,44,83),
    (r12,r13,r14,r23,r24,r34) = (13,18,7,57,10,34),
    (t123,t124,t134,t234) = (91,54,82,37).

In particular every r_ij is nonzero as a rational number. Under a proposed complex realization, every off-diagonal Aij is therefore nonzero. Diagonal similarity with

    D=diag(1,A12^(-1),A13^(-1),A14^(-1)), A'=D^(-1)*A*D

preserves all principal minors and produces A'12=A'13=A'14=1, A'21=r12, A'31=r13, A'41=r14. Hence there is no lost zero-entry branch in this gauge.

Put u=A'23, v=A'24, w=A'34. They are nonzero, and the pair products determine the reversed entries. The triple conditions imply

    r13*u^2-t123*u+r12*r23 = 0,
    r14*v^2-t124*v+r12*r24 = 0,
    r14*w^2-t134*w+r13*r34 = 0,
    g = r24*u^2*w^2+r23*r34*v^2-t234*u*v*w = 0.

The last equation is obtained by multiplying the fourth triple-cycle condition by the nonzero uvw. These are necessary conditions only; their inconsistency suffices. The full 4-by-4 determinant constraint is not needed.

## 3. Algebraic-closure exclusion and characteristic zero

Let R=Z_(101), the rational numbers with denominator coprime to 101. All q coefficients lie in R, since c is a unit. All r_ij also lie in R and are units, by the displayed nonzero residues. Normalize each of the three quadratic equations by its leading coefficient. Their reductions are

    u^2+23*u-43,
    v^2+50*v+33,
    w^2+46*w-28.

The quotient B over R by these separate monic quadratics is finite free of rank 8 with basis

    (1,w,v,vw,u,uw,uv,uvw).

This basis assertion needs no radicality, separability, or algebraic-closedness assumption. Repeated application of each monic quadratic gives existence and uniqueness of a representative of degree below 2 in each variable.

The independent script constructs multiplication by g directly using these reduction recurrences. It reproduces every entry of the supplied 8-by-8 matrix. Its determinant is 17 modulo 101. Therefore its determinant in R is a unit. Multiplication by g is invertible in B, so there exists h in B with gh=1. No field-valued point of B can additionally satisfy g=0. This excludes solutions over C and over every characteristic-zero extension, not merely F101 points.

There is no inference here that arbitrary complex matrix entries can be reduced modulo 101. Such an inference alone would be invalid. The finite-free quotient and unit norm supply the needed lifting argument.

As an extra direct check, the script computes the exact determinant of the multiplication matrix over Q. It is a nonzero rational number with a 2030-digit numerator and a 1915-digit denominator; its reduction is again 17. The full rational value is saved in the results. As a small modular witness, in the above basis the coefficients

    (93,76,22,64,71,12,81,73)

represent g^(-1) in the quotient over F101. Matrix multiplication independently verifies g*h=1.

## 4. Larger-size rank-one determinants

The original block/Schur-complement reduction is valid. Here is an independent proof that avoids any possible ambiguity about the chosen bases.

Suppose

    f(x)=det(M0+U*diag(x)*V^T),

where U,V have four columns and the coefficient c of x1*x2*x3*x4 is nonzero. Choose a constant basepoint b at which M(b) is invertible; it exists because f is a nonzero polynomial over the infinite field C. Set K=V^T*M(b)^(-1)*U. The matrix determinant lemma gives

    f(b+y)=det M(b)*det(I+diag(y)*K).

Every variable enters with rank one, so f is multiaffine; shifting does not change its full-monomial coefficient. Therefore

    c=det M(b)*det K.

Thus K is invertible, and

    f(x)/c=det(diag(x)+K^(-1)-diag(b)).

This is exactly the four-dimensional diagonal-plus-constant representation already excluded for q. There is no additional matrix-size restriction or genericity assumption beyond the nonzero full-monomial coefficient, which this fixture satisfies. Coefficient matrices of rank zero cannot occur for a representation of this particular polynomial; allowing rank at most one does not change the result.

## 5. Supplemental Nanson identity

The original reconstruction supplied a second certificate based on the first four rows of the Nanson matrix in Lin–Sturmfels, Section 3: [primary source](https://arxiv.org/html/0812.0601v3).

The displayed formula was checked against that primary source. More strongly, `audit_nanson.py` substitutes arbitrary independent off-diagonal matrix indeterminates into the six pair products and four triple-cycle sums, expands the 4-by-4 determinant using sparse integer polynomial arithmetic, and obtains exactly zero. This independently verifies the universal polynomial identity without relying on an empirical sample or the source's proof.

For the present fixture it independently reproduces

    [31 63 56 71]
    [48  1 77 26]
    [28 60 64 31]
    [57 12 18 86]

with determinant 5 modulo 101. Since the relevant rational inputs all have denominators prime to 101, the universal polynomial relation is nonzero on this fixture in characteristic zero. This is a second complete obstruction, independent of the finite-quotient proof. No novelty is claimed for the identity or the general principal-minor method.

## Final assessment

The exact finite obstruction is defensible by two independent algebraic certificates and an independently reconstructed source fixture. The appropriate research-status label is **exactly reproduced, algebraically audited finite obstruction**, with the limitations above. General PIT and logarithmic-contact conjectures remain open in this work.
