FINAL METADATA HANDOFF

This directory contains a final-ish usage/configuration snapshot, Python environment metadata for the four excluded venv roots, and exact Git source identity material. It does not contain proof analysis or an archive. The final roster and archive remain with the coordinator.

Files:
- `USAGE_SNAPSHOT_FINALISH.json`: output of `work/state/audit_usage.py` run explicitly with the root session and `work/state/cycle10_deep_review_dispatch.json`; includes per-session latest model/effort and cumulative token counters, no prompts.
- `RESOURCE_SUMMARY_FINALISH.json` and `.txt`: usage totals and refresh16 deltas, pricing proxy caveat, direct roster note, and the explicit unlaunched/pending status for `covariant_obstruction_sol`.
- `EXCLUDED_RUNTIME_ENVIRONMENTS.json`: four `venv`/`.venv` roots with `pyvenv.cfg`, Python version and installed distribution name/version from package metadata. Metadata parsing did not import packages or use network. These versions support environment reconstruction, but platform/native wheel identity is not captured; retain an environment if exact native replay requires it.
- `SOURCE_REPOSITORY_IDENTITY.json`: commit, tree, raw commit hashes/files, remotes and clean status for the two pinned repositories.
- `SOURCE_PATH_BLOB_MODE.tsv.gz`: complete `git ls-tree` path/blob/mode/size index (165,072 entries); `path_base64` preserves exact path bytes.
- `astra.HEAD.rawcommit` and `openai_math.HEAD.rawcommit`: raw commit-object payloads whose Git IDs were checked against HEAD.

Cumulative tokens are latest per-thread totals. Cached input is part of input; reasoning output is part of output. The USD value is a standard-rate estimate only; actual billing is unknown. The usage auditor's embedded active reservation uses an older dispatch roster, so the separate named-status estimate is explicitly qualified and the coordinator's final roster takes precedence.
