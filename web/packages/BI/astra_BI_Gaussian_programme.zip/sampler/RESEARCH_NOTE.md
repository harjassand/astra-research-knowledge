# Count-compressed Gaussian photon simulation

**Research date:** 9 October 2026  
**Output:** mathematical construction, finite-bit sampling method, executable prototypes, exact checks and numerical experiments.  
**Status:** an internally derived applied-method candidate. This document does not claim independently established historical novelty, a formally verified software implementation, a general quantum simulator, or a demonstrated 10/10 technological breakthrough.

## 1. The capability

Given an explicitly supplied nonnegative Gaussian Bargmann kernel, sample its joint photon-number distribution, optionally conditioned on specified photon counts in a subset of modes. The output is a vector of **binary-encoded counts**. The algorithm neither enumerates the photons nor simulates complete optical experiments until a rare herald occurs.

The central construction replaces trajectories by aggregate edge multiplicities. Eliminate the unobserved modes by Schur complements, sample a finite matching on the observed photon tokens, and undo elimination with binomial and negative-binomial draws. Coherent displacement is represented by a single additional boundary vertex and one Poisson draw.

The two concrete gains are distinct:

* The number of graph operations and scalar random-variate calls is cubic in the number of modes, not proportional to the numerical photon population.
* Conditioning is performed through a finite weighted matching law, not rejection with cost inverse to the herald probability.

The second principle already appears in Astra's N42 record. The contribution developed in this run is the **count-compressed reconstruction, explicit finite-bit route, executable implementation and their composition with pure/mixed/displaced positive kernels**. It would be incorrect to describe this as the first proposal for rejection-free positive-Gaussian heralding.

The implementation has two backends. The fast backend uses NumPy floats and 64-bit counts for pure, undisplaced states. The rational backend uses exact rational elimination and matching, arbitrary-size Python integers, and interval-based scalar samplers with an explicit error budget. Neither backend implements the general-graph perfect-matching FPRAS. Its consequences are separated in Section 8.

## 2. Scientific model and input contract

For a particularly transparent physical subclass, let

\[
 |\psi\rangle=Z^{-1/2}\exp\!\left(\tfrac12 a^{\dagger T}Ba^\dagger+g^Ta^\dagger\right)|0\rangle,
\]

where \(B=B^T\geq0\) entrywise, \(\|B\|_2<1\), and \(g\geq0\). All supplied coefficients are rational. This is a valid pure Gaussian state. For real parameters,

\[
 Z=\det(I-B^2)^{-1/2}\exp\!\left(g^T(I-B)^{-1}g\right).
\]

At \(g=0\), its photon-number distribution is

\[
 p_B(n)=\sqrt{\det(I-B^2)}\,
 \frac{\operatorname{haf}(B[n])^2}{\prod_i n_i!}.
\tag{2.1}
\]

Here \(B[n]\) repeats row and column \(i\), \(n_i\) times. A diagonal entry of \(B\) may join distinct copies of the same mode. Odd-order hafnians are zero. Photon collisions are retained.

More generally, use the real Bargmann density kernel

\[
 R(\xi)=c\exp\!\left(\tfrac12\xi^TK\xi+\ell^T\xi\right),
 \quad \xi=(z_1,\ldots,z_m,w_1,\ldots,w_m),
\tag{2.2}
\]

with rational symmetric \(K\geq0\), rational \(\ell\geq0\), and real ket/bra exchange symmetry. Write

\[
 X=\begin{pmatrix}0&I\\I&0\end{pmatrix},\qquad \rho(XK)<1.
\]

A quantum interpretation additionally requires that (2.2) represents a positive density operator. The general constructor does **not** attempt a complete physicality test. `pure_kernel` gives a physically valid input family; `trace_modes` produces physical mixed kernels by tracing modes out of an already physical input. Nonnegativity and convergence alone define a normalized positive diagonal count law, but should not be advertised as sufficient for every quantum-state constraint.

The pure subclass corresponds to \(K=\operatorname{diag}(B,B)\), \(\ell=(g,g)\). The normalizer of the general kernel is

\[
 c^{-1}=\det(I-XK)^{-1/2}
 \exp\!\left(\tfrac12\ell^T(I-XK)^{-1}X\ell\right).
\tag{2.3}
\]

Let \(H\) be the observed modes and \(h_i\geq0\) their prescribed counts. Write \(h=\sum_{i\in H}h_i\), \(s=|H|\), and \(U=H^c\). The desired output is

\[
 N_U\sim\mathcal L(N_U\mid N_H=h).
\]

A zero-probability herald is rejected as an invalid conditioning event. The working exact matching recurrence detects it exactly.

**Excluded interfaces.** Generic signed or complex interference matrices, approximate-input tomography without an error model, arbitrary non-Gaussian inputs, arbitrary quantum measurements, and the ordering of individual photon arrivals are not covered. A supplied local-phase gauge can sometimes reduce a state to the nonnegative class, but finding such a gauge is not assumed free. The algorithm samples a measurement distribution, not a classical description of the entire quantum state.

## 3. Positive Gaussian marginalization

Subscripts below refer to doubled sets of modes. Let \(D_z\) be diagonal on the doubled unobserved set, with the same physical marking variable on its ket and bra copy. Put

\[
 M=X_UK_{UU},\qquad
 J(z)=D_z(I-MD_z)^{-1}X_U.
\tag{3.1}
\]

For positive \(z\), this is also \((X_UD_z^{-1}-K_{UU})^{-1}\). The formula extends to zero markings by continuity. Define

\[
 S(z)=K_{HH}+K_{HU}J(z)K_{UH},
\]
\[
 t(z)=\ell_H+K_{HU}J(z)\ell_U,
 \qquad v(z)=\ell_U^TJ(z)\ell_U.
\tag{3.2}
\]

Gaussian contraction of unobserved ket/bra indices gives

\[
 R_H(\xi_H;z)=c\det(I-D_zM)^{-1/2}
 e^{v(z)/2}
 \exp\!\left(\tfrac12\xi_H^TS(z)\xi_H+t(z)^T\xi_H\right).
\tag{3.3}
\]

One can prove (3.3) either by completing the quadratic form in the complex Gaussian trace integral or by expanding in Wick contractions. Nonnegativity makes the path expansions below absolutely convergent for \(0\leq z\leq1\).

Let \(r=(h_1,\ldots,h_s,h_1,\ldots,h_s)\). Let \(L_r(S,t)\) be the sum of weights of all partitions of these **labeled** tokens into pairs and singletons. A pair of types \(a,b\) has weight \(S_{ab}\); a singleton of type \(a\) has weight \(t_a\). This is a loop hafnian, with singleton weights kept separate from pair weights between repeated copies.

Taking the observed Fock coefficient in (3.3) proves the conditional probability generating function

\[
 F_h(z)=
 \left[\frac{\det(I-M)}{\det(I-D_zM)}\right]^{1/2}
 \exp\!\left(\frac{v(z)-v(1)}2\right)
 \frac{L_r(S(z),t(z))}{L_r(S(1),t(1))}.
\tag{3.4}
\]

The factors \(\prod h_i!\) and the full-state normalizer cancel. This is why the sampler does not need the herald success probability.

For diagnostics only,

\[
 \Pr(N_H=h)=
 \sqrt{\frac{\det(I-XK)}{\det(I-M)}}
 e^{[v(1)-v_{\rm full}(1)]/2}
 \frac{L_r(S(1),t(1))}{\prod_i h_i!}.
\tag{3.5}
\]

The implementation never feeds (3.5) into a rejection step.

## 4. Count-compressed reconstruction theorem

### 4.1 Elimination

Take an entrywise nonnegative matrix \(W\), with an internal set \(U\) and a boundary set that is never traversed internally. Suppose \(\rho(W_{UU})<1\). For an internal vertex \(v\), set

\[
 p_v=1-W_{vv}>0,
 \quad V_{ij}=\frac{W_{iv}W_{vj}}{p_v},
 \quad W'_{ij}=W_{ij}+V_{ij}.
\tag{4.1}
\]

Record \(p_v\) and

\[
 \theta^{(v)}_{ij}=\frac{V_{ij}}{W'_{ij}},
\tag{4.2}
\]

taking the ratio to be zero when both numerator and denominator vanish. Repeat until all internal vertices have been removed. The final boundary matrix is

\[
 W_{HH}+W_{HU}(I-W_{UU})^{-1}W_{UH}.
\]

### 4.2 Reverse step

Suppose the reduced graph currently contains directed edge counts \(C_{ij}\). Independently, draw

\[
 R_{ij}\sim\operatorname{Binomial}(C_{ij},\theta^{(v)}_{ij}),
 \qquad K_v=\sum_{ij}R_{ij}.
\tag{4.3}
\]

Retain \(C_{ij}-R_{ij}\) direct edges. Replace the routed edges by

\[
 C_{iv}=\sum_jR_{ij},\qquad C_{vj}=\sum_iR_{ij}.
\]

Draw the self-loop count

\[
 C_{vv}\sim\operatorname{NegBin}(\alpha+K_v,p_v),
 \qquad N_v=K_v+C_{vv}.
\tag{4.4}
\]

The negative-binomial convention is

\[
 \mathbb E[z^{\operatorname{NegBin}(a,p)}]
 =\left(\frac{p}{1-(1-p)z}\right)^a.
\]

The shape is **\(\alpha+K_v\), not just \(K_v\)**. The additional shape accounts for the loop soup. For photon simulation, \(\alpha=1/2\).

### 4.3 Proof

Write \(a=W_{vv}\). Each reduced edge \(i\to j\) is a mixture of a direct edge of weight \(W_{ij}\) and an excursion through \(v\) of total weight \(W_{iv}W_{vj}/(1-a)\). Therefore the direct/excursion choice has probability (4.2). For a multiplicity of identical reduced edges, their independent choices aggregate exactly to (4.3).

Each of the \(K_v\) routed excursions makes one compulsory visit to \(v\), followed by a geometrically distributed number of self-loops with generating function \((1-a)/(1-az)\). Loops wholly removed at \(v\), independently, have generating function

\[
 \exp\!\left(\alpha\sum_{k\geq1}\frac{a^k(z^k-1)}k\right)
 =\left(\frac{1-a}{1-az}\right)^\alpha.
\]

Multiplying these factors gives a negative binomial of shape \(\alpha+K_v\). The marked effective excursion weight is

\[
 \frac{W_{iv}W_{vj}z}{1-az}.
\]

This is exactly the marked version of the Schur-complement update (4.1). Inductively undoing all vertices recovers the original path weights and determinant factor. This proves the joint occupation law, not merely its first moments.

In the absence of boundary paths, the result has PGF

\[
 \mathbb E[z^N]=
 \left[\frac{\det(I-M)}{\det(I-D_zM)}\right]^\alpha.
\tag{4.5}
\]

The argument permits arbitrary finite graphs, collisions, repeated edges, self-loops and nonreversible nonnegative internal matrices. There is no loop-length cutoff and no mixing-time assumption.

**What is inherited.** Schur-complement path compression and binomial/negative-binomial reconstruction have an established kinetic path-sampling antecedent [3]. The loop measure and determinant law are classical [4,5]. The present statement composes the loop immigration term, arbitrary boundary paths and the Gaussian conditioning interface. No claim that Schur elimination or kinetic path sampling itself is new is made.

## 5. Complete Gaussian sampling procedure

Use one additional boundary vertex \(\star\), representing the displacement source. Order the vertices as doubled \(U\), doubled \(H\), then \(\star\). Construct

\[
 W=
 \begin{pmatrix}
 X_UK_{UU}&X_UK_{UH}&X_U\ell_U\\
 K_{HU}&K_{HH}&\ell_H\\
 \ell_U^T&\ell_H^T&0
 \end{pmatrix}.
\tag{5.1}
\]

Eliminate only doubled \(U\). The final boundary block is

\[
 \begin{pmatrix}S(1)&t(1)\\t(1)^T&v(1)\end{pmatrix}.
\]

Perform the following operations:

1. Sample a pair/singleton matching of the \(2h\) observed tokens, with weights \(S(1),t(1)\).
2. Record each paired token pair as one directed boundary edge, choosing either orientation. Record each singleton as an edge to \(\star\).
3. Independently draw \(P\sim\operatorname{Poisson}(v(1)/2)\), and add \(P\) self-edges at \(\star\).
4. Reverse elimination by (4.3)–(4.4), with \(\alpha=1/2\).
5. Sum ket and bra occupation counts for each unobserved physical mode. Do not report the ghost or boundary occupations.

All boundary path functions are symmetric after physical variables are identified on ket/bra copies, so choosing a fixed orientation for each matched pair introduces no bias. The Poisson source contributes

\[
 \exp\!\left(\frac{v(1)}2\left[\frac{v(z)}{v(1)}-1\right]\right)
 =e^{[v(z)-v(1)]/2}.
\]

The zero-rate case is interpreted as no source paths. Combining this with (4.5) and the weighted matching law yields exactly (3.4). This completes the distributional proof of the algorithm in ideal scalar arithmetic.

For pure undisplaced GBS with no herald, there are no boundary paths, and the construction reduces to \(\alpha=1/2\) loops on

\[
 M=\begin{pmatrix}0&B\\B&0\end{pmatrix}.
\]

The resulting PGF is

\[
 \frac{\sqrt{\det(I-B^2)}}{\sqrt{\det(I-(D_zB)^2)}},
\]

which is the PGF of (2.1). This also explains even total photon parity. It does not assert a positive mixture of coherent quantum states.

### Exact matching backend

For type multiplicities \(r\), select the first occupied type \(a\). The executable recurrence is

\[
 Z(r)=t_a Z(r-e_a)
 +\sum_b (r_b-\mathbf1_{a=b})S_{ab}
 Z(r-e_a-e_b),\qquad Z(0)=1.
\tag{5.2}
\]

Negative-multiplicity terms are absent. Conditional branch probabilities are the summands divided by \(Z(r)\). Rational arithmetic makes these choices exact in the unbiased-random-bit model. The multiplicity factor counts the possible partner labels; no extra singleton multiplicity is required because the distinguished token is fixed.

The number of memoized states is bounded by

\[
 R_h=\prod_{i\in H}(h_i+1)^2.
\tag{5.3}
\]

Thus the executable matching stage is exponential in the worst herald configuration. It is efficient for small heralds and often substantially smaller for repeated types than explicit labeled-subset enumeration. A production implementation must impose memory and recursion budgets; these are not hidden polynomial-time claims.

## 6. Removing the numerical count from bit complexity

Counting one negative-binomial draw as unit cost would be insufficient: its output can exceed 64-bit range. The arbitrary-integer backend therefore uses a finite-support rejection construction.

### 6.1 Dyadic envelope lemma

Let \(f\) be a unimodal probability mass on \(\{0,\ldots,T\}\), with known mode \(m\). Scale by \(f(m)\), writing \(g(k)=f(k)/f(m)\), so \(g(m)=1\). Partition each side of the mode into blocks of distances

\[
 [1,1], [2,3], [4,7],\ldots.
\]

On a block, use the value at its endpoint nearest the mode as a constant upper envelope. A block of length at most \(2^j\) is bounded by twice the mass of the preceding closer block. Summation gives total envelope mass at most \(3\sum g\). Only \(O(\log(T+1))\) blocks are needed.

Choose an integer \(b\) with \(2^{-b}(T+1)\ll\eta\). Obtain dyadic bounds

\[
 l_k\leq2^b g(k)\leq u_k,\qquad u_k-l_k\leq2.
\]

Choose a block with integer weight equal to its length times its upper height, a uniform integer within that block, and accept using the downward height \(l_k\). All discrete choices use integer random tickets, not floating cumulative probabilities. Conditional on acceptance, the mass is proportional to \(l_k\); its total loss from the target is at most \(2(T+1)2^{-b}\). Rounding also adds at most this amount to the envelope. Success probability remains greater than \(1/5\). Capping the number of proposals at \(O(\log\eta^{-1})\), with a fixed fallback, contributes a separately bounded TV error.

### 6.2 Scalar distributions

A binomial has finite support \([0,n]\), known mode \(\lfloor(n+1)p\rfloor\), and a log mass ratio computable from log-gamma and logarithms.

A negative binomial of shape \(r\) and success probability \(p\) has mean \(r(1-p)/p\) and mode \(\max(0,\lfloor(r-1)(1-p)/p\rfloor)\). Truncate at

\[
 T=\left\lceil\frac{4r(1-p)}{p\eta}\right\rceil.
\]

Markov's inequality bounds the removed upper tail by \(\eta/4\). A Poisson law is treated identically with mean equal to its rate and mode its integer part. The remaining dyadic-rounding and attempt-cap errors fit within the rest of the scalar TV budget.

No factorial of an astronomically large integer is formed. Log-gamma mass ratios suffice. These can be enclosed in bit-polynomial work: shift small positive arguments to a size proportional to the requested precision, use Stirling's expansion with its signed next-term remainder bound, and evaluate logarithms with range reduction and convergent series. Bernoulli coefficients have polynomial encoding cost in the number of retained terms. Large arguments increase required working precision for cancellation by their binary length, not by their numerical value. Exponentials below the dyadic grid can be bounded by one grid cell instead of expanded to their full exponent.

The supplied implementation uses `mpmath.iv` for these enclosures. That is a numerical software dependency, not a formally verified kernel. Its documentation explicitly warns that interval support is experimental [8]. The program refines intervals until their scaled width is at most two units and raises an error if this fails. The tests check 740 returned enclosures against exact rational mass ratios. These checks are useful but not a universal certification of the library.

### 6.3 Graph-wide bound

There are at most

\[
 S_{\rm calls}=1+d+\sum_{v=0}^{d-1}(2m-v)^2=O(m^3)
\]

scalar calls in the general ghost-vertex construction, where \(d=2|U|\). Assign each a TV budget \(\varepsilon/S_{\rm calls}\). A stepwise coupling/union bound gives total scalar error at most \(\varepsilon\), even though later scalar parameters depend on earlier random counts.

Rational Schur entries and routing probabilities are ratios of determinants and rational products with polynomial encoding length. Let \(P\) bound the bit lengths of their inverse positive pivots. Starting with \(O(h)\) boundary matching edges and the explicitly truncated Poisson source count, a reverse stage increases the logarithm of the largest count by at most

\[
 O(\log m+P+\log\varepsilon^{-1}).
\]

There are \(O(m)\) stages. Consequently every count produced by the truncated construction has polynomial binary length in the original matrix encoding, \(m\), \(\log(h+1)\) and \(\log\varepsilon^{-1}\). No polynomial numerical-energy promise is needed.

With exact matching DP, bit complexity is

\[
 R_h\,\operatorname{poly}(L,m,h,\log\varepsilon^{-1}),
\tag{6.1}
\]

where \(L\) is the complete rational input length. Without heralds, \(R_h=1\), so this is bit-polynomial in the encoded Gaussian instance and accuracy. There is no numerical \(E\) or \(\Pr(H=h)^{-1}\) factor. Exact uniform-integer generation has expected polynomial bit cost; bounding its rejection attempts also yields a worst-case polynomial approximate sampler after charging the additional failure probability.

The mathematical finite-bit statement assumes valid scalar interval enclosures and unbiased independent bits. The tested seeded implementation uses a pseudorandom generator for reproducibility, and is not a formal proof of these software assumptions.

## 7. Actual resource requirements

Dense elimination requires \(O(m^3)\) rational arithmetic operations. The provided implementation stores every routing table and therefore uses \(O(m^3)\) rational entries, not \(O(m^2)\) storage. Each sample uses \(O(m^3)\) count updates/scalar variates plus its matching work. These operation counts do not make arbitrary-size integers unit-cost; Section 6 accounts for their bit lengths.

The method needs the kernel coefficients. It does not supply efficient experimental tomography. A synthetic instance with \(1-\rho(XK)\) of order \(10^{-40}\) needs correspondingly accurate input coefficients. Such benchmarks test the encoded mathematical interface, not the feasibility of obtaining those coefficients or preparing that energy in a laboratory.

The exact DP includes all \(h\) herald photons in its complexity. Binary encoding of an exponentially large herald count does not magically make the present DP polynomial. The polynomial extension below is polynomial in the **numerical** herald count \(h\), not merely \(\log h\).

## 8. What the OpenAI perfect-matching result supplies

The pinned OpenAI manuscript [6] states an FPRAS for perfect matchings in simple unweighted general graphs. It does not directly promise a compressed weighted or loop-hafnian interface. Those interfaces require reductions.

The source mechanisms examined here include the tree-bag/vertex-scaling architecture and the original signed cell identity and demand-encoding proof. In the latter, a rare guide-event mass \(p_X\) is retained in a weighted demand bound and cancels the \(1/p_X\) introduced by conditional Jensen. The proof does not lower-bound the rare probability. Its two-coordinate energy inequality is separately lifted to a replicated product chain. This source result is not re-proved, implemented or kernel-built in the present package.

### 8.1 Compact rational-weight gadget

For rational pair weights \(w_e\), clear denominators to obtain positive integers \(W_e=Dw_e\). Every perfect matching uses the same number of edges, so this only multiplies its weight by a common power of \(D\).

Construct a simple DAG with exactly \(W_e\) source-to-target paths and \(O(\log W_e)\) vertices. Reading the binary expansion, replace a count \(q\) by \(2q\) using two distinct intermediate routes; add one direct source edge for a one bit.

For each DAG vertex \(i\), create internal vertices \(L_i,R_i\) and an identity edge \(L_iR_i\). For each directed DAG edge \(i\to j\), add \(L_iR_j\). Connect the original graph edge's ports \(u,v\) to \(R_s,L_t\), respectively.

When neither port is matched into the gadget, acyclicity forces the unique identity matching internally. When both are matched into it, the internal alternating path follows one source-to-target DAG path, giving exactly \(W_e\) completions. Exactly one used port is impossible by parity. The gadget is simple, unweighted and has size polynomial in the binary weight length. Thus it does not expand an integer weight into that many parallel edges.

`matching_gadgets.py` implements this construction. Tests exhaust weights 1 through 127 in three boundary states and test 20 complete rationally weighted four-vertex reductions.

### 8.2 Singleton reduction

For a fixed number \(k\) of singleton tokens, add \(k\) labeled dummy vertices. Connect token \(i\) to each dummy with weight \(t_i\), keep all original pair weights, and put no edges among dummies. A perfect matching gives a pair/singleton configuration, with exactly \(k!\) dummy labelings. Hence

\[
 L_r(S,t)=\sum_{\substack{0\leq k\leq 2h\\k\equiv2h\pmod2}}
 \frac{Z_{\rm PM}(G_k)}{k!}.
\tag{8.1}
\]

All summands are nonnegative. Relative approximations therefore sum safely. Deterministic matching-existence checks on the support graphs detect zero partition functions; an approximate counter returning zero on a bad random tape is not used as a proof of impossibility.

### 8.3 Sampling and composed guarantee

Self-reduction evaluates the positive branches of (5.2) with approximate partition functions and samples a branch proportional to those estimates. Allocate relative error \(O(\varepsilon/(h+1))\) per step and enough confidence to cover the polynomial number of graph-counter calls. A coupling bounds the accumulated matching error by its allocated portion of \(\varepsilon\).

**Composition theorem, using the counting guarantee stated in [6].** On the stated positive Gaussian input class, there is a randomized \(\varepsilon\)-TV sampler for arbitrary nonzero photon heralds in

\[
 \operatorname{poly}(L,m,h,\varepsilon^{-1})
\]

bit time, without a numerical-energy promise and without inverse herald probability. This is a consequence of the imported counting theorem plus the explicit reductions and reconstruction proved here. It is not a claim that a practical large-herald FPRAS was executed. The tested backend remains the exact DP of (5.2).

## 9. Computational results from this run

All raw results, seeds, instance definitions and software versions are in `results/` and `validate.py`. Timings are measurements in the available execution environment, not predictions for a user's machine. No comparison against the fastest existing Gaussian simulators was performed.

### 9.1 Distribution checks

Six pure/undisplaced fixtures were sampled 16,000 times each, including vacuum heralding, one- and two-photon heralding, two observed modes and a sparse two-mode squeezed state. Their PGFs were compared with independent photon-basis expansion of the original state, not only with the sampler's own Schur formula. The largest absolute empirical deviation was 2.18 estimated standard errors. All applicable parity checks passed, as did exact equality of the two counts in the two-mode squeezed fixture.

Four rational-backend fixtures were sampled 700 times each: displaced pure, displaced heralded, mixed displaced heralded, and thermal. The largest absolute deviation was 1.62 estimated standard errors. The declared per-draw scalar error budget was \(10^{-10}\), subject to the software assumptions in Section 6. Empirical standard errors do not verify such a small TV tolerance.

The displaced and mixed analytic PGFs also agreed with independent original-state Fock expansion to floating-point precision. An exact rational identity checked marginalization before versus after conditioning. Zero-probability heralds, vacuum, observing every mode and a zero-PGF endpoint were checked explicitly.

There were 740 exact rational comparisons of interval mass-ratio enclosures and 401 exact matching-gadget checks. These are finite tests, not substitutes for the proofs.

### 9.2 Brightness scaling of the fast backend

For eight modes, use \(B=(1-\delta)(I/2+\mathbf1\mathbf1^T/16)\). Each row has the same sum. There were 400 samples per row below.

| Approximate mean total photons | Median seconds/sample |
|---:|---:|
| \(5.02\times10^2\) | 0.000461 |
| \(5.00\times10^5\) | 0.000516 |
| \(5.00\times10^8\) | 0.000514 |
| \(5.00\times10^{11}\) | 0.000482 |

The near-flat count dependence is consistent with the algorithm's operation count. It is not a certification of floating-point accuracy near a singularity, and not an optimized-frontier benchmark. The arbitrary-precision backend is the appropriate interface when input/pivot precision becomes critical.

### 9.3 Combined rare-and-bright stress case

Use three physical modes, with

\[
 \delta=10^{-40},\quad \lambda=10^{-60},\qquad
 B=\begin{pmatrix}
 0&\lambda/2&\lambda/3\\
 \lambda/2&3(1-\delta)/5&2(1-\delta)/5\\
 \lambda/3&2(1-\delta)/5&3(1-\delta)/5
 \end{pmatrix}.
\]

Condition on exactly four photons in the first mode. The computed herald probability is

\[
 \Pr(N_0=4)\simeq3.97455145393\times10^{-323}.
\]

The exact rational first moments are each approximately \(2.25\times10^{40}\). Seed 76219 produced the two output counts

```
12811628801419660685241082648743635866366
12811628801419660685369109401746084457836
```

Setup took about 0.00113 seconds and sampling about 0.702 seconds. The exact matching DP visited 15 states; the construction has at most 91 scalar calls. The requested total scalar TV budget was \(10^{-12}\).

This is not a factorized rare-event padding trick: the weakly coupled observed mode prepares a fourth-degree photon-added polynomial on the correlated unobserved Gaussian state. Both the non-Gaussian conditioning and the large output populations are handled by the reconstruction.

A separate exact-rational test reduced the herald couplings from order \(10^{-2}\) to \(10^{-100}\). The conditional PGF was unchanged exactly, while the event log-probability changed from about \(-17.50\) to \(-801.50\) in base 10. This scaling cancellation follows from the homogeneous degree of the herald amplitude, not from ignoring its coupling to the output.

These are synthetic numerical stress cases. They are not demonstrations of preparing \(10^{40}\) photons, measuring \(10^{-60}\) couplings, or increasing a laboratory herald success probability.

## 10. Provenance, significance and limits

Astra N38 already gives a positive loop-soup representation of pure nonnegative GBS and a walk-expansion algorithm polynomial in the numerical mean energy. It explicitly distinguishes that promise from merely encoding a large energy in binary. N42 already reports rare positive-Gaussian heralding without inverse success probability, still with a numerical-energy dependence and a dependency on the matching result. Those are the appropriate archive comparisons, not a claim that rare-event conditioning originated here.

The present construction removes the need to materialize walks or photons and supplies a complete executable alternative, including coherent source paths and exact-rational input handling. This changes an input-representation barrier, rather than just a constant in a per-photon loop.

Earlier quantum-inspired graph samplers also exploit nonnegativity [7]. In particular, a hafnian-weighted proxy is not the same target law as the squared-hafnian photon distribution. The present formula targets the latter full count law. This does not imply that Gaussian-inspired graph optimization is superior to ordinary optimization methods, nor does it solve arbitrary difficult graph problems in polynomial time.

The limits matter. Nonnegativity excludes generic interference phases. Many-body Hilbert spaces are not generally reduced to these small matrices. The output omits arrival ordering and loop topology. The large-herald polynomial extension has not been made into a practical FPRAS implementation. The scalar arithmetic library has not been formally certified. Priority for the complete composition has not been established against all loop-soup, permanental-process and kinetic-sampling literature.

**Assessment:** this run produced an operational mathematical method and working software, with an explicit representation improvement over the accessed Astra algorithms. It did not establish a historic-scale 10/10 scientific or technological breakthrough. A claim of that magnitude is not supported by the present evidence.

## References and accessed source revisions

[1] Astra research archive, commit `54b1614a6446ca9f41ed18f44eef1cb6a85e5a7f`. Navigation began with `00_START_HERE.txt`. N38 original construction was read through `web/pages/d-33f172c4dc41f1b1.html`, from the P-package evidence directory. N42 was available as its review record; its absent full packet was not treated as a supplied executable proof.

https://github.com/harjassand/astra-research-knowledge/tree/54b1614a6446ca9f41ed18f44eef1cb6a85e5a7f

[2] C. S. Hamilton et al., *Gaussian Boson Sampling*, Phys. Rev. Lett. 119, 170501 (2017).

https://arxiv.org/abs/1612.01199

[3] M. Athènes and V. V. Bulatov, *Path Factorization Approach to Stochastic Simulations*, Phys. Rev. Lett. 113, 230601 (2014). Original path-elimination and count-reconstruction mechanism accessed in HTML.

https://arxiv.org/html/1403.2282v2

[4] Y. Le Jan, *Markov Paths, Loops and Fields*. The archive's original proof explicitly identifies the double-cover loop-soup ancestry.

https://www.imo.universite-paris-saclay.fr/~lejan/pdfs/stfl1.pdf

[5] X. Li and Y. Zheng, *A note on alpha-permanent and loop soup*, Electronic Communications in Probability 28 (2023). The general determinant/occupation relation is distinguished from their special forest formulas.

https://arxiv.org/html/2212.06095v2

[6] OpenAI, *A Fully Polynomial Randomized Approximation Scheme for Perfect Matchings in General Graphs*, dated 23 September 2026. Accessed at repository commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`. Read the original TeX's theorem/architecture (lines 1–405) and cell/demand energy proof (lines 1800–2150). The product-replica theorem is an imported dependency; no complete independent audit or Lean build was performed here.

https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/build/main.tex

[7] C. Oh, B. Fefferman, L. Jiang and N. Quesada, *Quantum-Inspired Classical Algorithm for Graph Problems by Gaussian Boson Sampling*, PRX Quantum 5, 020341 (2024).

https://journals.aps.org/prxquantum/abstract/10.1103/PRXQuantum.5.020341

[8] mpmath documentation, interval arithmetic contexts. The installed test version was 1.3.0. The contemporary documentation explicitly warns that interval support remains experimental.

https://mpmath.readthedocs.io/en/latest/contexts.html

[9] *Classical Algorithms for Function Computation in Gaussian Boson Sampling*, arXiv:2609.38882v1. Inspected as a contemporary comparison; estimating observables is not silently equated with sampling the complete conditional law.

https://arxiv.org/html/2609.38882v1
