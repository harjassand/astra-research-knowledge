# Count-compressed Gaussian photon sampler

This package samples photon **counts**, without iterating over photons or accepting/rejecting complete experiments to obtain a rare herald. It is a research prototype for explicitly supplied **nonnegative real Gaussian Bargmann kernels**, not a general quantum simulator.

Read `RESEARCH_NOTE.md` for the input contract, proofs, complexity, inherited mechanisms, limitations and source revisions.

## Installation

Python 3.10 or newer is required. The recorded tests used Python 3.13.5, NumPy 2.3.5 and mpmath 1.3.0.

```sh
python -m pip install -r requirements.txt
python example.py
python validate.py
```

Run a subset of the tests with `python validate.py --part algebra`, `--part fast`, `--part rational`, `--part independent`, `--part stress` or `--part scaling`.

## Arbitrary-integer, rational-input backend

```python
from fractions import Fraction as F
import random
from rational_gaussian import RationalGaussian

model = RationalGaussian.from_pure(
    B=[[F(1, 10), F(1, 5)], [F(1, 5), F(1, 8)]],
    g=[F(1, 3), F(1, 4)],
    herald_modes=[0],
    herald_counts=[2],
)
counts = model.sample(random.Random(42), tolerance=F(1, 10**10))
print(counts)  # counts for unobserved modes, in original mode order
```

Use integers, decimal strings or `Fraction` values. Floats are intentionally refused by the rational backend. `g` is the linear coefficient of the pure Bargmann vector, not in general the physical coherent mean amplitude; for real inputs that mean is `(I-B)^(-1)g`.

`pure_kernel` constructs a physical pure input. `trace_modes` generates a physical mixed kernel by tracing part of an existing physical state. `RationalGaussian(K, ell, ...)` also accepts a general kernel directly, but requires the caller to supply a physicality guarantee for a quantum interpretation.

The tolerance budgets support truncation, dyadic rounding and finite rejection attempts. The corresponding TV statement assumes valid interval enclosures and unbiased random bits. The program uses mpmath's experimental interval implementation; it is not a formally certified numerical library. Seeded examples use a pseudorandom generator. `random.SystemRandom()` is also accepted.

## Fast backend

```python
import numpy as np
from prototype import PositiveGBS

model = PositiveGBS(np.array([[0.1, 0.2], [0.2, 0.125]]), [0], [2])
samples = model.sample_many(1000, seed=42)
```

This backend covers pure, zero-displacement inputs only. It uses binary64 arithmetic and signed 64-bit counts. No finite-precision TV guarantee is assigned to it. Use the rational backend for extremely close-to-critical kernels or counts outside this range.

## Package contents

`rational_gaussian.py`: general nonnegative kernel, herald matching, Schur reconstruction, exact conditional means, and mixed-state marginalization.

`bigint_sampler.py`: scalar binomial, negative-binomial and Poisson generation using dyadic rejection envelopes and arbitrary-size integers.

`prototype.py`: fast NumPy implementation for pure, undisplaced inputs.

`matching_gadgets.py`: explicit rational-weight to simple unweighted graph reduction, with a small exact diagnostic counter. **It does not implement an FPRAS.**

`validate.py` and `results/*.json`: reproducible instances, seeds, algebraic checks and measured experiments.

`RESEARCH_NOTE.md`: derivations, the finite-bit argument, provenance and distinctions between implemented and theorem-level backends.

## Resource and scope limits

The matrix dimension is `2*m+1`, not the number of photons. Preprocessing and the number of scalar calls are cubic in the mode count. The current implementation also stores cubic-size routing tables.

The exact matching dynamic program has at most `product((h_i+1)**2)` states. Large or many herald counts can therefore exceed memory or Python's recursion depth; no polynomial-herald implementation is claimed. The theorem-level extension uses the perfect-matching result stated in the pinned OpenAI manuscript and explicit reductions, not a counter hidden inside this software.

Kernel calibration, physical preparation, generic signed/complex phases and time-resolved photon records are outside the package. The very large-count tests are mathematical stress cases, not physical device demonstrations.
