# NPT bound-entanglement investigation — no complete resolution

Date: 9 October 2026 (Australia/Brisbane).

**Status: the foundational target was not resolved.** This record contains a precise target, a restricted reconstructed argument, an exact counterexample to an attempted sufficient certificate, and a source/verification ledger. None is represented as completion of the foundational objective. No historical novelty, journal review, or proof-assistant verification is claimed.

## 1. Pinned research capital and reading scope

- Astra: `646c643d69a6f289e73d424934c9e5789ead0e43`.
- OpenAI math: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.
- Additional three-copy candidate repository: `ipitchford/three-copy-werner-undistillability`, revision `66cd2f931abb1a2f24e18e1b86e280401be9a5e8`.

The investigation began with Astra's `00_START_HERE.txt`, then current priorities, topic indices and relevant scoped cards. Repository pins identify evidence; they do not certify mathematics. OpenAI's correction/withdrawal history was inspected, and withdrawn Hodge dependencies were not used. The source reading was selective, not an audit of every manuscript in the release.

Original mathematical material examined included the OpenAI zero-secret-key manuscript's representation and full four-effect coherence proof; the automata manuscript's exponential rank-loss argument; the July two-copy Werner partial-trace proofs; Wu–Zou's exterior-square and product-reference arguments; and the written reduction in the October three-copy candidate. The October candidate's full rational certificate was **not replayed**. The source manifest supplies exact locators and more detailed coverage.

## 2. Fixed foundational target T

T is the existential statement that a finite-dimensional bipartite state can have negative partial transpose while remaining undistillable:

\[
\exists d\ge3\ \exists \rho\in M_d(\mathbb C)\otimes M_d(\mathbb C):
\quad \rho\succeq0,\quad \operatorname{Tr}\rho=1,\quad \rho^\Gamma\not\succeq0,
\]
\[
\forall n\ge1\ \forall\psi\text{ with }\operatorname{SR}_{A^n:B^n}(\psi)\le2:
\qquad \langle\psi,(\rho^\Gamma)^{\otimes n}\psi\rangle\ge0.
\]

The rank-two distillation criterion and the Werner partial-trace formulation are imported established formulations; see Costa Rico and the references in the July 2026 papers. The investigation did not alter T to a finite-copy assertion.

A candidate strategy used

\[
\rho_*=(2I_9-F_3)/15,
\]

where \(F_3(x\otimes y)=y\otimes x\). The stronger statement that this particular state is undistillable would prove T. Conversely, finding it distillable would reject this candidate, **not** disprove existential T.

### Elementary checks and the exact remaining obligation

The symmetric and antisymmetric eigenspaces of \(F_3\) have dimensions six and three. Thus \(\rho_*\) has eigenvalues \(1/15\) and \(3/15\), is positive, and has trace one. Set \(\Omega=\sum_{j=0}^2 e_j\otimes e_j\). Since \(F_3^\Gamma=\Omega\Omega^*\),

\[
\rho_*^\Gamma=(2/15)(I-\tfrac12\Omega\Omega^*),
\qquad \rho_*^\Gamma\Omega=-\Omega/15.
\]

It is therefore NPT, without any imported conjecture.

For \(C\in M_{3^n}(\mathbb C)\), use row/column tensor factors indexed by the resource copies, and let \(\operatorname{Tr}_S C\) contract corresponding row and column indices on the subset \(S\). Define

\[
q_n(C)=\sum_{S\subseteq[n]}(-1/2)^{|S|}\|\operatorname{Tr}_S C\|_F^2.
\]

Vectorize \(C\) as \(\psi_C=\sum_{x,y} C_{xy}e_x\otimes e_y\). Its Schmidt rank is \(\operatorname{rank}C\). Expanding the tensor product and contracting each \(\Omega\Omega^*\) gives exactly

\[
\langle\psi_C,(\rho_*^\Gamma)^{\otimes n}\psi_C\rangle=(2/15)^n q_n(C).
\]

The unproved candidate obligation is therefore

\[
\boxed{\quad q_n(C)\ge0\quad\text{for every }n\ge1\text{ and every complex }C\text{ of rank at most two}.\quad}
\]

At one copy, \(|\operatorname{Tr}C|\le\|C\|_1\le\sqrt{2}\|C\|_F\) proves the inequality. The July two-copy theorem supplies \(n=2\). Neither statement supplies an induction. Partial trace need not preserve matrix rank: for example, the partial trace of a rank-one maximally entangled projector is a full-rank scalar identity.

## 3. What the recent sources do and do not provide

Fraser–Huber–Pozsgay–Vona and Bharti–Gajjala–Haug report sharp two-copy partial-trace inequalities. Their relevant arguments were examined, including the balanced rank-one decomposition and the auxiliary-qubit formulation. No all-copy theorem is imported from those papers.

Wu–Zou prove three-copy inequalities on the normal rank-two sector and specified nonnormal support sectors. Their nuclear-norm/exterior-square estimates and product-reference Schur argument were examined. Their normal-sector conclusion does not cover arbitrary complex rank-two matrices.

The 4 October anonymous candidate at the third pin claims unrestricted three-copy qutrit undistillability. Its written proof constructs matched moments of types (3,1), (2,2), (1,3), uses whole-replica partial transposes and a coupled quartic Gram map, and reduces to a 2,374-dimensional rational source space. A displayed identity with 716 positive multipliers is the decisive certificate. The written physical lifting and the finite source-space structure were read; the stored rational matrices and all 716 positivity checks were not independently replayed here. The repository explicitly claims neither four-copy nor all-copy undistillability. The earlier access failure to its Zenodo proof was subsequently resolved by finding its linked GitHub manuscript.

The OpenAI zero-key construction uses states of the form \((L\otimes M)(\chi\chi^*)\), with both local maps completely positive and completely copositive. Such a state is PPT: transposing Bob's output gives \((L\otimes(T\circ M))(\chi\chi^*)\succeq0\). Its tensor-closed coherence argument therefore does not itself construct an NPT state. No transfer removing that PPT condition was proved.

## 4. Restricted reconstruction: a product ray in one support plane

This section preserves a usable restriction of the Schur argument, **not a resolution of T**. The proof mechanism comes from Wu–Zou's product-reference calculation. The tensor calculation below applies to any finite number of physical sites. Priority of this formulation was not determined.

Let \(H=\bigotimes_{i=1}^n\mathbb C^{d_i}\), \(d_i\ge2\), and define

\[
\lambda_i(X)=\operatorname{Tr}(X)I_{d_i}-\tfrac12X,
\qquad \Phi=\bigotimes_i\lambda_i.
\]

**Restricted statement.** The corresponding endpoint form is nonnegative on rank-at-most-two \(C\) whenever \(\operatorname{ran}C\) or \(\operatorname{ran}C^*\) contains a nonzero fully product vector.

### 4.1 Local co-Choi bounds

Normalize a product reference \(u=\bigotimes_i u_i\). By local unitary covariance it suffices to use \(u_i=e_0\). For a single local dimension \(d\), write

\[
A=\lambda(e_0e_0^*)=I-\tfrac12P,\quad P=e_0e_0^*,\quad A^{-1}=I+P,
\]
\[
\ell_a=\lambda(e_ae_0^*)=\delta_{a0}I-\tfrac12e_ae_0^*,
\qquad M(E_{ab})=\ell_aA^{-1}\ell_b^*.
\]

Use the input-first co-Choi convention

\[
\widehat J(\Psi)=\sum_{a,b}E_{ab}\otimes\Psi(E_{ba}).
\]

Put \(R=\widehat J(\lambda)=I-\tfrac12F_d\), \(S=\widehat J(M)\). The following invariant orthogonal pieces give every entry needed to check the inequality \(-R\preceq S\preceq R\).

On \(\mathbb C(e_0\otimes e_0)\), both operators equal \(1/2\). On each span of \(e_0\otimes e_a,e_a\otimes e_0\), \(a>0\),

\[
R=\begin{pmatrix}1&-1/2\\-1/2&1\end{pmatrix},\qquad
S=\begin{pmatrix}1&-1/2\\-1/2&0\end{pmatrix}.
\]

Here \(R-S=\operatorname{diag}(0,1)\) and \(R+S=\begin{pmatrix}2&-1\\-1&1\end{pmatrix}\), both positive semidefinite. On \(e_0^\perp\otimes e_0^\perp\),

\[
R=I-\tfrac12F_{d-1},\quad S=\tfrac12F_{d-1},\quad
R-S=I-F_{d-1}\succeq0,\quad R+S=I\succeq0.
\]

This proves the local bounds directly.

### 4.2 Tensorization for a fully product reference

For the full product reference, define \(A=\Phi(uu^*)\), \(\ell_a=\Phi(e_au^*)\), and the same \(M_u(E_{ab})=\ell_aA^{-1}\ell_b^*\). These objects factor across sites. After the canonical permutation grouping input and output slots, their co-Choi matrices are \(R=\bigotimes_i R_i\), \(S=\bigotimes_i S_i\).

Each \(R_i\) is positive definite. The Hermitian matrices \(T_i=R_i^{-1/2}S_iR_i^{-1/2}\) have spectra in \([-1,1]\). Consequently \(\bigotimes_iT_i\preceq I\), and congruence gives \(R-S\succeq0\). Thus \(\Phi-M_u\) is completely copositive and, in particular, positive.

For arbitrary \(z\in H\), write \(\ell_z=\Phi(zu^*)\). Positivity gives

\[
\Phi(zz^*)-\ell_zA^{-1}\ell_z^*\succeq0.
\]

Since \(A\succ0\), the Schur complement implies

\[
\begin{pmatrix}
\Phi(uu^*)&\Phi(uz^*)\\
\Phi(zu^*)&\Phi(zz^*)
\end{pmatrix}\succeq0.
\]

These are precisely the two-dimensional input compressions of the Choi operator, with conjugation of the spanning vectors in the input-first convention. Complex conjugation preserves product vectors. The endpoint quadratic form is therefore nonnegative when its column space contains a product ray. The row-space version follows from \(q_n(C^*)=q_n(C)\). This completes the restricted proof.

A general two-dimensional subspace of a multipartite tensor product need not contain a product vector. No decomposition extending this argument to every allowed support plane was proved.

## 5. Exact failure of the entangled-reference tensor certificate

The tempting stronger assertion is that the preceding co-Choi domination remains valid for arbitrary, internally entangled references. It is false. This section supplies an exact finite counterexample to that **sufficient certificate**, not to the foundational target, and not to the valid product-reference argument.

Work first on \(H=\mathbb C^2\otimes\mathbb C^2\), with

\[
\Phi=(\operatorname{Tr}(\cdot)I_2-\tfrac12\operatorname{id})^{\otimes2},
\qquad u=(1,0,0,1)^T.
\]

The unnormalized reference causes no difficulty: scaling \(u\) by a nonzero scalar leaves \(M_u\) unchanged. Direct contraction gives

\[
A=\Phi(uu^*)=I_4+\tfrac14uu^*,\qquad A^{-1}=I_4-\tfrac16uu^*.
\]

Set \(\ell_a=\Phi(e_au^*)\), \(M_u(E_{ab})=\ell_aA^{-1}\ell_b^*\),

\[
R=\widehat J(\Phi),\qquad S=\widehat J(M_u).
\]

In input-first lexicographic order, choose

\[
v=(3,0,0,1,\ 0,0,2,0,\ 0,2,0,0,\ 1,0,0,3)^T.
\]

Exact multiplication yields

\[
Rv=(3/4,0,0,-3/4,\ 0,0,3/2,0,\ 0,3/2,0,0,\ -3/4,0,0,3/4)^T,
\qquad Sv=-\tfrac{11}{9}Rv.
\]

In particular,

\[
v^*Rv=9,\qquad v^*Sv=-11,\qquad v^*(R+S)v=-2.
\]

Thus the lower bound \(-R\preceq S\) already fails for this entangled reference.

Now pass to four physical qubit sites by using \(\Phi' = \Phi\otimes\Phi\) and reference \(u'=u\otimes u\). Since \(A'=A\otimes A\), the defining formula gives \(M_{u'}=M_u\otimes M_u\). After the canonical factor permutation, the relevant co-Choi matrices are \(R'=R\otimes R\) and \(S'=S\otimes S\). Hence

\[
(v\otimes v)^*(R'-S')(v\otimes v)
=9^2-(-11)^2=-40<0.
\]

The normalized value is \(-40/28^2=-5/98\). Therefore even the upper domination \(R'\succeq S'\) fails at four physical sites. This is an exact rational disproof of the proposed arbitrary-reference certificate.

### Why this is not a Werner counterexample

The local qubit map \(\lambda_2\) is completely positive: its ordinary Choi matrix is \(I_4-\tfrac12\Omega_2\Omega_2^*\succeq0\). Therefore all its tensor powers are completely positive. The actual rank-two positivity condition is true in this qubit example. The negative co-Choi certificate exposes a condition stronger than what positivity requires; it cannot be promoted into a distillation claim.

The standard-library verifier checks all displayed equalities with `fractions.Fraction`, including under `python -O`. A separate SymPy calculation gave the same rational witness. These computations check a finite algebraic counterexample; they are not a formalization or an independent specialist review of the foundational problem.

## 6. Other screened directions and numerical scope

The automata source proves a state lower bound through matching-monoid rank loss and idempotent corners. The argument examined did not supply a polynomial bound on lengths of hard input words. Its alphabet-independent state conclusion was not promoted to an L-versus-NL separation.

Astra's existing commutative-PIT and Bernoulli cards retain unproved transfer steps. Those records were not treated as completed PIT or unequal-entropy conjugacy theorems. The characteristic-zero rectangular rank example already rules out a weak proposed representation transfer. No alternate foundational target was declared solved.

Floating-point rank-constrained Werner probes and local-filter experiments were exploratory only. Small nonnegative values do not prove a universal inequality. Saved numerical matrices are not exact counterexamples and have not been assigned historical significance. The raw probe scripts are kept in the archive solely for reproducibility of exploration; the exact method-counterexample verifier is the only packaged pass/fail result being asserted here.

## 7. Final status

There is no proof in this record of the boxed all-copy inequality, no other fixed NPT state certified undistillable for every copy number, and no proof that every NPT state is distillable. Consequently neither T nor its negation has been established. The foundational research objective remains uncompleted.
