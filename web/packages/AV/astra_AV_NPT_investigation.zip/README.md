# Research record: foundational target not resolved

The target was the existence of a finite-dimensional NPT bound-entangled state.
Neither that theorem nor its negation was proved in this investigation.

Start with `INVESTIGATION.md`. It fixes the target, records source limitations,
proves a restricted product-reference statement, and gives a finite exact
counterexample to a stronger attempted proof certificate. These are research
capital, not a completed foundational discovery. Novelty has not been certified.

## Exact audit

Only Python's standard library is required:

```sh
python verify_exact_schur_certificate_failure.py --output my_receipt.json
python -O verify_exact_schur_certificate_failure.py
```

Expected key values are `v_R_v = 9`, `v_S_v = -11`, and
`tensor_square_expectation = -40`. These establish the failure of one sufficient
co-Choi domination certificate. They do not establish Werner distillability,
NPT bound entanglement, or failure of the valid product-reference argument.
Verification checks do not disappear under Python's `-O` option.

`exact_audit_receipt.json` is the receipt from the executed standard-library
verification. `exact_schur_audit.py` contains the earlier separate SymPy
calculation, including a symbolic parameter diagnostic. Neither is a Lean or
other proof-assistant formalization.

## Files and evidentiary roles

- `INVESTIGATION.md`: mathematical record, proofs and failure scope.
- `SOURCE_MANIFEST.json`: repository pins, primary-source locations, reading scope and verification limits.
- `verify_exact_schur_certificate_failure.py`, `exact_audit_receipt.json`: exact finite certificate and replay receipt.
- `exact_schur_audit.py`: supplementary SymPy derivation.
- `werner_probe.py`, `schur_probe.py`, `filter_probe.py`: exploratory numerical scripts using NumPy. Their outputs are not proofs.
- `*.npy`: saved floating-point exploratory matrices. Filenames containing “counterexample” refer to auxiliary conjectured comparisons, not a counterexample to the foundational target. No exact claim relies on these arrays.
- `SHA256SUMS`: checksums for the included files other than the checksum file itself.

For numerical probes, NumPy is required; the supplementary symbolic script
requires SymPy. All scripts are local computations. The numerical scripts do
not download sources or authenticate the separate October three-copy candidate.
That candidate's complete rational certificate was not replayed here.
