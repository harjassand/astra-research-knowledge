# Mechanistic tests of growth-noise inheritance and material-time reversibility

**Date:** 9 October 2026  
**Status:** Research record. No foundational scientific discovery is established. No claim of historical priority is made for the mathematical constructions. No raw experimental trajectories were successfully downloaded or reanalysed.

## 1. Scientific question and outcome

The investigation compared opportunities in cell-growth variability, glass aging, microdroplet redox chemistry, and strange-metal scattering. Detailed derivation concentrated on the first two. The aim was a causal explanation of an actual observation, not a new fit.

The cell-growth investigation did not identify a biochemical source. It produced an explicit counterexample showing that three coarse signatures—continuity at division, age-independent variance, and a generation-scale memory—do not alone identify when stochastic innovations enter a cell. A simple two-stage biochemical response was examined first; a broader response construction then exposed the insufficiency of those signatures. Neither construction is established as the mechanism in cells.

The glass investigation produced an exact measurement-level symmetry and a dissipative physical countermodel. These do not explain the microscopic evolution of a glass or establish that the optical mechanism applies to the published experiments. They therefore do not resolve the glass-aging problem.

These are investigative results, not the requested historic breakthrough.

## 2. Empirical anchors and their limitations

Levien and colleagues report 24 L1210 cell lineages, 235 full cycles, a mean generation duration of 10.2 hours, and a fluctuation relaxation time displayed as 5.4 ± 3.3 hours across lineages. Their analysis supports predominantly continuous rather than division-associated growth noise. The paper already discusses high abundance or controlled partitioning of limiting components. These observations and interpretations are published results, not findings of this investigation. [1]

A June 2026 preprint by Holtzman, Sheinman, and Amir already develops separation of continuous, division-associated, and lineage noise. Only its accessible abstract/metadata were examined here; its complete argument was not reviewed. [2]

The glass study reports stationary, reversible light-intensity fluctuations after material-time transformation, including chemically aging samples. It also studies simulation energy fluctuations. Its underlying large experimental records were not obtained here. [3]

Crucial distinctions:

* A fitted exponential relaxation time is not necessarily the integral of the normalized autocovariance.
* Across-lineage standard deviation is not a confidence interval on one common parameter.
* Matching a few published summary statistics is not a fit to the full trajectories.
* Absence of a detected jump is not a universal bound on hidden perturbations.

## 3. First cell mechanism: delayed transmission of division perturbations

Consider fluctuations about a balanced-growth state. Let an unobserved biochemical coordinate u affect the observed growth-rate fluctuation x:

\[
\dot u=-a u,\qquad \dot x=c u-bx,\qquad a,b>0.
\]

At the division times nT, suppose

\[
u(nT^+)=u(nT^-)+\eta_n,\qquad x(nT^+)=x(nT^-),
\]

where the independent perturbations have mean zero and variance sigma_eta^2. There is no stochastic forcing between divisions in this diagnostic model. Small, bounded perturbations can be used; Gaussianity is unnecessary for the second-moment calculations.

The observed impulse response to a unit perturbation in u is

\[
h(t)=\frac{c}{b-a}(e^{-at}-e^{-bt})\mathbf 1_{t\ge0}.
\]

At a=b its continuous limit is h(t)=ct exp(-at). In either case h(0)=0: division perturbs the hidden variable without an instantaneous jump in the measured growth rate.

In the steady periodically driven regime,

\[
x(t)=\sum_{n\in\mathbb Z}\eta_n h(t-nT).
\]

For phase theta in [0,T),

\[
V(\theta)=\sigma_\eta^2\sum_{k\ge0}h(\theta+kT)^2.
\]

For a != b, this gives

\[
V(\theta)=\frac{\sigma_\eta^2c^2}{(b-a)^2}
\left[
\frac{e^{-2a\theta}}{1-e^{-2aT}}
+\frac{e^{-2b\theta}}{1-e^{-2bT}}
-\frac{2e^{-(a+b)\theta}}{1-e^{-(a+b)T}}
\right].
\]

The covariance averaged uniformly over division phase is

\[
\bar C(s)=\frac{\sigma_\eta^2}{T}\int_0^\infty h(u)h(u+s)\,du,
\qquad s\ge0.
\]

This follows by expanding the covariance, retaining identical noise indices, and joining the integration intervals across all previous divisions. For the two-stage response,

\[
\rho(s)=\frac{\bar C(s)}{\bar C(0)}
=\frac{b e^{-as}-a e^{-bs}}{b-a}.
\]

Consequently,

\[
\tau_{\rm int}:=\int_0^\infty\rho(s)\,ds=\frac1a+\frac1b.
\]

In the equal-rate limit, rho(s)=(1+as)exp(-as), and tau_int=2/a.

### Numerical test of this family

For illustrative T=10.2 hours and chosen tau_int=5.4 hours, a scan over 301 logarithmically spaced rate ratios b/a between 1 and 1000 found its smallest phase-variance coefficient of variation at a=b:

* phase-variance coefficient of variation: **0.6764828**;
* minimum phase variance / phase mean: **0.1126093**;
* maximum phase variance / phase mean: **2.0697164**.

This is a numerical result within one response family, not a theorem that no biochemical network works, and not a statistical rejection using experimental trajectories. It shows that the most elementary delayed-response explanation has a substantial age-variation consequence that cannot be ignored.

## 4. A wider test: positive response kernels

Let h be causal, nonnegative, integrable and square-integrable. Retain periodic divisions and independent scalar perturbations. Then

\[
\tau_{\rm int}=
\frac{\left(\int_0^\infty h(u)\,du\right)^2}
     {2\int_0^\infty h(u)^2\,du}.
\]

The numerator identity follows by integrating h(u)h(u+s) over u,s>=0; this triangular integral is half the integral over the full positive quadrant.

Suppose the phase variance is exactly constant, with

\[
\sum_{k\ge0}h(\theta+kT)^2=S\quad (0\le\theta<T).
\]

Nonnegativity implies

\[
\sum_{k\ge0}h(\theta+kT)\ge\sqrt S.
\]

Integrating gives integral(h)>=T sqrt(S), whereas integral(h^2)=TS. Thus

\[
\boxed{\tau_{\rm int}\ge T/2.}
\]

This bound is a consequence of the stated pulse model. It is not a universal law for cells. Signed responses, multiple coupled innovations, random generation durations, feedback-dependent division times, or different conditioning require separate analysis. In particular, the empirical fitted relaxation time cannot simply be substituted for tau_int to claim a biological exclusion.

## 5. Explicit continuous counterexample with constant phase variance

The elementary two-stage failure does not prove that division-origin noise must cause age-dependent variance. For 0<delta<=T define

\[
h(t)=\begin{cases}
0,&t<0,\\
\sin(\pi t/(2\delta)),&0\le t<\delta,\\
1,&\delta\le t<T,\\
\cos(\pi(t-T)/(2\delta)),&T\le t\le T+\delta,\\
0,&t>T+\delta.
\end{cases}
\]

This kernel is continuous, not everywhere differentiable. For every phase theta in [0,T),

\[
\sum_{k\ge0}h(\theta+kT)^2=1.
\]

In the overlap interval this is sin^2+cos^2=1; outside it there is one unit plateau. Therefore

\[
V(\theta)=\sigma_\eta^2
\]

at every phase, although all random innovations occur at divisions. Since h(0)=0, x itself has no division jump. Direct integration gives

\[
\int h^2=T,\qquad
\int h=T+\delta(4/\pi-1),
\]

and hence

\[
\tau_{\rm int}=\frac{[T+\delta(4/\pi-1)]^2}{2T}.
\]

For T=10.2 hours and chosen tau_int=5.4 hours,

\[
\delta=\frac{\sqrt{2T\tau_{\rm int}}-T}{4/\pi-1}
=1.0822496831787702\ \mathrm{hours}.
\]

Numerical integration reproduces tau_int=5.4000000053 hours; the maximum phase-variance error on the test grid is 1.33e-15. These are implementation checks of an analytic construction, not experimental confirmation.

### Why this is not a biological explanation

The response was selected to demonstrate a mathematical possibility, not derived from measured chemical reactions. It also predicts constant growth fluctuation through the plateau of each cycle and concentrated changes during the transition. For the displayed parameters, a 15-minute increment has exactly zero variance for 86.94% of the cycle in this construction. That is an important additional signature, not a harmless detail. It has not been matched to the experimental within-cycle trajectories and should not be offered as their explanation.

A full test would examine phase-conditioned increments and covariance, with the experimental sampling gaps, growth-trend removal, variable cycle durations, and measurement model included. The construction neither proves the published analysis wrong nor establishes division partitioning as the actual noise source.

## 6. Glass-aging direction: an exact observation symmetry

Let E(t) be a zero-mean stationary proper complex Gaussian field. Proper means that its nonconjugated second moments vanish. For times t_1,...,t_m, write

\[
K_{ij}=\mathbb E[E(t_i)E(t_j)^*],\qquad I_i=|E(t_i)|^2.
\]

For a nonnegative diagonal matrix U,

\[
\mathbb E\exp[-\sum_i U_{ii}I_i]=\det(\mathbb I+KU)^{-1}.
\]

Time reversal replaces K by K^T because stationarity and Hermitian covariance give K(-t)=K(t)^*. But

\[
\det(\mathbb I+K^TU)
=\det(\mathbb I+UK)
=\det(\mathbb I+KU).
\]

The joint Laplace transforms, hence all finite-dimensional intensity distributions, are unchanged. Singular covariances follow by a regularization limit. Thus the intensity process is time-reversible under these assumptions.

The proof uses stationary Gaussian field statistics, not microscopic equilibrium. Gaussian field/intensity relations and their experimental tests are established optical theory; no novelty is claimed for that framework. [4,5]

A numerical test with a positive sum of two damped, oppositely rotating covariance kernels gave a forward/reversed Laplace-transform difference of 7.32e-20. A common phase rotation left 10,000 synthetic intensities unchanged to 5.33e-15.

### A physical dissipative example

For two position coordinates, both even under physical time reversal, consider an isothermal overdamped diffusion

\[
d\mathbf r=(-a\mathbf r+\omega J\mathbf r)dt+\sqrt{2D}\,d\mathbf W,
\qquad
J=\begin{pmatrix}0&-1\\1&0\end{pmatrix}.
\]

Here a,D>0 and the angular term is an externally maintained nonconservative force, not a magnetic Lorentz force. The stationary density is isotropic Gaussian with coordinate variance D/a, and its probability current is omega J r p. Its entropy-production rate is

\[
\frac{\dot S_{\rm tot}}{k_B}
=\int\frac{|\mathbf j|^2}{Dp}\,d^2r
=\frac{2\omega^2}{a}.
\]

Nevertheless, Itô's formula for I=|r|^2 gives

\[
dI=(4D-2aI)dt+\sqrt{8DI}\,dB.
\]

The angular drive disappears exactly from the whole radial process. At stationarity its one-dimensional current vanishes, although the full system dissipates. This example must not be used to assign that entropy formula to an optical detuning; the physical variables and their reversal must be specified separately.

### Extension to an actual relaxation protocol within this example

Start from an isotropic Gaussian with coordinate variance s_0 != D/a. The physical variance evolves as

\[
s(t)=D/a+(s_0-D/a)e^{-2at}.
\]

Set Y=I/s(t) and define

\[
\xi(t)=\int_0^tD/s(u)\,du
=\tfrac12\log\left[1+\frac{D}{a s_0}(e^{2at}-1)\right].
\]

A second application of Itô's formula gives

\[
dY=(4-2Y)d\xi+\sqrt{8Y}\,dB_\xi.
\]

Since Y(0) has its stationary chi-square distribution with two degrees of freedom, the normalized radial process is stationary and reversible in xi throughout the physical relaxation. The full instantaneous entropy production is

\[
\frac{\dot S_{\rm tot}(t)}{k_B}
=\frac{2s(t)}{D}
\left[(D/s(t)-a)^2+\omega^2\right],
\]

which is positive away from equilibrium, including radial relaxation with omega=0.

This is an exact calculation for a specified diffusion. It does not identify the material clock of a real glass. It illustrates why the physical observation map and its time-dependent normalization cannot be omitted from the inference.

## 7. What remains unestablished

For the cell candidate, no molecular implementation was derived from independent measurements. For the optical candidate, proper Gaussianity and field-level stationarity in the measured material time were not established for the experiments. The optical argument does not automatically explain the simulation-energy result, nor the microscopic origin of aging slowdown. Neither branch produced an independently validated new law of nature.

No claim is made that a historic discovery is impossible. This record says only what this investigation established and did not establish.

## 8. Reproduction and source controls

Run `python analysis.py` with NumPy and SciPy installed. It writes `results.json`, `theoretical_curves.csv`, and `phase_variance.csv`. All arrays and tests in these files are theoretical or synthetic. No experimental trajectory is included or silently substituted.

Repository revisions actually accessed:

* Astra: `779be19cab568565f4f6891f598c81274aca8529`.
* OpenAI math: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

Astra navigation began at `00_START_HERE.txt`. The N185 hidden-metastability card, status JSON, and the original proof excerpt in `web/pages/d-d8dac5da22a5dead.html` were read. The alternative evidence-object path returned 404. The construction appends a nearly inaccessible reversible trap, changing stationary entropy production without proportionately changing finite-path evidence. Its scope is a confidence-bound obstruction, not a discovery of a natural mechanism, and it is not a premise of the calculations above.

For OpenAI's diluted-spin-glass result, the released reasoning text was inspected, including marked Poisson perturbations, conditional multioverlap decorrelation, and the cavity comparison. The manuscript was not independently audited here. An equilibrium free-energy construction was not treated as an explanation of molecular glass-aging dynamics.

The L1210 CSV was located as `smr_data/traceupdated.csv` on the `published` ref, blob `ebd5efe490070995dcbd08f6ff8fe8f8c9044ed2`, reported size 12,534,116 bytes. Its bytes were not retrieved. The GitHub connector returned an empty large-file content field, then a size/format error; direct runtime network access was unavailable. The publisher's supplementary spreadsheet also could not be retrieved. No analysis depends on presumed contents of these inaccessible files.

## References

[1] E. Levien et al., *Stochasticity in mammalian cell growth rates drives cell-to-cell variability independently of cell size and divisions*, PNAS 123, e2516372123 (2026). DOI: 10.1073/pnas.2516372123. Article HTML and displayed figures 4–5 inspected.

[2] R. Holtzman, M. Sheinman, A. Amir, *Disentangling mechanisms of single-cell growth rate fluctuations* (2026 preprint). DOI: 10.64898/2026.06.07.730294. Accessible abstract and metadata only; full-text access failed.

[3] T. Böhmer et al., *Time reversibility during the ageing of materials*, Nature Physics 20, 637–645 (2024). DOI: 10.1038/s41567-023-02366-z; arXiv:2312.02395v2. HTML examined.

[4] D. Ferreira et al., *Connecting field and intensity correlations: The Siegert relation and how to test it*, American Journal of Physics 88, 831 (2020). DOI: 10.1119/10.0001630. Publisher abstract/metadata examined.

[5] *Field and intensity correlations: the Siegert relation from stars to quantum emitters*, European Physical Journal D 76, 246 (2022). DOI: 10.1140/epjd/s10053-022-00558-5. Publisher search result examined.
