# Exact reachability under self-coupled joins
## Tight stochastic cuts, finite synthesis, and entropy saturation

**Research date:** 9 October 2026.

**Status.** This note gives a complete finite-dimensional argument and accompanying exact-arithmetic tests. It is not externally reviewed or formally verified. The tight-cut characterization was derived during this investigation; its historical novelty has not been established. No historic-scale breakthrough, resolution of Frankl's conjecture, or resolution of the quantum information-combining conjecture is claimed. Classical stochastic transport, polymatroid optimization, and continuous Petri-net reachability are important predecessors, not inventions of this note.

## 1. The model

Let \(L\) be a nonempty finite join-semilattice, with \(m=|L|\). Thus the binary operation \(\vee\) is associative, commutative and idempotent. Write \(a\le b\) when \(a\vee b=b\). All joins in this note are **nonempty** joins; in particular, a bottom element cannot be generated for free.

A probability law \(r\) can undergo one **self-coupled join round** as follows. Choose any joint law of \((X,Y)\) with both marginals equal to \(r\), and replace \(r\) by the law of \(X\vee Y\). Independence is not required. Let \(\mathcal R_t(p)\) denote the laws attainable from \(p\) in \(t\) rounds, and let
\[
\mathcal R(p)=\bigcup_{t\ge0}\mathcal R_t(p).
\]
The diagonal coupling is an idle round, so \(\mathcal R_t(p)\subseteq\mathcal R_{t+1}(p)\).

An upper set \(U\subseteq L\) satisfies \(a\in U,\ a\le b\Rightarrow b\in U\). Define stochastic domination by
\[
p\preceq q\quad\Longleftrightarrow\quad p(U)\le q(U)\quad\text{for every upper set }U.
\]
When \(p\preceq q\), an upper set is **tight** if \(p(U)=q(U)\).

For a nonempty subset \(A\subseteq L\), write \(\langle A\rangle_\vee\) for its nonempty join closure; put \(\langle\varnothing\rangle_\vee=\varnothing\).

The input to the algorithmic statements is an explicit join table and complete rational probability vectors. No algorithm for acquiring an unknown law, implementing independent-copy quantum operations, or handling a succinct exponentially large state space is asserted.

## 2. Main theorem

**Theorem 1 (exact finite reachability).** For any probability laws \(p,q\) on \(L\), the following are equivalent.

1. \(q\in\mathcal R(p)\).
2. There are finitely many identically distributed random variables \(X_1,\ldots,X_N\), each with law \(p\), whose join has law \(q\). Arbitrary dependence is allowed.
3. \(p\preceq q\), and for every tight upper set \(U\),
   \[
   \operatorname{supp}(q)\cap U
   \subseteq
   \langle\operatorname{supp}(p)\cap U\rangle_\vee.
   \tag{1}
   \]
4. The monotone transportation polytope
   \[
   \mathcal T(p,q)=\left\{\pi\ge0:
   \sum_z\pi_{az}=p_a,\quad
   \sum_a\pi_{az}=q_z,\quad
   \pi_{az}=0\ \text{unless }a\le z\right\}
   \tag{2}
   \]
   is nonempty, and, for each \(z\) with \(q_z>0\),
   \[
   z=\bigvee A_z,\qquad
   A_z=\{a:\pi_{az}>0\text{ for some }\pi\in\mathcal T(p,q)\}.
   \tag{3}
   \]

In (3), an empty \(A_z\) fails the condition. Condition (1) is stronger than stochastic domination plus global support generation: **every stochastic-order equality face must preserve its own generating support**.

### 2.1 Finite monotone transport

We use the finite form of Strassen's coupling theorem [1], with the following elementary network proof. A monotone coupling implies stochastic domination because \(a\le z\) implies \(1_U(a)\le1_U(z)\).

Conversely, build a bipartite network with capacities \(p_a\) from the source to row \(a\), capacity 2 from row \(a\) to column \(z\) whenever \(a\le z\), and capacity \(q_z\) from column \(z\) to the sink. A cut of capacity below 1 cannot cut an order edge. If its source-side row set is \(A\), its source-side columns must contain \(\uparrow A\). Its capacity is therefore at least
\[
1-p(A)+q(\uparrow A)
\ge1-p(A)+p(\uparrow A)
\ge1.
\]
The max-flow/min-cut theorem gives a flow of value 1, which is (2). The same proof applies to equal-mass subprobabilities after scaling the capacities.

### 2.2 Which transport entries can be positive?

Suppose \(p\preceq q\), \(p_a>0\), \(q_z>0\), and \(a\le z\). Then
\[
\exists\pi\in\mathcal T(p,q):\pi_{az}>0
\quad\Longleftrightarrow\quad
\text{no tight upper set contains }z\text{ but excludes }a.
\tag{4}
\]

For necessity, every monotone coupling satisfies
\[
q(U)-p(U)=\sum_{a\notin U,\ z\in U}\pi_{az}.
\tag{5}
\]
A tight cut cannot carry a positive incoming transport entry.

For sufficiency, all upper sets separating \(a\) from \(z\) have strictly positive slack. There are only finitely many upper sets. Choose \(\epsilon>0\) no larger than \(p_a,q_z\) and all these positive slacks. Subtract \(\epsilon\) from \(p_a\) and \(q_z\). For an upper set, the stochastic-order slack decreases by \(\epsilon\) only when that set contains \(z\) and excludes \(a\); it is otherwise unchanged. The residual subprobabilities still satisfy stochastic domination. Transport them monotonically and add mass \(\epsilon\) at \((a,z)\). This proves (4).

Tight upper sets are closed under unions and intersections: the slack \(d(U)=q(U)-p(U)\) is nonnegative on upper sets and is modular, so \(d(U)=d(V)=0\) implies \(d(U\cap V)=d(U\cup V)=0\).

For each \(z\), let \(U_z\) be the intersection of all tight upper sets containing \(z\). This exists because \(L\) itself is tight. Formula (4) gives
\[
A_z=\operatorname{supp}(p)\cap U_z\cap\downarrow z.
\tag{6}
\]
Consequently, (1) implies (3): apply (1) to \(U_z\), and observe that every term in a join equal to \(z\) lies below \(z\). Conversely, (3) implies (1), because every source in \(A_z\) lies in every tight upper set containing \(z\).

### 2.3 Necessity of the generation condition

Suppose \(Z=X_1\vee\cdots\vee X_N\), with each \(X_i\sim p\) and \(Z\sim q\). Since \(X_i\le Z\), each joint law \((X_i,Z)\) belongs to \(\mathcal T(p,q)\). On \(\{Z=z\}\), every leaf therefore belongs to \(A_z\), and their join is \(z\). All members of \(A_z\) lie below \(z\), so \(\bigvee A_z=z\).

Equivalently, if \(U\) is tight, then \(1_U(X_i)\le1_U(Z)\) and their expectations are equal. Thus \(1_U(X_i)=1_U(Z)\) almost surely. Whenever the output is in \(U\), every leaf is in \(U\). This proves the intuitive content of (1).

### 2.4 A support-covering exchangeable coupling

Assume (3). Average finitely many feasible transports witnessing all the positive possibilities in (3), obtaining one \(\pi\in\mathcal T(p,q)\) with \(\pi_{az}>0\) for every \(a\in A_z\). For \(q_z>0\), put
\[
\kappa_z(a)=\frac{\pi_{az}}{q_z}.
\]
Select a nonempty generating subset \(B_z\subseteq A_z\) with \(\bigvee B_z=z\). Choose an integer \(N\) such that
\[
N\kappa_z(a)\ge1\quad(a\in B_z,\ q_z>0).
\tag{7}
\]
This is possible because the collection is finite and all selected probabilities are positive.

Here is an explicit conditional coupling. Write \(b_a=1_{a\in B_z}\), \(k=|B_z|\), and \(d=N-k\). If \(d=0\), (7) forces \(N\kappa_z=b\); use that deterministic count vector. If \(d>0\), define
\[
w_a=\frac{N\kappa_z(a)-b_a}{d}.
\]
These are nonnegative and sum to one. With probability \(w_a\), use the integer count vector
\[
b+d e_a.
\tag{8}
\]
Then uniformly permute the resulting multiset of \(N\) symbols. Every coordinate has marginal \(\kappa_z\), since the expected count vector is \(N\kappa_z\). Every realized tuple contains \(B_z\), and all its other letters lie below \(z\), so its join is exactly \(z\).

First sample \(z\sim q\), then apply this conditional construction. Each leaf has marginal
\[
\sum_z q_z\kappa_z(a)=\sum_z\pi_{az}=p_a,
\]
and the join has law \(q\). This proves sufficiency without replacing a finite coupling by a limit or by an independence assumption.

### 2.5 Equivalence with binary rounds

A \(t\)-round construction can be unfolded into a binary tree with \(2^t\) leaves. At each node, disintegrate the coupling used in that round conditional on its output. Inductively, every leaf has law \(p\), and the root is their join.

Conversely, suppose an \(N\)-leaf coupling exists. Pad to a power of two \(M\ge N\) by repeating existing leaves, then apply an independent uniform permutation of the \(M\) positions. Each leaf still has law \(p\), and idempotence preserves the total join. The tuple is exchangeable. Joins of blocks of equal size therefore have equal laws. Joining adjacent equal-size blocks gives a valid self-coupled round at each level of a balanced binary tree. There are \(\lceil\log_2 N\rceil\) levels. This completes Theorem 1.

## 3. A one-flow graph test

The exponentially many upper sets in (1) need not be enumerated.

Find **any** \(\pi\in\mathcal T(p,q)\). On the vertex set \(L\), build a directed graph \(G_\pi\) with
\[
a\longrightarrow b\quad\text{whenever }a\le b,
\qquad
z\longrightarrow a\quad\text{whenever }\pi_{az}>0.
\tag{9}
\]
Let \(C(z)\) be the strongly connected component containing \(z\).

**Corollary 2.** Exact finite reachability is equivalent to existence of a monotone transport and
\[
z=\bigvee\{a:p_a>0,\ a\le z,\ a\in C(z)\}
\quad\text{for every }q_z>0.
\tag{10}
\]
The strongly connected components relevant to this test do not depend on which feasible transport was chosen.

**Proof.** A subset of vertices is successor-closed in \(G_\pi\) exactly when it is an upper set closed under all reverse positive-transport edges. By (5), these are exactly the tight upper sets. Hence the smallest tight upper set containing \(z\) is the graph-reachability set from \(z\). When \(a\le z\), there is already an edge from \(a\) to \(z\). Thus \(a\) belongs to that reachability set exactly when \(a,z\) lie in the same strongly connected component. Apply (6). The family of tight upper sets is independent of \(\pi\), so the component partition is also independent of \(\pi\). ∎

If (10) fails at \(z\), the set of vertices reachable from \(z\) is a **single tight upper-set certificate** of failure. It contains \(z\), and its initially positive elements below \(z\) cannot generate \(z\).

For rational data, this gives a decision algorithm using one integer max flow, directed graph reachability, and joins in the supplied table. The included implementation also supplies an alternative forced-edge transport algorithm and cross-checks both against direct upper-set enumeration on small instances.

## 4. Rational round bounds and minimum-round synthesis

**Corollary 3.** Suppose every entry of \(p,q\) is an integer multiple of \(1/D\). If \(q\in\mathcal R(p)\), then
\[
q\in\mathcal R_T(p),\qquad
T\le\left\lceil\log_2(Dm^2)\right\rceil.
\tag{11}
\]
The minimum number of rounds, and rational pair-couplings achieving it, are computable in polynomial time in the explicit input length.

**Proof of the bound.** For each selected allowed edge \((a,z)\), force mass \(1/D\) through it. This is feasible by the proof of (4): every positive upper-set slack is at least \(1/D\). The residual integer max-flow problem supplies a rational witnessing transport.

Average \(K\le m^2\) selected witnesses. Every selected edge has mass at least \(1/(DK)\); after conditioning on \(z\), its probability is still at least \(1/(DK)\), since \(q_z\le1\). Construction (7) therefore works with any integer \(N\ge DK\). Choose the smallest power of two no smaller than \(DK\), proving (11).

The count certificate is succinct even when \(D\) is large: (8) uses at most \(m\) components per target, with large counts represented in binary. This is not a claim that explicitly listing all \(N\) leaves costs polynomial time in \(\log N\).

**Minimum-round synthesis.** For a fixed horizon \(t\), introduce laws \(r_0=p,r_t=q\) and nonnegative matrices \(P^{(j)}\), \(1\le j\le t\), with constraints
\[
\sum_bP^{(j)}_{ab}=r_{j-1,a},\qquad
\sum_aP^{(j)}_{ab}=r_{j-1,b},
\qquad
r_{j,z}=\sum_{a\vee b=z}P^{(j)}_{ab}.
\tag{12}
\]
This is a rational linear feasibility problem with \(O(tm^2)\) variables. It is precisely the definition of \(t\)-round reachability; there is no relaxation. Feasibility is monotone in \(t\) because idle rounds are allowed. Search over \(0\le t\le\lceil\log_2(Dm^2)\rceil\), treating \(t=0\) separately. Polynomial-time rational linear programming [11] supplies feasibility decisions and rational witnesses of polynomial encoding length. The bit length of a common denominator \(D\) is at most the sum of the input denominator bit lengths, so this is polynomial in the actual input length. ∎

Two refinements are useful. First, an irredundant generating set has size at most \(\lfloor\log_2(m+1)\rfloor\): its distinct nonempty subfamilies have distinct joins, since an equality between two different subfamily joins would make one generator redundant. Accordingly, the \(m^2\) in (11) can be replaced by \(m\lfloor\log_2(m+1)\rfloor\) using the selected-generator construction.

Second, if \(p\) has full support, stochastic domination alone implies exact reachability. One can simultaneously reserve diagonal mass \(\min(p_z,q_z)\) in a monotone transport: subtracting the same diagonal vector from both laws preserves all stochastic-order slacks, so the residual laws can still be transported. Taking \(B_z=\{z\}\) then gives the sufficient arity bound
\[
N\ge \max_{q_z>0}\max\{1,q_z/p_z\}.
\tag{13}
\]

## 5. Reachable closure and a quantitative approximation bound

Let
\[
S=\langle\operatorname{supp}(p)\rangle_\vee.
\]

**Theorem 4.** With probability laws identified with vectors in a finite-dimensional simplex,
\[
\overline{\mathcal R(p)}
=\{q:\operatorname{supp}(q)\subseteq S,\ p\preceq q\}.
\tag{14}
\]
All orders may equivalently be restricted to the subsemilattice \(S\).

**Proof.** Joins never leave \(S\), and stochastic domination is preserved at every round and under limits. This gives one inclusion.

Let \(k=|\operatorname{supp}(p)|\), and let \(s\) be the law of the join of \(k\) independent samples from \(p\). Every element of \(S\) is a join of at most \(k\) source atoms; padding by repetitions shows \(s_z>0\) for every \(z\in S\).

Given a target on the right side of (14), define
\[
p_\epsilon=(1-\epsilon)p+\epsilon s,
\qquad q_\epsilon=(1-\epsilon)q+\epsilon s.
\]
The law \(p_\epsilon\) is attainable from \(p\): mix a \(k\)-tuple of identical copies of one \(p\)-sample with a \(k\)-tuple of independent \(p\)-samples. Each leaf still has marginal \(p\). Moreover,
\[
q_\epsilon-p_\epsilon=(1-\epsilon)(q-p),
\]
so \(p_\epsilon\preceq q_\epsilon\). The source \(p_\epsilon\) has full support on \(S\), and therefore reaches \(q_\epsilon\) in finitely many rounds by (13). Composing constructions gives \(q_\epsilon\in\mathcal R(p)\). Since \(q_\epsilon\to q\), (14) follows. ∎

The proof also gives a rate. Let \(\tau=\lceil\log_2 k\rceil\) and \(\gamma=\min_{z\in S}s_z>0\). A monotone transport from \(p_\epsilon\) to \(q_\epsilon\) can reserve diagonal mass \(\epsilon s_z\), so arity \(N\ge1/(\epsilon\gamma)\) suffices after the initial \(\tau\) rounds. Consequently, for every target in (14),
\[
\inf_{r\in\mathcal R_t(p)}\|r-q\|_{\rm TV}
\le \min\left\{1,\frac{2^\tau}{\gamma\,2^t}\right\}.
\tag{15}
\]
When the right-hand fraction exceeds 1 the statement is the trivial probability-distance bound; otherwise choose \(\epsilon=2^\tau/(\gamma2^t)\) in the construction above. The constant is input-dependent and can be large.

## 6. The entropy envelope and its classical convex structure

Restrict to \(S\), and form the ordinary least-squares isotonic regression
\[
r^*=\arg\min\left\{\frac12\sum_{a\in S}(r_a-p_a)^2:
 r_a\le r_b\text{ whenever }a\le b\right\}.
\tag{16}
\]
No simplex constraint is required in (16).

**Theorem 5.** The vector \(r^*\) is a probability law, it satisfies \(p\preceq r^*\), and for every continuous convex \(\Phi:[0,1]\to\mathbb R\),
\[
\sum_a\Phi(r^*_a)\le\sum_a\Phi(q_a)
\quad\text{whenever }p\preceq q,\ \operatorname{supp}(q)\subseteq S.
\tag{17}
\]
Thus \(r^*\) is the least-majorized law in the reachable closure. In particular,
\[
\sup_{q\in\mathcal R(p)}H(q)=H(r^*),
\qquad H(q)=-\sum_aq_a\log q_a.
\tag{18}
\]
This supremum is attained in finitely many rounds if and only if \(r^*\) passes Theorem 1.

**Proof.** The order cone is closed and convex, so the Euclidean projection exists and is unique. Clamping coordinates into \([0,1]\) preserves order and reduces squared distance unless the vector already lies in that interval. Translation by any constant vector preserves the order cone; differentiating at the minimizer gives \(\sum_a r^*_a=\sum_a p_a=1\).

The optimality conditions for projection onto a polyhedral cone give nonnegative multipliers \(\lambda_{ab}\), indexed by \(a<b\), satisfying
\[
r^*-p=\sum_{a<b}\lambda_{ab}(e_b-e_a),
\qquad \lambda_{ab}(r^*_b-r^*_a)=0.
\tag{19}
\]
Every term is an upward mass flow, so \(p\preceq r^*\).

First let \(\Phi\) be differentiable and convex, and set \(g_a=\Phi'(r^*_a)\). This is an increasing function of the partial order. Stochastic domination gives \(\langle g,q-p\rangle\ge0\). Complementarity in (19) gives \(\langle g,r^*-p\rangle=0\), because each positively weighted edge joins equal fitted values. Hence
\[
\sum_a\Phi(q_a)-\sum_a\Phi(r^*_a)
\ge\langle g,q-r^*\rangle\ge0.
\]
Uniform approximation by differentiable convex functions extends this to continuous convex \(\Phi\). Choosing \(\Phi(x)=x\log x\), with \(0\log0=0\), proves the entropy bound. Formula (14) and continuity of entropy prove the supremum statement. Strict convexity of \(x\log x\) makes \(r^*\) the unique maximizer, so finite attainment is equivalent to reachability of \(r^*\). ∎

This convex-optimization component must not be sold as a new universal entropy principle. The stochastic upper polytope is the base polytope of the coverage-type submodular function
\[
f(B)=p(\downarrow B).
\tag{20}
\]
Indeed, stochastic domination implies \(q(B)\le p(\downarrow B)\); conversely, taking lower sets \(B\) in these inequalities gives stochastic domination. Minimum-norm and lexicographically optimal bases have substantial classical theory, including Fujishige's 1980 work [3] and later treatments [4]. The proof above is a direct specialization suited to the present dynamics.

The optimizer is strictly positive on \(S\): the closure contains the full-support law \(s\), and mixing it into a purported entropy maximizer with a zero coordinate would increase entropy, since \(-x\log x\) has infinite right derivative at zero. Combining this positivity with (15) and local Lipschitz continuity of entropy shows that
\[
0\le H(r^*)-\max_{q\in\mathcal R_t(p)}H(q)=O_p(2^{-t}).
\tag{21}
\]
The maximum for each fixed \(t\) exists because (12) describes a compact feasible polytope. For an explicit eventual constant, if \(\alpha=\min r^*_a\) and the total-variation approximation error is \(\epsilon\le1/2\), the path between \(r^*\) and \(q_\epsilon\) stays above \(\alpha/2\) coordinatewise, giving entropy error at most \(2\epsilon[1+\log(2/\alpha)]\).

A related exact stability criterion is immediate. No self-coupled join, of any finite arity, can increase \(H(p)\) if and only if its positive support is join-closed and its positive atom probabilities are increasing on that support. Sufficiency follows from
\[
H(p)-H(q)=D(q\Vert p)+\mathbb E[\log p_Z-\log p_X]\ge0,
\]
where \(X\le Z\). For necessity, a missing positive-source join creates a new positive output atom and increases entropy for a small off-diagonal perturbation; if instead \(a<b\) and \(p_a>p_b>0\), swapping small diagonal mass into the two off-diagonal pairs transfers mass from \(a\) to \(b\) and increases entropy to first order by \(\log(p_a/p_b)>0\).

## 7. Sharp three-state example

Let \(L=\{a,b,c\}\) with incomparable \(a,b\) and \(a\vee b=c\). Fix \(0<\delta<1/3\) and
\[
p=(1-\delta,\delta,0).
\]
The isotonic regression and entropy optimizer are
\[
r^*=\left(\frac{1-\delta}{2},\delta,\frac{1-\delta}{2}\right).
\tag{22}
\]
It stochastically dominates \(p\), and its support lies in the join closure of the source support. Nevertheless it is not finitely attainable: \(U=\{a,c\}\) is tight, and its initially positive support is just \(\{a\}\), which cannot generate \(c\).

For an \(N\)-leaf coupling, \(N\ge2\), a target \(q=(A,B,C)\) is attainable exactly when
\[
B+\frac CN\le\delta\le B+\frac{N-1}{N}C.
\tag{23}
\]
To prove necessity, the number of \(b\)-leaves is zero on the all-\(a\) outcome, \(N\) on the all-\(b\) outcome, and between 1 and \(N-1\) on a mixed outcome. Its expectation is \(N\delta\). Conversely, assign probabilities \(A,B\) to the constant tuples and, on the mixed event, mix counts between 1 and \(N-1\) to produce the required expectation; a uniform permutation gives identical leaf marginals. This also covers \(N=2\), when the mixed count is necessarily 1.

Set \(\delta=1/10\) and, for a multiple \(D\ge100\) of 20, take
\[
q_D=\left(\frac9{20}+\frac1D,\frac1{10}-\frac1D,\frac9{20}\right).
\tag{24}
\]
Then
\[
N_{\min}=\frac{9D}{20},\qquad
t_{\min}=\left\lceil\log_2\frac{9D}{20}\right\rceil.
\tag{25}
\]
Thus the logarithmic denominator dependence in (11) is necessary already on three states.

An exact optimal policy is explicit. First couple \(a\) and \(b\) with off-diagonal mass \(1/D\), producing \(c\)-mass \(2/D\). Then couple \(a\) with \(c\), doubling the \(c\)-mass each round until a final partial step reaches \(9/20\). This uses exactly (25) rounds. For \(D=100\), the successive laws are
\[
(.90,.10,0),\ (.89,.09,.02),\ (.87,.09,.04),\ (.83,.09,.08),
\ (.75,.09,.16),\ (.59,.09,.32),\ (.46,.09,.45).
\]
All displayed decimals are terminating exact rationals. The included verifier checks the full pair-coupling matrices, both marginals, every pushforward, and the final target.

There is also a sharp entropy convergence formula. Put \(N=2^t\), \(t\ge1\). Maximizing entropy under (23) yields
\[
q_N=\frac{(1,e^{-\lambda_N},e^{-\lambda_N/N})}
{1+e^{-\lambda_N}+e^{-\lambda_N/N}},
\tag{26}
\]
where \(\lambda_N>0\) is chosen so that \(B+C/N=\delta\). The entropy maximizer over the larger constraint \(B+C/N\le\delta\) has this Gibbs form and lies on the boundary; because \(N\ge2\), it automatically satisfies the other inequality in (23), proving optimality over the exact feasible set.

Writing \(u=1/N\), the optimized entropy is
\[
F(u)=\lambda(u)\delta+\log\bigl(1+e^{-\lambda(u)}+e^{-u\lambda(u)}\bigr).
\]
At \(u=0\),
\[
\lambda(0)=\log\frac{1-\delta}{2\delta},\qquad C(0)=\frac{1-\delta}{2}.
\]
The constraint derivative in \(\lambda\) is minus the variance of the weights \((0,1,u)\), which is strictly negative at \(u=0\). The implicit function theorem gives smoothness near zero. Differentiating the optimized value cancels the \(\lambda'(u)\) terms and gives \(F'(u)=-\lambda(u)C(u)\). Therefore
\[
H(r^*)-H(q_N)
=\frac{1-\delta}{2N}\log\frac{1-\delta}{2\delta}
+O_\delta(N^{-2}).
\tag{27}
\]
The positive leading coefficient proves that the general exponential-in-round upper rate (21) cannot be improved in order for every source.

## 8. Relation to continuous reaction networks

A symmetrized self-coupling changes the law by
\[
\sum_{a<b}\pi_{ab}\bigl(2e_{a\vee b}-e_a-e_b\bigr),
\]
where the ordering of the distinct labels in the sum is arbitrary. This is a parallel fractional firing of the reactions
\[
a+b\longrightarrow 2(a\vee b).
\tag{28}
\]
The source-marginal constraints ensure that total consumption at any species is no more than its initial mass. Consequently these firings can be performed sequentially: remaining initial mass suffices for every remaining planned consumption, and production only adds mass. Conversely, one feasible fractional firing of (28) is realized by adding its firing amount to \(\pi_{ab},\pi_{ba}\) and subtracting that amount from \(\pi_{aa},\pi_{bb}\). Thus the finite reachable sets agree under the ordinary fractional-firing semantics.

This identifies the result as a structural characterization for a particular class of continuous Petri nets. Polynomial-time reachability and constructive paths for general continuous models were studied before this investigation [5,6]. Consequently the polynomial-time decision conclusion is **not** evidence that a general computational barrier has been newly broken. The semilattice-specific tight-cut criterion, the common-marginal coupling construction, and the explicit parallel-round bounds are the precise claims whose independent precedence still needs to be checked.

## 9. Verification actually performed

`join_reachability.py` uses Python's standard library, arbitrary-precision integers and `fractions.Fraction`. No floating-point decisions are used in the main verifier.

The retained receipt records all distribution pairs on the following grids:

| State space | Common grid denominator | Distribution pairs |
|---|---:|---:|
| Three-element chain | 7 | 1,296 |
| Three-element V semilattice | 8 | 2,025 |
| Two-bit Boolean lattice | 6 | 7,056 |
| **Total** | | **10,377** |

On every pair, the forced-edge max-flow decision, the one-flow graph decision and direct tight-upper-set enumeration agreed. Every positive forced-edge result was checked by an independent exact reconstruction of its count-coupling certificate. Another 250 seeded generated cases were checked; direct upper-cut enumeration was additionally used whenever the generated state space had at most nine states. The four sharp examples with denominators 100, 1,000, 10,000 and 1,000,000 have exact optimal policies with 6, 9, 13 and 19 rounds respectively.

These are finite diagnostics, not universal or formal verification. The proofs above, rather than the counts of examples, support the quantified theorems. The general minimum-round LP algorithm is specified in (12); the implementation supplies general exact reachability/count certificates and exact minimum-round pair policies for the three-state sharpness family, not a general exact LP solver.

Run:

```bash
python verify_join_reachability.py
```

## 10. Research scope and provenance

The investigation screened sample compression, global entropy couplings for union-closed families, and quantum information combining. None yielded a completed major-conjecture resolution. The result retained here emerged from replacing an inadequate entropy-balancing condition with exact support constraints inside stochastic transport.

The Frankl branch still lacks the all-family half-frequency inequality. A uniform law on a union-closed family is already an entropy maximizer on its support; the present theorem does not supply the strict entropy lower bound that would contradict an all-rare-coordinate hypothesis. It is not a no-go theorem for all entropy-based proofs.

The quantum-information searches did not supply a universal noncommutative inequality or a certified counterexample. The older primary information-combining work [9] is background, not a theorem premise here. A recently surfaced exact-compression claim [10] was screened at abstract level and was not used.

Repository revisions actually accessed:

- **Astra:** `779be19cab568565f4f6891f598c81274aca8529`.
- **OpenAI math:** `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

Astra navigation began at `00_START_HERE.txt`. The original mathematical text of the regular-antichain rare-element construction was read through `web/pages/d-8c3e446e8c176565.html`, after locating its evidence path through card N376. The literal historical source path and an object-store path returned 404; the rendered original-text route succeeded. The source's star-union/isolate-free-induced-subgraph counting mechanism was inspected, including its explicit abundant-edge injection. It is an auxiliary counterexample, not Frankl's conjecture.

For OpenAI, the inspected original LaTeX files were

- `preprints/Sharp-binary-information-contraction-on-the-discrete-cube-September-24-2026/build/main.tex`;
- `preprints/Sharp-binary-information-contraction-on-the-discrete-cube-September-24-2026/build/sections/canonical.tex`.

The inspected mechanism prices an entropy budget and certifies a small-support optimizer by a global affine lower bound. This was methodological input concerning the necessity of preserving coupling constraints. The proof in this note does **not** assume the correctness of the full OpenAI contraction theorem or any Astra research claim.

## References and historical boundaries

[1] V. Strassen, *The Existence of Probability Measures with Given Marginals*, Annals of Mathematical Statistics **36** (1965), 423–439. DOI: `10.1214/aoms/1177700153`. The finite monotone-coupling fact used here is a classical consequence, re-proved by max flow in Section 2.1.

[2] D. Gabrielli and I. G. Minelli, *Stochastic monotonicity from an Eulerian viewpoint*, arXiv:`1403.3855` (2014). Primary work relating stochastic domination, monotone couplings and decomposable flows.

[3] S. Fujishige, *Lexicographically Optimal Base of a Polymatroid with Respect to a Weight Vector*, Mathematics of Operations Research **5** (1980), 186–196. DOI: `10.1287/moor.5.2.186`. A principal predecessor for minimum-norm and lexicographically optimal bases, not a result introduced here.

[4] A. Frank and K. Murota, *Decreasing Minimization on Base-Polyhedra: Relation Between Discrete and Continuous Cases*, arXiv:`2202.06561`; Japan Journal of Industrial and Applied Mathematics **40** (2023). DOI: `10.1007/s13160-022-00511-4`. Clarifies the older continuous theory and its relation to discrete optimization.

[5] E. Fraca and S. Haddad, *Complexity Analysis of Continuous Petri Nets*, Fundamenta Informaticae **137** (2015), 1–28. DOI: `10.3233/FI-2015-1168`; conference predecessor in PETRI NETS 2013. Existing reachability and limit-reachability algorithms materially limit any novelty claim based only on polynomial-time reachability.

[6] A. Case, J. H. Lutz and D. M. Stull, *Reachability Problems for Continuous Chemical Reaction Networks*, arXiv:`1508.04125` and ECCC TR15-140 (2015). Gives polynomial-time construction of reachability paths in the studied rate-independent continuous model.

[7] L. Yu, *Dimension-Free Bounds for the Union-Closed Sets Conjecture*, Entropy **25** (2023), 767. DOI: `10.3390/e25050767`. Background for entropy-based partial bounds; no claim here supersedes its universal bound.

[8] OpenAI, *Sharp binary-information contraction on the discrete cube*, manuscript dated 24 September 2026, at the pinned repository revision above. Only the named source files and their mechanisms were inspected; no whole-manuscript validation is asserted.

[9] C. Hirche and D. Reeb, *Bounds on Information Combining With Quantum Side Information*, IEEE Transactions on Information Theory **64** (2018), 4739–4757. DOI: `10.1109/TIT.2018.2842180`; arXiv:`1706.09752`. Supplies the conjectural sharp quantum information-combining background, not a proved premise used in this note.

[10] B. Li, *Labeled Compression Schemes for Concept Classes of Finite Functions*, arXiv:`2603.23561` (2026). Screened only; its announced exact-compression result was not verified or used.

[11] L. G. Khachiyan, *A polynomial algorithm in linear programming*, Doklady Akademii Nauk SSSR **244**(5) (1979), 1093–1096. The algorithmic claim in Section 4 uses classical polynomial-time rational linear programming, not a new LP algorithm.

**Final scope.** The note establishes the displayed finite-model arguments subject to mathematical review. It does not establish historical priority for the exact characterization, nor the foundational significance required by the original mission.
