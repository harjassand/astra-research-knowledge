# Noise-robust lineage moments, partition variability, and a reversible-growth counterexample

**Investigation date:** 9 October 2026  
**Status:** Conditional mathematical results, symbolic checks, and synthetic tests. No newly established biological law. Historical novelty of the inference identity is not established. No raw experimental dataset was successfully analysed.

## 1. Outcome and scientific question

This investigation screened galaxy-acceleration regularities, thermodynamic inference from coarse observations, and cellular size regulation. It concentrated on the last because repeated lineage measurements permit explicit distinctions between inherited fluctuations, stochastic division, and observation error.

The scientific question was whether the directional structure of cell-size inheritance reveals an otherwise hidden organizing mechanism. The initial proposed interpretation—non-Gaussian lineage fluctuations give a universal signature of active growth—fails. An exactly reversible growth-and-partition model supplies a counterexample. Reversible beta–gamma processes are also established prior work, not a new discovery [3].

A stronger conditional result survived: in an independent random-affine lineage model, nonzero-lag correlations of polynomial observables identify moments of the random inheritance coefficient despite unknown independent additive observation noise. The degree-two identity separates the mean coefficient from its second moment; it remains informative in the reversible counterexample where cubic time-asymmetry statistics vanish.

This is not evidence that cells universally obey the model. It does not identify a unique biochemical cause, infer metabolic heat, or establish a fundamental law of nature. Related random-coefficient estimation and noise-robust stochastic-operator methods already exist [4–6]. The precise degree-two biological specialization has not received a complete novelty audit.

## 2. Model and assumptions

Follow one daughter at each division. Let B_n be its birth size, Delta_n the size its mother adds before division, and R_n the fraction of the predivision size retained by the tracked daughter. Consider

    B_(n+1) = R_n (B_n + Delta_n),    0 < R_n < 1.

Assume the pairs (R_n, Delta_n) are independent and identically distributed across generations and independent of B_n and its past. R_n and Delta_n within the same generation MAY be dependent. Stationarity, finite fourth moments, and nondegeneracy of the covariance matrix of B and B^2 are required for the degree-two result. The nondegeneracy condition holds, for example, if the stationary law has at least three support points.

The measured size is

    Y_n = B_n + epsilon_n.

The observation errors are independent and identically distributed, independent of the entire latent process, and have finite fourth moments. Their variance and distribution need not be known. They need not be Gaussian or symmetric. Centering absorbs a constant error mean. The theorem concerns population moments; finite samples still have estimation error that grows with observation noise.

The independent-pair assumption is scientifically substantial. An empirical relation between average added size and birth size does not establish independence of the full conditional distribution. Hidden inherited molecular variables, selection of lineages, correlated segmentation errors, changing environments, and nonlinear growth control can invalidate it.

The background adder phenomenon and several molecular implementations are already studied experimentally [1,2]. No universal claim about all organisms is made here.

## 3. Complete degree-two derivation

Write mu = E[B], X_n = B_n - mu, and

    eta_n = R_n (Delta_n + mu) - mu.

Then

    X_(n+1) = R_n X_n + eta_n,    E[eta_n] = 0.

Define

    a = E[R],    q = E[R^2],    b = E[R eta],    V = E[X^2].

Since (R,eta) is independent of the current X,

    E[X_(n+1) | X_n=x] = a x,
    E[X_(n+1)^2 | X_n=x] = q x^2 + 2 b x + E[eta^2].

Stationarity gives E[eta^2] = (1-q)V. Therefore the centered observable vector

    f(x) = (x, x^2 - V)^T

has the exact conditional evolution

    E[f(X_(n+1)) | X_n] = T f(X_n),
    T = [[a, 0], [2b, q]].

Let Sigma = E[f(X_0) f(X_0)^T] and define the nonzero-lag matrices

    M_k = E[f(X_0) f(X_k)^T],    k >= 1.

Iterated conditioning yields

    M_k = Sigma (T^T)^k.

The covariance Sigma is invertible by assumption. Also a,q>0, so T is invertible. Consequently

    M_1^(-1) M_2 = T^T = [[a,2b],[0,q]].              (1)

In particular the two eigenvalues are E[R] and E[R^2], and

    Var(R) = q - a^2.                                 (2)

### Why unknown additive measurement noise does not bias these population matrices

Set W=Y-E[Y]=X+e, where e is the centered error, and s^2=E[e^2]. The observed feature vector is

    g(W) = (W, W^2 - E[W^2])^T.

Since E[W^2]=V+s^2,

    E[g(W_n) | X_n] = (X_n, X_n^2-V)^T = f(X_n).

For distinct generations, the observation errors are conditionally independent given the latent trajectory. Thus, for every k>=1,

    E[g(W_0) g(W_k)^T]
      = E[E[g(W_0)|X_0] E[g(W_k)|X_k]^T]
      = M_k.                                         (3)

Equation (1) therefore holds with matrices computed entirely from noisy observations. This uses nonzero lags: the zero-lag feature covariance is generally contaminated by observation noise.

### Explicit scalar formula

For k>=1 let

    C_k = E[W_0 W_k],
    H_k = E[W_0 W_k^2],
    K_k = E[W_0^2 W_k],
    F_k = Cov(W_0^2,W_k^2).

Then M_k=[[C_k,H_k],[K_k,F_k]]. The population identities give

    a = C_2/C_1,
    q = (C_1 F_2 - K_1 H_2)/(C_1 F_1 - K_1 H_1),
    Var(R) = q-a^2.                                  (4)

The denominator equals det(M_1)=det(Sigma)*a*q>0. It does not require a nonzero third moment or a nonzero arrow-of-time statistic.

### Dimensional check

C has units of size squared, H and K size cubed, and F size to the fourth power. Numerator and denominator in q both have units of size to the sixth power. Therefore a, q, and Var(R) are dimensionless, as required for a partition fraction. A change in the size unit acts by a similarity transformation on the matrix pencil and leaves its eigenvalues unchanged.

## 4. Higher-order extension and its limits

For integer d>=1, assume finite 2d-th moments of the latent size and observation error, and nonsingular covariance of the centered polynomial features of degrees 1 through d. Write a general random-affine recursion as

    B' = R B + U,

where the pair (R,U) is independent of the current B. For the division model U=R Delta; R and U may be dependent.

For each j,

    E[(R B+U)^j | B=x]
      = sum_(l=0)^j binom(j,l) E[R^l U^(j-l)] x^l.

The leading coefficient is r_j=E[R^j]. Centering the monomials removes their constant terms. Hence the conditional operator on centered polynomial features is triangular, with diagonal r_1,...,r_d.

Independent additive observation noise transforms these features by a lower-triangular matrix A with diagonal entries all equal to one. Explicitly, before any optional centering of the variable itself,

    E[Y^j-E[Y^j] | B]
      = sum_(l=1)^j binom(j,l) E[epsilon^(j-l)]
          (B^l-E[B^l]).

The observed nonzero-lag matrices therefore have the form

    M_k^Y = A Sigma (T_d^T)^k A^T.

Their pencil is

    (M_1^Y)^(-1) M_2^Y = A^(-T) T_d^T A^T.

Similarity preserves eigenvalues. The population eigenvalues are exactly

    E[R], E[R^2], ..., E[R^d].                        (5)

For 0<R<1 these are strictly decreasing, so their ordering resolves their labels. If the construction is valid for all degrees, the full moment sequence determines the distribution of R on [0,1]: equality of all moments gives equality of integrals of polynomials, uniform polynomial approximation extends this to continuous functions, and thus the probability measures coincide.

This is population identifiability, not a stable finite-sample distribution-recovery guarantee. High-degree features can be poorly conditioned and have enormous sampling variance. Finite 2d-th moments suffice for defining the matrices; stronger conditions are needed for particular central limit theorems and error bars. Hidden dynamics can share a finite collection of moments with the assumed model. No unique microscopic chemical mechanism follows from (5).

## 5. Cubic time asymmetry: useful identity, inadequate foundation

Define the third-order time-asymmetry statistic

    J_k = E[X_0^2 X_k] - E[X_0 X_k^2].

Let m_3=E[X^3]. Conditional expectation gives

    C_k=a^k V,
    K_k=a^k m_3,
    H_(k+1)=q H_k+2b a^k V,    H_0=m_3.

Since q<a for 0<R<1,

    H_k=q^k m_3+2bV(a^k-q^k)/(a-q),
    J_k=D(a^k-q^k),
    D=m_3-2bV/(a-q).                                 (6)

When J_1 is nonzero, this implies

    q=J_2/J_1-a.

For deterministic equal partition R=1/2, b=0, a=1/2 and q=1/4, so

    J_k=m_3(2^(-k)-4^(-k)).

Independent additive observation error leaves the cross-time cubic moments unchanged, but the ratio estimator becomes ill-conditioned when D is small or zero. The initial claim of a universal biological arrow of time was therefore rejected. Non-Gaussian linear-process time irreversibility is itself prior work [7].

## 6. Exact reversible counterexample

Let alpha,beta,theta>0, and take independent

    B ~ Gamma(alpha,theta),
    Delta ~ Gamma(beta,theta),
    R ~ Beta(alpha,beta),
    B'=R(B+Delta).

Set S=B+Delta. The change of variables (B,Delta)->(S,P), P=B/S, factorizes the density into Gamma(alpha+beta,theta) for S and Beta(alpha,beta) for P, with S and P independent. R is an independent copy of P. Therefore

    (B,B') = (P S,R S)

is exchangeable. B' has the same gamma law as B, and the stationary one-step joint law is symmetric. The corresponding Markov chain satisfies detailed balance and its entire stationary birth-size sequence is time reversible.

Nevertheless Delta is strictly positive and 0<R<1 almost surely: the bookkeeping describes growth followed by partition in every generation. For alpha=beta the mean partition is 1/2. For alpha=beta=4,

    a=1/2, q=5/18, Var(R)=1/36,

and every J_k is zero. The matrix in (1) is still nonsingular and identifies q.

This does NOT establish thermodynamic equilibrium of a cell. The generation-indexed birth-size sequence omits the continuous growth trajectory, molecular states, discarded daughter, and energetic exchanges. Reversible observed records do not imply reversible microscopic physiology. Reversible beta–gamma processes were published decades ago [3], so this is a reconstructed counterexample, not a novelty claim.

## 7. Computation actually performed

The script `investigate.py` performs exact symbolic checks of (1) and (6), checks the zero amplitude of the symmetric beta–gamma family, and simulates six separate scenarios. Each scenario uses 2,048 independent lineages and 4,096 retained generation pairs per lag per lineage after a burn-in. That is 8,388,608 pairs per lag in each scenario. These are synthetic samples, not cell measurements. Seeds start at 20261009.

Except for the inherited-addition control, added sizes follow Gamma(4,1/4), with mean one. Partition is either fixed at 1/2, Beta(20,20), or Beta(4,4). Measurement-noise cases use either independent N(0,0.2^2) error or independent Exponential(mean=0.2)-0.2 error. The correlated-addition control uses Delta_n=0.65 Delta_(n-1)+0.35 G_n, with G_n~Gamma(4,1/4), and independent Beta(20,20) partition.

The experiment knows the true stationary mean (one). Reported standard errors use a delta-method linearization across independent simulated lineages. They are not an empirical-data bootstrap or a validated confidence procedure for arbitrary biological records.

| Synthetic condition | True Var(R) | Matrix estimate | One standard error |
|---|---:|---:|---:|
| Fixed equal partition | 0 | 0.000901 | 0.002040 |
| Random partition, no observation error | 0.006098 | 0.003501 | 0.002174 |
| Random partition, Gaussian observation error | 0.006098 | 0.003397 | 0.003131 |
| Random partition, skewed observation error | 0.006098 | 0.008725 | 0.003574 |
| Reversible beta–gamma model | 0.027778 | 0.027033 | 0.002761 |

The estimates are compatible with the generating values at roughly conventional two-standard-error scales. This is a numerical consistency check, not proof. The exact identities are justified by the derivations, not by simulation. The standard errors also show that an exact noise-cancellation identity does not guarantee precise inference from short experimental lineages.

The scalar cubic estimator fails badly in the reversible case: the realised variance estimate is about -6.24 with a standard error about 18.68, because its denominator is a fluctuation around zero. This failure was retained rather than clipped away.

The deliberately misspecified inherited-addition model yields a plausible matrix variance estimate of about 0.00116, even though the true partition variance is 0.00610. Its first inferred coefficient is about 0.677 rather than the actual mean partition 0.5. Successive covariance ratios are approximately 0.6771, 0.6704, 0.6654, and 0.6611, instead of a single constant. Its held-out lag-three matrix defect is approximately 1.37%, compared with 0.10%–0.36% in the simulated independent models. These percentages are descriptive diagnostics for these runs, not hypothesis-test p-values or universal thresholds.

## 8. Quantitative, independently checkable consequences

The model predicts more than fitted values of a and q. Once T^T=M_1^(-1)M_2 is determined, all later nonzero-lag matrices must satisfy

    M_(k+1)=M_k T^T,    k>=1.

In particular M_3 must equal M_2 M_1^(-1) M_2. The lower-left entry of the degree-two pencil must vanish, within justified sampling error. Nonzero-lag covariance ratios must be constant. If independently observed division fractions are available, their first two moments must agree with the corresponding pencil quantities. For a genuine fraction in (0,1), a^2<=q<a. Fixed partition has equality q=a^2.

At higher degree, r_j=E[R^j] is decreasing and obeys the moment constraints of a probability measure on [0,1]. For example r_(j+1)^2<=r_j r_(j+2), and the full sequence obeys the alternating finite-difference inequalities obtained from E[R^n(1-R)^m]>=0. Failure of these constraints after appropriate uncertainty accounting rules out the assumed independent random-affine explanation; it does not by itself identify the replacement mechanism.

These are model predictions, not claims that real observations satisfy them. Agreement of finitely many identities is not uniqueness of a biochemical explanation.

## 9. Empirical evidence and access limitations

Published work provides real motivation, not validation of the identities derived here. Si et al. experimentally investigated threshold accumulation and balanced biosynthesis as mechanisms of bacterial adder behavior [1]. ElGamel and Mugler analysed molecular-noise constraints and compared their theory with public E. coli datasets [2]. Tanouchi et al. released long-term single-cell growth measurements [8].

A curated repository points to Tanouchi-derived lineage data, but the fetched `data/TPP2017_cg.csv` was a Git LFS pointer, not data. Its pointer identifies SHA-256 `345e6da7324c94b133076c794a81ea729159092b1698d3f74af713288c3b5812` and size 1,182,484 bytes. The content object was not obtained. Direct runtime network access failed; a web attempt on the media URL also failed. No raw cell-size trace was reconstructed from snippets or replaced with invented measurements.

Therefore this report contains no new empirical estimate, no validation of the proposed identity in living cells, and no independent observation distinguishing a new biological mechanism. That missing connection to actual measurements prevents a claim of a new fact about nature. Existing methods literature also prevents asserting historical novelty without further comparison.

## 10. Repository provenance and what was actually used

Astra revision inspected: `7e08c9fc917a684a437155abd2c790d5f5ff2d99`. Navigation began at `00_START_HERE.txt`. Probability routing and the N185 hidden-metastability/entropy-production obstruction summary were inspected. The linked original proof was not recovered; it is not a premise of any result above. The repository's entry explicitly distinguishes indexed claims from verification and states that no discovery gain is established.

OpenAI math revision inspected: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`. In addition to the catalogue, the actual TeX source for the September 24, 2026 Heisenberg-ferromagnet manuscript was accessed: `build/source/main.tex` and the available part of `build/source/sections/02-pin-test.tex`. The concrete mechanism inspected was stability-preserving partial symmetrization, Bernoulli-transposition exchange symbols, and coefficient-extraction/splicing toward a simultaneous pin test. This was not an independent audit of the full ferromagnet theorem. None of the biological formulas above is presented as a consequence of that manuscript.

The claim-status record for this investigation should remain:

- Mathematical status: conditional identities with self-contained derivations; several symbolic and synthetic checks completed; no independent formal verification.
- Novelty status: unestablished; substantial related prior methods and exact reversible-process precedents exist.
- Scientific status: no raw empirical test completed; no new biological mechanism established.
- Foundational-discovery status: not established.

## References

[1] Si, F., Le Treut, G., Sauls, J.T., Vadia, S., Levin, P.A., and Jun, S. (2019). Mechanistic Origin of Cell-Size Control and Homeostasis in Bacteria. *Current Biology* 29, 1760–1770.e7. DOI: 10.1016/j.cub.2019.04.062. https://www.sciencedirect.com/science/article/pii/S0960982219304919

[2] ElGamel, M., and Mugler, A. (2024). Effects of Molecular Noise on Cell Size Control. *Physical Review Letters* 132, 098403. https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.132.098403

[3] Lewis, P.A.W., McKenzie, E., and Hugus, D.K. (1989). Gamma processes. *Communications in Statistics. Stochastic Models* 5, 1–30. https://doi.org/10.1080/15326348908807096

[4] Wanner, M., and Mezic, I. (2022). Robust Approximation of the Stochastic Koopman Operator. *SIAM Journal on Applied Dynamical Systems*. https://doi.org/10.1137/21M1414425 (preprint arXiv:2011.00078).

[5] Zhang, X., Chen, J., and Li, Q. (2024). Estimation of Random Coefficient Autoregressive Model with Error in Covariates. *Axioms* 13, 303. https://doi.org/10.3390/axioms13050303

[6] Aue, A., Horvath, L., and Steinebach, J. (2006). Estimation in Random Coefficient Autoregressive Models. *Journal of Time Series Analysis* 27, 61–76. https://doi.org/10.1111/j.1467-9892.2005.00453.x

[7] Breidt, F.J., and Davis, R.A. (1992). Time-Reversibility, Identifiability and Independence of Innovations for Stationary Time Series. *Journal of Time Series Analysis* 13, 377–390. https://doi.org/10.1111/j.1467-9892.1992.tb00114.x

[8] Tanouchi, Y., Pai, A., Park, H., Huang, S., Buchler, N.E., and You, L. (2017). Long-term growth data of Escherichia coli at a single-cell level. *Scientific Data* 4, 170036. https://doi.org/10.1038/sdata.2017.36

[9] Skinner, D.J., and Dunkel, J. (2021). Estimating entropy production from waiting time distributions. *Physical Review Letters* 127, 198101. https://arxiv.org/abs/2105.08681

Data repository consulted: https://github.com/elevien/single-cell-size-data (metadata and LFS pointer accessed; the data payload was not retrieved).

Repository source paths:
https://github.com/harjassand/astra-research-knowledge/blob/7e08c9fc917a684a437155abd2c790d5f5ff2d99/00_START_HERE.txt
https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Spontaneous-magnetization-in-the-quantum-Heisenberg-ferromagnet-September-24-2026/build/source/sections/02-pin-test.tex
