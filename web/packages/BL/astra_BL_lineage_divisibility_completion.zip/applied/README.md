# Determinantal completion research package

The central result is an exact categorical-completion sampler for determinant-weighted designs, with a computable collision bound controlling rejection. It is a **scoped research result, not an established foundational breakthrough**. Historical priority is unresolved, and the efficient regime is not universal.

Read `REPORT.md` for the theorem, full proof, resource accounting, baseline results, prior-art findings, and explicit exponential failure family.

## Run

```bash
python -m pip install -r requirements.txt
python demo.py
python validation.py
OPENBLAS_NUM_THREADS=1 python scaling_benchmark.py
```

`demo.py` uses exact rational features and produces exact rational-reference samples and a normalizer estimate with a specified relative-error/failure-probability budget.

The tested package versions are pinned in `requirements.txt`. Environment details appear in `results/scaling.json`. Compilation/warm-up is excluded from the per-run timing table, but preprocessing and Gibbs burn-in are included. Timings are from one container, not a hardware-independent guarantee.

## Files

- `exact_completion.py`: exact rational conditional-DPP sampler, categorical completion, exact collision certificate, random-bit accounting, and relative-error normalizer estimator.
- `completion.py`: faster floating-point spectral/Householder implementation. No interval enclosure of its sampling probabilities is claimed.
- `validation.py`: exhaustive rational identities and conditional probabilities on a small fixture; finite detailed-balance audit of the separate defect chain.
- `scaling_benchmark.py`, `feature_gibbs.py`: four model-based diffusion cases, five seeds each, 5,000 outputs, and an optimized rank-update Gibbs baseline.
- `sampler.py`, `instances.py`, `pilot.py`: the earlier ridge-defect route and its unfavourable as well as favourable comparisons with Gibbs, block Gibbs, multiscale proposals, and replica exchange.
- `completion_pilot.py`: direct-sampler tests including exponentially poor rejection cases.
- `results/`: actual executed outputs, raw logs, instance arrays, and summary statistics.
- `source_ledger.json`, `claim_ledger.json`: source revisions, status boundaries, and what was or was not established.

## Minimal exact use

```python
from fractions import Fraction as F
from exact_completion import ExactCompletionSampler

X = [[F(4,5), 0], [F(3,5), F(1,5)],
     [0, F(3,5)], [F(1,5), F(4,5)]]
sampler = ExactCompletionSampler(X, groups=[0, 0, 1, 1])
print(sampler.acceptance_lower_bound)
designs, cost = sampler.sample(100, seed=123, max_trials=10000)
```

Optional categorical probabilities must sum exactly to one in each group. An optional rational positive-definite `prior_precision` is supported without irrational whitening. The target is proportional to the prior-product times the information determinant. It is not an optimizer.

A budget exhaustion raises an error; it never returns a distribution-changing fallback. Exact arithmetic refers to the supplied rational input. Pseudorandom bits are modelled as independent in the mathematical statements; a `SystemRandom` object can instead be supplied to the exact sampler.

## Important limits

The guarantee of inexpensive rejection requires a positive collision lower bound. On an explicit cycle family, even a polynomial-sized signal parameter produces exponential rejection cost. There is no universal new FPRAS or quantum-simulation claim. The general mixed-discriminant FPRAS was already claimed in Chen–Liu's 5 October 2026 preprint. The relation to established regularized DPP augmentation prevents treating this construction as priority-cleared foundational knowledge.
