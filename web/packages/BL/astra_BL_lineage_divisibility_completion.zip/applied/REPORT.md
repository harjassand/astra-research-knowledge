# Collision-certified determinantal completion
## Research result, operational construction, and limits

**Date:** 9 October 2026.  
**Status:** A derived and implemented sampling construction with an elementary correctness proof, an input-dependent runtime certificate, exact rational checks, and reproducible numerical experiments. Historical priority is not established. A foundational practical breakthrough is **not** established.

## 1. Result and scientific task

Suppose each of many hardware units, experimental stages, or labelled groups must contribute exactly one choice. A choice supplies a feature vector describing the information obtained about a linear scientific model. We want independent designs that favour informative, nonredundant joint measurements, while satisfying every group constraint exactly.

The target is a probability distribution, **not** the maximum-determinant design. Neither sampling from it nor estimating its normalizer is a claim to solve an NP-hard optimization problem.

Let the item set be partitioned into nonempty groups G_1,...,G_m. There are N items in total. Item i has feature x_i in R^d and categorical prior p_i>0, with sum_{i in G_g} p_i=1. Let A be a positive-definite prior precision matrix. A feasible design S contains exactly one item from every group. Define

    w(S) = [product_{i in S} p_i] det(A + sum_{i in S} x_i x_i^T),
    Z = sum_{feasible S} w(S),
    mu(S) = w(S)/Z.

For a whitened Gaussian linear observation model, A + sum x_i x_i^T is posterior precision. The determinant is an information-volume criterion. This established connection is developed in [S4]; no new statistical meaning for determinants is claimed here.

The construction below produces independent samples from mu without learning a mixing time, calibrating defect weights, or enumerating feasible designs. It is correct for every input of the stated form, but its **efficient** regime is explicitly restricted by a collision certificate. Outside that regime, rejection can be exponentially expensive.

## 2. What was investigated and what was discarded

The investigation screened attention computation, reliable scientific surrogates, rare-event simulation, and constrained determinant sampling. Only the determinant direction was implemented. The other screens are not completed research results.

A first construction replaced rank-penalty annealing in the OpenAI common-bases manuscript [S2] by ridge-determinant weights. Its positive homogeneous principal-minor polynomials and their complements have the required real-stability/signature structure. The source's enlarged state space consists of legal transversals plus one-empty/one-full-pair defects. This suggested a weighted exchange sampler.

However, a current-literature check found Chen and Liu's **5 October 2026** preprint [S3]. It already states an FPRAS for mixed discriminants and substantially more general products of measures. Therefore, a mixed-discriminant FPRAS is **not a novelty claim of this investigation**. Moreover, the conservative simulation budgets in [S2] are far too large to establish practical usefulness. A shorter adaptive implementation does not inherit those finite-time guarantees merely because it uses the same transition graph.

A practical ridge/defect sampler was implemented anyway and tested against single-pair Gibbs, two-pair Gibbs, multiscale proposals, and eight-replica tempering. The results were mixed and often unfavourable. These runs are retained in `results/pilot.json`; they were not deleted when a different method looked better.

Astra's positive EPR determinant representation [S1] was also read at its underlying proof, not just at its review card. That proof explicitly exhibits exponential relative variance for its raw positive estimator. Its lesson here is a resource constraint: a positive determinant expectation is not sufficient to establish efficient simulation. The construction below therefore includes a directly computable success-probability bound. It does not solve the EPR sampling problem.

## 3. The categorical completion identity

Define

    B = A + sum_i p_i x_i x_i^T,
    L_ij = sqrt(p_i p_j) x_i^T A^(-1) x_j.

The matrix L is positive semidefinite. Let T have the ordinary L-ensemble determinantal distribution

    Pr(T) = det(L_T)/det(I+L),

with det(L_empty)=1. Define the event

    E = {T contains at most one item from each group}.

### Algorithm

1. Draw T from this ordinary DPP.
2. Reject and repeat when E fails.
3. For each group already represented in T, keep that item.
4. Independently fill each unrepresented group according to its categorical prior p.
5. Return the resulting complete design S.

A collision detected during sequential DPP sampling permits immediate rejection: later inclusions cannot undo it. This is an exact early-exit optimization, not an approximation.

### Theorem 1 — exact output law

In exact arithmetic, each accepted output has distribution mu. Independent proposal draws and completion randomness give independent outputs. No convergence or burn-in assumption is needed.

### Proof

Write y_i=A^(-1/2)x_i. Fix a feasible S. For any T subset S, its DPP numerator is

    det(L_T) = [product_{i in T} p_i] det(Y_T Y_T^T),

where Y_T has rows y_i^T. The probability of completing this T to S contributes product_{i in S\T} p_i. Summing over T subset S, the unnormalized output mass is consequently

    [product_{i in S} p_i] sum_{T subset S} det(Y_T Y_T^T).

The principal-minor expansion, or Cauchy–Binet identity, gives

    sum_{T subset S} det(Y_T Y_T^T)
      = det(I + Y_S^T Y_S)
      = det(A + sum_{i in S} x_i x_i^T)/det(A).

The remaining factors, det(A), det(I+L), and the rejection acceptance probability, do not depend on S. Normalization therefore gives exactly mu. Repeating independent trials establishes independence of successive outputs. ∎

The identity is a categorical restriction-and-completion construction related to the established DPP-plus-Bernoulli augmentation in regularized volume sampling [S4]. Neither that earlier augmentation nor ordinary DPP sampling is a new invention here. A bounded literature search did not establish priority for the exact categorical form plus the certificate below. Absence of a search hit is not a novelty proof.

## 4. A success certificate computed before sampling

Let

    K = L(I+L)^(-1).

This is the DPP marginal kernel. For distinct items i,j,

    Pr(i and j are both in T) = K_ii K_jj - K_ij^2.

Define

    C = sum_g sum_{i<j in G_g} (K_ii K_jj - K_ij^2),
    a_lower = max(0, 1-C).

### Theorem 2 — collision and work bound

If a=Pr(E), then

    a >= 1-C.

When C<1, the expected number of proposal draws per complete design is at most 1/(1-C). In particular, C<=1/2 certifies at most two proposals on average.

### Proof

Failure requires at least one pair of items from the same group to be present. A union bound over all these pairs proves Pr(not E)<=C. Independent retries have a geometric waiting time of mean 1/a. ∎

The certificate is not an unknown partition function. It is computed from supplied features and a d-by-d inverse. Indeed, put R=B^(-1) and h_ij=x_i^T R x_j. Then

    K_ii = p_i h_ii,
    K_ij^2 = p_i p_j h_ij^2,
    C = sum_g sum_{i<j in G_g} p_i p_j(h_ii h_jj - h_ij^2).

These quantities are rational when A, p, and X are rational. For two choices per group, they can be evaluated using matrix–vector products and one cross inner product per group. Large groups incur the cost of their within-group pair totals; that cost is not omitted.

The result is stronger than reporting an observed acceptance rate after a successful run, but weaker than a universal efficient sampler. C>=1 means the union-bound certificate is inconclusive, not that the target is invalid or that acceptance is zero.

## 5. An operational rational implementation

`exact_completion.py` avoids eigenvalue or square-root sampling oracles. Its initial matrix is

    R = (A + sum_i p_i x_i x_i^T)^(-1).

It scans items in a fixed order. Given the preceding inclusion/exclusion decisions, let z=R x_i, h=x_i^T z, and q=p_i h. Draw an exact Bernoulli(q).

If i is included, update

    R <- R - z z^T/h.

If i is excluded, update

    R <- R + p_i z z^T/(1-q).

Zero-probability branches are never taken; the code handles deterministic inclusions/exclusions explicitly. On inclusion, reject immediately if the item's group has already been represented.

### Why the low-rank updates are correct

Use the rational, generally nonsymmetric kernel

    K_tilde = diag(p) X R X^T.

It is diagonally similar to K and has the same principal minors. DPP conditioning on inclusion of i takes the Schur complement at K_tilde_ii. Conditioning on exclusion adds the corresponding rank-one term with denominator 1-K_tilde_ii. Substitution gives precisely the two updates above. They preserve all remaining conditional inclusion probabilities. This is a specialization of standard sequential DPP conditioning, not a claim to invent Schur complements [S5].

For q=a/b, the implementation draws ceil(log_2 b) fair bits to obtain an integer u, rejects integers u>=b, and accepts the item exactly when u<a. The integer-draw acceptance probability exceeds one half, so its expected number of trials is less than two. The generated bit count is returned, rather than treating exact random sampling as a free primitive.

The exact path uses `Fraction` and rational matrix inversion. Its interpretation is exact for the rational input actually supplied. Python's seeded generator is used for reproducibility and is modelled as a source of independent fair bits in the mathematical statement. The API also accepts `SystemRandom`. No real implementation's pseudorandom generator is claimed to be a theorem about independent physical randomness.

### Resources

In an arithmetic-operation model, preprocessing uses a weighted feature covariance and inversion, O(N d^2+d^3), plus the collision calculation. One sequential proposal uses O(N d^2) arithmetic operations and O(Nd+d^2) storage. For paired groups and C<1, the resulting expected arithmetic cost per output is

    O(N d^2/(1-C)),

in addition to preprocessing and the O(m) output/completion cost.

This is **not** a claim that operations on large fractions cost one CPU cycle. For rational B-bit input, conditional probabilities and updates can be expressed as ratios of minors of rational conditional-kernel matrices. Standard determinant/minor bit bounds give polynomial bit lengths in N,d,B. Rational Gaussian elimination and exact integer rejection therefore give polynomial expected bit complexity when 1/(1-C) is polynomially bounded. The executable counts random bits; recorded wall-clock benchmarks for the fast floating implementation are not presented as timings for this exact arithmetic path.

An outer proposal cap can report failure instead of continuing. No fallback distribution is substituted. For a>0, Pr(a single output needs more than t proposals)=(1-a)^t<=exp(-a_lower t). Thus a cap can be allocated explicitly. The probability of numerical or arithmetic failure is not silently counted as successful sampling.

## 6. Normalizers, expectations, and conditioning

The same expansion yields

    Z = det(B) a.

Therefore N independent proposal acceptance indicators give the unbiased estimator

    Z_hat = det(B) * accepted/N.

For 0<epsilon<1 and a>=a_lower>0, the multiplicative Chernoff bound gives

    Pr(|Z_hat/Z - 1| > epsilon)
        <= 2 exp(-N a_lower epsilon^2/3).

`normalizer_estimate` allocates N using exact rational comparisons and a conservative integer upper bound on the required logarithm. It refuses a requested accuracy if its computed proposal count exceeds the supplied resource budget. `normalizer_estimate_fixed` exposes N directly.

For bounded observables of the independently drawn designs, ordinary independent-sample concentration applies. This does not establish scientific accuracy for a misspecified physical model: it establishes sampling or integration accuracy for the specified distribution.

Conditioning on choices in some groups simply adds their information matrices to A and removes those groups. Nonuniform categorical priors and groups with more than two options are already covered by the identity. A null option can be represented by x_i=0. General budget constraints, arbitrary interactions between choices, quantum Born probabilities, or maximum-determinant optimization do not follow from this theorem.

## 7. Executable verification

`validation.py` checks all probabilities on a rational fixture with four two-option groups and three features.

- All 256 possible auxiliary DPP subsets were checked against the exact determinant formula, including zero-probability sets. The sequential recursion has 93 nonzero leaves.
- All 16 feasible complete-design weights matched the completion identity exactly.
- The exact collision sum was 8705/596873. The lower bound and actual acceptance both equalled 588168/596873 in this rank-three fixture. Equality here is a property of this small fixture, not a general claim that the union bound is exact.
- The rational sampler produced 1,000 designs in the recorded run using 1,014 proposals and 183,929 random bits. Its reference run took approximately 0.24 seconds on this container. This small-instance time is not extrapolated to large rational matrices.
- The separate defect sampler passed a 64-state exchange-degree and detailed-balance check; the maximum floating detailed-balance residual was approximately 2.17e-19.

These are implementation and algebra diagnostics. The all-input proof is the argument in Sections 3–5; finite tests are not substitutes for it, and neither is a formal verification.

## 8. Scientific-model benchmarks

The benchmark is a **model-based periodic diffusion experiment**, not an experimental dataset. A finite real Fourier representation of a one-dimensional periodic heat field is used. Diffusivity times observation time is 0.0003. Short wavelengths are attenuated by exp(-0.0003(2 pi k)^2). Each hardware unit has two permissible sensing sites.

Local layouts place the two options nearby. Irregular layouts make the second option a perturbed permutation of first-option locations. The larger benchmark has 32–128 groups and 8–16 explicitly supplied Fourier features; no algorithmic low-rank truncation is performed on these instances.

The fast completion implementation uses a thin SVD and Householder-updated projection-DPP draws. It is mathematically exact in ideal arithmetic, but its floating-point probability error is **not interval-enclosed**. The exact rational reference is a separate implementation.

The larger baseline is not a deliberately slow full-determinant Gibbs implementation. It uses rank-one inverse updates and periodic recomputation for numerical stabilization. Its burn-in of 20 sweeps and one-sweep output spacing are charged. They are heuristic choices, not certified mixing bounds.

Each case was run with five fixed seeds and 5,000 output designs per run, on one machine with one BLAS thread. Preprocessing is included in completion times. One-time compiler warm-up is excluded from per-run timing and is disclosed in the experiment metadata. Effective sample sizes (ESS) are autocorrelation diagnostics, not confidence guarantees for an arbitrary nonstationary chain.

| Groups / features | Layout | Acceptance lower bound | Observed acceptance, median | Completion seconds | Gibbs seconds | Median ESS/sec ratio, first-choice indicator |
|---|---|---:|---:|---:|---:|---:|
| 32 / 8 | Irregular | 0.6081 | 0.6519 | 0.0372 | 0.0682 | 3.35 |
| 64 / 16 | Local | 0.9910 | 0.9911 | 0.1238 | 0.2509 | 4.52 |
| 64 / 16 | Irregular | 0.0913 | 0.3602 | 0.2626 | 0.2509 | 2.07 |
| 128 / 16 | Irregular | 0.5618 | 0.6342 | 0.3402 | 0.4862 | 2.99 |

Ratios are medians of per-run ESS rates, not ratios of separately averaged quantities. They describe this implementation, these observables, and these fixtures. The 64-group irregular case is slower in raw time per 5,000 outputs; its estimated advantage arises from lower correlation. A general speedup over all current methods is not established.

The earlier 12-group runs also include exact enumeration, two-pair Gibbs, multiscale jumps, and eight-temperature replica exchange. The defect method was not consistently competitive. Completion likewise performs badly on the irregular high-information cases where C exceeds one. All outcomes are retained in `results/`.

## 9. A precise exponential failure family

The restriction C<1 is substantive. For n>=3, give hardware group i the two features sqrt(beta)e_i and sqrt(beta)e_{i+1}, with cyclic indices, uniform categorical priors, and A=I. Then B=(1+beta)I.

Writing a bit for each choice, a transfer-matrix calculation gives

    a = 2^(-n) [(1+r)^n + (1-r)^n],
    r = sqrt(1+2 beta)/(1+beta).

The transfer matrix is [[1+beta, 1], [1+2 beta, 1+beta]]. Its trace to the nth power sums the complete-design determinant weights.

As beta tends to infinity, a tends to 2^(1-n). More strongly, for beta>=3n^2 we have r<=1/n and

    a <= (e+1) 2^(-n) < 4 * 2^(-n).

Thus rejection can be exponential even when the numerical signal parameter is only polynomial in n and its binary description is short. This is not an artifact of requiring an astronomically represented input.

This cycle itself has a simple specialized transfer-matrix method. It is therefore a counterexample to universal efficiency of this sampler, not evidence that the underlying scientific task is universally hard or that it beats specialized algorithms. In the 12-group perturbed-cycle numerical test at beta=10,000, acceptance was about 0.000502 and multiscale/tempering baselines were stronger.

## 10. Scope and novelty verdict

The operational result is a constrained determinant sampler with an explicit nonasymptotic gate for independent, rejection-efficient sampling and normalizer estimation. It has an exact rational executable path as well as a faster, separately qualified floating implementation.

The historical position is more limited:

1. Unconstrained DPP sampling, Schur-complement conditioning, determinant expansions, and DPP/Bernoulli augmentation are established techniques [S4,S5].
2. General mixed-discriminant approximation is already claimed by the 5 October paper [S3]; it cannot be credited to this investigation.
3. Priority for the particular categorical completion identity plus collision certificate has not been established. It should not be represented as a proven new foundational theorem.
4. The practical evidence is modest, input-dependent, and model-based. It establishes neither a broad scientific capability unavailable to all previous methods nor a historic-scale breakthrough.

The mission's foundational objective remains unmet for concrete reasons: overlapping prior work, an explicit exponential failure family, incomplete priority clearance, and limited comparative evidence. The supplied algorithm, proofs, tests, and failed experiments are complete research artifacts for the stated scope, not a promise of later validation.

## References and pinned provenance

**[S1] Astra research knowledge.** Revision `7e08c9fc917a684a437155abd2c790d5f5ff2d99`. Started at `00_START_HERE.txt`. Read N190's current status and the full underlying `DETERMINANT_LIFT_FINAL.txt` via `web/pages/d-fab535e71046fcca.html`. Page blob `479a0f3efd4c6b1893dd29fa4e5b74ff21d66333`. The historical original and object paths returned 404; the indexed exact-text page was available. Its source status is source-derived/unreviewed, not externally verified.

**[S2] OpenAI mathematics repository.** Revision `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`. `preprints/Approximate-counting-of-common-bases-of-two-matroids-September-23-2026/build/main.tex`, blob `dcfd7658e2aa165774ea1f41430e8f1d5574d128`. Relevant coefficient, transport, observable-Poincare, trace, and annealing sections were read. No Lean verification was run.

**[S3] Xiaoyu Chen and Kuikui Liu.** *An FPRAS for Counting Common Bases of Two Matroids*. arXiv:2610.06724v1, submitted 5 October 2026. In particular, Appendix C.5 discusses mixed discriminants and determinantal point processes. This is an externally retrieved preprint, not a theorem independently audited in full here.

**[S4] Michal Derezinski, Feynman Liang, and Michael Mahoney.** *Bayesian experimental design using regularized determinantal point processes*. AISTATS 2020, PMLR 108:3197–3207; arXiv:1906.04133. The DPP-plus-Bernoulli decomposition is a close conceptual predecessor.

**[S5] Claire Launay, Bruno Galerne, and Agnes Desolneux.** *Exact sampling of determinantal point processes without eigendecomposition*. arXiv:1802.08429; Journal of Applied Probability. Sequential DPP conditioning and factorization-based sampling are established. Also consult *Nystrom landmark sampling and regularized Christoffel functions*, Machine Learning (2022), for the conditional-kernel viewpoint.

**[S6] L. Elisa Celis, Amit Deshpande, Tarun Kathuria, Damian Straszak, and Nisheeth K. Vishnoi.** *On the Complexity of Constrained Determinantal Point Processes*. arXiv:1608.00554v3 / APPROX-RANDOM 2017. Useful historical baseline; its statements about then-open approximation questions are not treated as current after [S3].

Machine-readable source URLs, access notes, and revisions are in `source_ledger.json`. Numerical inputs, seeds, timings, source code, and claim statuses are retained locally. Neither remote repository was modified.
