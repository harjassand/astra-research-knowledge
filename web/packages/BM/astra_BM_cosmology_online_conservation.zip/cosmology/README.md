# Scientific investigation packet — 9 October 2026

**Outcome: no foundational natural-science discovery established.**

Read `RESULT.md` for the derivation, numerical results, provenance, failed data-access routes, prior-art boundaries, and what was not established.

## Reproduce

Python 3 with NumPy and SciPy is sufficient. From this directory:

```sh
python explore_bao.py
python validate_results.py
python test_envelopes.py
python envelope_fit.py
```

`validate_results.py` checks both source data hashes and repeats the three physical model fits. `test_envelopes.py` is a mathematical implementation test, not simulated empirical evidence. `envelope_fit.py` performs exploratory constrained fits, not certified optimization or significance calibration.

The text files under `data/` are the actual released DESI DR2 mean vector and covariance, verified byte-for-byte against their Git blob hashes. There are no supernova likelihood data in this packet. `sources/data_manifest.json` records source URLs and hashes.

`results/validation.json` contains the independently repeated fit numbers. `results/envelope_fits.json` preserves optimizer success and feasibility diagnostics, including unsuccessful convergence flags. The numerical environment is recorded in `sources/environment.json`.

All mathematical statements are conditional on their explicit assumptions. The main interval proof is supplied in the note; no external review, formal proof certification, historical novelty, or new natural law is claimed.
