# Independent mathematical investigation: a quantitative PPT decomposition obstruction

**Date:** 8 October 2026. **Repository:** [harjassand/astra-research-knowledge](https://github.com/harjassand/astra-research-knowledge/tree/d20c4b040f63c2fb0c8da76362046d1946d0a2b9). **Pinned commit:** `d20c4b040f63c2fb0c8da76362046d1946d0a2b9`.

The strongest outcome is a reconstructed quantitative obstruction to a proposed route toward the PPT composition conjectures. The rank permitted in a completely positive plus transposed-completely-positive decomposition must grow linearly with the local dimension if that class is to contain every PPT channel. The argument includes an explicit constant and applies to unital trace-preserving channels. It does **not** resolve PPT squared, PPT cubed, NPT bound entanglement, or the group-entropy questions. Historical novelty and external correctness review remain unknown.

[PROOF.md](PROOF.md) contains the complete analytical derivation. [CHECK_RESULTS.json](CHECK_RESULTS.json) contains the exact and finite checks, and [verify_obstruction.py](verify_obstruction.py) reproduces them. [SOURCES.json](SOURCES.json) records versions and read scope. Repository captures, their Git blob hashes, and a SHA-256 manifest are included in the packet.

## Starting contract and evidence boundary

The goal was to find a mathematically substantial, testable mechanism after comparing distinct frontier problems, then preserve either a proof or a precise obstruction. The stopping condition was a complete scoped argument, meaningful checks, an honest source audit, and a useful continuation route; a famous-conjecture solution was never presumed.

`00_START_HERE.txt` was read first. The investigation then followed topic routes, current review wrappers, priorities, upstream notices, and selected decisive proof ranges. The repository was pinned before using its contents. Its latest-at-start commit has timestamp `2026-10-08T11:06:57Z` and message “Integrate universal noise probes and outstanding research branches.” Seventeen task-relevant files are preserved byte-for-byte and verified against their Git blob SHA-1 identifiers. This is a selected capture, not a full repository clone or completeness audit of its 282 cards.

The linked prior conversation itself was not retrieved. Continuity comes from the repository's current notices and captured research packets. Older archived statements are evidence to assess, not instructions or certified premises. Source-reported checks, checks performed in this run, proof availability, external review, and historical priority are different fields. No subagents or external referees participated, and no remote repository was changed.

## Frontier comparison and allocation

The investigation compared three major open directions and a narrower stochastic-network lead. The judgments below concern the acquired evidence and the next mathematical obligation, not a ranking of the fields' importance.

| Direction | Mechanism examined | Decisive obligation or obstruction | Decision |
|---|---|---|---|
| Bernoulli classification and Rokhlin entropy beyond sofic groups | N169 defect-kernel splitting and finite-model rank obstruction, with N165/N166 corrections | An algebraic splitting does not construct a measurable Bernoulli conjugacy or decide the original group's entropy. The original group construction was not independently replayed. | Keep conditional; obtain the specific group and an entropy certificate before advancing classification claims. |
| NPT bound entanglement | Whether the N195 factorial-spin sequence or finite-copy Werner results supply an all-copy obstruction | A multipartite sequence separable across every singleton cut is not an NPT bipartite bound-entangled example. For NPT nondistillability, a Schmidt-rank-two inequality must hold for every tensor power. | Reject the shortcut; an invariant tensor-power mechanism is still missing. |
| PPT composition and dimension-free entanglement-breaking bounds | Recent decomposition cone `DSP_k = SP_k + transpose o SP_k`; dual simultaneous positivity | High Schmidt number alone is insufficient. A witness must control both low-rank vectors and their partial-transposed image. Gaussian width gives that control. | Select and reconstruct a quantitative obstruction. |
| Critical stochastic explosion in catalytic mass-action networks | N209 balanced Lamperti drift plus state-dependent clock | The candidate needs uniform excursion and unbounded-tail control. The broad strongly-endotactic explosion phenomenon is already known. N212 is a later source notice, not a proof replayed here. | Preserve as a narrower continuation; do not relabel the known broad phenomenon as a new major solution. |

For the group branch, Seward's *Krieger II*, Theorem 1.10, supplies the Bernoulli entropy interface; Corollary 7.7 confirms the current correction: `h_sup=0` excludes positive free ergodic Rokhlin entropy, including infinite entropy. That correction supersedes the contrary caveat in the older captured N169 proof. It still does not decide the particular group's entropy or prove conjugacy. *Weak containment and Rokhlin entropy*, Theorem 1.5, is an upper-bound interface, not a positive lower-bound certificate.

For the NPT branch, the July 2026 Fu–Gao–Park preprint is recorded as a claimed two-copy result whose proof was not independently reconstructed here. The all-copy criterion is the relevant remaining obligation. Finite-copy claims must not be promoted to NPT bound entanglement. The N195 input instead supports a different, channel-noise question; its source explicitly restricts entanglement depth to two and warns of exponential filtering cost.

For the reaction-network branch, Anderson–Cappelletti–Kim–Nguyen, arXiv:1808.05328v2, Example 3.2, already supplies a strongly endotactic explosive network. The cycle probability and summable holding-time mechanism were inspected. The exact parameter boundary in N209 was not certified by that precedent or by this run.

## Selected result and its meaning

On `C^d tensor C^d`, let `S_k` be the trace-one states of Schmidt number at most `k`, and let `Gamma` denote partial transpose. Define

\[
\mathcal D_k=\operatorname{conv}(S_k\cup S_k^\Gamma).
\]

This set includes indefinite matrices: it models the entire normalized sum cone, not just states whose Schmidt number is bounded. Let `k_*(d)` be the smallest rank allowance for which every PPT map on `M_d` belongs to `DSP_k`.

The analytical argument in PROOF.md gives, for every `d >= 2^24` and `1 <= k <= floor(d/2^24)`, a strictly PPT state with both marginals `I/d` such that

\[
\inf_{X\in\mathcal D_k}\frac12\|\rho-X\|_1\ge\frac1{576}.
\]

Consequently,

\[
\lfloor d/2^{24}\rfloor+1\le k_*(d)\le d,
\qquad k_*(d)=\Theta(d).
\]

The lower bound holds even when the PPT input class is restricted to unital trace-preserving channels. A dual witness is simultaneously `k`-positive and `k`-copositive but indecomposable. This rules out a universal fixed-rank inclusion, including fixed rank two or three, as a proof route. It leaves the small-dimensional inclusion `PPT(4,4) subset DSP_2(4,4)` undecided.

The construction is a standard Gaussian perturbation adapted to the two-sided cone. A Gaussian matrix `G` is projected to the subspace with both partial traces zero, and

\[
\rho=d^{-2}(I+G/(9d)).
\]

An elementary rank-vector net and direct chaining bound control the support function of both `S_k` and `S_k^Gamma` by `O(sqrt(dk))`. Positivity and PPT require only an `O(d)` spectral bound. The target's pairing with `G` is also of order `d`. Their separation gives the rank obstruction and the quantitative trace-norm gap. The zero-partial-trace projection supplies the exact channel normalization without filtering.

The same construction admits an entanglement-breaking square. After reshuffling its Choi matrix, write `Phi=Delta+E` with `Delta E=E Delta=0`. The proof gives

\[
\|C_{\Phi^2}-I/d\|_F
\le\|E\|_{\mathrm{op}}\|E\|_F
\le\frac{32}{81d}<\frac1d.
\]

The Gurvits–Barnum separable ball then certifies the square. This explains the precise failure scope: an individual channel's large decomposition rank does not imply entanglement survives composition.

There is also a finite-family extension. Even a fixed family of at most exponentially many Hilbert-space isometries fixing the identity cannot cover all PPT states using small-rank pieces, under the explicit bounds in PROOF.md §8. The family must be fixed before the random target is drawn. Adaptive representation changes and arbitrary filtering are outside that result.

## Source audit and originality

Park's arXiv:2608.13551v2, Question 5.11, supplies the exact cone question; Example 5.10 explains why large Schmidt number alone can be misleading. Its decomposition-to-composition implication is context, not a premise needed for the separation proof.

Huber–Lami–Lancien–Müller-Hermes, arXiv:1802.04975v1, §IV, already develops Gaussian PPT states with linearly growing Schmidt number. Collins–Hayden–Nechita, arXiv:1505.08042v1, §5, is earlier relevant Gaussian positive-map work. These are substantial antecedents. The present separation is an adaptation, with simultaneous partial-transpose control and exact channel marginals; the width mechanism itself is not claimed new. A targeted search did not clear historical priority. A no-hit search would not do so either.

The only non-elementary imported mathematical premise used in the square certificate is Gurvits–Barnum, arXiv:quant-ph/0204159v2, Theorem 1. Its Frobenius normalization and proof were inspected. The covering, Gaussian tails, chaining, projection, dual separation, and reshuffling argument are reconstructed directly in PROOF.md.

The tempting structured alternative was rejected exactly. For a `k`-Breuer–Hall Choi witness in even dimension, a Bell vector on a symplectic pair has Schmidt rank two and partial-transposed expectation `1-k`. At `d=6,k=2`, this is `-1`. Such a witness cannot supply simultaneous two-positivity and two-copositivity. The Gaussian construction resolves the obligation that this shortcut fails.

## Checks performed and their limits

The recorded command was `python3 research/verify_obstruction.py`. It passed exact constant arithmetic, an exact symbolic rejection of the Breuer–Hall shortcut, and seeded numerical convention/channel checks at dimensions `2,3,4,8,12,16`. Every tested channel was strictly PPT and bistochastic, and every tested square satisfied the separable-ball criterion. Choi normalization, both partial traces, partial-transpose adjointness, projection idempotence, reshuffling, and the cross-term cancellation were checked. Environment versions and raw residuals are preserved in CHECK_RESULTS.json.

The falsifiers were a failed integer inequality, a nonnegative expectation for the proposed negative test vector, a normalization or reshape residual above tolerance, or failure of a claimed square certificate. An early wrong choice of Bell vector was caught by an assertion and corrected to the symplectic pair. Snapshot hashing also caught newline changes introduced during copying; the saved source bytes were restored and all seventeen Git blob hashes then matched.

No global numerical optimization over all low-Schmidt-rank vectors was performed. The finite examples do not certify the cone obstruction and are not examples at the theorem's sufficient dimension. The all-dimension conclusion comes from the analytical probability bounds. There is no specialist review, proof-assistant verification, practical large-dimensional matrix, or exhaustive literature search in this packet.

For scale, storing a dense `d^2 by d^2` complex matrix costs `16d^4` bytes, and a dense eigendecomposition has order `d^6` arithmetic cost. At `d=2^24`, storage alone is `2^100` bytes. The probabilistic existence proof therefore supplies no feasible materialization algorithm at its conservative threshold. Nets in the proof are mathematical bounds, not enumerated computation.

## Continuation routes with decision gates

1. **Independent correctness and priority review.** Check the Stiefel operator-norm covering argument, the covariance after projection, the two-image chaining bound, and the complex reshuffling tail. Compare the exact two-sided cone statement with prior positive-map literature. A single failed hypothesis or earlier exact theorem should change the status immediately. Preserve this record and append a correction rather than silently rewriting history.

2. **A practical explicit counterexample.** Start with `d=4` or `6`, optimize a Hermitian `G` with both partial traces zero, and seek strict simultaneous low-rank witness bounds plus a negative PPT pairing. Sampling vectors only suggests a candidate. Acceptance requires a global certificate, such as an exact symmetry reduction, certified polynomial bound, or justified interval covering. Export rational matrices and check positivity and negative pairing exactly. If global control fails, the experiment is inconclusive, not evidence for inclusion.

3. **Sharper dimension dependence.** Improve the spectral and chaining constants, or use established sharp Gaussian widths with their normalization independently verified. The worthwhile target is an explicit upper or lower slope for `k_*(d)/d`, not merely removal of the conservative `2^24`. Every improvement must continue to control both partial-transposed support functions and both exact marginals.

4. **Composition-sensitive structure.** Search for PPT channels far enough from the depolarizing channel that the bound `||E_2||op ||E_1||F <= 1/d` fails, while retaining an exact witness on their composition. Failure of this sufficient ball bound does not prove entanglement. A counterexample needs two explicit PPT Choi matrices, their exactly computed composite, and a certified negative separability witness. A positive theorem needs a new argument controlling the composite rather than a false universal `DSP_2` inclusion.

5. **All-copy NPT route.** At the Werner endpoint, identify a certificate stable under tensor powers and Schmidt-rank-two contractions. The next useful falsifier is a three-copy witness violating that certificate. Partial trace can increase rank, so a two-copy matrix inequality cannot simply be iterated. This task is separate from the strictly PPT Gaussian construction.

6. **Return to the repository's other branches.** For the original group, acquire actual supports and a valid entropy-sign theorem before attempting conjugacy. Respect the current Corollary 7.7 correction and the unresolved positive-characteristic citation issue. For the catalytic network, audit the latest N212 source and uniform unbounded excursion tails before accepting the all-rate classification. For factorial noise probes, an unfiltered nonunital distinguishability bound would close a real operational gap; binary survival obtained through exponentially rare filtering does not.

The durable conclusion is a precise rank obstruction with a complete reconstructed argument and bounded checks. Its scientific status remains an unreviewed derivation with unknown priority. No major breakthrough is asserted.
