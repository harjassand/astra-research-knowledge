# Investigation packet

Begin with [RESEARCH_STATE.md](RESEARCH_STATE.md), then [PROOF.md](PROOF.md). The result is a quantitative obstruction to fixed-rank PPT decompositions, with an entanglement-breaking-square limitation. It is an unreviewed analytical derivation; historical priority is unknown. No major-conjecture solution is asserted.

The repository baseline is `harjassand/astra-research-knowledge` at `d20c4b040f63c2fb0c8da76362046d1946d0a2b9`. The selected captures in `pinned_repository/` match the Git blob hashes in `REPOSITORY_SNAPSHOTS.json`. `extracted/` contains readable payloads from four captured HTML pages, not new versions of the source evidence.

With the recorded NumPy and SymPy versions available, reproduce the checks from an extracted copy of this packet:

```sh
python3 verify_obstruction.py
```

The command writes `CHECK_RESULTS.json` alongside the script. Keep the original results before rerunning if a comparison is desired. Finite numerical residuals may vary with platform; these checks use tolerances, not a claim of byte-identical numerical reproduction. The all-dimension proof is analytical and is not a finite numerical test.

`SOURCES.json` records primary URLs, versions, passages, and audit limits. `SESSION.json` records inherited versus acquired information and corrections. `BRIDGE.json` specifies the next small-dimensional certification experiment. `MANIFEST.json` hashes every payload except itself; the outer ZIP is also excluded to avoid self-reference.

Primary papers are linked rather than copied. No external-paper byte snapshot, exhaustive historical search, specialist review, or remote GitHub update is claimed.
