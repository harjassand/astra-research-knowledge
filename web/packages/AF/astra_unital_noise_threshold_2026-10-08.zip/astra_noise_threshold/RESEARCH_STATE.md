# Restart state: unital-noise boundary investigation

## What is delivered

The strongest result is Theorem 1 in `THEOREM_AND_PROOF.md`: an exact threshold at squared Bloch Frobenius norm one, with finite-N separability on one side and a nonzero asymptotic three-axis local-measurement separation on the other. It applies to the maximally-mixed-input selected collective-thermal stationary state and fixed identical unital local channels. The entangled side assumes bath occupation o(sqrt N). With bath occupation at least (sqrt15-3)/6, the entangled outputs are singleton-separable and depth exactly two.

Status: self-contained internal mathematical derivation, not externally established priority or specialist validation. No parallel agents were used. No Lean proof was produced. Symbolic polynomial equalities in a finite range are not a formalization of the asymptotic theorem.

## Pinned capital and selection

Astra commit: ca22fffaeab073aaa1bbb690ce1b4250fc272956, dated 2026-10-08T07:15:38Z.
OpenAI release orientation snapshot: adc7f1241b42e322a6451854ab7e4b4c146bf78a.

Read Astra start guide, selective core orientation, topic routing, candidate bridge records, the complete current square-root-bath state, selected quantum cards, and the relevant sections of the original thermal proof checkpoint. The source table records the paths and read depths. The complete corpus and all release manuscripts were not loaded or audited.

Opportunities compared:

1. **Statistical experiment compression:** N31's weak-ellipsoid spectral law and posterior/reference-preserving kernel mechanism. Important potential for retaining information in inverse problems, but the full original proof package was absent. Sharp constants and finite-bit acquisition would require fresh foundational work. This was screened, not independently verified.
2. **Quantum memory at eigenvalue collisions:** N148's actual moving-gap qutrit law. Potentially significant representation-theoretic precision transition, but extension to other collisions requires a joint score/heat-kernel argument with counted classical labels. The card does not authorize such a transfer. Screened, not proved or falsified here.
3. **Collective thermal fluctuations:** current Maxwell/Wright–Fisher state and N130–N136. The noise-boundary gap had an exact finite-pair upper bound and a potentially removable variance obstruction. Selected for deep work. The Gaussian-mixture perspective was useful, but none of the Gaussian memory cards is a proof premise.
4. **Rare-event positive-kernel sampling:** the bridge record explicitly blocks transferring unconditional additive simulation to relative heralded sampling. No new relative-counting service was obtained, so this was not pursued as if the bridge already existed.

The wider mathematical ambitions in the core guided this selection. This run is not presented as a systematic proof audit of every discipline or as a result proved using a new OpenAI theorem. The official release and its pinned README were inspected; release verification status was not imported into this theorem.

## Dependency graph

Classical spin decomposition and detailed balance
  -> selected stationary formula
  -> positive symmetric Gibbs decomposition + singlet-pair twirl
  -> exact finite-N separability for tr(TT^T)<=1.

Same decomposition + binomial/Maxwell spin weights + nu_N=o(sqrt N)
  -> collective Gaussian-plus-one-sided-radius limit.

Product Bloch-vector Taylor expansion + tightness
  -> common separable Gaussian-mixture variance constraint.

One-sided Gaussian tail lemma + trace variance deficit
  -> no separable limiting triple
  -> positive three-axis measurement distance and trace distance.

Explicit rest-spin qubit block/twirl calculation
  -> singleton separability for nu>=nu_*
  -> bound entanglement and exact depth two on entangled side.

Separate product-filter Taylor proof + exact depolarizing finite-N formulas
  -> independent mathematical route to eventual entanglement and executable checks.

The proof does NOT use the candidate 1/4 logN entanglement entropy law, the transient diffusion limit, the full all-time thermal preservation theorem, a release family-197 result, or a counting oracle.

## Falsification and failed-route ledger

* An initial possible “new” all-time depth-two insight was found already in N120. It was discarded as a novelty claim.
* Surviving entanglement in each hidden noisy pair does NOT prove that their unrecorded mixture is entangled. The fluctuation/tail argument is the missing step.
* The old unfiltered variance witness loses the Maxwell radius variance. Its 0.626657 threshold was only sufficient. It cannot refute entanglement in (1/sqrt3,0.626657].
* At the exact boundary tr(TT^T)=1, an explicit full-separable decomposition exists. The proof uses a strict trace deficit and makes no contrary claim there. Finite t filter diagnostics remain on the separable side at that boundary.
* Taking a filter parameter to infinity at fixed N is not the asymptotic argument. The order is fixed t, then large N.
* A filtered variance violation alone does not imply a nonvanishing unfiltered trace-distance gap, because filter success may vanish. The gap is separately proved with bounded local measurements.
* Weak convergence of discrete counts is not convergence in TV to a continuous Gaussian density. TV in the theorem compares two finite-N measurement laws on the same sample space.
* Separable alternatives may have arbitrary classical correlations and heterogeneous product factors. The proof keeps a COMMON mixture of Gaussian means and variances; a single-Gaussian approximation or independent axis-specific mixtures would be invalid.
* Characteristic limits are not simultaneous quantum measurements. Only three separately chosen one-axis measurements are used operationally.
* The stationary state is selected by the input, not the generator's unique invariant state for arbitrary input.
* Nonunital extension is not automatic. Extensive mean, limiting commutators, and filtering-induced spin-sector tilts change. No theorem for that case is claimed.
* A local-noise-during-preparation perturbation breaks the conserved-sector interface. Post-preparation robustness does not solve it.
* Numerical work used dense small-N matrices and sector formulas, not physical N=10^8 states or a proof assistant.

## Executions

Both scripts were run successfully after an initial JSON serialization issue was fixed. `run_log.txt`, `results.json`, and `characteristic_results.json` contain actual outputs. Numeric libraries and Python version are recorded in the first results file. Seeds: 8102026 for random pair maps; 8112026 for characteristic checks.

There are 216 filtered-moment dense checks, 90 characteristic dense checks, 500 pair-PPT checks, and 90 exact symbolic Bernstein identities. There are also 24 large-N filtered-moment and 36 large-N characteristic diagnostics. These are internal checks, not independent verification by other researchers.

## Unresolved obligations, in priority order

1. External mathematical review, particularly common Gaussian-mixture tightness and the three-marginal tail obstruction. These are fully written proofs, not missing premises, but remain unreviewed.
2. Historical novelty audit of collective fluctuation separability, permutation-invariant states under noise, and local-filtered collective witnesses. The known unital two-qubit boundary must remain explicitly credited.
3. Compile certified bounded three-axis scores, quantify the positive distance, and obtain a finite-N threshold with explicit dependence on s-1 and bath occupation. This is the highest-value mathematical continuation because it avoids the explicit filter's exp(-t sqrt N/2) success cost.
4. Study the joint limit as the channel approaches its boundary with N. Fixed-channel convergence does not give a critical finite-size scaling exponent.
5. Determine the entanglement entropy/distance regime under fixed nonzero noise; positive limiting distance is neither near-unit distance nor a logN lower bound.
6. Establish preparation rates and tolerances under realistic additional noise. Convergence to the stationary state alone gives existence of sufficiently late finite times, not a useful laboratory time bound.

## Artifact policy

No repository files were changed or pushed. This packet is a local handoff. `PROPOSED_CARD.txt` is deliberately not assigned a numeric Astra identifier. Source URLs are pinned where applicable. The manifest hashes the final artifact contents and does not confer mathematical validity.
