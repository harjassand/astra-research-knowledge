# Collective-thermal unital-noise threshold: reproducible research packet

Start with `THEOREM_AND_PROOF.md`. The main conclusion is an exact local-noise boundary for the specified stationary family, including a positive three-setting local-measurement separation above the boundary. It is an internally derived, unreviewed result; historical novelty is not established.

The familiar two-qubit threshold is credited to the primary literature. The proposed new contribution is its attainment by this many-body thermal bound-entangled family and the fluctuation-tail proof of the converse.

## Reproduce

Use Python 3.13 (tested with 3.13.5). Create an environment and install `requirements.txt`, then run:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python verify_threshold.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python verify_characteristics.py
```

These regenerate `results.json` and `characteristic_results.json`. They use dense matrices only for N<=7 and Schur-sector formulas for the much larger diagnostic N. No external data or network connection is needed. Both scripts were executed in the delivered environment; versions appear in `results.json`. Floating-point tests are not rigorous interval certificates. SymPy checks only the explicitly stated finite set of identities.

## Contents

- `THEOREM_AND_PROOF.md`: exact statement, complete main proof, separate filter proof, finite-N formulas, costs and limits.
- `RESEARCH_STATE.md`: selection, dependency graph, falsification ledger and unresolved obligations.
- `PROPOSED_CARD.txt`: scoped proposed Astra card, without a numerical ID.
- `SOURCES.json`: pinned repository sources, primary sources, and read-depth limitations.
- `verify_threshold.py`, `verify_characteristics.py`: executable checks.
- `results.json`, `characteristic_results.json`, `run_log.txt`: actual successful-run outputs.
- `requirements.txt`: versions used in this environment.
- `SHA256SUMS.txt`: file integrity hashes, not proof certification.

Astra source commit: `ca22fffaeab073aaa1bbb690ce1b4250fc272956`.
No changes were pushed to the user's repository. No other model, subagent, or human independently verified this investigation.
