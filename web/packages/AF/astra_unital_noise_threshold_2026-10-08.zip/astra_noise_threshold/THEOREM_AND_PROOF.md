# A sharp unital-noise boundary for collective-thermal bound entanglement

**Research date:** 8 October 2026.  
**Astra revision:** `ca22fffaeab073aaa1bbb690ce1b4250fc272956`.  
**Status:** mathematical derivation and newly executed internal diagnostics. No external referee, independent agent, or proof assistant has verified the new theorem. Historical priority remains unresolved. The numerical value of the two-qubit channel boundary is established prior work; its attainment by the particular many-body thermal family, with a three-setting local-measurement separation, is the proposed advance.

This note contains the entire main argument. It does not require an unverified theorem from the October 2026 OpenAI release, nor any of Astra's more recent entropy or dynamical-limit claims. Those resources guided selection, not the proof's validity.

## 1. Exact statement

Write

\[
J_a=\frac12\sum_{i=1}^N\sigma_a^{(i)},\qquad
\mathcal D[L](\rho)=L\rho L^\dagger-\tfrac12\{L^\dagger L,\rho\}.
\]

Let \(\rho_{N,\nu}\) be the stationary state selected from \(I/2^N\) by

\[
\mathcal L_\nu=(\nu+1)\mathcal D[J_-]+\nu\mathcal D[J_+].
\]

The jumps are unnormalized. Multiplying the generator by a positive rate changes preparation time, not the selected state. Uniform couplings, no drive, and no additional noise during preparation are assumptions. The case \(\nu=0\) is interpreted directly as collective decay or as the limit of the displayed stationary formula.

Let \(\Lambda\) be a **fixed unital qubit CPTP map**, with real Bloch matrix \(T\):

\[
\Lambda((I+r\cdot\sigma)/2)=(I+(Tr)\cdot\sigma)/2.
\]

Define

\[
K=TT^T,\qquad s=\operatorname{tr}K,\qquad
\omega_N=\Lambda^{\otimes N}(\rho_{N,\nu_N}).
\]

The same channel acts independently at every site, **after** preparation. Let \(\mathrm{SEP}_N\) denote full separability across the N individual qubits.

### Theorem 1 — exact boundary and operational separation

**(a) Below and at the boundary.** If \(s\le1\), then \(\omega_N\in\mathrm{SEP}_N\) for every N and every finite \(\nu_N\ge0\).

**(b) Above the boundary.** If \(s>1\) and \(\nu_N=o(\sqrt N)\), then \(\omega_N\notin\mathrm{SEP}_N\) for all sufficiently large N. More strongly, consider the fixed measurement \(\mathcal M_N\) that chooses one of three orthonormal spatial axes uniformly, measures each qubit along that axis, and records the axis and the sum divided by \(\sqrt N\). Then

\[
\liminf_{N\to\infty}\inf_{\sigma\in\mathrm{SEP}_N}
\operatorname{TV}\big(\mathcal M_N(\omega_N),\mathcal M_N(\sigma)\big)>0.
\tag{1}
\]

In particular,

\[
\liminf_N\inf_{\sigma\in\mathrm{SEP}_N}
\tfrac12\|\omega_N-\sigma\|_1>0.
\tag{2}
\]

The gap is allowed to depend on T. Neither a uniform lower bound as \(s\downarrow1\) nor convergence of the distance to one is asserted. The discrete measurement laws are compared at each finite N; they are **not** claimed to converge in total variation to continuous Gaussian laws.

**(c) Bound-entangled attainment.** If additionally \(\nu_N\ge\nu_*=(\sqrt{15}-3)/6\) for all sufficiently large N, then the states in (b) are separable across every singleton-versus-rest cut and have entanglement depth exactly two. They are nevertheless not fully separable. Thus they are multipartite bound entangled when all N laboratories remain separate. This is not a claim about NPT bound entanglement, genuine N-party entanglement, or distillation when parties can join into groups.

### Corollaries

For depolarization \(T=\lambda I\), \(0\le\lambda\le1\),

\[
\boxed{\lambda_c=1/\sqrt3.}
\]

At or below \(\lambda_c\), the outputs are fully separable for every N. Above it, they are eventually entangled in the subcritical-bath regime, including the fixed-temperature bound-entangled family \(\nu=1\).

For phase damping \(T=\operatorname{diag}(\eta,\eta,1)\), every fixed \(\eta\ne0\) preserves entanglement for sufficiently large N; complete dephasing \(\eta=0\) yields full separability. Neither statement is uniform as the channel parameter approaches its boundary with N.

Filippov–Rybár–Ziman's established two-qubit result identifies \(s\le1\) as the identical-unital-channel entanglement-annihilation boundary. Therefore the theorem's family attains, asymptotically, the noise boundary attainable by a Bell pair, despite being singleton-separable and undistillable by separated laboratories in part (c). This is **not** a new classification of those channels.

## 2. Reconstructing the stationary state and hidden-pair decomposition

Schur–Weyl decomposition gives

\[
(\mathbb C^2)^{\otimes N}=\bigoplus_j V_j\otimes\mathbb C^{d_{Nj}},\quad
 d_{Nj}=\binom N{N/2-j}-\binom N{N/2-j-1}.
\]

Put \(M=2j\), with the parity of N. Collective operators act on \(V_j\) and leave its multiplicity register unchanged. In the basis \(k=m+j\), transitions are

\[
\lambda_k=\nu(M-k)(k+1),\qquad
\mu_k=(\nu+1)k(M-k+1).
\]

The initial block state is uniform. Detailed balance gives the selected distribution proportional to \(q^k\), \(q=\nu/(\nu+1)\). Thus, with \(\beta=\log(1+1/\nu)\),

\[
\rho_{N,\nu}=\bigoplus_j w_{Nj}\,
\frac{e^{-\beta J_z^{(j)}}}{Z_j(\beta)}\otimes\frac{I_{d_{Nj}}}{d_{Nj}},
\quad w_{Nj}=\frac{(2j+1)d_{Nj}}{2^N},
\quad Z_j=\sum_{m=-j}^j e^{-\beta m}.
\tag{3}
\]

This is not a unique stationary state for arbitrary inputs.

Let \(S=|\psi^-\rangle\langle\psi^-|\), and let \(\tau_{M,\beta}\) be the symmetric M-qubit Gibbs state in (3). It is fully separable: start with

\[
P_{\rm sym}/(M+1)=\int |r\rangle\langle r|^{\otimes M}\,d\Omega(r)
\]

and apply the product filter \(e^{-\beta\sigma_z/4}\) at every site, then normalize. This changes the measure to another positive measure on pure product states.

Choose \((N-M)/2\) singlet pairs, tensor them with \(\tau_{M,\beta}\), and average over all permutations of the N sites. The result is exactly the normalized j block in (3). To see this, a fixed singlet pairing selects a multiplicity vector; the irreducible permutation action on that multiplicity space sends its twirl to the normalized identity, while collective spin observables act only on the symmetric M-spin factor. Mixing these twirls with weights \(w_{Nj}\) gives \(\rho_{N,\nu}\).

Consequences needed below: depth at most two; channel application preserves this decomposition; and the collective-spin law can be computed from independent pair factors and an M-spin coherent component without knowing the actual pairing.

These structural ingredients are inherited from Astra N120/N130 and reconstructed here. Their existence is not the new claim.

## 3. The easy half of the threshold is exact at finite N

The noisy singlet is

\[
\tau_T=(\Lambda\otimes\Lambda)(S)
=\frac14\left(I\otimes I-\sum_{a,b}K_{ab}\sigma_a\otimes\sigma_b\right).
\tag{4}
\]

A common rotation diagonalizes the positive matrix K, with eigenvalues \(k_a\ge0\). If \(s=\sum k_a\le1\),

\[
\tau_T=(1-s)\frac{I_4}{4}+
\sum_{a=1}^3 k_a\frac{I_4-\sigma_a\otimes\sigma_a}{4}.
\tag{5}
\]

Each term on the right is separable: the second kind is an equal mixture of the two anti-aligned axis-product states. Apply (5) to every pair in the hidden-pair representation. The unpaired factor was already separable and remains so under a local channel. Every component, and hence their mixture, is fully separable. This proves Theorem 1(a), including equality. The two-qubit partial-transpose calculation also gives the smallest eigenvalue \((1-s)/4\); its threshold is established prior work.

Importantly, the converse cannot be obtained merely by saying that each hidden pair is entangled. An unrecorded mixture of entangled states can be separable. Sections 4–6 supply the missing converse.

## 4. The collective fluctuation law

### 4.1 Spin weights

In terms of M,

\[
w_{N,M}=\frac{(M+1)^2}{N/2+M/2+1}
\frac{\binom N{(N-M)/2}}{2^N}.
\tag{6}
\]

Stirling's formula on compact positive \(M/\sqrt N\) ranges, with lattice spacing \(2/\sqrt N\), gives

\[
X_N=M/\sqrt N\Rightarrow X,
\qquad f_X(x)=\sqrt{\frac2\pi}\,x^2e^{-x^2/2}\mathbf1_{x>0}.
\tag{7}
\]

The tails are controlled by binomial bounds. More explicitly, if \(M_0\) has the correct parity and \(k_0=(N-M_0)/2\), summation by parts gives

\[
\Pr(M\ge M_0)=(M_0+1)\Pr(B=k_0)+2\Pr(B\le k_0-1),
\quad B\sim\mathrm{Bin}(N,1/2).
\]

A central-binomial bound and the ratio of successive binomial masses, together with a Hoeffding tail bound, give a uniform bound of the form \(C(1+x)e^{-x^2/4}\) when \(M_0\simeq x\sqrt N\), with harmless constants for small N. In particular, polynomial moments times any fixed linear exponential in \(X_N\) are uniformly integrable.

### 4.2 Unpaired directions become fixed

In a positive coherent decomposition of \(\tau_{M,\beta}\), write the pure Bloch vector as r and its excitation probability as \(p=(1+r_z)/2\). Its mean excitation is the same as the Gibbs block's:

\[
M\mathbb E p=\mathbb E k\le\nu.
\]

For \(M\asymp\sqrt N\) and \(\nu_N=o(\sqrt N)\),

\[
\mathbb E\|r+e_z\|^2=4\mathbb E p\le4\nu_N/M\longrightarrow0.
\tag{8}
\]

The active M spins therefore contribute a limiting displacement in one fixed direction, not an independently random three-dimensional direction.

### 4.3 Pair noise and the limit

Set

\[
\Sigma=(I-K)/4,\qquad v=Te_z.
\]

The matrix \(\Sigma\) is positive semidefinite because a unital positive qubit map contracts the Bloch ball. For a fixed real vector t, one noisy pair contributes

\[
1-\big(1-\hat t^TK\hat t\big)
\sin^2\!\left(\frac{|t|}{2\sqrt N}\right)
\]

to \(\operatorname{tr}(\omega_N e^{it\cdot J/\sqrt N})\). Raising this to \((N-M)/2\), with \(M=O(\sqrt N)\), tends to \(e^{-t^T\Sigma t/2}\). A coherent unpaired component contributes

\[
\left[\cos\frac{|t|}{2\sqrt N}
+i\hat t\cdot Tr\sin\frac{|t|}{2\sqrt N}\right]^M
\longrightarrow e^{-iX t\cdot v/2}.
\]

Equations (7), (8), truncation to compact spin ranges, and boundedness of characteristic functions yield

\[
\operatorname{tr}(\omega_N e^{it\cdot J/\sqrt N})
\longrightarrow
 e^{-t^T\Sigma t/2}\mathbb E e^{-iXt\cdot v/2}.
\tag{9}
\]

The right side is the ordinary classical characteristic function of

\[
Z=G_\Sigma-\tfrac12vX,
\tag{10}
\]

where \(G_\Sigma\) is centered Gaussian, independent of X. Equation (9) asserts characteristic and one-axis weak convergence; it does not postulate a simultaneous finite-N measurement of noncommuting spin components or a discrete-to-continuous total-variation limit.

## 5. A separable fluctuation constraint, including arbitrary mixtures

This section is independent of the thermal model.

For a product state with Bloch vectors \(r_1,\ldots,r_N\), \(\|r_i\|\le1\), let

\[
\mu_N=\frac1{2\sqrt N}\sum_i r_i,\quad
Q_N=\frac1N\sum_i r_i r_i^T,\quad C_N=(I-Q_N)/4.
\tag{11}
\]

Then

\[
0\preceq C_N\preceq I/4,\qquad \operatorname{tr}C_N\ge1/2.
\tag{12}
\]

Expanding each single-qubit characteristic function gives, for every fixed t,

\[
\prod_i\left[\cos\frac{|t|}{2\sqrt N}
+i\hat t\cdot r_i\sin\frac{|t|}{2\sqrt N}\right]
=e^{it\cdot\mu_N-t^TC_Nt/2}+O_t(N^{-1/2}).
\tag{13}
\]

The error is **uniform over all product inputs**, including nonidentical Bloch vectors and degenerating covariances. This follows by a logarithmic Taylor expansion; the per-factor remainder is \(O(|t|^3N^{-3/2})\). It is an absolute characteristic-function estimate, not a relative approximation to small probabilities.

Integrate (13) over an arbitrary product decomposition of a fully separable state. Thus its characteristic functions are approximated by a classical mixture of Gaussians \(\mathcal N(\mu,C)\), every component satisfying (12). One must keep the mean and covariance jointly mixed; replacing their mixture by a single Gaussian would be wrong.

### Only three marginal laws are needed

Fix any orthonormal axes \(e_1,e_2,e_3\). Suppose the three measured laws of \(J_{e_a}/\sqrt N\) for a sequence of separable states converge weakly to probability laws. For each N, the associated Gaussian mixtures have the same three weak limits by (13) and the continuity theorem for characteristic functions. They are tight in each coordinate. Since \(0\le C_{aa}\le1/4\), tightness of these Gaussian marginals forces tightness of the three mixing means: a bounded-variance Gaussian cannot conceal an arbitrarily remote mean with high probability. The covariance diagonals already lie in a compact set.

Take a weakly convergent subsequence of the common mixing law of \((\mu,c_1,c_2,c_3)\). Its limiting marginals therefore have a common Gaussian-mixture representation with

\[
0\le c_a\le1/4,\qquad c_1+c_2+c_3\ge1/2
\quad\text{almost surely}.
\tag{14}
\]

This argument allows all correlations in the classical mixing variable and arbitrarily complicated separable decompositions. No exchangeability or identical-product restriction is imposed on the competing states.

## 6. One-sided Gaussian tails prove the hard half

Reverse the sign of each measurement axis when necessary so that \(e_a\cdot v\ge0\). This is only relabeling its outcomes. The a-th target limit is

\[
Z_a=G_a-b_aX,\quad
\operatorname{Var}(G_a)=\sigma_a^2=e_a^T\Sigma e_a,\quad b_a=|e_a\cdot v|/2\ge0.
\]

Because \(X\ge0\), for every R,

\[
\Pr(Z_a>R)\le \Pr(\mathcal N(0,\sigma_a^2)>R).
\tag{15}
\]

**Tail lemma.** If a real probability law is a Gaussian mixture and has an upper tail bounded by that of \(\mathcal N(0,\sigma^2)\), then the mixing variance is at most \(\sigma^2\) almost surely.

**Proof.** Otherwise some positive mixing mass has variance at least \(\sigma^2+\epsilon\) and means in a bounded interval, for some \(\epsilon>0\). The upper tail from that mass is at least a fixed positive multiple of the tail of a Gaussian of variance \(\sigma^2+\epsilon\) with a fixed, possibly negative, mean. Its large-R exponential decay is slower than that of the proposed Gaussian upper bound, a contradiction. A bounded interval with positive mass exists because mixing means are finite real numbers. If \(\sigma=0\), the upper-tail bound is zero for R>0, and any positive component variance is immediately impossible. QED.

If the three target limits admitted a separable common mixture (14), apply this lemma to each marginal. On a common probability-one set,

\[
c_a\le\sigma_a^2\quad(a=1,2,3).
\]

But

\[
\sum_a c_a\ge\frac12,
\qquad
\sum_a\sigma_a^2=\operatorname{tr}\Sigma
=\frac{3-s}{4}<\frac12
\quad\text{when }s>1.
\tag{16}
\]

Contradiction.

To obtain (1), assume its liminf were zero. Choose a subsequence and separable alternatives whose axis-and-outcome distributions approach those of \(\omega_N\) in total variation. Every marginal then has the same weak limit as the corresponding target marginal. Section 5 produces a common mixture, and (16) contradicts it. Thus the liminf is strictly positive. Data processing gives (2). This proves Theorem 1(b).

### Bounded scores exist; they have not been compiled here

Let \(\mathcal G\) be the convex set of triples of Gaussian-mixture marginals with a common mixing law satisfying (14). The tightness argument makes this set closed under convergence to probability marginals. The target triple lies outside it. Separation in the weak topology gives bounded continuous single-axis score functions with a strictly positive margin. They may be chosen smooth with compact support, up to additive constants: these functions and constants generate the relevant probability-measure topology, and smooth approximations preserve a strict margin.

For such fixed smooth scores, Fourier integration of the uniform characteristic estimate (13) transfers the Gaussian-mixture bound uniformly to every finite-N separable input, with a vanishing error. Target weak convergence preserves the margin. Consequently a finite bounded-score, three-setting local witness exists for all sufficiently large N. This is an existence theorem, **not** an emitted list of optimized score functions, an efficient certified optimization routine, or a useful numerical lower bound for the gap.

The covariance/tail mechanism is more reusable than the depolarizing numerical threshold: a one-sided random displacement cannot hide an excessively small Gaussian covariance inside a permissible separable mixture. It fails as stated when the displacement has unrestricted two-sided tails.

## 7. Singleton separability and the bound-entangled corollary

For finite \(\beta>0\), the product filter in (3) reduces the question to

\[
F_\beta=\sum_j f_jP_j,\quad f_j=(2j+1)/Z_j(\beta),\quad
\rho_{N,\nu}=2^{-N}e^{-\beta J_z/2}F_\beta e^{-\beta J_z/2}.
\]

Across a single qubit versus the other N-1, decompose the rest into spin k. Each nontrivial block is

\[
aI+b\,\sigma\cdot K_{\rm spin},\quad
 a=\frac{(k+1)f_++kf_-}{2k+1},\quad
 b=\frac{f_+-f_-}{2k+1}\le0,
\]

with \(f_\pm=f_{k\pm1/2}\). Partial transpose, conjugated by \(\sigma_y\), changes the sign of the dot-product term. The nontrivial positivity condition is

\[
\frac{f_-}{f_+}=
\frac{k}{k+1}\frac{\sinh((k+1)\beta)}{\sinh(k\beta)}\le2(k+1).
\tag{17}
\]

For k=1/2 and k=1 this is exactly \(\cosh\beta\le4\). For k>=1,

\[
\frac{\sinh((k+1)\beta)}{\sinh(k\beta)}
=\cosh\beta+\coth(k\beta)\sinh\beta
\le2\cosh\beta\le8,
\]

and \(8k/(k+1)\le2(k+1)\). Even N has a k=1/2 rest sector and odd N>=3 a k=1 sector, so this condition is necessary as well.

For these invariant qubit–spin blocks, positivity of partial transpose is also sufficient for separability. The SU(2) twirl of an up-pointing qubit and a down-pointing spin-k coherent state is separable and has dot-product expectation -k. In the two-irrep invariant family this realizes the boundary \(b/a=-1/(k+1)\). Mixing with the identity realizes the whole PPT interval. The rest-sector labels are local to the rest; combining them and undoing the invertible product filter preserves separability.

Thus every singleton cut is separable iff \(\cosh\beta\le4\), equivalent to \(\nu\ge\nu_*\). Any tensor product of local channels preserves each such cut. The hidden-pair decomposition bounds depth by two. Part (b) excludes depth one. Tensor powers and LOCC by separate laboratories preserve the singleton cuts, so they cannot distill a Bell pair between any two such laboratories. This proves part (c). Different cuts have different separable decompositions; no global product decomposition follows.

## 8. A separate constructive proof using weak product filters

For \(v\ne0\), let \(n=v/\|v\|\) and fix t>=0. Apply the product filter

\[
F_{N,t}=e^{tJ_n/(2\sqrt N)}
=\bigotimes_i e^{t n\cdot\sigma_i/(4\sqrt N)},
\qquad \widehat\omega_{N,t}=
\frac{F_{N,t}\omega_NF_{N,t}}{\operatorname{tr}(F_{N,t}\omega_NF_{N,t})}.
\tag{18}
\]

For each fixed t, direct expansion of the finite pair factors and the active product factors gives the exponentially tilted limit of (10). In that limit the Gaussian covariance stays \(\Sigma\); the independent Maxwell radius acquires density

\[
 f_b(x)=\frac{x^2e^{-x^2/2-bx}}{\int_0^\infty y^2e^{-y^2/2-by}\,dy},\qquad
 b=t\|v\|/2.
\]

It follows that

\[
\lim_N\frac1N\sum_a\operatorname{Var}_{\widehat\omega_{N,t}}(J_a)
=\frac{3-s}{4}+\frac{\|v\|^2}{4}\operatorname{Var}(X_b).
\tag{19}
\]

This is not inferred from weak convergence alone. Here is a direct moment argument. Put h=t/√N and let L be the total spin of one noisy pair. Its unfiltered mean is zero and its symmetrized covariance is \(C_{\rm pair}=(I-K)/2\). A two-by-two-site Taylor expansion under \(e^{h n\cdot L/2}\) gives normalization \(1+h^2 n^TC_{\rm pair}n/2+O(h^3)\), mean \(hC_{\rm pair}n+O(h^2)\), and covariance \(C_{\rm pair}+O(h)\). All remainders are bounded uniformly because the pair Hilbert space is fixed. Over (N-M)/2 independent pairs these yield limiting mean \(t\Sigma n\) and covariance \(\Sigma\) for J/√N.

The M unpaired spins have conditional covariance divided by N bounded by O(M/N), hence zero in the limit. Their mean divided by √N tends to \(-vX/2\). Their normalized individual states change by O(h) under the filter, which changes this aggregate mean by only O(Mh/√N)=o(1). Their scalar normalization weights tend to \(e^{-t\|v\|X/2}\); the pair normalization contributes the common Gaussian exponential factor. Conditional means and covariances, followed by the exact variance-of-a-mixture identity, therefore give (19).

Uniform exponential and polynomial moment control follows from the sub-Gaussian M/√N tail bound in Section 4, so differentiation and averaging here are legitimate. The depolarizing case below has an additional exact finite-N derivation and direct full-matrix checks.

For b>0, compare \(f_b\) with the Gamma(shape 3, rate b) density. The extra factor \(e^{-x^2/2}\) is decreasing, so it decreases every increasing expectation. Consequently

\[
\operatorname{Var}(X_b)\le\mathbb E X_b^2\le12/b^2.
\]

Equation (19) is at most \((3-s)/4+12/t^2\). Taking fixed \(t^2>48/(s-1)\) makes it less than 1/2. Fully separable states satisfy \(\sum_a\operatorname{Var}(J_a)\ge N/2\), by summing single-qubit variances and using concavity under mixtures. A product filter cannot turn a separable state into an entangled one. This separately proves eventual entanglement. If v=0, the radius term is absent and the unfiltered variance suffices.

For an exact non-boundary example, set \(\lambda=29/50=0.58\), \(\nu=1\), and t=100. The upper bound is exactly

\[
\frac{3(1-(29/50)^2)}4+\frac{12}{100^2}
=\frac{4989}{10000}<\frac12.
\]

Thus eventual entanglement at lambda=0.58 is certified by an exact rational asymptotic inequality, not just quadrature. This does not specify the minimum finite N.

**Physical cost.** Each factor in (18) has norm \(e^{t/(4\sqrt N)}\). Rescale to norm-one local Kraus operators. The probability of all successful outcomes is

\[
 p_{N,t}=e^{-t\sqrt N/2}\operatorname{tr}(\omega_Ne^{tJ_n/\sqrt N})
=\exp[-t\sqrt N/2+O_{T,t}(1)].
\tag{20}
\]

Hence this explicit postselected witness is not an efficient large-N experimental protocol. The three-setting result of Section 6 does not incur this success penalty, but its bounded scores have not been numerically compiled. Order of limits matters: choose a finite t large enough, then let N grow. Sending t to infinity at fixed N can select a polarized product component and is not the proof.

## 9. Exact finite-N depolarizing formulas

These formulas provide an independent check of the product-filter argument. Put \(h=t/\sqrt N\), \(T=\lambda I\), and use a z-axis filter. Define

\[
 A=1+(1-\lambda^2)\sinh^2(h/2),\qquad
 b=2\operatorname{artanh}(\lambda\tanh(h/2)).
\]

For the original thermal state, let

\[
 Z_o(b)=\sum_j w_{Nj}\frac{Z_j(\beta-b)}{Z_j(\beta)},
\quad \mu_o=\partial_b\log Z_o,\quad
 V_o=\partial_b^2\log Z_o,\quad B_o=\langle J_x^2\rangle_{\rho\text{ tilted by }b}.
\]

The noisy filter moment is exactly \(A^{N/2}Z_o(b)\). Writing derivatives of A and b with respect to h,

\[
 A'=(1-\lambda^2)\sinh h/2,\quad
 A''=(1-\lambda^2)\cosh h/2,\quad
 b'=\lambda/A,\quad b''=-\lambda A'/A^2,
\]

one obtains

\[
\begin{aligned}
\langle J_z\rangle_f&=\frac N2\frac{A'}A+b'\mu_o,\\
\operatorname{Var}_f(J_z)&=\frac N2\frac{A''A-(A')^2}{A^2}+(b')^2V_o+b''\mu_o,\\
\langle J_x^2\rangle_f&=\langle J_y^2\rangle_f
=\frac N4+\frac{\lambda^2}{A}\left(B_o-\frac N4\right).
\end{aligned}
\tag{21}
\]

For the transverse identity, the diagonal filter satisfies \(F\sigma_xF=\sigma_x\) locally, and axial symmetry removes unequal raising/lowering contributions. The coefficients for opposite flips cancel the two local tilt factors. The same result can be recovered by explicitly applying all local Pauli channels to the density matrix.

The large-N specialization of (19) is

\[
 V_\lambda(t)=\frac{3(1-\lambda^2)}4+
\frac{\lambda^2}{4}\operatorname{Var}(X_{\lambda t/2}).
\tag{22}
\]

At t=0, \(\operatorname{Var}(X)=3-8/\pi\), recovering Astra's old sufficient threshold \(\lambda>\sqrt{\pi/8}\). As t grows, the residual radius variance tends to zero, giving the exact threshold \(1/\sqrt3\). The old threshold's slack was classical radius fluctuation, not an intrinsic entanglement boundary.

## 10. Newly executed verification

`verify_threshold.py` and `verify_characteristics.py` were written and executed in this investigation. They share basic matrix constructors and Schur weights, but use different formulas for filtered moments and characteristic functions. They are not independent agents or externally audited implementations.

* 216 comparisons of (21) with explicit N-qubit density matrices for N=2,...,7, three bath occupations, four channel parameters and three filters: maximum absolute error in variance sum/N **4.440892098500626e-16**. Normalization and filter moments also checked.
* 90 full-matrix comparisons of a separately derived 2x2 symmetric-power characteristic formula, N=2,...,6 with generic measurement directions: maximum error **1.0007415106216803e-15**.
* 500 seeded Pauli-channel noisy-singlet PPT checks: maximum error against \((1-s)/4\) **2.220446049250313e-16**. These check normalization and the established pair boundary, not novelty.
* 90 exact symbolic Bernstein-generator identities for symmetric blocks M=1,...,12. These check a background thermal-preservation mechanism; the main stationary theorem does not require that dynamical mechanism.
* 24 filtered-moment and 36 characteristic-function large-N diagnostics, reaching N=10^8. These evaluate sector formulas, not 2^N-dimensional arrays and not physical experiments.

For fixed \(\nu=1\), examples at N=10^8 are:

| lambda | t | finite-N variance sum/N | limiting value |
|---:|---:|---:|---:|
| 1/sqrt(3) | 50 | 0.5011464085 | 0.5011354788 |
| 0.58 | 50 | 0.4988470197 | 0.4988360285 |
| 0.59 | 25 | 0.4929092227 | 0.4928891102 |
| 0.60 | 18 | 0.4867260621 | 0.4866991317 |
| 0.62 | 12 | 0.4735302983 | 0.4734923148 |
| 0.70 | 0 | 0.4381735880 | 0.4380563115 |

Values below 0.5 violate the fully separable variance bound after a product filter. This is a diagnostic, not interval-arithmetic certification of those decimal values. Large-N Schur sums are truncated at M about 16√N. The scripts record an original-sector tail bound and, where applicable, a separate reweighted tail bound; original additive tail control is not silently transferred through postselection. No finite numerical test proves the asymptotic theorem.

One initial execution completed the mathematical assertions but failed while serializing an infinite log-tail marker into strict JSON. The marker was replaced by explicit null/zero-tail fields; both complete suites were then rerun successfully. The final JSON and log are from the successful runs.

## 11. Novelty, scope and continuation

**Established/inherited:** collective thermal entanglement mechanisms (Li–Xu); collective-spin variance criteria and thermal bound-entanglement detection (Tóth and collaborators); the identical-unital two-qubit channel sphere (Filippov–Rybár–Ziman); Astra's stationary hidden-pair structure, depth two, singleton separability, and sufficient depolarizing threshold. The current note does not rebrand these as discoveries.

**Proposed advance:** the many-body converse above the pair-annihilation sphere; applicability to every fixed unital qubit channel and all subcritical bath sequences; a strictly positive three-setting local-measurement distance; and a separable Gaussian-mixture/one-sided-tail proof that explains why hidden pairing does not make the mixture separable above that boundary. This closes the particular noise-threshold gap explicitly left open in pinned N135.

Primary-source searches located the known two-qubit boundary and earlier thermal/spin-witness work. They did not establish whether the exact thermal-family converse or fluctuation-tail criterion has appeared elsewhere. Several broad searches returned irrelevant results; they are not evidence of novelty. Specialist review of quantum fluctuation limits, permutation-invariant separability and filtered collective witnesses remains required.

The proof does not cover nonunital noise, different maps at different sites, local noise during preparation, critical/supercritical baths, or a shrinking distance to the channel boundary. A naive nonunital extension changes both the extensive mean and the limiting commutation relations; constant prefilters can also exponentially reweight spin sectors. Those are not free substitutions.

The highest-value continuation is a **certified construction of the bounded three-axis score functions with explicit finite-N errors and a quantified channel-margin dependence**. That would turn the existence result into an evaluable witness without the exponentially small success probability of (20). Exact finite-size threshold scaling, the entropy remaining under fixed noise, and physically noisy preparation are distinct further questions.

## References and provenance

See `SOURCES.json` for immutable repository paths, primary-paper URLs and read-depth limitations. Key primary references are Li–Xu, arXiv:quant-ph/0505216; Tóth–Knapp–Gühne–Briegel, arXiv:quant-ph/0702219; Filippov–Rybár–Ziman, arXiv:1110.3757, Proposition 2; and Filippov–Melnikov–Ziman, arXiv:1310.4790. The two-qubit classification is credited even though the finite-N separability implication here has an elementary direct proof.
