# Rare-event certification research packet

**Status: the requested transformative invention was not established.**

Read `RESEARCH_NOTE.md` for the complete derivations, counterexample, source comparisons, and resource limitations. `results.json` contains actual executed diagnostics. `certified_paths.py` implements the finite-state certificate compiler, independent verifier, exact dyadic minimax selection, exact-weight sampling, and a certified median-of-means procedure. `test_certified_paths.py` contains 10 test groups.

```bash
python -m pip install -r requirements.txt
python -m unittest -v test_certified_paths
python run_experiments.py --volumes 40 80 160 --samples 20000
```

The Python files and note are generated research outputs, not externally reviewed software or a claim of historical novelty. The interval compiler already computes useful probability bounds; its explicit-state cost is the unresolved high-dimensional bottleneck. No benchmark against high-dimensional frontier methods was run. Physical-time rates and model error are not covered.

`SOURCE_MANIFEST.json` records accessed revisions and source paths, not a locally archived source corpus. `FILE_HASHES.json` records hashes of this packet's generated payloads.
