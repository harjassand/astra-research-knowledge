# Degree-only irrationality bounds for algebraic logarithms

Research checkpoint: 2026-10-08 UTC. Research proof candidate, not external certification, formal verification, or a historical-priority claim.

## Finding and precise scope

The most credible bridge found in the scoped comparison of release families 007, 017, and 159 is an arithmetic extension of family 017's interpolation determinant. The candidate is:

> Let a > 0 be a real algebraic number different from 1, and let d = [Q(a):Q]. Then mu(log a) <= 2d. Equivalently, for every nu > 2d, |log a - p/q| > q^(-nu) for all integers p and all sufficiently large positive integers q. The threshold depends on a and nu and is not shown effective.

The proof below establishes the implication from a precisely stated moving-center interpolation input. That geometric input is reconstructed in Section 2 from the original family 017 argument; an independently authored preprint, Liu–Jiang–Zhang, arXiv:2610.10192v1, already states and proves the same moving-center input for its rational-logarithm application. Neither source's research status is promoted by using it here.

Clarification of proof status: MI is not merely a desired, unproved new lemma. Section 2 supplies its source-based proof reconstruction and the current primary preprint independently supplies a full proof. The remaining dependency is correctness of that geometry chain and its standard imported intersection/blowup/vanishing theorems. Thus the combined argument is a source-dependent proof candidate with no currently identified missing new mathematical step, rather than an unconditional externally validated theorem. The number-field implication can also be read separately as a theorem conditional on precisely MI.

For d=1, this is exactly the rational-logarithm endpoint already claimed by Liu–Jiang–Zhang; it is not a new result of this investigation. No matching general degree-only 2d theorem was located in the targeted primary-source search, but that does not establish novelty. A larger foundational destination remains mu(log a)=2 for every positive algebraic a != 1. The present route does not close that endpoint for general d>1.

The proposed advance is uniformity of the exponent over all heights at fixed degree. The onset is allowed to depend on the algebraic argument and can be enormous. This is about rational approximants, not approximation by every element of Q(a), and those two exponents must not be conflated.

## 1. Why this direction survived the comparison

Family 007: the actual random-prime rank lemma eliminates an arbitrary controlling-prime function by independent differencing, then combines real rank with a prime-divisor bound. Its forest code counts ordinary graph closed walks. Neither statement supplies the hypergraph cancellation needed for fixed higher-order Chowla correlations. The arithmetic rank lemma is useful, but no new higher-order cancellation interface was found. A pairwise-to-joint inference is explicitly excluded.

Family 159: the actual bounded-grid moment and relative cube-detection lemmas remove current chart-mass dependence only below the current layer degree (q <= j, with testing degree r < j). Active replacement then preserves inherited determining equations exactly. This is an important quantitative mechanism, but a polynomial-Szemeredi extension would still need a new sampling/return theorem preserving fixed grading and the descending precision recurrence. This investigation did not find such a theorem, so it was not elevated over the more explicit logarithm route.

Family 017: its full-simplex counts, rowwise rational-denominator cancellation, and grouped Taylor collision estimate survive passage to a fixed number field. The new issue is finite-place denominator clearing and the other Archimedean embeddings. Both admit an explicit estimate. The norm contributes a factor d to the main arithmetic cost, while the other conjugate growth is a controllable error. This is the decisive mechanism, rather than the headline value mu(pi)=2.

## 2. Geometric input and its exact reconstruction

Write W=(w0,w1,...,wm), V=(v0,w1/theta,...,wm/theta), with positive rational weights and 0<theta<1. Let P_W(H) be the polynomials of weighted degree <=H, and J_V(H) the formal coefficient packet of monomials of V-weight <H.

Moving-center interpolation (MI): Fix m,K,w0,v0,theta with K(w0/v0)theta^m<1. There exist successive lower thresholds on w1,...,wm, depending only on these data and earlier weights, such that for arbitrary distinct nonzero y_j and arbitrary c_ji, the map

P -> ( P(y_j(1+t), c_j1+u1+log(1+t),...,c_jm+um+log(1+t)) )_j

from P_W(H) onto the direct sum of K copies of J_V(H) is surjective for sufficiently large divisible H. The eventual H threshold may depend on the centers; the successive weight thresholds may not.

Here is the alteration of the original source geometry, rather than an appeal to its pi endpoint:

1. Choose sigma>0 with (1+3sigma)^(m+1) K(w0/v0)theta^m<1 and (1+sigma)theta<1. The original weighted-transverse-multiplicity lemma applies to polynomial equations of degree <=N vanishing, along a component, under all commuting derivatives of weighted cost <epsilon N. It bounds each product of coordinate normal weights by 2k! epsilon^(-k) times each product of derivative normal costs. Its proof is a local intersection-length lower bound followed by weighted Bezout. All constants are independent of the component and equations.

2. Choose the w_i successively so that every reversed lexicographic exchange between a coordinate normal basis and a derivative normal basis violates that bound. This is exactly the finite family of inequalities in the source's equation geom:separation, with C_* = max_(1<=k<=m) 2k!((m+2)/sigma)^k. It involves no centers.

3. On the torus chart Y != 0 use D0=Y partial_Y + sum_i partial_Xi, Di=partial_Xi. At a moving center, t=Y/y_j-1 gives D0=(1+t)partial_t; the same costs therefore apply. For a branch through (y_j,c_j), define contact h_P as the minimum of ord(Y/y_j-1)/v0 and ord(Xi-c_ji-log(Y/y_j))/v_i. Define weighted curve degree as the sum over poles of max(0,-ord(Y)/w0,-ord(Xi)/wi).

4. A violating curve with deg_W C < (1+sigma) sum h_P forces a nonzero auxiliary polynomial and all its low-cost derivatives to vanish on the curve, by comparing total zero order with total pole order. The volume condition produces that polynomial by dimension count only; no interpolation surjectivity is assumed. A finite descending derivative-ideal chain has a persistent positive-dimensional component. The multiplicity lemma and separated normal bases force either every positive coordinate direction tangent or a relation dXi=dY/Y on that component. The former forces Y constant by properness. The latter forces Y constant because an exact meromorphic differential has zero residues whereas dY/Y has a nonzero residue at any zero or pole of a nonconstant Y.

5. Since the y_j are distinct, a curve in the constant-Y fiber meets at most one prescribed center. Choose any Xi nonconstant on that curve. On the fiber its local transverse coordinate is Xi-c_ji, and the divisor bound gives deg_W C >= theta^(-1) sum h_P > (1+sigma)sum h_P, contradiction. This replaces the original source's second auxiliary-polynomial argument in the common fiber Y=1. In particular, no separate K theta^m<1 condition is needed for MI.

6. The passage from the strict curve inequality to all jets is unchanged: truncate logarithms above their filtration weights, embed using all weighted monomials up to a common degree R, form local ideals (t^(R/v0),u_i^(R/v_i)), blow up their union, and use the curve inequality to make A-(1+sigma)E nef. A-E is ample as a positive combination of that nef class and aA-E for a sufficiently large a. Ordinary Rees pushdown for large powers and Serre vanishing yield surjectivity modulo I^n. Since I^n has weighted order >=nR, it surjects onto the desired packets. Eventual homogeneous coordinate surjectivity supplies polynomials of weighted degree <=nR. No uniform effective H threshold is asserted.

The nontrivial geometric foundations (local intersection theory, blowups, nef-plus-ample, and Serre vanishing) remain imported established mathematics. A separate internal audit has now reconstructed and checked this MI extension, including its Rees/Serre interfaces, without identifying a remaining gap. External specialist validation and formal verification have not been performed. Small finite rank experiments do not prove MI.

## 3. Set up the number-field determinant

Let F=Q(a), d=[F:Q], x=log a, and fix nu>2d. Suppose |x-p/q|<=q^(-nu) for arbitrarily large q. Choose finitely many such approximants r_i=p_i/q_i with w_i=ceil(log q_i) meeting all successive MI thresholds. Since x != 0, the denominators may be taken large enough that |r_i|<=|x|+1. The centers are

    y_j=a^j, c_ji=j r_i, 0<=j<K.

They have distinct y_j because a>0 and a!=1. Define F0>2/theta,

    T_i=ceil(F0 w_i/v0), G_i(t)=sum_(1<=k<T_i) (-1)^(k+1)t^k/k,
    L_i=lcm(1,...,T_i-1), D_H=product_i L_i^floor(H/w_i).

An empty lcm is 1. Truncation preserves the weighted filtration because the first omitted t monomial has V-weight >=F0 w_i>w_i/theta.

Use columns Y^h X^gamma with w0 h+w.gamma<=H, and rows rho=(j,s,beta) with v0 s+w.beta/theta<H. The entry is

    M_(rho,(h,gamma)) = [t^s u^beta] a^(jh)(1+t)^h product_i(jr_i+G_i(t)+u_i)^gamma_i.

It belongs to F. MI supplies a nonzero square minor Delta_H using every row. Let M denote its number of rows and

    bbar = (MH)^(-1) sum_rows w.beta.

Then 0<=bbar<=theta and

    M ~ K theta^m H^(m+1) / ((m+1)! v0 product_i w_i).

Every parameter and every approximant is fixed before H tends to infinity. This order of limits is essential.

## 4. Exact denominator clearing in F

Choose an integer b>=1 with b a an algebraic integer. The leading coefficient of a primitive minimal polynomial is one permitted choice. Scale column (h,gamma) by b^((K-1)h) product_i q_i^gamma_i, row (j,s,beta) by product_i q_i^(-beta_i), and every entry by D_H.

An entry vanishes unless gamma>=beta coordinatewise. Otherwise its scaled form is

    D_H b^((K-1-j)h) (ba)^(jh) product_i binom(gamma_i,beta_i)
       * [t^s](1+t)^h product_i(jp_i+q_i G_i(t))^(gamma_i-beta_i).

The only rational denominators left divide product_i L_i^(gamma_i-beta_i), which divides D_H. Hence every scaled entry is an algebraic integer. Therefore

    z_H=S_H Delta_H is a nonzero algebraic integer,

where

    log S_H = M log D_H +(K-1)log b sum_columns h
                + sum_columns sum_i gamma_i log q_i
                - sum_rows sum_i beta_i log q_i.

S_H is a positive rational scalar; integrality of z_H, not integrality of S_H separately, is the required fact. With Lambda=4 log 2, the source's elementary lcm bound yields

    log S_H/(MH) <= 1-bbar+E0,
    E0 = Lambda F0 m/v0 + Lambda sum_i(1/w_i) +theta/w_min
             +(K-1)log b/w0.

This handles nonintegral a and arbitrary denominators q_i without imposing coprimality between q_i and the field discriminant or b.

## 5. The other embeddings: a bound before taking norms

For every embedding sigma:F->C, let a_sigma=sigma(a). The rational approximants and truncated logarithms are fixed by sigma. On |t|=1/2, |G_i(t)|<=sum_(k>=1)2^(-k)/k=log 2. Put

    R_c=K(|x|+1)+log 2,
    C_c=2 max(1,R_c).

Cauchy's coefficient estimate and binom(gamma,beta)<=2^|gamma| give

    |sigma(M_(rho,(h,gamma)))|
      <= exp[ H E_sigma ],
    E_sigma = ((K-1)log^+|a_sigma|+log(3/2))/w0
                  +log 2/v0 +log C_c/w_min.

Indeed |a_sigma|^(jh) supplies the first conjugate term, |1+t|^h<= (3/2)^h supplies the next, the coefficient extraction costs 2^s, and all X-polynomial factors together cost at most C_c^|gamma|. Here h<=H/w0, s<H/v0, and |gamma|<=H/w_min.

The determinant estimate is consequently

    log|sigma(Delta_H)|/(MH) <= E_sigma +log(M!)/(MH).

The last term tends to zero because M is polynomial in H for fixed data. A nonzero algebraic number remains nonzero under every embedding, so none of the logarithms used in the norm argument is undefined.

Since |N_(F/Q)(z_H)| is a positive integer, taking the norm and singling out the given real embedding yields

    log|Delta_H|/(MH) >= -d(1-bbar)-E_ar-o_H(1),
    E_ar = d E0 +sum_(sigma != id) E_sigma.

This is the new arithmetic interface. The leading cost is d(1-bbar), not 1-bbar. Dropping the factor d is unjustified. By contrast, the field's fixed heights and the sizes of its conjugates enter only E_ar.

## 6. Analytic upper bound at the distinguished embedding

Put omega=x=log a and define f_(u,P)(z)=[v^u]P(e^z,z+v_1,...,z+v_m). For P=Y^h X^gamma,

    f_(u,P)(z)=binom(gamma,u)e^(hz) z^(|gamma|-|u|),

with zero value unless u<=gamma. At z=j omega+log(1+t), e^z=a^j(1+t). The same exact row expansion as the original proof applies, with epsilon_i=j(r_i-omega) and tau_i=G_i-log(1+t).

Choose one term from each row expansion, with transverse index u>=beta. Its scalar coefficient satisfies

    |xi| <= exp[-nu w.(u-beta)+H E_tr],
    E_tr = nu/F0 +log 2/v0 +(log 4+log K+nu)/w_min.

Using log(2K) instead of log K is a harmless enlargement. The proof is exact: a surviving product of tails obeys sum_i d_i w_i<H/F0, its Taylor coefficient is at most 2^s, and |j(r_i-omega)|<=K e^nu e^(-nu w_i). There are only polynomially many term choices per row.

For the grouped Taylor estimate choose R=4K(|omega|+1), so |j omega+log(1+t)|<R/2 on |t|=1/2. On |z|<=R,

    |f_(u,P)(z)|<=exp[H(R/w0+log(2R)/w_min)].

Expand in powers (z/R)^n. Terms with a repeated pair (u,n) have equal coefficient row vectors and vanish. If n_u rows have the same transverse index u, the surviving degrees sum to at least sum_u binom(n_u,2). Summing half the geometric decay freely gives

    log|det T|/(MH) <= -c sum_u n_u^2/(MH)+E_hol+o_H(1),
    c=(log 2)/4,
    E_hol=R/w0+log 2/v0+log(2R)/w_min.

This estimate is uniform over selected columns and translated row terms. Combining it with the scalar factors and their polynomial term count gives, for fixed 0<A<1 and 0<eta<1,

    log|Delta_H|/(MH)
      <= E_an+o_H(1)+max[-c L_H, -nu(A(1-eta)-bbar)],
    E_an=E_tr+E_hol,
    L_H -> L=eta^2 K theta^m / ((m+1)v0 A^m).

The dichotomy is whether at least eta M transverse indices have weight <=AH. In that case Cauchy-Schwarz gives the collision term. Otherwise the approximation-error factors give the second term. No positive approximation error or reduction of p/q was needed.

## 7. The parameter choice closes the 2d bound

For every nu>2d choose rational numbers theta,A,B,C with

    0<theta<A<B<1,
    nu(A-theta)>d(1-theta),
    C>1, B<1/C, B<C theta<1.

Existence is elementary. Choose rational beta0 between 1/2 and 1-d/nu, put theta=1-delta and A=1-beta0 delta for small rational delta>0. Then the desired approximation gap is positive and theta>A^2. Choose C in (A/theta,1/A), then B in (A,min(1/C,C theta)). Finally choose eta>0 so small that

    g=nu(A(1-eta)-theta)-d(1-theta)>0.

Set

    K=floor(C^m), w0=B^(-m), v0=2K theta^m w0.

The interpolation volume ratio is 1/2. Moreover

    K/w0 <= (CB)^m ->0,
    v0 ~2(C theta/B)^m ->infinity,
    m/v0 ->0,
    L=eta^2(B/A)^m/(2(m+1)) ->infinity.

First choose F0 sufficiently large that nu/F0 is a small part of g. Choose one finite m so large that all terms of E_ar+E_an depending on K/w0, 1/w0, m/v0 and 1/v0 are small and cL>d+1. The field F, b, and all |a_sigma| were fixed before this choice, so their constants cause no uniformity problem. Then choose the q_i successively sufficiently large to satisfy MI and make all 1/w_i and log K/w_min terms small. Their unboundedness under the contradictory assumption is sufficient.

For the second analytic alternative,

    nu(A(1-eta)-bbar)-d(1-bbar)
       =nu A(1-eta)-d-(nu-d)bbar >=g,

because bbar<=theta and nu>d. The first analytic alternative beats d(1-bbar)<=d. Take E_ar+E_an<min(g/2,1/2), fix all data, and then let H tend to infinity through the admissible multiples. Both upper alternatives are strictly below the arithmetic lower bound. Contradiction.

This rules out arbitrarily large q satisfying the assumed nu approximation for every nu>2d. Exact rational representations are also excluded, so log a is irrational. This proves the candidate implication from MI.

## 8. Falsification tests and limits

Direct finite test: take nonintegral and mixed-sign-conjugate algebraic arguments, arbitrary rational approximants (they need not be good approximants for this algebraic test), form actual small minors, and verify that the stated row/column clearing lies in Z[ba], its norm is a nonzero integer, and the unscaled conjugate product equals that norm divided by S_H^d. Missing b factors, omitted negative conjugates, or the wrong row sign would fail this exact test.

The universal test against a false stronger norm statement is the real quadratic unit u=1+sqrt(2). Its inverse powers are nonzero algebraic integers with principal absolute value tending to zero. Thus integrality alone never gives |z|>=1 at a real embedding. A proof of the d=1 arithmetic lower bound for general F must supply additional determinant-specific conjugate control, not cite integrality.

The full target mu(log a)=2 for all a remains open in this investigation. The precise missing improvement is an arithmetic lower bound with leading cost 1-bbar, or an equivalent analytic saving across the conjugates that cancels the extra d-1 copies. No such bound is proved here. In the present parameter architecture A^2<theta and theta<A<1 imply (A-theta)/(1-theta)<1/2; hence nu(A-theta)>d(1-theta) necessarily requires nu>2d. Adjusting constants alone cannot reach 2 for d>1.

Immediate but limited corollary: by rational-scaling invariance of the ordinary irrationality exponent, the candidate gives mu(log a)<=2 min_(n>=1)[Q(a^n):Q]. For a positive a with a nonzero rational power, the already claimed rational-logarithm endpoint applies. There is no claimed result for ratios log a/log b, powers (log a)^k, products of independent logarithms, effective onset, or bounded partial quotients.

## 9. Current status and next decisive task

- Actual progress: a complete source-dependent joint proof candidate, including both a reconstructed MI proof and the number-field denominator/conjugate argument with its closing parameter schedule. No additional unproved MI lemma remains in the reconstructed argument.
- Finite checks completed: five actual 8-by-12 jet matrices have full row rank, including nonintegral alpha with a prime common to b and q and a cubic field with nonreal conjugates. Exact clearing, determinant scaling and norm identities all pass. Twelve exact rational parameter schedules pass. Files: check_algebraic_log_ledger.py and algebraic_log_exact_checks.json. These checks do not establish asymptotic interpolation.
- Separate mathematical reconstruction: the separate audit first recorded a blind reconstruction before reading this proof, then compared the full ledger and reported no interface gap. See ../algebraic_log_audit/. Agreement by the separate reconstructions is not external or formal certification.
- Established antecedent: number-field norm/product-formula methods and the distinction between rational and number-field approximation are classical. The special rational-logarithm application is already claimed by a current preprint.
- Unresolved: complete priority review of degree-only logarithm bounds; formal verification and external specialist review. The separate mathematical reconstruction of MI, its blow-up interface and the 2d implication is complete, with no remaining gap identified. No publication was performed.
- Single most valuable next task: deepen the primary-literature comparison and obtain a specialist-quality scrutiny of the extraordinary interpolation input when appropriate and authorized. The current method does not establish the larger general exponent-two goal; EMBEDDING_GATE_AND_NOGO.md identifies and tests that exact boundary.

