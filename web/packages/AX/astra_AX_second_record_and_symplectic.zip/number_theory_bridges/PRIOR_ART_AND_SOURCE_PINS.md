# Scope, original sources, and priority ledger

Date of this scoped investigation: 2026-10-08 UTC.

## Immutable first record

The earlier programme record remains unchanged: Astra 39cdea532f19217f633f70315d92c314a6ce5e3e and OpenAI fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb. This investigation did not edit that record or its archive.

## Current reading pins

- Astra: 5d508c4b9f38cb9662e275b0f84a066479ce052c, reported current tip through GitHub commit search at 16:40 UTC; commit dated 2026-10-08T16:19:25Z. Start-here, the number-theory topic router, relevant number-theory review cards, one full status card, and selected source-directory metadata were read. No full corpus preload.
- OpenAI math: fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb, current tip verified 16:40 UTC; commit dated 2026-10-08T05:20:00Z. Manuscript paths below are relative to that pin, not moving main links.

## Actual original proof ranges read

### 007: Ordinary-two-point-correlations-of-multiplicative-functions-September-24-2026/build/

Read main.tex and introduction.tex; quantitative/01-setup.tex; quantitative/05-rank-witness.tex (especially lemma q:rank-probability, its complete proof, and its application to independent lit-consistency pairs); quantitative/06-forest.tex was retrieved and its structure inspected, with the introduction's explanation of coefficient-independent forest coding. The present work does not claim a full independent audit of the ordinary Chowla proof.

The rank lemma uses probability at most [alpha(1+floor(log M/log 2))]^(r/2), under product prime-coordinate law, nonsingular integer B, and a uniform bound M on B(y-y'). Differencing removes the arbitrary control-dependent function. It does not control higher-order multiplicative correlations merely because it controls a bilinear graph moment.

### 017: The-irrationality-exponent-of-pi-is-2-September-24-2026/build/

Read main.tex and complete sections/interpolation.tex, sections/determinant.tex, sections/conclusion.tex. Their immutable source locations are listed in `../EVIDENCE_PINS.txt`. The exact reused mechanisms are geom:multiplicity, geom:curve-inequality, the eventual ordinary-Rees-power/Serre passage in geom:interpolation, the row-dependent denominator benefit in det:arithmetic, det:translation, det:collision, and the full-simplex dimension schedule. The pi theorem itself is not used as a black box to infer a different irrationality measure.

### 159: Quasipolynomial-Bounds-for-Arithmetic-Progressions-September-23-2026/build/

Read main.tex, sections/00-introduction.tex and complete sections/03-relative-detection.tex, including bounded-grid moments and relative cube detection. Retrieved sections/04-return.tex and sections/06-active.tex and inspected theorem structure and the source's explanation of exact inherited marking. This was selective mechanism comparison, not a complete proof audit of the quasipolynomial Szemeredi theorem.

## Current primary literature checked

1. Jingwen Liu, Kai Jiang, Pingwen Zhang, "Irrationality exponents of logarithms of positive rational numbers," arXiv:2610.10192v1, submitted 7 October 2026 14:54:45 UTC. https://arxiv.org/abs/2610.10192v1 ; full https://arxiv.org/html/2610.10192v1 . Theorem 1 claims mu(log r)=2 for r>0 rational, r!=1. Theorem 2 gives moving-center interpolation with distinct nonzero multiplicative coordinates, the same geometric extension independently noticed here before the primary check. Section 7 covers rational linear combinations, rational affine changes and positive numbers with a rational positive integer power. It does not literally state the present general degree-only 2d rational-approximation bound. The authors explicitly call it a research draft under audit. Do not describe their claim as independently certified.

2. Francesco Amoroso and Carlo Viola, "Approximation measures for logarithms of algebraic numbers," Ann. Scuola Norm. Sup. Pisa (4) 30 (2001), 225–249. Primary PDF consulted: https://iris.unito.it/retrieve/0b661683-45ea-4ec6-a455-5216ec7277ea/Logar-estratti.pdf . A direct local download returned HTTP 403 and was not bypassed. The abstract and introductory scope concern Q(alpha)-approximation measures for suitable algebraic alpha. This is a different approximation domain and does not itself give a general rational 2d theorem. A full proof audit of this older source was not performed.

3. Raffaele Marcovecchio and Carlo Viola, "Irrationality and nonquadraticity measures for logarithms of algebraic numbers," J. Aust. Math. Soc. 92 (2012), 237–267, https://doi.org/10.1017/S1446788712000274 . Full primary PDF downloaded and introductory pages 237–241 inspected, including Definitions 2.1 and Lemma 2.2. The paper provides Q(alpha)-irrationality and nonquadraticity measures from double integrals and all conjugate asymptotics, for selected algebraic arguments. Its explicit exponents depend on integral growth, degree and the leading coefficient. The displayed 2delta is a Dirichlet LOWER bound for approximation over K, not a universal UPPER bound for rational approximation to log alpha. Mistaking these would create a false novelty/no-novelty judgment.

4. Noriko Hirata-Kohno, Ryuji Muroi and Yusuke Washio, "Approximation measures for shifted logarithms of algebraic numbers via effective Poincare-Perron," arXiv:2406.10820v2, revised 10 December 2024. https://arxiv.org/abs/2406.10820v2 ; complete HTML downloaded. Sections 1–3 and Theorem 3.4 were inspected. The theorem requires spectral inequalities at the embeddings and lambda=1/delta-log Q/(d log E)>0. Q involves denominator and conjugate spectral products. It establishes an effective K-approximation measure lambda^(-1), for a shifted logarithmic function. Its literal theorem is not the degree-only 2d statement above. Full implications over every permitted transformation have not been exhaustively ruled out.

5. Raffaele Marcovecchio, "The Rhin–Viola method for log 2," Acta Arith. 139 (2009), 147–184; author's institutional record https://ricerca.unich.it/handle/11564/648605?mode=complete checked. It records the classical 3.574... rational bound for log 2, providing historical context; the full 2009 proof was not read here.

6. Yufei Bai, "The irrationality measure of arctan1/2 is at most 8.585166," arXiv:2608.19782, abstract checked as a recent primary preprint. It is useful for the arctangent lead but not an input to the selected general-algebraic-logarithm proof.

7. Stephane Fischler and Tanguy Rivoal, "Transcendence of values of logarithms of E-functions," Mathematische Annalen (2026), primary author PDF https://www.imo.universite-paris-saclay.fr/~stephane.fischler/logE.pdf . Theorem 2 was read and primary PDF access was separately verified. The bound there for logarithms of E-function values has exponential-denominator form exp(-c b^d), not the proposed polynomial-denominator 2-degree bound for algebraic logarithms. The known non-Liouville status of algebraic logarithms must not be presented as new. This check is not priority clearance for our quantitative statement.

8. The matched-embedding limitation in EMBEDDING_GATE_AND_NOGO.md uses the classical Gelfond–Schneider theorem with its full complex, any-branch statement. That exact formulation was checked in Niven's proof monograph, Irrational Numbers, Chapter X, Theorem 10.1, https://doi.org/10.5948/9781614440116.011 . The restriction to rational exponent ratio, followed by finite-order Galois symmetry, is the stated reason only the identity and inverse pair can match; it does not require an unproved transcendence conjecture.

## Leads not treated as evidence

A current public discussion/search snippet attributed exponent-two bounds for arctan(1/2), arctan(sqrt(2))/sqrt(2), and log(3+2sqrt(2))/sqrt(2) to "Astra." No exact original manuscript, authenticated provenance linking it to the research repository, or pinned proof was located in this pass. The discussion may refer to a model rather than this project. These claims are NOT adopted as results, nor are those examples claimed as new here. The research repository's narrow search found no matches, but search absence is not absence of prior work.

## Priority conclusion

The rational-logarithm and moving-center routes have an explicit contemporary antecedent. The general degree-only 2d extension is currently a candidate deduction with an incomplete priority search. No claim of novelty, historical significance, or a solved general exponent-two conjecture is justified by this pass. The source claims themselves remain under audit. The separate mathematical audit of the candidate's interfaces is now complete, with no remaining gap identified. External specialist scrutiny and a more exhaustive primary-literature check remain next gates.

