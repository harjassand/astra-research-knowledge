# Number-theory bridge checkpoint

2026-10-08 UTC. Scoped proof mining of OpenAI families 007, 017, and 159.

## Result worth retaining

A complete source-dependent proof candidate now gives

    mu(log alpha) <= 2 [Q(alpha):Q]

for every fixed positive real algebraic alpha != 1. Equivalently, for any nu greater than twice its degree, rational approximations with error <=q^(-nu) have bounded denominators. The onset depends on alpha and nu and is not shown effective. No height-uniform onset or all-number-field approximation statement is claimed.

This extends the actual separated-weight determinant mechanism, not merely the stated pi result. Nonintegral arguments are handled by an explicit b-clearing factor. All field embeddings are accounted for. The norm multiplies the main rational-denominator cost by the degree, while the growth at the other embeddings is reduced to a small error by the original dimension schedule. The entire asymptotic order of choices is written down.

The geometric moving-center input has an explicit reconstruction from the source's weighted multiplicity/curve/blow-up argument. It is not just an unproved requested lemma. A 7 October primary preprint already proves this geometric extension and claims the rational-logarithm case; those portions are prior source work, not new discoveries here. The combined proof remains a candidate because the source-derived geometric chain, novelty, and external correctness have not been formally or externally certified.

## Verification actually done

- A separate reviewer recorded a blind proof reconstruction before receiving the originating derivation; full comparison found no missing interface. This is mathematical checking, not independent external certification.
- Five exact 8-row, 12-column jet matrices had full row rank. All scaled entries belong to Z[b alpha]; scaled/unscaled determinant and full field-norm identities passed. Cases include alpha=(1+sqrt(2))/3 with b=3 and q=9, negative real conjugates, and a cubic with nonreal conjugates.
- Twelve exact rational parameter schedules passed all inequalities for degree 1,2,3,10 and exponents 2d+1, 2d+0.1 and 2d+0.01.
- Exact rational-power jet denominator valuations were additionally tested; these are a narrow diagnostic of why logarithm ratios cannot be silently substituted into the same proof.
- No formal proof, external specialist review, or asymptotic computation was performed.

## What this does not close

The exceptional foundational destination mu(log alpha)=2 for every positive algebraic alpha remains open in this investigation. The current generic method stops at the factor of the degree. A Pell-unit family shows that this norm cost is genuinely necessary if one uses only rational denominator clearing and bounded other conjugates. Multiplying by units cannot improve the total norm balance. Exact vanishing at unwanted conjugates also annihilates the principal determinant.

A precise remaining sufficient lemma would provide approximate suppression of all unwanted conjugate determinants by exp[-(d-1)(1-bbar)MH+o(MH)] at unchanged clearing cost and with the same interpolation/collision controls. There is no proof of that lemma here.

There is a useful matched-embedding variant: if exp(c lambda)=alpha with alpha,c algebraic and lambda real, r embeddings reproduce that same lambda, and the requisite interpolation centers are nontorsion, the ledger gives 2d/r. But Gelfond–Schneider and finite-order Galois symmetry imply r<=2 in Q(alpha,c). This explains quadratic inverse-pair examples and prevents promoting that mechanism into an arbitrary-degree exponent-two theorem. Those quadratic examples have unverified current prior-claim leads and are not claimed new.

## Why other sampled directions were not selected

- Family 007 supplies an actual random-prime rank/differencing lemma and a graph forest code. It does not supply the required higher-order Chowla hypergraph cancellation. No pairwise-to-joint inference is made.
- Family 159 supplies chart-mass-independent relative cube detection and exact inherited-equation return. A polynomial-configuration extension still needs a new grading-preserving sampling/return theorem. No such interface was closed here.

## Prior-art status

The rational-logarithm result is already explicitly claimed in Liu–Jiang–Zhang, arXiv:2610.10192v1 (7 October 2026), whose status is a research draft under audit. The classical Amoroso–Viola and Marcovecchio–Viola papers, the 2024 shifted-logarithm approximation paper, and the current Fischler–Rivoal E-function-logarithm paper were screened at their relevant stated interfaces. They do not literally state the proposed general degree-only rational bound. This limited check does not establish priority.

## Files and next task

- ALGEBRAIC_LOGARITHM_CANDIDATE.md: full theorem, geometric reconstruction, integral minor, all-conjugate bounds, analytic comparison and parameter schedule.
- check_algebraic_log_ledger.py and algebraic_log_exact_checks.json: exact finite tests and results.
- EMBEDDING_GATE_AND_NOGO.md: the exponent-two missing lemma, Pell counterexample, unit balance, and matched-embedding limitation.
- PRIOR_ART_AND_SOURCE_PINS.md: precise reading scope and primary-source status.
- SOURCE_MANIFEST.json: immutable reading pins and external-source fingerprints. Root PACKAGE_PROVENANCE.json and SHA256SUMS.txt record this release. The first research record was not changed.

The highest-value next step is a specialist-quality independent audit of the moving-center geometry and a deeper prior-art search for degree-only rational approximation bounds. The larger exponent-two gate needs a new conjugate-sensitive mechanism; this pass found no justified shortcut to it.

