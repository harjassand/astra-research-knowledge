ASTRA SECOND PRIVATE RESEARCH RECORD
Counting-space consequences and algebraic-logarithm bounds
Research date: 8 October 2026 UTC / 9 October 2026 Australia/Brisbane

PURPOSE AND STATUS

This is a compact, private scientific record of two completed research
outcomes, their independent mathematical reconstructions and comparisons,
original test code, and test results. It is an additional record, not a
replacement for either earlier archive. No public posting or external review
is represented by its creation.

The proof reconstructions and adversarial comparisons found no remaining
mathematical gap in the stated new bridges. This is an audited research proof
record, not a formal verification, outside specialist certification, peer-
reviewed publication, or established historical-priority claim. The conclusions
retain the supplied mathematical inputs explicitly identified below.

Only original scientific derivations, literature comparisons, audits, code,
results, and packaging/provenance information are included. Downloaded papers,
repository source copies, private routing material, and correspondence are not
included. Primary source links and immutable revisions are in EVIDENCE_PINS.txt.

OUTCOME 1: PRECISELY SCOPED COUNTING-SPACE NONCAPTURE

Define CPS(Card) locally to mean the deterministic, fixed finite-signature,
finite-support ASM formalism of Ferrarotti--Schewe, arXiv:2401.16366v1, extended
by ordinary BGS cardinality: Card(a) is the von Neumann ordinal |a| for a set,
and Empty for an atom. It includes no choice, powerset, succinct-number oracle,
or other unlisted primitive. FS24 itself omits Card and does not formally define
the counting extension asked about in its conclusion.

The new bridge: for each fixed such ASM M, one fixed Card-enabled HF term
program simulates its finite runs and halt/output behavior using at most
C_M W^(d_M) peak inclusive hereditary space, where
W = 4 + max_i |Active(S_i)|.
The bound is independent of the finite runtime. Fixed-arity nonzero function
graphs encode current states; updates preserve exact defaults, simultaneous
execution, duplicate handling, whole-state clash behavior, and zero deletion.
The compiler does not retain a history or unbounded step counter. Fixed-term
footprint accounting also covers temporary values and update sets.

Composed with the earlier source243 and space-simulation results, the consequence
is an isomorphism-invariant ordinary-PTIME Boolean query Q on a fixed binary
vocabulary that no CPS(Card) program decides with polynomial peak active space.
Consequently this exact counting-space model does not capture PSPACE. This is
not a separation between ordinary PTIME and PSPACE.

Two distinct quantitative levels must remain separate:
- Qualitative: source243's original three-dimensional grids, together with the
  runtime-independent state-local orbit argument and the new space bridges,
  already exclude polynomial peak space. KOW expanders are not needed here.
- Quantitative: coefficient-uniform collective cofilling and KOW-type expanders
  yield exp(Omega_M(N)) peak active objects on at least one input of each
  sufficiently large hard pair, for each fixed deciding ASM M. N is the number
  of original input atoms, not a changed encoding size. Polynomial compiler
  overhead changes only the constant in the exponent.

These consequences depend on source243's supplied group/base/HF-transfer proofs
and the separately reconstructed history-independent compiler. Those proofs are
identified in the earlier records and source pins, rather than silently treated
as part of this local ASM audit. The ASM audit independently checked the bridge
and found no substantive gap; it did not recertify the entire dependency chain.

The finite-field-solvability non-elimination consequence is included as a model-
relative interpretation of the same lower bound. A broad statement about all
symmetry-preserving computation, rank-enabled computation, symmetric circuits,
or unrestricted Turing space is not justified. A completely written machine-
level solvability-preprocessing compiler remains separate from the source's
logical definability assertion.

Main files:
  novelty_and_consequences/ASM_COUNTING_SPACE_BRIDGE.md
  novelty_and_consequences/NOVELTY_AND_FOUNDATIONAL_CONSEQUENCES.md
  novelty_and_consequences/PRIOR_ART_COMPARISON.md
  counting_space_audit/BLIND_RECONSTRUCTION.md
  counting_space_audit/COMPARISON_AND_VERDICT.md

OUTCOME 2: DEGREE-ONLY RATIONAL APPROXIMATION BOUND

For each fixed positive real algebraic number alpha != 1, of degree
  d = [Q(alpha):Q],
the reconstructed and audited research proof gives
  mu(log alpha) <= 2d.
Precisely, for every real nu > 2d there is a threshold Q0(alpha,nu) such that
  |log alpha - p/q| > q^(-nu)
for every integer p and positive integer q >= Q0(alpha,nu).
No effectiveness of Q0, height-uniform onset, endpoint constant, bounded partial
quotients, or general exponent-two theorem for d > 1 is claimed.

The argument reconstructs moving-center interpolation (MI) from supplied
family017 geometry, selects a nonzero full-row jet minor over Q(alpha), clears
all denominators entrywise, bounds every conjugate before taking the norm, and
closes the grouped Taylor collision comparison with an explicit asymptotic
parameter schedule. The norm charges the denominator cost d times. Fixed
height and conjugate magnitudes enter errors absorbed only after alpha is fixed.
Approximants and all finite parameters are fixed before the final degree H
tends to infinity.

MI is reconstructed and independently checked as part of this proof. It is not
an additional leftover unproved assumption. The independent record checked the
moving-center geometry, ordinary-Rees-power/Serre interface, arithmetic clearing,
all embeddings, and order of limits, then compared the two derivations. Their
agreement does not certify the supplied extraordinary research machinery to the
mathematical community. Standard algebraic-geometric inputs remain imported.

The original blind audit files preserve chronological interim wording; the
COMPARISON_AND_VERDICT files and this README state the completed audit status.
Editorial release copies normalize source pointers and process labels only;
original pre-comparison SHA256 fingerprints are preserved in the audit and
PACKAGE_PROVENANCE.json. They are not represented as the hashes of edited copies.

Source017's pinned documentation claims the pi irrationality-exponent-two
statement has been formalized. Lean/Comparator were not replayed for this
record. That documented source formalization does not formally verify this
moving-center or algebraic-logarithm extension.

The d=1 rational-logarithm endpoint is already claimed in Liu--Jiang--Zhang,
arXiv:2610.10192v1, submitted 7 October 2026. Its Theorem 2 also supplies the
matching moving-center statement. The rational case is not claimed as new here.
The targeted primary-literature search did not locate the exact general
height-independent 2d rational-approximation theorem; this is not proof of
novelty. Approximation by rationals and approximation by arbitrary elements of
Q(alpha) are different problems and are explicitly distinguished.

Main files:
  number_theory_bridges/ALGEBRAIC_LOGARITHM_CANDIDATE.md
  number_theory_bridges/PRIOR_ART_AND_SOURCE_PINS.md
  algebraic_log_audit/BLIND_RECONSTRUCTION.md
  algebraic_log_audit/COMPARISON_AND_VERDICT.md

SCOPED SECONDARY LIMITATION: THE EXPONENT-TWO SHORTCUT

number_theory_bridges/EMBEDDING_GATE_AND_NOGO.md records a limited matched-
embedding argument and a Pell-type counterexample to an invalid generic norm
improvement. For F=Q(alpha,c), alpha != 0,1, c != 0 and alpha=exp(c lambda),
Gelfond--Schneider plus a finite-normal-closure argument restrict matching
embeddings to sigma(c)=+c or -c, hence at most two. For c=1 only the identity
matches. The independent audit checked this restriction.

A suggested 2[F:Q]/r refinement for r matching embeddings is not promoted to a
third fully proved theorem in this record: its full written geometric/arithmetic
extension would require its own completed proof. Roots of unity need an additional
bounded-fiber/common-fiber interpolation argument because powers repeat. The
period case alpha=1 is excluded. The barrier blocks this particular matched-
embedding shortcut; it neither disproves generic exponent two nor excludes other
methods. Exact conjugate annihilation or unit rescaling alone does not remove the
norm's degree cost. Approximate conjugate suppression at unchanged arithmetic
cost remains an explicit unproved possible next lemma.

REPRODUCIBILITY AND LIMITS OF COMPUTATION

From the extracted top directory:
  python3 REPRODUCE.py

Requirements: Python 3.10+ and SymPy 1.14.0 for the exact number-field ledger.
The package was replayed with Python 3.12.14 and SymPy 1.14.0. requirements.txt
records the tested dependency. No network access or downloaded source execution
is needed by the checks. The reproduction wrapper runs copied scripts in a fresh
temporary directory and compares their JSON results with the saved record; it
does not rewrite the frozen scientific files.

For standard-library checks only:
  python3 REPRODUCE.py --quick

Finite checks rerun for this archive:
- ASM graph semantics: 64 pair projections, 64 states, 320 lookups, 13,504
  state/update comparisons including 1,920 clashes, and 2,000 write/delete
  cycles. All passed; the cyclic coded closure peaked at 20.
- Exact algebraic ledger: five actual 8-by-12 jet matrices, each rank 8,
  including nonintegral cases, a shared denominator prime, negative conjugates,
  and a cubic field with nonreal conjugates. Integral clearing, nonzero integral
  norms, and determinant scaling identities all passed. Twelve exact rational
  parameter schedules and 54 rational-power jet valuation cases passed.
- Independent scalar schedule: four exact-rational/log-domain stress cases,
  including nu=2.01d and a large fixed conjugate-height allowance. All passed.

The exact ledger does not prove interpolation or an asymptotic theorem. The
schedule stress test uses conservative floating-point bounds after exact rational
choices and does not instantiate actual good approximants or every geometric
separation threshold. The ASM tests do not generate a complete BGS syntax tree.
The scientific proofs, not finite checks, support the general statements.

REPLAY_REPORT.json gives the selected rerun results. SHA256SUMS.txt covers every
other bundled file. PACKAGE_PROVENANCE.json records source and release hashes and
any editorial normalization. These files establish integrity and reproducibility,
not mathematical certification.

OPEN QUESTIONS AND NEXT GATES

1. External specialist review of the moving-center geometry and the whole
   algebraic-logarithm proof; formalization of this extension if pursued.
   No residual MI lemma is being relabeled as an open proof obligation.
2. A broader primary-source priority review of the exact general 2d theorem,
   and of the exact Boolean-query, counting, arbitrary-rank/runtime,
   exponential-peak-space conjunction. Existing symmetry/memory and rational-
   logarithm antecedents must continue to be credited.
3. Generic mu(log alpha)=2 for arbitrary positive algebraic alpha != 1 remains
   unproved here. Removing the degree cost requires a new determinant-specific
   arithmetic or multi-embedding saving, not merely adjusting constants.
4. A full generated-syntax/compiler verification would strengthen the counting
   bridge evidence. Any new primitive or altered resource convention needs a
   fresh bridge; no universal counting-enrichment theorem is asserted.

This record freezes the present outcomes. The items above are review or future
research gates, not a representation that those tasks have been completed.

EARLIER RECORDS PRESERVED

Astra_First_Research_Record_2026-10-09.zip
SHA256: 462d065f38b2b070bab918d24dbde8517017d95437567b954e02e796bdbf66d0

Astra_HF_Space_Simulation_Addendum_2026-10-08.zip
SHA256: 83be82c44506109a567f4ec41a737f7222bc323e07ad1c0a1f2b863c92ef91d0

Their bytes were checked before and after this build and remain unchanged.
Their contents are not duplicated inside this compact second record.
