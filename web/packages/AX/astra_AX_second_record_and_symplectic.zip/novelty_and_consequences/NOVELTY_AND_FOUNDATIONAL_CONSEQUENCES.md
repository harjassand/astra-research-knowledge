# Novelty screen and bounded foundational consequences

Assessment date: 2026-10-08, 16:48 UTC. All claims below are scoped to the actual formalism. The record distinguishes source-reported results, derived consequences, mathematical audits, executed finite tests, and historical priority. No result here is formally certified or externally reviewed.

## Decision

Preserve the candidate as a substantial, plausibly new **exponential peak-hereditary-space lower bound for a PTIME decision query with counting and arbitrary finite rank/runtime**. Do not advertise symmetry-based memory lower bounds, large-orbit arguments, or noncapture of CPT as new discoveries.

A more meaningful next consequence than a generic circuit analogy is a precisely stated negative answer to the counting version of Ferrarotti–Schewe's 2024 choiceless-space question. A local peak-space ASM bridge is reconstructed in `ASM_COUNTING_SPACE_BRIDGE.md`; it has now passed a separate blind reconstruction and adversarial mathematical comparison, with no substantive gap reported. The qualitative consequence already follows from source243's grid machinery once runtime-independent coding is supplied. KOW is needed for the much stronger exp(Omega(N)) quantitative upgrade.

No broader unrestricted complexity separation is established. The scoped bridge has completed the mathematical audit described below; the result should remain within its precise descriptive-complexity boundary.

## Exact candidate under review

There is a fixed all-input isomorphism-invariant PTIME linear-consistency query Q over F_3 in a fixed binary vocabulary. On an infinite family of opposite-answer input pairs, each with N atoms, every fixed Rossman/GKPS term program with Card deciding Q must use peak inclusive hereditary live-state size exp(Omega_P(N)) on at least one input. Runtime may be any finite value. Fixed program width is charged in the constant. Atom count N, not arbitrary bit-encoding length, is the parameter; the hard structures are bounded-degree and have O(N) relational tuples.

The proven-model chain is: source243 group/base/HF-transfer mechanism + coefficient-uniform collective cofilling on bounded-degree complexes + individual-orbit interpretation-trace bound + history-independent HF/interpretation simulation. Validity remains conditional on those mathematical inputs and the stated model conventions. The mathematical audits are not external certification.

## What is demonstrably already known

The full proof-level report is `PRIOR_ART_COMPARISON.md`. Primary-source links are given there and in `../EVIDENCE_PINS.txt`; downloaded papers are not bundled.

1. **Peak memory and orbit closure:** Pago, CSL2021, §2 and p.33:3 already place an activated object's entire orbit in a single invariant stage and explicitly extend the functional preorder obstruction to polynomial-space computations. Its hypercube family and functional task do not give an exp(Omega(N)) Boolean-query lower bound. Here |Aut(H_n)|=2^n n! while N=2^n, so the group is too small even to permit such an orbit lower bound.
2. **Exponential maximum gate orbit:** Dawar–Wilsenach, ITCS2022, Theorems 16, 18 and 19 use subexponential orbit-to-support conversion and a pebble-game lower bound for alternating-group-symmetric determinant circuits. The hard determinants have opposite signs but the same nonsingularity answer. Its global circuit action, arithmetic basis and input-size parameter do not constitute a compiler from the present adaptive HF computation model.
3. **Functional Card-enabled obstruction:** Rossman 2010, Theorem 6.1, excludes constructing the hyperplanes/dual of a finite vector space. The local construction argument is strong and runtime-independent in spirit. It is not a Boolean separation; its GL(d,q) action on N=q^d atoms likewise has at most exp(O(log^2 N)) elements.
4. **Unrestricted HF rank matters:** Dawar–Richerby–Rossman 2008 show an Abelian support bound (log m)^rank and a low-rank lower bound, while positively defining the same preordered CFI query with unbounded rank. Dropping the rank hypothesis is a false inference.
5. **Circuit extraction gap remains in the primary paper:** Pago MFCS2023 yields polynomial-size XOR circuits only under an additional CFI-symmetry/symmetric-basis condition; its lower bound requires stronger orbit and parent/child conditions than extraction supplies. This is not a full CPT lower-bound theorem in disguise.
6. **Time equivalence is not space equivalence:** GKPS15's published simulator retains old domains and concludes using a runtime factor; GSW20/SODA21 measures m+sum_i |V(A_i)|. Neither states the needed bound in peak live HF closure for arbitrary finite runtime. The candidate's garbage collection, dynamically bounded Card reserve and resettable incidence compiler are additional arguments.
7. **No-counting polynomial space was already separated:** Ferrarotti–Schewe 2024 §4 prove a Parity obstruction for their no-Card ASM space model, and §5 leaves counting as a future question. Older no-counting zero-one laws also discuss polynomial-space behavior; no claim of being first to separate choiceless space in general is justified.

No checked older primary result implies the exact conjunction of decision query, Card, all ranks, arbitrary finite runtime and exp(Omega_P(N)) peak hereditary memory. This is a targeted negative result, not novelty certification. New copies of our derived records in Astra or elsewhere are not independent prior art or review.

## Source243 and its witnessed-choice companion

Pinned original source: openai/math commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`, consulted on 2026-10-08 at 14:54 UTC. Relevant primary source directory:
https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026

The read text explicitly gives:
- the all-input PTIME linear-consistency query;
- rank-independent support O(L(q log N)^2) on three-dimensional grids;
- a quantitative supported-HF transfer theorem;
- finite interpretation formulas whose **length** depends on B but whose **variable width** does not;
- a total-trace bound 9B^3 used with polynomial runtime;
- definability in FPS_3 and FPR_3.

The witnessed-choice companion gives a separate all-input WSC-defined query and a strict CPT/WSC expressiveness result on grid pairs. Its complete term-evaluation trace is also bounded using polynomial runtime. It does not state an exponential peak-space result or the collective-cofilling upgrade. Its positive witness construction orders a grid using a bounded tuple of distinguished vertex blocks, a hypothesis not automatically available for the new expander bases. Therefore it cannot simply be quoted for an exp(Omega(N)) WSC space advantage on the expander family.

### Exact qualitative extension of source243

Let S be the largest universe in two finite interpretation runs. The H-orbit of each vertex code/payload is at most S; a preceding-vertex pair and its wrappers have orbit at most S^2; pure ordinal tags have orbit one. Every recursive constituent belongs to one of these cases at some stage, no matter how many stages exist.

If S<=N^q with q fixed, source243's support proposition gives s=O_q(L log^2 L). Its original M=floor(L^(7/4)) yields the needed O_{q,m}(L^(3/2)log^3 L)=o(M) homogeneity width. The supported domains therefore agree on the translated fixed-width formulas. Choose a finite common B bounding the two actual runtimes/state sizes; no polynomial B is necessary for syntactic width. At the earlier halt the other run must halt with the same output, contradiction.

Thus the source's **unbounded-time polynomial-state** consequence follows before KOW. The audited HF simulator and the new ASM graph bridge then transfer it to the corresponding live-memory formalisms. This is the clean provenance boundary: the new space handling extracts a stronger qualitative consequence from source243; collective cofilling gives an exponential quantitative strengthening.

## At most two genuine broader consequences

### 1. Counting does not rescue choiceless polynomial space

**Exact theorem target.** Define CPS(Card) by Ferrarotti–Schewe's deterministic finite-support, fixed-arity ASM syntax, adding ordinary von Neumann Card. Then PTIME is not contained in CPS(Card), witnessed by Q. In particular CPS(Card) does not capture PSPACE. On the expander family every fixed deciding ASM requires exp(Omega_M(N)) peak active-object count.

**Why it matters.** This excludes unlimited-time reuse of polynomial HF memory as a way around CPT's polynomial-time obstruction. It addresses an explicit 2024 question about a strictly more permissive resource setting, with counting and all HF ranks retained.

**Precise bridge.** The source does not formally define counting. We specify it and encode each finite-support dynamic function by its nonzero graph inside a tagged HF root. An r-ary graph has at most W^r entries when all nonzero-location arguments and values lie in the active family of size W. Assignment, branching and parallel rules yield fixed bounded-comprehension update terms; exact clash handling and zero-valued deletion restore one current graph root. The existing fixed-term footprint theorem bounds temporary work by W^{O_M(1)}, without a time factor.

**Status/missing obligation.** Full mathematical derivation is in `ASM_COUNTING_SPACE_BRIDGE.md`. The separate blind reconstruction and adversarial comparison reported no substantive gap at 16:51 UTC; the result still inherits source243's and the previously reconstructed transfer/simulation dependencies. No specialist priority validation has occurred. A literature sweep found only arXiv v1 for Ferrarotti–Schewe and no later primary paper resolving its counting question, but this is not exhaustive.

**Falsifier.** A permitted source primitive, state component or update behavior not faithfully expressible by a fixed term of polynomial footprint; e.g. uncharged nonzero location arguments, a succinct-number primitive, powerset, or history that cannot be removed. In the inspected syntax arguments/values are charged; none of the excluded primitives is present. Direct tests additionally target false truthiness, duplicated/conflicting updates, deletion and sibling-update visibility.

**Priority nuance.** The qualitative theorem follows already from source243 plus the new space bridges. It should not be described as a wholly independent 2026 noncapture breakthrough or as requiring the KOW exponential upgrade.

### 2. A single finite-field solvability operator cannot be eliminated with subexponential HF space

**Exact statement.** The query Q is definable by one F_3-solvability operator applied after polynomial-space choiceless preprocessing, as source243 §8 explicitly constructs; alternatively two rank tests suffice. Therefore no general translation eliminating that operator into the specified fixed Card-enabled HF terms can preserve subexponential peak hereditary memory on all inputs, even if arbitrary finite runtime is allowed. Quantitatively, a polynomial-memory source computation has exp(Omega(N)) target memory on the hard family.

Equivalently, FPS_3 and FPR_3 are not contained in the just-defined CPS(Card) once consequence 1's bridge is accepted. This is a model-relative noncontainment, not an assertion that all PTIME escapes all linear-algebraic logics.

**Why it matters.** It identifies a concrete primitive-level barrier: keeping all data invariant while allowing structured finite-field linear algebra is qualitatively stronger than merely iterating set construction and cardinality. Unlimited time is insufficient to compile away this algebraic primitive with polynomial memory.

**Precise bridge.** The input matrix has explicitly definable polynomially many tuple-indexed rows/columns. Its coefficients are bounded counts modulo three, representable by ordinary Card and bounded pure-ordinal arithmetic. The source243 all-ones/0–1 matrix normal form uses one solvability call. A fully syntactic extension of the fixed HF model by this operator would need its matrix encoding and the polynomial preprocessing bound written out; the source gives the logical formula but not this machine-level compiler.

**Falsifier.** A purported small-memory Card-only implementation of this precise matrix-solvability call, verified against the model and resource conventions, would contradict the lower bound. A rank/solvability primitive itself is instead a boundary control: it is equivariant and decides Q with polynomial explicit storage, so the phrase 'all symmetry-preserving computation requires exponential space' is false.

**Research value.** This sharpens an already source-reported FPS/FPR-vs-CPT separation to unlimited-time space. It is useful mathematical positioning, not by itself a route to a second historic breakthrough.

## Claims and paths to reject now

- No unrestricted Turing-space lower bound or P-vs-NP consequence follows.
- No general symmetric-circuit lower bound follows without a group-, basis-, and peak-space-preserving translation. Ordinary time-unrolling does not suffice.
- No impossibility theorem for every PTIME logic follows: a rank/solvability primitive is already a counterexample to the premise that symmetry and small HF state alone enforce the same transfer argument.
- No expander WSC consequence should be claimed without proving a replacement for the companion's grid-ordering and legal-history-witness construction.
- No near-optimal constants or exponent polishing is currently a high-value continuation.

## Executed finite checks and limits

`check_asm_graph_updates.py` uses actual HF Kuratowski codes rather than Python tuple identifiers for stored graphs. It completed 64 pair projection/injectivity cases, 13,504 state/update comparisons (including 1,920 clashes), 320 lookups, 64 sparse-state encodings and 2,000 write/delete cycles. All passed. The cyclic test returns exactly to the same initial graph and has bounded peak closure, demonstrating the intended current-state reset mechanism on the tested family.

These are semantic tests; they do not generate or execute the full target BGS syntax, certify the asymptotic proof, or supply independent expert validation.

## Recommended next action and stopping condition

The ASM-to-fixed-term peak-space bridge has passed the requested separate reconstruction and comparison. Preserve the counting-space corollary with explicit attribution to source243 and the exact Card extension, the exponential theorem, and the dependency ledger. Any later counterexample to the source primitive or state-charge assumptions must narrow the corollary rather than be hidden under a broad CPS claim.

With that local gate closed, pivot the broader foundational search unless a specific new bridge reaches a recognized open problem outside these already-separated invariant-HF models. There is currently no justified claim of such a bridge.
