# A peak-space bridge for finite-support ASM dynamic functions

Derivation: 2026-10-08, begun 16:41 UTC. Status: mathematical reconstruction; a separate blind reconstruction followed by adversarial comparison reported no substantive mathematical gap on 2026-10-08 at 16:51 UTC. Not formal certification or external expert review. This is a separately stated extension of the previously audited fixed-term theorem. It must not be treated as already covered by that theorem's published source or original scope.

## 1. Exact source and question

Ferrarotti–Schewe, *Choiceless Polynomial Space*, arXiv:2401.16366v1, 29 January 2024, 12 pages. The arXiv abstract page checked on 2026-10-08 lists only v1. The work is an arXiv preprint; no journal publication was established in this check.

Primary URLs:
- https://arxiv.org/abs/2401.16366
- https://arxiv.org/html/2401.16366v1
- https://arxiv.org/pdf/2401.16366v1

Relevant text: §2.1, pp.2–3 (background and finite-support dynamic functions); §2.2, pp.4–5 (term and rule syntax); §2.3, p.5 (active objects, simultaneous updates and per-state space); §5, final paragraph p.11 (question about counting).

The listed primitives are Pair, Union, TheUnique, Empty, Atoms, Boolean operations, equality, membership, input relations and finite-arity dynamic functions. There is **no Card**. Its noncapture proof uses Parity and therefore cannot survive Card(Atoms). In §5 the authors ask whether CPS with counting captures PSPACE. They do not formally define that extension.

Accordingly define **CPS(Card)** here to mean exactly their finite-support deterministic ASM formalism extended by the ordinary BGS cardinality operation: Card(a) is the von Neumann ordinal |a| for sets and Empty for atoms. No choice, powerset, succinct numerical oracle, unbounded comprehension, or additional background operation is added.

The 2024 arXiv page includes a text-overlap notice pointing to arXiv:2005.04598. That is a separate choice-based manuscript, currently v8 January 2025; its advertised PTIME-capture claims are not used. Choice is outside this bridge.

## 2. Bridge statement

Fix such an ASM M with fixed finite dynamic signature and one closed rule. Its input vocabulary is fixed unary/binary, matching the source243 query. For any finite run S_0,...,S_h define

    W = 4 + max_i |Active(S_i)|.

Active(S) is the source's inclusive hereditary closure of the atoms, 0, 1, all dynamic-function values, and every argument of a location whose value is nonzero. The input atoms are already counted.

There is one fixed Rossman/GKPS BGS term program T_M with Card simulating the same finite run and halt/output behavior, with maximum native-state inclusive hereditary size at most C_M W^{d_M}. The bound has no dependence on h. In fact the encoded ASM checkpoint roots alone obey C_M W^{r}, where r=max(1, maximum dynamic-function arity). The fixed term's temporary evaluation footprint is bounded by a possibly larger fixed polynomial in W.

Consequently composing with the independently audited history-independent interpretation compiler preserves polynomial peak space and transfers its exponential lower bound to these ASMs. This statement covers finite runs/prefixes and accepting/rejecting total computations. It does not claim to decide whether a general partial program will halt.

## 3. Encode the finite function graphs

Use injective fixed-length HF tuple codes made from Kuratowski pairs, uniformly for atoms and sets. For each dynamic symbol f of arity r_f let

    G_f(S) = { <a_1,...,a_{r_f},b> : f_S(a_1,...,a_{r_f})=b != Empty }.

Nullary functions are included, with the empty key tuple. A fixed tagged tuple of the finitely many G_f is the state code E(S). Wrap it using a fixed pure tag so that E(S) is never a Boolean halt value. Tags and the wrapper use O_M(1) HF objects and never choose atoms.

Every a_j and b in an entry belongs to Active(S), together with all their hereditary members. Functionality gives at most |Active(S)|^{r_f} nonzero entries for f (one if r_f=0). Every fixed-length tuple entry introduces only O_M(1) pair/wrapper objects. Thus

    |cl({E(S)})| <= C_M (1 + |Active(S)|)^r.

The input relations remain external static predicates over input atoms. No relation table, order, chosen representative, or earlier state is stored in the code. Function names are represented by distinct fixed pure tags; the names themselves are not input atoms.

Kuratowski projections and fixed tuple projections are bounded BGS terms. For a valid ordered pair p=<a,b>, its first component is the unique member of the intersection of p, and its second is the unique member of Union(p) minus {a} when that difference is nonempty, otherwise a. Intersection and the test use comprehensions bounded by Union(p), p and their members. The displayed decoding equations are asserted only for valid fixed-shape codes. The projection expressions themselves are total HF terms: eager evaluation of a discarded conditional branch may apply them to a startup sentinel or malformed candidate, but the result is unused and the fixed-term polynomial footprint bound still applies.

## 4. Exact translation of terms and Boolean guards

Translate a dynamic application f(t_1,...,t_r) by first translating its arguments, then taking TheUnique of the set of final components of entries e in G_f whose key matches the argument tuple. There is either one value or none. In the latter case TheUnique(Empty)=Empty, exactly the dynamic default. Distinct tuple encodings cannot introduce spurious matches.

All source background operations are the same operations in the target, including the explicitly added ordinary Card. Input tests, equality, and membership are exact. If membership is not taken as a target primitive, u in v is equivalent to the nonemptiness of {true : z in v and z=u}. Atoms have no members.

Source Boolean operations default to 0 on non-Booleans; translate with explicit tests that each operand belongs to {0,1} where necessary. The source rule guard takes its first branch precisely when its value is 1, and the else branch otherwise. Translating this as a comparison with true, rather than treating every nonempty HF object as truthy, preserves the source convention.

Bounded source comprehensions become bounded target comprehensions with the translated dynamic lookups. Every subterm sees the same frozen pre-update graph state. There is no sequential exposure of updates from sibling parallel rules.

## 5. Construct exactly the simultaneous update set

Represent an update by a tagged tuple <f,key,value>. A value of Empty must be retained at this stage: it means deletion, not absence of an update.

By structural induction on the fixed source rule r define one bounded BGS term U_r(E(S),parameters):

- skip: Empty
- assignment f(t_1,...,t_r):=t_0: the singleton of the corresponding translated update
- if guard then r_1 else r_2: U_{r_1} if the translated guard equals true, otherwise U_{r_2}
- forall v in t do r(v): Union({U_r(E(S),v) : v in translated(t)})

Every union is a set union, so identical duplicated updates are harmless. The fixed nested parallel-rule depth merely nests a fixed number of bounded comprehensions. There is no unbounded rule syntax or stored recursion stack.

The resulting U is exactly the source update set. A bounded double comprehension detects a clash iff U contains two entries with the same function tag and same key but different values. If any clash exists, return E(S) unchanged, matching S+U=S in §2.3.

If U is consistent, set

    G'_f = {e in G_f : no update in U_f has key(e)}
           union {e in U_f : value(e) != Empty},

after deleting the function tag from the retained update codes. This uses bounded comprehensions and unions. It implements simultaneous overwriting, including overwriting by Empty, exactly. Unchanged keys survive; every updated key has its unique specified value; zero-valued entries are omitted. All functions are updated from the same S and U before the new tagged root is returned.

In particular, deleting a nonzero value does not discard an old key too early, and conflicting updates are not resolved by choosing one. The construction never chooses an update or function-graph representative.

## 6. Initialization, halting and history independence

Initially all dynamic graphs are empty. Starting at the native Empty state, the first term step installs the fixed initial graph tuple. That tuple is distinguishable from Boolean values by the fixed wrapper. On each later call:

1. If the decoded source Halt is true, return the Boolean indicated by Output.
2. Otherwise construct the successor graph tuple as above.

Thus the first source halt is detected before any further source update. One startup and one terminal Boolean step are the only extra native checkpoints. For the decision applications, accepted and rejected runs have Output 1 or 0; partial/non-Boolean terminal behavior can instead be preserved in a tagged terminal code, and is unnecessary for the lower bound. A fixed finite source control flag, if desired, is just an additional nullary dynamic symbol.

The new root contains exactly the current function graphs and their data. It does not contain U, E(S), or any previous graph unless the **source's actual new values themselves** retain such objects. Hence histories cannot accumulate in the live native state merely because the simulation has run for a long time.

The checkpoint estimate from §3 applies freshly to every S_i. Translating one fixed rule produces one fixed BGS term; the existing fixed-term footprint lemma bounds all its temporary values by a polynomial of its current root closure and the input. Combining these is a local invariant in W, not an iterated polynomial in the previous simulator's total universe.

## 7. Polynomial guards and exact source semantics

Ferrarotti–Schewe define a bounded run as the longest prefix in which every state has at most p(n) active objects. For a program that accepts or rejects a structure, its unbounded underlying ASM run reaches the same halt without violating this guard. Therefore it is sufficient to simulate the underlying ASM on such inputs. One need not compute the active-object count, simulate a default for an oversized state, or decide divergence to transfer a lower bound against programs deciding Q on all inputs.

For promise separation the same reasoning applies on the two explicitly required finite, guarded runs. An oversized or nonhalting run outside the promise is irrelevant. This is why the bridge does not need a new hereditary-closure primitive merely to test the source polynomial annotation.

The source's Active(S) charges arguments only at nonzero locations. Zero assignments to many previously absent keys may produce temporary update sets larger than Active(S); the fixed syntactic footprint lemma, not an unjustified O(W^r) bound on U, controls these temporaries. It is essential that ranges are bounded terms with fixed syntax and no powerset primitive.

## 8. Exact consequence and provenance

Conditional on the source243 group/base/HF-transfer proofs and our independently audited history-independent interpretation coding, **there is an ordinary-PTIME binary-vocabulary query Q not decided by CPS(Card)** as explicitly defined above. Hence this counting model does not capture PSPACE either. This answers negatively the standard-counting version of the question raised in the final paragraph of Ferrarotti–Schewe, rather than a broader unspecified collection of possible counting primitives.

The **qualitative** consequence does not require KOW expanders or the new linear-logarithmic support estimate. On source243's original grids, N=Theta(L^3), every constituent of a finite interpretation trace has orbit at most S^2 where S is peak state size. If S=N^{O(1)}, source243 yields support O(L log^2 L). Its fixed-width HF transfer applies exactly as in its proof. Choosing a finite B bounding the two actual runtimes and state sizes makes the same translation exact; formula length depends on B but width does not. Thus the two outputs agree. The only changed resource step is the orbit bound being state-local rather than a total-trace count.

The **exponential** consequence additionally uses the new collective-cofilling/expander argument: for each fixed deciding ASM M, on one input of each sufficiently large hard pair its peak number of active objects is exp(Omega_M(N)). If the intermediate fixed-term or interpretation compiler costs C W^d, the exponent constant is simply divided by d. This preserves the same original atom size N.

Do not credit the noncapture query, rank-independent group-support method, or arbitrary-rank HF transfer to this bridge. They are source243's supplied inputs. Do not credit the standard idea of storing finite function graphs as new by itself. The separately checkable claim is its runtime-independent space accounting and the resulting precisely scoped counting-space consequence.

## 9. Falsification and independent-audit gates

A direct counterexample to any of the following invalidates this bridge:

- Two distinct allowed source functions have identical graph codes or a graph lookup misdecodes a zero/atom/high-rank value.
- A source deletion fails to delete, a duplicate update becomes a clash, or a clash partially changes a state.
- A sibling update is seen by a parallel rule during the same source step.
- A non-Boolean guard is interpreted as true merely because it is nonempty.
- Some source primitive creates superpolynomial hereditary footprint from polynomial arguments; the stated signature excludes the obvious powerset/succinct-number failures.
- The source definition omits from Active(S) data actually needed in a nonzero dynamic tuple. Reading §2.3 shows that it explicitly includes every such argument and value.
- The live coded root retains old graph wrappers after deletion or accumulates a step-index ordinal.

The accompanying finite test checks the function-graph/update part with actual HF pair codes. It does not generate a full BGS syntax tree or replace independent proof review. A separate blind reconstruction and subsequent adversarial comparison have now reported no substantive mathematical gap. The original blind reconstruction is retained at `../counting_space_audit/BLIND_RECONSTRUCTION.md`. The reviewer's single exposition caveat about eager evaluation of projections on unused branches has been incorporated above.
