# Prior-art check: choiceless peak memory and symmetric circuits

Research date: 2026-10-08. Scope: primary mathematical papers, with relevant proofs read locally. This is a targeted negative search, not a certification of historical novelty or of the candidate proof.

## Bottom line

I found no published theorem in the checked papers that already implies the exact combination in the candidate: an ordinary-PTIME **decision** query on fixed binary structures, **Card allowed**, **all finite HF ranks**, **arbitrary finite runtime**, and **exp(Ω_P(N)) peak live hereditary memory** for each fixed term program.

Several ingredients and nearby conclusions are emphatically prior art. In particular, the elementary principle that an invariant live HF state contains each constituent's entire automorphism orbit is already used explicitly as a **space**, not merely a time, obstruction by Pago (CSL 2021). Exponential maximum-gate-orbit bounds for restricted symmetric circuits also predate the candidate. A novelty claim should concern the conjunction above and the new bridges/quantitative support input, not the invention of symmetry-based memory bounds.

## 1. Pago, CSL 2021: genuine peak-space antecedent, functional scope

Primary published paper: [Choiceless Computation and Symmetry: Limitations of Definability](https://drops.dagstuhl.de/storage/00lipics/lipics-vol183-csl2021/LIPIcs.CSL.2021.33/LIPIcs.CSL.2021.33.pdf), DOI 10.4230/LIPIcs.CSL.2021.33.

Read §2, §4, §6, including Theorems 2 and 13 and the supporting-partition proof structure. Section 2 models a run as a sequence of symmetric HF states with polynomially bounded transitive closure. Its obstruction places the full orbit of a computed constituent into the **same stage**. Page 33:3 explicitly extends the observation to polynomial-space computation. Theorem 2 prohibits representing sufficiently fine preorders on all hypercubes inside polynomial-size invariant HF states. Published Theorem 13 concerns HF objects using all hypercube vertices as atoms and having only O(n) atoms at each membership-depth level. Its orbit is superpolynomial in 2^n.

**Obstacle:** this is a functional/preorder construction problem, not a PTIME decision separation. Moreover N=2^n and |Aut(H_n)|=2^n n!. Thus every orbit is at most exp(O(log N log log N)), far below exp(Ω(N)). The published theorem does not supply the candidate's bound.

**Version caution:** arXiv:2401.07147 reformulates Theorem 13 using ordered partitions. The published 2021 theorem uses level widths; do not silently interchange their wording.

## 2. Pago, MFCS 2023: the circuit transfer has explicit gaps

Primary published paper: [Lower Bounds for Choiceless Polynomial Time via Symmetric XOR-Circuits](https://drops.dagstuhl.de/storage/00lipics/lipics-vol272-mfcs2023/LIPIcs.MFCS.2023.73/LIPIcs.MFCS.2023.73.pdf), DOI 10.4230/LIPIcs.MFCS.2023.73. Full proof: [arXiv:2302.05426](https://arxiv.org/abs/2302.05426).

Read published Theorems 1, 2, 11, 16; full-version Theorems 31–33, 67, 68 and their proofs/discussion. The polynomial-size XOR-circuit extraction requires a CFI-symmetric object, or a more general symmetric-basis hypothesis. Full-version Theorem 32 explicitly leaves the circuit size uncontrolled without that hypothesis. The lower bound additionally requires circuit orbit size one and logarithmic orbit-wise parent/child counts; the extraction yields merely polynomial circuit orbit and logarithmic fan-in **dimension**. Section 9 explicitly leaves this gap unresolved.

**Obstacle:** it does not even separate the full stated CFI-symmetric algorithm class from PTIME, much less all Card-enabled fixed HF programs. It gives neither the desired arbitrary-runtime peak-space result nor the exp(Ω(N)) estimate. The actual theorem details matter more than the broad paper title.

## 3. Dawar–Wilsenach, ITCS 2022: exponential orbit bounds exist already, for different machines

Primary paper: [Lower Bounds for Symmetric Circuits for the Determinant](https://drops.dagstuhl.de/storage/00lipics/lipics-vol215-itcs2022/LIPIcs.ITCS.2022.52/LIPIcs.ITCS.2022.52.pdf), DOI 10.4230/LIPIcs.ITCS.2022.52.

Read circuit definitions, Theorems 14–19, and determinant construction/proof. Theorem 16 converts subexponential maximum gate-orbit size into sublinear support for alternating-group-symmetric circuits. Theorem 18 combines a linear pebble-game obstruction with this support theorem. Theorem 19 rules out subexponential-size Alt_n×Alt_n-symmetric determinant circuits over characteristic zero. The proof actually forces a large **maximum gate orbit**, not merely many gates spread over a long computation. The text immediately following Theorem 18 expressly says the orbit-support step needs a large alternating group. The hard determinant pair differs by a column swap and has opposite nonzero determinants.

**Obstacles:** this is an arithmetic/circuit statement with a prescribed global action on input variables, not a theorem about arbitrary HF programs. The determinant pair has the same nonsingularity answer and is not a linear-consistency decision obstruction. Rank gates are not licensed by the theorem. Hence this is substantial conceptual precedent, not an implication of the candidate.

## 4. Rank gates are an important negative control

Primary full proof: Dawar–Wilsenach, [Symmetric Circuits for Rank Logic](https://arxiv.org/abs/1804.02939), published in ACM TOCL, DOI [10.1145/3476227](https://doi.org/10.1145/3476227); earlier CSL 2018 version.

Read full-version §3.3, Theorems 3.15/3.17 and §4.1. Theorem 3.15 characterises FPR by P-uniform transparent symmetric rank circuits. Theorem 3.17 shows that adding arbitrary **fully symmetric Boolean** gate functions does not exceed symmetric-majority-circuit power. A matrix-rank gate is different: it retains a structured row/column incidence pattern and is not fully symmetric in its individual input bits. Their support theorem does extend to rank circuits, but counting-game indistinguishability no longer suffices for evaluating the gates.

**Independent implication:** an explicitly represented finite-field linear system can be tested by comparing rank(A) with rank([A|b]); polynomially many rank-threshold gates suffice. Consequently a lower bound attributed to 'symmetry alone' or to all symmetric circuits would be overbroad. Card-enabled HF terms have no primitive rank operator. This does not contradict the candidate's expressly narrower model.

## 5. Rossman 2010: local construction supports with counting; functional separation

Primary author paper: [Choiceless Computation and Symmetry](https://www.math.toronto.edu/rossman/yg70.pdf), published in LNCS 6300, pp. 565–580, DOI 10.1007/978-3-642-15025-8_28.

Read Definitions 2.5–2.6, Lemma 4.5, Proposition 4.3, Theorem 6.1 and Proposition 6.2/proof. The syntax includes Card. Lemma 4.5 is a **local term** support/constructibility induction. Proposition 4.3 applies it to the finite unrolled computation using a bound on all activated objects. Theorem 6.1 rules out constructing the hyperplanes/dual of a finite vector space in CPT+C, although the output is polynomial-size.

**Inference, not a printed theorem:** the local induction is a natural starting point for arbitrary-runtime, peak-space variants once a per-step footprint bound is proved. The paper's resource definition itself uses cumulative active objects. Its final problem is functional, not Boolean. With N=q^d vector atoms, |GL(d,q)|≤q^(d²)=exp(O((log N)²)), again precluding exp(Ω(N)) from an orbit lower bound on this family. No exact candidate implication was found.

## 6. Dawar–Richerby–Rossman 2008: rank dependence is essential

Primary author paper: [Choiceless Polynomial Time, Counting and the Cai–Fürer–Immerman Graphs](https://www.cl.cam.ac.uk/~ad260/papers/CPT-CFI.pdf), Annals of Pure and Applied Logic 152, pp. 31–50, DOI 10.1016/j.apal.2007.11.011.

Read Theorem 23 and proof, Theorem 33, and the proof of Theorem 40. For Abelian actions, the support estimate is σ_max(r,m)≤(log₂m)^r, explicitly dependent on HF rank r. Theorem 40 excludes low-rank CPT(Card) algorithms for preordered CFI; the same paper provides a positive unrestricted-rank CPT algorithm for that query (Theorem 17).

**Obstacle:** removing rank dependence is not an innocuous quantitative adjustment. This paper directly demonstrates why bounded-rank lower bounds cannot be promoted to all-HF-rank lower bounds. It does not imply the candidate's theorem.

## 7. GKPS15 does not explicitly prove the required history-independent simulation

Primary paper: [Characterising Choiceless Polynomial Time with First-Order Interpretations](https://www.logic.rwth-aachen.de/pub/schalthoefer/GKPS15.pdf), LICS 2015, DOI 10.1109/LICS.2015.68.

Read §IV, Definitions 9–10, Lemma 11, Proposition 12, and Theorem 16. Section IV builds an ordinal reserve up to an input-polynomial bound supplied with the CPT program. Definition 10 explicitly retains the previous represented domain S. The comprehension cleanup in Lemma 11 marks and retains that previous domain; it is not full native-step garbage collection. Proposition 12's final estimate is p_CPT·p_CPT+4. Theorem 16 only sketches successive two-dimensional simulations.

There is an apparent printed mismatch on p.685: the displayed per-step inequality uses |A| rather than old |A_i| despite the domain-preserving construction, then the prose uses the squared polynomial bound. I inspected the rendered PDF; this is not a text-extraction artefact. Do not cite that single display as an independently established history-free theorem.

**Conclusion:** the candidate's dynamic reserve, exact native-step GC, and all-intermediate-state compiler estimate are substantive extra arguments, even if they refine familiar constructions.

## 8. Grohe–Schweitzer–Wiebking: polynomial-time equivalence, not peak-space equivalence

Primary full paper: [Deep Weisfeiler Leman](https://arxiv.org/abs/2003.10935), published SODA 2021, DOI [10.1137/1.9781611976465.154](https://doi.org/10.1137/1.9781611976465.154).

Read §6, Lemmas 17/20 and Theorems 18/21. Its exact two-dimensional interpretation semantics use generated equivalence and existential representative relation semantics, agreeing with the candidate's source model. Polynomial time for IL is defined by m+Σ_i|V(A_i)| being polynomially bounded. Theorem 18 imports GKPS equivalence; Theorem 21 combines polynomial-time simulations to equate DeepWL and CPT. Lemma 17 invokes FPC simulation of polynomial-time controller computation, while Lemma 20 repeatedly adds pairs and contracts for IL instructions.

**Obstacle:** no theorem there states a uniform polynomial overhead in peak live HF space for arbitrarily long finite runs. The qualitative equivalence cannot be substituted for the candidate's new space-preserving bridge.

## General inference barriers

1. **Circuit size versus peak memory.** Unrolling a T-step, S-space computation typically gives size depending on T. An exponential circuit-size lower bound alone therefore does not force exponential S.
2. **Maximum circuit orbit versus live HF orbit.** A fixed circuit's gate orbit under all input relabellings and a constituent's orbit under Aut(A) of one particular input are different objects. Adaptive HF states depend on A. A resource-preserving, group-compatible translation needs proof; it is not supplied by ordinary unrolling.
3. **Counting, time, rank, and output type must all be stated.** The available precedents variously omit Card, bound HF rank, address functional construction, constrain the circuit basis, or bound total computation. None can be dropped silently.
4. **Source243 still matters.** This report does not re-audit that recent source. If its support/transfer proofs already yield a qualitative counting-space separation after the candidate's per-state argument, the exponential collective-cofilling strengthening is a quantitative advance beyond that source, rather than the first qualitative noncapture result.

## Source availability

The primary papers and their relevant proof passages are identified above. Downloaded papers and extracted copies are not bundled in this private scientific record.
