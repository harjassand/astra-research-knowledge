# Independent blind reconstruction: FS24 plus explicit Card

Audit phase: reconstructed from primary definitions before reading the proposed bridge proof. Date: 2026-10-08. This is a mathematical audit, not a claim of publication or formal verification.

## Verdict before comparison

The simulation claim is correct for the explicitly defined extension of FS24's deterministic ASM syntax by Card(x) = the von Neumann ordinal |x| for sets, and 0 for atoms, on legal finite halting runs. There is a fixed Rossman BGS term program and a polynomial depending only on the ASM that bound its peak hereditary state size, and even all hereditary intermediate objects within any one simulated transition, by a polynomial in the maximum FS24 per-state active-set size. No bound on the number of transitions is used. The union over the entire run need not be polynomial.

This is a simulation claim. The lower-bound consequence remains conditional on the separately supplied HF lower bound applying to these fixed BGS programs and the same hereditary/peak resource. FS24 does not itself define a counting extension.

## Sources read before proof comparison

- Ferrarotti and Schewe, *Choiceless Polynomial Space*, arXiv:2401.16366v1, 29 January 2024, Sections 2.1–2.3 and 5: https://arxiv.org/html/2401.16366v1 and https://arxiv.org/abs/2401.16366
- Rossman, *Choiceless Computation and Symmetry* (2010), Definitions 2.4–2.6, locally available primary PDF/text.
- Grädel, Grohe, Pago, Schalthöfer, *Characterising Choiceless Polynomial Time* (2015), Section II and Lemma 4, locally available primary PDF/text.

## Precise theorem

Fix a finite relational input vocabulary tau and a legal closed deterministic ASM M with precisely FS24's fixed-arity dynamic functions and rule constructors, extended only by the stated Card primitive. There is a fixed Rossman BGS program P_M, using the same input structure, such that each finite halting run S_0,...,S_T is simulated with one initialization stage and one step per ASM transition. The halt test is Halt=1, and the Boolean output test is Output=1. On inputs on which M halts with Output in {0,1}, acceptance and rejection agree.

Put s = max_i |active(S_i)|. There are constants C,d depending only on M such that every encoded state and every HF object evaluated by the simulator through halting has hereditary size at most C(s+1)^d. More strongly, the union of hereditary closures of all intermediate term values evaluated during any single simulator step has size at most C(s+1)^d. This does not assert the same bound for the union over all time.

The proof works for every fixed finite relational signature, including binary signatures. The restriction to a binary hard family is not needed for the compiler.

## 1. Canonical finite graph encoding of a state

Let f range over the finitely many dynamic symbols, with fixed arity r_f. Define

G_f(S) = { <a_1,...,a_{r_f},b> : f_S(a_1,...,a_{r_f})=b and b != 0 }.

Use a fixed injective HF tuple code, such as nested Kuratowski pairs with a fixed terminator, and a fixed tagged tuple for the finite list of G_f. Nullary symbols have a graph with at most one record. Pure finite tags distinguish the initialized state from the initial BGS value 0. Tuple tags/positions also avoid confusion between an atom or an arbitrary user HF value and an encoding wrapper.

Every argument and every nonzero value in a record belongs to active(S). If a=|active(S)|, there are at most a^{r_f} records for f because f is a function. Even the weaker bound a^{r_f+1} would suffice. A fixed tuple adds only O(r_f+1) wrapper objects per record, with all descendants of entries already in active(S). Consequently the complete state code has hereditary size O(a + sum_f a^{r_f} + 1), with constants depending only on M. Atoms has hereditary size at most a+1 even if the set Atoms itself is not counted active in FS24. Static input relations may be queried directly from the ambient input and do not need to be stored.

These codes are canonical and equivariant. Most importantly, the successor code contains its current graphs, not a nested copy of the preceding state or the update history.

## 2. Definable fixed-size coding operations

Singletons, ordered pairs, fixed-length tuples, and tuple projections have fixed BGS terms. For an ordered pair p={{a},{a,b}}, its first component is TheUnique({x in Union(p) : Pair(x,x) in p}). Having obtained a, its second component is TheUnique({x in Union(p) : x != a}) when this set is nonempty, and a otherwise. These expressions require only the allowed operations, comprehensions and equality. Iterate a constant number of times to decode any fixed tuple.

Conditional selection of arbitrary HF objects is expressible without unioning the selected object's contents: form the singleton {x} guarded by the condition and the singleton {y} guarded by its negation, take the union of these two guarded sets, then apply TheUnique. A guard-to-Boolean conversion similarly returns 0 or 1. Bounded existential/universal quantification is expressible by testing a comprehension for emptiness. No arbitrary selection occurs; TheUnique is only used on a singleton or deliberately allowed to return its defined default.

## 3. Compilation of terms, including zero defaults

Replace a dynamic application f(t_1,...,t_r) by a graph lookup. First compile the arguments, then form the set of final components of records in G_f whose argument components equal the compiled tuple. Apply TheUnique. On a legal state this set is either a singleton with the correct nonzero value or empty, yielding exactly 0. Thus missing graph records model the total function's zero default.

Copy the other background functions and input predicates directly, and translate comprehensions structurally. Treat FS24 Boolean operations by their finite truth tables when operands need not be Boolean: FS24 makes such operations return 0 on non-Boolean arguments. Do not substitute ordinary meta-level negation blindly for this totalized operation. Rule branching tests whether the compiled guard equals 1, matching FS24's else branch for every other value.

## 4. Compilation of the entire update set

For each rule r produce a fixed term U_r(state,parameters) whose values are update records, retaining zero-valued updates:

- skip produces the empty set;
- an assignment produces a singleton tagged by the dynamic symbol, with the compiled argument tuple and new value;
- branching selects the update set for the chosen branch;
- a bounded parallel rule takes Union({U_body(state,parameters,v) : v in compiled_bound}).

Every nested parallelism has fixed syntactic depth. All branches read the same old state. The construction never applies one update before evaluating another.

Consistency is a bounded test over U_r x U_r: there must not be two records with equal function tag and argument tuple but unequal assigned values. Identical duplicate updates collapse harmlessly because U_r is a set. If this test fails, return the unchanged state code. This models FS24's specified clash semantics, not an alternative halt/error convention.

If consistent, for each f let U_f be its updates and define the next nonzero graph as

{e in G_f : no u in U_f has the same argument tuple as e}
  union
{e(u) : u in U_f and value(u) != 0}.

Every update suppresses the preceding record at its location, including updates assigning 0. Only nonzero updates enter the new graph. Therefore deletion and overwriting are correct, unaffected locations persist, and no stale records accumulate. Bounded tests, filters, tuple reconstruction and finite unions are BGS terms. Function arities remain fixed; no dynamically growing tuples are introduced.

## 5. Initialization, halt and output

Use 0 only as the initial uninitialized BGS control state. On this value, construct a tagged vector of empty graphs, encoding S_0. On subsequent states apply the compiled update step. Make the halt predicate false on the initialization sentinel and otherwise test the decoded nullary Halt value for equality to 1. The output formula tests decoded Output=1. No elapsed-time ordinal, run log, or all-time active universe is stored.

GKPS's single-step-terminal-Boolean presentation can also be used by arranging that the step emits 0 or 1 on a halted encoded state and otherwise emits a non-Boolean tagged state. Rossman's explicit step/halt/output presentation gives the cleanest one-to-one simulation. This is an unbounded-time BGS program with a peak-space bound, not a CPT program merely by syntax.

## 6. Strong polynomial intermediate-evaluation lemma

For each fixed BGS term/formula t, let H include the hereditary closures of its supplied parameters, all input atoms, and fixed pure constants. There is a polynomial P_t such that the union of the hereditary closures of every term value encountered in the complete recursive evaluation of t is bounded by P_t(|H|+1). The statement remains true using Rossman's eager convention that evaluates the comprehension body even when the guard is false.

Proof: structural induction. Variables and constants are immediate. Input predicates, equality and logical connectives add at most fixed Boolean objects. Pair adds one set beyond the hereditary material of its operands. Union and TheUnique introduce at most one new root, because their descendants occur in the operand's closure. If z is a set, Card(z) has at most |z|+1 hereditary objects, and |z| is bounded by the existing closure of z; if z is an atom the result is 0. Fixedly many recursive calls add polynomials. For a comprehension, its bound has at most P_r(h) elements, and every bound element's closure is contained in the already bounded evaluation material. Each body/guard evaluation has parameter hereditary mass bounded polynomially in h. Multiply its polynomial bound by the polynomial number of bound elements and add the output set's root. Fixed syntax makes the result a fixed polynomial, regardless of ranks.

Apply this lemma to the fixed compiled step, halt and output terms. At simulated state S_i their parameter code has hereditary size at most a fixed polynomial in |active(S_i)|, and the input atom count is at most that active-set size. Hence one whole simulated transition has hereditary evaluation size polynomial in s. This estimate is reapplied to the exact canonical code of each current state; it is not a recurrence that repeatedly exponentiates a prior upper bound. Repeating it an arbitrarily large finite number of times changes neither the polynomial nor its exponent.

## Caveats that matter

1. FS24 bounds the active set separately in each stored state. It does not directly charge the discarded intermediate values of a large term. The structural lemma is needed to bridge that gap; declaring intermediates active by definition would change FS24's model.
2. Zero-valued updates must remain in the update collection until old records are removed. Dropping them earlier is wrong.
3. Conflicting updates must return the old state wholesale, not keep a consistent subset or halt.
4. Graph space is polynomial because arity is fixed and nonzero arguments are active. Omitting either assumption invalidates this argument.
5. A polynomial count of objects across the whole run is neither proved nor required. Rossman's CPT active-resource definition is cumulative and must not be silently conflated with this peak-space claim.
6. No powerset, choice, binary-succinct integer primitive, growing-arity relation, or arithmetic shortcut is used. Von Neumann Card cannot create exponentially large ordinals from a polynomial hereditary-size argument.
7. Legal relational dynamic locations have Boolean values. A syntactically ill-typed assignment outside legal state semantics is not a counterexample to simulation of legal runs.
8. No claim about PTIME versus PSPACE follows. A lower bound would separate a choiceless model from PTIME and therefore from capture of PSPACE, even if PTIME=PSPACE.

## Source-status check

The arXiv landing page checked on 2026-10-08 lists only v1 (29 January 2024) and supplies no journal reference. This supports citing it as the 2024 arXiv preprint; it does not establish that no publication exists elsewhere. No verified newer version or primary publication was located in the targeted search.

FS24 Section 5 explicitly says: “a natural research direction would be to explore whether CPS with counting can capture PSPACE.” The paper leaves the counting formalism unspecified. A conclusion should therefore name the extension above explicitly, e.g. FS24+Card, and describe the result as answering this natural instantiation. It should not claim every possible meaning of counting-space has been settled.
