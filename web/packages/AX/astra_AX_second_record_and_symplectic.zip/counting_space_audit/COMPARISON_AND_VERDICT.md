# Independent FS24+Card bridge audit: comparison and verdict

Date: 2026-10-08. Status: independent mathematical reconstruction and adversarial comparison; not formal certification or peer review.

## Verdict

**Pass for the precisely defined FS24+Card simulation claim.** The bridge in `../novelty_and_consequences/ASM_COUNTING_SPACE_BRIDGE.md` is valid as a fixed-program, arbitrary-finite-runtime, polynomial-peak-hereditary-space simulation of legal deterministic FS24 runs with the ordinary von Neumann Card operation added. I found no substantive gap requiring a change to the construction.

This verdict does not independently certify the supplied source243 lower bound, the history-independent interpretation compiler, the grid support argument, or the KOW/collective-cofilling exponential strengthening. Their consequences are conditional on those separately audited inputs.

## Independence record

Before reading the proposed bridge, I read the primary FS24, Rossman10 and GKPS15 definitions and wrote `BLIND_RECONSTRUCTION.md`. Its frozen pre-comparison SHA256 is:

`7d057c9734519079fd4db2c9904f6650105a50db1e27a50021412c35dc2bf5f2`

I then requested the originating author's full proof, read `ASM_COUNTING_SPACE_BRIDGE.md`, and compared each compilation and resource-accounting step. The proof author confirmed that file was unchanged since it was offered for comparison.

Bibliographic correction to the frozen blind note: I incorrectly expanded the initials GKPS there. The correct authors are Erich Grädel, Łukasz Kaiser, Wied Pakusa, and Svenja Schalthöfer. Full title: *Characterising Choiceless Polynomial Time with First-Order Interpretations*, LICS 2015, pp. 677–688. No mathematical part of the blind note depends on the mistaken author expansion.

## Items checked

1. **Exact source active resource.** The active set is per stored ASM state and contains the atoms, 0, 1, and hereditary data needed by each nonzero dynamic location. It need not contain all transient term results. The graph encoding only uses the former; the fixed-term evaluation lemma supplies the latter bound.
2. **Fixed arity and function graphs.** For arity r, at most s^r keys can occur when the active set has size s. Fixed tuple encodings add only a constant number of HF wrappers per entry. One current-state root has size O_M((s+1)^max(1,r_max)).
3. **Missing locations.** A lookup filters the current nonzero graph and applies TheUnique; an empty match set yields the source default 0.
4. **Atom and arbitrary-rank values.** Tuple encodings and projections work equally for atoms and sets. The bound counts distinct hereditary objects, not rank or unfolded tree size.
5. **Guards.** Branching checks equality with 1. Source Boolean operations need their specified 0 default when an argument is non-Boolean; ordinary truthiness or unrestricted Boolean negation would be incorrect.
6. **Parallel rules.** All compiled term evaluations read the frozen old graph. Nested parallelism has fixed syntactic depth and uses bounded comprehensions, followed by Union.
7. **Duplicate and conflicting updates.** Identical updates collapse harmlessly. Any unequal values at the same location cause the entire old state to persist, as FS24 prescribes.
8. **Zero updates, deletion and overwrite.** A zero-valued update remains in the update set until the old location has been suppressed, and is then excluded from the new nonzero graph. Filtering zero values earlier would be a genuine bug; the proof does not do that.
9. **Temporary zero-location keys.** These can be larger or more numerous than the stored active set, but the update term is fixed syntax. The stronger structural induction bounds all its intermediate hereditary values polynomially in the current encoded root and input atoms.
10. **Counting.** Card(z) returns an ordinal with at most |z|+1 hereditary objects. The cardinality |z| is at most the already bounded hereditary material of z. No succinct arithmetic or hidden powerset is used.
11. **History independence.** The new graph root contains current records, rather than its predecessor, a persistent update log, or a clock. The state bound is reapplied locally to the true current state; there is no repeated-exponentiation recurrence over runtime.
12. **Initialization and halt.** A distinguished startup value is followed by a non-Boolean tagged state. The source halt is tested before another source transition. Startup and final Boolean emission cost a constant number of checkpoints.
13. **Polynomial cutoff annotation.** The simulator does not have to implement the source's p(n)-active cutoff. On every input accepted or rejected by the bounded source machine, the underlying ordinary ASM reaches that same terminal state without crossing the cutoff. Those are the only runs needed for the decision/promise separation.
14. **No cumulative-resource substitution.** Rossman's all-time Active resource is different from per-state hereditary peak space. The bridge uses Rossman's syntax and the stronger one-step footprint induction, not an unjustified claim that the all-run union is polynomial.

## Minor presentation refinement

Under the eager subterm-footprint convention, a conditional macro may evaluate a discarded branch, including projection expressions at the startup sentinel. All BGS primitives are total, so this is harmless; the same polynomial footprint induction applies. It is more exact to say that the projection formulas satisfy their decoding equations on valid codes than to assert that only valid codes are ever passed to them. This is not a mathematical obstruction, and the proof author has been notified.

## Test review

I inspected the author's `check_asm_graph_updates.py` and `asm_graph_update_results.json` instead of duplicating an already completed external action. The tests implement genuine nested HF pair codes using frozensets; cover nullary, unary and binary dynamic functions; and compare graph updates to direct finite-map updates. The saved results report:

- 64 ordered-pair projection cases;
- 64 state round trips and 320 lookups;
- 13,504 state/update cases, including 1,920 clashes;
- 2,000 write/delete cycles, returning to the same empty-state code, with peak closure 20;
- all checks passed.

This supports the finite graph component and catches obvious deletion/clash mistakes. It is not an execution of a generated BGS syntax tree or a formal verification of the compiler, and I have not represented it as either. The mathematical proof is what covers arbitrary arity fixed in advance, arbitrary finite rank, and unbounded finite runtime.

## Consequence wording

A safe conditional statement is:

> For the extension of Ferrarotti–Schewe's deterministic ASM syntax by the ordinary BGS cardinality operation, a PTIME query on a fixed binary vocabulary is not decidable with polynomially many active objects per state, even with no time bound.

The qualitative version follows from the separately established time-independent polynomial-peak lower-bound transfer. If the separately established exponential HF peak lower bound on the same N-atom hard family is assumed, then the ASM peak active bound is exponential as well: C_M(s+1)^d_M >= exp(c_M N) implies s >= exp(c'_M N) for sufficiently large N. Compiler polynomial overhead changes only constants in the exponent.

The original-grid qualitative extension and the KOW/expander quantitative strengthening should be reported separately. This audit establishes the ASM-to-fixed-term bridge common to both, not their distinct combinatorial premises.

Do not state that FS24 already defined a counting logic, that all possible counting enrichments are ruled out, that this is a published resolution, or that PTIME differs from PSPACE. A PTIME query outside this particular choiceless model precludes its capturing PSPACE regardless of whether PTIME=PSPACE.

## Primary-source status and links

The FS24 arXiv page, checked on 2026-10-08, lists only v1 submitted 29 January 2024 and does not list a journal reference. No primary newer version or publication was verified in the targeted search. Cite the work as an arXiv preprint; this metadata check is not proof that no later publication exists elsewhere.

FS24's conclusion poses the counting question but does not define the enriched formalism. The exact short excerpt is in the frozen blind note. The conditional theorem should therefore explicitly say FS24 plus standard Card, or define CPS(Card) locally.

Verified primary links:

- FS24 landing page and history: https://arxiv.org/abs/2401.16366
- FS24 exact v1 text: https://arxiv.org/html/2401.16366v1
- Rossman10 author paper: https://www.math.utoronto.ca/rossman/yg70.pdf
- GKPS15 author paper: https://www.logic.rwth-aachen.de/pub/schalthoefer/GKPS15.pdf
- GKPS15 original conference record: https://lics.siglog.org/archive/2015/GrdelPakusaSchaltho-CharacterisingChoic.html

The FS24 main noncounting theorem was not needed or re-certified here. The bridge only uses its explicit machine definitions and the stated concluding research direction.
