# Blind reconstruction: algebraic logarithm interface

Recorded 2026-10-08 before reading the originating author's derivation. Sources read: the original family017 `sections/interpolation.tex`, `sections/determinant.tex`, and `sections/conclusion.tex`, identified by the immutable source pin in `../EVIDENCE_PINS.txt`; arXiv 2610.10192 abstract only (not its proof or appendices). The proposed interface was known. This is an audit of the proposed extension conditional on, and with a direct check of, the family017 interpolation mechanism; it does not constitute community certification of that extraordinary source claim.

## Setup and moving-center interpolation

Let alpha > 0 be algebraic, alpha != 1, F=Q(alpha), d=[F:Q], lambda=log alpha, and choose b>=1 with b alpha integral. Fix nu>2d and suppose there are unbounded denominators with |lambda-p/q|<=q^{-nu}. For sufficiently large such q, p/q is nonzero and bounded by |lambda|+1. Use m selected approximants r_i=p_i/q_i with w_i=ceil(log q_i), and nodes (alpha^j,jr_1,...,jr_m), 0<=j<K. Domain monomials Y^h X^a have w_0 h+w a<=H; row jets have v_0 s+w beta/theta<H.

The required generalization is substitution Y=alpha_j(1+t), X_i=c_ji+u_i+log(1+t), for alpha_j!=0. In the original proof replace the local coordinate Y-1 by Y/alpha_j-1 and log Y by log(Y/alpha_j). The same frame D_0=Y partial_Y+sum partial_X_i, D_i=partial_X_i still becomes (1+t)partial_t, partial_u_i and preserves polynomial weighted degree. The local multiplicity bound, separated normal-basis argument, residue contradiction dX_i=dY/Y, and weighted-degree pole count are unchanged. The persistent variety has Y constant. For alpha_j=alpha^j, distinctness of these first coordinates means that this fiber contains at most one node. If C meets a node and X_l is nonconstant on C, the divisor of X_l-c_jl gives deg_W C >= theta^{-1}sum h_P, contradicting the proposed violating curve. Thus the second derivative-ideal argument inside Y=1 can be replaced by this direct one-node argument. All preliminary coefficient-count constants and weight thresholds remain independent of alpha_j,c_ji. The final degree threshold can depend on the nodes, which is permitted because H is chosen last.

The curve-to-jets construction also survives: local t=Y/alpha_j-1 is a regular algebraic coordinate, and u'_i=X_i-c_ji-G_i(t). Algebraic coefficients lie in F. The blow-up argument is used over C; surjectivity implies that a maximal minor with entries in F is nonzero. No integral model or extension to the ring of integers is needed for rank. The truncation G_i uses T_i=ceil(F_0 w_i/v_0), F_0>2/theta, so omitted terms have v_0 T_i>w_i/theta and the coordinate change is filtered.

## Entrywise denominator clearing, including negative row powers

For a column Y^h X^a and row (j,s,beta), the raw entry vanishes unless a>=beta componentwise. Otherwise it is

alpha^{jh} binom(a,beta) [t^s](1+t)^h product_i (jr_i+G_i(t))^{a_i-beta_i}.

Scale the column by b^{(K-1)h} product_i q_i^{a_i} and the row by product_i q_i^{-beta_i}. The entry becomes

b^{(K-1-j)h}(b alpha)^{jh} binom(a,beta) [t^s](1+t)^h product_i (jp_i+q_i G_i(t))^{a_i-beta_i}.

The b-powers are nonnegative since 0<=j<K. Thus the algebraic factor is integral even when alpha is not an algebraic unit. Let L_i=lcm(1,...,T_i-1) and D_H=product_i L_i^{floor(H/w_i)}. The remaining rational denominator divides product_i L_i^{a_i-beta_i}, which divides D_H. Multiplying every row by D_H produces a matrix over O_F.

There is no need for the row factors separately to be integers. If desired, nonzero determinant forces the existence of a nonzero permutation term, and its entries imply sum_columns a_i>=sum_rows beta_i for every i; hence the total q_i exponent is itself nonnegative.

## Explicit arithmetic and norm bound

Write S_H=D_H^M b^{(K-1)sum_columns h} product_i q_i^{sum_columns a_i-sum_rows beta_i}; this is positive rational (indeed integral by the previous observation). Delta_H !=0 belongs to F, and delta_H=S_H Delta_H belongs to O_F\{0}. With bbar=(MH)^{-1}sum_rows w beta, 0<=bbar<=theta,

log S_H/(MH) <= 1-bbar + E_clear,

E_clear = Lambda F_0 m/v_0 + Lambda sum_i(1/w_i) + theta/w_* + (K-1)log b/w_0,

where Lambda=4log2. We used sum_columns w a<=MH, sum_columns h<=MH/w_0, and log q_i>=w_i-1. One could exploit the shared column budget to improve this, but it is unnecessary.

For each embedding sigma:F->C, coefficients r_i,G_i are rational and unchanged. On |t|=1/2, |G_i(t)|<=log2, |1+t|<=3/2, and |jr_i+G_i(t)|<=K(|lambda|+1)+log2. Put B_K=max(1,K(|lambda|+1)+log2). Every raw conjugate entry is bounded by exp(H E_sigma), with

E_sigma = ((K-1)log^+|sigma(alpha)|+log(3/2))/w_0 + (log2)/v_0 + log(2 B_K)/w_*.

This follows from binom(a,beta)<=2^{|a|}, |a|<=H/w_*, s<H/v_0, h<=H/w_0. The estimate is independent of T_i, selected approximants, rows and selected columns. Thus |sigma(Delta_H)|<=M! exp(MH E_sigma).

The nonzero integer norm yields

1<=|N(delta_H)|=S_H^d |Delta_H| product_{sigma != selected}|sigma(Delta_H)|,

and consequently

log|Delta_H|/(MH) >= -d(1-bbar)-E_ar,o,

where E_ar,o = d E_clear + sum_{sigma != selected} E_sigma + (d-1)log(M!)/(MH).

The last term tends to zero because M asymptotic to a fixed constant times H^{m+1}. The height constants log b and sum_sigma log^+|sigma(alpha)| are fully charged as constants multiplying K/w_0, and lambda affects only fixed constants in log B_K. There is no uniform assertion over varying alpha. The total field-degree multiplier is d, not 1; bounding only the selected embedding of the clearing scalar would be wrong.

## Analytic side

Use f_{a,P}(z)=[u^a]P(e^z,z+u_1,...,z+u_m). At z=j lambda+log(1+t), e^z=alpha^j(1+t), so the original exact row expansion holds with epsilon_i=j(r_i-lambda), tau_i=G_i-log(1+t). Here |epsilon_i|<=K e^nu exp(-nu w_i), and the tail budget sum_i d_i w_i<H/F_0 is unchanged. A valid translation error is

E_tr=nu/F_0+(log2)/v_0+(log4+log K+nu)/w_*.

Choose R=4K(|lambda|+1); then |j lambda+log(1+t)|<R/2 on |t|=1/2. The original Taylor-degree collision argument gives

log|det T| <= -c sum_a n_a^2 + MH(E_hol+o_H(1)),

c=(log2)/4, E_hol=R/w_0+(log2)/v_0+log(2R)/w_*.

The determinant expansion term count is polynomial in H with all parameters fixed. Therefore its logarithm divided by H vanishes uniformly over all choices.

## Full schedule and exponent 2d

The upper comparison is unchanged except the arithmetic baseline is d(1-bbar). Let

g_d=nu(A(1-eta)-theta)-d(1-theta),
L=eta^2 K theta^m/((m+1)v_0 A^m).

As nu>d, the second-branch gap nu(A(1-eta)-bbar)-d(1-bbar) is minimized at bbar=theta and is at least g_d. The collision branch contradicts the lower bound once cL>d+E_ar+E_an. Hence it suffices that g_d>0 and total fixed errors are <g_d.

For nu>2d choose rational beta_parameter in (1/2,1-d/nu), then theta=1-delta, A=1-beta_parameter delta for small rational delta>0. This gives nu(A-theta)>d(1-theta) and A^2<theta. Choose rational C in (A/theta,1/A), then A<B<min(1/C,C theta), and sufficiently small eta>0. These choices depend on nu,d, not on H or approximants.

First choose F_0 to control nu/F_0. Then choose m sufficiently large, K=floor(C^m), w_0=B^{-m}, v_0=2K theta^m w_0. Thus K/w_0->0, m/v_0->0, and L=eta^2(B/A)^m/[2(m+1)]->infinity. The fixed height constants and factors d are absorbed by choosing this finite m large enough; no logarithmic height grows with m except through the explicitly shown K/w_0 factor. Then choose m approximants successively far out in the unbounded set of good denominators to satisfy uniform interpolation separation and make all 1/w_*, sum_i 1/w_i and log K/w_* errors small. Finally take sufficiently divisible H->infinity. This permits all o_H terms to vanish while every center and approximation remains fixed.

## Blind interim verdict

No defect found in the proposed algebraic denominator/norm/conjugate/schedule interface. It gives a coherent conditional extension mu(log alpha)<=2d provided the original family017 moving-center interpolation mechanism is valid. The moving-center extension needed here is independently reconstructible from the supplied proof and is actually simpler after Y is shown constant, because alpha^j are distinct. The result remains conditional on the correctness of the full original interpolation proof; an extraordinary consequence does not become established merely because this interface audit found no new flaw.

Priority checks for comparison: origin must include the d multiplier on D_H and b denominators; prove entrywise integrality despite negative q row powers; bound raw rather than scaled conjugate determinants; include alpha-dependent height constants in the finite m choice; and retain H-last uniformity.
