# Adversarial comparison and verdict

2026-10-08. The independent reconstruction was saved before the originating candidate was read; its SHA256 is `264abc434bc41fef6bf84f55d78cda5b1fefadbd733148f19f5f5e812a425fa0`. The candidate compared is `../number_theory_bridges/ALGEBRAIC_LOGARITHM_CANDIDATE.md`.

## Bottom line

**The complete reconstructed proof of mu(log alpha)<=2[Q(alpha):Q], including its moving-center interpolation (MI) extension, survives this audit with no remaining gap identified.** MI was independently reconstructed from the supplied family017 argument and its established ingredients; it was not left as an additional unproved assumption. Separately isolating “MI implies the number-field bound” describes the new arithmetic interface, not an outstanding geometric proof obligation. I found no missing denominator, conjugate, height, asymptotic-quantifier, or field-base-change factor. The blind reconstruction and the origin's full proof agree on every load-bearing estimate and the closing parameter schedule.

This is a mathematical audit result, not formal verification, external specialist review, a claim of historical priority, or certification of the extraordinary family017/Oct7 research theorem. The geometric extension itself was reconstructed and checked below; its established algebraic-geometric inputs remain imported mathematics.

## Exact comparison

1. **Moving multiplicative centers are genuinely additional geometry.** The original family017 theorem only states Y=1. It cannot simply be invoked at Y=alpha^j. Both the independent reconstruction and the origin instead use t_j=Y/y_j-1 and retain the same global logarithmic frame. Its degree preservation, derivative costs and normal-basis estimates are independent of y_j. Once Y is constant on the persistent component, distinct y_j make the curve meet at most one center; the divisor of a nonconstant X_i-c_ji finishes the contradiction. No bound on distances between centers is needed. In this distinct-fiber setting the additional original condition K theta^m<1 is unnecessary, though the origin's schedule satisfies it anyway.

2. **The field rank step is sound.** After fixed truncation, every coefficient lies in F=Q(alpha). Surjectivity over C supplies a nonzero maximal minor of that same matrix, hence a nonzero element of F. Its conjugates cannot vanish. There is no claim of surjectivity over O_F, and no integral base-change theorem is needed.

3. **Negative q-row exponents cancel exactly.** Entries vanish unless gamma>=beta. For surviving entries the column/row scaling replaces (jr_i+G_i)^(gamma_i-beta_i) by (jp_i+q_iG_i)^(gamma_i-beta_i). This is entrywise cancellation, not an unjustified integer-row operation. A nonzero permutation term further shows the total q exponent in the determinant scalar is nonnegative, but that stronger fact is not needed.

4. **Nonunits and nonintegral alpha are handled.** For j<=K-1, b^((K-1)h)alpha^(jh)=b^((K-1-j)h)(b alpha)^(jh) is integral. The local inverse y_j^{-1} occurs only in the geometric coordinate definition; the actual evaluation matrix uses y_j(1+t) and introduces no unrecorded inverse alpha factors.

5. **Truncations stay fixed before H grows.** T_i=ceil(F_0 w_i/v_0) is independent of H. The denominator is D_H=product_i L_i^floor(H/w_i), and log D_H/H is bounded by Lambda F_0 m/v_0+Lambda sum_i 1/w_i. Replacing G_i by a full logarithm and clearing factorial-scale denominators would destroy this ledger; neither proof does so.

6. **The norm charges the clearing scalar d times.** With z_H=S_H Delta_H integral and nonzero,
   log|Delta_H| >= -d log S_H -sum_{sigma!=id} log|sigma Delta_H|.
   The origin includes d on both the main rational q cost and every clearing error. It never asserts that a nonzero algebraic integer is >=1 in the selected embedding.

7. **Conjugates are bounded before scaling.** The explicit E_sigma controls the unscaled entry using |G_i(t)|<=log2 on |t|=1/2, |r_i|<=|log alpha|+1, and |sigma alpha|^(jh). Therefore the other embeddings add only fixed-height multiples of K/w_0, 1/w_0, 1/v_0 and log K/w_min. No q_i logarithm is reintroduced through a scaled conjugate estimate. The determinant factor M! is present and contributes O(log H/H) after normalization.

8. **All degree/height dependencies are accounted for.** Alpha, d, b and its finitely many conjugate magnitudes are fixed before choosing m. The finite m may grow with those data. There is no height-uniform onset, effective onset, or constant lower bound at exponent 2d. The only uniform object asserted at fixed d is the limiting exponent.

9. **The analytic identity remains exact.** z=j log alpha+log(1+t) gives e^z=alpha^j(1+t). No branch of log(sigma alpha) is used or required. Fixed R=4K(|log alpha|+1) gives the same collision constant c=(log2)/4 and uniform O(log H/H) remainder. Powers of alpha in the selected embedding are already incorporated in e^{hz}.

10. **The two comparison branches close.** The high-transverse-index gap is nu(A(1-eta)-bbar)-d(1-bbar)>=g_d, since nu>d and bbar<=theta. The low-index branch uses cL>d+total_error. For nu>2d the rational gap constants can be chosen with A^2<theta, and K/w_0->0, m/v_0->0, L->infinity on the same m sequence. All q_i are chosen after m and before H, using location-independent MI thresholds. No limit exchange was found.

## Geometry dependency checks

The primary Oct7 moving-center theorem, Theorem 2 of https://arxiv.org/html/2610.10192v1, matches the reconstructed distinct-Y statement and explicitly separates location-independent weight thresholds from the center-dependent final degree threshold.

The following steps in the underlying proof were checked directly:
- The weighted transverse multiplicity lemma uses an affine coordinate slice transverse to the persistent component. Flow coordinates restrict to coordinates on this slice because their differential has kernel equal to the component's tangent space. Substitution in analytic coefficients does not decrease the already present transverse monomial weights.
- Weighted Bezout follows by unramified substitutions x_a=lambda_a+z_a^(M rho_a), allowing all preimages to be counted with equal local length. Other components away from the chosen point are irrelevant to the isolated-zero count.
- The derivative-ideal chain is selected backwards from a component containing the curve. Repetition of dimension in a nested chain of irreducible components gives an identical adjacent component, not merely equally sized unrelated components.
- Comparing every coordinate normal basis with every frame normal basis is justified on a common nonempty open set because there are finitely many index sets. The largest nontangent positive coordinate forces dX_i=dY/Y on the component; the residue contradiction is applied after restriction to an algebraic curve with nonconstant Y.
- Weighted monomial compactification recovers the exact pole degree by pure coordinate powers. Finite local ideals are algebraic after truncation. Their branch valuation is R h_P.
- On the ordinary blow-up, contracted curves have positive degree for -E; noncontracted curves receive the strict curve inequality. The explicit positive nef-plus-ample combination makes A-E ample, so mere strict nefness is not silently substituted for ampleness.
- The large-power pushdown is correctly about ordinary I^n. Stacks tags 0AG6 and 0AG7 were checked directly on the current primary site: they provide higher-cohomology vanishing and recovery of sufficiently high graded pieces of a finite graded module for a Noetherian degree-one-generated algebra. Applied to the Rees algebra, these give the displayed pushdown and relative vanishing. Tags 02OS and 02NS verify the Cartier exceptional divisor and relative ampleness. No normality assumption on the compactification or blow-up is inserted.
- The inclusion I^n subset {weight>=nR} has the correct direction for passing from surjectivity modulo I^n to the desired coefficient packet. Equality is neither true in general nor needed.

These checks found no local geometric interface defect. They do not replace a separate full algebraic-geometry specialist audit of the underlying research result.

## Reproducible scalar schedule stress checks

`check_parameter_schedule.py` uses exact rational choices of theta,A,B,C,eta and conservative logarithmic bounds for floor(C^m). It then checks that the fixed height/conjugate errors are small and the collision term large on the same m. Four cases were checked, including nu=2.01d and a conjugate-height allowance of 100 log10. Results are in `parameter_schedule_checks.json`.

For example, d=2, nu=4.2 has a valid explicit gap of approximately 0.0008518 under these deliberately loose choices, with m=524288. For d=2, nu=4.02 and very large fixed height allowance the chosen m is 67108864. These impractical sizes illustrate the qualitative nature of the proof and that enormous finite constants are not being treated as uniform. The script is a stress test, not a proof or an implementation of MI; it does not instantiate good approximants or geometric separation thresholds.

## Prior-art boundary checked

The current primary preprint https://arxiv.org/abs/2610.10192 (7 October 2026) already claims the rational-logarithm endpoint and supplies the moving-center input. Its Section 8 explicitly distinguishes the general algebraic case and says conjugate determinant bounds are not provided there. Its appendix on “final degree” concerns H, not the algebraic degree of alpha. Accordingly the d=1 endpoint is not novel here. A general degree-only 2d priority claim remains unverified; targeted searches are not exhaustive.

## Precise status to report

“The audit independently reconstructed both moving-center interpolation and the number-field determinant argument, and found no remaining gap in the candidate proof of mu(log alpha)<=2[Q(alpha):Q]. MI is proved within that reconstruction using the supplied family017 ingredients and established algebraic geometry; it is not an extra unproved assumption. This remains an audited research proof, without formal verification, outside specialist certification, or an established historical-priority claim.”


## Supplemental status clarification and scoped shared-embedding barrier

The blind file is intentionally preserved unchanged as the chronological independent-attempt record. Its initial conservative “conditional extension” wording should be read in light of the completed geometry checks and the exact-status clarification above. The audit did not locate a mathematical hole and then relabel it a condition. The boundary is ordinary fallibility of a manual audit of an extraordinary research proof and reliance on the stated standard theorems, rather than a remaining unproved MI assertion.

For the separate proposed shared-embedding refinement, let c!=0 and alpha!=0,1 be algebraic, let lambda be real with alpha=exp(c lambda), and put F=Q(alpha,c). An embedding sigma is called matching when sigma(alpha)=exp(sigma(c)lambda). The following barrier is correct:

1. rho=sigma(c)/c is algebraic, and exp(rho(c lambda))=sigma(alpha) is algebraic. Here c lambda is one particular logarithm of alpha. The all-values Gelfond--Schneider theorem therefore excludes rho being algebraic irrational, giving rho in Q. No assertion that c lambda is the principal logarithm is needed.
2. Extend sigma to an automorphism g of a finite normal closure of F. It has finite order n, fixes rational rho, and g(c)=rho c. Iterating gives c=g^n(c)=rho^n c. Since c!=0 and rho is rational, rho=+1 or -1. An arbitrary field embedding need not itself be an automorphism of F, so explicitly extending to the normal closure is essential.
3. The plus sign gives sigma(c)=c and sigma(alpha)=alpha, so sigma is the identity on F. The minus sign gives sigma(c)=-c and sigma(alpha)=alpha^{-1}. As alpha,c generate F, there can be at most one embedding of this second kind. Thus the number r of matching embeddings is at most 2. The second sign need not exist.

A primary current discussion of Gelfond--Schneider is Karatarakis--Wiedijk, https://arxiv.org/html/2603.24823v1 (the classic theorem is used here, not a claim that this audit ran or certified their Lean code).

The norm division by r in a shared-embedding determinant argument is structurally reasonable: sum the r analytic upper bounds, bound the other embeddings crudely, and divide the norm inequality by r, obtaining the leading cost ([F:Q]/r)(1-bbar). Fixed denominators and embedding sizes of c must also be charged. This short check does not replace a complete written proof of that supplementary corollary. If alpha is a root of unity other than 1, alpha^j repeats, so distinct-Y MI is not literally applicable; one must invoke the bounded-fiber/common-fiber variant with its extra fiber-volume hypotheses and additive separation. The main positive-real alpha!=1 theorem has no such issue.

The Gelfond--Schneider step above explicitly excludes alpha=1. No conclusion about that period case is asserted here without a separate proof, as requested.
