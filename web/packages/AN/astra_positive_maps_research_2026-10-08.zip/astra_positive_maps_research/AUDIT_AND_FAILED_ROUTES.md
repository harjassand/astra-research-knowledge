# Reassessment, route selection, and exact failed-transfer certificates

Research date: 8 October 2026. No parallel agents, external reviewers, proof assistants, or physical experiments were used. Prior files were read with the Files connector; repository state was read through GitHub at the immutable revisions below. This is an audit and new mathematical derivation, not a status upgrade by ingestion.

## 1. What survives from the old construction

The supplied candidate defines, for N=2n,

    R_N = Z_N^(-1) sum_(j=0)^n P_(N,j)/(2j+1)!!,

where the projectors contain all multiplicity spaces. The core algebra checks out in the reconstructed interfaces: common-rotation and permutation averaging gives singlet-pair/coherent-product decompositions; singleton partial transpose reduces to h_j <= (2j+3) h_(j+1); saturation gives the double-factorial coefficients. Twirling arbitrary singleton-PPT competitors preserves their total-spin law, so monotone reweighting gives the stated stochastic spin optimum. Dense states for N=2,4,6,8 and an independent symbolic N=4 reconstruction agree with these facts.

The arbitrary-identical-channel argument retains a specific external premise: quantum Sinkhorn normalization for a strictly positive qubit map by invertible input and output filters. The exact common-filter determinant identity on a singlet lets the input filter be replaced by a scalar inside each pair. The factorial sector weights control every fixed exponential reweighting of the unpaired spins. Boundary channels are handled by first adding a fixed sufficiently small amount of local depolarization, not by assuming invertible normalization there. The channel must be identical at all sites. Arbitrary site-dependent noise does not meet the determinant identity.

The imported normal-form statement and hypotheses were checked in Filippov 2021 Section II, which attributes the theorem to earlier operator-scaling work. It was not independently reproved. The separate unital two-qubit entanglement-annihilation criterion remains the published Filippov–Rybár–Ziman theorem, not a new result of the old construction.

These checks did not find a decisive error in the principal candidate theorem. They do not constitute a complete external validation of its entire old proof package, all prior claimed numerical runs, or historical novelty. In particular, the new work below is not conditional on that theorem.

## 2. A sharper obstruction: an explicitly distillable grouped cut

For every even N>=4, group two qubits into laboratory A and the other N-2 into B. Alice projects onto her spin-one subspace. Bob projects onto any one spin-one representation and a fixed multiplicity label in his even-sized collection. These projections are local to the **two grouped laboratories**, and the selected branch has positive probability because R_N is full rank.

The conditional 3-by-3 state is independent of N:

    B = (3/7) P_0 + (1/7) P_1 + (1/35) P_2,

where P_j projects onto total spin j in spin-one tensor spin-one. Indeed the unnormalized weights are 1,1/3,1/15 and their dimension-weighted sum is 7/3.

An exact symbolic calculation, also reconstructible from the spin-one matrices and Casimir interpolation, gives

    spectrum(B^Gamma) = { 1/21 (multiplicity 1),
                         -1/21 (multiplicity 3),
                         23/105 (multiplicity 5) }.

In the standard spin-one magnetic basis,

    v = ( |+1,0> + |0,-1> )/sqrt(2)

has Schmidt rank two and <v,B^Gamma v>=-1/21. Local projections onto the two Schmidt supports therefore yield an entangled two-qubit state. In the usual terminology this certifies one-copy distillability across that grouped cut: one copy can be filtered to an entangled qubit pair, not to a pure Bell pair without further distillation.

For N=4, the unreduced 2:2 partial transpose already has an exact negative eigenvalue -1/48 with Schmidt-rank-two eigenvectors. The fresh script records the full spectra and vectors. Thus the construction is not fully PPT, and this natural larger cut does not provide bipartite NPT undistillable entanglement. This does not contradict separability across every singleton cut. No assertion is made here about every other possible grouping.

## 3. Tensor positivity is not tested beyond the cluster size

For any map Q such that Q and Q tensor Q are positive, applying Q at every site to any two-producible state gives a positive operator. Proof: in every product-of-clusters summand, each cluster has one or two sites, so its image is positive; tensor and sum these images. This argument is independent of the special R_N coefficients.

Accordingly, tests on the R_N family cannot detect a failure of Q^(tensor n) on genuinely higher-cluster inputs once positivity on one and two factors is known. This is a structural limitation of the source family, not a numerical failure or an objection based on an open problem's age. Recasting its binary noise survival as tensor-stable positivity would change the universal input quantifier.

## 4. Exact obstruction to naive regularization

The prior Casimir proof correctly states an ordinary single-copy relative-entropy law and expressly does not assert the same regularized law. That caution is necessary.

Let P_0 be the N-qubit singlet projector. The exact single-copy fully separable maximum is 1/(n+1). For two copies, take the product across laboratories of local Bell states between each laboratory's two copy registers. This alternative is separable across the N laboratories, although each laboratory uses within-laboratory cross-copy entanglement. Because P_0 is real,

    expectation(P_0 tensor P_0) = Tr(P_0 P_0^T)/2^N
                                = rank(P_0)/2^N.

At N=4 this equals 1/8, strictly larger than (1/3)^2=1/9. The fresh script checks the same strict inequality exactly through N=24. Thus the single-copy product overlap bound does not multiply against the permitted regularized alternatives. This falsifies that particular proof transfer; it does not determine the actual regularized entanglement.

## 5. Why this ceased to be the main high-upside route

The old family proves a nontrivial contrast between singleton separability and channel-robust entanglement. But the above certificates leave no acquired bridge from that result to bipartite NPT bound entanglement, all-tensor positivity, quantum capacity, or a general secret-key theorem. General nonunital survival can still rely on exponentially small postselection. The previous restart already supplied a concrete channel for which leading Gaussian fluctuations have a separable realization.

The decision was therefore to stop extending that family as the main research route. This is a comparison of available mathematical mechanisms, not a claim that nobody could ever extract an important result from it.

## 6. Other routes investigated, and why they were not promoted

### A. Zero quantum key to classical bound information

OpenAI family 272 claims an entangled zero-distillable-key state and a counterexample to PPT-squared. Its introduction explicitly cites prior 2026 classical bound-information work. Moreover, replacing a purifying quantum adversary by a measured classical adversary is a change of resource model. The claimed quantum theorem cannot simply be relabeled as a new classical solution. This connection was discarded as a new-result claim.

### B. Eventual entanglement breaking of all PPT channels

Park's August 2026 manuscript states the general finite-index theorem. Its full-rank invariant-state and unital antecedents were distinguished from the new general statement. This was not treated as an open result to rediscover. No correctness premise from that theorem is used in the Gaussian work.

### C. Extending the released PPT-square counterexample to three factors

The dimension-ten construction uses a PPT map on M_4, a symmetric-square embedding, an exterior-square compression, and a Hodge-dual/transposition operation. Its kernel argument uses twenty projective directions in quadratic general position. The middle transposition cannot be inserted as an additional completely positive/PPT channel. A hypothetical additional PPT factor would need to preserve enough of the singular-output kernel structure; no such lemma was acquired.

The alternative projection-overlap construction derives entanglement of J(Psi* Psi) from exact zero entries and a conflict between Gram rank and compatible-support size. Additional compositions can fill those zeros. The two-factor proof does not survive arbitrarily many factors merely by repeating the notation. Both construction mechanisms were read as candidate source proofs, not certified by their release provenance.

### D. Low-Schmidt decompositions as a path to PPT-cubed

Park Question 5.11 asks which decomposable-Schmidt cone DSP_k contains the PPT cone. The sufficient inclusion PPT subset DSP_2 would imply PPT-cubed, but the converse is not asserted. High Schmidt number alone is not enough to refute this inclusion: the same paper supplies high-Schmidt PPT maps lying in DSP_2.

This last obstruction suggested the successful change of representation: construct one witness that is block-positive **both before and after partial transpose**. A projected Gaussian subspace provides that automatically. The uniform separable-compression argument then gives the stronger r-EB indecomposable maps, addressing the separate Devendra–Mallick–Sumesh open problem.

## 7. The redirect: what is actually proved

`proofs/GAUSSIAN_CONE_SEPARATION.md` contains the complete new derivation, with no unverified prior or release theorem as an input:

- indecomposable r-entanglement-breaking positive maps for every finite r, with d>=2^23 r^3; their adjoints share the property;
- a constant diamond-norm gap from decomposable maps;
- full-rank PPT states with maximally mixed marginals a constant trace distance from S_k+Gamma(S_k) at k proportional to d;
- K(d)=Theta(d) for Park's decomposition hierarchy, but not an exact finite-d formula.

`proofs/ITERATION_AND_LIMIT_BARRIERS.md` additionally proves that the physical channels in the construction can have entanglement-breaking index exactly two. It also shows that the positive maps converge to depolarization in the non-stabilized Hilbert–Schmidt operator norm along the growing-dimension ensemble, despite the stabilized norm separation. Neither a PPT-cubed counterexample nor a fixed all-tensor-positive nontrivial map was obtained.

The exact named open problem receives a negative answer in the supplied mathematical proof. Historical priority and external proof validation remain open. The argument's ancestry in the 2018 Gaussian high-Schmidt-number method is explicitly credited, and the existence statement could be recognized by specialists as an unstated consequence of that geometry. It is not labeled a historic-scale discovery.

## 8. Repository reconciliation

Astra snapshot: 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce, commit timestamp 2026-10-08T09:47:55Z. The current start guide, frontier priorities, selected card notices and relevant state routes were read. The complete corpus was not audited.

OpenAI snapshot for the family-272 mechanism: fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb. The source sections read are recorded in SOURCES.json. No release theorem or its formalization status is a proof premise of the new result.

No repository file, branch, issue, or pull request was changed. The new packet is a local reproducibility handoff.
