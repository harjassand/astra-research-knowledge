# Why the Gaussian theorem does not settle PPT-cubed or tensor-stable positivity

Date: 8 October 2026. Status: internally derived extension and transfer audit. This note uses the definitions and Gaussian construction in `GAUSSIAN_CONE_SEPARATION.md`. It adds one established external input, the bipartite Hilbert–Schmidt separable ball of Gurvits–Barnum (2002), Theorem 1, read in the original paper's HTML full text. The main theorem does not depend on that result.

## 1. Strong cone separation can coexist with entanglement-breaking index exactly two

The PPT channels in Theorem B can be chosen to satisfy **Lambda squared is entanglement breaking**, while Lambda itself lies outside DSP_k. Thus the cone counterexample is not merely insufficient to refute PPT-cubed: a simultaneous subclass explicitly has index exactly two.

Use the same h-by-h real Gaussian coefficient matrix g as in the main proof, and impose two additional good events:

    ||g||_op <= 8d,       ||g||_F <= d^2.

These are compatible with all main events. To see this directly, use quarter-nets of the two real unit spheres in dimension h. The bilinear net extension bounds ||g|| by twice the maximum sampled bilinear form; those forms are standard Gaussians. Since h<=d^2 and 2 log 9<5,

    Pr(||g||_op>8d) <= 2 exp(2h log9 - 8d^2) <= 2 exp(-3d^2).

Also h=d(d+1)/2-1 <= 3d^2/4 for d>=2. For Z=||g||_F^2 ~ chi-square_(h^2), exponential Markov with parameter 1/4 gives

    Pr(Z>d^4) <= exp[-d^4/4+(h^2/2)log2] <= exp(-d^4/20),

using log2<7/10 and h^2<=9d^4/16. Add these to the main failure bounds; their sum is still below one at every admitted dimension. All events can hold strictly.

With D(X)=Tr(X)I/d, write Lambda=D+R, where

    R(X)=(1/(6d^2)) sum_ab g_ab Tr(S_a X) S_b.

The traceless basis makes DR=RD=0 and D^2=D. Thus Lambda^2=D+R^2. In the same input-first Choi convention,

    d J(Lambda^2)= I + E,
    E=(1/(36d^3)) sum_ab (g^2)_ab S_a tensor S_b.

This is Hermitian, and orthonormality gives

    ||E||_F=||g^2||_F/(36d^3)
             <= ||g||_op ||g||_F/(36d^3) <= 2/9 < 1.

Gurvits–Barnum's exact bipartite theorem says I+E is separable for every Hermitian E with ||E||_F<=1. Therefore J(Lambda^2) is separable and Lambda^2 is entanglement breaking. Lambda is not entanglement breaking because its normalized Choi state is outside C_k, which contains the separable states. Its entanglement-breaking index is therefore exactly two.

This settles no case of the universal PPT-cubed question. Rather, it proves that the large decomposable-Schmidt level from Theorem B can occur even when two iterations erase all entanglement. A proof route requiring a bounded DSP level would discard these easy-to-iterate channels for the wrong reason.

## 2. No fixed-map limit has been acquired

For the positive, non-CP maps P in Theorem A,

    P-D=-(32/d^2) sum_ab g_ab Tr(S_a .) S_b.

Under the same extra event,

    ||P-D||_(2->2) <= 256/d -> 0,

while the main theorem has inf_DEC ||P-D' ||_diamond >= 6/55.

This is a separation between a non-stabilized Hilbert–Schmidt operator norm and the completely stabilized trace norm, not a contradiction. The algebras, maps, and reference dimensions vary with d. There is no embedding/limit theorem here producing a nontrivial fixed finite-dimensional map whose every tensor power is positive. The limiting Hilbert–Schmidt statement instead approaches the depolarizing map.

## 3. Exact distinction between the quantifiers

The proved statement is:

    for every finite r, there is d and an indecomposable P
    such that (id_r tensor P)(X) is separable for every X>=0.

The NPT-bound-entanglement/tensor-stability direction would require a fixed nontrivial P and

    P^(tensor n)(X)>=0 for every n and every positive X.

The former has one application of P with a bounded identity reference. The latter has arbitrarily many applications of P, no identity reference, and unrestricted joint inputs. Neither implication is supplied by this work. No compactness shortcut or same-map all-n claim is made.

## Imported source

Leonid Gurvits and Howard Barnum, *Largest separable balls around the maximally mixed bipartite quantum state*, Physical Review A 66, 062311 (2002), arXiv:quant-ph/0204159v2, Theorem 1. Full original statement and proof read at https://arxiv.org/html/quant-ph/0204159v2 . It concerns an unnormalized identity center and Hermitian perturbations in Frobenius norm; it is not a normalized-state operator-norm ball.
