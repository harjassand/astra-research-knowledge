# Indecomposable maps that break entanglement with every bounded reference

Research checkpoint: 8 October 2026.

**Status.** Complete, self-contained finite-dimensional probabilistic derivation, with internal numerical and exact-rational diagnostics. No external specialist, independent agent, or proof assistant has verified it. Priority is not established. The Gaussian geometry is closely related to Huber–Lami–Lancien–Müller-Hermes (2018); it is not a new invention of the Gaussian high-Schmidt-number mechanism. The proposed additional conclusions concern decomposability, simultaneous transpose constraints, and *separability of every small-reference output*. No unverified Astra theorem or OpenAI-release theorem is an input to the proof.

The maps denoted **P** below are positive linear maps, **not physical quantum channels**: indecomposability excludes complete positivity. The different maps denoted **Lambda** are actual completely positive, trace-preserving PPT channels.

## 1. Definitions and statements

All matrix algebras are over the complex numbers. Let Gamma=id tensor transpose on M_d tensor M_d. Write S_k for the cone of positive semidefinite matrices of Schmidt number at most k, and

\[
 \mathcal D_k=\mathcal S_k+\Gamma(\mathcal S_k),\qquad
 \mathcal C_k=\{A+B^\Gamma:A,B\in\mathcal S_k,\ \operatorname{Tr}A+\operatorname{Tr}B=1\}.
\]

The second set may contain nonpositive Hermitian matrices. It is the trace-one base of the first cone. It is compact: A and B lie in compact trace-bounded positive cones, and the image under the displayed continuous addition is compact. In particular, there is no hidden unbounded cancellation between the two summands.

A linear map P:M_d -> M_d is **r-entanglement breaking** (r-EB) if

\[
 (\operatorname{id}_r\otimes P)(X)\in\operatorname{SEP}(\mathbb C^r:\mathbb C^d)
 \quad\text{for every }X\succeq0.
\]

This entails r-positivity but does not require complete positivity. A map is **decomposable** if P=P_1+transpose o P_2 for completely positive P_1,P_2. Under the input-first Choi convention J(P)=sum_ij E_ij tensor P(E_ij), decomposability is equivalent to J(P)=A+B^Gamma with A,B positive semidefinite.

Set C=2^23=8,388,608.

### Theorem A: arbitrary finite-reference entanglement breaking does not imply decomposability

For every integer r>=1 and every d>=C r^3, there exists a complex-linear, real-coefficient map P:M_d -> M_d such that:

1. P is unital and trace preserving.
2. P o transpose=P=transpose o P.
3. Both P and its Hilbert–Schmidt adjoint P* are r-EB.
4. P is indecomposable. In fact,
   \[
    \inf_{D\text{ decomposable}}\|P-D\|_\diamond\ge6/55.
   \]

The diamond norm here is the completely stabilized trace norm of linear maps. Since P is not a physical channel, this last assertion must not be described as an experimentally implementable channel-discrimination protocol.

For r=2 the sufficient dimension in this conservative proof is d=2^26=67,108,864. No such giant matrix was materialized. The construction is a specified Gaussian ensemble with a proved positive probability of satisfying all of the required universal inequalities.

This gives a negative answer to Open Problem 1 of Devendra–Mallick–Sumesh, *Mapping cone of k-entanglement breaking maps*, 2021 preprint / Positivity 27,5 (2023), provided the derivation survives specialist audit. It is not a solution of PPT-cubed or NPT bound entanglement.

### Theorem B: linear decomposable-Schmidt complexity is necessary for PPT maps

For every k>=1 and d>=C k, there exists a real density matrix rho on C^d tensor C^d satisfying

\[
 \rho^\Gamma=\rho,\quad \rho_A=\rho_B=I_d/d,\quad
 \frac{I}{6d^2}\preceq\rho\preceq\frac{11I}{6d^2},
\]

and

\[
 \inf_{\tau\in\mathcal C_k}\frac12\|\rho-\tau\|_1\ge\frac7{3200}.
\]

The channel Lambda with J(Lambda)=d rho is unital, trace preserving, and PPT, but is not in SP_k+transpose o SP_k. Here SP_k consists of CP maps admitting a Kraus decomposition whose operators all have rank at most k.

If

\[
 K(d)=\min\{k:\operatorname{PPT}(d,d)\subseteq\operatorname{DSP}_k(d,d)\},
\]

then for d>=C,

\[
 \lfloor d/C\rfloor+1\le K(d)\le d.
\]

Thus K(d)=Theta(d). This establishes the asymptotic order, **not** the exact minimum for each d. In particular it does not decide the separate d=4,k=2 case. It rules out dimension-independent bounded-Schmidt decompositions of all PPT maps and the proposed universal inclusion in DSP_2, not the conclusion of the PPT-cubed conjecture itself.

## 2. The exact random subspace and its covariance

Let V_d be the real Hilbert space of traceless real symmetric d-by-d matrices with the Hilbert–Schmidt inner product. Its dimension is

\[
 h=\frac{d(d+1)}2-1.
\]

Choose an orthonormal basis S_1,...,S_h. Take independent real standard normal coefficients g_ab and put

\[
 G=\frac1d\sum_{a,b=1}^h g_{ab} S_a\otimes S_b. \tag{1}
\]

Exactly, G is real symmetric and

\[
 G^\Gamma=G=G^{\Gamma_A},\quad
 \operatorname{Tr}_A G=\operatorname{Tr}_B G=0.
\]

For every Hermitian matrix H,

\[
 \operatorname{Var}[\operatorname{Tr}(GH)]
 =d^{-2}\sum_{a,b}|\operatorname{Tr}[(S_a\otimes S_b)H]|^2
 \le d^{-2}\|H\|_2^2. \tag{2}
\]

This is just orthogonal projection onto a real Hilbert subspace. It applies to complex Hermitian H; no restriction of the later Schmidt vectors to real coordinates is made. Also,

\[
 d^2\operatorname{Tr}(G^2)=\sum_{a,b}g_{ab}^2\sim\chi^2_{h^2}. \tag{3}
\]

An equivalent numerical generation is to draw an isotropic real symmetric Gaussian matrix A on dimension d^2, orthogonally project it onto V_d tensor V_d, and divide by d. The projector first takes (A+A^Gamma)/2 and then removes the two local identity sectors. Both implementations were checked against each other on small dimensions.

## 3. Uniform Gaussian estimates, with explicit constants

Write m=d^2. Three kinds of events are used.

### 3.1 Global operator norm

A 1/4-net of the real unit sphere in R^m has at most 9^m elements. For a real symmetric matrix, its norm is at most twice the largest absolute quadratic form on that net. By (2), each quadratic form is a centered Gaussian of variance at most 1/m. Therefore

\[
 \Pr\{\|G\|_\infty>5\}
 \le2\exp[-(25/8-\log9)m]\le2e^{-m/2}. \tag{4}
\]

Real vectors suffice **only** for this global norm because G is real symmetric. The restricted estimate below uses complex vectors.

### 3.2 Hilbert–Schmidt mass

For a chi-square variable with L degrees of freedom, the elementary moment-generating-function Chernoff bound gives

\[
 \Pr\{\chi^2_L<0.9L\}\le e^{-L/400}.
\]

Indeed, optimizing E exp(-t chi-square) and using -log(1-u)-u>=u^2/2 gives this inequality. Since h>=d^2/2 for d>=2, (3) implies

\[
 \Pr\{\operatorname{Tr}G^2<9d^2/40\}\le e^{-d^4/1600}. \tag{5}
\]

### 3.3 Restricted bilinear norm

Define

\[
 q_k(G)=\sup_{\substack{\|x\|=\|y\|=1\\\operatorname{SR}(x),\operatorname{SR}(y)\le k}}
                  |\langle x,Gy\rangle|. \tag{6}
\]

For any eta>0,

\[
 \Pr\{q_k(G)>\eta\}
 \le4\exp\left[36dk-\frac{d^2\eta^2}{16}\right]. \tag{7}
\]

Here is a full net proof, including the often problematic uniform extension step.

**Rank-net size.** Identify vectors with d-by-d matrices by vectorization. A rank-at-most-k unit Frobenius matrix has SVD U diag(s) V*, where U,V are complex d-by-k isometries and s is a nonnegative unit vector in R^k. The set of isometries has an eta_0-net in the operator norm of size at most (1+2/eta_0)^(2dk): use disjoint eta_0/2 balls in the ambient real 2dk-dimensional normed space, all contained in the ball of radius 1+eta_0/2. Choose the net centers within the isometries. The s set has a Euclidean eta_0-net of size at most (1+2/eta_0)^k, again with unit centers.

The three factor approximations give Frobenius error at most 3 eta_0. Thus the rank set has an epsilon-net, with centers still of rank at most k and norm one, of cardinality

\[
 (1+6/\epsilon)^{(4d+1)k}.
\]

Set epsilon=1/8, giving 49^((4d+1)k).

**Extension without a dimension logarithm.** Split the singular values of a rank-at-most-2k vector into two groups of at most k. The sum of the norms of the two pieces is at most sqrt(2). Applying this separately to x and y proves

\[
 q_{\min(2k,d)}(G)\le2q_k(G).
\]

Approximating each of x,y by its rank-k net center gives

\[
 q_k(G)\le Q_{\rm net}+2\epsilon q_{\min(2k,d)}(G)
 \le Q_{\rm net}+4\epsilon q_k(G).
\]

Therefore q_k<=2 Q_net. No sampled low-rank optimization is substituted for this universal bound.

**Gaussian tail.** For fixed complex x,y, the real and imaginary parts of <x,Gy> are Gaussian quadratic pairings with Hermitian test matrices (yx*+xy*)/2 and (yx*-xy*)/(2i), respectively. Each test has HS norm at most one. Hence

\[
 \Pr\{|\langle x,Gy\rangle|>u\}\le4e^{-d^2u^2/4}.
\]

Union over two nets, with u=eta/2, gives

\[
 4\exp\left[2(4d+1)k\log49-d^2\eta^2/16\right].
\]

For d>=2 the entropy is at most 36dk, since 2(4d+1)<=9d and log49<4. This proves (7).

### 3.4 The two regimes

For d>=C k, using eta=1/64 in (7) yields

\[
 \Pr\{q_k>1/64\}\le4e^{-d^2/131072}. \tag{8}
\]

For d>=C r^3, using eta=1/(64r) and k=r yields

\[
 \Pr\{q_r>1/(64r)\}\le4e^{-d^2/(131072r^2)}. \tag{9}
\]

For example, the exponent comparison in (9) is

\[
 \frac{d^2}{65536r^2}-36dr
 \ge\frac{d^2}{131072r^2},
\]

using d>=2^23 r^3. In either regime, the sum of the relevant failure probability and (4),(5) is less than one. Indeed at the smallest allowed d each exponent already exceeds 100. Thus the intersection of all required good events has positive probability. Boundaries can be avoided; one can take all useful inequalities strict.

## 4. Witness/state pair and the linear cone obstruction

Take a realization with ||G||<5, Tr G^2>9d^2/40 and q_k<1/64, and put

\[
 \rho=\frac{I+G/6}{d^2},\qquad W=I-32G. \tag{10}
\]

The exact symmetries and partial traces in Section 2 give rho^Gamma=rho, trace one, and both marginals I/d. Its spectrum is in [1/(6d^2),11/(6d^2)]. For a normalized vector of Schmidt rank at most k,

\[
 \langle x,Wx\rangle\ge1-32q_k>1/2. \tag{11}
\]

Since W^Gamma=W, both W and W^Gamma are k-block positive. Every tau=A+B^Gamma in C_k consequently satisfies

\[
 \operatorname{Tr}(W\tau)\ge1/2,\qquad
 \operatorname{Tr}(G\tau)\le1/64.
\]

On the other hand,

\[
 \operatorname{Tr}(W\rho)
 =1-\frac{32}{6d^2}\operatorname{Tr}G^2
 <-1/5,
\qquad \operatorname{Tr}(G\rho)>3/80.
\]

Since ||G||<=5, duality of operator and trace norm gives

\[
 \frac12\|\rho-\tau\|_1
 \ge\frac{(3/80)-(1/64)}{10}=7/3200.
\]

This proves Theorem B's state claim. Under the Choi convention, S_k corresponds exactly to SP_k: a pure Choi vector corresponds to a Kraus operator with rank equal to that vector's Schmidt rank; sum the rank-one Choi decompositions. The channel statement follows with J(Lambda)=d rho, without importing a conjectural channel theorem.

The witness W itself defines the map P with J(P)=W/d. It is k-positive and k-copositive by (11). This equivalence can also be seen directly by compressing the first Choi factor to k-dimensional subspaces: those compressions are positive iff all Schmidt-rank-at-most-k quadratic forms are nonnegative.

A decomposable Choi matrix A+B^Gamma has nonnegative pairing with every PPT state. The negative pairing with rho therefore proves that P is indecomposable. Its partial traces are I, making P unital and trace preserving. Its input and output transpose invariances follow term by term from (1).

Explicitly,

\[
 P(X)=\operatorname{Tr}(X)\frac{I}{d}
       -\frac{32}{d^2}\sum_{a,b}g_{ab}\operatorname{Tr}(S_aX)S_b. \tag{12}
\]

For any decomposable map D,

\[
 \operatorname{Tr}[\rho J(D)]\ge0,\quad
 \operatorname{Tr}[\rho J(P)]\le-1/(5d),\quad
 \|\rho\|_\infty\le11/(6d^2).
\]

It follows that ||J(P)-J(D)||_1>=6d/55. Evaluate P-D on one half of a normalized maximally entangled state to conclude

\[
 \|P-D\|_\diamond\ge\frac1d\|J(P)-J(D)\|_1\ge6/55. \tag{13}
\]

Finally K(d)>=floor(d/C)+1 follows from the counterexample for that k. K(d)<=d follows because every positive Choi matrix has Schmidt number at most d and every PPT map is CP. This is an asymptotic-order answer, not an exact finite-dimensional classification.

## 5. An elementary dimension-asymmetric separable ball

**Lemma.** If E=E* acts on C^r tensor C^b and

\[
 \|E\|_\infty\le\epsilon\le\frac1{2r-1},
\]

then I+E is separable. The dimension b does not enter the bound.

**Proof.** Write E as r-by-r blocks E_ij. Each block has operator norm at most epsilon. For i<j define

\[
 H_{ij}=(E_{ij}+E_{ij}^*)/2,\quad
 K_{ij}=(E_{ij}-E_{ij}^*)/(2i),
\]

both Hermitian contractions of norm at most epsilon. Let P_ij=|i><i|+|j><j|, X_ij=|i><j|+|j><i|, and Y_ij=i(|i><j|-|j><i|). The two matrices

\[
 \epsilon P_{ij}\otimes I+X_{ij}\otimes H_{ij},\quad
 \epsilon P_{ij}\otimes I+Y_{ij}\otimes K_{ij}
\]

are separable. For example the first equals

\[
 \frac{P_{ij}+X_{ij}}2\otimes(\epsilon I+H_{ij})
 +\frac{P_{ij}-X_{ij}}2\otimes(\epsilon I-H_{ij}),
\]

a sum of positive tensors. The analogous identity holds for Y and K. Sum these over i<j. Their off-diagonal blocks reproduce all of E's off-diagonal blocks. The remaining diagonal block i is

\[
 I+E_{ii}-2\epsilon(r-1)I\succeq[1-(2r-1)\epsilon]I\succeq0.
\]

Those diagonal blocks are themselves separable tensors. This proves the lemma. No commutativity of the blocks is assumed. The result is not claimed to be an optimal or historically new separable-ball radius.

## 6. From small Schmidt norm to genuine r-EB maps

Now choose the good realization under d>=C r^3 and q_r(G)<=1/(64r). Keep W, rho, P from (10),(12).

For every complex isometry U:C^s -> C^d with s<=r, any vector in the range of U tensor I has Schmidt rank at most s. Therefore

\[
 \|(U^*\otimes I)G(U\otimes I)\|_\infty\le q_s(G)\le q_r(G).
\]

Consequently the first-factor compression of W is

\[
 (U^*\otimes I)W(U\otimes I)=I_s\otimes I_d+E_U,
\qquad \|E_U\|_\infty\le1/(2r)\le1/(2s-1).
\]

By Section 5 **every such compression is separable**, not merely positive or PPT.

To see that this is precisely enough for r-EB, take any pure input vector psi in C^r tensor C^d, of Schmidt rank s<=r. It can be written as

\[
 \psi=(A\otimes V)\Omega_s,
\]

where V:C^s -> C^d is an isometry, A:C^s -> C^r is arbitrary, and Omega_s=sum_i e_i tensor e_i is unnormalized. Direct expansion of the matrix units gives

\[
 (\operatorname{id}_r\otimes P)(|\psi\rangle\langle\psi|)
 =(A\otimes I)(V^T\otimes I)J(P)(\overline V\otimes I)(A^*\otimes I). \tag{14}
\]

The middle factor is the compression with U=overline V, divided by d. It is separable; the outer local filter preserves separability. Every positive input is a finite sum of such pure projectors, proving r-EB.

The adjoint map has coefficient matrix g^T. Its Choi perturbation is obtained by swapping the two tensor factors of G (because G is real). Swap preserves the Schmidt ranks in (6), the operator norm, and the exact transpose symmetries. The same argument proves r-EB for P*.

Indecomposability and the diamond-norm gap follow from Section 4, since q_r<=1/(64r)<=1/64. This proves Theorem A.

## 7. Why this is stronger than high Schmidt number alone

A PPT state can have a large Schmidt number and still be expressible as A+B^Gamma with low-Schmidt A,B. It is not enough to exhibit high Schmidt number for rho, or even separately for rho and rho^Gamma. The critical property here is **one separating witness valid on both low-Schmidt cones at once**, followed by the stronger separable-compression property in Theorem A.

The fixed-reference conclusion is about all inputs with a reference of that size, including complex Schmidt bases and arbitrarily singular local filters. It is not a collection of sampled input tests. Conversely, letting r tend to infinity while also changing d and P does not construct a fixed finite-dimensional tensor-stable map.

The theorem makes no claim that P tensor P, let alone every tensor power of P, is positive. Neither k-positivity nor r-EB at finite r licenses that inference. It also does not prove that the physical PPT channel Lambda has a non-entanglement-breaking cube. Failure of a sufficient low-Schmidt decomposition is not failure of that cube conclusion.

## 8. Existence, exact coefficients, and computational costs

The proof specifies an ordinary finite-dimensional Gaussian distribution and proves a positive-probability open set of successful coefficients. It is an existence construction, not a stored example at d=67,108,864.

Rational realizations also exist. The space V_d tensor V_d has a basis of rational matrices; rational coordinates are dense. Strict positivity, the negative witness pairing, and the strict uniform low-rank bound are open conditions in this finite-dimensional space. A sufficiently close rational perturbation therefore retains every conclusion. The orthonormal basis is used only to prove Gaussian estimates, not to assert irrational coefficients are necessary.

In principle one can enumerate rational matrices in that subspace and test the strict uniform low-rank bound using real quantifier elimination: real and imaginary coordinates, unit norms, rank minors and the squared bilinear inequality form polynomial constraints. Positivity and the moment conditions are also finite algebraic tests. Such an enumeration eventually terminates. It has not been executed; no useful time, memory, bit-complexity, or laboratory preparation bound is asserted. A practical high-probability random draw still requires O(d^4) real coefficients to store densely.

The theorem's universal inequalities are justified analytically by the net proof. Small-dimensional numerical low-rank searches cannot certify them, and the supplied software expressly does not treat those searches as certificates.

## 9. Primary literature and priority boundary

- Devendra, Mallick and Sumesh, *Mapping cone of k-entanglement breaking maps*, arXiv:2105.14991v2, Definition 3.1 and Open Problem 1 in Section 7; published Positivity 27,5 (2023). The question asks whether every 2-EB map is decomposable. Theorem A gives a negative answer under precisely that definition. The paper distinguishes this cone from completely positive k-EB maps, which are automatically decomposable.
- Park, *Every PPT channel has finite entanglement breaking index*, arXiv:2608.13551v2, Question 5.11 and Proposition 5.12, asks for the minimal decomposable-Schmidt level covering the PPT cone and gives the dual simultaneous-positivity formulation. Theorem B rules out fixed levels and determines the order in d. The paper's PPT-cubed sufficient condition remains a logically different assertion.
- Huber, Lami, Lancien and Müller-Hermes, *High-Dimensional Entanglement in States with Positive Partial Transposition*, arXiv:1802.04975, Section IV, already uses identity-plus-Gaussian states and restricted Schmidt witnesses to obtain linear Schmidt number. Section III.C also constructs PT-invariant high-Schmidt states. Those achievements and the Gaussian method are prior art. The present proof adapts that geometry to a zero-marginal, separately transpose-invariant subspace, and adds the uniform separable-compression lemma to reach r-EB indecomposability.
- The 2018 paper itself builds on earlier convex-geometric estimates for bounded Schmidt-number sets. The short net proof here avoids importing those estimates but does not confer historical novelty on them.

The exact full package above was not located in the targeted primary-literature review. This is not an exhaustive search or priority certificate. Several search queries returned irrelevant results; these are explicitly not evidence of novelty. A specialist may recognize the main existence statement as an unstated corollary of existing Gaussian geometry. No historic-scale significance is claimed on the basis of a new combination alone.
