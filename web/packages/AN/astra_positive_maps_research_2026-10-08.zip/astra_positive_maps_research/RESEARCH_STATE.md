# Restart state: Gaussian cone separation after auditing the bound-entangled family

Date: 2026-10-08. Status: **internal proof package, not external validation or priority clearance**. No parallel subagents. No proof assistant. No claim of a historic-scale breakthrough.

## Strongest exact conclusions

1. For every integer r>=1 and d>=2^23 r^3, there exists a unital trace-preserving positive map P:M_d(C)->M_d(C), invariant under input and output transpose, such that P and P* are r-entanglement breaking but P is indecomposable. In fact its diamond distance from the decomposable cone is at least 6/55. P is not CP and is not a physical channel.
2. For every d>=2^23 k, there is a real full-rank PPT state rho, invariant under partial transpose with marginals I/d, at half-trace distance at least 7/3200 from the trace-one base of S_k+Gamma(S_k). The necessary decomposable-Schmidt level for all d-dimensional PPT maps therefore has order Theta(d). The exact level at each finite d, including d=4, remains unresolved here.
3. The physical unital TP PPT channels with Choi d*rho can be chosen to have entanglement-breaking index exactly two. This separates high decomposable-Schmidt complexity from iteration length; it does not refute PPT-cubed.

The first result negatively answers Devendra–Mallick–Sumesh Open Problem 1 under Definition 3.1 in arXiv:2105.14991v2. The second gives the asymptotic order in Park Question 5.11, arXiv:2608.13551v2. Both are mathematical conclusions of the written derivation; independent specialist checking is still required. A targeted search did not locate the statements but did locate closely related Gaussian and PT-invariant high-Schmidt methods, so priority is not established.

## Exact construction

Take V_d=traceless real symmetric matrices, HS-orthonormal basis S_a, h=d(d+1)/2-1, and iid real standard Gaussian g_ab. Set

    G=(1/d) sum_ab g_ab S_a tensor S_b,
    rho=(I+G/6)/d^2,
    W=I-32G,
    J(P)=W/d,
    J(Lambda)=d*rho.

G is invariant under both local partial transposes and has zero partial traces. The main finite-dimensional events are

    ||G||_op<5,
    Tr G^2>9d^2/40,
    q_k(G)<1/64                       [linear hierarchy]
    q_r(G)<1/(64r)                    [genuine r-EB],

where q_k is the supremum of the complex bilinear form over unit vectors of Schmidt rank <=k. An explicit rank-net argument gives

    Pr(q_k>eta)<=4 exp(36dk-d^2 eta^2/16).

A real sphere net and a chi-square bound give the other events. Their intersection has positive probability at the stated dimensions. Rational realizations follow from strictness and density in a rational linear subspace. No enormous example or exhaustive rank net was materialized.

## Proof dependencies

MAIN THEOREMS A/B — self-contained finite-dimensional argument:

    exact tensor-transpose subspace
      -> Gaussian covariance and HS mass
      -> uniform complex low-rank net estimate
      -> simultaneous witness positivity before/after PT
      -> PPT state separation and indecomposability

    low-rank BILINEAR bound
      -> operator norm bound on every small-reference Choi compression
      -> explicit dimension-asymmetric separable-ball decomposition
      -> every positive input with that reference is mapped to SEP
      -> P and P* are r-EB

    zero partial traces -> exact TP/unital normalization
    negative PPT pairing + spectral bound -> diamond gap 6/55.

Known background reconstructed rather than treated as a frontier premise: Choi matrix-unit identity, Schmidt rank/Kraus-rank correspondence, duality of operator and trace norms. The proof imports no unverified Astra claim, release theorem, Park theorem, or Gaussian high-Schmidt theorem. Earlier Gaussian geometry is credited as methodological prior art.

ITERATION BARRIER — separate corollary:

    additional ||g||_op<=8d, ||g||_F<=d^2 events
      -> ||dJ(Lambda^2)-I||_F<=2/9
      -> Gurvits–Barnum 2002 Theorem 1
      -> Lambda^2 EB, with Lambda itself non-EB.

This last corollary explicitly imports the established bipartite unnormalized-identity Frobenius ball; see SOURCES.json.

## Old-family audit results

No decisive error was found in the principal old candidate's audited algebraic interfaces. It remains a candidate, not externally established. Three exact limitations were obtained:

- For every even N>=4, projection at the 2:(N-2) grouped cut produces B=(3/7)P_0+(1/7)P_1+(1/35)P_2 on spin-one tensor spin-one. B^Gamma has a Schmidt-rank-two vector with expectation -1/21. Thus that cut is one-copy distillable, not a bipartite NPT bound-entanglement example.
- Two-producibility makes the family incapable of testing tensor positivity beyond two factors once positivity on one and two factors is known.
- A product of local inter-copy Bell states gives <P_0 tensor P_0>=1/8 at N=4, exceeding the squared one-copy separable maximum 1/9. Thus the naive multiplicativity/regularization argument fails.

These are scoped obstructions. They do not refute the original singleton-bound-entanglement theorem or determine its true regularized relative entropy.

## Current decision

The old state family was abandoned as the main path to a much larger theorem because no verified bridge to the relevant universal input/tensor-power statements was obtained. The successful redirect addresses exact open questions in mapping-cone theory with a new separable-compression consequence of old Gaussian geometry. Its importance should be judged separately from the historic-scale target.

Do not spend another run merely increasing r or improving the enormous constants and present that as a historic advance. The highest-value mathematical question is whether a genuinely different mechanism can retain a nontrivial **fixed** finite-dimensional map while controlling all tensor powers, or can produce an actual non-EB composition of three physical PPT maps. The current results supply neither. The index-two corollary is an explicit warning against treating the Gaussian channels as ready-made PPT-cubed counterexamples.

## Verification executed

- Main Gaussian script: 8 bases, 32 independently formulated projection identities, 24 small Gaussian fixtures, 2760 sampled complex rank-constrained pairs, 100 explicit separable-ball decompositions, 20 Choi/filter identities, 120 SVD rank-splitting identities, exact rational constants for r=1..64. The rank samples are LOWER bounds only, not certificates.
- Old-family audit: dense N=2,4,6,8; exact four-qubit spectra and SR-two negative vectors; exact spin-one conditional block; exact cross-copy inequalities through N=24.
- Iteration script: 24 direct matrix-unit composition/Choi identities and HS coefficient checks.

All scripts passed. Residuals and actual outputs are in results/. Numerical tests do not establish continuum inequalities, theorem-sized existence, or novelty. No test is an independent researcher.

## Outstanding obligations

A. Specialist reconstruction of the complex rank-net extension, separable-compression equivalence, normalization and stabilized-norm separation. These have full written proofs, not asserted missing lemmas.
B. Historical-priority review: the named open question may have an unlocated subsequent solution or the result may be an unstated corollary of Huber–Lami–Lancien–Müller-Hermes 2018. Several exact-string searches were noisy or irrelevant; a no-hit is not evidence of novelty.
C. No useful dimension/bit-complexity bound or concrete r=2 matrix has been acquired. d=2^26 is a sufficient analytic dimension, not a produced matrix or a practical computation.
D. Exact K(d), especially d=4,k=2, remains open here; so do PPT-cubed, NPT bound entanglement, and nontrivial all-tensor positivity.
E. No physical computation, cryptographic, sensing, capacity, or laboratory advantage is proved.

## Pins and persistence

Astra: 687dfc0640ee80654bcbdbe38cb13d6e1f1586ce.
OpenAI family-272 source orientation: fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb.
The user-supplied prior proof artifacts and their hashes are recorded in SOURCES.json. They are not silently replaced. No repository writes, issue submissions, emails, or pull requests occurred. The package is local and reproducible.
