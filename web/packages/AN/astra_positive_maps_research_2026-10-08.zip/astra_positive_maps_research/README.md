# Gaussian cone separation: research proof and audit packet

**Status:** internally derived proofs and executed finite diagnostics. No external review, proof-assistant formalization, or historical-priority clearance. No historic-scale breakthrough is claimed.

Start with `proofs/GAUSSIAN_CONE_SEPARATION.md`. It proves existence of indecomposable r-entanglement-breaking positive maps for every finite r and a linear lower bound for the decomposable-Schmidt hierarchy covering the PPT cone. **Those positive maps are not physical quantum channels.** A separate construction in the same proof supplies actual PPT channels.

`AUDIT_AND_FAILED_ROUTES.md` explains why the preceding double-factorial bound-entangled state family was not retained as the main route and provides exact obstruction certificates. `proofs/ITERATION_AND_LIMIT_BARRIERS.md` proves that the new physical PPT channels can have entanglement-breaking index exactly two, despite the large decomposition complexity. `RESEARCH_STATE.md` is the restart handoff. `SOURCES.json` records source versions, exact scope, read depth, and the distinction between premises and orientation.

## Reproduce the finite checks

From this directory, with Python 3.13 and the packages in requirements.txt:

```bash
python tests/verify_gaussian_construction.py
python tests/audit_prior_family.py
python tests/verify_iteration_barrier.py
```

These scripts write JSON files in `results/`. Supplied logs are the outputs actually obtained. Numerical sampled-rank searches do **not** certify the universal Schmidt-rank bound: that is proved analytically using a complete net argument. No theorem-sized matrix at d=2^26 was generated. The exact rational constant checks and old-family certificates are not formal proofs of the probabilistic theorem.

No repository was changed. Files under `inputs/` in the working directory were only source material and are not redistributed in the new ZIP; their hashes are retained. The manifest covers the new deliverables and is an integrity record, not mathematical validation.
