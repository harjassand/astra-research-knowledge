# Independent adversarial audit of the strengthened stochastic theorem

Date: 9 October 2026. Scope: `strengthened_theorems.md` and the full supporting `source_scientific_record.md`, read independently and reconstructed algebraically. This is an independent agent audit within one investigation, not external peer review, a proof-assistant certificate, or a historical-priority assessment.

## Verdict

**No fatal mathematical defect found in the stated strengthening.** The exact halting bands, computable robustness promises at encoded rational centers, phase volume of Turing degree 0', and busy-beaver lower bounds follow from the supplied construction. The source switching lemma also survives the main adversarial checks. The qualifications already present about idealized unbounded populations, parameter-family robustness, effective existence rather than a fully expanded universal reaction list, and absent historical-priority certification are necessary.

The conclusions concern rate constants bounded above and below, not bounded jump intensities. They give no physical hypercomputation or practical finite experiment deciding halting.

## 1. The allegedly dangerous transient-controller step is valid

Mere recurrent visits to a favorable environment would not suffice if explosion probability deteriorated with current Z height. Here that loophole is closed. With alpha=(lambda-mu)/H>1, auxiliary birth-death weights satisfy pi_j asymptotic to a positive constant times j^(alpha-3). The exact finite first-passage recurrence gives u_j=(sum_{i<=j}pi_i)/(b_j pi_j), which is summable for all alpha>1, including the logarithmic alpha=2 case.

Let M=E_1 tau for the frozen environment. Starting at 1, every finite height z is hit before explosion, and the strong Markov property gives E_z tau <= M. Consequently every favorable visit, whatever its Z height, has explosion probability at least delta=(1/2)exp(-2q(v)M) before the next departure: require a holding time at least 2M and explosion during that time. All quantities are finite and delta is strictly positive, even when unimaginably small.

The finite-mean argument also does not improperly assume survival and cycle length are independent. Survival at entry sigma_k is measurable with respect to the past. The *future autonomous environment cycle* has conditional mean r_v at that entry, so E[1_{tau>sigma_k}L_k]=r_v P(tau>sigma_k). Geometric visit survival makes the total expectation finite. Cycle lengths need not be independent of survival to their end.

## 2. Nonexplosion and equality cases

For h(z)=sum_{j<z}1/j, direct calculation gives

L_Z h=(D-H)(z-1)-mu+eta/z for z>=2, and L_Z h(1)=eta.

When D<=H everywhere, this is at most eta uniformly over all controller counts, and at most -1/2 for sufficiently large z because mu>=1. Thus F=1+sum n_i+2(m+1)h(z) is proper and satisfies LF<=C. Finite-sublevel localization excludes explosion. The stronger drift LF<=-1 outside a finite set yields finite mean hitting times and positive recurrence. Neither a formal stationary measure for an explosive chain nor an unjustified stationary-moment calculation is used.

At band endpoints D=H is included. At theta=0 the compactified polynomial vanishes, H=B, and D-H<=0 in every integer state. Thus zero is positive recurrent even though explosive bands accumulate there.

## 3. Exact arithmetic and legal reaction realization

DPRM is applied to the exact finite runtime relation (k,t). Splitting the representing integer polynomial into positive and negative parts and introducing nonnegative arithmetic-gate variables gives a *fixed finite* quadratic system. This does not require T(k) to be computable from k. The gate equations only witness the c.e. relation.

At integer controller counts, sum f_j^2 is a nonnegative integer. Since r^2=1/8<1, S_a<1/8 forces every gate equation to vanish. It then forces |k-a|<r; conversely a true halting witness realizes the band. Excluding k=0 makes all resulting intervals lie strictly within (0,1).

The compactification theta^2[theta(k+1)-1]^2+theta^4 sum f_j^2 is exactly theta^4 S_a and has degree at most four separately in theta and in all controller variables. Integer Stirling transforms preserve integer coefficients. The envelope b_beta=2+||q_beta||_1 ensures every noise constant b_beta+q_beta(theta)>=2 throughout [0,1]. All fixed constants, including eta, are integers. Merging repeated channels changes neither positivity nor parameter degree.

Reaction-order checks: the controller catalyst degree is <=4; adding 2Y+2Z gives maximum reactant molecularity 8, while the other channels have product molecularity at most 8. Every net jump is one coordinate by one. Controller catalysis does not alter controller dynamics. Immigration vectors rule out nonzero linear conservation laws. The stochastic propensity convention must remain falling factorial, exactly as stated in the source.

## 4. Identical flow and the polynomial certificate

The noise pairs cancel as entire deterministic polynomials, and also cancel pointwise in the stochastic coordinate drift. The remaining deterministic damping is Gamma=Bbar(x)[2(y-1/2)^2+1/2]>=1. Its value at the all-one point is eta.

Writing delta=eta-Gamma and e=z-1, the independently checked identity is

2e[delta-Gamma e(z+1)]-delta^2 = -(delta-e)^2-[2Gamma(z+1)-1]e^2.

Adding the controller derivative proves the stated strict Lyapunov inequality. The residual defining Q vanishes at the origin of the integration coordinate, so division by that coordinate is harmless and integration gives rational coefficients of degree at most twelve. Coercivity follows directly from the squared-distance part. No deterministic blowup is hidden.

## 5. Robust rational centers, with the correct scope

Put c=k+1 and epsilon=1/(8c^2). For |theta-1/c|<epsilon,

|1/theta-c| < (1/8)/(1-1/(8c)) <=1/7<1/4.

The corresponding a remains within 1/4 of k and at distance greater than 3/4 from every other integer. Therefore the entire ball has the same stochastic phase as its central halting instance, regardless of which neighboring programs halt. The radius can be supplied computably without knowing membership in K.

This does not give robustness at theta=0, uniform positive radius over all k, robustness to arbitrary perturbations of all rates, or an algorithm deciding the promised phase. Arbitrary real inputs need a representation to formulate algorithmic questions; the undecidability theorem itself already holds on explicitly encoded rational centers with the supplied rational radius.

## 6. The phase-volume degree argument is sound

Disjointness uses 2r<1. Algebra gives the exact interval width w_k=2r/((k+1)^2-r^2). The all-index tail is computably bounded by comparison with k^-2. Hence K computes p=sum_{k in K}w_k, and p is left-c.e.

The converse does not require superincreasing weights or binary-digit isolation. For any queried k choose computable rational 0<c<w_k. Dovetail enumeration of K, monotone certified lower approximations L_s to the enumerated mass, and certified upper approximations U_s to p from its real oracle. Eventually U_s-L_s<c. If k has not appeared, it cannot appear later because its missing positive weight alone exceeds the residual budget. Approximation errors in already enumerated weights only enlarge the residual and cannot cause a false negative. This establishes K<=_T p.

Thus the exact probability is noncomputable and nonalgebraic. It is not claimed to be algorithmically random, nor does the argument say that every fixed coarse numerical approximation is inaccessible.

## 7. Runtime domination and busy-beaver growth

At the center for a halting program k, a favorable state requires runtime count T(k). Stop the process on first hitting that runtime count. Throughout the unstopped region D-H<=0, so the same proper-function generator bound excludes explosion before that hit. More formally apply Dynkin to t wedge H_T wedge sigma_L, where sigma_L exits an F-sublevel, and let L tend to infinity. For T>1 and initial runtime count 1, the controller stays below T before its first hit because jumps are nearest-neighbor.

The controller needs at least T-1 unit-rate immigrants to reach T; deaths only delay it. Therefore P(tau>s)>=P(Pois(s)<T-1). Its upward first-passage means obey v_0=1, v_j=1+jv_{j-1}; solving gives v_j=j! sum_{i=0}^j1/i!. Consequently E tau>=sum_{j=1}^{T-1}v_j>=(T-1)!. These are lower bounds on quantities that the favorable-visit proof separately shows are finite.

The median bound follows by P(Pois((T-1)/4)>=T-1)<=1/4. Any fixed quantile q in (0,1) has a proportional bound by choosing a Poisson time c(T-1) with 0<c<q. The latter qualification excludes the trivial zero quantile.

For any total computable g, a program hardcoding n computes g(n) and delays at least 8g(n)+8 steps; its length is c_g+O(log(n+2)), eventually <=n. Thus worst finite means and medians among halting descriptions of length <=n eventually exceed g(n). The proof concerns maxima and gives no computable maximizing code.

Minor presentation clarification, not a defect: if a convention allows T=0, define the stopping domain as all runtime counts other than T instead of only counts below T, or simply require halting runtimes >=1 by a fixed initial machine step. The claimed asymptotic and factorial bounds are only needed for T>=2. A conventional positive-integer binary encoding should be stated so that bit length of k+1 and description length differ by at most a fixed additive constant, as the current text anticipates.

## 8. Independent checks and external scope

A fresh SymPy check passed the harmonic identity, Lyapunov square-completion identity, coefficient (lambda-mu)/H-3 in the frozen cubic birth/death ratio, interval-width identity, and exact passage-time recurrence through j=29. These checks corroborate interfaces; they are not a universality test.

Independently opened Anderson–Cappelletti–Koyama–Kurtz, arXiv:1708.09356v2, https://arxiv.org/html/1708.09356v2 . Its mass-action convention agrees and it explicitly discusses the deterministic/stochastic explosion mismatch. Attempting to reopen the cited author-written Scholarpedia DPRM page returned a 502 error in this audit; no claim of newly verifying that source is made. DPRM remains the identified standard external theorem rather than an internally reproved result.

No paid or remote jobs, external communications, publication, or changes to the theorem files were performed. The audit does not establish priority, specialist endorsement, formal verification, or resolution of a historic open problem.
