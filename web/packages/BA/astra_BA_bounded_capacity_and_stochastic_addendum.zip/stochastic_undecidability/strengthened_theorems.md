# Robust undecidable phases, noncomputable phase volume, and busy-beaver lifetimes

Research derivation, 9 October 2026. Status: complete mathematical argument below, based on the retrieved source construction and classical DPRM. No independent human review, proof-assistant verification, or historical-priority claim. The universal Diophantine system is specified effectively, not expanded into an enormous reaction list. The findings strengthen the source theorem; they do not resolve a recognized historic open problem.

## 1. Exact source and audit

Source: Library file `libfile_d9f06c3031708191b106b60e5379df67`, `scientific_record.md`, created 8 October 2026 18:13:27 UTC. An exact text copy is saved beside this file as `source_scientific_record.md`.

I checked these interfaces independently by mathematical derivation:

* Harmonic observable: for b(z)=eta+lambda z(z-1)+H z(z-1)^2, d(z)=mu z(z-1)+H z(z-1)^2, and h(z)=sum_{j<z}1/j, Lh=(lambda-mu-H)(z-1)-mu+eta/z at z>=2, and Lh(1)=eta.
* Frozen positive mode: with alpha=(lambda-mu)/H>1, birth-death weights satisfy pi_j asymptotic to constant times j^(alpha-3); expected crossing times are summable. The expected explosion time is bounded uniformly over starting height by its value at height 1.
* Recurrent exposure: autonomous immigration-death controllers have finite mean return cycles. Uniform positive chance of explosion during each visit, together with the cycle bound, proves finite mean lifetime, not just positive probability.
* Nonpositive mode: the proper harmonic-plus-controller function has bounded-above generator and negative drift outside a finite set, giving nonexplosion and positive recurrence, including equality.
* Polynomial Lyapunov: the derivative identity in source equation (4.3) expands correctly, with Gamma>=1 on the nonnegative orthant.
* Positive coefficient envelope: its factorial-to-monomial conversion, bounded positive constants, and maximum molecularities are consistent. No flaw was found in this audit.

This is not a claim of formal verification. The two-species seven-reaction example is a separate source result; the new claims below concern a much larger fixed universal graph.

## 2. Arithmetic with an isolated integer input

Fix a conventional universal machine with positive integer program codes k. Let T(k) be its exact finite runtime when it halts, and let K be its halting set. Use a harmless compulsory initial step, so every halting runtime satisfies T(k)>=1. Choose an encoding in which an algorithm with integer constant n has a program of length O(log(n+2)) plus the fixed algorithm description. Binary self-delimiting encodings have this property.

The relation R={(k,t): k halts in exactly t steps} is computably enumerable (in fact decidable for finite k,t). DPRM supplies an integer polynomial for R. Introduce nonnegative arithmetic-gate witnesses and separate positive and negative polynomial parts. This gives a fixed finite list of integer quadratic polynomials

f_j(k,t,w), j=1,...,s,

such that there exists w in N^d with all f_j(k,t,w)=0 if and only if t=T(k). The list also excludes k=0; for instance add the equation k-u-1=0 with a nonnegative witness u. No real parameter occurs in these equations.

For real a>=0 define

S_a(k,t,w)=(k-a)^2 + sum_j f_j(k,t,w)^2.

Every term in the second summand is an integer square at integer controller counts. Thus, with r=1/sqrt(8),

8 S_a(k,t,w)<1

holds for some integer controllers exactly when a lies within distance r of some k in K. Indeed it forces all f_j=0; the remaining inequality is |k-a|<r. Conversely, a halting k has a witness and satisfies the inequality throughout that interval. Because 2r<1, the intervals around distinct integers are disjoint.

Compactify a=(1-theta)/theta for theta>0 and put

S_tilde_theta=theta^2 [theta(k+1)-1]^2 + theta^4 sum_j f_j(k,t,w)^2.

This is precisely theta^4 S_a, extends polynomially to theta=0, and has degree at most four separately in theta and in all controller variables. The first term has controller degree two. Coefficients are integers.

## 3. Compile into the same identical-flow construction

Use the source compiler with 8 S_tilde_theta-theta^4 in place of 2 S_tilde_theta-theta^4. In full, expand

8 S_tilde_theta(n)-theta^4 = sum_{|beta|<=4} q_beta(theta) (n)_beta,

where n=(k,t,w). Set b_beta=2+||q_beta||_1, h_beta(theta)=b_beta+q_beta(theta), B(n)=sum b_beta(n)_beta, Bbar(x)=sum b_beta x^beta, and eta=Bbar(1). Then all h_beta are between 2 and 2+2||q_beta||_1 on [0,1]. Include every multi-index through degree four, allowing zero q_beta.

All controller species n and one additional species Y have immigration and death at rate one. Include immigration of Z at eta, and the two channels 2Z->3Z and 2Z->Z at rate one. For every beta include:

* X_beta+2Z -> X_beta+Z at b_beta;
* X_beta+Y+2Z -> X_beta+Y+3Z at 2b_beta;
* X_beta+2Y+2Z -> X_beta+2Y+Z at 2b_beta;
* X_beta+2Z -> X_beta+3Z and X_beta+2Z -> X_beta+Z, each at h_beta(theta);
* X_beta+3Z -> X_beta+4Z and X_beta+3Z -> X_beta+2Z, each at h_beta(theta).

Parallel channels can be merged. This is one fixed finite graph, with a fixed number of species, polynomial rate constants of parameter degree at most four, and a common finite bound 1<=rate<=C. Source and product molecularities are at most eight. Every jump changes one coordinate by one. There is no linear stoichiometric conservation law.

Its exact threshold in controller state (n,y) is favorable only when y=1, in which case

D-H=theta^4-8 S_tilde_theta(n).

The source switching lemma therefore proves finite-mean almost-sure explosion whenever this is positive at any integer controller state, and nonexplosive positive recurrence otherwise. All conclusions use the minimal chain killed at explosion, on the closed irreducible class N^(d+3) x {1,2,...}, since w has d coordinates; all controllers range in N and Z>=1. The common initial state has every coordinate equal to one.

The complete deterministic vector field, independent of theta, is

x_i'=1-x_i, y'=1-y, z'=eta-Gamma(x,y)z^2,
Gamma(x,y)=Bbar(x)[2(y-1/2)^2+1/2]>=1.

It has the common globally asymptotically stable equilibrium 1. With u=(x,y),

Q(u)=integral_0^1 [Gamma(1+s(u-1))-eta]^2 ds/s,
V(u,z)=||u-1||^2+(z-1)^2+Q(u),

V is a coercive rational polynomial of degree at most twelve and Vdot<=-||u-1||^2-(z-1)^2. Thus all source deterministic guarantees are preserved. All stochastic coordinate drifts are also independent of theta.

## 4. Exact phase diagram and computable robustness

The explosive parameter set is exactly

E = union_{k in K} I_k,
I_k = (1/(k+1+r), 1/(k+1-r)),  r=1/sqrt(8).

These intervals are disjoint and wholly inside (0,1), since k>=1. Endpoints and theta=0 are nonexplosive and positive recurrent. Their accumulation at zero causes no exception to the switching lemma.

At theta_k=1/(k+1), define the explicitly computable rational radius

epsilon_k = 1/[8(k+1)^2].

If |theta-theta_k|<epsilon_k, then

|1/theta-(k+1)| < (1/8)/(1-theta_k/8) <= 1/7 < 1/4.

(The bound remains valid for k>=0; here k>=1.) If k halts, the distance to k is less than 1/4<r, so the whole ball is explosive. If k does not halt, its distance to every halting integer is greater than 3/4>r, so the whole ball is nonexplosive and positive recurrent.

Hence the same exact undecidability persists even with a computable, nonzero, instance-specific robustness radius supplied as a promise. This is robustness to variation along the designated one-dimensional polynomial rate family. It is NOT a theorem about arbitrary independent perturbations of every rate constant, nor a uniform lower bound on epsilon_k over all k.

## 5. Noncomputable phase volume

Let theta be drawn uniformly once from [0,1], then held fixed for the stochastic evolution. Conditional eventual explosion probability is 1_E(theta). Thus its unconditional probability is

p = measure(E) = sum_{k in K} w_k,
w_k = 2r / [(k+1)^2-r^2] > 0.

This real is left-computably enumerable: enumerate halting codes without repetition and add increasing rational lower approximations to their computable positive weights. The total series has a computable tail bound, for example sum_{k>N} w_k <= 2/(N+1) for N>=1, since r<1/2 and w_k<1/k^2; the displayed loose bound suffices.

Claim: p has precisely the Turing degree of K (degree 0').

First, K computes p: query membership for finitely many k and use the computable tail bound to attain any required error.

Conversely, an oracle giving arbitrarily accurate rational approximations to p decides K. On query k, choose a known positive rational c<w_k. Enumerate K, forming increasing certified lower partial masses L_s, while obtaining upper approximations U_s to p with U_s decreasing to p. Stop once U_s-L_s<c. This eventually happens because L_s tends to p. If k has been enumerated, answer yes. If not, answer no: future enumeration of k would add at least w_k>c, contradicting the certified residual bound. This proves K<=_T p.

In particular p is a noncomputable, and therefore nonalgebraic, real number. All reaction-rate functions have integer coefficients, all fixed constants in the construction are integers, and the random parameter has the ordinary computable uniform distribution. This noncomputability concerns the exact real probability and arbitrary-precision computation; it does not claim that every particular coarse approximation is impossible.

The result does not rely on any noncomputable number being inserted into the model specification. It arises from the long-time behavior of a finite, effectively specified idealized unbounded-state system.

## 6. Finite lifetimes with busy-beaver-scale lower bounds

At the central parameter theta_k for a halting k, every favorable environment state must have its input controller equal to k, all integer gate equations zero, and hence runtime controller equal to T(k). Let H_k be the first time the runtime controller reaches T(k), starting at count one.

There is no explosion before H_k. For T(k)>1, on all states with runtime count below T(k), the source harmonic-plus-controller Lyapunov function has its nonexplosive upper generator bound. Stop at H_k and at finite proper-function sublevels. The localized bound, followed by the sublevel limit, excludes explosion before H_k. The controller itself is nonexplosive and changes by unit steps. Therefore tau_k>=H_k almost surely. T(k)<=1 only makes the subsequent lower bounds trivial.

The runtime controller's immigrants arrive as a unit-rate Poisson process A(s). Reaching T(k) from one requires at least T(k)-1 immigrants, irrespective of deaths. Consequently

P(tau_k>s) >= P(Pois(s)<T(k)-1),
E tau_k >= T(k)-1.

There is also an exact and much stronger mean lower bound. For the unit immigration-death controller, the expected time v_j to first pass from j to j+1 satisfies v_0=1 and v_j=1+j v_(j-1). Hence v_j=j! sum_{i=0}^j 1/i!, and, for T(k)>=2,

E tau_k >= E_1 H_k = sum_{j=1}^{T(k)-1} j! sum_{i=0}^j 1/i! >= (T(k)-1)!.

This uses only a finite birth-death hitting problem; all passage expectations are finite.

One elementary quantile bound avoids asymptotics. With m=T(k)-1>0, Markov's inequality gives

P(tau_k<=m/4) <= P(Pois(m/4)>=m) <= 1/4.

Thus the median lifetime is at least (T(k)-1)/4. More generally, any fixed quantile has a proportional runtime lower bound by the same Poisson argument. Every such tau_k nevertheless has finite mean by the favorable-state argument.

Define M(n) as the maximum of E tau_k over halting codes of binary description length at most n, and define Q(n) similarly using median lifetimes; maxima of an empty set may be zero. Both are finite for each n.

For every total computable function g:N->N, both M(n) and Q(n) exceed g(n) for all sufficiently large n. To see this, construct, for each n, a halting program that has n hardcoded, computes g(n), then runs for at least 8g(n)+8 steps. Its description length is c_g+O(log(n+2)), hence at most n for all sufficiently large n. Its runtime bound, and the inequalities above, put it among the candidates for M(n),Q(n), with values greater than g(n). This is a standard busy-beaver diagonal argument applied to the explicitly required runtime witness.

Program code length and the bit length of theta_k's reduced rational denominator agree up to a fixed additive convention. Thus this lower bound is also a statement about the succinctness of rational rate-parameter inputs. It is NOT a lower bound for every individual halting input, and it does not provide a computable choice of the maximizing input.

## 7. What this mechanism cannot claim

For unit coordinate jumps with no simultaneous changes, the coordinate drifts and second-order generator data determine every transition rate. Indeed at a state x,

L x_i = b_i-d_i,
L(x_i^2)-2x_i Lx_i = b_i+d_i,

so b_i and d_i are uniquely recovered. Hence in this exact graph class, preserving all first and second coordinate-generator data preserves the entire stochastic generator. Undecidable changes cannot be hidden beyond second moments while retaining these unit-coordinate-jump assumptions. This is an exact obstruction, not merely failure to find a construction. It does not rule out constructions with larger jumps or other model classes.

The robust-phase and volume conclusions concern the designated family. They do not establish undecidability in realistic bounded-population chemistry, bimolecular closed systems, complex-balanced networks, or systems with finite-state cutoffs. Explosion is an idealized mathematical failure of an unbounded-population model.

## 8. Independent primary-source checks and attribution

* Yuri Matiyasevich, author's account of the DPRM theorem: https://www.scholarpedia.org/article/Matiyasevich_theorem . The theorem covers computably enumerable relations in several nonnegative integer variables and is constructive. The arithmetic-gate quadratic conversion is supplied above, rather than attributed to an unverified newer theorem.
* Anderson, Cappelletti, Koyama and Kurtz, 2018, Example 5: https://arxiv.org/html/1708.09356v2 . The actual example already combines a globally attracting deterministic equilibrium with almost-sure stochastic explosion through repeated exposure of an autonomous recurrent subsystem. These broad phenomena are prior art. Their complex-balance nonexplosion theorem is not contradicted here.
* Cook, Soloveichik, Winfree and Bruck, Programmability of Chemical Reaction Networks, Theorem 3: https://www.dna.caltech.edu/Papers/programmability_of_CRNs_book2009.pdf . The actual theorem establishes undecidability of bounded-error eventual production probabilities. General chemical stochastic undecidability is prior art.

The additional contributions proved here are the isolated-input compiler yielding exact disjoint halting bands and explicit parameter-robustness promises, noncomputable phase volume of Turing degree 0', and busy-beaver lower bounds on finite mean lifetimes/quantiles, all within the original identical-full-flow and common-Lyapunov class. Historical priority for these conjunctions has not been established. No assertion of a historic-scale breakthrough is warranted from this derivation alone.

## 9. Exact checks and one useful rational-endpoint variant

The executable `verify_strengthening.py` uses the small decidable gate relation k=v^2+1, t=k^2, rather than pretending to instantiate the universal machine. It passed 35 reconstructed factorial coefficients, positivity-envelope bounds, 3,564 exact rational-parameter witness-band checks, the harmonic-generator identity, band-width algebra, and 39 immigration-death passage recurrences. Output is in `verification_results.txt`. These checks support the algebraic interfaces and do not constitute proof of universality or an independent audit.

For an even simpler phase diagram, replace every factor 8 in the threshold/compiler by 16. All proofs are unchanged with r=1/4. Then

I_k=(4/(4k+5), 4/(4k+3)),
w_k=8/[16(k+1)^2-1],
epsilon_k=1/[16(k+1)^2].

The last radius guarantees |a-k|<1/15<r. Thus the exact noncomputable phase volume can be a sum of positive rational widths, with every band endpoint rational. The displayed test script checks the factor-eight version; the rational-endpoint variant follows by replacing its scalar threshold and is also covered by the same proof.

A related 2025 title, Alhazov et al., *The busy beaver game for reaction systems*, https://link.springer.com/article/10.1007/s11047-025-10037-6 , concerns qualitative set-rewriting reaction systems with finite state spaces. The primary paper explicitly identifies that finite-state distinction. It does not supply or refute the unbounded stochastic lifetime theorem proved here. More generally, neither use of a busy-beaver argument nor noncomputability arising from a halting encoding is itself a novel foundational technique.

## 10. Independent adversarial audit

A separate mathematical reconstruction on 9 October 2026 found no fatal flaw in the source mechanism or the new claims, including cycle conditioning, residual-mass recovery, stopped-Lyapunov runtime gating, and the factor-sixteen rational-endpoint variant. Its report is `independent_adversarial_audit.md`. A minor runtime-zero ambiguity was removed by the explicit compulsory-initial-step convention. This was a separate AI audit, not human peer review or machine-checked formal proof.
