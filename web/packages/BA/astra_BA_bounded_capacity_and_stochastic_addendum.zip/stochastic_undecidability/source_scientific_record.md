# Undecidable stochastic lifetimes under a fixed globally stable mass-action flow

**Research record — 9 October 2026**

## Status and scope

This record gives complete mathematical constructions and proofs. The principal result is an undecidability theorem for a fixed reaction graph whose entire deterministic vector field, stochastic infinitesimal drift, and explicit global polynomial Lyapunov function are independent of its rate parameter. A second, fully listed two-species example has an exactly classified, nonsemialgebraic explosion region.

These statements were derived in this investigation. Their historical priority has **not** been established. No independent human review or proof-assistant verification occurred. Exact symbolic checks support the algebraic interfaces but are not substitutes for the proofs. No result was published or merged. No resolution of a recognized historic-scale open problem is claimed.

The computability input is the established Davis–Putnam–Robinson–Matiyasevich (DPRM) theorem. No mathematical claim from the October 2026 OpenAI release is a dependency of the results proved here.

---

## 1. Principal theorem

Let \(K\subseteq\mathbb N\) be a fixed recursively enumerable complete set, for example the halting set. Here \(\mathbb N=\{0,1,2,\ldots\}\).

**Theorem 1.** There are a fixed finite mass-action reaction graph, a fixed number of species, and integer-coefficient polynomials \(k_r(\theta)\), one for each reaction, with the following properties.

1. For every \(0\le\theta\le1\), all rate constants lie in a fixed interval \([1,C]\), where \(C<\infty\) is independent of \(\theta\). They have parameter degree at most four. Every reaction changes exactly one coordinate by one, and both source and product complexes have total molecularity at most eight. There is no nonzero linear stoichiometric conservation law.
2. The **entire** deterministic mass-action vector field is identical for all \(\theta\). It has a unique globally asymptotically stable equilibrium \(\mathbf1\) in the nonnegative orthant. A single explicitly constructed coercive polynomial \(V\in\mathbb Q[x]\), of degree at most twelve, satisfies
   \[
   V(x)\ge\|x-\mathbf1\|^2,\qquad V(\mathbf1)=0,
   \qquad \dot V(x)\le-\|x-\mathbf1\|^2.
   \]
   The stochastic generators also agree on all coordinate functions; this is equality of infinitesimal drifts, not a claim about the existence or equality of unbounded moments.
3. Write \(\theta_a=1/(a+1)\). From the common initial state \(\mathbf1\), the minimal stochastic mass-action chain has lifetime \(\tau\) satisfying
   \[
   a\in K\ \Longrightarrow\ \mathbb E_{\mathbf1}\tau<\infty,
   \qquad
   a\notin K\ \Longrightarrow\ \mathbb P_{\mathbf1}(\tau=\infty)=1.
   \]
   In the latter case its closed irreducible state space is positive recurrent. The same dichotomy holds from every state of that class.
4. Consequently, deciding explosion, nonexplosion, or positive recurrence is undecidable on this one polynomial family, even when the common deterministic vector field and its polynomial Lyapunov certificate are supplied. The eventual explosion probability is exactly \(1_K(a)\). It cannot be uniformly approximated, from the rational parameter or rational rate constants, within any fixed error strictly below \(1/2\).
5. The explosive parameter set in \([0,1]\) is relatively open but not semialgebraic.

Only **rate constants** are uniformly bounded. State-dependent jump intensities are unbounded, as is necessary for explosion. This is an idealized open, unbounded-population model, not a claim about physical hypercomputation.

### Mass-action convention

For a reaction \(u\to v\) with constant \(k\), the deterministic rate is \(kx^u\) and the unit-volume stochastic propensity is
\[
k(n)_u=k\prod_i(n_i)_{u_i},\qquad
(n)_j=n(n-1)\cdots(n-j+1).
\]
The falling factorial is zero when a count is smaller than the required reactant multiplicity. This is the convention used in Anderson–Cappelletti–Koyama–Kurtz [2, Section 4]. It is not the binomial propensity with the same unadjusted constants.

The lifetime is the accumulation time of infinitely many jumps. The minimal chain is killed at that time; no continuation from infinity is used.

## 2. The exact stochastic mechanism

### 2.1 Harmonic detection of symmetric cubic noise

Let an autonomous environment \(N_t\in\mathbb N^m\), \(m\ge1\), have independent immigration–death coordinates:
\[
n\to n+e_i\text{ at rate }1,
\qquad n\to n-e_i\text{ at rate }n_i.
\]
It is nonexplosive: on bounded time intervals there are finitely many immigrants, and each initial particle or immigrant dies at most once. It is irreducible and has the product \(\operatorname{Pois}(1)\) stationary distribution, for example by the stationary immigrant-lifetime construction. Hence it is positive recurrent, and every state has finite mean hitting and return times.

Let \(Z_t\in\{1,2,\ldots\}\) have, conditional on \(N_t=n\), birth and death rates
\[
\begin{aligned}
b_n(z)&=\eta+\lambda(n)z(z-1)+H(n)z(z-1)^2,\\
d_n(z)&=\mu(n)z(z-1)+H(n)z(z-1)^2,
\end{aligned} \tag{2.1}
\]
where \(\eta>0\), \(\lambda,\mu\ge1\), and \(H>0\) are finite at each state. Put \(D=\lambda-\mu\).

The symmetric cubic term contributes zero to \(\mathcal L Z\). It is nevertheless detected exactly by
\[
h(1)=0,\qquad h(z)=\sum_{j=1}^{z-1}\frac1j\quad(z\ge2).
\]
Indeed, for \(z\ge2\),
\[
\boxed{\mathcal L_Zh(z)=(D(n)-H(n))(z-1)-\mu(n)+\eta/z.} \tag{2.2}
\]
This follows by substituting \(h(z+1)-h(z)=1/z\) and \(h(z-1)-h(z)=-1/(z-1)\). At \(z=1\), \(\mathcal L_Zh(1)=\eta\).

Thus symmetric noise invisible to the ordinary drift becomes a signed drift for a logarithmically growing observable.

**Lemma 2 (complete switching dichotomy).** For (2.1):

- If \(D(v)>H(v)\) at even one environment state \(v\), then the joint minimal chain explodes almost surely, with finite mean lifetime from every state.
- If \(D(n)\le H(n)\) for all environment states, the joint chain is nonexplosive and positive recurrent.

The critical case of equality is included.

### 2.2 Proof in the nonpositive case

Equation (2.2) gives \(\mathcal L_Zh\le\eta\) everywhere, and \(\mathcal L_Zh\le-1/2\) when \(z\ge R\), for any fixed integer \(R\ge\max(2,2\eta)\).

Set
\[
F(n,z)=1+\sum_i n_i+2(m+1)h(z).
\]
It has finite sublevel sets. Everywhere,
\[
\mathcal LF\le m+2(m+1)\eta.
\]
Localized Dynkin's formula, stopped on finite sublevel sets, then rules out explosion. To see the essential estimate, the probability of leaving a sublevel of height \(L\) by time \(t\) is bounded by \((F(n,z)+Ct)/L\); let \(L\to\infty\).

If \(z\ge R\), then \(\mathcal LF\le-1\). If \(z<R\), the bound
\[
\mathcal LF\le m-\sum_i n_i+2(m+1)\eta
\]
is negative outside a finite set. The finite-set Foster argument gives positive recurrence. More explicitly, stopped Dynkin bounds the expected hitting time of that finite set from each starting state. Inside it, irreducibility supplies a positive-probability finite path to a chosen reference state; the finite number of starting states and successors makes the intervening expected excursion costs finite. Repeating those trials gives a finite expected return time to the reference state.

Irreducibility holds because environment coordinates can increase and decrease, while \(Z\) can increase at every level and decrease at every level above one.

### 2.3 Frozen positive mode: finite mean, uniformly over starting height

Freeze the environment, writing \(\lambda,\mu,H\) for its constants, and suppose
\[
\alpha=(\lambda-\mu)/H>1.
\]
Use the birth and death rates \(b_j,d_j\) in (2.1). Define \(\pi_1=1\) and
\[
\pi_j=\frac{b_1\cdots b_{j-1}}{d_2\cdots d_j}\quad(j\ge2).
\]
These are auxiliary weights, **not** an assertion that a formal stationary measure is stationary for an explosive chain.

The expected time \(u_j\) to hit \(j+1\) starting at \(j\) satisfies
\[
b_j u_j=1+d_j u_{j-1},\qquad u_1=1/\eta.
\]
Consequently
\[
u_j=\frac{\sum_{i=1}^j\pi_i}{b_j\pi_j}. \tag{2.3}
\]
This recurrence is justified within a finite birth–death chain stopped on hitting \(j+1\), where all relevant hitting expectations are finite.

A direct expansion gives
\[
\frac{b_{j-1}}{d_j}=1+\frac{\alpha-3}{j}+O(j^{-2}),
\qquad \pi_j\asymp j^{\alpha-3}.
\]
Taking logarithms proves the second estimate because the \(O(j^{-2})\) error is summable. Since \(b_j\asymp j^3\), (2.3) yields
\[
u_j=\begin{cases}
O(j^{-\alpha}),&1<\alpha<2,\\
O(j^{-2}\log j),&\alpha=2,\\
O(j^{-2}),&\alpha>2.
\end{cases}
\]
Every case is summable. The first hitting times of levels tend to the minimal lifetime, so monotone convergence gives
\[
M:=\mathbb E_1\tau=\sum_{j\ge1}u_j<\infty. \tag{2.4}
\]
Starting from one, every finite higher level is hit before explosion, with finite mean hitting time. The strong Markov property therefore gives
\[
\sup_{z\ge1}\mathbb E_z\tau\le M.
\]
This uniformity is essential: visits of the environment to a favorable state are not by themselves a proof of almost-sure explosion.

### 2.4 Repeated exposure proves the positive case

At each entry of the autonomous environment into the favorable state \(v\), let \(T=2M\), using (2.4) for that state. By Markov's inequality, the frozen process explodes within time \(T\) with probability at least \(1/2\), whatever its current height.

The environment remains at \(v\) for time \(T\) with probability \(e^{-q(v)T}\), where \(q(v)=m+\sum_i v_i\). Its clocks can be constructed independently of the clocks driving \(Z\). Thus each visit has conditional success probability at least
\[
\delta=\tfrac12e^{-q(v)T}>0.
\]
Survival through \(k\) visits has probability at most \((1-\delta)^k\), proving almost-sure explosion.

For finite mean, let \(A\) be the first hitting time of \(v\), and \(\sigma_k\) successive entry times thereafter, separated by a departure. The autonomous environment may be extended after \(Z\) is killed. Its cycle lengths \(L_k=\sigma_{k+1}-\sigma_k\) have one finite mean \(r_v\), conditional on the history at \(\sigma_k\). Pathwise,
\[
\tau\le A+\sum_{k\ge0}1_{\{\tau>\sigma_k\}}L_k.
\]
Therefore
\[
\mathbb E\tau\le\mathbb EA+r_v\sum_{k\ge0}(1-\delta)^k
=\mathbb EA+r_v/\delta<\infty.
\]
This proves Lemma 2 completely.

## 3. Compiling arithmetic into noise while fixing both drifts

### 3.1 Fixed quadratic arithmetic input

By DPRM [1], choose a fixed integer polynomial representing \(K\). Replacing its arithmetic circuit by equations for additions, multiplications, constants, and output equality gives a fixed finite system
\[
f_1(a,n)=\cdots=f_s(a,n)=0,\qquad n\in\mathbb N^d, \tag{3.1}
\]
with each \(f_j\in\mathbb Z[a,n]\) of total degree at most two, such that (3.1) is solvable exactly when \(a\in K\).

For completeness, split a polynomial equation into equality of its positive-coefficient and negative-coefficient parts. Introduce a nonnegative auxiliary variable for every arithmetic gate. Addition becomes \(v-u-w=0\), multiplication \(v-uw=0\), and constants \(v-c=0\). Conversely every solution of these gate equations correctly evaluates the circuit. This preserves existence of natural-number witnesses.

Set
\[
\widetilde f_j(\theta,n)=\theta^2f_j((1-\theta)/\theta,n),
\qquad \widetilde S_\theta(n)=\sum_j\widetilde f_j(\theta,n)^2.
\]
The first expression extends polynomially through \(\theta=0\), since the total degree of \(f_j\) is at most two. These are integer-coefficient polynomials; \(\widetilde S\) has degree at most four in both the controller variables and the parameter. For \(\theta_a=1/(a+1)\),
\[
\widetilde S_{\theta_a}(n)=\theta_a^4\sum_j f_j(a,n)^2. \tag{3.2}
\]

### 3.2 A positive bounded-rate envelope

Expand only in the controller variables, not in the parameter:
\[
2\widetilde S_\theta(n)-\theta^4
=\sum_{|\beta|\le4}q_\beta(\theta)(n)_\beta.
\]
The coefficients \(q_\beta\) lie in \(\mathbb Z[\theta]\). This follows, for example, from the integer Stirling-number conversion between ordinary powers and falling factorials.

If \(\|q\|_1\) is the sum of absolute values of a polynomial's coefficients, define
\[
b_\beta=2+\|q_\beta\|_1,
\qquad h_\beta(\theta)=b_\beta+q_\beta(\theta).
\]
For \(0\le\theta\le1\),
\[
2\le h_\beta(\theta)\le2+2\|q_\beta\|_1.
\]
Put
\[
B(n)=\sum b_\beta(n)_\beta,\qquad
\overline B(x)=\sum b_\beta x^\beta,
\qquad H_\theta(n)=\sum h_\beta(\theta)(n)_\beta.
\]
Then
\[
H_\theta(n)=B(n)-\theta^4+2\widetilde S_\theta(n), \tag{3.3}
\]
and \(B,H_\theta\ge2\) on the integer orthant. Every noise coefficient has a fixed positive lower bound even at \(\theta=0\).

### 3.3 Explicit reaction compiler

Use controller species \(X_1,\ldots,X_d,Y\) with independent immigration and death at rate one. Write \(X_\beta=\sum_i\beta_iX_i\). Set \(\eta=\overline B(\mathbf1)=\sum b_\beta\), and include \(\varnothing\to Z\) at rate \(\eta\), together with \(2Z\to3Z\) and \(2Z\to Z\), both at rate one.

For each \(|\beta|\le4\), add the fixed-drift channels
\[
\begin{array}{lll}
X_\beta+2Z &\longrightarrow X_\beta+Z & b_\beta,\\
X_\beta+Y+2Z &\longrightarrow X_\beta+Y+3Z & 2b_\beta,\\
X_\beta+2Y+2Z &\longrightarrow X_\beta+2Y+Z & 2b_\beta.
\end{array} \tag{3.4}
\]
Also add four symmetric-noise channels, each at rate \(h_\beta(\theta)\):
\[
\begin{array}{ll}
X_\beta+2Z\longrightarrow X_\beta+3Z,&
X_\beta+2Z\longrightarrow X_\beta+Z,\\
X_\beta+3Z\longrightarrow X_\beta+4Z,&
X_\beta+3Z\longrightarrow X_\beta+2Z.
\end{array} \tag{3.5}
\]
Parallel channels may be combined by adding their constants. All resulting constants are still strictly positive polynomials, uniformly bounded on the parameter interval. This is a single fixed graph, not a graph chosen according to the sign of an input coefficient.

Every channel is legal and changes one coordinate by one. The largest source and product orders are eight. The immigration reaction vectors span the whole coordinate space, so there is no nonzero linear conservation law.

The controllers are unchanged by all \(Z\)-channels. Thus their stochastic process is exactly the autonomous environment of Lemma 2.

### 3.4 Exact stochastic threshold

At controller counts \((n,y)\), (3.4) gives
\[
\lambda(n,y)=1+2B(n)y,
\qquad \mu(n,y)=1+B(n)+2B(n)(y)_2,
\]
so
\[
D(n,y)=B(n)g(y),\qquad g(y)=1-2(y-1)^2.
\]
The two symmetric orders in (3.5) contribute
\[
H_\theta(n)\big((z)_2+(z)_3\big)
=H_\theta(n)z(z-1)^2
\]
to both birth and death rates. Thus the exact chain is (2.1).

For integer \(y\), \(g(1)=1\), and \(g(y)\le-1\) otherwise. Hence a favorable state can exist only at \(y=1\), where
\[
D(n,1)-H_\theta(n)=\theta^4-2\widetilde S_\theta(n). \tag{3.6}
\]
Lemma 2 proves the complete phase classification
\[
\boxed{\text{finite-mean a.s. explosion}
\iff \exists n\in\mathbb N^d:\ 2\widetilde S_\theta(n)<\theta^4.} \tag{3.7}
\]
In every other case the chain is nonexplosive and positive recurrent.

At \(\theta=\theta_a\), (3.2) and integrality imply that (3.7) holds exactly when every \(f_j(a,n)\) vanishes at some \(n\). A nonzero sum of integer squares is at least one. This establishes the halting equivalence with no approximate zero testing.

## 4. Identical deterministic dynamics and an explicit common Lyapunov polynomial

The elementary Poisson identity
\[
\mathbb E(P)_j=x^j\qquad(P\sim\operatorname{Pois}(x))
\]
explains the factorial-to-ordinary-power interface. In particular,
\[
\mathbb E g(P)=1-2[(y-1)^2+y]
=-\left(2(y-\tfrac12)^2+\tfrac12\right).
\]
The count-level function is positive at one, although its Poisson average is strictly negative at every nonnegative mean.

The symmetric channels cancel identically in the deterministic drift and in the stochastic coordinate drift. The complete deterministic system is
\[
\dot x_i=1-x_i,\qquad \dot y=1-y,\qquad
\dot z=\eta-\Gamma(x,y)z^2, \tag{4.1}
\]
where
\[
\Gamma(x,y)=\overline B(x)\left(2(y-\tfrac12)^2+\tfrac12\right)\ge1.
\]
There is **no** dependence on \(\theta\) in (4.1), even away from an invariant subspace. Moreover \(\Gamma(\mathbf1,1)=\eta\).

Write \(u=(x,y)\), \(m=d+1\). Define
\[
Q(u)=\int_0^1
\frac{[\Gamma(\mathbf1+s(u-\mathbf1))-\eta]^2}{s}\,ds.
\]
The residual vanishes at \(s=0\), so this is a polynomial with rational coefficients, nonnegative for every real \(u\). Since \(\deg\Gamma\le6\), its degree is at most twelve. Along \(\dot u=\mathbf1-u\),
\[
\dot Q=-[\Gamma(u)-\eta]^2. \tag{4.2}
\]
One can verify (4.2) by homogeneous expansion, or by writing the integral as the future integral of the squared residual along the contracting controller flow.

Set
\[
V(u,z)=\|u-\mathbf1\|^2+(z-1)^2+Q(u).
\]
It is coercive, vanishes at \((\mathbf1,1)\), and dominates squared distance. With \(e=z-1\), \(\delta=\eta-\Gamma(u)\), its exact derivative is
\[
\dot V=-(\delta-e)^2-[2\Gamma(u)(z+1)-1]e^2
-2\|u-\mathbf1\|^2
\le-e^2-2\|u-\mathbf1\|^2. \tag{4.3}
\]
The nonnegative orthant is forward invariant. Properness and (4.3) give global existence and boundedness; the derivative is strictly negative away from the equilibrium, giving global asymptotic stability.

There is also a small exact Gram certificate for \(Q\). Write
\[
\Gamma(\mathbf1+s v)-\eta=\sum_{j=1}^6s^j g_j(v).
\]
Then
\[
Q=\sum_{i,j=1}^6\frac{g_i g_j}{i+j}.
\]
The rational matrix \(G_{ij}=1/(i+j)\) is positive definite because it is the Gram matrix of \(s^i\) in \(L^2((0,1),ds/s)\). Its exact LDL diagonal is
\[
\frac12,\ \frac1{36},\ \frac1{600},\ \frac1{9800},\
\frac1{158760},\ \frac1{2561328}.
\]
Thus the common Lyapunov polynomial has a finite rational positive-semidefinite certificate. This is not a claim that a proof assistant checked the entire theorem.

## 5. Consequences and logical boundaries

The map \(a\mapsto\theta_a\mapsto(k_r(\theta_a))_r\) is computable and produces rational constants. A decision procedure for any of the stochastic alternatives in Theorem 1 would decide \(K\). Approximation of the eventual explosion probability within any error below \(1/2\) would also decide \(K\).

No sound recursively enumerable certificate system can certify nonexplosion for every nonexplosive member of this family: such a system would enumerate the complement of \(K\).

The explosive set is the countable union, over integer witnesses \(n\), of the relatively open sets in (3.7). It is not semialgebraic. A semialgebraic subset of the real line has only finitely many interval and point components, so its membership along the decreasing sequence \(1/(a+1)\to0\) is eventually constant. Membership in \(K\) is not eventually constant. At \(\theta=0\), (3.7) is impossible; this parameter is nonexplosive.

The claim concerns eventual lifetime behavior, not a uniform finite deadline. The proof does not provide a computable uniform waiting time over all explosive inputs. A rare witness state may be reached only after an extremely long time. Finite simulations cannot establish either side of the general classification.

---

## 6. Explicit two-species counterexample: infinitely many explosion bands

For a fully listed small example independent of the universal-polynomial input, let \(a\ge1\) be real and put \(\eta(a)=8(a-1)^2+7\). Consider seven reactions:
\[
\begin{array}{lll}
\varnothing\to X& &1,\\
X\to\varnothing&&1,\\
\varnothing\to Z&&\eta(a),\\
2Z\to3Z&&1,\\
X+2Z\to X+3Z&&16a-8,\\
2Z\to Z&&8a^2,\\
2X+2Z\to2X+Z&&8.
\end{array} \tag{6.1}
\]
Every rate constant is positive, and both source and product orders are at most four.

The deterministic equations are
\[
\dot x=1-x,\qquad \dot z=\eta(a)-\Gamma_a(x)z^2,
\]
where
\[
\Gamma_a(x)=8(x-a+\tfrac12)^2+8a-3\ge5,
\qquad \Gamma_a(1)=\eta(a).
\]
The common equilibrium is \((1,1)\), globally asymptotically stable; the initial trajectory from \((1,1)\) is constant. Unlike Theorem 1, this smaller example's full vector field depends on \(a\).

At \(X=n\), the stochastic birth and death rates of \(Z\) are
\[
b_n(z)=\eta(a)+\lambda_a(n)z(z-1),\quad
 d_n(z)=\mu_a(n)z(z-1),
\]
with
\[
\lambda_a(n)=1+(16a-8)n,\quad
\mu_a(n)=8a^2+8n(n-1),\quad
\lambda_a(n)-\mu_a(n)=1-8(n-a)^2. \tag{6.2}
\]

**Lemma 3 (quadratic switching dichotomy).** For an autonomous immigration–death environment, quadratic rates of this form with \(\lambda,\mu\ge1\), \(\eta>0\), explode a.s. with finite mean lifetime if \(\lambda>\mu\) at any environment state. If \(\lambda\le\mu\) everywhere, they are nonexplosive and positive recurrent, including equality cases.

*Positive case.* Freeze a state with \(\lambda>\mu\). The embedded upward probability is at least \(p=\lambda/(\lambda+\mu)>1/2\) at all levels above one. Put \(\rho=\mu/\lambda<1\). The stopped supermartingale \(\rho^{J_k-j}\) shows that, from \(j+1\), the probability of ever hitting \(j\) is at most \(\rho\). At every visit to \(j\), the probability that it is the final visit is at least \(p(1-\rho)=2p-1\). Thus expected visits to each level are at most \(1/(2p-1)\), uniformly over the initial height. Holding-time summation gives the explicit bound
\[
\sup_{z\ge1}\mathbb E_z\tau
\le \frac1{2p-1}\left(\frac1\eta+
\frac1{\lambda+\mu}\sum_{j=2}^\infty\frac1{j(j-1)}\right)
=\frac{\lambda+\mu+\eta}{\eta(\lambda-\mu)}.
\]
The recurrent-exposure proof in Section 2.4 then applies without alteration.

*Nonpositive case.* For \(f(z)=\sqrt z\), concavity gives, for \(z\ge2\),
\[
\mathcal L_Zf\le\eta(\sqrt{z+1}-\sqrt z)
+\lambda z(z-1)[\sqrt{z+1}+\sqrt{z-1}-2\sqrt z].
\]
The second difference is at most \(-1/[4(z+1)^{3/2}]\). Using \(\lambda\ge1\) gives, including \(z=1\),
\[
\mathcal L_Z\sqrt z\le\eta/2+1/18-\sqrt z/18.
\]
Consequently \(F=1+\sum n_i+\sqrt z\) satisfies
\[
\mathcal LF\le m+\eta/2+1/9-F/18.
\]
The same proper-function and finite-set arguments give nonexplosion and positive recurrence. This proves Lemma 3.

Applying it to (6.2) gives the exact result
\[
\boxed{\text{a.s. finite-mean explosion}
\iff\operatorname{dist}(a,\mathbb N)<1/\sqrt8.} \tag{6.3}
\]
Otherwise the chain is nonexplosive and positive recurrent. In particular, the endpoints with equality in (6.3) are nonexplosive.

The explosion region is
\[
\bigcup_{n\ge1}(n-1/\sqrt8,n+1/\sqrt8)\cap[1,\infty).
\]
Its infinitely many disjoint components show directly that explosion regions of polynomially parameterized mass-action systems need not be semialgebraic. No claim is made that this refutes a previously named conjecture.

## 7. Lower-order integer-rate variant

The earlier, separately verified order-six construction remains useful when identical full ODEs are not required.

Given fixed quadratic equations \(f_j(a,n)=0\), put
\[
S_a(n)=\sum_jf_j(a,n)^2,
\qquad D_a(n,y)=1-2S_a(n)-2(y-1)^2.
\]
Expand \(D_a=\sum r_\beta(a)(n,y)_\beta\), \(|\beta|\le4\). For each controller complex \(U_\beta\), use
\[
U_\beta+2Z\to U_\beta+3Z\text{ at rate }r_\beta^2+r_\beta+2,
\]
\[
U_\beta+2Z\to U_\beta+Z\text{ at rate }r_\beta^2+2.
\]
All constants are positive integer-coefficient polynomials, and are positive integers on integer input. Include rate-one immigration and death of the controllers and immigration of \(Z\) at
\[
\eta(a)=1+2\mathbb E S_a(P),\qquad P_i\sim\operatorname{Pois}(1).
\]
The quadratic switching threshold is precisely \(D_a>0\), equivalent to an integer witness and \(y=1\). The deterministic damping is
\[
\Gamma_a(x,y)=2\mathbb E S_a(P_x)+2(y-\tfrac12)^2+\tfrac12\ge\tfrac12.
\]
Its all-one equilibrium is globally asymptotically stable. Reactant order is at most six, product order at most seven. The rate polynomials have degree at most eight. The graph is fixed, but the full deterministic vector field depends on \(a\).

The sparse signed-coefficient version checked by `verify_crn_compilers.py` uses only nonzero coefficients, choosing birth or death according to sign, and adds a symmetric rate-one quadratic baseline. The fixed-graph positive-polynomial version is checked by `verify_extensions.py`.

The original order-eight conserved-catalyst experiment is retained only as verification data in the bundle. It cancels drift on the sector \(C=2\), not on the full state space; it is not needed for Theorem 1 and must not be confused with it.

## 8. Verification record and adversarial checks

The proof above does not assume that the deterministic rate polynomial equals the count-level drift. Every use of the falling-factorial interface is explicit. The main compiler has no hidden conserved input coordinate. The parameter occurs only in symmetric reaction constants. All controllers actually move.

The positive-mode argument supplies a bound uniform over the current \(Z\)-height before invoking repeated environment visits. Equality cases in both switching lemmas are settled by proper Lyapunov functions. Auxiliary birth–death weights are not mistaken for an invariant distribution of an explosive minimal chain.

Three executable exact-algebra checks accompany this record:

- `verify_crn_compilers.py`: 44 constructed network instances, 10,300 exact state checks, and 51 polynomial Poisson/Charlier product identities; all passed. It uses Stirling-number conversion and independently checks Poisson transforms with Touchard polynomials.
- `verify_extensions.py`: a separate forward-difference implementation checks two fixed-graph polynomial-rate examples and the seven-reaction phase example; 73 rational-parameter band checks passed.
- `verify_identical_ode.py`: reconstructs two identical-full-ODE examples from aggregated legal reaction channels; verifies parameter cancellation, birth/death formulas, positivity bounds, the harmonic generator identity, and 140 exact witness-threshold checks. It verifies the cubic auxiliary-weight asymptotic coefficient, a nontrivial polynomial Lyapunov identity, and the rational 6-by-6 LDL certificate. All passed.

The universal DPRM quadratic system was **not instantiated as a gigantic explicit reaction listing**. Theorem 1 is an effective existence theorem based on the established DPRM input and the fully specified compiler. The test systems are smaller examples, not a finite test of universality. No stochastic simulation is used as proof.

These are two algebraic representation methods implemented within one investigation, not independent external mathematical audits. Neither Lean nor another proof assistant was run.

## 9. Pinned research sources, mathematical reading scope, and prior art

### Repository pins

- Astra: `99408438b214266caf5826f4f5f227e62049b1d9`.
- OpenAI/math: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

Astra retrieval began with `00_START_HERE.txt`. Selected navigation and status records were read rather than loading the full archive. The actual squared-Pfaffian/determinant proof at `web/pages/d-fab535e71046fcca.html` was inspected after its N190 review card and status JSON. Its coefficient-orthogonality argument preserves physical equality sewing; its accompanying exponential-variance examples prevent inferring an efficient sampler from positivity alone. The N209 catalytic-explosion review card was an additional pointer, not an independently certified source theorem. None of these claims is a dependency of Theorem 1.

For OpenAI/math, the actual source at `preprints/The-Quasi-Riemann-Hypothesis-September-30-2026/build/paper.tex`, lines 1–560, was read selectively, including the complete conditional Mellin-continuation criterion and proof. That criterion constructs holomorphic continuation from two assumed power-saving comparisons with uniform exponent margins. Those power-saving inputs and the paper's claimed global zero-free theorem were **not** independently verified. `lean/docs/003.md` was inspected for its stated formalization scope; the Lean dependency closure was not audited or built. A scope note is not a kernel verification.

### Primary literature and attribution

[1] Yu. V. Matiyasevich, *Enumerable sets are Diophantine*, Doklady Akademii Nauk SSSR 191 (1970), 279–282; also the author's account *Matiyasevich theorem*, Scholarpedia (2008). DPRM is the sole external computability theorem used here. The quadratic-circuit conversion is supplied in Section 3.1. The original theorem was not reproved in this investigation.

[2] D. F. Anderson, D. Cappelletti, M. Koyama, T. G. Kurtz, *Non-explosivity of stochastically modeled reaction networks that are complex balanced*, arXiv:1708.09356v2 (2018). Section 4 states the rate convention used here. Example 5 already gives a globally attracting deterministic model whose stochastic version explodes almost surely, using visits of an autonomous recurrent subsystem to a favorable state. Its actual reaction diagram and argument were inspected. Thus neither the bare deterministic/stochastic mismatch nor recurrent exposure is claimed as a new general phenomenon.

[3] M. Cook, D. Soloveichik, E. Winfree, J. Bruck, *Programmability of Chemical Reaction Networks* (2009), Theorem 3. Its actual theorem and register-machine argument establish undecidability of bounded-error approximation of an eventual species-production probability. General undecidability of stochastic chemical behavior is therefore not a new claim of this record.

[4] G. Zavattaro and L. Cardelli, *Termination Problems in Chemical Kinetics*, CONCUR 2008, 477–491. Its termination framework and theorem statements were inspected as neighboring prior art; no equivalence with finite-time explosion is asserted.

[5] R. Cummings, D. Doty, D. Soloveichik, *Probability 1 computation with chemical reaction networks*, Natural Computing (2016). Its probability-one computation conventions were checked to avoid conflating eventual/lifetime behavior with exact finite halting or stable output.

The established ingredients include factorial moments, classical birth–death occupation calculations, Foster arguments, arithmetic-circuit encodings, and DPRM. The specific combined claims to assess for priority are: identical **full** deterministic and infinitesimal drift fields; a common explicit strict polynomial Lyapunov certificate; a fixed graph with uniformly positive bounded polynomial rate constants; and an exact finite-mean-explosion/positive-recurrence dichotomy encoding \(K\). The literature check did not establish priority for that conjunction, and absence from a bounded search is not a novelty proof.

## 10. Final scientific conclusion

A complete construction and proof were obtained for the stated undecidability theorem, together with an explicit seven-reaction, two-species nonsemialgebraic phase example. The main mechanism is an exact harmonic-number response to symmetric cubic noise, combined with factorial-moment separation and an arithmetic coefficient envelope. The decisive probabilistic threshold is proved, not left as a proposed sufficient condition.

The historical 10/10 objective is **not established** by this record. Historical novelty, specialist validation, and proof-assistant certification remain unestablished. No claimed 2026 source breakthrough was treated as a certified mathematical premise.
