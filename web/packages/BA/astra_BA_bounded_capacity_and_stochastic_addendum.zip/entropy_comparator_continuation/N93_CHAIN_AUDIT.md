# Bounded Holevo broadcasting reconstruction chain

Work in progress 9 October 2026 UTC. This file separates independently checked links from remaining imported obligations. It does not claim the complete implication before the final bridge audit returns.

## Exact target and source pin

For a finite-dimensional quantum experiment E (an arbitrary family of density matrices), define

C(E)=sup_(finite priors p) [S(Σ_xp_xρ_x)−Σ_xp_xS(ρ_x)],
b₂(E)=inf_(two-output CPTP B) sup_(ρ∈E) max_(a=1,2) (1/2)||B_a(ρ)−ρ||₁,
e(E)=inf_(EB Λ) sup_(ρ∈E) (1/2)||Λ(ρ)−ρ||₁.

Dimensions and label cardinalities may grow. N93 asks whether, for EVERY sequence E_n,

sup_n C(E_n)<∞ and b₂(E_n)→0 imply e(E_n)→0.

This is a uniform sup-label statement with a single EB channel for each entire experiment. Bounding one fixed prior's average Holevo quantity is not the same assumption. Neither existence of one per-label measurement nor averaged reconstruction would prove it.

Pin: harjassand/astra-research-knowledge commit 99a9d763558c3c7d329d3bdeb64905187cb5429c. Read 00_START_HERE, quantum topic router, N93 current review card and status JSON, and complete decisive proof sources d-b4ddaa96b233287d, d-c851b6e4ba719edf, d-48ed31af9b1d38fd. Historical source verdicts are preserved; they were written before this comparator proof.

## Link 1 capacity to a fixed two-sided sandwich

The source reduction is being separately independently checked. Its precise interface is:

For fixed capacity bound C and arbitrary approximation tolerance δ>0, a common relative-entropy center σ can be chosen with D(ρ||σ)≤C for EVERY ρ∈E. It is a finite convex combination of promised states, so every marginal approximately preserving E also approximately preserves σ. Exact support compression is implemented by the CPTP map X↦PXP+Tr[(I−P)X]σ, not by an unnormalized projection.

A unique fidelity-plus-quadratic optimizer G(ρ,σ), constrained by 0≤G≤Mσ and TrG≤1, supplies compatible smoothing. Normalize it and include exact σ. Uniform halftrace preservation error g(C,δ,b) tends to zero with b for fixed C,δ, with constants independent of dimension and number of labels. One can use η=δ²/8, M=(1−η)⁻¹exp[(C+ln2)/η], and λ=η/M.

Dilution with a=θ/(2M−1), any fixed θ∈(0,1), produces a family F containing σ and satisfying

(1−θ)σ≤ρ≤(1+θ)σ,
b₂(F)≤g(C,δ,b₂(E)),
e(E)≤2δ+[(2−a)/a]e(F).

The same channel serves all labels. Therefore it suffices to prove the fixed θ=1/2 sandwich implication, and take n→∞ at fixed δ before δ→0. This order of limits is load-bearing; exponential dependence on δ does not defeat the qualitative statement.

## Link 2 broadcasting a pair controls reference noncommutativity

Remaining specific source import under independent audit:

If {σ,ρ} has approximate two-output broadcasting error b, then

Δ(σ,ρ)=||sqrt(σ)sqrt(ρ)||₁−Tr[sqrt(σ)sqrt(ρ)]≤v(b), with v(b)→0 dimension-independently.

The source reports v(b)=O(sqrt[b log(1/b)]), imported from N46. Only the existence of a dimension-free vanishing modulus is needed for the present qualitative theorem. Pairwise bounds are used here to centralize the common reference; they do NOT by themselves assert simultaneous EB reconstruction or approximate joint measurement.

## Link 3 finite flagged centralization independently reconstructed

For ρ≤C_sσ, put S=sqrtσ, M_s=sqrt(C_s), and X_ρ=S⁻¹(SρS)^(1/2)S⁻¹. Then X_ρ≥0, X_ρσX_ρ=ρ, and X_ρ≤M_sI. If SQ=WP is the polar decomposition with Q=sqrtρ, then X_ρS=QW*, P≥ρ/M_s, and K=2I−W−W*≥0. Since Tr(PK)=2Δ,

||X_ρS−Q||₂²=Tr(ρK)≤2M_sΔ,
||[X_ρ,S]||₂≤2sqrt(2M_sΔ).

Thus Ξ=sup_ρ||[X_ρ,S]||₂→0 from the pair bridge, uniformly over the family.

Randomly shift logarithmic spectral bins of S with width t, pinch onto bins by D_u, and flatten each bin eigenvalue to its lower endpoint followed by normalization, obtaining S'_u. The separation probability of a pair of eigenvalues satisfies p_ac≤3|s_a−s_c|/[t(s_a+s_c)]. Summing and using Cauchy–Schwarz yields

E_u||(X_ρ−D_uX_ρ)S||₂²≤3M_sΞ/t.

The block-diagonal surrogate YσY, Y=D_uX_ρ, approximates ρ by at most 2||(X_ρ−Y)S||₂ in trace norm. Pinching contraction yields

E_u||D_uρ−ρ||₁≤4sqrt(3M_sΞ/t).

Define A_u=e^(−t)S'_uS⁻¹. It is a positive contraction, with e^(−2t)I≤A_u≤I. The exact CPTP correction

C_u(Z)=A_uD_u(Z)A_u+Tr[(I−A_u²)Z]σ'_u

satisfies C_u(σ)=σ'_u, preserves the sandwich order, and ||C_uρ−D_uρ||₁≤8t.

There are finitely many distinct C_u: bin assignments change only at the finitely many residues log(s_a) modulo t, and the common exp(u) cancels upon normalization. Flag the resulting at most d+1 intervals with their exact probability weights. This defines a finite linear CPTP encoder Enc and trace-preserving decoder Dec such that

sup_ρ||Dec Encρ−ρ||₁≤δ_c=4sqrt(3M_sΞ/t)+8t.

All encoded states lie in a finite direct-sum algebra A and the encoded reference σ_F is CENTRAL and faithful in A. No per-label encoder, common-shift selection, union bound, or outcome-count bound has been used.

For a broadcaster B set B_F=(Enc⊗Enc)B Dec. Its error on encoded states is ≤b+δ_c/2. Conversely e(F)≤e(Enc F)+δ_c/2. Input/output pinching onto A gives genuine CP maps A→A⊗A without changing promised states or errors. Choosing t→0 and Ξ/t→0, for example t=Ξ^(1/3) away from Ξ=0, makes δ_c→0. At Ξ=0 one can let t→0 or use exact spectral blocks.

## Link 4 Petz correction independently reconstructed

Symmetrize the encoded broadcaster so its marginals equal T. Write ν=Tσ_F and define the TP Petz map on its support, with replacement by σ_F off the support:

R(Y)=σ_F^(1/2) T*(ν^(−1/2) PYP ν^(−1/2)) σ_F^(1/2)+Tr[(I−P)Y]σ_F.

This is CPTP and Rν=σ_F. Postprocess both broadcaster outputs with R, obtaining a genuine self-compatible marginal S=RT. In the sandwiched Rényi-2 Hilbert norm its conjugate is V*V, a positive selfadjoint contraction by Rényi-2 data processing. The corresponding likelihood map Φ=S* is UCP, preserves τ(a)=Tr(σ_Fa), and is positive selfadjoint in L²(A,τ), because σ_F is central. It has an actual joint UCP map with both marginals Φ.

For θ-sandwich states with d_ρ=||Tρ−ρ||₁ and d_σ=||Tσ_F−σ_F||₁, direct quadratic continuity and contraction give

||Sρ−ρ||₁≤sqrt[2θ(d_ρ+d_σ)+6θ²sqrt(d_σ)].

All norm comparisons are reference-weighted and dimension-free. No KMS/GNS equivalence is used before centralization. For θ=1/2 and broadcast error b' this is r≤sqrt[4b'+(3/2)sqrt(2b')], tending to zero.

## Link 5 weighted-tracial common reconstruction proved

The new proof in WEIGHTED_TRACE_EXTENSION.md constructs one physical EB channel with

sup_ρ (1/2)||Ψρ−ρ||₁≤sqrt(θr).

This applies to precisely the output of Link 4, including arbitrary central weights and block-changing channels. It closes equation (25) of the source algebra report; it is stronger than a statement on full matrices with normalized counting trace only.

## Consequence if the remaining bridge checks

For fixed sandwich data, Links 2–5 imply e(F)→0 whenever b₂(F)→0, with a uniform dimension/cardinality-independent modulus. Link 1 then gives the full bounded-capacity implication by the fixed-δ limit described above. The proof would establish robust experiment-wise classical reconstruction; it would not imply a dimension-free diamond-norm approximation on unrestricted channel inputs, efficient reconstruction, or finite exact EB powers.

The independent pair-bridge audit and final external-source checks must be incorporated before this conditional conclusion is promoted. Historical priority and broad significance are separate questions even after mathematical reconstruction succeeds.

## Final status update 9 October 2026 UTC

The initially pending pair bridge was independently reconstructed from its finite adaptive-Helstrom proof and passes; see N46_PAIR_BROADCAST_GAP_AUDIT.md. The capacity-smoothing audit also passes; see CAPACITY_SMOOTHING_INDEPENDENT_AUDIT.md. The complete stitched theorem is now BOUNDED_CAPACITY_BROADCASTING_THEOREM.md, and a separate end-to-end adversarial audit, END_TO_END_ADVERSARIAL_AUDIT.md, found no gap in its composition. The full finite-dimensional bounded-capacity implication is therefore established at this internal analytic review level. Historical priority, external peer review, and broad foundational significance remain separate unestablished questions. Earlier conditional language above records the order of checking rather than a remaining mathematical premise.
