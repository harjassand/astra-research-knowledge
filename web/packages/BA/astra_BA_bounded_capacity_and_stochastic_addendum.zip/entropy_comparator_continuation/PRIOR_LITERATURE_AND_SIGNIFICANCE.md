# Prior literature and significance of the bounded capacity theorem

9 October 2026 UTC. Targeted primary-source screening, distinct from mathematical correctness. The fact that Astra called N93 open does not establish that the same result is absent from the public literature. No historical-priority or historic-scale claim is made.

## Exact claim being compared

For every capacity cap C, experiments of arbitrary growing Hilbert-space dimension and arbitrary label cardinality obey a common modulus e(E)≤f_C(b₂(E))→0, where C(E) is the supremum of the Holevo quantity over every finite prior, b₂ is uniform two-marginal broadcasting error, and e is uniform error of one EB reconstruction channel. The comparison must preserve all of these quantifiers. A fixed finite family, a fixed prior, a measured norm, or a dimension-dependent estimate is not the same result.

## Exact broadcasting and statistical experiments

Barnum, Caves, Fuchs, Jozsa and Schumacher, “Noncommuting mixed states cannot be broadcast,” establishes the exact no-broadcasting principle. It provides the conceptual baseline; the new argument is not a new exact impossibility principle. https://arxiv.org/abs/quant-ph/9511010

Kuramochi, “Accessible information without disturbing partially known quantum states on a von Neumann algebra,” Theorem 1 and Corollary 1, is an especially close conceptual predecessor. Corollary 1 characterizes broadcastable statistical experiments by normal CP equivalence to a classical experiment. Its setting is substantially more general algebraically than finite matrices. The conclusion is exact nondisturbance/broadcastability, however; the inspected theorem does not provide the dimension-uniform approximate modulus for varying experiments proved here. https://arxiv.org/pdf/1710.01599

Thus the present theorem is naturally positioned as a robust, bounded-information version of experiment-wise classical equivalence. The exact structural theorem is established prior art.

## Approximate two-state broadcasting

Lemm and Wilde, “Information-theoretic limitations on approximate quantum cloning and broadcasting,” Theorems 4 and 5 and their following discussion, derives entropic restrictions and recovery improvements for pairs, including a condition where one state is cloned while the other is broadcast. The paper also studies general pair broadcasting and cloning/partial-trace duality. The inspected results do not yield one common reconstruction uniformly over an unrestricted growing family from a capacity bound. They are important prior quantitative no-broadcasting literature. https://arxiv.org/pdf/1608.07569

The pair-extraction lemma used in the present proof is not presented as a novel mechanism. Its information-chain and posterior-preparation ideas are closely related to Qi–Ranard and earlier adaptive de Finetti methods. The additional lifting from pairwise reference control to collective reconstruction requires finite flagged centralization, compatible smoothing, and the common comparator. Pairwise reconstruction alone is insufficient.

## Collective emergent classicality and the relevant norm gap

Qi and Ranard, “Emergent classicality in general multipartite states and channels,” Theorem 1 gives a common POVM for many reduced channels, with excluded-region size depending on the input dimension. Theorem 2 and Proposition 1 have entropy-controlled statements in a measured/one-way LOCC norm. Their equations (13)–(14) and (22)–(23) explicitly charge dimension factors in conversion to trace/diamond norms. The finite-entropy and bounded-energy discussion at the end is important; it must not be summarized as simply “all prior results require dimension.” The inspected statements do not by themselves turn bounded experimental Holevo capacity into uniform unmeasured trace reconstruction of every label. https://arxiv.org/pdf/2001.01507

Li and Smith’s fully adaptive measurement de Finetti work is a further methodological predecessor, especially for the pair bridge. https://arxiv.org/abs/1408.6829

This is the substantive distinction: the new theorem controls the actual trace norm uniformly across a possibly growing state family using one reconstruction channel, under a capacity bound, rather than only correlations after a selected receiver measurement or an input-dimension-dependent channel estimate.

## Broadcasting Holevo information and fidelity optimization

Janzing and Steudel’s “A Quantum Broadcasting Problem in Classical Low Power Signal Processing” studies preservation/loss of Holevo information by broadcasting and consequences for communication and physical processes. Its stated task concerns information broadcast, not the uniform EB deficiency of an arbitrary bounded-capacity experiment. It is a necessary contextual citation, not an identified subsumption. https://arxiv.org/abs/quant-ph/0609162

Xie, Fang, Wang and Duan, “Approximate broadcasting of quantum correlations,” formulates broadcasting fidelities as SDPs and relates bilocal broadcasting to discord. These quantitative optimization/operational characterizations differ from the present capacity-uniform family theorem. https://arxiv.org/pdf/1705.06071

## Assessment

The checked result has more substantive operational content than the earlier induced-HS power approximation: it concerns every promised state in unrestricted trace distance, permits increasing dimension and label cardinality, and constructs one common classical experiment from approximate two-receiver reproducibility. It closes the actual N93 gate at the internal analytic level.

The primary sources inspected did not provide the same capacity-uniform theorem. This is evidence for a specialist novelty candidate, not proof of priority. A specialist literature review should further examine approximate sufficiency/deficiency of quantum statistical experiments, quantitative Koashi–Imoto theory, and energy-constrained emergent classicality. Neither a famous named conjecture nor a longstanding publicly documented open problem with precisely these hypotheses has been identified in this screening. Calling the result historic would therefore exceed the available evidence.

The cleanest mathematical advance is the common measurement comparator and its resulting collective robust no-broadcasting theorem. The many-receiver corollary is useful interpretation, but follows immediately once EB reconstruction exists and should not be counted as a separate breakthrough.

## Strongest concrete next target

Determine the quantitative capacity cost of retaining a genuinely quantum experiment under near-perfect broadcasting. The stitched proof has smoothing cost exp[O((C+1)/δ²)] followed by fixed-power losses. Balancing δ against broadcast error should give a universal logarithmic modulus and extend the result to growing capacity C=o(log(1/b₂)), a statement not implied by merely fixing C separately. That simplification is under a separate exact-constant audit and is not a premise of the theorem here.

Beyond that upper bound, the high-value research target is a matching or qualitatively stronger tradeoff between capacity C, irreducible EB error e, and broadcast error b₂, tested against actual legal growing-dimension broadcaster families. A bound on one chosen comparator is not a lower bound against the entire EB set. This asks what information growth is necessary to sustain nonclassicality while copying becomes almost accurate, rather than just improving C4 numerically or restating unlimited receiver preparation.
