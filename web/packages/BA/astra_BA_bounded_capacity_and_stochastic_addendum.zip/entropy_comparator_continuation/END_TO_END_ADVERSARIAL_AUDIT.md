# End-to-end adversarial audit of bounded-capacity broadcasting reconstruction

Date: 9 October 2026 UTC.

## Verdict and exact scope

The stitched theorem in `BOUNDED_CAPACITY_BROADCASTING_THEOREM.md` passes this independent end-to-end analytic audit. I found no missing mathematical implication or counterexample under its precise assumptions. The complete composition, not merely its separately named lemmas, gives

C(E_n) uniformly bounded and b₂(E_n)→0 ⇒ e(E_n)→0,

where capacity takes the supremum over all finite priors, broadcasting error is uniform over the entire family and both receivers, and e uses one ordinary full-domain EB channel per experiment. Each ambient Hilbert space is finite dimensional; dimensions and family cardinalities may grow without bound. A family in a given finite dimension may itself be infinite.

This is an internal analytic audit, not external peer review, proof-assistant verification, or historical-priority clearance. No numerical evidence is used. The conclusion does not include infinite-dimensional input spaces, a bounded output alphabet, efficient implementation, diamond-norm approximation, or any unrestricted channel reconstruction theorem.

## Material independently read

- The complete stitched theorem, 194 lines at audit time.
- The complete pinned smoothing audit `sources/d-b4ddaa96b233287d.txt`, and its independent contemporary reconstruction `CAPACITY_SMOOTHING_INDEPENDENT_AUDIT.md`.
- The complete centralization/Petz source `sources/d-c851b6e4ba719edf.txt`, including all of its Sections 1–10 and its deliberately open historical remainder.
- The complete pair-extraction audit `N46_PAIR_BROADCAST_GAP_AUDIT.md`.
- The C4 source and independent covariance reconstruction in `../c4_audit/`, and the weighted extension and cross-check.
- Primary quantum-substate theorem: https://arxiv.org/pdf/1103.6067, Theorem 1 and fidelity convention, independently reopened. The squared-fidelity convention and factor (1−η)⁻¹2^(D_obs/η) match the smoother's constants; D_obs_bits≤D_rel_bits+1 yields its nats conversion.
- Primary Rényi-DPI source https://arxiv.org/pdf/1306.5920 independently reopened. Alpha two is within the DPI range required here.

The older sources' statements that the broad gate remains open are historical statements about the absence of the final common comparator there. They are neither hypotheses nor counterarguments to the new stitched proof.

## 1. The center, supports, and nonlinear smoother

The capacity center really is common to the entire family. Closing the family preserves all three quantities in fixed finite dimension. Compactness of the entropy graph convex hull supplies a finite maximizing prior. If c=C(E) and σ is its mean, mixing any ρ at mass s gives

χ_s=(1−s)c+(1−s)D(σ||σ_s)+sD(ρ||σ_s)≤c.

Consequently D(ρ||σ_s)≤c, and lower semicontinuity gives D(ρ||σ)≤c, including support containment. This argument does not differentiate entropy at a singular boundary. Adding σ preserves a given broadcaster's error because σ is a finite convex combination of promised states; the same observation applies to a candidate EB map's error.

Support restriction is implemented by a CPTP retraction R₀(X)=PXP+Tr[(I−P)X]σ, not an unnormalized projection. It fixes all promised states. There is no eigenvalue-dependent constant.

The smoother G is nonlinear and need not be physically implementable. This is harmless: it constructs a new experiment, and the SAME original broadcaster approximately fixes its members by the optimizer stability estimate. I rechecked the strong-convexity gap, two-way objective-value comparison, normalization factor, and exact inclusion G(σ,σ)=σ. The objective transport only needs one-sided inequalities in each direction; it does not assume symmetric Q-distance after clipping. The bounded-likelihood transport costs depend on M and λ, not dimension or reference spectrum.

Crucially the smoother's preservation error tends to zero at fixed smoothing accuracy. There is no additive fixed smoothing error in that preservation estimate. An ordinary approximate state truncation would not establish this property and could break the whole argument; the present canonical optimizer avoids that failure.

Dilution is also a change of experiment. Its inverse is used solely as a signed affine identity on errors. No inverse quantum channel is asserted. Inclusion of σ is essential for that identity and is satisfied exactly.

## 2. The binary bridge does not hide label averaging

The pair argument uses a uniform binary design prior. At each prefix record h, for either x,

P(h|x)T(τ_x^h,q₀τ₀^h+q₁τ₁^h)=2p_hq₀q₁T(τ₀^h,τ₁^h).

Thus the same upper bound applies separately to each label. It is not an average-to-supremum conversion with an omitted probability factor. Prefix measurements act on other registers, so their nonselective action leaves the selected register's marginal unchanged even for correlated or entangled tree outputs. The preparable posterior states and selected index are fixed from the known pair before the unknown label is supplied.

Pairwise EB maps are NOT combined into a global EB map. They are used only to establish the scalar bound Δ(σ,ρ)≤v(b) for each pair. The resulting bound is uniform because its right side is label independent. The common reference is in the family, and the original common broadcaster broadcasts both members of every such pair.

The affinity step has the correct direction: measurement fidelity is at least input root fidelity, while joint concavity and homogeneity of affinity put output affinity above measurement fidelity for a measure-and-prepare channel. Square-root continuity then bounds the input fidelity-affinity gap.

## 3. Centralization uses one linear finite encoder

The polar calculation is valid: ρ≤M_s²σ implies P=(sqrtρ σ sqrtρ)^(1/2)≥ρ/M_s, and K=2I−W−W* is positive. This controls ||[X_ρ,sqrtσ]||₂ without a smallest-eigenvalue constant.

Although X_ρ depends nonlinearly on the state, it is used only to analyze pinching. The implemented channel C_u depends on σ and the common shift alone. The probability average is retained as a flag, rather than choosing a different favorable shift per label or trying a union bound over labels.

For a fixed finite reference spectrum, bin assignments have finitely many breakpoints. Normalized flattened eigenvalues are constant between breakpoints because their shared exponential factor cancels. The encoder is therefore genuinely finite. Its flag probabilities may be arbitrarily small; the proof never divides an error bound by those probabilities. The encoded reference is faithful and scalar on every matrix block.

The broadcaster transfer is physical and has the claimed orientation:

B_F=(Enc⊗Enc) B Dec.

On input Encρ, the decoder incurs at most c in full trace norm, then original broadcasting incurs at most 2b, then encoder contraction preserves the estimate. Thus encoded halftrace error is at most b+c/2. Conversely DecΛEnc is EB if Λ is EB, and incurs at most an additional c/2 on the original sandwich family.

At zero gap the exact spectral-block pinching of σ fixes every ρ because [X_ρ,sqrtσ]=0 implies [ρ,σ]=0. Hence the endpoint does not require t=0 in a formula containing 1/t.

## 4. Petz and weighted physical-channel orientation

After centralization, the algebra is represented canonically as an actual block-diagonal algebra, with ordinary physical trace. The output ν=Tσ_F need not be central or faithful, but lies in that algebra. All its generalized inverses stay in the algebra. Faithfulness of σ_F ensures that the whole range of T lies in suppν, and the specified replacement term makes R trace preserving on the whole algebra.

The positive contraction identity is in the sandwiched-Q Hilbert coordinates. Its general-Hermitian extension follows by adding a large multiple of σ before applying positive-input Rényi-DPI and canceling the equal trace cross terms. Thus it really gives a positive selfadjoint operator, not merely positivity on the cone of states.

Applying R to both outputs preserves self-compatibility with common marginal S=RT. Only AFTER centralization does the likelihood adjoint Φ=S* become selfadjoint for the tracial inner product τ(a)=Tr(σ_Fa). No nontracial KMS/GNS norm equivalence is assumed.

For the common comparator, the preparations σ_FE_y/τ(E_y) are positive and normalized because σ_F is central. The measurement effects sum to the ambient identity. Hence Ψ_phys is an ordinary EB channel, not a formal weighted-adjoint map incorrectly presumed positive. Its action satisfies Ψ_phys(σ_Fa)=σ_FΨ(a), which identifies weighted L¹ errors with ordinary trace errors exactly. Block-changing channels cause no difficulty.

## 5. Compactness is dimension dependent only where that is allowed

The covariance recursion constructs a physical finite POVM at every depth on the SAME fixed input algebra. Its starting noise may depend on the number of selected modes, and its contraction rate may deteriorate when eigenvalues approach the threshold. Both penalties disappear by taking the measurement-depth limit at that fixed algebra and channel.

The regression inequality is tested against an arbitrary Hermitian observable, not merely a selected slow-mode span. Consequently it controls all cross terms, and one limit comparator dominates the full spectral quadratic form. This is the place where the argument earns its common-channel conclusion.

For arbitrary faithful weighted trace, {h≥0:τ(h)=1} is compact at each fixed algebra. Its norm bound can depend badly on the smallest block weight. This does not contaminate the final bound: compactness is used only to obtain an exact limit channel at that fixed algebra. The barycenter and quadratic moment are retained, and finite-dimensional convex geometry restores finite support. There is no assertion of a common compact set across n, a uniform depth, or a uniform number of outcomes.

The final comparator inequality I−Ψ≤4(I−Φ) contains no dimension, block-weight, label, or threshold-gap constants. For all bounded likelihoods at once it yields halftrace error at most sqrt(θr). This is stronger than a collection of individually good measurements, and requires no exchange of infimum and label supremum.

## 6. Explicit composition and order of limits

For θ=1/2 set M_s=sqrt(3/2), x(b)=2sqrt(2M_s v(b)), t=min(1,x(b)^(1/3)), and

c(b)=4sqrt(3M_s x(b)/t)+8t,
w(b)=b+c(b)/2,
r(w)=sqrt(4w+(3/2)sqrt(2w)),
h(b)=min(1,c(b)/2+sqrt(r(w(b))/2)).

Set c(0)=h(0)=0 by exact spectral blocks or the limiting inequality. These are precisely the stitched constants. They tend to zero as b tends to zero. They may be used for all nonnegative input error upper bounds; if one instead defines them only on [0,1], replace a larger upper bound by its minimum with one. This is only a domain convention, not a mathematical obstruction.

For fixed C and smoothing tolerance δ, the stated g(C,δ,b) tends to zero with b. With a=θ/(2M−1),

e(E)≤2δ+((2−a)/a)h(g(C,δ,b)).

The coefficient may grow extremely rapidly as δ decreases, but is fixed before b tends to zero. Given target accuracy, choose δ first and then b sufficiently small. Taking an infimum over δ gives a common modulus f_C. Nothing requires a uniform smoothing parameter tending to zero at a predetermined rate with n.

The actual full-domain EB map on the original system is

Λ_original = inclusion ∘ Dec ∘ Ψ_phys ∘ Enc ∘ R₀.

The nonlinear smoother and affine undilution do not occur in this channel. Their role is solely to prove its error bound on the original states from its error bound on the modified experiment. This cleanly resolves a possible apparent physical-map gap.

## 7. Adversarial failure modes ruled out, and remaining limitations

The following proposed counterexample mechanisms do not attack a premise of this proof:

- A fixed-prior low Holevo value with many rare labels does not bound the required capacity.
- Vanishing pairwise commutators or fidelity-affinity gaps alone would not imply common reconstruction; the proof retains a common compatible channel and invokes the full-space comparator.
- Small weighted blocks and arbitrarily ill-conditioned σ do not enter its quantitative constants.
- Slowly mixing classical modes defeat the ultimate fixed-point projection, but the comparator retains those modes instead of taking that projection.
- A growing number of selected modes affects finite recursion depth, which is not claimed to be uniform or efficient.
- Per-label smoothing is not a per-label reconstruction channel; the same original broadcaster and final EB map are used.

No unresolved mathematical obligation remains within the audited finite-dimensional statement. Further independent human review and a literature/priority investigation would be separate obligations for a research announcement. Neither the audit nor the theorem supports a historic-scale or novelty label by itself.
