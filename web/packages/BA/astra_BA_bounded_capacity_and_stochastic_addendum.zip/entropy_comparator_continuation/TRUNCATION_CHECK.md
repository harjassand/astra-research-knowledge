# Entropy-truncation reconstruction audit

## Verdict and scope

The proposed argument is valid, including for non-Hilbert–Schmidt-selfadjoint bistochastic channels. No reversibility, normality, or commutation between the channel and spectral truncation is required.

Let tau = Tr/d and let Phi be bistochastic. Assume a canonical bistochastic entanglement-breaking channel Psi satisfies the Hilbert–Schmidt superoperator comparison

0 <= I-Psi <= C [I-(Phi+Phi*)/2].

Canonicality also gives 0 <= Psi <= I in HS superoperator order. For binary self-compatibility the audited comparator supplies C = 8 in general, and C = 4 when Phi is HS-selfadjoint.

For a density operator rho put X = d rho, epsilon_rho = ||rho-Phi(rho)||_1, and g_K(X) = min(X,K I). For every K > e,

||rho-Psi(rho)||_1
 <= 2 D(rho || I/d)/(log K-1) + sqrt(C K epsilon_rho).

For an ensemble with mean I/d, Holevo information chi <= H, and average residual epsilon, the same Psi therefore satisfies

sum_x p_x ||rho_x-Psi(rho_x)||_1
 <= 2H/(log K-1) + sqrt(C K epsilon).

All logarithms in this note are natural. Norms with a tau subscript are normalized Schatten norms. The ordinary trace norm is used for density matrices.

## 1. Scalar truncation inequality: exact orientation

For t >= 0 define g(t) = min(t,K) and

F(t) = t^2/2 for t <= K;
F(t) = Kt-K^2/2 for t >= K.

Then F' = g and, for every a,b >= 0,

g(a)(a-b) >= F(a)-F(b) + (g(a)-g(b))^2/2.

This can be checked exactly, without appealing to a smooth-convex theorem. The difference between the left and right sides is zero if a,b <= K, if a,b >= K, or if b <= K <= a. If a <= K <= b, the difference is (K-a)(b-K) >= 0. Thus the stated orientation is correct.

## 2. Spectral transition weights and the nonselfadjoint channel

Write X = sum_i x_i P_i using its distinct eigenvalues and spectral projections. Set

w_i = tau(P_i),
p_ij = tau(P_i Phi(P_j)).

Positivity of Phi makes p_ij >= 0. Unitality and trace preservation respectively give

sum_j p_ij = w_i,
sum_i p_ij = w_j.

These are common-marginal joint weights; unless all projectors have the appropriate equal rank, the p_ij themselves should not be described as an ordinary row-normalized doubly stochastic matrix. Symmetry p_ij = p_ji is neither assumed nor needed.

Multiplying the scalar inequality by p_ij and summing cancels the F terms. The left side becomes

tau[g(X)(X-Phi(X))].

The squared-difference term is exactly

(1/2) sum_ij p_ij (g(x_i)-g(x_j))^2
 = tau(g(X)^2) - tau(g(X) Phi(g(X)))
 = E_Phi(g(X)).

This proves

E_Phi(g_K(X)) <= tau[g_K(X)(X-Phi(X))]
 <= K ||X-Phi(X)||_(1,tau)
 = K epsilon_rho.

The last inequality is trace Holder. On Hermitian inputs the real quadratic form of I-(Phi+Phi*)/2 is precisely E_Phi, even when Phi is nonselfadjoint.

## 3. From Dirichlet control to reconstruction

Let L = I-Psi. Because Psi is a positive selfadjoint HS contraction,

0 <= L <= I and L^2 <= L.

For any Hermitian Y,

||Y-Psi(Y)||_(1,tau)^2
 <= ||L Y||_(2,tau)^2
 = <Y,L^2 Y>_tau
 <= <Y,L Y>_tau
 <= C E_Phi(Y).

Apply this to Y = g_K(X) to obtain

||g_K(X)-Psi(g_K(X))||_(1,tau) <= sqrt(C K epsilon_rho).

Set R = X-g_K(X) = (X-KI)_+ and t = tau(R). Positivity and trace preservation give ||Psi(R)||_(1,tau) = t. The decomposition

X-Psi(X) = R + [g_K(X)-Psi(g_K(X))] - Psi(R)

therefore proves

||rho-Psi(rho)||_1 = ||X-Psi(X)||_(1,tau)
 <= 2t + sqrt(C K epsilon_rho).

This channel Psi is the same for every rho and every K.

## 4. Entropy tail estimate

Let h(x) = x log x-x+1, with h(0) = 1. Then h >= 0 on [0,infinity), and tau(X) = 1 implies

tau(h(X)) = tau(X log X) = D(rho || I/d).

For x > K > e,

h(x) >= x(log K-1) >= (x-K)(log K-1).

For x <= K the positive-part tail is zero and h(x) >= 0. Functional calculus and the trace thus yield

t = tau((X-KI)_+) <= D(rho || I/d)/(log K-1).

This establishes the statewise reconstruction bound in the verdict.

## 5. Ensemble averaging and explicit modulus

If sum_x p_x rho_x = I/d, then

chi = sum_x p_x D(rho_x || I/d).

Averaging the statewise bound, applying chi <= H, and using Jensen on the square root gives

sum_x p_x ||rho_x-Psi(rho_x)||_1
 <= 2H/(log K-1) + sqrt(C K epsilon),

epsilon = sum_x p_x ||rho_x-Phi(rho_x)||_1.

For 0 < epsilon < e^(-2), choose K = epsilon^(-1/2). Then

sum_x p_x ||rho_x-Psi(rho_x)||_1
 <= 4H/(log(1/epsilon)-2) + sqrt(C) epsilon^(1/4).

Hence, for fixed finite H, the common reconstruction error tends to zero dimension-independently, with the proposed order O(H/log(1/epsilon)) + O(epsilon^(1/4)). For larger epsilon the general K > e inequality remains valid; the universal trace-distance upper bound 2 may also be used. At epsilon = 0, let K tend to infinity in the general inequality to obtain zero error. The fixed comparator Psi does not vary with K, so this limiting argument is legitimate.

## Optional constant improvement

The claimed bounds above are valid as written. There is also a harmless factor-two improvement in the residual term. Since tau(X-Phi(X)) = 0 and 0 <= g_K(X) <= K I,

tau[g_K(X)(X-Phi(X))]
 = tau[(g_K(X)-(K/2)I)(X-Phi(X))]
 <= (K/2) ||X-Phi(X)||_(1,tau).

Thus every sqrt(C K epsilon) above can be replaced by sqrt((C/2) K epsilon). With K = epsilon^(-1/2), the last coefficient is sqrt(C/2). In the binary general case C = 8 this is 2 epsilon^(1/4); in the binary HS-selfadjoint case C = 4 it is sqrt(2) epsilon^(1/4).

## Optional sharper entropy tail and clean modulus

The entropy tail denominator can also be improved, and the restriction K > e removed. For every K > 1 and x >= K, convexity of h gives

h(x) >= h(K) + h'(K)(x-K) >= (x-K) log K.

For x <= K the tail is zero. Thus

t <= D(rho || I/d)/log K.

Combining this with the centered residual bound gives, for every K > 1,

sum_x p_x ||rho_x-Psi(rho_x)||_1
 <= 2H/log K + sqrt((C/2) K epsilon).

Consequently, for every 0 < epsilon < 1, the choice K = epsilon^(-1/2) yields the cleaner bound

sum_x p_x ||rho_x-Psi(rho_x)||_1
 <= 4H/log(1/epsilon) + sqrt(C/2) epsilon^(1/4).

One can take the minimum of this expression and 2. This strengthening does not alter the conclusion that the original proposed inequality and rate were correct.
