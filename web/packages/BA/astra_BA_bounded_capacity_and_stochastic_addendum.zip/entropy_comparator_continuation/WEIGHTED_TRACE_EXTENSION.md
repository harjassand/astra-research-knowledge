# Common comparator on arbitrary finite tracial algebras

Derived 9 October 2026 UTC. This is a new continuation of the independently audited C4 theorem; frozen earlier audit files are not changed.

## Exact statement

Let A be a finite-dimensional C*-algebra and τ a faithful normalized tracial state. Let Φ:A→A be unital completely positive, τ-preserving, selfadjoint on L²(A,τ), and r-self-compatible in the Heisenberg sense: there exists UCP J:A^⊗r→A with J(I⊗...⊗a⊗...⊗I)=Φ(a) for each position. Then there is one finite POVM E_y∈A, Σ_yE_y=I, such that the canonical map

Ψ(a)=Σ_y [τ(E_y a)/τ(E_y)] E_y

satisfies Ψ≥f_r(Φ), f_r(t)=((rt²−1)/(r−1))_+, in L²(A,τ) operator order. In particular

I−Ψ≤r/(r−1)(I−Φ²)≤2r/(r−1)(I−Φ).

Zero effects are omitted. The same POVM works for all Hermitian a. No lower bound on the block weights, uniform number of blocks, or simple full-matrix algebra is required.

## Proof of the extension

The original proof requires only (i) a finite-dimensional real Hilbert space of Hermitian operators with tracial inner product, (ii) spectral projectors and finite POVMs, (iii) a positive joint reference functional with tracial one-output marginals, and (iv) compactness of canonical moment maps. All four remain available here, including arbitrary block-changing Φ.

In detail, choose τ-orthonormal traceless Hermitian eigenvectors a_i with |λ_i|>r^−1/2. Define the joint reference state ω=τ∘J on A^⊗r, after symmetrizing J over its inputs. It is positive and normalized, and its marginal is τ because τΦ=τ. Thus T_ij=ω(a_i⊗a_j⊗I...) is real symmetric and T≤I, by positivity of the square of a(v) in two commuting tensor factors.

Start with the random spectral POVM E_(i,s)=P_(i,s)/m and estimator z_j=m s δ_ij. Recursion E′=J(E_y1⊗...⊗E_yr), z′_i=Σ_k z_i(y_k)/(rλ_i) is a physical finite POVM with operator first moments a_i. The covariance under p_y=τ(E_y) obeys the identical matrix recursion C′=D⁻¹[C+(r−1)T]D⁻¹/r. Consequently C_n≤H+o(1)I with H=(r−1)(rD²−I)⁻¹.

For an arbitrary Hermitian a with τ(a)=0, define u_a(y)=τ(E_y a)/τ(E_y). Then E[u_a z_i]=τ(aa_i), and ⟨a,Ψ_n a⟩_τ=E[u_a²]. Classical regression therefore bounds Ψ_n on the entire Hermitian space. Compactness and the same limit yield the spectral domination, with the identity direction handled exactly.

For clarity, compactness does not rely on a dimension-uniform outcome bound. Write h_y=E_y/τ(E_y), so h_y≥0, τ(h_y)=1, Σp_yh_y=I, and Ψ_n(a)=Σp_yτ(h_ya)h_y. The positive trace-one set {h≥0:τ(h)=1} is compact because τ is faithful in this fixed finite dimension. Its first/second moments form a compact finite-dimensional convex set. Carathéodory supplies a finite ensemble for every limit; multiplying h_y by p_y returns a finite POVM. Extreme-state refinement is optional and not needed for reconstruction.

## Physical interpretation and entanglement breaking

Represent A as a block-diagonal subalgebra of B(H). Its trace τ has a central faithful density σ, so τ(a)=Tr(σa). Define the physical Schrödinger map on the algebra by

Ψ_phys(ρ)=Σ_y Tr(E_yρ) [σE_y/τ(E_y)].

Each preparation is positive because σ is central, and has trace one. Thus this is an ordinary measure-and-prepare EB channel. It preserves σ. On ρ=σa it equals σΨ(a). Precomposing the ambient input pinching onto A extends it to an ordinary full-domain EB channel on B(H). There is no requirement that Φ or the POVM acts separately on each block.

## Exact N93 final interface

The pinned source `d-c851b6e4ba719edf`, equation (25), asks precisely for such a finite tracial algebra, positive selfadjoint self-compatible Φ, and likelihood family ρ_H=σ(I+H), τH=0, ||H||∞≤θ=1/2, with residual r=sup_H||ΦH−H||_(1,τ)→0.

The comparator just proved gives

⟨H,(I−Ψ)H⟩_τ≤4⟨H,(I−Φ)H⟩_τ≤4θr.

Because Ψ is an L²-positive contraction, (I−Ψ)²≤I−Ψ. Cauchy–Schwarz under τ gives ||Z||_(1,τ)≤||Z||_(2,τ). Therefore the SAME physical EB channel obeys

sup_H (1/2)||Ψ_phys(ρ_H)−ρ_H||₁ ≤ sqrt(θr).

This closes that exact final weighted-tracial rounding interface. It is not, by itself, verification of the earlier reductions leading to the interface. In particular the pair-broadcasting-to-affinity-gap bridge and compatible bounded-capacity smoothing must also be checked before stating the complete N93 implication as established.

Pinned proof source:
https://github.com/harjassand/astra-research-knowledge/blob/99a9d763558c3c7d329d3bdeb64905187cb5429c/web/pages/d-c851b6e4ba719edf.html
