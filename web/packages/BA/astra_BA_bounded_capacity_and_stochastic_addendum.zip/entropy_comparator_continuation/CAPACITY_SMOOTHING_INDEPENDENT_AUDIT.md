# Independent audit: uniform capacity to a fixed sandwich

Date: 2026-10-09. Audited source: `sources/d-b4ddaa96b233287d.txt` (the October 7 compatible-smoothing audit). This is a new mathematical reconstruction of that reduction, not an audit of the separate fixed-sandwich theorem or a priority claim.

## Verdict

**The reduction is valid for arbitrary nonempty families of states in finite-dimensional spaces, allowing dimension and family size to grow along a sequence. No fatal gap found.** Its hypotheses are genuinely uniform: Holevo capacity is the supremum over all finite priors, broadcast error is a supremum over promised states and both marginals, and EB error is the infimum over one common channel of a supremum over promised states. A bound on Holevo information for one prescribed prior cannot replace capacity.

The conclusion is an equivalence of two sequence implications, conditional on the fixed-sandwich gate. This audit does not prove that gate. Necessary qualifications are: close each family before taking a capacity-maximizing prior; compress channels by an actual CPTP retraction, not by output projection alone; retain the center as a promised smoothed state; fix smoothing accuracy before taking the sequence limit. These qualifications already appear in the audited source.

A cleaner common-center proof below avoids differentiating entropy at singular states. An explicit modulus makes dimension independence and the order of quantifiers transparent.

## 1. Exact definitions and common center

Write T(rho,tau)=||rho-tau||_1/2. For an experiment E on H, set

- C(E)=sup_p [S(sum_i p_i rho_i)-sum_i p_i S(rho_i)], over all finite priors on E, with natural logarithms;
- b_2(E)=inf_B sup_{rho in E} max_{j=1,2} T(B_j(rho),rho), where one channel B:H→H⊗H supplies both marginals;
- e(E)=inf_{Lambda EB} sup_{rho in E} T(Lambda(rho),rho).

Replacing E by its closure preserves these three quantities in fixed finite dimension. For capacity this follows from entropy continuity and approximation of every finite collection of closure points. For the other two quantities it follows channel by channel from continuity.

The convex hull of the compact set {(rho,S(rho)):rho in E} is compact. Its affine dimension is at most d², so a maximizing point for S(mean)-mean entropy has a finite realizing ensemble of at most d²+1 atoms. Let sigma be its mean and c=C(E).

Here is a support-safe radius proof. For any rho in E and 0<t<1, add rho with mass t to the maximizing ensemble and write sigma_t=(1-t)sigma+t rho. Its Holevo information obeys

chi_t=(1-t)c+(1-t)D(sigma||sigma_t)+tD(rho||sigma_t)≤c.

Nonnegativity implies D(rho||sigma_t)≤c. Lower semicontinuity as t tends to zero gives D(rho||sigma)≤c. In particular, every promised state is supported on sigma. This proves the pointwise radius bound with one common center without a boundary derivative argument.

Because sigma is a finite convex combination of promised states, any linear channel with uniform error β on E has error at most β on sigma. Adding sigma changes neither b_2 nor e; it also does not increase capacity, since the relative-entropy radius at sigma bounds the capacity of the augmented experiment. The center may vary with the sequence index; no common ambient center is required.

For P=supp(sigma), define R(X)=PXP+Tr[(I-P)X]sigma. This is CPTP into B(PH), fixes every promised state and sigma, and output postcomposition (R⊗R)B reduces each marginal error. Conversely extend channels on PH by applying R to inputs; for an EB channel this remains EB. Therefore support compression has no approximation cost and introduces no eigenvalue constants.

## 2. Canonical smoother and its stability

For M≥1 and λ>0, define K_sigma={tau:0≤tau≤M sigma, Tr tau≤1},
Q_sigma(tau)=||sigma^(-1/4)tau sigma^(-1/4)||_2²,
and G(rho,sigma)=argmin_{tau in K_sigma}[-f(rho,tau)+λQ_sigma(tau)], with root fidelity f.

All inverses are on support. Strict convexity of Q and concavity of f give a unique minimizer. For every supported Hermitian X, Schatten Hölder gives ||X||_1²≤Q_sigma(X). For every feasible tau, Q_sigma(tau)≤M Tr tau≤M. The exact quadratic identity yields the strong-convexity gap

J(v)-J(G)≥λQ_sigma(v-G)≥λ||v-G||_1².

CPTP maps increase f and decrease Q, including for subnormalized tau: scale tau by its trace and use ordinary fidelity DPI and sandwiched-Renyi-2 DPI. They also map K_sigma into K_{T sigma}.

For references sigma,nu, write tau=sqrt(sigma) A sqrt(sigma), 0≤A≤MI. Transport to tau'=sqrt(nu)A sqrt(nu), then clip its trace to one if needed, obtaining kappa in K_nu. For d_s=||sigma-nu||_1 and d_r=||rho-rho'||_1, independently reconstructed estimates are

||kappa-tau||_1≤2M sqrt(d_s)+M d_s,
J_{rho',nu}(kappa)≤J_{rho,sigma}(tau)+xi,
xi=sqrt(d_r)+(sqrt(M)+2λM²)sqrt(d_s)+(M/2)d_s.

The sharper fidelity bound follows directly from f(rho,WW*)=||sqrt(rho)W||_1 with W=sqrt(sigma)A^(1/2); one need not turn structured transport into generic trace-distance continuity. Clipping costs at most M d_s/2 in fidelity because excess trace is at most M d_s and sqrt(t')-1≤(t'-1)/2. The Q difference before clipping is at most 2M²sqrt(d_s), and clipping only decreases Q. None of these bounds uses invertibility off support or the dimension.

Apply transport in both directions to bound minimum objective values. For a marginal endomorphism T, its image TG is feasible at (T rho,T sigma) and has objective at most the original minimum. Strong convexity there compares TG and the transported kappa to G(T rho,T sigma). Thus

||TG-G||_1≤(1+sqrt(2))sqrt(xi/λ)+2M sqrt(d_s)+M d_s,

with d_r=||T rho-rho||_1 and d_s=||T sigma-sigma||_1. This is O_{M,λ}(β^(1/4)) when the two half-trace errors are at most β. The comparison minimizer at the output reference is only a proof device; the actual smoothed experiment uses the same fixed G(rho,sigma), independent of the broadcaster or its marginal.

## 3. Approximation and normalization

Fix 0<epsilon<1 and a uniform capacity bound C≥C(E). Put

eta=epsilon²/8,
M=(1-eta)^(-1) exp((C+ln 2)/eta),
λ=eta/M.

Jain–Nayak's substate theorem supplies a normalized tau_0≤M sigma with squared fidelity at least 1-eta. Minimality of G and Q(tau_0)≤M give f(rho,G)≥sqrt(1-eta)-eta≥1-2eta. Consequently t=Tr G≥f²≥1-4eta>1/2. Define rhohat=G/t. Then rhohat≤2M sigma and T(rho,rhohat)≤epsilon/sqrt(2)≤epsilon.

For rho=sigma, f(sigma,v)≤sqrt(Tr v) and Q_sigma(v)≥(Tr v)². The scalar function -sqrt(t)+λt² decreases on [0,1] for λ≤1/4. The point v=sigma achieves its minimum, so uniqueness gives G(sigma,sigma)=sigma. Therefore the normalized smoothed experiment includes exactly sigma.

Normalization preserves compatibility: ||T rhohat-rhohat||_1=||TG-G||_1/t. Since t>1/2, its half-trace error is at most the right side of the preceding stability bound. Define

xi_C,epsilon(β)=(1+sqrt(M)+2λM²)sqrt(2β)+Mβ,
g_C,epsilon(β)=(1+sqrt(2))sqrt(xi_C,epsilon(β)/λ)+2M sqrt(2β)+2Mβ.

Then b_2(Ehat)≤g_C,epsilon(b_2(E)) (or use arbitrarily near-optimal broadcasters and continuity). Crucially g_C,epsilon(β) tends to zero as β tends to zero for fixed C,epsilon. There is no added epsilon error in this preservation bound. The constants can be extremely large as epsilon decreases, but are independent of dimension, label count, center spectrum and sequence index.

Channelwise contractivity gives e(E)≤e(Ehat)+2epsilon. No minimax exchange is involved.

## 4. Fixed sandwich and reverse reconstruction

Choose any fixed theta in (0,1), once and for all. Set U=2M and a=theta/(U-1), so 0<a<1. For each rhohat define tau=(1-a)sigma+a rhohat, and let F be the diluted experiment. Since sigma is included in Ehat, it is included in F. The inequalities 0≤rhohat≤U sigma imply

(1-theta)sigma≤tau≤(1+theta)sigma.

The same broadcast channel works and convexity gives b_2(F)≤b_2(Ehat). Operator monotonicity of logarithm gives D(tau||sigma)≤ln(1+theta), hence C(F)≤ln(1+theta).

For any one EB channel Lambda, put delta=sup_{tau in F} T(Lambda(tau),tau). Linearity and the included center imply, for every rhohat,

a T(Lambda(rhohat),rhohat)≤delta+(1-a)delta=(2-a)delta.

Thus e(Ehat)≤((2-a)/a)e(F), and altogether

e(E)≤2epsilon+((2-a)/a)e(F),
b_2(F)≤g_C,epsilon(b_2(E)).

The inverse is a signed affine identity on errors; no inverse quantum channel is asserted or needed. Center inclusion is indispensable to this argument. It is also essential that Lambda be common to all labels.

## 5. Sequence quantifiers and limitations

Suppose the fixed-sandwich implication holds for this one fixed theta, uniformly over arbitrary finite dimensions: b_2(F_n)→0 implies e(F_n)→0. For an arbitrary sequence with C(E_n)≤C and b_2(E_n)→0, first fix epsilon. All M,λ,a are now fixed independent of n. The constructed F_n has b_2(F_n)→0, and consequently limsup e(E_n)≤2epsilon. Let epsilon decrease to zero only after taking this limsup. The converse implication follows from C(F_n)≤ln(1+theta).

If a bounded-capacity sequence violates EB convergence, pass to a subsequence with e(E_n)≥c>0 and choose epsilon<c/4. Then the fixed-sandwich family has EB error bounded below by a positive constant depending on C,c,theta. This is the precise contrapositive.

For comparison, a single prescribed prior concentrated on one label has Holevo information zero even for an experiment containing every pure state in arbitrarily large dimension. Thus an averaged or one-prior theorem does not satisfy this reduction's capacity hypothesis or reconstruction conclusion.

This argument supplies no effective universal rate for the fixed-sandwich gate, no finite-outcome construction of its EB channel, and no infinite-dimensional extension. It cannot upgrade a dimension-dependent gate or a fixed-prior average reconstruction estimate into the required uniform theorem.

## Imports checked directly

- Jain and Nayak, *Short proofs of the Quantum Substate Theorem*, Theorem 1, https://arxiv.org/pdf/1103.6067 (PDF page 3): squared-fidelity convention, domination factor (1-eta)^(-1)2^(D_obs/eta), and D_obs≤D_rel_bits+1. The stated nats conversion is correct.
- Beigi, *Sandwiched Rényi divergence satisfies data processing inequality*, https://arxiv.org/pdf/1306.5920: DPI at alpha=2 gives exactly the required monotonicity of Q for normalized states; homogeneity extends it to subnormalized states.

Both primary PDFs were reopened during this independent audit. Other ingredients are elementary finite-dimensional convexity, entropy identities, fidelity bounds and Schatten Hölder. No numerical evidence was substituted for proof.
