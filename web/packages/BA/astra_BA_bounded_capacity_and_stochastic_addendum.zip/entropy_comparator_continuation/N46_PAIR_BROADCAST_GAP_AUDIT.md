# Independent audit: two-state broadcasting implies a small fidelity-affinity gap

## Verdict

The imported N46 two-state bridge is valid. Its decisive finite-dimensional proof can be reconstructed directly. In particular, it does not require the qualitative ultraproduct, finite-mixture, compact-experiment, or almost-commuting arguments elsewhere in N46.

Let T(rho,sigma) = (1/2)||rho-sigma||_1. Suppose a single CPTP channel B sends the input system to two copies of that system, with marginal channels T_0,T_1, and

max_{x=0,1; a=0,1} T(T_a(rho_x),rho_x) <= b.

Then for every integer L >= 0 there is a single EB channel E_L such that

max_x T(E_L(rho_x),rho_x) <= eta_L(b),
eta_L(b) = L b + sqrt(ln(2)/(2*2^L)).

Consequently, with root fidelity F(rho,sigma) = ||sqrt(rho)sqrt(sigma)||_1 and affinity A(rho,sigma) = Tr(sqrt(rho)sqrt(sigma)),

Delta(rho_0,rho_1) = F(rho_0,rho_1)-A(rho_0,rho_1)
 <= min(1, inf_{L>=0 integer} 2 sqrt(2 eta_L(b))).

This is a dimension-free modulus v(b) tending to zero and of order O(sqrt(b log(1/b))). No common reference, support, faithfulness, domination, state entropy, reversibility, or dimension bound is needed for this pair implication. The same broadcaster must work on both states and both receivers.

## Provenance actually read

Repository: harjassand/astra-research-knowledge.
Pinned commit: 99a9d763558c3c7d329d3bdeb64905187cb5429c.

Read at that commit:
- 00_START_HERE.txt.
- frontier/review_cards/N46-compact-quantum-classicality.txt.
- frontier/cards/N46-compact-quantum-classicality.json.
- web/pages/d-fc53e2ac7ba8887c.html, the general criterion and its explicit-pair pointer.
- web/R-sources.txt and the R-library inventory to resolve the decisive proof.
- web/pages/d-3309c2d38e9bf616.html, EXPLICIT_PAIR_BOUND.md.
- web/assets/36ef809b78e532bcefb0d70d8ef22f6f9ad5456d799b06fb8592d051226d5eac.md, exact original decisive proof bytes.

The last asset was saved as sources/N46_EXPLICIT_PAIR_BOUND_PINNED.md and independently SHA-256 checked against its asset filename: 36ef809b78e532bcefb0d70d8ef22f6f9ad5456d799b06fb8592d051226d5eac.

Direct decisive source:
https://github.com/harjassand/astra-research-knowledge/blob/99a9d763558c3c7d329d3bdeb64905187cb5429c/web/assets/36ef809b78e532bcefb0d70d8ef22f6f9ad5456d799b06fb8592d051226d5eac.md

The status card reports source_derived_unreviewed with no corrective notice invalidating this bridge. That status was not used as evidence of mathematical correctness. The following is the independent reconstruction.

## 1. Iterate the approximate broadcaster without assuming independent outputs

Apply B at every node of a binary tree of depth L. This produces one CPTP map C_L with K = 2^L output systems. The reduced channel at any leaf is a composition of L marginal maps, each selected from T_0 and T_1.

If a composition S of length k satisfies T(S(rho_x),rho_x) <= k b, then contractivity gives

T(T_a S(rho_x),rho_x)
 <= T(T_a S(rho_x),T_a(rho_x)) + T(T_a(rho_x),rho_x)
 <= (k+1)b.

Therefore every marginal of Omega_x = C_L(rho_x) is within Lb of rho_x. The full Omega_x can be correlated or entangled; no product approximation is asserted or used.

## 2. Binary information extraction: the critical dimension-free step

Consider any pair Omega_0,Omega_1 on Q_1 tensor ... tensor Q_K. Give the classical label X a uniform design prior. This prior is used only to design a common recovery channel; no promise is made about the actual input frequency.

Recursively define a sequential measurement of all K systems. At stage j, for each previous outcome record h, let

p_h = P(H_{j-1}=h),
q_x(h) = P(X=x | H_{j-1}=h),
tau_x^h = the conditional state of Q_j given x,h.

Null-probability branches can be assigned arbitrarily. Measure on Q_j the Helstrom sign projector for tau_0^h-tau_1^h. If r_x^h denotes its classical outcome distribution, this measurement satisfies

TV(r_0^h,r_1^h) = T(tau_0^h,tau_1^h).

Define

d_h = 2 q_0(h)q_1(h) T(tau_0^h,tau_1^h).

For a binary label, a direct expansion of the two rows of the joint distribution gives exactly

TV(P_{X,Y_j|h}, P_{X|h}P_{Y_j|h}) = d_h.

Classical Pinsker, with natural logarithms, therefore yields

g_j := I(X:Y_j | H_{j-1}) >= 2 sum_h p_h d_h^2.

The classical chain rule gives

sum_{j=1}^K g_j = I(X:Y_1,...,Y_K) <= H(X) = ln 2.

Choose a deterministic index j for which g_j <= ln(2)/K. Construct the recovery channel by performing only the prefix measurements on Q_1,...,Q_{j-1}, then preparing on a fresh Q_j system the state

xi_h = q_0(h)tau_0^h + q_1(h)tau_1^h.

Both the prefix protocol and every xi_h are fixed from the known pair and the uniform design prior. They do not depend on the unknown actual label.

The original Q_j marginal is unchanged by the nonselective prefix measurement, since that measurement acts only on other tensor factors. For either label x,

T(Omega_{x,j}, E(Omega_x))
 <= sum_h P(h|x) T(tau_x^h,xi_h)
 = sum_h [2 p_h q_x(h)] q_{1-x}(h) T(tau_0^h,tau_1^h)
 = sum_h p_h d_h
 <= sqrt(sum_h p_h d_h^2)
 <= sqrt(g_j/2)
 <= sqrt(ln(2)/(2K)).

The identity P(h|x)=2p_hq_x(h) is precisely where the uniform design prior is used. The two labels yield the same upper bound. There is no unjustified conversion of an average error to a worst-case error, and no multiplicative label-count factor is needed. This equality is special to the binary situation.

Composing this prefix measurement with C_L gives a genuine POVM on the original input algebra. Preparing xi_h is therefore an EB channel from the original system to itself. The leaf approximation from Step 1 adds Lb, proving eta_L.

## 3. An approximately fixing EB channel forces a small gap

Let E(rho) = sum_h Tr(M_h rho) xi_h. Set p_h = Tr(M_h rho_0) and r_h = Tr(M_h rho_1).

Monotonicity of root fidelity under the measurement map implies

F(rho_0,rho_1) <= sum_h sqrt(p_h r_h).

The affinity A(U,V)=Tr(sqrt(U)sqrt(V)) on positive operators is jointly concave and jointly degree-one homogeneous (Lieb's concavity theorem). Hence it is superadditive on pairs, which gives

A(E(rho_0),E(rho_1))
 >= sum_h A(p_h xi_h,r_h xi_h)
 = sum_h sqrt(p_h r_h).

It follows that

Delta(rho_0,rho_1)
 <= A(E(rho_0),E(rho_1))-A(rho_0,rho_1).

Powers-Stormer says

||sqrt(rho)-sqrt(rho')||_2 <= sqrt(||rho-rho'||_1).

Expand the difference of the two affinities into two terms, changing one square-root factor at a time. Hilbert-Schmidt Cauchy-Schwarz, together with ||sqrt(rho)||_2=1, implies

|A(rho_0',rho_1')-A(rho_0,rho_1)|
 <= sqrt(||rho_0'-rho_0||_1)+sqrt(||rho_1'-rho_1||_1).

If the two half-trace errors are bounded by eta, the last display is at most 2 sqrt(2 eta). Applying this to E_L proves the asserted gap bound.

The only imported general inequalities in this reconstruction are ordinary trace-distance contractivity, Helstrom's variational characterization, classical Pinsker and the classical information chain rule, root-fidelity monotonicity, Lieb affinity concavity, and Powers-Stormer. None carries a dimension factor in the form used here.

## 4. Explicit modulus and endpoints

For 0 < b <= 1, take L = ceil(2 log_2(1/b)). Then

eta_L(b) <= b [2 log_2(1/b)+1+sqrt(ln(2)/2)],

so

Delta(rho_0,rho_1)
 <= min(1, 2 sqrt(2b [2 log_2(1/b)+1+sqrt(ln(2)/2)])).

At b=0, use the same construction for every L and let L tend to infinity, proving Delta=0. No convergence of E_L is needed for this scalar conclusion. The modulus depends only on the supplied pairwise broadcaster error, not on Hilbert dimension.

If b denotes an infimum that is not attained, apply the argument to any broadcaster with error b+delta, then let delta decrease to zero. In fixed finite dimension the channel set is compact anyway.

## Consequence for the current continuation

When the family contains the reference sigma and one channel broadcasts every member with error b, restriction to each pair {sigma,rho} is legitimate and uses the same b. Taking the supremum over rho gives

sup_rho Delta(sigma,rho) <= v(b).

There is no net, finite-family reduction, label-count assumption, or extra supremum/measurement interchange in this step. Thus the specific bridge imported in Section 9 of the centralization source is supported by this proof.

This audit verifies that bridge and its scope; it does not by itself validate the other centralization or full bounded-Holevo reduction steps, nor establish novelty or external expert certification.
