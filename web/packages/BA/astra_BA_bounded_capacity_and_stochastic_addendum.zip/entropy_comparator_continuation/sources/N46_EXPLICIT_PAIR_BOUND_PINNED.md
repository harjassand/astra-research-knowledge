# Explicit dimension-free approximate no-broadcasting bound

Status: complete finite-dimensional candidate proof; the adaptive information-chain and posterior-preparation contracts have been independently checked by two agents. No ultraproduct or dimension-dependent de Finetti theorem is used. External correctness and priority review remain open.

## Statement

Let rho_0,rho_1 be arbitrary density matrices on a finite-dimensional H. Suppose one CPTP B:H -> H tensor H has both marginals T_a satisfying

    max_{i=0,1; a=0,1} T(T_a(rho_i),rho_i) <= epsilon,
    T(rho,sigma) = (1/2)||rho-sigma||_1.

Write Delta(rho,sigma)=||sqrt(rho)sqrt(sigma)||_1-Tr sqrt(rho)sqrt(sigma). For every integer L >= 0, there exists a measure-and-prepare channel E_L:H -> H such that

    max_i T(E_L(rho_i),rho_i)
      <= eta_L(epsilon)
      := L epsilon + sqrt(ln(2)/(2 * 2^L)).

Consequently

    Delta(rho_0,rho_1) <= 2 sqrt(2 eta_L(epsilon)).

The bound can be minimized over L. An explicit choice for 0 < epsilon <= 1 is

    L = ceil(2 log_2(1/epsilon)),

which gives

    Delta(rho_0,rho_1)
      <= 2 sqrt(2 epsilon [2 log_2(1/epsilon)+1+sqrt(ln(2)/2)]).

The right side can be capped at the trivial Delta <= 1. At epsilon=0, taking L -> infinity proves Delta=0. Thus an explicit universal modulus is

    v(epsilon) = min(1,
        inf_{L in nonnegative integers}
        2 sqrt(2 [L epsilon+sqrt(ln(2)/2) 2^(-L/2)])),

with v(0)=0. Its small-error order is O(sqrt(epsilon log(1/epsilon))). The known pure-qubit Helstrom construction forces every universal modulus to be at least (2+o(1))sqrt(epsilon), so the remaining logarithmic factor is not resolved by this proof.

## 1. Binary-tree iteration

Let C_0=id_H and define C_{L+1} by applying B independently to every leaf of C_L. This is one CPTP channel H -> H^(tensor K), K=2^L, fixed without knowing the input label. Every leaf channel is a composition of L maps selected from T_0,T_1. Contractivity and the assumed per-label one-step error imply inductively

    max_{i,j} T(C_L(rho_i)_j,rho_i) <= L epsilon.

The full joint outputs can be arbitrarily correlated or entangled. Product-output closeness is not assumed.

## 2. Dimension-free finite binary ensemble extraction

We prove a useful lemma for any two joint density matrices Omega_0,Omega_1 on Q_1 tensor ... tensor Q_K. With a uniform design prior X in {0,1}, there is an index j and a prefix measurement on Q_1,...,Q_{j-1} such that measuring that prefix and preparing a fixed state of Q_j reconstructs each original Q_j marginal within

    sqrt(ln(2)/(2K))

in trace distance. This is an ensemble-specific statement. The same prefix measurement and prepared states work for both unknown labels.

Build an adaptive measurement sequence as follows. At stage j, let h be the complete previous measurement record, let p_h=P(H_{j-1}=h), let q_x(h)=P(X=x|h), and let tau_x^h be the normalized conditional state of Q_j. Outcomes with p_h=0 are arbitrary. If q_x(h)=0, the corresponding conditional state may likewise be assigned arbitrarily.

On Q_j measure the two-outcome spectral sign projector of tau_0^h-tau_1^h. This realizes the trace distance between the two conditional states. Denote its outcome by Y_j, and put

    d_h = 2 q_0(h) q_1(h) T(tau_0^h,tau_1^h).

For this measurement, the total variation distance between the joint conditional classical law P(X,Y_j|h) and the product of its marginals is exactly d_h. Indeed, if r_x is the conditional outcome law for input x, then TV(r_0,r_1)=T(tau_0^h,tau_1^h), and a direct binary calculation gives

    TV(P_{X,Y_j|h}, P_{X|h} P_{Y_j|h})
      = 2 q_0(h) q_1(h) TV(r_0,r_1) = d_h.

Classical Pinsker in natural logarithms therefore implies

    g_j := I(X:Y_j | H_{j-1})
      >= 2 sum_h p_h d_h^2.

The information chain rule and the one-bit label give

    sum_{j=1}^K g_j = I(X:Y_1,...,Y_K) <= H(X)=ln(2).

Fix one j with g_j <= ln(2)/K. Although the full sequential protocol defined g_j, the eventual recovery channel performs only stages 1,...,j-1. All of those measurements act on other tensor factors, so their nonselective action leaves the original Q_j marginal unchanged.

For each prefix outcome h prepare

    xi_h = q_0(h) tau_0^h + q_1(h) tau_1^h.

These states and the prefix protocol are computed from the known pair Omega_0,Omega_1 and the uniform design prior. They do not depend on the actual unknown label. If E denotes this measure-and-prepare channel on the joint input, then for x in {0,1},

    T(Omega_{x,j},E(Omega_x))
      <= sum_h P(h|x) T(tau_x^h,xi_h)
      = sum_h [2 p_h q_x(h)] q_(1-x)(h)
                   T(tau_0^h,tau_1^h)
      = sum_h p_h d_h
      <= sqrt(sum_h p_h d_h^2)
      <= sqrt(g_j/2)
      <= sqrt(ln(2)/(2K)).

The equality of the two per-label convexity bounds is specific to two labels and a uniform prior. No generic prior-average-to-worst conversion is needed. For j=1 the prefix is empty and the channel simply prepares the averaged Q_1 state.

Apply this lemma to Omega_i=C_L(rho_i). Composing the prefix measurement with C_L gives a genuine POVM on the original H. Preparing xi_h therefore defines an entanglement-breaking channel E_L:H -> H, and triangle inequality with Step 1 gives eta_L.

## 3. EB reconstruction controls the fidelity-affinity gap

For a measure-and-prepare channel E(rho)=sum_h Tr(M_h rho) xi_h, write p_h=Tr(M_h rho_0) and r_h=Tr(M_h rho_1). Fidelity monotonicity under the measurement gives

    F(rho_0,rho_1) <= sum_h sqrt(p_h r_h).

The homogeneous form of Lieb's joint concavity of affinity gives

    A(E rho_0,E rho_1)
      >= sum_h sqrt(p_h r_h) A(xi_h,xi_h)
      = sum_h sqrt(p_h r_h).

Thus Delta(rho_0,rho_1) <= A(E rho_0,E rho_1)-A(rho_0,rho_1). Powers-Stormer gives

    ||sqrt(rho)-sqrt(rho')||_2 <= sqrt(||rho-rho'||_1),

and Hilbert-Schmidt Cauchy-Schwarz then implies that if each reconstruction error is at most eta,

    |A(E rho_0,E rho_1)-A(rho_0,rho_1)| <= 2 sqrt(2 eta).

This establishes the displayed bound.

## Interface, cost and prior-art limits

The result concerns full marginal density matrices in unrestricted trace distance, allows output correlations, and uses the same original B on both promised states. There is no support, dimension, entropy, faithfulness, dominance or spectral-gap hypothesis. The finite binary label entropy supplies the dimension-free constant.

The extraction channel is an existence construction using full conditional joint output matrices, adaptive spectral sign measurements and conditional state preparation. Iterating B requires K-1 calls and K output systems; the explicit choice has K of order epsilon^(-2), and conditional probability/spectral acquisition may be expensive. The proof is not an efficient compilation guarantee and does not preserve purifications or create independent copies.

Pinsker, information chain rules, Helstrom trace-distance measurements, affinity concavity and Powers-Stormer are established ingredients. The information-chain/posterior-preparation method is established prior art, not a new method: Xiao-Liang Qi and Daniel Ranard, *Emergent classicality in general multipartite states and channels*, https://arxiv.org/abs/2001.01507 , Proposition 1, Eq. (18), printed p9; proof on pp10-11; Lemma 2, pp19-20. Their Markov-blanket result, specialized to a binary classical reference, already supplies the binary extraction bound: the residual reference blocks are opposite operators, so one Helstrom measurement captures their complete trace norm. The source credits earlier Brandao-Piani-Horodecki and Brandao-Harrow methods; the fully adaptive formulation also appears in Ke Li and Graeme Smith, *Quantum de Finetti theorem under fully-one-way adaptive measurements*, https://arxiv.org/abs/1408.6829 . The proof above records an elementary specialization for the precise promised-pair interface.

The explicit no-broadcasting rate here is obtained by composing that established finite-label extraction mechanism with a binary-tree iteration of the supplied approximate broadcaster and the fidelity-affinity EB obstruction. A focused historical audit of that exact composed statement remains needed before any novelty claim. The exact no-broadcasting theorem and the root-fidelity/affinity gap itself have established prior art, listed in ../broadcast_prior_art/AUDIT.md. This finite proof supersedes the necessity of the ultraproduct argument for the pair converse, while leaving that argument available as a broader algebraic formulation.
