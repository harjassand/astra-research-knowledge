# Bounded capacity approximate broadcasting implies uniform classical reconstruction

9 October 2026 UTC. Complete stitched mathematical argument derived from the audited common-comparator theorem and independently reconstructed reductions. This is internal analytic verification, including separate checks of the comparator, weighted-tracial extension, compatible smoothing, and pair extraction. It is not external peer review, formal proof certification, or a historical-priority claim.

## The statement

An experiment E is any nonempty family of density matrices on one finite-dimensional Hilbert space. Its family need not be finite. Define, with natural-log entropy,

C(E)=sup_(finite priors p on E) {S(Σ_x p_xρ_x)−Σ_x p_x S(ρ_x)},

b₂(E)=inf_(CPTP B:H→H⊗H) sup_(ρ∈E) max_(a=1,2) T(B_aρ,ρ),

e(E)=inf_(entanglement-breaking CPTP Λ:H→H) sup_(ρ∈E) T(Λρ,ρ),

where T(ρ,ν)=||ρ−ν||₁/2 and B_a is the a-th marginal. The infima are over ordinary channels on the entire input matrix algebra, not only on the promised states. A single Λ must work for every member of E.

**Theorem.** For every finite C there exists a dimension- and family-cardinality-independent function f_C:[0,1]→[0,1], with f_C(b)→0 as b↓0, such that

C(E)≤C implies e(E)≤f_C(b₂(E)).

Equivalently, for arbitrary growing-dimensional experiments E_n,

sup_n C(E_n)<∞ and b₂(E_n)→0 imply e(E_n)→0.

The capacity assumption is a supremum over all finite priors. A bound for just one chosen prior is not this hypothesis. No efficient algorithm, uniformly bounded measurement alphabet, diamond-norm approximation of the channel on unrestricted inputs, or finite exact entanglement-breaking power is asserted.

The proof below specifies an explicit, though quantitatively weak, modulus by an infimum over a smoothing tolerance. It therefore proves uniformity rather than merely extracting a subsequence-specific classical channel.

## 1 A common reference and compatible smoothing

Closing E in the compact state space leaves all three quantities unchanged. The continuous entropy graph has compact convex hull in real dimension at most d². Consequently a finite prior attains C(E); let σ be its mean. For every ρ∈E one has D(ρ||σ)≤C(E). Here is a proof covering singular supports: mix ρ at mass t into the maximizing prior, so σ_t=(1−t)σ+tρ. The relative-entropy decomposition of the new Holevo quantity gives

χ_t=(1−t)C(E)+(1−t)D(σ||σ_t)+tD(ρ||σ_t)≤C(E).

Thus D(ρ||σ_t)≤C(E); lower semicontinuity as t↓0 yields the claim and support containment. Since σ is a finite convex combination of promised states, adjoining it leaves capacity and any broadcaster's uniform error bound unchanged. Restricting to P=suppσ is physically legitimate using the CPTP output map X↦PXP+Tr[(I−P)X]σ; later reconstruction channels extend by input pinching and fixed preparation. We may henceforth assume σ faithful.

Fix a smoothing tolerance 0<δ<1/2, and set

η=δ²/8, M=(1−η)⁻¹exp[(C+ln2)/η], λ=η/M.

The quantum substate theorem supplies, for every ρ∈E, a state τ₀≤Mσ with squared fidelity at least 1−η. The factor follows from observational relative divergence in bits being at most relative entropy in bits plus one; conversion to nats gives the displayed M. This is an established imported theorem, not a new assertion here.

On the compact convex set K_σ={0≤τ≤Mσ, Trτ≤1}, minimize

J_(ρ,σ)(τ)=−F_root(ρ,τ)+λQ_σ(τ),
Q_σ(X)=||σ^(−1/4)Xσ^(−1/4)||₂².

Call the unique minimizer G(ρ,σ). Fidelity concavity and positive-definite quadratic curvature yield the exact gap

J(v)−J(G)≥λQ_σ(v−G)≥λ||v−G||₁².

The last inequality is Schatten Hölder duality and Trσ=1. On K_σ, Q_σ(τ)≤MTrτ≤M, so comparison with τ₀ gives F_root(ρ,G)≥1−2η. Hence t=TrG≥(1−2η)²>1/2, and the state ρhat=G/t satisfies ρhat≤2Mσ and T(ρhat,ρ)≤δ. At ρ=σ the scalar bound J(v)≥−sqrt(Trv)+λ(Trv)², minimized at trace one, shows by uniqueness that G(σ,σ)=σ. Thus σ is included exactly in the smoothed family.

The essential feature is compatibility with a channel, not merely pointwise approximation. For any CPTP T with d_ρ=||Tρ−ρ||₁ and d_σ=||Tσ−σ||₁, define

ξ=sqrt(d_ρ)+(sqrt(M)+2λM²)sqrt(d_σ)+(M/2)d_σ.

Then the same optimizer obeys

||T G(ρ,σ)−G(ρ,σ)||₁
≤(1+sqrt2)sqrt(ξ/λ)+2M sqrt(d_σ)+M d_σ.                 (A)

For completeness, transport a feasible τ=sqrtσ A sqrtσ, 0≤A≤MI, to τ′=sqrt(Tσ) A sqrt(Tσ), and clip its trace down to one if necessary. Powers–Størmer bounds the un-clipped trace distance by 2M sqrt(d_σ), while excess trace is ≤M d_σ. Root-fidelity transport costs at most sqrt(Md_σ), because F_root(ρ,WW*)=||sqrtρ W||₁; clipping costs at most M d_σ/2. Expanding Q costs at most 2M²sqrt(d_σ). Variation of ρ costs sqrt(d_ρ). These estimates bound the two minimum values within ξ. Fidelity and sandwiched Rényi-2 data processing make TG feasible with objective at most the original minimum. Apply the strong-convexity gap once to TG and once to transported G; their distances to the new minimizer are at most sqrt(ξ/λ) and sqrt(2ξ/λ). Adding the transport distance proves (A). All inverse operations are on reference supports, so no condition-number bound enters.

Suppose B broadcasts E with halftrace error b. Both marginal maps satisfy d_ρ,d_σ≤2b. Put

ξ_b=(1+sqrtM+2λM²)sqrt(2b)+Mb,
g(C,δ,b)=max{b,(1+sqrt2)sqrt(ξ_b/λ)+2M sqrt(2b)+2Mb}.

After normalization by t>1/2, (A) shows the SAME broadcaster has halftrace error at most g on every smoothed state and σ. For each fixed C,δ, g→0 as b→0.

Choose θ=1/2 and a=θ/(2M−1). Dilute every smoothed state to ρtilde=(1−a)σ+aρhat. The family F containing these and σ satisfies

σ/2≤ρtilde≤3σ/2,
b₂(F)≤g(C,δ,b),
e(E)≤2δ+[(2−a)/a]e(F).                                (B)

The last inequality holds channel by channel: affine inversion and inclusion of σ bound the error on ρhat by (2−a)/a times the uniform error on F; approximation of original ρ adds two δ legs. This never selects a reconstruction channel depending on the label.

## 2 A dimension-free two-state bridge

For a pair {σ,ρ} broadcast with error u, iterate the broadcaster on a depth-L binary tree. There are K=2^L outputs, each marginal within Lu of its intended state. No product-output or independence assertion is made.

For any two K-partite output states with uniform design prior, sequentially measure register j with the Helstrom measurement for its two conditional states given the preceding record h. Let posterior probabilities be q_0(h),q_1(h), and conditional states τ_0^h,τ_1^h. Put d_h=2q_0q_1T(τ_0^h,τ_1^h). Classical Pinsker gives conditional information gain g_j≥2Σ_hp_hd_h². The chain rule bounds Σ_jg_j by ln2. Some j therefore has g_j≤ln2/K.

Measure only its preceding registers and prepare ξ_h=q_0τ_0^h+q_1τ_1^h. For EACH original label x, the reconstruction error on register j is at most

Σ_hP(h|x)T(τ_x^h,ξ_h)=Σ_hp_hd_h≤sqrt[ln2/(2K)].

The equality uses the binary uniform prior, since P(h|x)=2p_hq_x. Thus the SAME finite measure-and-prepare map reconstructs both pair states with error at most Lu+sqrt[ln2/(2·2^L)]. Compose its measurement with the tree to obtain an EB map on the original input.

For any EB map approximately reconstructing a pair to error ζ, fidelity monotonicity under its measurement and joint concavity of affinity imply

F_root(σ,ρ)≤A(Λσ,Λρ), where A(α,β)=Tr(sqrtα sqrtβ).

Powers–Størmer bounds the change in A by 2sqrt(2ζ). Therefore

Δ(σ,ρ):=F_root(σ,ρ)−A(σ,ρ)≤v(u),
v(u)=min{1, inf_(L≥0 integer) 2sqrt(2[Lu+sqrt(ln2/2)2^(−L/2)])}.

Set v(0)=0. In particular v(u)→0, and choosing L=ceil(2log₂(1/u)) gives O(sqrt[u log(1/u)]). This bridge uses only the pair restriction of the original common broadcaster; it does not itself make the entire experiment classical.

## 3 Finite centralization preserving the entire family

Now let F contain faithful σ and satisfy σ/2≤ρ≤3σ/2, with broadcaster error u. Let S=sqrtσ, M_s=sqrt(3/2), and

X_ρ=S⁻¹(SρS)^(1/2)S⁻¹.

Then X_ρσX_ρ=ρ and 0≤X_ρ≤M_sI. The polar decomposition Ssqrtρ=WP gives X_ρS=sqrtρ W*, P≥ρ/M_s, and

||[X_ρ,S]||₂≤2sqrt(2M_sΔ(σ,ρ))≤Ξ(u):=2sqrt(2M_s v(u)).

To check this, put K=2I−W−W*≥0; Tr(PK)=2Δ and ||X_ρS−sqrtρ||₂²=Tr(ρK)≤2M_sΔ. Add the adjoint difference.

For 0<t≤1, randomly shift width-t logarithmic spectral bins of S; write D_u for the resulting pinching. Pair separation probability is at most 3|s_i−s_j|/[t(s_i+s_j)]. Cauchy–Schwarz on matrix entries gives

E_u||(X_ρ−D_uX_ρ)S||₂²≤3M_sΞ/t,
E_u||D_uρ−ρ||₁≤4sqrt(3M_sΞ/t).

The second estimate follows by comparing ρ=X_ρσX_ρ with the block-diagonal surrogate (D_uX_ρ)σ(D_uX_ρ), then using pinching contraction. It is uniform in ρ, with the SAME shift distribution.

Flatten S within each bin to its lower endpoint and normalize to obtain S′_u. Then e^(−t)S≤S′_u≤e^tS. Let σ′_u=(S′_u)², A_u=e^(−t)S′_uS⁻¹, and define

C_u(Z)=A_uD_u(Z)A_u+Tr[(I−A_u²)Z]σ′_u.

This is CPTP, C_uσ=σ′_u, and it preserves the sandwich order exactly. Because e^(−2t)I≤A_u≤I, it differs from D_u by at most 8t in trace norm on every density matrix.

Only finitely many distinct C_u occur: bin assignments change at at most d residues, and the common exp(u) cancels in normalization. Retaining interval lengths as probabilities defines a finite flagged encoder Enc and decoder Dec with

sup_(ρ∈F)||Dec Encρ−ρ||₁≤c(u,t):=4sqrt(3M_sΞ(u)/t)+8t.

The encoded family and reference lie in a finite direct sum of matrix blocks, and the reference σ_F is faithful and CENTRAL there. The full-domain broadcaster (Enc⊗Enc)B Dec has error at most u+c/2 on encoded states. Conversely any one EB reconstruction on encoded states yields DecΛEnc with error at most its encoded error plus c/2.

Take t=min{1,Ξ(u)^(1/3)} for u>0. Then c(u):=c(u,t)→0. At u=0 use the exact zero-gap limit or spectral blocks. This step uses a finite common linear encoder, not a state-dependent filter or a selected shift for each label.

## 4 Exact reference correction and the common comparator

Pinch inputs and outputs onto the encoded direct-sum algebra A. All promised states are unchanged. Symmetrize the broadcaster, with common marginal T and halftrace error w=u+c(u)/2. The actual CPTP Petz recovery

R(Y)=σ_F^(1/2)T*(ν^(−1/2)PYPν^(−1/2))σ_F^(1/2)+Tr[(I−P)Y]σ_F,
ν=Tσ_F, P=suppν,

satisfies Rν=σ_F. Applying R to BOTH outputs yields a self-compatible marginal S=RT, preserving σ_F exactly. In the sandwiched Rényi-2 Hilbert coordinates this map is V*V for a contraction V, hence positive selfadjoint. Direct expansion on θ-sandwich states, using Powers–Størmer and trace Hölder, gives

||Sρ−ρ||₁≤sqrt[2θ(d_ρ+d_σ)+6θ²sqrt(d_σ)],
d_ρ=||Tρ−ρ||₁, d_σ=||Tσ_F−σ_F||₁.

Indeed Q loss is bounded by the expression in brackets, while (I−V*V)²≤I−V*V bounds squared Q recovery error by that loss; trace norm is at most Q norm. For θ=1/2 and d_ρ,d_σ≤2w, the uniform fulltrace residual is therefore

r(w)=sqrt[4w+(3/2)sqrt(2w)].

Because σ_F is central in A, τ(a)=Tr(σ_Fa) is a faithful normalized TRACE. The likelihood map Φ=S* is UCP, τ-preserving, positive τ-selfadjoint and genuinely self-compatible. The identity S(σ_Fa)=σ_FΦ(a) identifies its L¹(τ) residual with the physical trace residual. Nontracial KMS/GNS norms are never interchanged.

The independently proved weighted-tracial comparator theorem now supplies ONE finite POVM E_y in A and

Ψ(a)=Σ_y τ(E_ya)E_y/τ(E_y),
I−Ψ≤4(I−Φ).

Its physical channel prepares σ_FE_y/τ(E_y), so it is an ordinary EB channel fixing σ_F. The proof is exactly the broadcast-tree covariance and arbitrary-observable regression proof of C4, using joint reference state τ∘J; it works for arbitrary positive central block weights and block-changing Φ. Fixed-dimension compactness gives a finite POVM. There is no uniform outcome-count promise.

For every encoded likelihood ρ=σ_F(I+H), ||H||∞≤θ, τH=0,

||Ψ_physρ−ρ||₁²≤||(I−Ψ)H||²_(2,τ)
≤⟨H,(I−Ψ)H⟩_τ≤4⟨H,(I−Φ)H⟩_τ≤4θr(w).

Thus its uniform halftrace error is at most sqrt(θr(w)). Decoder composition proves for the original sandwich family

e(F)≤h(u):=min{1,c(u)/2+sqrt[r(u+c(u)/2)/2]},             (C)

with h(0)=0 and h(u)→0. All channels in this argument were chosen for the entire experiment before the unknown label was presented.

## 5 Closing the uniform limit

Combine (B) and (C). For each 0<δ<1/2, with the fixed C-dependent parameters above,

e(E)≤min{1,2δ+[(2−a)/a]h(min{1,g(C,δ,b)})}

whenever a broadcaster has error at most b. Infimize over δ to define f_C(b). For any target accuracy choose δ first, then let b↓0; g→0 and h→0 at that fixed δ. Hence f_C(b)→0. Compactness of finite-dimensional channels, or an arbitrarily small slack in b, handles the infimum defining b₂. The b₂=0 case follows by the same limiting estimate, with compactness of the EB channel set ensuring one exact EB reconstruction if desired.

The actual final channel on the original Hilbert space is the support inclusion composed with Dec, Ψ_phys, Enc, and the support-compression channel, in that order. Neither the nonlinear optimizer smoothing nor the affine undilution is implemented on the unknown state; they appear only in channelwise error inequalities that apply to this one actual channel.

This proves the stated theorem, including arbitrarily growing dimensions, arbitrary family cardinalities, and one common finite-outcome EB channel for each experiment.

For completeness, the reverse implication needs no capacity assumption: an EB representation Λ(ρ)=Σ_y Tr(E_yρ)ω_y yields a broadcaster B_k(ρ)=Σ_y Tr(E_yρ)ω_y^⊗k for every finite k, all of whose marginals equal Λ. Hence b₂(E)≤e(E), and the theorem proves a uniform approximate equivalence within each bounded-capacity class. It also upgrades two-receiver approximate broadcasting to arbitrary finite receiver counts at the same reconstruction error bound, with no claim that the outputs are unconditional independent copies.

## Verification, provenance, and boundaries

The full chain uses established quantum substate and sandwiched Rényi-2 data-processing results, together with standard fidelity concavity/monotonicity, Pinsker, Helstrom measurements, Lieb affinity concavity, Powers–Størmer, and finite-dimensional convex geometry. The new load-bearing final ingredient is the common C4 comparator, extended to arbitrary finite tracial algebras.

Independent audit records in this directory:
- WEIGHTED_TRACE_EXTENSION.md (exact comparator interface and physical representation)
- CAPACITY_SMOOTHING_INDEPENDENT_AUDIT.md (capacity center, imports, smoothing, dilution and quantifiers)
- N93_CHAIN_AUDIT.md (source-to-interface mapping and centralization/Petz checks; initial conditional status is historical)
- the separate N46 pair-bridge audit when saved

Source pin: harjassand/astra-research-knowledge 99a9d763558c3c7d329d3bdeb64905187cb5429c; decisive original proof pages d-b4ddaa96b233287d, d-c851b6e4ba719edf, d-48ed31af9b1d38fd, d-3309c2d38e9bf616. The comparator manuscript is Library libfile_f3c44709b11c8191af2b29a144f2b059. The initial C4 audit and nonselfadjoint power extension remain separately frozen.

Historical priority has not been established. In particular the binary extraction mechanism has earlier information-chain/Markov-blanket precedents; no novelty is claimed for those components. This theorem supplies an experiment-wise robust classicality conclusion under bounded Holevo CAPACITY. It must not be advertised as unrestricted operational classicalization, a diamond-norm theorem, or resolution of unrelated quantum-information conjectures.

### Established primary imports

- Jain and Nayak, quantum substate theorem, Theorem 1 and the observational-relative-divergence comparison: https://arxiv.org/abs/1103.6067
- Beigi, sandwiched Rényi data processing at alpha=2: https://arxiv.org/abs/1306.5920
- Gao, Li, Marvian and Rouzé, quadratic recovery inequality, independently reproduced here: https://arxiv.org/abs/2302.02341
- Qi and Ranard, information-chain/posterior-preparation precedent for binary extraction: https://arxiv.org/abs/2001.01507
- Li and Smith, fully adaptive measurement de Finetti precedent: https://arxiv.org/abs/1408.6829

These citations identify imported ingredients and neighboring methods, not a priority assessment of the stitched theorem.
