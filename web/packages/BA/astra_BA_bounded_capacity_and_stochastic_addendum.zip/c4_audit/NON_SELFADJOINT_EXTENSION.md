# Bistochastic channels without self-adjointness

Independent consequence derived and checked on 9 October 2026 UTC from the common spectral comparator theorem. This is a mathematical extension established within this review, with a second independent analytic check. Historical novelty is not established.

## The theorem

Let Φ:M_d→M_d be a completely positive, trace-preserving, unital channel that has an r-output self-compatible broadcaster, r≥2. No Hilbert–Schmidt self-adjointness or normality is assumed. Put τ=Tr/d and κ=2r/(r−1).

There exists a single finite canonical, unital, trace-preserving, HS-positive/selfadjoint entanglement-breaking channel Ψ such that

I−Ψ ≤ κ(I−Φ*Φ) ≤ 2κ[I−(Φ+Φ*)/2]

in HS quadratic-form order. In particular, for every Hermitian A,

τ[A(A−Ψ(A))] ≤ [4r/(r−1)] τ[A(A−Φ(A))].

For r=2 this gives the universal common comparator constant 8 for every bistochastic self-compatible channel.

For every integer n≥0 the channel

Λ_n = (1/(n+1)) Σ_(j=0)^n Φ^(n−j) Ψ Φ^j

is entanglement breaking and satisfies

||Φⁿ−Λ_n||₂→₂ ≤ sqrt[κ/(n+1)].

More precisely, for every A,

||(Φⁿ−Λ_n)(A)||₂,τ² ≤ [κ/(n+1)] (||A||₂,τ²−||Φ^(n+1)(A)||₂,τ²).

The same upper bound sqrt[κ/(n+1)] holds for the normalized Hermitian ∞→1 norm. For a binary broadcaster κ=2·2/(2−1)=4, so the bound is sqrt[4/(n+1)]=2/sqrt(n+1).

## Proof of the comparator

Bistochasticity makes Φ* completely positive, trace preserving, and unital. If B broadcasts Φ, then

B′=(Φ*⊗...⊗Φ*)∘B

broadcasts Θ=Φ*Φ. Indeed trace-preserving maps on the other r−1 outputs disappear under partial trace. The map Θ is bistochastic, HS-selfadjoint, and HS-positive. Its spectrum lies in [0,1].

Apply the independently audited theorem to Θ. It supplies Ψ with

I−Ψ ≤ [r/(r−1)](I−Θ²) ≤ [2r/(r−1)](I−Θ).

The last inequality is scalar functional calculus on [0,1]. Thus I−Ψ≤κ(I−Φ*Φ).

Also

2[I−(Φ+Φ*)/2]−(I−Φ*Φ) = (I−Φ)*(I−Φ) ≥ 0.

Combining these proves the asserted Dirichlet bound. For Hermitian A the scalar τ[AΦ(A)] is real and equals the quadratic form of (Φ+Φ*)/2, so the statement is exactly the original deficit expression, not an altered observable functional.

## Proof of the power approximation

Let K=I−Ψ. Every bistochastic channel is an HS contraction by Kadison's inequality and trace preservation. Since Ψ is also HS-positive and selfadjoint, 0≤Ψ≤I, and therefore

K²≤K≤κ(I−Φ*Φ).

Each Φ^(n−j) Ψ Φ^j is a channel and EB because composition before or after an EB channel preserves EB. Their convex average Λ_n is consequently EB.

The exact error identity is

(Φⁿ−Λ_n)(A) = (1/(n+1)) Σ_(j=0)^n Φ^(n−j) K Φ^j(A).

Jensen's inequality for squared Hilbert-space norm and contraction of the left channel power give

||(Φⁿ−Λ_n)(A)||₂,τ²
≤ (1/(n+1)) Σ_(j=0)^n ||KΦ^j(A)||₂,τ²
≤ (κ/(n+1)) Σ_(j=0)^n ⟨Φ^j(A),(I−Φ*Φ)Φ^j(A)⟩_τ
= (κ/(n+1)) Σ_(j=0)^n [||Φ^j(A)||₂,τ²−||Φ^(j+1)(A)||₂,τ²]
= (κ/(n+1)) [||A||₂,τ²−||Φ^(n+1)(A)||₂,τ²].

This telescoping proof uses neither normality nor any commutation with Ψ. Taking a supremum proves the induced norm estimate. Applying ||A||₂,τ≤||A||∞ and ||X||₁,τ≤||X||₂,τ proves the normalized Hermitian ∞→1 bound. Hermiticity preservation extends the HS estimate to arbitrary complex A by decomposition into Hermitian real and imaginary parts.

## Interpretation and exact boundaries

The new comparator argument uses the reversible channel Φ*Φ solely as an auxiliary object. The approximated powers remain those of the original nonnormal Φ. Averaging the insertion position of a single Ψ is essential in this proof: it converts possibly transient dissipation into a telescoping bound. This avoids incorrectly applying spectral functional calculus to a nonnormal channel.

This strengthens the scope of the source manuscript's power-approximation corollary: tracial/bistochastic self-compatible channels suffice. It does not improve the source's sharper finite-n bound sqrt[2nⁿ/(n+1)^(n+1)] when self-adjointness is available. It does not claim C=4 for non-selfadjoint channels, or C=2 in either class.

For state reconstruction with bounded tracial perturbations ||A_x||∞≤M and residual trace norm≤ε, the extended Dirichlet bound similarly gives a single comparator with error at most sqrt[8Mε] in the binary case. Unbounded state families and full bounded-Holevo control are not covered.

No conclusion in this record is in diamond norm. Bistochasticity is used twice: for HS contraction and to make Φ* a channel, so it cannot simply be omitted.

## Arithmetic correction recorded before release

An early chat summary and a draft binary specialization incorrectly gave sqrt[2/(n+1)] for the non-selfadjoint extension. The proved general constant is κ=2r/(r−1), which equals 4 at r=2. The correct binary extension bound is 2/sqrt(n+1). The original self-adjoint theorem retains its stronger sqrt[2/(n+1)] bound (and sharper finite-n expression). The general proof, C8 comparator, and all other constants are unchanged.
