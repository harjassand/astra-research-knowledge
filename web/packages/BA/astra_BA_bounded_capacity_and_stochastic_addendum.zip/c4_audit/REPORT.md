# Independent audit of the common comparator theorem

Date: 9 October 2026 UTC.
Source: Library `libfile_f3c44709b11c8191af2b29a144f2b059`, `common_classical_comparator.md`, created 8 October 2026 17:58:10 UTC. All 473 lines read. Source copy: `source_common_classical_comparator.md`.

## Verdict

**The mathematical argument passes this independent analytic audit.** Theorem 1 supplies a single finite canonical entanglement-breaking comparator with binary constant 4 on the entire Hermitian observable space. No missing inference or counterexample was found. A separate skeptical reconstruction also checked the covariance recursion, negative eigenvalues, full-space regression, and compactness successfully. This is independently reconstructed mathematical reasoning by AI reviewers, not human peer review, proof-assistant certification, or a historical-priority result.

The proof closes the previously open finite-universal-constant gate recorded in the earlier arbitrary-frame review, under its stated tracial, HS-selfadjoint, self-compatible hypotheses. It does not close the sharp constant-two conjecture. The lower control remains 2 and the upper bound 4.

**A further rigorously derived extension removes HS self-adjointness:** every finite-dimensional bistochastic r-self-compatible channel admits a canonical comparator with Dirichlet constant 4r/(r−1), hence binary constant 8. Its powers admit EB approximants with induced HS error at most sqrt[2r/((r−1)(n+1))], with no normality assumption. For r=2 this is 2/sqrt(n+1), since 2r/(r−1)=4. See `NON_SELFADJOINT_EXTENSION.md`. This extension has also passed the independent skeptical calculation.

## Reconstruction of the decisive argument

Let τ=Tr/d and let Φ be bistochastic, HS-selfadjoint, and r-self-compatible, r≥2. Symmetrize a broadcaster B over output permutations. Pick a τ-orthonormal Hermitian basis A_i of the traceless eigenspaces with |λ_i|>1/sqrt(r), and put D=diag(λ_i). Set σ=B(I/d). Every one-output marginal of σ is I/d. The real matrix T_ij=Tr[σ A_i^(1) A_j^(2)] is symmetric, and

vᵀ(I−T)v = (1/2) Tr[σ(A(v)^(1)−A(v)^(2))²] ≥ 0.

Thus T≤I as a whole matrix, without assuming product outputs.

Randomly select one spectral measurement of the A_i, with probability 1/m each. The effects E_(i,a)=P_(i,a)/m and estimators z_j(i,a)=m a δ_ij satisfy Σ_y z_i(y)E_y=A_i and covariance C_0=mI under outcome weights τ(E_y).

For any such unbiased POVM, define a new POVM E'_(y_1,...,y_r)=B*(E_y1⊗...⊗E_yr), and z'_i=(Σ_a z_i(y_a))/(rλ_i). The POVM is physical because B* is CP and unital. Each first moment remains A_i because B*(A_i^(a))=Φ*(A_i)=λ_i A_i. The covariance is exactly

C_(n+1) = (1/r)D⁻¹[C_n+(r−1)T]D⁻¹.

Same-child terms give C_n by the tracial marginals. Distinct-child terms give T by unbiasedness. This derivation retains every off-diagonal term and never assumes sibling independence.

The map L(M)=D⁻¹MD⁻¹/r preserves positive-semidefinite order even with negative eigenvalues. The positive diagonal H=(r−1)(rD²−I)⁻¹ obeys H=L(H+(r−1)I). Therefore

C_n ≤ H+Lⁿ(mI−H).

The norm of L is q=max_i 1/(rλ_i²)<1, so the remainder tends to zero in operator norm. Separately C_n≥I: for any scalar estimator w_y with M=Σw_yE_y, the positive identity Σ(w_yI−M)E_y(w_yI−M)=Σw_y²E_y−M² gives this after tracing. Thus the exact limit C_infinity is positive definite and bounded by H.

For each finite POVM, put p_y=τ(E_y), ρ_y=E_y/Tr(E_y), and let Ψ_n(X)=ΣTr(E_yX)ρ_y. Zero effects can be omitted. This is CP, TP, unital, EB, HS-positive, and HS-selfadjoint. For ANY traceless Hermitian A, put u_A(y)=Tr(ρ_yA), β_i=τ(AA_i). Then

E[u_A z_i]=β_i, and τ[AΨ_n(A)]=E[u_A²].

The scalar inequality E[(u_A−vᵀz)²]≥0 yields

τ[AΨ_n(A)] ≥ 2vᵀβ−vᵀC_n v.

This is the critical full-space statement. A need not lie in the selected eigenspace. It controls interactions with omitted directions automatically, unlike a bound on only a principal block.

Canonical channels are the finite-dimensional moments of probability measures on the compact density-matrix set with barycenter I/d. This moment set is compact. Choose any convergent subsequence of Ψ_n, independent of A. Passing the preceding inequality to its limit and taking v=H⁻¹β gives

τ[AΨ(A)] ≥ βᵀH⁻¹β = Σ_i [(rλ_i²−1)/(r−1)] τ(AA_i)².

The identity direction is fixed and has no cross terms with traceless directions. Thus Ψ ≥ f_r(Φ), where f_r(t)=max(0,(rt²−1)/(r−1)), in real HS operator order. The case m=0 is handled by the completely depolarizing channel.

Carathéodory's theorem preserves both barycenter and quadratic moments with finite support; hence the limit is an actual finite ensemble. Refining each state into pure states preserves barycenter and increases every quadratic moment by Jensen, giving the pure option. None of these steps takes a dimension limit or promises an efficient apparatus.

Finally 1−f_r(t)≤r(1−t²)/(r−1)≤2r(1−t)/(r−1) on [−1,1]. This proves the source theorem and binary constant 4.

## Consequences independently checked

1. Summation over arbitrary finite Hermitian frames gives V−k≤4(V−s_Φ). Nonnegative weights may be absorbed into the observables. A single comparator already exists before any frame is chosen.
2. Let Λ_n=ΨΦⁿ. Since 0≤Ψ≤I in HS order, (I−Ψ)²≤I−Ψ≤2(I−Φ²). Applying this quadratic inequality to ΦⁿA and maximizing xⁿ(1−x) gives ||Φⁿ−Λ_n||₂→₂≤sqrt[2nⁿ/(n+1)^(n+1)]. No Ψ–Φ commutation is used.
3. Tr_HS Ψ=dΣp_yTr(ρ_y²)≤d, so tracing spectral domination gives Σ_j(rλ_j²−1)_+≤(r−1)(d−1).
4. Bounded tracial perturbations ρ_x=(I+A_x)/d, ||A_x||∞≤M, and sup_x||ρ_x−Φρ_x||₁≤ε satisfy sup_x||ρ_x−Ψρ_x||₁≤2sqrt(Mε). The exact hypotheses are necessary to claim this corollary.
5. The universal symmetric cloner gives λ=(d+2)/(2(d+1)) on the traceless subspace, and any TP EB comparator has HS trace≤d. The full traceless frame therefore forces C≥2. The source's lower-bound algebra is correct.

All HS norms use the normalized trace; normalization cancels in induced 2→2 norms. Bounds first checked on Hermitian A extend to complex matrices because Hermiticity-preserving maps act separately on real and imaginary Hermitian parts and their squared HS norms add. The normalized Hermitian ∞→1 norm is smaller. There is no diamond-norm conclusion.

## Boundary against prior failed routes

The earlier review's exact affine-rounding gate was genuinely open there. The new construction does not prove that a spectral positive-part map is CP. It constructs a separate physical POVM, then a canonical EB channel dominating an abstract spectral quadratic form. It also does not substitute noncommuting observables into a scalar-positive polynomial. Regression concerns classical finite POVM outcomes only.

The new ingredient is not just scalar reconstruction for each slow mode. It is simultaneous finite unbiased estimation with matrix covariance control, followed by regression against arbitrary observables and a common fixed-dimension limit. That combination supplies precisely the common-measurement inference missing in diagonal or per-observable arguments.

## Remaining scope and novelty

Historical priority and significance beyond the identified Astra gate remain unestablished. The source's literature list is not proof that no earlier theorem implies its result. A primary-literature novelty check is appropriate before a publication claim.

The full bounded-Holevo reconstruction problem is not resolved by the bounded tracial perturbation corollary. The present extension removes self-adjointness but retains bistochasticity. Nontracial channels require a different reference-state geometry; weighted adjoints need not have the channel properties used here. Diamond-norm approximation, dimension-free outcome counts, finite exact EB indices, and the sharp binary C=2 comparator remain open in this work.

No numerical searches, paid jobs, external publication, or public repository edits were performed for this audit. The old stopped numerical programmes were not restarted.
