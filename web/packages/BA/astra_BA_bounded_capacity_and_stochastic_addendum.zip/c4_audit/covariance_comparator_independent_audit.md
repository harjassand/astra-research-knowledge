# Independent covariance-comparator and non-normal powers audit

Conclusion: the construction is valid. No fatal error was found. Assume finite d and integer r >= 2. When there are no selected traceless eigenobservables, use the completely depolarizing channel instead of the m-outcome-index initialization.

## Covariance recursion

Let tau = Tr/d, let omega = B(I/d), and choose tau-orthonormal Hermitian eigenobservables A_i with |lambda_i| > 1/sqrt(r). The output marginals of omega are I/d. Consequently the one-site covariance contribution is C, whereas every ordered distinct-site contribution is T_ij = Tr omega A_i^(1) A_j^(2). Symmetry makes T real symmetric. For A = sum_i x_i A_i,

x^T (I-T) x = (1/2) Tr omega (A^(1)-A^(2))^2 >= 0.

Thus T <= I. The recursively defined estimator remains unbiased because B*(A_i^(a)) = lambda_i A_i. Its covariance is exactly

C_next = D^(-1) [C + (r-1)T] D^(-1) / r.

Congruence by D^(-1) is order preserving even for negative eigenvalues. With H = (r-1)(rD^2-I)^(-1), q = max_i 1/(r lambda_i^2) < 1, and epsilon_n = q^n ||mI-H||, iteration yields C_n <= H + epsilon_n I.

## Full operator comparison

For any Hermitian traceless A, set beta_i = tau(A A_i), p_y = Tr(E_y)/d, rho_y = E_y/Tr(E_y), and u_y = Tr(rho_y A). Zero effects are omitted. The canonical EB map satisfies

tau(A Psi_n(A)) = E[u^2],   E[u z_i] = beta_i.

Hence for every real v,

tau(A Psi_n(A)) >= 2v^T beta - v^T C_n v.

Taking v = H^(-1) beta gives the full quadratic-form comparison, including cross blocks between selected and unselected eigenspaces. Since H^(-1) <= I,

Psi_n >= f_r(Phi) - epsilon_n P_strong,

where identity is handled exactly and f_r(t) = max(0, (r t^2-1)/(r-1)). A common subsequential limit therefore satisfies Psi >= f_r(Phi). This is Hilbert-Schmidt superoperator order, not completely positive order.

The canonical set is itself closed: normalized Choi(Psi_n) is a convex combination of rho^T tensor rho over density matrices rho. Their convex hull is compact. The limit has a finite convex representation, whose marginal I/d supplies effects E_y = d p_y rho_y, recovering the same canonical formula.

Canonical maps are positive selfadjoint contractions on complex Hilbert-Schmidt space, so 0 <= Psi <= I. All comparisons extend from Hermitian inputs to arbitrary complex inputs. In particular,

I-Psi <= [r/(r-1)](I-Phi^2) <= [2r/(r-1)](I-Phi).

## General bistochastic channels and powers

Let Phi now be any bistochastic r-self-compatible channel. Its adjoint is CPTP. The symmetric broadcaster (Phi* tensor ... tensor Phi*) composed with B has marginal Theta = Phi*Phi. Thus Theta is bistochastic, HS-positive, HS-selfadjoint, and r-self-compatible.

Applying the previous result gives a canonical EB Psi with K = I-Psi and

0 <= K <= I,   K^2 <= K <= kappa(I-Phi*Phi),   kappa = 2r/(r-1).

Also I-Phi*Phi <= 2I-Phi-Phi*, since the difference equals (I-Phi)*(I-Phi). Thus K <= [4r/(r-1)](I-(Phi+Phi*)/2).

For n >= 0 define

Lambda_n = (1/(n+1)) sum_{j=0}^n Phi^(n-j) Psi Phi^j.

Every summand is EB and bistochastic, so Lambda_n is EB and bistochastic. Importantly, it approximates Phi^n, not Phi^(n+1). Its exact error is the average of Phi^(n-j) K Phi^j. Jensen, HS contractivity, and the defect comparison give, for every complex A,

||(Phi^n-Lambda_n)A||_2^2
 <= (kappa/(n+1)) sum_{j=0}^n (||Phi^j A||_2^2-||Phi^(j+1) A||_2^2)
 = (kappa/(n+1))(||A||_2^2-||Phi^(n+1) A||_2^2).

Therefore

||Phi^n-Lambda_n||_(2->2) <= sqrt(2r / ((r-1)(n+1))).

For binary self-compatibility (r = 2), kappa = 4 and this generic nonselfadjoint powers bound is 2/sqrt(n+1). The corresponding symmetrized-defect constant is 8.

No normality, commutation, or selfadjointness of the original Phi is used. The dimension-free claim concerns induced HS norm; it does not imply a dimension-free diamond-norm bound.
