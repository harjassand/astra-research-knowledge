# A common classical comparator from a self-compatible tracial quantum channel

Research record — 9 October 2026

**Status.** This note supplies a complete finite-dimensional mathematical argument. Its elementary identities have been checked symbolically and its finite-measurement recursion has been tested on an explicit noncommuting qutrit fixture. These checks are not proof-assistant certification or independent expert review. Historical novelty and historic-scale significance have not been established. No theorem from the OpenAI manuscript collection is assumed as a premise.

## 1. Exact statement

Write \(M_d=M_d(\mathbb C)\), \(\tau(X)=\operatorname{Tr}(X)/d\), and equip the real space of Hermitian matrices with \(\langle A,B\rangle_\tau=\tau(AB)\). The identity matrix is denoted by \(I\); the identity superoperator by \(\mathsf I\). All superoperator inequalities below are quadratic-form inequalities on this real Hilbert space, not inequalities in completely positive order.

A channel is a completely positive, trace-preserving linear map. Call \(\Phi:M_d\to M_d\) **r-self-compatible** if there is a channel \(\mathcal B:M_d\to M_d^{\otimes r}\) whose every one-register marginal equals \(\Phi\).

**Theorem 1 (common spectral comparator).** Let \(r\ge2\) be an integer. Suppose that \(\Phi\) is unital, Hilbert–Schmidt self-adjoint, and r-self-compatible. There is a single finite-ensemble channel

\[
\Psi(X)=d\sum_y p_y\operatorname{Tr}(\rho_yX)\rho_y,
\qquad p_y\ge0,\quad \sum_y p_y=1,\quad
\sum_y p_y\rho_y=I/d,
\tag{1}
\]

such that

\[
\Psi\succeq f_r(\Phi),\qquad
f_r(t)=\left(\frac{rt^2-1}{r-1}\right)_+.
\tag{2}
\]

The channel \(\Psi\) is entanglement breaking, unital, trace preserving, Hilbert–Schmidt self-adjoint, and positive as a Hilbert–Schmidt operator. The ensemble can be taken to consist of pure states. In particular,

\[
\mathsf I-\Psi
\preceq \frac r{r-1}(\mathsf I-\Phi^2)
\preceq \frac{2r}{r-1}(\mathsf I-\Phi).
\tag{3}
\]

Thus, for a two-output broadcaster,

\[
\boxed{\quad
\tau[A(A-\Psi(A))]\le4\tau[A(A-\Phi(A))]
\quad\text{for every Hermitian }A.
\quad}
\tag{4}
\]

The same channel works for every observable, every frame, and every weighting. Neither a spectral gap nor positivity of \(\Phi\) as a Hilbert–Schmidt operator is assumed. Dimension and measurement size are unrestricted but finite. No dimension-independent computational or apparatus-size bound is asserted.

Importantly, (2) does **not** assert that \(f_r(\Phi)\) is itself a positive map or a channel. A separate physical channel dominates that abstract quadratic form.

## 2. Proof

### 2.1. Spectral setup and a joint second-moment bound

Kadison's inequality and preservation of trace give

\[
\|\Phi(A)\|_{2,\tau}^2\le\tau(\Phi(A^2))=\|A\|_{2,\tau}^2.
\]

Since \(\Phi\) is self-adjoint, it has an orthonormal Hermitian eigenbasis with real eigenvalues in \([-1,1]\). The identity direction has eigenvalue one, and the traceless subspace is invariant.

Choose an orthonormal basis \(A_1,\ldots,A_m\) of all traceless eigenspaces with \(|\lambda_i|>r^{-1/2}\), so that

\[
\Phi(A_i)=\lambda_iA_i,\qquad \tau(A_iA_j)=\delta_{ij}.
\tag{5}
\]

If \(m=0\), the completely depolarizing channel proves the theorem. Assume henceforth \(m\ge1\).

Average the broadcaster over permutations of its outputs. This preserves all its one-register marginals. Put \(\sigma=\mathcal B(I/d)\). Every one-register marginal of \(\sigma\) is \(I/d\). Define the real symmetric matrix

\[
T_{ij}=\operatorname{Tr}\bigl[\sigma A_i^{(1)}A_j^{(2)}\bigr].
\tag{6}
\]

Symmetry follows from permutation invariance. For \(A(v)=\sum_i v_iA_i\), positivity of \((A(v)^{(1)}-A(v)^{(2)})^2\) implies

\[
0\le 2\tau(A(v)^2)-2\operatorname{Tr}[\sigma A(v)^{(1)}A(v)^{(2)}]
=2v^\mathsf T(I_m-T)v.
\]

Consequently,

\[
T\preceq I_m.
\tag{7}
\]

No product-state assumption on \(\sigma\) is used.

### 2.2. A finite measurement with unbiased estimators

Write the spectral decomposition \(A_i=\sum_a aP_{i,a}\). Define a finite POVM and its real vector-valued estimator by

\[
E^{(0)}_{i,a}=P_{i,a}/m,
\qquad z_j^{(0)}(i,a)=m a\,\mathbf1_{i=j}.
\tag{8}
\]

This is the experiment that chooses one eigenobservable uniformly and measures it. Its operator first moments and reference second moments are

\[
\sum_y z_i^{(0)}(y)E_y^{(0)}=A_i,
\qquad
C_{0,ij}:=\sum_y\tau(E_y^{(0)})z_i^{(0)}(y)z_j^{(0)}(y)
=m\delta_{ij}.
\tag{9}
\]

Construct subsequent finite POVMs recursively. Given \(E^{(n)}\), set

\[
E^{(n+1)}_{y_1,\ldots,y_r}
=\mathcal B^*\left(E^{(n)}_{y_1}\otimes\cdots\otimes E^{(n)}_{y_r}\right),
\tag{10}
\]

\[
z_i^{(n+1)}(y_1,\ldots,y_r)
=\frac{\sum_{a=1}^r z_i^{(n)}(y_a)}{r\lambda_i}.
\tag{11}
\]

Complete positivity and unitality of \(\mathcal B^*\) show that (10) is a POVM. If its predecessor has first moments \(A_i\), then

\[
\sum_{\mathbf y} z_i^{(n+1)}(\mathbf y)E_{\mathbf y}^{(n+1)}
=\frac1{r\lambda_i}\sum_{a=1}^r\mathcal B^*(A_i^{(a)})
=\frac1{r\lambda_i}\sum_{a=1}^r\Phi^*(A_i)=A_i.
\tag{12}
\]

Here \(\Phi^*=\Phi\) is essential. Thus the estimators are exactly unbiased at every finite depth. Operationally, this is an r-ary broadcast tree, with independent randomized spectral measurements at its leaves. Incompatible observables are never measured together on a single leaf.

### 2.3. Exact matrix covariance recursion

Let

\[
C_{n,ij}=\sum_y\tau(E_y^{(n)})z_i^{(n)}(y)z_j^{(n)}(y),
\qquad D=\operatorname{diag}(\lambda_1,\ldots,\lambda_m).
\]

Expanding (11), there are \(r\) same-output terms and \(r(r-1)\) distinct-output terms. The former have expectation \(C_{n,ij}\), since each marginal of \(\sigma\) is tracial. By the exact operator first-moment identity (12), every latter term has expectation \(T_{ij}\). Therefore,

\[
\boxed{\quad
C_{n+1}=\frac1rD^{-1}\bigl(C_n+(r-1)T\bigr)D^{-1}.
\quad}
\tag{13}
\]

This is a matrix identity, including off-diagonal entries; bounding only its diagonal would not suffice.

Put

\[
\mathcal L(M)=\frac1rD^{-1}MD^{-1},
\qquad H=(r-1)(rD^2-I_m)^{-1}.
\tag{14}
\]

The map \(\mathcal L\) preserves positive-semidefinite order even when some \(\lambda_i\) are negative: it is a congruence map. Also,

\[
H\succeq I_m,\qquad H=\mathcal L\bigl(H+(r-1)I_m\bigr).
\tag{15}
\]

From (7), (13), and (15), induction yields

\[
C_n\preceq H+\mathcal L^n(C_0-H).
\tag{16}
\]

Every \(r|\lambda_i\lambda_j|>1\), so \(\mathcal L^n(M)\to0\) for every fixed \(m\)-by-\(m\) matrix. Hence

\[
C_n\preceq H+o(1)I_m.
\tag{17}
\]

More explicitly, the entries converge to

\[
(C_\infty)_{ij}=\frac{(r-1)T_{ij}}{r\lambda_i\lambda_j-1}.
\tag{18}
\]

For completeness, \(C_n\succeq I_m\). For any POVM \((E_y)\), scalars \(w_y\), and \(M=\sum_yw_yE_y\), the identity

\[
\sum_y w_y^2E_y-M^2
=\sum_y(w_yI-M)E_y(w_yI-M)\succeq0
\]

proves this after taking \(w_y=v^\mathsf Tz^{(n)}(y)\), using (12), and taking the normalized trace. Thus \(I_m\preceq C_\infty\preceq H\). This also proves directly that the inverse in the sharper statement below exists.

The only initial penalty for measuring different observables is \(C_0=mI_m\). Equation (16) shows that this penalty disappears in the supercritical spectral subspace. No approximate-commutation theorem or infinite-dimensional measurement is needed.

### 2.4. Regression produces one physical comparator on the full space

For each depth, discard zero POVM effects and write

\[
p_{n,y}=\tau(E_y^{(n)}),\qquad
\rho_{n,y}=E_y^{(n)}/\operatorname{Tr}(E_y^{(n)}).
\]

The associated canonical measure-and-prepare channel is

\[
\Psi_n(X)=\sum_y\operatorname{Tr}(E_y^{(n)}X)\rho_{n,y}.
\tag{19}
\]

Because \(\sum_yp_{n,y}\rho_{n,y}=I/d\), it is unital and trace preserving. Its displayed representation proves complete positivity and entanglement breaking. Moreover,

\[
\tau(A\Psi_n(A))=\sum_y p_{n,y}\bigl(\operatorname{Tr}(\rho_{n,y}A)\bigr)^2,
\tag{20}
\]

which proves Hilbert–Schmidt self-adjointness and positivity.

Fix **any** traceless Hermitian \(A\), not necessarily a linear combination of the selected eigenvectors. Define

\[
u_A(y)=\operatorname{Tr}(\rho_{n,y}A),\qquad
\beta_i=\tau(AA_i).
\]

The exact first-moment identity gives

\[
\mathbb E_{p_n}[u_Az_i^{(n)}]
=\tau\left(A\sum_yz_i^{(n)}(y)E_y^{(n)}\right)=\beta_i.
\tag{21}
\]

For every \(v\in\mathbb R^m\), positivity of the ordinary scalar square \((u_A-v^\mathsf Tz^{(n)})^2\) now gives

\[
\tau(A\Psi_n(A))\ge2v^\mathsf T\beta-v^\mathsf TC_nv.
\tag{22}
\]

This inequality holds for all \(A\) for the **same** \(\Psi_n\).

Canonical channels on the fixed space \(M_d\) form a compact set. To see this without an outcome-cardinality assumption, identify an ensemble with a probability measure on the compact set of density matrices. Its barycenter and its quadratic moment (20) are continuous functions of that measure. Measures with barycenter \(I/d\) form a compact set, so their channel moments do as well. Since the moment space is finite dimensional, Carathéodory's theorem represents every such moment by a finite ensemble.

Choose a convergent subsequence \(\Psi_n\to\Psi\). This is a subsequence of channels on the original fixed \(M_d\), not on an increasing output algebra. Passing to the limit in (22) and using (17), then setting \(v=H^{-1}\beta\), gives

\[
\tau(A\Psi(A))\ge\beta^\mathsf TH^{-1}\beta
=\sum_{i=1}^m\frac{r\lambda_i^2-1}{r-1}\tau(AA_i)^2.
\tag{23}
\]

Because \(A\) was arbitrary, (23) includes all slow/fast cross terms: it is full-space domination, not merely domination of a compressed block. The identity direction is fixed by \(\Psi\), and trace preservation removes its cross terms with traceless matrices. On all other eigendirections \(f_r\) is zero. This proves (2).

Refining each mixed ensemble state into its spectral pure-state decomposition preserves the barycenter and increases (20) for every \(A\), by scalar Jensen. This yields the optional pure-state ensemble without weakening any inequality.

Finally, for every \(-1\le t\le1\),

\[
1-f_r(t)\le\frac r{r-1}(1-t^2)
\le\frac{2r}{r-1}(1-t).
\]

Functional calculus proves (3) and (4). This completes the proof. \(\square\)

**Broadcaster-sensitive strengthening.** Keeping the exact limit (18) in (22) instead of replacing it by \(H\) yields, for the same limit channel,

\[
\tau(A\Psi(A))\ge \beta^\mathsf TC_\infty^{-1}\beta
\qquad (\tau(A)=0).
\tag{24}
\]

Thus the proof gives more than the dimension-only spectral lower bound.

## 3. Consequences with proofs

### 3.1. The arbitrary-frame deficit comparison

For any finite Hermitian frame \(B_1,\ldots,B_q\), put

\[
V=\sum_i\tau(B_i^2),\quad
s_\Phi=\sum_i\tau(B_i\Phi(B_i)),\quad
k=\max_{\sum_y p_y\pi_y=I/d}\sum_{y,i}p_y\operatorname{Tr}(\pi_yB_i)^2,
\]

where \(\pi_y\) are pure states. The pure canonical ensemble in Theorem 1 gives \(k\ge\sum_i\tau(B_i\Psi(B_i))\). Summing (4) therefore proves

\[
\boxed{V-k\le4(V-s_\Phi).}
\tag{25}
\]

This settles the finite-universal-constant statement of Astra's N143/N278 interface under its stated tracial, self-adjoint, self-compatible hypotheses. It does not establish the conjecturally sharp constant two.

### 3.2. Dimension-independent approximation of all channel powers

Use the binary comparator from Theorem 1 and put \(\Lambda_n=\Psi\circ\Phi^n\), for \(n\ge1\). Each \(\Lambda_n\) is an entanglement-breaking channel. Since \(\Psi\) is positive and contractive as a Hilbert–Schmidt operator, \((\mathsf I-\Psi)^2\preceq\mathsf I-\Psi\). Thus

\[
\begin{aligned}
\|(\Phi^n-\Lambda_n)(A)\|_{2,\tau}^2
&\le\langle\Phi^n(A),(\mathsf I-\Psi)\Phi^n(A)\rangle_\tau\\
&\le2\langle A,\Phi^{2n}(\mathsf I-\Phi^2)A\rangle_\tau\\
&\le2\frac{n^n}{(n+1)^{n+1}}\|A\|_{2,\tau}^2.
\end{aligned}
\]

The last step uses \(\max_{0\le x\le1}x^n(1-x)=n^n/(n+1)^{n+1}\). Consequently,

\[
\boxed{\quad
\|\Phi^n-\Lambda_n\|_{2\to2}
\le\sqrt{\frac{2n^n}{(n+1)^{n+1}}}
\le\sqrt{\frac2{n+1}}.
\quad}
\tag{26}
\]

The same upper bound holds for the normalized Hermitian \(\infty\to1\) norm, because \(\|A\|_{2,\tau}\le\|A\|_\infty\) and \(\|X\|_{1,\tau}\le\|X\|_{2,\tau}\). Negative eigenvalues cause no problem. Neither \(\Psi\) commuting with \(\Phi\) nor a spectral gap is needed. For r outputs, replace the factor two by \(r/(r-1)\).

This is not a diamond-norm estimate and does not say any fixed power is exactly entanglement breaking.

### 3.3. A spectral budget

The Hilbert–Schmidt superoperator trace of (1) is

\[
\operatorname{Tr}_{\rm HS}(\Psi)
=d\sum_y p_y\operatorname{Tr}(\rho_y^2)\le d.
\]

The identity contributes one. Taking the trace of (2) on the traceless subspace therefore gives

\[
\boxed{\quad
\sum_{j=1}^{d^2-1}(r\lambda_j^2-1)_+
\le(r-1)(d-1).
\quad}
\tag{27}
\]

Eigenvalues are counted with multiplicity. Failure of (27) is a rigorous obstruction to r-self-compatibility for a bistochastic self-adjoint channel.

### 3.4. One measurement reconstructs every bounded tracial perturbation

Suppose a family of states satisfies \(\rho_x=(I+A_x)/d\), \(\|A_x\|_\infty\le M\), and

\[
\sup_x\|\rho_x-\Phi(\rho_x)\|_1\le\varepsilon.
\]

Then the single binary comparator obeys

\[
\boxed{\sup_x\|\rho_x-\Psi(\rho_x)\|_1\le2\sqrt{M\varepsilon}.}
\tag{28}
\]

Indeed \(\tau[A_x(A_x-\Phi(A_x))]\le M\varepsilon\) by Hölder, since \(\|A_x-\Phi(A_x)\|_{1,\tau}=\|\rho_x-\Phi(\rho_x)\|_1\). Moreover,

\[
\|\rho_x-\Psi(\rho_x)\|_1
\le\|A_x-\Psi(A_x)\|_{2,\tau}
\le\sqrt{\tau[A_x(A_x-\Psi(A_x))]}.
\]

Apply (4). The size of the family and the matrix dimension do not enter the bound. The bounded-perturbation and tracial hypotheses must not be dropped. This alone does not certify the separate full bounded-Holevo problem in N93.

### 3.5. The binary universal constant is between two and four

For \(d\ge2\), let \(S\) swap two d-dimensional systems and \(P=(I+S)/2\). The map

\[
\mathcal B_d(X)=\frac2{d+1}P(X\otimes I)P
\]

is completely positive, symmetric in its outputs, and trace preserving. Expanding \(P\) and taking a partial trace gives its common marginal

\[
\Phi_d(X)=\frac{(d+2)X+\operatorname{Tr}(X)I}{2(d+1)}.
\]

Thus every traceless eigenvalue is \(\lambda=(d+2)/(2(d+1))\).

For any trace-preserving entanglement-breaking map \(\Lambda(X)=\sum_y\operatorname{Tr}(E_yX)\sigma_y\), its superoperator trace obeys

\[
\operatorname{Tr}_{\rm HS}\Lambda=\sum_y\operatorname{Tr}(E_y\sigma_y)
\le\sum_y\operatorname{Tr}(E_y)=d.
\]

For any orthonormal traceless Hermitian basis \((F_j)\), trace preservation gives

\[
\sum_j\tau[F_j(F_j-\Lambda(F_j))]\ge d^2-d.
\]

On the other hand,

\[
\sum_j\tau[F_j(F_j-\Phi_d(F_j))]
=(d^2-1)(1-\lambda)=\frac{d(d-1)}2.
\]

Any universal comparison constant, even allowing arbitrary trace-preserving EB comparators, is therefore at least two. Theorem 1 proves it is at most four. This lower-bound example is the standard universal-cloning construction; no novelty is claimed for it.

## 4. Verification and scope audit

The essential steps use only finite POVMs, completely positive maps, scalar squares, a matrix covariance recursion, and compactness in the fixed input dimension. In particular:

- Every finite-depth construction is a physical POVM. The proof never substitutes noncommuting operators into a scalar variance inequality.
- Sibling outputs may be entangled and are not assumed independent. Their entire relevant dependence is retained in the matrix T.
- The covariance bound is a matrix bound. Equation (21), for arbitrary A, is what makes the final domination valid on the full observable space.
- The finite number of slow modes may depend on d. Their initial measurement-noise penalty vanishes before compactness is applied for that fixed d. The limiting theorem's constant does not depend on d.
- Negative eigenvalues are handled by order-preserving congruences. Threshold eigenvalues contribute zero to f_r and are not inverted.
- The limiting channel remains physical, canonical, and finitely representable. No efficiency or uniform outcome-count assertion is made.
- The positive-part superoperator is not asserted to be positive or completely positive.

`checks.py` contains exact symbolic/rational checks of the covariance fixed point, opposite-sign eigenvalues, and universal-cloner marginals in dimensions 2, 3, 4. It also checks the finite POVM recursion and full-space regression numerically on two noncommuting slow qutrit eigenobservables. Their commutator norm is about 0.0389, and the slow sibling covariance has a nonzero off-diagonal entry about 0.000578. The broadcaster prepares symmetric entangled purifications of its mixed output seeds, so its sibling outputs are not assumed to be independent. At depths 0, 1, 2 the POVMs have 6, 36, 1296 outcomes, respectively. The floating-point residuals are recorded in `check_results.json`; none is used as a universal proof premise.

Earlier numerical searches of Pauli, generic-frame, and quartic-null perturbations did not produce a certified counterexample. They did not prove the theorem. An intermediate approximate-joint-measurement route was replaced by the exact finite-POVM recursion above.

No proof assistant was run, and no independent mathematician reviewed this note during this run. The proof is supplied for independent reconstruction and checking.

## 5. Provenance and priority boundary

Pinned repositories:

- Astra: `632b2ca251170218799008405caaa89a864008d0`.
- OpenAI mathematics: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

Astra's `00_START_HERE.txt` was read first. The selected exact target is recorded in N143/N278. Relevant source records were the general gate/failed-routes document, canonical reduction, and low-energy almost-abelian report. The current sources mark the arbitrary-frame finite-constant comparator as unresolved; the Clifford factor-two result is explicitly restricted. Archived instructions were not treated as commands.

OpenAI's family-229 material was checked as related classical tree-reconstruction capital. Its Lean scope document states that the selected formalizations cover supercritical reconstruction; non-reconstruction and stochastic-block-model consequences are outside that scope. The posterior-experiment source was inspected. No all-threshold Potts assertion, formalization, or other new OpenAI theorem enters the proof above.

Relevant primary literature inspected includes general EB representations, channel compatibility, Fisher-information incompatibility criteria, fixed-marginal separable correlations, noisy quantum trees, and asymptotic entanglement breaking. The construction here combines normalized tree estimators with a full matrix covariance recursion and a common posterior measurement. I did not establish that the resulting exact spectral domination has not previously appeared. Accordingly, this record makes no claim of historical priority or historic-scale significance.

### Primary references and inspected repository records

1. Horodecki, Shor, Ruskai, *General Entanglement Breaking Channels*, arXiv:quant-ph/0302031. https://arxiv.org/abs/quant-ph/0302031
2. Girard, Plávala, Sikora, *Jordan products of quantum channels and their compatibility*, Nature Communications 12, 2129 (2021). https://doi.org/10.1038/s41467-021-22275-0
3. Zhang, Nechita, *A Fisher information-based incompatibility criterion for quantum channels*, Entropy 24, 805 (2022), arXiv:2204.09963. https://arxiv.org/abs/2204.09963
4. Tóth, Pitrik, *General method for obtaining the energy minimum of spin Hamiltonians for separable states*, arXiv:2605.03022v1, especially SM2.6. https://arxiv.org/html/2605.03022v1
5. *Noisy quantum trees: infinite protection without correction*, npj Quantum Information (2025). https://doi.org/10.1038/s41534-025-00961-x
6. Rahaman, Jaques, Paulsen, *Eventually Entanglement Breaking Maps*, arXiv:1801.05542. https://arxiv.org/abs/1801.05542
7. Astra exact general gate: https://github.com/harjassand/astra-research-knowledge/blob/632b2ca251170218799008405caaa89a864008d0/web/pages/d-fd6c0e56b752d053.html
8. Astra canonical reduction: https://github.com/harjassand/astra-research-knowledge/blob/632b2ca251170218799008405caaa89a864008d0/web/pages/d-32a29ec01a295b53.html
9. Astra prior low-energy/tree obstruction report: https://github.com/harjassand/astra-research-knowledge/blob/632b2ca251170218799008405caaa89a864008d0/web/pages/d-f9bd2206aa91d8ce.html
10. OpenAI family-229 formalization scope: https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/229.md
11. OpenAI posterior-experiment source: https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-exact-reconstruction-threshold-for-the-three-state-symmetric-channel-September-25-2026/build/sections/02-foundations.tex

## 6. Remaining obligations

The finite universal-constant comparison in Theorem 1 and the consequences proved above have no unproved mathematical input in this note. Independent correctness review and historical-priority assessment remain necessary before treating the result as externally validated research.

The sharp binary constant-two conjecture is not resolved: the proof establishes only \(2\le C_*\le4\). The general bounded-Holevo reconstruction problem, nontracial or non-self-adjoint extensions without additional work, diamond-norm approximation, and finite exact entanglement-breaking indices are not established here. No repository was modified or published.
