# Maximal operational obstruction to dimension-free classicalization

9 October 2026 UTC. Independent mathematical derivation. No claim of historical novelty or external peer review. This result does not depend on the newly audited comparator theorem.

## Main theorem

For every integer n >= 1,

sup over finite d and bistochastic, Hilbert–Schmidt-selfadjoint, binary-self-compatible channels Φ on M_d of

    inf over entanglement-breaking channels E of ||Φ^n − E||diamond

is exactly 2 (the maximal channel distance).

The channels in the supremum can be chosen as tensor powers of universal-cloner marginals. In the same explicit examples, the exact induced Hilbert–Schmidt distance to the EB set is exponentially small in n, independently of the tensor-power count. Thus the obstruction is genuinely a norm separation, not failure of the HS comparator.

Consequences: there cannot be any dimension-independent diamond approximation function tending to zero for powers of channels in this class. There cannot be a dimension-independent finite EB index either. The qualitative fixed-dimension asymptotic theorem is unaffected: dimension grows in this supremum.

## 1. Explicit physical family

Let q >= 2 be an integer and let F swap C^q⊗C^q. Set P_+=(I+F)/2 and

    B_q(X) = [2/(q+1)] P_+ (X⊗I) P_+.

This map is CP. Since Tr[P_+(X⊗I)] = (q+1)Tr(X)/2, it is trace preserving. It is invariant under output swap. A direct expansion of the four terms shows that either output marginal is

    D_λ(X) = λX + (1−λ)Tr(X)I/q,
    λ = (q+2)/(2(q+1)).

Indeed the partial traces of X⊗I, F(X⊗I), (X⊗I)F, and F(X⊗I)F are respectively qX, X, X, Tr(X)I. Hence each marginal is [(q+2)X+Tr(X)I]/[2(q+1)].

D_λ is bistochastic and HS-selfadjoint. For any integer m >= 1 let Φ=D_λ^⊗m, viewed as a channel on M_(q^m). Tensor B_q m times and regroup all first children and all second children to obtain an explicit binary broadcaster for Φ. Therefore Φ lies in the claimed class and

    Φ^n = D_a^⊗m,     a = λ^n.

The formula is the familiar universal symmetric cloner; an original primary source is R. F. Werner, “Optimal Cloning of Pure States,” Phys. Rev. A 58, 1827 (1998), https://arxiv.org/abs/quant-ph/9804001. All properties needed here were checked directly above; optimality is not used.

## 2. A uniform test against every globally separable state

Let P=|Ω_q><Ω_q|, with |Ω_q>=q^(-1/2)Σ_i |i i>. The normalized Choi state of D_a is

    ρ_a = aP + (1−a)I/q²,

and its singlet-test success probability is

    f = Tr(Pρ_a) = a+(1−a)/q².

On m reference–output pairs let P_i denote P on pair i, and let K=Σ_i P_i. These projectors commute.

If σ is any state separable across the full reference:output split A_1...A_m : B_1...B_m, then for every subset S of the pairs,

    Tr[σ ∏_(i in S) P_i] <= q^(−|S|).

To see this, reduce σ to A_S:B_S; it remains separable. The product of the P_i is a maximally entangled rank-one projector in dimension q^|S|, whose overlap with a product density matrix α⊗β is q^(−|S|)Tr(α^Tβ) <= q^(−|S|). Convexity handles all separable σ. Crucially, no independence or pairwise product assumption is made about σ.

For t>0, expand the commuting factors with nonnegative coefficients:

    Tr[σ exp(tK)]
    = Tr[σ ∏_i (I+(e^t−1)P_i)]
    <= [1+(e^t−1)/q]^m.

Write p=1/q. For any p<s<f, let T be the spectral projection 1_{K >= ms}. Exponential Markov optimization gives

    sup_sep σ Tr(Tσ) <= exp[−m D(s||p)],

where D(u||v)=u log(u/v)+(1−u)log((1−u)/(1−v)). Under ρ_a^⊗m the count K is Binomial(m,f), and the lower-tail Chernoff bound gives

    Tr(Tρ_a^⊗m) >= 1−exp[−m D(s||f)].

The real threshold ms causes no problem: the first event is K>=ms and its complementary event is K<ms; the standard exponential bounds hold for these real thresholds.

Since the trace-norm difference between density matrices is at least twice the difference in acceptance probabilities of any effect,

    inf_sep σ ||ρ_a^⊗m−σ||_1
    >= 2{1−exp[−m D(s||p)]−exp[−m D(s||f)]}.       (1)

This is an elementary finite-size amplification bound against the entire separable set, not just tensor-product separable approximants.

## 3. Diamond-distance conclusion

Every EB channel E on M_(q^m) has a separable normalized Choi state J(E). Testing Φ^n−E on the maximally entangled input therefore yields

    ||Φ^n−E||diamond >= ||ρ_a^⊗m−J(E)||_1.

The condition f>1/q is equivalent to a>1/(q+1). Because λ>1/2, choosing

    q = 2^n

ensures a=λ^n>2^(−n)=1/q>1/(q+1). Thus p<f. Fix s=(p+f)/2 and put

    c = min{D(s||p), D(s||f)} > 0.

For every ε in (0,2), any integer

    m >= log(4/ε)/c

makes (1) at least 2−ε, simultaneously for every EB E. Since distances of channels never exceed 2, the supremum is exactly 2.

A more quantitatively economical choice is q=2^(n+1), which makes the singlet-probability gap a fixed proportion of f instead of the much smaller gap at q=2^n. The exact relative-entropy expression, rather than an asymptotic estimate, is the certified finite-size prescription.

## 4. Exact Hilbert–Schmidt distance for this family

Put b=1/(q+1). The channel D_b is EB: its normalized Choi state is the Haar average of |ψ><ψ|⊗|ψbar><ψbar|, which equals [I+qP]/[q(q+1)]. The finite-dimensional convex hull is closed, so a finite ensemble also exists.

Since D_a and D_b have eigenvalue 1 on the identity and a,b respectively on traceless matrices, their tensor powers have eigenvalues a^k and b^k on weight-k traceless tensor sectors. Here 0<b<a<1 and

    a+b <= λ+b = (q+4)/(2q+2) <= 1.

For every k>=1,

    a^k−b^k = (a−b)Σ_(j=0)^(k−1) a^(k−1−j)b^j
               <= (a−b)(a+b)^(k−1) <= a−b.

Equality holds at k=1. Thus the explicit EB channel D_b^⊗m gives

    ||D_a^⊗m−D_b^⊗m||_(2→2) = a−b.

This upper bound is optimal over all EB channels, including correlated ones. First, the one-system optimum for D_a is a−b: twirling an arbitrary EB channel over U(q) preserves EB and cannot increase its 2→2 distance to D_a; the result is a depolarizing D_c. Its Choi overlap with P is at most 1/q by separability, forcing c<=b, and its distance is |a−c|>=a−b.

Second, any global EB E induces a one-system EB E_1 by feeding the other m−1 inputs the maximally mixed state and tracing their outputs. In normalized HS geometry, injection X↦X⊗I and normalized partial-trace extraction are norm-one, and after accounting for the maximally mixed normalization they show

    ||D_a−E_1||_(2→2) <= ||D_a^⊗m−E||_(2→2).

Equivalently, with ordinary HS norms the input map X↦X⊗I/q^(m−1) has norm q^(−(m−1)/2) and the output partial trace has norm q^((m−1)/2), whose product is 1. The same conclusion follows without a normalization convention.

Consequently,

    inf_EB E ||Φ^n−E||_(2→2) = λ^n−1/(q+1),       (2)

independently of m. With q=2^(n+1), this is O(2^(−n)), while the diamond distance can be arbitrarily close to 2 by increasing m.

## Exact interpretation and limits

This is a rigorous impossibility theorem for a natural foundational-strength upgrade of the comparator. It shows that a uniform HS classicalization statement can coexist with almost maximal entanglement-assisted distinguishability from every classical channel. The obstruction remains within the strongest audited hypotheses: finite dimension, tracial stationarity, selfadjointness, and explicit binary self-compatibility.

It does not show the audited n^(−1/2) HS upper bound is sharp. This family converges exponentially in HS distance. It does not contradict fixed-dimension diamond convergence or no-broadcasting. It does not establish a new historical theorem: the construction uses old cloning and separability ideas, and a dedicated priority search would be needed for publication positioning.

No stopped numerical campaign was restarted. No paid/remote compute, publication, push, or contact was used.

## Primary-source priority check

Beigi and Shor, “Approximating the Set of Separable States Using the Positive Partial Transpose Test,” arXiv:0902.1806, https://arxiv.org/pdf/0902.1806, Section I.A and Section III, already establish the general tensor-amplification principle: powers of an entangled state approach maximal distance from the full separable set. Their paper also applies the principle to symmetric-extension criteria. They use half the trace norm, so their maximal value 1 is our value 2.

Combining that old amplification principle with the elementary high-dimensional universal-cloner marginal gives the qualitative channel-power obstruction above. Therefore the main supremum theorem should be positioned as a useful explicit corollary/boundary, not claimed as a newly discovered foundational theorem. The elementary singlet-count proof here avoids importing the general amplification theorem and supplies a direct exponential finite-size certificate for this family. No priority claim is made for that certificate or the exact HS-distance calculation either.
