# Independent cross-check of the weighted-tracial comparator

9 October 2026 UTC. Checked the complete local WEIGHTED_TRACE_EXTENSION.md supplied by the N93 worker.

## Verdict

The weighted-tracial comparator and its final reconstruction estimate are correct under the exact stated hypotheses. This checks the final interface only, not the reductions that produce it.

1. Every finite-dimensional algebra can be represented canonically as a direct sum of full matrix algebras. Write τ(a)=Σ_b w_b Tr(a_b)/d_b with all w_b>0, Σ_b w_b=1. The density σ=⊕_b (w_b/d_b)I_b is central, faithful and normalized. Arbitrarily small weights cause no defect; compactness is only needed at fixed algebra and fixed τ.

2. For UCP J:A^⊗r→A with one-leg restrictions Φ, the functional ω=τ∘J is a state, and τ-preservation makes every marginal τ. Neither J nor Φ must preserve the individual central blocks. Symmetrization over input tensor slots leaves the restrictions unchanged. The cross covariance T is real symmetric because distinct tensor factors commute. Positivity of (a⊗I−I⊗a)^2 gives T<=I.

3. The unbiased POVM recursion is algebra-internal: tensor effects are positive; J is positive and unital; summation gives the identity; applying the one-leg restriction gives the exact first moment. All covariance identities depend only on marginal τ, not uniform block weights. Kadison/trace estimates and matrix-order recursion are unchanged.

4. The limit-channel moment set is compact: on the finite-dimensional positive cone, faithfulness of τ bounds any fixed norm on {h>=0:τ(h)=1}. Its barycenter/second-moment convex hull is compact. Carathéodory restores finite outcomes. Every resulting Ψ is unital, τ-preserving, CP, τ-selfadjoint and positive in L²(τ). Regression is against arbitrary observables, so it controls omitted-mode cross terms.

5. Physical orientation is consistent. For Ψ(a)=Σ_y τ(E_y a)E_y/τ(E_y), the ordinary Schrödinger map is Ψ_phys(ρ)=Σ_y Tr(E_yρ)σE_y/τ(E_y). Centrality makes σE_y positive with trace τ(E_y), and Ψ_phys(σa)=σΨ(a). Moreover if Φ is τ-selfadjoint, its ordinary trace adjoint satisfies Φ†(σa)=σΦ(a): for every b, Tr[b σΦ(a)]=τ[bΦ(a)]=τ[Φ(b)a]. Thus a Heisenberg self-compatibility J corresponds exactly to an ordinary physical broadcaster J† of this physical channel. No illicit weighted adjoint is being assumed CP.

6. An ambient extension is measure-and-prepare with the same block-diagonal effects. Their sum is the ambient identity in the canonical direct-sum representation. One may equivalently pinch the input first. In a representation with nontrivial multiplicities, use the trace-preserving conditional expectation onto the represented algebra rather than merely central-block pinching; the canonical representation avoids this harmless representational issue.

7. For central σ, ||σZ||_1=τ(|Z|). Hence with ||H||∞<=θ and ||H−ΦH||_(1,τ)<=r, C4 gives ⟨H,(I−Ψ)H⟩τ<=4θr. Since 0<=Ψ<=I, ||(I−Ψ)H||²_(2,τ)<=4θr. Finally half the physical trace distance is at most sqrt(θr), exactly as stated.

The possible remaining N93 difficulty is entirely upstream: obtaining the claimed central weighted-tracial interface with its necessary compatibility and selfadjointness, while controlling errors. This check establishes none of those upstream reductions.
