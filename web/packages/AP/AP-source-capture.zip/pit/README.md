# ASTRA foundational investigation: research packet

Research date: 8 October 2026. No foundational breakthrough or solution to general commutative PIT is claimed.

## Start here

Read `RESEARCH_STATE.md` for the exact target, opportunity comparison, full proofs, novelty correction, failed approaches, remaining hypothesis and scope limitations. `claims.json` supplies machine-readable claim status. `sources.json` records source pointers, revision pins and actual access scope.

The strongest complete argument characterizes the exact linear realization complexity of a polynomial evaluated on independent logarithms. This does **not** prove a lower bound for general commutative circuits or rule out direct logarithmic vanishing-order bounds. The positive small-derivative-space hitting theorem was already in Bhardwaj–Saptharishi (28 September 2026) and must not be counted as new.

## Reproduce the finite checks

Use Python 3.10 or newer. No additional packages or network access are required:

```sh
python verify.py --output replay_results.json
```

The expected terminal result is `ALL CHECKS PASSED`. `verification_results.json` records the original successful run. `contact_examples.json` contains exact integer fixtures; their discovery used SymPy, but the delivered replay uses only the Python standard library. The verifier proves only its finite checks, not the quantified mathematical theorems or historical novelty.

To check file integrity before producing new files:

```sh
sha256sum -c SHA256SUMS
```

## Repository pins

- Astra: `d20c4b040f63c2fb0c8da76362046d1946d0a2b9`.
- OpenAI mathematics: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

No remote repository was changed. Full copies of external papers are not included. All claimed proofs are in the report; source availability, internal reconstruction, formal verification, external review and historical priority remain distinct.

## Decisive remaining obligation

Prove or disprove an explicit, uniform polynomial bound B(n,s,D) for the order at zero of P(log(1+z), log(1+z/2), ..., log(1+z/n)) for every nonzero polynomial P computed by a size-s degree-D commutative circuit. Section 8 proves that such a bound would give the selected polynomial-degree black-box PIT result. No proof or counterexample to this bound was obtained.
