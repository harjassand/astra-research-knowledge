# Local transport proof of the Riesz interaction virial

9 October 2026. Original reconstruction of the low-order derivative interface; a lemma, not yet a complete nonexistence theorem or priority claim.

Let n>=2, 0<s<n, K_s(z)=c|z|^(s-n), c>0. Let W_B(x)=|x|^B b(x/|x|) and W_A similarly, where positive angular coefficients are C1. Suppose positive continuous u,v on R^n satisfy u=K_s*g, v=K_s*f, with f=W_B u^q and g=W_A v^p, p,q>0. Assume local C1 regularity away from the origin for this lemma, local integrability of f,g,fu,gv, and finite potentials. Set a=1/(q+1), b=1/(p+1) (the scalar b here is distinct from the angular coefficient).

For any C1 compactly supported vector field X whose support avoids the origin,

 a int fu(div X + X·grad log W_B)
 + b int gv(div X + X·grad log W_A)
 = (n-s) int [(X(x)-X(y))·(x-y)/|x-y|^2] f(x)g(y)K_s(x-y) dxdy.

This holds for all s>0, including s<=1, without using absolutely convergent individual kernel-gradient integrals.

## Proof with only finite local differences

Let Phi_t be the flow of X and J_t its Jacobian. Choose a bounded open annulus D containing the support of X compactly; its boundary is fixed by the flow, so Phi_t(D)=D. Push both source densities forward:

 f_t(Phi_t x)=f(x)/J_t(x), g_t(Phi_t x)=g(x)/J_t(x).

Their differences h_t=f_t-f and k_t=g_t-g are supported in D, and because f,g are C1 there, h_t/t and k_t/t converge uniformly on D to -div(fX) and -div(gX). In particular they are O(t) uniformly.

Use local differences of the nonlinear energy

 N_f(f)=q/(q+1) int W_B^(-1/q) f^(1+1/q),
 N_g(g)=p/(p+1) int W_A^(-1/p) g^(1+1/p).

The displayed global integrals need not exist; N_f(f_t)-N_f(f) means integration of their difference on D only, and likewise for g. Their derivatives at zero are int_D u h'_0 and int_D v k'_0, since W_B^(-1/q)f^(1/q)=u and analogously for g.

The interaction difference is defined by

 I(t)-I(0)=int h_t u + int k_t v + int h_t(x)K_s(x-y)k_t(y) dxdy.

Every term is finite. The last is O(t^2), since s>0 implies local integrability of K_s on D-D. Consequently the derivative of [N_f difference + N_g difference - I difference] at zero is zero, using the integral equations. No global finite-energy assumption is involved.

On the other hand, a change of variables gives

 N_f(f_t)-N_f(f)
 = q/(q+1) int_D f(x)^(1+1/q) [W_B(Phi_t x)^(-1/q) J_t(x)^(-1/q)-W_B(x)^(-1/q)] dx.

Its derivative is -a int_D fu [divX+X·gradlogW_B]. The analogous formula holds for g.

The interaction difference can equivalently be computed by transporting BOTH variables:

 I(t)-I(0)=int f(x)g(y)[K_s(Phi_t x-Phi_t y)-K_s(x-y)] dxdy.

To justify this despite possibly infinite total interaction, partition R^(2n) into D×D, D×D^c, D^c×D, D^c×D^c. Each of the first three pieces is finite by the potential marginals; the last piece is unchanged. Phi_t preserves D and is the identity outside it. Ordinary changes of variables on the three finite pieces therefore prove the identity.

The flow is uniformly bi-Lipschitz for small t. The kernel difference quotient is bounded by C K_s(x-y), and vanishes if both x,y lie outside D. This follows from homogeneity and |X(x)-X(y)|<=Lip(X)|x-y|. Its dominating interaction mass is at most C[int_D fu+int_D gv]<infinity. Dominated convergence gives

 I'(0)=-(n-s) int [(X(x)-X(y))·(x-y)/|x-y|^2] d pi,

where d pi=f(x)g(y)K_s(x-y)dxdy. Combining the three derivatives proves the identity.

## Radial field through the origin

For X(x)=x eta(|x|), with eta smooth compactly supported and constant near0, take X_rho(x)=X(x)[1-chi(x/rho)], chi smooth equal1 near0. These fields have uniformly bounded Lipschitz constants, and are supported in one fixed ball. On the left, the error is supported in B_(C rho), with bounded divX_rho and bounded X_rho·gradlogW (homogeneity and bounded angular log-gradient). The local energy integrability makes the error tend to zero. On the right, the uniform Lipschitz bound times K_s dominates the integrand on pairs with at least one endpoint in the fixed ball. That interaction mass is finite by the same potential marginals, so dominated convergence applies. Thus the radial virial also holds through0.

For radial X=x eta, x·gradlog angular coefficient=0 and divX+X·gradlogW_B=(n+B)eta+x·gradeta. Hence, with w=-x·gradeta,

 a(n+B)E_f+b(n+A)E_g-aW_f-bW_g=(n-s)int Phi d pi.

## Generalized cutoff exponents

The original source's choices m=n+3, k=n(m+1), N=k+n+2 still suffice for every 0<s<n. The three far-tail powers become

 N-1-m(n-s)=2n+1+ms>0,
 N-m(n+1-s)=n-1+ms>0,
 N-n-m(n-s)=n+2+ms>0.

Thus replacing Newton order2 by arbitrary s does not create a cutoff-tail exponent failure. This observation does not by itself discharge regularity bootstrap, all pressure steps, historical novelty, or PDE/integral equivalence.
