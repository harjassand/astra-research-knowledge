# Fractional PDE to Riesz representation: exact global weak gate

Date: 2026-10-09. This note verifies the transfer needed for the weighted Riesz system. It treats only the standard fractional Laplacian of order (s\in(0,2)), not higher-order or polyharmonic equations.

## Statement

Let (n\ge 2), (0<s<2), and put
\[
\mathcal L_s^1(\mathbb R^n)=\left\{w\in L^1_{\rm loc}(\mathbb R^n):\int_{\mathbb R^n}\frac{|w(x)|}{1+|x|^{n+s}}\,dx<\infty\right\},\qquad L_s=(-\Delta)^{s/2}.
\]
Fix the positive Riesz kernel (K_s(x)=\kappa_{n,s}|x|^{s-n}), normalized by (L_sK_s=\delta_0). Since (s<n) under these dimension/order assumptions, (K_s) is locally integrable.

The standard distributional definition for (w\in\mathcal L_s^1) is
\[
\langle L_sw,\phi\rangle=\int_{\mathbb R^n}w(x)L_s\phi(x)\,dx,\qquad \phi\in C_c^\infty(\mathbb R^n).
\]
This is well-defined because (L_s\phi(x)=O((1+|x|)^{-n-s})) at infinity. The phrase “globally in distributions” below means this identity is imposed for every such test function, including those that do not vanish near the origin.

**Scalar representation lemma for the weighted sources used here.** Let (A>-n), (p>0), and let (u,w\in C(\mathbb R^n)) be strictly positive, with (u\in\mathcal L_s^1). Suppose
\[
L_su=F:=|x|^A w^p\quad\text{in }\mathcal D'(\mathbb R^n).
\]
Then (A>-s), (F\in\mathcal L_s^1), and there is a constant (c_u\ge0) such that, at every (x\in\mathbb R^n),
\[
u(x)=c_u+I_sF(x),\qquad I_sF(x):=\int_{\mathbb R^n}K_s(x-y)F(y)\,dy.
\]
No boundedness of (u,w) at infinity, finite-energy hypothesis, or Sobolev hypothesis is required.

**System corollary.** Suppose additionally (B>-n), (q>0), and (v\in C(\mathbb R^n)\cap\mathcal L_s^1) is strictly positive with
\[
L_su=|x|^A v^p,\qquad L_sv=|x|^B u^q\quad\text{in }\mathcal D'(\mathbb R^n).
\]
Then (A,B>-s) and
\[
u=c_u+I_s(|\cdot|^A v^p),\qquad v=c_v+I_s(|\cdot|^B u^q),\qquad c_u,c_v\ge0.
\]
In fact (c_u=c_v=0), so the fractional PDE system is exactly the positive Riesz integral system.

## Proof

### 1. Ball Green comparison in the weak class

First, (F\in L^1_{\rm loc}), since (A>-n) and (w) is locally bounded. Also (F) is continuous and strictly positive on (\mathbb R^n\setminus\{0\}). Fix a ball (B_R). Choose (F_j\in C_c^\infty(B_R\setminus\{0\})) with (0\le F_j\le F) and (F_j\to F) almost everywhere on (B_R). Such lower approximations exist by exhausting compact annuli and using a partition of unity with local lower bounds for the positive continuous function (F).

Let
\[
U_{R,j}(x)=\begin{cases}\displaystyle\int_{B_R}G_R(x,y)F_j(y)\,dy,&x\in B_R,\\0,&x\notin B_R,\end{cases}
\]
where (G_R) is the zero-exterior Green kernel for (L_s) on (B_R). In the convention of Bucur's paper the operator is ((-Δ)^\sigma), (0<\sigma<1); set \(\sigma=s/2\). Her Green formula and representation theorem imply that (U_{R,j}\in C(\mathbb R^n)\cap\mathcal L_s^1) and (L_sU_{R,j}=F_j) in (B_R). The data (F_j) are smooth with compact support in the ball, so they meet the stated regularity hypotheses of that theorem.

Now (z_{R,j}=u-U_{R,j}\in\mathcal L_s^1\cap C(\mathbb R^n)), (L_sz_{R,j}=F-F_j\ge0) in (B_R), and (z_{R,j}=u\ge0) on (\mathbb R^n\setminus B_R). The distributional weak maximum principle applies exactly here. Silvestre defines a supersolution by the distributional inequality against nonnegative tests (Definition 2.10); Proposition 2.15 characterizes such supersolutions for the weighted class \(\mathcal L_\sigma\), with weight (n+2\sigma); Proposition 2.17 says that for a bounded domain, a lower-semicontinuous supersolution on its closure that is nonnegative on the complement is nonnegative everywhere. Here \(\sigma=s/2\), so \(\mathcal L_\sigma=\mathcal L_s^1\), and (z_{R,j}) is continuous, hence lower-semicontinuous. Therefore
\[
u(x)\ge U_{R,j}(x)\quad\text{for all }x\in\mathbb R^n.
\]

For fixed (R), Fatou's lemma and (F_j\to F) almost everywhere give
\[
u(x)\ge\int_{B_R}G_R(x,y)F(y)\,dy.
\tag{1}
\]
The formula for (G_R), with normalization chosen consistently with (K_s), is
\[
G_R(x,y)=C_{n,s}|x-y|^{s-n}\int_0^{\rho_R(x,y)}t^{s/2-1}(1+t)^{-n/2}\,dt,
\quad
\rho_R(x,y)=\frac{(R^2-|x|^2)(R^2-|y|^2)}{R^2|x-y|^2}.
\]
For fixed (x,y), once (R>\max(|x|,|y|)), \(\rho_R\) is increasing with (R\) and tends to infinity. Thus (G_R(x,y)\uparrow K_s(x-y)): the limiting integral is (B(s/2,(n-s)/2)), and the constant is the fundamental-solution normalization. Monotone convergence in (1) yields
\[
0\le I_sF(x)=\int_{\mathbb R^n}K_s(x-y)F(y)\,dy\le u(x)<\infty\quad\text{for every }x.
\tag{2}
\]

### 2. The origin forces (A>-s)

By strict positivity and continuity of (w), (F(y)\ge c|y|^A) for small (|y|). At (x=0), the Green formula gives (G_R(0,y)\ge c_R|y|^{s-n}) for (|y|\le R/2): the upper limit \(\rho_R(0,y)\) is bounded below by a positive constant, so the integral in the formula is bounded below. If (A\le-s), then the right side of (1) at zero is at least
\[
c\int_0^{R/2}r^{A+s-1}\,dr=+\infty,
\]
contradicting (u(0)<\infty). Hence (A>-s).

In particular, (F(y)\le C|y|^A) near the origin. Formula (2) at (x=0) gives
\[
\int_{\mathbb R^n}K_s(y)F(y)\,dy=I_sF(0)\le u(0)<\infty.
\tag{3}
\]
Since (K_s(y)\asymp |y|^{s-n}\) and
\[
\frac1{1+|y|^{n+s}}\le C|y|^{s-n}\qquad(y\ne0),
\]
(3) implies (F\in\mathcal L_s^1). Also (I_sF\in\mathcal L_s^1) by (0\le I_sF\le u).

### 3. Verify the distributional inverse identity, including Fubini

For (\phi\in C_c^\infty(\mathbb R^n)), set (H=L_s\phi). The standard fractional Laplacian estimate gives (H\in L^1\cap L^\infty) and (|H(x)|\le C_\phi(1+|x|)^{-n-s}). For (y\ne0),
\[
J(y):=\int_{\mathbb R^n}K_s(x-y)|H(x)|\,dx\le C_\phi K_s(y).
\tag{4}
\]
Indeed, on bounded (y)-sets the convolution is uniformly bounded because (s>0) makes the kernel locally integrable. For large (|y|), split into (|x-y|<|y|/2) and its complement. On the first set, (|H(x)|\le C|y|^{-n-s}), and the kernel integral is (O(|y|^s)), giving (O(|y|^{-n})\); on the complement, (K_s(x-y)\le C|y|^{s-n}\) and (H\in L^1). Since (s>0), both bounds are (O(|y|^{s-n})\). By (3)–(4), the double integral below is absolutely integrable, so Fubini is valid:
\[
\int_{\mathbb R^n}I_sF(x)H(x)\,dx
=\int_{\mathbb R^n}F(y)\left[\int_{\mathbb R^n}K_s(x-y)L_s\phi(x)\,dx\right]dy
=\int_{\mathbb R^n}F(y)\phi(y)\,dy.
\tag{5}
\]
The inner identity is the standard Riesz-kernel fundamental-solution identity (I_s(L_s\phi)=\phi), with (K_s) normalized by (L_sK_s=\delta_0). It follows either by distributional convolution or from the Fourier multipliers \(|\xi|^{-s}\) and \(|\xi|^s\); (n>s) makes the Riesz kernel locally integrable. Equation (5) proves (L_s(I_sF)=F) in \(\mathcal D'(\mathbb R^n)\), not merely away from zero.

### 4. Classify the remainder and upgrade to pointwise equality

Set (h=u-I_sF\). By (2), (h\ge0); by (u,I_sF\in\mathcal L_s^1), (h\in\mathcal L_s^1); and by (5), (L_sh=0) in \(\mathcal D'(\mathbb R^n)\). Fall's Theorem 1.1 (“Entire (s)-harmonic functions are affine,” Proc. Amer. Math. Soc. 144 (2016), 2587–2592) says that if (0<\tau<1), (h\in L^1_\tau) with weight (n+2\tau), and ((-Δ)^\tau h=0) distributionally on all of \(\mathbb R^n\), then (h) is affine (constant when \(\tau\le1/2\)). Take \(\tau=s/2\); its weight is exactly (n+s). Thus (h) is affine a.e.; since (h\ge0) a.e. on all of \(\mathbb R^n\), its linear part is zero and (h=c_u\ge0) a.e.

It remains to check pointwise equality, because the theorem first identifies distributions/a.e. representatives. Here (A>-s), and near zero (F(y)\le C|y|^A). For (|x|\le r), scaling gives
\[
\int_{|y|<2r}K_s(x-y)F(y)\,dy\le Cr^{A+s};
\]
the scaled integral is uniformly bounded for (|x|/r\le1) precisely because (A>-s). This tends to zero as (r\downarrow0). On (|y|\ge2|x|), the kernel is bounded by (C K_s(y)); (3) and dominated convergence show that the complementary part tends to (I_sF(0)). Thus (I_sF) is continuous at zero. Away from zero, (F) is locally bounded and continuous; local integrability of the kernel gives continuity of its local potential, while (3) dominates the tail. Hence (I_sF\in C(\mathbb R^n)). Since (u) is continuous and (u-I_sF=c_u) a.e., equality holds at every point.

This proves the scalar lemma.

### 5. The system, and elimination of the constants

Apply the scalar lemma first with (w=v,A,p), then with (w=u,B,q). This gives (A,B>-s) and the two representations with (c_u,c_v\ge0).

If (c_u>0), then (u(y)\ge c_u) everywhere and
\[
|y|^B u(y)^q\ge c_u^q|y|^B.
\]
For fixed (x), the Riesz potential of the right side diverges at infinity:
\[
\int_{|y|>R}K_s(x-y)|y|^B\,dy\asymp\int_R^\infty r^{B+s-1}\,dr=+\infty,
\]
because (B>-s). This contradicts the finite value (v(x)=c_v+I_s(|\cdot|^Bu^q)(x)). Therefore (c_u=0). The same argument, using (A>-s), gives (c_v=0). Thus
\[
u=I_s(|\cdot|^A v^p),\qquad v=I_s(|\cdot|^B u^q)
\]
pointwise on \(\mathbb R^n\).

## Origin-extension caveat

The proof assumes the equations in \(\mathcal D'(\mathbb R^n)\), with the ordinary locally integrable right-hand sides. For that formulation, the minimal natural exponent condition is (A,B>-n); the argument then improves it to (A,B>-s). If one starts only with classical/distributional equations on \(\mathbb R^n\setminus\{0\}\), the proof does not by itself establish their extension across zero. One must separately impose or prove the no-defect identities for tests meeting zero. This note does not assert a continuous counterexample, nor does it claim arbitrary punctured-domain equations are nonremovable.

## Primary references and exact scope

1. L. Silvestre, “Regularity of the obstacle problem for a fractional power of the Laplace operator,” *Comm. Pure Appl. Math.* 60 (2007), 67–112, DOI [10.1002/cpa.20153](https://doi.org/10.1002/cpa.20153), author PDF [§2.2, Definition 2.10 and Propositions 2.15, 2.17](https://math.uchicago.edu/~luis/preprints/The%20Obstacle%20problem%20for%20the%20fractional%20laplacian.pdf). The cited maximum principle is a distributional weak principle in the weighted (L^1) class; its stated semicontinuity requirement is met here by continuity.
2. C. Bucur, “Some observations on the Green function for the ball in the fractional Laplace framework,” *Commun. Pure Appl. Anal.* 15 (2016), no. 2, 657–699, DOI [10.3934/cpaa.2016.15.657](https://doi.org/10.3934/cpaa.2016.15.657), [arXiv:1502.06468](https://arxiv.org/html/1502.06468v4), Theorems 3.1–3.2. Her operator is ((-Δ)^\sigma), (0<\sigma<1); set (\sigma=s/2). Theorem 3.2's source hypotheses include smooth compactly supported (F_j), as used above. The paper notes that the Green formula itself is classical and supplies an elementary exposition.
3. M. M. Fall, “Entire (s)-harmonic functions are affine,” *Proc. Amer. Math. Soc.* 144 (2016), no. 6, 2587–2592, DOI [10.1090/proc/13021](https://doi.org/10.1090/proc/13021), [arXiv:1407.5934](https://arxiv.org/html/1407.5934v2), Theorem 1.1 and §2. Fall's convention is ((-Δ)^\tau), (0<\tau<1), and (L^1_\tau) has weight (n+2\tau); choose (\tau=s/2). The theorem explicitly permits affine remainders for (s>1), which is why nonnegativity of the Green-comparison remainder is used.
4. R. Zhuo, W. Chen, X. Cui, Z. Yuan, “Symmetry and non-existence of solutions for a nonlinear system involving the fractional Laplacian,” *Discrete Contin. Dyn. Syst. A* 36 (2016), 1125–1141, DOI [10.3934/dcds.2016.36.1125](https://doi.org/10.3934/dcds.2016.36.1125), preprint [arXiv:1401.7402](https://arxiv.org/abs/1401.7402), Theorem 3 and Remark 1. This is a primary precedent for the Green-ball PDE-to-integral strategy for nonnegative global strong solutions and suitable nonlinearities. Its theorem is not cited as directly covering the variable-weight, merely distributional system here; the weak maximum-principle adaptation above is supplied explicitly.
