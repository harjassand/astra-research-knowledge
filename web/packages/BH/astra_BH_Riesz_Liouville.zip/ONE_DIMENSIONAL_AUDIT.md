# One-dimensional audit of the Riesz Liouville proof

## Conclusion and scope

The direct integral-system theorem extends to (n=1), (0<s<1). The only essential structural gap in the (n\ge2) proof was the coincident-line contribution in the line-layer inequality. It is filled by first proving the interval inequality with a positive transverse regularization parameter and then taking that parameter to zero by monotone convergence. The other dimension-dependent estimates specialize with (m=4), (k=5), (N=8). This audit concerns the direct integral equations only; any fractional-PDE corollary must retain its separately stated representation hypotheses and dimension/order range.

## Coincident-line weighted interval inequality

Write \(\mu=1-s\in(0,1)\). For \(\lambda>0\), define
\[
K_\lambda(h)=c_s(\lambda^2+h^2)^{-\mu/2},\qquad D_\lambda(h)=\frac{h^2}{\lambda^2+h^2}.
\]
The midpoint proof of (19) uses only the derivative identities for \(K_\lambda\) and the reflection monotonicity of the interval-overlap density. It gives the same weighted inequality (20), with \(D_\lambda\) in the pressure term, for all bounded interval pairs. The proof does not require a transverse dimension.

As \(\lambda\downarrow0\), \(K_\lambda\uparrow K_0=c_s|h|^{-\mu}\) away from the diagonal. The endpoint averages increase as well, and
\[
D_\lambda K_\lambda=c_s h^2(\lambda^2+h^2)^{-1-\mu/2}\uparrow K_0
\]
for \(h\ne0\). Since \(\mu<1\), \(|h|^{-\mu}\) is locally integrable: both \(\iint_{I\times J}|t-t'|^{-\mu}\,dt\,dt'\) and the endpoint integrals such as \(\int_J|a-t'|^{-\mu}\,dt'\) are finite for bounded intervals, including overlapping intervals. The diagonal is null in \(I\times J\). Every term of (20) is nonnegative, so monotone convergence passes the entire weighted inequality to \(\lambda=0\). On the coincident line, \(D_e=1\) away from the diagonal, which is precisely the limit of \(D_\lambda\).

A necessary presentation caveat: the raw signed \(\zeta h/(\lambda^2+h^2)K_\lambda\) term need not have an absolutely integrable \(\lambda=0\) limit. The proof should pass the already-established nonnegative inequality (20) by MCT; it should not assert a standalone \(\lambda=0\) integration-by-parts identity or a principal-value interpretation.

When one interval coefficient is zero, the residual-weight inequality is pointwise; positive coefficients occur only on bounded level components. Thus an unbounded zero-weight interval introduces no subtraction or finiteness problem.

## Direction caps and source layers

The sphere of directions is \(\mathbb S^0=\{-1,+1\}\), with mass \(1/2\) per direction. For \(l=\kappa r<1\),
\[
Z(l)=\tfrac12[\psi(0)+\psi(2/l)]=\tfrac12,
\]
since \(\psi(0)=1\) and \(\psi\) vanishes beyond 1. Hence \(h_e=2w\) on the shell with \(\operatorname{sign}(x)=e\) and is zero on the opposite shell; \(\mathbb E_e h_e=w\). The bounds in (21) hold with powers \(N-n=7\) and \(N-n-1=6\). For \(x\ne0\), \(D(x,y)=D_e(x,y)=1\) off the diagonal, so the cap comparison has zero error.

For the long-component estimate (24), a component of length greater than \(\ell\) contains, on one side of \(x\), a segment of length \(\ell/2\). Thus \(\int_{B_\ell(x)} f\ge t\ell/2\). In \(\mathbb S^0\), component length is direction-independent, so the event has probability zero or one; the integral bound proves (24) with an absolute constant. The same applies to \(g\).

A positive component weight \(\chi_I\) forces \(I\) to be bounded and contained in the shell away from zero, with \(|I|\le2\delta r(x)\). Its endpoints are therefore nonzero and satisfy \(f(x_\pm)=t\) by continuity. The potential values at the endpoints are finite by hypothesis. The relative derivative bound for \(|x|^{-B/q}\) is uniform on \(1\le|x|\le2\), so the endpoint estimate (26) and the finite-before-subtraction argument remain valid. The same holds for \(g,v\). In one dimension there is just one line for each direction and no transverse integration; use the \(\lambda=0\) interval inequality for each component pair.

## Other assumptions and exponent checks

The origin restriction is unchanged: in one dimension the annular lower bound is \(\int_{2|x|}^{r_0}r^{A+s-1}\,dr\), which diverges as \(x\to0\) if \(A\le-s\); interchanging equations gives \(B>-s\). Hence \(A,B>-s>-1\), and the weights, sources, and local energies are integrable near zero. The Riesz kernel is locally integrable since \(s>0\). The local regularity propositions cited in Section 2 are stated on \(\mathbb R^n\) with constants depending on \(n\), so they apply at \(n=1\); the bootstrap is in the \(s\le1\) case.

With \(m=4,k=5,N=8\), the boundary exponents in Sections 4 and 6 are
\[
N-1-m\mu=3+4s>0,\qquad N-m(\mu+1)=4s>0,\qquad N-1-m\mu=3+4s>0.
\]
The high-level long-component term has power \(N=8\), and the low-level term has power \(N-1-k=2>0\). Thus all localization and source-layer integrals close exactly as in the higher-dimensional proof. The mass/scaling/tail bounds, transport identity, energy closure, and contradiction have no additional one-dimensional obstruction.

## Recommended theorem-scope edit

State the direct integral theorem for \(n\ge1\), \(0<s<n\). In dimension one this means \(0<s<1\). Keep any PDE corollary's dimension and order hypotheses separate unless its representation step has independently been proved in the intended class.
