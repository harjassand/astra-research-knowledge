# Subcritical weighted Riesz integral systems: complete analytic proof candidate

Research record: 9 October 2026.

## What is established in the supplied argument

The manuscript gives a complete analytic nonexistence argument for the full strict subcritical parameter region of the equal-order weighted Riesz integral system. The stated solution class is positive, continuous, globally finite, and satisfies the integral equations pointwise everywhere.

For every n >= 1, every real Riesz order 0 < s < n, every p,q > 0 and real weights A,B, consider

u(x) = c_s integral |x-y|^(s-n) |y|^A v(y)^p dy,
v(x) = c_s integral |x-y|^(s-n) |y|^B u(y)^q dy,

with c_s > 0. There are no such solutions if

(n+A)/(p+1) + (n+B)/(q+1) > n-s.

No radial symmetry, stability, global boundedness, decay, finite energy, or other global integrability condition is assumed. Local boundedness follows from the explicitly assumed continuity. This is not a theorem excluding singular measurable almost-everywhere solutions: those can exist on the subcritical side and are addressed in the scope assessment.

## Fractional PDE consequence

A separate representation proof also closes the standard full-space fractional PDE transfer for n >= 2 and 0 < s < 2. It assumes positive continuous functions in the natural weighted tail class, A,B > -n, and equations globally in distributions, including through the origin. It does not assume radiality, global boundedness, or finite energy. Green comparison, harmonic-remainder classification, and positivity yield the exact pointwise integral representation, so the same full subcritical nonexistence conclusion follows. See FRACTIONAL_PDE_COROLLARY.md and the complete representation proof and audit. This is a scoped PDE theorem, not a claim about every possible PDE formulation.

## Why this is consequential

The unweighted version is the regular-solution Liouville problem historically called the HLS integral-system conjecture. The full weighted and arbitrary-order statement reaches beyond the radial, decaying/integrable, and restricted-parameter results found in the primary-literature comparison.

For example n=8, s=1, A=B=0, p=3/2, q=11/10 lies in the asserted nonexistence region, since the hyperbola sum is 736/105 > 7. It is outside both the cited scaling-exponent region and the cited scaling-spheres upper rectangle. This comparison shows a concrete gap the proposed theorem fills; it is not an exhaustive priority certificate.

This is a substantially stronger endpoint than an isolated refinement or conditional reduction. The proof is supplied in full for its stated class, with no central unproved lemma retained as a hypothesis. Its correctness and novelty still require external specialist review. No historic 10/10 rating is asserted in this record.

## Mathematical mechanism and attribution

The proof develops the localized source-layer pressure construction in OpenAI's September 24, 2026 Newtonian Hénon–Lane–Emden manuscript. The weighted interval comparison, angular cap localization, and source-layer loss argument are credited to that source.

The extension to arbitrary Riesz order requires more than changing the kernel exponent: when s <= 1, individual differentiated potential integrals are generally not absolutely convergent. A simultaneous transport of both source densities gives the needed virial identity through finite local energy differences, avoiding that singular-derivative step entirely. The proof also closes regularity by a precisely cited local Riesz bootstrap and checks every order-dependent cutoff exponent.

The original source's linked Lean declaration contains an unfilled proof placeholder. The supplied new argument does not use that declaration as evidence of correctness; all relevant mathematical interfaces are reconstructed in the manuscript and checked separately.

## Read in this order

1. MAIN_THEOREM.md: complete standalone theorem and analytic proof, including the dimension-one argument in Appendix A.
2. PROOF_AUDIT.md: separate component and full-argument checks, including the final corrected manuscript. ONE_DIMENSIONAL_AUDIT.md separately checks the coincident-line limit and one-dimensional estimates.
3. LOCAL_TRANSPORT_VIRIAL.md: detailed finite-local-difference proof of the new low-order interface.
4. LITERATURE_AND_SCOPE.md: precise historical comparison, regular-versus-singular distinction, and uncovered parameter example.
5. FRACTIONAL_PDE_COROLLARY.md, FRACTIONAL_PDE_REPRESENTATION.md, and FRACTIONAL_PDE_REPRESENTATION_AUDIT.md: the exact full-space weak fractional PDE consequence and its proof.
6. SOURCE_PROVENANCE.md and upstream_source/: immutable source pins, verified blob hashes, attribution, original proof sections, incomplete Lean comparator, and license.

## Verification boundaries

The argument has been read and checked by separate AI-assisted mathematical reviews. This is not external independent verification, peer review, or proof-assistant certification. The literature search is bounded, so historical priority remains provisional. Nothing has been published, submitted to researchers, or pushed to a public repository in this session.

The theorem concerns the strict subcritical nonexistence assertion. The packet does not claim a new existence theorem on the critical/supercritical side, an automatic theorem for every PDE formulation with the same formal powers.
