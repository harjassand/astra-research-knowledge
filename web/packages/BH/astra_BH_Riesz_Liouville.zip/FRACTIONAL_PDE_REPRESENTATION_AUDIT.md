# Independent adversarial audit: fractional PDE representation

Date: 2026-10-09. Audited `FRACTIONAL_PDE_REPRESENTATION.md` only in its stated scope: (n\ge2), (0<s<2), positive continuous weighted-class functions, (A,B>-n), and equations imposed globally in distributions. I did not audit the separate full subcritical integral nonexistence theorem.

## Finding

No fatal gap found. The proof supports the exact pointwise Riesz representations, the nonnegativity and subsequent elimination of the constants, under these hypotheses. In particular, it does not silently extend punctured-domain equations across the origin or make a higher-order claim.

## Adversarial checks

- The lower source approximation is available: (F=|x|^A w^p) is positive and continuous on every compact annulus away from zero, so smooth compactly supported minorants can exhaust those annuli and converge to (F) a.e. The origin is a null set and (F\in L^1_{loc}) follows from (A>-n).
- The ball comparison has the right weak hypotheses. For each smooth source (F_j\le F), its zero-exterior Green solution is continuous and in the weighted class; hence (z=u-U_{R,j}\in\mathcal L_s^1\cap C\), (L_sz=F-F_j\ge0) distributionally in (B_R), and (z\ge0) on the complement. Silvestre's distributional supersolution maximum principle therefore applies. Fatou followed by monotone convergence is legitimate because (G_R,F_j\ge0), and the displayed Green parameter is increasing in (R) for (R>\max(|x|,|y|)); the limit is the normalized Riesz kernel off the diagonal.
- The origin argument correctly forces (A>-s): positivity/continuity of (w) gives (F\ge c|y|^A) near zero, while (G_R(0,y)\gtrsim |y|^{s-n}) there. The resulting integral diverges if (A\le-s). Once this is known, (I_sF(0)<\infty) gives the required weighted source moment, since ((1+|y|^{n+s})^{-1}\lesssim |y|^{s-n}).
- The inverse identity is not merely off-origin. For (H=L_s\phi), its boundedness and (O(|x|^{-n-s})) tail yield (int K_s(x-y)|H(x)|dx\lesssim K_s(y)); the finite moment at zero therefore gives absolute Fubini. The inner Riesz fundamental-solution identity then proves (L_s(I_sF)=F) against every compactly supported test, including tests meeting zero.
- The remainder classification uses exactly the weighted entire Liouville theorem after setting its order parameter to (s/2\in(0,1)). Positivity removes the affine slope. The potential continuity argument is sound: the near-origin piece is (O(r^{A+s})=o(1)), uniformly for (|x|\le r), and the rest is dominated by the finite (K_sF) moment. Away from zero, split off a neighborhood of (x), where (F) is continuous and bounded; the remaining tail is dominated by the same moment. Thus the a.e. constant remainder upgrades to pointwise equality.
- If (c_u>0), the second source dominates (c_u^q|y|^B), whose Riesz potential diverges at infinity because (B+s>0); this contradicts the finite pointwise representation of (v). The symmetric argument kills (c_v).

## Scope/caveat

The global distributional assumption is essential to the inversion and entire-harmonic classification steps. The note correctly withholds any conclusion for equations known only on \(\mathbb R^n\setminus\{0\}\); no origin-removability claim is established here.
