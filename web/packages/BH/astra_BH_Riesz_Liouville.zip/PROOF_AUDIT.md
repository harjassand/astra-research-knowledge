# Independent audit: local Riesz virial lemma

**Verdict:** no fatal gap under the hypotheses stated in `ROOT_FLOW_VIRIAL.md`. The local-difference argument works for every (0<s<n), including (0<s\le1), and does not require absolute integrability of the individual ∇K terms. The estimates below also make two proof details explicit: the kernel difference-quotient bound and the compact support required of the origin cutoff.

Let (D\Subset\mathbb R^n\setminus\{0\}) be an annulus containing the support of (X), and let Φ_t be its flow. Since (X=0) near ∂D, Φ_t(D)=D), and the two pushforward differences (h_t=f_t-f), (k_t=g_t-g) vanish off (D). On ̄D, (h_t/t\to-\operatorname{div}(fX)) and (k_t/t\to-\operatorname{div}(gX)) uniformly. The restricted nonlinear-energy differences are finite; differentiating their integrands at (f,g>0) gives (W_B^{-1/q}f^{1/q}=u) and (W_A^{-1/p}g^{1/p}=v). Thus their first variations are ∫_D u h'_0 and ∫_D v k'_0.

The interaction difference expands as ∫h_tu+∫k_tv+∫h_tK_sk_t. The first two terms are finite, and the last is (O(t^2)): (h_t,k_t=O(t)) uniformly on (D), while (K_s\in L^1_{ loc}) exactly because (s>0). Hence the derivative of the sum of the two local nonlinear differences minus the interaction difference is zero. Separately, change of variables gives

\[
\left(N_f(f_t)-N_f(f)\right)'_{t=0}
=-\frac1{q+1}\int_D fu\bigl(\operatorname{div}X+X\cdot\nabla\log W_B\bigr),
\]

and the analogous expression for (g).

For the simultaneous transport of the interaction, partition into (D\times D), (D\times D^c), (D^c\times D), and (D^c\times D^c). The first three pieces are finite: the compact-piece singularity is locally integrable, and the cross pieces are bounded by the compact-source potential marginals ∫_D fu and ∫_D gv (also after transport). The last piece is unchanged. Consequently the difference is the integral of the kernel difference over pairs with at least one endpoint in (D), without subtracting infinite global energies.

Here is the needed domination. For (r=|x-y|), Lipschitz continuity of (X) and its flow imply
\[
|((\Phi_t x-\Phi_t y)-(x-y))|\le C|t|r.
\]
For sufficiently small |t|, the segment between these two displacement vectors stays at distance at least (r/2) from zero. The mean-value theorem and |∇K_s(z)|=C|z|^{s-n-1} therefore give
\[
\frac{|K_s(\Phi_t x-\Phi_t y)-K_s(x-y)|}{|t|}≤ C K_s(x-y).
\]
The quotient vanishes when both endpoints lie outside (D). Its dominating interaction mass is at most ∫_D fu+∫_D gv<∞. Dominated convergence yields
\[
I'(0)=-(n-s)\int\frac{(X(x)-X(y))\cdot(x-y)}{|x-y|^2}\,d\pi.
\]
The diagonal is a Lebesgue-null set; no separate integral of ∇K is taken. Combining derivatives gives the claimed identity.

For the radial passage, choose χ∈(C_c^\infty\), χ=1 near zero, so (X_\rho=X(1-\chi(\cdot/\rho))) is an admissible field. Its Lipschitz constants are uniformly bounded since |X(x)|=O(|x|). The left-side coefficient errors are uniformly bounded and supported in (B_{C\rho}), so local integrability of (fu,gv) makes them vanish. On the right, the difference quotients are dominated by (C K_s) on pairs with an endpoint in one fixed ball; that interaction mass is finite by the same local marginals. Dominated convergence gives the radial identity through the origin.

Finally, with (m=n+3), (k=n(m+1)), (N=k+n+2=nm+2n+2), replacing the Newton tail ℓ(^{2-n}) by the Riesz tail ℓ(^{s-n}) gives the three cutoff exponents
\[
N-1-m(n-s)=2n+1+ms,\quad
N-m(n+1-s)=n-1+ms,\quad
N-n-m(n-s)=n+2+ms,
\]
all positive for (n\ge2, s>0). The pressure-layer exponents are unchanged: (N-n+k-mn=N) for the high-level loss, and (N-1-k=n+1) for the low-level term. These are arithmetic checks only: solution-uniform tail constants still require the separate uniform local source-mass/potential estimates used by the larger argument; they do not follow from this local virial lemma alone.

## Parallel-line and layer-pressure extension

For distinct parallel lines with transverse gap `lambda > 0`, write `h = s - s'`, `d0 = m_I - m_J`, `K_s = c_s (lambda^2 + h^2)^((s-n)/2)`, and `D_e = h^2/(lambda^2+h^2)`. Then

`partial_s K_s = -(n-s) h/(lambda^2+h^2) K_s`, and `partial_s' K_s = (n-s) h/(lambda^2+h^2) K_s`.

The midpoint integration-by-parts identity is

`integral (2 K_s - Kbar_{s,I} - Kbar_{s,J}) = (n-s) integral [(h^2-d0 h)/(lambda^2+h^2)] K_s`.

The overlap-density argument is unchanged: the density of `h` is `F(|h-d0|)` with `F` nonincreasing, so `d0 integral h K_s/(lambda^2+h^2) >= 0`. Thus the interval-pair inequality has `n-s` in place of `n-2`. Its nonnegative, extended-integral formulation remains essential when one interval weight is zero and the partner is unbounded; the proof never subtracts divergent line integrals. When both weights are positive, both intervals are bounded, so the midpoint calculation is finite.

The angular cap `h_e`, its normalization `E_e h_e = w`, gradient/oscillation estimates, and near/far split do not depend on kernel order. On far pairs, the required tail factor changes from `ell^(2-n)` to `ell^(s-n)`, giving exactly the three positive powers listed above. For source layer loss, the geometric estimate `P_e(|I|>ell) <= C (t ell^n)^-1 integral_{B_ell(x)} f` is unchanged. The high-level factor is `d^(N-n+k-mn)=d^N`; averaging low levels gives `P d^(-k) w <= C P d^(N-1-k)=C P d^(n+1)`. Thus the high-level relative error is `C_{kappa,delta} P^-1 E`, while low levels contribute a uniform additive `C P integral_{B_4} u`. That last bound requires the separate uniform `integral_{B_4} u` estimate.

For anisotropic weights `W_B(x)=|x|^B b(x/|x|)` with positive `C^1` angular coefficient, the exact layer identity still holds with `tau=(t/W_B(x))^(1/q)`. On `1 <= |x| <= 2`, `grad log W_B` is bounded, so endpoints within `2 delta d(x)` give `|u_bar_I - tau| <= C delta d(x) u(x)`; the analogous bound holds for `g`. Cap-pressure approximation and `d w <= C eta` are unaffected. After averaging directions, the pressure inequality has `n-s` in front of `integral w D d-pi`; the cap-angle relative error is `C(n-s) kappa`, independent of `delta,P`, the high-level coefficient is `C_{kappa,delta} P^-1`, and the remaining relative errors are `C_kappa delta` (plus the `C delta E` endpoint error). The parameter order `kappa`, then `delta`, then `P` still closes it.

**Dependency to keep explicit:** solution-uniform additive constants in localization and pressure require the generalized tail estimate `integral_{|x-y|>=ell} K_s(x-y)(f(y)+g(y)) dy <= C ell^(s-n)` and uniform `integral_{B_4}(f+g+u+v) <= C`. In the larger proof these follow only after separate centered source-mass bounds with positive decay exponents; they do not follow from the local virial/interface assumptions alone. Pressure reconstruction also requires the exact potential identities `u=K_s*g`, `v=K_s*f`.

## Standalone-proof scope verdict

I checked the current `anisotropic_hle_transfer/RIESZ_HLE_STANDALONE.md` end to end against the stated positive continuous, everywhere-finite-potential integral class. No material missing hypothesis or gap found, provided the identified editorial fixes are made. In particular:

- The origin test gives (A,B>-s), hence all four local integrabilities (f,g,fu,gv\in L^1_{loc}). The ball lower bounds have exponent (s+A+p(s+B)>0), so (pq\le1) is excluded before defining α,β. Then (pq>1) gives α,β>0, the scaling exponents satisfy (p\beta=\alpha+s+A), (q\alpha=\beta+s+B), and the source scaling yields the centered mass bounds. The dyadic tails sum by α,β>0; compact Riesz integrability yields (7), and the split at (B_8) yields (8).
- Silvestre's author-PDF Propositions 2.8–2.9 state the bounded-RHS Hölder gain and the Hölder-RHS gain used here. For the localized potential (U=K_s*(\chi g)), (U\in L^\infty) and ((-Δ)^{s/2}U) is a fixed multiple of χg. The complementary potential is smooth near the smaller compact set: the cutoff separates its source from that set, and all kernel derivatives there are dominated by (C_QK_s(x_0-y)), integrable by the finite potential at any fixed (x_0\in Q). Iterating with nested annuli/cutoffs is finite and gives (C^1_{loc}) off zero for (s\le1); for (s>1), ∇K_s\in L^1_{loc}) gives (C^1) for the localized convolution directly. Primary reference: [Silvestre, author PDF](https://www.math.uchicago.edu/~luis/preprints/The%20Obstacle%20problem%20for%20the%20fractional%20laplacian.pdf), Propositions 2.8–2.9.
- The stated solution class is enough for (10), every local transport difference, the origin cutoff passage, and finiteness-before-subtraction in the pressure argument. The uniform estimates come separately from (6)–(8); no global interaction or energy finiteness is tacitly needed.
- The closure has γ=(1-a-b)(α+β+s-n)>0 exactly by the strict gap, and the localized virial/pressure inequalities absorb errors using |E_f-E_g|. Scaling the already obtained uniform (B_1) energy bound contradicts α+β+s-n>0.

Editorial prerequisites for a clean standalone statement: define α,β only after establishing (pq>1); assign (f(0)=g(0)=0) for the level-set measurability discussion; state (D_e=h^2/(\lambda^2+h^2)) explicitly; and make the flow domination quantitative via |(\Phi_t x-\Phi_t y)-(x-y)|\le C|t||x-y|), so the displacement segment stays away from zero for small (t). The theorem's final scope limitation is correct: it proves only the direct Riesz integral system, not a fractional-PDE-to-integral reduction.

### Final reread after manuscript edits

Re-read the current standalone manuscript top/Section 1 and the transport/localization/pressure/closure sections. The requested editorial corrections are now present: α,β are defined only after (pq>1); (f(0)=g(0)=0) is explicit; both global (D_e) and its line restriction are defined; the flow perturbation has the quantitative (C|t||x-y|) displacement bound; and the regularity bootstrap specifies nested annuli/cutoffs. With those edits, my final scope verdict is that the stated proof is complete for the direct positive continuous integral-equation class with finite potentials at every point. The source-mass/tail bounds, Silvestre regularity bootstrap, finite-before-subtraction arguments, and final γ-gap/scaling contradiction fit together under exactly that class. I found no additional material hypothesis or analytic gap. This is an independent mathematical audit, not a formal certificate or a claim of exhaustive literature/priority verification.
