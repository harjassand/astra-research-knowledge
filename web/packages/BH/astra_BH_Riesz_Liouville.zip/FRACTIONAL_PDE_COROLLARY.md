# Full-space fractional Hénon–Lane–Emden corollary

## Statement

Let \(n\ge2\), \(0<s<2\), \(p,q>0\), and \(A,B>-n\). Define the natural fractional tail class
\[
\mathcal L_s^1=\left\{w\in L^1_{\rm loc}(\mathbb R^n):
\int_{\mathbb R^n}\frac{|w(x)|}{1+|x|^{n+s}}\,dx<\infty\right\}.
\]
There are no strictly positive functions
\[
u,v\in C(\mathbb R^n)\cap\mathcal L_s^1
\]
satisfying
\[
(-\Delta)^{s/2}u=|x|^A v^p,\qquad
(-\Delta)^{s/2}v=|x|^B u^q
\quad\text{in }\mathcal D'(\mathbb R^n)
\]
if
\[
\frac{n+A}{p+1}+\frac{n+B}{q+1}>n-s.
\]
The distributional equations must hold for tests through the origin as well as away from it. The right-hand sides are ordinary locally integrable functions. No radial symmetry, stability, global boundedness, or finite-energy assumption is imposed. The displayed tail condition is part of the standard distributional definition used here and is not omitted.

## Proof

The representation lemma in FRACTIONAL_PDE_REPRESENTATION.md applies to this exact weak class. Positivity and comparison with ball Green potentials first give
\[
I_s(|\cdot|^A v^p)\le u,\qquad I_s(|\cdot|^B u^q)\le v.
\]
Finiteness at zero forces \(A,B>-s\). The globally fractional-harmonic remainders are nonnegative constants; each constant vanishes because a positive lower bound on one component would make the other Riesz potential diverge at infinity. The representation is pointwise everywhere, including zero. Hence the pair satisfies the exact Riesz integral equations in MAIN_THEOREM.md with the normalized positive kernel. Since \(0<s<2\le n\), its order is in the integral theorem's range \(0<s<n\). The strict subcritical integral theorem therefore gives a contradiction.

The attached representation note supplies the weak maximum-principle argument, Green limit, source moment, absolute Fubini identity, harmonic-remainder classification, and a.e.-to-pointwise step. Its primary references are identified precisely. This corollary does not cover arbitrary off-origin equations with no extension condition or arbitrary higher-order PDE formulations.

## Verification status

This is an analytic consequence of the supplied integral proof and the separately checked representation lemma. Both have received separate AI-assisted proof checks; neither has external specialist review or a proof-assistant certificate. The result's mathematical scope is explicit, and historical priority remains provisional.
