# Source provenance and verification boundaries

The proof mechanism comes from OpenAI, *The Subcritical Hénon–Lane–Emden Conjecture*, September 24, 2026, family 370 in the OpenAI Math repository.

Immutable revision accessed: fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb.

[Source manuscript directory](https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Subcritical-Henon-Lane-Emden-Conjecture-September-24-2026)

The upstream_source folder contains unmodified copies of the exact proof sections inspected, the manuscript README and author attribution, the associated Lean comparator, and the repository's Apache 2.0 license. Git blob hashes of the local source copies were recomputed and matched the connector's returned hashes:

- 02-preliminaries.tex: 4d0b73f7b963ab83b0de5e2d063b0669b40ba567
- 03-localization.tex: a1660194caa44b79d8df552b76478059843120a5
- 04-intervals.tex: 25e10d1a86a3b5ed3f9f77de3d54ad413c805adf
- 05-pressure.tex: d3deb4a82a9c3b45b3f2e4c0862ba88bb5a54bcd
- 06-conclusion.tex: 0d1abfe015aac929e93ef441f98d8c1a5de8dd71
- HenonEmden.lean: 6481354cae9713ce9f1e0db2ec5eb06a42c649ef
- README.md: 54bd8275076ded528ceb89e683ee53ddeff909b5
- LICENSE: 261eeb9e9f8b2b4b0d119366dda99c6fd7d35c64

The exact theorem declaration in [HenonEmden.lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/ComparatorChallenges/HenonEmden.lean) ends in an unfilled `sorry`. It is not a machine-checked proof of the source's nonexistence theorem.

The new manuscript is a modified and extended mathematical reconstruction of the source mechanism, not an unmodified upstream file. It replaces the Newton kernel by arbitrary Riesz order, proves the required low-order virial with simultaneous transport of both source densities, checks every changed tail exponent, and uses a standard local regularity theorem to cover the stated continuous solution class. Its core interval and source-layer arguments are attributed to the upstream manuscript and are reproduced as mathematical derivations rather than invoked as an unverified black-box theorem.

The new proof has undergone separate AI-assisted component and whole-argument checks. Those are not external independent specialist review or formal verification. Historical priority is assessed by a bounded primary-literature comparison, not established by the absence of a matching search result. Nothing in this record has been published, submitted, or pushed to a public repository by this research session.

Astra navigation revision used in selecting the direction: 39cdea532f19217f633f70315d92c314a6ce5e3e. That repository is research navigation and context; its prior claimed results are not assumptions in the theorem proved in the accompanying manuscript.
