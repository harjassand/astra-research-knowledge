# Focused independent review brief

Verify or refute the complete theorem in MAIN_THEOREM.md. Do not assume correctness from the source repository, proof length, or agreement among earlier AI-assisted checks. The intended outcome is either a precise mathematical gap/counterexample, or a reconstruction that discharges every hypothesis for the stated solution class.

Prioritize these interfaces:

1. Universal centered source-mass estimates and positive scaling exponents without global boundedness, decay, radiality, or finite energy.
2. Local regularity bootstrap from continuous finite integral solutions, including small Riesz orders.
3. Simultaneous source-density transport: stationarity from finite local differences, safe changes of variables with infinite total interaction, and domination of the kernel difference quotient.
4. The weighted two-interval midpoint inequality, especially mismatched interval weights and unbounded components assigned zero weight.
5. Directional cap selection and the high-/low-level source-layer loss estimate. Check the dependence and ordering of constants, not just formal exponents.
6. Tonelli before subtraction: prove every integrated endpoint, pressure, and mismatch term is finite for each solution without inserting an unassumed global energy bound.
7. The final cutoff-energy absorption and centered scaling contradiction for arbitrary positive p,q in the strict hyperbola region.
8. Any one-dimensional appendix: coincident-line regularization, monotone convergence of all nonnegative terms, and the two-point sphere measure.
9. The fractional PDE corollary separately: exact weak maximum-principle hypotheses, the whole-space Green limit, absolute Fubini for the fundamental solution, affine remainder, origin continuity, and elimination of constants.
10. Historical scope: distinguish globally continuous finite solutions from singular almost-everywhere solutions; compare direct integral and PDE hypotheses exactly. Check whether an earlier theorem already covers the full stated class.

The central pressure mechanism is inherited from the pinned OpenAI family-370 manuscript and is reproduced in the new argument. Its linked Lean proof is incomplete. Treat the analytic proof itself as the object to review. The arbitrary-order extension and low-order transport interface must stand on their written justifications.

A weaker integrability/radial theorem, a parameter rectangle, or validation only for s>1 does not verify the full claim. Conversely, a singular a.e. solution that diverges at zero does not refute the stated continuous finite solution class.
