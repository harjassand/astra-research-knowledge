# Literature and scope assessment

## Claim being assessed

For $n\ge2$, $0<s<n$, $p,q>0$, and $A,B\in\mathbb R$, consider strictly positive continuous functions $u,v:\mathbb R^n\to(0,\infty)$, finite everywhere, satisfying pointwise
\[
u(x)=c\int_{\mathbb R^n}\frac{|y|^A v(y)^p}{|x-y|^{n-s}}\,dy,\qquad
v(x)=c\int_{\mathbb R^n}\frac{|y|^B u(y)^q}{|x-y|^{n-s}}\,dy
\]
for a fixed $c>0$. The proposed theorem excludes such solutions when
\[
\frac{n+A}{p+1}+\frac{n+B}{q+1}>n-s.
\]

The class is globally continuous and finite, but imposes no radiality, decay, boundedness, stability, or global integrability/finite-energy condition. This explicit class matters: origin finiteness forces $A,B>-s$, and positivity plus the equations forces $pq>1$.

## Historical conjecture and solution-class caveat

Caristi, D’Ambrosio, and Mitidieri, “Representation Formulae for Solutions to Some Classes of Higher Order Systems and Related Liouville Theorems,” *Milan Journal of Mathematics* 76 (2008), 27–67, [DOI: 10.1007/s00032-008-0090-3](https://doi.org/10.1007/s00032-008-0090-3), §5, introduce the unweighted HLS integral system and state its “HLS Conjecture”: for $N>\alpha>0$, $p,q>0$, if
\[
\frac1{p+1}+\frac1{q+1}>\frac{N-\alpha}{N},
\]
then the system has no nontrivial positive solutions. The conjecture sentence does not specify a function space or explicitly say whether the integral equations are required pointwise everywhere or only almost everywhere. Do not recast it as a theorem about all measurable a.e. solutions.

Their proved radial result is more precise: Theorem 5.1 assumes $N>\alpha\ge2$, $p,q>0$, and a nonnegative radial solution in $C^2(\mathbb R^N)\times C^2(\mathbb R^N)$; it concludes zero under the same hyperbola. Remark 5.3 identifies the radial case $0<\alpha<2$ as open at that time. The paper discusses PDE/integral representation formulas holding a.e. under suitable hypotheses, so a result for the direct pointwise integral system should not automatically be presented as a resolution of every associated PDE formulation.

There are singular a.e. counterexamples to an unrestricted measurable interpretation. In the scalar case $p=q$ with $p>n/(n-s)$, the power
\[
u(x)=C|x|^{-s/(p-1)}
\]
has locally integrable source and, by homogeneity, satisfies $u=I_s(u^p)$ for $x\ne0$ after choosing $C>0$. For $p<(n+s)/(n-s)$, its exponent is locally integrable as well and the parameters lie on the subcritical side of the scalar hyperbola. At $x=0$ the potential diverges. Thus this is an a.e. solution, not a globally finite pointwise solution. The theorem’s regularity/finite-everywhere hypothesis excludes it; claims should be confined to that explicit class.

## Closest established regions

- **Unweighted historical HLS literature.** Chen–Li, “An integral system and Lane-Emden conjecture,” *DCDS* 24 (2009), [DOI: 10.3934/dcds.2009.24.1167](https://doi.org/10.3934/dcds.2009.24.1167), study the direct integral formulation and establish results under integrability assumptions (including symmetry methods). This does not give the proposed no-global-integrability theorem.
- **Weighted, general Riesz order, radial hyperbola.** Villavert, “Sharp existence criteria for positive solutions of Hardy–Sobolev type systems,” *CPAA* 14 (2015), 493–515, [arXiv:1401.5454](https://arxiv.org/abs/1401.5454), Theorem 5, proves the weighted hyperbola in the radial class for $2\le\alpha<n$, with its stated admissible weight ranges and $p,q>0$. Its convention is denominator weights $|y|^{-\sigma_i}$, hence for the target $\sigma_1=-A,\sigma_2=-B$, with its cross-exponents interchanged relative to the target labels. The result is not for arbitrary real weights or arbitrary nonradial solutions.
- **Weighted, general order, unrestricted but partial scaling region.** The same paper’s Theorem 6 gives nonexistence without radiality in a rectangle specified by scaling exponents (and allows double-bounded coefficients); it does not fill the hyperbola. The target’s unweighted example below lies outside that rectangle.
- **Nonradial result with decay assumptions.** Villavert, “Qualitative properties of solutions for an integral system related to the Hardy–Sobolev inequality,” *JDE* 258 (2015), 1685–1714, [DOI: 10.1016/j.jde.2014.11.011](https://doi.org/10.1016/j.jde.2014.11.011), Theorem 2, proves a weighted hyperbola result for bounded, decaying positive classical solutions when $1<\alpha<n$. The bounds/decay are additional assumptions; this does not reach $\alpha=1$.
- **Additional direct-integral rectangle predecessor.** Phuong Le, *Journal of Differential Equations* (2021), [DOI: 10.1016/j.jde.2021.06.041](https://doi.org/10.1016/j.jde.2021.06.041), is a direct integral-system nonexistence predecessor in a rectangular/partial parameter region, not the complete hyperbola in the present class.
- **Fractional PDE and related integral regions.** Cao–Qin, *DCDS* (2021), [DOI: 10.3934/dcds.2020361](https://doi.org/10.3934/dcds.2020361), prove fractional PDE/integral results in a restricted parameter region (including an upper rectangle; at zero weights $p\le(n+s)/(n-s)$, $q\le(n+s)/(n-s)$). For $n=8,s=1,p=1.5,q=1.1$, the $p$-bound is $9/7$, so this rectangle does not cover the example. PDE results retain their own solution-class and representation hypotheses.
- **Related 2024 fractional PDE work.** Li–Yu–Zhang, *NoDEA* (2024), [DOI: 10.1007/s00030-023-00903-6](https://doi.org/10.1007/s00030-023-00903-6), gives fractional PDE Liouville results in bounded parameter regions and discusses equivalence to integral systems under suitable assumptions. It does not cover the full pointwise weighted claim here.

## Quantitative example outside the known rectangles

For $n=8,s=1,A=B=0,p=1.5,q=1.1$,
\[
\frac{n+A}{p+1}+\frac{n+B}{q+1}
=\frac{8}{2.5}+\frac{8}{2.1}
=\frac{736}{105}\approx7.00952>7=n-s.
\]
The Villavert scaling quantities in the unweighted case are
\[
\frac{s(1+p)}{pq-1}=\frac{50}{13}\approx3.846,\qquad
\frac{s(1+q)}{pq-1}=\frac{42}{13}\approx3.231,
\]
both below $n-s=7$, so Theorem 6’s unrestricted rectangle does not cover it. Cao–Qin’s zero-weight upper bound also fails since $p=1.5>9/7$. Thus the example is a concrete subcritical hyperbola point beyond those cited regions.

## Recent claims and priority

A September 24, 2026 OpenAI Math Release preprint claims a weighted local/Newtonian Hénon–Lane–Emden theorem (Riesz order $s=2$) in a regular class without radial or growth assumptions. It is an unreviewed preprint and does not settle arbitrary fractional Riesz orders. The corresponding Lean declaration exists, but main_nonexistence ends in by sorry; that is an incomplete proof placeholder, not a formal proof. See the [preprint repository README](https://github.com/openai/math/blob/main/preprints/The-Subcritical-Henon-Lane-Emden-Conjecture-September-24-2026/README.md) and [paper PDF](https://github.com/openai/math/blob/main/preprints/The-Subcritical-Henon-Lane-Emden-Conjecture-September-24-2026/paper.pdf).

**Assessment:** If proved, the proposed theorem would be a major full-regular-class weighted HLS Liouville endpoint: arbitrary fractional Riesz order and real power weights in the stated pointwise class, beyond radiality, decay, boundedness, and global-integrability assumptions. It should not be advertised as excluding singular measurable a.e. solutions or as automatically settling all PDE Lane–Emden formulations. This was a targeted, bounded literature scan; it cannot establish absolute priority. The defensible statement is that no peer-reviewed source was found in this scan proving the full proposed theorem and class, while nearby results leave identifiable gaps.
