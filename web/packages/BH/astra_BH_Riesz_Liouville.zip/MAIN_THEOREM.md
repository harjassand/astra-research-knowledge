# A Liouville theorem for homogeneous Riesz integral systems

Date: 9 October 2026. This manuscript records a proposed complete proof transfer from the pinned OpenAI Math family-370 Hénon–Lane–Emden manuscript, commit fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb, Sections 02–06. It is a mathematical proof document for the integral-equation class below, not a formal certification and not an exhaustive priority determination.

## Theorem

Let \(n\ge1\), \(0<s<n\), \(p,q>0\), and \(A,B\in\mathbb R\). Fix \(c_s>0\) and define \(K_s(x)=c_s|x|^{s-n}\) for \(x\ne0\). There do not exist strictly positive \(u,v\in C(\mathbb R^n)\) such that the two potentials are finite for every \(x\) and
\[
u(x)=\int_{\mathbb R^n}K_s(x-y)|y|^A v(y)^p\,dy,\qquad
v(x)=\int_{\mathbb R^n}K_s(x-y)|y|^B u(y)^q\,dy
\tag{1}
\]
whenever
\[
\frac{n+A}{p+1}+\frac{n+B}{q+1}>n-s.
\tag{2}
\]
Equation (1) is the hypothesis. No assertion is made here that every solution of a fractional PDE has this Riesz representation.

Set
\[
f(x)=|x|^B u(x)^q,\qquad g(x)=|x|^A v(x)^p,\qquad \mu=n-s,
\]
with the explicit convention \(f(0)=g(0)=0\). Also put
\[
a=\frac1{q+1},\qquad b=\frac1{p+1}.
\tag{3}
\]
Constants denoted by \(C\) may depend on the fixed equation parameters \(n,s,A,B,p,q,c_s\), but not on a particular solution. Subscripts record permitted dependence on auxiliary parameters.

## 1. Origin restrictions, superlinearity, scaling, and tails

The equations force \(A,B>-s\). For example, if \(A\le-s\), continuity and \(v(0)>0\) give \(g(y)\ge c|y|^A\) near zero. For \(x\to0\), on the annulus \(2|x|<|y|<r_0\), \(|x-y|\) is comparable to \(|y|\), so
\[
u(x)\ge c\int_{2|x|}^{r_0}r^{A+s-1}\,dr\longrightarrow\infty.
\]
This contradicts continuity. Interchange the equations to get \(B>-s\). Since \(s<n\), both weights are locally integrable, and \(f,g,fu,gv\in L^1_{\rm loc}\).

For \(R>0\), define \(m_u(R)=\inf_{B_R}u>0\), \(m_v(R)=\inf_{B_R}v>0\). Since \(K_s(x-y)\ge cR^{s-n}\) for \(x,y\in B_R\),
\[
m_u(R)\ge cR^{s+A}m_v(R)^p,\qquad
m_v(R)\ge cR^{s+B}m_u(R)^q.
\]
Combining gives
\[
m_u(R)^{1-pq}\ge cR^{s+A+p(s+B)}.
\]
The exponent on the right is positive. If \(pq<1\), the left is at most \(u(0)^{1-pq}\); if \(pq=1\), it equals one. Both contradict \(R\to\infty\). Thus \(pq>1\). Only now define
\[
\alpha=\frac{s+A+p(s+B)}{pq-1},\qquad
\beta=\frac{s+B+q(s+A)}{pq-1}.
\]
Both are positive, and direct algebra gives
\[
p\beta=\alpha+s+A,\qquad q\alpha=\beta+s+B.
\tag{4}
\]

The centered dilates \(u_R(x)=R^\alpha u(Rx)\), \(v_R(x)=R^\beta v(Rx)\) again solve (1), and
\[
f_R(x)=R^{s+\beta}f(Rx),\qquad
g_R(x)=R^{s+\alpha}g(Rx).
\tag{5}
\]

Let \(M_f=\int_{B_1}f\), \(M_g=\int_{B_1}g\). The ball lower bounds at \(R=1\), integrated against \(|x|^B\) and \(|x|^A\), give \(M_f\ge cM_g^q\), \(M_g\ge cM_f^p\). Since \(pq>1\) and both masses are positive, they have universal upper bounds. Apply these same bounds to every scaled solution and change variables in (5). This proves
\[
\int_{B_R}f\le CR^{n-s-\beta},\qquad
\int_{B_R}g\le CR^{n-s-\alpha}\qquad(R>0).
\tag{6}
\]

For \(x\in B_4\), the contribution of the source annulus \(2^j\le|y|<2^{j+1}\) to \(K_s*g(x)\) is at most \(C2^{j(s-n)}\int_{B_{2^{j+1}}}g\le C2^{-j\alpha}\); similarly the \(f\)-potential tail is at most \(C2^{-j\beta}\). Thus the source potentials outside \(B_8\) are uniformly bounded on \(B_4\). Also,
\[
\sup_{y\in B_8}\int_{B_4}K_s(x-y)\,dx\le\int_{B_{12}}K_s(z)\,dz<\infty.
\]
Tonelli's theorem and (6) now give
\[
\int_{B_4}(f+g+u+v)\le C.
\tag{7}
\]
If \(x\in B_2\) and \(0<\ell\le1\), the part \(y\in B_8,\ |x-y|\ge\ell\) is bounded by \(C\ell^{s-n}\) using (6), and the far part \(y\notin B_8\) is bounded by \(C\le C\ell^{s-n}\). Consequently
\[
\int_{|x-y|\ge\ell}K_s(x-y)(f(y)+g(y))\,dy\le C\ell^{s-n}.
\tag{8}
\]

## 2. Local regularity off the origin

The transport identity below uses \(f,g\in C^1\) away from zero. This follows from standard Riesz-potential regularity; the precise estimates needed are Silvestre, “Regularity of the obstacle problem for a fractional power of the Laplace operator,” Propositions 2.8–2.9, pp. 10–11 ([author PDF](https://www.math.uchicago.edu/~luis/preprints/The%20Obstacle%20problem%20for%20the%20fractional%20laplacian.pdf)).

Fix compact sets \(Q\Subset Q'\Subset\mathbb R^n\setminus\{0\}\), and choose smooth \(\chi\) supported away from zero and equal to one near \(Q'\). On this region the weights are smooth, and \(u,v\) are bounded above and below by positive constants. Thus \(\chi g\) is bounded and compactly supported. The localized potential \(U=K_s*(\chi g)\) is bounded globally, since \(K_s\) is locally integrable and the source is bounded and compactly supported. Up to a fixed nonzero normalization factor, \((-\Delta)^{s/2}U=\chi g\). The complementary potential \(K_s*((1-\chi)g)\) is smooth near \(Q\): every derivative of its kernel is bounded there by \(C_QK_s(x_0-y)\), which is integrable against \(g\) by (1).

If \(0<s\le1\), take \(\sigma=s/2\). Silvestre's Proposition 2.9 says that bounded \(U\) with bounded \((-\Delta)^\sigma U\) is \(C^{0,\rho}\) for each \(\rho<2\sigma=s\). Proposition 2.8 says that if \((-\Delta)^\sigma U\in C^{0,\rho}\), then \(U\) gains \(2\sigma=s\) Hölder orders, and is \(C^1\) whenever \(\rho+s>1\). Initially both localized sources are bounded, so \(u,v\) are locally \(C^{0,\rho}\) for all \(\rho<s\). Positivity and the smoothness of \(t\mapsto t^p,t^q\) on compact positive intervals imply that the sources then have the same local Hölder regularity. Recut on nested compact annuli and apply Proposition 2.8 repeatedly, choosing at least \(s/2\) Hölder gain each time until \(\rho+s>1\). This takes finitely many steps. If \(s>1\), \(\nabla K_s\in L^1_{\rm loc}\), so convolution of a bounded localized source is already \(C^1\). Thus in all cases
\[
u,v,f,g\in C^1_{\rm loc}(\mathbb R^n\setminus\{0\}).
\tag{9}
\]

## 3. The localized virial identity by simultaneous transport

Define
\[
d\pi(x,y)=f(x)g(y)K_s(x-y)\,dx\,dy.
\]
By (1), its marginals are
\[
\pi(dx,\mathbb R^n)=f(x)u(x)\,dx,\qquad
\pi(\mathbb R^n,dy)=g(y)v(y)\,dy.
\tag{10}
\]
Let \(X\in C_c^1(\mathbb R^n\setminus\{0\};\mathbb R^n)\). Let \(\Phi_t\) be its flow and \(J_t\) its Jacobian, and push both densities forward by
\[
f_t(\Phi_t x)=f(x)/J_t(x),\qquad
g_t(\Phi_t y)=g(y)/J_t(y).
\]
Take a bounded annulus \(D\Subset\mathbb R^n\setminus\{0\}\) containing the support of \(X\). The flow fixes the boundary and maps \(D\) to itself. The differences \(h_t=f_t-f\), \(k_t=g_t-g\) are supported in \(D\) and are \(O(t)\) uniformly by (9).

Use only local differences of the functionals
\[
N_f=\frac q{q+1}\int |x|^{-B/q}f^{1+1/q},\quad
N_g=\frac p{p+1}\int |x|^{-A/p}g^{1+1/p},\quad
I=\iint f(x)g(y)K_s(x-y)\,dx\,dy.
\]
The full integrals need not be finite; their differences under this flow are well-defined because all changes occur in \(D\). Since \(|x|^{-B/q}f^{1/q}=u=K_s*g\) and \(|x|^{-A/p}g^{1/p}=v=K_s*f\), the first variations of \(N_f,N_g\) are \(\int_D u h'_0\), \(\int_D v k'_0\). Expanding the interaction in source variables gives
\[
I(f_t,g_t)-I(f,g)=\int_D h_tu+\int_D k_tv+
\iint h_t(x)K_s(x-y)k_t(y)\,dx\,dy.
\]
The last term is \(O(t^2)\), since \(K_s\in L^1_{\rm loc}\) and \(h_t,k_t=O(t)\) on \(D\). Thus the first variation of \(N_f+N_g-I\) is zero.

Direct change of variables in \(N_f,N_g\) gives
\[
N_f'(0)=-a\int fu\bigl(\operatorname{div}X+X\cdot\nabla\log|x|^B\bigr),
\]
\[
N_g'(0)=-b\int gv\bigl(\operatorname{div}X+X\cdot\nabla\log|x|^A\bigr).
\tag{11}
\]
To differentiate \(I\) without separate singular kernel-gradient integrals, transport both variables:
\[
I(f_t,g_t)-I(f,g)=\iint f(x)g(y)
\left[K_s(\Phi_t x-\Phi_t y)-K_s(x-y)\right]dx\,dy.
\]
This is legitimate despite a possibly infinite total interaction: partition into \(D\times D,D\times D^c,D^c\times D,D^c\times D^c\). The first three pieces are finite by (10), and the last is unchanged. Since \(\Phi_t-\mathrm{id}\) has Lipschitz norm at most \(C|t|\),
\[
| (\Phi_t x-\Phi_t y)-(x-y)|\le C|t|\,|x-y|.
\]
Thus the flow is uniformly bi-Lipschitz for small \(t\), the difference quotient is bounded by \(CK_s(x-y)\), and it is zero if both endpoints are outside \(D\). The dominating interaction mass is at most \(\int_Dfu+\int_Dgv<\infty\). Dominated convergence and homogeneity of \(K_s\) imply
\[
I'(0)=-\mu\iint
\frac{(X(x)-X(y))\cdot(x-y)}{|x-y|^2}\,d\pi(x,y).
\tag{12}
\]
Combining stationarity, (11), and (12), for every such \(X\),
\[
\begin{aligned}
a\int fu\bigl(\operatorname{div}X+X\cdot\nabla\log|x|^B\bigr)
+b\int gv\bigl(\operatorname{div}X+X\cdot\nabla\log|x|^A\bigr)
=\mu\iint\frac{(X(x)-X(y))\cdot(x-y)}{|x-y|^2}\,d\pi.
\end{aligned}
\tag{13}
\]

We also need \(X=x\eta(|x|)\), which does not vanish near the origin. Let \(\chi\) be smooth, radial, equal to one on \(B_1\), supported in \(B_2\), and set \(X_\rho(x)=X(x)(1-\chi(x/\rho))\). These fields are supported away from zero, have uniformly bounded Lipschitz constants, and a common compact support. The left-side error is supported in \(B_{2\rho}\); the divergence and \(X_\rho\cdot\nabla\log|x|^{A,B}\) terms are uniformly bounded there. Since \(fu,gv\in L^1_{\rm loc}\), that error tends to zero. On the right, the integrands are uniformly bounded and vanish unless at least one endpoint lies in the common compact support; that interaction mass is finite by (10). Dominated convergence extends (13) to \(X=x\eta\).

Choose
\[
r(x)=\min\{1,(2-|x|)_+\},\quad m=n+3,\quad k=n(m+1),\quad N=k+n+2,
\]
\[
\eta(x)=\big[(1-(|x|-1)_+^3)_+\big]^N,\quad
w(x)=-x\cdot\nabla\eta(x),\quad X(x)=x\eta(x).
\tag{14}
\]
This cutoff is \(C^2\), supported in the closed ball \(\overline B_2\), vanishes outside it, and equals one on \(B_1\). It satisfies
\[
r^N\le\eta\le Cr^N,\quad |\nabla\eta|+w\le Cr^{N-1},
\]
\[
|\nabla^2\eta|+|\nabla w|+|\nabla^2X|\le Cr^{N-2},\quad rw\le C\eta.
\tag{15}
\]
Define
\[
E_f=\int\eta fu,\quad E_g=\int\eta gv,\quad E=E_f+E_g,\qquad
W_f=\int wfu,\quad W_g=\int wgv.
\tag{16}
\]
These are finite for each solution since \(u,v\) are locally bounded and \(A,B>-s>-n\). For radial \(X=x\eta\),
\[
\operatorname{div}X+X\cdot\nabla\log|x|^B=(n+B)\eta-w,
\]
and likewise for \(A\). Equation (13) becomes
\[
a(n+B)E_f+b(n+A)E_g-aW_f-bW_g
=\mu\iint\Phi(x,y)\,d\pi,\qquad
\Phi(x,y)=\frac{(X(x)-X(y))\cdot(x-y)}{|x-y|^2}.
\tag{17}
\]
The integral is absolutely convergent because \(\Phi\) is bounded by \(\operatorname{Lip}(X)\) and zero when both endpoints lie outside \(B_2\).

## 4. Localization of the virial integrand

Let
\[
D(x,y)=\frac{((x-y)\cdot\hat x)^2}{|x-y|^2}
\]
for \(x\ne0,x\ne y\), with arbitrary values on the negligible exceptional sets. For every unit vector \(e\), also define globally
\[
D_e(x,y)=\frac{((x-y)\cdot e)^2}{|x-y|^2}\quad(x\ne y),
\]
with any value on the diagonal. The line quantity \(\mathcal D_e(t,t')\) in Section 5 is this same function restricted to the two parallel lines. We prove, for every \(\varepsilon>0\),
\[
|E_f-E_g|+\iint|\Phi(x,y)-\eta(x)+w(x)D(x,y)|\,d\pi
\le\varepsilon E+C_\varepsilon.
\tag{18}
\]

Fix \(0<\delta<1/4\), and put \(\ell(z)=\delta r(z)^m\) when \(r(z)>0\). A pair is close if \(|x-y|\le\ell(z)\) for at least one endpoint \(z\) with \(r(z)>0\); all other pairs are far. Since \(r\) is 1-Lipschitz and \(\ell(z)\le\delta r(z)\), \(r\) along the segment of a close pair is comparable to \(r(z)\). Taylor expansion using (15) and \(\nabla X=\eta I-w\hat x\otimes\hat x\) gives
\[
|\Phi-\eta(x)+w(x)D|+|\eta(x)-\eta(y)|
\le C\delta r(z)^{N-2+m}\le C\delta r(z)^N.
\]
Since \(r(z)^N\le\eta(z)\le\eta(x)+\eta(y)\), the marginals (10) bound the close-pair integrals by \(C\delta E\).

For far pairs, if endpoint \(z\in B_2\), then \(|x-y|>\ell(z)\). The cutoff bounds and \(0\le D\le1\) give
\[
|\Phi-\eta(x)+w(x)D|+|\eta(x)-\eta(y)|
\le C\sum_{\substack{z\in\{x,y\}\\r(z)>0}}
\left(r(z)^{N-1}+\frac{r(z)^N}{\ell(z)}\right).
\]
For the \(x\)-endpoint, (8) bounds the integral by
\[
C\int_{B_2}f(x)\left(r(x)^{N-1}\ell(x)^{-\mu}
+r(x)^N\ell(x)^{-\mu-1}\right)dx.
\]
With (14), the powers of \(r\) are
\[
N-1-m\mu=2n+1+ms>0,\qquad
N-m(\mu+1)=n-1+ms>0.
\]
Thus this integral is bounded by \(C_\delta\int_{B_2}f\le C_\delta\). The \(y\)-endpoint is the same with \(g\). Finally, (10) gives
\[
E_f-E_g=\iint(\eta(x)-\eta(y))\,d\pi.
\]
We have proved \(|E_f-E_g|+\iint|\Phi-\eta(x)+wD|d\pi\le C\delta E+C_\delta\); choosing \(\delta\) small proves (18).

## 5. The weighted interval lemma

Fix a unit vector \(e\) and parallel lines \(x=z+te\), \(y=z'+t'e\), \(z,z'\in e^\perp\), with \(\lambda=|z-z'|\) and \(h=t-t'\). For distinct lines, \(\lambda>0\). First take bounded intervals \(I,J\) on the lines; let \(m_I,m_J\) be their midpoints, \(\zeta=m_I-m_J\), and let \(\overline{\mathcal K}_I,\overline{\mathcal K}_J\) be the means of the line kernel at the two respective endpoints. The weighted conclusion below allows possibly unbounded intervals only when their coefficient is zero. For \(n=1\), every pair lies on the single coincident line, so the required \(\lambda=0\) case is established in Appendix A.
\[
\mathcal K(t,t')=c_s(\lambda^2+h^2)^{-\mu/2},\qquad
\mathcal D_e(t,t')=\frac{h^2}{\lambda^2+h^2}.
\]
Using
\[
\partial_t\mathcal K=-\mu\frac h{\lambda^2+h^2}\mathcal K,\qquad
\partial_{t'}\mathcal K=\mu\frac h{\lambda^2+h^2}\mathcal K,
\]
integration by parts gives
\[
\iint_{I\times J}(2\mathcal K-\overline{\mathcal K}_I-\overline{\mathcal K}_J)
=\mu\iint_{I\times J}\frac{h^2-\zeta h}{\lambda^2+h^2}\mathcal K.
\tag{19}
\]
The pushforward of \(dt\,dt'\) under \(h=t-t'\) has density
\[
\rho(h)=F(|h-\zeta|),\quad
F(r)=\max\{0,\min(|I|,|J|,(|I|+|J|)/2-r)\},
\]
where \(F\) is nonincreasing. If \(\zeta\ge0\), \(\rho(h)\ge\rho(-h)\) for \(h>0\); if \(\zeta\le0\), the inequality reverses. Since \(h(\lambda^2+h^2)^{-1}\mathcal K(h)\) is odd and positive for \(h>0\),
\[
\zeta\iint_{I\times J}\frac h{\lambda^2+h^2}\mathcal K\ge0.
\]
Consequently (19) is at most \(\mu\iint\mathcal D_e\mathcal K\).

For nonnegative interval weights \(c_I,c_J\), assume any interval with positive weight is bounded. Put \(c=\min(c_I,c_J)\). Multiply the last upper bound by \(c\); the residual weight is \(|c_I-c_J|\), and the corresponding endpoint averages are nonnegative. Thus
\[
\begin{aligned}
\iint_{I\times J}(c_I+c_J)\mathcal K
\le \iint_{I\times J}\big[
&c_I\overline{\mathcal K}_I+c_J\overline{\mathcal K}_J\\
&+(\mu\min(c_I,c_J)\mathcal D_e+|c_I-c_J|)\mathcal K
\big].
\end{aligned}
\tag{20}
\]
If only one coefficient is positive, (20) is pointwise true. All terms are nonnegative extended integrals, so no subtraction over an unbounded zero-weight interval is used. For \(n\ge2\), the coincident-line set \(z=z'\) has measure zero in \(e^\perp\times e^\perp\). The case \(n=1\), where it is the entire line-pair contribution, is covered by Appendix A.

## 6. Cap-localized source-layer pressure

For \(e\in\mathbb S^{n-1}\), let \(\mathbb E_e\) denote normalized surface average. Fix \(0<\kappa<1\), \(0<\delta<1/4\), and choose smooth \(0\le\psi\le1\), equal to one near zero and supported in \([0,1]\). Define
\[
Z(l)=\mathbb E_e\psi(|e-\theta|/l),
\]
which is independent of \(\theta\). Chordal polar coordinates give \(cl^{n-1}\le Z(l)\le Cl^{n-1}\) and \(|Z'(l)|\le Cl^{n-2}\). For \(n=1\), these bounds follow directly from \(\mathbb S^0=\{-1,+1\}\): when \(0<l<1\), \(Z(l)=1/2\) and \(Z'(l)=0\); see Appendix A. With \(\hat x=x/|x|\), define
\[
h_e(x)=w(x)\frac{\psi(|e-\hat x|/(\kappa r(x)))}{Z(\kappa r(x))}
\quad(1<|x|<2),
\]
and zero elsewhere. Then \(\mathbb E_e h_e(x)=w(x)\), and differentiation plus (15) gives
\[
0\le h_e\le C_\kappa r^{N-n},\qquad
|\nabla h_e|\le C_\kappa r^{N-n-1}.
\tag{21}
\]
The profile is constant near its center, so the chordal distance causes no differentiability issue. The weight vanishes continuously at both annulus boundaries.

Use the same close/far split as in Section 4. On close pairs,
\[
|h_e(x)-h_e(y)|\le C_\kappa\delta r(z)^{N-n-1+m}
\le C_\kappa\delta r(z)^N.
\]
On far pairs, (8) gives the \(x\)-endpoint bound
\[
C_\kappa\int_{B_2}f(x)r(x)^{N-n}\ell(x)^{-\mu}\,dx,
\]
whose boundary exponent is \(N-n-m\mu=n+2+ms>0\); the \(y\)-endpoint uses \(g\). Thus
\[
\iint|h_e(x)-h_e(y)|\,d\pi\le C_\kappa\delta E+C_{\kappa,\delta}.
\tag{22}
\]
On the support of \(h_e(x)\), \(|e-\hat x|\le\kappa r(x)\), so \(|D_e-D|\le2\kappa r(x)\). Average in \(e\) and use \(rw\le C\eta\):
\[
\mathbb E_e\iint h_e(x)D_e(x,y)\,d\pi
\le\iint w(x)D(x,y)\,d\pi+C\kappa E.
\tag{23}
\]

For \(0<t<f(x)\), let \(I\) be the component containing \(x\) of the open level set \(\{f>t\}\) on the line \(x+\mathbb R e\). Set
\[
\chi_I=
\begin{cases}
\inf_I h_e,& I\text{ bounded and }|I|\le2\delta\inf_I r,\\
0,&\text{otherwise},
\end{cases}
\qquad \chi_f(e,x,t)=\chi_I.
\]
Define \(\chi_g(e,y,t')\) using components of \(\{g>t'\}\). These weights and finite endpoints are jointly measurable: forward and backward exit distances are measurable from the condition that a compact line segment lies in the open layer; infima over components equal infima over rational offsets.

Define
\[
L_f(e)=\int u(x)\int_0^{f(x)}(h_e(x)-\chi_f(e,x,t))\,dt\,dx
\]
and \(L_g(e)\) by replacing \(u,f,\chi_f\) with \(v,g,\chi_g\). Let \(\ell(x)=\delta r(x)^m\). If a component \(I\) has length at most \(\ell(x)\), it satisfies the component rule and loses at most \(C_\kappa\delta r(x)^N\) of cap weight. If \(|I|>\ell(x)\), one of its two portions from \(x\) contains a segment of length \(\ell(x)/2\). Polar integration around \(x\) and (7) imply
\[
\mathbb P_e(|I|>\ell(x))
\le \frac{C}{t\ell(x)^n}\int_{B_{\ell(x)}(x)}f
\le\frac{C}{t\ell(x)^n}.
\tag{24}
\]
For high levels \(t\ge P r(x)^{-k}\), (21) and (24) bound the expected long-component loss by
\[
C_\kappa r^{N-n}\frac{C}{P\delta^n}r^{k-mn}
\le \frac{C_{\kappa,\delta}}P r^N,
\]
because \(k=n(m+1)\). Integrate over high levels against \(u(x)f(x)\,dx\) and use \(r^N\le\eta\). For lower levels, the loss is at most \(P r^{-k}w(x)u(x)\); since \(N-1-k=n+1\), its integral is bounded by \(CP\) using (7). The same proof applies to \(g,v\), so
\[
\mathbb E_e(L_f+L_g)\le
(C_\kappa\delta+C_{\kappa,\delta}P^{-1})E+CP.
\tag{25}
\]

If \(\chi_I>0\), its endpoints \(x_\pm\) lie in \(1<|x|<2\), satisfy \(f(x_\pm)=t\), and hence
\[
u(x_\pm)=(t/|x_\pm|^B)^{1/q}.
\]
The length rule gives \(|x_\pm-x|\le2\delta r(x)\). Since \(|x|^{-B/q}\) has bounded relative derivative on \(1\le|x|\le2\), with \(\bar u_I=(u(x_-)+u(x_+))/2\),
\[
|\bar u_I-(t/|x|^B)^{1/q}|\le C\delta r(x)u(x).
\tag{26}
\]
The \(g\)-layers give the analogous estimate for \(v\).

Fix \(e,t,t'\). For \(n\ge2\), on each pair of distinct parallel lines apply (20) to every \(f\)-component \(I\) and \(g\)-component \(J\), with weights \(\chi_I,\chi_J\). For \(n=1\), apply the \(\lambda=0\) version from Appendix A to the component pair on the sole line. Integrate over the transverse line parameters (none when \(n=1\)) and levels. Tonelli applies to every term before subtraction. Define
\[
H_f(e)=\int h_e fu,\quad H_g(e)=\int h_e gv,
\]
\[
U_f(e)=\int_{\mathbb R^n}\int_0^{f(x)}\chi_f(e,x,t)u(x)\,dt\,dx,\quad
U_g(e)=\int_{\mathbb R^n}\int_0^{g(y)}\chi_g(e,y,t')v(y)\,dt'\,dy.
\]
Let \(V_f,V_g\) be the same layer integrals with \(u,v\) replaced by the corresponding endpoint averages \(\bar u_I,\bar v_J\). All these terms are finite: \(U_f\le H_f\), \(V_f\le CH_f\), and similarly for \(g\), by (26). The pressure term is at most \(\mu H_f\), and the mismatch term is at most \(H_f+H_g\), by the marginals (10). Thus subtraction is legitimate only after this finite-before-subtraction check. The estimate
\[
|\chi_f(e,x,t)-\chi_g(e,y,t')|
\le |h_e(x)-h_e(y)|+(h_e(x)-\chi_f(e,x,t))+(h_e(y)-\chi_g(e,y,t'))
\]
gives, with \(S_e=(U_f-V_f)+(U_g-V_g)\),
\[
S_e\le \mu\iint h_e(x)D_e(x,y)\,d\pi
+\iint|h_e(x)-h_e(y)|\,d\pi+L_f(e)+L_g(e).
\tag{27}
\]

For every \(x\ne0\),
\[
\int_0^{f(x)}\left[u(x)-(t/|x|^B)^{1/q}\right]dt=a f(x)u(x),
\]
because the integral of the second term is \(qf(x)u(x)/(q+1)\). Compare this identity with the layer term in \(S_e\) using (26), \(0\le\chi_f\le h_e\), and \(0\le (t/|x|^B)^{1/q}\le u(x)\); do the same for \(g\). Then
\[
\begin{aligned}
aH_f(e)+bH_g(e)\le S_e+L_f(e)+L_g(e)
&+C\delta\int r(x)h_e(x)f(x)u(x)\,dx\\
&+C\delta\int r(y)h_e(y)g(y)v(y)\,dy.
\end{aligned}
\tag{28}
\]
Average (27)–(28) over \(e\). Since \(\mathbb E_e h_e=w\) and \(rw\le C\eta\), (22), (23), and (25) imply
\[
aW_f+bW_g\le
\mu\iint w(x)D(x,y)\,d\pi+\varepsilon E+C_\varepsilon.
\tag{29}
\]
Indeed choose \(\kappa\) small first, \(\delta\) next, and \(P\) last.

## 7. Energy closure and contradiction

Set
\[
T=\iint w(x)D(x,y)\,d\pi,\qquad
Q=\iint(\Phi(x,y)-\eta(x)+w(x)D(x,y))\,d\pi.
\]
By (18), \(|Q|+|E_f-E_g|\le\varepsilon E+C_\varepsilon\). The virial identity (17) is equivalent to
\[
c_1E_f+c_2E_g=aW_f+bW_g-\mu T+\mu Q,
\]
where
\[
c_1=a(n+B)-\mu,\qquad c_2=b(n+A).
\]
The pressure bound (29) gives \(c_1E_f+c_2E_g\le C\varepsilon E+C_\varepsilon\). Also
\[
c_1+c_2=\gamma
=a(n+B)+b(n+A)-\mu
=\frac{n+B}{q+1}+\frac{n+A}{p+1}-(n-s).
\]
Algebra using (3) gives
\[
\gamma=(1-a-b)(\alpha+\beta+s-n),\qquad
1-a-b=\frac{pq-1}{(p+1)(q+1)}>0.
\]
The gap (2) means \(\gamma>0\). Since
\[
c_1E_f+c_2E_g
=\frac{\gamma}{2}E+\frac{c_1-c_2}{2}(E_f-E_g),
\]
localization and sufficiently small \(\varepsilon\) imply a universal bound \(E\le C\), and in particular
\[
\int_{B_1}(fu+gv)\le C.
\tag{30}
\]

For each \(R>0\), the scaled pair is admissible. A change of variables gives
\[
\int_{B_1}(f_Ru_R+g_Rv_R)
=R^{\alpha+\beta+s-n}\int_{B_R}(fu+gv).
\]
By \(\gamma=(1-a-b)(\alpha+\beta+s-n)>0\), the exponent is positive. The last integral is at least its strictly positive value on \(B_1\) for \(R\ge1\), so the scaled energy diverges as \(R\to\infty\), contradicting (30). This proves the theorem.

## Appendix A: The one-dimensional case

When \(n=1\), the condition \(0<s<n\) is exactly \(0<s<1\), and \(\mu=1-s\in(0,1)\). The proof in Sections 1–4 and 6–7 applies with the choices from (14):
\[
m=4,\qquad k=5,\qquad N=8.
\]
The only structural issue is that for each \(e\in\mathbb S^0\), \(e^\perp=\{0\}\), so all point pairs occur on the same line. The following coincident-line version of Section 5 resolves it.

For \(\lambda>0\), put
\[
\mathcal K_\lambda(h)=c_s(\lambda^2+h^2)^{-\mu/2},\qquad
\mathcal D_\lambda(h)=\frac{h^2}{\lambda^2+h^2}.
\]
The midpoint calculation (19) uses only
\[
\partial_t\mathcal K_\lambda=-\mu\frac{h}{\lambda^2+h^2}\mathcal K_\lambda,
\qquad
\partial_{t'}\mathcal K_\lambda=\mu\frac{h}{\lambda^2+h^2}\mathcal K_\lambda,
\]
and the monotonicity of the interval-overlap profile under reflection. It therefore proves (20) for \(\mathcal K_\lambda\), with \(\mathcal D_e\) replaced by \(\mathcal D_\lambda\), for every pair of bounded intervals. If an interval has zero coefficient, the pointwise argument in Section 5 applies; positive coefficients are used only on bounded intervals.

As \(\lambda\downarrow0\), \(\mathcal K_\lambda(h)\uparrow c_s|h|^{-\mu}\) for \(h\ne0\), and each nonnegative endpoint average increases to its corresponding endpoint average for \(\mathcal K_0(h)=c_s|h|^{-\mu}\). Also,
\[
\mathcal D_\lambda(h)\mathcal K_\lambda(h)
=c_s h^2(\lambda^2+h^2)^{-1-\mu/2}
\uparrow c_s|h|^{-\mu}=\mathcal K_0(h),\qquad h\ne0.
\]
The diagonal is a null set in \(I\times J\). Since \(\mu<1\), \(|h|^{-\mu}\) is locally integrable on the line, so its double integral over bounded intervals and its endpoint integrals are finite, even when \(I\) and \(J\) overlap. Every term in (20) is nonnegative, and monotone convergence passes the full weighted inequality to \(\lambda=0\). On the coincident line, \(\mathcal D_e=1\) for \(t\ne t'\), in agreement with this limit. Thus (20) applies to all interval pairs used in the one-dimensional layer decomposition. Intervals with positive layer coefficient are bounded by definition; an unbounded zero-coefficient interval causes no subtraction or finiteness issue.

The remaining dimension-dependent details are as follows.

* On \(\mathbb R\setminus\{0\}\), \(\hat x=\operatorname{sign}(x)\), so \(D(x,y)=1\) for \(x\ne y\), and \(D_e(x,y)=1\) for both \(e=\pm1\). Consequently the cap comparison in (23) is exact.
* Normalized surface measure on \(\mathbb S^0\) assigns mass \(1/2\) to each direction. Since \(l=\kappa r<1\), \(Z(l)=1/2\), and \(h_e(x)=2w(x)\) when \(\operatorname{sign}(x)=e\), while \(h_e(x)=0\) on the opposite shell. Thus \(\mathbb E_e h_e=w\); the bounds in (21) hold with powers \(N-n=7\) and \(N-n-1=6\).
* The long-component estimate (24) is the one-dimensional polar estimate. If the component through \(x\) has length greater than \(\ell\), one of its two sides contains a segment of length \(\ell/2\); hence \(\int_{B_\ell(x)}f\ge t\ell/2\). On \(\mathbb S^0\), the component length is independent of direction, so the probability in (24) is either zero or one. The displayed integral bound therefore gives (24) with an absolute constant. The same reasoning applies to \(g\).
* If \(\chi_I>0\), the interval is bounded, lies in the shell away from the origin, and has length at most \(2\delta r(x)\). Its endpoints are therefore away from zero and satisfy \(f(x_\pm)=t\) by continuity. The endpoint values of \(u\) are finite by the hypothesis that the potentials are finite everywhere. Since \(|x_\pm|\in[1,2]\), the relative derivative bound for \(|x|^{-B/q}\) used in (26) remains valid. The same statements hold for \(g,v\), so the endpoint averages and finite-before-subtraction check after (27) are unchanged.
* The origin argument in Section 1 specializes to \(\int_{2|x|}^{r_0}r^{A+s-1}\,dr\), which diverges as \(x\to0\) when \(A\le-s\); interchanging the equations gives \(B>-s\). Thus \(A,B>-s>-1\), so the weights and all local energy terms used in the proof are integrable near the origin.
* The boundary powers in Sections 4 and 6 are strictly positive:
\[
N-1-m\mu=3+4s>0,\qquad N-m(\mu+1)=4s>0,
\qquad N-1-m\mu=3+4s>0.
\]
The low-level long-component exponent is \(N-1-k=2>0\). The cited Silvestre regularity propositions are stated on \(\mathbb R^n\) with constants depending on \(n\), so they apply at \(n=1\); since \(s<1\), the bootstrap in Section 2 is in its \(s\le1\) case. The scaling bounds, transport identity, and contradiction in Section 7 require no further dimension-specific change.

## Scope and primary-source context

This proof is only for the direct integral equations (1). A fractional-PDE-to-integral reduction must be proved in the intended PDE solution class; otherwise an entire fractional-harmonic remainder may remain.

The source proof mechanism being transferred is from “The Subcritical Hénon–Lane–Emden Conjecture,” OpenAI Math family-370, repository pin fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb, Sections 02–06. Its Lean comparator at that pin ends with an unfilled sorry; it is not a formal certificate.

The closest direct predecessor found is Phuong Le, “Method of scaling spheres for integral and polyharmonic systems,” *Journal of Differential Equations* 298 (2021), 132–158, DOI [10.1016/j.jde.2021.06.041](https://doi.org/10.1016/j.jde.2021.06.041). It proves nonexistence for the rectangular range \(p\le(n+\alpha+2A)/(n-\beta)\), \(q\le(n+\beta+2B)/(n-\alpha)\), excluding the simultaneous top pair. At equal order \(s\), this does not cover the full gap: \(n=3,s=1,A=B=0,p=5/2,q=3/2\) satisfies \(3/(7/2)+3/(5/2)=72/35>2\) but has \(p>2=(n+s)/(n-s)\). Cao–Qin, arXiv:1911.09000, Theorem 1.4, is a related fractional-PDE result in a corresponding rectangle and with nonnegative-weight assumptions ([arXiv](https://arxiv.org/abs/1911.09000), DOI [10.3934/dcds.2020361](https://doi.org/10.3934/dcds.2020361)). Chen–Li, “An integral system and the Lane–Emden conjecture,” DCDS 24 (2009), 1167–1184, treats the unweighted Riesz system under additional integrability conditions ([DOI](https://doi.org/10.3934/dcds.2009.24.1167)). These comparisons are selective, not an exhaustive priority claim.
