# Intake clarification; separate from immutable authored reports

No independent proof reconstruction, scientific diagnostic replay, external correctness or priority certification occurred in this intake.

SOL/A free-subgroup proof: the final rank inference needs the finite-coset-support argument, not the unrestricted assertion that a free module containing infinitely many independent vectors must have infinite rank over a noncommutative ring. If Rp were finitely generated over k[H], finitely many generators would occupy finitely many left-H-coset coordinates in R; all their k[H]-linear combinations stay in that same finite coordinate union. The constructed g_i p have pairwise disjoint nonempty coordinate supports, contradicting finite generation. With the imported FIR submodule-freeness theorem and countability, this yields countably infinite free rank. This is an elementary intake clarification of a written inference, not a source audit receipt or validation of the whole theorem. Independently check the exact FIR theorem and convolution/duality conventions.

Retain the infinite-index free-subgroup hypothesis explicitly. The report's cyclic consequence additionally requires infinite index; torsion-freeness alone is not that hypothesis. A separate argument using the actual witness would be needed to discharge it.

The random equivariant basis criterion is sufficient and conditionally linear; it is not equivalent to all measurable Bernoulli conjugacies. Independence and spanning are both mandatory. No random basis or effective construction is provided. The inherited finite-defect splitting lemma is explicitly audit-deferred by SOL/A, so its report does not independently validate N252.

Affine smoothing is a source-reconstructed unconditional reduction; the degree-at-most-eight undecidability corollary is conditional on the unverified pinned H10(Q) theorem. Naive projectivization adds rational boundary points and is not the proposed projective upgrade. Constant preprocessing preserves solvability only. Exact finite tests reported in the note have no bundled executable/result artifacts.
