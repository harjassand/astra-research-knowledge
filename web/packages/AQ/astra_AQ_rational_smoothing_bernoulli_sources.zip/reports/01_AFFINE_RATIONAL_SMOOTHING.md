# ASTRA X HIGH — Rational-point rigidity and effective affine smoothing

**Date:** 2026-10-09 (AEST)  
**Status:** Explicit unconditional reduction, with primary-literature comparisons; no historically verified novel or 10/10 result. The undecidability corollary is conditional on the validity of the OpenAI H10(Q) proof.

## Immutable inputs

- Astra knowledge: [`harjassand/astra-research-knowledge`](https://github.com/harjassand/astra-research-knowledge/tree/39cdea532f19217f633f70315d92c314a6ce5e3e), commit `39cdea532f19217f633f70315d92c314a6ce5e3e`; read `00_START_HERE.txt`, `frontier/PRIORITIES.md`, cards N165 and N257, topic routes.
- OpenAI mathematics: [`openai/math`](https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb), commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`; H10(Q) family 004, PIT family 116, random SAT 235, Baum–Connes 285, 2D area law 265 and sampling 139 inspected selectively.
- Caution: OpenAI acknowledges unformalized manuscripts and October 7 corrections/withdrawals. A repository assertion is not external validation.

## Statement: Effective rational-point-preserving smoothing

**Proposition (proof reconstructed here; historical novelty UNVERIFIED).** Given a nonconstant polynomial `f ∈ Q[X_1,...,X_n]` of degree `d ≥ 1`, an algorithm returns a positive integer `m` and an affine hypersurface

    H_{f,m}:  Z - Z^3 = m^2 f(X_1,...,X_n)^2

such that:

1. `H_{f,m}` is smooth over `Q` (hence geometrically smooth).
2. `H_{f,m}` is geometrically integral (absolutely irreducible).
3. `H_{f,m}(Q) = V(f)(Q) × {-1,0,1}` as rational point sets.
4. Its total degree is `max(3,2d)` and it uses only one more variable than `f`.
5. Consequently `#H_{f,m}(Q) = 3 #V(f)(Q)` whenever the cardinality is finite, with the evident statement for infinite sets.

Constant inputs can be preprocessed: replace `f=0` by the nonconstant polynomial `X`, and replace a nonzero constant by `X^2+1` (with a new variable). These have matching rational solvability.

### Proof 1: Arithmetic rigidity, an unconditional classical input

The elliptic curve `E: Y^2 = X^3 - X` has exactly the three affine rational points `(-1,0)`, `(0,0)`, `(1,0)`; its fourth rational point is the point at infinity. This follows from Fermat's descent showing that 1 is not a congruent number (Keith Conrad, *The Congruent Number Problem*, Theorem 2 and the discussion of `Y^2=X^3-X`). Substituting `X=-Z`, `Y=T` yields the equivalent elliptic curve

    C: T^2 = Z - Z^3,

whose affine rational points are precisely `(T,Z) = (0,-1),(0,0),(0,1)`.

Every rational point of `H` gives a rational point `(T,Z)=(m f(x),z)` of `C`. Necessarily `m f(x)=0`, hence `f(x)=0` and `z` is one of `-1,0,1`. The reverse implication is immediate. This proves assertion 3, independent of the selection of nonzero `m`.

### Proof 2: Geometric integrality via the absence of rational curves on an elliptic curve

Work over the algebraic closure `k=Qbar`. The equation defining `H` is a cubic in `Z`:

    P(Z)=Z^3 - Z + m^2 f(X)^2.

Suppose it were reducible in `k(X_1,...,X_n)[Z]`. A reducible cubic has a root `R(X) ∈ k(X_1,...,X_n)`. Then the rational functions

    (T,Z)=(m f(X), R(X))

satisfy `T^2=Z-Z^3`. They give a rational map from affine n-space (and hence projective n-space) to the smooth projective genus-one completion of `C`. As `f` is nonconstant, the map is nonconstant. Restricting to a sufficiently general affine line on which `f` is nonconstant produces a nonconstant rational map `P^1 → Cbar`. Properness extends it to a morphism, contradicting Riemann–Hurwitz for maps from genus 0 to genus 1. Thus `P` is irreducible over `k(X)[Z]`. Being monic in `Z`, it is irreducible in `k[X,Z]` by Gauss's lemma. This proves assertion 2.

*Rejected shortcut:* One cannot simply assert that `k(X)` is regular over `k(f)`: for `f=X^2`, `k(X)/k(f)` is a nontrivial algebraic extension, hence is **not** regular. Generic-fiber linear disjointness therefore is not a valid proof for arbitrary `f`. The argument above instead exploits the genus-one curve and the absence of rational maps from rational varieties to elliptic curves; that argument works without the false regularity premise.

### Proof 3: Global smoothness by finite critical-value avoidance

Write `h(Z)=Z-Z^3` and `F=h(Z)-m^2f(X)^2`. If all partial derivatives of `F` vanish at a geometric point on `F=0`, then

    h'(Z) = 1-3Z^2 = 0,
    -2m^2 f(X) (∂_i f)(X) = 0 for all i.

At `Z=±1/sqrt(3)`, `h(Z)=±2/(3sqrt(3))≠0`. Thus `F=0` forces `f(X)≠0`, and all partial derivatives of `f` must vanish. Every nonconstant polynomial map `f:A^n_C→A^1_C` has finitely many critical values in characteristic zero (algebraic Sard; alternatively finite irreducible decomposition of its critical locus and vanishing differential). For any nonzero critical value `c`, a bad `m` must satisfy

    m^2 c^2 = +2/(3sqrt(3)) or -2/(3sqrt(3)).

There are only finitely many such positive integers `m`. Hence some positive integer gives no singular geometric point. An algorithm enumerates `m=1,2,...` and uses Gröbner-basis computation over `Q` to test whether the Jacobian ideal

    <F, ∂F/∂Z, ∂F/∂X_1,...,∂F/∂X_n>

is the unit ideal. By the Nullstellensatz this is equivalent to geometric nonsingularity; since all but finitely many integers work, enumeration terminates. This proves assertion 1 and effectivity.

## Consequence from OpenAI family 004, if its main result is valid

The pinned OpenAI H10(Q) manuscript claims undecidability of rational polynomial solvability and separately proves a degree-four normal form (an arbitrary polynomial is first turned into quadratic arithmetic-circuit equations, then one quartic sum-of-squares polynomial). Applying the proposition to the quartic polynomial gives a **many-one reduction** to smooth, geometrically integral affine rational-point existence in degree at most **8**, with no restriction on ambient dimension. Under the OpenAI theorem, this restricted decision problem is undecidable and has the same Turing degree `0'`.

The reduction proposition is unconditional, but the restricted undecidability corollary uses the OpenAI theorem as a premise. The primary OpenAI H10(Q) proof is long and was not independently audited in this investigation. Its existing proof statuses, source dependencies and historical priority remain separate.

## Three independent tests and the projective failure

- Exact symbolic Jacobian/Gröbner computations over `Q`, using SymPy, returned the unit ideal for illustrative instances `f=x`, `f=x^2-2`, `f=x^2+1`, `f=(x^2-1)(x^2+1)`, and `f=x^2+y^2-1` with `m=1`. These are finite checks, **not** a proof of universal smoothness or irreducibility.
- For a degree-`d` input `d≥2`, homogenization to degree `2d` gives (with homogeneous `f_h(X,W)` of degree `d`):

      F_h(X,Z,W) = W^(2d-1) Z - W^(2d-3) Z^3 - m^2 f_h(X,W)^2.

  The point `P=[X_1:...:X_n:Z:W]=[0:...:0:1:0]` is rational and lies on this projective closure **for every input**, including `f` with no rational zero. This destroys the rational-point equivalence.
- For `d≥3`, every first derivative also vanishes at `P`, so the projective closure is singular there (for d=2, `∂F_h/∂W(P)=-1`, though the extraneous rational point still remains). Thus ordinary homogenization does **not** solve the smooth projective hypersurface problem. An effective resolution/compactification does not automatically remove rational boundary points.

## Prior art, scope and attribution

1. **B. Poonen, 2011, *Automorphisms mapping a point into a subvariety*, Lemma 4.1**: effective smoothing with degree exactly `2 deg f`, geometrically integral over Q, **preserving integral-point existence** using `c(y^2-y)+f(x)^2`; this construction does not preserve rational solvability, since `y^2-y` can be negative for rational `0<y<1`. **Closest identified precursor**; do not claim an independent new 10/10 result from merely changing the field.
2. **B. Poonen, 2009, *Existence of rational points on smooth projective varieties*, Theorem 1.1**: an oracle deciding rational points on smooth projective geometrically integral varieties would decide points on all varieties; this is a Turing reduction. It does **not** establish an equivalent result specifically for smooth **projective hypersurfaces**, and its paper explicitly asks about that in §11(iii).
3. **B. Poonen, 2012, *Uniform boundedness of rational points and preperiodic points*, Proposition 1.7**: arbitrary systems can be encoded in degree-four **affine** hypersurfaces via quadratic gates and sum of squares. Those hypersurfaces may be singular.
4. **K. Conrad, *The Congruent Number Problem*, classical Theorem 2**: Fermat's proof that 1 is not a congruent number supplies the exact elliptic arithmetic detector.

Historical priority for the exact rational-field affine smoothing proposition has **not** been exhaustively settled. The argument may already be part of the existing literature or folklore; novelty is **UNKNOWN**.

### Primary links

- Poonen (2011): https://math.mit.edu/~poonen/papers/automorphism.pdf
- Poonen (2009): https://arxiv.org/pdf/0712.1782
- Poonen (2012): https://math.mit.edu/~poonen/papers/uniformboundedness.pdf
- Conrad: https://kconrad.math.uconn.edu/articles/congruentnumber.pdf
- OpenAI H10(Q), pinned source: https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hilberts-tenth-problem-over-the-rational-numbers-October-6-2026/build/sections/01-introduction.tex
- OpenAI H10(Q), degree-four normal form: https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hilberts-tenth-problem-over-the-rational-numbers-October-6-2026/build/sections/07-consequences.tex

## Priority-ranked cross-field opportunity comparison

- **Rational Diophantine geometry:** exact many-one rational smoothing, degree at most eight; real progress as a reconstruction; major remaining gate is a point-preserving *smooth projective hypersurface* transformation without rational points at infinity. An affine result is not a projective result.
- **Noncommutative PIT (OpenAI 116):** universal finite characteristic matrix hitting point for bounded-size noncommutative formulas. Important positive-characteristic representation via multiplicative shifts, but a general polynomial-time *commutative* PIT compiler is not supplied: representation/access and commutation barriers remain.
- **Quantum lattice Hamiltonians (OpenAI 265):** claimed 2D gapped area law and polynomial-bond PEPS approximation, but efficient contraction/output sampling is a separate algorithmic problem; a small representation does not itself provide an efficient universal classical simulation.
- **Baum–Connes (OpenAI 285):** reported torsion-free reduced assembly noninjectivity; the manuscript explicitly distinguishes maximal assembly and the classical Novikov conjecture, which remains untouched by this obstruction.
- **Random 3-SAT (OpenAI 235):** finite-certificate computability of limiting threshold is distinct from efficiently computing its digits or solving worst-case SAT; the result concerns k=3, and critical-density behavior remains open.
- **Soficity/Bernoulli (Astra N165/N257):** source discrepancy concerning characteristic-p idempotent citation and unverified Haar splitting/rank claims preclude assuming an entropy classification or exact Bernoulli shift conjugacy. No 10/10 Bernoulli result verified.

## Decision and future decisive obligations

- **Established within this note:** effective affine smoothing reduction and elementary failure of naïve projective homogenization.
- **Conditional on unverified upstream claim:** undecidability for smooth geometrically integral affine hypersurfaces of degree ≤8.
- **Unresolved:** correct historical priority; independent specialist audit of this proof; unconditional verification of the long OpenAI H10(Q) source; a projective point-preserving construction; any 10/10 historic new result.
- **Not justified:** claim that a smooth projective hypersurface rational-point oracle is undecidable, or that integer-point solvability and rational-point solvability are interchangeable.

A viable projective upgrade must prove, *at minimum*, the exact equivalence of rational-point existence after completing the affine cover, including all exceptional divisors and points at infinity; smoothness and geometric integrality throughout; and the reduction's effectivity. This was not achieved here.
