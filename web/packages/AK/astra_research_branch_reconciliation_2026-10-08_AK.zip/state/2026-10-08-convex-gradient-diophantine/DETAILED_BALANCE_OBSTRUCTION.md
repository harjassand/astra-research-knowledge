# Detailed-balance decidability obstruction for the Diophantine CRN route

**Status:** independently reconstructed classical algebraic observation; not a novelty claim. Supports the same 2026-10-08 research branch pinned originally at `b5824d0fcbfe0688980788da2722270a2f068fb0`. No independent worker or formal assistant.

## Theorem III (positive *rational* equilibria of detailed-balanced reaction networks are decidable)

Let a finite mass-action chemical reaction network consist of reversible reaction pairs `alpha_j <-> beta_j`, with integer nonnegative complexes and **positive rational** forward/backward rate constants `k_j^+, k_j^-`. Suppose it is known (or promised) that it is **detailed-balanced**, i.e. there exists at least one real positive concentration vector `x_*` satisfying equality of both reaction fluxes of every pair.

Then there is a terminating exact algorithm deciding whether the system has **any** strictly positive rational-coordinate equilibrium. When one exists, the algorithm constructs one. Without the detailed-balance promise, the algorithm still decides existence of a positive **rational detailed-balanced** state, but not the existence of arbitrary rational stationary states.

### Proof (global, not a specified stoichiometric compatibility class)

For each pair let `B_j=beta_j-alpha_j` be an integer row vector and `c_j=k_j^+/k_j^->0`. The detailed-balance equations are exactly

    product_i x_i^{B_{j,i}} = c_j   (j=1,...,m).

Factor all finitely many positive rational `c_j` into rational primes, let `P` be their finite set of divisors. For each prime p in P form the integer column `b_p=(v_p(c_j))_j`, and solve the **integer linear system**

    B n_p = b_p,    n_p in Z^d.

Integer solvability is decidable by Smith normal form. If one system is inconsistent, there is no positive rational solution. If all are solvable, put

    x_i = product_{p in P} p^{(n_p)_i}  in Q_{>0}.

For every reaction j, the valuations at all primes p of `x^{B_j}` and `c_j` coincide (both have zero valuations outside P), so `x^{B_j}=c_j` exactly. Conversely any rational detailed-balanced x yields integer solutions `n_p=(v_p(x_i))_i` for every p in P. Hence this algorithm is exact and constructive. (The empty P case yields x_i=1, if all c_j=1.)

To pass from detailed-balance states to **all positive steady states of a detailed-balanced network**, fix a real x_* satisfying detailed balance and consider the relative-entropy Lyapunov function

    F(x)=sum_i [x_i log(x_i/x_{*,i})-x_i+x_{*,i}].

Its derivative along mass-action dynamics is

    dF/dt = -sum_j (f_j(x)-r_j(x)) log[f_j(x)/r_j(x)] <= 0,

where f_j=k_j^+ x^{alpha_j}, r_j=k_j^- x^{beta_j}. The equality follows because log(f_j/r_j) = -B_j dot log(x/x_*). Each summand is nonnegative, and it vanishes exactly when f_j=r_j. At any positive equilibrium, dF/dt=0, so each reaction pair individually satisfies detailed balance. Thus the rational equilibrium problem under the real detailed-balance promise reduces to the explicit valuation algorithm. QED.

### Exact falsifier illustrating why the rational algorithm matters

The reversible single-species reaction `2A <-> 0` with rate ratio `k^+/k^-=1/2` has a positive real equilibrium x=sqrt(1/2) but **no positive rational equilibrium**. Its exponent equation `x^{-2}=1/2` requires the prime-2 valuation to solve `-2n=-1`, impossible for integer n. Equivalently choose `0 <-> 2A` with forward/backward rate ratio 2 and required `x²=2`. So neither positive-real existence nor real-algebraic computation suffices for rationality; valuation congruences are essential.

## Consequences and sharp limitation

1. An H10(Q)-based undecidability transfer **cannot simply land in the globally detailed-balanced mass-action class with rational rate constants and unconstrained existence of an equilibrium**: its proposed decision problem has the explicit algorithm above. The network may be *reversible* without being detailed-balanced; reversible topology and detailed balance are different assumptions.
2. This theorem does **not** decide rational steady states restricted to a prescribed rational stoichiometric class, because the output x may lie in another class; nor does it decide rational equilibria in an arbitrary reversible network not promised detailed-balanced.
3. The conclusion rests on rational **rate constants** and ordinary integer stoichiometric exponents; if rate constants are arbitrary noncomputable real numbers, there is no generic input-decision algorithm.
4. This is standard toric/log-linear detailed-balance structure, not a historical breakthrough. The earlier Boros-Craciun-Yu (2020) reversible construction permitting equilibrium continua is **not** detailed-balanced, and its general ability to preserve the rational zero set of arbitrary circuits remains unproved.

## Recommended strongest continuation

Pursue, if possible, an **explicit non-detailed-balanced but reversible** reaction-network compiler with rational rates and an exact rational-equilibrium-preserving map for arbitrary Diophantine gate systems. The present sum-of-squares clock is **not** such a compiler: positive M does not satisfy coefficient-level mass-action kinetic constraints, and ad hoc auxiliary species may introduce extra rational equilibria. Establish a no-go theorem or the missing realization lemma before claiming any chemical undecidability theorem.

Sources: classical detailed balance and free-energy dissipation (Horn–Jackson); 2020 Boros–Craciun–Yu, *Weakly reversible mass-action systems with infinitely many positive steady states*, SIAM J Appl Math 80(4), doi:10.1137/19M1303034. See `RESEARCH_STATE.md` for the conditional 2026 H10(Q) interface.
