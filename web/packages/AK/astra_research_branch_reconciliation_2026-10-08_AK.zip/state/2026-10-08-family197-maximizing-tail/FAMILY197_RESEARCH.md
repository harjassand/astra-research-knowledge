# Family 197: entropy-neutral defect extraction and a supremal-entropy tail

**Date:** 8 October 2026 (UTC).  
**Astra evidence revision:** `b5824d0fcbfe0688980788da2722270a2f068fb0`.  
**OpenAI source revision:** `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.  
**Verdict:** Neither zero nor positive supremal Rokhlin entropy is proved for the original family-197 construction. Bowen's measurable Bernoulli-isomorphism question remains unresolved. The strongest conditional deduction is that the residual Haar tail itself is free, mixing, and has Rokhlin entropy exactly equal to the group's finite supremal entropy. The defect-layer quotient leaves relative entropy unchanged and has atomless conditional fibers. Complete proofs, supporting structural deductions, and failed transfer arguments follow. Historical priority of the exact tail theorem is not certified.

## 1. Scope, provenance, and novelty boundary

The task was to cross the gap left by the inherited bound, rather than rerun finite-window ranks, fixed-power estimates, or rare-generator equivalences. I began with `00_START_HERE.txt`, read the relevant reviewed cards and their current notices, and retrieved the prior `state/2026-10-08-bowen-bernoulli-direct-finiteness/{RESEARCH,ADDITIONAL_AUDITS}.md`. The original family-197 introduction, algebra, assembly, topology and supporting graph arguments were retrieved from the pinned OpenAI source. Its long construction is not independently re-proved here.

The source is existential: it selects a successful finite graph matching and gives a finite presentation recipe, rather than singling out a canonical group or listing a concrete successful matching. Here “the original group” means a group supplied by that recipe, conditional on the source theorem. No direct product, overgroup, or replacement group is used in the deductions.

The inherited result is

$$
0\le s:=h_{\sup}^{\mathrm{Rok}}(G)
=h_G^{\mathrm{Rok}}(\mathbb F_2^G,u_2^G)
\le (1-1/m)\log2<\log2,
\qquad m=|\operatorname{supp}(1-ba)|.
$$

No numerical support size was acquired. The equality with the binary Bernoulli entropy uses Seward's finite-base min formula, and the strict bound is the inherited proper-subshift argument. This investigation does not claim a better bound.

Here $h_{\sup}^{\mathrm{Rok}}$ has Seward's precise convention: the supremum of the **finite** Rokhlin entropy values of free ergodic p.m.p. actions. Infinite-entropy actions are excluded from this defining supremum. This convention matters for the conditional consequences below.

**Important prior-art finding.** Ceccherini-Silberstein, Coornaert and Phung (2021), Theorem 1.5/Corollary 1.6 and Theorem 1.9/Corollary 1.10, already imply that the limit set of the injective, nonsurjective linear cellular automaton below is infinite-dimensional and not of finite type. Accordingly, those conclusions are credited as established consequences, not advertised as new theorems. The module proof is retained because it also supplies the flat/nonprojective description and the nonsplitting argument. The exact Rokhlin-entropy connection below is a deduction developed in this run; no publication with this exact formulation was located in the bounded primary-source search. Its ingredients and several of its algebraic consequences are standard, so absence of a search hit is not a novelty certificate.

Fifteen Luna workers were assigned distinct or adversarial tasks, with at most six active concurrently. Worker agreement is an internal mathematical check, not independent specialist review or formal verification. Two proposed factor-monotonicity arguments were rejected before inclusion as results.

## 2. Main conditional theorem

Let $G$ be a countable group and suppose $a,b\in R=\mathbb F_2[G]$ satisfy

$$
ab=1,\qquad ba\ne1.
$$

On the compact group $X=\mathbb F_2^G$, with left shift and Haar measure $\mu$, define

$$
(T_u x)(g)=\sum_{t\in G}u_t x(gt),\qquad
A=T_a,\ B=T_b,\ C=I-BA=T_r,\ r=1-ba,
\quad K=\ker A=\operatorname{im}C.
$$

Then the map

$$
\Theta:X\longrightarrow K^{\mathbb N},\qquad
\Theta(x)=(CA^j x)_{j\ge0}
\tag{2.1}
$$

has the following properties.

1. It is a continuous equivariant group epimorphism and $\Theta_*\mu=m_K^{\mathbb N}$. In particular its layer coordinates are independent variables with Haar law on $K$.
2. Its kernel is $D=\bigcap_{n\ge0}B^nX$. This subgroup is infinite and has atomless Haar measure. No finite-generation assumption on the whole group is necessary.
3. Its fibers have coset-Haar conditional measures. Consequently, if a Borel set $E\subset X$ has $\Theta|_E$ injective, then $\mu(E)=0$. Thus this specified layer coding cannot become a measurable isomorphism by removing a null set.
4. The dual module of $D$ is cyclic, flat, nonprojective, and not finitely presented. The exact sequence

   $$
   0\longrightarrow D\longrightarrow X\xrightarrow{\Theta}K^{\mathbb N}\longrightarrow0
   \tag{2.2}
   $$

   has no continuous equivariant **group-homomorphic** section. This statement does not exclude arbitrary Borel sections or an unrelated measurable conjugacy.
5. If $\mathcal F=\Theta^{-1}\mathcal B(K^{\mathbb N})$, then

   $$
   \boxed{h_G^{\mathrm{Rok}}(X,\mu\mid\mathcal F)
   =h_G^{\mathrm{Rok}}(X,\mu).}
   \tag{2.3}
   $$

   For the family-197 premise, the common value is the inherited $s<\log2$. Revealing the entire independent layer sequence leaves this relative entropy unchanged. This calculation is not an entropy-additivity formula. A separate continuity argument below evaluates the intrinsic entropy of $D$.
6. Under the original family-197 torsion-free premise, the Haar action on $D$ is free and mixing, and

   $$
   \boxed{h_G^{\mathrm{Rok}}(D,m_D)
   =h_G^{\mathrm{Rok}}(X,\mu\mid\mathcal F)
   =h_G^{\mathrm{Rok}}(X,\mu)
   =h_{\sup}^{\mathrm{Rok}}(G)=s.}
   \tag{2.8}
   $$

   In particular, this proper linear limit subshift attains the finite supremum, although its dual is flat and nonprojective. This is an exact comparison, not a proof that its common value vanishes or is positive.

### Proof of the algebraic and measure statements

The convention above gives $T_uT_v=T_{uv}$. Thus $AB=I$, $C^2=C$, $AC=0$, $CB=0$, and $BA+C=I$. Iterating $x=Cx+BAx$ gives the compact-group isomorphism

$$
\Phi_n(x)=(A^n x,Cx,CAx,\ldots,CA^{n-1}x)
:X\longrightarrow X\times K^n
$$

with inverse

$$
(y,z_0,\ldots,z_{n-1})\longmapsto
B^n y+\sum_{j<n}B^jz_j.
$$

It carries Haar measure to product Haar. Every finite prefix of (2.1) is therefore onto and independent. The image of $\Theta$ is compact and contains every finite cylinder pattern, so it is all of $K^{\mathbb N}$. The first $n$ layer coordinates vanish precisely on $B^nX$; intersecting proves the kernel formula. Also $\Theta(Ax)$ is the left shift of $\Theta(x)$ in the layer index. This auxiliary one-sided shift is not the original $G$-action.

Identify $\widehat X$ with the left $R$-module $R$, using finitely supported characters. A coefficient pairing gives

$$
\widehat{T_u}(f)=fu.
$$

Write $S(f)=fb=\widehat B(f)$, $U_n=\ker S^n$, $U=\bigcup_nU_n$. The map $S$ is onto because $f=(fa)b$, and noninjective because $r\ne0$ and $rb=0$. Moreover

$$
U_n=Rr_n,\qquad r_n=1-b^na^n,
\qquad a^nb^n=1.
\tag{2.4}
$$

Indeed $r_nb^n=0$, and $fb^n=0$ implies $fr_n=f$. Each $r_n$ is idempotent, so $U_n$ is a direct summand of $R$, and $R/U_n\cong R$. The inclusions are all strict: $ra^n\in U_{n+1}\setminus U_n$, since $(ra^n)b^n=r\ne0$ and $(ra^n)b^{n+1}=rb=0$.

The annihilator of $B^nX$ is $U_n$. The annihilator of their intersection is their increasing union $U$. For completeness, in the binary case a character vanishing on $D$ must vanish on some $B^nX$: otherwise the nested nonempty compact sets $B^nX\cap\{\chi=1\}$ would have nonempty intersection, contradicting its vanishing on $D$. Hence

$$
D^\perp=U,\qquad \widehat D\cong R/U.
\tag{2.5}
$$

The union $U$ is not finitely generated. A finite generating set would lie in one $U_N$, forcing $U=U_N$ and contradicting strict growth. A useful refinement is

$$
p_j=b^jra^j,\qquad
r_n=\sum_{j<n}p_j,\qquad
U=\bigoplus_{j\ge0}Rp_j\cong\bigoplus_{j\ge0}Rr.
\tag{2.6}
$$

The $p_j$ are pairwise orthogonal idempotents; $Rp_j=Rra^j$, and multiplication by $a^j$, with inverse multiplication by $b^j$ on that summand, identifies it with $Rr$. Thus $U$ is itself projective and countably generated. The nonprojective module in the theorem is $R/U$.

Since $R/U=\varinjlim_nR/U_n$ is a filtered colimit of free modules, it is flat. It is cyclic. If it were finitely presented, the kernel of the canonical epimorphism $R\to R/U$ would be finitely generated. This follows, over any unital ring, from Schanuel's lemma applied to a finite presentation. If it were projective, that epimorphism would split and $U$ would be a direct summand of the cyclic module $R$, hence cyclic. Both alternatives contradict the preceding paragraph. The projective resolution $0\to U\to R\to R/U\to0$ also gives projective dimension exactly one.

First suppose $G$ is finitely generated. Every finite-dimensional $\mathbb F_2[G]$-module is finitely presented: choose a finite vector-space basis and impose its action relations for a finite symmetric generating set. In the presented quotient every group word reduces to the span of that basis; the quotient maps onto the specified module of the same dimension, proving equality. If $D$ were finite, $\widehat D=R/U$ would be finite-dimensional and therefore finitely presented, a contradiction.

For a general countable $G$, let $H\le G$ be generated by the finite supports of $a,b$. The same witness holds in $\mathbb F_2[H]$, and the finitely generated case proves $D_H$ infinite. Right convolution reads independently within the blocks $gH$. Choosing representatives for the blocks $gH$ gives a compact-group identification

$$
D_G\cong\prod_{gH\in G/H}D_H.
\tag{2.7}
$$

Thus $D_G$ is infinite as well. Haar measure on an infinite compact group is atomless. As noted in Section 1, this infinitude also follows from the 2021 limit-set theorems.

A continuous equivariant group section of $\Theta$ would split the dual sequence and make $U\subset R$ a direct summand. An $R$-linear projection from $R$ is determined by its value on $1$, so its image is cyclic. This contradicts non-finite generation of $U$, proving the specified nonsplitting. Finite local linear defining constraints for $D$ would likewise generate $D^\perp=U$, proving it is not of finite type. The 2021 stability theorem gives the same latter conclusion directly, because $B$ is injective and nonsurjective and its descending images never stabilize.

Finally, Haar disintegration for a compact-group quotient makes the conditional measure above $y\in K^{\mathbb N}$ the translate of $m_D$ on $\Theta^{-1}(y)$. An injective Borel subset meets each fiber in at most one point, which has conditional measure zero. Integrating gives $\mu(E)=0$. This is a genuine measure-level obstruction to this coding, beyond merely counting fixed or periodic points. It does not distinguish arbitrary Bernoulli shifts up to measurable conjugacy.

### Proof of the relative-entropy identity

Let $\mathcal F_n=\sigma(Cx,CAx,\ldots,CA^{n-1}x)$, where each variable takes values in the whole compact $G$-system $K$. These are invariant sigma-algebras and $\mathcal F=\bigvee_n\mathcal F_n$.

The finite splitting makes $K^n$ a factor of the Bernoulli shift $X$. Weak containment passes to factors. By Abért–Weiss, the Bernoulli shift is weakly contained in every free p.m.p. action, hence so is $K^n$. Seward, *Weak containment and Rokhlin entropy*, Theorem 1.2 (equivalently its Corollary 6.6 version), therefore gives

$$
h_G^{\mathrm{Rok}}(X\times K^n\mid\mathcal B(K^n))
=h_G^{\mathrm{Rok}}(X).
$$

Transporting this through $\Phi_n$ gives $h_G^{\mathrm{Rok}}(X\mid\mathcal F_n)=h_G^{\mathrm{Rok}}(X)$ for every $n$. The right side is finite because the coordinate partition of $X$ has entropy $\log2$. Seward, *Krieger's finite generator theorem II*, Corollary 7.2(ii), applies to the increasing invariant sigma-algebras and yields

$$
h_G^{\mathrm{Rok}}(X\mid\mathcal F)
=\inf_n h_G^{\mathrm{Rok}}(X\mid\mathcal F_n)
=h_G^{\mathrm{Rok}}(X).
$$

This proof never uses intrinsic entropy monotonicity under factors, a sofic approximation, or product entropy additivity. No intrinsic entropy value of $K^{\mathbb N}$ is inferred.

### Proof that the residual tail attains the supremum

Put $M=\widehat D=R/U$. Flatness here means flatness as a left $R$-module. Fix $g\ne1$ and let $H=\langle g\rangle$. Torsion-freeness gives $H\cong\mathbb Z$. The ring $R$ is free as a left $Q=\mathbb F_2[H]$-module. Restriction therefore makes $M$ flat over $Q$: for right $Q$-modules $N$,

$$
N\otimes_Q M\cong(N\otimes_Q R)\otimes_R M,
$$

and both tensor steps preserve injections. As $Q$ is a domain, $M$ is $Q$-torsion-free. It is nonzero because $1\notin U$ (otherwise $b^n=0$ for some $n$, contradicting $a^nb^n=1$). Any nonzero $v\in M$ gives an injection $Q\to M$, $q\mapsto qv$. Dualizing supplies a Haar-preserving $H$-factor

$$
D\big|_H\longrightarrow\mathbb F_2^H.
\tag{2.9}
$$

Thus each infinite cyclic restriction has KS entropy at least $\log2$ and is essentially free. Taking the countable intersection of the sets where each nonidentity element acts without fixed points makes the $G$-action essentially free.

It is also mixing. If $gv=hv$ for $g\ne h$ and nonzero $v\in M$, then $(1-g^{-1}h)v=0$, contradicting the preceding Laurent-ring torsion-freeness. Every nonzero character therefore has a free $G$-orbit. Distinct character matrix coefficients vanish outside at most one group element; finite linear combinations and then density in $L^2(D)$ prove mixing. In particular the action is ergodic. This also describes its mean-zero Koopman representation as a direct sum of regular representations; no entropy positivity is inferred from that spectrum.

Now let $\mu_n$ be Haar measure on $B^nX$, considered as an invariant measure on the *same* full shift $X$. These measures converge weak-* to $m_D$. Indeed, for every finite coordinate set $F$, the projected subspaces $\pi_F(B^nX)$ decrease inside the finite vector space $\mathbb F_2^F$, so eventually stabilize. Their intersection equals $\pi_F(D)$ by compactness of the nested preimage sets. Their Haar marginals are uniform, and hence eventually equal the marginal of $m_D$. Cylinder functions determine weak-* convergence.

The map $B^n:X\to B^nX$ is an equivariant compact-group isomorphism with inverse $A^n$ on its image. Consequently $h_G^{\mathrm{Rok}}(X,\mu_n)=s$ for every $n$. Alpeev–Seward, *Krieger III*, Corollary 5.6(ii), gives upper semicontinuity on invariant measures of a finite-alphabet shift. The finitely generated case applies directly; alternatively all these measures and the limit are ergodic, so the stated ergodic-domain version suffices. It follows that

$$
h_G^{\mathrm{Rok}}(D,m_D)
\ge\limsup_n h_G^{\mathrm{Rok}}(X,\mu_n)=s.
$$

The coordinate partition makes $h_G^{\mathrm{Rok}}(D,m_D)\le\log2<\infty$. Because $D$ is free and ergodic, the definition of $h_{\sup}^{\mathrm{Rok}}(G)$ gives the reverse inequality

$$
h_G^{\mathrm{Rok}}(D,m_D)\le h_{\sup}^{\mathrm{Rok}}(G)=s,
$$

where the last equality is the inherited strict bound combined with Seward's binary min formula. This proves (2.8). Notice that no entropy comparison for the inclusion $D\subset X$ was assumed: the lower bound is a continuity statement about invariant measures, and the upper bound is the defining supremum over free ergodic actions.

The algebraic infinitude/non-finite-type facts have identified prior art. The exact maximizing-tail comparison (2.8) and the relative-layer application (2.3) were developed and separately audited in this run; no priority claim beyond that bounded search is made.

## 3. Additional structural consequences

### The defect action has infinite-entropy Bernoulli cyclic restrictions

Assume the family-197 torsion-free/nonamenable premise. The dual of $K$ is the nonzero projective left module $Rr$. For $H=\langle g\rangle\cong\mathbb Z$, $g\ne1$, put $Q=\mathbb F_2[H]\cong\mathbb F_2[t,t^{-1}]$. The module $R$ is free over the PID $Q$, and its summand $Rr$ is consequently free over $Q$.

Its rank is exactly countably infinite. The index $[G:H]$ is infinite, since a finite-index amenable subgroup would make $G$ amenable. Write $S=\operatorname{supp}(r)$. Choose $g_i$ successively so that the finite coset sets $Hg_iS$ are pairwise disjoint: each earlier choice excludes only finitely many left $H$-cosets, of which infinitely many remain. The elements $g_ir$ have disjoint $Q$-module coset supports. Each is nonzero and is $Q$-torsion-free because $R$ is $Q$-free. They are therefore $Q$-linearly independent. Countability supplies the matching upper bound on the rank.

Duality now gives the compact-group Haar conjugacy

$$
K\big|_H\cong(\mathbb F_2^{\mathbb N})^H.
\tag{3.1}
$$

Thus the restriction to every nontrivial cyclic subgroup is a Bernoulli $\mathbb Z$-shift of infinite Kolmogorov–Sinai entropy. The $G$-action on $K$ is mixing, as a factor of the mixing full shift, and essentially free, as is also immediate from (3.1).

This does not prove $h_G^{\mathrm{Rok}}(K)>0$. The subgroup has infinite index, and countably many coset tracks are required to turn a $G$-generator into an $H$-generator. Bowen's zero-entropy extension theorem supplies explicit counterexamples to transferring this subgroup behavior to positive ambient Rokhlin entropy: a zero-$G$-entropy extension of a $G$-Bernoulli shift retains infinite KS entropy upon restriction to each such $H$, by amenable entropy monotonicity for that restricted factor.

### A Baumslag–Solitar subgroup is forced

Formanek's prime-characteristic criterion, as stated in Bartels–Lück–Reich p. 9, says: if a group has no $p$-torsion and no nonidentity element conjugate to a $p^k$-power of itself, its group algebra over a field of characteristic $p$ has only trivial idempotents. Applying the contrapositive to $r$ and $p=2$ gives $g\ne1,t\in G,k\ge1$ with

$$
tgt^{-1}=g^{2^k}.
\tag{3.2}
$$

Since $g$ has infinite order, this is an embedded $\mathrm{BS}(1,2^k)$, not merely a homomorphic image. To check injectivity, write $\mathrm{BS}(1,n)=\mathbb Z[1/n]\rtimes\mathbb Z$, $n>1$. The homomorphism sending its standard generators to $g,t$ is injective on the normal $\mathbb Z[1/n]$: a nonzero element is conjugate to a nonzero integral power of $g$. If its kernel had an element of nonzero integer height $q$, its commutator with the unit element of $\mathbb Z[1/n]$ would be the nonzero element $n^q-1$ of that normal subgroup, contradicting this injectivity.

This is an application of established literature, not a new Formanek theorem. It explains more precisely the obstruction to hyperbolicity. It also gives an internal amenable root/dilation structure to investigate without adjoining another group. However, that subgroup is neither finite-index nor coamenable in nonamenable $G$. Baumslag–Solitar dilation alone cannot force zero supremal entropy: $\mathrm{BS}(1,n)$ itself is infinite amenable and has unbounded finite Bernoulli entropy. No ambient entropy compression theorem using (3.2) was proved.

### A counterconstruction to universal homoclinic-tail exclusion

The tail depends on the chosen one-sided-inverse witness. This can be checked entirely inside the original group's ring, without replacing the group. For $L\ge1$, define

$$
e_L=1-b^La^L,\quad
a_L=e_L+b^La^{L+1},\quad
b_L=e_L+b^{L+1}a^L,\quad p_L=b^Lra^L.
$$

The identities $e_Lb^L=0$ and $a^Le_L=0$ kill all cross terms, giving

$$
a_Lb_L=1,\qquad b_La_L=1-p_L,\qquad
a^Lp_Lb^L=r\ne0.
$$

If $b=a^*$, as in the source, then $e_L^*=e_L$ and $b_L=a_L^*$. The new configuration map $B_L=T_{b_L}$ fixes $E_L=\ker A^L=\operatorname{im}T_{e_L}$ pointwise. Indeed $T_{e_L}$ is the identity on its image and $b^{L+1}a^Le_L=0$. Therefore

$$
E_L\subset D_L:=\bigcap_n B_L^nX,\qquad E_L\cong K^L.
$$

The nonzero finite-support vector $C\delta_e$ belongs to $K$, so $E_L$ and then $D_L$ contain nonzero finite-support homoclinic points. Thus an argument excluding all homoclinic tail points from the abstract one-sided-inverse or self-adjoint premises is false. This says nothing about absence or presence of such points in the *specific original witness's* tail. It prevents a universal exclusion from being used without additional witness-specific information.

## 4. Decisive failed interfaces

The following failures were checked, rather than treated as unexplored plans.

| Proposed mechanism | Tested obstruction or precise failure |
|---|---|
| Infinite independent defect coordinates recover $X$ | The specified $\Theta$ has atomless conditional fibers and is not injective on any positive-measure Borel set. |
| Add a finite residual label to those coordinates | The actual tail $D$ is infinite; the finite-fiber marker lemma does not cover it. |
| Continuous equivariant group splitting of the tail | $U$ is not finitely generated, so it cannot split off cyclic $R$. |
| Compact or flat tail implies zero relative entropy | Compactness and flatness do not suffice: a nontrivial Bernoulli compact-group extension over an amenable group has positive relative entropy, with a free/flat kernel dual. |
| Positive entropy of a finite factor or subgroup transfers to $G$ | Intrinsic Rokhlin entropy is not factor monotone; infinite-index subgroup entropy has no such lower-bound transfer. |
| Infinite Bernoulli factor contradicts finite entropy of $X$ | False for nonamenable groups. Bowen's zero-entropy extensions can factor onto positive/infinite-entropy systems. |
| Regular Koopman summands force positive entropy | Bowen's zero-entropy extensions factor onto Bernoulli shifts and hence contain their regular Koopman representations. Seward's condition is necessary, not sufficient. |
| Positive top-degree $L^2$-Betti number gives a positive-entropy Gaussian action | The source-conditioned Euler calculation below gives $\beta_2^{(2)}>0$, but Hilbert-module dimension supplies no proved lower bound for a generator's Shannon entropy. The Gaussian candidate's entropy remains undetermined. |
| Cost $>1$ forces an action to have positive Rokhlin entropy | Free $F_2$-actions have cost 2, while Bowen supplies free ergodic zero-Rokhlin-entropy $F_2$-actions. This blocks an action-level implication; it does not refute every possible group-level existence theorem. |
| Random coordinate bijection doubles randomness | An equivariant random bijection $G\times\{0,1\}\to G$ violates mass transport: expected outgoing mass 2, incoming capacity 1. This excludes coordinate relabeling, not arbitrary nonlinear isomorphisms. |
| Sparse fixed masks determine the algebraic kernel | A nonzero finitely supported kernel vector must have every translate of its support hit; an invariant mask independent of the input then has density bounded below by the reciprocal support size. This does not control general input-dependent nonlinear codes. |
| Self-adjointness $b=a^*$ gives complex positivity | The source has $b=a^*$, but the mod-2 coisometry has no faithful positive complex trace lift satisfying the same inverse identity. The characteristic-zero direct-finiteness argument cannot be imported. |
| Mutual Bernoulli factors imply conjugacy | Bowen's mutual-factor theorem supplies weak isomorphism, not a measurable inverse. |

The finite-fiber statement used here has a direct proof. For an ergodic nonatomic base and fibers of size at most $d$, measurably label each fiber. On a base set of measure $p>0$, record the label; elsewhere record a star. The base determines whether the set is visited, so conditional Shannon entropy is at most $p\log d$. Ergodicity makes its translates cover the base modulo null sets. The base point and label orbit-name then recover the fiber point. Letting $p\to0$ gives zero relative Rokhlin entropy. The actual infinite fibers do not admit this finite-label estimate.

The cohomological calculation was checked against the original graph parameters. Write $\ell$ for the source's construction parameter (to distinguish it from the defect support size $m$ above). There are 16,520 directed labels, 8,260 rose edges, $16,513\ell$ vertices in $\Gamma_A$, and $16,513(\ell-1)$ in $\Gamma_B$. Every directed label has respectively $129\ell$ and $129(\ell-1)$ outgoing slots. Dividing slots by two gives $1,065,540\ell$ and $1,065,540(\ell-1)$ graph edges. If $c_0$ counts connected components of both graphs, coning them changes Euler characteristic by $c_0-|V|+|E|$, hence the source complex $Y$ satisfies

$$
\chi(Y)=1,049,027(2\ell-1)+c_0-8,259>0.
$$

Conditional on its claimed finite aspherical two-dimensional structure, the $L^2$ Euler–Poincaré formula and infinitude of $G$ give $\beta_2^{(2)}(G)-\beta_1^{(2)}(G)=\chi(Y)$, thus $\beta_2^{(2)}(G)>0$. The real harmonic top-chain representation is a nonzero subrepresentation of finitely many regular representations and gives a free mixing Gaussian candidate. No theorem converting this particular Gaussian dimension into positive Rokhlin entropy was established. Cost's usual lower bound involves $\beta_1^{(2)}$, for which this calculation supplies no positive lower bound.

The outer-Pinsker cancellation route was also tested. Under each finite splitting, Seward's product theorem expresses the Pinsker algebra as the join of the two pulled-back Pinsker algebras. Iterating this does not identify the residual intersection or supply a cancellation theorem. In the positive alternative, Sinai's factor theorem extracts smaller Bernoulli factors, but their intrinsic entropy is not their outer entropy in an arbitrary extension. Bowen's zero-entropy extensions are counterexamples to that identification. No Pinsker argument deciding the sign or constructing a measurable inverse was obtained.

## 5. Consequences for Bowen and the exact unresolved obligation

The sign of $s$ is unchanged by this investigation. The new coding obstruction concerns the particular algebraic factor (2.1), not an isomorphism invariant separating arbitrary Bernoulli shifts.

If $s>0$, Seward's finite-base formula gives entropy $t$ to every Bernoulli base with $0<t<s$, producing uncountably many pairwise nonisomorphic Bernoulli shifts and refuting complete collapse. Infinite-base Bernoulli shifts then have infinite Rokhlin entropy, although the supremum over finite entropy values remains $s<\log2$. This would also refute the groupwise implication POS $\Rightarrow$ INF. If $s=0$, Corollary 7.7 excludes every positive-entropy free ergodic action, including infinite entropy, and all nontrivial Bernoulli shifts have zero Rokhlin entropy. That equality alone is not measurable isomorphism.

**Correction to the old handoff.** Its `RESEARCH.md` Theorem C(4), and the corresponding discussion of an extra infinite-entropy obstruction, are false. Seward's Corollary 7.7 equates existence of finite positive and infinite entropy free ergodic actions. The statement still open in Seward is $s>0\Rightarrow s=\infty$, not the possibility of an infinite-entropy free ergodic action when $s=0$. The older file is retained as history; this report supersedes that scoped claim.

For the canonical extension, the precise remaining zero-entropy obligation is to construct relative generating partitions $\beta_\varepsilon$ satisfying

$$
\sigma_G(\beta_\varepsilon)\vee\mathcal F=\mathcal B(X),
\qquad H_\mu(\beta_\varepsilon\mid\mathcal F)<\varepsilon,
$$

despite its infinite atomless fibers. Equation (2.3) proves that succeeding would establish $s=0$, not merely zero entropy of some factor. No such construction was obtained. For a positive resolution, neither (3.1), the regular Koopman representation, nor (3.2) supplies a positive ambient lower bound; a valid lower bound or a free ergodic action with positive Rokhlin entropy is still missing.

Even a zero-entropy solution would leave a separate classification obligation: construct a measurable equivariant conjugacy between unequal-base Bernoulli shifts, with inverse, or prove a theorem giving one. The failed inverse for $\Theta$ is not evidence that all other nonlinear conjugacies fail.

## 6. Mathematical dependencies and verification limits

| Assertion | Complete substantive inputs |
|---|---|
| Algebraic layer map, dual tail, flat/nonprojective/nonsplit module | Countable $G$, coefficient field $\mathbb F_2$, finite-support $a,b$ with $ab=1\ne ba$; compact-group/Pontryagin duality; Schanuel's lemma; filtered colimits of flat modules. No hyperbolicity, soficity, or entropy premise. |
| Atomless fibers and failure on every positive-measure Borel set | Preceding algebra; finite-support subgroup reduction or the cited 2021 limit-set theorem; Haar disintegration of compact-group quotients. |
| Entropy neutrality (2.3) | Free ergodic finite-base Bernoulli shift; finite splittings; Abért–Weiss; weak containment passing to factors; Seward Weak Containment Theorem 1.2; Seward Krieger II Corollary 7.2(ii). |
| Common value equals $s<\log2$ for family 197 | Inherited proper-subshift bound; Seward Weak Containment Theorem 1.5 and Krieger II Theorem 1.10. |
| The intrinsic tail entropy equals the supremum (2.8) | Flat quotient module; torsion-free source premise; Laurent-ring torsion-freeness and dual Bernoulli factors (freeness); free character orbits (mixing); decreasing Haar subgroup weak-* convergence; Alpeev–Seward Krieger III Corollary 5.6(ii); finite coordinate generator; preceding identification of the finite-entropy supremum with $s$. |
| Infinite Bernoulli cyclic restrictions | Nonzero projective module $Rr$; torsion-free/nonamenable source premise; restriction of free modules to subgroup rings; Laurent PID freeness; finite-support disjoint-coset argument; Pontryagin duality. |
| Embedded $\mathrm{BS}(1,2^k)$ | Nontrivial idempotent $r$; absence of 2-torsion; Formanek criterion; infinite order of $g$; elementary normal-subgroup argument above. |
| Consequences of $s=0$ or $s>0$ for Bernoulli entropy | Seward Krieger II Theorem 1.10, Theorem 1.12/7.6 and Corollary 7.7; isomorphism invariance. |
| Positive $\beta_2^{(2)}$, without entropy positivity | Original graph label/slot counts and source-claimed asphericity; Lück's $L^2$ Euler–Poincaré formula. |

All main steps are written above and were mathematically checked by the coordinator and the tail audit workers. This is not a proof-assistant certificate. No concrete matching realization or expanded relator list, explicit support cardinality, numerical entropy value, peer review, or exhaustive novelty search was obtained. Finite diagnostic computations cannot decide the measurable entropy sign and none is presented as doing so.

## 7. Primary references

1. [Pinned Astra state](https://github.com/harjassand/astra-research-knowledge/tree/b5824d0fcbfe0688980788da2722270a2f068fb0).
2. OpenAI, [family-197 original preprint](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Torsion-Free-Group-Algebra-That-Is-Not-Directly-Finite-October-4-2026/direct-finiteness.pdf), with [algebra source](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Torsion-Free-Group-Algebra-That-Is-Not-Directly-Finite-October-4-2026/build/sections/algebra.tex).
3. Abért–Weiss, [Bernoulli actions are weakly contained in any free action](https://arxiv.org/abs/1103.1063).
4. Seward, [Weak containment and Rokhlin entropy](https://mathweb.ucsd.edu/~bseward/Files/weakcontainrokentropy.pdf), Theorems 1.2, 1.5 and the outer-Pinsker statements. The precise Theorem 1.2 and Corollary 6.6 interface was read; no conjectural addition formula was used.
5. Seward, [Krieger's finite generator theorem for actions of countable groups II](https://mathweb.ucsd.edu/~bseward/Files/krieger2.pdf), Theorems 1.10/1.12, Proposition 6.5, Corollaries 7.2/7.7 and the inverse-limit discussion. The continuity citation in this proof is Part II, not a presumed same-numbered statement in Part III.
6. Ceccherini-Silberstein–Coornaert–Phung, [On linear shifts of finite type and their endomorphisms](https://arxiv.org/pdf/2011.14191), v4 (2021), Theorem 1.5/Corollary 1.6 and Theorem 1.9/Corollary 1.10. These supply prior art for infinite-dimensional, non-finite-type $D=\Omega(B)$.
7. Bowen, [Zero entropy is generic](https://arxiv.org/pdf/1603.02621), v2, Theorem 1.2/5.1 and the Section 4 universal Bernoulli factor construction; used as actual counterexamples to proposed entropy and spectral transfers.
8. Bowen, [Finitary random interlacements and the Gaboriau–Lyons problem](https://arxiv.org/abs/1707.09573), mutual-factor corollary. Weak isomorphism was not promoted to conjugacy.
9. Bartels–Lück–Reich, [On the Farrell-Jones Conjecture and its applications](https://arxiv.org/pdf/math/0703548), p. 9, prime-characteristic Formanek criterion. [Original Formanek paper](https://doi.org/10.4153/CJM-1973-037-6). The use here is the stated criterion, not K-theory positivity or a characteristic-zero argument.
10. Seward, [The Koopman representation and positive Rokhlin entropy](https://arxiv.org/abs/1804.05270), used only as a necessary-condition interface, together with Bowen's counterexamples to its converse.
11. Alpeev–Seward, [Krieger's finite generator theorem for actions of countable groups III](https://arxiv.org/pdf/1705.09707), v3 (2020), Corollary 5.6(ii): the separate weak-* upper-semicontinuity input for (2.8).
12. Lück, [L²-Invariants](https://math.uchicago.edu/~shmuel/L%5E2%20cohomology%20readings/Lueck_L2-invariants.pdf), Theorem 1.35; Gaboriau, [Coût des relations d'équivalence et des groupes](https://perso.ens-lyon.fr/gaboriau/Travaux-Publi/Cout/Cout.pdf), Corollary 1. These are used for the cohomology calculation and the cost counterexample, not as an ambient entropy lower bound.

**Research status:** an exact supremal-entropy tail theorem, a rigorous obstruction for the specified infinite defect coding, an exact relative-entropy identity, and source-conditioned structural deductions. No resolution of the entropy sign or Bowen's conjugacy question has been established.
