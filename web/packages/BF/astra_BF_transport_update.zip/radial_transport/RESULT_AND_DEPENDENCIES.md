# Smooth planar radial non-Monge construction

## Theorem and verification scope
For the three-particle cost c(x,y,z)=1/|x-y|+1/|x-z|+1/|y-z|, there is a radial density rho in C_c^infinity(R^2), with a probability measure mu=rho dx supported on five disjoint annuli, such that the equal-marginal Kantorovich minimum is finite and attained but no optimal plan is a graph over any coordinate. The infimum over measurable mu-preserving map pairs equals that minimum.

The argument is computer-assisted: trusted mpmath outward interval arithmetic discharges explicit finite hypotheses, followed by the self-contained analytic construction in PROOF.md. The two parts have separate analytic/adversarial reviews and the computation was rerun locally. AI review is not external review; neither proof-assistant certification nor priority clearance is claimed. No explicit numerical annulus width is necessary or provided: its existence follows from strict inequalities, continuity and the implicit-function theorem.

## How the chain closes
1. A five-variable Krawczyk inclusion isolates four angular stationary coordinates and one radius. Its fifth equation is exact equality of the two source radial forces. The contraction bound also makes the Jacobian nonsingular.
2. Interval-positive angular Hessians on four reflected local boxes, and global exclusion on each complement, classify the two contacts' global minima.
3. All 33 noncontact radius multisets, each in both cyclic orders, have a strict cost gap greater than 0.006 above the exact dual values. Repeated radii and angular boundary/collision configurations are included.
4. The reduced radial Hessian is computed by the angular Schur complement. Every required mixed derivative is nonzero, with a separate symbolic-derivative interval check.
5. One common source potential, two anchor envelopes, and sufficiently large negative potential curvature give smooth equality branches on a shared source annulus. The finite gap survives restriction to smaller annuli.
6. Rotationally invariant source mass and a symmetric branch mixture produce the common smooth radial marginal. Any graph optimizer must select among finitely many equality maps on the source annulus. Each branch image has exactly half the marginal mass of its source selection set, contradicting marginal preservation.
7. Nonatomic cell allocation gives graph approximants with costs tending to the minimum, so the claim is nonattainment rather than a positive value gap.

## Yukawa consequence
The same existence/nonattainment conclusion holds for every screening parameter kappa>0 with pair kernel exp(-kappa*r)/r.

Here the continuation premise in PROOF.md is supplied by the certificate: its exact C^1 stationarity/equal-force system has an invertible five-variable Jacobian at kappa=0. Replace the Coulomb edge kernel in that mathematical system by exp(-kappa*r)/r; the implicit-function theorem gives a local branch of exact roots. The angles and radii stay separated, and the strict finite gaps, isolated angular minima, Hessian positivity and nonzero reduced radial couplings persist for small kappa. A uniform collision barrier exp(-kappa_1 D)/r prevents angular minima escaping to collisions, so the global assertions persist too. Dual contact values are continuously redefined by their exact costs. Thus at least one small kappa_0>0 has a radial example.

For any given kappa>0, dilate this example by lambda=kappa_0/kappa. The identity exp(-kappa*lambda*r)/(lambda*r)=lambda^(-1) exp(-kappa_0*r)/r multiplies every transport cost by a positive constant, preserves marginals under dilation, and preserves graph versus non-graph form. This proves the consequence for every kappa>0 without a new numerical search. It does not supply an explicit permissible small-kappa threshold.

## Attribution and boundaries
The envelope and mass-deficit mechanism is adapted from OpenAI/math family373, pinned manuscript at fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb. The present analytic proof and finite certificate do not take that manuscript's theorem as an unverified premise. Standard implicit-function, compactness and nonatomic measure arguments are used directly.

The radial restriction is the substantive additional conclusion over the source's nonradial examples. Equality of the two infima is known in broader settings and is not a novelty claim. The primary-literature comparison supports a potentially new specialist result but is not exhaustive. This does not prove non-Monge behavior for generic physical densities, connected positive supports, or radial densities in three dimensions. A small positive background cannot be added by an energy-gap argument, because there is no Monge/Kantorovich value gap.
