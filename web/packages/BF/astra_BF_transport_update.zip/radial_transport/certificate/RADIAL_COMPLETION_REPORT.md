# Radial Coulomb candidate: completed interval certificate

Date: 2026-10-09 (UTC)

## Result

The fixed five-radius candidate now has a reproducible outward-rounded interval certificate for its force-matching root, global angular contacts, finite-shell dual gap, and angularly reduced radial cross derivatives. All active checks pass. In combination with the separately audited local envelope and finite-branch mass-obstruction argument, this discharges the candidate's finite-shell hypotheses for a smooth radial no-Monge example in the plane.

This is a computer-assisted interval proof using mpmath's interval context, not a proof-assistant kernel certificate or external expert review. The annular lift uses the existence argument from the conditional audit: choose sufficiently large finite curvature, then shrink the annuli by continuity/IFT. This rerun does not provide an explicit numerical annulus width.

## Exact candidate and contact values

The five shell radii are

- `R0 = 1`
- `R1 = 3.7632172480656902`
- `R2 = 0.4252867292159305`
- `R3 = 1.7669840027711121`
- `R4 = s`, where `s` is the unique zero of the five-equation system in the `force_root.X` box in `validated_certificate.json`.

The five equations are angular stationarity for `P=(R0,R1,R2)`, angular stationarity for `Q=(R0,R3,R4)`, and equality of their source radial forces. The saved decimal centers are only seeds. Existence and uniqueness of the exact root in the displayed interval box are established by the Krawczyk inclusion and contraction checks.

The exact contact values are the angular minima at those two root configurations. Their outward enclosures are in `global_and_lp.contact_costs`; approximately `C(P)=1.20749195771086845` and `C(Q)=1.55525235042329408`.

Exact dual values are defined by

- `p0 = 0.57511124`, `p1 = -0.25224512`, `p3 = 0.21401706`
- `p2 = C(P) - p0 - p1`
- `p4 = C(Q) - p0 - p3`

Thus equality at both P and Q is exact by definition, with one shared source value. JSON interval entries enclose these exact values; they are not being declared equal to their midpoints.

## Verified checks

- Krawczyk image: all five components strictly inside the root box. Maximum upper row-sum bound for `I-AJ(X)` is `4.146998483112157e-24`.
- Contact angular geometry: all four chart boxes (two reflections for each profile) contain the mapped root interval and have positive angular Hessian (`H11>0`, `det>0`). The four B&B complements are certified, so each profile's angular minimizers consist exactly of its reflection orbit.
- Finite-shell dual: the 35 unordered radius multisets of size three were considered; P and Q are the only equality multisets. For each of the other 33 multisets, both cyclic gap orders were checked, giving 66 certified B&B cases. Every noncontact angular cost is proved greater than the dual-potential sum plus `0.006`. The smallest certified excess beyond that threshold is `4.81431502129933449e-8` (multiset `(0,2,3)`, order `(0,2,1)`). This is a lower bound from interval leaf comparisons, not a midpoint estimate.
- Reduced radial Hessian: with `c(r)=min_{alpha,beta} F(r,alpha,beta)`, the code computes `c_rr = F_rr - F_rTheta (F_ThetaTheta)^(-1) F_Theta r`. For each exact contact and both reflections, the intervals for `c01`, `c02`, and `c12` are strictly positive. Rounded values are:

  - P: `c01 ≈ 0.01975331161236`, `c02 ≈ 0.71077320254301`, `c12 ≈ 0.01032870254621`
  - Q: `c01 ≈ 0.15714624469302`, `c02 ≈ 0.47844509616205`, `c12 ≈ 0.18390977051423`

  Full outward enclosures, including angular Hessian determinants and branch-by-branch positivity flags, are in `reduced_radial_derivatives.branches` in the JSON. The needed source-anchor and anchor-nonanchor couplings are `c01` and `c12`; both are nonzero at P and Q. Continuity then permits the neighborhoods in the envelope construction to be shrunk until the couplings remain nonzero.

## Domain and rounding repairs

The certifier no longer maps angle/gap coordinates using scalar `mp.pi`. `TWO_PI=2*iv.pi` is used for the interval transformations and for the third cyclic gap. Global gap boxes lie in the exact dyadic square `[0,7]^2`, which contains the closed `2*pi` gap simplex. Local chart and root boxes are converted from mpf endpoints directly to `iv.mpf`; there is no rounded `mp.nstr`/`mp.mpf(TWO_PI.b)` clipping step that could shrink their coverage. The root interval is formed by interval arithmetic around the fixed center. Rounded matrix entries in the Krawczyk preconditioner are converted directly to enclosing intervals. The script also verifies that each transformed root interval lies strictly inside its local gap box. The contact B&B record now stores the actual `rel_order` used by that run.

## Reproduction

From this directory, with Python 3.12.14 and mpmath 1.3.0:

```sh
python certify.py all
```

The run writes `validated_certificate.json` and prints the contact-complement summaries. On the recorded environment it completed in 27.83 seconds. All three aggregate flags are true: `force_root.all_inside && force_root.contraction`, `global_and_lp.all_root_gaps_inside_local && all_local_PD && all_global_contact && all_noncontact`, and `reduced_radial_derivatives.all_contact_branch_cross_derivatives_positive`.

The active interval precision is 60 decimal digits (`iv.dps=60`); ordinary `mp` is used only to choose fixed dyadic box endpoints and a fixed Krawczyk preconditioner. Every comparison that determines a proof flag is an interval endpoint comparison.
