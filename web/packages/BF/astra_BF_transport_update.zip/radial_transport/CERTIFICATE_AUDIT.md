# Adversarial review of the radial interval certificate

Review date: 2026-10-09 (UTC)

## Scope and reviewed artifacts

This review audits the *current* interval-certificate route in `radial_completion/certify.py` and `radial_completion/angular_interval.py`, including the corrected `validated_certificate.json`. It is a mathematical/static review of the implementation and recorded run, not a proof-assistant verification of every mpmath operation.

SHA-256 hashes at review time:

- `radial_completion/certify.py`: `5511e4ac5fdbda052e3669f24453de985bcc75c4077c1784fcc3f5267865cc19`
- `radial_completion/angular_interval.py`: `29c850ab74f9eb0a75c399f4f670722001bffe8e20a20b4eb05448390fb67ca0`
- `radial_completion/validated_certificate.json`: `434c82908fa6afec4a05301b78a30b546bba044009714ec74e407b855d19942d`

The JSON reports elapsed time 27.8255 s. It records Krawczyk inclusion and contraction true; all four local angular PD/root-containment checks true; all four contact-complement searches true; all 66 noncontact triple/order searches true; and all four pointwise Schur cross-derivative checks positive.

## Verdict

I found **no fatal mathematical gap in the current interval certificate implementation or its recorded result**, conditional on the intended mpmath interval-arithmetic semantics and on treating the input decimal strings as exact decimal rationals. The current code fixes the chart-transform/endpoint issues described in the older `radial_completion/INDEPENDENT_INTERVAL_AUDIT.md`; that older note is stale on those implementation points and on the absence of a Schur check.

This is a validated numerical certificate executed in ordinary Python with mpmath intervals, not a standalone proof-assistant artifact. The JSON is a summary, so an independent verifier must trust/re-run the source or inspect the interval implementation; the printed margin strings are not a substitute for the in-code strict interval comparisons.

## Main soundness checks

### 1. Root isolation and uniqueness

`G5` consists of the four angular stationarity equations for profiles P and Q plus equality of the shared source-radius force. Direct differentiation of the pair cost `h(a,b,t)` agrees with `edge` and `J5`, including the sign of the Q-force row and its derivative in the fifth radius.

`root_box` encloses the exact decimal radius used for the box radius, and its interval addition to the finite-precision center rounds outward. In `krawczyk`, the center residual and Jacobian on the box are interval evaluations; the preconditioner is merely a fixed high-precision approximate inverse, whose entries are enclosed by `Aiv`. The Krawczyk image is strictly interior in all five coordinates. In addition, the reported upper bounds for every row sum of `abs(I-AJ(X))` are below 1 (largest about `4.15e-24`). This contraction bound supplies uniqueness; it also implies the chosen preconditioner is nonsingular, since a nonzero vector in its kernel would be fixed by `I-AJ` and contradict the strict norm bound. Thus the calculation does not rely on treating the floating-point inverse as an exact inverse.

The isolated fifth-radius interval is inside the initial exact-decimal bracket in `angular_interval.py` (visible from the printed enclosures); the certificate uses the isolated interval for subsequent radii. The first four radii are positive exact-decimal inputs. All five radii are pairwise distinct, so pair distances in the contact-root equations are nonsingular.

### 2. Full angular-domain coverage, including boundaries and collisions

For each labelled triple, fixing particle 0 at angle zero leaves two cyclic orders, `(0,1,2)` and `(0,2,1)`. Each is represented by nonnegative successive gaps `g1,g2,g3` with `g3=2*pi-g1-g2`. The square `[0,7]^2` contains the entire feasible gap simplex because `2*pi<7`; infeasible boxes are skipped only when the outward interval upper bound for `g3` is strictly negative. If the interval for `g3` straddles zero it is clipped to `[0,upper]`, which still encloses every feasible gap. Closed box splitting covers all boundaries, including zero gaps and collinear configurations. The two orders together cover configurations with either orientation; ties/coincidences lie on their closed boundaries.

The `gap_lower` objective is safe: for each edge, `d.b` is an outward upper bound on its squared distance, so `1/sqrt(d.b)` is a lower bound on the Coulomb term whenever the distance is nonzero. If an edge-distance upper bound is nonpositive, the routine returns zero, a safe lower bound. Equal-radius collision configurations therefore are not silently dropped. At finite positive box widths their interval distance upper bounds permit refinement; boxes adjacent to collisions can be resolved by their growing lower bound. The recorded searches end certified rather than at a node/depth cap.

In the B&B proof decision, the only acceptance test is `lb.a > threshold.b`. `float(lb.a)` is used solely as a heap scheduling key; it cannot change coverage or acceptance. Midpoint bisection covers each parent rectangle by its two closed children. The 66 noncontact records are exactly the 33 noncontact multisets among the 35 three-element multisets from five shells, each checked in both orders.

### 3. Endpoint conversion, contact neighborhoods, and global minima

The active global route uses `TWO_PI = 2*iv.pi`, not ordinary-precision `mp.pi`; the gap-domain edge is the exactly representable integer 7. Root angle intervals are mapped to gap intervals with outward interval addition by `2*pi`. The local gap-box center is chosen from endpoint midpoints at higher ordinary precision, but that midpoint is used only to define a proposed dyadic box: `interval_root_in_gap_box` then verifies that the entire interval root image lies strictly inside that box. The local-box-to-angle map uses interval `TWO_PI`, and the Hessian is evaluated over interval hulls containing the transformed local domain. Thus ordinary-precision midpoint selection does not narrow either the root or the convexity domain.

For every contact and each of its two reflected branches, the local rectangle has `H11>0` and determinant `>0` throughout its interval angle hull. Hence the angular cost is strictly convex on that convex angle rectangle. The isolated root is an interior stationary point, so it is the unique minimizer there. The four contact B&B runs cover the complement of the corresponding open local rectangle in the appropriate cyclic-order square; each proves cost strictly above the contact-cost enclosure on that complement. The smallest recorded complement margin is about `4.97e-10`.

`gap_rect_complement` is the four-rectangle complement cover of the local rectangle in `[0,7]^2`; its closed rectangles overlap on boundaries but leave no gap. The contact records are correctly labelled with `rel_order` in the current code. Both mirrored minima are treated for P and Q.

### 4. Exact dual-potential interpretation

The interval entries for the dual vector are enclosures, not exact midpoint values. The exact values may be defined by

`p0 = 0.57511124`, `p1 = -0.25224512`, `p3 = 0.21401706`,

`p2 = C(P)-p0-p1`, and `p4 = C(Q)-p0-p3`,

where `C(P)` and `C(Q)` are the exact angular contact costs at the unique isolated force-equality root. This definition makes both contact equalities exact and uses one shared source potential. The interval costs and interval potential sums enclose those exact reals. For each noncontact multiset/order the accepted comparison is against the upper endpoint of `potential sum + 0.006`, so it proves strict slack over the exact dual sum. The smallest recorded excess beyond the requested 0.006 is about `4.81e-8`; the decisive fact is the interval comparison, not the printed decimal margin.

### 5. Reduced radial Schur derivatives

The current `reduced_radial_hessian` builds the radial block `D`, mixed block `B`, and two-angle Hessian `H`, then evaluates `D-B H^{-1} B^T`. I checked the edge derivatives and block assembly against differentiating the three-pair cost in coordinates `(r0,r1,r2,alpha,beta)`: in particular the shared edge has angle `alpha-beta`, which gives the `+/-` signs in its mixed rows and the off-diagonal angular Hessian. The contact angular Hessian determinants are strictly positive, so the interval inverse is valid. On both reflected branches for P and Q, each of the three off-diagonal Schur entries has an interval wholly above zero. Approximate enclosures are P: `c01≈0.0197533`, `c02≈0.7107732`, `c12≈0.0103287`; Q: `c01≈0.157146`, `c02≈0.478445`, `c12≈0.183910`.

## Remaining scope caveat

These files certify the finite-shell angular/dual facts, the isolated root, and pointwise Schur signs at the contact branches. They do not, by themselves, prove every hypothesis of a broader radial-transport theorem or give a uniform interval neighborhood/annulus certificate for any condition that theorem may require. Strict pointwise Schur signs imply some neighborhood by continuity, but a theorem requiring a specific uniform annulus still needs its own argument/certificate. That is outside this interval-file audit.

