# Independent audit: conditional planar radial Coulomb non-Monge theorem

## Bottom line

The local-envelope construction and finite-branch mass obstruction are mathematically sound under the exact hypotheses stated below. In particular, the obstruction applies to every optimal deterministic graph coupling, including nonsymmetric ones; no symmetry assumption on a candidate Monge plan is used.

This is a standalone conditional theorem. Applying it to the proposed five-shell data requires the companion numerical certificate; this document does not certify those shell data.

## Set-up and exact hypotheses

For $x,y,z\in\mathbb R^2$, let
\[
 C(x,y,z)=|x-y|^{-1}+|x-z|^{-1}+|y-z|^{-1},
\]
with value $+\infty$ at collisions. For positive radii define the angularly reduced radial cost
\[
 c(a,b,d)=\min_{\theta,\varphi\in\mathbb T}
 C\big((a,0),(b,\theta),(d,\varphi)\big).
\]
The simultaneous-rotation degree of freedom has already been removed. The reduced cost $c$ is symmetric in its three radii.

Take five pairwise distinct positive radii
\[
 a_0,\ b_P,\ d_P,\ b_Q,\ d_Q,
\]
and two contact multisets \(P=(a_0,b_P,d_P)\), \(Q=(a_0,b_Q,d_Q)\), each with three distinct entries. Assume:

1. **Angular classification.** At each contact, the global angular minimizers, modulo simultaneous rotations, form exactly one reflection orbit (one point is allowed if fixed by reflection). The two-angle Hessian at a representative is positive definite.
2. **Finite shell certificate.** There are finite values \(p_i\), one per radius, and 
   \[
   c(R_i,R_j,R_\ell)\ge p_i+p_j+p_\ell
   \]
   for all 35 unordered radius multisets of size three with repetition. Equality holds exactly for (P,Q), and every other multiset has a common strict gap at least \(\delta>0\).
3. **Common source force.** The reduced-cost source derivatives agree exactly:
   \[
   c_a(P)=c_a(Q)=q.
   \]
4. **Radial response nondegeneracy.** For each profile, label its coordinates \((a,b,d)\) with \(a=a_0\), \(b\) the target radius used as the envelope anchor, and \(d\) the other target radius. Write all derivatives below for the reduced cost \(c\), evaluated at that profile. Choose a common sufficiently large \(K>0\), and set
   \[
   D=(K+c_{aa})(K+c_{dd})-c_{ad}^2,
   \]
   \[
   N_a=c_{ad}c_{db}-(K+c_{dd})c_{ab},\qquad
   N_d=c_{ad}c_{ab}-(K+c_{aa})c_{db}.
   \]
   Require \(D>0\), \(N_a\ne0\), and \(N_d\ne0\) at both profiles. These are the exact finite-\(K\) conditions needed below. For example, either \(c_{ab}c_{db}\ne0\) or \(c_{ab}c_{ad}\ne0\) is a convenient sufficient condition for all sufficiently large \(K\). The derivatives must be those of the angularly minimized cost; raw radial derivatives of \(C\) at fixed angles are not interchangeable with them.

The exact derivatives are the angular Schur complement. If \(\Theta=(\theta,\varphi)\) and \(F(a,b,d,\Theta)\) is the unreduced cost at a minimizing angular configuration, then
\[
 c_{ij}=F_{ij}-F_{i\Theta}(F_{\Theta\Theta})^{-1}F_{\Theta j}.
\]

## Conditional theorem

Under hypotheses 1–4, there is a smooth, compactly supported, radial probability measure $\mu$ with density $\rho\in C_c^\infty(\mathbb R^2)$, supported on five disjoint annuli, such that the three-marginal planar Coulomb problem with all marginals $\mu$ has an optimal coupling but has **no optimal Monge coupling** of the form \((\mathrm{id},T_1,T_2)_\#\mu\). The conclusion also rules out a graph representation over either of the other two marginals, by permuting coordinates.

This theorem is proved from the finite-shell hypotheses and the local analysis below. It does not rely on the correctness of the separate source373 construction; that work is motivation for the mechanism, not a load-bearing premise here.

## Proof

### 1. Build one common source potential and two local envelope branches

Choose one smooth radial source potential \(u_0\) on a small interval about \(a_0\), with
\[
u_0(a_0)=p_0,\qquad u_0'(a_0)=q,\qquad u_0''=-K.
\]
For each \(k\in\{P,Q\}\), write its non-anchor radius as \(d_k\), and choose a smooth potential \(w_k\) near \(d_k\) with
\[
w_k(d_k)=p_{d_k},\qquad w_k'(d_k)=c_d(k),\qquad w_k''=-K.
\]
The two profiles use the very same \(u_0\); equality of the source force is what permits this.

For a fixed anchor radius \(b\) near \(b_k\), define
\[
v_k(b)=\min_{a,d}\{c(a,b,d)-u_0(a)-w_k(d)\},
\]
where (a,d) range over sufficiently small closed intervals around (a_0,d_k). At the contact point, stationarity follows from (u_0'(a_0)=c_a(k)) and (w_k'(d_k)=c_d(k)). The Hessian in the minimized radial variables is
\[
M_K=\begin{pmatrix}K+c_{aa}&c_{ad}\\c_{ad}&K+c_{dd}\end{pmatrix}.
\]
It is positive definite for large (K), and its determinant is (D).

To check the full minimization, use the two angular coordinates relative to the fixed anchor vector. Their Hessian (A=F_{\Theta\Theta}) is positive definite by hypothesis 1. The Schur complement of (A) in the full Hessian of (F-u_0-w_k) is exactly (M_K), by the displayed formula for (c_{ij}). Thus the full Hessian in the minimized variables is positive definite. The two reflection-related minima have the same value by reflection symmetry. The angular classification and compactness isolate these minima; after shrinking the intervals, they give the minimizing envelope branches for nearby (b). Consequently (v_k) is smooth and radial, and
\[
v_k(b_k)=c(k)-p_0-p_{d_k}=p_{b_k}.
\]

The implicit-function theorem gives smooth radial responses (a_k(b),d_k(b)). Differentiating the two stationarity equations gives
\[
a_k'(b_k)=\frac{c_{ad}c_{db}-(K+c_{dd})c_{ab}}{D}=\frac{N_a}{D},\qquad
d_k'(b_k)=\frac{c_{ad}c_{ab}-(K+c_{aa})c_{db}}{D}=\frac{N_d}{D}.
\]
Hypothesis 4 makes both responses nonzero. They remain nonzero on smaller neighborhoods. Hence (b\mapsto a_k(b)) is locally invertible, and both target radii (b_k(a)), (d_k(b_k(a))) are local diffeomorphisms of the source radius.

### 2. Equality maps and the support-cubed dual inequality

For each profile, first fix open radial neighborhoods (I_0,I_{k,b},I_{k,d}) of its three contact radii, contained in the domains where the local minimizers/envelopes above are defined. Shrink these neighborhoods as needed so the envelope minimizer in (a,d) is unique for each anchor (b), apart from the angular reflection pair. The smooth angular minimizer branches, composed with the radial responses and inverted as above, give two reflected maps from the source annulus to each target annulus. In polar coordinates they have the form
\[
H_{k,j,\pm}(r,\theta)=\big(R_{k,j}(r),\ \theta\pm\phi_{k,j}(r)\big),
\]
where (R_{k,j}>0) and (R'_{k,j}\ne0). Thus each (H_{k,j,\pm}) is a smooth annulus diffeomorphism. The plus/minus maps have the same radial response.

Fix (K) and the local neighborhoods first. Each profile gives a source interval around (a_0) on which both response maps are invertible. Intersect these intervals and then choose one smaller common interval (J) around (a_0). For profile (k), define its two target intervals as (B_k=b_k(J)) and (D_k=d_k(b_k(J))), using the inverse source response. Shrink (J) so their closures remain inside (I_{k,b},I_{k,d}), and so the closures of (J,B_P,D_P,B_Q,D_Q) are pairwise disjoint. Their widths need not be comparable.

Define a single radial potential (U) on these five annuli: (u_0) on the source annulus; (v_k) on profile (k)'s anchor annulus; and (w_k) on its other target annulus. On either contact product box, the envelope definition and (C\ge c) give
\[
C(x,y,z)\ge c(|x|,|y|,|z|)\ge U(|x|)+U(|y|)+U(|z|).
\]
This inequality is valid in every coordinate ordering because the cost and the sum of the same one-variable potential are symmetric.

For every other shell multiset, the finite certificate has gap (\delta). Continuity of the reduced cost and of the local potentials, plus shrinking the five annuli, preserves a positive gap (for example (\delta/2)) for every such product box. There are only finitely many multisets, including those with repeated shells. Therefore
\[
C(x,y,z)\ge U(|x|)+U(|y|)+U(|z|)
\quad\text{for all }(x,y,z)\in\operatorname{supp}(\mu)^3.
\]
Equality occurs only on the following explicitly classified set: for (k=P,Q), choose a source point (x=(r,\theta)) with (r\in J), choose one of the two *joint* reflected angular branches (\varepsilon\in\{+,-\}) (or the single branch if reflection fixes the minimizer), and form
\[
\bigl(x,H_{k,b,\varepsilon}(x),H_{k,d,\varepsilon}(x)\bigr).
\]
Then take any of its (3!=6) coordinate permutations. There are no other equality tuples: noncontact shell multisets retain strict slack; on a contact box the envelope has a unique radial minimizer and equality in (C\ge c) requires a globally minimizing angular configuration. The plus/minus choices are joint choices for the whole triple, not independent signs for each target. This **support-cubed** inequality is all transport optimality needs; no all-space dual extension is asserted.

### 3. Construct a smooth radial marginal and an optimal plan

Choose a radial probability law \(\nu\) with a nonnegative \(C^\infty\) planar density compactly supported in the interior of the common source annulus. Sample \(x\sim\nu\), choose profile \(P\) or \(Q\) with probability \(1/2\), choose either reflection with probability \(1/2\) (or the one fixed branch if reflection fixes it), form the corresponding contact triple, and uniformly permute its three coordinates. Call the resulting symmetric coupling \(\Gamma\).

Its common marginal has
\[
\mu|_{A_0}=\nu/3.
\]
For each target annulus (A_{k,j}), in the two-branch case,
\[
\mu|_{A_{k,j}}=\tfrac1{12}(H_{k,j,+})_\#\nu+
                     \tfrac1{12}(H_{k,j,-})_\#\nu.
\]
The composition (H_{k,j,-}^{-1}H_{k,j,+}) is
\[
(r,\theta)\longmapsto(r,\theta+2\phi_{k,j}(r)),
\]
which preserves every radial measure. Hence the two pushforwards are equal and
\[
\mu|_{A_{k,j}}=(H_{k,j,+})_\#\nu/6=(H_{k,j,-})_\#\nu/6.
\]
For a reflection-fixed branch, the single branch has weight (1/6), with the same conclusion. The masses are (1/3) on the source annulus and (1/6) on each of four target annuli, totaling one.

If \(g(r)\) is the planar radial density of \(\nu\), the density transported by a branch with radial response \(R\) is
\[
g_{\rm out}(R(r))=\frac{g(r)\,r}{R(r)|R'(r)|}.
\]
It is smooth, radial, and compactly supported strictly inside the image annulus. Thus each pushforward has a smooth zero extension; their disjoint sum with \(\nu/3\) gives \(\mu\in C_c^\infty(\mathbb R^2)\), radial. The coupling \(\Gamma\) is supported on equality, and so
\[
\int C\,d\Gamma=3\int U\,d\mu.
\]
The support-cubed inequality gives the reverse lower bound for every coupling of \(\mu\) with itself three times. Therefore \(\Gamma\) is optimal.

### 4. Exclude arbitrary, possibly nonsymmetric, Monge plans

Suppose \(\pi=(\mathrm{id},T_1,T_2)_\#\mu\) were optimal. Since the support-cubed slack is nonnegative and \(\Gamma\) attains its integral bound, optimality forces equality in the dual inequality \(\pi\)-almost surely.

For \(x\) in the source annulus, equality classification leaves only finitely many possible first-output maps \(H_{k,j,+}\) or \(H_{k,j,-}\): two profiles, two target labels per profile, and at most two reflection branches. This conclusion does not use symmetry of \(\pi\). The measurable source annulus is therefore partitioned, up to null sets, into finitely many sets on each of which \(T_1\) agrees with one fixed branch \(H\). One set \(S\) has positive \(\nu\)-measure.

Assume \(H=H_{k,j,+}\); the minus case is identical. The target marginal formula yields
\[
\begin{aligned}
\mu(H(S))
&=\tfrac1{12}\nu(S)
 +\tfrac1{12}\nu(H_{k,j,-}^{-1}H_{k,j,+}(S))\\
&=\tfrac1{12}\nu(S)+\tfrac1{12}\nu(S)
 =\nu(S)/6,
\end{aligned}
\]
because the intervening map is a radius-dependent angular rotation and \(\nu\) is radial. Meanwhile \(\mu(S)=\nu(S)/3\). Since \(T_1=H\) on \(S\), we have \(S\subseteq T_1^{-1}(H(S))\). If \(T_1\) preserves \(\mu\), then
\[
\mu(H(S))=\mu(T_1^{-1}(H(S)))\ge\mu(S),
\]
contradicting \(\nu(S)/6<\nu(S)/3\). Thus no optimal graph plan exists. No symmetry or cyclicity condition on the graph maps was used.

### 5. The Monge infimum still equals the Kantorovich minimum

For this construction, one can say more than “a positive gap has not been proved”: the two infima are equal, although the Monge infimum is not attained. Let (K_\mu=\operatorname{supp}\mu), and choose finite Borel partitions of the five compact annular pieces into cells of diameter at most \(\epsilon_n\to0\), with every cell contained in one annulus. Index all cells by (C_i). For the optimal coupling \(\Gamma\), put
\[
m_{ijk}=\Gamma(C_i\times C_j\times C_k).
\]
Because \(\mu\) is nonatomic, each source cell \(C_i\) can be split into Borel pieces \(E_{ijk}\) of masses \(\mu(E_{ijk})=m_{ijk}\). On each positive-mass piece choose measurable maps \(S^1_{ijk},S^2_{ijk}\) such that
\[
(S^1_{ijk})_\#(\mu|_{E_{ijk}})=\frac{m_{ijk}}{\mu(C_j)}\mu|_{C_j},\qquad
(S^2_{ijk})_\#(\mu|_{E_{ijk}})=\frac{m_{ijk}}{\mu(C_k)}\mu|_{C_k}.
\]
Such maps exist because the normalized restrictions of the nonatomic measure to these Borel sets are nonatomic standard probability spaces. Define \(T_1,T_2\) on \(E_{ijk}\) by these maps. The first map pushes \(\mu\) to \(\mu\) since, for each \(j\), \(\sum_{i,k}m_{ijk}=\mu(C_j)\); likewise \((T_2)_\#\mu=\mu\). The graph plan \(\Gamma_n=(\mathrm{id},T_1,T_2)_\#\mu\) has exactly the same mass \(m_{ijk}\) as \(\Gamma\) in every cell triple.

All nonzero \(m_{ijk}\) come from contact triples, which use three distinct annuli. The closures of the five annular support regions are separated by a positive radial gap, so Coulomb cost is bounded and uniformly continuous on every cell triple with nonzero mass, uniformly in \(n\). Since \(\Gamma_n\) and \(\Gamma\) have the same mass in each such cell triple, their cost integrals differ by at most the modulus of continuity of \(C\) at a distance \(O(\epsilon_n)\). Hence
\[
\int C\,d\Gamma_n\longrightarrow\int C\,d\Gamma.
\]
Every graph plan is a coupling and therefore has cost at least the Kantorovich minimum. This sequence proves the reverse inequality for the infimum over graph plans. Thus
\[
\inf_{\mathrm{Monge}}\int C\,d\pi
=\min_{\mathrm{all\ couplings}}\int C\,d\pi,
\]
but no graph plan attains that value.

## What this would and would not establish

If the finite-shell/angular/derivative certificates are proved for the candidate, the direct conclusion is a smooth compactly supported **radial** density in the plane for which the three-marginal Coulomb problem has no optimal Monge map, despite equality of the Monge and Kantorovich infima. This would go beyond ruling out a prescribed finite family of Seidl-type maps.

It would not give a connected-support example, a density positive throughout a convex domain, a result for every radial density, or a dimension-three result. The latter cannot use this finite-branch argument unchanged because fixing a source vector in three dimensions leaves a continuous stabilizer of orientations.

### Conditional Yukawa extension

There is a sound conditional extension to every screening parameter $\kappa>0$, provided the exact Coulomb shell solution is known to continue under the Yukawa perturbation. Let
\[
\varphi_\kappa(\rho)=e^{-\kappa\rho}/\rho.
\]
It suffices to have a certified local radius-vector branch $\mathbf r(\kappa)$ through the Coulomb radii, for $\kappa$ near zero, that preserves the exact common-source-force equality
\[
\Delta(\mathbf r,\kappa):=c_{\kappa,a}(P_{\mathbf r})-c_{\kappa,a}(Q_{\mathbf r})=0.
\]
For the single scalar condition, a nonzero derivative with respect to at least one radius variable gives this branch by the implicit-function theorem; a verified nonsingular finite-dimensional equal-force/stationarity system is also sufficient if its solution branch enforces this equality. The contact potential values (p_i(\kappa)) can be adjusted continuously to keep the two contact equalities exact. All other finite-shell inequalities remain strict by continuity. The isolated angular minima and positive Hessians, radial-response determinants/numerators, and strict finite-shell gaps are open conditions, so they persist for small \(\kappa\) once the exact force equality is maintained. Collision singularities do not obstruct this continuation: on the bounded radius range, for \(0\le\kappa\le\kappa_1\),
\[
\varphi_\kappa(\rho)\ge e^{-\kappa_1D}/\rho\longrightarrow+\infty\quad(\rho\downarrow0),
\]
where (D) bounds all relevant pair distances. Thus minimizers cannot escape toward collisions, and the strict angular gaps persist. The conditional planar construction then gives a smooth radial non-Monge example for every sufficiently small positive \(\kappa\).

One such $\kappa_0>0$ would imply the same conclusion for any prescribed $\kappa>0$ by spatial scaling. With dilation factor $\lambda=\kappa_0/\kappa$,
\[
\varphi_\kappa(\lambda s)=\lambda^{-1}\varphi_{\kappa\lambda}(s)
=\lambda^{-1}\varphi_{\kappa_0}(s).
\]
Scaling every coordinate by $\lambda$ multiplies the full cost by the positive constant $\lambda^{-1}$, preserving optimality and preserving whether an optimizer is a graph. The scaled marginal remains smooth, compactly supported, and radial. Hence, conditional on a valid base certificate and the stated IFT continuation, one example at small positive screening yields examples for all Yukawa screening parameters. This is a conditional corollary, not an additional certified result for the current numerical candidate.

## Requirements to instantiate the conditional theorem

- Verify exact common source-force equality at $P,Q$.
- Certify the global angular minimizer orbit and positive angular Hessians.
- Certify all 35 finite shell inequalities, with strict gaps at the 33 noncontact multisets.
- Certify reduced angular-Schur-complement derivatives and exact response numerators $N_a,N_d\ne0$ at a common finite $K$.

No mathematical flaw was found in the conditional envelope/mass-obstruction argument. Whether particular numerical data satisfy the hypotheses is a separate certification question.
