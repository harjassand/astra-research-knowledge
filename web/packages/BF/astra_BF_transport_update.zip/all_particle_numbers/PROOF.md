# Proof-outward lead: polygonal branch splitting for every particle number

Status: internally reconstructed candidate extension. No external expert review, formalization, or independent second-agent audit yet. Do not treat as certified or as a priority/novelty determination.

## Source and exact mechanism

- OpenAI/math, pinned commit fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb.
- Source manuscript: preprints/A-counterexample-to-the-Monge-ansatz-for-the-three-marginal-Coulomb-cost-September-25-2026/paper.pdf; GitHub blob SHA f2bf6349fc5ee9db3a1c4479996531b793c168eb.
- Relevant source locations: Theorem 1.1 and mechanism overview pp. 1–3; exact selection obstruction Lemma 2.1, p. 3; local stabilized-Hessian branch Lemma 3.1, pp. 4–5; full supporting inequality/marginal/no-map proof, §§4–5, pp. 6–8; inverse-power extension Theorem 7.1, pp. 11–13.
- Lean status at the same pin: lean/docs/373.md scopes the formalization to the three-dimensional three-marginal Coulomb theorem, including equality of infima; it explicitly excludes the paper's inverse-power extensions. The theorem is routed through lean/OAI/Analysis/CoulombTransport/Main.lean → Conclusion.lean → ActualGeometryConclusion.lean. A dependency walk over the 73 imported CoulombTransport Lean files found no literal `sorry` or `admit` tokens in that proof dependency closure. I did not run Lean compilation or the Comparator harness here, so this is a pinned-source inspection, not an executed verification receipt. No formalization covers the proposed N>3 polygon theorem.
- The source's exact mass obstruction is: on a central component B, μ|B = ν/3, while each of four forced branch images has μ(H(S)) = ν(S)/6. A deterministic μ-preserving map T forced to select H(x) on a Borel set S would have μ(T⁻¹(H(S))) ≥ ν(S)/3 > ν(S)/6 = μ(H(S)).
- The source constructs two local equality branches by adding strongly concave quadratic pieces to the dual potentials, equivalently +K I to the minimized-variable Hessian. This simultaneously makes the stationary branch unique and makes every desired coordinate of that branch a local diffeomorphism of the free anchor variable.

## Proposed theorem

Let N ≥ 3, d ≥ 2, m = N−1. Let φ:(0,∞)→(0,∞) be C∞, with
$$
\lim_{r\downarrow0}\phi(r)=+\infty,\qquad \phi'(r)<0,\qquad \phi''(r)>0\quad(r>0).
$$
Define
$$
c_N(x_1,\ldots,x_N)=\sum_{1\le i<j\le N}\phi(|x_i-x_j|),
$$
with value +∞ at a collision. Then there is a smooth compactly supported probability density ρ on ℝᵈ, with √ρ ∈ C_c∞, such that, for μ=ρ dx:

1. The equal-marginal Kantorovich problem for c_N has a finite attained minimum.
2. Every optimal plan fails to be a graph over any one of its N coordinates.
3. The infimum over (N−1) μ-preserving Borel maps equals the Kantorovich minimum, and finite-cost graph plans approach the value.

The density depends on N,d,φ and the chosen radius. Its construction uses 2N−1 disjoint smooth component patches; it does not give connected support or a density strictly positive throughout a connected domain. This is a counterexample to a universal “an optimal Monge plan always exists” assertion; it says nothing about arbitrary prescribed μ, genericity, uniqueness, or minimizers for standard physical densities.

The assumptions include φ_s(r)=r^(−s) for every s>0, and screened Coulomb/Yukawa φ_κ(r)=e^(−κr)/r for every κ>0. For Yukawa,
$$
\phi_\kappa'(r)=-e^{-\kappa r}(\kappa/r+1/r^2)<0,\quad
\phi_\kappa''(r)=e^{-\kappa r}(\kappa^2/r+2\kappa/r^2+2/r^3)>0.
$$

## Reconstruction

### 1. A finite center code: two rotated regular polygons

Embed a plane in ℝᵈ. Choose R>0, and let A={a_{0,j}} for j=0,…,m−1 be the regular m-gon of radius R, with angles 2πj/m. Let B={a_{1,j}} be the same polygon rotated through π/m. Their union is the regular 2m-gon. Each branch configuration is the origin plus all vertices from one of the two polygons. The polygon centroid identity Σⱼ a_{k,j}=0 gives
$$
c_N(0,a_{k,0},\ldots,a_{k,m-1})
=C_*:=m\phi(R)+\sum_{j<\ell}\phi(|a_{k,j}-a_{k,\ell}|),
$$
with the same value for both k, and ∇ₓ c_N(0,a_{k,0},\ldots)=0.

The crucial center-level strictness is a self-contained Jensen argument. For angular separation t∈(0,2π), set F(t)=φ(2R sin(t/2)). With r(t)=2R sin(t/2), r''=−r/4, so
$$
F''(t)=\phi''(r)(r')^2-\phi'(r)r/4>0.
$$
For any m distinct points on the circle, order them cyclically and let their gaps be g₁,…,gₘ>0, Σᵢ gᵢ=2π. For q=1,…,m−1, set sᵢ,q=gᵢ+⋯+gᵢ₊q₋₁ cyclically. Then Σᵢsᵢ,q=2πq. Since F is strictly convex,
$$
\sum_i F(s_{i,q})\ge mF(2\pi q/m).
$$
The pair-energy equals ½Σ_qΣ_iF(sᵢ,q), so it is minimized uniquely by the regular m-gon. Among m-subsets of the 2m-gon A∪B, only the two parity classes A,B are regular m-gons. Every mixed selection has strictly higher outer pair-energy. Since each selected outer center has distance R from the origin, its central interactions are all mφ(R); thus the only distinct-center equality patterns with the origin are the two prescribed branches.

All distinct-center patterns without the origin have positive cost, whereas the outer center potentials below are zero. If any two variables lie in the same sufficiently small component ball, their mutual cost tends to +∞ uniformly as the radius shrinks, and dominates the bounded sum of dual potentials. There are finitely many center patterns, so all noncontact inequalities persist after shrinking the component balls.

### 2. Lift the center code to exact local equality manifolds

Fix branch k, choose one polygon vertex aₖ,₀ as anchor y, and minimize over the remaining m variables
$$
w=(x,z_1,\ldots,z_{m-1})\in(\mathbb R^d)^m,
$$
where x is the central point and zⱼ are the other polygon vertices. Let bₖ,ⱼ be the gradient of c_N in zⱼ at the center configuration. Use local potentials
$$
u_0(x)=C_*-\frac K2|x|^2,\qquad
v_{k,j}(z)=b_{k,j}\cdot(z-a_{k,j})-\frac K2|z-a_{k,j}|^2.
$$
For Fₖ=c_N−u₀−Σⱼvₖ,ⱼ, the w-gradient vanishes at the center configuration. Its Hessian there is Mₖ+K Iₘd, positive definite for large K.

Let h(v)=φ(|v|). At any nonzero v, the eigenvalues of D²h(v) are φ″(|v|) radially and φ′(|v|)/|v| tangentially, so every such Hessian is invertible. The mixed derivative Dᵧ∇w c_N is a stack of m invertible d×d blocks: the central-variable block is −D²h(aₖ,₀), and the block for zⱼ is −D²h(aₖ,ⱼ−aₖ,₀). As K→∞,
$$
K(M_k+K I_{md})^{-1}D_y\nabla_w c_N\longrightarrow D_y\nabla_w c_N.
$$
Hence for all sufficiently large K, every d×d component block of the stationary-branch derivative is invertible. The implicit function theorem and inverse function theorem give smooth local diffeomorphisms Xₖ(y) for the central point and Zₖ,ⱼ(y) for every other polygon vertex. Positive definiteness on small product balls makes the stationary point the unique minimizer for each fixed y. Its minimum value supplies the anchor potential vₖ,₀(y), giving an exact local supporting inequality with equality precisely on that branch.

Both branches have the same central potential u₀. At each outer center the corresponding vₖ,ⱼ (including the anchor minimum potential) vanishes. Combining these local inequalities, the strict center-level gaps above, and the collision barrier produces one bounded potential u on the disjoint union of the 2N−1 component balls such that
$$
c_N(x_1,\ldots,x_N)\ge \sum_{i=1}^N u(x_i)
$$
on the whole support product, with equality exactly on permutations of the two local branch families.

Reparameterize each branch by central point x: invert Xₖ, and compose its inverse with each Zₖ,ⱼ. This yields 2m smooth diffeomorphisms Hₖ,ⱼ:B→ℝᵈ, k∈{0,1}, j=0,…,m−1, whose open images lie in the distinct outer component balls and such that
$$
(x,H_{k,0}(x),\ldots,H_{k,m-1}(x))
$$
is an equality tuple for every x∈B.

### 3. Smooth marginal, optimal coupling, and exact mass obstruction

Choose g∈C_c∞(B), g≥0, ∫g²=1, and write ν=g²dx. Set
$$
\mu=\frac1N\nu+\frac1{2N}\sum_{k=0}^1\sum_{j=0}^{m-1}(H_{k,j})_\#\nu.
$$
The coefficients sum to one because 1/N+2m/(2N)=1. Each image measure has smooth density gₖ,ⱼ², where
$$
g_{k,j}(y)=g(H_{k,j}^{-1}y)\,|\det DH_{k,j}^{-1}(y)|^{1/2}.
$$
The image of supp g is compactly inside Hₖ,ⱼ(B), and all component supports are disjoint. Thus ρ and √ρ are both smooth and compactly supported.

Sample x∼ν, choose one of the two branches uniformly, and uniformly permute the resulting N-tuple. Its law π₀ has all marginals μ and lies on the equality set, so it saturates the supporting inequality. Any other coupling also lies in the support product and satisfies the inequality. Therefore π₀ is a finite optimal coupling. Every optimal coupling must be concentrated on the equality set.

Now let a candidate optimal graph use any coordinate as its source, and restrict to the event that this source coordinate is in B. Equality forces any one of its other coordinates to take one of the 2m values Hₖ,ⱼ(x). For any Borel selection set S⊂B,
$$
\mu(S)=\nu(S)/N,\qquad
\mu(H_{k,j}(S))=\nu(S)/(2N).
$$
If a μ-preserving map T selected Hₖ,ⱼ(x) on S, then
$$
\nu(S)/N=\mu(S)\le\mu(T^{-1}(H_{k,j}(S)))
=\mu(H_{k,j}(S))=\nu(S)/(2N),
$$
forcing ν(S)=0. The finitely many selection sets cannot cover B up to full ν-measure. This rules out a graph over any coordinate for every optimal coupling, not merely for the exhibited π₀.

### 4. Equality of infima without attainment

The source's cell-reallocation proof (§6) generalizes unchanged. The finitely many compact component supports have a positive minimum separation η. Partition each into cells of diameter at most δ, and let qᵢ₁…ᵢN be the masses of π₀ on cell products. Split each source cell into pieces of these exact masses, then use Borel maps between absolutely continuous probabilities (e.g. the source's explicit Rosenblatt/conditional-quantile construction) to realize the prescribed target-cell laws for each of the other N−1 coordinates. The resulting graph coupling has exactly the same cell-product masses as π₀, and only uses products of distinct component supports. On these products the cost is Lipschitz; if L=sup|φ′| over their compact distance range, the cost oscillation in a cell product is at most N(N−1)Lδ. Thus finite-cost graph plans approach ∫c_N dπ₀, while no graph plan attains it.

## Why this matters / prior-art boundary

The original OpenAI release's Theorem 7.1 handles three marginals for every d≥2 and every Riesz exponent s>0; the proposed polygon construction changes the source's antipodal two-point branches into two parity classes of an m-gon and applies for arbitrary N. It also adds non-homogeneous kernels such as screened Yukawa. The mathematical consequence is that for every particle number N≥3, in every spatial dimension d≥2, there are smooth identical marginals where the pairwise repulsive Riesz/Yukawa problem has no deterministic Monge optimizer.

Relevant primary prior art checked:

- Friesecke, arXiv:2601.02616v1, https://arxiv.org/abs/2601.02616. Its §3.2 (HTML lines 231–248) reports the earlier Coulomb mass-splitting example at N=3,d=3, says the all-N Coulomb Monge-existence question remained open outside d=1, and summarizes other three-marginal examples. Its §4 separately proves all-N mass splitting for a fully discrete/time-discrete generalized-Euler cost, not the pairwise Coulomb/Riesz cost here.
- Gerolin–Kausamo–Rajala, “Nonexistence of Optimal Transport Maps for the Multimarginal Repulsive Harmonic Cost,” https://doi.org/10.1137/18M1186514, concerns three marginals; it is a different smooth harmonic cost.
- Targeted Astra current-priority and topic-index scans found no direct named Coulomb/Riesz Monge record. This is not a full Astra corpus audit.

The novelty judgment remains UNKNOWN. The Jensen polygon bound and higher-dimensional branch IFT are internally derived here; the earlier source has neither the N>3 construction nor the polygon code, but related all-N mass-splitting phenomena for other costs are known. External literature review and specialist verification are decisive before promotion.

## Decisive audit points / next falsification tests

1. Independently rederive the local md-variable IFT and verify each output block is invertible after one common K. This is the highest-risk technical step.
2. Check that the noncontact finite center patterns exhaust all N-tuples: with the origin present, distinct outer vertices form an m-subset of the 2m-gon; without it, the dual-potential sum is zero; repeated component indices are ruled out by the singularity.
3. Reprove the cyclic-gap Jensen formula and its strict equality characterization, especially pair counting for q and m−q.
4. Independently test the theorem's predicted boundary against a counterexample search for kernels with φ′≤0 but degenerate φ″, bounded-at-zero kernels, and d=1. These are outside the stated theorem; failure of this proof interface is not itself a counterexample.
5. Check whether a 2026 source beyond the searched arXiv literature already contains an all-N, d≥2, singular pairwise Riesz/Yukawa no-Monge example.

No public repository was changed. This report is an internal proof candidate, not a verified theorem.

