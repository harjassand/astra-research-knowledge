# Independent audit: all-N polygonal Monge obstruction

Date: 2026-10-09 (UTC)

## Scope and verdict

I independently reconstructed the construction from the stated data and then checked the proof candidate at `/workspace/shared/astra_luna_campaign/proof_outward/openai373_all_n_polygon.md`. This is a proof audit, not a literature/novelty review. I found **no fatal mathematical gap in the proposed argument**. The core geometry, local IFT, common dual-potential construction, exact marginal bookkeeping, mass-selection contradiction, and equality-of-infima argument all appear internally consistent under the stated assumptions on `φ`.

The theorem is not “every prescribed marginal fails Monge”; it is an existence counterexample for each `N,d,φ`. The principal presentation weakness is that the global support-product case split and simultaneous shrinking of the local balls should be written explicitly rather than compressed into “combine”/“persist.” The finite-pattern argument below supplies that missing detail. The IFT and measure-isomorphism steps should also be fully spelled out in any final proof.

## Blind reconstruction and checks

Write `m=N−1`, `h(v)=φ(|v|)`. Take the origin and the `2m` vertices of a regular `2m`-gon of radius `R` in a plane in `R^d`. The vertices split into two alternating regular `m`-gons `A_0,A_1`, with `A_1` rotated by `π/m`. Each target equality pattern is the origin plus every vertex of one `A_k`.

### Strict center-code inequality

For `F(t)=φ(2R sin(t/2))`, `r(t)=2R sin(t/2)` gives `r''=-r/4`, and hence

`F''(t)=φ''(r)(r')² − φ'(r)r/4 > 0` on `(0,2π)`.

If `m` distinct points on the circle have cyclic gaps `g_i>0`, `Σg_i=2π`, their `q`-step cyclic arcs `s_{i,q}=g_i+…+g_{i+q−1}` satisfy `Σ_i s_{i,q}=2πq`. Strict Jensen, summed over `q=1,…,m−1`, bounds the pair energy below by that of the regular `m`-gon. The pair-count identity is `E=(1/2)Σ_qΣ_i F(s_{i,q})`; each unordered pair appears twice and `F(t)=F(2π−t)`. Equality at `q=1` forces all gaps equal. Thus the regular polygon is the unique minimizer among `m` distinct points on the radius-`R` circle. Among the `m`-subsets of the `2m`-gon, only the two parity classes are regular, so every mixed subset has a strict positive energy gap.

At the reference tuple, central interactions contribute the same `mφ(R)` on either branch; the centroid identity gives `∇_x c_N=0` at the origin. Denote the full reference energy by `C_*`.

### Local branch families and all coordinate Jacobians

Fix one outer vertex as anchor `y`; minimize in the remaining `m` variables `w=(x,z_1,…,z_{m−1})`. Set

`u_0(x)=C_*−K|x|²/2`, and, for each non-anchor outer variable, `v_j(z)=b_j·(z−a_j)−K|z−a_j|²/2`, where `b_j=∇_{z_j}c_N` at the reference tuple. At that tuple, `F=c_N−u_0−Σv_j` has zero `w`-gradient and `w`-Hessian `M+K I`. For sufficiently large common `K`, this is positive definite for both branches.

The mixed derivative `D_y∇_w c_N` is an `md×d` column of `m` blocks, one for each variable in `w`. Each block is `−D²h(q−a_anchor)` for a nonzero separation `q−a_anchor`. The radial eigenvalue of `D²h(v)` is `φ''(|v|)>0`; every tangential eigenvalue is `φ'(|v|)/|v|<0`. Hence every block is invertible, including in `d>2`. Since

`K(M+KI)^{-1}D_y∇_w c_N → D_y∇_w c_N`,

all `m` component blocks of `Dw/Dy=−(M+KI)^{-1}D_y∇_w c_N` are invertible for one sufficiently large `K`. There are only finitely many blocks across both branches. The IFT gives the minimizing variables as smooth functions of `y`; the inverse-function theorem applies separately to the central block `X_k(y)` and every outer block `Z_{k,j}(y)`. On a smaller common neighborhood, all are diffeomorphisms. Reparameterizing by central position gives the `2m` diffeomorphisms `H_{k,j}=Z_{k,j}∘X_k^{-1}` (with the anchor block included), each with a disjoint outer image.

The minimized value `v_{k,0}(y)=F(y,w_k(y))` is the anchor potential. Strict local convexity in `w` gives the exact inequality `c_N≥u_0+Σ_jv_{k,j}` on the corresponding product of sufficiently small balls, with equality exactly on the branch family. At every reference outer center, the relevant potential is zero, including the anchor potential; at the origin `u_0(0)=C_*`. Both branches use the same `u_0` and one common `K`.

### Explicit global dual case split

Let the `2m+1` component balls be disjoint and so small that each branch product lies in its local convexity neighborhood. Define the bounded potential `u` by the branch potentials on each component ball. The following exhaust every `N`-tuple in their product:

1. **At least two coordinates in one component ball.** Their mutual distance is at most `2ε`, so their pair cost is at least `φ(2ε)→∞` as `ε↓0`. All other pair costs are positive. The potential sum is uniformly bounded; choose the common radius small enough for strict domination.
2. **No central component and no repeated component.** At the component centers every `u` is zero while the cost is a finite sum of positive terms. There are finitely many such label patterns, so each has a strictly positive gap that persists on sufficiently small balls.
3. **Exactly one central component, with repeated outer component.** This is case 1.
4. **Exactly one central component and `m` distinct outer components.** If the labels are a parity `m`-gon, the local branch inequality applies and equality is precisely the branch family. If they are a mixed subset, the central interactions equal `mφ(R)` and the outer-energy Jensen gap is strict; the center potential sum is `C_*`. There are finitely many mixed patterns, so these gaps persist after shrinking.

These cases also cover tuples with two or more central entries (case 1). Thus, after a common shrink, `c_N≥Σ_i u(x_i)` on the whole support product; its equality set is exactly the two local branch families and their coordinate permutations. This makes the finite-pattern global step rigorous and excludes unaccounted no-center/mixed/repeated-cluster configurations.

### Smooth marginal and exact optimal coupling

Choose `g∈C_c∞(B)`, `g≥0`, `∫g²=1`, with support compactly inside the common central parameter domain; let `ν=g²dx`. Define

`μ=(1/N)ν+(1/(2N)) Σ_{k=0}^1 Σ_{j=0}^{m−1}(H_{k,j})#ν`.

The mass is `(1+m)/N=1`. All component supports are compactly contained in disjoint balls. Each pushforward has density obtained by the smooth change-of-variables formula, and its square root is `g(H^{-1}y)|det DH^{-1}(y)|^{1/2}`. Because supports are disjoint, the square root of the sum density is the sum of the individual smooth square roots with the corresponding coefficient square roots; the global density and its square root are compactly supported and smooth.

Sample `x∼ν`, choose branch `k` with probability `1/2`, form `(x,H_{k,0}(x),…,H_{k,m−1}(x))`, and uniformly permute the `N` coordinates. Each marginal is exactly `μ`: central term `ν/N`, plus each outer image `H_{k,j}#ν/(2N)`. All pair distances stay positive on compact disjoint component supports, so this plan has finite cost. The global dual inequality is saturated on it. Every feasible plan has cost at least `N∫u dμ`; hence the Kantorovich minimum is finite and attained. Any optimal plan must be concentrated on the dual equality set.

### No optimal graph over any coordinate

For any source coordinate of a putative optimal graph, restrict to its central component. The source event has measure `ν(S)/N` for a Borel subset `S` of central positions. Fix any one of the other output maps `T`. On this event, equality forces `T(x)=H_{k,j}(x)` for one of the finitely many `2m` branch maps. The selection sets cover the central support. On each positive-mass selection set `S`, disjointness and injectivity give

`μ(H_{k,j}(S))=ν(S)/(2N)`,

whereas `T#μ=μ` and `T(S)=H_{k,j}(S)` imply `μ(H_{k,j}(S))≥μ(S)=ν(S)/N`, a contradiction. Images of Borel sets are Borel because each `H_{k,j}` is a diffeomorphism on the parameter domain. Each selection set therefore has zero `ν`-measure, contradicting their finite cover. This argument is independent of which coordinate is the source, and rules out every optimal plan that is a graph over any coordinate. It also explains why diffuse central mass does not permit deterministic branch selection: each selected branch copy has exactly half the source density.

### Equality of Kantorovich and Monge infima

The standard finite-cell approximation appears sound and can be made precise using atomless standard Borel measure isomorphisms. Partition the finitely many component supports into cells of diameter at most `δ`; let `q_{i_1,…,i_N}` be the masses of the optimal coupling on cell products. Split each source cell into pieces of these masses. For each target coordinate separately, partition each target cell into pieces with the corresponding same masses and map each source piece measure-preservingly to its assigned target piece. Absolute continuity makes all positive-mass restricted pieces atomless; hence the required Borel maps exist. The resulting graph plan has exactly the same cell-product masses. Every cell-product with positive `q` comes from one central and `m` distinct outer component labels, so no collision cost arises. Those products remain uniformly separated; `φ` is Lipschitz on the resulting compact distance interval. Moving each coordinate by at most `δ` changes the total cost by at most `N(N−1)Lδ`, where `L` bounds `|φ'|` on that interval. Thus graph costs converge to the Kantorovich optimum. Combined with the obstruction, the Monge infimum is equal but unattained.

## Caveats / proof-polishing requirements

- State the extension as “for every `N≥3`, `d≥2`, and every fixed kernel satisfying the hypotheses, there exists a constructed `μ`”; do not say “arbitrary marginal.”
- Make explicit that `K` is chosen once for the finitely many branches, then choose product balls/central parameter domain/support of `g` small enough to satisfy all local, separation, and gap conditions simultaneously.
- Define the local minimization on a convex product neighborhood where the `w`-Hessian remains positive definite and the IFT minimizer stays interior; this validates the exact branch inequality on the full local product, not just at stationary points.
- In the graph approximation, cite/prove the atomless standard Borel measure-isomorphism lemma rather than claiming an arbitrary joint cell table automatically comes from maps.
- This audit is not an external specialist review or novelty search. The original pinned source manuscript was not separately downloaded/read here; the structural comparison is to the supplied proof candidate. No counterexample was found.
