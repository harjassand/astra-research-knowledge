# Luna quantum entropy / no-broadcasting attack

Date: 2026-10-09

Status: no proof or counterexample to the unrestricted capacity-free Holevo inequality or to capacity-free approximate no-broadcasting. The two speculative routes below are separated carefully from the proved statements. This note records one dimension-free Gram-matrix identity from a family-wise pure-state broadcaster and a precise failure of a tempting fidelity bridge.

## 1. The exact target and scope

For a finite cq ensemble \(\omega_{XBE}=\sum_x p_x|x\rangle\langle x|\otimes\rho_x^{BE}\), the target under investigation is

\[
  I(B:E)_\omega-I(B:E|X)_\omega
  =\chi(X:B)+\chi(X:E)-\chi(X:BE)
  \le I_{\rm acc}(X:BE).
\]

The equality is an entropy identity. It does not turn the left side into a classical mutual information. A mean-eigenbasis measurement is not a proof: for equiprobable product states \(|u\rangle|u\rangle\), \(|v\rangle|v\rangle\), with \(|\langle u|v\rangle|=c\in(0,1)\), the mean output has symmetric/antisymmetric eigenvectors, and the two conditional states have identical outcome probabilities in that basis. Thus that particular measurement gives zero information even though

\[
\chi_B+\chi_E=2h_2((1+c)/2)
  > h_2((1+c^2)/2)=\chi_{BE}.
\]

For example, \(c=1/2\) gives \(1.622\ldots>0.954\ldots\). This invalidates only the proposed mean-eigenbasis witness, not the target inequality; a different joint measurement can carry information.

## 2. A dimension-free weighted-Gram identity for pure-state broadcasters

This is the main concrete new mechanism from this pass.

Let \(\{p_i,|\psi_i\rangle\}_{i=1}^n\) be any finite pure-state ensemble on \(A\). Let \(\mathcal B:A\to A_1A_2\) be a CPTP map such that

\[
T\!\left(\mathcal B_a(|\psi_i\rangle\langle\psi_i|),
       |\psi_i\rangle\langle\psi_i|\right)\le b
\quad (a=1,2;\ i=1,\dots,n),
\]
where \(T=\|\cdot\|_1/2\).

Take a Stinespring isometry \(V:A\to A_1A_2R\) and set \(|\Omega_i\rangle=V|\psi_i\rangle\). For \(P_i=|\psi_i\rangle\langle\psi_i|\), trace-distance/fidelity duality gives

\[
\langle\Omega_i|P_i^{A_1}\otimes I|\Omega_i\rangle\ge1-b,
\qquad
\langle\Omega_i|I\otimes P_i^{A_2}|\Omega_i\rangle\ge1-b.
\]

Since \(I-P_i\otimes P_i\le(I-P_i)\otimes I+I\otimes(I-P_i)\),

\[
q_i:=\langle\Omega_i|P_i^{A_1}\otimes P_i^{A_2}\otimes I_R|\Omega_i\rangle\ge1-2b.
\]

For \(b<1/2\), project \(|\Omega_i\rangle\) onto \(|\psi_i\rangle^{\otimes2}\otimes R\), normalize the resulting environment vector to \(|e_i\rangle\), and fix its phase so the overlap is nonnegative. Then

\[
\big\|\,|\Omega_i\rangle-|\psi_i\rangle^{\otimes2}|e_i\rangle\,\big\|_2^2
=2(1-\sqrt{q_i})\le4b.
\]

Define linear maps from \(\mathbb C^n\):

\[
W|i\rangle=\sqrt{p_i}\,V|\psi_i\rangle,
\qquad
S|i\rangle=\sqrt{p_i}\,|\psi_i\rangle^{\otimes2}|e_i\rangle.
\]

Then \(\|W-S\|_2\le2\sqrt b\), while \(\|W\|_2=\|S\|_2=1\). Their Gram density matrices obey

\[
G=W^\dagger W,\qquad K=S^\dagger S,
\]

with entries

\[
G_{ij}=\sqrt{p_ip_j}\langle\psi_i|\psi_j\rangle,
\qquad
K_{ij}=\sqrt{p_ip_j}\langle\psi_i|\psi_j\rangle^2\langle e_i|e_j\rangle.
\]

Schatten Hölder gives the cardinality- and dimension-free estimate

\[
\boxed{\ \|G-K\|_1
=\|W^\dagger W-S^\dagger S\|_1
\le(\|W\|_2+\|S\|_2)\|W-S\|_2
\le4\sqrt b.\ }
\]

Unlike a pairwise overlap bound, this is a trace-norm statement about the entire prior-weighted Gram matrix. It detects overcomplete frames: many individually small overlap errors may still produce a constant trace-norm gap. The exact fixed-point equation \(G=K\) forces every nonzero overlap to have modulus one (because \(|\langle e_i|e_j\rangle|\le1\)); hence the pure states fall into identical-state/orthogonal-class blocks. This is the exact no-cloning geometry in Gram form.

### Missing stability step

A useful sufficient lemma would be:

> For every \(\varepsilon\), there exists \(f(\varepsilon)\to0\), independent of dimension, finite cardinality, and prior, such that whenever \(G_{ij}=\sqrt{p_ip_j}\langle\psi_i|\psi_j\rangle\) and \(K_{ij}=G_{ij}\langle\psi_i|\psi_j\rangle\langle e_i|e_j\rangle\) with \((\langle e_i|e_j\rangle)\) a correlation matrix and \(\|G-K\|_1\le\varepsilon\), there exists one EB channel \(\Lambda\) with \(\sum_i p_iT(\Lambda(P_i),P_i)\le f(\varepsilon)\).

If true, the broadcaster identity yields a prior-average EB reconstruction for every finite prior. For a finite family, minimax applies because trace-distance loss is convex in \(\Lambda\) and linear in the prior; it upgrades prior-average reconstruction to one channel with uniform error. For an infinite family in a fixed finite-dimensional space, compactness of the EB channel set plus the finite-intersection property extends the result. This would settle the pure-state capacity-free case with a dimension-free modulus. I have not proved the stability lemma. The hard issue is the global trace-norm stability of approximate fixed points of the Schur map \(G\mapsto G\circ C\circ H\); entrywise or Hilbert–Schmidt estimates alone do not control overcomplete frames.

## 3. A tempting fidelity tradeoff is false

One possible shortcut was to bound a cloner's fidelity by an EB estimator's accessible fidelity, or to assert \(F_1+F_2\le1+F_{\rm acc}\). Both fail already for a balanced binary pure-state ensemble.

Let \(|\psi_0\rangle,|\psi_1\rangle\) have overlap \(c\in(0,1)\), and let \(|t_i\rangle=|\psi_i\rangle^{\otimes2}\), so \(\langle t_0|t_1\rangle=c^2\). Define

\[
|e_\pm\rangle=\frac{|t_0\rangle\pm|t_1\rangle}{\sqrt{2(1\pm c^2)}},
\qquad
\delta=\tfrac12\arccos c,
\]
\[
|\Phi_0\rangle=\cos\delta|e_+\rangle+\sin\delta|e_-\rangle,
\qquad
|\Phi_1\rangle=\cos\delta|e_+\rangle-\sin\delta|e_-\rangle.
\]
Their overlap is \(\langle\Phi_0|\Phi_1\rangle=c\), exactly matching the input pair. Therefore the map on the two-dimensional input span taking \(|\psi_i\rangle\mapsto|\Phi_i\rangle\) is an isometry and extends to a valid channel. It is symmetric under swapping the two outputs.

The global clone fidelity and each marginal fidelity are

\[
F_{\rm glob}=|\langle t_i|\Phi_i\rangle|^2
=\frac{1+c^3+\sqrt{(1-c^2)(1-c^4)}}2,
\]
\[
F_{\rm loc}=\langle\Phi_i|P_i\otimes I|\Phi_i\rangle
=\frac{1+2c^2+c^3+(1-c^2)\sqrt{1+c^2}}{2(1+c^2)}.
\]

For equal prior, the exact accessible single-copy fidelity is

\[
F_{\rm acc}=\frac{1+\sqrt{1-c^2+c^4}}2.
\]
This binary accessible-fidelity expression follows from the optimal-POVM calculation in Fuchs–Sasaki, *Squeezing Quantum Information through a Classical Channel*, arXiv:quant-ph/0302092, Sec. 4.1, Eq. (73) (their \(x\) is the state overlap).

At \(c=0.8\),

\[
F_{\rm glob}=0.98651247\ldots,\qquad
F_{\rm loc}=0.99177590\ldots,\qquad
F_{\rm acc}=0.93863424\ldots.
\]
Thus \(F_{\rm glob}>F_{\rm acc}\), and \(2F_{\rm loc}-1>F_{\rm acc}\). The fidelity bridge is not a substitute for the entropy inequality. This example has finite error and is not a counterexample sequence with \(b\to0\).

## 4. Spectral-overlap shortcut is rigorously false

A natural attempted bridge was

> For the pure ensemble (E={p_i,|psi_i\rangle}), let (G) be its weighted Gram matrix and (K=G\circ C\) the doubled-state Gram matrix, with (C_{ij}=\langle\psi_i|\psi_j\rangle). Then perhaps (F_{\rm acc}(E)\ge\sum_j\min(\lambda_j(G),\lambda_j(K))).

This fails even for three pure qubit states. Take the equatorial trine

\[
|\psi_k\rangle=(|0\rangle+e^{2\pi i k/3}|1\rangle)/\sqrt2,
\qquad(p_0,p_1,p_2)=(1/20,1/10,17/20).
\]

Writing the Bloch vectors as (n_k), their first and second moments are

\[
r=\sum_kp_kn_k=(-17/40,-3\sqrt3/8,0),\qquad
T=\sum_kp_kn_kn_k^T=\begin{pmatrix}23/80&3\sqrt3/16&0\\3\sqrt3/16&57/80&0\\0&0&0\end{pmatrix}.
\]

The one-copy Gram spectrum is the spectrum of \(\rho_1=\sum p_k|\psi_k\rangle\langle\psi_k|\), namely
\[
a_\pm=(1\pm\sqrt{241}/20)/2,\quad 0;
\]
numerically (a_+\approx0.888104), (a_-\approx0.111896). The doubled-state Gram is diagonally gauge-equivalent to
\[
K=\frac34\operatorname{diag}(p)+\frac14xx^T,\qquad x=(\sqrt{p_0},\sqrt{p_1},\sqrt{p_2})^T,
\]
with characteristic polynomial (t^3-t^2+(159/1280)t-459/128000). Its eigenvalues lie respectively in ((.860,.861),(.096,.097),(.043,.044)). Therefore the spectral overlap is
\[
\sum_j\min(\lambda_j(G),\lambda_j(K))=\mu_1+\mu_2=1-\mu_3>.956.
\]

An exact dual certificate proves (F_{\rm acc}\le.95). A rank-one qubit POVM can be written (M_a=w_a(I+v_a\cdot\sigma)/2), with (q_a=w_a/2), \,\(\sum_aq_a=1\), and \,\(\sum_aq_av_a=0\). Optimizing the prepared pure state for each outcome gives
\[
F=\frac12+\frac12\sum_aq_a\,\|r+Tv_a\|.
\]
Set (A=9/10) and (b=Tr/A=(-533/1440,-37\sqrt3/96,0)). For unit (u=(v_x,v_y)), (Ab=T_{xy}r_{xy}) cancels the linear term and
\[
(A+b\cdot u)^2-\|r_{xy}+T_{xy}u\|^2=u^TMu,
\]
where
\[
M=\begin{pmatrix}324265/2073600&-6199\sqrt3/138240\\-6199\sqrt3/138240&3073/76800\end{pmatrix},
\quad \det M=37267/165888000>0.
\]
The leading diagonal entry is positive, so (M\succ0). Also (\|b\|^2=302041/518400<A^2), so (A+b\cdot u>0) on the circle. Hence (\|r+T u\|\le A+b\cdot u) there, and by convexity on the entire unit disk. Averaging over the POVM removes (b\cdot v_a), yielding (F_{\rm acc}\le(1+A)/2=.95). Thus the proposed spectral lower bound is strictly false.

This counterexample only kills the spectrum-only shortcut. It has (\|G-K\|_1\approx.3565), not a vanishing residual, and does not refute the dimension-free Gram stability lemma. For a general environment Gram (H), the physical matrix is (K=G\circ C\circ H); this remains a unital Schur-channel output and hence is spectrally majorized by (G), but majorization alone gives no accessible-fidelity lower bound. The actual stability question remains open here.

## 5. What this pass does and does not establish

Established exactly:

- The weighted Gram trace-norm estimate \(\|G-K\|_1\le4\sqrt b\) for finite pure-state ensembles broadcast with uniform half-trace error \(b<1/2\).
- The explicit binary pure-state isometric cloner above, which falsifies a proposed global-cloning-fidelity/accessibility shortcut.
- The equal-prior binary accessible-fidelity formula cited above.

Not established:

- A dimension-free stability theorem converting weighted-Gram closeness to an EB channel.
- The capacity-free broadcasting-Holevo inequality, or its negation.
- A counterexample sequence with broadcasting error tending to zero but EB reconstruction error bounded away from zero.
- A quantitative mixed-state theorem.

No historical-priority claim is made. The next mathematically sharp step is the Gram fixed-point stability lemma above or a concrete family showing that no dimension-free modulus can follow from it.
