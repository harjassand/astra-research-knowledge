# Counterexample to the proposed pure-ensemble spectral bound

## Claim tested

For a pure-state ensemble \(E=\{p_i,|\psi_i\rangle\}\), let
\[
 \rho_1=\sum_i p_iP_i,\qquad \rho_2=\sum_i p_iP_i\otimes P_i,
 \quad P_i=|\psi_i\rangle\langle\psi_i|.
\]
The proposed lower bound is
\[
 F_{\rm acc}(E)\stackrel?\ge \sum_j\min(\lambda_j(\rho_1),\lambda_j(\rho_2)).
\]
It is false already for a qubit ensemble. The counterexample below has spectral-overlap right-hand side strictly greater than \(0.956\), while an exact dual certificate proves \(F_{\rm acc}\le 0.95\).

## Ensemble and moment matrices

Take the three equatorial trine states
\[
 |\psi_k\rangle=\frac{|0\rangle+e^{2\pi i k/3}|1\rangle}{\sqrt2},\quad k=0,1,2,
 \qquad (p_0,p_1,p_2)=\left(\frac1{20},\frac1{10},\frac{17}{20}\right).
\]
Their Bloch vectors are \(n_k=(\cos(2\pi k/3),\sin(2\pi k/3),0)\). Set
\[
 r=\sum_kp_kn_k=\left(-\frac{17}{40},-\frac{3\sqrt3}{8},0\right),\qquad
 T=\sum_kp_kn_kn_k^T=
 \begin{pmatrix}
 23/80&3\sqrt3/16&0\\
 3\sqrt3/16&57/80&0\\
 0&0&0
 \end{pmatrix}.
\]
Thus \(\rho_1=(I+r\cdot\sigma)/2\) has eigenvalues
\[
 a_\pm=\frac{1\pm\sqrt{241}/20}{2}.
\]

## Spectral-overlap side

The nonzero spectrum of \(\rho_2\) is the spectrum of the weighted Gram matrix of the vectors \(|\psi_k\rangle^{\otimes2}\). The off-diagonal entries have modulus \(\sqrt{p_ip_j}/4\), and their cycle phase is trivial after squaring the trine overlaps, so a diagonal unitary makes this Gram matrix
\[
 G=\frac34\operatorname{diag}(p_0,p_1,p_2)+\frac14xx^T,
 \qquad x=(\sqrt{p_0},\sqrt{p_1},\sqrt{p_2})^T.
\]
Its characteristic polynomial is
\[
 f(t)=t^3-t^2+\frac{159}{1280}t-\frac{459}{128000}.
\]
Exact endpoint signs isolate its three eigenvalues \(\mu_1\ge\mu_2\ge\mu_3>0\):
\[
 \mu_1\in(.860,.861),\quad \mu_2\in(.096,.097),\quad \mu_3\in(.043,.044).
\]
For example, \(f(.860)=-4829/16000000<0<f(.861)=1291149/4000000000\),
\(f(.096)=15597/2000000000>0>f(.097)=-132183/4000000000\), and
\(f(.043)=-56097/4000000000<0<f(.044)=57743/2000000000\).
Meanwhile \(a_+>.888\) and \(a_->.111\), since
\(.776<\sqrt{241}/20<.778\). Hence \(\mu_1<a_+\) and \(\mu_2<a_-\), so the proposed spectral overlap is
\[
 \sum_j\min(\lambda_j(\rho_1),\lambda_j(\rho_2))
 =\mu_1+\mu_2=1-\mu_3>.956.
\]

## Exact upper bound on accessible fidelity

Any qubit entanglement-breaking channel has a measure-and-prepare form. Refine its POVM effects into rank-one effects without changing the channel, and take the prepared states pure (which is optimal for a linear score). Write
\[
 M_a=\frac{w_a}{2}(I+v_a\cdot\sigma),\quad |v_a|=1,\qquad
 Q_a=\frac12(I+s_a\cdot\sigma),\quad |s_a|=1.
\]
The POVM conditions imply \(q_a=w_a/2\ge0\), \(\sum_aq_a=1\), and \(\sum_aq_av_a=0\). Direct expansion of the score gives
\[
 F=\frac12+\frac12\sum_aq_a\,s_a\cdot(r+Tv_a)
 \le \frac12+\frac12\sum_aq_a\,g(v_a),\qquad
 g(v)=\|r+Tv\|.
\]
Since \(r_z=0\) and \(T\) has zero z-row/column, \(g(v)\) depends only on \(u=(v_x,v_y)\), with \(\|u\|\le1\).

Here is a global affine majorant for \(g\) on that disk. Let \(A=9/10\) and
\[
 b=\frac{Tr}{A}=\left(-\frac{533}{1440},-\frac{37\sqrt3}{96}\right).
\]
For \(\|u\|=1\), define \(D=bb^T-T_{xy}^2\), where \(T_{xy}\) is the upper-left \(2\times2\) block of \(T\). The linear term cancels because \(Ab=Tr\), and \(\|r\|^2=241/400\), giving
\[
 (A+b\cdot u)^2-\|r+T_{xy}u\|^2
 =\frac{83}{400}+u^TDu
 =u^T\left(D+\frac{83}{400}I\right)u.
\]
The matrix in parentheses is positive definite. Its exact entries are
\[
 D+\frac{83}{400}I=
 \begin{pmatrix}
 324265/2073600&-6199\sqrt3/138240\\
 -6199\sqrt3/138240&3073/76800
 \end{pmatrix},
\]
whose first diagonal entry is positive and determinant is exactly
\(37267/165888000>0\). Also
\[
 \|b\|^2=\frac{302041}{518400}<\frac{81}{100}=A^2,
\]
so \(A+b\cdot u>0\) on the unit circle. It follows that
\(g(u)\le A+b\cdot u\) on the circle. Since \(g(u)=\|r+T_{xy}u\|\) is convex, the same affine majorant holds throughout the unit disk by writing any disk point as a convex combination of two antipodal boundary points.

Therefore, for every rank-one POVM,
\[
 \sum_aq_ag(v_a)\le \sum_aq_a(A+b\cdot u_a)=A,
\]
because \(\sum_aq_au_a=0\). Consequently
\[
 F_{\rm acc}(E)\le \frac12+\frac12A=\frac{19}{20}=.95.
\]

Combining both sides gives the strict contradiction
\[
 F_{\rm acc}(E)\le .95 < .956 < \sum_j\min(\lambda_j(\rho_1),\lambda_j(\rho_2)).
\]

## Consequence

The proposed spectrum-only expression is falsified for pure ensembles, even in dimension two. It cannot be used as a universal accessible-fidelity lower bound without additional hypotheses or a correction. This does not by itself rule out bounds involving ensemble geometry / eigenvectors, nor say anything about a distinct environment Gram-matrix formulation.

## Exact replay files

The exact rational checks are in `verify_spectral_stability_counterexample.py`; run with Python 3:

```sh
python verify_spectral_stability_counterexample.py
```

Captured output is in `verify_spectral_stability_counterexample.out`. The script reconstructs the affine-certificate matrix entries, determinant and norm bound using `fractions.Fraction`, derives the Gram-matrix characteristic coefficients from the priors, and verifies all six rational endpoint signs for the three root brackets.
