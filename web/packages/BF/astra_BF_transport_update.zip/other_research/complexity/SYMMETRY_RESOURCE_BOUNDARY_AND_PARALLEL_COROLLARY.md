# Symmetry-derived state lower bound: scope and two extensions

Research note, 2026-10-09. This is an independent complexity-boundary probe of the exponential maximum-state candidate in `/workspace/shared/astra_programme/proof_mining/EXPONENTIAL_INTERPRETATION_SPACE_CANDIDATE.md`. It is not a new verification of that candidate's expansion, support, transfer, or historical novelty inputs.

## 1. Abstract orbit-to-state conversion

The mechanism can be stated as a reusable conditional lemma. Let a group `G_N` act on the atoms of an input pair `A_N^0,A_N^1`. Assume:

1. Every HF object `x` with `|G_N x| <= q` has a support of size at most `c log_r q` for constants `c,r>1` independent of `N` and of the rank of `x`.
2. The two inputs are indistinguishable by the target counting logic on every hereditarily `t_N`-supported domain, for a threshold `t_N`.
3. A fixed equivariant state program has state carrier size at most `S`, and every descriptor recursively entering the encoded trace is equivariantly generated from at most `w` elements of one actual state carrier (pure tags have orbit one).

Then every trace constituent has orbit at most `S^w`, hence support at most `c w log_r S`. If `c w log_r S <= t_N`, the transfer applies and the program cannot distinguish the pair. Therefore every correct program must satisfy

`S > r^(t_N/(c w))`.

The derivation is just orbit-stabilizer monotonicity under equivariant images plus the support theorem; it does not depend on run length or object rank. The decisive research input remains item 2: a pair-specific transfer theorem. This is not a model-independent lower bound for ordinary Turing-machine space.

For the candidate theorem, fixed-width two-dimensional interpretation states have `w=2` after the source's explicit quotient-code construction (including recursive wrappers), while the expansion/cofilling transfer gives `t_N = Omega_P(N)`. Hence `S = exp(Omega_P(N))`. The exponent necessarily depends on the fixed program's formula width/support constants. If descriptor arity or formula width grows with `N`, this argument gives a weaker parameterized bound and does not yield a uniform exponential constant.

## 2. Exact boundary against ordinary randomization and advice

The lower bound uses automorphisms of the *uncolored input* acting throughout the run. It should not be restated as a lower bound for arbitrary randomized algorithms or algorithms with arbitrary labels/advice.

For an `n`-atom input, attach to each atom an independent uniform `k`-bit label and order atoms lexicographically by labels. The collision probability is at most

`binom(n,2) 2^(-k)`.

With `k = 3 ceil(log2 n)`, this is at most `1/(2n)` for `n>=2`. On the no-collision event the labels give a total order. A solver can build the `F_3` consistency matrix and run ordinary Gaussian elimination with polynomial space (at most a polynomial-size table; the matrix has O(n^2) rows and O(n) columns in the displayed query). The answer is correct with probability at least `1 - 1/(2n)`. Conditional on the labels, the input automorphism group is reduced to the stabilizer of the labeling, which is trivial when labels are unique. Thus the support argument has no leverage on this natural randomized extension. The random-label distribution itself is isomorphism-invariant, but its individual realizations are not; invariance in distribution is weaker than per-run equivariance.

An arbitrary advice order has the same failure mode. Randomness/advice attached only as a global scalar that is fixed by every input automorphism is different: it does not shrink the input automorphism group. A pointwise-equivariant program may plausibly inherit pair indistinguishability seed-by-seed, but that restricted statement would be a model-specific corollary, not robustness against standard BPP-style per-object randomness. No useful broad randomized theorem follows from the current support result alone.

## 3. Candidate low-parallel corollary (not promoted as fully audited)

The source243 query has at most `2n` unknowns and `n+n^2` equations over `F_3`. For an `n`-element input, each coefficient and equation-incidence predicate is a fixed relational computation with reductions over at most polynomially many tuples, so the matrix can be assembled by polynomial-size polylog-depth Boolean circuits. Pad a rectangular coefficient matrix `A` and augmented matrix `[A|b]` to square matrices. The system is consistent iff `rank(A)=rank([A|b])`. Mulmuley's primary publication abstract states that rank over an arbitrary field is computable in `O(log^2 n)` parallel time with polynomially many processors (Ketan Mulmuley, 1987, [Combinatorica DOI page](https://doi.org/10.1007/BF02579205)). Under the standard uniform deterministic NC^2 formulation of that rank algorithm, this yields an isomorphism-invariant query in `NC^2` that is not definable in full CPT with counting.

This is a potentially sharper descriptive-complexity corollary than merely `P \ CPT`, because it puts an easy-parallel query outside CPT. It is not `P != NC`, `NC^2 != P`, or any conventional complexity-class separation. **Audit limit:** the Springer primary abstract verifies arbitrary-field scope, depth/time, and processor count, but its accessible abstract does not display the proof's deterministic/uniform circuit construction or Boolean encoding details. I did not retrieve the full Mulmuley proof in this pass. Therefore the exact uniform-NC^2 claim should be checked against the paper's full proof before relying on it in a final theorem statement. The weaker polynomial-time claim is already in source243.

The candidate query statement itself is in `/workspace/shared/astra_programme/proof_mining/243_00-introduction.tex` (linear system definition and P-time algorithm) and `/workspace/shared/astra_programme/proof_mining/243_06-coding.tex` plus `243_07-separation.tex` (CPT noncapture). The checked snippets do not discuss NC or parallel rank.

## 4. Research assessment

The most defensible contribution from this branch is the model boundary plus the abstract orbit-to-state conversion: symmetry-preserving fixed-width relational memory obeys an exponential representation cost when the support threshold is linear. The random-label construction is a sharp warning against calling that general algorithmic space. The NC^2 observation is likely a useful corollary but is routine once the separator and standard parallel-rank theorem are accepted; it does not provide the sought broader mechanism by itself.

I found no valid route in this pass from the candidate to P-vs-NP, circuit lower bounds, or unrestricted space lower bounds. Any such bridge would require new hypotheses/results; state-orbit lower bounds alone do not supply it.
