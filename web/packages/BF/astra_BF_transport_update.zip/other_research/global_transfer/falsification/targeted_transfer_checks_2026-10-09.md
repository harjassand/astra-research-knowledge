# Targeted falsification check: N175 countable transfer

Date: 2026-10-09 UTC  
Target: exact pinned `PROOF_v3` at [`harjassand/astra-research-knowledge`, commit `031ce532f7f6d1c070387f6213a00204893be79d`, page `web/pages/d-413da5591afd120a.html`](https://github.com/harjassand/astra-research-knowledge/blob/031ce532f7f6d1c070387f6213a00204893be79d/web/pages/d-413da5591afd120a.html), especially §§2, 5–8.  
Scope: toy finite-block transfer, full off-diagonal control, stagewise averaging, and the countable fixed-point step. This is not an audit of the source crossing lemmas or the full PDE freezing proof. No decisive counterexample to the *repaired* transfer was found in this pass.

## 1. Exact finite-block counterexample to selected-entry-only control

Let `δ>0`, `D>0`, and in dimension three let the only nonzero entries of `E` be

`E_21 = δ D^(-3/4)`, `E_23 = δ`.

Take `v=e_1−ρe_3`. At an exact reference double (reference matrix `I`), the second coordinate of the shear defect is

`(E v)_2 = δ D^(-3/4) − ρδ`.

It is negative whenever `D>ρ^(-4/3)`, despite `E_21>0`. Moreover `E` has just one nonzero row, so

`||E||_2 = δ sqrt(D^(-3/2)+1) < 2δ`

for `D≥1`. For the exact values `δ=1, D=10^6, ρ=0.1`, the selected entry is `+3.1623e-5`, the cross-column term is `−0.1`, the defect is `−0.0999684`, and `||E||_2≈1.000000001`. This reproduces the failure recorded in PROOF_v3; any argument controlling only one signed entry is insufficient.

## 2. Why the stated whole-matrix repair defeats that toy counterexample

At a reference double `M_0=λI`, write `M=M_0+E`, `E=a z B+R`, with `||B||_2≤C`, `|B_21|≥b>0`, and `||R||_2≤εa`. For a line vector `v=e_1+u`, `u_1=0`, `||u||_∞≤ρ`, the exact two-coordinate shear defect is

`F=(Mv)_2−u_2(Mv)_1=(Ev)_2−u_2(Ev)_1`.

The common `λI` term cancels exactly. Since `||u||_2≤sqrt(p−1)ρ`, the perturbation away from the signed leading term `a z B_21` obeys

`|F−a z B_21| ≤ a C sqrt(p−1)ρ + εa(1+sqrt(p−1)ρ) + ρ a C(1+sqrt(p−1)ρ) + ρ εa(1+sqrt(p−1)ρ)`.

Thus for each fixed finite cutoff dimension `p`, first choose `ρ>0` sufficiently small relative to `b/C/sqrt(p)`, then choose `ε` small, and the sign is uniform over the coordinate box. This is exactly the extra strength of PROOF_v3's claimed full `p_n×p_n` local norm bound `||E||≤C'_n a_ν`; it is not supplied by the weaker selected-entry estimate. For example, with `p=4,C=3,b=1,ρ=ε=0.01`, the displayed normalized error bound is below `0.11`, leaving a positive margin from the unit leading coefficient. The toy example in §1 violates `||E−a zB||=o(a)` and therefore does not falsify this repair.

## 3. Independent weighted-averaging lemma for the stage schedule

Fix a stage `m`, with phase period `P_m=Q_m S_m`. Let a bounded periodic reference frequency be `g_m(s)`, of period `P_m`, with mean `\bar g_m≤β`. Set `ds/dt=(D_m t^(3/4))^(-1)`, i.e. `dt/ds=A(s)=D_m t(s)^(3/4)`. Put `f=g_m−\bar g_m` and choose a periodic primitive `G'=f`; then `||G||∞≤P_m||f||∞` (up to the immaterial choice of additive constant). Integration by parts gives

`∫_{T_m}^t f(s(x)) dx = [G(s)A(s)]_{T_m}^t − ∫_{s(T_m)}^{s(t)} G(s) A'(s) ds`.

Here `A'(s)=(3/4)D_m^2 t(s)^(1/2)`, whose integral on the interval is `D_m(t^(3/4)−T_m^(3/4))`. Consequently

`|∫_{T_m}^t (g_m(s(x))−\bar g_m) dx| ≤ 3 P_m ||f||∞ D_m t^(3/4)`.

So the *full label period* condition `C_n D_m Q_m S_m T_m^(−1/4)≤2^(−m)` yields a stage error at most `2^(−m)t` for every `t≥T_m` (after absorbing the fixed cutoff-dependent frequency bound into `C_n`). Summing completed stages gives `o(t)`: each fixed stage's absolute error is finite and hence vanishes after division by `t`; the normalized stage errors are dominated by the summable sequence `2^(−m)`, so dominated convergence applies. The partial current-stage error is `O(2^(−m)t)` and vanishes as the active stage index tends to infinity. This verifies the claimed use of a growing finite program and a slower phase clock, conditional on the stated periodwise mean bound and cutoff-uniform stage inequalities.

If the controlled rather than reference frequency differs by `O_n(t^(−9/16))`, its integrated discrepancy is `O_n(t^(7/16))=o(t)`. This is consistent with the fixed-cutoff all-order envelope in §3 and the matrix/frequency comparison claimed in §§5,8.

## 4. Countable compact fixed-point step

Abstractly, let `X=∏_{ν≥1}[-1,1]`, a compact metrizable space, and suppose each mismatch `M_ν:X→R` is continuous and has strict opposite signs on the two faces `z_ν=−1,+1`, uniformly over all other coordinates. For each `N`, freeze the tail at any fixed value and apply the finite-dimensional Poincaré–Miranda theorem to `(M_1,…,M_N)` on `[-1,1]^N`, obtaining `x^(N)` with the first `N` mismatches zero. Compactness gives a coordinatewise-convergent subsequence; for each fixed `ν`, continuity and `M_ν(x^(N))=0` for all sufficiently large subsequence indices imply `M_ν(x*)=0`. Thus the limit solves all countably many equations. Endpoint signs put every coordinate in the interior.

This abstract argument is valid. The substantive dependency is the proof-specific premise that each `M_ν` is continuous in the product topology despite the graph extending into the future. PROOF_v3 explicitly asserts fixed-cutoff graph continuity via contraction and says each trial output is a finite sum; if those assertions are established with the claimed uniform tail-modulus, the compact-product limit is justified. This note does not independently reprove the PDE contraction/graph-continuity assertion.

## Verdict within assigned scope

- The old selected-entry inference has a concrete finite-dimensional counterexample, explicitly documented above.
- The stated whole-local-matrix repair is sufficient to exclude that mechanism at each fixed finite cutoff; finite dimension matters because the coordinate-box radius can absorb `sqrt(p_n)`.
- Stagewise periodic averaging with `dt/ds=D_m t^(3/4)` and the full `Q_mS_m` timing condition is correct by a direct primitive/IBP estimate.
- The countable Brouwer/diagonal argument is correct conditional on the asserted product-topology continuity of every mismatch map.
- No new decisive toy-ODE, finite-block, averaging, or abstract fixed-point counterexample to the repaired N175 transfer was found. Remaining unverified load-bearing points here are the specific PDE graph-freezing/continuity and the source finite spectral inputs, outside this targeted check.
