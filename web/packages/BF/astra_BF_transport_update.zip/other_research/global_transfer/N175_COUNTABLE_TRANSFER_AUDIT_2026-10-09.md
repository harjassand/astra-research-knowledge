# Independent interface audit: N175 countable spectral-to-harmonic transfer

Date: 2026-10-09 (UTC)

## Scope and verdict

I audited the countable transfer in the pinned `COMMON-METRIC TRANSFER: AUTHORITATIVE VERSION 3`, §§1–8, against the pinned source paper's Dirichlet-map / invariant-graph / crossing-matching arguments. I also checked the two pre-existing bridge notes, especially their whole-ball contraction and stage-envelope claims. This audit does **not** redo the fixed-area finite spectral gates S1–S3; those remain explicit conditional inputs.

**Verdict:** I found no concrete obstruction in the countable PDE/global-harmonic-transfer interface. I independently rederived the whole-ball contraction, compact-family freezing modulus, fixed-cutoff graph contraction/continuity, and the full finite-matrix crossing expansion from the displayed geometry and stage envelopes; I did not treat those as black-box assumptions. The remaining load-bearing mathematical inputs are the fixed-area finite spectral gates S1–S3, standard Dirichlet/Schauder theory, and the stated common-neighborhood crossing nondegeneracy. All transfer constants may deteriorate arbitrarily with band index; the stage schedule needs only finitely many at a time, so no degree-uniform bound is required.

This is a conditional mathematical audit, not a formal certificate or external specialist validation. In particular, it does not convert the internal source reports on S1–S3 into independently proved source facts, and it does not establish a materialized metric or useful quantitative radii.

## Pinned evidence reviewed

- Astra source pin `031ce532f7f6d1c070387f6213a00204893be79d`, `web/pages/d-413da5591afd120a.html`, PROOF_v3, §§0–8: [pinned PROOF_v3](https://github.com/harjassand/astra-research-knowledge/blob/031ce532f7f6d1c070387f6213a00204893be79d/web/pages/d-413da5591afd120a.html)
- Same commit, POST_SOURCE_STATUS: [pinned status page](https://github.com/harjassand/astra-research-knowledge/blob/031ce532f7f6d1c070387f6213a00204893be79d/web/pages/d-7a7b27b94021a6ef.html)
- Target paper at OpenAI/math commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`: [pinned paper PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf), especially §§4–7 and Propositions 4.1, 5.1–5.3, 5.2, and §6. The current transfer proof modifies the fixed-program estimates for the countable stage schedule.
- Prior local finite-input audit: `/workspace/shared/astra_programme/harmonic_crossing_source_audit/GEOMETRY_INPUTS_AUDIT.md` (scope explicitly stops before transfer).
- Prior bridge notes: `/workspace/shared/astra_luna_campaign/independent_bridge/harmonic_growth_endpoint_audit_2026-10-09.md`, `uniform_weyl_endpoint_extension.md`, and `slow_polar_gluing_and_radial_barrier.md`.

## Interface-by-interface checks

### 1. Countable band skeleton, frames, and protected cuts

The construction needs one reference angular path for each fixed cutoff (p_n=B_{M_n}), not an all-spectrum frame with a uniform gap. For fixed n, the selected boundary p_n is strict on the common simple stem and on every active loop: loops are internal to one band and cross only their designated pair. The round endpoint has the strict gap between round degrees M_n and (M_n+1). The countably many high-rank detours approach round in each fixed smooth norm, so the closure still has a positive p_n-boundary gap for this fixed n. This supplies a finite-cutoff continued frame and (gamma_n>0) on the reference skeleton; no positive infimum over all n is needed.

The stage program P_m is a concatenation of finitely many based cycles and returns to the common base. Its monodromy permutes labels only within the disjoint bands. Taking Q_m divisible by each band cycle length makes the labels return to their starting slots before switching to P_{m+1}. A possible sign holonomy of real eigenvectors is a frame convention only: it does not change eigenvalues or the estimates, and the crossing control orientation can be chosen occurrence-by-occurrence. The geometry, not the auxiliary frame, is what must be smooth at stage joins; the common constant-base interval provides that.

At any phase of P_m, repetition through Q_m samples each label equally over every rank of its own band. This remains true while other bands' loops are traversed: at each fixed phase the repeated program acts by the same within-band permutation. Thus the band mean bound is a rank average at that phase, not an assumption that other loops leave the spectrum unchanged.

### 2. Whole-ball Dirichlet maps, cap solvability, and leakage

For the polar metric with a fixed pointwise angular area form, the averaged harmonic equation is

\[
  (fr^2\,\partial_r\bar ur)'=0.
\]
Regularity in the Euclidean core forces the integration constant to vanish, so the μ-mean is preserved on every sphere. The maximum principle gives positivity and preservation of constants for each whole-ball restriction (R_{r,R}). Jensen's inequality for a positive unital map then gives

\[
  \|R_{r,R}v\|_{L^2(\mu)}^2 \le \int R_{r,R}(v^2)\,d\mu
  =\|v\|_{L^2(\mu)}^2.
\]

For smooth boundary data, classical Dirichlet solvability on the smooth compact ball applies; L² data follow by density and the contraction. Interior elliptic regularity makes inner traces smooth. These facts give the exact nesting identity needed to glue extensions on the increasing balls. I found no cap-boundary or compatibility obstruction.

For a fixed cutoff p_n, high-mode leakage is controlled by the *outer cluster gap* only. The actual boundary map T_j is compared with the frozen inward map on all of L² in operator norm, and with the frozen map on a finite smooth low frame at the sharper (o(\delta_j)) scale. The high-to-low block only needs o(1); the low-to-high block is (O(\delta_j)). Since p_n is fixed before taking (j\to\infty),

\[
\tau_{*,n}=\inf_{s,b,i\le p_n}e^{-d(b^{-2}\lambda_i(s))}>0
\]

and the positive spectral gap at p_n yields a strict high-block contraction relative to τ. This is sufficient even when τ is extremely small: choose the stage/band start later. It would be insufficient to assert one contraction constant uniform in n, but the proof does not need that.

The operator-norm freezing proof's compactness argument is coherent: for arbitrary bounded boundary data, pass to a weakly convergent subsequence and a smoothly convergent frozen link. Whole-ball L² contraction bounds every section; local elliptic compactness gives strong convergence at an interior sphere. Testing against smooth angular functions gives a bounded normal derivative up to the outer boundary, identifying the weak boundary trace. In the limiting half-cylinder, the negative radial root is excluded by sectional L² boundedness as (x\to-\infty), leaving exactly the frozen inward semigroup. The same limit holds for the frozen map, which proves the asserted uniform o(1) operator-norm difference by contradiction. This uses compactness of the link family and the uniform time-derivative envelopes, not previous-radius control values.

### 3. Invariant graph and full low-matrix estimate

For each fixed n, the reference projection Π_j onto the first p_n modes has a uniform-in-time boundary gap on its active skeleton. The actual controlled link differs from reference by (O(j^{-9/16})), so the whole cluster projection differs by the same order even at internal double crossings; no individual eigenvector of the controlled cluster is used. The sharp finite-frame freezing estimate gives

\[
T_{QL}=O(\delta_j),\qquad T_{LL}=\operatorname{diag}(α_i^{-1})+O(\delta_j),\qquad
T_{LQ}=o(1),\qquad \|T_{QQ}\|\le \kappaτ_j.
\]

The graph update (F_j(V)=(T_{QL}+T_{QQ}V)(T_{LL}+T_{LQ}V)^{-1}) is a contraction on a fixed small operator ball once j≥J_n. The lower bound tau_{*,n}>0 absorbs the absolute o(1) operator error. Iterating inward from a zero terminal graph gives V_j, with ‖V_j‖ ≤ C_n δ_j; the tail error decays geometrically in the inward graph iterations. This proves both uniqueness in that ball and continuity in the entire countable control product: finite graph iterates depend on finitely many ball controls, while the remaining tail is uniformly geometric. No operator-norm continuity of T_j on all of L² is required.

The repaired local crossing estimate is essential and is correctly stronger than the global ‖E_j‖≤C_nδ_j estimate. On a crossing collar, with

\[
η_m(t)=t^{-3/4}/D_m,\qquad a_\nu=η_m(t_\nu)^{3/4},
\]

the stated local expansion is in **full p_n×p_n matrix norm**:

\[
E_j^{(n)}=a_\nu z_\nu B_n(s(j),b(j))
+O_n\!\left(a_\nu^2+r_{n,m}(j)+Ω_n(j)j^{-9/16}\right).
\]

The frozen finite-cluster calculus gives the selected crossing entry by a divided difference of e^{d(b^{-2}L)}. At the double it equals
α b^{-2} d'(b^{-2}λ) ⟨e_h, L̇ e_i⟩, which is nonzero and keeps its sign on a sufficiently small collar.

The local PDE residual is
\[
r_{n,m}=O_n\big((η_m+t^{-3/2})(1+\log(1/η_m))+η_m^2\big).
\]
On a crossing support, a_ν=t_ν^{-9/16}D_m^{-3/4} and η_m=t^{-3/4}/D_m. For each fixed stage m, the three ratios
\[
\frac{η_m\log(1/η_m)}{a_ν}=O(t^{-3/16}D_m^{-1/4}\log t),\quad
\frac{t^{-3/2}\log(1/η_m)}{a_ν}=O(t^{-15/16}D_m^{3/4}\log t),\quad
\frac{η_m^2}{a_ν}=O(t^{-15/16}D_m^{-5/4})
\]
tend to zero. The graph correction divided by a_ν is O_n(D_m^{3/4}Ω_n(j)); choose T_m so the tail modulus D_m^{3/4} sup_{j≥T_m}Ω_n(j) is small for every n≤m. The O_n(a_ν²) finite-matrix Taylor remainder is smaller still.

This proves E_j^{(n)}=a_ν z_ν B_n(s(j),b(j))+o_n(a_ν) in **full p_n×p_n matrix norm**, uniformly over the other controls. The finite-cluster matrix function and its inverse are C² on this finite-dimensional cluster, so the Taylor remainder and matrix norm are controlled in the entire block, not just the selected entry. Thus ‖E_j^{(n)}‖≤C'_n a_ν on the collar. In the line force, every other column term is O_n(ρ_n a_ν); choose ρ_n>0 small relative to the finite list of signed coefficients for that fixed band. This keeps the mismatch endpoint signs uniform. The whole-local-matrix bound is essential: the retained 3×3 example in PROOF_v3 shows that a selected-entry-only estimate fails.

### 4. Stable line recurrence and the countable exact crossing fixed point

For each birth band n, the finite low outward matrix satisfies A_j^{(n)}=diag(α_i(j))+E_j^{(n)}. For a column v_i=e_i+Σ_{h≠i}u_{hi}e_h, the exact line-invariance equations reduce to the scalar recurrence

\[
u_{hi}(j+1)=r_{hi}(j)u_{hi}(j)+F_{hi}(j),\qquad
r_{hi}=\alpha_h/α_i,
\]
with the denominator uniformly positive on the column box and ‖F‖ bounded by the full matrix estimate.

Each reference crossing is linearly split, so ℓ_hi=log r_hi has a simple zero. On a stable sign interval the accumulated log contraction is bounded below by c η_* m²-C, hence stable weights obey W(m)≤C e^(−cη_*m²) and \(∑_m W(m)=O(η_*^{-1/2})\). Away from own crossing plateaux the force is made smaller than ε_m|r-1|; on the plateau its selected control term has a fixed sign. The trial coordinate size is O(η_*^{1/4})<ρ_n. At a negative-to-positive cut there are ≈η_ν^{-1/2} central mesh points with incoming weight bounded below and force ≈η_ν^{3/4}, producing a signed mismatch of size ≈η_ν^{1/4}. Outside-plateau terms are exponentially damped. Thus the two endpoint values z_ν=±1 force opposite mismatch signs uniformly over all other box variables.

The fixed-point bookkeeping is valid as stated:

- one crossing has one matching condition, because reversing the ordered pair changes r to (r^{-1}); one orientation is a two-incoming cut and the other is a prescribed zero cut;
- each control belongs to its crossing's birth band; later birth-band columns are separated from earlier-band crossings by the protected boundary, so those events are nonresonant for the new columns and do not require duplicate equations;
- each scalar trial output depends on finitely many coordinates, except a noncrossing backward tail, whose geometric weights give a uniformly convergent sum;
- every graph/matrix coordinate is continuous in the full control product, and the countable product of closed intervals is compact metrizable;
- finite-coordinate Brouwer maps with the tail frozen, followed by diagonal subsequence extraction and coordinatewise continuity, gives one fixed point. The endpoint mismatch signs exclude boundary controls, so the fixed point has zero mismatch and satisfies every recurrence exactly.

The birth-only convention matters: one does not solve duplicate old-band matching systems again at larger cutoffs. For new columns, earlier-band crossings cannot be resonances because their eigenvalues stay strictly below the new band. The resulting controls are nevertheless common to every birth graph because each V^{(n)} is built over the same full metric/control product.

### 5. Stage envelopes, Ricci sign, and completeness

For fixed spatial order (q), normalization of a band-n direction in (C^{n+2}), amplitude cap (2^{-n}), and (D_m) chosen to dominate the finite stage-m phase/spatial derivative data imply uniform tail bounds of the advertised orders:

\[
\|H_z-H_{\rm ref}\|_{C^q}=O_q(t^{-9/16}),\quad
\|\partial_tH_z\|_{C^q}=O_q(t^{-3/4}),\quad
\|\partial_t^2H_z\|_{C^q}=O_q(t^{-3/2}).
\]

For each (q), high bands have controlled C^q norms and finitely many early bands only enlarge the constant. The conditions D_m Q_m S_m T_m^{-1/4} ≪ 1 make phase speed and η comparable throughout each bump support. Stage-start requirements are finitely many lower bounds on T_m (including T_m≥2T_{m-1}); increasing T_m satisfies all because the moduli tend to zero. Smooth changes of phase speed happen in the common constant-base interval where (H_s=0), so they do not create metric derivative jumps.

With A=H⁻¹H_t=O(t⁻³ᐟ⁴) and A_t=O(t⁻³ᐟ²), the tangential Ricci block retains a positive t⁻²-scaled buffer because K_H>κ>a² and b→a. The mixed block is O(t⁻³ᐟ⁴); its Schur-complement loss is O(t⁻³ᐟ²). The tail choice b_tt+b_t=−C t⁻³ᐟ² supplies a radial block of the same order; choose C once large enough relative to the fixed derivative/divergence constants, then start late. The radial factor is concave, a≤f′≤1, equals r near zero, and tends to slope (a). This yields a smooth complete metric with exact radial distance and AVR a². I found no completeness or Ricci-sign obstruction in the staged metric.

### 6. Lifting, growth, and independence

For each birth cutoff, the invariant graph gives (w_i(j)=\iota_jv_i(j)+V_jv_i(j)) and the exact inward compatibility (T_jw_i(j+1)=\sigma_i(j)^{-1}w_i(j)). Multiplying by (c_i(j+1)=c_i(j)\sigma_i(j)) gives compatible L² traces on nested balls. A trace is smooth because it is the restriction of the next larger ball's harmonic extension to an interior sphere. Classical Dirichlet uniqueness then glues the ball extensions into one entire smooth harmonic function.

The low projection of (w_i) has coordinate (v_i), the graph is orthogonal to the low space, and the fixed column boxes keep these traces uniformly bounded above and away from zero. Thus

\[
\log\sigma_i(j)=d(b(j)^{-2}\lambda_i(s(j)))+O_n(j^{-9/16}).
\]

The error sums to O_n(T^{7/16})=o(T). Within a stage, the phase-frequency deviation from its band mean has a bounded period primitive; integration by parts costs O_n(D_m Q_m S_m T³ᐟ⁴), whose relative size is at most 2⁻ᵐ by the stage-start condition. Completed-stage errors sum to o(T) because T_m≥2T_{m-1}, and the current partial stage is o(T). The radial-factor change b−a=O(t⁻¹ᐟ²) and unit-mesh errors are also sublinear for each fixed cutoff. Hence each new-band function has upper spherical exponent at most the band mean β_n.

All-radius control is correctly transferred: whole-ball L² contraction bounds intermediate radii between integer log radii; a uniform local L²-to-sup estimate on fixed-width cylinders converts the L² exponent to pointwise growth; the compact core changes only the multiplicative constant. A strict exponent margin β_n<k_n absorbs the local estimate and finite initial radii.

At a common late sphere, any finite collection of birth-band traces has low vectors equal to its distinct orthonormal reference modes plus o(1): each fixed-band line coordinate tends to zero and each fixed-band graph tends to zero. Therefore the finite collection is linearly independent. No nesting of different birth graphs V^{(n)} is needed.

## Exact remaining limits / no-overclaim statement

1. The conditional theorem still rests on S1–S3 and on the usual elliptic, fixed-area gauge, and exact Ricci identities. This audit was intentionally not a second finite-spectral source audit.
2. The crucial repaired statement is the local p_n×p_n matrix expansion plus the D_m^{3/4}Ω_n(T_m)→0 choice. Dropping either reopens the known selected-entry failure; both are explicit in PROOF_v3.
3. Constants are nonuniform in band index and may be very poor; the proof is nonquantitative. This is acceptable for the countable existence argument, not for a numerical realization or effective bound.
4. The pinned status page itself says formal certification, external validity, and priority are not established. This audit does not change that status.
