# Fixed-c one-metric claim versus endpoint (9v/4)

Date: 2026-10-09 (UTC)

## Short verdict

The fixed-q, fixed-(c) N175 schedule conditionally supports, for each fixed 4/9<v<1 and c<9v/4, a **single metric depending on (v,c)** with \(\limsup h_k/(k+1)^2>c\). This does not by itself give one metric attaining the endpoint by taking c→9v/4; that would change q, the selected band sequence, and potentially the entire metric.

A separate endpoint upgrade is mathematically plausible under the already-audited all-adjacent-pair spectral input and the countable transfer audit in `N175_COUNTABLE_TRANSFER_AUDIT_2026-10-09.md`. The compact-family Weyl argument and variable q_n schedule close the **endpoint bookkeeping** without demanding transfer constants uniform in n. This remains conditional on the same substantial N175 geometric transfer and S1–S3 inputs.

## Noncircular compact Weyl umbrella

The key condition is to preselect a band-independent family K_W before choosing the sequence M_n. It is a frequency-bound family, not the active protected-gap family for any selected cutoff.

1. Fix one all-spectrum-simple stem in a common small near-round neighborhood.
2. For each fixed smooth neighborhood U_m↓{g_0}, use the pinned S3 all-high-adjacent-pairs quantifier to choose a degree threshold R_m. For each high adjacent pair of round degree ℓ, assign the largest (m(\ell)) with (R_m\le\ell), and select its isolated-double detour in (U_{m(\ell)}). Include its crossing-control box after normalizing the direction in C^{m(ℓ)+2} and imposing a cap tending to zero (e.g. at most 2^{-m(ℓ)}, additionally reduced to remain in the common curvature neighborhood).
3. The high-degree detours and control boxes converge to round in every fixed C^q; finite early families are compact; the common stem is compact. Hence their union has compact closure K_W in C^0 (indeed in C∞). Every member retains the exact area form (d\mu_{g_0}), total area (4\pi).
4. Keep K_W separate from the active cutoff-p_n skeleton. After choosing M_n, use only crossings internal to its bands and omit all loops at selected band boundaries. Then K_W may contain a crossing at an eventual boundary without spoiling that boundary's gap in the actual transfer program.

The uniform Weyl lemma follows directly: finite C^0 nets on K_W give multiplicative comparison of Dirichlet energies, while the L² denominator is identical because the area form is identical. Min–max transfers this comparison to every ordered eigenvalue, and the ordinary Weyl law at finitely many net centers gives

\[
\sup_{h\in K_W}\left|\frac{\lambda_j(h)}{j}-1\right|\longrightarrow0.
\]

This only controls frequencies. It provides no gap, crossing slope, frame, graph, or PDE constant; those remain per-cutoff estimates on the active skeleton.

## Endpoint band schedule

Let B_M=(M+1)^2, a=√v, and I_n=(B_{M_{n-1}},B_{M_n}]. Choose any ε_n↓0 with 2/(3a)+ε_n<1, and choose a uniform Weyl tolerance δ_n=o(ε_n) with cutoff J_n. For ranks j≥J_n, every h∈K_W obeys λ_j(h)≤(1+δ_n)j. Because b(t)≥a and d(x)≤√x, the band mean is bounded by

\[
\frac{β_n}{M_n}\le \frac{2}{3a}\sqrt{1+δ_n}
\frac{1-θ_n^3}{1-θ_n^2}+O(M_n^{-1}),\qquad
θ_n=\frac{M_{n-1}}{M_n}.
\]

Since the ratio equals 1+θ_n²/(1+θ_n), make θ_n²=o(ε_n), M_n^{-1}=o(ε_n), and set q_n=2/(3a)+ε_n. Then β_n/M_n<q_n for all sufficiently large n, with a strict positive margin. Choose M_{n-1} beyond √J_n and that band's finite crossing thresholds; then choose M_n arbitrarily larger to satisfy the ratio/error and monotonicity requirements. The next band's lower cutoff is handled by one-step lookahead when choosing M_n. This is noncircular because K_W, its Weyl cutoffs, and all all-pair crossing thresholds are preselected before the M_n sequence.

Set k_n=ceil(q_n M_n), choosing M_n so k_n increases. The common fixed point supplies B_{M_n}-B_{M_{n-1}} new independent functions of growth exponent below k_n, and all previous ones remain in H_{k_n}. Thus

\[
\limsup_n\frac{h_{k_n}(g)}{(k_n+1)^2}
\ge \lim_n\frac{(M_n+1)^2-(M_0+1)^2}{(\lceil q_nM_n\rceil+1)^2}
=\frac{9a^2}{4}=\frac{9v}{4}.
\]

The shrinking arithmetic margin creates no new uniformity demand: every n is fixed while its own transfer constants, box radius, crossing threshold, and stage threshold are selected. The countable stage construction only asks for finitely many such conditions at stage m.

## Explicit qualification

The endpoint conclusion is **not** in the original fixed-q proof and must not be inferred by a limit over different metrics. It is a separate diagonal compact-Weyl refinement. Its load-bearing requirement is the existence of the prebuilt compact K_W containing every reference and allowed control link actually used. The S3 quantifier and diagonal C^q normalization support that construction, but until the all-pair skeleton and its controlled boxes are fixed in this order, the Weyl cutoffs could be circular. The endpoint is therefore conditional on that K-first construction plus the complete countable transfer audit; no universal upper bound, full limit, novelty, or external validation follows.
