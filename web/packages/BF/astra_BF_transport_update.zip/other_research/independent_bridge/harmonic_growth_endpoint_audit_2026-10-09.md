# Independent audit: harmonic-growth endpoint upgrade

Date: 2026-10-09  
Target: N175 `COMMON-METRIC TRANSFER: AUTHORITATIVE VERSION 3`, especially §§0–8, plus the proposed variable-band/Weyl strengthening.  
Status: analytic audit of the endpoint modification, conditional on N175's countable transfer and the finite spectral construction. This is not a formal proof certificate, external expert review, or priority assessment.

## Executive verdict

**No mathematical obstruction to the endpoint modification is apparent, provided one first fixes a band-independent compact Weyl umbrella `K_W`.** This umbrella covers all reference and allowed controlled link values for frequency bounds; it need not have protected boundary gaps and must be distinguished from the cutoff-specific active transfer skeleton. For a compact family `K_W` of smooth `S²` metrics with the exact same pointwise area form `dμ_round` (total area `4π`), the ordered eigenvalues satisfy

`sup_{h∈K} |λ_j(h)/j − 1| → 0`.

This yields band means `β_n/M_n → 2/(3a)` when `M_{n−1}/M_n → 0`. Replacing N175's fixed `q` by `q_n=2/(3a)+ε_n`, with `ε_n↓0` chosen larger than the Weyl and band-ratio errors, gives `k_n=ceil(q_n M_n)` and the same-metric subsequence bound

`limsup_{k→∞} h_k(g)/(k+1)² ≥ 9a²/4 = 9 AVR(g)/4`.

This endpoint change does not alter the crossing controls, fixed-cutoff transfer, countable product/Brouwer equations, or stage-timing mechanism: in §§0–8 of PROOF_v3, `q` is used to set degree thresholds and verify `β_n<k_n`. It is an epsilon/diagonal refinement of the already much harder one-metric construction. It is **not** a consequence of the older per-degree theorem by itself: those metrics may vary with degree, and no convergence/compactness argument transfers their harmonic functions to one limit metric. The endpoint statement is still only a limsup lower bound, not a full-limit or all-degree lower bound, and `9v/4` is not established as a universal upper bound.

**Required proof repair:** do not define `K` only after choosing all `M_n` and then use its unspecified Weyl cutoff to choose those same `M_n`. Preselect a countable crossing/control skeleton with shrinking neighborhoods, including its common stem, before band selection, or state and prove an equivalent cutoff-independent tail estimate. The source quantifiers support this route (details below), conditional on the source lemmas and N175 path/control construction.

## Exact sources inspected

- Astra proof pin: [`harjassand/astra-research-knowledge`, commit `031ce532f7f6d1c070387f6213a00204893be79d`, `web/pages/d-413da5591afd120a.html`](https://github.com/harjassand/astra-research-knowledge/blob/031ce532f7f6d1c070387f6213a00204893be79d/web/pages/d-413da5591afd120a.html), `PROOF_v3`, §§0–8.
- Target paper pin: [`openai/math`, commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`, `preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf`](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf).
- The paper's fixed-area gauge is explicit at Eq. (2.4): `dvol_{h(w)} = dvol_{g0} = 4π dμ`.
- The relevant source gate is Lemma 2.5 (“Adjacent doubles”), including its within-round-block and cross-block constructions. Its proof uses Lemmas 2.1–2.4 and then says the remaining perturbations can be arbitrarily small.
- The same Astra commit has a later `POST_SOURCE_STATUS` page dated 2026-10-08: [`web/pages/d-7a7b27b94021a6ef.html`](https://github.com/harjassand/astra-research-knowledge/blob/031ce532f7f6d1c070387f6213a00204893be79d/web/pages/d-7a7b27b94021a6ef.html). It supersedes PROOF_v3's historical “final reports pending” wording: it says S1–S3 were internally reconstructed by separate reports, including “every adjacent pair” and a diagonal finite-derivative budget. It still explicitly reports no formal certificate or external specialist validation, with external validity and priority unknown.

## 1. Uniform Weyl lemma

Let `K` be compact in `C∞(S²)` and suppose each `h∈K` has the same pointwise area form, with total area `4π`. Since `K` is compact in particular in `C⁰`, for any `δ>0` choose a finite `C⁰` net of smooth center metrics `h_1,…,h_N∈K` fine enough that a member `h` and its center satisfy

`(1−δ) E_{h_i}(u) ≤ E_h(u) ≤ (1+δ) E_{h_i}(u)`

for every smooth `u`. The `L²` norm is exactly the same for all members because the area form is pointwise identical. The min–max principle gives the same multiplicative comparison for every ordered eigenvalue. For each of the finitely many centers, the ordinary surface Weyl law gives `λ_j(h_i)/j→4π/Area(h_i)=1`. Taking the maximum of their finite thresholds and then letting `δ→0` proves the displayed uniform law.

Only `C⁰` precompactness and a common area measure are used in this step. In particular, this lemma does not give uniform eigenvalue gaps, frame bounds, crossing slopes, IFT radii, or PDE transfer constants; N175 must retain all its separate fixed-cutoff estimates.

## 2. Rank-band mean and endpoint arithmetic

Use the source indexing `B_M=(M+1)²`, with the constant eigenfunction at position 1. Given a uniform-Weyl tolerance `δ_n→0`, choose `J_n` so `λ_j(h)≤(1+δ_n)j` for every `h∈K`, `j≥J_n`. For cone frequency

`d(x)=(√(1+4x)−1)/2`,

we have `d(x)≤√x`. Since the radial factor `b(t)=f(e^t)/e^t` tends to `a` (and in the concave capped construction is at least `a`), the frequency for rank `j` is bounded by

`d(b(t)^{-2} λ_j(h)) ≤ a^{-1}√(1+δ_n) √j`

on the band, once its lower rank exceeds `J_n`. Exact cycle averaging then gives the uniform upper bound

`β_n ≤ a^{-1}√(1+δ_n) [Σ_{j=B_{M_{n−1}}+1}^{B_{M_n}} √j] / [B_{M_n}−B_{M_{n−1}}]`.

Writing `θ_n=M_{n−1}/M_n`, Euler summation gives

`β_n/M_n ≤ (2/(3a))√(1+δ_n) (1−θ_n³)/(1−θ_n²) + O(1/M_n)`.

The quotient is `1+θ_n²/(1+θ_n)`. Thus `δ_n→0`, `θ_n→0`, and `M_n→∞` imply `β_n/M_n→2/(3a)`. The coefficient `2/3` is the average of `√j` over the full rank interval, equivalently the same leading cubic-over-quadratic ratio as N175's `F(M)` count.

For an explicit margin argument, preassign `ε_n↓0` with `ε_1<1−2/(3a)` (possible since `a>2/3`). Choose the Weyl tolerance `δ_n=o(ε_n)`, require `θ_n²=o(ε_n)` and `1/M_n=o(ε_n)`, and set `q_n=2/(3a)+ε_n`. Then, by shrinking constants if necessary, `β_n/M_n≤2/(3a)+ε_n/2<q_n`. Choose `M_n` still larger to make `q_n M_n` strictly increasing. It follows that `k_n=ceil(q_n M_n)` is strictly increasing and `β_n<k_n` for every band. Because `q_n→2/(3a)>0`, `k_n→∞`.

N175's countable construction supplies `B_{M_n}−B_{M_0}` independent functions whose growth exponents come from bands `1,…,n`. Each band `i` has exponent below `k_i`; monotonicity gives `H_{k_i}⊂H_{k_n}` for `i≤n`. Therefore

`h_{k_n}(g)/(k_n+1)² ≥ [B_{M_n}−B_{M_0}]/(ceil(q_n M_n)+1)² → 1/(2/(3a))² = 9a²/4`.

Only a limsup follows, along the sparse sequence `k_n`.

## 3. Noncircular compact family and the source's all-pairs quantifier

The direct Weyl argument is valid only after one has a fixed `K`; defining `K` as the closure of links selected using future `M_n`, and then selecting `M_n` using `K`'s Weyl threshold, leaves a circular quantifier unless a cutoff-independent bound is added.

A noncircular construction is available under the pinned source inputs:

1. Fix a sequence of increasingly small smooth neighborhoods `U_m` of round. For each fixed `m`, Lemma 2.5 applies to `U_m` and all sufficiently large source degrees, with one threshold uniform over every adjacent pair in the stated band.
2. To see the all-adjacent-pair scope explicitly, let `ℓ` be the round degree. For large `ℓ`, set the paper's integer `k=ℓ−1`, `L=ℓ−1`, and `M=⌊ϑ(ℓ−1)⌋` for fixed `ϑ>1`. Then `M≥ℓ+1`. Every adjacent pair internal to degree `ℓ` and the boundary pair at rank `B_ℓ` satisfy `B_L+1≤i<p=B_M`; thus Lemma 2.5 covers both kinds. Its threshold `k_0(U_m)` gives one degree threshold `R_m` for all these pairs. The paper explicitly treats cross-block pairs by the even perturbation and within-block pairs by full-block splitting; it does not leave consecutive round-degree boundaries out.
3. Diagonalize the fixed neighborhoods: choose increasing `R_m` and assign each high pair of degree `ℓ` the largest `m(ℓ)` with `R_m≤ℓ`. Then `m(ℓ)→∞`, so detours can be selected in neighborhoods shrinking to round in every fixed smooth norm. The paper's cross-block seed `w_ℓ=log(1−(3/2)ψ/ℓ)` tends to zero in each fixed `C^q`; its within-block diagonal splitting can be arbitrarily small, and its remaining finite-cutoff/double-preserving perturbations can be made arbitrarily small. The later POST_SOURCE_STATUS reports a diagonal `C^ℓ` budget for these corrections.
4. Include the fixed compact simple-spectrum stem and every selected detour and controlled-link box in a **Weyl umbrella family** `K_W`. Normalize the finite crossing/control directions in the corresponding finite smooth norm, and impose a cap tending to zero with `m(ℓ)`. The high-degree detours and their controls then converge to round in every fixed spatial `C^q`; the finite early family is compact. The resulting closure is `C∞`-compact (or, for Weyl alone, it suffices to establish `C⁰` precompactness). The fixed-area gauge makes every member have exactly the same `4π dμ`.
5. The global all-pair umbrella may include crossings at ranks that will later be chosen as band boundaries. It therefore must **not** be used as the active transfer path family for a selected cutoff: those crossings would destroy its protected outer gap. After selecting `M_n`, define the band-`n` active transfer skeleton by including only the designated internal adjacent-pair loops in `I_n` (and excluding loops at each boundary `B_{M_n}`), as N175 requires. The Weyl bound on `K_W` restricts to this active subfamily; spectral-gap, frame, and PDE transfer estimates remain separate and must be proved on the active skeleton.
6. Apply uniform Weyl to the prebuilt `K_W`. Only now choose the endpoints `M_n`, using one-step look-ahead: place each lower band endpoint `M_{n−1}` beyond the uniform spectral cutoff `J_n`, the source crossing-neighborhood threshold for band `n`, and its other finite transfer thresholds; then choose `M_n` arbitrarily larger to make `θ_n` and the band errors small. Since all cutoffs and thresholds are finite and the fixed-point/stage scheme allows arbitrarily late starts, this does not add an upper constraint.

This uses a diagonal of **fixed** neighborhoods, not a claim that one variable shrinking neighborhood is covered directly by one fixed-threshold lemma. The source Lemma 2.5 quantifier is enough for the diagonal if accepted: for each fixed `U_m`, all sufficiently high adjacent pairs are available uniformly. The exact-double and finite-cutoff avoidance constructions must still preserve the prescribed shrinking neighborhood; that is part of the source S1–S3 interface and the N175 skeleton construction, not a consequence of Weyl theory.

## 4. Compatibility with transfer, phases, and countable fixed point

- In PROOF_v3 §§0–8, fixed `q` is used to choose the integer growth threshold `k_n=ceil(qM_n)` and establish `β_n<k_n`; it does not enter the spectral crossing controls or the local PDE graph, matching, fixed-point, or radial Ricci estimates.
- The uniform Weyl umbrella must cover every link value actually used by each active reference cycle and every allowed crossing-control box, not just the initial stem or uncontrolled reference metrics. However, the umbrella's global union of all possible pair crossings need not have the protected boundary gaps. Those gaps belong to the cutoff-specific active transfer skeleton after boundary-crossing loops are omitted. Uniform Weyl supplies a frequency upper bound only; source protected boundary gaps, all-other-simple active loops, frame estimates, and whole-ball transfer remain needed.
- The endpoint `ε_n` may shrink with `n`: N175's transfer estimates are fixed-band, and at any stage `m` only finitely many bands `n≤m` are active. No degree-uniform transfer constant is required. Require the positive band margin `q_n−β_n/M_n` when selecting that band's cutoff; each band then has its own strict growth slack.
- Keep the full label-period `Q_m` and the source support-comparability/averaging inequalities, including `D_m Q_m S_m T_m^{-1/4}` small. `M_n` can make `Q_m` enormous but finite; `T_m` has no upper bound and may be chosen later to meet finitely many conditions. Shrinking `ε_n` changes no control equation. No argument here yields effective or practical stage sizes.
- The countable product/Brouwer fixed point is essential to the “same single metric” conclusion: it solves all band controls simultaneously. Replacing `q` by `q_n` does not change its equations, but the endpoint claim is not proved unless that already conditional fixed-point argument is valid.

## 5. Source-input and significance limits

The target paper's Lemma 2.5 supports the all-high-rank gate needed for the diagonal skeleton. Nevertheless, the endpoint proof remains conditional on the full N175 interface: S1 finite-cutoff path avoidance in the fixed-area gauge; S2 exact-double retention, nonzero split/coupling variation and all-other-simple construction; S3 every adjacent pair including cross-block pairs in prescribed neighborhoods; and the remaining Ricci, graph, matching, countable fixed point, and weighted averaging arguments. The later Astra POST_SOURCE_STATUS reports internal audits for S1–S3 and integration, but it explicitly stops short of formal certification or external specialist validation. This audit verifies the stated source quantifier mapping for Lemma 2.5 and the endpoint algebra; it does not independently certify the complete countable transfer proof.

Significance should be stated narrowly. The prior OpenAI/math paper proves a metric depending on each large degree. N175's claimed conditional extension is one metric serving an unbounded degree sequence. The `q_n` change would refine that one-metric claim from “for each `c<9v/4`, limsup is greater than `c`” to the endpoint limsup lower bound `≥9v/4` for the constructed metric (indeed the schedule can be chosen from `v` without a `c`). Once the compact family is fixed, this last endpoint passage is routine asymptotic bookkeeping; the substantive burden is the countable one-metric transfer, not the Weyl/epsilon trick. No historic novelty/priority label, universal sharpness claim, or unconditional rigor claim is warranted here.
