# Independent audit: slow polar gluing and radial barrier

Date: 2026-10-09  
Target: `slow_polar_gluing_and_radial_barrier.md`  
Scope: independent calculation check, admissibility/compatibility check, and primary-literature novelty screen. This is a technical review, not a priority claim or specialist sign-off.

## Executive verdict

1. **Rotationally symmetric harmonic-function barrier:** the ODE, sign, dimension upper bound, and positive-AVR leading coefficient check out in the stated warped-product class. Minor proof exposition should make the positivity bootstrap for `w_l` explicit.
2. **Slow-link Ricci calculation:** radial and tangential Gauss–Codazzi formulas check after accounting for the common-area-form condition. The mixed Ricci formula is correct in coordinate components, but the stated unit-frame norm drops a factor `rho^{-1}` (equivalently the squared Schur term drops `rho^{-2}`) if `div_h E` is measured in the `h` norm. This makes the displayed `m` buffer insufficient as written for arbitrary small `rho`.
3. **Repair is available and noncircular:** fix `rho_min=rho(s0)/2` first, choose the buffer using `rho_min^{-2}`, and then choose transition widths so the total forcing is small. A bootstrap for `w=-u` proves `rho>=rho_min`, preserving the estimate used to select the buffer.
4. **After that repair:** the cap, completeness, positive AVR, and subsequential cone convergence are compatible and appear viable. An explicit nonisometric pair with a common pointwise area form exists by a small trace-free volume-preserving perturbation of the round sphere.
5. **Novelty:** the broad phenomenon and much of the mechanism are already covered by Colding–Naber. Their peer-reviewed paper, GAFA 23 (2013), Theorem 1.4, explicitly asserts smooth open manifolds of every dimension `n>=3` with `Ric>=0`, Euclidean volume growth, and distinct asymptotic cones. Their Lemma 2.1 is a close radial link-gluing mechanism: constant pointwise volume form on the link path, a slowly varying link parameter, a radial scale factor with positive limit, and direct Ricci estimates. Do not present 3D smooth nonuniqueness or the general link-gluing idea as new. The exact elementary finite-forcing ODE presentation, or a more narrowly prescribed pair of smooth `S^2` links, may be a distinct exposition/construction, but this audit establishes no priority claim.

## 1. Rotational warped-product section

For `g=dr^2+f(r)^2 g_{S^2}`, the standard smooth-pole conditions are `f(0)=0`, `f'(0)=1` plus the usual odd smooth expansion. The radial Ricci equation is `Ric_rr=-2f''/f`, so `Ric>=0` gives `f''<=0`. Since `f` remains positive for all `r>0`, concavity forces `f'>=0`; otherwise a negative derivative would persist and eventually force `f` below zero. Thus `f'` decreases to `a>=0`, `f(r)/r -> a` by Cesàro averaging, and `f(r)>=r f'(r)`. Also `f(r)<=r` from `f'<=1`. The radial volume formula gives `AVR=a^2`.

For a spherical harmonic of degree `ell>=1`, `u` solves

`(f^2 u')' = ell(ell+1)u`.

Substituting `u=r^ell w` gives the displayed divergence-form equation in the target note. Its bracket is nonpositive because `rf'/f<=1` and `f<=r`. Near the pole, regularity gives `w->1` and `f^2 r^(2ell)w'->0`. To conclude `w'>=0`, use a first-zero/bootstrap argument: while `w>0`, the ODE makes `(f^2r^(2ell)w')'>=0`; hence `w'>=0` and `w>=1`, ruling out a first zero. Therefore `u_ell>=r^ell` after unit normalization.

For any global harmonic function with `O(r^d)` growth, each spherical Fourier coefficient has that same growth bound, so the coefficient of every regular mode with `ell>d` must vanish. Summing multiplicities gives `dim H_d <= sum_{ell=0}^{floor d}(2ell+1)=(floor d+1)^2`.

When `a>0`, the Riccati equation for `q_ell=ru'_ell/u_ell` is correct. Its coefficients converge to the autonomous field `-q-q^2+ell(ell+1)/a^2`, whose positive equilibrium is

`p_ell=(-1+sqrt(1+4ell(ell+1)/a^2))/2 = ell/a+O(1)`.

Standard asymptotically autonomous scalar-ODE comparison (first establish boundedness of positive `q`) gives `q->p_ell`, hence `u_ell=r^(p_ell+o(1))`. All modes with `p_ell<d` are in `H_d`, modes with `p_ell>d` are out, and at most one boundary shell contributes `O(d)`. The count is `a^2 d^2+o(d^2)`. If `a=0`, the Riccati forcing `ell(ell+1)(r/f)^2` tends to infinity, forcing `q_ell->infinity` for each fixed `ell>=1`; each nonconstant regular mode is superpolynomial. The claim that only constants have finite polynomial growth follows.

## 2. Gauss–Codazzi calculation and the scale correction

Write the induced metric on `r=const` as `G_r=r^2 rho(s)^2 h_s`, `s=log r`, and define

`E=1/2 h^{-1} dot h`, `u=dot rho/rho`, `A=(1+u)I+E`.

The common pointwise area form implies `tr E=0`. The shape endomorphism and mean curvature are

`S=r^{-1}A`, `H=2(1+u)/r`.

The standard radial-foliation identities are

`Ric_rr=-H'-tr(S^2)`,  
`Ric_T = Ric(G_r)-S'-H S`,  
`Ric(r,.) = div_G S-dH`.

They yield

`Ric_rr = r^-2[-2(u'+u+u^2)-|E|_h^2]`.

For tangent vectors, as an endomorphism (the omitted common dimensional factor is `r^-2`),

`Ric_T = r^-2{[K_h/rho^2-(1+u)^2]I + (Phi+m)I/2 -(1+2u)E-dot E}`

provided `u'+u+u^2=-(Phi+m)/2`. Thus `Ric_rr>=m/r^2` when `Phi>=sup|E|^2`. The sign of the `dot E` and `(1+2u)E` terms agrees with the target note.

For the mixed term, with the convention `(div_h E)_i= nabla_j E^j_i`, the **coordinate** component is

`Ric_{ri}=r^-1 (div_h E)_i`.

A `g`-unit tangent frame vector is `e_a=r^-1 e_{eta,a}`, where `e_{eta,a}` is `eta=rho^2h`-unit. Since a covector norm rescales by `|.|_eta=rho^-1|.|_h`, the orthonormal mixed block satisfies

`|Ric(e_r,.)| <= r^-2 rho^-1 sup|div_h E|_h`.

If the angular block is `>=delta/r^2`, the Schur complement therefore requires

`m >= delta^-1 rho^-2 sup|div_h E|_h^2`.

The target's `m >= 2 delta^-1 sup|div_h E|_h^2` omits `rho^-2`; the factor cannot be discarded when `rho<1`. If the author instead defines divergence norms using `eta`, the formula should say so explicitly; then the divergence bound is `sup|div_eta E|_eta^2=rho^-2 sup|div_h E|_h^2`.

## 3. Noncircular corrected buffer/ODE bootstrap

A safe proof can select all constants in this order:

- Choose the cap and start radius `s0` first. Arrange `rho0:=rho(s0)<1`, `kappa0/rho0^2>1+2delta`, and initial `w0:=-u(s0)>0` as small as desired (take `s0` far out in the affine cap tail).
- Fix `rho_min:=rho0/2` before solving the forced ODE.
- On transition `j`, choose smooth endpoint-flat path parameter `theta_j` over width `T_j`. Uniform path bounds give `|E|<=C|theta'_j|/T_j`, `|dot E|+|div_h E|<=C|theta'_j|/T_j` (with the second-s derivative in `dot E` actually `O(T_j^-2)` under the fixed smooth profile).
- Choose smooth envelopes `Phi_j=C0|theta'_j|^2/T_j^2` and `m_j=C1 rho_min^-2 delta^-1 |theta'_j|^2/T_j^2`, with constants large enough to dominate the indicated suprema. Both vanish to all orders at the transition endpoints. Then `F=Phi+m` has `integral F <= C(rho_min,delta) sum_j T_j^-1`; make this as small as needed by scaling the widths so the reciprocal sum is small. The plateau lengths can separately tend to infinity.
- Solve `w'=-w+w^2+F/2`, `w(s0)=w0`. At `w=0`, the vector field is nonnegative, so `w>=0`. Bootstrap on `w<=1/2`; there

  `w(t)<=w0 exp(-(t-s0)/2)+(1/2) integral_{s0}^t exp(-(t-s)/2)F(s) ds`,

  hence `sup w<=w0+(1/2)integral F` and `integral w<=2w0+integral F`. Choose `w0+(1/2)integral F<1/2` and `2w0+integral F<log 2`. The first inequality closes the `w<=1/2` bootstrap; the second gives

  `rho(s)=rho0 exp(-integral_{s0}^s w) >= rho0 exp(-(2w0+integral F)) > rho0/2=rho_min`.

  Thus the preselected `m` buffer really dominates the `rho^-2` Schur term. There is no assumption of the limit of `rho` in selecting `m`.
- The same bootstrap implies `rho` is monotone decreasing to `rho_infty>0`. For `0<=w<=1/2`, `(1+u)^2=(1-w)^2<=1`. Since `rho<=rho0` and `K_h>=kappa0`, the isotropic angular margin is at least `kappa0/rho0^2-1>2delta`; by making `E` and `dot E` small, keep the complete angular block `>=delta/r^2`.

This fixes both the missing scale factor and the potential circularity: the buffer uses a fixed lower bound established by a bootstrap after choosing a small total forcing.

## 4. Admissible links, cap, and blowdowns

A concrete common-area pair exists. Let `h0` be the unit round metric, choose a smooth degree-2 spherical harmonic `phi`, and let `T=(Hess phi - (Delta phi/2)h0)` be its trace-free Hessian. Set `A=h0^-1 T` and

`h_epsilon(v,w)=h0(exp(2 epsilon A)v,w)`.

Because `tr A=0`, `dA_{h_epsilon}=dA_{h0}` pointwise. For small nonzero epsilon, `h_epsilon` is `C^2`-close to round, so its Gauss curvature stays uniformly positive. Its curvature is nonconstant for suitable `phi`: the first scalar-curvature variation of the trace-free perturbation is proportional to `div div T`, which is a nonzero multiple of the degree-2 harmonic. Thus it is not isometric to the round link. The path with `epsilon` replaced by `t epsilon` preserves the same area form and has a uniform positive curvature lower bound for `t∈[0,1]`. Reversing it supplies alternating transitions.

For a cap, take a smooth nonincreasing `f'` with `f'(0)=1`, `f'=a` for large `r`, and `0<a<1`; integrate with `f(0)=0`. Then `f=ar+b` eventually with `b>0`. The cap metric `dr²+f²g_{S²}` has

`Ric_rr=-2f''/f>=0`,  
`Ric_tan=(1-(f')²-ff'')g_{S²}/f²>=0`.

In its affine tail `rho=f/r`, `u=rf'/f-1<0` solve the zero-forcing ODE exactly. Choose `a` below the curvature threshold and start at a sufficiently large radius so `rho0<1`, `kappa0/rho0²>1+2delta`, and `w0=-u(s0)` is small. Keep `h_s` round before the first transition, with flat-ended transitions thereafter; this gives smooth matching at the cap and pole and a complete metric on `R^3`.

Because the pointwise area form is fixed, `Area(h_s)=A` for all `s`; the volume of a pole-centered ball is exactly

`Vol B_R = A integral_0^R r^2 rho(log r)^2 dr`.

Thus `AVR=A rho_infty^2/(4pi)>0`. For plateau centers `s_j` with lengths tending to infinity, choose blowdown scales `R_j=e^{s_j}`. For every fixed annulus `epsilon<=t<=epsilon^-1`, `h_{s_j+log t}` is exactly the plateau link for large `j`, while `rho(s_j+log t)->rho_infty` uniformly. The rescaled metrics converge smoothly on such annuli to `dt²+t²rho_infty² h_i`; radial-distance control at the tip upgrades this to pointed GH convergence of the full blowdowns. If `h0,h1` are nonisometric, the cone links `rho_infty²h0,rho_infty²h1` are nonisometric, so the two pointed metric cones are distinct.

## 5. Literature and scope correction

The target file currently says its search found Perelman's 4D example and Colding–Naber 3D Ricci-limit-space examples but had not established a direct smooth 3D asymptotic-cone example. This misses a stronger primary source:

- Tobias H. Colding and Aaron Naber, “Characterization of Tangent Cones of Noncollapsed Limits with Lower Ricci Bounds and Applications,” *Geometric and Functional Analysis* 23(1) (2013), 134–148, DOI: [10.1007/s00039-012-0202-7](https://doi.org/10.1007/s00039-012-0202-7), arXiv [1108.3244v3](https://arxiv.org/pdf/1108.3244).
- Its Theorem 1.4 (PDF pp. 2–3) explicitly states: for every `n>=3`, there is a smooth open `n`-manifold with `Ric>=0` and Euclidean volume growth having tangent cones at infinity `R^k x C(X)` for each `0<=k<=n-2`, with `X` smooth and not isometric to the standard sphere. In `n=3`, the `k=0` and `k=1` cases furnish distinct cones: the first has a smooth nonspherical 2-link, while the second splits a line and its 1-link is nonstandard. The paper’s introduction says these splittings are precise. So smooth 3D nonuniqueness at infinity is established well before this note.
- More directly relevant to the proof mechanism, their Lemma 2.1 and formulas (5)–(8) use a family `g(s)` of closed links with `d/ds dv(g(s))=0`, link Ricci lower bound, bounded slow derivatives, and a radial ansatz `dr²+r² h(r)² g(f(r))`, yielding `Ric>=0` while `h(r)` tends to a positive limit. This overlaps the conditional “slow-link gluing” idea very substantially. In dimension 3, a uniform positive `K_h` path can be scaled by a fixed constant so `Ric(g_s)>=g_s`, and the common pointwise area form is precisely their constant-volume-form hypothesis. Time-stretching enforces derivative bounds. Their construction therefore supplies a strong prior-art warning even for a two-link oscillation specialization.
- Their theorem statement says “smooth open manifold,” not explicitly “`R^3`.” The link-based construction uses a Ricci-closable spherical link in the relevant realization, and the round small-sphere cap in the present note is explicit; but do not overstate the precise topology comparison without checking the theorem’s construction details.
- Perelman’s 1997 example is indeed ambient dimension 4 with `S^3` principal links, and is not the key missing citation here. Colding–Naber’s 3D local Ricci-limit-space example is also accurate but less directly relevant than their Theorem 1.4.

**Novelty conclusion:** remove any implication that the broad smooth-3D existence result is new. At most, characterize the present result as an elementary explicit ODE-based variant/specialization, subject to a corrected Schur buffer and expert review. The radial harmonic-growth calculation is independent of this cone-gluing literature, but no priority finding is made for it.
