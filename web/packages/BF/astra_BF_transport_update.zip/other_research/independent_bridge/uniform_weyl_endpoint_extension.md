# Conditional endpoint extension of N175 by compact-family Weyl asymptotics

Date: 2026-10-09. This records a proof modification, not an independent
validation of the source construction or a priority claim.

## Source and target

The source is OpenAI/math at `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`,
paper `preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf`, and the pinned coordination proof is Astra at
`031ce532f7f6d1c070387f6213a00204893be79d`,
`web/pages/d-413da5591afd120a.html` (`COMMON-METRIC TRANSFER: AUTHORITATIVE VERSION 3`), §§0–8.

The source theorem fixes a constant `C_*>1` and a constant
`q>2 sqrt(C_*)/(3a)`; its band estimate has leading constant
`2 sqrt(C_*)/(3a)`. The source's conditional conclusion is for each fixed
`c<9a^2/4`, a possibly `c`-dependent one-metric limsup greater than `c`.
The following change appears to make the same one-metric construction attain
the endpoint `9a^2/4` as a limsup, provided the full N175 geometric inputs and
transfer proof are valid.

## Uniform Weyl lemma

Let `K` be the compact family of link metrics asserted in source §1/§3,
including all allowed controlled links. Suppose every `h in K` has the same
pointwise area form `dmu`, with total area `4 pi`. Write `lambda_j(h)` for the
ordered function-Laplacian eigenvalues, indexed starting with the constant
eigenfunction at `j=0` or `j=1` consistently. Then

`sup_{h in K} |lambda_j(h)/j - 1| -> 0` as `j -> infinity`.

Proof: for any `eps>0`, cover compact `K` by finitely many C0-balls centered
at `h_1,...,h_N`, with radii small enough that metrics in one ball satisfy
`(1-eps) E_{h_i}(u) <= E_h(u) <= (1+eps) E_{h_i}(u)` for every smooth `u`.
The L2 norm is identical because the pointwise area form is identical.
The min-max principle gives the same comparison for every eigenvalue. Each
center obeys the ordinary two-dimensional Weyl law
`lambda_j(h_i)/j -> 4 pi/Area=1`. Taking the maximum of the finitely many
thresholds and then sending `eps` to zero proves uniformity. The indexing
offset by one is immaterial asymptotically.

This argument needs C0-precompactness and fixed area form, not bounds on
curvature derivatives beyond those used to establish the source's compact
family. If source K's compactness is not accepted as proved, it is enough to
verify its stated decomposition: a fixed compact stem plus finitely many
finite-dimensional controlled families at each of finitely many early bands,
and links converging uniformly to round for later bands.

## Replacing the fixed margin

Set `a=sqrt(v)`. Let `B_M=(M+1)^2`, and let band `I_n` have ranks
`(B_{M_{n-1}},B_{M_n}]`. By uniform Weyl, choose `delta_n -> 0` and cutoffs
`J_n` such that for every `h in K`, `lambda_j(h) <= (1+delta_n)j` for
`j>=J_n`. The cone frequency obeys

`d(a^{-2} lambda) = (sqrt(1+4 a^{-2} lambda)-1)/2 <= sqrt(lambda)/a`.

Consequently its band phase mean is bounded by

`beta_n <= sqrt(1+delta_n)/a * [sum_{j=B_{M_{n-1}}+1}^{B_{M_n}} sqrt(j)] / [B_{M_n}-B_{M_{n-1}}]`.

Euler summation yields, for `theta_n=M_{n-1}/M_n`,

`beta_n/M_n <= (2/(3a)) sqrt(1+delta_n) * (1-theta_n^3)/(1-theta_n^2) + O(1/M_n)`.

Choose `M_{n-1}` beyond `sqrt(J_n)` and the source's finitely many
band-`n` crossing thresholds; choose `M_n` so fast that `theta_n -> 0`, the
displayed right side is strictly less than
`q_n := 2/(3a)+epsilon_n`, and `q_n M_n` is strictly increasing, where
`epsilon_n -> 0` is any sequence slower than the resulting Weyl and
Euler-summation errors. Then put `k_n=ceil(q_n M_n)`. This gives
`beta_n<k_n` for all sufficiently large `n`; finitely many initial bands
can be assigned larger `q_n` or omitted from the lower-bound count.

No other use of the fixed `q` is apparent in §§1–8: it only sets `k_n` and
establishes `beta_n<k_n`. Every transfer/compactness constant and stage
threshold is fixed-band or finite-stage, so the stage argument should remain
unchanged after replacing those values by `q_n`. At degree `k_n`, all earlier
band functions are also counted because `k_n` can be forced increasing and
`H_{k_j} subset H_{k_n}` for `j<=n`. The source's dimension count then gives

`h_{k_n}/(k_n+1)^2 >= [B_{M_n}-B_{M_0}]/(ceil(q_n M_n)+1)^2 -> 1/(2/(3a))^2 = 9a^2/4`.

Thus the proposed endpoint statement is
`limsup_{k->infinity} h_k(g)/(k+1)^2 >= 9 AVR(g)/4`, for a single metric
with prescribed `4/9<AVR(g)<1`, conditional on N175's S1–S3 and all its
countable transfer steps.

## Exact audit obligations / caveats

1. Verify that the compact link family in §§1/3 includes *every* controlled
   link actually used in the fixed-point construction and has exactly the
   common pointwise area form. This makes the uniform Weyl lemma applicable.
2. Verify recursive band selection is genuinely noncircular when `J_n` is
   taken from that family. A clean route is the K-first diagonal construction
   below; this is stronger than merely appealing to a K whose compactness was
   shown after band selection.
3. Check that the chosen `epsilon_n` can dominate both `delta_n` and
   `theta_n^2` while `M_{n-1}` is already set. Recursive look-ahead can select
   `M_{n-1}` beyond the next band's `J_n`; the previous `M_{n-2}` is free to
   have been chosen arbitrarily large, so `M_{n-1}/M_n` can then be made as
   small as needed.
4. Check that source Step 6's finite timing requirements and Step 7's matching
   use only `beta_n<k_n`, not a globally fixed q. The displayed text suggests
   they do, but this is the main construction-level audit rather than a formal
   proof certificate.
5. N175 remains conditional on finite source inputs S1–S3 and is internally
   source-reported, not externally validated. No claim is made here that the
   endpoint is a publishable or novel theorem, nor that `9v/4` is a universal
   upper bound.

## K-first diagonal schedule addressing threshold circularity

The bands should not be chosen before the family used in the Weyl lemma is
fixed. Instead:

1. Choose the common all-spectrum-simple stem once. For every adjacent rank
   pair `r,r+1` above a fixed low cutoff, choose one isolated-double loop and
   one splitting direction. The source S3 / §§1–3 provide loops for every
   sufficiently high adjacent pair in arbitrarily prescribed *fixed* smooth
   neighborhoods of round. By diagonalization, choose thresholds `R_m` so
   that for every `r>=R_m`, the complete detour and its direction, after
   normalization, lie in C^{m+2}-distance at most `2^{-m}` from round / zero.
   Let `m(r)=max{m:R_m<=r}` (increase the thresholds strictly). Then
   `m(r)->infinity`, and for each fixed q the rank-r detours and controlled
   perturbations converge to round in C^q. For the control direction use
   C^{m(r)+2} norm at most one and a pre-fixed amplitude cap `2^{-m(r)}`.
   Scaling does not erase the crossing: every cap is positive, so the signed
   first-variation coefficient remains nonzero. For each finite band its
   minimum may be very small but positive and can be accommodated by the
   nonquantitative later stage threshold.
2. The union of the fixed stem, the finitely many low-rank loop/control
   families, and the high-rank detours/control boxes has compact closure in
   C-infinity. Indeed a sequence with rank tending to infinity converges to
   round in every fixed seminorm; bounded finite-rank control boxes are compact.
   Denote this fixed family by K. It is selected independently of every M_n.
3. Apply the uniform Weyl lemma to K and choose `delta_n->0` and `J_n` in
   advance. Also choose R_n to ensure every crossing used in band n lies in
   the small `C^{n+2}` neighborhood required by the transfer proof.
4. Choose M_{n-1} only when constructing the previous band's upper endpoint,
   with finite look-ahead: impose `B_{M_{n-1}} >= J_n`, `M_{n-1}>=R_n`, and
   all of the source's finite crossing thresholds for band n. Since all are
   lower bounds on M_{n-1}, this does not conflict with choosing it arbitrarily
   large for band n-1's averaging margin. Then choose M_n still larger to make
   `M_{n-1}/M_n` as small as desired and ensure `beta_n<q_n M_n`.

This removes the main apparent dependency loop: K and its Weyl thresholds are
fixed before the M sequence. The source already uses the same finite-lookahead
logic for the next band's crossing thresholds. The remaining source-level check
is whether the stated S3 convergence holds for all high adjacent pairs uniformly
past each fixed smooth-neighborhood threshold, including within-round-block
pairs, and whether positive rescaling of the directions preserves every local
Step 5–7 signed estimate. The latter should only change band-dependent positive
constants, but it has not been fully audited here.
