# Independent geometry bridge: radial barrier and slow-link gluing

Status: self-derived calculations on 2026-10-09; not externally reviewed, not a priority claim, and not an independent validation of the Astra/OpenAI candidate manuscripts. The point is to isolate a checkable geometric mechanism outside the quantum, algebraic-log and choiceless-complexity lanes.

## 1. Exact barrier for rotationally symmetric 3-manifolds

Let

\[
(M^3,g)=([0,\infty)\times S^2,\; dr^2+f(r)^2g_{S^2})
\]

be smooth at the pole, complete, and satisfy \(\mathrm{Ric}_g\ge0\). Then \(f(0)=0\), \(f'(0)=1\), and the radial Ricci component gives \(f''\le0\). Since \(f>0\) at every positive radius, concavity implies \(0\le f'(r)\le1\). Consequently

\[
0<f(r)\le r,\qquad r f'(r)\le f(r),\qquad
 a:=\lim_{r\to\infty}f'(r)=\lim_{r\to\infty}f(r)/r\in[0,1].
\]

The asymptotic volume ratio is \(\mathrm{AVR}(M)=a^2\).

For degree \(\ell\ge1\), the regular radial coefficient of a harmonic function in a spherical-harmonic mode solves

\[
(f^2u_\ell')'=\ell(\ell+1)u_\ell,\qquad
u_\ell(r)=r^\ell w_\ell(r),\quad w_\ell(r)\to1\text{ at }0.
\]

A direct substitution yields

\[
\big(f^2r^{2\ell}w_\ell'\big)'
+f^2r^{2\ell}\,\ell\!\left[
\frac{2f'}{fr}+\frac{\ell-1}{r^2}-\frac{\ell+1}{f^2}
\right]w_\ell=0.
\]

The bracket is nonpositive: \(rf'/f\le1\) and \(f\le r\) imply it is at most
\(\ell[2+(\ell-1)-(\ell+1)]/r^2=0\). The regular initial asymptotics give
\(f^2r^{2\ell}w_\ell'\to0\) and \(w_\ell\to1\) at the pole. Positivity and the displayed ODE therefore imply \(w_\ell'\ge0\), hence \(u_\ell(r)\ge r^\ell\).

It follows that every globally harmonic function of growth \(O(r^d)\) has no angular modes \(\ell>d\); taking spherical Fourier coefficients bounds each mode by the global supremum. Thus

\[
\dim\mathcal H_d(M)\le (\lfloor d\rfloor+1)^2.
\]

This rules out any integer-degree excess within the entire rotationally symmetric class, without requiring positive AVR.

A sharper leading-order statement holds when \(a>0\). Set \(s=\log r\) and \(q_\ell=ru_\ell'/u_\ell\). Then

\[
\dot q_\ell=q_\ell\left(1-2\frac{rf'}f\right)
+\ell(\ell+1)\left(\frac rf\right)^2-q_\ell^2.
\]

As \(r\to\infty\), \(rf'/f\to1\), \(r/f\to1/a\); scalar ODE comparison gives
\(q_\ell\to p_\ell\), where \(p_\ell(p_\ell+1)=\ell(\ell+1)/a^2\). Thus \(u_\ell(r)=r^{p_\ell+o(1)}\). Modes with \(p_\ell<d\) lie in \(\mathcal H_d\), and modes with \(p_\ell>d\) do not. The possible equality boundary contributes at most one multiplicity block \(O(d)\). Since \(p_\ell=\ell/a+O(1)\),

\[
\dim\mathcal H_d(M)=a^2d^2+o(d^2)=\mathrm{AVR}(M)d^2+o(d^2).
\]

If \(a=0\), then \(r/f\to\infty\). The Riccati equation forces \(q_\ell\to\infty\) for every \(\ell\ge1\), so each nonconstant regular mode is superpolynomial and \(\mathcal H_d\) consists only of constants for finite \(d\).

### What this does and does not screen out

It makes explicit why a radial warped-product ansatz cannot realize the fixed-factor harmonic-dimension excess in the pinned OpenAI/math 3D paper: its leading coefficient is exactly the volume ratio \(a^2\le1\). Any stronger construction has to use angular geometry, not just a variable radial warping function.

## 2. A conditional, dimension-three slow-switching lemma for cone links

There is a separate geometric mechanism that appears to let angular link metrics oscillate forever while spending only finite radial Ricci budget. This is a candidate proof lemma; the tensor calculation is included so a reviewer can inspect the decisive step.

Let \(h_s\) be a smooth path of metrics on \(S^2\), with the *same pointwise area form* for every \(s\). Define

\[
\bar E_s=\tfrac12h_s^{-1}\dot h_s,
\qquad \mathrm{tr}\,\bar E_s=0.
\]

For a positive scalar \(\rho(s)\), set \(\eta_s=\rho(s)^2h_s\), \(u=\dot\rho/\rho\), and on \((0,\infty)\times S^2\) consider

\[
g=dr^2+r^2\eta_{\log r}.
\]

The shape operator of the spheres \(r=\mathrm{const}\) is
\(S=r^{-1}((1+u)I+\bar E)\), with mean curvature \(H=2(1+u)/r\). Direct Gauss--Codazzi contraction gives

\[
\begin{aligned}
\mathrm{Ric}_{rr}
&=r^{-2}\big[-2(u'+u+u^2)-|\bar E_s(x)|^2\big],\\
\mathrm{Ric}_{\mathrm{tan}}/\eta
&=\big[K_{h_s}/\rho^2-(1+u)^2\big]I
+\tfrac12(\Phi+m)I
-(1+2u)\bar E-\dot{\bar E},\\
\mathrm{Ric}_{r,\hat i}
&=r^{-2}(\mathrm{div}_{h_s}\bar E)_i,
\end{aligned}
\]
provided \(u\) is chosen to solve

\[
u'+u+u^2=-\tfrac12(\Phi(s)+m(s)),
\qquad \Phi(s)\ge \sup_{x\in S^2}|\bar E_s(x)|^2.
\]
Here \(\hat i\) denotes an \(\eta\)-unit tangential frame and \(m(s)\) is a nonnegative scalar buffer. Since \(\Phi\) is a uniform upper envelope, this gives \(\mathrm{Ric}_{rr}\ge m/r^2\) pointwise. The coordinate formula for \(\mathrm{Ric}_{ri}\) has an extra \(r^{-1}\); the unit-frame conversion supplies the second \(r^{-1}\), as displayed. The tangential formula is a quadratic-form identity; \(K_{h_s}\) is the Gauss curvature.

Assume a family \(h_s\) stays in a compact smooth path family with \(K_{h_s}\ge\kappa_0>0\), and transitions are time-stretched so that \(\|\bar E\|+\|\dot{\bar E}\|+\|\mathrm{div}\bar E\|\) are uniformly as small as desired. Choose \(\rho(s_0)<1\) with \(\kappa_0/\rho(s_0)^2>1+2\delta\) for some \(\delta>0\). Since \(u\le0\) and \(\rho\) only decreases, the angular Ricci block then remains \(\ge\delta r^{-2}\) for sufficiently slow transitions. Before choosing the buffer, fix a proposed lower bound \(\rho_{\min}>0\) for \(\rho\). Pick

\[
m(s)\ge 2\delta^{-1}\rho_{\min}^{-2}\sup_{x\in S^2}|\mathrm{div}_{h_s}\bar E_s(x)|^2
\]
with a smooth envelope. The Schur complement shows the full Ricci tensor is nonnegative once \(\mathrm{Ric}_{rr}\ge m/r^2\): the mixed unit-frame block has squared norm at most \(\rho_{\min}^{-2}\sup|\mathrm{div}\bar E|^2/r^4\), while the angular block has lower bound \(\delta/r^2\). The factor \(\rho_{\min}^{-2}\) is essential because converting the coordinate mixed component to an \(\eta=\rho^2h\)-unit frame contributes \(\rho^{-1}\). To close this without circularity, set \(\rho_{\min}=\rho(s_0)/2\) and choose total forcing small enough that the solution of the ODE for \(w=-u\) has \(\int w<\log 2\); then \(\rho\ge\rho(s_0)/2\) validates the preselected buffer. See `slow_polar_gluing_audit_2026-10-09.md` for a complete corrected bootstrap.

For a transition profile \(h_s=\widehat h(\theta((s-s_j)/T_j))\) on an interval of logarithmic width \(T_j\), take smooth envelopes \(\Phi(s)=C_0|\theta'|^2/T_j^2\) and \(m(s)=C_1|\theta'|^2/T_j^2\), with constants large enough for the uniform path bounds. Then \(\int(\Phi+m)ds=O(T_j^{-1})\). Taking \(\sum_jT_j^{-1}<\infty\) makes the total forcing \(F=\Phi+m\) integrable. For \(w=-u\),

\[
w'=-w+w^2+F/2.
\]

If initially \(0\le w(s_0)<1/4\) and \(\int F\) is sufficiently small, then \(0\le w(s)<1/2\) and
\(w'\le-w/2+F/2\). Hence \(\int_{s_0}^\infty w(s)ds<\infty\), so \(\rho(s)\to\rho_\infty>0\). The radial contraction is finite despite infinitely many angular transitions.

A radial cap can be attached before the first transition: take \(f(0)=0\), \(f'(0)=1\), \(f''\le0\), and make \(f(r)=ar+b\) for large \(r\), with \(a<1\). The warped cap \(dr^2+f^2g_{S^2}\) has
\(\mathrm{Ric}_{rr}=-2f''/f\ge0\) and
\(\mathrm{Ric}_{tan}=(1-(f')^2-ff'')g_{S^2}/f^2\ge0\). In its affine tail, \(\rho=f/r\) and \(u=rf'/f-1\) solve the zero-forcing ODE above. Start link variation at a large radius, where \(\rho<1\), \(u<0\), and \(u\) is small. Flat-ended time-stretched transitions preserve smooth matching.

If the link path alternates between two non-isometric positively curved metrics \(h_0,h_1\) of a common pointwise area form, and the corresponding constant-link plateaus have logarithmic lengths tending to infinity, then blowdowns centered in those plateaus converge to two distinct cones
\[
C(S^2,\rho_\infty^2h_0),\qquad C(S^2,\rho_\infty^2h_1).
\]
The cone-volume ratio is \(\rho_\infty^2\mathrm{Area}(h_i)/(4\pi)>0\). Distinctness follows because the metric link is recovered from the unit sphere about the cone tip. A concrete two-link input can be a small trace-free volume-form-preserving perturbation of the round sphere; the path remains positively curved by \(C^2\)-smallness, while nonconstant Gauss curvature rules out isometry with the round link.

This is intended as a *conditional* realization theorem for links, not a claim that the harmonic functions on the cone lift to global polynomial-growth harmonic functions on the smooth manifold. That missing spectral-to-harmonic transfer is the hard step relevant to the N175 excess candidate. In particular, this gluing calculation alone does not establish Yau-counterexample growth dimensions.

## 3. Potential use / unresolved verification

The pinned OpenAI/math source `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb` includes the 3D integer-growth counterexample paper. Its public statement gives, for each fixed \(4/9<v<1\) and \(1<c<9v/4\), a metric depending on each large integer degree \(k\), with \(\mathrm{AVR}=v\) and \(\dim\mathcal H_k\ge c(k+1)^2\). The Astra current-main coordination index separately labels N175 as a one-metric limsup candidate, but that candidate is source-derived/unreviewed. This note neither validates N175 nor proves the countable harmonic transfer.

A priority search found Perelman's published nonunique-cone example on \(\mathbb R^4\) (a radial variable with \(S^3\) links), and Colding--Naber examples of 3D *Ricci-limit spaces* with nonunique tangent cones. It did not establish whether the above direct smooth \(\mathbb R^3\) slow-switching construction is new; absence from search is not a priority result. This requires a specialist audit of every Ricci component, cap matching, and literature before any novelty claim.

## Source pins consulted

- OpenAI/math, immutable commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`; source paper `preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf`.
- Perelman, “A Complete Riemannian Manifold of Positive Ricci Curvature with Euclidean Volume Growth and Nonunique Asymptotic Cone,” *Comparison Geometry* (1997), pp. 165–166; Cambridge chapter DOI `10.1017/9781009701891.009`. Its cohomogeneity-one links are `S^3`, so the ambient example is 4-dimensional.
- Colding–Naber, “Characterization of Tangent Cones of Noncollapsed Limits with Lower Ricci Bounds and Applications,” arXiv:1108.3244. It constructs 3-dimensional Ricci-limit spaces with nonunique tangent cones; that is a different scope from a smooth fixed complete manifold’s asymptotic cones.
