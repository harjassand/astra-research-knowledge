# Problem-backward attack: the sharp higher-dimensional infinity-harmonic endpoint

Updated 2026-10-09. Status: exploratory proof work; no endpoint theorem established.

## Source pins and verification status

- Astra start interface: `harjassand/astra-research-knowledge`, commit `031ce532f7f6d1c070387f6213a00204893be79d`; `00_START_HERE.txt` was fetched at this exact ref and routes task-first retrieval.
- OpenAI math: `openai/math`, commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`; `README.md`, `CONTENTS.md`, `lean/docs/377.md`, and the family-377 build source tree were fetched at that exact ref. The source tree is `preprints/Uniform-Interior-C1alpha-Estimates-for-Infinity-Harmonic-Functions-October-4-2026/build/manuscript/`.
- Family 377 is a 46-page Oct. 4, 2026 manuscript. The repository's `lean/docs/377.md` is citation/scope metadata, not a proof formalization. The family page says no Lean formalization and no expert review is recorded. OpenAI's README itself says released results are at different verification stages and unformalized results may have issues.
- The source proof sections inspected: `01-introduction.tex`, `02-flatness.tex`, `03-reduction.tex`, `04-limiting-tools.tex`, `05-envelope-contact.tex`, `06-discrete-propagation.tex`, `07-contact-localization.tex`, `08-rigidity.tex`.

## Exact next theorem

For each integer `d >= 3`, does there exist `C_d` such that every viscosity infinity-harmonic `u` on `B_1 subset R^d` satisfies

`||Du||_{L-infinity(B_{1/2})} + [Du]_{C^{0,1/3}(B_{1/2})} <= C_d osc_{B_1} u`?

The exponent is optimal: Aronsson's example `u=(|x_1|^{4/3}-|x_2|^{4/3})/2`, extended independently of the other coordinates, has `|Du(te_1)-Du(0)|=(2/3)|t|^{1/3}`. Any exponent above `1/3` fails.

The exceptional significance of the neighboring theorem is clear: before the Oct. 2026 release, Evans--Smart had proved pointwise differentiability in all dimensions, but continuity of `Du` was open for `d>=3`; Evans--Savin had `C^{1,alpha}` in the plane. Family 377 claims uniform `C^{1,alpha_d}` for `d>=3`, with `alpha_d` positive but non-explicit. It explicitly makes no endpoint claim. The remaining endpoint is therefore a strict strengthening of that source claim, and is supported by the 4/3 Aronsson obstruction.

## Primary sources checked

- Evans--Smart, “Everywhere differentiability of infinity harmonic functions,” 2011, DOI `10.1007/s00526-010-0388-1`: https://link.springer.com/article/10.1007/s00526-010-0388-1. The article states that every infinity-harmonic function is differentiable, and its introduction says continuous differentiability in dimensions `n>=3` remained open at the time.
- Evans--Savin, “C^{1,alpha} regularity for infinity harmonic functions in two dimensions,” 2008, DOI `10.1007/s00526-007-0143-4`: https://www.math.columbia.edu/~savin/evans-savin.pdf. Their method establishes a positive planar exponent, with the higher-dimensional proof conditional on further estimates.
- Kai Xu, “Infinity-harmonic functions and inverse mean curvature flow clusters,” arXiv:2607.06698 (July 2026): https://arxiv.org/abs/2607.06698. The primary abstract claims planar `C^{1,1/3}` and additional structure, so the 2D endpoint is no longer the target here.
- OpenAI family 377 official source at the pinned commit: https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Interior-C1alpha-Estimates-for-Infinity-Harmonic-Functions-October-4-2026/build/manuscript/ .

## Source mechanism reconstructed from the proof, not just the card

The release's route has two layers.

1. A three-point viscosity maximum argument upgrades near-affine convergence to a midpoint-defect estimate uniform over all endpoint separations. This establishes only qualitative uniform flatness for normalized lifted solutions `U(y,b)=u(y)+b`.
2. A bad-cylinder sequence is anisotropically rescaled: axial length `r`, transverse length `sqrt(lambda) r`, vertical error `lambda r`. The limit solves
   `F[v] = D^2v[(grad_x v,1)] = 0`.
   To rule out a non-affine limit, the proof takes an extremal horizontal Jensen defect, builds the variance-penalized barycentric envelope
   `C_t v(x,t) = sup_{mean y_i=x} { sum theta_i v(y_i,t) - Var(y)/(2t) }`,
   and subtracts `kappa^2 t/2`. The envelope is a subsolution by a common-time theorem-of-sums argument: along the viscosity direction, the weighted variance penalty is affine in time. The resulting positive-gap contact is propagated to time zero using a discrete forward/backward envelope walk whose drift controls squared optimizer-velocity discrepancies. The final envelope-slope rigidity yields a contradiction.

The actual lift lemma, barycentric subsolution calculation, and contact walk were inspected in source. I found no immediate algebraic sign error in those pieces. The critical *quantitative* issue for the endpoint is different: the final bad-scale selection chooses exponents `gamma_i -> 0` and uses a fixed enlargement factor `Lambda=32`; it proves `b(s) <= B s^gamma` for some non-explicit `gamma>0`, but gives no control at the linear threshold `gamma=1`.

## The exact missing gate in the paper's mechanism

Family 377 defines a cylinder fit at `(z,r)` with parameter `lambda` when some slope `P` gives

`|U(z+h)-U(z)-P.h| <= lambda r` on `Z_lambda(z,r;P)`,

where `Z_lambda` has axial radius `r` and transverse radius `sqrt(lambda) r`. Its modulus is `b(s)`, the supremum of bad parameters over normalized lifts and radii `r <= s dist(z, boundary)`.

A sufficient sharp gate for the desired `C^{1,1/3}` conclusion is

`b(s) <= B s`.

Why the exponent matches exactly: choose `lambda = A r` at physical radius `r`. The cylinder contains a ball of radius `rho = sqrt(A) r^{3/2}` and the affine error is `A r^2`. At dyadic scales `r_j=2^{-j}r_0`, fitted slopes on common balls differ by `O(r_j^{1/2})`, so they converge to a gradient with tail `O(r_j^{1/2})`. For `rho_{j+1}<|h|<=rho_j`, the first-order remainder is `O(r_j^2)=O(|h|^{4/3})`; comparing Taylor estimates at adjacent centers gives `|Du(z)-Du(z')|<=C|z-z'|^{1/3}`. This repeats only the local extraction step, not the unproved global gate.

The gate is sharp on the Aronsson example: it has `b(s) >= c s` at the origin and admits `lambda <= C r` cylinder fits at every center. Thus a proof by improving to `b(s)=o(s)` is impossible.

## Actual scaled test on Aronsson's solution

Let `a=1/2`, `f(s)=a|s|^{4/3}`, `u(x)=f(x_1)-f(x_2)`, and `U(x,b)=u(x)+b`. At the origin the correct cylinder axis is the lifted gradient `P=e_b`.

For every axis direction and every `0<lambda<=1`, the cylinder contains both `+h e_1` and `-h e_1` for `h=sqrt(lambda) r/2`. The two affine residuals sum to `2a h^{4/3}`; if each is at most `lambda r`, then

`lambda r >= a h^{4/3}`, hence `lambda >= a^3 r/16 = r/128`.

Conversely, at `P=e_b` and `lambda=r`, any cylinder point has horizontal radius at most `r^{3/2}`, so

`|u(x)| <= 2a (r^{3/2})^{4/3}=r^2=lambda r`.

So the origin exactly saturates the linear parameter law up to constants; the largest allowed improvement one can hope for is `O(r)`.

There is also an all-center estimate for this exact example. If `s=x_i`, `g_i=f_i'(s)`, and `delta_i` is a coordinate displacement, the one-dimensional cusp has the scale-invariant remainder bound

`|f_i(s+delta_i)-f_i(s)-f_i'(s)delta_i| <= C delta_i^2/(|s|+|delta_i|)^{2/3}`.

For a lift-cylinder with `lambda=A r`, every horizontal coordinate increment satisfies `|delta_i| <= C r |s|^{1/3} + sqrt(A) r^{3/2}`. Splitting at `|s|=sqrt(A) r^{3/2}` bounds the remainder by `C(1+A^{2/3})r^2`; choosing A sufficiently large gives a fit. This confirms the source's linear-cylinder gate is compatible with the sharp model, rather than being disproved by the singular axes.

## A useful scaling reduction for falsification

At a critical point, a profile with remainder order `|x|^{1+alpha}` would require cylinder parameter approximately

`lambda ~ r^{2 alpha/(1-alpha)}`

because `(sqrt(lambda) r)^{1+alpha} ~ lambda r`.

- `alpha=1/3` gives `lambda~r`.
- Any `alpha<1/3` gives `lambda/r -> infinity` as `r->0`.

Thus a counterexample to the endpoint should show up as a non-affine anisotropic blow-up with subcritical `4/3` spatial growth. Conversely, a route to the endpoint could seek a Liouville theorem for the limit equation `F[v]=D^2v[(grad_x v,1)]=0` ruling out all admissible non-affine limits with subcritical `4/3` growth.

I derived the spherical equation for a classical homogeneous ansatz `u(r,omega)=r^q phi(omega)`:

`<D_S^2 phi grad_S phi, grad_S phi> + q(2q-1) phi |grad_S phi|^2 + q^3(q-1) phi^3 = 0`.

At a smooth angular critical point with `phi != 0`, this forces `q=1`; therefore any non-affine homogeneous profile of degree `q>1` must have angular singular structure at its extrema. Balancing a power cusp `M-c|theta|^beta` against the nonzero radial term gives `3 beta - 4 = 0`, hence `beta=4/3`, the Aronsson exponent. This is a formal local balance, not a proof that all viscosity profiles have that cusp.

## Falsification status and next proof task

- The standard separable Aronsson family supports, but does not prove, `b(s)=Theta(s)`.
- I found no higher-dimensional primary-source example with a gradient exponent below `1/3`; the 2018 explicit separated-solution paper does not supply one. This negative search is not a literature certification.
- The strongest concrete next lemma is: **every global solution of the anisotropic limit equation produced by a sequence with `lambda_i/r_i -> infinity` must be affine**. This is more precise than the generic quadratic-fit Liouville, because the latter admits the time-independent Aronsson profile and is too weak. The extra inherited constraint from bounded normalized original solutions must be stated and used explicitly.
- Current mathematical status: the endpoint gate is not proved or falsified. The proof machinery from family 377 supplies qualitative flatness and some power decay, not the linear bound.

## Conditional extraction proved independently

Here is the complete local argument behind the sufficient gate. Suppose a Lipschitz function `U` on a neighborhood of `B_{1/2}` has, at every `z` and every small `r`, a cylinder fit with parameter `lambda=A r` and error `lambda r=A r^2`, with one fixed `A`.

The cylinder contains `B_{rho}(z)`, `rho=sqrt(A) r^{3/2}`. Set `r_j=2^{-j}r_0`, choose any fitted slope `P_j(z)` at each scale, and `rho_j=sqrt(A)r_j^{3/2}`. On `B_{rho_{j+1}}(z)` both affine fits apply, so

`|P_j(z)-P_{j+1}(z)| <= A(r_j^2+r_{j+1}^2)/rho_{j+1} <= C_A r_j^{1/2}`.

The geometric tail converges uniformly, defining `P_infinity(z)` with `|P_j-P_infinity|<=C_A r_j^{1/2}`. At every `|h|<=rho_j`,

`|U(z+h)-U(z)-P_infinity(z).h| <= A r_j^2 + |P_j-P_infinity|rho_j <= C_A r_j^2`.

For `rho_{j+1}<|h|<=rho_j`, one has `r_j^2<=C_A |h|^{4/3}`. Therefore `U` has a uniform `O(|h|^{4/3})` first-order remainder. This implies differentiability with gradient `P_infinity`; comparing the remainders at two centers (and one common evaluation point) gives `[DU]_{C^{0,1/3}}<=C_A`. On the lift `U(y,b)=u(y)+b`, restriction to `b=0` is the desired endpoint estimate for `u`.

This closes the extraction direction. It does not prove the key universal linear cylinder-fit bound.

## Quantitative obstruction in the current proof architecture

The endpoint failure can be fed into the source bad-scale selection with exponent `1`, but that selection no longer gives a uniform enlargement constant. If `s_i` is a running near-maximum for `b(s)/s` and `lambda_i` is comparable to `b(s_i)`, then for every fixed scale factor `M`,

`b(2 M s_i) <= 2 b(s_i) (2M)`,

so the enlargement needed to make nearby fits good is `Lambda(M)=O(M)`. A fit at normalized radius `R` then has error `Lambda(R)R=O(R^2)`. The published Liouville theorem needs one constant times `R` at every radius. This pinpoints why the existing proof does not yield the endpoint.

I tested a natural extension of the novel barycentric-envelope mechanism rather than assuming it transfers. Suppose a horizontal defect obeys `D<=kappa r^q`, `1<q<2`. The same envelope penalty optimizes as

`sup_r {kappa r^q-r^2/(2t)} = (1-q/2) q^{q/(2-q)} kappa^{2/(2-q)} t^{q/(2-q)}`.

For `q=4/3`, the correction is `g(t)=(16/27)kappa^3 t^2`. Although `C_t v` remains a subsolution, `W=C_t v-g(t)` satisfies only `F[W]>=-g''=-32 kappa^3/27`, rather than `F[W]>=0`. In the source's step-`epsilon` walk, the forward midpoint gap then has lower bound `D>=-g'' epsilon^2`; after the identity divides by `4 epsilon`, this allows a drift loss of `g'' epsilon/4` per step. The simple symmetric time walk has order `epsilon^{-2}` steps on a fixed interval, so this direct lower-expectation argument loses order `epsilon^{-1}` and cannot preserve the contact estimate. This is an obstacle to reusing the current walk, not a refutation of the endpoint; a compensated martingale or a new forcing-sensitive contact potential could change it.

The same calculation explains the critical scaling. If a critical-point profile has size `|x|^q`, balance of the transverse-cylinder error gives `lambda ~ r^{2(q-1)/(2-q)}`. The ratio `lambda/r` has exponent `(3q-4)/(2-q)`, so `q<4/3` is exactly the regime `lambda/r -> infinity`; `q=4/3` is the linear-fit threshold. A concrete route to an endpoint proof is therefore a subcritical-profile Liouville theorem for the anisotropic limit equation, or an inhomogeneous contact-walk theorem at the `q=4/3` forcing level.

## Full check of the model fit

For `f(s)=a|s|^{4/3}`, `f'(s)=(4a/3)sgn(s)|s|^{1/3}`. Directly splitting `|delta|<=|s|/2` (use `|f''(s)|<=C|s|^{-2/3}`) and `|delta|>|s|/2` (use the 1/3-Hölder bound on `f'`) gives

`|f(s+delta)-f(s)-f'(s)delta| <= C delta^2/(|s|+|delta|)^{2/3}`.

At a center `(x_1,x_2)`, take `P=(f'(x_1),-f'(x_2),1)` for the lift. A displacement in `Z_{A r}(z,r;P)` has each horizontal coordinate increment satisfying `|delta_i|<=r|f_i'(x_i)|+sqrt(A)r^{3/2}`. Write `S=|x_i|` and `T=sqrt(A)r^{3/2}`.

- If `S>=T` and `A>=1`, then `S>=r^{3/2}`, `rS^{1/3}<=S`, and the remainder quotient is bounded by `C(r^2+A r^3/S^{2/3})<=C(1+A^{2/3})r^2`.
- If `S<T`, then `rS^{1/3}<=A^{1/6}r^{3/2}` and `|delta_i|<=C sqrt(A)r^{3/2}`; the Hölder form of the same remainder bound gives `C A^{2/3}r^2`.

Summing two coordinates gives residual `<=C(1+A^{2/3})r^2`. Choose a fixed `A` large enough that `A>=C(1+A^{2/3})`; then `lambda=A r` is a valid fit at every center for all sufficiently small r. Together with the origin lower bound `lambda>=r/128`, the example has the exact linear order `b(s)~s` up to constants.
