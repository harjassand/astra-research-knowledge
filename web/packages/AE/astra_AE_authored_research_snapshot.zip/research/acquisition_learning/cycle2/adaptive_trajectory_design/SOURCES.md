# Primary-source ledger and scope

These sources establish context or a standard testing lemma. The finite-HMM
likelihoods, exact risk formulas, Blackwell comparison, and transfer
counterexample in `RESULT.md` are derived here; no external source is claimed
to prove those statements.

1. Leifur Thorbergsson and Giles Hooker, “Experimental design for Partially
   Observed Markov Decision Processes,” arXiv:1209.4019 (v4, 2018),
   [primary preprint](https://arxiv.org/abs/1209.4019). Its abstract describes
   adaptive control policies selected to maximize Fisher information about
   parameters in POMDP experiments, including online policy updates. It
   confirms that adaptive POMDP experiment design is established prior art;
   it does not supply this finite binary predictive-model risk comparison.
2. Brigham Anderson and Andrew W. Moore, “Active Learning for Hidden Markov
   Models: Objective Functions and Algorithms,” ICML 2005, pp. 9–16,
   [official proceedings PDF](https://icml.cc/Conferences/2005/proceedings/papers/002_Active_AndersonMoore.pdf),
   [ACM DOI](https://doi.org/10.1145/1102351.1102353). The paper develops
   query-selection objectives for HMM model/state/path learning. Its
   described setting uses queryable hidden observations from a sequence;
   this leaf instead charges physical controls and resettable raw emissions.
   This is interface context, not a priority claim.
3. Satinder Singh, Michael R. James, and Matthew R. Rudary, “Predictive State
   Representations: A New Theory for Modeling Dynamical Systems,” UAI 2004,
   pp. 512–519, [paper preprint](https://arxiv.org/abs/1207.4167). It frames
   state using predictions of observable experiments. That supports the
   observable-table target; it does not establish adaptive acquisition or
   the HMM calculation here.
4. Herman Chernoff, “A Measure of Asymptotic Efficiency for Tests of a
   Hypothesis Based on the Sum of Observations,” *Annals of Mathematical
   Statistics* 23(4), 493–507 (1952),
   [DOI](https://doi.org/10.1214/aoms/1177729330). The binary iid testing
   error exponent used to interpret `C_A` and `C_F` is classical. In this
   construction the symmetric likelihoods make the optimizing Chernoff
   parameter `1/2`, giving exactly the displayed negative log
   Bhattacharyya coefficients.

## Workspace overlap and novelty boundary

The concurrent Cycle 2 leaf
`outputs/research/acquisition_learning/cycle2/active_hmm/RESULT.txt` also
studies a noisy-cue action-alignment advantage over pre-observation actions.
It uses a four-state reset episode, one pulse, and a blank/token emission
target; this leaf uses a two-state transition HMM, two ordinary noisy binary
symbols, and transfer to a four-cell controlled prediction table. The
abstract alignment mechanism is shared, so these are adjacent constructions,
not independent replications and not evidence of novelty. The Cycle 2
`adaptive_policy_frontier/REPORT.txt` is another distinct known-model state
identification result; it is not used in this proof.

The larger literature on active POMDP/HMM experiment design and PSRs is
substantial. No exhaustive novelty search or expert review was performed.
