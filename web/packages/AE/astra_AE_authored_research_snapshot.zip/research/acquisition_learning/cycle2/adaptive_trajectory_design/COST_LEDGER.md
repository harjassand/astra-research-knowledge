# Cost ledger: adaptive observable prediction in the two-state HMM

The theorem counts independent reset episodes. Each episode contains exactly
one reset, two observed binary symbols, one binary control, and one logged
control. The environment does not return hidden-state labels or conditional
probabilities. Noise is part of the stated BSC emissions and affects sample
complexity through `d=gamma(1-2epsilon)(1-epsilon)` and
`ell=gamma(1-2epsilon)epsilon`; no clean measurements or denoising oracle are
used.

## Interaction and data costs

Let `c_R` be the reset cost, `c_A` the executed action cost, `c_Y` the cost
per observed bit, `c_L` the action-log cost, and `c_S` the feedback selection
computation cost per episode. For the same `N` episodes:

| Resource | Feedback `A=Y0` | Pre-observation design |
|---|---:|---:|
| Resets | `N` | `N` |
| Observed symbols | `2N` bits | `2N` bits |
| Executed actions | `N` bits/actions | `N` bits/actions |
| Action records | `N` bits | `N` bits |
| Core acquisition cost | `N(c_R+c_A+2c_Y+c_L)` | same |
| Action selection | `N c_S` | no current-cue selection |
| Full raw-data retention | `3N` bits, if retained | same |

Both statistical estimators are allowed the complete raw log
`(Y0_i,A_i,Y1_i)_{i=1}^N`. Thus the lower bounds cover a full-data estimator,
not a restricted readout. If the data are streamed rather than retained,
feedback needs a signed sum of `2Y1-1` and a counter, or
`O(log N)` bits. The pre-observation full-data likelihood ratio needs only
four counts for `(match/mismatch, Y1=0/1)`, also `O(log N)` bits, plus the
shared constants. Both can therefore operate with finite logarithmic memory;
the full-data lower bound remains valid regardless of storage.

## Coding, arithmetic, and validation

The public class description consists of the alphabet and the known rational
parameters `epsilon,gamma`. If each has at most `h` bits, this common
description costs `O(h)` bits. The fitted predictive table can be encoded by
one bit for `theta` plus the shared formula and constants; a literal four-cell
table has `O(h)` bits per entry. There is no cost for transmitting a hidden
basis because none is provided or used.

The active rule copies `Y0` to the control (one equality/copy operation per
episode) and updates one signed counter. The full-data fixed-design
likelihood ratio can be computed from four integer counts and the shared
log-likelihood weights. This is `O(N)` elementary observation/count updates.
The report does not claim a bit-complexity bound for exact comparisons of
weighted log-likelihood sums; full raw retention also provides a valid
finite-memory-independent comparator. A practical implementation may charge
its chosen numerical precision separately.

The theorem itself supplies a finite-sample risk guarantee, so it uses no
held-out validation episodes. The exact-rational checker costs one local
finite enumeration of 16 latent paths per sign/policy and is an algebra
diagnostic only. If an empirical held-out validation stage is added, its
resets, observations, actions, and log bits must be added equally to both
arms; none are silently included here.

## Total-cost break-even

The statistical sample counts are the exact risk thresholds
`N_A*(delta)` and `N_F*(delta)` in `RESULT.md`. Let
`c_0=c_R+c_A+2c_Y+c_L` and include identical model/output coding cost `c_M`.
The declared totals are

```text
C_feedback = N_A*(delta)*(c_0+c_S) + c_M,
C_pre      = N_F*(delta)*c_0 + c_M.
```

The theorem establishes `N_A*(delta) <= N_F*(delta)` by Blackwell
dominance, and a strict asymptotic statistical advantage because
`C_A>C_F`. It does not claim that feedback wins for every monetary/latency
assignment: with nonzero `c_S`, total cost is lower exactly when
`(N_F*-N_A*)c_0 > N_A*c_S`. This condition keeps adaptive computation visible
instead of assuming it is free.
