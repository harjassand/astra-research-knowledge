# Witness horizons for finite-state hidden processes

**Status:** internally proved, with an exact two-model calculation and a primary-source audit. The state-count theorem is proved directly below; the cited finite-rank realization paper supplies context, not a citation for this particular horizon bound. No external proof review or novelty/priority audit has been done.

## Result and interface

Let `M0,M1` be stationary or nonstationary finite-state HMMs over the same finite alphabet `Σ`, with `s` and `t` hidden states. Only raw emitted symbols are observed. Write `P_i(w)` for the probability of a word `w ∈ Σ*`, and `P_i^(L)` for the law of the first `L` emissions.

**Finite witness-horizon theorem.** If

$$
P_0(w)=P_1(w)\quad\text{for every } |w|\le s+t-1,
$$

then the two laws agree on every finite word. Consequently, if each model has at most `m` states, exact equality of the length-`L` observation laws for `L ≥ 2m−1` rules out any later predictive difference. More generally, any two unequal laws with these state counts have a differing word of length at most `s+t−1`. This is a population identifiability statement; it does not bound the number of noisy trajectories needed to estimate small word-probability differences.

The threshold does not depend on alphabet size, mixing, or lower probability bounds. The result applies to general finite-state HMMs, so in particular to bounded-state fast-mixing HMMs. A length-`L` law determines every shorter marginal, so equality of `P_0^(L)` and `P_1^(L)` gives the premise for every `|w| ≤ L`.

### Proof

Use row-vector conventions. For model `i`, let `π_i` be its initial hidden-state law, `Q_i` its row-stochastic transition matrix, and `D_{i,a}` the diagonal matrix of emission probabilities for symbol `a`. Since `Q_i 1 = 1`, define `B_{i,a}=D_{i,a}Q_i` and obtain, including the empty word,

$$
P_i(a_1…a_k)=π_i B_{i,a_1}…B_{i,a_k}1.
$$

Set `r=s+t`, `B_a=diag(B_{0,a},B_{1,a})`, `λ=(π_0,−π_1)`, and `β=(1_s,1_t)^T ≠ 0`. The difference series is `f(w)=P_0(w)−P_1(w)=λB_wβ`. Define

$$
V_k=span\{B_wβ:|w|≤k\} ⊆ R^r.
$$

Here `dim(V_0)=1`, and `V_(k+1)=V_k+Σ_(a∈Σ) B_a V_k`. If `V_(k+1)=V_k`, then `V_k` is invariant under every `B_a`, so all later `V_j` equal `V_k`. Otherwise dimension strictly increases. Since `V_0` has dimension one and the ambient space has dimension `r`, by `k=r−1` the sequence has either stabilized earlier or has reached all of `R^r`, which is itself invariant. Thus `V_(r−1)` is invariant and contains `B_wβ` for every word. If `f(w)=0` for `|w|≤r−1`, then `λ` annihilates the spanning set of `V_(r−1)`, hence annihilates all `B_wβ`. Therefore `f(w)=0` for every word. `□`

The Hankel matrix `H(u,v)=P(uv)` of an `n`-state HMM has rank at most `n`, by the same linear representation. The direct-sum proof above is a finite-horizon consequence of that representation and does not need a minimal realization or a mixing assumption.

## A fast-mixing exact alias at horizon one

This example demonstrates that the bound is substantive: one-step data can be exactly uninformative even with strictly positive transition and emission probabilities and rapid mixing.

For `ρ ∈ {+1/2,−1/2}`, let `Z_t ∈ {−1,+1}` be stationary with uniform initial law and transition

$$
Pr(Z_(t+1)=z′ | Z_t=z)=(1+ρzz′)/2.
$$

Conditional on the hidden states, emissions are independent and

$$
Pr(Y_t=1 | Z_t=z)=1/2+z/4,   Y_t ∈ {0,1}.
$$

Call the two HMMs `M+` and `M−`. Each has exactly two hidden states and a binary output alphabet. The initial state mass is `1/2` per state. Every transition entry and every conditional emission-symbol probability is at least `1/4`. In fact, for every word `w` of length `k`, `P_ρ(w) ≥ 4^(−k)`. The stationary single-symbol context has `P(Y_1=1)=1/2`.

The hidden chain has second eigenvalue `ρ`. Its Dobrushin contraction coefficient is exactly `|ρ|=1/2`, and from a fixed state its distance to stationarity after `j` transitions is `2^(−j−1)`. Thus the usual `1/4`-mixing time is one transition. Both models are aperiodic and uniformly ergodic.

The one-symbol law is Bernoulli`(1/2)` under both models, so their observation laws agree exactly through horizon `T=1`. But

$$
Pr(Y_2=1 | Y_1=1)=1/2+2(1/4)^2ρ
=\begin{cases}9/16,&ρ=+1/2,\\7/16,&ρ=−1/2.\end{cases}
$$

The conditional next-bit predictions differ by exactly `1/8`. Equivalently, `P_ρ(11)=P_ρ(00)=1/4+ρ/16` and `P_ρ(10)=P_ρ(01)=1/4−ρ/16`. The length-two laws have total-variation distance exactly `1/8`, so length two is the minimum population observation horizon that resolves this pair.

### Predictive rank and a finite Hankel margin

For either model, the Hankel block indexed by prefixes and suffixes `{ε,1}` is

$$
H_ρ=\begin{pmatrix}1&1/2\\[2pt]1/2&1/4+ρ/16\end{pmatrix}.
$$

Its determinant is `ρ/16=±1/32`, so each full process Hankel matrix has rank exactly two (the HMM representation gives the upper bound two, and this minor gives the lower bound). The smaller singular value of this explicit `2×2` witness block is

$$
σ_2(H_+)=(41−√1553)/64≈0.0248731095,   σ_2(H_−)=(√1649−39)/64≈0.0251231408.
$$

These are finite-block singular margins only; no spectral-gap claim is made for the infinite Hankel operator.

## Noisy raw-trajectory acquisition cost

The statistical interface is `n` independent stationary episodes of exactly two observed bits each; hidden states are never revealed. The candidate family and parameters are known, and only the sign of `ρ` is withheld. One-bit episodes have identical laws, so no number of them can identify the model: under the equal prior every test has error exactly `1/2`. For a prediction target, any estimate of `Pr(Y_2=1 | Y_1=1)` with absolute error strictly below `1/16` also identifies the model by whether it lies above or below `1/2`.

For each two-bit episode, set `S=1{Y_1=Y_2}`. Under `M+`, `S ~ Bernoulli(9/16)`; under `M−`, `S ~ Bernoulli(7/16)`. Conditional on `S`, the two equal strings or two unequal strings have equal probability in either model, so `S` is sufficient and the full raw-string likelihood-ratio test reduces exactly to a binomial test. If `K=Σ_(j=1)^n S_j`, the likelihood ratio is `(9/7)^(2K−n)`; the minimax test chooses `M+` for `K>n/2`, `M−` for `K<n/2`, and randomizes at equality.

Its exact minimax error (also equal-prior Bayes error) is

$$
e_n=\frac12\sum_{k=0}^n \min\left\{\binom nk(9/16)^k(7/16)^{n-k},\binom nk(7/16)^k(9/16)^{n-k}\right\}.
$$

Therefore the exact minimum episode cost for error at most `α<1/2` is `n_*(α)=min{n:e_n≤α}`. Exact binomial summation gives `n_*(0.1)=105` independent length-two episodes (210 observed symbols and 105 starts). This is optimal among all learners with this data interface by the Neyman–Pearson lemma and symmetry. Computation is `O(n)` comparisons and additions with an `O(log n)`-bit counter; candidate prediction outputs are the fixed rationals `7/16` and `9/16`.

For a closed-form lower bound, the one-episode KL divergence is exactly

$$
D(P_+^(2)||P_−^(2))=D(Bern(9/16)||Bern(7/16))=(1/8)log(9/7)≈0.03141430354 nats.
$$

If both test errors are at most `α`, data processing of transcript KL through the decision event gives

$$
n ≥ kl(1−α||α)/((1/8)log(9/7)).
$$

At `α=0.1`, this gives `n≥55.95`, hence at least 56 episodes. Conversely, thresholding `K/n` at `1/2` and Hoeffding's inequality give `e_n≤exp(−n/128)`, so `n≥128 log(1/α)` suffices (295 episodes at `α=0.1`); the exact binomial risk above is sharper. The full likelihood-ratio rule is the strongest raw-data baseline in this episodic interface, not merely a moment estimator.

The one-bit context `Y_1=1` occurs with probability `1/2`, so a passive length-two episode reaches that context after two starts on average and then reveals its `Y_2` continuation. An oracle that directly returns the conditional law answers `9/16` or `7/16` in one call, but that call supplies the missing predictive information; it is not a free consequence of knowing the state count or the model family. Likewise, supplying the exact model realization including `ρ` makes prediction immediate, while supplying only the two-state architecture leaves the one-bit model identity to be acquired.

## Description length and information accounting

The schema (two named states, uniform initial distribution, binary alphabet, and fixed emission table `3/4,1/4`) is common knowledge. Within this known two-candidate family, the only unknown is the sign of `ρ`, exactly one bit. If the whole HMM is serialized in a redundant fixed table, it has 10 probability entries (two initial, four transition, four emission); assigning each value in `{1/4,1/2,3/4}` a two-bit code uses exactly 20 parameter bits per model, plus a fixed schema header. Neither representation grows with the witness horizon. The experiment pays `n` independent starts and `2n` emitted symbols; hidden state labels, interventions, and conditional-law answers are not in this baseline.

## Primary-source audit

- J. W. Carlyle and A. Paz, “Realizations by stochastic finite automata,” *Journal of Computer and System Sciences* 5(1), 26–40 (1971), [publisher record and DOI](https://doi.org/10.1016/S0022-0000(71)80005-3). The publisher abstract describes a finite-rank characterization of string functions by finite-state sequential systems. It supports the linear-representation/Hankel framework used here; the `s+t−1` finite-witness lemma above is proved explicitly in this report and is not attributed to a theorem statement from that paper.
- W. Hoeffding, “Probability inequalities for sums of bounded random variables,” *Journal of the American Statistical Association* 58(301), 13–30 (1963), [publisher DOI](https://doi.org/10.1080/01621459.1963.10500830). This is the primary source for the concentration inequality used in the simple upper bound. The exact binomial risk, KL value, and KL decision lower bound here are calculated directly for the stated pair.

## Claim gate and open boundary

Source-access limit: publisher metadata and the Carlyle–Paz abstract were checked; the browser could not retrieve either full text in this pass (ScienceDirect returned 403, and the Hoeffding DOI redirected to an inaccessible full-text page). No proof here depends on an uninspected source theorem: the horizon and testing arguments are derived explicitly above.

**Proved:** exact finite-state HMM laws cannot remain aliased beyond `s+t−1` observations; a strictly positive, two-state, binary, one-step-mixing HMM pair can nevertheless agree exactly at horizon one and have a fixed `1/8` next-step prediction gap; the raw length-two episodic testing cost is exactly characterized by `e_n`.

**Not proved / UNKNOWN:** sharpness of `s+t−1` for HMMs with positive transitions and emissions; a quantitative witness horizon or sample bound for *approximately* equal length-`T` laws under just a state bound, mixing coefficient, emission/transition floors, Hankel block margin, and finite description length; and any improvement from active controls for a general HMM class. Finite parameter bit length alone does not supply a statistical margin unless its encoding and a lower separation bound are related explicitly. The present exact result is an identifiability theorem, not a uniform noisy-acquisition guarantee for arbitrary unknown HMMs.
