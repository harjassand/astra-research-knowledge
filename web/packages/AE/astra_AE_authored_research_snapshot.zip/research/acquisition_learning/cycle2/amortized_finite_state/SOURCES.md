# Primary sources consulted

Access date for the records below: 2026-10-08.

1. George H. Mealy, “A Method for Synthesizing Sequential Circuits,” Bell System Technical Journal 34(5), 1045–1079 (1955). Publisher record and DOI: https://onlinelibrary.wiley.com/doi/abs/10.1002/j.1538-7305.1955.tb03788.x ; DOI https://doi.org/10.1002/j.1538-7305.1955.tb03788.x . This is the primary reference for the classical finite-state input/output sequential-machine model used here. The theorem in this report is proved directly and is not claimed from Mealy.

2. Dana Angluin, “Learning Regular Sets from Queries and Counterexamples,” Information and Computation 75(2), 87–106 (1987). DOI https://doi.org/10.1016/0890-5401(87)90052-6 ; author-hosted paper PDF https://homepages.math.uic.edu/~lreyzin/papers/angluin87.pdf . The paper’s opening definition gives membership queries and equivalence queries with counterexamples; it also discusses the assumptions behind equivalence testing. We cite it to distinguish that stronger teacher interface from the reset-word-only interface here. Our exhaustive length-n² validation panel replaces an equivalence oracle only under the deterministic known-state-cap promise, at exponential cost.

The product-state distinguishing-length proof, exhaustive-search cost, drift coupling, and retainer simulation are established in this note. No literature novelty or priority claim is made.

