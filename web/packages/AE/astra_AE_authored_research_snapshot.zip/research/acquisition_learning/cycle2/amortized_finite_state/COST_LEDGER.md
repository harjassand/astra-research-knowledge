# Resource and break-even ledger

This ledger instantiates REPORT.md for binary deterministic Mealy machines, n-state cap, d=n² distinguishing horizon, future task horizon H, and K tasks. Counts treat every reset experiment, input symbol, binary output symbol, bit of storage, and transition simulation as a separate resource.

## Resource inventory

| Resource | Acquisition panel T | Validation panel V | Total setup |
|---|---:|---:|---:|
| Reset queries | 2^d−1 | 2^d | Q=2^{d+1}−1 |
| Input symbols | X_T=(d−2)2^d+2 | X_V=d2^d | X=(2d−2)2^d+2 |
| Output bits | X_T | X_V | X |
| Query input precision | one exact binary symbol per input | same | no numerical estimate |
| Output precision | one exact bit per output symbol | same | deterministic transcript |

The exact fitted table for a selected candidate with m≤n states costs
2s+2m(s+1) bits, where s=⌈log2(n+1)⌉. The uniform cap is
B_M=2s+2n(s+1).
A sufficient fitting cap is
B_peak = X + B_M + B_ctrl + L_alg,
B_ctrl = ⌈log2(N_n+1)⌉ + 4⌈log2(X+1)⌉ + 2d + s + 16,
N_n = Σ_{m=1}^n m^{2m+1}4^m.
This holds the complete raw panel while storing the candidate table and loop state. Thus the raw-retention comparator can keep the same transcript within this cap. Once setup finishes, the representation policy may erase the transcript and retain only B_M bits. During K tasks of horizon at most H it stores B_M bits and uses at most KH table transitions.

Let C_fit be the local search budget. There are at most N_n X transition/output comparisons. A direct implementation uses at most O(N_n(X+n)w) bit operations with w=⌈log2(N_n+X+n+2)⌉. The bound includes checking both T and V, candidate generation, and transcript traversal. It is intentionally exhaustive.

## Weighted setup cost and independent refitting

Choose nonnegative resource prices:
- α_R per reset query;
- α_I per input symbol;
- α_O per output bit;
- α_C per local computation operation;
- α_M per model bit per task-horizon unit;
- α_L per unit of normalized-Hamming prediction loss.

Charge validation explicitly through Q_V and X_V. The complete one-fit setup cost is
F = α_R(Q_T+Q_V) + (α_I+α_O)(X_T+X_V) + α_C C_fit.
The hard memory requirement is B≥B_peak. Future task costs common to both policies are K resets, at most KH input and output symbols, and at most KH table transitions. The fitted model occupies α_M K H B_M bit-task units under either policy if each independent fit holds its table while predicting its task.

For this comparison, each task has a reset-query setup window with the same source interface and panel budget; the reuse policy can leave it unused. For K stationary tasks with zero loss, acquiring once costs F+common task cost; independent refitting costs KF+common task cost. Thus the strict break-even condition is exactly
(K−1)F>0.
In resource-vector form, the acquisition saves (K−1)Q reset queries, (K−1)X input symbols, (K−1)X output bits, and (K−1)C_fit local operations. It does not save model precision or task-time model storage; those terms cancel.

For drift with total reuse loss L and any additional noncommon reuse charge Δ, the comparison becomes
reuse is strictly cheaper iff (K−1)F > Δ+α_L L.
If per-task setup costs differ, with F_acq the one-time acquisition cost, the exact condition is
Σ_{t=1}^K F_t > F_acq+Δ+α_L L.
This is sharp for the declared weighted cost, but F_t for noisy drifted sources requires a separately proved sample/precision guarantee.

## Raw-transcript replay with refitting

A narrower baseline may acquire T∪V once, retain all X raw output bits, and rerun the exhaustive model search before each task. It uses the same legal observations, B_peak cap, and panel. Let F_obs=α_R Q+(α_I+α_O)X be the common one-time observation cost. Let C_fit be charged per full search, including validation checks against the retained transcript. The fitted table’s task-time storage and all task prediction operations are common. If raw transcript residence is charged at α_M per bit per task-horizon unit, then:

- reusable representation cost: F_obs + α_C C_fit + common task cost + α_L L;
- raw-retain/refit cost: F_obs + Kα_C C_fit + α_M K H X + common task cost.

Therefore the reusable representation beats this literal raw-only refitter iff
(K−1)α_C C_fit + α_M K H X > α_L L.
This is a genuine restricted-baseline frontier. The raw-only refitter is compelled to keep X sample bits and redo the model search; it is not the strongest retainer.

If the comparator may cache any derived B-bit state, it can run the same search once, keep the B_M-bit table, and erase or retain the transcript as desired. The strict frontier then disappears: its resource vector is exactly the same as the acquisition policy’s. This is Theorem 2, not a cost approximation.

## Drift and loss

For aligned stochastic task kernels with per-row joint output/next-state total-variation drift ε_t, define
L_max = Σ_{t=1}^K min{1, ε_t(H+1)/2}.
The representation’s expected normalized-Hamming loss is at most L_max. Its expected exact-sequence error on task t is at most min{1,Hε_t}. Charge α_L times the selected loss bound if using a worst-case budget. These guarantees are conditional on the drift assumptions in REPORT.md; the drift values are not learned or supplied by the acquisition oracle.

For deterministic future Mealy tasks, use the explicit task-distribution output-trace drift D_t from REPORT.md; the reuse loss is ΣD_t exactly. No bound on D_t is implied by a small reset-panel fit unless a structural relation is assumed.
