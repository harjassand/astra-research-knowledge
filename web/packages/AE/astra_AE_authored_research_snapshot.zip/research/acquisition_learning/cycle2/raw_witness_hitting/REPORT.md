# Raw-trajectory acquisition of a finite Hankel witness

**Status:** conditional theorem with direct proofs of the horizon, raw-path hit bound, finite-table rank recovery condition, coupon lower bound, and KL lower bound. The result is not externally proof-reviewed and makes no novelty or priority claim.

## 1. Claim and observation interface

There are \(N\) independent trajectories from one stationary finite-alphabet HMM, each of length \(T\), over alphabet \(\Sigma\), with \(|\Sigma|=a<\infty\). The learner may inspect every emitted symbol. It is given the alphabet and a known upper bound \(K\) on the number of hidden states, but not the exact state count, minimal predictive rank, any basis words, any values \(P(w)\), or any matrix responses. It cannot request a conditional sample, restart at a chosen context, or query a word probability. It may compute empirical word counts from observed paths.

For a word \(w\), write \(P(w)\) for its stationary occurrence probability at a fixed time. Use row-vector HMM conventions: if \(\alpha\) is the stationary hidden-state row vector, \(Q\) the transition matrix, and \(D_x\) the diagonal matrix of emission probabilities for symbol \(x\), put \(A_x=D_xQ\). Then
\[
P(x_1\cdots x_s)=\alpha A_{x_1}\cdots A_{x_s}\mathbf 1,
\qquad P(\epsilon)=1.
\]
The predictive Hankel matrix is \(H_{u,v}=P(uv)\), indexed by finite prefixes and suffixes. Its rank \(r\le K\) is the minimal linear predictive dimension. This predictive rank need not equal the number of hidden states.

The class promises a quantitative witness. There exist unknown sets \(U=\{u_1,\ldots,u_r\}\) and \(V=\{v_1,\ldots,v_r\}\), each consisting of distinct words of length at most \(r-1\), such that the rows indexed by \(U\) and columns indexed by \(V\) are bases of the full Hankel row and column spaces, and
\[
M=H[U,V],\qquad \sigma_{\min}(M)\ge\gamma>0,\qquad
P(u_iv_j)\ge p_*>0\quad(1\le i,j\le r). \tag{1}
\]
For the algorithmic rank-recovery statement, \(K\), a lower bound \(\gamma\), and the mass/mixing constants below are supplied in a computable representation. The last condition in (1) can be factored into context mass and continuation mass: if \(P(u_i)\ge p_U\) and \(P(v_j\mid u_i)\ge p_V\) for every pair, then \(p_*=p_Up_V\). This is a strong positivity promise on the unknown witness rectangle; it does not lower-bound every word in the alphabet.

For a single long path, assume uniform geometric mixing of the hidden chain:
\[
\sup_s\|Q^g(s,\cdot)-\pi\|_{\rm TV}\le C\rho^g,\qquad
C<\infty,\quad 0<\rho<1. \tag{2}
\]
The observation process inherits this upper bound on dependence between separated blocks. Independent stationary trajectory starts need no burn-in. If starts are arbitrary, discard \(b\) symbols per path and add the explicit coupling error \(NC\rho^b\). All probability guarantees below are conditional on (1) and (2); \(K,\gamma,p_*,C,\rho\) are premises, not quantities learned for free.

## 2. A minimal basis has bounded word horizon

**Lemma 1 (finite witness horizon).** For an HMM with predictive Hankel rank \(r\), there are row-basis words and column-basis words of length at most \(r-1\). Hence a nonsingular minimal witness matrix can be chosen from words \(uv\) of length at most \(2r-2\), and the supplied state cap gives the universal horizon
\[
L_K=2K-2\quad(K\ge2). \tag{3}
\]

**Proof.** The HMM gives a finite linear representation \(P(w)=\alpha A_w\mathbf 1\). Let \(\mathcal R\) be the span of reachable rows \(\alpha A_u\), and define
\[
\mathcal N=\{x\in\mathcal R:xA_v\mathbf1=0\text{ for every word }v\}.
\]
The subspace \(\mathcal N\) is invariant under right multiplication by every \(A_x\): if \(z\in\mathcal N\), then \((zA_x)A_v\mathbf1=zA_{xv}\mathbf1=0\). The quotient \(\mathcal R/\mathcal N\) is therefore a linear representation of the same word-probability series. The map from a reachable row to its values against all suffixes has kernel exactly \(\mathcal N\), so the quotient dimension is the Hankel rank \(r\).

In this minimal representation, let \(R_\ell=\operatorname{span}\{[\alpha A_u]:|u|\le\ell\}\). It starts at dimension one because \(P(\epsilon)=1\). If \(R_{\ell+1}=R_\ell\), then \(R_\ell\) is invariant under every symbol operator and no later prefix enlarges it. Otherwise dimension increases by at least one. Since its final dimension is \(r\), the prefix span is stable by depth \(r-1\). Applying the dual argument to the observable columns \(A_v\mathbf1\) gives suffix span depth at most \(r-1\). Choose \(r\) basis rows and \(r\) basis columns from these finite spans. Their cross-pairing is nonsingular: a vector in either basis annihilating the other full basis would be zero in the minimal representation. This gives the witness matrix and (3). \(\square\)

For \(K=1\), \(r=1\) and the empty-word pair \(H_{\epsilon,\epsilon}=1\) is already a witness; no emitted symbol is needed. Below assume \(K\ge2\).

Let
\[
\mathcal W_K=\{w:|w|\le K-1\},\qquad
W_K=|\mathcal W_K|=\sum_{j=0}^{K-1}a^j.
\]
The complete finite block \(H^{(K)}=H[\mathcal W_K,\mathcal W_K]\) has rank exactly \(r\), because it contains bases for both full spaces. Moreover, (1) implies \(\sigma_r(H^{(K)})\ge\gamma\): the witness matrix is a row/column submatrix, and selection cannot increase singular values. All remaining singular values are zero.

## 3. Raw-path witness hitting theorem

Set the observed block length to \(L=L_K=2K-2\). From each path, choose \(m\) nonoverlapping length-\(L\) windows with at least \(g\) intervening symbols. For \(T\ge L\), the largest regular schedule has
\[
m=1+\left\lfloor\frac{T-L}{L+g}\right\rfloor,\qquad Q_0=Nm. \tag{4}
\]
The learner can scan every chosen window and every other symbol in each trajectory. The starts are fixed independently of the unknown basis. If $b$ symbols are discarded for burn-in, use $T-b$ in (4).

**Theorem 2 (witness words occur in raw paths).** Under (1) and (2),
\[
\Pr[\text{every }u_iv_j\text{ occurs in at least one selected raw window}]
\ge 1-r^2e^{-Q_0p_*}-N(m-1)C\rho^g. \tag{5}
\]
For nonstationary starts after burn-in \(b\), subtract an additional \(NC\rho^b\). Thus, for stationary starts, it suffices that
\[
Q_0\ge p_*^{-1}\log\frac{2K^2}{\delta},
\qquad
N(m-1)C\rho^g\le\delta/2 \tag{6}
\]
to hit the full witness rectangle with probability at least \(1-\delta\). A conservative gap for \(m\ge2\), using \(m-1\le T\), is
\[
g\ge\max\left\{0,\left\lceil\frac{\log(2NTC/\delta)}{-\log\rho}\right\rceil\right\}. \tag{7}
\]
If there is only one window per path, no gap is needed; set $g=0$. Constants shift by at most one depending on whether the gap is counted in symbols or hidden transitions.

**Proof.** Uniform ergodicity couples each later length-\(L\) window, conditional on all earlier windows in that path, to a fresh stationary length-\(L\) window with failure probability at most \(C\rho^g\). Sequentially coupling all paths costs at most \(N(m-1)C\rho^g\). On the complementary event, the \(Q_0\) windows are independent and stationary. For any witness word \(w=u_iv_j\), the probability at a window start is at least \(p_*\), so its miss probability is at most \((1-p_*)^{Q_0}\le e^{-Q_0p_*}\). There are \(r^2\le K^2\) cells; a union bound proves (5). Arbitrary initial laws add at most \(C\rho^b\) for each first window. \(\square\)

With \(N\) independent stationary episodes of length exactly \(L\), there is one independent window per episode and no mixing penalty. In this clean episodic case, \(N\ge p_*^{-1}\log(K^2/\delta)\) trajectories suffice for literal encounter. A longer path can contribute more windows, with the mixing-gap cost above.

## 4. From occurrence to a data-derived basis

The hit statement alone does not give numerical probabilities or identify the unknown words. A finite legal reconstruction route uses only the observed blocks and the known alphabet/cap \(K\).

For every distinct word \(w\) of length at most \(L_K\), count the selected windows whose prefix is \(w\). Let \(\widehat P(w)\) be that count divided by \(Q_0\). Build the estimated finite Hankel block by lookup:
\[
\widehat H^{(K)}_{u,v}=\widehat P(uv),\qquad u,v\in\mathcal W_K.
\]
No probability or matrix entry was requested from the source. Cells with the same concatenated word reuse the same count. The table has \(W_K^2\) cells and at most
\[
D_K=\sum_{j=0}^{2K-2}a^j \tag{8}
\]
distinct word counters.

On coupled-independent windows, Hoeffding and a union bound give
\[
\Pr\left[\max_{u,v}|\widehat H^{(K)}_{u,v}-H^{(K)}_{u,v}|>\eta\right]
\le 2W_K^2e^{-2Q_0\eta^2}. \tag{9}
\]
Add \(N(m-1)C\rho^g\) (and, if applicable, \(NC\rho^b\)) for the original paths. If
\[
\eta\le\frac{\gamma}{4W_K},\qquad
Q_0\ge\frac{8W_K^2}{\gamma^2}\log\frac{4W_K^2}{\delta_{\rm est}}, \tag{10}
\]
then, with the corresponding estimation and coupling probability, \(\|\widehat H^{(K)}-H^{(K)}\|_{\rm op}\le W_K\eta\le\gamma/4\). Weyl's inequality puts the \(r\)-th empirical singular value above \(3\gamma/4\) and all remaining singular values at most \(\gamma/4\); thresholding at \(\gamma/2\) recovers the unknown rank \(r\).

For the true witness rectangle, the empirical \(r\times r\) block has operator error at most \(r\eta\le K\eta\le\gamma/4\), since \(W_K\ge K\). It therefore has minimum singular value at least \(3\gamma/4\). Enumerating candidate word sets and checking certified singular-value intervals finds a data-derived pair with minimum singular value at least \(\gamma/2\). This exhaustive search is finite and does not receive \(U,V\), but can be combinatorial in \(W_K\). It proves acquisition, not a polynomial-time basis-finding algorithm.

For both literal occurrence and this full-table rank/basis recovery, take the maximum of the coupon window count in (6) and the estimation count in (10), along with mixing or burn-in charges. The accuracy condition depends on \(W_K\), which is exponential in \(K\) for \(a\ge2\). The finite-horizon result alone is not a polynomial-in-\(K\) acquisition algorithm.

## 5. Sharp coupon lower bound for small witness masses

For an iid block distribution with \(M\) distinct required witness words, each of mass \(q\), the coupon scale is
\[
n=\Theta\!\left(q^{-1}\bigl(\log M+\log(1/\delta)\bigr)\right). \tag{11}
\]
The union-bound upper side is \(n\ge q^{-1}\log(M/\delta)\). For the lower side, let \(X\) count the unseen required words. Then
\[
\mathbb E X=M(1-q)^n,\qquad
\operatorname{Cov}(1\{i\text{ unseen}\},1\{j\text{ unseen}\})\le0
\]
for distinct categories, because \((1-2q)^n\le(1-q)^{2n}\). Hence \(\operatorname{Var}(X)\le\mathbb EX\) and \(\Pr[X=0]\le1/\mathbb EX\). For \(n\le(1-o(1))q^{-1}\log M\), the expected number unseen diverges and the probability of complete coverage tends to zero. A single category gives the confidence lower bound \(n\ge\log(1/\delta)/[-\log(1-q)]\). Together these match (11) up to constants. For nonuniform masses, a small minimum alone gives the one-word confidence obstruction; the extra \(\log M\) requires many comparably rare distinct words.

This coupon scale occurs in an explicit rank-\(K\) HMM. Let the hidden chain have \(K\) states, uniform stationary law, and transition matrix
\[
Q=(1-\lambda)I+\lambda\frac{\mathbf1\mathbf1^\top}{K},
\qquad 0<\lambda<1. \tag{12}
\]
At state \(i\), emit the observed pair \(X=(i,Z)\), with \(Z\sim\operatorname{Bernoulli}(1/2)\). The state label is exposed, which only makes acquisition easier. The hidden chain contracts at rate \(1-\lambda\). Set \(u_i=v_i=(i,0)\). Then
\[
H[U,V]=\frac1{4K}Q,\qquad
\operatorname{rank}H[U,V]=K,\qquad
\sigma_{\min}(H[U,V])=\frac{1-\lambda}{4K}.
\]
Moreover, \(P(u_i)=1/(2K)\), \(P(v_j\mid u_i)=Q_{ij}/2\ge\lambda/(2K)\), and every cross-word is positive. Each off-diagonal witness word \(u_iv_j=((i,0),(j,0))\), \(i\ne j\), has probability
\[
q=\frac{\lambda}{4K^2}.
\]
There are \(M=K(K-1)\) such distinct words. With \(N\) independent raw length-two trajectories, each trajectory supplies one pair draw. The coupon lower bound requires
\[
N=\Omega\!\left(\frac{K^2}{\lambda}\log K\right)
\]
to encounter every off-diagonal witness word. The union-bound upper has the same order for fixed \(\lambda\) and constant confidence. Diagonal witnesses have mass \(\Theta(1/K)\) and do not change the rate. Thus (5) has the correct inverse-mass and log-number dependence for literal witness coverage. This lower bound concerns acquiring every witness cell, not every prediction objective.

## 6. KL lower bound for a rare-context prediction

The coupon lower concerns literal occurrence of all witness cells. Prediction can also require repeated observations at a rare context. In the same HMM family, for each state \(j\), define model \(P_j\) by changing only its bit emission to
\[
Z\mid S=j\sim\operatorname{Bernoulli}(1/2+\varepsilon),
\qquad 0<\varepsilon\le1/4,
\]
while other states retain Bernoulli\((1/2)\) emissions. The stationary state distribution is uniform and predictive rank remains \(K\). For witness words \(u_i=v_i=(i,0)\), the witness matrix is
\[
H_j[U,V]=\operatorname{diag}\!\left(\frac{q_i}{K}\right)Q\operatorname{diag}(q_i),
\qquad q_i=P(Z=0\mid S=i)\in[1/4,1/2],
\]
so \(\sigma_{\min}(H_j[U,V])\ge(1-\lambda)/(16K)\), and every cross-word has mass at least \(\lambda/(16K^2)\). The context \(u_j=(j,0)\) has mass at least \(1/(4K)\).

After context \(u_j\), the probability that the next output bit equals one is
\[
P_j(Z_{t+1}=1\mid X_t=(j,0))
=\frac12+Q_{jj}\varepsilon,\qquad
Q_{jj}=1-\lambda+\lambda/K.
\]
It differs from the baseline prediction \(1/2\) by at least \((1-\lambda)\varepsilon\). Thus an estimator returning all these conditional predictions to error below \((1-\lambda)\varepsilon/3\) identifies which state \(j\) carries the changed prediction.

For \(N\) independent stationary paths of length \(T\), the hidden-state law is common to all models. The emitted label reveals the state, so the observed-data KL is exactly the conditional-emission KL:
\[
D(P_j^{\otimes N,T}\|P_0^{\otimes N,T})
=\frac{NT}{K}D\!\left(\operatorname{Bern}(1/2+\varepsilon)\middle\|\operatorname{Bern}(1/2)\right)
\le \frac{4NT\varepsilon^2}{K}. \tag{13}
\]
The last inequality follows from the chi-square upper bound on Bernoulli KL. Fano's inequality over the \(K\) alternatives implies that identifying the changed context with error at most \(1/3\) requires
\[
NT=\Omega\!\left(\frac{K}{\varepsilon^2}\log K\right)
=\Omega\!\left(\frac{1}{p_{\rm ctx}\varepsilon^2}\log K\right),
\qquad p_{\rm ctx}\asymp1/K. \tag{14}
\]
For small \(K\), the two-point bound below supplies the constant-order form. Le Cam's two-point argument gives \(NT=\Omega(K/\varepsilon^2)\). These bounds hold even when the transition/emission architecture and state labels are otherwise known. They rule out a uniform sample guarantee independent of context mass and response margin; they do not rule out polynomial acquisition when both have explicit lower bounds.

## 7. Full-data baseline and adaptive CUR

The full-data baseline receives the same \(N\) paths and retains every symbol. It can run the same fixed window scan, word-counter update, concentration test, and candidate-basis search. Any adaptive CUR procedure based on these paths is a randomized postprocessing of this raw sample (plus its own coins); a full-data learner can simulate it. Therefore, for every loss and every \(N,T\), the minimum achievable risk with retained trajectories is no greater than that of adaptive CUR output. CUR cannot reduce raw trajectory count, observed symbol count, or rare-context occurrences required by (11)–(14).

CUR can change computation after data acquisition: if a legal algorithm finds a well-conditioned basis, it can store selected rows/columns and factorize a low-rank block instead of carrying out a dense SVD. This report does not prove that such a basis can be found in polynomial time under only (1)–(2). The elementary unknown-basis procedure stores \(D_K\) word counters and performs a finite search; its cost is exponential in \(K\). A faster CUR route needs additional structure, such as coherence/sampling conditions or a separately proved rank-revealing selection guarantee. Calling a selected row/column an oracle response would be inaccurate: every entry here comes from observed paths.

Both methods use the same \(NT\) observed symbols and, if starts are not stationary, the same \(Nb\) burn-in symbols. The full-data learner can always emulate CUR. Fewer samples would require a different access model, such as conditional resets or direct \(P(w)\) queries, which is excluded here.

## 8. Cost ledger

Let \(a=|\Sigma|\), \(L=2K-2\), \(W_K=\sum_{j=0}^{K-1}a^j\), \(D_K=\sum_{j=0}^{2K-2}a^j\), and \(Q_0=Nm\).

- **Raw data:** \(NT\) emitted symbols, plus \(Nb\) discarded symbols for nonstationary starts. Reading costs \(O(NT)\) symbol operations and \(O(NT\log a)\) bits if all paths are retained.
- **Witness hitting:** \(Q_0\ge p_*^{-1}\log(2K^2/\delta_{\rm hit})\) windows, with the dependence penalty in (5). For independent length-\(L\) episodes, \(N=Q_0\), each episode costs \(L\) symbols, and no mixing penalty is present.
- **Uniform word counts:** at most \(D_K\) integer counters, each using \(O(\log(Q_0+1))\) bits, plus \(O(D_KL\log a)\) bits for direct word keys. Each block updates its \(L+1\) prefixes in \(O(L)\) operations. Constructing the finite Hankel table uses \(W_K^2\) lookups.
- **Rank/basis recovery:** a sufficient count is \(Q_0\ge8W_K^2\gamma^{-2}\log(4W_K^2/\delta_{\rm est})\), in addition to hitting. A certified SVD or exact-rational rank test uses a \(W_K\times W_K\) table. Exhaustively searching well-conditioned \(r\times r\) submatrices can cost \(\binom{W_K}{r}^2\) candidates, exponential in \(K\) for fixed \(a\ge2\).
- **Numerical precision:** empirical probabilities have denominator \(Q_0\). A certified singular-value calculation must resolve the threshold gap \(\gamma/2\); this takes \(O(\log(W_K/\gamma))\) precision bits up to conditioning and rounding terms. No specific library or practical runtime is assumed.
- **CUR versus full data:** both pay identical path/sample and word-scan cost. CUR may reduce later matrix storage and factorization only after basis extraction; the theorem proves no statistical saving.

The word-count estimator is a finite computation using integer counters and certified rational/numerical intervals. This report does not claim a practical certified-SVD implementation or suppress the exponential dependence on \(K\).

## 9. UNKNOWN and claim boundaries

- **No state/rank cap:** without known \(K\), the uniform horizon \(2K-2\) and finite candidate universe are unavailable. A finite observed path cannot certify that a longer context is unnecessary.
- **No positive witness mass:** if a basis cell has \(P(u_iv_j)=0\), literal encounter is impossible. If its mass is arbitrarily small, no uniform finite hit budget exists. An unobserved word is not evidence that its probability is zero.
- **No singular margin:** exact population rank may be \(r\) while nonzero singular values approach zero. No uniform finite-sample rank/basis recovery guarantee follows without a quantitative gap such as \(\gamma\).
- **No mixing or independent starts:** repeated windows from one path can be arbitrarily redundant; (5) does not apply without dependence control or independent stationary episodes.
- **No efficient unknown-basis search:** a well-conditioned witness's existence does not itself yield a polynomial-time procedure to locate it from a dense finite table. The exhaustive procedure is finite but exponential.
- **No sample improvement from CUR:** postprocessing cannot beat an equally informed retained-trajectory learner. A stronger claim would need an oracle/control interface or a restricted baseline.
- **No arbitrary HMM parameter identification:** the theorem acquires a finite predictive Hankel witness and rank under its stated margin; it does not uniquely identify hidden labels, a positive realization, or all parameter matrices.
- **No formula-hitting transfer:** the proof uses stationary HMM path probabilities and raw observations. It makes no use of noncommutative rational formulas, formula coefficient encodings, matrix-evaluation oracles, or cycle-1 finite examples.
- **No all-field or novelty claim:** these are real-valued HMM probabilities. No extension to arbitrary fields, external proof review, exhaustive literature audit, or priority assessment is claimed.

## 10. Primary sources and comparison

1. J. W. Carlyle and A. Paz, “Realizations by Stochastic Finite Automata,” *Journal of Computer and System Sciences* 5(1), 26–40 (1971), [publisher DOI](https://doi.org/10.1016/S0022-0000(71)80005-3). The paper connects finite Hankel rank of a string function with finite-state sequential realization. It supports the predictive linear-representation framework; the depth-\(r-1\) witness bound here is proved directly.
2. D. Hsu, S. M. Kakade, and T. Zhang, “A Spectral Algorithm for Learning Hidden Markov Models,” *JCSS* 78(5), 1460–1480 (2012), [journal version](https://doi.org/10.1016/j.jcss.2011.12.025), [arXiv version](https://arxiv.org/abs/0811.4413). This is a primary raw-observation spectral HMM-learning result under parameter separation. It is a comparison point, not a source for the present coupon theorem or for a CUR sample advantage.
3. B. Yu, “Rates of Convergence for Empirical Processes of Stationary Mixing Sequences,” *Annals of Probability* 22(1), 94–116 (1994), [DOI](https://doi.org/10.1214/aop/1176988849). Yu develops independent-block coupling for beta-mixing sequences. The finite-state geometric-mixing coupling in (5) is stated and bounded directly here.

**Comparison status:** internally derived result plus primary-source context; no external proof review, exhaustive literature review, or novelty assessment. Source theorem statements are not imported as stronger claims than the access models and assumptions above.
