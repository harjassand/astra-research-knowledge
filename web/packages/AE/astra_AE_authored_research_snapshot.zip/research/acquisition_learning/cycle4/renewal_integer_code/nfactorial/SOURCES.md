# Primary source

Han, Jiang, and Wu, “Prediction from compression for models with infinite
memory, with applications to hidden Markov and renewal processes,”
arXiv:2404.15454v1 (2024), https://arxiv.org/html/2404.15454v1.

Relevant statements: Proposition 1 gives the stationary redundancy-to-risk
conversion used by the fixed-horizon HJW suffix average; Theorem 4 states the
stationary renewal minimax rate is Theta(n^(-1/2)); Section 3.4 bounds the
renewal memory term by log(n+2)/n. The explicit pointwise redundancy bound for
the type-first Q_N assignment was established in the preceding Cycle 4
result. This implementation task changes only exact arithmetic and does not
claim a new statistical theorem.
