# Source and provenance ledger

This is a bounded primary-source check for the stationary renewal code and
the risk conversion. It does not establish novelty.

1. Yanjun Han, Tianze Jiang, and Yihong Wu, “Prediction from compression for
   models with infinite memory, with applications to hidden Markov and
   renewal processes,” arXiv:2404.15454v1 (23 Apr 2024),
   <https://arxiv.org/html/2404.15454v1>.
   Proposition 1 defines the suffix-averaged terminal predictor and bounds
   its expected KL loss by block redundancy/n plus a memory term. Theorem 4
   gives minimax renewal risk Theta(n^-1/2). Section 3.4 uses the stationary
   countdown HMM and bounds memory by log(n+2)/n, gets the optimal rate from
   Theta(sqrt(n)) NML redundancy, then calls a computationally efficient
   optimal renewal predictor unclear. Section 1 defines the stationary
   initial wait P(W=w)=m_mu^-1 sum_{j>=w}mu(j).

2. Imre Csiszár and Paul C. Shields, “Redundancy rates for renewal and other
   processes,” IEEE Transactions on Information Theory 42(6), 2065-2072
   (1996), DOI <https://doi.org/10.1109/18.556596>.
   HJW cite this for Theta(sqrt(n)) minimax redundancy. The article's full
   text was not directly accessible during this bounded audit.

3. Imre Csiszár, “The Method of Types,” IEEE Transactions on Information
   Theory 44(6), 2505-2523 (1998),
   <https://iest2.ie.cuhk.edu.hk/~whyeung/post/manuscript/06_SAEP/method%20of%20types.pdf>.
   Section VII identifies renewal types by counts of zero-run lengths,
   explains same-type equiprobability under its renewal convention, and
   reports the exp(O(sqrt(n))) renewal type-class count proved by
   Csiszár-Shields. This makes the general type-class route established prior
   art. Its initial-wait convention has not been reconciled line-by-line with
   the stationary likelihood used here. Whether the precise
   start-position-weighted stationary assignment and shared all-suffix marked
   DP below appeared before is UNKNOWN.

4. Aurélien Garivier, “Modèles contextuels et alphabets infinis en théorie
   de l'information,” PhD thesis (2006),
   <https://www.numdam.org/item/BJHTUP11_2006__0708__P0_0.pdf>.
   Chapter 3 equation (3.12) gives the renewal likelihood with a special
   first-passage factor and right-censored terminal factor. Theorem 22 on
   printed p.85 (PDF p.90) visually reads
   C1 sqrt(n) log_2 n <= R_n^*(CTW|R) <= C2 sqrt(n) log_2 n.
   The thesis describes CTW as an efficient renewal code but with a log n
   factor above minimax order. The PDF page was rendered locally from
   `work/programmes/acquisition_learning/cycle4/renewal_novelty_check/garivier_2006_thesis.pdf`.

5. Philippe Flajolet and Wojciech Szpankowski, “Analytic Variations on
   Redundancy Rates of Renewal Processes,” IEEE Transactions on Information
   Theory 48(11), 2911-2921 (2002), DOI
   <https://doi.org/10.1109/TIT.2002.804115> and author copy
   <https://algo.inria.fr/flajolet/Publications/FlSz02.pdf>.
   Its precise asymptotics are for nonstationary renewal sources; it is
   included to keep that model boundary explicit, not used for the proof.

No broad post-2024 priority search was completed. The primary CS96 paper was
not inspected directly. Do not claim that this algorithm closes a published
open problem as a novel contribution until those gates and an independent
proof review are complete.
