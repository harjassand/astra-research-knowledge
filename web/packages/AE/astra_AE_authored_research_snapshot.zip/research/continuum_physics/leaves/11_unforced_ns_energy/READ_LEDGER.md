# Read ledger

Date checked: 2026-10-08

| Source | Type and date | What was read | What it supports here | Limits |
|---|---|---|---|---|
| Jean Leray, [*Sur le mouvement d'un liquide visqueux emplissant l'espace*](https://doi.org/10.1007/BF02547354), Acta Math. 63 (1934), 193–248 | Primary research paper | Original PDF, especially the introduction (printed pp. 193–195), energy-dissipation passage (around printed p. 241), and weak-solution definition | Leray's global weak construction uses an energy-dissipation inequality; the introduction explicitly cautions that bounded kinetic energy alone need not imply regularity | Historical notation differs from the modern Leray–Hopf formulation; modern norm statement and rescaling calculations are written out independently in RESULT.txt |
| Eberhard Hopf, [*Über die Anfangswertaufgabe für die hydrodynamischen Grundgleichungen*](https://doi.org/10.1002/mana.3210040121), Math. Nachr. 4 (1950/1951), 213–231 | Primary research paper | Wiley publisher metadata and date/pages | Historical attribution for the weak initial-value framework | Full text was not inspected; this source is not needed for any derived estimate |
| James Serrin, [*On the interior regularity of weak solutions of the Navier-Stokes equations*](https://doi.org/10.1007/BF00253344), Arch. Rational Mech. Anal. 9 (1962), 187–195 | Primary research paper | Springer publisher record and CiNii bibliographic record | Historical reference for interior regularity / Prodi–Serrin context and accurate title/date/pages | The inspected publisher view did not expose the full article. The stated L5 criterion is proved directly for maximal strong solutions in RESULT.txt, not attributed as a verbatim theorem from this article |

## Evidence integrity

- The rescaling counterexample is an exact transformation of a local smooth solution of the unforced PDE, not a forced example or a numerical simulation.
- The proof uses standard local strong existence for smooth data and standard H1 continuation. These are named proof dependencies, not independently reproved from primary-source texts in this leaf.
- No code, solver, or finite numerical diagnostic was run. All displayed rescaling identities are direct changes of variables.
- No external novelty, full global regularity, or blowup claim is made.
