# Read ledger — leaf 12

Audit date: 2026-10-08. Scope was restricted to the no-slip incompressible Navier–Stokes / smooth Euler limit, Kato's strip condition, energy/enstrophy bounds, and the requested shear test.

| Source | What was read / used | Role and limits |
|---|---|---|
| Kato (1984), “Remarks on zero viscosity limit for nonstationary Navier–Stokes flows with boundary,” https://doi.org/10.1007/978-1-4612-1110-5_6 | Bibliographic primary source and theorem identification (pp. 85–98) | Original criterion. Full chapter text was not independently obtained in this session; proof details were reconstructed and cross-checked against the explicit later corrector proof below. |
| Schröder & Wiedemann (2026), “On the vanishing viscosity limit for inhomogeneous incompressible Navier–Stokes equations on bounded domains,” https://doi.org/10.1007/s00030-026-01198-z | Springer full text: introduction lines 61–74; energy inequality lines 92–112; Theorem 3.1 lines 176–201; corrector construction and bounds lines 208–231; estimates lines 271–302; converse lines 303–322; publication date 2026-02-20 | Published primary extension. Setting density constant recovers homogeneous Kato. The corrector estimates and Hardy-bound use support the reconstructed quantitative proof. “No rigorous example known” is the authors' literature-status statement at publication, not a theorem or exhaustive novelty result. |
| Kelliher (2014), “Observations on the vanishing viscosity limit,” https://arxiv.org/abs/1409.7716 | Abstract and HTML excerpts identifying Kato-equivalent conditions and later examples | Supplemental secondary synthesis; not used to establish the primary theorem. |

## Derived in this leaf

1. Pointwise and integrated local kinetic-energy balance for a smooth Navier–Stokes solution, including orientation and sign of the inner-strip flux.
2. Corrector residual bounds and a Grönwall modulus with the viscosity and strip-dissipation powers displayed, using the corrector estimates and Hardy/Poincaré bound.
3. Nonimplication of the Kato little-o condition from the O(1) Leray energy bound; implication from a genuinely uniform-in-viscosity H1 bound.
4. Exact Fourier/heat-semigroup shear solution and the O(nu times log(1/nu)) Kato-strip estimate.
5. Distinction between an O(1)-instantaneous-power shear profile and an actual unforced trajectory.

## Not done

No exhaustive literature search, formal proof-assistant replay, independent mathematician review, numerical solve, grid convergence study, or force-dependent extension proof. The open-example status is bounded by the cited published source and must be refreshed before any priority claim.
