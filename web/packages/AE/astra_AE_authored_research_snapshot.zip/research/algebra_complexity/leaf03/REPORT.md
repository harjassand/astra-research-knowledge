# Leaf 03 — Border rank, finite-bit extraction, and the W-tensor obstruction

## Scope and status

**Result.** A supplied, exact Laurent-polynomial border-rank witness with bounded exponent support yields an exact base-field rank decomposition of tensor powers, with a polynomial overhead in the tensor-power parameter. It does not yield an exact rank-r decomposition of the original tensor. The (2\times2\times2) W tensor is a rational counterexample: it has border rank 2 and exact rank 3. Its standard rank-2 approximants have coefficient size and a cancellation condition number growing as the inverse approximation error.

**Status.** The coefficient-extraction lemma and both W-tensor claims below have self-contained proofs. The finite-bit bounds apply when the exact witness is supplied in the stated encoding; they are not an acquisition theorem. The explicit decomposition output bound is charged and may be exponentially large. This result gives no finite-bit requested-output matrix-multiplication algorithm and no new matrix-multiplication exponent.

**Restart.** To advance the selective-output target, the next required object is an exact, mask-dependent, value-independent circuit or a mask-aware degeneration with bounded Laurent degree and coefficient height, controlled conditioning, and an efficient circuit for applying the extracted decomposition. Its mask acquisition, coefficient acquisition, field extension, and decoding costs must be included.

## 1. Exact extraction from a supplied degeneration

Let (F) be a field, (E/F) a finite extension of degree (k), and let (T\in F^{n_1}\otimes F^{n_2}\otimes F^{n_3}). Assume an exact supplied witness

\[
G(t)=\sum_{i=1}^{r}a_i(t)\otimes b_i(t)\otimes c_i(t)
\]

with (a_i,b_i,c_i) Laurent-polynomial vectors over (E). Suppose every coordinate exponent in every factor lies in ([-d,d]), and the formal tensor identity is

\[
G(t)=T+tT_1+t^2T_2+\cdots.
\]

Thus all negative-power coefficients cancel in the sum and the constant coefficient is exactly (T). For every integer (m\ge1),

\[
\operatorname{rank}_{F}(T^{\otimes m})\le k^3 r^m(2md+1)^2. \tag{1}
\]

When (E=F), take (k=1). The theorem uses the supplied symbolic identity; a numerical sequence of approximate tensors alone does not meet its hypotheses.

**Proof.** First work over (E). Since (G(t)=T+O(t)), the constant coefficient of (G(t)^{\otimes m}) is (T^{\otimes m}). Distribute the (r)-term sum across the (m) tensor factors. There are (r^m) choices \(\mathbf i=(i_1,\ldots,i_m)\), and the corresponding summand is

\[
A_{\mathbf i}(t)\otimes B_{\mathbf i}(t)\otimes C_{\mathbf i}(t),
\]

where, for example, (A_{\mathbf i}(t)=a_{i_1}(t)\otimes\cdots\otimes a_{i_m}(t)). Each of these three vector-valued Laurent polynomials has exponents in ([-md,md]). Write their coefficient vectors as (A_{\mathbf i,u},B_{\mathbf i,v},C_{\mathbf i,w}). The constant coefficient of this summand is

\[
\sum_{u+v+w=0} A_{\mathbf i,u}\otimes B_{\mathbf i,v}\otimes C_{\mathbf i,w}.
\]

Choose (u,v\in[-md,md]\); then (w=-u-v) is forced. There are at most ((2md+1)^2) choices, and every displayed term is rank one over (E). Summing over \(\mathbf i\) proves the bound (r^m(2md+1)^2) over (E).

For descent, choose an (F)-linear functional \(\ell:E\to F\) with \(\ell(1)=1) and an (F)-basis (e_1,\ldots,e_k) of (E). For any one rank-one tensor (u\otimes v\otimes w) over (E), expand each vector coordinatewise in this basis. Applying \(\ell\) to the tensor entries gives a sum of at most (k^3) tensors of the form (u_a\otimes v_b\otimes w_c) over (F), with scalar \(\ell(e_ae_be_c)\) absorbed into one vector. Applying \(\ell) to the whole decomposition preserves (T^{\otimes m}), since its entries lie in (F) and \(\ell(1)=1\). This gives (1). \(\square\)

For fixed (r,d,k), the overhead in (1) is polynomial in (m), so

\[
\limsup_{m\to\infty}\operatorname{rank}_{F}(T^{\otimes m})^{1/m}\le r.
\]

This is an exact algebraic statement about tensor powers. It does not assert \(\operatorname{rank}(T)\le r\), and it does not by itself produce a compact or fast circuit for applying the large decomposition.

## 2. Finite-bit and cost contract

The following costs are for the stated explicit construction, not hidden in the word “extraction.”

* **Supplied data.** The witness supplies (r,n_1,n_2,n_3,d), every Laurent coefficient, the field representation, and an exact formal identity (G(t)=T+O(t)). For rational coefficients, suppose each input numerator and denominator has at most (h) bits. If the witness is not supplied, its acquisition cost (P) must be added; border rank as an existential statement gives no bound on (P).
* **Identity verification.** For (E=\mathbb Q), direct convolution and comparison of all tensor coordinates verifies the negative-power cancellations and constant coefficient using (O(r n_1n_2n_3d^2)) rational operations. The bit cost is polynomial in these parameters and the encoded coefficient lengths. This verification is not a substitute for acquiring the coefficients.
* **Exact output size and time.** Put (R_m=r^m(2md+1)^2). Before field descent, the decomposition contains at most (R_m) rank-one terms, each with three vectors of lengths (n_1^m,n_2^m,n_3^m). Explicit dense listing therefore writes at most (R_m(n_1^m+n_2^m+n_3^m)) field elements. A direct construction takes at most this output scale times a polynomial in (m,d) field operations; it has no claim of polynomial-in-(m) total time. After extension descent, multiply the term and output costs by at most (k^3).
* **Coefficient bit growth.** A coordinate of an (m)-fold coefficient vector is a sum of at most ((2d+1)^m) products of (m) input rationals. Using product denominators gives (O(m(h+\log(d+1)))) bits per rational coordinate, up to constant factors. If (E/\mathbb Q) is used, also supply and charge a basis, multiplication structure constants, and their heights; the per-coordinate bound becomes (O(m(h+h_E+\log(k(d+1))))) for a fixed encoding height bound (h_E), again up to constant factors. The number-field rank loss is the explicit factor (k^3), not a free field operation.
* **Precision.** Exact rational input needs no numerical precision. If coefficients are acquired only as certified approximations and their numerator and denominator bounds are known to be (2^h), a conservative rational-reconstruction threshold is absolute error below (2^{-2h-1}) per coefficient: distinct rationals with denominators at most (2^h) are separated by at least (2^{-2h}). Without a height bound, no finite precision threshold follows. If only the target tensor is observed, rather than the factors, this coefficient-reconstruction argument does not acquire a decomposition.
* **Conditioning.** For a specialized decomposition (S=\sum_i u_i\otimes v_i\otimes w_i), use the cancellation measure

\[
\kappa_{\rm sum}(S)=\frac{\sum_i\|u_i\|_2\|v_i\|_2\|w_i\|_2}{\|S\|_F}.
\]

Under relative perturbations of the factors of size \(\eta\), the first-order absolute output error is at most (O(\eta\,\kappa_{\rm sum}(S)\|S\|_F)). A bound on the witness height does not bound this condition measure after specialization. The W family below has \(\kappa_{\rm sum}=\Theta(1/|t|)\).

The explicit output bound is deliberately conservative and often enormous. To turn (1) into a useful arithmetic algorithm, one needs additional structure showing how to apply the decomposition without densely writing every coordinate. The L03 arithmetic exponent record supplies no such machine-bit or selective-output application procedure.

## 3. Counterexample: border rank 2 does not extract exact rank 2

Let (e_0,e_1) be the standard basis of \(\mathbb Q^2\), and set

\[
W=e_1\otimes e_0\otimes e_0+e_0\otimes e_1\otimes e_0+e_0\otimes e_0\otimes e_1.
\]

For every nonzero rational (t), define

\[
W(t)=t^{-1}(e_0+te_1)^{\otimes3}-t^{-1}e_0^{\otimes3}.
\]

This is a sum of two simple tensors, so its exact rank is at most 2. Expanding gives

\[
W(t)=W+t(e_1\otimes e_1\otimes e_0+e_1\otimes e_0\otimes e_1+e_0\otimes e_1\otimes e_1)+t^2e_1^{\otimes3}.
\]

Thus (W(t)\to W) as (t\to0), with \(\|W(t)-W\|_\infty=|t|\) for (0<|t|\le1). Therefore \(\underline{\operatorname{rank}}_{\mathbb Q}(W)\le2\).

Now slice by the third factor. The two matrix slices are

\[
A_0=\begin{pmatrix}0&1\\1&0\end{pmatrix},\qquad
A_1=\begin{pmatrix}1&0\\0&0\end{pmatrix},
\]

so \(\det(xA_0+yA_1)=-x^2\), a nonzero quadratic with a repeated linear factor. If (W) had rank at most 2, its two third-mode vectors would have to be independent because its two slices are independent. Its first- and second-mode vector pairs would also have to be independent because (A_0) is invertible. Writing the decomposition as (u_1\otimes v_1\otimes w_1+u_2\otimes v_2\otimes w_2), the pencil determinant would then be

\[
\det[u_1,u_2]\det[v_1,v_2]L_1(x,y)L_2(x,y),
\]

where (L_1,L_2) are independent linear forms coming from the independent vectors (w_1,w_2). This quadratic has two distinct roots over an algebraic closure, contradicting (-x^2). Hence \(\operatorname{rank}_{\mathbb Q}(W)\ge3\), and the displayed three-term formula gives equality.

So no procedure can convert the given border-rank-2 witness into an exact rank-2 decomposition of (W): the requested output does not exist. Increasing numerical precision cannot repair this rank gap. What is valid is the tensor-power extraction theorem: the Laurent witness for (W(t)) has (r=2,d=1), hence

\[
\operatorname{rank}_{\mathbb Q}(W^{\otimes m})\le 2^m(2m+1)^2.
\]

This distinction is the point: degeneration controls asymptotic rank through coefficient extraction, while one-shot exact rank need not be closed under limits.

## 4. Explicit bit and conditioning charges for the counterexample

Take (t=2^{-p}), (p\ge1). The approximation error is exactly (2^{-p}). The specialized rank-2 decomposition has a fixed number of rational coefficients, each with (O(p)) bits; it needs no field extension. Given the formula, writing the coefficients costs (\Theta(p)) bits, and exact evaluation uses a constant number of rational operations on (O(p))-bit values (with the bit cost of those operations charged). This is a supplied family and not a claim about acquiring border-rank witnesses from an oracle.

The sum of the Frobenius norms of its two rank-one summands is

\[
2^p\big((1+2^{-2p})^{3/2}+1\big)=\Theta(2^p),
\]

while \(\|W(2^{-p})\|_F^2=3+3\cdot2^{-2p}+2^{-4p}=\Theta(1)\). Thus \(\kappa_{\rm sum}=\Theta(2^p)\). A standard termwise floating-point error bound is (O(u2^p)) for unit roundoff (u). To make this arithmetic error no larger than the approximation error (2^{-p}), that bound calls for (u=O(2^{-2p})), or about (2p+O(1)) working bits. This is a stability bound for the displayed evaluation route, not a universal lower bound on every possible algorithm.

At the formal level the Laurent coefficients are small rationals of constant height and the degree support is fixed. The large bits arise when the formal parameter is specialized to (2^{-p}), because (t^{-1}=2^p). This separates symbolic exact extraction from numerical evaluation of a badly conditioned specialization.

## 5. Connection to L03 and the selective-output target

The prior L03 record says that the released all-field (9/4) result transfers as an **arithmetic exponent** over every fixed field, with finite-extension descent and finite-field repairs. It explicitly does not supply a finite-bit decomposition algorithm, coefficient-height bounds, numerical stability, or selected coordinates. Its source-derived proof material is in the family107 manuscript and the local field-descent reconstruction cited below. Equation (1) gives a generic exact coefficient-extraction contract once a bounded witness is supplied; it does not certify the family107 coefficient sizes, acquire its witnesses, or furnish an implementation.

The selective-output material has a separate interface. For (X\in\mathbb Z^{N\times D}), (Y\in\mathbb Z^{D\times N}), and arbitrary supplied mask (W\subseteq[N]^2), the earlier audit proves: if a value-independent, division-free circuit of cost (T) for ((Z,Y)\mapsto ZY^\mathsf T), with (Z) supported on (W), is supplied, then contraction with (X) and reverse differentiation returns ((XY)_W) in (O(T+ND+|W|)) field operations, plus circuit acquisition (P) and storage. That exact circuit is the missing object. The target (D=N^{1/4}, |W|\le N^{15/8}) remains open; the \(\Omega(N^2)\) cover result applies only to independently charged complete-block covers. Neither L03 nor (1) supplies the mask circuit or avoids the charged output-incidence and decoding costs.

## 6. Primary sources and prior material

1. Dario Bini, Grazia Lotti, and Francesco Romani, “Approximate Solutions for the Bilinear Form Computational Problem,” *SIAM Journal on Computing* 9(4), 692–697 (1980), [DOI: 10.1137/0209053](https://doi.org/10.1137/0209053). Primary source on approximate bilinear algorithms, their topological interpretation, and error/stability accounting. The coefficient-extraction proof in §1 is supplied here explicitly.
2. Vin de Silva and Lek-Heng Lim, “Tensor Rank and the Ill-Posedness of the Best Low-Rank Approximation Problem,” *SIAM Journal on Matrix Analysis and Applications* 30(3), 1084–1127 (2008), [arXiv:math/0607647](https://arxiv.org/abs/math/0607647), [DOI: 10.1137/06066518X](https://doi.org/10.1137/06066518X). Primary source for nonclosedness and ill-conditioning of tensor low-rank approximation; their paper explicitly treats rank-3 tensors lacking best rank-2 approximants.
3. Jarosław Buczyński and J. M. Landsberg, “On the third secant variety,” *Journal of Algebraic Combinatorics* 40, 475–502 (2014), [arXiv:1111.7005](https://arxiv.org/abs/1111.7005), [DOI: 10.1007/s10801-013-0495-0](https://doi.org/10.1007/s10801-013-0495-0). Primary classification of low border-rank tensor normal forms and ranks; relevant background, while the concrete W calculation here is self-contained.
4. Prior L03: [L03-all-field-nine-fourths.txt](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/astra_prior/cards/L03-all-field-nine-fourths.txt), with the reconstructed proof [FINITE_FIELD_SEPARATOR_TRANSFER.md](</Users/harjas/Documents/ChatGPT/Literature Digestion/notes/logic_prior14/cycle19/FINITE_FIELD_SEPARATOR_TRANSFER.md>) and the primary family107 manuscript at [/Users/harjas/Documents/ChatGPT/Literature Digestion/sources/frontier_tensor_bridge/cycle19/release/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/build/paper.tex](</Users/harjas/Documents/ChatGPT/Literature Digestion/sources/frontier_tensor_bridge/cycle19/release/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/build/paper.tex>).
5. Selective-output source audit: [SELECTIVE_OUTPUT_AUDIT.md](</Users/harjas/Documents/ChatGPT/Literature Digestion/notes/frontier_tensor_bridge/cycle19/SELECTIVE_OUTPUT_AUDIT.md>), summarized in [N12-selective-tensor-barrier.txt](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/astra_prior/cards/N12-selective-tensor-barrier.txt).
