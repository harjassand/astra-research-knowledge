# Leaf 03 status and restart

**Status: COMPLETE WITHIN SCOPE.** Proved a bounded Laurent-witness coefficient-extraction theorem for exact tensor powers and gave a rational (2\times2\times2) counterexample to extracting an exact rank-2 decomposition of a border-rank-2 tensor. Supplied/acquired data, coefficient bits, precision, conditioning, field extension, explicit time, and output size are separated in REPORT.md.

**Scope boundary.** No result here supplies an exact arbitrary-mask circuit, a machine-bit implementation of L03, or an efficient compact application of the extracted large tensor-power decomposition. The selective target remains open.

**Restart.** Seek a mask-aware exact circuit/degeneration with bounded Laurent support and rational/number-field height, then provide a compact application algorithm and charge mask acquisition, coefficient acquisition, precision/conditioning, extension basis, and output decoding. Do not use one-shot border rank as if it were exact rank.
