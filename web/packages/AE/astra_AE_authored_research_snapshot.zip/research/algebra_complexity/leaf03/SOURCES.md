# Leaf 03 sources

External primary sources used:

- Bini, Lotti, Romani (1980), “Approximate Solutions for the Bilinear Form Computational Problem,” SIAM Journal on Computing 9(4), 692–697. https://doi.org/10.1137/0209053
- de Silva and Lim (2008), “Tensor Rank and the Ill-Posedness of the Best Low-Rank Approximation Problem,” SIAM Journal on Matrix Analysis and Applications 30(3), 1084–1127. https://arxiv.org/abs/math/0607647 and https://doi.org/10.1137/06066518X
- Buczyński and Landsberg (2014), “On the third secant variety,” Journal of Algebraic Combinatorics 40, 475–502. https://arxiv.org/abs/1111.7005 and https://doi.org/10.1007/s10801-013-0495-0

Prior local research material:

- work/astra_prior/cards/L03-all-field-nine-fourths.txt
- work/astra_prior/cards/N12-selective-tensor-barrier.txt
- /Users/harjas/Documents/ChatGPT/Literature Digestion/notes/logic_prior14/cycle19/FINITE_FIELD_SEPARATOR_TRANSFER.md
- /Users/harjas/Documents/ChatGPT/Literature Digestion/notes/frontier_tensor_bridge/cycle19/FIELD_DESCENT.md
- /Users/harjas/Documents/ChatGPT/Literature Digestion/notes/frontier_tensor_bridge/cycle19/SELECTIVE_OUTPUT_AUDIT.md
- /Users/harjas/Documents/ChatGPT/Literature Digestion/sources/frontier_tensor_bridge/cycle19/release/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/build/paper.tex

The W-tensor formulas, rank proof, coefficient-extraction lemma, and cost bounds are derived in REPORT.md. Source citations support context; they are not a certification of the L03 source manuscript or of priority/novelty.
