# Leaf 14 addendum — sparse linear aliases in a precompiled kernel library

**Status:** reconstructed counting obstruction, conditional on the stated alias model. This is an extension of the coordinate-copy library argument; it is not an arbitrary arithmetic-circuit lower bound.

## Model

Let N be the output side length, D=N^(1/4), and m=floor(N^(15/8)). A library contains K_N fixed source kernels. Each source kernel computes all outputs of a fixed graph-masked product

\[
T_{H,D}=\sum_{(u,v)\in H}\sum_{k=1}^D A_{u,k}B_{k,v}C_{uv},
\]

with h=|H| edges, U nonisolated source rows and V nonisolated source columns. The source arithmetic circuits are precompiled and are not rewritten after specialization.

A specialization assigns each source row and column from sparse linear aliases of target coordinates:

\[
A_{u,k}=\sum_{i\in S_u}a_{u,i}X_{i,k},\quad |S_u|\le q;
\qquad
B_{k,v}=\sum_{j\in T_v}b_{v,j}Y_{k,j},\quad |T_v|\le q.
\]

The same support and coefficients are used for every k. Coefficients may be arbitrary and may depend on the mask. The source outputs may be selected or combined by an arbitrary linear decoder. The aliases and decoder are generously treated as free for the counting obstruction. If they are actually computed, their acquisition and evaluation costs must be added.

Assume every kernel that the strategy evaluates has charge at most C_N=cN^(2−η), for a fixed η>0 and constant c, with the charge at least max{h,UD,VD}. Thus h≤C_N and U+V≤2C_N/D. Also assume log K_N=o(m log N).

## Counting theorem

If q≤N^(η/2−δ) for some fixed δ>0, then for all sufficiently large N there is a legal mask W of exactly m outputs that no specialization of this library can compute under the model above.

For a fixed source graph and fixed alias supports, the source output indexed by (u,v) expands only on target pairs in S_u×T_v. Therefore every decoded target output must lie in the envelope

\[
E=\bigcup_{(u,v)\in H}S_u\times T_v,\qquad |E|\le q^2h\le q^2C_N.
\]

This remains true for arbitrary alias coefficients and arbitrary output linear combinations: they can cancel monomials within E, but cannot introduce a monomial x_{ik}y_{kj} for a pair outside E.

The number of possible support assignments is at most

\[
A_q(N)^{U+V},\qquad A_q(N)=\sum_{j=0}^q\binom Nj.
\]

For each assignment, at most \(\binom{q^2C_N}{m}\) size-m masks are contained in its envelope. Hence the whole library can serve at most

\[
K_N A_q(N)^{\,2C_N/D}\binom{q^2C_N}{m}
\]

masks (rounding exponents and replacing a binomial coefficient by zero when q²C_N<m only strengthens the claim).

When q²C_N≥m, compare with the \(\binom{N^2}{m}\) legal masks. The product formula gives

\[
\frac{\binom{N^2}{m}}{\binom{q^2C_N}{m}}
\ge \left(\frac{N^2}{q^2C_N}\right)^m,
\quad
\log\frac{\binom{N^2}{m}}{\binom{q^2C_N}{m}}
\ge m\bigl(\eta\log N-2\log q-\log c\bigr).
\]

The cost gap has coefficient \(\eta\), not \(2\eta\): indeed N²/(q²C_N)=Θ(N^η/q²). Under q≤N^(η/2−δ), it is at least (2δ log N−O(1))m.

For q≤N/2,

\[
\log A_q(N)=O(q\log(eN/q)+\log q)=O(q\log N).
\]

The support-assignment entropy is at most

\[
O((C_N/D)q\log N)=O(N^{7/4-\eta}q\log N)=o(m\log N),
\]

since q≤N^(η/2−δ) and m=Θ(N^(15/8)). Together with log K_N=o(m log N), the library covers fewer masks than exist. One legal mask is uncovered.

## Boundary and cost audit

The condition that alias coefficients do not vary with k is load-bearing. If each k may choose a different q-sparse row/column support, a source edge can touch up to q²D target pairs across the middle coordinates, and the q²h envelope proof no longer applies.

The theorem deliberately grants the support patterns, real-valued coefficients, and output decoder for free. This makes the obstruction stronger as a counting statement: charging them cannot create a missing mask. It does not certify a feasible algorithm. In an actual algorithm, storing sparse supports costs Ω(q(U+V)log N) bits in the worst case, and direct alias evaluation costs O(qD(U+V)) field operations per specialization (potential sharing may reduce this and must be shown). A linear decoder from h source outputs to m requested outputs also incurs circuit/storage cost unless explicitly supplied for free. These costs must be included in any positive construction.

The obstruction does not cover a mask-dependent rewrite of the source circuit, k-dependent mixed maps, dense linear maps, or arbitrary circuits built directly for W. A library with mask-sized entropy is also outside the conclusion; the hypothesis on K_N must be checked against the exact acquisition interface.

## Falsifier and restart

**Falsifier.** Produce an explicit library and a fixed q≤N^(η/2−δ) alias rule satisfying the model that covers every size-m mask, and exhibit the missing support-envelope count. Or show a target output polynomial can contain a monomial x_{ik}y_{kj} when (i,j) is outside E; that would invalidate the central support claim.

**Restart.** If a proposed transfer uses coefficients that depend on k, recompute the envelope before applying this theorem. If it rewrites the kernel after seeing W, count the rewrite/preprocessing and abandon this finite-library bound. For q at or above N^(η/2), the envelope entropy gap may vanish; use a sharper mask family count or a different circuit invariant rather than extrapolating this proof.
