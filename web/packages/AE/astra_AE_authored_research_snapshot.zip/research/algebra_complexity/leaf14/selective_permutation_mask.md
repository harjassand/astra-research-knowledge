# Leaf 14 — selective multiplication on a permutation mask

**Status:** reconstructed. The interface and tensor calculation below are explicit; the circuit-size lower bound is an application of Strassen's tensor-rank theorem as stated in Shpilka–Yehudayoff, Theorem 3.23. No new lower bound for arbitrary masks, and no novelty or priority claim, is made.

## Goal and stopping point

Give one exact, auditable arithmetic-circuit model for returning only masked entries of XY, then settle one concrete mask family while charging the mask input and permitting arbitrary shared linear combinations of outputs. Compare that result with independently charged complete-block covers.

Take N=q^4, D=q=N^(1/4), and a permutation π∈S_N. The mask is

\[
W_\pi=\{(i,\pi(i)):i\in[N]\},\qquad |W_\pi|=N.
\]

The inputs are X∈Q^(N×D), Y∈Q^(D×N), and the supplied permutation. The outputs, in row order, are

\[
f_i=(XY)_{i,\pi(i)}=\sum_{k=1}^D x_{ik}y_{k,\pi(i)}\quad(i\in[N]).
\]

The same conclusions hold over any characteristic-zero subfield of R. Integer input bit costs are stated separately below.

## Circuit and information model

For fixed N,D,W, the arithmetic circuit is a directed acyclic graph over Q, with input variables the entries of X,Y, field constants, and gates +,-,×. Circuit size counts every arithmetic gate; output wires are free. The circuit must produce the requested coordinates exactly as polynomials, for every X,Y. It may use arbitrary intermediate polynomials, cancellations, shared subcircuits, and arbitrary linear combinations of intermediate values to form the outputs. Thus this is not restricted to one dot-product circuit per output.

The mask is discrete input to a uniform preprocessing stage, not a free field constant or an uncharged oracle. For this family it is encoded by the sequence (π(1),...,π(N)); preprocessing must read that sequence and may specialize wiring. Charge its bit/word cost separately from field-gate count. For a per-mask circuit family, charge the circuit description or its construction as well. The arithmetic lower bound below holds even if the circuit receives free mask-dependent wiring/constants, so it cannot be defeated by hiding shared output combinations in the circuit description.

## Theorem: exact tensor rank and optimal arithmetic exponent

Let T_π be the trilinear tensor of the scalarization

\[
F_\pi(X,Y,z)=\sum_{i=1}^N z_i f_i
             =\sum_{i=1}^N\sum_{k=1}^D z_i x_{ik}y_{k,\pi(i)}.
\]

Then:

1. rank(T_π)=ND.
2. A bilinear circuit for the output vector needs exactly ND scalar products in the rank model.
3. Every division-free arithmetic circuit over Q producing all f_i, even with arbitrary shared output recombinations, has size Ω(ND). A direct circuit has exactly ND multiplication gates and N(D−1) addition gates, hence total size 2ND−N. Therefore the unrestricted arithmetic-circuit complexity is Θ(ND)=Θ(N^(5/4)).

**Proof.** Flatten T_π between the X-leg and the Y⊗z-legs. Its ND rows, indexed by (i,k), have a single 1 in distinct columns indexed by (k,π(i),i). Thus this flattening has matrix rank ND, and tensor rank is at least ND. The displayed formula is a sum of ND rank-one tensors, so tensor rank is exactly ND. In the bilinear rank model, a rank-one tensor is one scalar product, and output linear recombination is already represented by the third tensor factor; it cannot evade the flattening bound.

For the unrestricted circuit claim, start with any circuit of size S for all f_i, and append the scalarization Σ_i z_i f_i, using at most N multiplications and N−1 additions. The resulting circuit computes the trilinear polynomial whose tensor is T_π. Strassen's circuit-size theorem gives size Ω(rank(T_π))=Ω(ND); hence S+2N−1=Ω(ND), so S=Ω(ND) because D=N^(1/4)→∞. The direct algorithm uses one product for each (i,k), then sums the D products separately for each i, for exactly ND+N(D−1)=2ND−N gates. □

The lower bound is robust to all shared output linear combinations: after scalarization they are simply part of a circuit for the same trilinear polynomial. The rank statement is exact; the general arithmetic-size lower bound has the usual unspecified absolute constant from the cited theorem.

## Mask and bit costs

The family contains N! masks, so any lossless representation that distinguishes every permutation requires at least

\[
\lceil\log_2(N!)\rceil=N\log_2N-(\log_2 e)N+O(\log N)
\]

bits in the worst case. The row-ordered permutation array uses N⌈log₂N⌉ bits, within O(N) bits of this lower bound. If the mask is a known rule such as the identity permutation, the rule can be shorter; that is a different supplied-information contract. This result charges a supplied arbitrary permutation, not a free fixed diagonal.

For integer entries with at most b bits, the straightforward uniform algorithm reads 2NDb data bits and N⌈log₂N⌉ mask bits, and writes N(2b+⌈log₂D⌉+O(1)) result bits in the worst case. With integer multiplication cost M(b), it uses

\[
O\!\left(ND\,M(b)+ND(b+\log D)+N\log N\right)
\]

bit operations, including summation and mask handling. With schoolbook multiplication this is O(NDb²+ND(b+logD)+NlogN). For b=O(log N), the field-operation result becomes an exact-integer algorithm with a polylogarithmic factor. The proof is an arithmetic-operation lower bound; it is not a matching bit-complexity lower bound.

For comparison, the number of all size-m masks on an N×N grid is binom(N²,m), so arbitrary-mask identification has worst-case description length at least log₂ binom(N²,m). This can be much larger than the Θ(NlogN)-bit permutation description. A claimed uniform arbitrary-mask circuit must charge its actual mask representation/acquisition rather than inherit the permutation family's compressed structure.

## Complete-block comparison

Use the following restricted cover model. A block chooses row set R⊆[N], column set C⊆[N], and inner set K⊆[D], then computes the complete product X[R,K]Y[K,C]. It may retain requested coordinates in R×C and partial sums for those same coordinates. Different blocks may cover overlapping requested triples. Charge a block the standard volume/flattening lower charge

\[
c_B=\max\{|R||C|,\ |R||K|,\ |K||C|\}.
\]
This is the block-level volume charge used for the cover comparison; the three quantities are flattening ranks of the complete rectangular multiplication tensor, and so each block also has arithmetic-circuit size \Omega(c_B) by the cited tensor-rank circuit bound.

For a permutation mask, a rectangle R×C contains at most e_B=min(|R|,|C|) mask edges. Hence

\[
e_B|K|\le \min(|R|,|C|)|K|
      \le \max\{|R||K|,|C||K|\}\le c_B.
\]

To assemble every requested dot product by coordinatewise block coverage, every triple (i,π(i),k) must be supplied by at least one block, so Σ_B e_B|K_B|≥ND. Therefore Σ_B c_B≥ND. Conversely, one block per requested edge with R={i}, C={π(i)}, K=[D] has charge D, for total ND. Thus the optimal coordinatewise complete-block-cover charge is exactly ND, matching the arithmetic-circuit exponent.

This cover argument is deliberately stated for coordinatewise block coverage. The general arithmetic-circuit theorem above allows arbitrary shared output combinations and proves the same Θ(ND) lower bound without imposing the cover representation. This family therefore does not expose a gap between general circuits and complete-block covers; it is a clean control family where both models are tight to the same exponent. It also does not validate the separate random-mask Ω(N²) complete-block-cover obstruction from the earlier cycle19 note: that obstruction has a different mask family and a restricted cover model.

## Sources and evidence

- A. Shpilka and A. Yehudayoff, *Arithmetic Circuits: A Survey of Recent Results and Open Questions*, §3.8.2, Theorem 3.23, pp. 45–46. The theorem states that a trilinear tensor of rank at least R requires arithmetic-circuit size Ω(R); the proof homogenizes a circuit to a bilinear circuit and recovers a tensor-rank decomposition. The theorem is attributed there to Strassen. [PDF](https://www.cse.iitk.ac.in/users/nitin/courses/CS748-2015-16-II/pdfs/survey-SY10.pdf).
- V. Strassen, *Vermeidung von Divisionen*, J. Reine Angew. Math. 264 (1973), 184–202. [DOI](https://doi.org/10.1515/crll.1973.264.184). The survey's bibliography identifies this as the source of Theorem 3.23.
- Internal comparator: work/programmes/algebra_complexity/leaf01/d-d2ebdc4e16ec4b31.txt, §5, “Complete-block covers require Ω(N²) for some legal masks.” That is a distinct, random sparse-mask obstruction; this leaf reuses its complete-block charge form but independently proves the permutation-mask calculation above.

## Falsifier and restart

**Falsifier.** An exact division-free arithmetic circuit family over Q that outputs every (XY)_{i,π(i)} for arbitrary supplied permutations and has o(ND) arithmetic gates would contradict the stated application of Strassen's theorem or reveal a mismatch in the circuit/output interface. A purported example should first be scalarized with fresh z_i and its trilinear tensor flattening checked.

**Restart.** If the goal is to find a gap beyond complete-block covers, move to masks with repeated row and column degrees (for example, a random mask of density N^(−1/8)). Recompute all three tensor flattenings, then test whether shared linear encodings can lower the circuit cost. Keep the earlier random-mask block-cover result scoped to coordinatewise full-block covers; an unrestricted-circuit conclusion needs a new tensor or circuit lower bound. For any proposed upper bound, count mask bits, circuit/wiring acquisition, input transforms, field operations, output decoding, and integer bit growth.

## Read status

Sources read: Shpilka–Yehudayoff survey theorem and its proof sketch; Strassen bibliographic record. The tensor calculation and complete-block cover argument were reconstructed in this leaf. No external peer review, formal proof assistant check, or novelty search was performed.
