# Leaf 18 — Exact matrix interfaces to noncommutative formula PIT

Status as of 2026-10-08: scoped reduction reconstructed from the stated interfaces and selected primary-source passages. N68 and the all-field integer extension of N51 remain `source_derived_unreviewed` in the supplied Astra records; external correctness and priority are unresolved. The newer OpenAI Math preprints state direct one-matrix hitting theorems for division-free formulas. Their source claims are recorded here, not treated as independent proof validation. This leaf makes no claim about general circuit PIT.

## Result

There are three different interfaces here.

1. **N68 sparse acquisition.** A single specially chosen exact matrix query reconstructs an unknown polynomial with at most `t` nonzero noncommutative words. The supplied decoder uses dimension `2t` and has output-sensitive polynomial bit cost. A formula of size `m` need not be `m`-sparse; the sparsity can be exponential in `m`, so this route alone does not give polynomial cost in formula size.

2. **N51 rational-formula list.** Conditional on the supplied N51 theorem, a generated polynomial-total-bit list gives a deterministic multi-query black-box test for size-bounded admissible rational formulas, provided each query reports either `undefined` or the exact matrix value. For a division-free formula every query is defined. For a formula with inverse gates, all original inverse occurrences and their domains must be preserved. N51's source-derived all-field/integer strengthening is still unreviewed and its full generator has not been run. The public Sept. 24 preprint supports the rational-list theorem over `Q`, not the added all-field coefficient-extension conclusion.

3. **Direct formula hit points in the current primary sources.** The Sept. 24, 2026 OpenAI Math preprint gives one rational tuple for every nonzero division-free size-`s` formula over every characteristic-zero coefficient field. It states dimension `d <= 2 n s^2`, polynomial-bit construction, and a single exact matrix-evaluation query. The Oct. 4, 2026 companion gives one tuple over `F_p` for each supplied prime `p`, with `d = O(n^3 s^6)`, polynomial total output and generator time in `n,s,log p`, and a guarantee uniform over every coefficient-field extension of `F_p`. These are scoped formula results: no inverse gates, no arbitrary shared circuits. The manuscripts explicitly separate construction cost from evaluation over an unspecified coefficient field.

Thus the direct answer for division-free noncommutative formulas is a one-query hit point in the cited current manuscripts; N68 and N51 are not needed to compose that route. The useful N68/N51 connection is the conditional list-based reduction below, plus an exact account of where sparsity and inverse-domain handling enter. No claim here promotes the unpublished/source-derived N51 extension to an externally validated all-field rational identity-testing theorem.

## Costed reductions

### N68: sparse polynomial and formula-size obstruction

Write `t` for support size. The supplied N68 theorem works over `Q` with a known variable count `n` and at most `t` nonzero words, with no degree bound. It constructs one fixed tuple in `M_(2t)(Z)^n`; the entry bit length is `O(t log(n+1))`. The dense query description therefore has `n(2t)^2 = O(n t^2)` integer entries and `O(n t^2 * t log(n+1))` bits under this per-entry bound. The exact full response has `4t^2` rational entries. Prony/Hankel recovery is deterministic and polynomial in `n,t` and the actual response bit length; the coefficient and root/output bits are charged. There are no inverse gates or domain conditions.

For identity testing under the same sparsity promise, reconstruction is unnecessary: a nonzero matrix response certifies nonidentity. The official Lakhani–Mukhopadhyay ECCC source states the stronger size-`t` hitting-point form for sparse PIT, with tuple in `M_t(Z)^n`, deterministic `poly(n,t)` construction, and entry bit complexity `O(t log n)`. That is a PIT guarantee, whereas N68's `2t` dimension and optimality statement concern injective one-response acquisition. They should not be conflated.

The formula-to-sparsity substitution is not polynomial in general. For

`F_k = (x_1+x_2)(x_3+x_4) ... (x_(2k-1)+x_(2k))`,

the formula has `4k-1` vertices and expands to exactly `2^k` distinct words. Applying the N68 decoder with `t=2^k` costs dimension `2^(k+1)`, `4^(k+1)` response entries, and a dense query of `n*4^k` matrix entries. This refutes the proposed *parameter substitution* from formula size to N68 sparsity; it is not a lower bound against other PIT algorithms.

### N51: list-to-PIT reduction, with exact domains

Suppose the N51 list theorem holds for `(n,s)` (its card uses the auxiliary pencil bound `B=2s+1`) and outputs `H={X^(1),...,X^(L)}`. Let `d_j` be the matrix dimension at point `j`, and let `h_j` be its maximum integer-entry bit length. The supplied theorem claims `L`, every `d_j`, every `h_j`, the total dense list length, and deterministic generation time are polynomially bounded in unary `n,s`; the construction is coefficient-independent and integer-valued. It can be reduced to any characteristic and interpreted in any coefficient extension if that stronger internal theorem is correct.

For a division-free formula `f`, the reduction is:

* Generate the list using only `n,s`.
* Query `f(X^(j))` for every `j`, interpreting integer entries in the coefficient field.
* Return nonzero if any returned matrix is nonzero; otherwise return identity.

If `f` is nonzero, N51's claimed strong hit supplies a nonzero (indeed invertible) output. If `f=0`, all evaluations are zero. Every candidate is defined because there are no inverse gates.

For a rational formula `Phi`, use the original expression tree at every query. Skip points reported `undefined`; return nonzero iff a defined response is nonzero. N51's strong guarantee is specifically that some list member is defined with invertible value for every nonzero admissible formula. A zero formula has zero value at every point in its domain. The oracle contract must expose undefinedness, or the evaluator must receive the formula tree and check every inverse operand exactly before querying. Algebraic cancellation does not erase an inverse node's domain requirement.

If the generator emits `L` points of dimensions at most `d`, the list contains at most `L n d^2` dense input entries. A full matrix-valued oracle emits `sum_j d_j^2` field elements; their actual bit encodings are additional response cost. A zero/nonzero-only response reduces output payload to `L` bits but does not reduce the matrix query description. Given an explicit formula description with total coefficient encoding length `C`, straightforward exact gate evaluation costs polynomially many field operations in `s,d`; over `Q` or a represented finite extension, bit cost also depends on `C`, matrix-entry heights, and the field representation. N51's generator theorem does not pay these evaluation costs. Over an abstract field with no effective representation, polynomial bit runtime for formula evaluation is not defined; the matrix oracle/field-operation interface must be supplied.

The single-point or block-diagonal shortcut is invalid for rational formulas. Let `Phi(x)=1+0*x^(-1)`. At `x=1` the original expression is defined and equals `1`; at `x=0` its inverse occurrence is undefined. On the block tuple `diag(1,0)`, the inverse is undefined, so block-summing a list can destroy the only legal hit even though one list member works. N51's list algorithm avoids this by querying members separately and preserving each original domain. An exact no-domain-status oracle is therefore the missing interface for a black-box implementation of the rational-formula list route; it is not missing for division-free formulas.

The supplied N51 audit also proves a scoped list-length lower bound under its arbitrary coefficient-extension quantifier: a universal strong list for `B` simultaneous feasible pencils needs at least `B+1` tuples. Its rational-expression domain construction gives a linear-in-formula-size lower bound on list length. This rules out one common strong point as a universal replacement for N51's list under those quantifiers. It does not rule out a polynomial list.

### Current direct hit-point sources for division-free formulas

The characteristic-zero source defines `Form_(n,s)(F)` as formulas with at most `s` tree vertices. Its Theorem 1.1 generates `T_(n,s) in M_d(Q)^n`, `d <= 2 n s^2` (with the constant special case `n=s=1`), and proves `f(T) != 0` for every nonzero formula over every characteristic-zero field. Its construction reads only `n,s`. The source gives entry bit length

`O(log(ns+1) + n s^2 log(n+1))`,

dense output length `O(n d^2 B)` and deterministic construction time `O(n d^2 B^2)`, where `B=O(log(d+1)+d log(n+1))`. One query returns `d^2` exact field entries; evaluating an unknown formula over an arbitrary coefficient field is explicitly outside the generator bit-time claim. Since there are no inverse gates, every query is legal.

For characteristic `p>0`, the Oct. 4 source takes promised `p` in binary and `n,s` in unary and outputs one tuple over `F_p` of dimension `O(n^3 s^6)`. It states total output length and generator time at most `C(n+s+ceil(log_2 p)+1)^k`, with all entries dense residues. The tuple works over every characteristic-`p` coefficient extension, including `p=2`; the query response has `d^2` field entries, and formula evaluation in an unspecified extension field remains an exact-oracle cost. No inverse gates are present.

These direct sources close the sparse-to-formula-size gap for this formula model by a separate construction. They do not turn N68's recovery decoder into a formula-size-polynomial decoder, and they do not validate N51's all-field rational-formula strengthening. For explicit white-box noncommutative division-free formulas, Raz–Shpilka already give deterministic polynomial-time PIT; the hit-point sources address the uniform matrix-evaluation/black-box interface.

## Exact status and unresolved scope

* **N68:** supplied card status `source_derived_unreviewed`; complete supplied S evidence package; internal proof/audit status only; external correctness/priority unresolved. The ECCC current-version page was read for its theorem statement, not its full proof. N68's output decoder and 2t-dimensional injective acquisition remain separate from the ECCC sparse PIT point of dimension t.
* **N51:** supplied card status `source_derived_unreviewed`; complete supplied R evidence package; local adversarial audit reports no counterexample, but external correctness/priority unresolved. The whole promised-size all-field generator and reconstruction were not run; constants are explicitly impractical. The public Sept. 24 preprint states a polynomial-total-bit rational list over `Q`; it does not establish the local all-characteristic/all-extension integer-list repair.
* **Current formula hit points:** the two OpenAI Math primary manuscripts state deterministic one-query theorems for the division-free formula class. In this leaf we read the characteristic-zero theorem/definition/cost section and the positive-characteristic theorem/intro; we did not independently audit every proof step or establish external validation/priority.
* **Not claimed:** deterministic PIT for arbitrary noncommutative circuits, general algebraic circuits, arbitrary rational formulas in every characteristic from N51, or efficient evaluation over an unrepresented coefficient field.

## Falsifiers and next decision

The scoped N68-to-formula-size route is falsified by the exact family `F_k` above: its support is `2^k` at size `4k-1`, so N68's parameter produces exponential query dimension and response. This is already a proof, not a numerical experiment.

The list-to-PIT lemma is a direct implication of N51's stated universal-list guarantee. A theorem-level falsifier would be a nonzero admissible size-`s` expression whose every generated list point is either outside the original tree's domain or has zero value; the most decisive attack surface is the folded-Newton subspace-expansion lemma and its characteristic/extension-field descent. The example `1+0*x^(-1)` falsifies any implementation that silently cancels inverse nodes or combines a list by block direct sum; it does not falsify N51's pointwise list claim.

The current one-point formula sources have the direct adversarial falsifier: exhibit one nonzero size-`s` formula over a coefficient field in the claimed characteristic whose evaluation on the generated tuple is the zero matrix. For the char-zero theorem, small cases can be checked by exact formula expansion; for larger instances the decisive work is proof review of the word-series independence, vanishing-order bound, and finite truncation (char zero), or the shift-order bound and characteristic descent (positive characteristic). Such finite checks cannot validate universal quantifiers.

## Restart

1. Use the pinned primary PDFs and exact statements in `SOURCES.md`; do not infer all-field N51 status from the `Q`-only public rational-list theorem.
2. If pursuing rational-formula black-box PIT, specify the oracle contract first: exact matrix response plus an `undefined` result, or a syntactic tree with exact inverse-domain checking. Then audit the all-field integer N51 construction separately from its public `Q` source, including complete generator bit output and runtime.
3. If pursuing only division-free formula PIT, the cited one-point theorem is already the right interface. Audit proof obligations and the exact field arithmetic model; keep shared circuits and inverse formulas outside the conclusion.
4. Keep the N68 sparse decoder as an acquisition result. Do not substitute formula size for sparsity or claim N51 list entries can be decoded by N68's special moment decoder.
