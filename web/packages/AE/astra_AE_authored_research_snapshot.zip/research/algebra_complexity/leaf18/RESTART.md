# Restart — leaf 18

Current checkpoint: the requested N68/N51 composition is costed in `REPORT.md`. The sparse acquisition theorem alone scales with support, which can be exponential in formula size. The N51 list gives a conditional exact-domain PIT reduction under an explicit `undefined`/matrix response interface. Current primary manuscripts separately state one-point polynomial-cost hitting theorems for division-free formulas in characteristic zero and positive characteristic.

Next decisive action depends on the target:

* **Division-free formula, black-box:** audit the two direct-hit-point proofs and reproduce their generators on bounded instances. Keep the exact coefficient field and matrix-response model in the contract. A failed exact nonzero formula that maps to the zero matrix falsifies the corresponding theorem.
* **Rational formula over `Q`:** audit the public rational-list proof's affine-pencil reduction and domain induction; determine whether the generated list and query oracle match the intended black-box interface. Keep each inverse occurrence in the original syntax.
* **Rational formula over arbitrary fields/extensions:** audit the local N51 all-field folded-Newton, descent, and complete bit-generator proof as a new claim. The `Q`-only public theorem does not validate that extension. First check whether the full generator can be operationally executed on small parameters and whether its output matches the stated cost ledger; then target the all-extension descent and actual-domain pencil lemma for independent review.
* **N68 decoder:** seek an acquisition target with a supplied polynomial support bound. Do not set `t=formula-size` absent a proof. The explicit product family in `REPORT.md` is the restart counterexample to that shortcut.

No general circuit PIT claim is open or closed by this leaf. Any continuation should state whether formulas are division-free or have inverse gates and whether the goal is white-box or matrix-query black-box testing.
