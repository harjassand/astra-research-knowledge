# Restart — cycle 5 evaluation-to-PIT

The result is in `RESULT.md`; source/status notes are in `SOURCES.md`; the exact finite fixture is in `evidence/`.

Key boundaries:

* N68 exact readout followed by abelianization is a valid one-query route when free-word support is at most `s`. Its decoder runtime is polynomial in the exact full-response bit length, not automatically in a succinct formula description.
* A coefficient-independent fixed tuple of `d × d` matrices cannot test every commutative polynomial of degree at most `D` when `binom(n+D,D) > d²`. This is a fixed-one-query black-box obstruction, not a formula lower bound.
* A supplied L01-type realization `(lambda, A_i, gamma)` has commutative image `lambda (I - sum_i x_i A_i)^(-1) gamma`. Zero-testing this image is equivalent to zero-testing a bordered affine-pencil determinant. A deterministic determinant consumer is the missing interface in that route.
* N51's free rational PIT output cannot by itself test abelianization. The exact witness `xy-yx` has zero commutative image and an invertible nonzero evaluation at `E12,E21`.

Next decisive experiment, if a stronger black-box barrier is wanted: take fixed tuples with `d² < binom(n+D,D)`, compute exact low-height kernel witnesses for the canonical monomial evaluation map, and compare their explicit sparse descriptions with the intended formula class. Do not infer a small-formula counterexample from rank-nullity alone. A positive next step would require either a deterministic zero-test for the precise bordered-pencil family or a proved polynomial-size commutativization/readout that avoids full free-support growth.
