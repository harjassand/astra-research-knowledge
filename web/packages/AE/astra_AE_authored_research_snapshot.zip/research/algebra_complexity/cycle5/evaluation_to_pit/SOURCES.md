# Sources and provenance — cycle 5 evaluation-to-PIT

Checked 2026-10-08. Technical claims below distinguish public theorem statements from local supplied cards and this leaf's derivations.

## Primary public sources

1. Foram Lakhani and Partha Mukhopadhyay, “Hitting point for sparse noncommutative polynomials,” ECCC TR26-120, Revision 2 (2026-07-20), [official record and theorem statement](https://eccc.weizmann.ac.il/report/2026/120/) and [Revision 2 PDF](https://eccc.weizmann.ac.il/report/2026/120/revision/2/download). The official page states a one-query tuple in M_s(Z)^n for sparse PIT, polynomial deterministic generation, O(s log n)-bit entries, and notes that deterministic high-degree sparse commutative PIT is known. This leaf read the official page/theorem statement, not the full proof. The 2s-dimensional exact full-response acquisition is the separate local N68 derivation, not the ECCC theorem.

2. Markus Bläser, Moritz Hardt, Richard J. Lipton, Nisheeth K. Vishnoi, “Deterministically Testing Sparse Polynomial Identities of Unbounded Degree,” *Information Processing Letters* 109(3), 187–192 (2009), [author-hosted paper PDF](https://cs.yale.edu/homes/vishnoi/Publications_files/BHLV08-ipl.pdf). The abstract states deterministic sparse identity-testing algorithms with running time polynomial in circuit size and number of nonzero monomials, with only logarithmic degree dependence. Used only as the baseline that sparse commutative PIT already has deterministic algorithms; the algorithm itself is not reconstructed here.

3. Adam R. Klivans and Daniel A. Spielman, “Randomness Efficient Identity Testing of Multivariate Polynomials,” STOC 2001, [author-hosted paper PDF](https://www.cs.yale.edu/homes/spielman/PAPERS/ran3.pdf). The paper's abstract gives the sparse-polynomial random-bit bound and the sparse interpolation context. Not needed for the proof; retained as a primary historical comparator alongside BHLV.

## Supplied local records

4. work/astra_prior/cards/N68-sparse-nc-one-query.txt — local N68 card. It states the 2s-dimensional affine-action full-response acquisition interface over Q, the Prony/Hankel decoder, output-sensitive runtime, and limits. Its status is source_derived_unreviewed; external correctness/priority is unresolved. The proof and costs used in this leaf are also re-stated in RESULT.md.

5. `work/astra_prior/cards/L01-cyclic-grid.txt` — local L01 card. It supplies the proper recognizable-series/state-bound exact full-matrix learner interface and its query/dimension counts. It is a local source-derived record; this leaf proves the commutative generating-function/bordered-determinant transformation directly from the returned linear realization. L01's learner proof and historical priority are not re-audited here.

6. `work/astra_prior/cards/N51-universal-integer-hitting.txt` — local N51 card. It records the all-field integer rational-formula list as source-derived/unreviewed and the original inverse-domain contract. This leaf only uses the basic distinction between free rational-formula evaluation and commutative abelianization; the commutator witness is proved explicitly and does not depend on the universal-list theorem.
7. OpenAI Math, “Polynomial Hitting Lists for Noncommutative Rational Formulas” (2026-09-24), [primary manuscript PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026.pdf). This is the public characteristic-zero rational-list comparator; it does not certify the local N51 all-field integer strengthening.

8. work/astra_prior/cards/P-pit.txt — prior PIT card. It records the abelianization-kernel issue and a determinant/ABP gadget whose 2-by-2 noncommutative blow-up rank is full in both commutative zero and nonzero cases. This leaf does not rely on its gadget; its fixed-tuple lower bound and commutator witness are independent exact arguments.

## Reproducibility and status

Run `python3 outputs/research/algebra_complexity/cycle5/evaluation_to_pit/evidence/check_n68_dense_kernel.py`. It uses only Python's standard library and exact integer arithmetic. The checker covers one finite N68 tuple and is not proof of the universal N68 theorem. No source downloads, generated hitting lists, or external validators were executed in this leaf.
