# Cycle 5 — exact matrix readout to commutative PIT

**Status (2026-10-08):** three scoped, internally proved statements. (i) N68's one-query full-response acquisition computes the commutative image of a sparse noncommutative polynomial and therefore gives commutative PIT under an explicit free-support promise. (ii) A fixed one-query $d\times d$ matrix evaluation cannot hit every commutative polynomial of total degree at most $D$ when $\binom{n+D}{D}>d^2$; the full matrix response does not evade this linear-algebra obstruction. (iii) A supplied finite-state linear realization from the L01 interface turns commutativization into a bordered linear-pencil determinant identity. This last route stops at commutative determinant PIT; N51's free-rational-formula guarantee does not test the commutative quotient. No general formula/circuit PIT claim is made.

## Exact positive route: sparse free support

Let $F\in\mathbb Q\langle x_1,\ldots,x_n\rangle$ have at most $s$ nonzero words. Its abelianization is
\[
\pi(F)=\sum_w c_w x_1^{|w|_1}\cdots x_n^{|w|_n},
\]
where $|w|_i$ counts occurrences of $x_i$ in $w$, and coefficients of equal exponent vectors are added. The supplied N68 full-response decoder reconstructs the complete sparse word list from one exact evaluation of $F$ at its integer tuple in dimension $2s$. Applying the displayed map and exact rational addition then outputs $\pi(F)$, so deciding whether this output is zero is a deterministic commutative PIT procedure for this interface.

In particular, let a commutative division-free formula $f$ be interpreted syntactically in the free algebra as $F$. Abelianization is a ring homomorphism, hence $\pi(F)=f$. If the fully expanded free polynomial $F$ has at most $s$ words, the N68 query plus readout decides whether $f=0$. This promise is on **free-word support**, not commutative monomial support and not formula size.

The reconstruction fact used here has a short exact proof. Put $B=n+1$, $D_*=2s$, and define the N68 matrices by
\[
(A_i)_{a,b}=\begin{cases}\binom ba B^a i^{b-a}&a\le b,\\0&a>b,\end{cases}\qquad 0\le a,b<D_*.
\]
For $v(z)=(1,z,\ldots,z^{D_*-1})$, $v(z)A_i=v(Bz+i)$. A word $w=x_{i_1}\cdots x_{i_\ell}$ therefore has the distinct positive integer code
\[
\alpha(w)=B^\ell+\sum_{q=1}^\ell i_qB^{\ell-q},\qquad \alpha(\epsilon)=1,
\]
and the column sums of the full response $Y=F(A)$ are its first $2s$ power moments. For $F=\sum_{j=1}^r c_jw_j$, $r\le s$, the leading $r\times r$ Hankel block factors as $V\operatorname{diag}(c_j)V^{\mathsf T}$, where $V_{a,j}=\alpha(w_j)^a$. Its determinant is
\[
\left(\prod_j c_j\right)\left(\prod_{i<j}(\alpha(w_j)-\alpha(w_i))^2\right)\ne0.
\]
Thus the exact moments recover the distinct codes and coefficients by a Hankel recurrence, integer-root isolation, base-$B$ decoding and a Vandermonde solve. This recovers $F$, not just its zero bit, so abelianization is a legitimate post-readout operation.

### Cost boundary

For N68's full-acquisition tuple, $D_*=2s$; the dense query has $nD_*^2=4ns^2$ integer entries, each $O(s\log(n+1))$ bits, hence $O(ns^3\log(n+1))$ query bits. It is generated in $\mathrm{poly}(n,s)$ time. The response has $4s^2$ rational entries; let $R$ be their complete binary encoding length. The decoder costs $\mathrm{poly}(n,s,R)$ bit time. Abelianizing the recovered list costs polynomial time in $s,n,\log(\Delta+1),R$, where $\Delta$ is the maximum word length, and the commutative output has at most $s$ monomials.

If the polynomial is supplied as an explicit list of words of total length $W$, then $\Delta\le W$, and exact formula evaluation/query response size are polynomial in the explicit input length, $n,s,W$, and coefficient bit length. If instead a succinct formula has degree $\Delta$ exponential in its description length, response bits must still be charged. With query-entry bit bound $b=O(s\log(n+1))$, a safe per-entry response bound for an explicit word-list input with coefficient bit length $C$ is
\[
O\big(C+\log(s+1)+W(b+\log(2s))\big),
\]
so total response length is at most $4s^2$ times this bound. For a size-$m$ formula, the same estimate uses its actual maximum expanded word length $\Delta$, which can be $2^{\Theta(m)}$; include an additional $O(m)$ term for the number of parse-tree summands. The reduction is output-sensitive and is not thereby polynomial in formula size. A direct formula evaluator uses $O(m(2s)^3)$ field operations, while bit time additionally depends on intermediate heights/response size.

The ECCC primary source gives a distinct, stronger sparse **PIT** point: dimension $s$, deterministic $\mathrm{poly}(n,s)$ construction and $O(s\log n)$-bit integer entries. N68's supplied $2s$-dimensional construction is the full-response **acquisition** route used above. For the zero bit alone, use the ECCC point instead. The ECCC page also states that deterministic black-box PIT for high-degree sparse commutative polynomials was already known; this route is a representation/readout bridge, not an improvement over that baseline.

## Sharp fixed-tuple obstruction for dense bounded-degree inputs

Fix $A_1,\ldots,A_n\in M_d(\mathbb Q)$, and interpret a commutative polynomial by the canonical ordered substitution
\[
\Phi_A(p)=p(A):=\sum_{|\alpha|\le D}c_\alpha A_1^{\alpha_1}\cdots A_n^{\alpha_n}.
\]
This is a $\mathbb Q$-linear map from the $N=\binom{n+D}{D}$-dimensional vector space $\mathbb Q[x]_{\le D}$ into the $d^2$-dimensional vector space $M_d(\mathbb Q)$. If $N>d^2$, rank-nullity supplies a nonzero $p$ of degree at most $D$ with $p(A)=0$. The full response to $p$ is therefore exactly the response to the zero polynomial. No deterministic postprocessing of that one response can be a PIT for the entire degree-$D$ space. Necessarily
\[
d^2\ge\binom{n+D}{D}
\]
for this restricted, coefficient-independent single-tuple interface.

This lower bound is exact as an information-space statement, not a formula-PIT lower bound. It allows the tuple to depend on $n,D$, but not on the unknown coefficient vector. It also does not exclude multiple tuples, coefficient-dependent white-box preprocessing, or a tuple whose dimension meets the displayed lower bound. For integral $A_i$, a rational kernel witness always exists. If each entry has at most $b$ bits, each monomial image entry is at most $d^D2^{bD}$ in absolute value. Choose a minimally dependent set of at most $r+1$ columns, where $r\le d^2$ is the image rank, and clear its relation using an $r\times r$ nonsingular minor. Its cofactor coefficients are bounded by $r!(d^D2^{bD})^r$, giving at most $d^2+1$ monomials and coefficient bit length $O(d^2(\log(d+1)+D(b+\log(d+1))))$. The witness is a finite explicit sparse polynomial, though its description is not asserted to fit any prescribed small-formula class.

The barrier applies directly to a fixed N68 acquisition query when one tries to extend its support parameter beyond the promised sparse class. With $d=2s$, any such universal bounded-degree extension would require $4s^2\ge\binom{n+D}{D}$. For $(n,s,D)=(5,2,2)$, the checker violates this inequality and verifies the explicit nonzero kernel polynomial
\[
p=60x_3x_4-91x_3x_5+156x_4^2-130x_4x_5+5x_5^2
\]
at that N68 tuple. Its support is five, exceeding the promised $s=2$, exactly where the N68 theorem stops.

## L01 route: linear realization becomes a commutative determinant

This route uses a finite-state realization, as supplied/learned under L01's proper recognizable-series interface. Suppose the coefficient of each word is $F(w)=\lambda A_{i_1}\cdots A_{i_\ell}\gamma$, with $r\times r$ transition matrices $A_i$ over $\mathbb Q$ and exact row/column $\lambda,\gamma$. The realization may include an empty-word coefficient $\lambda\gamma$. Its commutative image as a formal power series is
\[
p(x)=\sum_wF(w)x^{|w|_1,\ldots,|w|_n}
=\lambda\left(I_r-\sum_{i=1}^n x_iA_i\right)^{-1}\gamma.
\]
The identity follows by expanding the geometric series at the origin: the degree-$\ell$ term is $\lambda(\sum_i x_iA_i)^\ell\gamma$, which sums exactly over all length-$\ell$ words. Let $M(x)=I_r-\sum_i x_iA_i$. It has $\det M(0)=1$, so the inverse is formally defined at the origin. The bordered pencil
\[
K(x)=\begin{pmatrix}M(x)&\gamma\\\lambda&0\end{pmatrix}
\]
satisfies, by the Schur complement,
\[
\det K(x)=-\det(M(x))\,p(x).
\]
Because $\det M$ is nonzero, $p\equiv0$ iff $\det K\equiv0$. If the original NC series is a polynomial, its commutative image is a polynomial; if it has degree at most $D$, the determinant identity instance has size $r+1$, $n$ variables and degree at most $r+1$. This is a legal polynomial-size reduction from zero-testing the commutative image of a supplied realization to zero-testing a commutative determinant of an affine linear pencil.

Cost: construct $K$ by copying $nr^2+O(r)$ exact field entries. If input entries have total bit size $C_A$, this is polynomial in $nr^2+C_A$; evaluating the determinant circuit or expanding coefficients is a separate cost and may grow. For L01's stated learner, one must additionally pay its at-most $m(1+nr)$ exact matrix queries, each of dimension at most $2nm(r+1)$, all returned matrix entries and their actual bit sizes, plus reconstruction/runtime. Its record is field-operation/output sensitive; a polynomial field-operation count alone is not a bit-time bound.

This reduction ends at a commutative determinant identity instance, not at an already-known deterministic zero test. N51 does not fill the gap: it tests whether a free noncommutative rational formula is zero/nonzero in the free setting, while the target is its abelianized image. The exact witness
\[
F=xy-yx,\qquad \pi(F)=0,
\]
shows the semantic mismatch. At $X=E_{12},Y=E_{21}\in M_2(\mathbb Q)$, $F(X,Y)=\operatorname{diag}(1,-1)\ne0$ (indeed invertible). Therefore a free-formula hit is compatible with a zero commutative image. The supplied N51 all-field list remains source-derived/unreviewed; the public rational-list manuscript is $\mathbb Q$-scoped. Neither status changes this exact quotient mismatch. Preserving every inverse occurrence and reporting undefined points, as N51 requires, fixes rational-expression **domains** but does not perform abelianization.

## Exact status, falsifiers, and restart

* **Internally proved:** sparse-support N68 reconstruction followed by exact abelianization; the fixed-tuple rank-nullity obstruction and its coefficient-height bound; the bordered-pencil identity for any supplied linear realization; the commutator mismatch for free PIT.
* **Finite replay:** evidence/check_n68_dense_kernel.py reconstructs the $(n,s)=(5,2)$ N68 tuple, confirms the five-term nonzero degree-two polynomial has zero $4\times4$ response, and computes the $16\times21$ monomial-image rank/nullity. evidence/receipt.json records the exact result.
* **Source-reported:** ECCC TR26-120 Rev. 2 states a one-query dimension-$s$ sparse NC PIT tuple over $\mathbb C$ with integer entries and deterministic polynomial generation; its page notes deterministic high-degree sparse commutative PIT as known. L01's precise learner costs are taken from the supplied local card. N51's all-field strengthening is not promoted beyond its supplied status.
* **Unknown/out of scope:** whether the determinant route admits a deterministic polynomial-time zero test for the target realization class; whether any formula-size-polynomial construction avoids exponential free support for the N68 route; arbitrary commutative formula/circuit PIT; and any general lower bound for formula PIT or for coefficient-dependent/multi-query reductions.

**Falsifiers.** A nonzero $s$-sparse $F$ whose N68 full response is zero falsifies the positive sparse route. A disagreement between the supplied exact word coefficients and the recovered/abelianized list falsifies the readout. A nonzero kernel witness of degree at most $D$ with coefficient count/height outside the claimed bounds would refute the witness-height estimate. The rank-nullity obstruction would fail only if the fixed evaluation map were not $\mathbb Q$-linear into $M_d(\mathbb Q)$, or if $N\le d^2$. The L01 determinant identity is falsified by an exact realization for which the formal geometric expansion disagrees with the path coefficients or the Schur-complement identity fails. The commutator witness is directly checked by the displayed $2\times2$ multiplication.

**Restart.** Choose the target interface first. For an explicit sparse commutative polynomial, compare the direct commutative sparse-PIT generator against the N68 readout bridge; the latter is useful when the unknown is supplied only through a full matrix response and one needs the actual abelianized coefficient list. For a state-bounded NC series, first obtain/verify $(\lambda,A_i,\gamma)$, then build the bordered pencil and name the deterministic determinant/PIT consumer. For general formula input, do not replace free support by commutative support or state dimension without proving an encoding. Treat N51 as free rational PIT with original domains, not as commutative quotient testing.
