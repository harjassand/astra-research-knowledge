# Leaf 12 — exact one-query acquisition of sparse noncommutative polynomials

## Claim and interface

Let \(n,s\ge1\), and let the unknown be \(f\in\mathbb Q\langle x_1,\ldots,x_n\rangle\) with at most \(s\) distinct nonzero words. Words and rational coefficients are unknown, and there is no degree or word-length bound. One exact black-box call receives a known matrix tuple and returns the entire rational matrix \(F=f(A_1,\ldots,A_n)\). Under this interface, \(f\) is deterministically recoverable in bit time polynomial in \(n,s,L\), where \(L\) is the total binary length of the returned rational entries. The query dimension is \(2s\), entries are integers with \(O(s\log(n+1))\) bits, and the tuple is constructible in \(\operatorname{poly}(n,s)\) time.

This reconstructs the affine-action encoding in Lakhani–Mukhopadhyay. Their source theorem is sparse PIT at dimension \(s\); the acquisition decoder below uses \(2s\) moments. Status: internally reconstructed and source-supported, externally unreviewed. Historical priority for this acquisition consequence: UNKNOWN.

## Query and proof

Set \(D=2s\), \(B=n+1\), and \(v_D(z)=(1,z,\ldots,z^{D-1})\), a row vector. For \(1\le i\le n\), define \(A_i\in\mathbb Z^{D\times D}\) by
\[
(A_i)_{a,b}=\begin{cases}
\binom ba B^a i^{b-a},&0\le a\le b<D,\\
0,&a>b.
\end{cases}
\]
The binomial theorem gives \(v_D(z)A_i=v_D(Bz+i)\). For a word \(w=x_{i_1}\cdots x_{i_\ell}\), set
\[
\alpha(w)=B^\ell+\sum_{t=1}^{\ell}i_tB^{\ell-t},\qquad \alpha(\epsilon)=1.
\]
Composing the affine maps gives \(v_D(1)A_w=v_D(\alpha(w))\). The base-\(B\) code has leading digit 1 and subsequent digits in \(\{1,\ldots,n\}\), so it is injective, including the empty word.

Write \(f=\sum_{j=1}^r c_jw_j\) with distinct words and nonzero rational \(c_j\). For the full response \(F=f(A_1,\ldots,A_n)\), the row vector \(v_D(1)=(1,\ldots,1)\) gives the column sums:
\[
(t_0,\ldots,t_{D-1})=v_D(1)F,\qquad
t_k=\sum_{j=1}^r c_j\alpha(w_j)^k.
\]
Thus the response contains \(2s\) exact power moments at at most \(s\) distinct positive integer nodes.

Form \(H=(t_{a+b})_{0\le a,b<s}\). With \(V_{a,j}=\alpha(w_j)^a\),
\[
H=V\,\mathrm{diag}(c_1,\ldots,c_r)\,V^{\mathsf T}.
\]
Vandermonde full rank gives \(\operatorname{rank}(H)=r\), even for signed coefficients. Its leading \(r\times r\) block has determinant
\[
\left(\prod_j c_j\right)\left(\prod_{i<j}(\alpha(w_j)-\alpha(w_i))^2\right)\ne0.
\]
Solve the nonsingular Hankel system using \(t_0,\ldots,t_{2r-1}\) for
\[
P(X)=X^r+\sum_{q=0}^{r-1}a_qX^q,\qquad
t_{k+r}+\sum_{q=0}^{r-1}a_qt_{k+q}=0\quad(0\le k<r).
\]
Then \(P(X)=\prod_j(X-\alpha(w_j))\). Exact Sturm isolation over \(\mathbb Q\), with a Cauchy root bound and isolating intervals narrower than \(1/2\), recovers its distinct integer roots in time polynomial in \(r\) and coefficient bit length. Decode each root in base \(B\), then solve the first \(r\) moment equations for the coefficients by a nonsingular Vandermonde system. If \(r=0\), return zero. All moment indices used are at most \(2r-1\le2s-1\).

## Optimal dimension: acquisition versus PIT

For any one-query tuple \(T=(T_1,\ldots,T_n)\in M_d(K)^n\) over the same field \(K\) as the polynomial coefficients, the minimal polynomial \(\mu_{T_1}\) has degree \(q\le d\) and at most \(q+1\) terms. If \(d<2s\), it has at most \(2s\) terms. Split its terms into two groups of size at most \(s\), and write \(\mu_{T_1}=g-h\). Then \(g\ne h\), both are at most \(s\)-sparse, and \(g(T)=h(T)\). Hence a one-query acquisition map cannot be injective below dimension \(2s\). The construction is optimal for full acquisition in this same-field model.

Lakhani–Mukhopadhyay Theorem 2.7 instead proves dimension at least \(s\) for a PIT hitting point. That only separates zero from nonzero, while acquisition must separate every pair. This lower bound does not cover extension-field entries with coefficients in a strict subfield, or multiple queries.

## Costs and sharp limitations

- **Query:** a dense tuple has \(nD^2=4ns^2\) scalar slots. Each nonzero integer uses \(O(D\log(n+1))=O(s\log(n+1))\) bits. The complete explicit query uses \(O(ns^3\log(n+1))\) bits and is constructible in polynomial time.
- **Response and decoder:** \(F\) has \(D^2=4s^2\) rational entries. Let \(L\) count numerator, denominator, sign, and framing bits. Exact rational operations, rank and linear solves, integer-root isolation, and output take \(\operatorname{poly}(n,s,L)\) bit time. There is one oracle call; oracle evaluation time is a separate cost.
- **Succinct circuits:** no polynomial-in-circuit-size claim follows. At \(s=1\), \(A_1=\begin{pmatrix}1&1\\0&B\end{pmatrix}\). An \(O(m)\)-gate repeated-squaring circuit for \(x_1^{2^m}\) returns an entry \((B^{2^m}-1)/(B-1)\), requiring \(\Theta(2^m\log B)\) bits. Even one term can produce an exponentially long explicit response.
- **Finite fields:** for fixed finite \(\mathbb F_q\) and fixed dimension \(d\), the generated semigroup is finite. Two distinct words collide, so their nonzero difference is a 2-sparse polynomial in the kernel, also in characteristic 2. Thus no fixed finite-field tuple supports unbounded-degree acquisition, even at sparsity 2. More quantitatively, \(N\) dimension-\(k\) hitting tuples over \(\mathbb F_q\) separating words through degree \(D_0\) must satisfy \(n^{D_0}\le q^{k^2N}\), hence \(N\ge D_0\log n/(k^2\log q)\) for \(n\ge2\). The source's bounded-degree PIT construction over an extension uses degree \(m>D_0\lceil\log_p(n+1)\rceil\). It depends on the degree bound and does not itself give an acquisition decoder; no such extension is claimed.
- **Unknown sparsity:** the decoder recovers actual rank \(r\). Only a capacity \(s\) is needed to choose dimension \(2s\); the exact \(r\) need not be supplied. No fixed finite dimension covers unbounded sparsity.

## Primary prior art and attribution

1. **Closest source:** Foram Lakhani and Partha Mukhopadhyay, “Hitting point for sparse noncommutative polynomials,” ECCC TR26-120, revision 2 (20 July 2026), [official record](https://eccc.weizmann.ac.il/report/2026/120/). The primary PDF is preserved in sources/LM2026-rev2.pdf, SHA-256 bc1ed1118a98ae9d28d4eea68b25cab9e7790b889584352ff4848439e382f793. Theorem 2.1, equations (1)–(2), Lemmas 2.3–2.5, and Theorem 2.7 are on PDF pp. 2–5. It proves degree-unbounded characteristic-zero sparse PIT with one dimension-\(s\) tuple, not reconstruction. Section 3 gives the finite-field boundaries above.
2. **Prior interpolation with a degree bound:** V. Arvind, P. Mukhopadhyay, and S. Srinivasan, “New Results on Noncommutative and Commutative Polynomial Identity Testing,” *Computational Complexity* 19(4), 521–558 (2010), [arXiv:0801.0514](https://arxiv.org/abs/0801.0514). The primary preprint's Theorems 2.9 and 3.3 reconstruct a sparse noncommutative polynomial in time polynomial in circuit size, degree bound \(d\), variable count \(n\), and sparsity \(t\). The proof uses automata and prefix search, so it retains \(d\) and uses multiple evaluations.
3. The ECCC paper's introduction reports randomized black-box PIT for high-degree sparse polynomials from Arvind–Joglekar–Mukhopadhyay–Raja (2019). This is contextual PIT prior art, not a premise of this reconstruction and not claimed as interpolation prior art.

## Falsifier and restart

A decisive mathematical falsifier would be an \(s\)-sparse nonzero rational polynomial whose encoded words collide, whose Hankel matrix has rank below its support size, or whose moments fail to give the stated recurrence. A same-field injective acquisition tuple of dimension \(d<2s\) would refute optimality; the minimal-polynomial split rules this out under the stated assumptions. A black box that returns a succinct/compressed exact matrix while charging neither expanded output bits nor equivalent decoding work would change the response-cost boundary, not algebraic identifiability.

Restart by fixing the interface first (full exact rational matrix, coefficients in \(\mathbb Q\), one query), then re-derive affine composition and Hankel rank, and audit root-isolation/output bit bounds. Keep source theorem correctness, reconstruction correctness, same-field optimality, response-sensitive complexity, and historical priority as separate questions. External review and priority remain UNKNOWN.

