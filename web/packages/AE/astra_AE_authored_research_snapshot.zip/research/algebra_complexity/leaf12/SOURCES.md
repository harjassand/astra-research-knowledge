# Sources and provenance

- Primary affine-action and hitting-point source: Lakhani–Mukhopadhyay, ECCC TR26-120 revision 2, official record https://eccc.weizmann.ac.il/report/2026/120/ . Retrieved 2026-10-08 from https://eccc.weizmann.ac.il/report/2026/120/revision/2/download. Local PDF: LM2026-rev2.pdf. SHA-256: bc1ed1118a98ae9d28d4eea68b25cab9e7790b889584352ff4848439e382f793. Complete extracted text: LM2026-rev2.txt. Pages 3-4 were visually inspected to confirm formulas and theorem flow.
- Prior interpolation: Arvind–Mukhopadhyay–Srinivasan, arXiv:0801.0514 (published 2010), https://arxiv.org/abs/0801.0514 . Primary preprint Theorems 2.9 and 3.3, PDF pp. 7 and 9 in the web-rendered source. Theorem 2.9 is degree-bounded circuit interpolation; Theorem 3.3 is its black-box counterpart.
- Supplied card: work/astra_prior/cards/N68-sparse-nc-one-query.txt. The exact rational Prony and root-isolation decoder is independently reconstructed in REPORT.md; that decoder is not stated as a theorem in the ECCC paper.

