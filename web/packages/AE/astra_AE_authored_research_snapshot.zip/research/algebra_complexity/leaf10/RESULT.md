# Leaf 10 — rank, border rank, and a two-output matrix-product mask

**Status.** Reconstructed, elementary result; no novelty or priority claim. This note gives a fully explicit masked-product example with exact rank 3 and border rank 2, then identifies exactly when its degeneration can be converted into an exact bounded-integer algorithm. The example does not solve the arbitrary-mask target recorded in `work/astra_prior/cards/P-tensor.txt` and `N12-selective-tensor-barrier.txt`.

## Interface and mask

Let $x_0,x_1,y_0,y_1\in\mathbb Z$ satisfy $|x_0|,|x_1|,|y_0|,|y_1|\le B$, where $B\ge1$ is a supplied integer magnitude bound. The structured matrix inputs and requested mask are

\[
X=\begin{pmatrix}x_0&x_1\\0&0\end{pmatrix},\qquad
Y=\begin{pmatrix}y_1&y_0\\y_0&0\end{pmatrix},\qquad
W=\{(1,1),(1,2)\}.
\]

Only the two entries in $W$ are requested. Direct multiplication gives the map

\[
T(x,y)=(z_0,z_1)=(x_0y_1+x_1y_0,\;x_0y_0).
\]

The four scalars are the complete independent input. The repeated $y_0$, zero entries, and output projection are part of the stated interface. Supplying the arrays explicitly costs $O(\log(B+1))$ bit copies; it does not incur a dimension-dependent matrix scan in this fixed-size example.

## Tensor and exact rank

Over a field $F$, let $a_0,a_1$, $b_0,b_1$, and $c_0,c_1$ be bases for the two input dual spaces and the output space. The tensor for $T$ is

\[
\mathcal W=a_0\otimes b_1\otimes c_0
 +a_1\otimes b_0\otimes c_0
 +a_0\otimes b_0\otimes c_1.
\]

Its tensor rank is exactly 3 over every field. The displayed sum proves rank at most 3. For the lower bound, contract the first leg by the vector $(s,t)$. In the $b,c$ bases the resulting matrix pencil is

\[
M(s,t)=\begin{pmatrix}t&s\\s&0\end{pmatrix},\qquad \det M(s,t)=-s^2.
\]

If $\operatorname{rank}(\mathcal W)\le2$, write $\mathcal W=u_1\otimes v_1\otimes w_1+u_2\otimes v_2\otimes w_2$. The slice matrices are then

\[
M(s,t)=\lambda_1(s,t)v_1w_1^{\mathsf T}
       +\lambda_2(s,t)v_2w_2^{\mathsf T},
\]

with linear forms $\lambda_1,\lambda_2$. Since $M(1,0)$ has rank 2, both pairs $(v_1,v_2)$ and $(w_1,w_2)$ must be independent. Their determinant identity therefore gives $\det M(s,t)=c\lambda_1(s,t)\lambda_2(s,t)$ for nonzero $c$. The polynomial $-s^2$ forces each linear form to be proportional to $s$, so $M(0,t)=0$, contradicting $M(0,t)=\left(\begin{smallmatrix}t&0\\0&0\end{smallmatrix}\right)$. Thus rank is 3.

This is a legal **restriction** of the ordinary $2\times2$ matrix-product map: embed $(x_0,x_1)$ and $(y_0,y_1)$ by the displayed linear maps into $X,Y$, then project the output linearly onto $W$. Substitution into any supplied exact matrix-multiplication circuit gives an exact circuit for $T$; copying $y_0$ and discarding unrequested coordinates are charged linear wiring here. In general, restriction monotonicity preserves an exact rank upper bound, but the input/output linear maps still need an implementation and cost ledger. De Silva–Lim state rank monotonicity under multilinear maps in Lemma 6.

For $T$ itself the exact bilinear multiplication count is 3, attained by

\[
p_0=x_0y_1,\quad p_1=x_1y_0,\quad p_2=x_0y_0;\qquad
z_0=p_0+p_1,\quad z_1=p_2.
\]

This uses 3 variable multiplications and 1 addition, with no scalar multiplication. The rank proof shows that no exact bilinear circuit over $F$ can use only 2 variable multiplications. For $n$-bit inputs, the direct circuit has bit cost $3M(n)+O(n)$, where $M(n)$ is the cost of multiplying two $n$-bit integers; input reading and output writing are $O(n)$.

## Border rank and degeneration

Here border rank means closure of the rank-$r$ tensors over $\mathbb R$; the explicit parameter family also gives the algebraic degeneration directly.

For a parameter $\varepsilon\ne0$, define

\[
\mathcal W_\varepsilon=
\frac{(a_0+\varepsilon a_1)\otimes(b_0+\varepsilon b_1)\otimes(c_0+\varepsilon c_1)
      -a_0\otimes b_0\otimes c_0}{\varepsilon}.
\]

Each $\mathcal W_\varepsilon$ is a sum of two simple tensors, so it has rank at most 2. Expanding gives

\[
\mathcal W_\varepsilon=\mathcal W+\varepsilon\mathcal V+\varepsilon^2(a_1\otimes b_1\otimes c_1),
\]

where

\[
\mathcal V=a_0\otimes b_1\otimes c_1+a_1\otimes b_0\otimes c_1
                +a_1\otimes b_1\otimes c_0.
\]

Thus $\mathcal W_\varepsilon\to\mathcal W$ as $\varepsilon\to0$, and the border rank is at most 2. It is not 1 because a flattening of $\mathcal W$ has rank 2, and the rank-at-most-1 locus is closed. Hence $\underline{R}(\mathcal W)=2<3=R(\mathcal W)$.

The induced two-product approximate map is explicit. Put

\[
s=x_0y_1+x_1y_0,\qquad u=x_0y_0,\qquad t=x_1y_1.
\]

Then

\[
T_\varepsilon(x,y)=(s+\varepsilon t,\;u+\varepsilon s+\varepsilon^2t).
\]

For every nonzero fixed $\varepsilon$, this is not the exact target map on all inputs; for instance $(x_0,y_0,x_1,y_1)=(0,0,1,1)$ gives $T=(0,0)$ but $T_\varepsilon=(\varepsilon,\varepsilon^2)$. Setting $\varepsilon=0$ in the rank-2 formula is invalid because of its $1/\varepsilon$ coefficient. So border rank 2 alone is not a two-multiplication exact bilinear algorithm. The divergent coefficient is the key cost and precision issue in degeneration. Bini–Lotti–Romani explicitly connect approximate bilinear algorithms to lower multiplicative complexity with error and a topological interpretation; de Silva–Lim characterize rank-2 limits and give the same three-term boundary form.

## Exact bounded-integer decoding, with full bit charges

The degeneration does yield a legal exact **integer bit algorithm** when the magnitude bound is part of the interface and nearest-integer decoding is allowed and charged. Let $n=\lceil\log_2(B+1)\rceil$ and set

\[
q=2n+4,\qquad Q=2^q>8B^2,
\]

and compute

\[
A=Qx_0+x_1,\quad C=Qy_0+y_1,\quad P=AC,\quad R=x_0y_0.
\]

There are exactly 2 variable integer multiplications, $P$ and $R$. Expanding,

\[
P=Q^2u+Qs+t.
\]

Therefore

\[
\operatorname{round}\!\left(\frac{P-Q^2R}{Q}\right)
 =\operatorname{round}(s+t/Q)=s=z_0,
\]

because $|t|/Q\le B^2/Q<1/8<1/2$. Also,

\[
\operatorname{round}\!\left(\frac{P}{Q^2}\right)
 =\operatorname{round}(u+s/Q+t/Q^2)=u=z_1,
\]

since

\[
\left|s/Q+t/Q^2\right|
 \le 2B^2/Q+B^2/Q^2
 <1/4+1/64<1/2.
\]

The strict inequalities exclude ties, including for negative inputs. The decoding divisions are by powers of two and can be done by shifts, remainder inspection, and signed nearest-integer rounding. The coefficients $Q,Q^2$ have $O(\log(B+1))$ bits and are implemented by shifts; they do not require extra general multiplications.

Since $B<2^n$, $A,C$ have at most $3n+5$ bits and $P$ at most $6n+10$ bits; $R$ has at most $2n$ bits. The complete bit-cost bound is

\[
M(3n+5)+M(n)+O(n),
\]

including shifts, additions/subtractions, exact rounding, input reading, and output writing. With schoolbook multiplication this is at most about $10n^2+O(n)$ elementary bit operations under the usual $n^2$ multiplication accounting, while the direct rank-3 circuit uses about $3n^2+O(n)$. So the border-rank construction lowers the number of bilinear products from 3 to 2 only by allowing a nonlinear decode and larger intermediate operands; it gives no bit-cost improvement in this toy case. It is an exact integer algorithm, not an exact rank-2 circuit over $\mathbb Q$.

If the task supplies arbitrary unbounded field elements, requires an exact straight-line (+,×) circuit, or disallows rounding, this decoding lemma does not apply; the exact rank remains 3. For a general large mask, the error margin, coefficient heights, encoding and decoding costs, and output incidence must all be justified per target instance. The two-entry structured example proves none of those general obligations.

## Comparison ledger

| Notion | What transfers here | What the count omits |
|---|---|---|
| Exact tensor rank ($R=3$) | A 3-product exact bilinear algorithm. Restriction of an exact source algorithm followed by the fixed input maps and output mask is legal. | Linear encoding/decoding costs for larger interfaces; tensor rank counts bilinear products, not total bit work. |
| Border rank ($\underline R=2$) | Rank-2 tensors arbitrarily close to the target; on bounded integer inputs, this explicit family can be rounded to exact answers with 2 integer products. | A rank-2 exact field circuit; coefficient growth, finite precision, error margin, enlarged operand bits, and rounding are absent from the bare border-rank number. |
| Degeneration | The displayed Laurent-parameter family converges to the target and exposes a usable finite-$\varepsilon$ approximation. | Evaluation at the limit; the $1/\varepsilon$ coefficient diverges, so one needs extraction or a declared finite-domain error/rounding argument. |
| Restriction | Fixed linear embeddings of structured inputs and projection to $W$ preserve exactness and cannot increase rank. | Cheapness is not automatic when maps are large, dense, mask-dependent, or expensive to acquire. |

## Sources, status, and falsifier

Primary sources checked:

1. D. Bini, G. Lotti, F. Romani, [“Approximate Solutions for the Bilinear Form Computational Problem,” SIAM Journal on Computing 9(4), 692–697 (1980)](https://doi.org/10.1137/0209053). Read scope: abstract. It states that arbitrarily small error can lower multiplicative complexity below tensor rank, gives a topological interpretation, and relates exact and approximate complexity.
2. V. de Silva and L.-H. Lim, [“Tensor Rank and the Ill-Posedness of the Best Low-Rank Approximation Problem,” SIAM Journal on Matrix Analysis and Applications 30(3), 1084–1114 (2008)](https://arxiv.org/abs/math/0607647). Read scope: arXiv v2 HTML, Theorem 1 and equations (1)–(2) with the following example (lines 111–124), plus Lemma 6 (lines 275–280). The theorem gives the rank-2 boundary form and an explicit sequence converging to it; Lemma 6 gives monotonicity of rank under multilinear maps. This is the primary source most directly matching the degeneration used here.
3. W. Dür, G. Vidal, J. I. Cirac, [“Three qubits can be entangled in two inequivalent ways,” Physical Review A 62, 062314 (2000)](https://doi.org/10.1103/PhysRevA.62.062314). Read scope: arXiv HTML around the W-class discussion (lines 106–110, 145–159). Their product-decomposition discussion identifies the three-product-term form in the complex setting. The slice-pencil proof above supplies the algebraic lower bound directly for this note.

**Novelty/status.** The exact rank/border-rank gap and degeneration are classical. The output-mask embedding is explicit bookkeeping; the power-of-two integer rounding argument is an elementary, bounded-input consequence of the degeneration. No historical priority search was performed, and no novelty claim is made. No computation was used as proof. This is a scoped reconstructed lemma, not an external validation of the broader selective-output programme.

**Falsifier.** Any bounded input with $|x_0|,|x_1|,|y_0|,|y_1|\le B$ on which either rounded expression differs from $(x_0y_1+x_1y_0,x_0y_0)$ refutes the decoding claim; the displayed residual bounds give a direct proof check. A two-term exact bilinear decomposition over characteristic zero would refute the rank claim; the determinant pencil contradiction is the check. The decoding result must be withdrawn in any target model that excludes nearest-integer operations or does not supply a finite input bound.
