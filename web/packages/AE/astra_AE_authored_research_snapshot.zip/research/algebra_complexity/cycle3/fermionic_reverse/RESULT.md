# Exact support lower bound for universal positive Pfaffian quadrature

Date: 8 October 2026  
Status: internally proved theorems for a narrow, explicitly defined algorithm class; exact finite replay at \(n=6\). One theorem covers exact input-independent quadrature; a second gives an exponential support bound for any fixed positive atom list that must relatively approximate the test family with error below one. Neither is a lower bound for general \(Z_k\) algorithms, FPRASs, or all determinant lifts.

## Result

Consider the full half-sector \(n=2k\) and the legal real-rational target

\[
 Z_{n/2}(A)=
 \sum_{\substack{|I|=|J|=n/2\\I\cap J=\varnothing}}
 \det(A[I,J])^2.
\]

The full-sector Pfaffian formula gives a positive estimator from signs:

\[
 Z_{n/2}(A)=\mathbb E_{\sigma\in\{\pm1\}^n}
 \left|\operatorname{Pf}(D_\sigma A-A^T D_\sigma)\right|^2,
 \qquad D_\sigma=\operatorname{diag}(\sigma_1,\ldots,\sigma_n).
\]

The claim proved here is a worst-case support bound for **input-independent exact quadrature of this sign expectation**.

**Theorem.** Fix even \(n\). Let

\[
 Q(f)=\sum_{\ell=1}^s \lambda_\ell f(\sigma^{(\ell)}),
 \qquad \lambda_\ell\ge 0,\quad \sum_{\ell=1}^s\lambda_\ell=1,
\]

be a sign quadrature chosen before seeing \(A\). Suppose it exactly computes \(Z_{n/2}(A)\) through the displayed Pfaffian-square estimator for every real-rational matrix in the block-pair family defined below. Then its support modulo the global sign \(\sigma\sim-\sigma\) contains every class. In particular,

\[
 s\ \ge\ 2^{n-1}.
\]

This is tight: one representative from each global-sign class, all with weight \(2^{-(n-1)}\), is exact for the full-sector Pfaffian-square identity. Thus the minimum support in this class is exactly \(2^{n-1}\).

The family is explicit and uses only nonnegative rational matrix entries. Let \(\pi=\{\{u_i,v_i\}:1\le i\le k\}\) be any perfect pairing of \([n]\). For rational \(a_i,b_i>0\), define \(A_{\pi,a,b}\) by

\[
 A_{u_i v_i}=a_i,\qquad A_{v_i u_i}=b_i,
\]

with every other entry zero. The construction takes polynomial input bits: the matrix is a rational \(n\times n\) matrix and \(k=n/2\) is supplied as part of the legal target query. The theorem is a statement about deterministic exact quadrature support, not a statement that the target index \(k\) is a discovered minor location.

## Proof

First compute the target exactly on this family. A nonzero minor must take the same number of rows and columns from each pair block. Because the row and column sets are disjoint and each block has only two sites, a block can contribute at most one selected row. Since there are \(k\) blocks and the total number of selected rows is \(k\), every block contributes exactly one row and one column. The two sites chosen in a block must be opposite. The minor is then a product of one entry from each block, up to the permutation sign, so summing its square over the two choices in each block gives

\[
 Z_{n/2}(A_{\pi,a,b})=\prod_{i=1}^k(a_i^2+b_i^2)>0. \tag{1}
\]

Now permute coordinates so each pair is adjacent. The skew matrix \(D_\sigma A-A^T D_\sigma\) is block diagonal, and its block for \(\{u_i,v_i\}\) has upper-right entry \(\sigma_{u_i}a_i-\sigma_{v_i}b_i\). A simultaneous coordinate permutation can change the Pfaffian by a global sign only. Hence

\[
 \left|\operatorname{Pf}(D_\sigma A_{\pi,a,b}-A_{\pi,a,b}^T D_\sigma)\right|^2
 =\prod_{i=1}^k(\sigma_{u_i}a_i-\sigma_{v_i}b_i)^2.
\]

Writing \(x_i=\sigma_{u_i}\sigma_{v_i}\) and

\[
 \gamma_i=\frac{2a_i b_i}{a_i^2+b_i^2},
\]

the normalized integrand is

\[
 \frac{|\operatorname{Pf}(\cdots)|^2}{Z_{n/2}(A_{\pi,a,b})}
 =\prod_{i=1}^k(1-\gamma_i x_i). \tag{2}
\]

Under uniform independent signs, the \(x_i\) are independent uniform signs, so the mean of (2) is one. This proves the Pfaffian estimator identity directly on the required test family, without relying on any algorithmic assumption.

Suppose \(Q\) is exact for every rational choice of \(a_i,b_i>0\). Dividing by (1), equation (2) yields

\[
 \sum_{\ell=1}^s\lambda_\ell
 \prod_{i=1}^k(1-\gamma_i x_i^{(\ell)})=1
\]

for every \(\gamma_i=2r_i/(1+r_i^2)\) with \(r_i=b_i/a_i\in\mathbb Q_{>0}\). This is an infinite set of values in each coordinate. The left side minus one is a polynomial of degree at most one in each \(\gamma_i\); a multivariate polynomial that vanishes on this Cartesian product of infinite sets is identically zero. Comparing its coefficient for any nonempty \(S\subseteq[k]\) gives

\[
 \sum_{\ell=1}^s\lambda_\ell
 \prod_{i\in S}\sigma^{(\ell)}_{u_i}\sigma^{(\ell)}_{v_i}=0. \tag{3}
\]

The pairing \(\pi\) was arbitrary. Every nonempty even subset \(U\subseteq[n]\) can be made a union of pairs in some perfect pairing: pair the elements of \(U\) among themselves and pair the even-sized complement among itself. Applying (3) to that pairing proves

\[
 \widehat Q(U):=\sum_{\ell=1}^s\lambda_\ell
 \prod_{j\in U}\sigma_j^{(\ell)}=0
\quad\text{for every nonempty even }U. \tag{4}
\]

Pass to the finite group \(G=\{\pm1\}^n/\langle-\mathbf 1\rangle\), which has \(2^{n-1}\) elements. Its characters are exactly the even-subset characters \(U\mapsto\prod_{j\in U}\sigma_j\). Equation (4), together with \(\widehat Q(\varnothing)=1\), says that the Fourier transform of the pushforward distribution on \(G\) is one at the trivial character and zero at every other character. Fourier inversion therefore makes that pushforward the uniform distribution on all \(2^{n-1}\) classes. Each class has positive mass, so at least one atom of \(Q\) must represent each class. This proves \(s\ge2^{n-1}\).

For tightness, choose \(\sigma_1=+1\) and let the remaining signs range uniformly over all \(2^{n-1}\) choices. This is uniform on the quotient \(G\). Every nontrivial even character averages to zero, and the Pfaffian square is invariant under \(\sigma\mapsto-\sigma\). Therefore this quadrature is exact for every full-sector Pfaffian-square integrand, and hence for every real-rational \(A\) covered by the identity.

## Approximation support bound for a fixed atom list

There is also an exponential support obstruction that does not require exactness or input-independent weights. Fix a set \(S\subseteq\{\pm1\}^{2k}\) of Pfaffian sign atoms **before** the matrix is supplied. For each input, allow any nonnegative coefficients on these atoms, including coefficients chosen after inspecting the input:

\[
 \widehat Z(A)=\sum_{\sigma\in S}\lambda_\sigma(A)
 \left|\operatorname{Pf}(D_\sigma A-A^T D_\sigma)\right|^2,
 \qquad \lambda_\sigma(A)\ge0.
\]

If this positive fixed-support rule has relative error \(\epsilon<1\) on every rational block-pair input \(A_{\pi,1,1}\), then

\[
 |S|\ \ge\
 \left\lceil\frac{(2k-1)!!}{k!}\right\rceil
 =
 \left\lceil\frac{\binom{2k}{k}}{2^k}\right\rceil
 \ \ge\ \left\lceil\frac{2^k}{2k+1}\right\rceil
 =2^{\Omega(n)}. \tag{5}
\]

For \(a_i=b_i=1\), equation (1) gives \(Z_{n/2}=2^k\), while the Pfaffian-square value is

\[
 \prod_{i=1}^k(\sigma_{u_i}-\sigma_{v_i})^2
 =4^k\,\mathbf 1\{\sigma_{u_i}\sigma_{v_i}=-1\text{ for every pair of }\pi\}.
\]

Because all coefficients are nonnegative, a fixed atom list missing this event for even one pairing produces estimate zero on that instance. Relative error below one forbids zero, so \(S\) must intersect the all-opposite event for every perfect pairing \(\pi\). An atom can lie in such an event only if it has exactly \(k\) positive and \(k\) negative coordinates. A balanced atom covers exactly \(k!\) pairings: pair each positive coordinate with a negative coordinate by any bijection. There are \((2k-1)!!\) pairings in total. Counting covered pairings, with overlap allowed, gives \(|S|k!\ge(2k-1)!!\), proving (5). Global-negation-equivalent signs cover the same events, so the same lower bound also applies to the number of quotient classes in the support.

This approximation theorem is deliberately about a **fixed atom support**, though its nonnegative weights may depend arbitrarily on \(A\). It rules out a polynomial-size universal shortlist of Pfaffian evaluations even when exactness is relaxed to any relative tolerance below one. It does not rule out sampling new signs per input, choosing the proposal from \(A\), signed combinations, or a formula that aggregates Pfaffian terms without evaluating a fixed list.

## What the obstruction does and does not rule out

The excluded class is precise: a single sign list and nonnegative weights are fixed independently of the input, the output is the literal weighted sum of the Pfaffian-square evaluations at those sign vectors, and exactness is required for all rational block-pair inputs above. The theorem rules out a polynomial-support deterministic quadrature for that universal exact task. Its mechanism is Fourier uniqueness across all pairings, rather than the exponential-variance calculation for repeated \(4\)-cycle blocks or the \(K_4\) diagonal-term interference counterexample.

It does **not** rule out any of the following:

* a randomized FPRAS whose sample law or estimator depends on \(A\);
* an input-dependent quadrature, an adaptive method, or a compressed formula that aggregates many sign terms without evaluating each atom;
* a different positive matching, mixed-discriminant, determinantal, or tensor-network lift;
* exact or approximate polynomial-time algorithms for \(Z_k\) using methods outside this quadrature class;
* the bounded-block algorithms already known for the same test family.

In particular, each matrix \(A_{\pi,a,b}\) is easy: equation (1) computes its target in \(O(n)\) rational operations once the blocks are given. The exponential lower bound is on the number of input-independent Pfaffian evaluations needed to cover all such instances, not on computing these instances directly and not on the general target.

## Cycle-2 interface audit and baseline match

The relevant earlier identities were checked before selecting this mechanism:

1. For \(V=[I_n,A^T]\), \(G=V^*V\), and \(P(S)\) selecting both columns associated to every \(i\in S\), Cauchy–Binet gives
   \[
   \det G[P(S),P(S)]
   =\sum_{\substack{J\subseteq S^c\\|J|=|S|}}|\det A[S,J]|^2,
   \qquad
   Z_k(A)=\sum_{|S|=k}\det G[P(S),P(S)].
   \]
   Thus the support condition is linear matroid parity on the paired columns. The separate support/zero/witness route recorded in cycle 2 imports a matroid-parity optimization algorithm; even granting that interface, it does not compute the positive weighted partition sum or its conditional masses.
2. In the full sector \(n=2k\), the Pfaffian sign identity is a positive unbiased estimator. The earlier \(d\)-block \(4\)-cycle calculation proves relative variance \(2^d-1\) for direct independent sampling on that family. That variance statement is about that estimator.
3. The natural row-activity polynomial has exact \(C_4\) and \(P_5\) stability/log-concavity counterexamples, and the direct same-variable PSD-pencil/mixed-discriminant lift is excluded for those polynomials. These are route-specific obstructions, not a general determinant-lift theorem.
4. Bounded blocks have an exact coefficient DP, so they remain a strong algorithmic baseline. The present theorem uses a parameterized block family to test an input-independent universal quadrature, but it does not contradict that DP.
5. The known PM-to-\(Z\) reduction and the conditional OA113 + PC-05 weighted-PM baseline do not make weighted PM an open problem and do not imply a reverse \(Z\)-to-PM reduction. This leaf makes no PM-hardness or PM-open-problem claim.

The exact \(n=6\) replay enumerates all 15 pairings, checks the target formula and Pfaffian-square expectation over all 64 sign vectors for rational block weights, verifies that the resulting pair-union characters are all 31 nontrivial even characters, and checks rank 32 for the quotient Walsh matrix. The replay is finite evidence only; the Fourier proof supplies the all-\(n\) theorem.

## Cost ledger and status

For dimension \(n=2k\), the exact minimum quadrature support is \(2^{n-1}\). An explicit sign atom needs \(n\) bits. The tight weights \(2^{-(n-1)}\) need \(O(n)\) bits each. On an explicit rational \(A\) of bit length \(L\), one Pfaffian can be evaluated using polynomially many rational operations with polynomially bounded intermediate bit lengths (clear a common input denominator, then use exact fraction-free Pfaffian elimination or the determinant/Pfaffian algorithms). Therefore the literal quadrature cost is at least \(2^{n-1}\) polynomial-cost evaluations; an explicit atom list itself has exponential length. No approximation parameter \(\epsilon\), failure probability \(\delta\), retry cost, or normalization transfer is asserted, because this is an exact quadrature lower bound rather than an approximation-preserving reduction.

The theorem is internally proved. The executable evidence is finite at \(n=6\). Pfaffian minor summation and linear matroid parity are prior mathematical frameworks; no priority or novelty claim is made for those identities. The specific exact universal-quadrature support theorem is an internal result whose external novelty has not been checked.

## Falsifier

Any fixed normalized quadrature with fewer than \(2^{n-1}\) sign atoms that exactly computes the full-sector Pfaffian-square expectation for every rational block-pair matrix at some even \(n\) falsifies the theorem. Equivalently, a non-uniform probability distribution on \(\{\pm1\}^n/\{\pm\mathbf1\}\) whose every nontrivial character expectation is zero would falsify the Fourier step. The exact \(n=6\) replay checks the finite pairing/character incidence and Walsh rank; it does not replace the general group argument.

## Sources

See SOURCES.md for primary references, local cycle-2 audit paths, evidence status, and the exact scope of each citation.
