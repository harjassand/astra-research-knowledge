# Sources and evidence ledger

Date: 8 October 2026

## Primary mathematical references

1. Masao Ishikawa and Masato Wakayama, “Minor Summation Formula of Pfaffians,” *Linear and Multilinear Algebra* 39 (1995), 285–305. The paper establishes a Pfaffian expression for weighted sums of minors. Publisher record: https://doi.org/10.1080/03081089508818403. The general full-sector sign identity used as context in this leaf is also recorded in the cycle-2 derivation; the new block-family proof is checked directly and does not depend on an unverified theorem statement from this source.
2. Kazuki Matoya and Taihei Oki, “Pfaffian Pairs and Parities: Counting on Linear Matroid Intersection and Parity Problems,” arXiv:1912.00620 (2019), https://arxiv.org/abs/1912.00620. This is background for the paired-column / linear-matroid-parity support interface, not a weighted partition-function algorithm.
3. Julius Borcea, Petter Brändén, and Thomas M. Liggett, “Negative Dependence and the Geometry of Polynomials,” arXiv:0707.2340, https://arxiv.org/abs/0707.2340. This is prior framework for the stability/strong-Rayleigh discussion already audited in cycle 2; the present quadrature theorem does not invoke stability.

## Internal cycle-2 checks reviewed

* Fixed-filter Gram identity, Pfaffian expectation/variance, and existing stability counterexamples: ../../cycle2/hitting_list_generator/REPRESENTATION_ROUTE.md.
* Exact natural-polynomial C4/P5 stability and PSD-pencil scope: ../../cycle2/determinant_finiteness/RESULT.txt.
* Exact linear-matroid-parity support interpretation: ../../cycle2/RESULT.txt and ../../../../../work/programmes/fermionic_algorithms/cycle2/leaf-02/RESULT.txt.
* Bounded-block exact sampler baseline: ../../../../../work/programmes/fermionic_algorithms/cycle2/leaf-06/RESULT.txt.
* Conditional weighted-PM baseline and why it is not an open-problem implication: ../../cycle2/conditional_lb/CONDITIONAL_LB.md and ../../cycle2/determinant_beyond_degree/WEIGHTED_PM_TO_Z.md. OA113 is marked source-reported; PC-05 is an internal proof candidate. Neither is independently validated by this leaf.

The cycle-2 stability, cycle, and P5 exact replays were rerun read-only with outputs sent to /tmp; they passed. No cycle-2 file was edited.

## New evidence

* Proof: RESULT.md, exact Fourier-uniqueness argument for exact universal sign quadratures and pairing-covering bound for relative error epsilon<1 on a fixed atom support.
* Finite checker: evidence/check_universal_pfaffian_quadrature.py.
* Receipt: evidence/receipt.json, PASS at n=6: all 15 pairings, all 31 nontrivial even characters, quotient Walsh rank 32, and the exact Z_3/Pfaffian expectation plus quotient-representative quadrature for every tested rational block matrix.

Finite replay does not substitute for the all-even-n proof. External novelty/priority of either quadrature theorem is unknown.
