# Leaf 04: all-fixed-field matrix multiplication exponent

Audit date: 8 October 2026. Scope: the field transfer behind `L03-all-field-nine-fourths`, especially the exact field hypotheses, extension overhead, characteristic two, and the distinction between an arithmetic exponent and an explicit algorithm artifact.

## Verdict

The primary 9/4 manuscript proves its headline only over `C`. The all-field 9/4 statement is a separate, internally reconstructed corollary, not a theorem stated by that manuscript. I found no algebraic gap in the finite-field transfer steps routed through the card: each extension-field operation can be descended with an explicit `k^3` copy charge; all asymptotic losses vanish in the relevant root or entropy limit; and the characteristic-two steps use no division by two or semisimplicity. The result remains conditional on the correctness of the 9/4 manuscript's character/profile proof and on the manual field-independent adaptation of its detecting-character argument. This is a scoped mathematical reconstruction, not a kernel-checked or external validation.

The exact arithmetic conclusion supported by that reconstruction is:

> For every field `F` and every `ε>0`, there is a finite division-free arithmetic program for square matrix multiplication over `F` with cost `O_{F,ε}(n^(9/4+ε))`. More sharply, the construction can be made over the prime subfield: for each prime `p`, the same `O_{p,ε}` program works over every field of characteristic `p`; in characteristic zero a rational-coefficient program works over every such field. No constant uniform over all characteristics is established.

The conclusion is an exponent statement. It does not give a displayed low-rank decomposition, a procedure that efficiently finds one, a practical crossover size, or a bit-complexity bound.

## What the primary sources say

OpenAI, *An Upper Bound of 9/4 for the Matrix Multiplication Exponent*, dated 2 October 2026, states Theorem 1.1 over the complex numbers. Its introduction defines the arithmetic exponent using scalar field operations and arbitrary positive exponent slack. The tensor sections and Appendix A are written for tensors over `C`; they do not state the all-field corollary. The paper's number-field remark does establish that its complex exact-rank premise can be realized over `Qbar`: the rank equations have rational coefficients, so a complex solution gives an algebraic solution, and finitely many coefficients lie in one number field.

The official family-107 formalization scope separately records `ω(C)≤9/4` and the bound `ω(F)<2.371054886006746` over every field. It describes the arithmetic model as finite division-free programs and explicitly separates arithmetic from bit complexity and practical crossover. Thus the all-field formalized statement in that record is the weaker 2.371… bound, not the 9/4 transfer audited here.

OpenAI, *Staggered extraction for exact matrix multiplication over every field*, dated 24 September 2026, proves an exact arithmetic bound `<2.371054886006746` over every fixed field, including positive characteristic. This is a distinct all-field result and a useful baseline; it does not by itself transfer the later complex 9/4 bound. In the official release catalog, entry 004 is Hilbert's tenth problem over `Q` and is unrelated. The L03 card's declared external dependency is `external:OA107`; if “release 4” means another source than the September all-field companion, that name is not identified in the card's dependency record.

Primary-source links:

- [9/4 manuscript PDF, 2 October 2026](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf) and [its README/citation](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/README.md).
- [Family 107 formalization scope](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/docs/107.md).
- [Staggered extraction manuscript PDF, 24 September 2026](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Staggered-extraction-for-exact-matrix-multiplication-over-every-field-September-24-2026/Staggered-extraction-for-exact-matrix-multiplication-over-every-field-September-24-2026.pdf).
- The official [release overview](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/overview.tex) distinguishes entry 004 from family 107 and lists the two matrix-multiplication manuscripts under 107.

The source text checked locally is indexed in the routed corpus as `d-885fe56f728a0f91` (the 9/4 paper), `d-ccaccb70b5589bf1` and `d-a4e09a88a57fe06d` (the September all-field manuscript and its introduction), and `d-d3cf9332d1df9fe3`, `d-c8c44a330cd66a5b`, `d-2dd80b9b6fe74acf` (the three transfer reconstructions). The last three are research notes, not primary-source certification.

## Exact finite-field transfer lemma

Let `F=F_q` be a fixed finite field, `E/F` a degree-`k` extension, and `ell:E→F` an `F`-linear functional with `ell(1)=1`. Such an `ell` exists by choosing an `F`-basis of `E` containing `1`. If an `E`-linear restriction of `A_E` has all final coefficients in `F`, expand each of its three substituted linear forms in that basis. Applying `ell` to each resulting trilinear coefficient gives

`ell(UVW) = Σ_{i,j,h} ell(e_i e_j e_h) U_i V_j W_h`.

For each triple `(i,j,h)`, the coordinate forms `U_i,V_j,W_h` are `F`-linear substitutions on the three legs of one whole copy of `A`; absorb the scalar `ell(e_i e_j e_h)` into one leg. Thus an `E`-restriction of `L` copies whose output is `F`-rational descends to an `F`-restriction of at most `L k^3` full copies. For a one-parameter degeneration, apply the same operation coefficientwise: zero lower coefficients stay zero, and an `F`-valued leading tensor is fixed by `ell`. The projection is linear, not multiplicative; the cubic coordinate expansion is essential.

### Separator and charged overhead

For `A=Σ_{h=1}^M A_h` with a shared first leg and matched, disjoint second- and third-leg sectors, set

`k = min{j≥1 : q^j ≥ 3M+1}`, `L=q^k−1`.

The group `E^×` is cyclic of order `L`; choose a primitive `L`th root `ζ`. In `L` source copies use the phase substitutions in the L03 reconstruction. Their coefficient average is

`L^(-1) Σ_{r=0}^{L−1} ζ^{r e}`, where `e=u−v+2(g−h)`.

Since `|e|≤3(M−1)<L`, orthogonality selects exactly `e=0`, as an integer equality. The surviving target coefficients lie in `F`. The target-variable weights `g²`, `hu−h²`, and `−hv` give total weight `(g−h)²` on every surviving term, so the minimum-weight tensor is exactly `⊕_{h=1}^M(A_h⊗B_X(M))`. Descent therefore gives the base-field degeneration

`A^(⊕ L k^3)  ↠  ⊕_{h=1}^M(A_h⊗B_X(M))`.

Minimality of `k` gives `L < q(3M+1)` and `k≤1+log_q(3M+1)`. Hence the charged number of source copies is

`L k^3 = O_q(M(1+log M)^3)`.

The factor cannot be discarded at finite `M`. In the entropy argument, after dividing by the number `M` of type words, the extra factor is only `O_q((1+log M)^3)`. For a tensor power indexed by `N`, `log M=O(N)`, so its `N`th root tends to one. The original entropy exponent is preserved. Constants depend on the chosen base field (or can be routed through `F_p` to depend only on its characteristic).

### Degeneration monotonicity over a finite field

Suppose a fixed witness of degree `D` over `F` degenerates `A` to `B`. For its `j`th tensor power, the coefficient polynomial has degree at most `jD` and constant coefficient `B^⊗j`. Put `s_j=jD+1`, and choose `E_j/F` of degree `k_j` with `q^{k_j}−1≥s_j`. Interpolate the constant coefficient from `s_j` distinct nonzero points of `E_j`; each evaluated tensor is an `E_j`-restriction of `A_Ej^⊗j`. Descend the whole interpolation once. For every `F`-tensor character `lambda`,

`lambda(B)^j ≤ s_j k_j^3 lambda(A)^j`, with `k_j=O_{q,D}(log(j+2))`.

Taking `j`th roots proves `lambda(B)≤lambda(A)`. If `D=0`, the exact restriction suffices. This repairs the finite-field failure of trying to interpolate from only `F_q^×` after `jD+1>q−1`. The overhead is polynomial in `j` and logarithmic-degree cubed; no continuity of `lambda` is assumed.

### Convolution profile

For fixed `a,b`, let `m=a+b−1` and choose one finite extension `E/F` with at least `m` elements. Evaluation/interpolation gives `rank_E C(a,b)≤m`, where `C(a,b)` is univariate polynomial convolution. Tensor there first, then descend once using the fixed degree `k=[E:F]`:

`rank_F(C(a,b)^⊗j) ≤ k^3 m^j` for every `j`.

Consequently `lambda_F(C(a,b))≤m` after taking `j`th roots. The extension degree is fixed as `j→∞` because `a,b` are fixed. Charging a new extension-coordinate factor at each tensor factor would be an incorrect exponential loss; the proof does not do that.

## Characteristic two and the remaining source argument

For `q=2`, `L=2^k−1` is odd, so `1/L` exists in `E=F_{2^k}` and `E^×` has a primitive `L`th root. The Fourier exponent `u−v+2(g−h)` is an integer group exponent, not a field coefficient; the bound `|e|<L` still forces `e=0`. Formal degeneration weights are integer valuations and are not reduced modulo the field characteristic.

The determinant filtration in the 9/4 proof can be checked directly in every characteristic. Its map is diagonal substitution in a polynomial ring over the field; with `D=uw−vs`, the kernel is `D V_{e−1}`. Multiplication by the nonzero polynomial `D` is injective because the polynomial ring is a domain, and the dimensions give exactness. The quotient lifts map to the standard monomial basis with coefficient `1`; the appended kernel basis has unit pivots (`±1`, both units in every characteristic). Multiplication commutes with diagonal substitution and takes `Dg` to `D(fg)`. This uses no division by two and no semisimplicity of an `SL_2` representation. In characteristic two, the minus sign in `D` becomes plus, while the exact-sequence and basis argument remains unchanged.

The three-sector construction uses only integer coordinate weights, deletion of coordinates, index translations, and a basis reversal. The formal weights and the coordinate maps remain meaningful in characteristic two. The appendix's detecting-character proof can likewise be rerun over a chosen field: its tensor semiring, rank bounds, finite-dimensional rational cone certificate, compact convex state space, and fixed-point step use only exact restrictions, direct sums, tensor products, integer ranks, and real compactness. No complex topology or algebraically closed coefficient assumption enters that argument. This adaptation is part of the reconstructed corollary; it is not asserted by the complex-only statement of the primary paper.

## Exponent versus a decomposition or bit algorithm

Once the character/profile proof gives `nu_F≤9/4`, the definition `nu_F=inf_d log_d rank_F(T_d)` implies that for every `δ>0` some fixed block size `u` has an exact rank decomposition of `T_u` with `r<u^(9/4+δ)` terms. Recursing this fixed bilinear identity gives `S(N)≤r S(N/u)+O_{u,r}(N^2)` on powers of `u`; padding to an arbitrary dimension changes size by only a fixed factor. This proves `O_{F,ε}(n^(9/4+ε))` field operations.

That argument is existential. It does not provide `u`, the `r` rank-one tensors, a search procedure with useful runtime, a practical crossover, or bounds on coefficient heights. The 9/4 source's own number-field remark handles characteristic zero by choosing coefficients in one finite extension of `Q` and simulating each extension-field operation by a constant number (depending on that fixed extension) of rational operations; the resulting rational program embeds in every characteristic-zero field. In characteristic `p`, the finite-field proof can be carried out over `F_p`, and the resulting program embeds in every field of that characteristic. Neither route is a bit algorithm: operation counts ignore coefficient encoding, construction of extensions/bases, and coefficient acquisition.

## Source and proof status

The field-specific lemmas above were reconstructed from the exact finite-separation interface in Proposition “Finite separation” of the 9/4 paper and the character/profile chain in its Sections 2–5 and Appendix A. They match the detailed routed derivations in `d-d3cf9332d1df9fe3`, `d-c8c44a330cd66a5b`, and `d-2dd80b9b6fe74acf`. The September all-field paper independently confirms the meaning of “arithmetic exponent over every fixed field,” but its numerical result is weaker.

**Scoped status:** no gap found in the extension degree/cost, convolution root-limit, or characteristic-two repairs. The all-field 9/4 result is a conditional manual corollary of the October 2 complex 9/4 proof plus the field-independent character argument. No Lean theorem, external expert validation, explicit low-rank decomposition, coefficient-height accounting, or novelty/priority conclusion is established by this audit.
