# Leaf 01 — Shared graph kernels with row-local encodings

**Status: scoped obstruction proved; target algorithm still open.** This note extends the supplied coordinate-alias counting obstruction to repeated use of a polynomial-size library of globally shared graph kernels. It also grants each source vertex an arbitrary linear change of its inner coordinate and gives output decoding for free. These extensions still cannot cover every legal mask in subquadratic arithmetic cost. This is not a lower bound for arbitrary arithmetic circuits, and it does not solve the requested selective product.

## Interface and model

Let \(N\) tend to infinity through fourth powers, \(D=N^{1/4}\), and \(m=\lfloor N^{15/8}\rfloor\). The target inputs are dense \(X\in\mathbb Z^{N\times D}\) and \(Y\in\mathbb Z^{D\times N}\); the supplied mask \(W\subseteq[N]\times[N]\) has size \(m\). The required outputs are the exact polynomials

\[
p_{ij}(X,Y)=\sum_{k=1}^D X_{ik}Y_{kj},\qquad (i,j)\in W.
\]

The scoped strategy is as follows.

All kernel choices, maps, transforms, and decoder coefficients may depend on \(N,W\), but not on the values of \(X,Y\). There is no data-dependent branching.

1. Before seeing \(W\), a library contains \(K_N\le N^a\) fixed source kernels, for a fixed constant \(a\). Kernel \(\ell\) is a division-free arithmetic circuit for the exact graph-restricted product on a nonempty bipartite graph \(H_\ell\subseteq[U_\ell]\times[V_\ell]\), with \(h_\ell=|H_\ell|\ge1\) edges and no isolated vertices. It computes one output for each edge:
   \[
   q_{uv}(A,B)=\sum_{k=1}^D A_{uk}B_{kv},\qquad (u,v)\in H_\ell.
   \]
   The source circuit may share arithmetic globally in any way.
2. After seeing \(W\), the strategy may invoke any sequence of library kernels. For each source row vertex \(u\), it may feed an arbitrary linear transform of one target row \(X_{f(u),:}\), or zero; for each source column vertex \(v\), it may feed an arbitrary linear transform of one target column \(Y_{:,g(v)}\), or zero. Here \(f(u),g(v)\in[N]\cup\{\bot\}\). The transforms may have arbitrary exact field coefficients, and their construction and description are granted free. They may mix the \(D\) inner coordinates, but may not mix distinct target rows or distinct target columns.
3. Every chosen source circuit is evaluated in full. The strategy may then use arbitrary linear combinations of all source outputs, also granted free, to produce the requested outputs. The source arithmetic circuit itself is not rewritten after the aliases or transforms are chosen.

The only charge assumption is that evaluating a source kernel costs at least
\[
c_0\max\{h_\ell,U_\ell D,V_\ell D\}
\tag{1}
\]
arithmetic operations, for a fixed \(c_0>0\). For the graph tensor
\[
T_{H_\ell,D}=\sum_{(u,v)\in H_\ell}\sum_{k=1}^D
A_{uk}\otimes B_{kv}\otimes C_{uv},
\]
the output flattening has rank \(h_\ell\): its edge slices have disjoint monomial supports. The \(A\)-input flattening has rank \(U_\ell D\), since the slice for each \((u,k)\) is nonzero and has monomials \(B_{kv}C_{uv}\) disjoint from those for every other \((u',k')\); nonisolation ensures nonzero slices. The \(B\)-input flattening similarly has rank \(V_\ell D\). Tensor rank dominates each flattening rank, and bilinearizing an arithmetic circuit costs at most a constant factor in gates. Thus (1) is a valid charged lower bound up to \(c_0\). The assumption permits an ideal source attaining this lower bound; it does not use a current matrix-multiplication exponent.

## Theorem

For any fixed \(\eta>0\) and \(C>0\), if a strategy in this model invokes kernels of total arithmetic cost at most \(B=C N^{2-\eta}\), then for all sufficiently large \(N\) it fails on at least one mask \(W\) of size \(m\). Thus a polynomial-size library, repeated globally shared source computations, arbitrary inner-coordinate transforms local to each row or column, and free linear output decoding do not give a uniform \(O(N^{2-\eta})\)-operation algorithm for the target.

## Proof

Fix one complete strategy configuration: the ordered source-kernel choices and all discrete maps \(f,g\). Let \(E\subseteq[N]\times[N]\) be the union, over all invoked source edges \((u,v)\in H_\ell\), of the mapped pairs \((f(u),g(v))\) for which neither endpoint is \(\bot\). Every output of an invoked source kernel is a bilinear polynomial supported only on the pair assigned to that source edge. Its inner-coordinate transforms can change the coefficients of monomials \(X_{ik}Y_{k'j}\), but cannot change the row/column pair \((i,j)\). Linear combinations of source outputs therefore have no row/column pair outside \(E\).

The requested polynomials \(p_{ij}\) for distinct pairs are linearly independent: the monomial \(X_{i1}Y_{1j}\) occurs in \(p_{ij}\) and in no \(p_{i'j'}\) with \((i',j')\ne(i,j)\). Consequently, returning every \(p_{ij}\) for \((i,j)\in W\) requires \(W\subseteq E\). If \(L\) kernels are invoked, then
\[
|E|\le\sum_{\ell=1}^L h_\ell\le B/c_0.
\tag{2}
\]

It remains to count possible supports. From (1), each invocation costs at least \(c_0D\), so \(L\le B/(c_0D)\). The number of ordered source sequences of length at most this bound is at most
\[
\bigl(\lceil B/(c_0D)\rceil+1\bigr)K_N^{B/(c_0D)+1}.
\]
For a fixed sequence, the discrete alias maps have at most
\[
(N+1)^{\sum_\ell(U_\ell+V_\ell)}\le (N+1)^{2B/(c_0D)}
\]
possibilities. The arbitrary transforms and output-decoder coefficients add no support choices: they cannot introduce a new target row/column pair. Each fixed configuration can therefore serve at most \(\binom{\lceil B/c_0\rceil}{m}\) masks. The total number of masks this strategy class can serve is at most
\[
\bigl(\lceil B/(c_0D)\rceil+1\bigr)K_N^{B/(c_0D)+1}
(N+1)^{2B/(c_0D)}
\binom{\lceil B/c_0\rceil}{m}.
\tag{3}
\]

If \(\lceil B/c_0\rceil<m\), no configuration covers even one size-\(m\) mask. Otherwise, since \(B=O(N^{2-\eta})<N^2\),
\[
\frac{\binom{N^2}{m}}{\binom{\lceil B/c_0\rceil}{m}}
=\prod_{r=0}^{m-1}\frac{N^2-r}{\lceil B/c_0\rceil-r}
\ge\left(\frac{N^2}{\lceil B/c_0\rceil}\right)^m
=\exp\bigl(m(\eta\log N-O(1))\bigr).
\tag{4}
\]

The logarithm of the other factors in (3) is
\[
O\!\left(\frac{B}{D}(\log N+\log K_N)\right)
=O(N^{7/4-\eta}\log N)
=o(m\log N),
\]
because \(K_N\le N^a\) and \(m=N^{15/8+o(1)}\). The gap in (4) is \(\Theta(\eta m\log N)\), so (3) is strictly less than \(\binom{N^2}{m}\) for sufficiently large \(N\). At least one legal mask is uncovered. \(\square\)

## Cost and precision ledger

This is a lower bound in an exact arithmetic-circuit model with fully evaluated source circuits. It is intentionally generous to the strategy in several ways.

- The source computations are charged by arithmetic operations, including all shared arithmetic within a kernel. Their output and input ranks give the lower bound (1). Repeated source invocations are charged separately.
- The original dense inputs contain \(2ND=2N^{5/4}\) entries. If entries have \(b=O(\log N)\) bits, reading them costs \(O(N^{5/4}\log N)\) bits. A supplied size-\(m\) mask costs \(\Theta(m\log N)=\Theta(N^{15/8}\log N)\) bits to read. Both are below \(N^2\) by a polynomial factor.
- For a subquadratic source budget, the discrete kernel choices and aliases take \(O((B/D)\log N)=O(N^{7/4-\eta}\log N)\) bits when \(K_N\) is polynomial. Their construction time is not charged here. This is smaller than the supplied mask itself at the target density.
- Each answer has at most \(2b+\lceil\log_2D\rceil+O(1)=O(\log N)\) bits. Writing all answers costs \(\Theta(m\log N)\) bits and at least \(m\) arithmetic/output writes. These costs fit below \(N^2\) and do not explain the obstruction.
- The row-local and column-local transforms can contain arbitrary exact coefficients; the proof charges neither their computation nor their storage. Likewise it grants arbitrary output linear combinations for free. An actual dense decoder can cost \(\Theta(mh)\) operations for \(h\) source outputs, and all transform/decoder coefficient bits, source-circuit descriptions, library acquisition/storage, and exact evaluation precision would also need charging. Including these costs can only make this restricted strategy more expensive.
- The argument does not turn an arithmetic-operation lower bound into a lower bound for all bit algorithms. It permits arbitrary exact constants, so it needs no numerical approximation or number-field precision assumption. A bit-complexity implementation must still specify and charge coefficient representations, intermediate bit lengths, mask-map storage, and decoding. Data-dependent branching or a mask-dependent rewrite is outside the model.

## Exact scope, falsifier, and restart

The bound rules out only low-entropy precompiled graph-kernel libraries whose per-mask specialization maps each source vertex to one target row or column, possibly with arbitrary mixing of its inner coordinates. It allows shared arithmetic inside a kernel and multiple kernel evaluations. It does not rule out a uniform mask-dependent circuit rewrite, arbitrary linear maps that mix target rows or columns, or other genuinely mixed encodings. A mask-sized family of circuits also evades the counting premise, although constructing its selected member within the charged budget is precisely the missing acquisition problem.

A direct falsifier of the proof would be an allowed row-local/column-local configuration producing a monomial with a row/column pair outside \(E\); that would expose an error in the support claim. To attack the original target, the next object should be an explicit uniform mixed-encoding construction for arbitrary \(W\), together with its exact output maps. Charge its mask-reading and encoding time, source arithmetic, all output combinations, coefficient-bit lengths, and output writes before claiming \(O(N^{2-\eta})\). A useful test is whether the acquired circuit produces the \(m\) independent polynomials \(p_{ij}\) with total rank and encoding work below \(N^2\); a fixed-mask tensor-power rank limit alone does not supply that circuit.

No end-to-end algorithm was found in this leaf. The useful result is a scoped extension of the supplied coordinate-copy obstruction to repeated kernel composition and free, row-local inner-coordinate changes. The arbitrary-mask target remains **UNKNOWN / OPEN**.

## Evidence and primary sources

Precise local source ranges inspected:

- [L04 block-cover card](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/astra_prior/cards/L04-block-cover-obstruction.txt:1): lines 3–4 state the exact target, the \(\Omega(N^2)\) theorem for independently charged complete-block covers, and the permitted shared-arithmetic gap.
- [N12 selective-tensor card](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/astra_prior/cards/N12-selective-tensor-barrier.txt:1): line 5 records the fixed-mask tensor-power quantifier, the failed complete-array parameter range, and that no unrestricted impossibility follows.
- [Cycle19 selective-output audit, local source mirror](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/programmes/algebra_complexity/leaf01/d-d2ebdc4e16ec4b31.txt:78): lines 78–112 give the complete-block-cover proof and its explicit exclusions (input sharing, output combinations, and general circuits).
- [Selective-tensor package, local source mirror](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/programmes/algebra_complexity/leaf01/d-1e7a99ec32d38c30.txt:91): lines 91–164 give the supplied one-kernel coordinate-copy counting theorem, including its source-cost axiom, proof, and escape routes. The repeated-kernel count above is a separate derivation extending that source model.
- [State audit, local source mirror](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/programmes/algebra_complexity/leaf01/d-7191d1abbaf01e2b.txt:144): lines 146–180 give the charged target interface and the exact failure of the complete-array certificate; lines 182–184 give the remaining circuit bridge.
- [Cycle19 report, local source mirror](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/programmes/algebra_complexity/leaf01/d-efd7fb715443bfdc.txt:47): lines 49–50 distinguish the all-field arithmetic exponent from a compiled bit/selective algorithm and state that the selective-output target remains open.

The proof above is an elementary counting and support argument; it does not depend on an external matrix-multiplication theorem. Primary papers checked for the surrounding algorithmic routes are [Alman and Vassilevska Williams, arXiv:2610.06783](https://arxiv.org/abs/2610.06783), whose thin-product result uses \(D\le N^{1/18}\) and therefore does not cover this target, and [Graia, arXiv:2608.18496](https://arxiv.org/abs/2608.18496) on fully sparse multiplication. The latter's endpoint sketch limitation is recorded in the supplied audit at lines 38–54.
