# N51 follow-up: exact list-length obstruction and cost ledger

**Status.** `reconstructed` for the lower bounds below. They are exact, unconditional consequences of the stated formula and strong-pencil interfaces. The all-fields list-length obstruction is also present in an earlier archived audit, so this leaf does not claim novelty. It does not refute N51: the supplied generator's list is vastly longer than the necessary linear lower bound. The N51 construction remains a source-derived, internally audited candidate; it has not been externally validated, and its full generator has not been executed.

## 1. Exact card, source, and interface

The exact card is [`work/astra_prior/cards/N51-universal-integer-hitting.txt`](../../../astra_prior/cards/N51-universal-integer-hitting.txt), SHA-256 `4472910e05bb4e6668d26d2c0304b9b9f010e107c1e4550e26d7d683043ea568`. It points to source ID `d-428f5b788339766c`, `updates/R/package/work/agents/complexity_algebra/UNIVERSAL_INTEGRAL_STRONG_LIST.md`. The complete source is preserved as exact UTF-8 in [`d-428f5b788339766c.html`](../../../astra_prior/web/pages/d-428f5b788339766c.html), with original bytes in [`e19a...md`](../../../astra_prior/web/assets/e19a152562e15b57222f44597fe94521d749f37767b2e1db5456f1df739c467b.md). The companion all-characteristic strong-pencil construction and an independent internal audit are also archived at [`ALL_CHARACTERISTIC_STRONG_PENCIL_HITTING`](../../../astra_prior/web/pages/d-2d2ad75880a7c0f4.html) and [`UNIVERSAL_INTEGRAL_LIST_AUDIT`](../../../astra_prior/web/pages/d-d5a55aa5aa7e4d75.html). The earlier audit that records the eigenvalue lower bound is [`all_field_audit/REPORT.txt`](../../../astra_prior/web/pages/d-45004af877cb82de.html).

N51's exact target is stronger than a characteristic-zero formula list: from unary `n,B`, one deterministic generator prints integer `n`-tuples of square matrices. The same list, reduced through the prime subfield, must simultaneously hit every family of at most `B` feasible affine pencils of orders at most `B`, over every coefficient field and every characteristic. Feasibility means invertibility at some matrix evaluation over an extension. The generator receives no coefficients, witnesses, formula, characteristic, or advice. The rational-formula corollary uses formula size `s` equal to the number of tree vertices (leaves and gates count), rational/field constants as leaves, ordered multiplication, and inverse gates. The requested hit must respect every inverse occurrence in the original tree and give a defined invertible final value. Coefficient bit lengths and the cost of evaluating the unknown formula are separate from list generation.

The public September 24, 2026 primary manuscript at commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a` states a related characteristic-zero theorem with rational matrix outputs. N51's all-characteristic integer list is an additional local construction using q-Newton expansion, adjugates, and appended prime-specific lists; I keep the two claims separate.

## 2. All-fields lower bound: at least linear list length

Let an integer list have `h >= 1` tuples

\[
X^{(j)}=(X^{(j)}_1,\ldots,X^{(j)}_n),\qquad X^{(j)}_i\in\operatorname{Mat}_{d_j}(\mathbb Z).
\]

Fix any characteristic, map the list into an algebraic closure `F` of that characteristic, and choose an eigenvalue `a_j\in F` of the first matrix `X^{(j)}_1` for each tuple. The field `F` is allowed by N51's all-coefficient-fields quantifier, and constants `a_j` are allowed formula leaves.

Define

\[
P(x_1)=\prod_{j=1}^h(x_1-a_j).
\]

It is a monic nonzero polynomial. At tuple `j`, one factor `X^{(j)}_1-a_j I` is singular, so `P(X^{(j)}_1)` is singular (the factors are polynomials in the same matrix; equivalently, its determinant is the product of their determinants). Since `F` is infinite, some scalar `b\in F` avoids the finite set `{a_1,...,a_h}`; then `P(b)\ne0`. Thus `P` is a nonzero admissible formula, and it has no inverse gates, so its domain is all matrix tuples.

Each linear factor has a 3-vertex formula `x_1+(-a_j)`. Multiplying the `h` factors adds `h-1` gates. The total formula size is exactly `4h-1`. Hence every list that gives a defined invertible hit for every nonzero size-`s` formula over every field must have

\[
\boxed{h\ge \left\lfloor\frac{s+1}{4}\right\rfloor+1.}
\]

This is a formula-list access lower bound independent of the matrix dimensions or bit lengths. It holds in characteristic zero and in every positive characteristic because the coefficient field can be its algebraic closure and the list entries are reduced from integers.

There is a matching direct lower bound for the strong-pencil interface. If `h<=B`, use the feasible order-one pencil family `L_j(x)=x_1-a_j`, `j=1,...,h`. Pencil `L_j` is feasible over `F` (the scalar evaluation `x_1=a_j+1` gives `1`), but it is singular at list tuple `j`. Therefore no tuple hits all `h` pencils simultaneously. A list promised to hit every family of at most `B` such pencils must have

\[
\boxed{h\ge B+1.}
\]

The second bound is stronger for the strong-pencil problem. Since N51 instantiates its strong-list generator with `B=2s+1` for a size-`s` formula, the actual generated strong list must contain at least `2s+2` tuples. This is a theorem-imposed lower bound on N51's output list; it remains tiny relative to the stated five-grid. The first bound is the direct consequence for any list promised only to hit size-`s` formulas. These arguments were already recorded in the archived independent audit cited above; they are reproduced here to make the interface and constants explicit.

## 3. The inverse-domain requirement also has a concrete adversary

Use the same `P`. The formula `P(x_1)^{-1}` has size `4h`, is defined and invertible at a scalar `b` with `P(b)\ne0`, and is undefined at every list tuple because its inverse gate receives the singular matrix `P(X^{(j)}_1)`. This is a domain-respecting failure, not a cancellation argument.

To expose why simplifying a rational expression before testing its domain is invalid, use

\[
\Phi(x_1)=1+0\cdot P(x_1)^{-1}.
\]

Its formula tree has `4h+4` vertices. It is admissible and nonzero: at a scalar `b` avoiding all `a_j`, every gate is defined and the value is `1`. At each listed tuple, the original inverse occurrence is undefined, even though the free-field element simplifies to `1`. Thus a domain-preserving size-`s` list must also have at least `floor(s/4)` tuples for `s>=8`; the division-free polynomial lower bound in Section 2 is slightly stronger for some residue classes.

This also explains why replacing a list by one block-diagonal tuple is not a valid compression for inverse formulas. A successful tuple can make one formula defined, while another block can make an inverse singular; inversion of the block-diagonal operand requires all blocks to be invertible.

## 4. Weaker Q-only dimension obstruction

For a list required only to hit formulas with coefficients in `\mathbb Q`, the eigenvalues `a_j` above may not be permitted constants. A coefficient-field-compatible fallback uses Cayley–Hamilton. For tuple `j`, let

\[
\chi_j(T)=\det(TI_{d_j}-X^{(j)}_1)\in\mathbb Z[T],
\qquad F(T)=\prod_j\chi_j(T).
\]

`F` is monic, nonzero, defined everywhere, and `F(X^{(j)}_1)=0` for every `j`. Each monic degree-`d` factor has a Horner formula with `4d-1` vertices; after multiplying the factors, the full formula has `4D_{\rm tot}-1` vertices, where `D_tot=\sum_jd_j`. A universal size-`s` Q-formula list therefore needs

\[
D_{\rm tot}>(s+1)/4.
\]

For integer outputs this Cayley–Hamilton witness has integer coefficients and remains nonzero after reduction in every characteristic. This aggregate-dimension bound is weaker than the all-fields cardinality bound for N51 because N51 permits the formula constants `a_j` in extension coefficient fields.

## 5. N51 generation and access cost ledger

The exact N51 integer construction uses `w=n+1`, `Delta=4w^3B`, the least power of two `M>B Delta`, `rho=M/2`, and `d=M rho=M^2/2`. For its characteristic-zero/large-characteristic branch it sets

\[
E_0=3M^2(w+M+1),\qquad T_0=Bd(dE_0+1),\qquad K=\max(M,BT_0+2),
\]

and emits the normalized integer tuples `lambda adj(U_0)U_i` over the five-dimensional grid `{0,...,K}^5`. The `n` matrices in each tuple have order `d`.

From `M=O(w^3B^2)` and `M>w`, these explicit formulas give

\[
\begin{array}{c|c}
\text{quantity} & \text{large-branch bound}\\
M & O(w^3B^2)\\
d & O(w^6B^4)\\
E_0 & O(w^9B^6)\\
T_0 & O(w^{21}B^{15})\\
K & O(w^{21}B^{16})\\
\text{grid tuples }(K+1)^5 & O(w^{105}B^{80})\\
\text{dense integer entries }n d^2(K+1)^5 & O(nw^{117}B^{88})
\end{array}
\]

These are stage-specific polynomial bounds, not a practical runtime claim. The source's exact example at `n=B=1` has `M=64`, `d=2048`, `K=3,453,153,708,034`, about `4.91e62` grid tuples, and about `2.06e69` dense integer entries in the large branch alone. The full generator was not run.

The source proves polynomial coefficient heights but leaves their numeric exponent implicit. If `h_U` is a bit bound for coefficients of the polynomial matrices `U_i`, then evaluating them on the grid gives entry bits

\[
b_U=O(h_U+E_0\log(K+1)+\log(E_0+2)).
\]

Hadamard's bound gives `O(d(b_U+log d))` bits for each cofactor and hence for each output integer, up to the additional `log K` bits from `lambda`. The large-branch dense output-bit bound is therefore

\[
O\!\left(n d^2(K+1)^5\,d(b_U+\log d+\log K)\right),
\]

with `h_U=poly(n+B)` source-derived but no explicit exponent recovered here.

For each prime `p<=K`, N51 appends the separate prime-specific list. The archived construction chooses a prime-to-`p` `M_p=O(w^3B^2)`, `rho_p<=M_p`, `e_p=O(log H_p)`, dimension `d_p=M_p e_p rho_p`, and

\[
H_p=O(B^2M_p^5)=O(w^{15}B^{12}),\qquad |G_p|^4\le H_p^{16}.
\]

Thus each such list has at most `O(H_p^16)` tuples, dimension `d_p=O(w^6B^4 log(wB))`, and `O(nw^{252}B^{200}log^2(wB))` dense entries. Summing over at most `K=O(w^{21}B^{16})` primes gives the conservative upper bound `O(nw^{273}B^{216}log^2(wB))` appended entries; converting entries to integer representatives adds at most `O(log K)` bits per entry. The exact bit-generation exponent for this combined branch remains implicit in the supplied machine bounds.

For a list-evaluation PIT, direct dense evaluation of a size-`s` formula at tuples of dimensions `d_j` uses at most `O(s\sum_jd_j^3)` rational or represented-field operations; a singular inverse marks that tuple undefined. This is a field-operation count. Binary cost also depends on formula input length, constant heights, field representation, and intermediate/response sizes. The N51 generator cost does not include evaluating the unknown formula. In an explicit binary input model, an identity tester cannot run in time bounded only by `n+s` when rational constants are unbounded: two size-three formulas `a-b` can have same-length integer constants whose only differing bit is the final bit, with one difference zero and the other `-1`, forcing worst-case `Omega(L)` input-bit access.

## 6. Primary PIT sources, status, and falsifier

The primary prior sources checked are Arvind–Chatterjee–Mukhopadhyay's 2022 inversion-height-two hitting set and their 2023 paper, revised in 2025, which gives quasipolynomial-size hitting for all rational formulas. Hrubeš–Wigderson 2015 supplies the free-field/domain framework referenced by the N51 construction. These sources establish the surrounding PIT interface; they do not independently validate the local all-characteristic q-Newton and prime-patching construction.

The September 24, 2026 public release paper's generator proves a characteristic-zero rational-output result and gives a separate `O((n+s+1)^87 log(n+s+1))` output-bit calculation. That bound must not be reported as the full all-field integer-list bound: N51 uses the five-parameter adjugate branch and appends small-prime lists. I read the archived exact N51 source, its all-characteristic pencil construction, and the internal integral-list audit; I did not re-run their finite diagnostics or independently reconstruct every inherited lemma. The archive explicitly reports no external proof/priority clearance and no full generator execution.

A falsifier for the cardinality bound would be a list of `h<=floor((s+1)/4)` integer tuples that hits every size-`s` formula over every coefficient field; `P` is an explicit counterexample. A falsifier for the strong-pencil bound would be a list of `h<=B` points that simultaneously hits every family of at most `B` feasible order-at-most-`B` pencils; the eigenvalue pencils refute that. These are lower bounds, not contradictions to N51's much longer list.

## 7. Restart

The next useful quantitative target is a sharper coefficient-height/output-bit polynomial for the five-parameter integer branch and the sum of all prime-specific branches, or a construction whose list length approaches the necessary `Omega(s)` formula bound / `B+1` strong-pencil bound while preserving arbitrary extension coefficients and original inverse domains. The archived small example shows the existing grid cannot be executed at its stated conservative parameters. Keep external correctness, generator execution, and priority as separate unresolved status fields.

### Sources

- N51 compact card: `work/astra_prior/cards/N51-universal-integer-hitting.txt`.
- Full N51 integer-list construction: <https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/updates/R/package/work/agents/complexity_algebra/UNIVERSAL_INTEGRAL_STRONG_LIST.md> (archived exact copy linked above).
- Internal eigenvalue lower-bound audit: `work/astra_prior/web/pages/d-45004af877cb82de.html`.
- All-characteristic strong-pencil construction: <https://raw.githubusercontent.com/harjassand/astra-research-knowledge/main/updates/R/package/work/agents/complexity_algebra/ALL_CHARACTERISTIC_STRONG_PENCIL_HITTING.md>.
- Independent integral-list audit: `work/astra_prior/web/pages/d-d5a55aa5aa7e4d75.html`.
- Public primary, characteristic-zero formula hitting generator, pinned commit: <https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/build/sections/generator.tex>.
- Arvind, Chatterjee, Mukhopadhyay, 2022: <https://arxiv.org/abs/2202.05693>.
- Arvind, Chatterjee, Mukhopadhyay, 2023/v4 2025: <https://arxiv.org/abs/2309.15647>.
- Hrubeš and Wigderson, 2015: <https://zesty2.cs.uchicago.edu/articles/v011a014/>.
