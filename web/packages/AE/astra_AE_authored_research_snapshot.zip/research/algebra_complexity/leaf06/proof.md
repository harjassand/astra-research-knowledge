# Leaf 06: the smooth-form ceiling for determinant lower bounds

Date: 2026-10-08

## Scoped question

Can degree, projective smoothness, and essential variable count alone yield a super-cubic lower bound for the determinantal complexity of an affine restriction of the (m\times m) permanent?

## Exact obstruction

Work over \(\mathbb C\), with \(r,d\ge 2\), and set

\[
F_{r,d}(x_1,\ldots,x_d)=\sum_{i=1}^d x_i^r.
\]

Its degree is exactly \(r\), and all \(d\) variables are essential. Its projective hypersurface is smooth: the partial derivatives are \(r x_i^{r-1}\); their common zero is only the zero vector, which is not a projective point.

There is an affine-linear determinant representation of order

\[
N=1+d(r-1).
\]

Index rows and columns by a hub \(0\) and vertices \((i,j)\), where \(1\le i\le d\) and \(1\le j\le r-1\). Define the matrix \(M\) by

\[
M_{00}=0,\qquad M_{(i,j),(i,j)}=1,
\]

and, for each \(i\), put \(x_i\) in positions

\[
(0,(i,1)),\quad ((i,j),(i,j+1))\ (1\le j<r-1),\quad ((i,r-1),0),
\]

with the last entry replaced by \((-1)^{r-1}x_i\). Set all remaining entries to zero.

To expand \(\det M\), each branch vertex either uses its diagonal 1 or lies on the unique directed cycle through the hub and that branch. The hub has no diagonal term, so every nonzero determinant term must use exactly one such cycle: two cycles cannot both use the hub. Choosing branch \(i\) contributes the permutation sign \((-1)^{r-1}\) times the edge product \((-1)^{r-1}x_i^r\), hence contributes \(x_i^r\). All unused branch vertices contribute their diagonal 1. Therefore

\[
\det M=\sum_{i=1}^d x_i^r.
\]

This is an exact representation, so it also bounds border determinantal complexity:

\[
\operatorname{bdc}(F_{r,d})\le \operatorname{dc}(F_{r,d})\le 1+d(r-1).
\]

The witness has \(dr\) variable coefficients and \(d(r-1)\) constant diagonal coefficients, up to one optional hub constant. Thus its sparse coefficient description has \(O(rd)\) entries of height 1, or \(O(rd\log(rd))\) bits when row, column, and variable indices are explicitly encoded. A dense coefficient-array serialization would separately write zero entries (up to \(O(dN^2)\) scalar slots) and is not claimed to have linear output length. Determinantal complexity counts matrix order; it does not charge determinant-evaluation time.

## Consequence for geometry-only criteria

Any lower-bound rule that is valid for every smooth degree-\(r\) hypersurface in \(d\) essential variables must respect

\[
L(r,d)\le 1+d(r-1).
\]

In particular, no such rule can give \(\omega(rd)\) uniformly. The scale \(\Omega(rd)\) is possible and is asymptotically matched by this example, so this is not a refutation of a degree-times-dimension lower bound.

An affine restriction of \(\operatorname{Perm}_m\) has degree at most \(m\). It depends on at most \(m^2\) essential affine coordinates because the source permanent has only \(m^2\) input coordinates. Therefore a universal smooth-form bound based only on these parameters can contribute at most

\[
1+m^2(m-1)=O(m^3).
\]

This precisely blocks super-cubic or super-polynomial escalation by repeated use of the same degree/smoothness/essential-dimension information. It does not block a cubic lower bound. The September 2026 Family 108 manuscript's claimed smooth-form estimate \((r-1)(d-1)/(4e)\) is consistent with the Fermat upper bound and would yield a cubic permanent bound if its separate permanent-projection and smooth-section arguments are valid.

This ceiling concerns criteria uniform over all smooth forms and depending only on degree and essential dimension. It does not rule out invariants of the particular permanent restriction, such as additional dual or conormal data, if those invariants are proved to force higher determinantal complexity.

For an affine-only variant, \(1+F_{r,d}\) also has a smooth affine zero hypersurface and is represented by the same matrix after changing \(M_{00}\) from 0 to 1; its determinant is \(1+F_{r,d}\). The homogeneous Fermat form above is the relevant example for a smooth-projective-initial-form criterion.

## What this does and does not falsify

The explicit determinant is a falsifier for any proposed *universal smooth-form criterion stronger than order \(rd\)*. It is not a counterexample to a cubic permanent lower bound: for \(r\asymp m\), \(d\asymp m^2\), both the candidate \(\Omega(rd)\) lower bound and this upper bound have cubic scale.

The Family 108 webpage says its cubic theorem has a Lean formalization, but at the pinned release commit both posted theorem declarations end in `by sorry`. This directly falsifies the narrower claim that these posted Lean files mechanically certify the results. It does not falsify the mathematical theorem or replace a proof audit.

## Source record

1. Astra N79 card: `work/astra_prior/cards/N79-smoothness-determinant-barrier.txt`, lines 1–10; source ID `d-14513a2bef6ac3df`. The linked U full note/code/ZIP are explicitly absent. The locally available rendered summary is `work/astra_prior/web/pages/d-14513a2bef6ac3df.html`, lines 271–277. SHA-256: card `100c4e4aac6e0eaf8691b5dad65ce40a72e6c16d1421ac46f0d516e31631e9ac`; page `5b0415ace16df4aa87a73276bc3fab4e9db658c59d79c47ebec18d8abdf41561`.
2. Primary candidate manuscript, OpenAI, *A cubic lower bound for border determinantal complexity of the permanent*, 2026-09-24, 35 pages. Release page: <https://ameskandari.github.io/ai4math/family/108/>. PDF pinned to repository commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a`: <https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-cubic-lower-bound-for-border-determinantal-complexity-of-the-permanent-September-24-2026/A-cubic-lower-bound-for-border-determinantal-complexity-of-the-permanent-September-24-2026.pdf>. Its Theorem 2.3 and Corollary 9.3 state the smooth-form bound; Proposition 7.3 supplies a smooth form of degree \(\asymp m\), dimension \(\asymp m^2\), as an affine permanent projection. PDF SHA-256: `9eb71358fe8d9e08b450286ec6f40cb9f1452f3a49ed7801429485c2676526a6`.
3. Pinned Lean source: <https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/ComparatorChallenges/SmoothInitialForm.lean> and <https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/ComparatorChallenges/PermanentCubic.lean>. The declarations `smooth_initial_form_lower_bound` and `permanent_cubic_lower_bounds` end in `by sorry` in this snapshot. Local downloaded SHA-256 values are recorded in `RESULT.txt`.
4. Published prior benchmark: Thierry Mignon and Nicolas Ressayre, “A quadratic bound for the determinant and permanent problem,” *International Mathematics Research Notices* 2004(79), 4241–4253, DOI <https://doi.org/10.1155/S1073792804142566>; author-hosted primary PDF: <https://math.univ-lyon1.fr/~ressayre/PDFs/permdet.pdf>. It proves the characteristic-zero exact lower bound \(\operatorname{dc}(\operatorname{Perm}_m)\ge m^2/2\). The candidate 2026 manuscript claims a cubic improvement but is not peer reviewed.

## Read scope and limits

The Family 108 PDF was downloaded at the pinned commit and selectively read around its smooth-form theorem, permanent projection, smooth-section construction, polar count, and conclusion (PDF pp. 6–8 and 18–33). Page 18 was rendered to verify that its field is \(\overline{\mathbb F}_2\), not the two-element field; text extraction drops the overbar. This leaf reconstructs the Fermat determinant directly. It does not certify the full 35-page manuscript, its coefficient gadget, or its geometric argument. The release page itself reports no expert review and no independent build of the Lean formalization.
