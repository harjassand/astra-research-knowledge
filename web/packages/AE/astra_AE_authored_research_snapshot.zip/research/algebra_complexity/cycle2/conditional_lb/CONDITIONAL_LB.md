# Conditional approximation consequence for the selective $Z_k$ target

Date: 8 October 2026  
Status: internally derived interface audit; conditional on the stated oracle and source claims. No new inapproximability theorem or reverse reduction is established.

## Target and oracle contract

For $A\in\mathbb Q(i)^{n\times n}$ and a supplied sector index $0\le k\le\lfloor n/2\rfloor$, define

\[
 Z_k(A)=\sum_{\substack{|I|=|J|=k\\I\cap J=\varnothing}}|\det A[I,J]|^2.
\]

The approximation oracle considered here receives the explicit rational-complex matrix $A$, the supplied integer $k$, relative error $\epsilon\in(0,1)$, and failure bound $\delta\in(0,1/2)$. It returns only a scalar estimate: with probability at least $1-\delta$, the answer lies in $[(1-\epsilon)Z_k(A),(1+\epsilon)Z_k(A)]$, with polynomial worst-case bit cost in the encoded input, $\epsilon^{-1}$, and $\log\delta^{-1}$. Unless separately promised, this is not a sampler for $I,J$, a witness finder, or an oracle for conditional masses at prefixes. In particular, the sector $k$ is supplied; it does not encode the locations of any selected minor or output witness.

## Conditional theorem: what a $Z_k$-FPRAS would imply

Assume the one-query weighted-perfect-matching-to-$Z_k$ reduction proved in `../determinant_beyond_degree/WEIGHTED_PM_TO_Z.md`. Then an FPRAS for the half-filled family $Z_{N/2}(A)$ on polynomial-bit rational matrices gives an FPRAS for nonnegative rational weighted perfect matchings in general graphs. The reduction itself constructs real rational $A$, so a real-rational half-sector FPRAS suffices.

If the legal target domain additionally requires $\|A\|_2\le1$, the chart can be shrunk by the positive rational factor $\lambda=[2(1+\sum_{i,j}|A_{ij}|)]^{-1}$ and the oracle queried on $\lambda A$. Since $Z_k(\lambda A)=\lambda^{2k}Z_k(A)$, exact rational rescaling preserves the relative-error and bit-cost bounds. This adapter handles that norm promise only; it does not imply any bound on a physical postselection probability or support other unlisted matrix restrictions.


Here is the charged interface. Let a source be a finite simple graph with an even number $m$ of vertices, $E$ edges, and nonnegative rational activities of total encoding length $L$. Delete zero-weight edges and decide feasibility on the positive support first. If the source count is zero, return zero without a $Z$-query: the positive chart perturbation below can make the target positive even for a zero source. Handle the empty graph directly. If $E<m$, the reduction adds two vertices, a forced unit edge, and unit spokes; otherwise use the original graph. After this padding, write $r=m/2$, $N=2E-m$, and $k=N/2=r+d$, using the padded graph's parameters.

Normalize positive weights by $M=\max_e w_e$, set $p_e=w_e/M$, and let $p_{\min}=\min_e p_e>0$. For requested source error $\rho\in(0,1]$, choose

\[
 \eta=\rho/(64r),\qquad 2^{-s}\le \eta p_{\min}/4,
 \qquad t=2^{-q},\qquad 8k2^N t\le \rho p_{\min}^{r}/32.
\]

Taking $a_e=2^{-s}\lfloor 2^s\sqrt{p_e}\rfloor$ gives $0<a_e\le\sqrt{p_e}$ and $a_e/\sqrt{p_e}\ge1-\eta$, so each $r$-edge matching's product of squared $a_e$'s has relative error at most $2r\eta\le\rho/32$. Put $d=E-m$, so there are $d$ private dummy pairs and $N=E+d$ coordinate-pair labels. Orient each graph edge $e=(u,v)$ arbitrarily and give it columns $b_e=e_u$, $c_e=a_e e_v$. Give each dummy pair two distinct private coordinate columns. Let $B,C\in\mathbb Q^{N\times N}$ have columns $b_j,c_j$. For every label set $S\subseteq[N]$ of size $k=N/2=r+d$, set

\[
 D_S(t)=\det\bigl([b_j+t e_j,\ c_j]_{j\in S}\bigr),
 \qquad R(t)=\sum_{|S|=k}D_S(t)^2,
\]

where $e_j$ is the coordinate vector assigned to pair label $j$. At $t=0$, each selected column is a coordinate vector times either $1$ or $a_e$. A minor is nonzero exactly when it includes every dummy pair and its remaining $m/2$ graph-edge pairs form a perfect matching. Each surviving determinant has one coordinate-basis permutation term, so $R(0)=\sum_{M\text{ perfect}}\prod_{e\in M}a_e^2$.

For $t=2^{-q}$, let $T=B+tI$. The columns of $B$ are coordinate vectors, so its functional digraph consists of cycles with in-trees; every nonzero eigenvalue is a root of unity and all other eigenvalues are zero. Thus $T$ is nonsingular for $0<t\le1/2$. Define $A^T=T^{-1}C$, which is rational. Factoring $T$ from $[T_S,C_S]$ and expanding along the selected identity columns gives, up to sign, $D_S(t)=\det(T)\det(A[S,S^c])$. Since $k=N/2$, disjoint size-$k$ sets are complementary, and the exact identity follows:

\[
R(t)=\det(T)^2 Z_{N/2}(A).
\]

For each $S$, the coefficients of $D_S(t)$ are zero or products of some $a_e$'s, hence have magnitude at most one. If $kt\le1/2$, then $|D_S(t)-D_S(0)|\le(1+t)^k-1\le2kt$, $|D_S(t)|\le2$, and $|D_S(0)|\le1$, so $|D_S(t)^2-D_S(0)^2|\le8kt$. Summing over at most $2^N$ label sets gives $|R(t)-R(0)|\le8k2^Nt$. A positive source has normalized count $\operatorname{PM}_w(G)/M^r\ge p_{\min}^r$. By the choices of $s,q$, weight rounding and chart perturbation together change that normalized count by at most $\rho/16$. Query the $Z$-oracle once at relative error $\rho/4$ and confidence $1-\delta$; multiply its answer by the exact scale $M^r\det(T)^2$. The resulting weighted-PM estimate has relative error at most $\rho$, with the same failure probability $\delta$. The polynomial-time support matching check is the required zero branch.

The precision is polynomially charged:

\[
 s=O(\log(1/\rho)+\log(1/p_{\min})+\log r),\qquad
 q=O(N+r\log(1/p_{\min})+\log(1/\rho)+\log k).
\]

Because $p_{\min}$ has bit length polynomial in $L$, $N=O(E)$, and determinant/cofactor bounds give $O(N(q+\log N))$ bits per chart numerator or denominator (plus $s$ for dyadic edge factors), the fully written $N^2$-entry matrix and exact scale have polynomial encoded length in the source input and $\log(1/\rho)$. This is an approximation-preserving implication with one scalar target query; it does not preserve a vertex-count subquadratic exponent. The complete derivation is in `../determinant_beyond_degree/WEIGHTED_PM_TO_Z.md`, with exact finite replay in `../determinant_beyond_degree/evidence/check_weighted_pm_reduction.py` and `../determinant_beyond_degree/evidence/check_weighted_pm_reduction.json`. The K4 interference check for the reverse-interface counterexample is under this leaf's own evidence directory.

## Existing baseline removes the usual open-problem consequence

The source manuscript OA113, pinned at [the 23 September 2026 release](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/main.pdf), claims an FPRAS for every finite simple unweighted general graph: relative error $\epsilon$, failure at most $\delta$, exact zero output, and worst-case bit time polynomial in input length, $\epsilon^{-1}$, and $\log(1/\delta)$. This is a primary-source theorem claim, not independently proof-checked in this workspace.

The local PC-05 construction extends that claimed interface to nonnegative rational edge weights without changing the approximation parameters by more than the input-size substitution. Clear rational denominators with $D=\prod_e\operatorname{den}(w_e)$ and replace each positive integer weight $W_e=Dw_e$ by a simple bipartite two-port gadget with matching signature $(1,W_e,0,0)$ and $O(\log(W_e+1))$ vertices, $O(\log^2(W_e+1))$ edges. Its proof uses a binary-coded acyclic digraph with exactly $W_e$ source-to-sink paths, split into left/right copies with diagonal edges: the unused-port state has one completion, the both-used state has one completion per path, and either one-port state has none. Every source perfect matching uses $r=m/2$ weighted edges, so the expanded unweighted count is exactly

\[
 \#\operatorname{PM}(G_{\rm expanded})=D^r\operatorname{PM}_w(G).
\]

If the rational input has bit length $L$ and the host has $E$ edges, then $\log(W_e+1)=O(L)$ and the expanded simple graph has $O(EL)$ vertices and $O(EL^2)$ edges. Dividing the FPRAS estimate by $D^r$ preserves relative error and confidence, with $\log D^r=O(rL)$ bits. The detailed PC-05 proof is `work/programmes/photonic_complexity/leaves/positive_kernel_counting.txt`; exact enumeration for $W=1,\ldots,20$ is only a finite sanity check. Thus, conditional on OA113 and the internally proved PC-05 gadget, a weighted-general-PM FPRAS is already available independently of a $Z_k$-FPRAS. The old statement that this weighted matching FPRAS is still open is stale under this source baseline.

Consequently, the implication $\mathrm{FPRAS}(Z_{N/2})\Rightarrow\mathrm{FPRAS}(\text{weighted general PM})$ is **not** a new open-problem consequence or an approximation-hardness result. Exact $\#P$-hardness does not repair this: exact hardness and relative-approximation hardness are different claims. No SETH, #ETH, or other fine-grained lower bound follows from the reduction above.

## Separate exact rational-square route

The exact weighted construction in ../border_rank_bits/RESULT.txt strengthens the encoding in a different direction but does not strengthen the approximation consequence. For each positive rational edge weight p/q, it writes the integer p*q as a sum of at most twice its bit length many integer squares, then uses the corresponding rational amplitudes as edge variants. After dummy padding, the paired determinant sum at zero perturbation equals the weighted matching partition function exactly. The number of variants and target dimension are linear in the source encoding length; the proof gives polynomial bounds for all rational bit sizes and an O(Nk) coefficient dynamic program for the perturbation mass. Choosing the perturbation from that mass and a known positive lower bound obtained from one support perfect matching gives a one-query approximation-preserving reduction with target error beta/4 and confidence 1-delta, yielding source relative error below beta. It also gives an exact scalar-query reduction: after clearing source denominators, the perturbed value is close enough for nearest-integer recovery. This exact-query statement is an exact counting consequence, not an approximation-hardness result.

## Reverse interface gap and explicit counterexample

The known reduction runs from matching counts into $Z$; its construction is not invertible. The scalar PM FPRAS therefore does not by itself give an algorithm for arbitrary $Z_k(A)$. To obtain one through this baseline, a separate polynomial-bit AP reduction from the arbitrary complex-rational $Z_k$ input to nonnegative weighted PM is needed, with relative-error transfer, exact-zero handling, and all graph/weight encoding costs charged. No such reverse reduction was found.

The direct determinant expansion explains the obstruction to the simplest proposed reverse map. Each squared minor contains cross terms with signs/phases:

\[
 |\det A[I,J]|^2=
 \sum_{\sigma,\tau\in S_k}\operatorname{sgn}(\sigma)\operatorname{sgn}(\tau)
 \prod_{i\in I}A_{i,\sigma(i)}\overline{A_{i,\tau(i)}}.
\]

They cannot generally be replaced by the positive sum of squared permutation monomials. For the $4\times 4$ skew matrix

\[
 A_{ij}=\begin{cases}1&i<j,\\-1&i>j,\\0&i=j,\end{cases}
\]

with $k=2$, the six complementary minors have determinants $0,2,0,0,2,0$, so $Z_2(A)=8$. If one drops determinant cross terms and sums the squared magnitudes of the permutation monomials instead, the three perfect matchings of $K_4$ each occur in four row/column orientations, giving $12$. The aggregate interference is $-4$. This falsifies the naive diagonal-term positive matching encoding; it does **not** rule out every possible AP reduction or positive representation. The exact arithmetic check and receipt are in `evidence/check_k4_interference.py` and `evidence/k4_interference.json`.

An exact positive Gram lift is known: for $V=[I_n,A^T]$, $G=V^*V$, and $P(S)$ selecting both columns for each site in $S$,

\[
 Z_k(A)=\sum_{|S|=k}\det G[P(S),P(S)].
\]

This is a weighted linear-matroid-parity / paired-principal-minor sum. It is not a representation as a graph's nonnegative edge-activity perfect-matching partition function, nor does it supply a sampler for the terms. Establishing such a representation with polynomial bit size, or another reverse AP reduction, is the exact missing interface. The positive Gram identity, by itself, does not supply the missing reduction.

## Status, falsifier, and restart

* **Conditional consequence:** An FPRAS for the fixed half-sector $Z_{N/2}$ yields a weighted rational general-PM FPRAS, assuming the internally proved one-query construction in `../determinant_beyond_degree/WEIGHTED_PM_TO_Z.md`.
* **Baseline match:** OA113's primary release claims the unweighted general-graph FPRAS; PC-05 plus denominator clearing conditionally supplies nonnegative rational weights in polynomial bit size. These source claims and local derivations have not received an independent end-to-end proof audit here.
* **Unknown:** Whether arbitrary $Z_k(A)$ has an FPRAS; whether it admits a reverse nonnegative-PM AP reduction; whether a stronger approximation-hard source reduces to this exact supplied-$k$, complex-rational interface.
* **Falsifier for the naive proposal:** The skew-$K_4$ calculation above. To close the general interface gap, provide a correct reverse AP reduction with polynomial graph/weight bit lengths, explicit $\epsilon,\delta$ transfer, and exact-zero logic, or provide an independently checked direct $Z_k$ algorithm. A no-go claim would require a separately stated complexity assumption; none is used here.
* **Restart:** Audit the reverse direction first. Preserve the distinction between the supplied scalar sector index and discovered minor locations. Do not use arbitrary CNF filters or signed-cancellation encodings as if they were nonnegative weighted matching reductions. If no reverse construction emerges, keep the conclusion at “approximation implication with no new lower bound” and seek a source with a genuinely stronger approximation classification.

## Sources and evidence status

1. OA113, “A Fully Polynomial Randomized Approximation Scheme for Perfect Matchings in General Graphs,” pinned primary release PDF, 23 September 2026: [source](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/main.pdf). Theorem claim checked against the source TeX at `work/astra_prior/web/assets/dcf28553d442dfc53a9f90f7c52bd48c9e2e7e5e27b197aa7ca4be1c8daed703.tex`, lines 110–137. Source-reported; not independently validated here.
2. PC-05 simple integer-weight gadget and rational denominator clearing: `work/programmes/photonic_complexity/leaves/positive_kernel_counting.txt`, section 2; claim ledger `outputs/research/photonic_complexity/CLAIMS.json`, PC-05. Internally proved candidate; (W=1,ldots,20) enumeration is finite diagnostic evidence only.
3. Weighted PM to fixed $Z$: the compact chart proof is in `../determinant_beyond_degree/WEIGHTED_PM_TO_Z.md`; exact finite replay files are `../determinant_beyond_degree/evidence/check_weighted_pm_reduction.py` and `../determinant_beyond_degree/evidence/check_weighted_pm_reduction.json`. The exact rational-square alternative is `../border_rank_bits/RESULT.txt`. Both are internally derived candidates with finite diagnostics, not independent proof validation.
