# Fixed Gutzwiller norm: determinant, stability, and positive-estimator routes

Date: 8 October 2026  
Status: internally derived route audit; exact algebraic witnesses and costs are stated below. No implementation, external proof review, or novelty claim is supplied. This note supplies no general arbitrary-rank FPRAS or sampler for `Z_k`. The prior claim that general-graph perfect-matching approximation remains open is stale relative to OA113 (September 2026), which source-reports an unweighted general-graph PM FPRAS. PC-05's exact binary gadget plus rational denominator clearing conditionally transfers that claim to nonnegative rational weighted PM with polynomial bit complexity. These theorem/reduction claims are source-reported or internal candidates and are not independently validated here. The unresolved direction is a reverse `Z_k -> weighted-PM` reduction or another direct `Z_k` algorithm; none is given here.

## Interface and verdict

The input is an explicit rational-complex matrix \(A\in\mathbb Q(i)^{n\times n}\), encoded in \(L\) bits, and an integer \(0\le k\le n/2\). The target is

\[
 Z_k(A)=\sum_{\substack{|I|=|J|=k\\I\cap J=\varnothing}} |\det A[I,J]|^2,
 \qquad
 W_k(A)=\sum_{|I|=|J|=k}|\det A[I,J]|^2=[t^k]\det(I+tAA^*).
\]

The desired classical law, when \(Z_k>0\), assigns mass \(|\det A[I,J]|^2/Z_k\) to each allowed pair. The exact unrestricted norm \(W_k\) is a polynomial-time determinant coefficient; the hard part is the fixed local no-double-occupancy filter. For a normalized canonical input, its physical pass probability is \(p_G=Z_k/W_k\).

The paired-column Gram determinant and its mixed-discriminant coefficients are positive and have a compact exact description. The obstacle is the required whole-site-pair extraction: it is not a stable/log-concave operation. A rational 4-cycle permutation gives a positive target for which the resulting site-pair polynomial is neither right-half-plane stable nor log-concave. The full-sector Pfaffian identity is also positive and unbiased, but its direct estimator has exponential relative variance on independent 4-cycle blocks.

There are real, scoped algorithms. An exact rational sampler for the *unfiltered* fixed-\(k\) minor-square law, followed by the no-double rejection step, gives an FPRAS and a conditional sampler under a supplied inverse-polynomial promise \(p_G\ge p_0\). Independently, bounded-width block diagonal matrices admit exact \(Z_k\), exact Born sampling, and exact physical success probability for any \(p_G\), including exponentially small cases. Neither result gives a polynomial-cost route for unrestricted \(A\).

## Paired-column Gram and mixed discriminants

Let \(e_i\) be the \(i\)-th standard basis column and \(f_i\) the transpose of row \(i\) of \(A\). Set

\[
 V=[I_n,A^T],\quad G=V^*V,\quad
 M_i=e_ie_i^*+f_if_i^*\succeq0.
\]

If \(P(S)\) denotes both columns \(e_i,f_i\) for every \(i\in S\), Cauchy–Binet followed by expansion along the identity columns gives

\[
 \det G[P(S),P(S)]
 =\sum_{\substack{J\subseteq[n]\|J|=|S|\\J\cap S=\varnothing}}|\det A[S,J]|^2,
 \qquad
 Z_k(A)=\sum_{|S|=k}\det G[P(S),P(S)]. \tag{1}
\]

Equivalently, define

\[
 p_A(x)=\det\!\left(I_n+\sum_{i=1}^n x_iM_i\right)
       =\det\bigl(I_n+V\operatorname{diag}(x_1,x_1,\ldots,x_n,x_n)V^*\bigr).
\]

Then \([\prod_{i\in S}x_i^2]p_A=\det G[P(S),P(S)]\), so \(Z_k\) is the sum of those coefficients over \(|S|=k\). Each coefficient is, up to the standard multinomial normalization, a mixed discriminant with two copies of \(M_i\) for each \(i\in S\) and \(n-2k\) copies of \(I_n\). Positivity follows from the Gram representation.

Because the \(M_i\) are positive semidefinite, \(p_A\) is real stable: for \(\operatorname{Im}x_i>0\), a kernel vector would have zero quadratic form against every \(M_i\), hence against \(I+\sum x_iM_i\) only if it were zero. But extracting only exponents 0 or 2 at each site is an even-part projection, not a stability-preserving operation. Precisely, since each variable has degree at most two,

\[
 C_A(z)=\sum_{S\subseteq[n]}\det G[P(S)]z^S
 =2^{-n}\sum_{\sigma\in\{\pm1\}^n}p_A(\sigma_1\sqrt{z_1},\ldots,\sigma_n\sqrt{z_n}),
\]

where the square-root notation is only a coefficient identity. This expression exposes an exponential sign average; the PSD determinant does not by itself compute the desired paired extraction.

### Exact failure of the stability/log-concavity transfer

Take the rational permutation matrix of a directed 4-cycle,

\[
 A=P_4=\begin{pmatrix}
 0&1&0&0\\0&0&1&0\\0&0&0&1\\1&0&0&0
 \end{pmatrix},\qquad k=2.
\]

For a 2-set \(I\), the only nonzero minor has \(J=P_4(I)\). Disjointness holds only for \(I=\{1,3\}\) or \(I=\{2,4\}\), each with squared minor one. Thus

\[
 Z_2(P_4)=2,\qquad C_{P_4,2}(z)=z_1z_3+z_2z_4.
\]

At \(z=(1,1,1,1)\), \(C=2\) and \(\nabla C=(1,1,1,1)\). In the coordinate order \((z_1,z_2,z_3,z_4)\), choose \(v=(1,-1,1,-1)\). Then \(\nabla C\cdot v=0\), \(v^T(\nabla^2C)v=4\), and

\[
 v^T\nabla^2\log C\,v=\frac{4}{2}-\frac{0^2}{2^2}=2>0.
\]

So this exact positive-target coefficient is not log-concave. It is not right-half-plane stable either: take \(z_1=z_3=e^{i\pi/4}\), \(z_2=z_4=e^{-i\pi/4}\). Every variable has positive real part, but \(z_1z_3+z_2z_4=i-i=0\). This rules out applying a stable/log-concave coefficient method directly to the paired site polynomial. It does not rule out another lift or another algorithm.

A second direct fixed-sector witness is the adjacency matrix of the path \(P_5\), with \(k=2\). Define the row-marginal polynomial

\[
 F_{A,2}(x)=\sum_{|S|=2}w(S)x^S,
 \qquad w(S)=\sum_{\substack{J\subseteq[5]\setminus S\\|J|=2}}\det(A[S,J])^2.
\]

Exact enumeration gives

\[
 F_{A,2}=x_1x_3+2x_1x_4+x_1x_5+x_2x_3+3x_2x_4+2x_2x_5+x_3x_4+x_3x_5.
\]

At \(x=\mathbf1\), its value and gradient are \(12\) and \((4,6,4,6,4)\). With \(v=(-5,3,0,-3,5)\), the gradient dot product is zero and \(v^T\nabla^2Fv=16\), hence \(v^T\nabla^2\log F(\mathbf1)v=16/12=4/3>0\). It also has an exact upper-half-plane zero at

\[
 (x_1,x_2,x_3,x_4,x_5)=
 \left(-3+\frac{i}{100},\;2+\frac{29397}{20500}i,\;2i,\;-2+\frac{i}{100},\;3+\frac{i}{100}\right),
\]

whose imaginary parts are \((1/100,717/500,2,1/100,1/100)\). This independently rules out log-concavity and real stability of the direct homogeneous fixed-sector row marginal. The exact rational replay is `../evaluation_to_pit/evidence/verify_p5_stability_witness.py`.

The direct row/column-token coefficient lift has a separate exact obstruction already at \(n=2,k=1,A=\begin{psmallmatrix}0&1\\1&0\end{psmallmatrix}\): its squared-minor factor is \(x_{r_1}x_{c_2}+x_{r_2}x_{c_1}\), with positive log-Hessian direction at the all-ones point. In the paired Gram lift, the Gram-volume factor is log-concave, but its complementary whole-pair selector \(e_{n-k}(x_{e_1}x_{f_1},\ldots,x_{e_n}x_{f_n})\) fails log-concavity in every nontrivial sector. These are counterexamples to two explicit factorizations, not to Chen–Liu's theorem or to all possible stable lifts.

For scale, Chen–Liu's homogeneous subset-convolution FPRAS requires both nonnegative generating polynomials to be log-concave, complementary homogeneous degrees, exact value oracles, a positive support seed, and coefficient-range bounds. Under those hypotheses its v1 Theorem 5.1 gives

\[
 O\!\left(N^{10}(N+\log(R_\mu R_\nu))^2\epsilon^{-2}
 \log^2\!\frac{2(N+\log(R_\mu R_\nu))}{\epsilon}\right)
\]

arithmetic operations and oracle calls on every execution; Appendix A.5, Remark A.4, states a rational finite-bit cap. For the natural determinant-squared and paired-Gram factorizations, the oracle/range/seed interfaces can be made polynomial-bit, but the witnesses above violate a required curvature premise. The theorem therefore supplies no FPRAS here.

Mixed-discriminant approximations do not close this interface. Known general PSD mixed-discriminant algorithms give simply-exponential multiplicative factors; a quasi-polynomial relative approximation is known under a near-identity operator-norm promise. Equation (1) asks for a sum over paired repeated-index mixed discriminants, not one unconstrained mixed discriminant. Neither a generic approximation factor nor the stability of \(p_A\) evaluates this paired sum. The known hardness of unrestricted mixed discriminants also does not, by itself, transfer to this special paired coefficient.

## Positive full-sector Pfaffian expectation and variance

For \(n=2k\), let \(D_\sigma=\operatorname{diag}(\sigma_1,\ldots,\sigma_n)\), with independent uniform signs. Pfaffian minor summation applied to \([I_n,A^T]\) yields, up to one fixed global ordering sign,

\[
 \operatorname{Pf}(D_\sigma A-A^TD_\sigma)
 =\sum_{|S|=k}\det V[:,P(S)]\prod_{i\in S}\sigma_i.
\]

The square-free sign characters are orthogonal, and \(|\det V[:,P(S)]|^2\) is the Gram term in (1) for the full sector. Therefore

\[
 Z_{n/2}(A)=\mathbb E_\sigma\left|\operatorname{Pf}(D_\sigma A-A^TD_\sigma)\right|^2. \tag{2}
\]

For rational-complex input each draw is a nonnegative rational, computable by an \(n\times n\) Pfaffian in polynomial bit time; the sign generator consumes \(n\) fair bits. This is a legal positive unbiased estimator, not a variance bound.

Let \(A\) be a block diagonal matrix of \(d\) directed 4-cycle permutation blocks, so \(n=4d,k=2d\). On each block the Pfaffian is a signed sum of two distinct quadratic sign characters; its squared modulus is 0 or 4 with probability 1/2 each. Blocks use disjoint signs. If \(Y=|\operatorname{Pf}(D_\sigma A-A^TD_\sigma)|^2\), then exactly

\[
 Z_{2d}=\mathbb EY=2^d,\quad \mathbb EY^2=8^d,\quad
 \frac{\operatorname{Var}Y}{(\mathbb EY)^2}=2^d-1.
\]

For \(T\) independent draws, seeing no nonzero sample has probability \((1-2^{-d})^T\). Hence any relative estimate with error below one and constant success probability requires \(T=\Omega(2^d)\) for this *direct estimator*. Each sample is polynomial-cost, but the proposal is exponentially inefficient. This family is an easy block-product instance, so the calculation proves no hardness or lower bound on all algorithms.

More generally, if a promised class supplies a polynomially bounded \(\Lambda\) such that every Pfaffian sample obeys \(Y\le\Lambda Z\), multiplicative Chernoff gives a relative estimate using \(O(\Lambda\epsilon^{-2}\log(1/\delta))\) samples. This is a valid conditional estimator when the bound is provided; no polynomial universal \(\Lambda\) follows from PSD Gram positivity or unit spectral condition number.

## A legal inverse-polynomial-acceptance route

There is a direct route from exact matrix evaluation to a useful promised class. It uses no stable-polynomial assumption.

First sample the unfiltered fixed-\(k\) law exactly. Put \(K=AA^*\). Cauchy–Binet gives

\[
 W_k=[t^k]\det(I+tK)=\sum_{|I|=k}\det K[I,I].
\]

Sample \(I\) with mass \(\det K[I,I]/W_k\), a fixed-cardinality determinantal law. Given a positive-mass \(I\), set \(L_I=A[I,:]^*A[I,:]\) and sample \(J\) with mass \(\det L_I[J,J]/\det K[I,I]\). A second Cauchy–Binet identity gives \(\det L_I[J,J]=|\det A[I,J]|^2\) and \(\sum_{|J|=k}\det L_I[J,J]=\det K[I,I]\). The resulting joint law is exactly

\[
 \Pr(I,J)=|\det A[I,J]|^2/W_k.
\]

These fixed-\(k\) determinantal samples can be generated with rational arithmetic and no eigenvalue decomposition. For a rational PSD matrix \(K\), maintain forced indices \(S\), remaining allowed indices \(R\), and \(r=k-|S|\). If \(\det K[S,S]>0\), form the Schur complement

\[
 Q=K[R,R]-K[R,S]K[S,S]^{-1}K[S,R].
\]

The total completion mass is \(\det K[S,S]\,[x^r]\det(I+xQ)\), by the block determinant formula and Cauchy–Binet. The include/exclude masses for the next index are obtained by the same formula on the remaining principal submatrices. Computing a characteristic-polynomial coefficient by exact rational arithmetic at each of at most \(n\) sites gives a conservative \(O(n^5)\) rational-operation bound per fixed-\(k\) sample, with polynomial bit lengths. Zero determinants and empty sectors are decided exactly. The same self-reduction samples \(J\) from \(L_I\). Clearing denominators, Hadamard bounds, and fraction-free elimination keep all input, Schur-complement, determinant, and completion-mass bit lengths polynomial in \(n,L\). A rational categorical draw via capped uniform-integer rejection has worst-case polynomial runtime and an explicit abort/TV budget; uncapped exact draws use polynomial expected fair bits.

Now let \(p_G=Z_k/W_k\). Repeating this unfiltered sampler and retaining only pairs with \(I\cap J=\varnothing\) gives the exact target law after acceptance. If the promise supplies a rational \(p_0\ge 1/\operatorname{poly}(n,L)\) with \(p_G\ge p_0>0\), then:

* estimating the Bernoulli pass probability to relative error \(\epsilon\) and returning \(W_k\widehat p_G\) is an FPRAS using \(O(p_0^{-1}\epsilon^{-2}\log(1/\delta))\) proposal samples;
* exact rejection sampling has expected \(1/p_G\le1/p_0\) proposals, and a cap of \(O(p_0^{-1}\log(1/\delta))\) proposals gives abort probability at most \(\delta\).

If proposal draws are bit-capped and hence have total-variation error \(\eta\), choose \(\eta\le \epsilon p_0/16\) per proposal; this bounds the pass-probability bias by \(\eta\) and the conditioned output-law error by \(O(\eta/p_0)\). Thus the probability cap is charged explicitly. The arithmetic per proposal is polynomial in \(n,L\), and \(W_k\) has polynomial bit length. This is an actual algorithm on a meaningful physical-overlap promise; it does not say how to establish that promise for arbitrary \(A\).

The promise is necessary for this rejection route. For \(n=2s,k=s\) and \(A\) equal to \(s\) unitary swap blocks,

\[
 W_s=\binom{2s}{s},\qquad Z_s=2^s,\qquad
 p_G=\frac{2^s}{\binom{2s}{s}}\sim\sqrt{\pi s}\,2^{-s}.
\]

All singular values are one, but expected rejection count is exponential. This is a falsifier of any claim that good spectral conditioning alone makes the physical or classical rejection route efficient. The block promise itself remains easy and admits a different direct sampler.

## Strongest positive comparison and scope boundary

The most direct exact positive comparator for this target is the bounded-block dynamic program already in the cycle-2 record. If a supplied site partition makes \(A=\bigoplus_{b=1}^s A_b\) with \(|B_b|\le w\), enumerate each block's unfiltered/no-double polynomials \(u_b(x),d_b(x)\) and convolve:

\[
 W_k=[x^k]\prod_bu_b(x),\qquad Z_k=[x^k]\prod_bd_b(x).
\]

Local enumeration costs \(O(4^w\operatorname{poly}(w,L))\); coefficient DP and exact sequential sampling give total \(O(s4^w\operatorname{poly}(w,L)+skw\operatorname{poly}(n,L))\) bit work and polynomial-size integer masses. For fixed or logarithmic \(w\), this is polynomial. It computes the normalization and target Born sampler without a \(1/p_G\) cost. Physical postselection still costs \(W_k/Z_k\) expected attempts; the swap-block example shows that this can be exponential even though the direct classical sampler is exact and efficient.

The cycle-2 bounded-rank fourfold-exterior DP is another exact FPT route, with normalizer cost \(O(nd^2 16^d)\) and sampler cost \(O(n^2d^2 16^d)\) for rank \(d\). Monomial/permutation and path/cycle support classes have additional exact transfers. N89 records a conditional Chen–Liu/N63 route after a bipartite particle-hole reduction; it is a narrower admitted class, not a general BCS theorem. N63 itself is a projected-Slater quota result with acquired coefficient, support, range, and prefix interfaces; it does not directly acquire the paired determinant-square/no-double coefficient for arbitrary \(A\). Its imported theorem/compiler status is source-derived and not independently validated here.

The exact-status ledger for this leaf is:

* **Proved in this note:** Gram/mixed-discriminant coefficient identity; 4-cycle and \(P_5\) stability/log-concavity witnesses; Pfaffian expectation/variance calculations assuming the standard Pfaffian minor-summation identity; exact unfiltered fixed-\(k\) self-reduction; inverse-polynomial-\(p_G\) FPRAS/sampler transfer.
* **Exact finite replay:** the \(P_5,k=2\) coefficients, Hessian witness, and upper-half-plane zero are asserted with rational arithmetic in `../evaluation_to_pit/evidence/verify_p5_stability_witness.py`; the captured output is `../evaluation_to_pit/evidence/P5_WITNESS_RECEIPT.json`.
* **Existing internally derived class results:** bounded-block and bounded-rank exact DPs; their evidence and detailed bit costs are in `work/programmes/fermionic_algorithms/cycle2/leaf-06/RESULT.txt` and `work/programmes/fermionic_algorithms/cycle2/leaf-12/RESULT.txt`.
* **Source-reported / conditional:** Chen–Liu's 2026-10-05 v1 FPRAS theorem/finite-bit appendix is not independently proof-checked here. OA113 (23 September 2026) source-reports an unweighted general-graph PM FPRAS; PC-05's exact binary gadget and denominator clearing give a conditional polynomial-bit transfer to nonnegative rational weighted PM. Neither the OA113 claim nor PC-05 is independently validated here. The 2017 paper below records an earlier open status, not the current status claimed by OA113.
* **Unknown:** arbitrary-rank polynomial-time relative approximation, general exact/approximate classical sampler, and a general polynomial bound on \(p_G\), proposal ratios, or Pfaffian variance.

The missing interface is a polynomial-cost positive evaluation/sampling mechanism for the paired site selector that supplies either (i) conditional counts with controlled precision at every prefix, (ii) an accepted/proposal ratio bounded below by inverse polynomial, or (iii) a bounded second-moment or pointwise envelope for a positive estimator. Support/zero detection alone, a PSD Gram formula, and polynomial coefficient bit heights do not supply any of these weighted-mass bounds. The repository's internal exact-hardness/AP-reduction lead transfers an FPRAS for this \(Z_k\) to nonnegative rational weighted perfect matching. OA113 source-reports an unweighted general-graph PM FPRAS, and PC-05 conditionally extends that claim to rational nonnegative edge weights by an exact binary gadget and denominator clearing; this is not independent validation. Since the reduction direction is PM \(\to Z_k\), it does not yield an algorithm for \(Z_k\). No reverse \(Z_k\to\) weighted-PM reduction or direct arbitrary-rank \(Z_k\) algorithm is supplied. This is the remaining route gap, not an open PM barrier.

## Primary sources and falsifiers

Primary-source URLs inspected or preserved for the claims above:

1. Xiaoyu Chen and Kuikui Liu, [*An FPRAS for Counting Common Bases of Two Matroids*, arXiv:2610.06724v1](https://arxiv.org/html/2610.06724v1), especially Theorem 5.1 and Appendix A.5, Remark A.4. Submitted 5 October 2026; source-reported and not independently audited here.
2. Kazuki Matoya and Taihei Oki, [*Pfaffian Pairs and Parities*, arXiv:1912.00620](https://arxiv.org/html/1912.00620), for the established Pfaffian-minor-summation/linear-matroid-parity framework.
3. Alexander Barvinok, [*Stability and Complexity of Mixed Discriminants*, arXiv:1806.05105](https://arxiv.org/abs/1806.05105), for the near-identity quasi-polynomial approximation regime and discussion of mixed-discriminant complexity; [*A Simple Polynomial Time Algorithm to Approximate the Permanent within a Simply Exponential Factor*, arXiv:math/9704218](https://arxiv.org/abs/math/9704218), for the older general PSD mixed-discriminant simply-exponential approximation.
4. Daniel Štefankovič, Eric Vigoda, and John Wilmes, [*On Counting Perfect Matchings in General Graphs*, arXiv:1712.07504](https://arxiv.org/abs/1712.07504), a 2017 source that states the general-graph perfect-matching FPRAS question remained open then and shows JSV's chain fails on some instances. Its historical status statement is superseded here by the later OA113 source claim below.
5. Mark Jerrum, Alistair Sinclair, and Eric Vigoda, [*A Polynomial-Time Approximation Algorithm for the Permanent of a Matrix with Nonnegative Entries*](https://doi.org/10.1137/S0097539700381388), the bipartite nonnegative-permanent FPRAS comparator.
6. OpenAI, [*A Fully Polynomial Randomized Approximation Scheme for Perfect Matchings in General Graphs*](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/build/main.tex), 23 September 2026, pinned source. OA113 claims an unweighted simple-graph PM FPRAS with exact-zero detection and worst-case polynomial binary runtime. This route audit treats it as source-reported, not independently validated. PC-05's rational weighted transfer is an internal candidate reduction, also not independently validated.

**Falsifiers.** The most compact checks are: (a) enumerate the six 2-subsets for \(P_4\) and find any additional positive disjoint minor or a coefficient other than one; (b) recompute the \(P_4\) Hessian/right-half-plane zero and the \(P_5\) coefficients, Hessian, or exact upper-half-plane zero (receipt: `../evaluation_to_pit/evidence/P5_WITNESS_RECEIPT.json`); (c) for one 4-cycle block, find a Pfaffian sample outside \(\{0,4\}\) or a probability other than \(1/2\); (d) find a flaw in the Schur-complement completion identity or in the two-stage factorization of the unfiltered pair law; or (e) exhibit a general polynomial bound on an actual proposal ratio/conditional mass that bypasses the displayed rare-event family. Counterexamples (a)–(d) falsify concrete calculations; (e) would be new progress beyond this scoped audit.

## Restart

Next, independently formalize the rational fixed-\(k\) determinantal self-reduction as a short lemma and implement a small exact enumeration comparison on rational matrices, then add the inverse-polynomial-acceptance algorithm to the cycle-2 claim ledger. In parallel, seek a structural promise broader than bounded blocks/rank that controls the hard no-double conditional mass without requiring \(p_G\ge1/\operatorname{poly}\); candidates are a bounded-width factor graph for the paired minors or a particle-hole reduction to the admitted bipartite Slater class. Do not infer a generic FPRAS from the pair-Gram stability of \(p_A\), the Pfaffian expectation, the support oracle, or the PM\(\to Z_k\) implication alone.
