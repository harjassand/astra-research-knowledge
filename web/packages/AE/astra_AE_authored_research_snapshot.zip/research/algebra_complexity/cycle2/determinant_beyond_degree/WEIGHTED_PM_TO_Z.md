# Weighted perfect matchings reduce to one fixed $Z_k$ sector

**Status (8 October 2026).** The one-query approximation-preserving reduction below is an internally proved candidate for nonnegative rational weighted perfect matching, with polynomial binary encoding cost. Its exact finite replay passes (receipt and script in [evidence](evidence/)). It is not an independently audited proof package. Combined with the pinned OA113 manuscript and the separate PC-05 integer-weight gadget, it transfers a source-reported general-graph perfect-matching FPRAS to this $Z_k$ sector in the stated model. It does not yield a no-FPRAS conclusion, a stronger approximation barrier, an algorithm for arbitrary $Z_k$, or a claim about physical postselection success.

## Claim and interface

For an even integer $N$, a rational matrix $A\in\mathbb Q^{N\times N}$, and $k=N/2$, define the unnormalized real-rational sector
\[
Z_k(A)=\sum_{\substack{I,J\subseteq[N],\ |I|=|J|=k\\ I\cap J=\varnothing}}
       \det(A[I,J])^2.
\]
Here the sector size $k$ is supplied per instance and grows with $N$; it is fixed within the query, not a constant independent of input size. Since $N=2k$, every disjoint pair has $J=I^c$, so
\[
Z_{N/2}(A)=\sum_{|I|=N/2}\det(A[I,I^c])^2.
\]

The source is a finite simple undirected graph $H=(V,E_0)$ on even $m_0$ vertices with nonnegative rational edge weights $w_e$. Its partition function is
\[
\operatorname{PM}_w(H)=\sum_{M\text{ perfect matching of }H}\prod_{e\in M}w_e.
\]
The reduction uses deterministic polynomial-time preprocessing and at most one randomized $Z_{N/2}$-FPRAS query. The target interface is initially **all rational real matrices**, with no sign or norm promise. An optional exact adapter below handles the extra promise $\|A\|_2\le1$.

**Reduction theorem.** If $Z_{N/2}(A)$ has an FPRAS for rational matrices of polynomial binary size, then nonnegative rational weighted general-graph perfect matching has an FPRAS with exact zero handling. Given requested source error $0<\rho<1$ and failure probability $0<\delta<1/2$, one target call at relative error $\rho/4$ and failure probability $\delta$, followed by exact rational rescaling, returns a $\rho$-relative estimate with failure at most $\delta$. The input length, target dimension, all rational bit lengths, and the target accuracy parameter are polynomially bounded by the source input length and $\rho^{-1}$; the confidence cost is $\log(1/\delta)$.

## Construction and proof

**1. Exact zero and padding.** Delete zero-weight edges when forming the support graph. The source value is positive exactly when this graph has a perfect matching, so Edmonds' maximum-matching algorithm decides the zero case in polynomial time. If it has none, return zero without querying the target. This branch is necessary: for a zero-source instance the perturbation below can give $Z_k(A)>0$, so the target oracle's exact-zero behavior cannot by itself identify source zero. By convention, the empty graph has value one; return one for $m_0=0$. For odd $m_0$, return zero.

Start from the positive-support graph. If its vertex and edge counts $m_0,E_0$ satisfy $E_0<m_0$, add two new vertices $u,v$, the edge $uv$ of weight one, and edges $ux$ of weight one for every old vertex $x$. The new leaf $v$ forces $uv$, so every perfect matching uses $uv$ and restricts to exactly one old perfect matching; the source partition function is unchanged. Positivity guarantees $E_0\ge m_0/2\ge1$, so the padded graph has $E_0+m_0+1\ge m_0+2$ edges. From here on, $H,m,E$ denote the positive-support graph after any padding; thus $E\ge m$ and $m$ is even and positive. If $E_0\ge m_0$, no padding was needed. Let $r=m/2$.

Let $M=\max_{e\in E}w_e>0$, $p_e=w_e/M\in(0,1]$, and $p_{\min}=\min_e p_e$. Every perfect matching of the padded instance has exactly $r$ edges, and padding preserved its total weight. Consequently
\[
P:=\frac{\operatorname{PM}_w(H)}{M^r}
   =\sum_{M'\text{ perfect matching}}\prod_{e\in M'}p_e,
\qquad P\ge p_{\min}^r>0.
\]

**2. Dyadic activity approximation.** Set
\[
\eta=\frac{\rho}{64r},\qquad
s=\left\lceil\log_2\frac{4}{\eta p_{\min}}\right\rceil,\qquad
a_e=2^{-s}\left\lfloor2^s\sqrt{p_e}\right\rfloor.
\]
The floor is computed exactly by integer square root after clearing the rational denominator. Since $2^{-s}\le\eta p_{\min}/4\le\eta\sqrt{p_e}/4$, each $a_e>0$ and
\[
1-\eta\le(a_e/\sqrt{p_e})^2\le1.
\]
Indeed the relative error in the square root is at most $\eta/4$, and $(1-\eta/4)^2\ge1-\eta$. For any $r$-edge matching, its product of squared activities therefore underestimates its normalized weight by relative error at most $r\eta$, and in particular at most $2r\eta=\rho/32$. Define
\[
P_0=\sum_{M'\text{ perfect matching}}\prod_{e\in M'}a_e^2,
\qquad 0\le P-P_0\le(\rho/32)P.
\]

**3. Paired-coordinate determinant sum.** There are $E$ positive graph edges and $D=E-m\ge0$ dummy pairs. Put
\[
N=E+D=2E-m,\qquad k=N/2=E-m/2=r+D.
\]
Use $N$ row coordinates: the $m$ old graph vertices and $2D$ new private dummy coordinates. For a graph edge $e=\{u,v\}$, choose either orientation $(u,v)$ once and define
\[
b_e=e_u,\qquad c_e=a_e e_v.
\]
For dummy pair $j\in[D]$, let $b_{E+j}$ and $c_{E+j}$ be the two different private basis vectors of that pair. Let $B,C\in\mathbb Q^{N\times N}$ be the matrices of these first and second columns, in the same fixed pair order. For $t>0$ and each $k$-element set $S\subseteq[N]$, take the $N\times N$ matrix whose columns, in pair order, are
\[
[\,b_j+t e_j,\ c_j\,]_{j\in S},
\]
where $e_j$ is the $j$-th standard basis vector in the $N$-coordinate space. Call its determinant $D_S(t)$, and let
\[
R(t)=\sum_{|S|=k}D_S(t)^2.
\]

At $t=0$, a nonzero determinant must select every dummy pair: its two private row coordinates occur nowhere else. It must also select exactly $k-D=r$ graph-edge pairs. Each selected graph pair contributes its two endpoints, with the second column weighted by $a_e$. The determinant is nonzero precisely when those $r$ edges are a perfect matching, in which case its square is $\prod_{e\in M'}a_e^2$. Therefore
\[
R(0)=P_0.
\]

For a fixed $S$, multilinearity in its $k$ first columns expands $D_S(t)$ into terms indexed by which first columns use $t e_j$. Each individual term is zero or a signed product of some $a_e$'s: every column in that term is a scalar multiple of a coordinate vector. Thus each term has absolute value at most one. There are $\binom{k}{j}$ terms of degree $j$, so if $kt\le1/2$,
\[
|D_S(t)-D_S(0)|\le(1+t)^k-1\le2kt.
\]
Also $|D_S(0)|\le1$ and $|D_S(t)|\le2$, hence
\[
|D_S(t)^2-D_S(0)^2|\le8kt.
\]
There are at most $2^N$ choices of $S$. Choose a dyadic perturbation
\[
q=\left\lceil\log_2\frac{256k2^N}{\rho p_{\min}^r}\right\rceil,\qquad
t=2^{-q}.
\]
It satisfies $kt\le1/2$ and
\[
|R(t)-R(0)|\le8k2^Nt\le\frac{\rho p_{\min}^r}{32}
                         \le\frac{\rho P}{32}.
\]
Combining the weight approximation and perturbation bounds gives
\[
|R(t)-P|\le\frac{\rho}{16}P.
\]

**4. Convert the paired sum to the target chart.** Put $T=B+tI_N$. Each column of $B$ is a standard basis vector, so $B$ is the matrix of a function $f:[N]\to[N]$, with $Be_j=e_{f(j)}$. The directed functional graph of $f$ consists of cycles with in-trees; the eigenvalues of $B$ are zeroes and roots of unity. Since $0<t\le1/2$, every eigenvalue of $T$ is nonzero, so $T$ is invertible over the rationals. Define
\[
A^T=T^{-1}C,\qquad A=C^TT^{-T}.
\]
For each $S$, factor $T$ on the left of the paired-column matrix. The remaining columns are $e_j$ and $T^{-1}c_j=A^Te_j$, for $j\in S$. Laplace expansion along the identity columns gives, up to sign,
\[
D_S(t)=\det(T)\det(A[S,S^c]).
\]
The sign vanishes after squaring. Since $N=2k$, all disjoint size-$k$ pairs in the target are exactly $(S,S^c)$ as $S$ ranges over the $k$-subsets. Therefore
\[
R(t)=\det(T)^2 Z_k(A).
\]

Call the target FPRAS once on $A$ with relative error $\rho/4$ and confidence $1-\delta$, and multiply its output by the exact rational factor $M^r\det(T)^2$. On the target success event, the resulting value is within relative error at most
\[
\rho/16+\rho/4+\rho^2/64\le21\rho/64<\rho
\]
of $\operatorname{PM}_w(H)$. The deterministic zero branch handles zero source values, and the positive branch has $Z_k(A)>0$ because $R(t)$ differs from $P>0$ by less than $P$. This proves the claimed one-query AP reduction.

## Exact bit size, conditioning, and optional contraction

Let $L$ be the total binary input length for graph weights and graph encoding. Then $\log_2(1/p_{\min})=O(L)$. The dyadic precisions satisfy
\[
s=O(L+\log r+\log(1/\rho)),\qquad
q=O(N+rL+\log k+\log(1/\rho)).
\]
Because $E\le\binom m2$ and $N=2E-m$, $N$ is polynomial in the source input. The activity denominators are $2^s$, and $T=2^{-q}(2^qB+I)$. Every entry of the integer matrix $H=2^qB+I$ has magnitude at most $2^q+1$. Hadamard's inequality bounds the bit length of each determinant or cofactor of $H$ by $O(N(q+\log N))$. Since $T^{-1}=2^qH^{-1}$, its entries and then $A^T=T^{-1}C$ have polynomial bit length; using the common determinant denominator for $H^{-1}$ and the dyadic denominator $2^s$ for $C$ gives a direct polynomial-size representation. The rational powers $M^r$ and $\det(T)^2$ have polynomial bit lengths as well (at most the base bit length times $O(r)$ or $O(N)$). Thus preprocessing and rescaling use polynomial-time exact rational arithmetic; they do not require floating-point inversion.

The construction also has an explicit conditioning bound. The Frobenius norm of $B$ is $\sqrt N$, so $\|T\|_2\le\sqrt N+t\le2\sqrt N$. Each eigenvalue of $T$ has magnitude at least $t$, giving $|\det T|\ge t^N$. Since the product of the singular values is $|\det T|$,
\[
\sigma_{\min}(T)\ge\frac{t^N}{(2\sqrt N)^{N-1}},\qquad
\kappa_2(T)\le(2\sqrt N)^N t^{-N},
\]
and $\log\kappa_2(T)=O(N(q+\log N))$. This may be exponentially large as a numerical condition number, but its logarithm and the exact rational chart size are polynomial in the input bit length. The reduction performs exact rational arithmetic, so it does not assume a numerically stable floating-point inverse.

If the target's legal matrix domain additionally requires $\|A\|_2\le1$, make the final rational shrink
\[
\lambda=\frac{1}{2(1+\sum_{i,j}|A_{ij}|)},\qquad A'=\lambda A.
\]
Then $\|A'\|_2\le\|A'\|_F\le\lambda\sum_{i,j}|A_{ij}|<1/2$, and
\[
Z_k(A')=\lambda^{2k}Z_k(A).
\]
The rational sum, $\lambda$, and $\lambda^{2k}$ have polynomial bit length; query the target on $A'$ and multiply its estimate by $\lambda^{-2k}$ as part of the exact final rescaling. This adapter only addresses the unnormalized $Z_k$ target. It establishes no lower bound on a physical filter's postselection probability such as $Z_k/W_k$, nor on expected physical retries; shrinking can lower physical success.

## Source baseline and what this does not establish

* **OA113 source status.** The pinned OpenAI/math manuscript dated 23 September 2026, Theorem 1, claims a uniform FPRAS for perfect matchings in every finite simple unweighted general graph: relative error $\epsilon$, failure at most $\delta$, exact zero output, and worst-case bit time polynomial in input length, $\epsilon^{-1}$, and $\log(1/\delta)$. This is a primary-source theorem claim and remains **source-reported here**, not independently proof-audited, formally checked, or implementation-validated. [Pinned primary TeX](https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/build/main.tex) · [pinned PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/main.pdf).
* **PC-05 weighted transfer.** The local positive-kernel note [positive_kernel_counting.txt](../../../../../work/programmes/photonic_complexity/leaves/positive_kernel_counting.txt), §2, gives a separate explicit simple-graph gadget of $O(\log W)$ vertices and $O(\log^2W)$ edges with signature $(1,W,0,0)$ for integer edge weight $W$. For rational weights, clear denominators with $D=\prod_e\operatorname{den}(w_e)$ and set $W_e=Dw_e\in\mathbb Z_{\ge0}$. Every perfect matching uses $r_0=m_0/2$ source edges, so its weighted count is multiplied uniformly by $D^{r_0}$. Replace each positive integer weight $W_e$ by the PC-05 simple-graph gadget; the expanded graph has polynomial size because $\log W_e$ is polynomial in the full binary input length. Divide the unweighted-count estimate by $D^{r_0}$; relative error and confidence are unchanged, and zero edges are omitted. Thus the rational weighted-PM FPRAS transfer is conditional on both OA113 and PC-05. PC-05's proof is an internal derivation; its $W=1,\ldots,20$ enumeration is finite evidence only. PC-05's validation status and OA113's source status are distinct.
* **Consequence for this reduction.** Under those two conditional inputs, weighted rational PM already has a claimed FPRAS. Thus PM$\to Z_k$ is an encoding/comparison result and does not show that $Z_k$ is harder to approximate than PM. It supplies no reverse $Z_k\to$PM reduction, no algorithm for arbitrary rational $Z_k$, and no hardness claim for nonnegative $Z_k$. The older general-graph PM status in [Štefankovič–Vigoda–Wilmes (2017)](https://arxiv.org/abs/1712.07504) is historical and predates OA113. Yi's dense-support weighted-hafnian approximation is a restricted class, not a substitute for the OA113 source claim: [arXiv:2609.04079](https://arxiv.org/abs/2609.04079).

## Falsifier and restart

A single exact rational input falsifying $R(0)=\sum_M\prod a_e^2$, the chart identity $R(t)=\det(T)^2Z_k(A)$, or the stated rational rescaling falsifies the reduction. The finite replay is designed to catch such errors on small instances, including a $K_4$ case with $M=2$ that distinguishes $r=m/2$ from target sector size $k=N/2$. A superpolynomial bit-length counterexample to the determinant/cofactor bounds or a target-domain rule excluding both $A$ and the contraction adapter would invalidate the claimed cost/interface scope. The zero-source-star replay also exhibits $R(t)>0$ when the source is zero, so removing the exact support test would invalidate exact zero handling.

To restart: (1) independently review the source TeX and the elementary determinant proof; (2) extend exact Fraction checks to more padded and non-padded graphs and include explicit zero-support preprocessing tests; (3) audit the OA113 theorem and PC-05 gadget separately before describing the transferred weighted-PM FPRAS as more than conditional; (4) attack the unresolved reverse reduction or a direct $Z_k$ approximation method. Do not infer a no-FPRAS result from this reduction.

## Replay record

Run:

~~~sh
python3 outputs/research/algebra_complexity/cycle2/determinant_beyond_degree/evidence/check_weighted_pm_reduction.py
~~~

The exact Fraction replay passes 328 chart equalities across three cases: weighted $C_4$, weighted $K_4$ with two dummy pairs and $M=2$, and a zero-source star padded to six graph vertices. It checks the dyadic activity error and perturbation inequalities on those cases. The star case deliberately has a positive perturbed target sum despite zero source weight; it checks the need for the exact zero branch. These are finite identity/bound diagnostics, not proof validation. See [the JSON receipt](evidence/check_weighted_pm_reduction.json) and [the replay script](evidence/check_weighted_pm_reduction.py).
