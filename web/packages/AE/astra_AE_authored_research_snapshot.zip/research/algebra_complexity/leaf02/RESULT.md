# Leaf 02 — Tensor restriction, degeneration, and the selective product

**Status: reconstructed; inherited claims remain source-derived and unreviewed.** The fixed-mask estimate is conditional on the cited matrix-multiplication exponent inputs. Counterexamples here are exact deductions over Q. No lower bound against arbitrary selective-product circuits is proved.

## Main finding

An exponent for tensor powers does not supply a one-shot circuit for arbitrary selected outputs. There are two independent gaps:

- Asymptotic rank takes a limit in tensor-power length with one tensor fixed. It need not equal one-shot rank. Degeneration controls border rank, which can also be strictly below exact rank.
- Exact rank counts bilinear products but does not imply support locality. A rational, rank-preserving change of basis makes every coefficient in Strassen’s rank-seven identity nonzero; tensor powers then activate every product leaf from singleton support.

These refute generic rank-to-leaf-pruning transfers. They do not rule out a new mask-dependent circuit with shared encoders.

## Interface and charges

Input dense \(X\in\mathbb Z^{N\times D}\), \(Y\in\mathbb Z^{D\times N}\), and a supplied arbitrary \(W\subseteq[N]^2\). Return exactly \((XY)_{ij}\) on W, with \(D=N^{1/4}\), \(|W|\le N^{15/8}\), and deterministic time \(O(N^{2-\eta})\) for fixed \(0<\eta<1/8\). An N-only bit bound needs entries of \(b=O(\log N)\) bits. Charge input/mask reading, mask-dependent preprocessing and circuit acquisition, encodings, arithmetic, coefficient heights, decoding, and answer writes.

A valid transposition route acquires from W a division-free, value-independent circuit for \(Z_WY^\mathsf T\), where \(Z_W\) has independent formal variables \(z_{ij}\) on W. Contract the output with X:

\[
f=\sum_{i,k}X_{ik}(Z_WY^\mathsf T)_{ik}
=\sum_{(i,j)\in W}z_{ij}\sum_{k=1}^D X_{ik}Y_{kj}.
\]

Then \(\partial f/\partial z_{ij}=(XY)_{ij}\). Reverse evaluation costs \(O(T+ND+|W|)\) field operations and retains all structural gates, even at \(Z=0\); acquisition is additional. At maximum |W|, independent dot products cost \(\Theta(N^{17/8})\). L04 gives \(\Omega(N^2)\) only for independently charged complete-block covers on some legal masks; shared arithmetic and general circuits are explicitly outside that theorem.

## Fixed-mask asymptotic rank does not transfer

For fixed W let

\[
T_{W,D}=\sum_{(i,j)\in W}\sum_{k=1}^D z_{ij}x_{ik}y_{kj}.
\]

The supplied N12 derivation maximizes \(\min\{15/8,s\}+t/4\) subject to \(s+(93/200)t\le2\), \(0\le t\le1\). Its optimum is \(s=15/8,t=25/93\), yielding, conditional on the cited dual exponent and character inequalities,

\[
\widetilde R(T_{W,D})\le N^{15/8+25/372}
=N^{1445/744}=N^{2-43/744}.
\]

The definition says that for each fixed N,W,

\[
\forall\epsilon>0\ \exists k_0(N,W,\epsilon)\ \forall k\ge k_0:
R(T_{W,D}^{\otimes k})\le N^{(1445/744+\epsilon)k}.
\]

The output mask of this tensor power is \(W^{\times k}\), a Cartesian power. The requested algorithm must handle each varying supplied W at the base instance. The estimate supplies no uniform \(k_0\), no finite decomposition for each W, no coefficient-height bound, and no mapping from arbitrary masks to these Cartesian masks. This is a quantifier mismatch, not an algorithm.

There is an explicit strict gap for matrix multiplication. Let \(M_2=\langle2,2,2\rangle\). Strassen gives \(R(M_2)\le7\), Winograd proves \(R(M_2)=7\) in characteristic zero, and \(M_2^{\otimes k}\cong M_{2^k}\). Conditional on the release claim \(\omega\le9/4\),

\[
\widetilde R(M_2)=2^\omega\le2^{9/4}<7=R(M_2).
\]

Thus an exponent bound on tensor powers is not a one-shot rank bound. The 9/4 result is used only as a supplied, internally reconstructed premise.

## Degeneration counterexample

Over Q define

\[
W_3=e_0\otimes e_0\otimes e_1+
e_0\otimes e_1\otimes e_0+
e_1\otimes e_0\otimes e_0.
\]

For nonzero \(\epsilon\),

\[
S_\epsilon=
\frac{(e_0+\epsilon e_1)^{\otimes3}-e_0^{\otimes3}}{\epsilon}
=W_3+\epsilon(e_1e_1e_0+e_1e_0e_1+e_0e_1e_1)
+\epsilon^2e_1^{\otimes3}
\]

has rank at most two and tends to \(W_3\). Thus border rank is at most two; the displayed expression gives exact rank at most three. The third-leg slices are

\[
A_0=\begin{pmatrix}0&1\\1&0\end{pmatrix},\quad
A_1=\begin{pmatrix}1&0\\0&0\end{pmatrix},\quad
\det(sA_0+tA_1)=-s^2.
\]

All mode flattenings have rank two. If exact rank were two, both terms would be independent in every leg. After invertible basis changes the slices would be diagonal with independent third-leg coefficients, so the determinant pencil would have two distinct linear factors. Its repeated-root property is invariant under these changes, contradiction. Therefore \(R(W_3)=3>\underline R(W_3)\). Degeneration provides a limit, not an exact rank-two circuit; interpolation and coefficient/bit costs are separate.

## Rank-preserving failure of support-density pruning

Start with Strassen’s identity \(XY=\sum_{\ell=1}^7a_\ell(X)b_\ell(Y)C_\ell\). Take

\[
P=\begin{pmatrix}7&5\\1&2\end{pmatrix},\quad
Q=\begin{pmatrix}6&6\\5&1\end{pmatrix},\quad
R=\begin{pmatrix}5&5\\4&1\end{pmatrix},
\]

with determinants \(9,-24,-15\). Substituting \(X'=PXQ^{-1}\), \(Y'=QYR^{-1}\) preserves multiplication up to invertible output change and gives exact rank-seven terms

\[
a_\ell(PXQ^{-1})b_\ell(QYR^{-1})P^{-1}C_\ell R.
\]

Exact rational arithmetic verifies the 16 input-basis-pair products (equivalently all 64 scalar tensor coefficients) and that all \(7(4+4+4)=84\) coefficients in the input forms/output matrices are nonzero. The independent check is [check_dense_gauge.py](check_dense_gauge.py).

Under tensor powers, every coefficient remains nonzero. One supported coordinate among \(4^k\) therefore activates all \(7^k\) product leaves. This refutes the generic rule that live leaves of a given rank identity scale with support density. It does not prevent a different decomposition or a shared refactorization.

For the full \(N\times D\) by \(D\times N\) tensor, flattening across the \(N^2\)-dimensional output leg has rank \(N^2\), so every exact decomposition has at least \(N^2\) products. Over an infinite field, a rank-preserving left/right basis change can make every coefficient in each nonzero input form and output matrix nonzero. Hence every nonempty W keeps all leaves of that representation live. This blocks syntactic pruning only; shared linear encoders and general selective circuits remain open.

The general density claim follows by a finite-avoidance argument. For a nonzero first-leg form \(a\), each target coordinate coefficient after the change of basis is \(a(P E_{ij}Q^{-1})\), a polynomial in invertible \(P,Q\). It is not identically zero: the orbit of a rank-one matrix spans the full matrix space, on which \(a\) is nonzero. The second leg is identical. For any nonzero output matrix \(C\), each target entry of \(P^{-1}CR\) is also a nonzero polynomial, since some pairing \(u^\mathsf T C v\ne0\) and \(u,v\) can be completed to invertible basis changes. The product of these finitely many polynomials and the determinants is nonzero; over an infinite field it has a nonvanishing rational point. The explicit Strassen witness above additionally checks one small instance with small rational data.

## Direct incidence lemma

For any field write \(T_{W,D}=\sum_{\ell=1}^r a_\ell(Z)c_\ell(X)b_\ell(B)\). For fixed \((i,j)\in W\), the coefficient slice at \(z_{ij}\) is \(\sum_{k=1}^D x_{ik}b_{jk}\), whose coefficient matrix has rank D. Each surviving rank-one term contributes a rank-one matrix, so at least D terms contain \(z_{ij}\). Consequently

\[
I_Z:=\sum_{(i,j)\in W}\deg_Z(i,j)\ge |W|D.
\]

The same argument gives \(I_X,I_B\ge|W|D\). At maximum |W| this is \(N^{17/8}\). An evaluator that independently builds each sparse-leg form with binary additions and then performs rank-term products costs at least \((I_Z-r)+r=I_Z\), so it misses the target. This is exact in every characteristic, but shared partial sums can compress incidences; it is not a general circuit lower bound or rank lower bound.

Alman–Li’s Kronecker-power algorithm needs a separately bounded depth-two linear-circuit degree \(\delta(M)\). Tensor rank, \(\omega\), or the dual exponent do not provide \(\delta\) by renaming it.

## Evidence, falsifier, restart

| Evidence | Status and scope |
|---|---|
| \(\omega\le9/4\), all-field transfer | Supplied source claim with internal reconstruction; arithmetic exponent only. No selective-output circuit or bit algorithm. |
| \(1445/744\) | Conditional, fixed-mask asymptotic-rank estimate. Mask stays fixed through the tensor-power limit. |
| \(Z_WY^\mathsf T\) | Required mask-dependent circuit to acquire; shared encoders, preprocessing, bit heights, and decoding must be charged. Not obtained. |
| Dense-gauged Strassen | Exact matrices, independently recomputed. Refutes proportional pruning of this rank identity only. |
| Complete-block cover | \(\Omega(N^2)\) in a restricted model on some masks; not a general lower bound. |

The incidence lemma would be falsified by an exact decomposition where a rank-D coefficient slice at some \(z_{ij}\) uses fewer than D rank-one terms. The Strassen witness would fail if the exact check found a zero coefficient or basis-pair mismatch.

Restart by seeking a mask-specialized **shared** factorization of the Z-leg or transposed circuit. A successful construction must cover every supplied legal W and prove

\[
P_{\rm acquire}+E_Z+E_B+R_{\rm products}+E_{\rm decode}
=O(N^{2-\eta}\operatorname{polylog}N),
\]

with exact integer bit-height/decoding bounds for \(b=O(\log N)\). Charge every encoder gate, product, decoder operation, coefficient, and mask bit.

## Source record

Starting cards: L03 SHA-256 c11418c4dd35e5e59942d038ee308538e7406a939ee7ac366f5214d45e8e5888; L04 8efd29634f6516a46ae9ccf15822360bcf24fd7ef6e6afd070ad3a74ddf48d41; N12 66a3374c0216b0f7c40e7cef47c420ba881407f125362edae1c1484d47b749b3. Astra export HEAD 420ee79e9ed7fe1441d12f131f5b8e790e12a692.

- L04 source ID d-d2ebdc4e16ec4b31, SELECTIVE_OUTPUT_AUDIT.md: interface/costs lines 10–18; reverse-mode gate lines 20–35; block-cover scope lines 95–117; next object lines 125–127. Exported SHA-256 64b20f592543b13f868101c15a58e6ae4a816cd2f06046a0c318022a7659c3f2.
- N12 source ID d-1e7a99ec32d38c30, selective_tensor.md: fixed-mask estimate/quantifiers lines 56–87. Exported SHA-256 6cde0aa369e52e7bc40b02a282557492310872fb9048cb579e49b95b38bf9616.
- Direct sparse-transposition note: incidence theorem lines 28–82; general-circuit caveats lines 76–90. Exported SHA-256 eeb5648521affd134f7d23c98e6c3e5ed9a30840dc8fc6a2f314665f1885504f.
- Dense-gauge audit: general lemma lines 98–147; rational witness lines 149–169. Exported SHA-256 e8dc9524de30bc14a44fccbef55945389f507fd197e9b1ea5391986fba36befa.

Primary references: Christandl–Vrana–Zuiddam, [Universal points in the asymptotic spectrum of tensors](https://arxiv.org/abs/1709.07851), §1.1; S. Winograd, [On multiplication of 2 × 2 matrices](https://doi.org/10.1016/0024-3795(71)90009-7), LAA 4(4), 381–388 (1971); Alman–Li, [Kronecker Powers, Orthogonal Vectors, and the Asymptotic Spectrum](https://arxiv.org/abs/2509.14489), Theorem 7.1; OpenAI, [An Upper Bound of 9/4 for the Matrix Multiplication Exponent](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf), release107 pinned at commit adc7f1241b42e322a6451854ab7e4b4c146bf78a. The latter is used only as a supplied premise; the repository warns that manuscripts are at different verification stages and some unformalized results could contain issues.
