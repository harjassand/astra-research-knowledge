# Cycle 4 — Exact subquadratic multiplication for selected-column masks

**Status: proved structured-family algorithm; arbitrary-mask target remains open.** For every supplied Cartesian mask \(W=I\times J\) with sufficiently large sides, a blockwise Strassen construction computes exactly its requested entries. In the target aspect ratio, the family \(W=[N]\times J\), \(|J|=\lfloor N^{3/4}\rfloor\), has \(|W|=\Theta(N^{7/4})\le N^{15/8}\) and admits a deterministic \(O(N^{2-\varepsilon})\)-operation algorithm for an explicit \(\varepsilon>0\). The construction is a structured-mask result, not an arbitrary-mask result and not a new matrix-multiplication exponent.

## Interface and theorem

The output-only interface supplies dense integer matrices
\[
X\in\mathbb Z^{N\times D},\qquad Y\in\mathbb Z^{D\times N},
\]
and a succinct product-mask descriptor consisting of row indices \(I\subseteq[N]\) and column indices \(J\subseteq[N]\). It must return exactly
\[
\{(XY)_{ij}:(i,j)\in I\times J\}.
\]
Assume \(D=\Theta(N^{1/4})\), and let \(r=|I|\), \(s=|J|\), with \(r,s\ge D\).

For the main family, \(I=[N]\) is implicit and the descriptor is just \(J\), an arbitrary sorted list of \(\lfloor N^{3/4}\rfloor\) columns. Thus the mask family is large, but each instance has a short, explicit description.

Put \(\alpha=\log_2 7<3\). There is a deterministic exact algorithm using
\[
O\!\left(\left\lceil\frac rD\right\rceil
          \left\lceil\frac sD\right\rceil
          D^\alpha\right)
=O(rsD^{\alpha-2})
\]
arithmetic operations, with the second expression applying when \(r,s\ge D\). Every output recombination is included. More generally, for any fixed \(\delta>0\), product masks with
\[
rs\le N^{\,2-(\alpha-2)/4-\delta}
\]
have \(O(N^{2-\delta})\) arithmetic cost. In particular, for
\[
I=[N],\qquad s=\lfloor N^{3/4}\rfloor,\qquad W=[N]\times J,
\]
the mask has size \(\Theta(N^{7/4})\), and the cost is
\[
O\!\left(N^{5/4+\alpha/4}\right)
=O\!\left(N^{2-\varepsilon}\right),\qquad
\varepsilon=\frac{3-\log_2 7}{4}>0.
\]
Computing each selected length-\(D\) dot product independently costs \(\Theta(|W|D)=\Theta(N^2)\); computing the entire product must write \(N^2\) outputs. The structured algorithm beats both interfaces by a polynomial factor.

## Construction and proof

Choose \(d\) to be the least power of two with \(d\ge D\), so \(D\le d<2D\). Split the selected row list \(I\) and selected column list \(J\) into blocks of at most \(d\) indices. For each row block \(I_a\) and column block \(J_b\):

1. Gather the corresponding rows of \(X\) into a \(d\times d\) matrix \(A\). Pad missing rows and the \(D\) inner coordinates with zero.
2. Gather the corresponding columns of \(Y\) into a \(d\times d\) matrix \(B\). Pad missing columns and inner rows with zero.
3. Compute \(AB\) with recursive Strassen multiplication and write only the real row/column positions in \(I_a\times J_b\).

The tiles partition \(I\times J\), so each requested entry is written exactly once and no unrequested product entry is computed.

For completeness, partition a \(2q\times2q\) multiplication into four \(q\times q\) blocks \(A_{ij},B_{ij}\). Compute
\[
\begin{array}{ll}
M_1=(A_{11}+A_{22})(B_{11}+B_{22}),&
M_2=(A_{21}+A_{22})B_{11},\\
M_3=A_{11}(B_{12}-B_{22}),&
M_4=A_{22}(B_{21}-B_{11}),\\
M_5=(A_{11}+A_{12})B_{22},&
M_6=(A_{21}-A_{11})(B_{11}+B_{12}),\\
M_7=(A_{12}-A_{22})(B_{21}+B_{22}),
\end{array}
\]
then form
\[
C_{11}=M_1+M_4-M_5+M_7,\quad
C_{12}=M_3+M_5,\quad
C_{21}=M_2+M_4,\quad
C_{22}=M_1-M_2+M_3+M_6.
\]
Distributivity verifies \(C=AB\) over the integers. The recurrence for all scalar multiplications, additions, subtractions, and output combinations is
\[
T(d)\le 7T(d/2)+O(d^2),
\]
hence \(T(d)=O(d^\alpha)\). This recurrence charges the 18 block additions/subtractions at each level; the reconstruction of all four output blocks is part of that charge.

There are
\[
O\!\left(\frac rD\cdot\frac sD\right)
\]
tiles because \(d=\Theta(D)\). Multiplying by \(O(D^\alpha)\) per tile gives \(O(rsD^{\alpha-2})\). For \(r=N\), \(s=\Theta(N^{3/4})\), \(D=\Theta(N^{1/4})\), this is \(O(N^{7/4}N^{(\alpha-2)/4})=O(N^{(5+\alpha)/4})\). Since \(\alpha<3\), the exponent is strictly below two.

## Full cost ledger

- **Arithmetic:** All seven recursive products and every input/output addition or subtraction are counted by \(O(D^\alpha)\) per tile. There is no extra decoder across tiles.
- **Inputs and repeated access:** Reading both full dense matrices costs \(O(ND)\) word reads. Even if the implementation gathers both tile inputs afresh for every tile, this is at most \(O((rs/D^2)D^2)=O(rs)\) word reads, which is below the arithmetic bound by the factor \(D^{\alpha-2}\).
- **Mask and preprocessing:** The structured descriptor \(I,J\) costs \(O((r+s)\log N)\) bits. Sorting/deduplicating index lists costs \(O((r+s)\log N)\) word operations. The block schedule is generated in \(O(r+s)\) time; no mask-specific circuit is searched for or compiled. If the caller instead supplies the full pair list \(W\), sorting it and checking that it equals \(I\times J\) costs \(O(rs\log(rs))\) word comparisons and \(O(rs\log N)\) input bits. For the stated family these remain subquadratic.
- **Output:** There are exactly \(rs\) answers. If inputs have \(b\) bits, each answer has \(O(b+\log D)\) bits. Writing them costs \(O(rs(b+\log D))\) bits. At the stated size and \(b=O(\log N)\), this is \(O(N^{7/4}\log N)\).
- **Bit complexity and precision:** The algorithm uses only integer additions, subtractions, and multiplications. At each recursion level a linear form's coefficient growth is at most a constant factor, so the bit length of intermediate values is \(O(b+\log D)\). With \(b=O(\log N)\), schoolbook arithmetic gives total bit time \(O(N^{(5+\alpha)/4}\log^2N)\), which is still \(O(N^{2-\varepsilon'})\) for any fixed \(\varepsilon'<\varepsilon\). There are no approximate coefficients, number-field conversions, or numerical precision choices. For larger input bit lengths, retain the dependence on \(b\); an \(N\)-only subquadratic bit bound is not claimed.

## Scope, falsifier, and restart

This works because \(W\) is one Cartesian product: every \(d\times d\) tile in the selected row/column grid is fully requested. For an arbitrary sparse mask, most tile products would compute unrequested outputs, and this proof gives no bound on the number of occupied tiles. Thus it does not improve the arbitrary-mask \(D=N^{1/4}, |W|\le N^{15/8}\) problem.

A direct falsifier of the theorem is an exact tile where the seven-product formulas fail, or a cost audit showing that a hidden cross-tile sum or output recombination was omitted. The formulas give an algebraic proof over \(\mathbb Z\), and the finite exact check below covers two target-aspect instances. For a claimed arbitrary-mask extension, the decisive falsifier is a legal \(W\) whose occupied \(d\times d\) tile count makes the charged cost reach \(N^2\); do not replace the actual mask incidence by an assumed dense rectangle count.

Restart from unions of \(q\) product masks or bounded biclique-cover masks. First charge \(q\) tile grids, duplicated outputs, mask-description bits, and all overlap corrections. The only useful continuation is a proved range where those terms remain \(o(N^2)\); an unrestricted mask conclusion would require a new incidence argument.

## Finite exact check

The exact-integer script [check_product_mask.py](evidence/check_product_mask.py) implements the seven-product recursion, tiles \(X\) and the selected columns of \(Y\), and compares every requested entry against direct dot products. It passed for \(N=16,D=2,|J|=8\) and \(N=256,D=4,|J|=64\). The recorded run is [exact_check.json](evidence/exact_check.json). These checks validate this finite implementation only; the asymptotic statement follows from the written recurrence and tile count.

## Source ledger

- [N12 selective-tensor card](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/astra_prior/cards/N12-selective-tensor-barrier.txt:5): the fixed-mask tensor-power exponent is not a uniform arbitrary-mask circuit, and the arbitrary-mask target remains open. The result here gives a uniform construction only for the succinct product-mask family.
- [N59 matrix-profile card](/Users/harjas/Documents/Codex/2026-10-08/use-the-astra-research-knowledge-repository-3/work/astra_prior/cards/N59-matrix-profile-barrier.txt:8): its obstruction is a countermodel to a numerical profile system, not a tensor lower bound. This algorithm does not use or strengthen that profile.
- Primary arithmetic source: Volker Strassen, “Gaussian elimination is not optimal,” *Numerische Mathematik* 13 (1969), 354–356, [DOI 10.1007/BF02165411](https://doi.org/10.1007/BF02165411). The rank-seven identity is written explicitly above; the contribution here is its charged application to this output-only mask family, not the identity itself.
- Primary release underlying N59's profile discussion: OpenAI, “An Upper Bound of 9/4 for the Matrix Multiplication Exponent,” pinned 2 October 2026, [source PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf). The present algorithm makes no inference from its exponent claim.

The result is an elementary, exact structured-mask algorithm with a complete asymptotic and bit-cost ledger. No arbitrary-mask advance or novelty/priority claim is made.
