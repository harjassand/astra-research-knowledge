# Hidden renewal code: approximation bottleneck and a full-prefix FKG counterexample

**Status: partial result; general FPRAS status UNKNOWN.** The relative-count-to-prediction step is already available conditionally: a uniform relative FPRAS for every positive child-prefix mass would preserve the (O(n^{-1/2})) expected terminal-KL order after smoothing, with polynomial bit cost and no inverse-prefix-mass charge. This note isolates the missing oracle and gives exact counterexamples to two direct routes: the hidden-state posterior for a full prefix need not be FKG/log-supermodular, and a natural magnetization polynomial for a full-span word need not have log-concave coefficients. These examples include the exact unused-row and terminal-tail rules. They do **not** rule out an auxiliary-variable FPRAS or prove approximation hardness.

## Interface and exact target

Use the fixed-horizon projected row-urn code (Q_N^{\rm bin}) from the marked-renewal packet, with (q=2) hidden event marks (\{0,1\}) mapped to observed event symbol (1), and observed non-events (0). The input is a binary prefix (y\in\{0,1\}^t), (t\le N); the rest of the horizon is marginalized. The code chooses uniformly from the all-zero option and all (q^2)-colored gap-count pools of total span (S\le N-1), then chooses an anchor in ([N-S]), a starting mark uniformly, and samples each outgoing row without replacement. It stops when the current row empties; other rows may retain unused items.

For a nonzero prefix, let (a) be its first event time, (\ell) its last hidden mark, (b) the number of trailing observed zeros, and (c_{i,d,g}) its completed-transition counts. For a pool (C\ge c), put

\[
R_i=\sum_{d,g}C_{i,d,g},\quad r_i=\sum_{d,g}c_{i,d,g},\quad
T=R_\ell-r_\ell,\quad
L=\sum_{d,\,g>b}(C_{\ell,d,g}-c_{\ell,d,g}).
\]

Writing ((x)_k=x!/(x-k)!), its marked-prefix contribution is

\[
\frac{1}{2K_N(N-S)}\,
\frac{\prod_{i,d,g}(C_{i,d,g})_{c_{i,d,g}}}
     {\prod_i(R_i)_{r_i}}
\begin{cases}1,&T=0,\\ L/T,&T>0.\end{cases}
\]

The projected prefix mass sums this expression over **all** compatible hidden mark paths and all pools with (S\le N-a). In the (T=0) case, unused counts in rows other than (\ell) remain legal. In the (T>0) case, the strict condition (g>b) enforces the observed trailing zeros. A common integer scale is (H_N(y)=2K_NN!Q_N^{\rm bin}(y)), whose bit length is polynomial for fixed (q).

For full-span input with event gaps (w=(g_1,\ldots,g_m)), the pool is forced to equal the consumed transition counts. Thus

\[
Q_N^{\rm bin}(x(w))=\frac{Z(w)}{2K_N},\qquad
Z(w)=\sum_{u\in\{0,1\}^{m+1}}
\frac{\prod_{i,d,g}c_{i,d,g}(u)!}{r_0(u)!r_1(u)!}.
\]

A uniform FPRAS for all prefix masses must, in particular, approximate this (Z(w)), but an FPRAS for this full-span special case alone would not handle arbitrary prefixes with unused rows and tail terms.

## Conditional transfer to optimal expected KL

This part is conditional, not an FPRAS construction. Let (A=2) be the observed alphabet size, and let (q^*(\cdot\mid x^n)) be the exact reverse-suffix average of the conditionals of the same fixed (Q_{n+1}^{\rm bin}). Suppose every child mass (Q_{n+1}^{\rm bin}(z_tv)), for every supplied suffix (z_t) and (v\in\{0,1\}), has a randomized relative estimate within (\delta\) with failure probability at most (\eta), uniformly in the prefix, and with bit time polynomial in (N,\delta^{-1},\log(1/\eta)). Normalize the two child estimates for each suffix, average the resulting categorical laws, and smooth by

\[
q_\gamma=(1-\gamma)\widetilde q+\gamma/2.
\]

On the event that all (An) calls succeed, every averaged probability is within multiplicative factors ((1-\delta)/(1+\delta)) and ((1+\delta)/(1-\delta)) of (q^*). Hence for any true next-symbol law (p),

\[
D(p\Vert q_\gamma)\le D(p\Vert q^*)+
\log\frac{1+\delta}{1-\delta}-\log(1-\gamma).
\]

On failure, smoothing gives (D(p\Vert q_\gamma)\le\log(2/\gamma)). A conditional union bound therefore adds at most (2n\eta\log(2/\gamma)) to expected risk; no independence or lower bound on (Q(z_t)) is used. Taking (k=\lceil\sqrt n\rceil), (\delta=\gamma=1/(4k)), and (\eta=1/(2n^2)) gives extra expected KL (O(n^{-1/2})+O(\log n/n)=O(n^{-1/2})). The exact projected code already has (O(n^{-1/2})) expected risk for fixed (q=2), so such an oracle would preserve the optimal order. There are (2n) calls, and the specified per-call bit contract makes the total cost polynomial.

The load-bearing unresolved statement is consequently: **a relative FPRAS for (H_N(y)) uniformly over all binary prefixes (y), including rare prefixes, unused-row completions, and the terminal (L/T) statistic.** Additive estimates or rejection sampling until a rare prefix appears do not meet this contract.

## Exact full-prefix counterexample to direct FKG/ferromagnetic sampling

Take (N=5) and the supplied binary prefix (y=1110). Its events occur at positions (1,2,3), so the observed gaps are (1,1) and the trailing-zero age is (b=1). There are (164) four-coloured pools of span at most (4), because

\[
\sum_{s=0}^4[z^s]\prod_{g=1}^4(1-z^g)^{-4}=164,
\]

and therefore (K_5=165) after the extra all-zero option. For each hidden path (u=(u_0,u_1,u_2)\in\{0,1\}^3), let (\lambda(u)) be the sum of its pool contributions after omitting the common positive factor (1/(2K_5)). Exact enumeration gives:

| Hidden path (u) | (\lambda(u)) |
|---|---:|
| 000, 111 | (7) |
| 001, 110 | (8/3) |
| 010, 011, 100, 101 | (61/12) |

Thus \(\sum_u\lambda(u)=119/3\) and \(Q_5^{\rm bin}(1110)=(119/3)/(2\cdot165)=119/990\). The hidden-path posterior is proportional to \(\lambda\), so common scaling does not affect the following test.

For a positive measure on the Boolean lattice, the FKG positive-lattice condition is

\[
\lambda(x\wedge y)\lambda(x\vee y)\ge\lambda(x)\lambda(y).
\]

Set (x=010) and (y=100). Then (x\wedge y=000), (x\vee y=110), and

\[
\lambda(000)\lambda(110)=7\cdot\frac83=\frac{56}{3}
<\left(\frac{61}{12}\right)^2
=\lambda(010)\lambda(100).
\]

So the hidden-path measure for this valid full-prefix marginal is not log-supermodular and does not satisfy the direct FKG hypothesis. The example explicitly includes the pool-completion effects: on path (000), the (T=0) branch contributes (19/3), of which (6) comes from pools with unused items in the other row; the (T>0) tail-accepted branch contributes (2/3). Pools with (T>0) but no residual gap (g>1) have pre-tail base contribution (5) and are correctly assigned zero mass. Requiring every row to be exhausted or dropping the strict tail test changes these values.

This falsifies a direct proof by FKG/monotone coupling on the hidden marks. It does not exclude an auxiliary-variable representation, a different partial order, annealing, or another FPRAS.

## Exact failure of a natural coefficient log-concavity route

For a full-span word (w), define

\[
A_r(w)=\sum_{u:\,r_0(u)=r}\prod_{i,d,g}c_{i,d,g}(u)!,\qquad
P_w(z)=\sum_{r=0}^m\binom mr A_r(w)z^r.
\]

Then (m!Z(w)=P_w(1)). For (w=(1,2,2,2,2,2,2)), exact enumeration of its (2^8) hidden paths gives

\[
(A_0,\ldots,A_7)=(840,1176,588,540,540,588,1176,840),
\]

and the coefficients of (P_w) are

\[
(840,8232,12348,18900,18900,12348,8232,840).
\]

They are not log-concave at index (2):

\[
12348^2=152{,}473{,}104
<155{,}584{,}800=8232\cdot18900.
\]

This blocks an argument that assumes this natural magnetization polynomial is log-concave or real-rooted. It is not a general obstruction to all log-concave encodings.

There is also a tractable control. If all (m) full-span gap labels are distinct, then (a(u)=1), and exactly (2\binom mr) hidden paths have (r_0=r). Therefore

\[
Z(w)=2\sum_{r=0}^m\frac{\binom mr}{r!(m-r)!}
=\frac{2}{m!}\binom{2m}{m}.
\]

This is computable exactly with polynomial bit cost. In particular, a large raw hidden-path count vector by itself is not an approximation-hardness argument.

## Cost and evidence scope

The full-prefix counterexample checker enumerates the (164) pools and (8) hidden paths using exact rational arithmetic. It computes the stated pool formula and independently checks it against sequential row-urn draws followed by the residual-gap survival event. The full-span coefficient check enumerates (2^8=256) hidden paths. These diagnostics have constant small-instance cost; they prove only the displayed finite identities. No large-scale experiment, FPRAS, mixing bound, or approximation lower bound is claimed.

The exact colored-pool dynamic program has not been converted to an FPRAS here; the current exact fallback in the hidden-code packet is exp(O(q sqrt(N))) times a fixed-q polynomial. The FKG and coefficient counterexamples identify why two direct structural shortcuts fail, but they do not decide whether the full relative oracle exists.

## Source and theorem status

- The precise hidden projected-code definition, full-span (Z(w)), and exact-hardness boundary are in the internal candidate [hidden-renewal result](../../../../sol_hidden_renewal/RESULT.txt), especially §§1–3 and 9. I treated its formula as an input interface and independently checked the finite prefix calculation here; I did not independently certify its all-input reduction.
- The all-pool prefix expression with unused rows and the (L/T) tail factor is the internally proved observed-mark formula in [marked-renewal result](../../../../sol_marked_renewal/RESULT.txt), §§4–5.
- The relative-count-to-KL argument is the internal conditional lemma in [root relative-prediction proof](../../../../root_relative_prediction_compiler/PROOF.txt). This note rederives the binary-alphabet parameters and cost contract; it does not claim an oracle.
- Fortuin, Kasteleyn and Ginibre, “Correlation Inequalities on Some Partially Ordered Sets,” *Communications in Mathematical Physics* 22 (1971), 89–103, [DOI](https://doi.org/10.1007/BF01651330), state the positive-lattice criterion and discuss ferromagnetic Ising applications. Our finite violation is checked directly.
- Jerrum and Sinclair, “Polynomial-time Approximation Algorithms for the Ising Model,” *SIAM Journal on Computing* 22 (1993), 1087–1116, [DOI](https://doi.org/10.1137/0222066), give a randomized approximation algorithm for arbitrary ferromagnetic Ising systems. That theorem concerns ordinary pairwise Ising partition functions; it does not imply an FPRAS for the hidden-code measure above.
- The exact partition-function hardness premise cited by the separate hidden-code proof is Govorov–Cai–Dyer, [arXiv:2002.02021v1](https://arxiv.org/html/2002.02021v1), Theorem 3.2; its published version is [JCSS DOI 10.1016/j.jcss.2022.09.002](https://doi.org/10.1016/j.jcss.2022.09.002). The exact reduction uses cancellation-heavy interpolation and is not an approximation-preserving reduction. No approximation-hardness claim is sourced from it.

## Falsifier and restart

The finite FKG result would be falsified by an arithmetic or interface error in the checker’s pool enumeration, terminal branch, or path table. The log-concavity result would be falsified by an incorrect coefficient sequence. A transformed FKG representation may still exist and would supersede the narrow method obstruction if its transformation and polynomial cost were proved.

Restart by proving or refuting a uniform relative FPRAS for every full projected prefix mass (H_N(y)), retaining the state path, all unused-pool coordinates, anchor denominators, (T=0) stop branch, and the (T>0) strict (g>b) tail. Seek either an explicit rapid-mixing/annealing representation with polynomial conductance and bit costs, or an approximation-preserving reduction; do not infer either from the exact interpolation hardness result. Preserve `UNKNOWN` if neither is obtained.
