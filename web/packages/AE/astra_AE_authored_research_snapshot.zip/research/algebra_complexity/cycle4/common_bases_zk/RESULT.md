# Chen–Liu Theorem 1.6 versus the selective determinant target

Date: 8 October 2026  
Status: exact coefficient encoding established; its natural row/column factorization fails the theorem's log-concavity hypothesis on a 2-by-2 rational input. This is an interface obstruction to this encoding, not a no-go theorem for every encoding of the target.

## Target and theorem interface

For a rational-complex matrix $A\in\mathbb Q(i)^{n\times n}$ and supplied integer $k$, let

\[
 Z_k(A)=\sum_{\substack{I,J\subseteq[n],\ |I|=|J|=k,\ I\cap J=\varnothing}}
          |\det(A[I,J])|^2.
\]

Theorem 1.6 of Chen–Liu, arXiv:2610.06724v1, takes two nonnegative set-weight evaluation oracles on a common ground set of size $m$, whose multiaffine generating polynomials are log-concave on the positive orthant. It also requires one positive-weight seed set for each oracle and upper bounds on both coefficient ranges

\[
 R_\mu=\frac{\max_{S:\mu(S)>0}\mu(S)}{\min_{S:\mu(S)>0}\mu(S)},\qquad
 R_\nu=\frac{\max_{T:\nu(T)>0}\nu(T)}{\min_{T:\nu(T)>0}\nu(T)}.
\]

For supplied $\alpha\in\{0,1,2\}^{U}$, it estimates $[x^\alpha](g_\mu g_\nu)$ with relative error $\epsilon$, success probability at least $3/4$, and at most

\[
 \widetilde O\!\left(\frac{m^{11}(m+\log(R_\mu R_\nu))^2}{\epsilon^2}\right)
\]

arithmetic operations and value-oracle calls. Median amplification multiplies this by $O(\log(1/\delta))$ for failure probability $\delta$. The paper's Remark A.4 gives polynomial worst-case bit time for rational parameters and polynomial-bit rational value oracles. Its Appendix A support step returns exact zero when the restricted supports cannot meet the coefficient constraint, under the same log-concavity premise.

## Exact row/column coefficient identity

Use $U=\{r_i,c_i:i\in[n]\}$, with one row token and one column token per site. For $S\subseteq U$, put

\[
 I(S)=\{i:r_i\in S\},\qquad J(S)=\{i:c_i\in S\},
\]

and define the two nonnegative set weights

\[
 \mu(S)=\mathbf1[|I(S)|=|J(S)|=k]\,|\det(A[I(S),J(S)])|^2,
 \qquad
 \nu(T)=\mathbf1[ T\cap\{r_i,c_i\}\ne\varnothing\text{ for every }i].
\]

Their generating polynomials are

\[
 g_\mu=\sum_{|I|=|J|=k}|\det(A[I,J])|^2 x^{I_r}x^{J_c},\qquad
 g_\nu=\prod_{i=1}^n(x_{r_i}+x_{c_i}+x_{r_i}x_{c_i}).
\]

For $\alpha=\mathbf1_U$, expanding the product gives

\[
 [x^U](g_\mu g_\nu)=\sum_{S\subseteq U}\mu(S)\nu(U\setminus S).
\]

For a term with row set $I$ and column set $J$, $\nu(U\setminus S)=1$ exactly when $S$ does not contain both $r_i,c_i$ at any site $i$, equivalently $I\cap J=\varnothing$. Therefore this coefficient is exactly $Z_k(A)$, including when it is zero. This proves the identity without replacing determinant squares by diagonal permutation terms.

The selector factor does satisfy the theorem's analytic condition. For $h(x,y)=x+y+xy$ and $x,y>0$,

\[
 \nabla^2\log h=-\frac1{h^2}
 \begin{pmatrix}(1+y)^2&1\\1&(1+x)^2\end{pmatrix}.
\]

The displayed matrix is positive definite: its diagonal entries are positive and its determinant is $(1+x)^2(1+y)^2-1>0$. Thus each local $\log h$ is concave, and $\log g_\nu$ is their sum on disjoint variable pairs. The polynomial is multiaffine and nonnegative as required.

## Minimal failure: the row/column determinant factor is not log-concave

Take

\[
 n=2,\quad k=1,\quad A=\begin{pmatrix}0&1\\1&0\end{pmatrix}.
\]

Then

\[
 g_\mu=x_{r_1}x_{c_2}+x_{r_2}x_{c_1},\qquad Z_1(A)=2.
\]

Order variables as $(x_{r_1},x_{r_2},x_{c_1},x_{c_2})$, and evaluate at $\mathbf1$. We have $g_\mu=2$, $\nabla g_\mu=(1,1,1,1)$, and the only nonzero Hessian pairs are $H_{1,4}=H_{4,1}=H_{2,3}=H_{3,2}=1$. For $v=(1,-1,-1,1)$,

\[
 \nabla g_\mu\cdot v=0,\qquad v^T(\nabla^2g_\mu)v=4,
 \qquad v^T\nabla^2\log g_\mu(\mathbf1)v
 =\frac{4}{2}-\frac{0^2}{2^2}=2>0.
\]

This contradicts the required negative-semidefinite Hessian of $\log g_\mu$. It is the first failed theorem condition in this exact encoding: both factors are nonnegative and multiaffine; $\nu$ is log-concave; the rational evaluation oracle is exact; the supplied seed sets can be $S_0=\{r_1,c_2\}$ and $T_0=\{r_1,r_2\}$; and both coefficient ranges are exactly one. The failure is thus not caused by a missing seed, a large range, signs in the summands, or an incorrect coefficient identity.

There is also a positive-target-zero example: for the 2-by-2 identity matrix with $k=1$, both oracles have positive support and the matrix rank is at least $k$, but every nonzero minor has $I=J$, so the target is zero. This identity-matrix instance is itself inadmissible too: its determinant-weight polynomial is $x_{r_1}x_{c_1}+x_{r_2}x_{c_2}$, which has the same positive-curvature witness after relabeling variables. The example only shows that rank and positive seeds do not imply a positive target. Appendix A's support routine handles zero coefficients for factors that satisfy the theorem's assumptions; it cannot be invoked on either counterexample here.

## Cost ledger for the candidate encoding

Let $L$ be the total binary input length of the rational real and imaginary parts of $A$, with positive denominators. Let $D$ be the product of those denominators and $B=DA\in\mathbb Z[i]^{n\times n}$; then $\log_2D\le L$ and $\log_2\max(1,\|B\|_\infty)=O(L)$, where $\|B\|_\infty=\max_{ij}|B_{ij}|$. If $\operatorname{rank}(A)\ge k$, every nonzero minor has squared-modulus weight at least $D^{-2k}$, because a nonzero Gaussian integer has squared modulus at least one, while Hadamard gives

\[
 |\det(A[I,J])|^2\le \frac{(k\max(1,\|B\|_\infty)^2)^k}{D^{2k}}.
\]

Consequently $\log R_\mu=O(k(L+\log(n+1)))$; $R_\nu=1$. The $\mu$-oracle checks the two cardinalities and computes one exact rational determinant and its square using $O(k^3)$ field operations; its returned numerator and denominator have $O(k(L+\log(n+1)))$ bits each, so fraction-free elimination gives polynomial bit cost. For $k>\lfloor n/2\rfloor$, the target is zero by disjoint-set feasibility and can be returned immediately. In the remaining sector, if $\operatorname{rank}(A)<k$, the target is identically zero and can also be returned exactly before any oracle call. If rank is at least $k$, Gaussian elimination produces a nonzero $k$-minor and hence a positive seed for $\mu$; the explicit $T_0$ above generalizes by taking all row tokens.

Were both factors log-concave, the quoted theorem bound at $m=2n$ would be

\[
 \widetilde O\!\left(
 \frac{(2n)^{11}\bigl(2n+O(k(L+\log(n+1)))\bigr)^2}{\epsilon^2}
 \right)
\]

arithmetic operations/oracle calls, times $O(\log(1/\delta))$ for confidence $1-\delta$, with the polynomial bit overhead above. This is a cost for a valid instance of the theorem, not an algorithm for general $Z_k$: the swap witness invalidates its premise. The theorem's polynomial oracle-cost statement also does not expose the selected $I,J$; $k$ is supplied and the requested output here is a scalar estimate.

## Second natural lift and its obstruction

For rational-complex $A$, let $V=[I_n\mid A^*]$ and $G=V^*V$. Index the $2n$ columns by $U=\{r_i,c_i:i\in[n]\}$ and write $P(S)=\{r_i,c_i:i\in S\}$. Cauchy–Binet gives

\[
 \det G[P(S)]=\sum_{\substack{J\subseteq[n]\\|J|=k,\ J\cap S=\varnothing}}
                    |\det(A[S,J])|^2
 \qquad (|S|=k).
\]

Indeed, the selected columns of $V$ consist of the coordinate vectors $e_i$ for $i\in S$ and the conjugated rows of $A$ indexed by $S$. In each $2k$-row Cauchy–Binet minor, the coordinate columns force the row set to contain $S$; the remaining $k$ rows form a set $J$ disjoint from $S$, and expansion along the coordinate columns leaves, up to sign, the conjugate of $\det A[S,J]$. Taking squared moduli and summing over $S$ proves $Z_k(A)=\sum_{|S|=k}\det G[P(S)]$.

This is itself a subset-convolution coefficient with $\alpha=\mathbf1_U$: take $\mu(Q)=\mathbf1[|Q|=2k]\det G[Q]$, and let $\nu(T)=1$ exactly when $T$ is the union of $n-k$ complete site-pairs. Then

\[
 g_\nu=e_{n-k}(x_{r_1}x_{c_1},\ldots,x_{r_n}x_{c_n}),
 \qquad [x^U](g_\mu g_\nu)=Z_k(A).
\]

The Gram weights are nonnegative because $G$ is positive semidefinite. But the selector factor already fails log-concavity at $n=2,k=1$, where it is $x_{r_1}x_{c_1}+x_{r_2}x_{c_2}$. At the all-ones point, in variable order $(r_1,c_1,r_2,c_2)$, the direction $(1,1,-1,-1)$ has gradient dot product zero and Hessian quadratic form $4$, so its logarithmic Hessian quadratic form is $4/2=2>0$. Thus the exact Gram lift moves the failure to the complete-pair selector; it does not make this two-factor encoding admissible. This rejects the stated selector factorization only, not arbitrary alternative oracle constructions.

## Status and falsifier

The exact coefficient identity and the log-concavity counterexample are proved above and replayed in the evidence script check_coeff_encoding.py. Chen–Liu's theorem is used at its stated evaluation-oracle, multiaffine-log-concave, positive-seed, coefficient-range interface. Its source is a v1 arXiv manuscript; this note does not independently audit that manuscript's full FPRAS proof.

**Conclusion:** Theorem 1.6 does not yield an FPRAS for the general selective $Z_k(A)$ by either of the two natural exact subset-convolution encodings recorded here. No general impossibility result, approximation lower bound, or claim against a different encoding is established.

**Falsifier / next decisive step:** give a different exact coefficient encoding of general $Z_k(A)$ with two nonnegative multiaffine log-concave generating polynomials, efficient exact rational evaluation oracles, positive seeds, and polynomial-bit coefficient-range bounds; or give a counterexample to the stated coefficient identity. The current evidence already falsifies the row/column log-concavity premise on the minimal 2-by-2 swap input.
