# Leaf 08 result

**Status:** target remains open. A hypothetical deterministic, fully charged \(O(N^{2-\eta})\) solver for the arbitrary-mask product at \(D=N^{1/4}\), \(|W|\le N^{15/8}\), implies lopsided triangle in \(O(n^{2-\eta})\), Exact Triangle in \(O(n^{3-\eta/2}\operatorname{polylog}n)\), 3SUM in \(n^{2-\eta/4+o(1)}\), and integer APSP/min-plus in \(\widetilde O(n^{3-\eta/6})\).

Alman–Vassilevska Williams, arXiv:2610.06783v1, already reports 3SUM \(O(n^{1.9992})\), APSP/min-plus \(O(n^{2.99942})\), and Exact Triangle \(O(n^{3-0.00175}\log n)\). The conditional exponents improve those baselines only when \(\eta>0.0035=7/2000\); the known hypotheses are already refuted according to that preprint.

The strongest structural consequences available here are model-limited: some legal masks force \(\Omega(N^2)\) under independently charged complete-block covers, and a subquadratic solver cannot come from a low-entropy precompiled graph-kernel library using only coordinate-copy aliases. These results do not lower-bound general circuits. Tensor rank alone also fails to specify input acquisition, coefficient heights, or output decoding.

See [REPORT.md](REPORT.md) for derivations, assumptions, sources, status, falsifiers, and scope. [RESTART.md](RESTART.md) preserves the next gate.
