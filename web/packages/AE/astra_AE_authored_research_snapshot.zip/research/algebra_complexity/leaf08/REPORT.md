# Conditional consequences of the selective tensor target

**Status (8 October 2026).** The target remains open in this repository. This note proves what a hypothetical fully charged solver would imply and records the strongest structural exclusions already available. The fine-grained reductions are conditional on the target algorithm. The 3SUM and APSP hypotheses they would refute have already been refuted by a newer primary preprint, so those implications would not themselves be new hypothesis refutations. No general arithmetic-circuit lower bound is claimed.

## Target and cost model

For \(N\) tending to infinity, let \(D=N^{1/4}\), let \(X\in\mathbb Z^{N\times D}\), \(Y\in\mathbb Z^{D\times N}\), and let an arbitrary list \(W\subseteq[N]^2\) of at most \(N^{15/8}\) positions be supplied. The task is to return every exact value
\[
  (XY)_{ij}=\sum_{k=1}^{D}X_{ik}Y_{kj},\qquad (i,j)\in W.
\]

Assume a deterministic uniform algorithm does this in \(O(N^{2-\eta})\) operations for one fixed \(0<\eta<1/8\), on \(O(\log N)\)-bit words, charging input, mask, answer writes, preprocessing, arithmetic, and all intermediate bit lengths. Equivalently, assume bit time \(O(N^{2-\eta}\operatorname{polylog}N)\). A field-operation count with unbounded coefficients is insufficient for the word-RAM reductions. The output bound is consistent because \(|W|\le N^{15/8}=o(N^{2-\eta})\) in this range of \(\eta\).

The target is a requested-output product. The algorithm must work for each newly supplied mask \(W\).

## Theorem: consequences for lopsided triangles, Exact Triangle, 3SUM, and APSP

Suppose the target algorithm above exists. Then:

1. Counting or detecting triangles through any supplied set \(W\) of at most \(n^{15/8}\) outer pairs in a tripartite graph with outer parts of size \(n\) and middle part of size \(n^{1/4}\) takes \(O(n^{2-\eta})\) time. This is the counting version of lopsided all-edges sparse triangle.
2. For polynomially bounded integer edge weights, Exact Triangle on \(n+n+n\) vertices is solvable deterministically in
   \[
   O\!\left(\nu n^{3-\eta/2}\log n+n^{\omega+3/8+o(1)}+n^{9/4+\eta/2}\right)
   =O(n^{3-\eta/2}\operatorname{polylog}n),
   \]
   using a square-matrix multiplication exponent \(\omega<2.372\).
3. The standard deterministic reductions then give 3SUM on \(n\) polynomially bounded integers in \(n^{2-\eta/4+o(1)}\) time, and min-plus product and directed APSP with polynomially bounded integer weights and no negative cycles in \(\widetilde O(n^{3-\eta/6})\) time.

**Proof.** For the first claim, let \(A,B,C\) be the graph parts, with \(|A|=|B|=n\) and \(|C|=D=n^{1/4}\). Let \(X[a,c]=1\) iff \(ac\) is an edge and \(Y[c,b]=1\) iff \(cb\) is an edge. Then
\[
(XY)[a,b]=|\{c\in C: ac,cb\text{ are edges}\}|.
\]
The requested product values are exactly common-neighbor counts for queried pairs; a count is positive iff that pair lies in a triangle. The matrices are 0/1, each answer is at most \(D\), and the mask has the allowed size. Reading the matrices and mask and testing positivity fit the assumed charge.

For Exact Triangle, use Alman and Vassilevska Williams, Theorem 17 of [their primary paper](https://arxiv.org/html/2610.06783v1). For reduction parameter \(D\) and \(1\le g\le\sqrt D\), their deterministic reduction makes at most \(4ng\) lopsided instances, each with at most \(n^2/\sqrt D\) queried pairs, and uses additional time
\[
O\!\left(\nu n^3\log n/g+n^{\omega+o(1)}D^{3/2}+n^2Dg\right),
\]
for input edge weights of magnitude at most \(n^\nu\). Choose \(D=\lfloor n^{1/4}\rfloor\) and \(g=\lceil n^{\eta/2}\rceil\). Rounding to integer dimensions, and padding \(n\) to the next fourth power if the target is stated only at exact fourth powers, changes the bounds by \(n^{o(1)}\). The reduction's mask cap is
\[
n^2/\sqrt D=n^{15/8+o(1)}.
\]
A constant-factor excess over the target mask cap is handled by a constant number of batches. The target calls cost
\[
O(ng\,n^{2-\eta})=O(n^{3-\eta/2}).
\]
The witness scans cost \(O(\nu n^{3-\eta/2}\log n)\). The other terms are \(n^{\omega+3/8+o(1)}<n^{2.747+o(1)}\) and \(n^{9/4+\eta/2}\le n^{2.3125}\), both lower order since \(3-\eta/2>2.9375\). Also \(g\le\sqrt D\) because \(\eta<1/8\). This proves the Exact Triangle bound.

For 3SUM, Theorem 21(a) in the same paper reduces it deterministically to \(n^{1/2+o(1)}\) Exact Triangle instances, each with \(n^{1/2+o(1)}\) vertices per part, plus \(n^{3/2+o(1)}\) work. Substituting \(T(s)=s^{3-\eta/2+o(1)}\) gives
\[
n^{1/2+o(1)}T(n^{1/2+o(1)})=n^{2-\eta/4+o(1)}.
\]
For min-plus product and APSP, Theorem 21(b) gives \(O(n^2T(n^{1/3})\log^k n)\) for fixed \(k\le3\), provided \(T(s)/s\) is nondecreasing. The envelope \(T(s)=O(s^{3-\eta/2}\log s)\) has this property, so the total is \(\widetilde O(n^{3-\eta/6})\). The APSP assumption is directed graphs with polynomially bounded integer weights and no negative cycles. The cited reductions include the call counts and their auxiliary work. ∎

## Baselines and what the implication adds

The primary comparison is the 5 October 2026 Alman–Vassilevska Williams preprint [arXiv:2610.06783v1](https://arxiv.org/abs/2610.06783v1). Its Theorem 1 gives a deterministic requested-output algorithm for \(D\le N^{1/18}\), \(|W|\le N^2/\sqrt D\), in \(O(N^2/D^{0.063})\) operations on polynomially bounded integers. Its more general regime permits \(D\le N^\epsilon\) for every \(\epsilon<0.1204\), with a positive saving when the mask is polynomially sparse. Theorem 19 reports Exact Triangle in \(O(n^{3-0.00175}\log n)\). Theorem 22 reports deterministic 3SUM in \(O(n^{1.9992})\) and APSP/min-plus in \(O(n^{2.99942})\). Thus the classical 3SUM, APSP, and Exact Triangle hypotheses are already refuted according to this primary source.

The hypothetical target has the same mask density \(N^2/\sqrt D=N^{15/8}\) at \(D=N^{1/4}\), beyond that preprint's width regime. Its Exact Triangle exponent \(3-\eta/2\), and therefore both downstream exponents, strictly improve the reported baselines only when
\[
\eta/2>0.00175,\qquad\text{equivalently}\qquad \eta>0.0035=7/2000.
\]
The threshold matches all three comparisons: the established 3SUM and APSP savings are \(0.00175/2\) and \(0.00175/3\). For \(0<\eta\le0.0035\), this reduction still gives the wider lopsided-product algorithm, but it does not improve the source-reported 3SUM/APSP exponents. The cited preprint is a primary source; this leaf checked its theorem statements and the parameter substitution, not the whole manuscript or its formal verification.

There is also an exact offline set-disjointness interpretation. For sets \(S_i,T_j\subseteq[D]\), set \(X[i,k]=1_{k\in S_i}\) and \(Y[k,j]=1_{k\in T_j}\). The target returns \(|S_i\cap T_j|\) for any \(N^{15/8}\) supplied pairs in \(O(N^{2-\eta})\) time. This is a batch algorithm for a universe of size \(N^{1/4}\); it does not provide an online or adaptive-query data structure. Pairwise counting costs \(N^{15/8}N^{1/4}=N^{17/8}\), while full rectangular multiplication costs \(N^{2+o(1)}\) in this width range. The target would beat these baselines for its stated width and mask regime.

## Structural lower bounds a hypothetical solver must evade

These are model-restricted obstructions, not lower bounds against arbitrary arithmetic circuits.

### Independent complete-block covers

Let \(\rho=N^{-1/8}\), \(D=N^{1/4}\), and sample every output position independently with probability \(\rho/2\). For all sufficiently large \(N\), there exists a legal \(W\) with \(|W|=\Theta(\rho N^2)=\Theta(N^{15/8})\) and, simultaneously for every row set \(R\) and column set \(C\),
\[
e_W(R,C)\le \rho |R||C|+C_0(|R|+|C|)\log N,
\]
where \(C_0=6/\ln 2\) suffices. Indeed, for \(E\sim\mathrm{Bin}(|R||C|,\rho/2)\), exponential Markov at \(\lambda=\ln2\) bounds a violation by \(N^{-6(|R|+|C|)}\). There are at most \(N^{|R|+|C|}\) such choices; a union bound and Chernoff concentration for \(|W|\) prove existence.

A complete multiplication block chooses \(R,C\) and \(K\subseteq[D]\), with \(d=|K|\), and is charged at least
\[
c=\max\{|R||C|,\ |R|d,\ |C|d\}.
\]
It covers at most \(e_W(R,C)d\) requested summands. Since \(d\le D\), the mask inequality gives
\[
e_W(R,C)d\le(\rho D+2C_0\log N)c.
\]
Every pair in \(W\) requires all \(D\) inner-coordinate summands, so a cover of \(W\times[D]\) must cover at least \(|W|D\) triples. Its total independent block charge is therefore
\[
\sum c\ge\frac{|W|D}{\rho D+2C_0\log N}=\Omega(N^2),
\]
because \(\rho D=N^{1/8}\) dominates \(\log N\). Thus a truly subquadratic solver cannot use this independent complete-block-cover strategy on every legal mask. The proof permits mask-dependent rectangles, overlaps, arbitrary aspect ratios, arbitrary inner subsets, and ideal blocks at their flattening-size cost. Cross-block arithmetic sharing and general output-local circuits remain outside its scope.

### Small precompiled libraries with coordinate-copy inputs

A second obstruction allows global arithmetic sharing inside each source kernel. Fix \(m=\lfloor N^{15/8}\rfloor\). Suppose a library contains \(K_N\) precompiled graph-masked kernels. A source kernel has graph \(H\subseteq[U]\times[V]\) with \(h\) edges and computes every output of
\[
T_{H,D}=\sum_{(u,v)\in H}\sum_{k=1}^{D} A_{uk}B_{kv}C_{uv}.
\]
Assume its full evaluation costs at least a constant multiple of \(\max\{h,UD,VD\}\), from its output and input flattening ranks. A specialization may depend arbitrarily on \(W\) and use aliases and scalings
\[
A_{uk}=a_uX_{f(u),k},\qquad B_{kv}=b_vY_{k,g(v)},\qquad f(u),g(v)\in[N]\cup\{0\}.
\]
It may select or linearly combine outputs, and its assignment choices are given for free. The source circuit itself is not rewritten after seeing the aliases.

**Claim.** If every source has cost \(O(N^{2-\eta})\) for fixed \(\eta>0\) and \(\log K_N=o(m\log N)\), these sources fail to realize at least one legal mask of size \(m\), for all sufficiently large \(N\).

For a fixed source and assignment, its output polynomials are scaled copies of \(p_{ij}=\sum_kX_{ik}Y_{kj}\) for pairs in
\[
E=\{(f(u),g(v)):(u,v)\in H,\ f(u),g(v)\ne0\},\qquad |E|\le h.
\]
The \(p_{ij}\) are linearly independent for distinct pairs because their monomials have distinct row and column indices. Linear combinations cannot produce a target pair outside \(E\); at most \(\binom{h}{m}\) size-\(m\) masks are attainable for this assignment. There are at most \((N+1)^{U+V}\) assignments. Writing \(C_N=cN^{2-\eta}\) for an upper bound on source cost, we have \(h\le C_N\) and \(U+V=O(C_N/D)=O(N^{7/4-\eta})\). The library covers at most
\[
K_N(N+1)^{O(N^{7/4-\eta})}\binom{\lfloor C_N\rfloor}{m}
\]
masks. If \(C_N<m\), coverage already fails. Otherwise
\[
\frac{\binom{N^2}{m}}{\binom{\lfloor C_N\rfloor}{m}}
=\prod_{r=0}^{m-1}\frac{N^2-r}{\lfloor C_N\rfloor-r}
\ge (N^2/C_N)^m.
\]
Its logarithm is at least \(m(\eta\log N-\log c)=\Theta(m\log N)\). The library and assignment prefactor has logarithm \(\log K_N+O(N^{7/4-\eta}\log N)=o(m\log N)\), so fewer than all \(\binom{N^2}{m}\) masks are covered. ∎

This excludes polynomial-size fixed libraries and similar low-entropy precompilation through coordinate permutations or duplications, even with shared arithmetic inside each kernel and arbitrary output combinations. It gives free mask-dependent alias selection. It does not exclude a mask-dependent circuit rewrite, genuinely mixed linear encodings, a library with mask-sized description entropy, or arbitrary uniform algorithms. In particular, it is not a lower bound against Alman–Vassilevska Williams's output-local construction, whose encodings mix input variables.

## Counterexample to a rank-only runtime inference

For any fixed \(C\in\mathbb{Z}^{m\times r}\), the bilinear map
\[
F_C(a,b)=C(a\circ b)=\sum_{j=1}^{r}a_jb_jC_{*,j}
\]
has tensor rank at most \(r\). This counts the \(r\) scalar products, but says nothing about applying the output map \(C\); literal dense decoding costs \(O(mr)\), and the rank statement supplies no cheaper decoder. In the simpler map \(F(a,b)=(ab,\ldots,ab)\in\mathbb{Z}^m\), rank is one while writing the \(m\) outputs takes \(\Omega(m)\) word operations. These are counterexamples to “rank equals total runtime,” not lower bounds on the target.

The earlier selective-tensor dossier also records a fixed-mask spectral estimate \(\widetilde R(T_{W,D})\le N^{1445/744}\). This is a tensor-power limit with the mask held fixed: it concerns decompositions for \(T_{W,D}^{\otimes k}\), whose output mask is \(W^{\otimes k}\). It does not supply a uniform one-shot circuit for arbitrary masks \(W_N\), an acquired finite decomposition, coefficient-height bounds, or a cheap output decoder. Exchanging those quantifiers is invalid. See [leaf01's selective-tensor audit](../leaf01/d-1e7a99ec32d38c30.txt) for the full spectral calculation and its scope.

## Status, falsifier, and restart

- **Derived conditional result:** the fine-grained exponent transfer follows from the target assumption and the cited primary reduction statements. The target has not been obtained.
- **Current baseline:** arXiv:2610.06783v1 already reports the deterministic 3SUM/APSP improvements listed above. Its complete proof, formalization, and historical priority were not independently certified in this leaf.
- **Structural no-go claims:** the block-cover and coordinate-copy-library proofs are elementary counting arguments under the stated models. Neither is a general circuit lower bound.
- **Falsifier for the reduction calculation:** find a dimension, mask-size, weight-range, or auxiliary-cost term in Theorems 17/21 that fails under \(D=n^{1/4}\), \(g=n^{\eta/2}\), or the target's bit model. The size and cost exponents are exposed above for line-by-line checking.
- **Falsifier for the coordinate-copy claim:** exhibit, for infinitely many \(N\), a library with \(\log K_N=o(m\log N)\) and source cost \(O(N^{2-\eta})\) that realizes every size-\(m\) mask under the specified aliases.
- **Restart:** verify any proposed selective solver against the one-shot integer interface and charged intermediate bit lengths, then substitute its proved \(\eta\) here. If \(\eta>7/2000\), update the fine-grained comparison; otherwise report the wider \(D=N^{1/4}\) lopsided-triangle and set-intersection regime without claiming improved 3SUM/APSP exponents. Do not infer SETH/OV consequences without separate reductions.

## Primary and repository sources

1. Josh Alman and Virginia Vassilevska Williams, [*Truly Subquadratic 3SUM and Truly Subcubic APSP via Triangles in Sparse Lopsided Graphs*, arXiv:2610.06783v1](https://arxiv.org/html/2610.06783v1). Theorem 1 gives the selective-product baseline; Theorem 17 gives the deterministic Exact Triangle-to-lopsided reduction and auxiliary costs; Theorem 19 gives its Exact Triangle baseline; Theorems 21–22 give the deterministic 3SUM/APSP transfers and current exponents.
2. Matthias Christandl, Péter Vrana, and Jeroen Zuiddam, [*Universal points in the asymptotic spectrum of tensors*](https://toc.cs.uchicago.edu/articles/v017a002/v017a002.pdf), Theory of Computing 17 (2021). This is the primary source for the asymptotic-spectrum duality behind the fixed-tensor rank interpretation.
3. Earlier repository audit: [leaf01 selective-tensor report](../leaf01/d-1e7a99ec32d38c30.txt); compact source cards [L04](../../../astra_prior/cards/L04-block-cover-obstruction.txt), [N12](../../../astra_prior/cards/N12-selective-tensor-barrier.txt), and [Alman–Vassilevska Williams baseline](../../../astra_prior/cards/W-frontier-tensor-bridge.txt).

This is a conditional reduction audit, not external validation, a new algorithm, or a general lower-bound theorem.
