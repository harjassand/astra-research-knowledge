# Leaf 08 restart

Read [REPORT.md](REPORT.md) first.

The target remains open: exact integer requested entries of \(XY\), with \(D=N^{1/4}\), arbitrary \(|W|\le N^{15/8}\), and all input, mask, output, arithmetic, and bit-height costs charged.

The main conditional transfer is:

\[
\text{target }O(N^{2-\eta})
\Rightarrow
\begin{cases}
\text{lopsided all-edges sparse triangle }O(n^{2-\eta}),\\
\text{Exact Triangle }O(n^{3-\eta/2}\operatorname{polylog}n),\\
\text{3SUM }n^{2-\eta/4+o(1)},\\
\text{integer APSP/min-plus }\widetilde O(n^{3-\eta/6}).
\end{cases}
\]

This composes Alman–Vassilevska Williams, arXiv:2610.06783v1, Theorems 17 and 21. Their Theorems 19 and 22 already report Exact Triangle \(n^{3-0.00175}\operatorname{polylog}n\), 3SUM \(O(n^{1.9992})\), and APSP/min-plus \(O(n^{2.99942})\). The hypothetical transfer improves those reported exponents only for \(\eta>7/2000\). The preprint's result is source-reported here; this leaf checked the parameter substitution, not its full proof.

Two model-restricted no-go results are proved in the report: some masks force \(\Omega(N^2)\) cost for independent complete-block covers; and a low-entropy precompiled kernel library with coordinate-copy inputs cannot cover every size-\(N^{15/8}\) mask at subquadratic source cost. Neither rules out arbitrary arithmetic circuits.

Resume by checking any proposed solver against the one-shot arbitrary-mask integer interface and its charged intermediate bit lengths. Then substitute its proved \(\eta\) into the reduction table. Do not infer SETH/OV or online/adaptive data-structure consequences without separate reductions. Do not convert the fixed-mask asymptotic-rank estimate into a uniform one-shot algorithm.
