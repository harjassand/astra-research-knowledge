# Frontier continuation: uniform log-valuation kinetics and exact face obstruction

Status: **conditional proof candidate**, Oct 8 2026. Not externally refereed, priority not cleared, no formal proof checker. Do not promote to an established theorem on ingestion.

Astra baseline: commit ca22fffaeab073aaa1bbb690ce1b4250fc272956. Relevant inherited: N33-endotactic-permanence (unreviewed higher-dimensional core), state/2026-10-08_positive-rational-tropical-permanence.txt (positive rational extension already known to Astra), and OpenAI October 5 2026 family149 original affine approximation lemma (pinned source below). See also the full local investigation packet RESEARCH.md, exact checker and random exact tests (SHA256 checks recorded there).

## The exact conditional theorem

For a finite collection of nonzero reaction vectors nu_e in R^d and positive Caratheodory rates w_e(t,x), consider x'=sum_e nu_e w_e(t,x) on the positive orthant. Assume uniformly locally Lipschitz state dependence, and continuous log-orders tau_e on [-1,1]^d such that uniformly over e, every allowed kinetic path, t>=0 and p in [-1,1]^d,

    |log(w_e(t,h^p))/log(h) - tau_e(p)| <= epsilon(h) --> 0 (h downarrow 0).

For every r having any relevant edge (r.nu_e != 0), let m(r)=min_{r.nu_e !=0} tau_e(r). Suppose every relevant e with tau_e(r)=m(r) satisfies r.nu_e>0. Include lower-dimensional hyperplane faces; ignoring them is unsound.

**Claim, conditional on the October 2026 OpenAI family149 affine-minimum approximation lemma:** in every positive stoichiometric class P=(c+span{nu_e}) cap positive orthant, there exists a single nonempty compact convex positively invariant absorber K_P common to all admissible kinetic paths. Entry is finite with bound uniform over paths for each initial point. No useful practical construction/precision or biologically measured parameter inference follows automatically.

## Proof skeleton (all quantifiers deliberate)

1. For each r outside S-perp, choose a tropical-minimal relevant edge e+(r). By the inwardness test r.nu_e+>0 and each negative-projection edge has strictly larger tau_e(r). By continuity choose a pointwise radius E(r)>0 so each negative edge has tau_e(p)-tau_e+(p)>g(r)>0 for |p-r|<E(r). Also choose E(r)<|r_i|/2 at each nonzero coordinate; E(0)<=1/2. For r in S-perp, only coordinate conditions apply. E is allowed to be discontinuous and to have inf E=0.
2. OpenAI family149 provides one **finite, h-independent** affine minimum F_h=min_lambda(r_lambda.x+b_lambda(h)) with the property that every active slope at x=h^p lies within E(r_lambda) of p uniformly for all sufficiently small h. The finite selected active slopes have uniform gap g_0>0 and positive projected coefficient a_0>0 for their selected e+. The uniform log-order condition implies w_negative / w_e+ <=h^(g_0/2). Negative contributions sum to <=B h^(g_0/2) w_e+, so r_lambda.xdot >= a_0 w_e+/2 >=delta_h>0 for every active r_lambda outside S-perp, uniformly over paths. Neutral slopes have projected derivative exactly 0. This does not use monomial-source comparison from N33.
3. Fix c in class P. For small h, p_c=log c/log h is close to 0. The coordinate tolerances ensure all labels active at c have zero slope, hence the concave finite-affine F_h has a global maximum M_h=F_h(c). Its plateau K_h={F_h=M_h} is closed convex, contains c, and is compact within int[h^(1/2),h^(-1/2)]^d (zero active slope forces |p|<1/2; convexity excludes crossing the box boundary). At class points outside plateau, no slope in S-perp is active.
4. Along Caratheodory trajectories in [h,h^-1]^d, the finite affine-minimum chain rule gives dF_h/dt=min_{active r} r.xdot almost everywhere. It is nonnegative and >=delta_h outside plateau in P. Thus K_h is invariant, and any path staying inside [h,h^-1]^d enters K_h in finite time bounded by (M_h-min_box F_h)/delta_h.
5. Each x0 lies in K_h0 at a sufficiently small h0. Iterate h_(j+1)=min(sqrt(h_j),h_P) and K_hj subset int B_sqrt(h_j) subset B_h(j+1). After finitely many iterations every admissible trajectory enters the common K_hP cap(c+S). This uses **no nesting** assumption for the successive plateaux. Uniform constants depend on the supplied full-family log-order convergence envelope, not on a chosen path.

## Class extension not already in Astra's rational result

With positive generalized polynomials P_e,Q_e and bounded positive rate prefactors, tau_e(p)=min_{alpha in supp P_e}alpha.p -min_{beta in supp Q_e}beta.p. One may multiply each rate by

    exp(c_e (1+sum_i (log x_i)^2)^(1/4)),

with arbitrary fixed finite real c_e, or uniformly bounded c_e across an uncertainty family. For L=-log h, the added logarithmic order is <=|c_e|(1+d L^2)^(1/4)/L=O_d(L^-1/2), uniformly in p. The multiplier is unbounded or decays to zero along nonzero logarithmic directions, so the old two-sided constant *power envelopes* need not hold. The (positive, locally Lipschitz) deformed Hill repression toggle qualifies by the elementary inwardness check.

## Exact polynomial fixed-d face criterion

For rational supports form the finite list of every alpha-beta from numerator and denominator terms of each edge; cut R^d by (alpha-beta)-(alpha'-beta') normals across all pairs and by the reaction-vector normals nu_e. Every **relative-open face**, including lower-dimensional ones, has fixed signs of r.nu_e, fixed numerator and denominator minimizers, and fixed order of tau_e(r). One exact rational witness in each face decides the criterion. Standard rational hyperplane arrangement enumeration and rational LP give polynomial bit-complexity for each *fixed* d (degree depends on d), not dimension-uniform polynomial time. This decides tropical inwardness only, not a finite-bit geometric absorber or physical model.

## Exact counterexample: generic directions can all pass

    0 -> Y; 2Y -> Y; X+Y -> Y
    x'=-xy, y'=1-y^2

With y(0)=1, x(t)=x(0)exp(-t) ->0. Yet the tropical inwardness check passes for every angular direction with r_y !=0, including all open arrangement sectors. It fails only for r=(r_x,0), r_x>0, because the sole relevant edge X+Y->Y points outward. **Checking only generic fans would falsely certify a nonpersistent system.** Exact rational 2D checker and independent test packet accompany the handoff.

## Verification and limitations

Exact 2D checker tests: Hill toggle 24/24 face directions passes; autocatalytic-loss case rejected; boundary-only extinction case rejected at (1,0), all open sectors pass. Separate seed 2601008 crosscheck: 200 random small rational networks; 33,840 exact common-denominator lift identities and 16,000 rational-direction comparisons pass. These are finite code checks, not a proof of dynamics. No independent reviewers/subagents were used. Extra obligations: audit arbitrary-tolerance affine lemma, external novelty search on general kinetic tropical differential inclusions, formalize the a.e. chain rule and all-time uniformity, exact higher-d verifier with bounded bit sizes, measured test networks, and stochastic/spatial extensions without invalidly transferring deterministic guarantees.

## Primary sources

* Source snapshot: https://github.com/harjassand/astra-research-knowledge/tree/ca22fffaeab073aaa1bbb690ce1b4250fc272956
* Full inherited N33 original: https://github.com/harjassand/astra-research-knowledge/blob/ca22fffaeab073aaa1bbb690ce1b4250fc272956/web/pages/d-326696af15b5e02b.html
* Original OA149 affine proof: https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/build/sections/affine.tex
* Original OA149 permanence: https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/build/sections/permanence.tex
* Two-species variable-k endotactic: Craciun-Nazarov-Pantea 2013 doi:10.1137/100812355
* Strongly endotactic all-d: Gopalkrishnan-Miller-Shiu 2014 doi:10.1137/130928170
* Two-dimensional tropically endotactic: Brunner-Craciun 2018 doi:10.1137/17M1133762
* Endotactic toric differential inclusion embedding: Craciun-Deshpande 2020 doi:10.1137/19M1269312

**Research state:** conditional exact deduction and finite checks only. No field-breaking historical breakthrough has been established.
