# Astra frontier continuation: uniform logarithmic-valuation permanence

**Session:** 2026-10-08 (Brisbane)  
**Repository:** `harjassand/astra-research-knowledge`  
**Read-only base revision:** `ca22fffaeab073aaa1bbb690ce1b4250fc272956`  
**Status:** New source-conditioned theorem candidate, a complete mathematical proof modulo the source's affine-approximation lemma, exact-arithmetic verified finite checker, and a sharp boundary-face counterexample. **No independent expert review, proof-assistant certificate, exhaustive priority search, or experimental validation.** Single-agent mathematical derivation; numerical/exact diagnostics are not external validation.

## 1. Selection and provenance

Three unusually promising mechanisms considered from the pinned repository:

1. **Astra N33** / OpenAI family 149: all-dimensional common compact absorber for endotactic generalized power-law networks. The decisive mechanism is a fixed finite affine-minimum family whose active slopes track the logarithmic exponent direction even with a discontinuous, slope-dependent tolerance; combine a dominant inward projected flux with a compact plateau and nonnested scale absorption. Existing N33 is an unreviewed research candidate, not a certified theorem.
2. **Collective-spin Lindbladian critical bath** (`state/2026-10-08-square-root-bath-occupation-threshold.md`): stationary full-SEP distance equals 1 or 0 outside `nu_N ~ sqrt(N)`; at critical scaling the sector birth-death chain limits to a selected Wright–Fisher diffusion. Intrinsic distance to full SEP at `nu_N = gamma sqrt(N)` remains open. The source's `gamma ~ 0.328` is a *witness* crossing, not the separability threshold.
3. **Family 197 Bernoulli/direct-finiteness**, with a source-conditional proper shift self-embedding and entropy inequality. Does not settle measurable Bernoulli conjugacy. Formanek's existing all-fields trivial-idempotent theorem blocks a torsion-free hyperbolic non-directly-finite group ring, unlike a hyperbolic nonsofic group with no such ring witness.

Pursued 1 because it has a proof mechanism with a sharp and previously unexploited interface: **multiplicative rates need not remain comparable to monomials; only their uniform logarithmic orders need to converge.** This is stronger than the *positive-rational* rate result already present in `state/2026-10-08_positive-rational-tropical-permanence.txt` (which only assumes two-sided constant multiples of powers at each scale).

## 2. Candidate main theorem (all dimensions)

Fix a finite set of nonzero reaction vectors `nu_e in R^d`, and write `S=span_R{nu_e}`. On the positive orthant consider the Carathéodory dynamics

\[
 \dot x(t) = \sum_{e\in E} \nu_e\, w_e(t,x(t)),\qquad w_e(t,x)>0.
\]

Assume uniform local Carathéodory existence/uniqueness hypotheses: measurability in `t`, continuity and uniform local Lipschitz control in `x` on each positive compact set, sufficient for well-posedness. Rates may be chosen from a family `F` of admissible time paths/kinetic functions, but the following convergence bound is **uniform over the entire family**. There are continuous functions `tau_e:[-1,1]^d -> R` and `epsilon(h) -> 0` as `h downarrow 0` with

\[
 \sup_{f\in \mathcal F}\ \sup_{e\in E}\ \sup_{t\ge 0}\ \sup_{p\in[-1,1]^d}
 \left|\frac{\log w_e(t,h^{p_1},\ldots,h^{p_d})}{\log h}
 -\tau_e(p)\right| \le\epsilon(h). \tag{UV}
\]

(The supremum over `f` means across all admissible choices of the rates, not merely a single trajectory.) Define the *relevant* edges `E_r={e:r dot nu_e !=0}`. Suppose for every `r in [-1,1]^d` with `E_r` nonempty, **every** edge attaining

\[
 m(r)=\min_{e\in E_r}\tau_e(r)
\]

has `r dot nu_e >0`. Call this **strict tropical essential inwardness** (TE). The check includes all boundary faces where some `r dot nu_e=0`; checking generic directions is insufficient.

**Claim.** Subject to the validity of the affine-minimum approximation lemma in the cited OpenAI family-149 manuscript, `(UV)+(TE)` imply: for each positive stoichiometric class `P=(c+S) cap R^d_{>0}`, there exists a nonempty compact convex set `K_P subset P`, independent of the initial state and admissible kinetic path, forward invariant for every permitted path, such that each positive trajectory enters `K_P` in finite time. The entry bound may depend on the initial state, but can be chosen uniformly over admissible paths. Consequently all coordinates eventually lie within one class-dependent interval `[delta_P,delta_P^{-1}]`.

If `S={0}`, the statement is immediate with `K_P={c}`.

This is **not** a claimed unconditional resolution of a historically open problem: the proof uses the unreviewed source family-149 lemma, and neither peer review nor exhaustive historical priority has occurred. It is nevertheless formulated as an exact, falsifiable result with explicit assumptions and proof obligations.

### Proof reconstruction

**Affine family and pointwise tolerances.** For each `r` with `E_r` nonempty, choose an edge `e_+(r)` attaining `m(r)`. By TE, `r dot nu_e+>0`. Every *negative-projection* edge `e` satisfies `tau_e(r)>tau_e+(r)` (otherwise it would be a negative minimizer). Continuity and finiteness give a radius `a(r)>0` and `g(r)>0` such that

\[
 \tau_e(p)-\tau_{e_+(r)}(p)>g(r)
 \quad \text{for every }e\text{ with }r\cdot\nu_e<0,
 \ \|p-r\|_\infty<a(r).
\]

When there is no negative edge, this restriction is vacuous. Independently, choose the tolerance less than `|r_i|/2` for every nonzero coordinate `r_i`. For `r in S^perp`, only the coordinate tolerance is required. Choose in every case `0<E(r)<=1/2`. The arbitrary-positive-tolerance affine lemma furnishes **one finite, h-independent** set `Lambda` of labels `(r_lambda,b_lambda(h))` such that every label active in

\[
 F_h(x)=\min_{\lambda\in\Lambda} (r_\lambda\cdot x+b_\lambda(h))
\]

at `x=h^p` for `p in [-1,1]^d`, and sufficiently small `h`, obeys `||p-r_lambda||_infty<E(r_lambda)`. Crucially `E` need not be continuous or bounded below over all slopes. The *selected finite* slopes are the only ones to which uniform lower gaps must subsequently be applied.

**Dominant projected flux.** Fix an active slope `r notin S^perp`, its selected `e+`, and an active point `x=h^p`. By finite-family compactness there are constants `g_0>0`, `a_0>0`, `B<infinity` independent of this label and of admissible rate paths, with `r dot nu_e+ >= a_0` and `sum_e |r dot nu_e| <=B`. From `(UV)`, for every negative edge and sufficiently small h,

\[
 \frac{w_e(t,h^p)}{w_{e_+}(t,h^p)}
 = h^{\tau_e(p)-\tau_{e_+}(p)+\theta_e-\theta_{e_+}}
 \le h^{g_0/2}.
\]

The whole negative flux is bounded by `B h^{g_0/2} w_e+`, while the selected positive flux is at least `a_0 w_e+`. Taking h smaller makes

\[
 r\cdot\dot x \ge (a_0/2) w_{e_+}(t,h^p)>0.
\]

All functions tau are bounded on the compact exponent cube, so `(UV)` also gives a **uniform fixed-scale** bound `w_e+(t,h^p) >= h^M` for some finite `M>=1` independent of the admissible rate path and active label. Hence

\[
 r\cdot\dot x \ge \delta_h:=(a_0/2)h^M>0
 \quad (r\notin S^\perp),
 \qquad r\cdot\dot x=0\quad (r\in S^\perp). \tag{drift}
\]

This proof is a direct *rate-order* reconstruction and does not invoke the inherited N33 monomial-source comparison. The only borrowed geometric mechanism is the affine lemma plus the elementary plateau construction (spelled out next).

**Global plateau.** Fix any positive `c in P`. At h sufficiently small, `p_c=log(c)/log(h)` is arbitrarily close to zero, so the coordinate-tolerance guarantee prevents a nonzero affine slope from being active at `c`. Thus some active affine label has slope zero. Put `M_h=F_h(c)`. Then `F_h<=M_h` everywhere and the plateau

\[
 K_h=\{x:F_h(x)=M_h\}=\bigcap_\lambda\{x:r_\lambda\cdot x+b_\lambda(h)\ge M_h\}
\]

is closed, convex, contains `c`, and is compact: any plateau point inside `B_h=[h,h^{-1}]^d` has an active zero label, forcing `||p||_infty<E(0)<=1/2` and hence lies in `int B_{sqrt(h)}`. Convexity then rules out plateau points outside `B_h` (their segment to c would meet the forbidden boundary), proving `K_h subset int B_{sqrt(h)}`. For `x in P\K_h`, no slope in `S^perp` can be active, since its affine value is constant along the class and at least `M_h`.

**Monotonicity and scale absorption.** Along any absolutely continuous solution inside `B_h`, `F_h(x(t))` is absolutely continuous with a.e. derivative equal to the minimum `r dot xdot` over *all* active slopes. The drift estimate makes it nondecreasing and makes its derivative at least `delta_h` outside `K_h` in the class. Compactness of `B_h` gives a uniform finite entry bound `W_h=(M_h-min_{B_h}F_h)/delta_h`. A path starting in `K_h` cannot exit it, because `F_h` cannot increase beyond `M_h`, and it cannot leave `B_h` while in the strictly interior plateau. This also yields global existence and positivity via compact continuation.

Every positive initial x0 lies in `K_{h0}` if h0 is sufficiently small (the same coordinate-zero-label reasoning). Form a finite sequence `h_{j+1}=min(sqrt(h_j),h_P)` ending at a fixed class-dependent hP. Since `K_{h_j} subset B_{sqrt(h_j)} subset B_{h_{j+1}}`, inductive finite entry proves eventual residence in `K_{hP}`. **The plateaux need not be nested**. Finally `K_P=K_{hP} cap (c+S)` is the common compact convex absorbing set. QED conditional on the cited affine lemma and the hypotheses.

## 3. Strictly enlarged physical/mathematical rate class

The theorem includes the inherited positive-rational kinetics `w_e=k_e(t) P_e(x)/Q_e(x)` with positive generalized-polynomial P_e,Q_e and rate coefficients in common positive compact intervals. Its tropical orders are

\[
 \tau_e(p)=\min_{\alpha\in\operatorname{supp}P_e}\alpha\cdot p
 -\min_{\beta\in\operatorname{supp}Q_e}\beta\cdot p.
\]

Moreover, choose *arbitrary fixed real* `c_e` and deform them to

\[
 w_e(t,x)=k_e(t)\frac{P_e(x)}{Q_e(x)}
 \exp\{c_e(1+\textstyle\sum_i(\log x_i)^2)^{1/4}\}.
\]

For `L=-log h`, `x=h^p` and `p in [-1,1]^d`, the new term in the logarithmic valuation is at most

\[
 |c_e|\frac{(1+dL^2)^{1/4}}{L}=O_d(L^{-1/2})\to0.
\]

The positive polynomial coefficient bounds contribute only `O(1/L)`. Hence `(UV)` still holds with the same tau. For `c_e !=0`, the multiplicative correction is unbounded (or approaches zero) along nonzero log-exponent directions. Therefore the class genuinely exceeds the inherited `c h^{tau} <= rate <= C h^{tau}` envelope and is not the previous rational lifting in disguise.

Concrete example: the `n,m` Hill-repression toggle with independent positively bounded time-varying coefficients,

\[
 \dot x=\frac{a_x(t)\,\xi_1(x,y)}{1+y^n}-d_x(t)x\,\xi_2(x,y),\qquad
 \dot y=\frac{a_y(t)\,\xi_3(x,y)}{1+x^m}-d_y(t)y\,\xi_4(x,y),
\]

where each `xi_e=exp(c_e(1+log^2 x+log^2 y)^{1/4})`, meets `(UV)+(TE)` for all positive integers `n,m` and all finite c_e. For any direction with a negative component, its corresponding degradation term has negative tropical order and positive projected drift; for a direction with no negative components, a relevant production term at order zero points inward. All equality/boundary cases are included. The resulting uniform *mathematical* permanence is not a biological validation of the model or its parameters.

## 4. Exact finite tropical certificate for positive-rational sparse input

Suppose all exponent supports and reaction vectors are rational. Enumerate every possible difference `alpha-beta`, one per numerator/denominator monomial pair, from every reaction. Add hyperplanes perpendicular to `nu_e` and every nonzero difference between any two such difference vectors. This is an over-refinement: on each relative-open face of the resulting **central rational hyperplane arrangement**, ordering of all numerator exponents, denominator exponents, pairwise differences, and signs `r dot nu_e` is constant. Consequently the relevant set, exact minima of tau_e, and projected signs are constant on that face. It suffices to check one exact rational point from **every face, including lower-dimensional faces** (or one of each antipodal direction where appropriate). For each fixed dimension `d`, the number of faces, bit complexity of face representatives, and exact arithmetic are polynomial in the sparse rational input size; the exponent of that polynomial depends on d. There is **no dimension-uniform polynomial complexity statement**, nor a polynomial algorithm for acquiring the affine absorber.

Implementation provided here: `tropical_check_2d.py`, a dependency-free exact `fractions.Fraction` checker enumerating rays and open wedges of the induced rational line arrangement in d=2. Positive coefficients are immaterial to the sign certificate once known positive. `verify_bridges.py` independently checks the decision logic against grid-rational directions and the lifted common-denominator source minimum identity.

**Exact falsifier to generic-directions-only checking.** Consider three mass-action edges

\[
 0\to Y,\quad 2Y\to Y,\quad X+Y\to Y
\]

with unit rates and concentrations x,y:

\[
 \dot x=-xy,\quad \dot y=1-y^2.
\]

For initial `y(0)=1`, the exact solution is `y(t)=1`, `x(t)=x(0)e^{-t}`. Hence the system is **not persistent**. Yet condition `(TE)` holds for every `r=(r_x,r_y)` with `r_y !=0`. If `r_y>0`, an outward edge cannot beat both the `0->Y` production edge and (when `r_x<0`) the `X+Y->Y` inward loss edge. If `r_y<0`, either `2Y->Y` or `X+Y->Y` supplies an inward minimal edge. The criterion fails **only** for `r=(r_x,0)` with `r_x>0`, because only `X+Y->Y` is relevant and `r dot nu<0`. Thus an algorithm inspecting only generic directions (even all open sectors) wrongly accepts this extinctive example. This is an exact mathematical counterexample to that *algorithmic shortcut*, not to the stated all-face theorem.

## 5. Reproducible checks: scope and limitations

Run with Python 3.11+ (stdlib only):

```
python tropical_check_2d.py
python verify_bridges.py
```

- The exact 2D checker accepts the Hill toggle (`24/24` face directions) and rejects an autocatalytic loss system; it rejects the boundary-only example at exactly `(1,0)` while **all its open sectors pass** (`16` face directions, 4 distinct hyperplane normals).
- Repeated independent rational-identity check across **200** seeded random sparse rational networks: **33,840** exact identities verifying the common-denominator lift, and **16,000** independent exact rational-direction comparisons with the first checker.
- The explicit logarithmic subpower deformation has an analytic uniform distortion bound; at `L=10000,d=2,c=3`, bound `0.03567621` (illustration of asymptotic, not proof).

These tests verify code/finite algebra only; they **do not computationally prove permanence**, replay the entire original geometric proof, establish complexity of a practical absorber synthesizer, or certify novelty.

## 6. Novelty boundary, dependencies, blockers and next steps

**Dependencies:** (i) *OpenAI*, `Uniform Permanence in Weakly Reversible Mass-Action Systems` (Oct 5 2026), especially the affine approximation and uniform-activity lemma, pinned source `adc7f1241b42e322a6451854ab7e4b4c146bf78a`; (ii) elementary positive-domain Carathéodory ODE continuation, finite minimum chain rule, finite hyperplane arrangement; (iii) N33/Astra reconstructed plateau mechanism. In contrast to N33, the new projected drift uses only rate-order separation, not monomial source-level comparison. In contrast to the Oct 8 existing Astra rational-rate note, the log-valuation extension allows **unbounded subpower factors**.

**Historical literature actually consulted:** Craciun–Nazarov–Pantea (SIAM J Appl Math 2013), 2D endotactic/power-law variable-κ permanence; Gopalkrishnan–Miller–Shiu (SIAM J Appl Math 2014), strongly endotactic arbitrary dimension; Brunner–Craciun (SIAM J Appl Math 2018), 2D tropically endotactic polynomial/power-law systems; Craciun–Deshpande (SIAM J Appl Dyn Syst 2020), endotactic embedding into toric differential inclusions; OpenAI Oct 2026 family 149. The primary abstracts and available original proof were inspected, but this is **not exhaustive priority clearance**. The rational denominator-clearing idea is an existing Astra result and a standard algebraic transformation. Fixed-d arrangement enumeration is standard computational geometry. No specific claim of historical first discovery is made.

**Unresolved obligations (descending priority):**

1. External mathematician to verify OA149's arbitrary-tolerance affine lemma including boundary sequences/ties, and independently check N33 plateau/finite-entry argument; current work is internal model self-verification.
2. Search earlier general-kinetics differential-inclusion and asymptotically monomial permanence theorems, including equivalent conditions under different naming; distinguish any overlap before announcing novelty.
3. Formalize lemma, full drift and plateau chain in Lean; particularly uniform quantifiers over arbitrary measurable time paths and regularity/existence.
4. Build an exact d-dimensional face-enumeration verifier with explicit rational bit-size and certified face samples, benchmark against equally-informed CRNT MILP/siphon/concordance certificates on actual BioModels or SBML systems; charge input acquisition, expression parsing, rational approximation and uncertainty boxes.
5. Derive numerical finite-size absorber/entry bounds from a constructive affine compiler. The source lemma is currently existential, with no practical label-count/precision bound. No experimentally actionable quantitative concentration bound follows without it.
6. Investigate stochastic jump and spatial reaction-diffusion extensions separately. Neither is implied by deterministic permanence; phenomenological Hill factors do not automatically supply physical molecular jump propensities.

**Interpretation:** This is a mathematically explicit new conditional **transfer principle** for robust all-dimensional permanence, with an exact obstruction to an attractive but invalid generic-direction shortcut. Its high potential significance depends primarily on certifying the inherited endotactic proof and establishing novelty relative to the general-kinetics literature. No field-breaking breakthrough, independent peer review, or practical capability is claimed as already accomplished.

## 7. Exact reference pointers

- Astra snapshot: `https://github.com/harjassand/astra-research-knowledge/tree/ca22fffaeab073aaa1bbb690ce1b4250fc272956`
- Entry and core: `00_START_HERE.txt`, `01_CORE.txt` at pinned commit.
- Primary Astra claims: `cards/N33-endotactic-permanence.txt`; full original source `web/pages/d-326696af15b5e02b.html` (first 30k characters contain theorem, lemma, drift, plateau and scale proof); prior rational extension `state/2026-10-08_positive-rational-tropical-permanence.txt`.
- Original OpenAI affine lemma: `https://raw.githubusercontent.com/openai/math/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/build/sections/affine.tex`
- Original OpenAI absorption: `https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/build/sections/permanence.tex`
- Classical 2D endotactic permanence: `https://doi.org/10.1137/100812355`
- Strongly endotactic: `https://doi.org/10.1137/130928170`
- 2D tropically endotactic: `https://doi.org/10.1137/17M1133762`
- TDI embedding: `https://doi.org/10.1137/19M1269312`
- The unrelated collective-thermal critical lead: `state/2026-10-08-square-root-bath-occupation-threshold.md` and `state/2026-10-08-thermal-character-temperature-scaling/RESULT_AND_RESTART.md`.
