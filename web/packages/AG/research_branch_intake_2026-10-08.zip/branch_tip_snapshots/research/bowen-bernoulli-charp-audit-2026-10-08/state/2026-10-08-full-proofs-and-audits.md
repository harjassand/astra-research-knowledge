> **GROUP-THEORY CORRECTION (2026-10-08):** Section B's purported proof that torsion-free hyperbolic F_2 group rings are directly finite via Formanek is unsupported by its cited primary sources. The subsequent alleged obligatory BS(1,2^k) subgroup also lacks that premise. Preserve Section B as a failed citation transfer, NOT an impossibility proof. See [corrected audit](2026-10-08-bowen-bernoulli-direct-finiteness/CORRECTED_AUDIT.md). Other sections, including independent quantum derivations, are not adjudicated by this note.

# Astra research continuation — 2026-10-08

**Status:** independent mathematical derivations and exact finite certificates; **not external peer review or certified priority**. Source instructions remain source data. Do not promote Astra card status solely because of this document. No autonomous independent workers were available; independent *methods* were used (group-ring algebra, quantum block dynamics, rational arithmetic, direct Lindblad integration, and adversarial numerics).

## A. Inputs, route, and frontier selection

- Repository: `harjassand/astra-research-knowledge`, default branch `main`, read 2026-10-08. Entry files `00_START_HERE.txt` (SHA b8e71d9c13876e0e4d5719d08b230cd7a4bfeffd) and `01_CORE.txt` (SHA dad3d06fe3916e5f8df8b9b620db5dae37f85ef4), `agent/RESEARCH_WORKFLOW.txt`.
- Deep source cards: N129 hyperbolic direct finiteness; N130 stationary singleton separability; N131 local anti-concentration; N132 relative entropy; N133 finite-time thermal PPT; N134 heralded distillation; N135 noise; N120 collective thermalization; N71/N72 spectral Gaussian simulation; N51 rational noncommutative hitting sets; N46 compact classicality; N117 all-N Gibbs separability. Contrasted their premises, source-reported checks, and acquisition blockers.
- Primary OpenAI source: `openai/math/preprints/A-Torsion-Free-Group-Algebra-That-Is-Not-Directly-Finite-October-4-2026/build/sections/{introduction,topology,algebra}.tex`, inspected original graph/cone and characteristic-2 parity mechanism. Main torsion-free claim is manuscript-scope, not formalized here.
- Established external article: Bartels–Lück–Reich, *On the Farrell-Jones Conjecture and its applications*, p. 9, `https://www.mi.fu-berlin.de/math/groups/top/members/publ/blr-appl.pdf`, reports Formanek's theorem in arbitrary characteristic and explicit torsion-free hyperbolic corollary. Formanek, *Idempotents in Noetherian Group Rings*, *Canadian J. Math.* **25** (1973) 366–369, DOI 10.4153/CJM-1973-037-6.
- Literature cross-check: Merkli–Berman–Sigal, *Dynamics of Collective Decoherence and Thermalization* (2008), `https://arxiv.org/abs/0804.0243`; an adjacent general class, **not a duplicate priority clearance**. Li–Xu 2005 collective model credited within N130. Nonlinear spin/coupling and physical bandwidth/precision not addressed.
- Three promising lines attacked: group-ring geometry (decisive impossibility + necessary subgroup), finite-time thermal multipartite entanglement (new rational counterexample), and exact mixing scaling/algorithms (proofs below). Gaussian-sampling cubic loss N71/N72 and noncommutative PIT N51 were reviewed but did not overtake the thermal line because unresolved practical oracle/compiler interfaces and source verification cost are larger.

## B. A proof-level obstruction: N129's torsion-free hyperbolic target is impossible

Let `G` be torsion-free, `F` any field. If `a,b` in `F[G]` have `ab=1` and `ba != 1`, then `e=1-ba` is an idempotent strictly between `0` and `1`: `e^2=1-2ba+b(ab)a=1-ba`. If `e=1` then `ba=0`, hence `a=aba=0`, absurd. If `e=0` then `ba=1`, excluded.

For a torsion-free word-hyperbolic `G`, Formanek's theorem as explicitly recorded on page 9 of Bartels–Lück–Reich forbids every such proper idempotent over fields of *all* characteristics. Therefore no torsion-free word-hyperbolic group admits an F2-group-ring counterexample to direct finiteness. **The hyperbolic conclusion of N129 must be withdrawn, not just flagged as an unresolved proof gap.** This does not decide groups with torsion or possible errors in the separate torsion-free (not hyperbolic) OpenAI manuscript.

**Required characteristic-p geometry (a corollary of Formanek, not claimed original):** If `G` is torsion-free and `F_p[G]` has a proper idempotent/non-directfinite, then there exist `1!=g in G`, `t in G`, `k>=1` with `tgt^-1=g^(p^k)` (up to conjugator orientation). Thus `G` contains a subgroup isomorphic to `BS(1,p^k)`. To show injectivity of the homomorphism `BS(1,m)=Z[1/m] ⋊ Z -> G`, note the additive base is the increasing union of conjugates `t^-r <g> t^r`; every nonzero base element maps to a nontrivial conjugate of `g^n`, since `g` has infinite order. If a kernel element has nonzero `Z`-exponent `n`, normality/commutator with the base and the relation imply `g^(m^n-1)=1` (after clearing denominators), impossible for infinite-order `g`. Hence the whole map is injective. In particular, conditional on family197's torsion-free main theorem, its group contains `BS(1,2^k)` for some `k>=1`; identifying explicit words or `k` remains open. The group cannot be torsion-free hyperbolic, and no routine small-cancellation hyperbolic upgrade is possible.

**Failed route preserved:** The original N129 graph surgery and random count need not be false locally. However *their conjunction with the claimed hyperbolic conclusion* is inconsistent with an established theorem, so further random-graph auditing cannot validate that intended target. The structural failure must be located in those hypotheses or deductions. N47's earlier withdrawn Farrell–Jones trace conflict is distinct from the Formanek contradiction.

## C. Exact finite counterexample to all-time singleton PPT

Work with `N=3` qubits and dimensionless time `s=Gamma*t`, ideal generator

```
  d rho/ds = (nu+1) D[J_-](rho) + nu D[J_+](rho),
  rho(0)=I/8,   D[L](rho)=L rho L^dagger - {L^dagger L,rho}/2.
```

Set `nu=3/20`, `s=5/2`. The state remains permutation-invariant and can be reconstructed using the two Schur spin sectors `j=3/2,1/2`. Let `p_M(k;s)` be the evolved uniform `M+1`-level birth-death probability at level `k` for `M=2j` (generator in section D). In excitation-number block `k=0,...,3` with dimension `d_k=binom(3,k)`, write `P^+_k` for the rank-one all-ones projector `ones(d_k)/d_k`; for `k=1,2`, write `P^-_k=I-P^+_k`. Then

```
 rho(s)|_k = [p_3(k;s)/2] P^+_k
             + [p_1(k-1;s)/4] P^-_k  (second term only for k=1,2).
```

Take computational basis indices `0,...,7`, first qubit as highest bit. The integer vector `v=(0,1,1,0,0,0,0,14)` satisfies exactly

```
  6 v^T rho(s)^(T_first) v
    = 4 p_3(1;s) + 56 p_3(2;s) + 588 p_3(3;s)
      + p_1(0;s) - 28 p_1(1;s).
```

**Exact rational sign certificate:** In either sector take generator `Q_M` as in D, rational stochastic `P_M=I+Q_M/6`; maximum total exit rate among `M=1,3` is below `6`. Then

```
  exp(s Q_M)u_M = exp(-15) sum_(n>=0) (15^n/n!) P_M^n u_M.
```

For each `M=1,3`, truncate at `n=90` and work entirely in `fractions.Fraction`. The resulting unnormalized quadratic form is a **strictly negative rational number** `q90`, whose decimal for orientation is `-43962.50188217626`. The absolute contribution of omitted terms is at most `||v||² R=198R`, with

```
 R <= (15^91/91!)/(1-15/92) < 9.346 * 10^(-34),
 198R < 1.851 * 10^(-31) << -q90.
```

The bound follows because every normalized stochastic iterate is a density matrix and `||rho^(T_A)||_op <= ||rho||_2 <= 1` (partial transpose preserves Hilbert-Schmidt norm). Thus the actual finite-time partial transpose has a negative Rayleigh quotient: **NPT**. A completely independent `64x64` Lindblad-superoperator `expm` integration (no Schur decomposition) agrees with the 8x8 Schur state to `3.34e-16` maximum entry error and gives minimum PT eigenvalue about `-6.981503154825615e-05`. These numerical values are supporting checks; the fraction inequality certifies the sign.

At stationarity `q=nu/(nu+1)=3/23`, `p_M(k;∞)=q^k/(sum_(r=0)^M q^r)` is rational. The exact stationary 8x8 first-qubit partial transpose has **all eight leading Sylvester principal minors strictly positive**, so the stationary state is PPT across every singleton cut (permutation invariance); at `s=0`, the initial `I/8` is also strictly PPT. Hence PPT -> NPT -> PPT as time increases. This disproves the conjectured all-time version of N130's **stationary** singleton-PPT threshold, but **does not contradict N130 or N133 as actually stated**. It does not show finite-time bound entanglement, quantum computational advantage, or a useful entanglement yield.

Code: `certify_thermal_npt.py` contains rational certificate and Sylvester checks; `crosscheck_lindblad.py` gives independent superoperator integration; `thermal_pt_experiment.py` and `pt_scan.py` are exploratory and can be discarded after retaining exact certificate. Realizing the same dynamics physically requires collective-jump calibration and timing; detection margin order `7e-5` is very small, implying naive independent bounded-observable statistics on the order of `10^8`–`10^9` or greater shots for high confidence before correlated noise and detector overhead.

## D. Sharp rare-sector relaxation theorem (self-contained mathematical derivation)

**Theorem D1.** Fix any finite `nu>0` and `s>0`. For ideal `N`-qubit dynamics above with maximally mixed initial state and its selected sector-preserving stationary state `rho_N(∞)`, define `D_N(s)=(1/2)||rho_N(s)-rho_N(∞)||_1`. Write `r=N mod 2`. Then, as `N->infinity` through parity `r`,

```
 lim N^(3/2) D_N(s)
    = 2 sqrt(2/pi) * sum_(M>=1, M==r mod2) (M+1)^2 d_M(s)
    =: C_(r,nu,s) in (0,infinity),
```

where `d_M(s)= (1/2)||exp(s Q_M)u_M - pi_M||_1`, `u_M` uniform, `pi_M(k)=q^k/(sum_(i=0)^M q^i)`, `q=nu/(nu+1)`, and `Q_M` is tridiagonal birth-death generator with `k->k+1` rate `lambda_k=nu(M-k)(k+1)` and `k->k-1` rate `mu_k=(nu+1)k(M-k+1)`. Consequently `D_N(s)=Theta_(nu,s,r)(N^(-3/2))` for both parity subsequences.

**Proof.** The Schur-Weyl decomposition has spin `j=M/2`, multiplicity `m_(N,M)=binom(N,(N-M)/2)-binom(N,(N-M)/2-1)` and total sector weight

```
 w_(N,M) = ((M+1)^2/(N/2+M/2+1)) * binom(N,(N-M)/2)/2^N.
```

Under the initial maximally mixed state, each spin sector starts with `u_M`, multiplicities remain maximally mixed, and the blocks have orthogonal supports; hence **exactly** `D_N(s)=sum_M w_(N,M)d_M(s)`.

To bound `d_M(s)` for large `M`, let `tau_0` be the first hitting time of level `0`. Standard skip-free birth-death recurrences yield for starting level `x`:

```
 E_x tau_0 = sum_(k=1)^x [sum_(i=k)^M pi_i]/[mu_k pi_k]
           = sum_(k=1)^x (1-q^(M-k+1))/[k(M-k+1)]
           <= 2 H_M/(M+1) =: A_M.
```

In particular the expectation is bounded uniformly in starting `x`. By Markov at `2A_M` and successive strong-Markov restarts, for all `s>0`,

```
  sup_x Pr_x(tau_0>s/2)
    <= 2 exp[-(ln2)*s*(M+1)/(8H_M)].
```

For mixing after the first visit to `0`, compare the sector Dirichlet form to a reversible reflecting birth-death chain with constant up-rate `nu*M` and down-rate `(nu+1)*M`, preserving the same geometric stationary distribution. Every actual edge rate is at least the comparison edge rate since `(k+1)(M-k)>=M`. The comparison chain's spectral gap is at least `c_nu*M`, `c_nu=(sqrt(nu+1)-sqrt(nu))²>0`. The initial chi-square divergence of `delta_0` from `pi_M` is at most `nu` because `1/pi_M(0)-1<=nu`. Therefore after `s/2` from state `0`, the TV distance is at most `(sqrt(nu)/2) exp(-c_nu*M*s/2)`. Using the Markov property at `tau_0` and contraction thereafter gives

```
 d_M(s) <= 2 exp[-(ln2)*s*(M+1)/(8H_M)]
            + (sqrt(nu)/2) exp[-c_nu*M*s/2].          (BOUND)
```

This is summable with any fixed polynomial weight in `M` at every fixed `s>0`, because `H_M~ln M`. Stirling/local central binomial give for each fixed admissible `M`,

```
  N^(3/2) w_(N,M) -> 2 sqrt(2/pi)*(M+1)^2.
```

Uniformly in admissible `M<=N`, the elementary `central_binomial <= C 2^N/sqrt(N)` gives `N^(3/2)w_(N,M)<=C'(M+1)^2`. The BOUND and dominated convergence establish the formula. The constant is positive: for every `M>=1`, `u_M!=pi_M` when `nu` is finite and the invertible finite-dimensional matrix `exp(sQ_M)` cannot map the initial nonstationary vector exactly to `pi_M` at finite `s`. Both parity families contain such a block. QED.

**Corollary D2 (optimal order of trace-distance thermalization).** For every fixed `nu>0`, `eps in (0,1)`, the mixing time of this *particular maximally mixed input*, not a worst-case quantum-state mixing time,

```
 T_(N,eps)=inf{s : D_N(s)<=eps}
             = Theta_(nu,eps)(log N/sqrt N).
```

*Upper bound:* the total Schur weight of `M<a sqrt N` is `O(a^3)` by the explicit weight formula. On `M>=a sqrt N`, insert `s=C log N/sqrt N` into BOUND; the first term is <=`2 exp(-Omega(a C))`, the second tends to zero. Choose `a` small enough for residual <eps/2, then `C` large enough for remainder <eps/2.

*Lower bound:* under Schur weights, `M/sqrt N` converges to Maxwell density `f(x)=sqrt(2/pi)*x² exp(-x²/2)` on `(0,infty)`. Choose a compact band `[a,b]` of mass as near 1 as desired. Conditioned on any `M` in this band, all except an arbitrarily small fraction of the uniform initial levels have `k(0)>=delta M`. Couple the original level process from below by a *pure-death* process whose per-particle death rate is `(nu+1)M`: original downward rate is <=`(nu+1)Mk` and upward transitions only increase the level. This pure death has `Binomial(k(0),exp(-(nu+1)Ms))` survivors. At time `s=c log N/sqrt N` with fixed `c<1/[2(nu+1)b]`, its expected survivors from those initial levels diverges as a positive power of `N`; with high probability the actual level exceeds any fixed `K`. In contrast the geometric stationary law places mass `1-q^(K+1)+o(1)` on levels `0,...,K`. Taking a small initial-level excluded fraction, large fixed `K`, and a band of weight near 1, one obtains `D_N(s)>eps` for every fixed eps<1 and suitably small c. The stronger consequences are `D_N(s_N)->1` if `s_N=o(log N/sqrt N)`, and `D_N(s_N)->0` if `s_N >> log N/sqrt N`. The constants for ε-thresholds are not shown to coincide; **no classical cutoff in the technical mixing-time sense is asserted**. QED.

*Physical rate scaling:* if the Lindblad operators are conventionally divided by `sqrt N` while Γ remains fixed, all dimensionless times gain a factor `N`; the input-specific physical mixing scale becomes `Theta(sqrt N log N)/Gamma`, not `Theta(log N/sqrt N)/Gamma`. Also no exact finite-time PPT follows from a polynomial trace-distance error because minimum PT eigenvalues can shrink exponentially with N.

## E. Explicit Maxwell crossover at zero bath temperature

**Theorem E1.** Extend only the **relaxation** calculation to zero temperature `nu=0` (not the N130 stationary singleton-PPT claims). For every fixed `c>0`, set `s_N=c logN/sqrt N`. Then

```
 lim_(N->infinity) D_N(s_N)
   = F_Maxwell(1/(2c))
   = erf(1/(2 sqrt(2)c)) - sqrt(2/pi)*(1/(2c))*exp(-1/(8c²)).
```

This limit holds along both parity sequences. It is a **nontrivial, continuous mixing profile**, not a Heaviside cutoff. Proof: at `nu=0`, each sector is a pure-death chain with rates `r_k=k(M-k+1)` and absorbing state 0, so `d_M(s)=Pr_(uniform initial level)(tau_0>s)` exactly. For initial level `x`, `tau_0` is the sum of independent exponential holding times `E_k~Exp(r_k)` for `1<=k<=x`. Thus

```
 E_x tau_0 = (H_x+H_M-H_(M-x))/(M+1),
 Var_x(tau_0) = sum_(k=1)^x 1/[k²(M-k+1)²].
```

Uniformly for `x/M` in any compact subinterval of `(0,1)`, the mean is `(log M+O(1))/M` and variance `O(M^-2)`. Chebyshev shows `M tau_0/log M->1` in probability for a uniform initial level (boundary fractions made arbitrarily small). Therefore `d_M(alpha logM/M)->1` if `alpha<1` and `->0` if `alpha>1`. If `M/sqrt N->x>0`, `M*s_N/log M->2cx`, so the sector TV tends to `1_(x<1/(2c))`. Schur weights converge weakly to Maxwell density `sqrt(2/pi) x² exp(-x²/2)`. Dominated convergence for triangular arrays and continuity of Maxwell measure yield the stated CDF. QED.

**Status boundary:** An exact positive-temperature Maxwell profile is a promising hypothesis, not established here. D2 proves the *scale* for each fixed ν>0. Developing a uniform concentration theorem for finite-temperature birth-death hitting times is the needed missing lemma to transfer E1 to ν>0.

## F. Independent checks, useful algorithms, and costs

- `certify_thermal_npt.py`: **executed**, exact `fractions.Fraction` rational certificate N3, ν3/20, s5/2, Poisson tail and all eight positive stationary Sylvester minors. The truncated unnormalized witness is about −43962.50, omitted witness contribution <1.851e−31.
- `crosscheck_lindblad.py`: **executed**, 64x64 full Lindbladian `expm`, max entry difference vs independently assembled Schur rho <3.34e−16, PT eigenvalue ≈−6.981503154825615e−5.
- `verify_rare_sector_bounds.py`: **executed**, 140 finite tridiagonal exact-matrix-exponential checks for `nu in {.01,.2,1,10}`, `M in {1,2,3,4,8,16,24}`, `s in {.01,.1,.5,1,2.5}`; stochasticity, hitting upper bound, sector TV bound passed. Parity coefficient partial-sum estimates for ν=.2: at s1, even 7.38558495 / odd 7.45712894; at s2.5, even 0.12312302 / odd 0.13951519 (sum M<=48 only; not a certified full-tail numerical enclosure).
- `thermal_mixing_check.py`: executed N up to96, confirmed fixed-time polynomial trend (asymptotics slow at s=.1).
- `zero_temperature_maxwell_check.py`: **executed** finite N<=96, numerical profiles move toward Maxwell limit but converge slowly. This is illustration, not proof.
- `thermal_pt_experiment.py`, `pt_scan.py`: floating exploratory counterexamples N3..8. Exact N3 certificate supersedes them.

Practical calculation: exact global trace distance for this symmetric initial state is a weighted sum of tridiagonal `(M+1)`-level classical chains, `O(N²)` total state variables, instead of a `2^N x2^N` density matrix. Each sector can be computed with sparse matrix exponentials or rational uniformization; naive **polynomial** arithmetic cost has factors of exit rate `O((nu+1)N²)`, time `s`, precision `log(1/epsilon)`, and bit lengths of ν,s. A stronger asymptotic compression at fixed `s` approximates `C_(r,nu,s)` by keeping `M<=L` because (BOUND) yields a stretched-exponential tail in `L/log L`; coarse `L=O_(nu,s)(log(1/eps) loglog(1/eps))` suffices. Acquiring/calibrating physical ν, Γ, and the collective-jump model, and obtaining global trace distance from data, are not free.

## G. Priority, falsifiers, and restart obligations

- **Established prior art**: Formanek obstruction to torsion-free hyperbolic direct-finiteness counterexample; cannot claim a new solution to that conjecture.
- **Independently derived in this run**: N3 time-reentrant PPT/NPT exact rational witness; D1 sharp parity-sensitive N^-3/2 fixed-time law; D2 Theta(logN/sqrtN) worst-total-error mixing scale for this specific maximally-mixed input; E1 zero-temperature Maxwell mixing crossover. Proofs are included at auditable step level, but **originality and expert review UNKNOWN**. A literature check found adjacent collective-decoherence papers, not a certification that the exact results are novel.
- **No inference** to family197 Bernoulli entropy/isomorphism, quantum PCP, physical quantum advantage, strong NPT bound entanglement, or efficient generic Schur-state preparation.
- **Counterexample/failure**: Claim 'N130 stationary singleton PPT threshold implies all-time PPT for initially maximally mixed trajectories' is FALSE; N3 exact rational witness above.
- **High-upside transfer**: the rare-sector mass exponent `(dim representation)^2 * N^-3/2` is the small-spin edge of an SU(2) local CLT. Analogous compact-group representation multiplicity tails may produce further input-specific relaxation exponents for higher-d local systems, but without an independently established uniform sector mixing bound, this is only a conjectural bridge. N07/N08 qudit affine dimensions `d²-1` share a superficially similar representation dimension but imply no free theorem here.
- **Next falsifiers**: (i) specialist must locate Formanek assumptions and check N129 contradiction, (ii) independent exact operator-algebra proof of N3 PT representation and measured witness, (iii) attempt to disprove D1 via sector edge/multiplicity conventions and slow high-M weight, (iv) literature/priority search around spin superradiance transient NPT and Maxwell relaxation profiles, (v) positive-temperature Maxwell profile requires proving hitting-time concentration at scale logM/M uniformly over typical initial levels (or producing a counterexample), (vi) finite-time *strict* PPT preparation requires a lower-bound eigenvalue/interface beyond global trace-norm mixing.

**Acquisition and persistence:** No new physical data; rational exact certificate uses prescribed ν and time and explicit Schur operators. Source-reported historical checks are not replays. New scripts and this note are the reproducibility packet. Reopen original full source proofs when claiming N130/131 global entanglement or entanglement depth; only their sector decomposition is required by D/E.