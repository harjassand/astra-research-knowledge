# Corrected research audit: direct finiteness, Bernoulli isomorphism, and positive characteristic

Date: 2026-10-08 (Brisbane). Independent proof audit using original OpenAI family-197 source, Seward's original theorems, Formanek 1973, Burger–Valette, and Bartels–Lück–Reich.

**Research status.** Algebraic deductions below are proved **conditional on** an explicit non-direct-finiteness witness in a countably infinite group algebra. Entropy statements use published Seward theorems exactly as quoted. Family-197's entire probabilistic/topological construction and the separate N129 hyperbolic strengthening have NOT been independently certified; no explicit matching/finite presentation was acquired. Historical priority and peer review remain unknown. The full Bernoulli isomorphism question is NOT settled.

**This supersedes the disputed claims in** state/2026-10-08-bowen-bernoulli-direct-finiteness/RESEARCH.md, ADDITIONAL_AUDITS.md, state/2026-10-08-formanek-frontier/RESEARCH_STATE.md, the group-theory Section B of state/2026-10-08-full-proofs-and-audits.md, and the main index's "Formanek impossibility" gloss. The unrelated mathematical claims in those records are not being retracted by this focused audit.

## 1. Explicit input and scope

Assume G is countably infinite; q is a prime power; R=F_q[G]; a,b in R with ab=1 but ba!=1. Set r=1-ba, S=supp(r), m=|S|. Then r is a nonzero proper idempotent (r^2=r); r=1 would imply ba=0 and a=aba=0, contradicting ab=1. In particular m>=2: a nonzero one-term idempotent in a group algebra is 1.

The released OpenAI family-197 torsion-free preprint, at
https://github.com/openai/math/tree/main/preprints/A-Torsion-Free-Group-Algebra-That-Is-Not-Directly-Finite-October-4-2026/build/sections ,
asserts finite presentation, torsion-freeness, a finite 2-dimensional classifying complex, and a,b,c in F_2[G] with ab=1, ac=0, c!=0. The parity-criterion calculation can be checked algebraically in algebra.tex. The global graph exclusion / cone picture / topology / random-selection arguments are nontrivial and were NOT fully independently established by this audit. No numerical m or concrete words for a,b were acquired; the selection is existential.

## 2. Exact equivariant Haar splitting: proved from ring identities

Put X=F_q^G with coordinatewise addition, product topology, uniform product measure, and the left G shift (h.x)(g)=x(h^{-1}g). For u=sum_s u_s s define (T_u x)(g)=sum_s u_s x(gs). Then T_u T_v=T_{uv}; T_u is a continuous, shift-equivariant compact-group homomorphism. Write A=T_a, B=T_b, C=T_r=I-BA. We have AB=I; AC=0; CB=0; C^2=C; ker(A)=im(C)=:K; and ker(C)=im(B)=:Y.

The mutually inverse maps
  Phi:X -> X x K, Phi(x)=(Ax,Cx);
  Psi:X x K -> X, Psi(y,z)=By+z
are continuous G-equivariant *group* isomorphisms. Proof: ABy=y, ACx=0, CBy=0, Cz=z (z in K), and BAx+Cx=x. Therefore Phi pushes product Haar on X exactly to Haar_X x Haar_K, so the two outputs are independent. B:X -> Y is similarly a topological and measure-preserving conjugacy.

K is nontrivial because r!=0 implies T_r!=0. It is infinite, with atomless Haar: choose infinitely many disjoint translates of finite support S and observe that the corresponding coordinates of Cx for iid uniform x are independent and uniform F_q. It is a factor of a mixing Bernoulli action, hence itself mixing. This does NOT identify K as Bernoulli, even measurably. For family-197's optional c with ac=0, im(T_c) is a nonzero subgroup of K.

Topological obstruction, not measurable: augmentation eps(a)eps(b)=1, hence eps(a)!=0 and A has no nonzero constant vector in its kernel. K has exactly one fixed point whereas any nontrivial full finite-alphabet shift has more than one. The full shifts X and X x X have q versus q^2 fixed points. Neither topological fact obstructs a measure conjugacy (these fixed sets are Haar-null).

Finite-quotient audit: for any finite quotient Q of G, the images of a,b satisfy ab=ba=1 in the finite-dimensional F_q[Q], so the image of r is zero. On every finite-index-normal periodic-point space, C=0; K has no nonzero finite-orbit points, and Y contains every finite-orbit point of X. By combining finitely many quotients, some distinct pair s,t in supp(r) must have identical images in every finite group quotient. This is a valid algebraic residual-kernel consequence, not a measurable Bernoulli invariant.

## 3. Rokhlin-entropy theorem and exact dependencies

The subgroup Y=im(B)=ker(C) satisfies, for every y in Y, sum_{s in S} r_s y(s)=0. Its identity-coordinate partition alpha is generating, finite entropy log q, and uniform. The S-pattern projection is contained in a codimension-at-least-one F_q linear subspace, hence H(alpha^S) <= (m-1)log q. We invoke Seward, "Weak containment and Rokhlin entropy", Theorem 1.5 (requires a free p.m.p. action, generating partition, finite translation window) to give h_G^Rok(Y) <= inf_{T finite}H(alpha^T)/|T| <=(1-1/m)log q.

Since B conjugates X to Y and X is free ergodic for infinite G, h_G^Rok(X) is strictly smaller than log q. Invoke Seward, "Krieger's finite generator theorem for actions of countable groups II", Theorem 1.10:
  h_G^Rok(F_q^G) = min(log q, h_sup^Rok(G)).
The strictness forces the **identity** h_sup^Rok(G)=h_G^Rok(F_q^G) and the bound

  0 <= h_sup^Rok(G) <= (1 - 1/m) log q < log q.

In particular this is <log 2 for the characteristic-two release. Seward II Theorem 1.3 alone gives a weaker explicit strict inequality, but Theorem 1.5 above gives the stated coefficient. This deduction does not establish h_sup(G)=0.

**Exact finite-window linear-rank refinement (derived).** For a finite T subset G put R_T=span_Fq{g:g in T} and d_T=dim_Fq((R r) intersect R_T), where Rr is the *left* ideal. Duality identifies Rr with the finite-coordinate linear relations annihilating Y=ker T_r, so its T-projection is a uniform linear subspace of dimension |T|-d_T. Consequently
  H(alpha^T)=(|T|-d_T)log q,
  h_sup^Rok(G) <= inf_{T finite} (1-d_T/|T|)log q.
For n>=1, a^n b^n=1, r_n=1-b^n a^n!=0, Y_n=im(T_{b^n}) is likewise Bernoulli and the same formula holds with Rr_n. Thus the infimum can be taken jointly over n and finite T. A computable lower bound on d_T is rank(span_Fq{g r_n:g supp(r_n) subset T}); no oracle for the infinite ideal is needed for that sufficient estimate.

**Direct finite-matrix form (same bound).** Right multiplication by b on R has kernel Rr: if u b=0 then u=(u b)a+u r=u r, and r b=0. Thus |T|-d_T = dim_Fq span{t b:t in T}. This dimension is computed by a finite coefficient matrix for the translates t b, given an explicit witness and decidable equality of its finitely many group words. In particular
  h_sup^Rok(G) <= inf_{T finite} [rank_Fq{t b:t in T}/|T|] log q,
and likewise for b^n. A sequence (n_j,T_j) with normalized rank tending to zero would force h_sup(G)=0; no such sequence is known. This is an exact reduction to finite linear algebra, not a finite-time algorithm unless the group operations/witness can be acquired.

To force h_sup(G)=0 by this method it would suffice to find windows and n such that d_{T,n}/|T| tends to 1. No such rank-density theorem has been proved, nor are actual words a,b available for a numerical test. Iterating X ~= X x K^n does not give that density limit, entropy additivity, or X ~= X x X.

Primary sources:
- Seward, Weak containment and Rokhlin entropy, Theorem 1.5: https://mathweb.ucsd.edu/~bseward/Files/weakcontainrokentropy.pdf
- Seward, Krieger's finite generator theorem II, Theorems 1.10-1.12 and Corollary 7.7: https://mathweb.ucsd.edu/~bseward/Files/krieger2.pdf

## 4. A missed theorem removes the 'infinite-only POS' loophole

Seward II, Corollary **7.7**, states the equivalence for countably infinite G of:
(i) h_sup^Rok(G)>0;
(ii) existence of a free ergodic action with finite, strictly positive Rokhlin entropy;
(iii) existence of a free ergodic action with infinite Rokhlin entropy.
Therefore **no positive-Rokhlin-entropy free ergodic action of G exists iff h_sup^Rok(G)=0**, and this includes infinite values. The earlier RESEARCH.md warning that h_sup=0 might coexist with infinite positive Rokhlin actions was mathematically wrong. Seward's unresolved implication POS=>INF concerns h_sup=+infinity, not whether h_sup is positive.

If s=h_sup^Rok(G)>0 then choose infinitely many biased two-point base distributions with distinct Shannon entropies t in (0,min(s,log 2)); Theorem 1.10 gives Bernoulli Rokhlin entropy t. Thus *uncountably many* Bernoulli shifts are pairwise nonisomorphic. If s=0, Theorem 1.10 makes every finite-Shannon Bernoulli shift have zero Rokhlin entropy, while Theorem 1.12 together with Corollary 7.7 does the same for *infinite*-Shannon bases. Hence

  all nontrivial Bernoulli shifts have identical Rokhlin entropy
    <=> h_sup^Rok(G)=0
    <=> no free ergodic action of positive Rokhlin entropy.

The common value in that case is 0. The equivalence is about *entropy*, NOT about measurable isomorphism. Full Bernoulli-isomorphism collapse implies these equivalent conditions but is not known to follow from them.

## 5. Strongest extension: explicit zero-POS groups, including a finitely presented version

Let G be as in Section 1 (non-direct-finite group ring, therefore finite h_sup). Seward II Theorem **1.11**: if P is any countable group with arbitrarily large finite subgroups and h_sup^Rok(G)<infinity, then
   h_sup^Rok(G x P)=0.
Combine with Corollary 7.7:
   EVERY free ergodic p.m.p. action of Gamma=G x P has Rokhlin entropy 0
(in particular, none has entropy +infinity). Every nontrivial Bernoulli Gamma-shift has zero Rokhlin entropy for ANY finite or infinite Shannon base, by Theorems 1.10 and 1.12.

The old construction P=direct sum_n C_2 is countable but infinitely generated. **New finite-presentation refinement:** choose P=Richard Thompson's group V, which is finitely presented and contains every finite symmetric group, hence arbitrarily large finite subgroups. If G is finitely presented as claimed in family-197, Gamma=G x V is finitely presented. The witness a,b remains non-direct-finite in the embedding F_q[G] -> F_q[Gamma]. Thus, conditional on family-197, there is a *finitely presented* group with non-direct-finite F_2-algebra and with Rokhlin entropy identically zero **on free ergodic actions**. Gamma has torsion and is not the original G. This does NOT imply every Bernoulli Gamma-shift is isomorphic.

Thompson V references:
- J. C. Birget, "The Groups of Richard Thompson and Complexity": https://pi.math.cornell.edu/~justin/Limited2Cornell/thompson_complexity.pdf (V finitely presented; contains every finite group).
- Cambridge chapter "Obstructions for subgroups of Thompson's group V": https://www.cambridge.org/core/books/abs/geometric-and-cohomological-group-theory/obstructions-for-subgroups-of-thompsons-group-v/0E92DC81B2B4C3FE03107F3ECC04FB29

Tim Austin, ICM 2026, "Some Recent Developments in Structural Ergodic Theory", Question 3.1 asks whether Rokhlin entropy can be identically zero for some countable group: https://epubs.siam.org/doi/10.1137/25M1805564 . The Gamma result addresses the **free ergodic** formulation; do not extrapolate to every action without checking the intended scope. It is an immediate application of Seward's published results to the newly claimed direct-finiteness witness, **not** a novel proof of Theorem 1.11 or Corollary 7.7; independent novelty review is absent.

## 6. Hyperbolic / Formanek / Burger–Valette / Bartels–Lück–Reich: corrected primary-source audit

**DO NOT claim an all-characteristics torsion-free hyperbolic idempotent no-go based on the earlier citations.** The previous Formanek-frontier and group-theoretic audit promoted an inadequately supported assertion to an impossibility theorem.

Original Formanek, *Idempotents in Noetherian Group Rings* (1973), Theorem 1 is explicitly: torsion-free **Noetherian** G and field **characteristic 0** -> no nontrivial idempotents. Its Theorem 2 concerns trace 0<tr(e)<1 in characteristic zero; Theorem 3 (credited to Zalesskii) says trace lies in prime subfield in arbitrary characteristic. It does NOT prove the claimed F_2 torsion-free hyperbolic exclusion:
https://www.cambridge.org/core/services/aop-cambridge-core/content/view/25AF425E2069C808258EA860D2329372/S0008414X00050392a.pdf/idempotents-in-noetherian-group-rings.pdf

Burger–Valette, *Idempotents in complex group rings*, p. 8, Lemma 4.1 assumes no p-torsion and no conjugacy between g and g^{p^k} and concludes **tau(e)=0 or 1 in characteristic p**; it does NOT conclude e=0 or 1. Their Proposition 4.2 assumes infinitely many such primes and concludes idempotent-freeness for **C[G]**, not F_p[G]:
https://people.math.ethz.ch/~burger/pub/1998_Idempotents.pdf

Bartels–Lück–Reich, *On the Farrell-Jones Conjecture and its applications*, p. 9, DOES PRINT a stronger all-characteristics trivial-idempotent sentence and a torsion-free hyperbolic corollary, attributing them to Formanek and Burger–Valette Lemma 4.1+Proposition 4.2:
https://www.mi.fu-berlin.de/math/groups/top/members/publ/blr-appl.pdf
However those cited original statements do NOT justify its positive-characteristic conclusion. Separately, BLR Theorem 0.12's K_0/FJ route requires stable finiteness, characteristic zero, or soficity, none furnished by the alleged F_2 nonsurjunctive group. The discrepancy requires a specialist to locate another valid result, hidden hypotheses, or an erratum. We have NOT proved the printed BLR sentence false, and cannot label the hyperbolic strengthening either a theorem or an impossibility merely from this mismatch.

The counterexample idempotent r=1-ba automatically has tau(r)=0 because coefficient-at-identity is a trace and tau(ab)=tau(ba). Its augmentation is also zero, as eps(a)eps(b)=1. Thus Burger–Valette's characteristic-p trace constraint does NOT obstruct it. Moreover R=Rba direct_sum Rr as left modules, and Rba ~= R (via right multiplication by a), giving [Rr]=0 in K_0 even though Rr is nonzero. Rational K_0 is not a positivity certificate.

**Withdraw as unjustified** the previous deductions "all F_p[G] torsion-free hyperbolic are directly finite by Formanek", "every torsion-free F_p counterexample contains BS(1,p^k)", "finite multiplication pattern forbids all torsion-free hyperbolic local approximants" and "no colimit of torsion-free hyperbolic groups can contain such a witness" insofar as they depend on the unproved all-characteristics claim. This is a dependency correction, not a refutation of any separately proven theorem. If an independent full positive-characteristic idempotent theorem is located, revisit conditionally.

**N129 hyperbolic strengthening remains an unreviewed conditional candidate** with difficult uniform graph exclusion, disk extension/linear Dehn, torsion-freeness and preservation of nonzero witness; no explicit small-cancellation model or external audit. Neither the old false impossibility nor a bare citation discrepancy proves it. Keep separate from other proposed nonsofic hyperbolic constructions, which do not by themselves entail group-ring non-direct-finiteness.

## 7. Independent approaches, failures, and decisive gates

- **Entropy upper bound -> zero**: failure. The finite nonzero support m yields only s<log q; finite-window rank density d_T/|T|->1 would suffice but is unproved and no concrete graph selected.
- **Algebraic absorption -> Bernoulli shift of larger base**: failure. X~X x K and its finite iterations do not identify K with a nontrivial Bernoulli action. A factor of an arbitrary nonamenable Bernoulli need not itself be Bernoulli; entropy additivity or cancellation cannot be assumed.
- **Topological full-shift cancellation**: specifically impossible for the displayed K via fixed/periodic points. This is NOT a measurable obstruction.
- **Bernoulli mutual factors -> measurable conjugacy**: failure. Bowen's established nonamenable mutual-factor theorem is weaker. Likewise Seward's equal-Shannon-entropy isomorphism theorem does NOT compare unequal base entropies. For P x G, equal Rokhlin entropy zero gives no measurable classification.
- **Construct free ergodic positive-Rokhlin action for original G**: no construction. If it exists, Seward Corollary 7.7 yields s>0, forcing uncountably many nonisomorphic Bernoulli shifts. If none exists, all their Rokhlin entropy vanishes but isomorphism STILL open.
- **Direct-finiteness -> hyperbolic impossibility**: failed literature transfer; see Section 6. Retain original N129 candidate as conditional and unverified, not refuted.
- **Priority**: existing Seward formulas, entropy-window method, Formanek char0 and Burger–Valette trace are established. Haar split is elementary group-ring linear algebra. The precise support-size entropy bound, dual finite-window rank extension, and applying Seward to family-197 plus Thompson V are not externally priority-cleared. No new universal classification theorem is claimed.

**Decisive remaining obstruction:** establish s(G)>0 or s(G)=0 for the *original* family-197 group, and, independently, construct an actual measurable inverse between unequal-entropy Bernoulli shifts (or find a legitimate measure-conjugacy invariant separating them). No amount of mutual factoring, Haar splitting, finite-window upper bounding, or zero entropy *alone* supplies the missing measurable isomorphism.
