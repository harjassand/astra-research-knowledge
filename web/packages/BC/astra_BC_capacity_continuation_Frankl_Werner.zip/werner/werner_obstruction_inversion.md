# A second-order obstruction at the NPT Werner endpoint

**Research note — 9 October 2026.** No claim of historical novelty, external peer verification, or resolution of NPT bound entanglement. This note derives two exact mathematical facts from the endpoint partial-trace representation. No publication or repository modification has been made.

## The question and exact quadratic form

Let \(H=(\mathbb C^d)^{\otimes n}\), where \(d\ge3\). Identify \(C\in\operatorname{End}(H)\) with its vectorization across the two parties and put
\[
 Q_n(C)=\sum_{S\subseteq\{1,\ldots,n\}}(-1/2)^{|S|}\|\operatorname{Tr}_S C\|_F^2.
\]
The endpoint Werner state \(\rho_d=(2I-F)/(2d^2-d)\) is positive and NPT for \(d>2\), and
\[
 \langle\operatorname{vec}(C),(\rho_d^\Gamma)^{\otimes n}\operatorname{vec}(C)\rangle
  =\big(2/(2d^2-d)\big)^n Q_n(C).
\]
Thus all-copy nondistillability of this particular state requires \(Q_n(C)\ge0\) for **every** \(n\) and **every complex rank-at-most-two** \(C\). This requirement remains open; the results below do not settle it.

For local matrix units \(E_{ij}\), the polarized quadratic form satisfies
\[
 B_n(E_{a b},E_{c e})=\prod_{r=1}^n\left(\delta_{a_r c_r}\delta_{b_r e_r}-\tfrac12\delta_{a_r b_r}\delta_{c_r e_r}\right),\quad Q_n(C)=B_n(C,C),
\]
with \(B_n\) conjugate-linear in its first variable.

## Theorem 1: exact local support-overlap test

Fix nonzero subspaces \(U_i,V_i\subseteq\mathbb C^d\), with orthogonal projections \(P_i,R_i\), and let \(\mathcal C\) be all operators \(C\) whose range lies in \(\bigotimes_i U_i\) and whose adjoint range lies in \(\bigotimes_i V_i\). Then
\[
 Q_n(C)\ge0\quad \text{for every }C\in\mathcal C
 \quad\Longleftrightarrow\quad
 \operatorname{Tr}(P_iR_i)\le2 \quad\text{for each }i.
\]
**Proof.** In vectorized coordinates, the one-site Hermitian operator for \(Q_1\) is \(K=I-\tfrac12|\Omega_d\rangle\langle\Omega_d|\), where \(|\Omega_d\rangle=\sum_{j=1}^d|jj\rangle\) is unnormalized. Its compression to \(U_i\otimes\overline{V_i}\) is \(I-\tfrac12|\eta_i\rangle\langle\eta_i|\), where \(\eta_i=(P_i\otimes\overline{R_i})\Omega_d\) and \(\|\eta_i\|^2=\operatorname{Tr}(P_iR_i)\). The full compressed operator, after permuting slots, is the tensor product of these local compressions. Each factor is positive semidefinite exactly when its overlap is at most two, proving sufficiency. If an overlap exceeds two, its local compression has a strictly negative eigenvalue. Every other local compression has a strictly positive eigenvalue (on a space of dimension one this follows from \(\operatorname{Tr}(P_iR_i)\le1\); otherwise it has an eigenvalue one). A product of a negative eigenvector at the offending site and positive eigenvectors elsewhere has negative expectation. This proves necessity. \(\square\)

This classifies positivity on **entire product-defined operator spaces**, without an assumption on matrix rank. It does not classify arbitrary rank-two matrices, whose left and right local supports may overlap in more than two dimensions.

## Theorem 2: second-order stability of the canonical zero witnesses

Let \(n\ge2\) be even, \(d\ge3\), \(a=0^n\), \(b=1^n\), and
\[
 C_0=|a\rangle\langle a|-|b\rangle\langle b|.
\]
Then \(\operatorname{rank}(C_0)=2\), \(Q_n(C_0)=0\). For **every twice differentiable path** \(C(t)\) of rank-at-most-two complex matrices with \(C(0)=C_0\),
\[
 Q_n(C(t))=t^2 H+o(t^2)\quad\text{with } H\ge0.
\]
The assertion is only second-order: it does not say \(Q_n\) is nonnegative in a neighborhood of \(C_0\).

**Proof.** Write \(P=\operatorname{span}(a,b)\) and \(J=\operatorname{diag}(1,-1)\) on \(P\). Since \(PC_0P=J\) is invertible, every nearby rank-two matrix has a block-Schur parameterization
\[
 C(t)=(I+X(t))M(t)(I+Y(t))^*,
\]
where \(M(t):P\to P\), \(X(t),Y(t):P\to P^\perp\), \(M(0)=J\), \(X(0)=Y(0)=0\). Indeed, the invertible upper-left \(2\times2\) block determines the lower-right block by the rank-two Schur identity. Put \(M(t)=J+tM_1+O(t^2)\), \(X(t)a=t x+O(t^2)\), \(X(t)b=t z+O(t^2)\), \(Y(t)a=t y+O(t^2)\), \(Y(t)b=t w+O(t^2)\), with \(x,y,z,w\perp P\). The first-order term is
\[
 T=M_1+xa^*+ay^*-zb^*-bw^*.
\]
The second-order term has, modulo terms inside \(P\times P\) or off its diagonal blocks, the component \(xy^*-zw^*\). All the omitted terms are \(B_n\)-orthogonal to \(C_0\). Directly from the matrix-unit formula, \(B_n(C_0,C_0)=0\), \(B_n(C_0,T)=0\); hence
\[
 H=Q_n(T)+2\operatorname{Re}B_n(C_0,xy^*-zw^*).
\]
For each string \(c\notin\{a,b\}\), define \(m_0(c)=\#\{i:c_i=0\}\), \(m_1(c)=\#\{i:c_i=1\}\),
\[
 \alpha_c=2^{-m_0(c)},\quad\beta_c=2^{-m_1(c)},\quad
 A_c=\prod_i(\mathbf1_{c_i=0}-\tfrac12)-\prod_i(\mathbf1_{c_i=1}-\tfrac12).
\]
Let \(\mathcal B=\{0,1\}^n\setminus\{a,b\}\), and let \(\mathcal D\) be the remaining strings, i.e., those containing a symbol other than zero or one. For \(c\in\mathcal B\) set \(\bar c=(1-c_1,\ldots,1-c_n)\), \(\sigma_c=(-1)^{m_0(c)}\). Matrix-unit multiplication gives the **exact** decomposition
\[
\begin{split}
 H={}&2^{-n}|(M_1)_{aa}+(M_1)_{bb}|^2+|(M_1)_{ab}|^2+|(M_1)_{ba}|^2\\
 &+\sum_{c\in\mathcal B}\alpha_c\left(|x_c-\sigma_c\overline{w_{\bar c}}|^2+|y_c-\sigma_c\overline{z_{\bar c}}|^2\right)\\
 &+\sum_{c\in\mathcal D}\Big[\alpha_c(|x_c|^2+|y_c|^2)+2A_c\operatorname{Re}(x_c\overline{y_c})\\
 &\hspace{35mm}+\beta_c(|z_c|^2+|w_c|^2)-2A_c\operatorname{Re}(z_c\overline{w_c})\Big].
\end{split}
\]
To verify the decomposition, note that local off-diagonal matrix units are \(B_1\)-orthogonal to everything except themselves, while any pair of diagonal units has pairing \(\delta_{ij}-1/2\). The only off-block cross pairings occur between \(E_{ca}\) and \(E_{b\bar c}\), or between \(E_{ac}\) and \(E_{\bar c b}\), with \(c\in\mathcal B\). Their normalized coefficient is \(\sigma_c\alpha_c\). The \(C_0\)-curvature pairing vanishes for \(c\in\mathcal B\), and is \(A_c\) for diagonal \(E_{cc}\) with \(c\in\mathcal D\).

For even \(n\), the binary terms vanish because \(A_c=0\) on \(\mathcal B\). On \(\mathcal D\), parity gives \(A_c=0\) or \(|A_c|=2^{1-n}\). Because every \(c\in\mathcal D\) has \(m_0(c),m_1(c)\le n-1\), one has \(|A_c|\le\alpha_c\) and \(|A_c|\le\beta_c\). Thus each \(\mathcal D\) bracket is nonnegative by \(2|uv|\le|u|^2+|v|^2\); the other terms are manifest sums of squares. Consequently \(H\ge0\). \(\square\)

### Scope and unclosed obligation

Theorem 2 proves that an arbitrary smooth rank-two witness curve cannot make \(Q_n\) negative at order one or two near this family of zero witnesses. It does **not** eliminate negative terms of higher order or distant negative rank-two witnesses, so it does not prove four-copy, general even-copy, or all-copy undistillability. Similarly, Theorem 1 is a product-support characterization, not a characterization of all rank-two supports. Establishing an NPT bound-entangled state still requires universal positivity \(Q_n(C)\ge0\) for **all** \(n\) and **all complex rank-two** \(C\), or another complete construction.

### Verification and originality qualification

The algebraic second-order coefficient was independently expanded by matrix-unit contractions and its proposed sum-of-squares formula was checked with exact rational random tangent instances for \(n=2,4,6\), and with complex Gaussian-integer instances for \(d=3\), \(n=2,4,6\), and \(d=4\), \(n=4\). Those are diagnostics, not substitutes for the proof. No exhaustive priority search, proof-assistant certification, external specialist review, or historic novelty determination was completed. Background primary references include Costa Rico (2025), Fraser–Huber–Pozsgay–Vona (2026), and Wu–Zou (2026). Research-source repository pins: Astra `f1888d1108bd22386e687773a7a782bfc1d25e60`, OpenAI mathematics `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.
