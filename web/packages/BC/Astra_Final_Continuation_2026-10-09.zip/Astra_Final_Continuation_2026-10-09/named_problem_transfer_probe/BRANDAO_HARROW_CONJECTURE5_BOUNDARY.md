# Testing the new reconstruction theorem against correlated measurement de Finetti

9 October 2026 UTC. A concrete named-problem transfer attempt, with an exact obstruction to the attempted bridge. No claim of solving or refuting the conjecture.

## Named primary target and status boundary

Brandão and Harrow, Quantum de Finetti Theorems under Local Measurements with Applications, arXiv:1210.6367v5, Conjecture 5, equations (12)–(13), printed pp.12–13, explicitly proposes:

For a k-extendible state ρ_AB and output dimension D=dim(A_tilde), find ONE separable σ_AB such that

max_(E:A→A_tilde) max_(measurement Λ:B→classical)
||(E⊗Λ)(ρ_AB−σ_AB)||₁ ≤ sqrt(2lnD/k).

The equivalent averaged formulation permits the receiver measurement to depend on the chosen compression E_m. The proven theorem in that paper has the expectation and measurement maximization in the opposite order. The authors explicitly identify this as a different quantum problem, not a no-signaling information-chain corollary.

Primary: https://arxiv.org/pdf/1210.6367

The conjecture is verified as a named proposal in the original primary source. A targeted search for a later resolution did not locate one, but did not establish its current 2026 open status conclusively. Therefore it is not described here as a newly verified longstanding open problem. Its old complexity consequences also must not be restated as current novelty without accounting for later nonlocal-game results.

## Why the new machinery initially looks relevant

The bounded-capacity reconstruction theorem now gives one common EB channel uniformly over all promised states, not a separate measurement for each observable. It also handles arbitrary trace norm rather than only a measured residual. These are superficially similar to the missing common-separable-state and correlated-measurement requirements.

For each fixed compression E:A→A_tilde, a conditional-state experiment on A_tilde has capacity at most lnD. A k-extension supplies many correlated B registers. It is tempting to try to turn these ingredients into a small-error broadcaster and apply the new theorem.

## The exact domain mismatch

A k-extension of a bipartite state can be represented by a k-compatible channel N from an input reference into B (after the appropriate faithful marginal/Choi identification). It gives a joint map from the INPUT space to k B outputs, each with marginal N.

The new reconstruction theorem instead needs a channel consuming the PROMISED B state and producing two approximately identical B marginals. These are different requirements. To obtain the latter from the extension one would need a return map R:B→input for which NR is close to the identity on the output experiment N(D(input)). No such approximate sufficiency statement follows from extension length alone.

## Exact counterexample to the canonical Petz return-map shortcut

Let both input and output be a classical bit, embedded as diagonal qubit density matrices. Define N by dephasing and applying the symmetric stochastic matrix

P=[[3/4,1/4],[1/4,3/4]].

It is CP, TP, unital, and HS-selfadjoint. It has an exact k-output extension for EVERY k: measure the input bit, sample one output bit according to P, and prepare that same sampled bit at all k outputs. Thus there is no shortage of extension length.

At reference I/2, the Petz reverse is R=N. Let

τ_±=N((I±Z)/2)=(I±Z/2)/2.

The induced self-compatible endomorphism S=NR=N² has

S(τ_±)=(I±Z/8)/2,
T(Sτ_±,τ_±)=(1/2−1/8)/2=3/16.

This residual is independent of k and does not vanish even though the original channel is already EB and the associated Choi state is separable. Therefore no universal implication “k-compatible channel ⇒ its Petz loop approximately fixes its image as k grows” can underwrite the desired transfer.

The example does not refute the de Finetti conjecture: its conclusion is trivially true here by taking σ_AB=ρ_AB. It proves that the missing near-fixation hypothesis cannot simply be silently obtained from shareability by the proposed Petz construction. A more selective mechanism would have to preserve classical information that the noisy forward-and-back loop attenuates.

## The compression-label obstruction

Capacity at most lnD for EACH compressed experiment does not give capacity at most lnD for a single experiment retaining every compression label m. If the protocol needs m to select the operation, explicitly adjoining its classical flag can cost ln|M|.

The elementary example is the flagged family |m><m|⊗ω with fixed ω. Every fixed-m slice has capacity zero; the union has capacity ln|M|, witnessed by the uniform prior. This does not refute the conjecture either, but it invalidates a direct substitution of compressed quantum dimension for total experimental capacity when a label flag is retained.

Erasing the flag is not a free repair: one must then show that the same physical input channel, measurement, and output preparation work for every compression, precisely the correlated-context issue posed by the conjecture.

## Outcome and recommendation

This named-problem attempt did not produce a proof or counterexample to Conjecture 5. It produced two exact constraints on any proposed reduction and one explicit channel calculation defeating the most natural Petz shortcut. The current comparator controls near-invariant experiments under an actual splitter; generic extendible correlations do not provide that interface.

A credible next mechanism would need a dimension/capacity-controlled approximate statistical-sufficiency theorem that constructs a common return channel while retaining already-classical attenuated modes. It cannot be merely another bound on pairwise commutators, another application of the Petz adjoint, or a swap of max and expectation. No such theorem is established in this record. The affinity-assisted substate interpolation is a more direct productive direction for the machinery currently proved, and is being investigated separately rather than claiming a named de Finetti breakthrough.
