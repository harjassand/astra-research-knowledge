# Independent audit of the logarithmic capacity/broadcasting modulus

## Verdict

The proposed universal bound follows from the stitched theorem with its stated constants:

For 0 < b = b_2(E) < 1 and C = C(E),

e(E) <= min{1, 3072 sqrt((C+1)/ln(1/b))}.

All entropy and unqualified logarithms are natural. The error e and broadcasting error b use half trace norm.

There is one intermediate arithmetic correction: the exponential-absorption threshold is A >= 24704, not A >= 24576. The proposed choice A = 2^20 satisfies the corrected threshold by a large margin, so the final bound and constant 3072 are unchanged.

This audit checks the quantitative deductions from BOUNDED_CAPACITY_BROADCASTING_THEOREM.md. It does not promote the source to external peer review or formal certification, and it asserts no rate optimality.

## 1. Parameters and the trivial branch

Put

L = ln(1/b), A = 2^20, delta = sqrt(A(C+1)/L).

Capacity satisfies C >= 0, while L > 0. If L <= 4A(C+1), then the unclipped proposed bound 3delta is at least 3/2. Hence the asserted minimum is 1 and the claim is the ordinary bound e(E) <= 1.

For the rest assume L > 4A(C+1). Then

0 < delta < 1/2, L > 4A = 2^22,
eta = delta^2/8 < 1/32,
M = (1-eta)^(-1) exp((C+ln 2)/eta),
lambda = eta/M = delta^2/(8M).

Because ln 2 < 1 and (1-eta)^(-1) < 2,

1 <= M <= 2 exp(8(C+1)/delta^2) = 2 exp(8L/A).

## 2. Smoothing constants

The stitched proof has

xi_b = (1+sqrt M+2lambda M^2)sqrt(2b)+Mb,
g = max{b, (1+sqrt 2)sqrt(xi_b/lambda)+2M sqrt(2b)+2Mb}.

Since 2lambda M^2 = (delta^2/4)M <= M/16, and 1,sqrt M <= M,

1+sqrt M+2lambda M^2 <= 3M.

Using b <= sqrt b and sqrt 2 < 3/2 therefore gives

xi_b <= (3sqrt 2+1)M sqrt b <= 6M sqrt b.

It follows that

sqrt(xi_b/lambda) <= sqrt(48) M delta^(-1) b^(1/4).

Dividing the nontrivial entry of the maximum defining g by M delta^(-1)b^(1/4), its coefficient is at most

(1+sqrt 2)sqrt(48) + 2sqrt 2 delta b^(1/4) + 2delta b^(3/4)
 < (5/2)*7 + 3/2 + 1 = 20.

The other entry b is also at most M delta^(-1)b^(1/4). Thus the claimed looser convenient bound is valid:

g <= 22 M delta^(-1)b^(1/4).

## 3. A uniform power bound for the pair gap

For 0 < u <= 1, choose depth k = ceil(2 log_2(1/u)) in the pair bound. With c_0 = sqrt(ln 2/2) < 1, this gives

v(u)^2 <= 8u [2 log_2(1/u)+1+c_0].

Let s = sqrt u. The elementary maximum s ln(1/u) = -2s ln s <= 2/e, together with ln 2 >= 1/2 and e >= 2, gives

v(u)^2 / sqrt u
 <= 8[4/(e ln 2)+1+c_0]
 <= 48 < 49.

Consequently v(u) <= 7u^(1/4). At u=0 the same inequality holds by definition v(0)=0. The cap v <= 1 causes no difficulty.

## 4. Centralization and reference-correction constants

Set M_s = sqrt(3/2). Then

Xi(u) = 2sqrt(2M_s v(u)) <= sqrt(56M_s)u^(1/8) <= 9u^(1/8).

First suppose 0 < Xi <= 1, so t = Xi^(1/3). The centralization error becomes exactly

c(u) = [4sqrt(3M_s)+8] Xi^(1/3).

The coefficient multiplying u^(1/24) is less than 34. For example M_s < 5/4 gives 4sqrt(3M_s)+8 < 16, and 9^(1/3) < 21/10, whose product is 33.6. Therefore

c(u) <= 34u^(1/24),
w = u+c(u)/2 <= 18u^(1/24),

where u <= u^(1/24) for 0 <= u <= 1.

If also w <= 1, then

r(w) = sqrt(4w+(3/2)sqrt(2w))
 <= sqrt(4+(3/2)sqrt 2) w^(1/4)
 <= 3w^(1/4).

Thus, using the stitched h(u) = min{1,c(u)/2+sqrt(r(w)/2)},

h(u)
 <= 17u^(1/24) + sqrt(3/2)18^(1/8)u^(1/192)
 <= [17+sqrt(3/2)18^(1/8)]u^(1/192)
 <= 20u^(1/192).

The last coefficient is strictly below 19; the stated 20 leaves slack.

The other branches are also valid and must not be omitted:

- If Xi > 1, then Xi <= 9u^(1/8) implies u^(1/192) > 9^(-1/24), so 20u^(1/192) > 1. Hence h <= 1 proves the same inequality.
- If Xi <= 1 but w > 1, then w <= 18u^(1/24) implies u^(1/192) > 18^(-1/8), again making 20u^(1/192) > 1.
- At u = 0, h(0) = 0.

Therefore the uniform bound

h(u) <= 20u^(1/192)

holds on the entire needed interval 0 <= u <= 1.

## 5. Undilution and the final remainder

The dilution parameter is a = 1/(4M-2), so

(2-a)/a = 8M-5 <= 8M.

Use u = min{1,g}. Since u <= g and the exponent is positive, the stitched inequality gives

e(E) <= 2delta + 160M g^(1/192)
 <= 2delta + R,

R = 160M (22M/delta)^(1/192) exp(-L/768).

The cap u=min{1,g} remains valid even when the smoothing estimate exceeds 1. There is no small-g premise in this step.

Insert M <= 2exp(8L/A) and delta^(-1) <= sqrt L to obtain

R <= 320 * 44^(1/192) L^(1/384)
       * exp[-L(1/768 - 193/(24A))].

The prefactor 320*44^(1/192) is below 400. To replace the exponential rate by 1/1024, the exact requirement is

193/(24A) <= 1/768-1/1024 = 1/3072,

or

A >= 128*193 = 24704.

This is the sole correction to the proposed arithmetic threshold. A=2^20 satisfies it. Hence

R <= 400 L^(1/384) exp(-L/1024).

For a particularly elementary verification that this is at most delta, use exp(L/1024) >= L/1024 and delta >= 1024/sqrt L. Then

R/delta <= 400 L^(-191/384).

In the present branch L > 2^22, so

400 L^(-191/384) < 400 * 2^(-4202/384) < 1.

Therefore R <= delta and

e(E) <= 3delta = 3072 sqrt((C+1)/L).

Combining this with e(E) <= 1 proves the claimed clipped bound.

## 6. Infima, endpoints, and growing capacity

If the broadcasting error is treated as an unattained infimum, apply the argument at b+epsilon and let epsilon decrease to zero. For fixed finite-dimensional systems, compactness of the channel set and the uniform trace-distance objective also give attainment. No parameter choice depends on a hidden input-state label.

At b=0, apply the bound at arbitrarily small positive error allowances: e(E)=0. Finite-dimensional compactness of EB channels supplies exact reconstruction if required. At b=1, the displayed logarithmic expression is not evaluated; use the trivial bound e(E)<=1. A zero-capacity experiment is also harmless (indeed its states coincide), though the displayed bound is intentionally not optimized for C=0.

For a sequence with b_n -> 0 and C_n = o(ln(1/b_n)), the bound yields e(E_n) -> 0. Thus the theorem covers capacity growth sublinear in ln(1/b), in addition to uniformly bounded capacity. No optimality or matching lower bound is established.
