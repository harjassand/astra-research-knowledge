# A uniform logarithmic capacity tradeoff

9 October 2026 UTC. Separate quantitative consequence of BOUNDED_CAPACITY_BROADCASTING_THEOREM.md. Constants are deliberately loose; no optimality claim. An independent arithmetic check is recorded below when complete.

## Statement

Use the same halftrace definitions of e(E), b₂(E), and natural-log Holevo capacity C(E). For any finite-dimensional experiment with 0<b=b₂(E)<1 and C=C(E)<∞,

e(E) ≤ min{1, 3072 sqrt[(C+1)/ln(1/b)]}.                 (1)

At b=0 set the right side to zero; at b=1 use the trivial bound one. The number 3072 is an explicit safe universal constant, not a useful optimized constant.

In particular, the capacity need not remain bounded: if b₂(E_n)→0 and

C(E_n)=o(log[1/b₂(E_n)]),

then e(E_n)→0. Conversely, if e(E)≥ε>0, then

C(E)+1 ≥ (ε²/9437184) ln[1/b₂(E)].                       (2)

Thus persistent nonclassical reconstruction error requires at least logarithmically growing information capacity as two-receiver broadcasting becomes accurate. This is a necessary tradeoff, not a matching lower-bound construction or a sharp threshold.

## Proof with explicit constants

Write L=ln(1/b), A=2²⁰, and choose smoothing tolerance

δ=sqrt[A(C+1)/L].

If L≤4A(C+1), the right side of (1) before clamping is at least 3/2, so the bound follows trivially from e≤1. Assume therefore L>4A(C+1), so 0<δ<1/2.

The stitched proof supplies, with M=(1−δ²/8)⁻¹ exp[8(C+ln2)/δ²] and a=1/[2(2M−1)],

e(E)≤2δ+[(2−a)/a]h(min{1,g}),
M≤2exp(8L/A),
(2−a)/a=8M−5≤8M.

Its smoothing parameter λ=δ²/(8M) gives

ξ_b=(1+sqrtM+2λM²)sqrt(2b)+Mb ≤6M sqrtb.

Consequently

g≤22M δ⁻¹ b^(1/4).                                    (3)

Indeed the strong-convexity term is at most (1+sqrt2)sqrt48·Mδ⁻¹b^(1/4), and the remaining terms 2M sqrt(2b)+2Mb are absorbed by 22Mδ⁻¹b^(1/4), since δ<1/2 and b≤1. The max with b in the definition of g is harmless.

We next bound the sandwich reconstruction modulus by

h(u)≤20u^(1/192), 0≤u≤1.                              (4)

For u>0, choose tree depth ceil(2log₂(1/u)) in the pair bound. Its reconstruction error is at most u[3ln(1/u)+2]≤5u^(1/2), since ln(1/u)≤u^(−1/2). Thus v(u)≤2sqrt10·u^(1/4)≤7u^(1/4). With M_s=sqrt(3/2), the centralization commutator bound gives

Ξ≤2sqrt(2M_s v(u))≤9u^(1/8).

If Ξ≤1, take t=Ξ^(1/3). Then

c(u)=(4sqrt(3M_s)+8)Ξ^(1/3)≤34u^(1/24),
w=u+c(u)/2≤18u^(1/24).

If also w≤1, the Petz fulltrace residual satisfies

r(w)=sqrt[4w+(3/2)sqrt(2w)]≤3w^(1/4).

Therefore

h(u)≤c(u)/2+sqrt[r(w)/2]
≤17u^(1/24)+2·18^(1/8)u^(1/192)
≤20u^(1/192).

If Ξ>1, then 9u^(1/8)>1, which makes 20u^(1/192)>1, so (4) follows from h≤1. If w>1 while Ξ≤1, the upper bound w≤18u^(1/24) similarly makes 20u^(1/192)>1. This covers all cases; h(0)=0.

Equations (3)–(4), including the harmless clipping at g=1, imply

e(E)≤2δ+160M(22M/δ)^(1/192)exp(−L/768).

Because δ⁻¹≤sqrtL, M≤2exp(8L/A), and A=2²⁰ satisfies 8(193/192)/A≤1/3072, the second term is at most

400 L^(1/384) exp(−L/1024).                            (5)

For L≥4A, this is at most sqrt(A/L)≤δ. One exact way to verify the first comparison is to take logarithms: the function

ln400+(1/2+1/384)lnL−L/1024−(1/2)lnA

is decreasing for L≥4A and is already negative at L=4A. Hence e≤3δ, which is precisely (1), since 3sqrtA=3072. Taking arbitrarily small slack in the broadcast infimum and then a limit covers b=b₂(E).

The proof gives the stated growing-capacity regime and (2) by direct rearrangement.

## Significance and next obstruction

Unlike merely restating the fixed-C theorem, (1) controls experiments whose Holevo capacity diverges with dimension. It quantifies an information cost for retaining a fixed amount of nonclassicality under increasingly accurate broadcasting.

The large constant and slow logarithmic modulus come from the compatible substate smoothing route. They are not evidence that logarithmic growth is necessary and sufficient. The next substantial target is to exhibit or exclude a legal family with e bounded away from zero and C only logarithmic in 1/b₂. Bounds on a selected reconstruction channel, pairwise commutators, or unrestricted Choi distance do not supply such a lower-bound family; one must bound error against the entire EB class.

## Independent verification completed

The separate constant-by-constant audit QUANTITATIVE_LOG_MODULUS_AUDIT.md confirms (1), all large-error branches, clamping, and endpoints. The auxiliary absorption threshold is A≥24704 (not 24576); the actual chosen A=2²⁰ satisfies it. The displayed proof above uses the actual exact inequality and is unaffected. This remains internal analytic review, not external certification.
