# Robust classical reconstruction on separable Hilbert spaces

9 October 2026 UTC. A checked extension of the finite-dimensional bounded-capacity broadcasting theorem. The optimal-reference and compactness mechanism is established prior art of Shirokov, independently reconstructed below. The broadcasting/reconstruction transfer is a consequence of the newly checked finite-dimensional theorem. No historical-priority claim is made for this composition.

## Exact statement

Let H be any separable Hilbert space, possibly infinite-dimensional. Let E be any nonempty family of normal density operators on H. Define

C(E)=sup_(finite priors p on E) Σ_xp_xD(ρ_x||Σ_zp_zρ_z).

This definition remains meaningful when the individual von Neumann entropies are infinite; do not write an undefined infinity-minus-infinity entropy difference. Define b₂(E) using normal CPTP maps on trace-class operators H→H⊗H and uniform halftrace marginal error, as in the finite-dimensional theorem. Define e(E) as the infimum of uniform halftrace error over normal CPTP EB channels H→H.

If C(E)≤C<∞, the finite-dimensional reconstruction modulus transfers unchanged by finite-rank approximation. In particular, for 0<b₂(E)<1,

e(E)≤min{1,3072sqrt[(C+1)/ln(1/b₂(E))]}.

Thus uniformly bounded capacity and b₂(E_n)→0 imply e(E_n)→0 even when the experiments live on arbitrary separable infinite-dimensional Hilbert spaces. The growing-capacity regime C(E_n)=o(log[1/b₂(E_n)]) is also retained.

More concretely, for any tolerance strictly larger than the right-hand bound, a finite-outcome EB channel with finite-dimensional output support achieves that error. No uniform cutoff rank or outcome count is asserted. At b₂=0 the conclusion is the infimum statement e(E)=0; this approximation argument does not assert that a finite-outcome exact minimizer exists.

No Hamiltonian, energy constraint, lower eigenvalue bound, or bound on S(ρ) or S(σ) is required. Finite experimental Holevo capacity is the controlling hypothesis.

## 1 A common relative-entropy center

Let C₀=C(E)<∞ and choose finite ensembles on E whose Holevo quantities χ_n tend to C₀. Let σ_n be their mean states. Donald's identity for the half-half mixture of two ensembles gives

C₀≥(χ_n+χ_m)/2 + [D(σ_n||μ_nm)+D(σ_m||μ_nm)]/2,
μ_nm=(σ_n+σ_m)/2.

Pinsker's inequality bounds the second term below by ||σ_n−σ_m||₁²/8. Therefore σ_n is Cauchy in trace norm. Completeness of trace class and positivity/normalization give a limiting density matrix σ.

Fix any ρ∈E and 0<t<1. Add ρ at mass t to the n-th ensemble. Another exact Donald decomposition gives

C₀≥(1−t)χ_n+(1−t)D(σ_n||(1−t)σ_n+tρ)+tD(ρ||(1−t)σ_n+tρ).

Drop the nonnegative middle term. Lower semicontinuity first as n→∞ proves D(ρ||(1−t)σ+tρ)≤C₀. Lower semicontinuity as t↓0 then proves

sup_(ρ∈E)D(ρ||σ)≤C₀≤C.

All identities concern relative entropies, not differences of possibly infinite entropies. For finite ensembles, each divergence to its mixture is finite (bounded by the negative logarithm of its positive prior weight), so these mixing identities have no undefined subtraction.

This common-center theorem and the compactness consequence below are established in Shirokov's work. Their reconstruction here checks the exact interface used for the transfer, not novelty.

## 2 Uniform finite-rank approximation

Choose finite-rank spectral projections P_N of σ increasing to its support; put q_N=Tr[(I−P_N)σ]→0. For any ρ∈E, let p_N(ρ)=Tr[(I−P_N)ρ]. Binary measurement data processing implies

D(ρ||σ)≥d_binary(p_N||q_N)
≥p_N ln(1/q_N)−ln2.

Hence, when 0<q_N<1,

sup_ρ p_N(ρ)≤min{1,(C+ln2)/ln(1/q_N)}→0.

If q_N=0, support containment from finite relative entropy gives p_N=0 for all ρ. Reference directions outside suppσ never occur in the promised family.

Choose one density ω_N supported on P_NH. Define the ordinary CPTP compression

Enc_N(ρ)=P_NρP_N+Tr[(I−P_N)ρ]ω_N

with codomain the finite-dimensional P_NH, and let Dec_N be its natural isometric inclusion into H. The gentle measurement bound gives

T(Dec_NEnc_Nρ,ρ)≤sqrt[p_N(ρ)]+p_N(ρ)/2=:δ_N(ρ).

Thus δ_N=sup_ρδ_N(ρ)→0. These are genuine common channels on all trace-class inputs. Uniform approximation is obtained without a dimension-independent cutoff size.

Data processing gives C(Enc_NE)≤C(E).

## 3 Transfer the broadcaster and reconstruction

Given any normal broadcaster B for E with error at most b, define

B_N=(Enc_N⊗Enc_N)∘B∘Dec_N.

For a promised encoded state Enc_Nρ, contractivity and triangle inequality show that either marginal obeys

T((B_N)_aEnc_Nρ,Enc_Nρ)≤b+δ_N.

Hence b₂(Enc_NE)≤min{1,b+δ_N}. Apply the finite-dimensional bounded-capacity theorem to Enc_NE. Choose an optimal finite-outcome EB reconstruction Λ_N there, or one within arbitrarily small prescribed slack. It induces the normal finite-outcome EB channel

Λ=Dec_N∘Λ_N∘Enc_N

on the original H, with uniform error at most e(Enc_NE)+δ_N (or an arbitrarily small slack if an infimum is used).

Using the explicit continuous bound F_C(b)=min{1,3072sqrt[(C+1)/ln(1/b)]}, extended by F_C(0)=0 and F_C(1)=1, gives

e(E)≤F_C(min{1,b+δ_N})+δ_N.

Take N→∞ and then b↓b₂(E), with channels allowed to depend on the desired approximation tolerance. Continuity of F_C proves the stated inequality. At b₂=0, the same two limits give e=0. No compactness of the infinite-dimensional set of EB channels or existence of a limiting channel is assumed.

## Interpretation and prior-art boundary

This extends the robust experiment-wise classicality theorem to continuous-variable and other separable systems, using only a capacity promise. It does not convert finite capacity into a uniform computational or physical cutoff: the finite-rank approximation depends on the common reference spectrum. Individual state entropies may be infinite.

Shirokov, “Entropic characteristics of subsets of states,” establishes the optimal average state and relative compactness of finite-capacity sets. Primary sources:
- https://arxiv.org/pdf/quant-ph/0510073 (Theorem 1 and the finite-capacity compactness result; numbering differs between preprint and published parts)
- Published Part I, Theorem 1 and Corollary 5: https://www.mathnet.ru/links/fb55ffe1ea94ae2134977e5497bab52e/im730_eng.pdf

Therefore center existence, uniform tightness, and finite-dimensional reduction are not themselves new discoveries. The new conditional input to this extension is the internally checked capacity-uniform finite-dimensional broadcasting-to-EB theorem. This composition still needs external specialist correctness and priority review before publication claims.
