# Independent audit: separable infinite-dimensional capacity extension

## Verdict

The infinite-dimensional extension is valid for normal states on any separable Hilbert space and normal CPTP channels. The common relative-entropy center and uniform finite-rank approximation are established results of Shirokov, and the supplied elementary center argument independently reproduces their required interface. The finite-dimensional broadcasting-to-reconstruction theorem then transfers with no energy or von Neumann entropy hypothesis.

The explicit continuous modulus transfers unchanged:

e(E) <= min{1, 3072 sqrt((C(E)+1)/ln(1/b_2(E)))}

for 0 < b_2(E) < 1 and finite C(E), with endpoint conventions F_C(0)=0 and F_C(1)=1.

At b_2(E)=0, the approximation proof establishes e(E)=0 as an infimum. It does not prove existence of a finite-outcome exact EB minimizer. A concrete obstruction to that stronger statement is given below.

Final reinspection of THEOREM.md confirms that its two wording/interface corrections have been applied: Section 3 chooses an optimal or near-optimal finite-dimensional EB reconstruction, and e is explicitly defined over normal CPTP EB channels. With those corrections the displayed proof and its final wording pass this audit.

## 1. Definitions that remain valid with infinite individual entropies

Let E be nonempty and consist of density operators in trace class T_1(H). For a finite ensemble mu={p_i,rho_i}, define its mean sigma_mu=sum_i p_i rho_i and

chi(mu)=sum_i p_i D(rho_i || sigma_mu).

Define C(E) as the supremum of chi(mu) over finite ensembles in E. No expression S(sigma_mu)-sum_i p_i S(rho_i) is used when its summands may be infinite.

After omitting zero prior weights, sigma_mu >= p_i rho_i gives

D(rho_i || sigma_mu) <= -ln p_i.

Thus every finite ensemble has a finite chi quantity, even when each individual entropy is infinite. Normal quantum relative entropy has lower semicontinuity, data processing, Pinsker, and Donald's identity in this setting.

Donald's identity is an equality of nonnegative extended quantities:

sum_i p_i D(rho_i || omega)
 = chi(mu)+D(sigma_mu || omega).

For each mixture used below, the reference dominates every contributing state by a positive coefficient. All terms in that invocation are finite. In particular, no subtraction of infinities occurs.

## 2. Independent verification of the supplied center argument

Set C_0=C(E)<infinity. Choose finite ensembles mu_n in E with chi_n -> C_0, and write sigma_n for their means.

Their equal mixture is a finite ensemble in E, with mean omega_nm=(sigma_n+sigma_m)/2. Donald's identity yields

C_0 >= (chi_n+chi_m)/2
       + [D(sigma_n || omega_nm)+D(sigma_m || omega_nm)]/2.

Pinsker in natural-log normalization is D(alpha||beta)>=||alpha-beta||_1^2/2. As each sigma differs from omega_nm by half the sigma_n-sigma_m difference, the last average is at least

||sigma_n-sigma_m||_1^2/8.

Consequently sigma_n is Cauchy in trace norm. Completeness of trace class gives a limit sigma; positivity and trace one survive that limit. In particular, the center is a normal state rather than a weak-limit singular functional. It belongs to the trace-norm closed convex hull of E.

Now fix rho in E and t in (0,1). Append rho with weight t to mu_n, reducing its original weights by the factor 1-t. Put omega_n,t=(1-t)sigma_n+t rho. Another Donald decomposition gives

C_0 >= (1-t)chi_n
       +(1-t)D(sigma_n || omega_n,t)
       +t D(rho || omega_n,t).

Dropping the middle term gives the explicit finite upper bound

D(rho || omega_n,t) <= [C_0-(1-t)chi_n]/t.

For fixed t, the right side tends to C_0 and omega_n,t tends in trace norm to omega_t=(1-t)sigma+t rho. Lower semicontinuity therefore yields

D(rho || omega_t) <= C_0.

Apply lower semicontinuity once more as t decreases to zero to get

D(rho || sigma) <= C_0.

The same sigma was constructed before rho was chosen, so this is the required common bound sup_{rho in E}D(rho||sigma)<=C_0. No interchange of an uncountable supremum with a limit is needed.

Optional consistency checks: if another state sigma' obeys the same radius bound, Donald's identity applied to mu_n gives D(sigma_n||sigma')<=C_0-chi_n ->0. Pinsker then implies sigma'=sigma. This also shows that the center is canonical. Adjoining sigma does not increase capacity; and any broadcaster approximately fixing E with error b also fixes sigma within b by convexity and trace-norm continuity.

## 3. Uniform finite-rank compression

Finite D(rho||sigma) implies supp(rho) is contained in supp(sigma). Let P_N be nonzero finite-rank spectral projections of sigma increasing to its support, and write

q_N=Tr[(I-P_N)sigma],
p_N(rho)=Tr[(I-P_N)rho].

If 0<q_N<1, apply the binary measurement {I-P_N,P_N}. Relative-entropy data processing gives

C_0 >= D(rho||sigma) >= d(p_N(rho)||q_N).

The binary relative entropy can be written

d(p||q)=p ln(1/q)+(1-p)ln(1/(1-q))-h_2(p)
       >= p ln(1/q)-ln2.

Hence

sup_{rho in E}p_N(rho)
 <= min{1,(C_0+ln2)/ln(1/q_N)} ->0.

If q_N=0, support containment instead gives p_N(rho)=0 for every rho. This covers finite-rank centers without dividing by zero.

Choose a state omega_N on P_N H and define

Enc_N(rho)=P_N rho P_N+Tr[(I-P_N)rho]omega_N,
Dec_N: the isometric inclusion of T_1(P_N H) into T_1(H).

These maps are ordinary normal CPTP maps. Let R_N=Dec_N Enc_N. The subnormalized gentle projection inequality gives

||rho-P_N rho P_N||_1 <= 2sqrt(p_N(rho)).

Adding the replacement state yields the halftrace estimate

T(R_N rho,rho) <= sqrt(p_N(rho))+p_N(rho)/2.

Therefore delta_N=sup_{rho in E}T(R_N rho,rho) tends to zero. The slightly looser proposed bound sqrt(p)+p is also valid. In finite-dimensional P_N H the state space is compact; these uniform approximations also establish relative compactness of E directly.

Nothing controls the required cutoff rank solely from C_0 and the error tolerance. The spectrum of this particular center may decay arbitrarily slowly. This is why no energy assumption is required but no universal efficient cutoff follows.

Data processing, applied separately to every finite ensemble, gives C(Enc_N E)<=C(E).

## 4. Exact channel-transfer losses

Let B:T_1(H)->T_1(H tensor H) be a normal broadcaster whose uniform marginal halftrace error on E is at most beta. Define the finite-dimensional broadcaster

B_N=(Enc_N tensor Enc_N) composed with B composed with Dec_N.

For rho_N=Enc_N rho, either marginal satisfies

T((B_N)_a rho_N,rho_N)
 <= T(Enc_N B_a R_N rho,Enc_N B_a rho)
       +T(Enc_N B_a rho,Enc_N rho)
 <= T(R_N rho,rho)+T(B_a rho,rho)
 <= delta_N+beta.

Thus b_2(Enc_N E)<=min{1,beta+delta_N}. There is one compression-loss term here, not two.

For a finite-dimensional EB channel Lambda_N, its pullback

Lambda=Dec_N composed with Lambda_N composed with Enc_N

is normal, CPTP, entanglement breaking, finite-outcome, and has finite-dimensional output support. Its actual error obeys

sup_{rho in E} T(Lambda rho,rho)
 <= sup_{nu in Enc_N E}T(Lambda_N nu,nu)+delta_N.

Choose Lambda_N optimal or with arbitrarily small slack. The finite-dimensional explicit theorem, capacity monotonicity, and monotonicity of its bound in both arguments give

e(E) <= F_C(min{1,beta+delta_N})+delta_N,

F_C(b)=min{1,3072sqrt((C+1)/ln(1/b))},
F_C(0)=0, F_C(1)=1.

This F_C is continuous and nondecreasing on [0,1]. First let N tend to infinity, then let beta decrease to the infimum b_2(E). For b_2=1 the bound is simply 1. No infinite-dimensional compactness of the set of channels is invoked.

For every tolerance strictly above the resulting numerical bound, some finite N and a finite-dimensional Lambda_N achieve it. This proves the finite-outcome, finite-output-support approximate statement. The same reasoning gives the growing-capacity regime whenever b_n ->0 and C_n=o(ln(1/b_n)).

## 5. Why finite-outcome exact reconstruction cannot be inferred

Here is an explicit finite-capacity, zero-broadcast-error family on l^2(N). Let

sigma=sum_{n>=1}2^(-n)|n><n|,
a_n=n^(-2),
rho_n=(1-a_n)sigma+a_n|n><n|,
E={sigma} union {rho_n:n>=1}.

Joint convexity of relative entropy gives

D(rho_n||sigma) <= a_n D(|n><n| || sigma)
                = (ln2)/n <= ln2.

Donald's identity then shows C(E)<=ln2. The family is commuting and is exactly broadcast by the normal countable-outcome channel that measures the basis and prepares |n,n><n,n|, so b_2(E)=0.

Nevertheless, no finite-outcome measure-and-prepare channel fixes every member. The linear range of such a channel lies in the finite-dimensional span of its finitely many prepared states. If it fixed sigma and every rho_n, that range would contain all

rho_n-sigma=a_n(|n><n|-sigma).

These vectors are linearly independent. Indeed, for any finite linear relation, matrix entries outside its finitely many selected basis indices force the coefficient sum to vanish; then each selected diagonal entry forces the corresponding individual coefficient to vanish. This contradicts finite-dimensional range.

Thus the theorem's infimum-only endpoint wording is essential for its finite-outcome assertion. This example does have an exact countable classical reconstruction, but a general exact-channel conclusion is not needed for the transfer proof.

## 6. Checked primary source and priority boundary

Primary source actually read: M. E. Shirokov, arXiv:quant-ph/0510073v2, dated 12 October 2005:
https://arxiv.org/pdf/quant-ph/0510073

Exact locations in that preprint:
- Section 2, equation (3), printed pp.5-6: Donald's identity for arbitrary finite ensembles and comparison states.
- Theorem 1 and equation (25), printed pp.24-27: the optimal average state and relative-entropy radius characterization.
- Theorem 2(D), printed p.29: relative compactness from finite chi-capacity.

The published Part I is “Entropy characteristics of subsets of states. I,” Izvestiya Mathematics 70(6), 1265-1292 (2006):
https://www.mathnet.ru/eng/im730

Published numbering differs: the optimal-average theorem is Theorem 1 and the finite-capacity relative-compactness assertion is Corollary 5. The center and compactness steps are established prior art. Their supplied proof has been checked here for the required infinite-entropy interface. The new input in this continuation is the internally audited, dimension-uniform finite-dimensional broadcasting-to-EB bound; this extension composes that bound with established compactness. No historical-priority or external-review claim follows from this audit.
