ASTRA FINAL CONTINUATION FOR THIS RESEARCH BATCH
9 October 2026 UTC

This continuation contains new checked results and explicit unresolved research
boundaries. It does not replace or duplicate the earlier archives.

REQUIRED BASE RECORD

Astra_Bounded_Capacity_and_Stochastic_Addendum_2026-10-09.zip
Library file ID: libfile_fac8c3f033988191bd67bc3f1604f545
SHA-256: 380ab3b9929d32acb0f02ca5cbd0d89de58f7cd88f9f93e8a0dbdf53e10a1231

That base contains the bounded-capacity theorem, its supporting proofs,
common-comparator dependency, source pin and end-to-end audit. Read it beside
this continuation. Cross-file references to BOUNDED_CAPACITY_BROADCASTING_THEOREM.md
and the original smoothing/sandwich machinery refer to that base. It remains
unchanged. The original third record is also unchanged and is not rebundled.

A. CHECKED ANALYTIC RESULTS

1. Linear logarithmic capacity tradeoff

linear_capacity_probe/LINEAR_LOGARITHMIC_TRADEOFF.md
INDEPENDENT_ADVERSARIAL_AUDIT.md
WEIGHTED_POLAR_AND_SMOOTHING_INDEPENDENT_AUDIT.md

For 0<b=b2(E)<1, with natural logarithms and half-trace reconstruction error,
  e(E) <= min{1, 20480 (C(E)+1)/ln(1/b)}.
C(E) is Holevo capacity, the supremum over ALL finite priors. One full-domain
EB channel reconstructs the whole experiment. Independent analytic audits
checked the weighted polar identity, compatible trace-distance smoother,
constants, supports and common-channel quantifiers. No matching lower-bound
family or historical-priority result is established.

The earlier checked 3072 square-root-logarithmic proof and audit are supplied
in entropy_comparator_continuation/ as dependencies and chronology. The main
new quantitative conclusion is the stronger linear bound above. The optional
zero-offset refinement is excluded from this archive and is not asserted.

2. Separable infinite-dimensional extension

infinite_dimensional_capacity_extension/THEOREM.md
infinite_dimensional_capacity_extension/INDEPENDENT_AUDIT.md

The finite-dimensional reconstruction modulus transfers to normal density
operators and normal CPTP broadcasters/EB channels on any separable Hilbert
space. The written report states the checked 3072 square-root-log bound and
its growing-capacity consequence. It needs no energy constraint or bound on
individual von Neumann entropies. Capacity is defined through relative entropy
to avoid infinity-minus-infinity expressions.

Each positive tolerance above the bound can be achieved with finite outcomes
and finite output support. At zero broadcast error, the conclusion is e=0 as
an infimum; the report does not claim a finite-outcome exact minimizer. Common
reference/tightness machinery is credited to Shirokov. No priority claim is
made for its composition with the new reconstruction theorem.

3. Approximate double Markovity with a classical label

linear_capacity_probe/APPROXIMATE_DOUBLE_MARKOV_CLASSICAL_RECOVERY.md
linear_capacity_probe/DOUBLE_MARKOV_INDEPENDENT_AUDIT.md

For a finite-dimensional cq state with both conditional mutual informations
at most epsilon, there is one EB channel B -> BC with prior-average joint
half-trace error at most
  min{1, 864 sqrt[(I(X:B)+1)/ln(1/epsilon)]}.
Here I(X:B) is the ACTUAL-prior mutual information. This conclusion is
prior-average, not uniform over rare labels. Prepared BC states may be
entangled internally. Approximate common-projective-block structure is not
proved. Recovery is an established imported theorem; priority of this
corollary is unestablished.

These are positive internal analytic AI audits, not formal proof certification,
external human peer review, or evidence of historic-scale significance.

B. PROVED REDUCTIONS AND PARTIAL RESULTS; CENTRAL TARGETS UNRESOLVED

broadcast_inequality/EXACT_REDUCTION.md and BINARY_AFFINITY_REDUCTION.md
record exact reformulations of the broadcast-information/MC entanglement
question. SPECTRAL_BRIDGE_PARTIAL.md proves the candidate spectral bridge for
commuting pairs and equal-rank normalized projections, while rejecting a
false shortcut. The general spectral bridge remains unresolved.

CONSTRUCTIVE_QUANTUM_SQUASHING.md records explicit quantum extensions and
completed exploratory searches. No proof or counterexample to
  E_F + E_D <= 2 E_sq
was obtained. Numerical failures to find a violation do not prove the target
or exclude other squashing channels, larger dimensions or complex families.

linear_capacity_probe/ENTROPY_TREE_OBSTRUCTION.md and
ENTROPY_COMPARATOR_LOCAL_TESTS.md identify limitations of attempted entropy
arguments. The general capacity-free entropy-comparator/classical-recovery
question remains unresolved. Local BKM checks do not establish its nonlinear
version.

entropy_loss_classicalization/POWER_EXPONENT_OBSTRUCTION.md gives a rigorous
qubit exponent boundary for a proposed entropy-loss modulus. It is a specific
obstruction, not a solution of the general capacity-free problem.

named_problem_transfer_probe/BRANDAO_HARROW_CONJECTURE5_BOUNDARY.md records
the domain mismatch and failure of a proposed Petz return-map transfer. It
neither proves nor refutes Conjecture 5. The cited original proposal is verified;
its present open status was not conclusively established.

C. COMPUTATION AND REPRODUCTION

Exploratory scripts, saved optimizer vectors and logs are retained under
broadcast_inequality/. Some early searches used no fixed random seed. Several
scripts contain their original output paths. They are scientific source
snapshots, not a portable push-button optimizer campaign. Do not interpret
tiny endpoint residuals as rigorous certificates.

REPRODUCE.py runs only the explicitly described bounded, deterministic checks.
It does not restart the optimization searches. REPLAY_REPORT.json states
exactly what was replayed and separates exact algebra from floating entropy
evaluations. The analytic theorems are supported by the written proofs and
audits, not by these finite checks.

D. PROVENANCE AND INTEGRITY

EVIDENCE_PINS.txt lists the required base, source pin and primary references.
MANIFEST.json gives file sizes and SHA-256 hashes. SHA256SUMS.txt covers every
other bundled file. Archive paths, CRC and checksums were verified. Only
scientific deliverables, evidence references, scripts/results and concise
status are included. Earlier archives remain immutable.
