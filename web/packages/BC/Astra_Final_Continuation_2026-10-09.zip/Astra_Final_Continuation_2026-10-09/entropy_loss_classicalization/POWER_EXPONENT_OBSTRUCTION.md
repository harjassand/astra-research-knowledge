# Entropy-loss classicalization: a rigorous exponent obstruction

9 October 2026. Independent stress test. Natural logarithms and half trace distance throughout.

## Exact example

For 0<r≤1 take the uniform six-state qubit ensemble

    E_r={ρ_(j,s)=(I+s r σ_j)/2 : j∈{x,y,z}, s∈{−1,+1}}.

Its optimal prior-average reconstruction error over a single entanglement-breaking channel is exactly

    e_p(E_r)=r/3.

Proof: twirl any EB channel by the octahedral rotation group, simultaneously acting on input and output. Convexity of trace distance and invariance of the ensemble show that average error does not increase. The twirled channel has zero translation and scalar Bloch matrix tI. For a depolarizing qubit channel, EB implies t≤1/3: its normalized Choi state is t|Φ><Φ|+(1−t)I/4, and partial transpose has eigenvalue (1−3t)/4. Conversely t=1/3 is EB, explicitly choose one Pauli basis uniformly, measure in that basis, and reprepare the measured eigenstate. The error is r|1−t|/2, minimized at t=1/3.

The channel

    T(ρ)=(2/3)ρ+(1/3)I/2

is self-compatible. A full-domain symmetric extension is

    B(ρ)=(2/3)P_sym(ρ⊗I)P_sym,
    P_sym=(I+SWAP)/2.

Indeed it is CP; Tr[P_sym(ρ⊗I)]=3/2; and each partial trace is (2/3)ρ+(1/6)I. Thus both marginals equal T.

Let h(q)=−q ln q−(1−q)ln(1−q). The ensemble averages before and after T are I/2, hence

    δ_r=χ(E_r)−χ(T(E_r))
       =h((1+2r/3)/2)−h((1+r)/2)
       =(5/18)r²+O(r⁴).

Consequently, any universal bound

    e_p(E)≤K[χ(E)−χ(T(E))]^α

for all self-compatible T and finite ensembles must satisfy α≤1/2. If α=1/2, then K≥sqrt(2/5). This does NOT disprove any exponent 0<α≤1/2, nor the existence of a dimension-free modulus.

## A genuine literature implication, and the missing implication

Seshadreesan and Wilde, Physical Review A 92, 042321, Proposition 32 (approximate faithfulness), establish small quantum discord implies approximate invariance under one EB channel. Their explicit natural-log-compatible estimate is halftrace error at most sqrt(discord), up to log-base conventions. Piani, PRL 117, 080401, gives a hierarchy of symmetric-broadcast recoverability quantities below the EB recoverability quantity and quantum discord.

Primary sources:
- https://link.aps.org/accepted/10.1103/PhysRevA.92.042321
- https://arxiv.org/abs/1501.06855
- https://pure.strath.ac.uk/ws/portalfiles/portal/53822980/Piani_PRL2016_Hierarchy_of_efficiently_computable_and_faithful_lower_bounds_to_quantum_discord.pdf

These results do not supply an upper bound on discord from the two-output Holevo deficit. The hierarchy inequalities have the opposite direction. Iterating a recovery map without a uniform summability/convergence estimate does not fix this gap.

Hayashi–Zhao, arXiv:2601.09995v1, Theorem 1, gives an exact double-Markov block/PVM characterization for arbitrary finite-dimensional A,B,C. It is an exact theorem, not an approximate modulus. In particular, its application to classical A=X does not alone justify a dimension-free approximate result.

Primary source: https://arxiv.org/html/2601.09995v1

A broad two-output bound χ_B+χ_E≤χ_A+I_acc(E_A), if true, would close the gap via discord≤2δ, but it is not proved here. It must not be cited as a known inequality. Neither simple Haar product-copy ensembles nor a two-basis locking heuristic supplied a counterexample during this check.

## Status

Established: exact finite-qubit exponent obstruction, valid also with a classical six-valued label. Not established: a capacity-free positive theorem or a classical-label counterexample to every universal modulus. General quantum-reference approximate-Markov counterexamples cannot be imported without explicitly preserving classicality of X.

## Decisive exclusion: universal-cloner and independent tensor routes

A general argument eliminates information locking attached to a replacement-mixture channel. Let

    T=t id+(1−t)R_ω,  R_ω(ρ)=ω,  0≤t<1.

Flag the two branches before discarding the flag. The flagged ensemble has Holevo information exactly tχ(E); data processing therefore gives χ(T(E))≤tχ(E), for every ensemble, with no barycenter, dimension, or pure-state assumption. Thus δ≥(1−t)χ(E). The constant EB channel R_barρ, where barρ is the ensemble barycenter, satisfies by quantum Pinsker and Jensen

    e_p(E)≤Σ_x p_x sqrt[D(ρ_x||barρ)/2]≤sqrt[χ(E)/2].

Combining proves the exact general root bound

    e_p(E)≤sqrt[δ/(2(1−t))].

This proof does not even need self-compatibility. Standard d-dimensional 1→2 universal-cloner marginals have t=(d+2)/(2d+2)≤2/3, so all ensembles, including arbitrarily high-dimensional locking ensembles, satisfy e_p≤sqrt(3δ/2). Locking cannot give the sought counterexample with these channels.

For an independent product prior and product-state ensemble E=⊗_i E_i, subjected to ⊗_i T_i of this type with t_i≤t_*<1, Holevo additivity gives

    δ=Σ_iδ_i≥(1−t_*)Σ_iχ(E_i)=(1−t_*)χ(E).

The same constant EB channel proves e_p(E)≤sqrt[δ/(2(1−t_*))]. Thus tensorizing weak Pauli states and letting n r² scale cannot produce δ→0 with e_p bounded away from zero; this is an all-EB upper bound, not merely a bad-estimator heuristic.

This does not cover correlated label priors across tensor factors or channels with a nearly noiseless classical algebra. A putative counterexample must use those additional structures, or a genuinely non-replacement self-compatible channel; it cannot be obtained by the uncomplicated locking/universal-cloner or independent weak-state amplification routes.

### Orthogonal classical flags do not rescue that construction

Suppose ρ_x=⊕_j q(j|x)ρ_xj, and T preserves j while its restriction is T_j=t_j id+(1−t_j)R_ωj, with t_j≤t_*<1. Write p_j=Σ_xp_xq(j|x) and E_j for the posterior ensemble in block j. The exact direct-sum entropy identity is

    χ(E)=I(X:J)+Σ_j p_jχ(E_j).

The classical I(X:J) term is unchanged, and the replacement-mixture bound inside each block gives

    δ≥(1−t_*)Σ_jp_jχ(E_j).

The single EB channel which measures j and prepares the corresponding posterior barycenter has average halftrace error at most

    Σ_jp_jΣ_xp(x|j)T(ρ_xj,barρ_j)
      ≤sqrt[(Σ_jp_jχ(E_j))/2]
      ≤sqrt[δ/(2(1−t_*))].

Thus arbitrary classical capacity, branch-dependent priors, and locking inside each orthogonal block are all covered. The assumption is literal block diagonality of the input ensemble; merely having diagonal marginals is not enough.

### Why the generic recovery argument stops

Universal recovery produces one R with prior-average T(ρ_x,RTρ_x)≤O(sqrt δ). Applying R to both outputs of a symmetric extension of T produces a broadcaster S whose equal marginals approximate identity on the ensemble. Iterating S in a binary tree gives 2^k outputs with each marginal error at most k O(sqrt δ), by telescoping and trace-norm contraction.

This is not yet an EB channel. A finite de Finetti/channel-extendibility approximation must still be applied at depth k; its trace-norm error depends on Hilbert-space dimension (or some independently controlled information quantity). Sending k→∞ at fixed δ makes the telescoping error diverge. Sending δ→0 while dimensions also grow does not justify interchanging those limits. A direct recovery proof of the universal root bound therefore needs a new uniform classicalization estimate, or a summable error/entropy-production identity that survives the entire iteration. Approximate recoverability and exact self-compatibility alone do not supply either in the displayed argument.
