# Exact binary reduction and analytic benchmark

Status: partial mathematical progress, no proof or counterexample to the full target.

## A complete operator formulation for the equiprobable binary pure case

For density matrices r,s define

- c(r,s) = Tr(sqrt(r) sqrt(s)), the unsquared affinity;
- J(r,s) = S((r+s)/2) - (S(r)+S(s))/2;
- e(c) = h2((1+sqrt(1-c^2))/2);
- f(c) = h2((1+c)/2) + 1 - e(c).

The target for every equiprobable two-element pure ensemble and every isometric broadcast channel is equivalent to the operator inequality

    2 J(r,s) <= f(c(r,s))

for density matrices of arbitrary finite dimension.

### Necessity

Use pure output states vec(sqrt(r)) and vec(sqrt(s)). They are normalized and have inner product c. Their B marginals are r,s, and their E marginals are their transposes. Thus their marginal Holevo sum is 2J. The input Holevo information is h2((1+c)/2), and its accessible information is 1-e(c).

### Sufficiency (symmetrization)

Represent arbitrary normalized pure outputs as vec(M_0), vec(M_1), with rectangular matrices M_i. Pad if needed. Their overlap is c=|Tr(M_0 M_1^dagger)|. Define positive matrices

    R_i = [sqrt(M_i M_i^dagger) direct-sum sqrt(M_i^dagger M_i)] / sqrt(2).

Their Hilbert-Schmidt norms equal one. The density matrices r_i=R_i^2 have Holevo quantity

    J(r_0,r_1) = [chi(X:B)+chi(X:E)]/2.

This follows directly from the equal-weight block entropy identity. Moreover

    c' = Tr(R_0 R_1) >= |Tr(M_0 M_1^dagger)| = c.

For completeness, writing M_i=U_i D_i V_i, Hilbert-Schmidt Cauchy–Schwarz gives

    |Tr(M_0 M_1^dagger)|^2
    <= Tr(sqrt(M_0 M_0^dagger) sqrt(M_1 M_1^dagger))
       * Tr(sqrt(M_0^dagger M_0) sqrt(M_1^dagger M_1)),

and arithmetic–geometric mean gives the claim. Both summands of f(c) decrease on [0,1]. Hence the operator inequality implies

    chi(X:B)+chi(X:E) = 2J(r_0,r_1) <= f(c') <= f(c).

The symmetrization technique also appears in Ahmed–Smith, arXiv:2609.14031v1 (2026), https://arxiv.org/html/2609.14031v1 . Their nonattainment theorem does not resolve the inequality above.

## Stronger spectral bridge candidate

Write r=sum_i lambda_i |i><i| and s=sum_j mu_j |j><j|. Define classical distributions

    P_ij=lambda_i |<i|j>|^2,
    Q_ij=mu_j |<i|j>|^2.

Candidate, not yet proved universally:

    2 J(r,s) <= h2((1+c)/2) + JS(P,Q).

The canonical purifications measured in the product basis |i>_B tensor |j*>_E yield exactly P,Q. Their classical affinity equals c. The usual binary pure-state accessible-information bound gives JS(P,Q)<=1-e(c), so this bridge would prove the operator inequality. An independent worker is investigating it; consult SPECTRAL_BRIDGE_PARTIAL.md for its proved subclasses.

## Reproducible exploration, not a certificate

search_affinity.py used seed 20261009, analytic gradients and 30 starts per dimension d=3,4,6,8,12. The 150 starts found no positive violation (max about -9.5e-14); optima approached endpoint equalities. The code parameterizes real positive roots as normalized LL^T, so it does not cover all complex pairs. The log, parameters and script are retained.

A separate spectral candidate probe used seed77, 1000 random real pairs per dimension2,3,4,8,16 and 20 finite-difference BFGS starts per dimension2,3,4. Again no positive violation above floating-point noise. This is solely guidance for analytic work.

## Exact negative-isotropic coherence benchmark

For rho=(I-|+><+|)/(d-1), coherence of formation equals

    1                                      for 2<=d<=6,
    log2(d) - (1-2/d) log2(d-1)            for d>6.

Hellmund, Quantum Information and Computation13(2013),379–392, Theorem4.1 proves the minimum diagonal entropy on the sum-zero subspace. Permutation-twirling its minimizing vectors produces rho, giving matching convex-roof upper bounds. Source: https://www.rintonpress.com/xxqic13/qic-13-56/0379-0392.pdf . Its distillable coherence is log2(d/(d-1)). This supplies an exact target for negative-overlap regular-simplex ensembles, which are outside the positive-isotropic branch.
