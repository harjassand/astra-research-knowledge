# Constructive quantum-squashing attack (2026-10-09)

## Status

No counterexample or general obstruction theorem was established. The computations below are exploratory, reproducible searches, not certificates of the conjecture. They go beyond the previously attempted arbitrary pairs of two-qubit output vectors.

## 1. Exact-formation symmetric MC test bed

Consider the maximally correlated state canonically identified with

    G_p = (1-p) I_d/d + p |+><+|,       0 <= p <= 1.

Let F=(1+(d-1)p)/d, gamma(F)=(sqrt(F)+sqrt((d-1)(1-F)))^2/d and

    R(F) = h_2(gamma(F)) + (1-gamma(F)) log_2(d-1).

Its formation is exactly the convex hull co R(F). For d>2 this is R(F) through F=4(d-1)/d^2, followed by the line

    log_2 d + [d log_2(d-1)/(d-2)] (F-1).

For d=2 use R(F) everywhere. Distillable entanglement is exactly log_2 d - S(G_p).

Reason for the exact formation reduction: isotropic LOCC twirling of the associated MC state retains maximally entangled fraction F, giving the usual isotropic-state formation as a lower bound. Conversely, the isotropic minimizing pure Schmidt vector, with one distinguished nonnegative amplitude and all other amplitudes equal, can be twirled by simultaneous basis permutations. Its MC Gram state is exactly G_p. Mixtures achieve the convex hull. Thus both bounds coincide.

Primary sources for the scalar convex-roof minimization and its convex hull:
- Terhal and Vollbrecht, https://arxiv.org/abs/quant-ph/0005062
- Fei and Li-Jost (proof of the all-dimensional convex-hull formula), https://arxiv.org/abs/quant-ph/0602137

### Covariant squashing family

A pure output vector phi_i on (d+1)x(d+1) has amplitudes constant on the ten orbits of simultaneous label permutations fixing i. The first five orbits are (j=k=i), (j=i != k), (k=i != j), (j=k != i), and (j,k,i all distinct). The last five involve an extra invariant basis vector indexed d: (d,d), (d,i), (d,j != i), (i,d), (j != i,d).

Assign arbitrary complex amplitudes to these ten orbits and normalize. Their pairwise overlaps are a common real p, so their uniform Gram state is G_p. This gives a twenty-real-parameter structured quantum squashing, with output dimensions d+1 and d+1, and a rigorously evaluable formation benchmark for p>=0.

Script: search_pyramid_squash.py. Seed 20261009; 25 BFGS starts for each d=3,4,6,8,12, maxiter 250. Objective:

    chi(B)+chi(E)-S(G_p)-[log d - E_F(G_p)].

All 125 runs failed to find a positive value; maxima approached the uninformative p=1 boundary. This does not rule out interior local maxima or larger representations. The code uses the weaker E_F>=0 rather than an exact formula when p<0; therefore negative-p points were not properly tested for exclusion. Full log: pyramid_search.log. Best numerical vector: pyramid_best.json. These boundary vectors are not witnesses.

## 2. Implemented Ahmed–Smith descent for binary MC

Primary source supplied by the parallel proof investigation:

    Ahmed and Smith, No cardinality bound for squashed entanglement,
    https://arxiv.org/html/2609.14031v1

For rho_c = (|00><00|+|11><11|+c|00><11|+c|11><00|)/2,

    E_F = h_2((1+sqrt(1-c^2))/2),
    E_D = 1-h_2((1+c)/2).

Write an extension on the MC support as W, a 2d-by-2d positive matrix. Factoring W into block rows M_0,M_1 gives positive matrices

    P_i = [sqrt(M_i M_i*) direct-sum sqrt(M_i* M_i)]/sqrt(2).

This preserves CMI while producing coherence c'=2Tr(P_0P_1)>=c. Multiplying the resulting extension by c/c' and adjoining two orthogonal fully dephased flags restores c and scales its CMI by c/c'. The paper proves that further rank-support perturbations or entropic-singularity mixing always permit a strict finite-dimensional improvement.

Scripts:
- iterate_binary_squash.py: symmetrization plus optimized mixing with rho_c tensor I/d; endpoint-safe log-grid search for mixing parameter.
- iterate_binary_full.py: additionally applies the paper's kernel-support idea. It adds epsilon K_0 P_1 K_0 to P_0 and epsilon K_1 P_0 K_1 to P_1, normalizes, and optimizes epsilon before rescaling coherence and adjoining flags.

Initial extension is the formation-optimal classical two-pure-state decomposition, with CMI=2E_F. Five rounds of the fuller descent were tested at c=.01,.05,.1,.2,.4,.6,.8,.95. No crossing of E_F+E_D occurred. Representative final CMI gaps above E_F+E_D:

    c=.6:  about .184064 bits, conditioning dimension 114
    c=.8:  about .173795 bits, conditioning dimension 114
    c=.95: about .0685614 bits, conditioning dimension 116

Full output: iterate_binary_full.log. Numerical eigenvalue cutoffs and cancellation mean tiny improvements are not certified. Large positive gaps are merely failures to find a witness, not lower bounds. The theorem gives strict descent, but no rate or guarantee of crossing the desired midpoint bound.

### Simple exact member of this descent family

At c=4/5 start with the optimal formation decomposition, and mix its extension with rho_c tensor I_2/2 with weight t=1/16. In MC block form,

    W_00 = diag(25/64,7/64),
    W_11 = diag(7/64,25/64),
    W_01 = W_10 = I_2/5.

All entries are rational. With r=2 sqrt((25/64)(7/64))=sqrt(175)/32, symmetrization produces

    c' = r + (4/25)/r > 4/5.

Adjoining dephased flags therefore gives a legitimate quantum extension of rho_(4/5) with CMI exactly (4/(5c')) I(W), strictly below I(W). Its CMI is approximately 1.42750115 bits, still well ABOVE E_F+E_D approximately 1.25293 bits. This supplies an explicit nontrivial quantum-squashing construction, but not a counterexample and not a proven separation from optimal classical squashing.

## 3. Further exact two-flag family

Let omega_+/- have MC-support Bloch matrices (I+cX +/- zZ)/2, with c^2+z^2<=1. Attach equally likely pure conditioning states with overlap t. Their mean MC state is rho_c. This separable extension's CMI is explicitly

    2 + 2h_2((1+sqrt(t^2+z^2(1-t^2)))/2)
      - H({lambda_s,+, lambda_s,- : s=+1,-1}) - h_2((1+t)/2),

where

    lambda_s,+/- = [1+sct +/- sqrt((c+st)^2+z^2(1-t^2))]/4.

A differential-evolution diagnostic over c,z,t found no violation. No theorem that the optimum lies at t=0 or t=1 was proved. This compact formula is retained as a reproducible analytic test bed, not an exclusion result.

## Conclusion

The genuinely quantum extension dimension is a real issue even for binary MC states, as the new cardinality theorem shows. Our literal constructive descent improves elementary squashes only modestly and does not falsify the midpoint lower bound. A stronger perturbation direction, a non-symmetric many-label Gram ensemble, or a new entropy/affinity inequality is still needed.

## 4. Negative-coherence regular-simplex endpoint

A further targeted run projects the ten-orbit masks onto the standard representation by subtracting their mean over the label i. Consequently sum_i phi_i=0 exactly, and the normalized overlaps are -1/(d-1). This enforces the Gram state

    G = (I-|+><+|)/(d-1)

without letting optimization escape to the uninformative p=1 boundary. Script: search_simplex_squash.py; seed 551; 12 BFGS starts per d in 3,4,6,8,12,20,32; logs simplex_search.log.

The parallel proof worker identified a primary exact formation theorem for this endpoint: Hellmund, Entanglement and output entropy of the diagonal map, Theorem 4.1, https://www.rintonpress.com/xxqic13/qic-13-56/0379-0392.pdf . The minimum pure-state diagonal entropy in the sum-zero subspace, hence by permutation twirling the exact formation of G, is

    CF(G)=1                          for 2<=d<=6,
    CF(G)=log d-(1-2/d)log(d-1)       for d>6.

ED(G)=log(d/(d-1)) exactly. Initially the run used the rigorous but weaker lower bound h_2(1/d), obtained from max_i |v_i|^2<=(d-1)/d for every normalized sum-zero vector. The stronger exact benchmark still leaves all found CMIs above target:

    d=3:  best CMI 2.16992500, exact target 1.58496250
    d=4:  best CMI 2.19613528, exact target 1.41503750
    d=6:  best CMI 2.01792191, exact target 1.26303441
    d=8:  best CMI 1.78896762, exact target 1.08712889
    d=12: best CMI 1.40420564, exact target 0.82763370
    d=20: best CMI 0.99758667, exact target 0.57279391
    d=32: best CMI 0.71088192, exact target 0.40124465

For large d the optimizer is reaching values close to 2CF, not the required CF+ED. These are local-search upper bounds only. This explicit test addresses a genuinely nonpositive-overlap Gram ensemble, rather than extending the positive-p isotropic family by an invalid formula.
