# Broadcast Holevo inequality: exact reduction, not a resolution

Target for a finite cq ensemble and CPTP map A -> BE:

    chi(X:B)+chi(X:E) <= chi(X:A)+I_acc(X:A).

Status (2026-10-09): No proof or counterexample established in this investigation. In particular numerical searches below are not evidence sufficient to assert it.

## Universal cq reformulation

The universal target is equivalent to the following assertion for every cq state XBE:

    I(B:E) - I(B:E|X) <= I_acc(X:BE).

Necessity: take A=BE and identity channel. Sufficiency: apply this assertion to the output, then use chi(X:BE)<=chi(X:A) and I_acc(X:BE)<=I_acc(X:A). The entropy identity is exact.

## Pure-input equivalence to a squashed-entanglement inequality

For pure ensemble {p_x, |psi_x>_A}, introduce

    |Omega>_{RR'A} = sum_x sqrt(p_x) |x>_R |x>_{R'} |psi_x>_A,
    omega_RR' = Tr_A |Omega><Omega|.

This is a maximally correlated state. Write H=H(p), and use logarithms consistently (bits below). Known identities give

    E_F(omega) = H - I_acc(X:A),
    E_D(omega) = H - S(omega) = H - chi(X:A).

For any isometry V:A->BE, let |phi_x>=V|psi_x>. Its induced extension omega_RR'B has

    S(RB)=S(R'B)=H + sum_x p_x S(phi_x^B),
    S(RR'B)=S(E),
    S(B)=S(B).

Consequently

    I(R:R'|B) = 2H - chi(X:B)-chi(X:E).

Every extension of omega is obtained by a channel on the purifier A, and every such channel admits an isometry A->BE. Therefore the pure-input target for all ensembles/channels is EXACTLY equivalent to

    E_F(omega) + E_D(omega) <= 2 E_sq(omega)

for every maximally correlated omega.

Allowing an arbitrary rather than isometric broadcast channel causes no problem in the pure-input reduction: dilate A->BEF and put F with either receiver; dropping F can only decrease the corresponding Holevo information.

This does NOT establish the mixed-input target. Purifying the input states changes both chi and I_acc, so the pure-input statement cannot simply be applied to the original mixed ensemble.

## Classical extensions do satisfy the entanglement inequality

For a classical extension sum_y q_y omega_y \otimes |y><y|, every omega_y remains supported on the maximally correlated subspace. For each omega_y,

    I(R:R')_{omega_y} = H(diag omega_y) + E_D(omega_y),
    E_F(omega_y) <= H(diag omega_y).

Both E_F and E_D on maximally correlated states are convex (the latter is relative entropy of coherence under the canonical identification). Thus

    sum_y q_y I(R:R')_{omega_y} >= E_F(omega)+E_D(omega).

The exact missing step is extension from classical conditioning to arbitrary quantum conditioning. Defining squashed entanglement with classical extensions would make the desired lower bound immediate; replacing quantum extensions by classical ones is not legitimate in general.

## Literature checked

1. Christandl and Winter, Uncertainty, Monogamy and Locking of Quantum Correlations, IEEE TIT 51 (2005), arXiv:quant-ph/0501090, https://arxiv.org/pdf/quant-ph/0501090 . Proposition 4 and discussion establish the E_F=H-I_acc identities for flower/maximally correlated constructions. Proposition 6 separates E_F and E_sq on generalized flower states. It does not refute the displayed inequality: E_F is about log d, 2E_sq about log d plus lower-order terms, while E_D is small. The standard flower states have E_F=E_sq and also do not refute it.
2. Janzing and Steudel, Quantum broadcasting problem in classical low-power signal processing, PRA 75, 022309 (2007), https://arxiv.org/abs/quant-ph/0609162 . Their explicit broadcasting-Holevo optimization is the same average-output information objective. The retrieved primary abstract and definition do not contain the target accessible-information bound. They study timing ensembles and energy-distribution bounds.
3. Brandao, Piani, Horodecki, Generic emergence of classical features in quantum Darwinism, Nat Commun 6,7908 (2015), https://doi.org/10.1038/ncomms8908 . Identifies discord with asymptotic average broadcasting loss as number of recipients grows. This asymptotic result is not the finite two-recipient factor-1/2 bound required here.

Novelty status: no claim that the exact inequality or its negation is absent from literature. Searches did not locate it.

## Numerical probes (nonproof)

- 100 BFGS random starts over pairs of pure two-qubit output vectors, uniform binary label, using exact binary-pure accessible information 1-h_2((1-sqrt(1-c^2))/2). No positive violation found; optima approached zero.
- 100 BFGS random starts over pairs of mixed two-qubit states. Used I_acc upper bound supplied by purifications attaining root fidelity F, namely 1-h_2((1-sqrt(1-F^2))/2). No positive violation of this weaker test found.
- 100 BFGS random starts for infinitesimal uniform binary ensembles rho±tD, optimizing rho and the most violating traceless direction. Exact second-order necessary condition tested:

    K_BKM,B + K_BKM,E - K_BKM,BE - K_SLD,BE <= 0.

Here partial traces pull the marginal quadratic forms back to BE. No positive eigenvalue found. Near-boundary maxima approached zero from below.

Scripts: search.py, search_mixed.py, search_metric.py in this directory. Random seeds were not fixed, so these are exploratory diagnostics, not reproducible certificates.

## Operational scope warning

Even a proof would first bound the measurement information loss (discord) chi-I_acc by the sum of the two Holevo losses. An operational entanglement-breaking recovery statement would require a further valid recoverability theorem and conversion with constants/norms specified. It does not directly provide trace-norm recovery merely by algebra.

## Structured follow-up and eliminated activation routes

- Tensor products of maximally correlated candidates cannot activate a violation: E_F is additive on MC states, E_D is additive by its entropy formula, and E_sq is additive generally. Hence the signed gap 2E_sq-E_F-E_D adds exactly. Adding a tensor-product MC catalyst contributes only its own signed gap; it cannot turn nonnegative gaps negative. Locally flagged direct sums give weighted sums by the flags property, likewise not a route by themselves.
- Primary source for the formation/coherence-cost additivity mechanism: Winter and Yang, Operational Resource Theory of Coherence, PRL116,120404 (2016), https://arxiv.org/abs/1506.07975 . Earlier primary MC additivity discussion: Horodecki et al., https://arxiv.org/abs/quant-ph/0207031, Section VI.
- Standard/generalized flower states have optimal *trivial* squashing, by the channel uncertainty calculation in Christandl–Winter. Whenever trivial squashing is optimal on an MC state, 2E_sq=I(R:R')=H(diagonal)+E_D, and the desired lower bound follows immediately from E_F<=H(diagonal). Thus no state in this subclass can falsify it, regardless of how large its E_F/E_sq separation becomes.
- Multipartite flower states do separate quantum and classical squashing for one multipartite-information definition: Yang et al., https://arxiv.org/abs/0704.2236 . This is not a bipartite MC counterexample. Grouping copies of the repeated classical labels into two parties is locally isometric to the original bipartite flower state, removing this proposed route.
- Searches specifically for bipartite maximally correlated quantum-versus-classical squashing or a lower bound relating E_F+E_D to 2E_sq did not locate a primary proof/counterexample. This is a limited search result, not a certified statement of open-problem status.

At this point the concrete structured flower/tensor routes are exhausted. A decisive next result requires either an explicit nontrivial quantum squashing of a non-flower maximally correlated state whose CMI is below E_F+E_D, or a theorem proving that no such extension exists. The general mixed-input target is a further issue even if the pure-input version is resolved.
