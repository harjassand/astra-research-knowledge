# Spectral entropy bridge: exact partial results

Let J=JS(r,s), N=JS(P,Q), c=Tr(sqrt(r)sqrt(s)), and H(x)=h_2((1+x)/2). The candidate is 2J-N <= H(c).

## Exact canonical-purification reformulation

Put |a>=|sqrt(r)>, |b>=|sqrt(s)> and Omega_AB=(|a><a|+|b><b|)/2. Then both marginals are m=(r+s)/2 up to transpose, S(Omega)=H(c), and

    I(A:B)_Omega - [S(r)+S(s)] = 2J-H(c).

Measuring A in an r eigenbasis and B in the conjugate s eigenbasis gives conditional distributions P_ij=lambda_i |U_ij|^2 and Q_ij=mu_j |U_ij|^2. Thus the candidate is equivalent, for this special cq ensemble, to

    H(Z|A)+H(Z|B) >= H(Z|AB)+H(Z|IJ).

This is NOT ordinary SSA, and the measurement I,J cannot be replaced by an arbitrary measurement. This reformulation is a precise gap rather than a proof.

## Proven: commuting states

For commuting r,s, N=J (the NS functional reduces to the classical JS functional even with eigenvalue degeneracies). The canonical pure-state Holevo bound J<=H(c) proves the candidate.

## Proven: equal-rank normalized projections, including all pure pairs

Suppose r=P/k and s=Q/k with P,Q projections of the same rank k. Let t_l in [0,1], l=1,...,k, be the squared cosines of their principal angles. The principal-angle decomposition gives

    c=(1/k) sum_l t_l,
    J=(1/k) sum_l H(sqrt(t_l)),
    N=1-c.

Since f(t)=H(sqrt(t)) is concave, J<=H(sqrt(c)). It is therefore enough to establish

    2H(sqrt(c))-H(c)-1+c <=0,  0<=c<=1.

Here is an exact scalar proof. Define g(c) as the left side. It is continuous, with g(0)=g(1)=0. For 0<c<1, its second derivative obeys the convergent expansion

    (ln 2) g''(c)
      = sum_{k>=0} (2k+2) c^(2k) [1/(4k+3)-c/(4k+5)] >=0.

Thus g is convex and lies below the chord between its zero endpoints. This proves the whole equal-rank projection class, with no numerical assumption.

For the concavity claim, the elementary entropy series is

    f(t)=1-(1/ln 2) sum_{n>=1} t^n/[2n(2n-1)],

whose second derivative is nonpositive on (0,1).

## Invalid shortcut explicitly excluded

The tempting universal estimate J<=H(sqrt(c)) is false. Take commuting r=|0><0| and s=I_d/d. Then c=d^(-1/2), while

    J=1 - [(d+1) log_2(d+1)-d log_2 d]/(2d).

Hence 1-J is asymptotic to (log_2 d)/(2d), whereas 1-H(sqrt(c)) is asymptotic to 1/(2 ln(2) sqrt(d)); for sufficiently large d, J>H(sqrt(c)). Therefore the projection-class proof does not extend merely by asserting this stronger bound.

Status: the unrestricted bridge remains unproved and unrefuted by this analytical pass.
