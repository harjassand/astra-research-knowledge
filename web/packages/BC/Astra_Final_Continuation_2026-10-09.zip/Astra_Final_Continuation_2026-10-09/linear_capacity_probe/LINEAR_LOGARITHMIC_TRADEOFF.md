# A linear logarithmic capacity tradeoff from broadcast-compatible smoothing

9 October 2026. Original analytic derivation; an independent proof audit has passed (see WEIGHTED_POLAR_AND_SMOOTHING_INDEPENDENT_AUDIT.md). This is a separate proposed strengthening, not an edit to the checked theorem.

## Theorem

With the experiment definitions in BOUNDED_CAPACITY_BROADCASTING_THEOREM.md and natural logarithms, for 0<b=b₂(E)<1,

    e(E) ≤ min{1, 20480 (C(E)+1)/ln(1/b)}.

The proof uses the already checked pair bridge Δ(σ,ρ)≤7 b^(1/4) and sandwich modulus h(u)≤20u^(1/192). Its new ingredient is a near-commuting substate estimate, followed by a trace-distance rather than fidelity optimizer. It requires no extra capacity, label, or cardinality assumption.

## 1. New substate estimate

Let σ be faithful, ρ a state, S=√σ, A=√ρ, and

    X=S⁻¹(SρS)^(1/2)S⁻¹, so XσX=ρ.

Set Δ=F_root(σ,ρ)−Tr(SA). For every R>1 there is a positive subnormalized τ≤R²σ such that

    ||ρ−τ||₁ ≤ (D(ρ||σ)+ln2)/(2 ln R) + 2√(2RΔ).       (N)

Proof. Use a unitary extension of the polar decomposition SA=WP. Then XS=AW*, SX=WA. The kernels of X and A coincide, so, with X⁺ the pseudoinverse,

    P=A X⁺ A.

Indeed SX=WA implies SA=SX X⁺ A=WA X⁺ A. Put E=A−XS=A(I−W*). Cyclicity gives exactly

    Tr(X⁺ EE*)=Tr[P(2I−W−W*)]=2Δ.

Here Tr(PW)=Tr(WP)=Tr(SA) is real. The rows of E in ker X vanish.

Let Q=1_{X≤R}, P_R=I−Q, p=Tr(ρP_R), and q=Tr(σP_R). Then p=Tr(σX²P_R)≥R²q. Applying data processing of relative entropy to {P_R,Q},

    D(ρ||σ) ≥ p ln(p/q)+(1−p)ln[(1−p)/(1−q)]
               ≥ 2p ln R−ln2.

Set τ=S X² Q S. This is positive, τ≤R²σ, and Trτ=1−p. Define B=QA and D_0=QXS. Their Hilbert–Schmidt norms both equal √(1−p), and

    ||B−D_0||₂² ≤ R Tr(X⁺ EE*)=2RΔ.

Because AQA=B*B and τ=D_0*D_0,

    ||AQA−τ||₁ ≤ (||B||₂+||D_0||₂)||B−D_0||₂
                 ≤2√(2RΔ).

Finally ρ−AQA=A P_R A≥0 has trace p. This proves (N). Singular ρ causes no problem because of the common kernel and pseudoinverse identities.

## 2. Compatible trace-distance optimizer

Choose a capacity center σ, as in the checked theorem, so D(ρ||σ)≤C for every promised ρ and σ can be included in the family. Let M≥1 and 0<δ<1/4. Suppose each ρ has some τ₀ satisfying

    0≤τ₀≤Mσ, Trτ₀≤1, ||ρ−τ₀||₁≤δ.

On Kσ={0≤τ≤Mσ, Trτ≤1}, minimize

    J_(ρ,σ)(τ)=||ρ−τ||₁+λ Qσ(τ),  λ=δ/M,
    Qσ(τ)=||σ^(−1/4)τ σ^(−1/4)||₂².

The unique minimizer G satisfies J(v)−J(G)≥λQσ(v−G)≥λ||v−G||₁². Since Qσ(τ₀)≤M,

    ||ρ−G||₁≤2δ, t=TrG≥1−2δ>1/2.

Thus ρhat=G/t obeys ρhat≤2Mσ and T(ρhat,ρ)≤2δ. The latter follows by adding the normalization cost |1−t|≤||ρ−G||₁. Moreover G(σ,σ)=σ: for t≤1, J≥1−t+λt², which is decreasing on [0,1], and equality is attained by σ.

For any CPTP T, set dρ=||Tρ−ρ||₁ and dσ=||Tσ−σ||₁. Exactly the reference-transport and strong-convexity argument in the checked smoothing proof gives

    ||TG−G||₁ ≤(1+√2)√(ξ/λ)+2M√dσ+M dσ,             (T)
    ξ=dρ+(2M+2λM²)√dσ+M dσ.

For clarity, the transport of τ=√σ A₀√σ with 0≤A₀≤MI to √(Tσ)A₀√(Tσ), followed by downward trace clipping, changes its trace norm by at most 2M√dσ+M dσ. Its quadratic objective increases by at most 2M²√dσ; clipping only decreases that term. Trace-distance contraction and Qσ data processing make TG feasible at the new reference with objective at most the old minimum. Transporting in both directions bounds the two minima within ξ. The objective gaps of TG and the transported old minimizer are ≤ξ and ≤2ξ. Strong convexity and the transport bound prove (T). All inverses are taken on the reference support; no spectral conditioning parameter appears.

If T is either marginal of a broadcaster with halftrace error b, both dρ,dσ≤2b. Since λM=δ<1/4,

    ξ≤9M√b,
    ||TG−G||₁≤13M δ^(−1/2)b^(1/4).

For example, the first term is at most 3(1+√2)Mδ^(−1/2)b^(1/4), and the remaining two terms are at most (2√2+2)M b^(1/4), absorbed in the stated constant. Normalization divides halftrace error by 2t>1. Consequently the SAME broadcaster works on the entire normalized smoothed family and σ with error

    g≤13M δ^(−1/2)b^(1/4),

where taking the maximum with b does not enlarge this bound.

## 3. Quantitative conclusion

Write L=ln(1/b), A₀=4096, and δ=A₀(C+1)/L. If L≤4A₀(C+1), the proposed bound 5A₀(C+1)/L is at least 5/4, so the result is trivial. Hence assume L>4A₀(C+1), and δ<1/4. Set

    R=exp[(C+ln2)/δ],   M=R²≤exp(2L/A₀).

The capacity center is also broadcast to error b, so the checked pair bridge gives Δ≤7b^(1/4). The new estimate (N) yields a subnormalized τ₀≤Mσ with

    ||ρ−τ₀||₁≤δ/2+√56 exp[−L/8+L/(2A₀)]≤δ.

For the final inequality it suffices to use δ≥A₀/L and L≥4A₀; the left exponential decays faster than A₀/(2L), and the logarithmic comparison is already overwhelmingly negative at L=4A₀.

Use Section 2 to make the smoothing compatible. Dilute the normalized smoothed states exactly as in the checked theorem, with a=1/[2(2M−1)], and then apply its already checked sandwich modulus. Channelwise undilution and the two approximation legs give

    e(E)≤4δ+8M h(min{1,g})
        ≤4δ+160M (13M δ^(−1/2))^(1/192) exp(−L/768).

Because 160·13^(1/192)<163, δ⁻¹≤L, and

    1/768−2(193/192)/4096 > 1/2048,

the final term is at most

    163 L^(1/384) exp(−L/2048).

This is at most A₀/L≤δ for L≥4A₀. To check it exactly, the logarithm of its ratio to A₀/L is

    ln163+(1+1/384)ln L−L/2048−ln4096.

Its derivative is negative for L≥16384, and its value at 16384 is less than −1.49. Therefore

    e(E)≤5δ=20480(C+1)/ln(1/b).

The proof applies to any broadcaster with error b. Arbitrarily small slack and passage to a limit cover the infimum defining b₂. At b₂=0 the checked exact theorem supplies e=0. Every actual reconstruction is one common EB channel on the full input algebra, with the support extension and encoder/decoder composition of the checked theorem. The nonlinear smoother is used only in channelwise inequalities and is never implemented on an unknown input.

## Consequence and limits

This improves the square-root logarithmic upper bound to a linear logarithmic one. Equivalently, persistent e≥ε requires C+1≥(ε/20480)ln(1/b₂). It does not change the qualitative threshold C=o(ln(1/b₂)) and does not provide a matching counterexample. No novelty or historical-priority assessment has been made.
