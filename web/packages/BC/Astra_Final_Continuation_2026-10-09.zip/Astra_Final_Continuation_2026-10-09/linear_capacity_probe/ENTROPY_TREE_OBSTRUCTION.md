# What the covariance-tree proof does not imply about entropy

9 October 2026. A rigorous obstruction to a naive proof route, not a counterexample to the entropy-comparator conjecture.

## 1. Spectral domination does not lift to entropy-loss domination

Let P_N be a lazy reversible bounded-degree expander Markov kernel on N points, with uniform stationary distribution and spectral gap at least γ>0 independent of N. Laziness makes its spectrum nonnegative. Let Π_N reset every input to the uniform distribution. On real functions,

    I−Π_N ≤ γ⁻¹(I−P_N).

This is exactly the kind of universal quadratic/Dirichlet comparison furnished by the common spectral comparator.

For a point mass δ_x, however,

    D(δ_x||u)−D(Π_Nδ_x||u)=lnN.

The support of P_Nδ_x has at most d+1 points if the underlying graph degree is d, so

    D(δ_x||u)−D(P_Nδ_x||u)=H(P_Nδ_x)≤ln(d+1).

Thus no universal constant can pass this quadratic comparison through relative entropy for the SAME comparator Π_N. The ratio grows at least lnN/ln(d+1).

This is not a counterexample to existence of another EB comparator: the identity channel on a classical algebra is already EB and has zero entropy loss. It proves that the checked C4 inequality alone cannot establish the proposed entropy theorem by applying a scalar/operator functional calculus to its quadratic forms.

## 2. The precise tree obstruction

The existing proof constructs unbiased leaf estimators z and controls their covariance through an exact sibling second-moment recursion. Its regression step is quadratic. A relative-entropy variational argument instead requires control of exponential moments of those estimators.

Even for commuting random variables with identical marginals, arbitrary sibling dependence gives only the Hölder bound

    E exp[(z_1+...+z_r)/r] ≤ E exp(z_1).

There is no independent-product factorization and no automatic 1/r improvement in the logarithmic moment-generating function. Covariance bounds do not repair this: rare perfectly correlated large outcomes can have bounded covariance while making exponential moments arbitrarily large.

The spectral threshold also hides a concrete information issue. A bounded-degree expander can have every nonconstant eigenvalue below the C4 supercritical threshold, so the spectral construction is allowed to return Π_N, while one channel use still retains lnN−O(1) bits about a uniform point input. Those many fast modes collectively carry almost all the information. An entropy proof must retain nonlinear likelihood information that is invisible to the selected slow eigenspace.

This is analogous to nonlinear reconstruction below a second-moment/Kesten–Stigum threshold. The analogy is a guide, not an imported theorem.

## 3. Exact missing inequality

A sufficient ensemble-level target would be: for a self-compatible channel Φ and an ensemble E, find ONE POVM M with

    I(X:M(A)) ≥ 2χ(ΦE)−χ(E).

Equivalently, its measurement Holevo loss would be at most twice the one-step loss through Φ. Small measurement loss then yields an EB reconstruction by a common recovery map. A slightly weaker dimension-free modulus would also suffice.

The simple proposed joint-output inequality

    χ(X:B)+χ(X:C) ≤ χ(X:BC)+I_acc(X:BC)

would imply this after data processing. It remains unproved here. Product-output pure-state ensembles reduce it to a nontrivial coherence-of-formation inequality on weighted Gram matrices, and are being checked separately.

What is missing from the tree approach is an ENTROPY reconstruction or likelihood-ratio recursion which produces a common POVM satisfying this bound. The verified covariance recursion, the new weighted-polar substate lemma, and the bounded-capacity theorem do not supply that inequality. No general entropy comparator or capacity-free double-Markov recovery theorem is claimed.
