# Operational approximate double Markovity for classical labels

9 October 2026. Derived corollary of the internally checked linear capacity theorem. Independent proof audit completed with no mathematical correction; see DOUBLE_MARKOV_INDEPENDENT_AUDIT.md. It does not assert proximity to an exact common-block Markov state.

## Statement

Let ω_XBC=Σ_x p_x |x><x|⊗ρ_x^BC be finite dimensional, with X classical, and put C=I(X:B)_ω, using natural logarithms. Suppose

    I(X:C|B)_ω≤ε,  I(X:B|C)_ω≤ε,  0<ε<1.

Then there is ONE entanglement-breaking CPTP map Λ:B→B⊗C such that

    T[(id_X⊗Λ)(ω_XB),ω_XBC]
       ≤ min{1,864√[(C+1)/ln(1/ε)]}.                    (DM)

Thus bounded ordinary mutual information and vanishing double conditional mutual information imply operational reconstruction of the entire cq joint state from a measurement on B followed by preparation of a BC state. Unlike the original experiment theorem, the capacity assumption here is just the actual-prior quantity I(X:B), not a supremum over alternative priors. The result is prior-average, not uniform over arbitrarily rare x.

The same statement holds from C with C replaced by I(X:C). These two reconstruction channels are not claimed to have identical outcomes or to arise from compatible projective measurements. Prepared BC states may themselves be entangled across B:C; the channel is EB across its input and entire BC output.

## 1. From double CMI to one approximate broadcaster

The established quantum recoverability inequality gives CPTP maps R_B:B→BC and R_C:C→BC with

    Σ_x p_x T[R_B(ρ_x^B),ρ_x^BC]≤√ε,
    Σ_x p_x T[R_C(ρ_x^C),ρ_x^BC]≤√ε.

These follow from recovery fidelity at least exp(−ε/2) and Fuchs–van de Graaf; the cq block structure identifies joint trace distance with average conditional trace distance. Both maps are chosen for the full cq state and are independent of x.

Write r_x and s_x for the respective conditional trace errors, and U=Tr_C∘R_C:C→B. Define the full-domain broadcaster

    J=(id_B⊗U)∘R_B:B→B⊗B.

Its first marginal error on ρ_x^B is at most r_x. Its second is at most r_x+s_x, by applying contraction first to R_B(ρ_x^B) versus ρ_x^BC and then tracing R_C(ρ_x^C). Hence

    Σ_x p_x max_a T[J_a(ρ_x^B),ρ_x^B]≤2√ε.

For u=ε^(1/4), all labels outside a set of prior probability at most 2ε^(1/4) have uniform broadcasting error at most u.

## 2. From actual-prior Holevo information to capacity on good labels

Let σ=ω_B. The exact identity

    Σ_x p_x D(ρ_x^B||σ)=I(X:B)=C

and Markov's inequality show that, for any 0<δ<1, the labels with D(ρ_x^B||σ)>C/δ have total probability at most δ. (For C=0, all positive-prior conditional states equal σ and this trimming is unnecessary.) On the surviving labels, the family has sup-prior Holevo capacity at most C/δ, because for every finite prior q,

    χ_q=Σ_x q_x D(ρ_x^B||σ)−D(Σ_x q_xρ_x^B||σ)≤C/δ.

Intersect this set with the broadcast-good set from Section 1. The union of discarded labels has probability at most δ+2ε^(1/4).

The checked linear experiment theorem, with constant K=20480, supplies one EB channel V:B→B satisfying

    sup_good x T[V(ρ_x^B),ρ_x^B]
        ≤ min{1,4K(C/δ+1)/ln(1/ε)}.

If the good set is empty, the discarded-probability bound is at least one and the following estimate is simply trivial. Therefore, for some V in all cases,

    Σ_x p_x T[V(ρ_x^B),ρ_x^B]
        ≤δ+2ε^(1/4)+81920(C/δ+1)/L,
    L=ln(1/ε).

Compose with the first recovery map: Λ=R_B∘V is EB from B to BC, and

    T[(id_X⊗Λ)(ω_XB),ω_XBC]
      ≤√ε+2ε^(1/4)+δ+81920(C/δ+1)/L.                 (A)

## 3. Explicit modulus

Set a=81920(C+1)/L. If a≥1, the right side of (DM) before clamping exceeds one, so the assertion is trivial. Otherwise take δ=√a. Then

    δ+81920(C/δ+1)/L≤δ+a/δ+a≤3√a.

For every L>0,

    √L e^(−L/2)≤1,
    2√L e^(−L/4)≤2,

so √ε+2ε^(1/4)≤3/√L. Consequently (A) is bounded by

    [3√81920+3] √[(C+1)/L]
      <864√[(C+1)/L],

proving (DM). If the finite-dimensional infimum needs slack, take a convergent subsequence in the compact EB channel set.

## Stronger sup-prior hypothesis

If the conditional B-state family itself has capacity at most C_* uniformly over priors, the entropy trimming is unnecessary. Directly from Section 1,

    T[(id_X⊗Λ)(ω_XB),ω_XBC]
      ≤min{1,√ε+2ε^(1/4)+81920(C_*+1)/ln(1/ε)}.

## External context and limitations

Hayashi and Zhao, “Double Markovity for quantum systems,” arXiv:2601.09995 (January 2026), Theorem 1, gives an exact common-projective-block characterization when both CMIs vanish: https://arxiv.org/html/2601.09995v1 . The present corollary concerns an operational approximate version with classical X and bounded I(X:B). It does not prove their structural conclusion approximately and is not asserted to resolve an open conjecture from that paper.

The imported recovery theorem is Fawzi and Renner, “Quantum conditional mutual information and approximate Markov chains,” arXiv:1410.0664: https://arxiv.org/abs/1410.0664 . Existence of a universal recovery map is sufficient; no special Petz implementation is required.

No priority assessment has been completed. In particular, related approximate local-broadcasting and quantum-Darwinism results may subsume or strengthen this operational consequence.
