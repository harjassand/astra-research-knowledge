# Local tests of a proposed entropy comparator

9 October 2026. This file records a concrete unresolved target and completed obstruction tests. It is not a proof of the target.

## Target

For a σ-preserving, KMS-positive, KMS-selfadjoint, genuinely self-compatible physical channel Φ, seek a σ-preserving EB channel Ψ and universal K such that for every state ρ,

    D(ρ||σ)−D(Ψρ||σ) ≤ K[D(ρ||σ)−D(Φρ||σ)].

An ensemble-average variant, allowing Ψ to depend on the ensemble, would already give a useful capacity-free Holevo-loss-to-classical-reconstruction result after a suitable recovery step. This is substantially stronger than the checked bounded-capacity theorem.

## Exact local necessary condition

For ρ_t=σ+tA, TrA=0 and A Hermitian, the relative entropy Hessian is

    D(ρ_t||σ)=(t²/2) Tr[A Ωσ⁻¹(A)]+O(t³),
    Ωσ⁻¹(A)=∫₀∞ (σ+sI)⁻¹ A (σ+sI)⁻¹ ds.

Thus the proposed comparator necessarily obeys, as quadratic forms on traceless Hermitian perturbations,

    Ωσ⁻¹−Ψ*Ωσ⁻¹Ψ ≤ K(Ωσ⁻¹−Φ*Ωσ⁻¹Φ).

This is the Bogoliubov–Kubo–Mori metric. It is not the sandwiched Rényi-2 metric used by the checked C4 proof. In an eigenbasis of σ, the coefficient on A_ij is

    c(σ_i,σ_j)=(lnσ_i−lnσ_j)/(σ_i−σ_j),

with c(a,a)=1/a.

## Thermal-qubit test: no counterexample, exact local constant 2

Let σ=diag(1−s,s), 0<s<1, and Φ be generalized amplitude damping with relaxation γ=1/2 and stationary excitation s. It is a convex mixture of zero-temperature downward and upward amplitude damping channels at damping 1/2, each of which has a symmetric two-output extension. Hence Φ is self-compatible. It fixes σ, is positive and selfadjoint in the relevant diagonal KMS coordinates, acts on population perturbations by 1/2, and on both real and imaginary coherences by 1/√2.

Let Ψ dephase in the σ eigenbasis. Its entropy-loss Hessian vanishes on population perturbations and equals the full BKM form on coherences. For Φ, the corresponding loss fractions are 3/4 on populations and 1/2 on coherences. Consequently the local necessary condition holds with K=2, uniformly as s→0. Extremely small eigenvalues alone do not break the local conjecture.

## Why fixed σ-eigenbasis pinching is not a general answer

A σ-preserving EB Petz measurement channel can retain almost all of a noncommuting X direction when σ is close to maximally mixed, while pinching in a fixed nondegenerate σ eigenbasis destroys that direction. The comparator must be allowed to choose a POVM adapted to Φ; σ-basis dephasing is not universally sufficient.

## A tempting modular gain that self-compatibility blocks in the two-level model

A generic coherence map that sends a pair of reference weights (a,b) to (ta,b) and attenuates the coherence by √t has BKM retention ratio

    t c(ta,b)/c(a,b) → 1 + ln(t)/ln(a/b)

when a/b→∞. Hence a single channel can appear to retain nearly all BKM information while attenuating an amplitude by a constant.

This does not directly make a broadcasting counterexample. The symmetric pure isometry which splits the HIGH-probability basis vector while duplicating the rare vector necessarily puts order-a probability into the output level which was supposed to remain rare. The spectral enhancement disappears. The standard symmetric one-excitation splitter instead splits the rare branch, yielding reference weights approximately (a,b/2), coherence factor 1/√2, and BKM retention asymptotically 1/2. This is a completed check of the simplest rare-eigenvalue mechanism, not a general no-go proof.

## Status

No counterexample or proof of the entropy comparator has been obtained. In particular, local BKM comparison would not alone establish the nonlinear boundary-state entropy inequality. A full argument must control arbitrary modular spectra and arbitrary states, or an explicit family must violate it. The completed linear capacity theorem and approximate double-Markov corollary do not depend on this conjecture.
