# Independent audit: operational approximate double Markovity

9 October 2026 UTC. Audited `APPROXIMATE_DOUBLE_MARKOV_CLASSICAL_RECOVERY.md` end to end. This audit imports the independently checked linear capacity theorem with constant K=20480; it does not independently reprove all of that theorem's prerequisites. Natural logarithms and halftrace distance T=||·||₁/2 are used throughout.

## Verdict

**PASS. No mathematical correction is required.** For a finite-dimensional cq state ω_XBC with I(X:C|B), I(X:B|C) ≤ ε, 0<ε<1, there is a single entanglement-breaking CPTP map Λ:B→BC satisfying

    T((id_X⊗Λ)(ω_XB),ω_XBC)
        ≤ min{1,864 sqrt[(I(X:B)+1)/ln(1/ε)]}.

The information quantity really is the actual-prior mutual information. No supremum over alternative priors is assumed for the original ensemble. The conclusion is prior-average reconstruction by a common channel, and makes no uniform promise on rare labels. This is an operational consequence, not an approximate common-PVM theorem or a theorem of proximity to an exact double-Markov state. No novelty determination was part of this audit.

## 1. Recovery maps, fidelity convention, and classical labels

Fawzi–Renner's original statement uses root fidelity F(ρ,σ)=||√ρ√σ||₁ and base-two CMI. Its main-result equation (3), converted to nats, gives a channel R_B:B→BC with

    F(ω_XBC,(id_X⊗R_B)(ω_XB)) ≥ exp[−I(X:C|B)/2].

The public primary source was checked directly: https://arxiv.org/html/1410.0664v3, Introduction, Main result, equations (2)–(3), and its fidelity footnote. The displayed trace-distance implication also appears in equations (6) and the adjacent explanation. Only existence is needed; a universal map independent of all tripartite extensions, or an explicit Petz implementation, is unnecessary.

Fuchs–van de Graaf gives joint halftrace error ≤sqrt(1−exp(−ε))≤√ε. Since R_B acts solely on B, it does not alter classical X. The difference of the two joint states is block diagonal in X, so this joint distance equals Σ_x p_x r_x, where r_x=T(R_Bρ_x^B,ρ_x^BC). The recovery map is one map for the full cq state; it is not selected separately for each x.

Apply the same theorem to the ordering X,C,B, and swap output factors to the order B,C. This yields one CPTP R_C:C→BC with Σ_x p_x s_x≤√ε, where s_x=T(R_Cρ_x^C,ρ_x^BC).

Zero-prior labels can and should be ignored. Recovery channels can be taken on the full input matrix algebra; any support-only formulation extends by pinching and fixed preparation off the relevant support.

## 2. A bona fide same-domain broadcaster

Let U=Tr_C∘R_C:C→B and J=(id_B⊗U)∘R_B:B→B⊗B. This composition is a CPTP channel on all inputs, with two output copies of the original B space. Its marginal identities are

    J_1=Tr_C∘R_B,
    J_2=U∘Tr_B∘R_B.

The first marginal obeys T(J_1ρ_x^B,ρ_x^B)≤r_x. For the second, insert Uρ_x^C and use contraction twice:

    T(J_2ρ_x^B,ρ_x^B)
      ≤T(Tr_B R_Bρ_x^B,ρ_x^C)+T(Uρ_x^C,ρ_x^B)
      ≤r_x+s_x.

Thus m_x=max_a T(J_aρ_x^B,ρ_x^B)≤r_x+s_x and Σp_x m_x≤2√ε. With u=ε^(1/4), the set {x:m_x>u} has probability at most 2ε^(1/4). On its complement the very same broadcaster J has uniform error at most u. Correlations between its output copies do not affect the argument; no product-output condition is invoked.

## 3. Actual-prior information to good-family capacity

Write c=I(X:B) and σ=ω_B. For positive-prior labels, supp ρ_x^B⊆supp σ, and

    Σ_x p_x D(ρ_x^B||σ)=c.

For c>0 and 0<δ<1, Markov's inequality makes the set D(ρ_x^B||σ)>c/δ have probability at most δ. For c=0, nonnegativity forces ρ_x^B=σ for every positive-prior label, so no entropy trimming is needed. These facts do not require σ to be faithful on the original full space.

On the entropy-good set, every finite alternative prior q obeys the exact relative-entropy decomposition

    χ_q=Σ_x q_x D(ρ_x^B||σ)−D(Σ_x q_xρ_x^B||σ)≤c/δ.

It is irrelevant that σ may include discarded states and need not lie in the convex hull of the retained family: the identity holds for any reference with the required support, and its final term is nonnegative. Intersecting with the broadcast-good set preserves this capacity bound and uniform broadcast error. The discarded original-prior mass is at most δ+2ε^(1/4).

## 4. Common EB channel and averaged reconstruction

For a nonempty retained family E_G, its optimal broadcast error satisfies b₂(E_G)≤u<1. If b₂>0, monotonicity of 1/ln(1/b) together with the imported theorem gives a single full-domain EB map V:B→B with uniform retained-family error at most

    min{1, K(c/δ+1)/ln(1/u)}
      =min{1,81920(c/δ+1)/ln(1/ε)}.

The exact b₂=0 endpoint gives zero error instead. Finite-dimensional EB CPTP maps are compact in their Choi representation, so the infimum is attained; alternatively take a convergent subsequence. No label-dependent channel choice occurs.

Outside the retained family the halftrace error of any channel is at most one. Hence the original-prior average V-error is at most

    δ+2ε^(1/4)+81920(c/δ+1)/L,  L=ln(1/ε).

If the retained set is empty, its discarded mass is one, which forces δ+2ε^(1/4)≥1; an arbitrary EB map gives the same asserted inequality. Thus empty sets cause no theorem-domain problem.

Now set Λ=R_B∘V. Postprocessing preserves the EB property: if V(τ)=Σ_y Tr(M_yτ)ν_y, then Λ(τ)=Σ_y Tr(M_yτ)R_B(ν_y). The prepared BC states may themselves be entangled across B:C. This does not contradict EB, which concerns entanglement between the channel input reference and its entire BC output.

Contractivity and the first recovery estimate give

    Σ_x p_x T(Λρ_x^B,ρ_x^BC)
      ≤√ε+2ε^(1/4)+δ+81920(c/δ+1)/L.

Again cq block diagonality turns this into the claimed joint-state distance. Postprocessing error is not multiplied by a dimension or by a label count.

## 5. The explicit coefficient and endpoint bookkeeping

Set a=81920(c+1)/L. If a≥1, the claimed unclamped coefficient 864sqrt[(c+1)/L] is already greater than one, so any EB channel proves the clamped claim. Otherwise δ=√a lies strictly between zero and one and

    δ+81920(c/δ+1)/L ≤δ+a/δ+a≤3√a.

For L>0, sqrt(L)e^(−L/2)≤1 and 2sqrt(L)e^(−L/4)≤2. Therefore √ε+2ε^(1/4)≤3/√L. Since c+1≥1,

    total error ≤(3sqrt(81920)+3)sqrt[(c+1)/L]
                <864sqrt[(c+1)/L].

Here 3sqrt(81920)+3≈861.6501. Every normalized-state distance is also at most one, completing the min{1,·} statement without changing Λ.

The printed theorem restricts to 0<ε<1, so neither logarithmic endpoint is undefined. At ε=0 an exact conclusion is also available: both recovery errors vanish on positive-prior labels, J exactly broadcasts that family, the exact imported endpoint supplies an EB V that fixes it, and R_B∘V recovers ω_XBC exactly. At ε≥1 the trivial bound one remains valid but the displayed logarithmic formula should not be used. At c=0 an even simpler constant-preparation EB recovery already achieves error ≤√ε using R_B(σ).

## 6. Symmetric and stronger-capacity variants

Swapping B and C proves the analogous statement with I(X:C), with a separate reconstruction channel from C. There is no reason in this proof for the two measurement outcome spaces or effects to agree.

If the original conditional B-state family has a supplied sup-prior capacity bound c_*, entropy trimming is unnecessary. Restriction to the broadcast-good family cannot increase that capacity. The same proof gives

    error ≤min{1,√ε+2ε^(1/4)+81920(c_*+1)/L}.

This verifies the stronger-hypothesis variant as stated. The audit does not substantiate a common projective measurement, approximate Markov structural decomposition, efficient channel implementation, or literature-priority claim.
