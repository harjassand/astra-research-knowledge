# Independent audit of affinity assisted substate smoothing

9 October 2026 UTC. Independent analytic reconstruction of LINEAR_LOGARITHMIC_TRADEOFF.md. The new lemma, compatible trace-distance optimizer, and final constant pass. A separate end-to-end reviewer is also checking the result. No historical priority is asserted.

## Weighted polar identity

Let S=sqrtσ be invertible, A=sqrtρ, X=S⁻¹(SA²S)^(1/2)S⁻¹, and SA=WP a polar decomposition with W extended to a unitary. Then XS=AW* and SX=WA. Since XσX=ρ, kerX=kerA; equivalently their ranges coincide. Therefore XX⁺A=A and

SA=SX X⁺A=WAX⁺A,
P=AX⁺A.

For E=A−XS=A(I−W*), cyclicity gives

Tr(X⁺EE*)=Tr[AX⁺A(2I−W−W*)]=2TrP−2Tr(SA)=2Δ.

Tr(SA) is real and nonnegative. The rows of E on kerX vanish, because both A and XS have range in ranX. This is the detail that licenses the subsequent pseudoinverse bound when ρ is singular.

## Exact spectral cutoff comparison

Let Q=1_(X≤R), including the zero eigenspace, and P_R=I−Q. With p=Tr(ρP_R), q=Tr(σP_R), commutation with X implies p=Tr(σX²P_R)≥R²q. Binary relative-entropy data processing bounds p≤(D(ρ||σ)+ln2)/(2lnR). The second binary term is at least −ln2, while the first is at least 2p lnR. Empty cutoffs or p=0 are harmless.

The truncated state τ=SX²QS is positive, has trace 1−p, and obeys τ≤R²σ. Let B=QA and D=QXS. Both have HS norm sqrt(1−p), and

||B−D||₂²=||QE||₂²≤RTr(X⁺EE*)=2RΔ.

On nonzero eigenvalues selected by Q, 1≤R/x; on the zero eigenspace E has zero rows. Thus the inequality holds without an inverse-norm constant. Since B*B=AQA, D*D=τ, and ρ−AQA≥0 has trace p,

||ρ−τ||₁≤p+2sqrt(2RΔ).

This proves precisely the proposed near-commuting substate estimate. No invalid operator monotonicity of squaring or replacement of noncommuting matrices by scalar variables occurs.

## Compatible optimization

The trace-distance term ||ρ−τ||₁ is convex; adding λQσ gives strict quadratic curvature and the same strong-convexity gap as the earlier fidelity optimizer. Trace-norm contractivity and sandwiched-Rényi-2 data processing make TG feasible with no objective increase at reference Tσ.

Transport τ=sqrtσ A₀sqrtσ to sqrt(Tσ)A₀sqrt(Tσ), then clip its trace if needed. The trace-norm transport bound is 2M sqrt(dσ)+M dσ. The Q increase is at most 2M²sqrt(dσ); downward clipping decreases Q. The distance objective changes by at most dρ plus the transport norm. Hence the proposed ξ and strong-convexity estimate (T) are valid in both directions, including differing reference supports.

With λ=δ/M and a feasible τ₀ within δ, the optimizer G has ||ρ−G||₁≤2δ and trace t≥1−2δ>1/2. Normalization adds at most another 2δ in full trace norm, giving T(ρhat,ρ)≤2δ. For ρ=σ, J≥1−t+λt² is decreasing on [0,1], and equality at σ proves G(σ,σ)=σ. Thus the reference remains included exactly. The nonlinear smoother is only an analytic comparison device, not an operation performed on the unknown input.

## Constants and final quantifiers

For dρ,dσ≤2b and δ<1/4, ξ≤9M sqrtb and the fulltrace optimizer residual is bounded by 13Mδ^(−1/2)b^(1/4). Because 2t>1, the same expression bounds the normalized halftrace residual. It dominates b as required when adjoining σ.

Put L=ln(1/b), A₀=4096, δ=A₀(C+1)/L, R=exp[(C+ln2)/δ], M=R². The nontrivial branch L>4A₀(C+1) has δ<1/4. The affinity term sqrt56 exp[−L/8+L/(2A₀)] is at most δ/2 there. Thus the candidate substate is within δ, as required.

The previously double-checked sandwich modulus is h(u)≤20u^(1/192), including all large-error branches. Substitution gives the claimed remainder bounded by 163L^(1/384)exp(−L/2048). The exponent comparison holds:

1/768−2(193/192)/4096=0.0008112589518... >1/2048.

The logarithm of the ratio of this remainder to 4096/L is decreasing on L≥16384 and equals −1.494684447... at 16384. Therefore the remainder is at most δ. The final e≤5δ gives the constant 20480 exactly. The complementary branch is trivial after clamping at one.

Capacity is still a supremum over all priors, error is still a supremum over all labels for one EB channel, and the physical support/encoder/decoder composition is unchanged. A vanishing slack handles the broadcaster infimum. The bound therefore improves the capacity dependence of the logarithmic modulus without a hidden finite-family or dimension constraint.
