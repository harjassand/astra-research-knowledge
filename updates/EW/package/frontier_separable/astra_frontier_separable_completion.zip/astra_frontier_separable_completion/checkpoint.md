# ASTRA checkpoint — 13 October 2026

## Retained scientific target

Macroscopic tracial particle transport for translation-invariant nearest-neighbour coherent hopping, bounded nonperturbative finite-range diagonal interactions, and the original positive pure dephasing. No artificial physical damping, supplied relaxation gap, compact exact response, or free equilibrium preparation.

## New operation

Represent relative-gap coefficients by separated geometric fields or matrix-product/TT cores. For b=B_1...B_m, M_i=sum B_i, rho_i normalized, H_i=prefix(B_i-rho_i M_i), the flux F_i=B_<i H_i (rho M)_>i satisfies div_grid F=b-mass(b)*product rho. At zero mass it repairs the source exactly.

Route each coordinate edge by g->g+e1->...->g+ei. The suffix sums of the F_i are encoded by upper-triangular block cores [[B_i,H_i],[0,rho_i M_i]]. Each physical-edge-family payload has TT ranks at most twice the input ranks; no radius enumeration or multidimensional Poisson matrix is needed. The construction is a feasible right inverse, not the orthogonal/minimum-energy projection.

A dyadic multiscale source-class repair connects normalized product-geometric scale 2^J to delta_0 in O(m^2 J) terms. For gap dimension m>=3 the unweighted energy is <24m^2 independently of J; at m=4 it is <=128. This does not assert an energy bound for every source or rank bounds for the full inverse.

## Infinite certification and solver interface

Geometric TT overlaps are finite rational transfer-matrix products. Local quantum commutators use finite contact branches near endpoints, not enumeration of long gaps. Complete infinite residuals are included. Geometric nonlocal witnesses transfer to D by exactly balanced compact approximation; true response tails need not be exponential.

For a Hodge source b=div F, potential phi and feasible w give lower 2<b,phi>-||grad phi||^2 and upper ||w||^2; gap=||w-grad phi||^2. Then F-w is balanced and within sqrt(gap) of the exact projection. This supplies a measured-error projection operation, not an inverse-gap oracle.

With W_N skew, ||W_N||<=M_N, projected Richardson step h=1/(1+M_N^2) and per-projection error eta has error <=(sqrt(1-h))^j||z||+2eta. Every rounding/commutator error must be charged. The number of outer steps is polynomial; inner rank/pole complexity remains open.

## Executed evidence

- Actual grade-three current-projection dipole b=delta_(0,1)-delta_(1,0):
  0.42510190863487 <= E_b <= 0.42510190864763.
  Exact width 1.2751786347077035e-11; 136 potential and 306 cycle variables; 1489 residual atoms; all infinite tails included.
- Main discovery and exact full-residual check: 5.121s excluding imports, peak116332KiB. This is E_b, NOT D.
- Compact sparse radius128 certificate: tighter width1.33709e-12 in0.2267s. No speed superiority; compressed representation is much smaller. Higher-dimensional solver performance untested.
- m4,J40 multiscale completion:478 routed terms, exact divergence, analytic energy upper128; no grid.
- TT identities, factor-two block automaton, finite/infinite Majorana checks, actual harmonic/source identities, independent residual verification, and all standalone reruns passed.
- Broad full-model nonlocal pipeline: D roughly in[.4554488799,.6414075846] at t1,U4,V1,d2; not an accuracy improvement.
- Saved old practical packet has about99.21% of its dissipative witness energy through degree4; about92.23% of its remaining certificate width comes from degrees3–6. These are properties of that packet, not a universal exact-solution rank law.

## Exact remaining theorem

Construct and certify near-minimum-energy Hodge corrections and the actual interaction-generated response fields with ranks, pole/state counts, rational bits and total solve/compression/discovery cost <=C_physical^N error^-c. Exact feasibility can now be maintained at factor-two rank overhead; this does not prove that near-optimal corrections have low rank.

Do not equate low Majorana degree, finite source rank, exact conservation, or cheap matvecs with a low-rank inverse. The exact Cauchy-matrix example rejects exact rank preservation only, not approximate-rank feasibility for the physical class. No polynomial-impossibility theorem is claimed.

## Provenance and scope

Prior graded note/checkpoint read. Astra pinned d47777a817e273668b6af3f0548cd02af92c6bc5, exact N754 locality-obstruction source read and key identities reconstructed. No theorem imported from unrelated compact-manifold openai/math sources. No external writes, Lean build, independent review, laboratory experiment or novelty clearance.
