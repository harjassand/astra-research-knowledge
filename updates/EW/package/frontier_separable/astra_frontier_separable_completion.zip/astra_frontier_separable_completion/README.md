# ASTRA — Separable and tensor-train conservation completion

This package contains the current research note, exact rational infinite-domain certificates, prototype source/quantum algebra, and a matched compact sparse baseline. It is not a production high-degree transport solver, independent proof validation, or a uniform polynomial inverse-accuracy theorem.

## Main outputs

- `research_note.md`: all derivations, assumptions, resource boundaries and sources.
- `pressure_L10K6_certificate.json`: exact interval for an infinite-graph Hodge projection **energy**, not the transport coefficient D.
- `pressure_L10K6_witness.json`: dyadic potential and cycle coefficients, independently usable by the verifier.
- `tt_completion.py`: matrix-valued telescoping, a rank-factor-two routed completion, exact infinite contractions.
- `multiscale_repair.py`: energy-controlled source-class construction at dyadic scales.
- `separable_repair.py`: exact scalar separated prefix/routing operations.
- `gap_algebra.py`: original quantum-generator commutators on geometric Majorana gap fields.
- `nonlocal_transport_trial.py`: broad full-model interface check, not a precision improvement.
- `compact_pressure_baseline.py`: faster compact sparse baseline for the two-gap example; full exterior residual is included.
- `structural_tests.py`: exact harmonic/current-source identities, independent expansion checks, rank counterexample, finite iteration diagnostics.
- `prior_packet_profile.json`: profile of the saved earlier successful packet, not an exact-solution tail law.

## Requirements

Python 3.11 or newer, NumPy, SciPy and SymPy. The recorded environment is in `environment.json`. No internet, GPU, quantum hardware, equilibrium specimens, or private repository access is needed for the standalone current checks. Do not use `python -O`: the test/certificate scripts deliberately reject it.

## Reproduce

From this directory:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python run_checks.py
```

This runs each current standalone test in `recheck/`, preserves stdout/stderr, and writes `reproduction_status.json`. It does not overwrite the original benchmark certificates or rerun the earlier packet discovery.

To recompute the main infinite pressure solve, including discovery and exact verification:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python pressure_certificate.py --L 10 --K 6
```

To verify the stored dyadic coefficients without numerical optimization:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python pressure_certificate.py --verify pressure_L10K6_witness.json
```

The full geometric tails are contracted. No large spatial domain is generated. All coefficients of the complete residual, including tails outside the trial dictionary, contribute to the final norm.

The optional historical profile needs the previously supplied `astra_frontier_thermodynamic_certificate.zip` extracted separately:

```sh
OPENBLAS_NUM_THREADS=1 python prior_packet_profile.py --prior-package /path/to/astra_frontier_thermodynamic_certificate
```

It requires that prior package's own NumPy/SciPy/Numba compiler dependencies. The old package is not duplicated in this archive. Its precomputed current profile is included. `reference_majorana.py` is a preserved module from the earlier graded package; its use is documented as prior same-programme code, not independent external evidence.

## Interpretation

The primary executed value is

```
0.42510190863487 <= E_b <= 0.42510190864763
```

for a unit dipole on the infinite three-particle exclusion gap graph. The exact width is about 1.27518e-11. This is the norm-squared of a pressure-gradient projection appearing in the actual quantum current calculation, not the final coefficient D.

The main run took 5.121 seconds inside the solver (imports excluded) and peaked at about 113.6 MiB. The radius-128 sparse compact baseline was faster and tighter. Hardware performance is not guaranteed; see both records rather than interpreting representation counts as a speedup claim.

The four-dimensional multiscale fixture represents length 2^40 in 478 separated routed terms. Its divergence is checked exactly; its energy upper bound 128 comes from the proof. This does not certify a norm-optimal correction or every interacting response at that scale.

## Status

Current theorem derivations and implemented tests are unreviewed research outputs. No formal proof, experimental model validation, strongest-specialist benchmark across physical systems, or historical novelty clearance is claimed. `CLAIM_LEDGER.json` and `checkpoint.md` separate completed operations from the remaining rank theorem.
