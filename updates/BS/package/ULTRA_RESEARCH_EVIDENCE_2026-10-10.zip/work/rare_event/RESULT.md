# Rare-event certificate acquisition: a sharp information obstruction and a charged positive regime

Date: 2026-10-10. Status: internally reconstructed proofs, an independent model audit, exact finite checks, and a synthetic implementation. **The historic-scale objective is not achieved.** No external correctness or historical-priority claim is made. The positive estimator is a composition of established product-form estimation and weighted-DNF coverage sampling. The strongest negative result below is a precise moment-matching obstruction derived with standard orthogonal-kernel machinery; novelty is unresolved.

## 1. Source pin and research decision

Astra revision: `8aed7fd74eb14622ed5a0a3635a799374296e32a`.

Read route: `AGENTS.md` → `00_START_HERE.txt` → `agent/topics.txt` → `agent/topics/probability.tsv`, entries N486–N493 → their `frontier/review_cards/` wrappers. Read `agent/RESEARCH_WORKFLOW.txt`. All eight reviewed records remain source-derived and unreviewed; a wrapper is not proof certification.

The decisive original note was read using `git show` at:

`web/assets/3724e9edad63df08248b0f7f01b7eed95ac188ed12a30a1a281eb38012f46b69.md`

Its logical `updates/BN/package/RESEARCH_NOTE.md` and evidence-object paths do not exist in this sparse checkout/revision tree; the content-addressed web asset does. No checkout mutation was made. Exact proof spans in this 450-line asset: operational contract lines 71–102; local induction lines 103–134; stopping-time obstruction and supersolution extension lines 247–334; acquisition failure and cost boundary lines 367–407. The previous continuation interval compiler had already approximately solved the probability problem by enumerating the state-time table.

The source's local inequality is sound by backward induction, but general second-moment supersolutions are already explicit in Blanchet–Glynn (2008), and finite-horizon slack is explicit in Blanchet–Glynn–Leder (2012). This investigation therefore concentrates on information acquisition. `COMPARATORS.md` records a targeted primary-source audit including Doob transforms, subsolutions, adaptive splitting, contemporary certified deep importance sampling, product-form estimation, and weighted DNF algorithms.

## 2. Strongest obstruction: many exact marginals still leave rare-event-scale uncertainty

Let `0<a<=1/2`, `d>=1`, and `0<=k<d` be integers where appropriate. Set

\[
P_0=\operatorname{Bern}(a)^{\otimes d},\quad
A=\{\mathbf1\},\quad p=P_0(A)=a^d.
\]

Define the orthonormal basis in `L²(P0)`

\[
\phi_S(x)=\prod_{i\in S}\frac{x_i-a}{\sqrt{a(1-a)}},
\]

and

\[
L_k(x)=\sum_{|S|\le k}\phi_S(x)\phi_S(\mathbf1),\qquad
H_k(x)=\sum_{|S|>k}\phi_S(x)\phi_S(\mathbf1).
\]

Write

\[
D_k=L_k(\mathbf1)=\sum_{j=0}^k {d\choose j}\left(\frac{1-a}{a}\right)^j,
\qquad K=p^{-1}-D_k.
\]

**Theorem 1.** If `D_k<=K`, the law

\[
P_\star(x)=P_0(x)\left(1+\frac{H_k(x)}K\right)
\tag{1}
\]

is nonnegative, has exactly the same joint marginals on every set of at most `k` coordinates as `P0`, and satisfies

\[
P_\star(A)=2p,\qquad
\chi^2(P_\star\Vert P_0)=K^{-1}\le2p.
\tag{2}
\]

Moreover `K^{-1}` is the minimum chi-square divergence among **all** laws agreeing with `P0` on those marginals and assigning mass `2p` to `A`. This is optimality for that divergence and those constraints; it is not a finite-sample minimax-testing claim.

**Proof.** The full orthonormal reproducing kernel at the atom `1` is

\[
L_k(x)+H_k(x)=\frac{\mathbf1_{x=\mathbf1}}p.
\]

At `x!=1`, `H_k(x)=-L_k(x)`. For each coordinate, the factor `phi_i(x)phi_i(1)` equals `(1-a)/a` at one and `-1` at zero. Since `a<=1/2`, each absolute degree-`j` product is at most `((1-a)/a)^j`. Hence `|L_k(x)|<=D_k<=K`, proving nonnegativity off the target. At the target `H_k(1)=K`, so the likelihood ratio is two.

Every term of `H_k` has positive degree, so `E0 H_k=0`; normalization follows. Every function of at most `k` coordinates belongs to the span of the degree-at-most-`k` basis. Orthogonality therefore proves equality of its expectation under the two laws, including all cylinder indicators. Finally `E0 H_k²=K`, proving the divergence identity.

For any competing law `Q`, let `h=Q/P0-1`. The marginal constraints make its coefficients vanish through degree `k`; the target constraint says `h(1)=1`. Cauchy–Schwarz gives

\[
1=\left(\sum_{|S|>k}\widehat h_S\phi_S(\mathbf1)\right)^2
\le K\sum_{|S|>k}\widehat h_S^2
=K\chi^2(Q\Vert P_0).
\]

Equality is attained by (1). ∎

The condition has a useful exact interpretation:

\[
pD_k=\Pr\{\operatorname{Bin}(d,1-a)\le k\}\le\tfrac12.
\tag{3}
\]

For `a=1/2`, it includes every `k<=floor((d-1)/2)`. Thus agreement through roughly half of all coordinates can coexist with twice the rare-event probability and chi-square distance at most twice that probability. Equation (3), rather than an informal asymptotic cutoff, is the asserted regime.

**Compact acquisition of the counterexample.** No exponential table is needed to specify its likelihood ratio. Given `x`, retain coefficients through degree `k` of

\[
\prod_{j=1}^d(1+t_jz),\qquad
t_j=\begin{cases}(1-a)/a&x_j=1,\\-1&x_j=0.\end{cases}
\]

Their sum is `L_k(x)`. The recurrence including the input scan costs `O(d(k+1))` rational arithmetic and `O(k+1)` live coefficients. For rational `a` of input bit length `b`, actual coefficient bit lengths are `O(db+d)`; arithmetic is not unit-cost. Since the likelihood ratio in (1) lies in `[0,2]`, rejection from `P0` with acceptance probability `(1+H_k/K)/2` samples `Pstar` exactly with expected two trials. Exact rational Bernoulli generation uses rejection on finite uniform bit strings. Thus this is a compact evaluable and sampleable alternative, not an exponentially long adversarial table. The supplied sampler identity is still unknown to the statistical estimator in the two-law experiment.

## 3. What the obstruction means for data and assays

Suppose an estimator is given `n` independent complete vectors from an unknown law in `{P0,Pstar}`. Give it both candidate models, `a,d,k`, the target, and every low-order marginal for free; the only unknown is which law generates observations. If it estimates the target probability within relative error `epsilon<1/3`, with success probability at least `1-delta` under **each** law, then its two possible target intervals are disjoint. Thresholding the estimate gives a test with both error probabilities at most `delta`.

Put

\[
c_\delta=(1-2\delta)\log\frac{1-\delta}{\delta},\quad 0<\delta<1/2.
\]

Binary KL data processing gives `n D(Pstar||P0)>=c_delta`. Jensen's inequality under `Pstar` gives

\[
D(P_\star\Vert P_0)\le\log E_\star(P_\star/P_0)
=\log(1+1/K).
\]

Therefore

\[
\boxed{n\ge\frac{c_\delta}{\log(1+1/K)}\ge c_\delta K\ge\frac{c_\delta}{2p}.}
\tag{4}
\]

This lower bound allows arbitrary computation. Faster conditional probability evaluation cannot repair the missing information. It also applies to any automatically acquired variance certificate plus estimator that would imply the forbidden relative guarantee with a smaller **total** number of original observations.

For precision dependence, replace `H_k/K` in (1) by `eta H_k/K`, `0<eta<=1`. Then the event mass is `(1+eta)p` and chi-square is `eta²/K`. Taking `eta=4epsilon`, `0<epsilon<=1/4`, keeps the target intervals disjoint and yields

\[
n\ge \frac{c_\delta K}{16\epsilon^2}
\ge\frac{c_\delta}{32\epsilon^2p}.
\tag{5}
\]

**Partial assays are even weaker.** If at most `k` coordinates are revealed from each fresh specimen, adaptively selecting subsequent coordinates based on earlier values, the entire transcript has **exactly the same distribution** under the two laws, for any number of specimens. Every within-specimen decision-tree leaf fixes at most `k` bits, so its cylinder probability agrees. Conditional on the past, the next fresh specimen satisfies the same argument. Randomized choices can be conditioned on the algorithm's random seed. This statement does not cover repeated assays of the same specimen whose union reveals more than `k` coordinates.

## 4. Simpler face construction and the access that defeats it

A simpler pair makes the acquisition cost of conditional sampling transparent. Let `r=k+1`, `H={x1=...=x_(d-r)=1}`, and

\[
\Delta(x)=p\,\mathbf1_H(x)(-1)^{\#\{j>d-r:x_j=0\}},\qquad P_1=P_0+\Delta.
\tag{6}
\]

Negative affected cells have at least one zero and baseline mass at least `p`, so the law is nonnegative. The perturbation sums to zero. Any at-most-`k` marginal misses a suffix coordinate and cancellation in that coordinate proves equality. The target mass doubles. Direct summation gives

\[
\chi^2(P_1\Vert P_0)=\frac{p}{(1-a)^r}.
\tag{7}
\]

The same testing argument yields `n>=c_delta(1-a)^r/p`. For fixed `k`, this is the original rare-event scale. This pair is weaker than Theorem 1 when `k` grows, but has the following explicit escape interface.

The cylinder `H` has the same probability `a^(d-r)` under both models. An oracle providing independent samples conditional on `H` reduces the problem to `r` bits: the last all-one event has probabilities `a^r` versus `2a^r`, and crude conditional event counting needs `O(a^(-r) epsilon^(-2) log(1/delta))` oracle samples. For fixed `k,a`, that is constant in `d`. Obtaining one such sample by passive rejection costs `a^(-(d-r))` complete specimens on average, restoring an **expected** `O(p^(-1) epsilon^(-2) log(1/delta))` original observations. Conditional access genuinely helps only if it is physically or computationally available more cheaply.

An intervention that sets the prefix bits is **not automatically** sampling from the observational conditional law. The two observational distributions do not specify intervention semantics. A valid escape requires a justified causal/preparation model showing that the operation implements the required conditional distribution, together with its full preparation and measurement costs.

## 5. Repaired regime: supplied independence, acquired ordinary marginals

This section gives an executable positive acquisition result but is **established-estimator composition**, not a claimed new principle. Assume a trusted product-family model

\[
P=\bigotimes_{j=1}^d\operatorname{Bern}(p_j),\qquad p_j\in[a,1-a],
\]

with unknown `p_j`, known `a>0`, a fixed event specified independently of the data, and full coordinate observations. From `n` independent vectors form the **unsmoothed** marginal empirical laws `P_hat_j` and their product `P_hat`. Data across coordinate sample arrays are independent under the supplied model.

For every fixed `f>=0`, `Pf>0`,

\[
E(\widehat P f)=Pf,\qquad
\frac{E[(\widehat P f)^2]}{(Pf)^2}\le C_n
:=\prod_{j=1}^d\left(1+\frac{1/\min(p_j,1-p_j)-1}{n}\right)
\le\left(1+\frac{1-a}{na}\right)^d.
\tag{8}
\]

**Proof and sharpness.** For one marginal with mass function `q`,

\[
\frac{E[\widehat q(x)\widehat q(y)]}{q(x)q(y)}
=1+\frac{\mathbf1_{x=y}/q(x)-1}{n}.
\]

This is nonnegative and is bounded by `1+(1/min q-1)/n`. Independence tensorizes the pair kernel. Summing against the nonnegative coefficients `f(x)f(y)P(x)P(y)` proves (8). The least-probable full assignment attains equality, so this uniform multiplicative factor cannot be improved. Unbiasedness follows by multiplying the marginal expectations.

The exact ANOVA variance is stronger for individual functions. Write `f=Σ_S f_S`, with canonical orthogonal components centered in each coordinate they contain. Then

\[
\operatorname{Var}(\widehat P f)
=\sum_{\emptyset\ne S\subseteq[d]} n^{-|S|}\|f_S\|_{L^2(P)}^2.
\tag{9}
\]

To prove it, cross terms with different index sets vanish after integrating a coordinate in their symmetric difference. For a fixed `S`, expand both empirical averages into sample-index tuples. If the two sample indices differ in any coordinate of `S`, integrating the singly occurring sample gives zero. Only the `n^|S|` fully matched tuples remain among `n^(2|S|)` pairs, giving exactly `n^-|S| ||f_S||²`.

Equations (8)–(9) describe the [product-form estimator of Kuntz–Crucinio–Johansen](https://link.springer.com/article/10.1007/s11222-021-10069-9), whose unbiasedness and finite-sample variance are established. Our sharp Bernoulli factor is a direct specialization. Generic evaluation can still require exponential computation.

## 6. Explicit rare failure modes close the computational side

Suppose the event is supplied as `M>=1` explicit consistent nonempty DNF clauses `A_i`, each fixing a subset of component values, with total literal count `J`. This models a listed family of component failure modes. Acquiring a complete mode list from a general fault tree or black-box simulator is a separate unsolved/costly task; it is not free preprocessing in this result.

For the empirical product model compute each clause mass `alpha_i=P_hat(A_i)` and `S=Σ_i alpha_i`. If `S=0`, output zero. Otherwise select `i` with probability `alpha_i/S`, force the clause's literals, and sample all other coordinates independently from their empirical marginals. Let `c(x)` count satisfied clauses and return `Y=S/c(x)`. The proposal mass is `P_hat(x)c(x)/S`, so `E[Y|data]=P_hat(A)` exactly, including empirical zero probabilities.

Since `Y` lies in `[S/M,S]`, the elementary bounded-variable inequality `(Y-S/M)(S-Y)>=0` gives

\[
\frac{E[Y^2\mid data]}{\widehat P(A)^2}\le B_M:=\frac{(M+1)^2}{4M}.
\]

For the mean `Z` of `L` conditionally independent coverage draws,

\[
\boxed{EZ=P(A),\qquad
\frac{EZ^2}{P(A)^2}\le C_n\left(1+\frac{B_M-1}{L}\right).}
\tag{10}
\]

This is the law of total second moment, not a new sampling principle. Weighted DNF and reciprocal-coverage methods are present in [Karp–Luby–Madras (1989)](https://www.math.cmu.edu/users/af1p/Teaching/MCC17/Papers/KLM.pdf). Their self-adjusting algorithm is a stronger total-work baseline than our simple full-coverage counter.

For `0<epsilon<=1`, sufficient per-group choices are

\[
n=\left\lceil\frac{16d(1-a)}{a\epsilon^2}\right\rceil,\qquad
L=\max\left(1,\left\lceil\frac{16(B_M-1)}{\epsilon^2}\right\rceil\right).
\]

Using `e^t<=1/(1-t)` for `0<=t<1`, (10) gives relative variance at most `2epsilon²/(16-epsilon²)<epsilon²/4`. Hence one group fails relative error `epsilon` with probability below `1/4`. An odd number `G>=8 log(1/alpha)` of fully independent groups and their median gives failure probability at most `alpha`. Independence here includes fresh calibration data for each group; duplicating one dataset does not create independent groups.

**Charged costs.** Per group: `n` full-vector specimens, `nd` scalar observations/additions, `O(d+J)` stored input/counts, `O(J)` arithmetic to compute clause masses, and for the implemented sampler `O(L(d+J+M))` elementary coordinate/membership/selection work. Exact empirical probabilities have denominator `n`; an integer common denominator `n^w` for maximum clause width `w` gives weights with `O(w log n+log M)` bits. `reproduce.py` uses exact rational scores and exact integer selection. Rational operations, random integer generation, and model calibration are charged. The final sample median can be exact rational. Physical model validity and mode enumeration are **supplied assumptions**, not acquired by this code.

Even with known factorization, the data dependence is unavoidable up to constants. For `a<=1/4`, compare product laws with parameters `a` and `a'=a(1+4epsilon/d)`, `epsilon<=1/4`, and the all-one event. Their probability ratio is at least `1+4epsilon`; their full-vector KL is at most `16a epsilon²/[d(1-a)]`, using Bernoulli KL bounded by chi-square. The same two-point argument requires `Omega(d(1-a)/(a epsilon²))` full-vector observations. This matches the positive calibration order; it does not validate the structural product assumption.

## 7. Exact checks and executed synthetic diagnostic

Run `python3 work/rare_event/reproduce.py --groups 60` from the task root. Python 3.14.3 and NumPy 2.5.3 were used. The executable saves `results.json`.

Finite exact checks include: normalization, nonnegativity, every required marginal, target mass, and chi-square identities for both constructions; 255 nonempty events on a three-bit space for the sharp product-form bound; explicit enumeration of empirical counts matching the ANOVA identity; a small exact sampler first/second moment; and the zero empirical mass branch. The face construction passed 652 exact marginal equalities; kernel checks comprise 20 admissible parameter settings and 385 exact marginal equalities. An independent model audit separately checked its own formulas without reading the builder implementation; neither is external validation.

`CompactKernelLaw` implements the polynomial coefficient evaluator and exact rejection sampler without a state table. Its 80-bit, `a=1/4`, `k=40` diagnostic produced 20 samples in 37 proposals; this is a functionality receipt, not a distributional validation. The target likelihood ratio was exactly two, the chi-square divergence was `1/1461499720198846809459565774817995405346945025126`, and the stored `K` numerator had 160 bits. The expected proposal count of two comes from the proof, not this finite run.

Synthetic diagnostic: 48 independent components with probability `1/4`, eight fixed modes of width 39, `n=4096` full vectors per independent calibration group, 64 inner draws, 60 groups. The exact reference was computed with 255 inclusion-exclusion terms; this cost is recorded and is not given to the estimator.

| Quantity | Executed value |
|---|---:|
| Exact target probability | `1812763 / 79228162514264337593543950336` |
| Target probability, rounded | `2.2880285778098512e-23` |
| Logical complete specimens | 245,760 |
| Logical component observations | 11,796,480 |
| Expected passive event hits at that budget | `5.6230590328254904e-18` |
| Coverage proposal draws | 3,840 |
| Coverage literal tests | 1,157,840 |
| Largest integer weight representation | 469 bits |
| Certified per-group relative variance upper bound | `0.060549771917227255` |
| Observed per-group normalized variance | `0.0324654338764043` |
| Observed normalized mean | `1.049177706097591` |
| Exact plugin comparator observed normalized variance | `0.029012428882388582` |

The diagnostic generated sufficient counts directly as independent binomials; it did not literally acquire eleven million measurements. The table charges those **logical** observations rather than claiming a physical experiment. The pseudorandom seed is a reproducibility aid; mathematical probability claims assume ideal independent randomness. The reference has an intentionally easy common-core structure, so this is not a frontier benchmark or proof of practical superiority. The plugin comparator already has lower variance and evaluates cheaply at this small mode count. The latest complete diagnostic, including repeated exact plugin comparisons, took about 0.51 seconds; no optimized-runtime superiority is inferred.

## 8. Predecessors, failures, and next decisive gate

The simple face perturbation is an elementary variation of parity plus biased thinning in [Benjamini–Gurel-Gurevich–Peled, Proposition 26](https://arxiv.org/pdf/1201.3261). Vanishing low-order Fourier coefficients characterize the same marginal constraints in [Rubinfeld–Xie](https://people.csail.mit.edu/ningxie/papers/RX09.pdf). [Berend–Ernst–Kontorovich–Kumar (2024)](https://arxiv.org/html/2407.18688v1) studies extremal all-one probabilities for k-wise independent bits. The chi-square-optimal kernel specialization is closely related to standard moment and reproducing-kernel arguments; its historical novelty was not established. The two-point statistical reduction is classical.

Failed innovation hypotheses preserved: (i) generic local Lyapunov certificates are prior art; (ii) approximate Doob residual accumulation is prior art; (iii) empirical product estimation is prior art; (iv) DNF witness sampling is prior art; (v) the explicit rare diagnostic is already tractable to stronger exact small-instance baselines. We have no defensible transformative performance claim.

The single most consequential remaining obstacle is **acquiring or experimentally justifying the tail-relevant dependence structure without spending rare-event-scale observations or assuming an inexpensive conditional-preparation oracle**. The theorem makes this obstacle concrete: even exact, very high-order marginal agreement does not certify the probability of a catastrophic conjunction. Primitive Genesis can study alternative representations only after stating how they reveal the hidden high-order component; Natural Sciences must identify an intervention whose distributional semantics and preparation costs are justified; Theoretical Pro can seek stronger boundary theorems for restricted, physically defensible dependence classes. Mere transfer of a supplied independence representation does not remove the obstruction.

## 9. Compact handoff

- Scope: passive rare-event acquisition under known product models versus indistinguishable dependent alternatives.
- Inherited inputs: pinned N486–N493 and original proof note; trusted product structure, fixed explicit DNF, known lower marginal bound in positive regime.
- Acquired inputs: ordinary marginal counts; no rare observations required under the trusted positive model.
- Reconstructed claims: sharp kernel obstruction; partial-assay transcript impossibility; exact product-form variance; charged DNF composition.
- Artifacts: `RESULT.md`, `reproduce.py`, `results.json`, `COMPARATORS.md`, `OBSTRUCTION_AUDIT.md`.
- Comparator: Kuntz–Crucinio–Johansen product-form estimator; Karp–Luby–Madras weighted DNF; exact small-mode inclusion-exclusion.
- Falsifier: any asserted model-validation procedure must distinguish the explicit pair at its claimed observation cost. If it conditions/intervenes, specify and charge how that interface is obtained.
- Status: internal reconstruction and finite checks only; historical novelty and external correctness unresolved; historic objective not achieved.
