# Independent adversarial audit: finite resolvent queries

Status: internal mathematical derivation, not external certification or a novelty claim. Convention throughout is G_ρ(z)=∫(z−x)^{-1}dρ(x), so G maps the upper half-plane into the lower half-plane. SC_s denotes the centered semicircle law of variance s; SC_0=δ_0.

## Verdict

(A) The quadrature construction is correct. Its finite adaptive exact-query impossibility consequence is correct for deterministic algorithms. It must not be extended to randomized exact-query algorithms: a constructive randomized exact-arithmetic recovery procedure is given below.

(B) The Chebyshev identity, the uniform q bound, the stated smoothing bound for b<η², and the stated Le Cam/Pinsker constant are correct. State the observation model and quantifiers explicitly. The lower bound concerns a single estimator valid under both hypotheses, with strictly smaller than a/2 error, a fixed minimum query height η>0, and independent Gaussian noise of variance σ² in each real coordinate.

## A. Full check of quadrature construction

Let μ be a finitely supported probability measure, t₀>0, ν=μ⊞SC_{t₀}, z_i∈C₊, and g_i=G_ν(z_i), i=1,…,m. Fix 0≤t<t₀. Write s=t₀−t and λ=μ⊞SC_s. Associativity gives ν=λ⊞SC_t and hence

    g_i=G_λ(w_i),       w_i=z_i−t g_i ∈ C₊.

Set Q(x)=∏_{i=1}^m(w_i−x)(conj(w_i)−x). On the real line, Q>0 and has degree 2m. The measure ρ(dx)=λ(dx)/Q(x) is positive and compactly supported. It has infinite support: for any positive semicircular smoothing s, if u=−Im G_λ(z) and y=Im z, the fixed point and the elementary Cauchy-transform bound give

    u ≤ |G_λ(z)| ≤ 1/(y+s u),

so u≤1/√s uniformly; in particular λ has no atoms. Thus the ordinary (m+1)-node Gaussian quadrature rule for ρ has distinct real nodes ξ_j and strictly positive weights α_j and integrates polynomials of degree at most 2m+1 exactly.

Define β_j=α_j Q(ξ_j)>0 and μ_t^Q=∑_{j=1}^{m+1}β_j δ_{ξ_j}. Gaussian exactness on Q gives ∑β_j=∫Q dρ=1. Each Q(x)/(w_i−x) is a complex polynomial of degree 2m−1; applying real quadrature exactness to its real and imaginary parts gives

    G_{μ_t^Q}(w_i)
      = Σ_j α_j Q(ξ_j)/(w_i−ξ_j)
      = ∫Q(x)/(w_i−x) dρ(x)
      = G_λ(w_i)=g_i.

Thus g_i is a lower-half-plane solution of g=G_{μ_t^Q}(z_i−t g). This solution is unique. Indeed, for two such solutions g,h, writing w=z−tg and v=z−th, subtraction yields

    g−h=t(g−h) ∫[(w−x)(v−x)]^{-1}dμ_t^Q(x).

If g≠h, the right-hand integral would have absolute value at least 1/t. But Cauchy–Schwarz and −Im G(w)=(Im w)∫|w−x|^{-2}dμ imply

    t |∫[(w−x)(v−x)]^{-1}dμ|
    ≤ sqrt( t(−Im g)/(Im z+t(−Im g))
             · t(−Im h)/(Im z+t(−Im h)) ) < 1.

This is a contradiction; t=0 is immediate. Therefore ν_t=μ_t^Q⊞SC_t matches all queried transforms.

Additional exact scope: Gaussian nodes lie in the convex hull of supp λ. Since xQ has degree 2m+1, the construction also preserves the mean of λ. It need not preserve its variance; x²Q exceeds the quadrature exactness degree. Distinct z_i imply distinct w_i, although distinctness of w_i is not needed for polynomial divisibility.

### Deterministic adaptive consequence

Run a deterministic algorithm on ν₀=SC_{t₀} until it terminates after m exact transform queries. Build μ_t^Q from that complete finite transcript. The alternative ν_t has exactly the same answer at every queried point. By induction the algorithm makes the same adaptive queries, stops at the same time, and returns the same output. As its true noise variance is t rather than t₀, exact universal recovery is impossible. The same reasoning rules out a deterministic uniform error guarantee smaller than half any chosen separation t₀−t.

This assumes the algorithm is required to terminate on the baseline. It applies to a class with an unrestricted, unknown finite number of atoms. It does not prove nonuniqueness from the entire transform, does not prove impossibility when a fixed atom bound is known, and does not establish a fixed pair hard for randomized exact queries. The alternative depends on the complete realized query transcript.

## Optional randomized exact-query caveat: constructive recovery

There is in fact an almost-sure finite-query randomized procedure under an ideal exact-real-arithmetic model, including exact equality/rank tests. It uses O(k²) queries when the unknown atomic measure has k distinct atoms with positive weights. This is not a numerically stable acquisition result.

Write μ=∑p_jδ_{x_j},

    D(w)=∏(w−x_j),
    N(w)=Σ_j p_j∏_{ℓ≠j}(w−x_ℓ),
    R(w)=N(w)/D(w).

D is monic of degree k, N is monic of degree k−1, and gcd(D,N)=1 because N(x_j)=p_jD′(x_j)≠0. If ν=μ⊞SC_t, its transform satisfies

    P(z,g)=g D(z−t g)−N(z−t g)=0.

The polynomial gD(w)−N(w) is primitive and irreducible in C[w,g] (degree one in g and coprime coefficients). The invertible linear substitution w=z−t g preserves irreducibility. P has total degree k+1, with leading homogeneous part

    g(z−t g)^k.

Every polynomial that vanishes identically on the analytic branch g=G_ν(z) is divisible by P. One way to see this is to substitute z=w+tR(w), g=R(w); a polynomial vanishing on an open branch becomes an identically zero rational function, and the kernel of this rational parametrization is the prime ideal generated by P. Hence there is no nonzero relation of total degree <k+1, and the space of relations of degree ≤k+1 is one-dimensional.

For d=1,2,… take n_d=(d+1)(d+2)/2 iid query points from any absolutely continuous distribution supported on an open subset of C₊, reusing earlier points. Build the n_d-by-n_d evaluation matrix of all monomials z^p g^q with p+q≤d. Test its rank exactly. For each fixed unknown ν:

* If d<k+1, the monomial functions are linearly independent. Their evaluation matrix is nonsingular almost surely.
* If d=k+1, their span has dimension n_d−1. The matrix has exactly that rank almost surely, and its one-dimensional nullspace recovers P up to scalar.

The rank assertion follows because any nonzero analytic determinant has a zero set of Lebesgue measure zero; linear independence supplies a nonzero determinant. The finite/countable intersections needed as d increases still have probability one. Stop at the first rank deficiency. Then k=d−1, and coefficients of P determine

    t = − coeff[z^{k−1}g²]P / (k · coeff[z^k g]P).

The denominator is nonzero. Replacing z by w+t g then recovers gD(w)−N(w), and roots/residues recover μ if desired. Total queries on termination are n_{k+1}=(k+2)(k+3)/2.

There is no contradiction with deterministic impossibility. For every fixed model the random sampling avoids its exceptional interpolation sets almost surely. For every fixed finite transcript, a higher-complexity alternative can nevertheless be constructed to match that transcript. Exchanging these quantifiers is invalid. Exact rank tests and exact complex numbers are indispensable to this argument; arbitrarily small perturbations destroy the zero-test decision. This caveat makes the statistical conditioning question central.

## B. Chebyshev discretization and uniform bound

Assume a>0 and integer k≥1. Set

    x_j=2√a cos(jπ/(k+1)),
    p_j=2 sin²(jπ/(k+1))/(k+1),       j=1,…,k.

These are the spectral nodes and first-coordinate weights of the k-by-k Jacobi matrix with zero diagonal and off-diagonal √a. Consequently

    G_{μ_k}(z)=(1/√a) U_{k−1}(z/(2√a))/U_k(z/(2√a)).

For q=√a G_{SC_a}(z), one has z/√a=q+q^{-1}, |q|<1, Im q<0. The Chebyshev formula yields

    G_{μ_k}(z)=G_{SC_a}(z) (1−q^{2k})/(1−q^{2k+2}).

To bound q, write q=ρ exp(−iθ), 0<ρ<1, 0<θ<π. Then

    Im z=√a(ρ^{-1}−ρ) sin θ ≤ √a(ρ^{-1}−ρ).

Thus Im z≥η>0 implies

    ρ≤r=(√(η²+4a)−η)/(2√a)<1.

Equality is attained at z=iη, q=−ir. Subtracting the exact transform gives

    G_{μ_k}−G_{SC_a}
      =−(1/√a) q^{2k+1}(1−q²)/(1−q^{2k+2}),

so uniformly on Im z≥η,

    |G_{μ_k}−G_{SC_a}| ≤ E₀
      := a^{-1/2} r^{2k+1}(1+r²)/(1−r^{2k+2}).

All exponents and signs check out.

## B. Stability after common semicircular smoothing

For any probability measures α,β whose transforms differ by at most E₀ throughout Im w≥η, let g₁=G_{α⊞SC_b}(z), g₂=G_{β⊞SC_b}(z), and w_j=z−b g_j. Then Im w_j≥η. Since

    |G_β(w₁)−G_β(w₂)|
      ≤ |w₁−w₂|/(Im w₁ Im w₂)
      ≤ b |g₁−g₂|/η²,

subtraction of the fixed-point equations gives

    |g₁−g₂| ≤ E₀+(b/η²)|g₁−g₂|.

For 0≤b<η² this proves

    |g₁−g₂| ≤ E := E₀/(1−b/η²).

Apply this with α=μ_k and β=SC_a. The second smoothed measure is SC_{a+b}. The restriction b<η² is used genuinely by this proof. Do not claim this particular bound for b≥η². It is a sufficient bound, not a proved optimal stability constant.

## B. Noisy adaptive estimation lower bound

Fix two unknown signal/noise models:

    H₀: signal δ₀, noise variance t₀=a+b, observed law SC_{a+b};
    H₁: signal μ_k, noise variance t₁=b, observed law μ_k⊞SC_b.

A query z∈C₊ with Im z≥η returns

    Y=G_ν(z)+ε,       (Re ε, Im ε)∼N(0,σ² I₂),

independently across queries, with σ>0. An adaptive or randomized algorithm chooses each query from its preceding transcript and its parameter-independent internal randomness. Include that randomness in the transcript. For a fixed number M of queries, or at most M queries (pad after stopping), the chain rule for relative entropy gives

    KL(P₀ || P₁)
      = E₀ Σ_j |G_{ν₀}(z_j)−G_{ν₁}(z_j)|²/(2σ²)
      ≤ M E²/(2σ²).

Query-policy kernels cancel because the algorithm is the same under both hypotheses. Pinsker gives

    TV(P₀,P₁) ≤ √(KL/2) ≤ √M E/(2σ).

Suppose one estimator t_hat satisfies

    P_h(|t_hat−t_h|<a/2) ≥ 1−δ,       h=0,1,

where 0≤δ<1/2. Thresholding at b+a/2 yields a binary test with each error probability at most δ. Hence TV≥1−2δ, and necessarily

    M ≥ 4σ²(1−2δ)²/E².

The factor 4 is correct for variance σ² in EACH real coordinate. A convention assigning total complex variance σ² would change it. Strict inequality <a/2 is essential: with ≤a/2, the constant midpoint estimator succeeds under both hypotheses. The class must contain both a one-atom signal and a k-atom signal; the theorem applies directly to “at most k atoms,” not “exactly k atoms” for k>1.

## Resource and interpretation caveats

* The exponential obstruction fixes η>0 and σ>0. Allowing arbitrarily small query height, uncharged arbitrarily high precision, or zero observation noise changes the acquisition model.
* The original query lower bound charges transform samples under its specified oracle. It does not automatically lower-bound physical samples of ν, random-matrix observations, or other measurement types. The additional positive-noise theorem below separately proves an iid full-law bound.
* Both hypotheses are fixed before the randomized noisy algorithm runs, unlike the transcript-dependent alternative in A.
* Matched information is respected: the algorithm may know a,b,k,η,σ and the two candidate transforms and still faces the testing bound.
* Fixed/max query count is proved above. Expected stopping-time bounds require stating and checking the corresponding sequential KL conditions separately.
* None of these internally checked results establishes novelty, practical transformative capability, or external proof certification.

## Additional audit: exactly-k extension

Let μ_ε consist of k distinct equally weighted atoms in [−ε,ε]. Realize a self-adjoint X with law μ_ε, ||X||≤ε, free from S with law SC_{a+b}. The resolvent identity gives

    (z−X−S)^{-1}−(z−S)^{-1}
      =(z−X−S)^{-1} X (z−S)^{-1}.

Taking the tracial state and using ||(z−A)^{-1}||≤1/Im z for self-adjoint A yields

    |G_{μ_ε⊞SC_{a+b}}(z)−G_{SC_{a+b}}(z)|≤ε/(Im z)².

Thus ε=η²E_k gives a pair of exactly-k atomic signals whose transforms differ by ≤2E_k throughout Im z≥η, while their noise variances still differ by a. This is valid. One may choose ε=min(η²E_k,√a) to keep both signal supports in [−2√a,2√a] for every k while retaining the bound. Choosing the small atoms symmetrically also matches the signal means. The construction permits vanishing separation; it does not satisfy a fixed positive separation promise as k grows.

## Additional audit: decreasing-height pairwise repair

Fix a=1,b=0 and query z=i/(k+1). With

    r=exp(−asinh(1/[2(k+1)])),

symmetry gives q=−ir and the exact transform gap is

    D_k = r^{2k+1}(1+r²)
          / |1−(−1)^{k+1}r^{2k+2}|.

As asinh(x)≤x,

    r^{2k+1} ≥ exp(−(2k+1)/[2(k+1)]) > e^{-1}.

Also 1+r²≥1 and the denominator is ≤2, so D_k>1/(2e). The bound is valid for every integer k≥1, with no asymptotic qualification.

For the independent Gaussian transform oracle, project the sample mean onto the direction separating the two known complex means and threshold at their midpoint. Under each hypothesis its error is Φ(−√M D_k/(2σ)), bounded by exp(−M D_k²/(8σ²)). Therefore the explicit sufficient count

    M=max{1, ceil(32e² σ² log(1/δ))}

works for 0<δ<1/2, σ>0. The correct uniform order includes the unavoidable one-query term: O(1+σ² log(1/δ)). This is an achievable pairwise test under a changed query-height interface; it is not universal estimation of unknown μ and t.

For iid samples X of the observed law, take only the imaginary part of the empirical resolvent. At this query height,

    Im[1/(z−X)] = −η/(X²+η²) ∈ [−(k+1),0].

Both true transforms are purely imaginary, so their imaginary means differ by D_k. Hoeffding's one-sided inequality for midpoint thresholding gives each testing error at most

    exp(−n D_k²/[2(k+1)²]).

Thus

    n=max{1, ceil(8e² (k+1)² log(1/δ))}

is an explicit sufficient iid sample count. Using the full complex empirical transform also gives the claimed O(k² log(1/δ)) order with slightly different constants.

The strongest exact-iid baseline is much simpler for this b=0 pair: one exact sample lies in the known finite support of μ_k with probability one under H₁ and probability zero under the continuous SC_1 law. Exact support membership therefore distinguishes the pair in one sample. Finite physical measurement precision would have to be added to that baseline and charged. Accordingly, this repair only shows how a decreasing query height defeats this particular transform obstruction; it is not a new sampling capability, does not solve positive-b deconvolution, and does not resolve general unknown-signal acquisition.

## Additional audit: uniform positive-noise law bound and iid lower bound

This extension is valid and materially strengthens the original oracle statement. Assume a>0 and b>0, put c=a+b, ρ=√(a/c), and choose any fixed r with ρ<r<1. Define

    e_k(r)=r^{2k+1}(1+r²)/[√a(1−r^{2k+2})],
    d_k(r)=b e_k(r),
    D_k(r)=(√a/c) r d_k(r)
          =(b/c) r^{2k+2}(1+r²)/(1−r^{2k+2}),
    h_k(r)=3√D_k(r)/√a+e_k(r).

If

    ρ+3√D_k(r)<r,

then

    sup_{z∈C₊}|G_{μ_k⊞SC_b}(z)−G_{SC_c}(z)|≤h_k(r).

The condition holds for all sufficiently large k; h_k(r)=O(r^k) with a,b,r fixed.

### Checked continuation proof

Set λ_s=(1−s)SC_a+sμ_k and ν_s=λ_s⊞SC_b for 0≤s≤1. Fix z∈C₊, and let

    g_s=G_{ν_s}(z),  w_s=z−b g_s,
    q_s=√a G_{SC_a}(w_s).

The functions s↦g_s,w_s,q_s are continuous. For g_s this follows directly from bounded subsequences (|g_s|≤1/Im z), continuity of G_{λ_s}(w) in s,w when Im w≥Im z, and the unique lower-half-plane fixed point. Thus no uniform-in-s density regularity theorem is needed for this step. Each q_s belongs to the lower half of the unit disk and is nonzero.

The Chebyshev identity gives

    z=F₀(q_s)+s R_k(q_s),
    F₀(q)=√a/q+cq/√a,
    R_k(q)=−(b/√a)q^{2k+1}(1−q²)/(1−q^{2k+2}).

For |q|≤r, |R_k(q)|≤d_k(r). Let

    u=√a G_{SC_c}(z),   v=ρ²/u.

Then |u|<ρ, q_0=u, and

    (c/√a)(q−u)(q−v)
      =(c/√a)q²−zq+√a.

Multiplying the equation for q_s by q_s proves, whenever |q_s|≤r,

    |(q_s−u)(q_s−v)|≤D_k(r).

Write δ_k=√D_k(r). Every such q_s lies in the union of the two closed disks B(u,δ_k) and B(v,δ_k). If the disks are disjoint, a continuous path beginning at u cannot leave its disk while remaining in their union. If the disks intersect, their centers are at distance at most 2δ_k, so their union lies in B(u,3δ_k). This proves |q_s−u|≤3δ_k on any initial interval on which |q_s|≤r.

If a first time with |q_s|=r existed, the bound at that time would give

    |q_s|≤|u|+3δ_k<ρ+3δ_k<r,

a contradiction. Thus |q_s|<r and |q_s−u|≤3δ_k for all s. At s=1,

    G_{ν_1}(z)=G_{μ_k}(w_1)
              =q_1/√a+[G_{μ_k}(w_1)−G_{SC_a}(w_1)],

where the bracket has modulus ≤e_k(r). Since G_{SC_c}(z)=u/√a, the uniform bound h_k(r) follows.

The first-exit argument is necessary. One must not simply assume all q_s remain in |q|≤r in order to bound R_k. The stated strict condition closes this bootstrap correctly. The second root v may be very large as z→∞; the disk argument still works and introduces no dependence on v into the final bound. Reconstructing w via q+q^{-1} is unnecessary and would introduce an avoidable singular-looking factor near q=0.

### Full-law total variation

Both laws have support in [−R,R], with R=2√a+2√b: this follows from self-adjoint operator norm bounds, since supp μ_k⊂[−2√a,2√a]. Positive semicircular convolution has a density. A short sufficient argument is the fixed-point bound −Im G_{λ⊞SC_b}(z)≤1/√b; bounded Poisson integrals imply absolute continuity with density at most 1/(π√b).

The uniform transform bound gives, by Poisson approximation / Stieltjes inversion,

    ||f_{μ_k⊞SC_b}−f_{SC_c}||_∞≤h_k(r)/π

in the essential-supremum sense. Therefore, with TV(P,Q)=½∫|f_P−f_Q|,

    TV(μ_k⊞SC_b,SC_c)≤ε_k:=R h_k(r)/π=O(r^k).

No continuity claim at support edges is required; the almost-everywhere density bound suffices.

For M iid exact samples from either law, maximal coupling gives

    TV(P₀^{⊗M},P₁^{⊗M})≤1−(1−ε_k)^M≤M ε_k

when ε_k<1. Any single estimator whose noise-variance error is strictly <a/2 with probability ≥1−δ under both hypotheses yields a test with TV≥1−2δ. Thus

    M≥(1−2δ)/ε_k

and, more sharply for 0<δ<1/2,

    M≥log(1/(2δ))/[−log(1−ε_k)].

These are necessary sample counts under the full iid-law interface, even if the two candidates and every parameter except the hypothesis are supplied to the estimator. They grow exponentially in k for fixed a,b,r,δ. The whole-transform bound also yields the corresponding independent Gaussian transform-query lower bound without any minimum query height, replacing E by h_k(r).

This result is restricted to fixed positive common noise b. At b=0, ρ=1 and there is no admissible r; indeed the atomic-versus-continuous pair has TV=1. This dependence is mathematically essential and consistent with the decreasing-height and exact-support repairs above. The theorem still does not lower-bound the joint law of all eigenvalues of one finite random matrix, which is a different dependent observation experiment. It is an internally checked ill-conditioning theorem, not evidence of novel practical capability or historical priority.
