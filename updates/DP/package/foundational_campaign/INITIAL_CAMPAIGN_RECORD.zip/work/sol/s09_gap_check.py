"""Small deterministic diagnostic for the commuting-creation gap identities.

The proof is in s09_gap.md. These finite floating-point instances do not
establish the theorem or any tensor-to-creation expansion premise.
"""

import itertools
import json
import math

import numpy as np


def local_operator(mat, indices, dims):
    """Embed a matrix on ordered indices without assumptions on dimensions."""
    n = math.prod(dims)
    result = np.zeros((n, n), dtype=complex)
    all_states = list(itertools.product(*(range(d) for d in dims)))
    support_dims = [dims[i] for i in indices]
    for column, state in enumerate(all_states):
        local_column = np.ravel_multi_index(tuple(state[i] for i in indices), support_dims)
        for local_state in itertools.product(*(range(d) for d in support_dims)):
            local_row = np.ravel_multi_index(local_state, support_dims)
            coefficient = mat[local_row, local_column]
            if coefficient == 0:
                continue
            new_state = list(state)
            for i, value in zip(indices, local_state):
                new_state[i] = value
            row = np.ravel_multi_index(tuple(new_state), dims)
            result[row, column] += coefficient
    return result


def instance(dims, seed):
    rng = np.random.default_rng(seed)
    count = len(dims)
    supports = [tuple(s) for size in range(1, min(3, count) + 1)
                for s in itertools.combinations(range(count), size)]
    terms = []
    norms = []
    for support in supports:
        local_dims = [dims[i] for i in support]
        vector = np.zeros(math.prod(local_dims), dtype=complex)
        for values in itertools.product(*(range(1, d) for d in local_dims)):
            vector[np.ravel_multi_index(values, local_dims)] = rng.normal() + 1j*rng.normal()
        vector /= np.linalg.norm(vector)
        weight = float(rng.uniform(0.1, 1.0))
        matrix = np.zeros((len(vector), len(vector)), dtype=complex)
        matrix[:, 0] = weight*vector
        terms.append(local_operator(matrix, support, dims))
        norms.append(weight)
    unscaled = max(sum(len(s)*weight for s, weight in zip(supports, norms) if i in s)
                   for i in range(count))
    scale = 0.1/unscaled
    terms = [scale*term for term in terms]
    norms = [scale*weight for weight in norms]
    kappa = max(sum(len(s)*weight for s, weight in zip(supports, norms) if i in s)
                for i in range(count))
    total_dim = math.prod(dims)
    K = sum(terms, np.zeros((total_dim, total_dim), dtype=complex))
    vacuum = np.zeros(total_dim, dtype=complex)
    vacuum[0] = 1
    h = [local_operator(np.diag([0]+[1]*(dims[i]-1)), (i,), dims)
         for i in range(count)]
    K_i = [sum((term for s, term in zip(supports, terms) if i in s),
               np.zeros_like(K)) for i in range(count)]
    reports = []
    for t in [0.0, 0.3, 1.0]:
        Q = [h_i-t*k_i for h_i, k_i in zip(h, K_i)]
        H = sum((q.conj().T@q for q in Q), np.zeros_like(K))
        commutator = [[qi@qj.conj().T-qj.conj().T@qi for qj in Q] for qi in Q]
        row_sum = max(sum(float(np.linalg.norm(c, 2)) for c in row) for row in commutator)
        first = sum(((qi@qj).conj().T@(qi@qj) for qi in Q for qj in Q), np.zeros_like(K))
        second = sum((Q[i].conj().T@commutator[i][j]@Q[j]
                      for i in range(count) for j in range(count)), np.zeros_like(K))
        target = vacuum.copy()
        term = vacuum.copy()
        for order in range(1, count+1):
            term = (t/order)*(K@term)
            target += term
        target /= np.linalg.norm(target)
        eigenvalues = np.linalg.eigvalsh(H)
        lower = 1-2*t*kappa-2*t*t*kappa*kappa
        defect = H@H-lower*H
        report = {
            "t": t,
            "kappa": kappa,
            "commutator_row_sum": row_sum,
            "row_sum_bound": 2*t*kappa+2*t*t*kappa*kappa,
            "idempotent_error": max(float(np.linalg.norm(q@q-q)) for q in Q),
            "commuting_error": max(float(np.linalg.norm(qi@qj-qj@qi)) for qi in Q for qj in Q),
            "H_squared_identity_error": float(np.linalg.norm(H@H-first-second)),
            "ground_residual": float(np.linalg.norm(H@target)),
            "zero_eigenvalue_count": int(np.sum(np.abs(eigenvalues)<1e-10)),
            "gap": float(eigenvalues[1]),
            "gap_lower_bound": lower,
            "minimum_gap_polynomial_eigenvalue": float(np.linalg.eigvalsh(defect)[0]),
        }
        assert report["zero_eigenvalue_count"] == 1
        assert row_sum <= report["row_sum_bound"]+1e-10
        assert report["gap"] >= lower-1e-10
        assert report["minimum_gap_polynomial_eigenvalue"] >= -1e-10
        assert report["H_squared_identity_error"] < 1e-10
        assert report["ground_residual"] < 1e-10
        reports.append(report)
    return {"local_dimensions": dims, "seed": seed, "reports": reports}


if __name__ == "__main__":
    c = math.log(5/4)
    explicit_kappa = c*(20/27)/(4*(1-1/512))
    result = {
        "status": "finite_diagnostic_only",
        "explicit_q": 2**-34,
        "explicit_R": 512,
        "explicit_kappa_bound": explicit_kappa,
        "explicit_gap_bound": 1-2*explicit_kappa-2*explicit_kappa**2,
        "instances": [instance([2, 2, 2, 2], 20261011), instance([3, 4, 2], 20261012)],
    }
    print(json.dumps(result, indent=2))
