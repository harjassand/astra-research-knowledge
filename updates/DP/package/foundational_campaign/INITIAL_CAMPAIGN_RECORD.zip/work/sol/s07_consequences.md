# Consequences of the anisotropic rare-defect PEPS norm expansion

Status: working consequence derivations. The base norm theorem is supplied by root's separate proof and is treated as an explicit input here, rather than as independently validated or prior-art-cleared. No breakthrough or novelty claim is made. No public or paid action is authorized or performed.

## 1. Supplied interface

On an open square grid with N vertices and bond dimension D, let |Omega> be the product of normalized Bell pairs on virtual edges. Local PEPS maps T_v obey T_v* T_v=I-H_v, where 0<=H_v<=I and, at interior vertices,

H_v=A_{v,L} tensor B_{v,URD}, 0<=A_v,B_v<=I,
q_v=||H_v||_F/D^2<=1/128.

Boundary defects are set to zero. The squared norm is Z=<Omega| tensor_v(I-H_v)|Omega>. The supplied theorem gives a deterministic FPTAS, polynomial jointly in N,D,epsilon^(-1), through:

- defect moments t_S=<Omega|prod_{v in S}H_v|Omega> with 0<=t_S<=prod_{v in S}q_v;
- factorization over disconnected vertex sets;
- computation of t_S in poly(|S|,D), because the left-leg factorization cuts horizontal contractions and leaves vertical chains;
- a zero-free disk |z|<=2 for Z(z)=sum_S(-z)^|S|t_S;
- a connected-support expansion whose order-m cost is N exp(O(m))poly(D).

A physical local observable O on R inserts K_R=T_R* O T_R on that region instead of the product of local Gram factors. An outcome effect E_v inserts T_v*E_v T_v. Consequences must establish efficient contraction and a bound after those substitutions; norm approximation alone does not justify arbitrary observables or self-reducible full sampling.

## 2. Initial consequence targets

1. Fixed-support observables: derive an anchored expansion that handles an arbitrary bounded insertion on O(1) sites without demanding that the insertion itself have the rare-defect form.
2. Full sampling: find a nontrivial explicitly described measurement family whose every outcome and every conditioning step preserves a tractable background and the defect-moment bound.
3. Determine whether the norm theorem extends to observables only through an exponential-in-support routine or yields a stronger stable measurement simulator. Compare assumptions with arXiv:2604.21919, 2510.02290, and 2604.03228 using primary text.

## 3. Arbitrary bounded insertions on finitely many sites

Assume the supplied scalar deletion theorem: for every vertex subset U and |z|<=2,

Z_U(z)!=0,
|Z_U(z)/Z_(U minus v)(z)-1|<=rho=1/5.

Write b=1-rho=4/5 and q=1/128. Let R be ANY fixed vertex set of size r; it need not be connected. A physical Hermitian observable O supported on R has virtual insertion

K_R=(tensor_{v in R}T_v)* O (tensor_{v in R}T_v).

Since each T_v*T_v<=I, ||K_R||<=||O||. This insertion has to be acquired from the physical maps or supplied explicitly: local Gram matrices alone do not determine physical observables. For S disjoint from R put

u_S=<Omega| K_R tensor (tensor_{v in S}H_v) tensor I |Omega>.

Then, by operator order,

|u_S|<=||O|| t_S<=||O|| product_{v in S}q_v.            (9)

Indeed, -||O||I_R<=K_R<=||O||I_R and the disjoint tensor product H_S is PSD. This is the needed marked-cluster bound; no special cut factorization or positivity of O is assumed at the insertion. In particular it covers signed observables and zero expectations, for which a relative guarantee would be inappropriate.

Define

N_O(z)=sum_{S subset V minus R}(-z)^|S|u_S,
E_O(z)=N_O(z)/Z_V(z).

At z=1, E_O(1)=<psi|O|psi>/<psi|psi>. The numerator omits all original Gram factors on R and substitutes K_R; the denominator retains them. This distinction is essential.

### Anchored component decomposition and an N-independent analytic bound

For any S outside R, separate its connected components into those adjacent to R and those not adjacent. Moment factorization holds for the latter even though K_R can couple all roots. Let C contain R and all vertices of the components adjacent to R. Then every component of C intersects R. Conversely such a C, with all remaining selected vertices outside N[C], specifies the same decomposition. Thus

N_O(z)=sum_C (-z)^|C minus R| u_(C minus R) Z_(V minus N[C])(z), (10)

where C ranges over sets containing R whose every connected component meets R. The closed neighborhood N[C] includes C. The case C=R is allowed, whether or not R is connected.

The number of such C with |C minus R|=k is at most

choose(k+r-1,r-1)16^k.                                  (11)

To prove this, take a spanning forest rooted at all r vertices of R, with each non-root vertex assigned to one root. Such a forest exists whenever every component meets R. If root i receives k_i vertices, its assigned set plus root is connected and has at most 16^(k_i) possible vertex sets by the connected-set bound. Sum over weak compositions k_1+...+k_r=k. A deterministic choice of forest gives an injection into these tuples; allowing all tuples only overcounts.

Compare Z_(V minus N[C]) with Z_(V minus R). The deletion ratios bound its absolute ratio by b^(-|N[C] minus R|), while

|N[C] minus R|<=5k+4r.

Therefore, using (9), (10), and (11),

|N_O(z)/Z_(V minus R)(z)|
 <=||O|| b^(-4r) sum_{k>=0} choose(k+r-1,r-1) a^k
 =||O|| [b^(-4)/(1-a)]^r,

a=32q b^(-5)<1.

Deleting the r roots from the denominator gives
|Z_(V minus R)/Z_V|<=b^(-r). Consequently

|E_O(z)|<=||O|| C^r for |z|<=2,
C=b^(-5)/(1-32q b^(-5))=1/(b^5-32q)<13.               (12)

This bound depends on support size and norm, and is independent of N and D. Its constants are deliberately loose. Cauchy's estimate gives

|E_O(1)-sum_{k=0}^m [z^k]E_O(z)|<=||O|| C^r 2^(-m).   (13)

Thus m=ceil(log_2(C^r/epsilon)) gives additive error epsilon||O||. Arbitrary bounded local observables do not require a separately postulated decay-of-strings hypothesis in this specific defect class: (9) supplies it directly.

## 4. Exact anchored coefficient algorithm and its costs

For any outside-root set T, let E_T(z) be the expectation ratio in the instance whose allowed defect vertices are R union T. More explicitly,

E_T(z)=[sum_{U subset T}(-z)^|U|u_U]/Z_(R union T)(z).

For S outside R define the finite Mobius coefficients

d_(S,k)=sum_{T subset S}(-1)^(|S|-|T|)[z^k]E_T(z).       (14)

Mobius inversion gives [z^k]E_V=sum_S d_(S,k). Only sets with |S|<=k and every component of S union R meeting R contribute. The size cancellation follows by expanding the denominator as a formal geometric series: a term of z-degree k uses at most k outside vertices, and the alternating sum annihilates terms not using all of S. For the rooted-component cancellation, an outside component disconnected from R supplies an identical partition factor in numerator and denominator, which cancels exactly; alternating over its nonempty vertex set then gives zero.

Enumerate the rooted forests of Section 3 through k=m, deduplicating their vertex supports. For each S compute u_U for U subset S and t_U for U subset R union S, form the numerator and denominator polynomials for every T subset S, perform formal division through degree m, and evaluate (14). Naive subset work is exp(O(m+r)). This is an exact algebraic identity, with no sampling oracle hidden in the coefficient construction.

The arbitrary insertion K_R removes the left-leg cut at only r vertices. After contracting the horizontal A leaves at every other selected vertex, the remaining components are vertical transfer chains joined to at most r exceptional tensors. Each exceptional tensor touches only constantly many chains. Contract the unmarked chain segments first; the remaining finite network has O(r) attachment legs of dimension D^2. Hence

cost(u_U)<=poly(|U|,D) D^O(r),

besides acquiring and storing K_R. This is polynomial jointly in |U| and D for fixed r. An insertion supported on disconnected sites obeys the same bound. Ordinary unmarked t_U retain their poly(|U|,D) exact contraction cost.

Combining with m=O(r+log(1/epsilon)), one obtains a deterministic additive approximation algorithm with time

D^O(r) exp(O(r)) (1/epsilon)^O(1) poly(local input length), (15)

for fixed grid degree. The displayed epsilon exponent is independent of D. No dependence on N is needed after the required tensor entries are locally accessible; reading a globally supplied input still costs its actual length. Tensor data accessed lie within graph distance m of R. Forming K_R from physical maps and O costs their input and matrix multiplication work; it is not included for free in a Gram-only norm oracle.

For rational data, all contractions and formal divisions can be performed by exact rational arithmetic. Bit lengths depend polynomially on m, r, D and the local input bit length, since every primitive is a contraction of O(m+r) explicitly supplied tensors. These statements are additive estimates, not a fully polynomial relative scheme for arbitrary observables.

### Algorithmic locality

If two allowed instances have the same K_R and the same defect tensors within distance m of R, their coefficients in (14) agree through order m. Their normalized observable expectations therefore differ by at most

2||O|| C^r 2^(-m).

This proves a local-data approximation property directly, without computing or assuming a BP fixed point. It is a specific consequence of the supplied defect criterion, not a claim that algorithmic locality as a general concept is new.

## 5. Exponential clustering of fixed local observables

Let O_A,O_B be bounded Hermitian observables on disjoint connected finite regions A,B, of sizes r_A,r_B, at graph distance d>=1. Define their analytic expectation ratios using their fixed insertions K_A,K_B as in Section 3, and let

F(z)=E_(O_A O_B)(z)-E_(O_A)(z)E_(O_B)(z).

By (12), F is analytic for |z|<=2 and

|F(z)|<=2 C^(r_A+r_B)||O_A||||O_B||.

Every coefficient [z^k]F vanishes for k<d-1. One direct proof introduces formal sources xK_A,yK_B in place of the respective root Gram products and takes [xy]log of the full contraction. This coefficient equals F. By component factorization, log terms contributing both x and y must connect the two root regions. A path connecting A and B needs at least d-1 defect vertices outside the roots; a z^k term has at most k such vertices. This is a formal linked-support cancellation, independent of convergence considerations.

Summing the Cauchy coefficient bounds from k=d-1 gives

|<O_A O_B>-<O_A><O_B>|
 <=4 C^(r_A+r_B)||O_A||||O_B|| 2^(-(d-1)).              (16)

The expectations here are in the normalized physical PEPS at z=1. Constants are loose but uniform in N and D for fixed support sizes. This establishes ordinary exponential clustering for the class, including its allowed local kernels. It neither implies a parent-Hamiltonian spectral gap nor supplies a quantum preparation algorithm.

## 6. A deterministic extension to bounded directional operator rank

The exact one-term left cut can be replaced by a supplied decomposition of fixed length chi:

H_v=sum_{l=1}^chi A_(v,l),L tensor B_(v,l),URD,
0<=H_v<=I, ||H_v||_F/D^2<=q.

The individual factors may be taken PSD in the measurement example below, although only the positivity and norm of the whole H_v enter convergence. For a moment supported on k vertices, expand the chi choices and contract each term by the same vertical-chain algorithm. The exact moment cost is at most

chi^k poly(k,D).

All bounds and component identities of the supplied norm theorem remain unchanged because they apply to the whole H_v. Its coefficient enumeration therefore costs exp(O(m))chi^m poly(D), which is polynomial jointly in N,D,1/epsilon for fixed chi. The observable algorithm likewise gains chi^m and retains (15) for fixed chi and fixed support. If chi grows with D, this argument does not give uniform joint polynomial time; the factor chi^O(log(N/epsilon)) must be charged explicitly.

Boundary identity tensors can be retained. More generally, on a boundary vertex of degree d_v the correct average-defect norm is ||H_v||_F/D^(d_v/2), with a cut compatible with the same contraction order. No interior normalization is silently imposed on a lower-degree boundary tensor.

## 7. Full joint Born sampling for a stable weak-measurement class

Consider a protocol measuring each physical site at most once. The measurement at a site may depend on previous classical outcomes. For each allowed outcome a supply an effect E_(v,a)>=0, sum_a E_(v,a)=I, and a positive scalar c_(v,a) such that the normalized pulled-back Gram is

T_v* E_(v,a) T_v / c_(v,a)=I-H_(v,a).

Require every H_(v,a) to satisfy the same norm/PSD assumptions and to have a supplied directional decomposition of length at most a fixed chi. This is an explicit, locally checkable stability interface. It is stronger than merely supplying the unmeasured norm instance.

For any prefix h of outcomes, replace each measured local Gram by I-H_(v,h_v), leaving unmeasured Grams unchanged, and call its normalized contraction Z_h. The exact joint probability of the prefix is

P(h)=[product_{v measured}c_(v,h_v)] Z_h/Z_empty.

This follows from the Born rule for effects on disjoint sites, including classically adaptive choices. Thus the next-outcome probabilities are proportional to

w_a=c_(v,a) Z_(h,a).

Approximate each positive Z_(h,a) by the deterministic norm scheme to relative error delta=epsilon/(4N), normalize the approximate w_a, and sample the resulting categorical distribution. If all weights have relative error at most delta<1/2, the one-step conditional total variation error is at most delta/(1-delta)<=2delta. The total variation distance between the full sampled outcome law and the exact protocol law is at most the sum over the N conditional errors, hence at most epsilon/2. Finite random-bit precision can consume the remaining epsilon/2. Only the actually visited history is processed, so exponentially many possible prefixes are not enumerated.

For a polynomially described number of outcomes per site, this is a classical approximate sampler with total variation error epsilon in time polynomial jointly in N,D,input length,1/epsilon (fixed chi). It is sampling of the complete outcome string for the stated measurement class, rather than only a fixed number of marginal outcomes.

### A concrete nontrivial stable family, including an exact kernel

Let the physical local space equal the virtual local space and choose the canonical map

T=sqrt(I-A_L tensor B_URD), 0<=A,B<=I.

Measure only its physical left leg, with effects M_a on that leg commuting with A. Assume

0<=M_a<=c_a I,
0<=I-M_a/c_a<=delta I.

Commutation implies the exact pulled-back defect identity

H_a=(I-M_a/c_a)_L tensor I_URD
       +(M_a A/c_a)_L tensor B_URD.                    (17)

This is a two-term directional decomposition. All factors in (17) are PSD contractions. Moreover H_a=H+T*J_a T, where J_a=(I-M_a/c_a)_L tensor I, so

0<=H_a<=I,
||H_a||_F/D^2 <= q_original+delta.                     (18)

If q_original<=1/256 and delta<=1/256, every outcome remains within q=1/128. These are single measurements on different sites; repeated measurements on one site would accumulate their distortion and need an additional budget.

For an explicit rational kernel example take D>=16,

A=P=|0><0|,
B=|GHZ_D><GHZ_D|,
H=P tensor B,
T=I-H.

Here H and T are rational projections and q_original=1/D^2<=1/256. Let Q=2P-I on the physical left leg and use the two-outcome weak POVM

M_+=(I+eta Q)/2,
M_-=(I-eta Q)/2,
eta=1/1024,
c_+=c_-=(1+eta)/2.

The effects sum to I, commute with P, and obey delta=2eta/(1+eta)=2/1025<1/256. Every local outcome therefore gives (17) with chi=2 and satisfies (18). Boundary vertices may use trivial coin effects I/2, preserving their identity Grams. The whole protocol has a deterministic-contraction-based approximate Born sampler despite the original PEPS maps having an exact kernel. Adaptive choices of commuting weak effects with the same budget are also allowed.

The weakness is material: these effects are uniformly close to scalar identity. This result does not establish sampling after arbitrary projective measurements. Already for the identity Gram on a D^4-dimensional interior space, a rank-one effect produces H'=I-|e><e| with normalized Frobenius norm sqrt(1-D^(-4)), far outside 1/128. This is a failure of the stability hypothesis, not a hardness proof for that particular measurement.

## 8. Conditional extension from a general-defect norm FPRAS

Root has proposed a separate Gaussian-bond-sketch route to approximating moments without directional factorization; s03 is reconstructing it in work/sol/s08_gaussian_moment.md. Its claimed general-HS-small norm FPRAS is NOT assumed proved in Sections 3-7. If established, it would remove the directional-rank requirement from the sampling interface above.

Specifically, for arbitrary supplied physical maps T_v with T_v*T_v=I-H_v and q_v<=1/256, let every allowed local effect have the flat form

E_a=c_a(I-J_a), 0<=J_a<=delta I, delta<=1/256.

Then its normalized pulled-back defect is exactly H_a=H_v+T_v*J_aT_v, which is PSD, <=I, and has normalized Hilbert--Schmidt norm <=q_v+delta<=1/128. This bound uses T_v*J_aT_v<=delta I and the correct local virtual dimension. No commutation or directional structure is needed. Thus all prefixes remain within the proposed general norm class.

A norm FPRAS can be substituted in the sequential sampler, boosting the failure probability per call to at most epsilon/(4Q), where Q bounds the total number of norm calls. A union bound remains valid for adaptive query inputs because the FPRAS guarantee is pointwise for every allowed input. On successful calls, conditional weight errors accumulate as above; bad-oracle probability and finite random-bit approximation consume separate error budgets. This would give a full approximate Born sampler for arbitrary weak local POVMs satisfying the flatness budget, jointly polynomial in N,D,input length,1/epsilon. It remains conditional on the general norm algorithm and its bit/error analysis.

The same Gaussian primitive would plausibly replace the exact contraction of mixed insertion moments, at a cost depending polynomially on D for fixed r. That further extension needs an explicit second-moment bound and coefficient-error propagation and is not being asserted merely by analogy.

## 9. Stable sampling beyond commuting effects and operator-small perturbations

### Bounded operator ranks of physical maps and effects

Suppose the local physical space is partitioned as L_phys tensor R_phys, matching the virtual L tensor URD partition. Supply decompositions

T=sum_{l=1}^kappa L_l tensor R_l,
E_a=sum_{j=1}^eta C_(a,j) tensor D_(a,j),

where kappa and eta are fixed constants. Then

T*E_aT=sum_{l,m,j}(L_l* C_(a,j)L_m) tensor (R_l*D_(a,j)R_m)

has directional operator rank at most kappa^2 eta. The normalized defect I-T*E_aT/c_a has rank at most chi=1+kappa^2 eta. The factors need not individually be Hermitian or PSD; exact contraction still works, while convergence is checked on the positive whole defect. All needed decompositions are input, not rank-discovery oracles.

For T=I-P_L tensor B_URD with P and B projections, kappa=2. Any product effect E=M_L tensor C_URD has eta=1, so chi<=5. Explicitly,

T*ET=M tensor C - PM tensor BC - MP tensor CB + PMP tensor BCB.

No commutation is needed. Product weak POVMs on L_phys and R_phys with individual flatness budgets delta_L,delta_R obey total flatness at most delta_L+delta_R: I-(I-J_L) tensor (I-J_R) is PSD and <=(delta_L+delta_R)I. Thus arbitrary noncommuting adaptive product weak measurements on the entire physical site, rather than only a commuting left-leg measurement, are covered by the deterministic sampler. For example take binary effects (I+/-eta Q)/2 and (I+/-eta R)/2 for arbitrary rational Hermitian contractions Q,R and eta=1/2048; their joint four-outcome POVM has total flatness <=4/2049<1/256.

### Hilbert--Schmidt-small outcome holes

Operator-flatness was sufficient but is stronger than necessary. Suppose E_a=c_a(I-J_a) with 0<=J_a<=I. The exact identity

H_a=H+T*J_aT

shows that it is enough to bound

||T*J_aT||_F/D^2 <=delta,
q_original+delta<=1/128.                                (19)

When physical and virtual dimensions both equal D^4 and T is a contraction, ||T*J_aT||_F<=||J_a||_F by the ideal property of Frobenius norm. Condition (19) therefore allows an exact kernel in the effect E_a if its excluded subspace is sufficiently small. This is not an operator-norm perturbation guarantee.

### Concrete exclusion POVM and its full sampling theorem

Use the rational kernel PEPS maps T=I-P tensor B above with D>=16, identity boundary maps, and q_original=1/D^2. At an interior site choose an orthonormal product basis {|i>_L tensor |j>_URD}, with D and D^3 vectors on its two factors. It may be chosen adaptively from past outcomes, provided its description and associated projectors are acquired at their actual costs. Define the D^4-outcome local POVM

E_(i,j)=[I-|i><i| tensor |j><j|]/(D^4-1).               (20)

The effects sum to I and are PSD. Every effect has a zero eigenvalue. With c_(i,j)=1/(D^4-1), its hole J_(i,j)=|i><i| tensor |j><j| is a rank-one projector and satisfies ||J_(i,j)||_F/D^2=1/D^2. Thus every normalized pulled-back defect obeys

0<=H_(i,j)<=I,
||H_(i,j)||_F/D^2<=2/D^2<=1/128.                       (21)

Each E_(i,j) has directional operator rank at most two. Since kappa(T)=2, the supplied expansion of its H_(i,j) has at most chi=9 terms. The norm scheme for bounded chi and the sequential construction of Section 7 give a randomized classical output string whose distribution is within total variation epsilon of the exact joint Born law of (20) at every interior site. The contraction algorithm used at each step is deterministic. The total time is polynomial jointly in N,D,input bit length,1/epsilon; at most D^4 norm calls per site and the cost factor 9^k for a k-site defect moment are explicitly charged. Boundary sites may use trivial coin measurements, retaining identity Grams.

This is a complete stable-measurement sampling theorem for a concrete noninjective PEPS family, conditional only on the base norm theorem and the proved bounded-rank extension. Its effects are not close to scalar identity in relative operator norm: ||J_(i,j)||op=1. The small average excluded subspace, rather than small worst-case distortion, is what preserves convergence. It is not sampling of an arbitrary rank-one projective readout, and it does not provide a physical preparation procedure.

The exclusion outcome can be interpreted as reporting a product basis label ruled out by the effect; this is a noisy local measurement rather than a projective measurement in that basis. A generic outcome-conditioned tensor need not preserve the class, so the exact algebra and norm budget above are load-bearing.

## 10. Primary literature comparison and unresolved priority

The generic use of connected expansions for local observables is established. The relevant distinctions below concern sufficient hypotheses and the uniform bond-dimension cost, not novelty of the expansion framework.

- Midha and Zhang, *Beyond Belief Propagation: Cluster-Corrected Tensor Network Contraction with Exponential Convergence*, arXiv:2510.02290, https://arxiv.org/html/2510.02290v2 . Its theorem assumes a BP normalization and exponential decay of loop weights. It provides the general convergence and truncation framework. Our positive/small-average-defect bounds and exact directional contractions are a specific sufficient mechanism; the generic convergence technology is not new.
- Midha et al., *Algorithmic Locality via Provable Convergence in Quantum Tensor Networks*, arXiv:2604.21919, https://arxiv.org/html/2604.21919v1 . The main setup assumes constant D and degree; strong injectivity is defined by a strictly positive minimum singular value. The rank-one-hole map T=I-H has a zero singular value, so it fails that stated sufficient hypothesis. This establishes a distinction from that theorem, not from every contraction technique.
- Midha et al., *Belief Propagation and Tensor Network Expansions for Many-Body Quantum Systems: Rigorous Results and Fundamental Limits*, arXiv:2604.03228, https://arxiv.org/html/2604.03228v1 . Section III already gives observable expansions and additive estimates, assuming decay of strings on the original and inserted networks. Its footnote and Section S3.3 explicitly caution that bulk loop decay alone does not guarantee inserted-string decay. Here (9) and (12) provide the missing bound within a particular explicitly supplied class. Exponential clustering and local correction formulas are established ideas.
- Heddes, Nunes, Givargis and Nicolau, *Approximating Tensor Network Contraction with Sketches*, arXiv:2603.07387, https://arxiv.org/html/2603.07387v1 . Theorem 1 gives randomized arbitrary cyclic contraction with error relative to the product of input Frobenius norms and exponential dependence 3^|E| on the edge count. This is a close prior primitive for the general-moment route. It does not by itself give relative approximation of the full PEPS norm; composing it with a controlled cluster expansion is a separate consequence whose priority remains unresolved.

No search non-detection is being treated as novelty evidence. A complete comparison with algorithmic quantum cluster expansions, noisy-circuit simulation, and earlier sketching work remains necessary before publication or significance claims. No external proof validation has occurred.

## 11. Finite-phase moment sketches without continuous sampling

The following derivation supplies an exact finite-bit version of the proposed Gaussian primitive. It is included to support consequence proofs; arbitrary tensor-network sketching is prior art as noted above.

After tracing identity exterior legs, a k-vertex defect moment is a scalar tensor contraction on an induced graph. Its edge indices are double-layer pairs of dimension Q=D^2. An internal normalized Bell bond contributes D^(-1), not Q^(-1). Distribute this factor as D^(-1/2) to each incident tensor for analysis; the implementation retains the global rational factor D^(-|E|).

For each internal edge and each of its Q coordinate values, independently choose a fourth root of unity xi in {1,i,-1,-i}. Put xi on one endpoint and conjugate(xi) on the other. Contract each local tensor against these vectors separately, and multiply all resulting local scalars with the Bell normalization. Call the result Y. Since E[xi_a conjugate(xi_b)]=1_{a=b}, E Y equals the exact moment. A sample requires only O(k) local contractions of explicitly stored bounded-degree tensors, hence poly(k,D), and finite random bits.

For a local tensor f of degree d with independent complex Gaussian leg vectors, its multilinear contraction y satisfies

E|y|^4 <=2^d ||f||_F^4.                                  (22)

Indeed the Gaussian fourth moment has two pairings on each leg. Each of the 2^d terms is a reduced-state purity of |f><f| across a leg bipartition, bounded by (Tr|f><f|)^2=||f||_F^4. This also proves the bound for Hilbert-valued intermediate tensors. For the finite phases, the single-leg fourth-moment operator is the Gaussian operator minus the PSD diagonal projector sum_j |j,j><j,j|. Thus it is PSD and dominated by the Gaussian operator. Tensor-product Loewner domination gives (22) for the finite phases as well.

Apply graph Finner to the functions |y_v|^2 of the independent edge vectors, using exponent two at every vertex. Every edge variable appears at exactly two endpoints. Then

E|Y|^2 <= product_v (E|y_v|^4)^(1/2)
 <=2^|E| product_v ||f_v||_F^2
 <=4^k product_{v in S}q_v^2,                            (23)

because |E|<=2k. This proof is valid for complex Hermitian tensors of either sign; positivity is not needed for the second-moment bound.

For a mixed insertion u_S, merge R into one root blob after contracting Bell edges internal to R. In the original PSD-hole class, its operator norm is at most ||O||, so its normalized Frobenius norm is at most ||O||. Its degree is at most 4r. The same proof gives

E|Y_insert|^2 <=4^(k+r)||O||^2 product_{v in S}q_v^2.      (24)

Per-sample work is poly(k,D)D^O(r), including the explicitly acquired root blob. These are upper second moments, not relative variances with respect to a possibly zero observable.

Real parts estimate real Hermitian moments. Median-of-means with independent blocks estimates each such moment to absolute error eta (or eta||O|| for an insertion) with sample count exp(O(k+r))eta^(-2)log(1/failure). All sampled values are rational complex when tensor entries are rational; no Gaussian rounding or floating-point assumption is required. Internal-root Bell contractions and the global D^(-|E|) factor are rational operations.

## 12. Randomized local observables without directional factorization

For the PSD-hole class 0<=H_v<=I with the same normalized Hilbert--Schmidt bound, Sections 3 and the zero-free proof never used the directional cut. Only exact computation in Section 4 did. Substituting the finite-phase estimates from Section 11 yields a randomized local additive approximation scheme for arbitrary fixed-support observables without a directional decomposition, as follows.

Normalize ||O||<=1 for notation. Choose m so C^r2^(-m)<=epsilon/2 and put ell=m+r. Suppose every needed t_U estimate has error at most eta and every u_U estimate has error at most eta||O||. There are exp(O(m+r)) such queries. On |z|=2, each denominator polynomial estimate differs from its true value by at most eta3^ell, while

|Z_(R union T)(z)|>=b^ell,
|N_(O,T)(z)|<=||O||(1+2q)^ell.

If eta3^ell<=b^ell/2, division is stable on the entire circle. The estimated ratio obeys

|Ehat_T(z)-E_T(z)|<=4||O|| eta K^ell,
K=3(1+2q)/b^2<5.                                        (25)

This follows by writing the difference of two ratios, using the denominator lower bounds and numerator error eta||O||3^ell. Cauchy's estimate bounds the error in the degree-m Taylor sum at one by 8||O||eta K^ell. Alternating over T subset S costs at most 2^m, and the number of rooted supports S of size <=m is at most 2^(r+1)32^m by (11). Therefore the total error of the anchored coefficient algorithm is at most

16||O|| eta (2K)^r (64K)^m.                              (26)

Choose

eta<=min{(b/3)^ell/2,
          epsilon/[32(2K)^r(64K)^m]}.

Then (26) is at most epsilon||O||/2. Combined with the truncation error, the output has additive error epsilon||O|| whenever all moment estimates meet their guarantees. Give each query failure probability delta/Q, with Q an explicit bound on the number of queries, and use a union bound. Equations (23)-(24) and median-of-means yield total time

D^O(r) exp(O(r)) (1/epsilon)^O(1) poly(log(1/delta),input length),

for fixed support r. The exponents do not grow with D or N. The dependence on N is only acquisition of locally accessible input; queried tensors still lie within distance m of R. This is an internally derived randomized additive theorem, not a conditional appeal to an unknown log-coefficient stability claim. It relies on the same supplied Finner/zero-free base proof and the explicit finite-phase calculation above.

For arbitrary non-Hermitian insertions one can either estimate real and imaginary Hermitian parts, or write u_S=Tr(K_R R_S) for the PSD reduced operator R_S of trace t_S and use |u_S|<=||K_R||t_S. Thus matrix-unit queries are covered. For fixed physical dimension per site or dimensions polynomial in D, finitely many such estimates recover a fixed-region reduced density matrix to trace-norm accuracy epsilon at a polynomial additional dimension cost. Acquisition and projection to a normalized PSD approximation must be included; the number of matrix entries is not treated as constant when D grows.

## 13. Outcome-dependent centering and a high-effective-rank sampler interface

s03's strengthened norm route allows signed Hermitian H_v with W_v=I-H_v>=0, using |t_S|<=product q_v rather than nonnegative moments. The zero-free recurrence is unchanged. The general norm FPRAS and its full log-coefficient error analysis are documented separately in work/sol/s08_gaussian_moment.md. The sampling reduction below assumes that norm result; it does not require unsigned holes or a common centering scalar across outcomes.

For any nonzero rational PSD local Gram G on a d-dimensional virtual space, choose the rational scalar

c(G)=Tr(G^2)/Tr G,
W=G/c(G), H=I-W.

This minimizes the normalized squared Frobenius defect among positive scalar centerings. Explicitly,

q_min^2=||H||_F^2/d
 =1-(Tr G)^2/[d Tr(G^2)]
 =1-r_eff(G)/d.                                         (27)

Thus q_min<=q0=1/128 is equivalent to the locally checkable effective-rank bound

r_eff(G)>=(1-q0^2)d.

The centered W may have eigenvalues greater than one; its H may have negative eigenvalues. They must not be silently treated as PSD holes. The centering gives ||W||_F/sqrt(d)=sqrt(r_eff(G)/d)<=1.

Let G_v=T_v*T_v and G_(v,a)=T_v*E_(v,a)T_v. Assume every nonzero unmeasured Gram and every nonzero allowed outcome Gram meets (27). Supply or compute their outcome-dependent scalars c_(v,0),c_(v,a) and centered tensors. For a measurement prefix h, let Z_h be the contraction of those centered tensors. Its exact Born probability is

P(h)=[product_{v measured}(c_(v,h_v)/c_(v,0))] Z_h/Z_0.  (28)

At the next site the conditional weights are c_(v,a)Z_(h,a). Completeness gives sum_a c_(v,a)Z_(h,a)=c_(v,0)Z_h, so normalization yields the correct conditional probabilities without any common scalar assumption. A zero local outcome Gram is an impossible outcome and can be omitted. All other centered contractions are strictly positive by the norm theorem.

Substitute the norm FPRAS with per-call relative accuracy O(epsilon/N) and boosted confidence, and use exactly the TV accumulation argument of Section 7. This yields a full approximate Born sampler for the explicitly stable high-effective-rank measurement family, polynomial jointly in N,D,input length,1/epsilon, with its oracle failure budget included. All allowed outcomes at every visited prefix must meet the criterion; a uniform promise or a proved measurement-family condition is necessary for a uniform sampler theorem. Checking only successful or likely outcomes cannot silently replace that promise.

The weak and exclusion measurement examples satisfy a stronger uncentered HS bound, so optimal centering can only improve their q. They therefore remain concrete examples of this interface. Outcome-dependent rational centering does not imply that arbitrary projective measurements preserve high effective rank.

### Signed-H observables: distinctions and a complete fallback

The operator-order argument in (9) does not apply to signed H_S. For a SINGLE root site, however, canonical centering and Schatten Holder give

||K_v||_F=||C_v*O C_v||_F
 <=||O||||C_v||_4^2
 =||O||||W_v||_F,

where C_v=T_v/sqrt(c_(v,0)). Hence the root normalized Frobenius weight is <=||O||. Applying Finner directly to this root and all signed defect tensors restores |u_S|<=||O||product q_v. The anchored proof and finite-phase estimates then give a dimension-independent local bound and the randomized local additive algorithm without requiring a reserve in q. The same statement holds for a PRODUCT observable over several roots, using separate local insertion tensors.

An arbitrary entangled observable on r connected sites requires a root blob or an explicit product expansion. A safe blob bound is ||K_R||op<=||O||product_v||W_v||op<=||O||(1+qD^2)^r for interior dimension D^4. This is D^O(r), so truncation order becomes O(r log D+r+log(1/epsilon)); the algorithm is still joint polynomial in D and 1/epsilon for fixed r. The dimension-independent prefactor from the unsigned contraction class must not be transferred without this adjustment.

A simpler global-oracle fallback, supplied by root, is available when the centered base q_v<=q0/2. For a single-site observable with ||O||<=1 choose t=q0/2. Then

W_v +/-tK_v=C_v*(I+/-tO)C_v>=0,
||I-(W_v+/-tK_v)||_F/sqrt(d)<=q0,
Z_+/-=Z(1+/-t<O>).

Three norm estimates (base, plus, minus), with relative error O(epsilon t), recover <O> to additive error epsilon. For a product of r norm-one local observables, replace the r local Grams by W_v+sigma_v tK_v for all 2^r choices sigma. The exact signed finite difference divided by (2t)^rZ equals the product expectation, since the contraction is multilinear in those local substitutions. Norm-estimation errors need precision O(epsilon [t/(1+t)]^r). General fixed-support observables can be explicitly expanded into product bases at a D^O(r) physical-dimension cost. This fallback depends polynomially on the full N through its norm calls, whereas the anchored construction accesses only local data. Neither method is a relative guarantee for a potentially zero expectation.

## 14. A Gaussian random-PEPS corollary with an explicit dimension bound

This is a consequence of the general norm FPRAS in s08, rather than of the deterministic directional-cut primitive. Let d_v=D^(deg(v))<=d_max=D^4 be the local virtual dimension and let T_v be a p by d_v matrix with independent CN(0,1) entries. The physical dimension is p; it is distinct from the virtual dimension d_v. Boundary maps may instead be fixed isometric embeddings, as in the original boundary convention. Independence between vertices is unnecessary for the union bound, although it describes the usual independent local-map ensemble.

For any 0<delta<1, a sufficient uniform dimension is

p >= 128 q0^(-2) [2 d_max log 9 + log(2N/delta)],
q0=1/128.                                               (29)

With probability at least 1-delta, every Gaussian site's optimally centered Gram G_v=T_v*T_v satisfies q_min<=q0/2. Therefore these inputs lie in the high-effective-rank norm-FPRAS class. The normalized physical PEPS is unchanged by the local scalar centerings. Its original squared norm is the centered contraction multiplied by product_v c(G_v). For fixed q0, (29) is p=O(D^4+log(N/delta)), with a large explicit constant; it is a sufficient condition and not an asserted sharp threshold.

### Elementary concentration proof

For any fixed unit x in C^d, ||T x||^2 is the sum of p independent mean-one exponential random variables. Chernoff's bound gives, for 0<t<=1,

P(| ||T x||^2/p-1 |>t)<=2 exp(-p t^2/4).

Indeed the upper-tail exponent is p[t-log(1+t)]>=p t^2/4, and the lower-tail exponent is p[-t-log(1-t)]>=p t^2/2. A 1/4-net of the complex unit sphere has at most 9^(2d) points. For every Hermitian A, ||A||op is at most twice max_x |x*A x| on this net. Hence

P(||G/p-I||op>alpha)
 <=2 exp[2d log 9-p alpha^2/16].                          (30)

Take alpha=q0/2 and union bound over at most N sites. Already the constant 64 in place of 128 in (29) would suffice; (29) retains spare concentration. On this event, scalar centering at p has normalized Frobenius defect at most alpha, since ||G/p-I||_F/sqrt(d)<=||G/p-I||op. Minimization over all positive scalar centerings then gives q_min<=alpha, proving the assertion without a Marchenko--Pastur approximation or an asymptotic exchange of limits.

There is also an unsigned centering on this event. Set c=p(1+alpha). Then W=G/c<=I and

0<=I-W<= [2alpha/(1+alpha)] I,
q(W)<=2alpha/(1+alpha)<q0.

Thus even the PSD-hole convergence proof applies to the random inputs. Their defect tensors generally lack a fixed directional rank, so the supplied finite-phase moment primitive is still required for a uniform polynomial algorithm. Using this contraction centering permits the dimension-independent anchored observable bound in Section 3 for arbitrary fixed-support physical observables. Their explicitly supplied tensor entries and physical dimensions are charged.

### Input and precision costs

The random proposition above concerns an ideal continuous ensemble. The finite-bit algorithm concerns supplied rational local tensors; one must not silently identify these two interfaces. In particular the dense physical-map input contains O(N p D^4) complex entries, and constructing its Grams costs, naively, O(N p D^8) arithmetic operations. At p=O(D^4+log N), both are polynomial in N and D; neither is omitted from the overall algorithm cost. Multiplying the rational scalar centerings contributes bit length O(N) times their individual bit lengths, which is polynomial even when the unnormalized norm is exponentially small or large.

The Gaussian guarantee is robust to rational rounding. If every complex matrix entry changes by at most h<=q0/(128 d_v), then ||Delta T||op<=h sqrt(p d_v). On the event in (30), ||T||op<=2sqrt(p), and therefore

|| (T+Delta T)*(T+Delta T)-G ||op/p
 <=4h sqrt(d_v)+d_v h^2<q0/16.

Optimal centering of the rounded rational Gram consequently has q_min<9q0/16, leaving a fixed certification margin. Its certificate (27) is checked exactly from the rational entries, independently of the random-instance promise. On the same event, each entry has magnitude at most 2sqrt(p), so O(log p+log d_v) bits per entry suffice for this fixed-margin rounding, apart from fixed q0 constants.

If an algorithm is to approximate the original continuous-model physical state rather than the rounded model, a model-error budget must also be included. Taking

h<=min{q0/(128 d_v), epsilon_model/(64 N d_v)}

suffices with polynomially many additional bits. To see this, sigma_min(T)>=sqrt(p/2) on the event, so Delta T=F T with F=Delta T T^dagger and ||F||op<=2h sqrt(d_v). The product of these physical perturbations differs from identity in operator norm by at most exp(sum_v ||F_v||op)-1. Normalizing the nonzero global state changes it by at most twice this amount in Hilbert norm, and hence by at most that same Hilbert-norm bound in pure-state trace distance. With the displayed h this is less than epsilon_model/4. Every measurement distribution then changes in TV by at most epsilon_model/4. The induced squared-norm relative error is bounded by the same product-perturbation estimate. A finite random generator's own distributional error and tail handling are separate acquisition costs; no exact finite-bit sampler of a continuous Gaussian law is claimed.

The instance failure delta, the randomized contraction-oracle failure, and any generator/model error are distinct budgets. A rank-one physical projective outcome has Gram rank at most one and hence q_min^2>=1-1/d_v. Such outcomes generally leave this certified class, so (29) does not imply an unrestricted computational-basis Born sampler for random PEPS. The full sampler remains the explicitly stable measurement theorem of Sections 7, 9, and 13.

### Close primary comparisons and status

[Gonzalez-Garcia et al., Random insights into the complexity of two-dimensional tensor network calculations (2023)](https://arxiv.org/html/2307.11053v1) study random PEPS through a replicated statistical-mechanics mapping, large-D analysis, and numerics. Their introduction explicitly labels the arguments physical rather than rigorous proofs. Their prediction that generic norms and correlations are easy is therefore important prior context, but is not itself the finite-input FPRAS proved by the supplied norm route here.

[Chen et al., Sign problem in tensor network contraction, Section V.3 (2025 version)](https://arxiv.org/html/2404.19023v2) give an efficiently evaluable positive-sum representation through local balanced bipartite separability at physical dimension of order D^6 and conclude a BPP^NP approximate-counting bound. This is a different sufficient mechanism. The comparison p=O(D^4+log N) here uses high effective rank and the separate small-cluster sketch algorithm; it does not follow from positivity alone.

The strong-injectivity comparison in Section 10 has a sufficient perturbation tolerance shrinking with D in its displayed large-D bound. Combining that condition with Gaussian covariance fluctuations suggests a p of order D^6, but that inference is only a comparison of sufficient conditions, not a lower bound on that method or a priority claim. The existing sketch primitive and cluster-expansion framework are prior art. The exact combined theorem's priority remains UNKNOWN, and all proofs in this note are internally reconstructed consequences rather than external validation.
