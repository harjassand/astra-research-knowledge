# A dimension-uniform circuit-trace consequence and its boundary

Internal mathematical reconstruction, 11 October 2026, worker s03. This is a
consequence of `work/sol/s08_gaussian_moment.md`, with a new physical input
interface. The trace reduction and the complex-error accounting are closed
below. No full implementation, external proof validation, or priority
clearance is claimed. The underlying connected-log and random-contraction
primitives overlap established work; see Section 7.

The closed consequence is a classical relative approximation algorithm for
the normalized trace, maximally entangled return probability, and average
gate fidelity of a class of large-qudit circuits, with a commuting-projector
ground-space-counting corollary. It allows gates that change
some vectors maximally while remaining close to identity on average. It
requires that each qudit occur in at most two supplied gates. It does not
extend to unrestricted fixed-input circuit amplitudes or general quantum
Hamiltonian partition functions.

## 1. Exact supplied-input theorem

Supply N explicitly represented complex-rational unitary matrices U_v, each
acting on a set S_v of at most four d-dimensional qudits. Fix any ordering of
the gates. Every qudit belongs to at most two sets S_v. Idle qudits may be
deleted. Let n be the number of remaining qudits and

    U = product_v U_v,
    A = d^(-n) Tr U,
    q_v = ||I-U_v||_F / d^(|S_v|/2).

Assume q_v <= q=1/128 for every v. This is an exact checkable promise:
q_v^2 is a rational sum of squared entry magnitudes divided by d^|S_v|.
Unitary input can also be checked exactly by U_v* U_v=I.

There is a randomized algorithm which, given 0<epsilon<1 and 0<beta<1,
outputs a complex rational Ahat with

    P[ |Ahat-A| <= epsilon |A| ] >= 1-beta

in time polynomial jointly in N, d, the explicit input bit length,
1/epsilon, and log(1/beta). In particular, A is nonzero. The polynomial
degree is large and no practical-runtime bound is claimed.

The theorem in fact holds for arbitrary complex-rational local matrices in
place of the unitaries, with the same average-distance promise. Unitarity is
used for the physical corollaries, not the contraction argument.

The same algorithm gives relative approximations to

    K = |Tr U|^2 / d^(2n) = |A|^2,
    F_avg(U,I) = (d^n |A|^2 + 1)/(d^n+1).

Use the trace approximation with relative tolerance epsilon/4 for these
nonnegative quantities. These are respectively the normalized spectral form
factor / maximally entangled return probability and the Haar average gate
fidelity to identity. The fidelity identity is standard; a primary source is
[Nielsen 2002](https://arxiv.org/abs/quant-ph/0205035).

The theorem charges the acquisition of the matrices as explicit input. It
does not infer them from experimental observations, and it does not supply a
physical gate compiler. There is no additional PEPS physical-output-dimension
assumption because the interface is a circuit on the stated qudits.

## 2. Exact reduction to a Bell-edge network

Write D_v=I-U_v. Make one vertex for each supplied gate. A qudit occurring in
two gates becomes a wire joining their vertices. A qudit occurring in one
gate becomes a private leg of that gate. If two gates share m physical
qudits, combine their m parallel wires into a single edge of dimension

    d_e = d^m.

Each vertex has at most four incident edges, the sum of the wire
multiplicities at a vertex is at most four, and its matrix dimension before
tracing private legs is at most d^4. The grouped interaction graph is simple.

First trace each private leg with normalized trace. If b_v is the number of
private qudits at v, put

    B_v = d^(-b_v) Tr_private D_v.

Orient each grouped edge arbitrarily. At its terminal vertex, transpose B_v
on all the physical qudits belonging to this edge. Denote the resulting
partially transposed matrix by H_v. This is a transpose, not an adjoint. It
may destroy unitarity and positivity. Partial transpose preserves
Hermiticity, but H_v need not be Hermitian because I-U_v need not be
Hermitian. The complex version of the moment theorem imposes none of those
properties.

The normalized partial-trace Frobenius inequality gives

    ||B_v||_F <= d^(-b_v/2) ||D_v||_F,

and partial transpose preserves the Frobenius norm. Therefore

    ||H_v||_F / sqrt(product_{e incident v} d_e) <= q_v.    (1)

Let Omega be the product of normalized Bell states Phi_{d_e}, one on each
grouped edge. Then the exact identity is

    d^(-n) Tr(product_v U_v)
      = <Omega| tensor_v (I-H_v) |Omega>.                  (2)

Proof, including order and complex orientation: expand each local operator
in products of single-qudit matrix units. On a private qudit the trace is
Tr E_ij=1[i=j]. On a qudit joining two gates the only local factor is

    d^(-1) Tr(E_ij E_kl) = d^(-1) 1[j=k]1[l=i].

The Bell contraction of E_ij at one endpoint and the transpose E_lk at the
other gives exactly the same scalar. Matrix units on different qudits factor.
This proves (2) term by term, including arbitrary complex coefficients.
Grouping parallel wires preserves the identity because Phi_{d^m} is the
tensor product of m copies of Phi_d in the product basis.

An extra useful fact is that the normalized trace is independent of the
ordering of the gates under the at-most-two-occurrences condition. In the
same product-basis expansion, every qudit contributes a trace of either one
matrix or two matrices; Tr(XY)=Tr(YX). The gates themselves need not commute.
This fact is about the trace functional, not equality of the circuit
unitaries. No arbitrary quantum circuit can be parallelized by this argument.

For any subset T of gate vertices, apply the same identity with all gates
outside T replaced by identity. Thus all Taylor moments needed by the
connected-log algorithm have the same fixed local H_v representation. There
is no subset-dependent acquisition step.

## 3. Dimension-independent complex moments

For T subset V define

    t_T = d^(-n) Tr(product_{v in T} D_v),   t_empty=1,

where gates retain the supplied order. Equivalently, this is the Bell moment
with H_v at T and identities elsewhere. It factors over the connected
components of the induced interaction graph.

For a moment on T, trace all exterior Bell halves. If E_T is the set of
internal grouped edges, the reduced local arrays h_v satisfy

    ||h_v||_F <= q_v sqrt(product_{e in E_T, e incident v} d_e).

Use the operator index (ket,bra) of dimension Q_e=d_e^2 on edge e. With the
same index ordering at both endpoints,

    t_T = (product_{e in E_T} d_e^(-1))
          sum_edge_indices product_{v in T} h_v[indices].

Graph Finner / Holder, with exponent two at every vertex, gives

    |t_T| <= product_{v in T} q_v <= q^|T|.                (3)

For each edge e, draw Q_e independent coordinates uniformly from
{1,-1,i,-i}. One endpoint receives the vector xi_e and the other receives
its complex conjugate. Let L_v be the multilinear evaluation of h_v on its
incident probe vectors, and set

    Y_T = (product_{e in E_T} d_e^(-1)) product_{v in T} L_v.

Then EY_T=t_T exactly, using E xi_a conjugate(xi_b)=1[a=b]. The elementary
four-phase fourth-moment inequality, followed by graph Finner over the
independent edge vectors, yields

    E|Y_T|^2 <= 2^|E_T| product_{v in T} q_v^2
              <= (4q^2)^|T| <= 1.                        (4)

The proof of this inequality is given in Sections 3--4 of s08 and uses no
positivity or realness of the arrays. The local fourth-moment bound is
E|L_v|^4 <= 2^deg(v) ||h_v||_F^4. All edge-dimension factors cancel in (4).
This cancellation is the reason the growing local dimension is affordable.

A sample is an exact complex rational number. Evaluating a local array
requires at most O(d^8) rational operations because the total number of
original physical legs at a gate is at most four. The grouped probe vectors
have length at most d^8, so generating all probes costs O(|T|d^8) fair bits
and rational operations as well. Grouping does not cause a d^(32) local
tensor cost. The sample uses no continuous random numbers.

Estimate the real and imaginary components separately by median of means.
For requested complex absolute error delta, use component tolerance delta/2,

    B = ceil(32/delta^2) samples per block,

and an odd number J >= 2 log_2(2M/beta)+3 of blocks, where M bounds the total
number of moment calls. Chebyshev gives component block-failure probability
at most 1/8; the median tail and a union bound give simultaneous complex
errors at most delta with probability at least 1-beta. Clip each component
to [-q^|T|,q^|T|], which contains the true component by (3).

## 4. Zero-free log, complex sensitivity, and explicit costs

Define for S subset V

    Z_S(z) = sum_{T subset S} (-z)^|T| t_T.

Then Z_V(1)=A. The absolute bound (3), component factorization, and maximum
interaction degree four are exactly the hypotheses of the deletion proof
in s08 Section 5. No step there uses t_T >= 0. For |z|<=2, it gives

    Z_S(z) != 0,
    |Z_S(z)| >= (4/5)^|S|,
    |log Z_S(z)| <= |S| log(5/4),                          (5)

for the analytic log equal to zero at z=0. In particular,

    |A| >= (4/5)^N,
    |log A - sum_{k=1}^m [z^k]log Z_V(z)|
      <= N log(5/4) 2^(-m).                              (6)

The connected-support Mobius formula is valid for complex coefficients:

    c_{S,k} = sum_{R subset S} (-1)^(|S|-|R|)
                                 [z^k]log Z_R(z).

It vanishes if S is disconnected or |S|>k. Enumerating connected |S|<=m
and estimating all moments on their subsets requires at most

    M <= N m 32^m

calls. On simultaneous moment error delta, the polynomial error on |z|<=2
is at most delta 3^m, and the relative error is at most
alpha=delta(15/4)^m. For alpha<=1/2, the analytic log error is at most
2delta(15/4)^m. Cauchy on the radius-two circle, Mobius summation, and the
at-most-Nm16^m connected supports imply total truncated-log error at most

    2 delta N m^2 120^m.                                 (7)

This analytic argument applies to complex perturbations. It avoids a hidden
m^m sensitivity factor from enumerating formal-log products.

Choose

    m = ceil(log_2(64N/epsilon)),
    delta = epsilon/(64 N m^2 120^m).

Compute each log series with exact rational complex arithmetic using

    g_k = a_k - (1/k) sum_{j=1}^{k-1} j g_j a_{k-j}

for log(1+sum a_j z^j)=sum g_j z^j, and combine the connected coefficients.
By (6)--(7), the resulting Lhat has complex absolute error at most
epsilon/32+epsilon/256 on the joint successful event.

Before exponentiation, clip Re Lhat and Im Lhat separately to [-N,N]. The
true analytic log has both components in this interval by (5), so coordinate
clipping cannot increase the complex Euclidean error. This caps output size
and elementary-function cost on every random tape, including failed ones.

For a+ib equal to the clipped estimate, approximate exp(a) to relative error
epsilon/64, and cos b and sin b each to absolute error epsilon/128. All three
arguments have magnitude at most N. Rational Taylor evaluation after range
reduction for exp, and rational Taylor evaluation for sin/cos, have polynomial
bit cost in N, input precision, and log(1/epsilon). Their combined complex
relative error is less than epsilon/32. Together with (6)--(7) and
|exp(w)-1|<=exp(|w|)-1, this proves the theorem's final epsilon budget.

An explicit arithmetic-operation bound, up to absolute constants, is

    O( N m 32^m delta^(-2) m d^8 log(Nm32^m/beta)
         + N m 64^m poly(m) ).                            (8)

Every exponential base in m is numerical and independent of d. As
m=O(log(N/epsilon)), (8) is jointly polynomial. This is a broad asymptotic
capability, with an enormous polynomial exponent.

Finite-bit accounting: let L be total input bit length and Q_0 the product
of all input denominators, so log Q_0<=L. Partial traces and Bell
normalizations introduce powers d^O(m); a moment sample denominator divides
Q_0^m d^O(m). Means add the factor B, component medians select existing
means, and clipping adds the rational endpoints 128^(-|T|). Thus raw-moment
common denominators have bit length O(mL+m log d+log B+m). Log-series
coefficients through degree m are rational polynomials of degree at most m
in these numbers with factorial/lcm divisors of polynomial bit length.
Their bit length is bounded by a polynomial in m,L,log d,log B,log M.
Summing all connected coefficients adds only log M to numerator length.
Input checking and the initial private-leg partial traces are polynomial in
the explicit local matrix sizes and L. Consequently (8) lifts to polynomial
bit complexity, not only an arithmetic-RAM statement.

## 5. What new family and physical capability are actually covered

Let P_v be any explicitly supplied rational orthogonal projector on the
gate's full d^|S_v|-dimensional space, of rank r_v, and take

    U_v = I-2P_v.

This is an exact rational unitary reflection and

    ||I-U_v||op = 2,
    q_v = 2 sqrt(r_v/d^|S_v|).

Thus every choice of entangled projector subspaces with

    r_v <= d^|S_v| / 65536

is admitted. A rank-one reflection on four qudits is admitted already at
d>=16. More generally, a gate may implement any unitary on a subspace of
this rank and identity on its orthogonal complement. This extends the
operation condition beyond uniformly small operator-norm errors. It does
not show that these inputs are hard for all previous algorithms.

The return-probability interpretation is exact. Prepare n normalized Bell
pairs between the circuit system and a reference, apply U on the system,
and project back onto the initial product of Bell pairs. The amplitude is
A and the probability is K=|A|^2. Running the theorem at epsilon/4 gives

    | |Ahat|^2/K - 1| <= 2(epsilon/4)+(epsilon/4)^2 < epsilon.

The positive affine formula for F_avg then preserves relative epsilon
accuracy. The integer d^n has n log d bits, which is polynomial in the
input size. These are efficiently computed physical quantities, even
though an arbitrary computational-basis output distribution is outside the
claim.

There is no assumption that the global return probability is constant or
inverse polynomial. For disjoint reflection gates rejecting a fixed local
fraction f<=1/65536, A=(1-2f)^N and K=(1-2f)^(2N), exponentially small in N.
The theorem's relative estimate does not pay the inverse of this global
probability. Disjoint gates are an easy diagnostic family; the theorem
also allows arbitrary interaction graphs of degree at most four.

### 5.1 Commuting quantum constraints at zero temperature

Supply explicitly represented complex-rational orthogonal projectors P_v,
each on at most four d-dimensional qudits. Assume they commute pairwise,
every qudit belongs to at most two supplied supports, and

    rank(P_v)/d^|S_v| <= 1/16384.                         (10)

There is a joint-poly(N,d,input bits,1/epsilon,log(1/beta)) randomized
relative approximation to the exact integer ground-space dimension

    g_0 = dim ker(sum_v P_v).

In particular, g_0>0. This is a supplied-input counting result, not an
algorithm for sampling a uniformly random quantum ground state.

Proof: commuting orthogonal projectors give the exact ground-space
projector

    P_0 = product_v (I-P_v),
    d^(-n) g_0 = d^(-n) Tr product_v (I-P_v).

Apply the arbitrary-matrix version of the trace theorem to the local
weights I-P_v. Its normalized Frobenius defects are
sqrt(rank(P_v)/d^|S_v|), so (10) is precisely the q<=1/128 promise.
The same finite-phase moments, analytic error bound, and cost (8) apply.
For a positive estimate on every random tape, take the real part of the
complex output and clip it to [(4/5)^N,1]. The true normalized g_0 lies
in this interval by the zero-free lower bound and 0<=P_0<=I. Clipping
cannot increase its real absolute error. Multiply by the exact integer
d^n; its bit length n log d is polynomial. This preserves relative error.

All extra assumptions are checkable. Verify P_v*=P_v and P_v^2=P_v
exactly. The rank in (10) equals Tr P_v. Check each overlapping pair's
commutator by embedding its operators on their union, which contains at
most eight qudits. The fixed exponent makes this cost polynomial in d
and the input length. Nonoverlapping pairs commute automatically. Thus
pairwise commutation is not an uncharged acquisition oracle.

This is an exact zero-temperature statement: no beta-to-infinity limit,
spectral gap, or inclusion-exclusion stability hypothesis is used.
Without commutation, the displayed product is generally not the
ground-space projector, so that conclusion is not licensed.

Counting commuting ground spaces in a local-lemma regime is prior art.
[Mann--Waite 2025](https://arxiv.org/html/2512.10134v1), Theorem 3,
assumes small relative projector ranks and exp(O(cluster size)) evaluation
of intersection weights; Corollary 2 fixes d,k,Delta and evaluates them
by diagonalizing the cluster support. The potentially distinct scope of
the present corollary is its explicit joint polynomial dependence on a
growing d, under the additional at-most-two-occurrences restriction and
the concrete stochastic contraction proof. This is not a dominance or
priority claim over their general overlap class, rank threshold, or
deterministic algorithm.

## 6. Exact obstructions to two tempting overextensions

### 6.1 Fixed-input amplitudes need a different hypothesis

For one d-dimensional qudit, let U swap |0> and |1> and act as identity on
the other d-2 states. Then

    ||I-U||_F = 2,
    q=2/sqrt(d),
    <0|U|0> = 0.

For d>=65536 the same average-distance promise is satisfied, yet the
fixed-input amplitude is zero. The scalar interpolation from I to U even
has a zero at the endpoint. A general fixed-input zero-free theorem under
the present hypothesis is therefore false, already for one gate.

More strongly, with unrestricted wire reuse, take any rational two-qubit
circuit and embed each gate as its 4-dimensional code-subspace unitary on two d-level
qudits, and act as identity on the complement. The normalized Frobenius
defect is at most 4/d, so d>=512 satisfies the local promise for every such
gate. An input inside the qubit code remains there and undergoes the
original quantum computation. Average local closeness by itself thus
provides no classical simulation mechanism for selected inputs. This is
an exact embedding, not a new complexity lower bound.

### 6.2 A three-use wire defeats the naive phase sketch

For a single physical wire appearing in three operator factors, independently
draw phase vectors x,y,z of length d and consider the direct cyclic sketch
for the normalized trace of three defects H_1=H_2=H_3=qI:

    Y = (q^3/d) (x* y)(y* z)(z* x).

It is unbiased: EY=q^3. Put a=x* y. Conditioning on x,y and using the exact
four-phase fourth-moment identity gives

    E_z |y* z|^2 |z* x|^2 = d^2 + |a|^2 - d.

As E|a|^2=d and E|a|^4=2d^2-d,

    E|Y|^2 = q^6(d+1-1/d),
    Var_complex(Y) = q^6(d-1/d).                          (9)

The dimension cancellation in (4) is lost. One can connect m disjoint
three-gate groups by additional two-use wires so the gate interaction
graph is connected and each gate has arity at most three. With all local
defects qI, the cyclic sketch factorizes over physical wires and has

    E|Y_cluster|^2
      = q^(6m) (d+1-1/d)^m (2-1/d)^(m-1).

Consequently this direct sketch does not give exp(O(cluster size)) variance
with a dimension-independent base. For clusters of logarithmic size its
bound can be d^Theta(log N).

This is a failure of the specified sketch, not an impossibility theorem
for algorithms on higher-use circuits. The example operators are themselves
easy to contract; a single length-three wire can be multiplied exactly in
O(d^3). Improved contraction, structural resummation, or a different oracle
could remove this particular variance. No general replacement is proved
here. Repeated interactions in exp(-beta sum h_e) cause exactly this extra
wire reuse, so the read-two trace theorem cannot simply be asserted for
arbitrary noncommuting quantum partition functions.

## 7. Closest primary comparisons and final status

[Mann--Minko 2024](https://arxiv.org/html/2306.08974v2), Theorem 11,
already gives cluster algorithms for product-input circuit amplitudes with
local operator-norm-close gates. Its Lemma 14 computes cluster weights by
matrix-vector multiplication at fixed local dimension. Our closed statement
uses a normalized trace, restricts wire reuse, permits the reflections above,
and explicitly removes the local-dimension dependence from the exponent of
the cluster size. It therefore is not a dominance claim over that theorem.

[Mann--Helmuth 2021](https://arxiv.org/html/2004.11568v2) proves high-temperature
quantum partition-function algorithms; its introduction explicitly makes the
polynomial degree depend on log d, and its polymer-weight calculation uses
the Hilbert space of a cluster. The present proof does not solve that more
general dimension bottleneck.

[Heddes--Nunes--Givargis--Nicolau 2026](https://arxiv.org/html/2603.07387v1)
already supplies an unbiased arbitrary cyclic tensor contraction sketch with
variance exponential in the number of edges times local Frobenius norms.
This overlaps the moment primitive. The useful combination here is the
read-two trace reduction, small normalized-Frobenius moments, and stable
zero-free connected log. No claim of first randomized contraction is made.

Status: the read-two complex trace, its physical scalar corollaries, and
the commuting ground-space corollary are
internally reconstructed consequences of s08, with complete interface,
variance, error, and finite-bit accounting. Historical novelty is unresolved.
The stronger unrestricted circuit / noncommuting partition-function extension
remains open; (9) identifies a concrete failed mechanism, not a lower bound.
The separate filtered-Bell-state preparation result from root/s09/s10 is not
needed for this consequence and is not silently assumed to provide an
arbitrary circuit simulator.
