# Finite-phase connected moments for a tensor-network norm FPRAS

Internal reconstruction, 11 October 2026. Author: worker s03, following root's
random-edge-probe invention and rare-defect deletion argument. The name of this
file reflects the initial Gaussian version; the theorem below uses only four
finite phases. Status: complete internal proof draft, not external validation.
Priority and comparison with prior randomized contraction methods remain open.

The strongest physical statement is the centered-positive-weight corollary in
Section 9: arbitrary PSD local Grams with effective rank at least
(1-1/128^2) times their virtual dimension admit the same FPRAS after an exact
rational scalar normalization. Sections 1--8 prove its simpler PSD-defect
subclass first, then Section 9 checks every changed assumption explicitly.

## 1. Claim, exact interface, and actual improvement

Let G be a simple graph of maximum degree four, with N vertices. Each edge
consists of two D-dimensional systems in the normalized Bell state
Phi_D=D^(-1/2) sum_i |i,i>. Write Omega for their tensor product. Supply explicit
rational Hermitian local matrices H_v, acting on the actual incident legs, with

    0 <= H_v <= I,       q_v := ||H_v||_F / D^(deg_G(v)/2) <= q=1/128.

Identity boundary tensors are allowed by H_v=0. In particular, on a square grid
one may supply arbitrary D^4-by-D^4 interior defects and identity boundaries.
No tensor-product factorization, separable decomposition, injectivity, or
positive lower bound on I-H_v is required. Let

    Z = <Omega| tensor_v (I-H_v) |Omega>.

There is a randomized algorithm which, given 0<epsilon<1 and 0<beta<1, outputs
a positive rational Zhat satisfying

    P[ |Zhat/Z - 1| <= epsilon ] >= 1-beta

in time polynomial jointly in N, D, the explicit input bit length, 1/epsilon,
and log(1/beta). Also Z>0. This is a norm FPRAS for the displayed supplied-input
class. It is not a sampler for general physical measurement outcomes.

The earlier rare-defect algorithm in work/root/rare_defect_theorem.txt evaluated
connected moments exactly using an acquired directional 1|3 factorization.
The finite-phase estimator below removes that structural restriction. The
polynomial has a large exponent and no practical-runtime claim is made.

The proof has three load-bearing parts: small normalized Hilbert--Schmidt
defects give a uniform zero-free disk; random edge probes estimate an arbitrary
small connected contraction with dimension-independent absolute variance; and
analytic stability controls the connected log coefficients without a hidden
m^m or D^m cost.

## 2. Reduced tensors and moment normalization

For U subset V define

    t_U = <Omega| (tensor_{v in U} H_v) tensor I_{V\U} |Omega>,   t_empty=1.

All t_U are real and nonnegative. Their values multiply across the connected
components of the induced graph G[U], because identity sites do not join their
incident edges.

Write r_v=deg_{G[U]}(v), d_v=deg_G(v), and e=|E(G[U])|. Tracing the exterior
Bell halves gives the local reduced matrix

    h_{v,U} = D^(-(d_v-r_v)) Tr_exterior H_v.

The elementary partial-trace bound ||Tr_B X||_F <= sqrt(dim B)||X||_F yields

    ||h_{v,U}||_F <= q_v D^(r_v/2).                         (1)

Use the pair (ket,bra) as an operator index a_e in [Q], Q=D^2, on each internal
edge. Its ordering is the same at both endpoints. The contraction is

    t_U = D^(-e) sum_{a in [Q]^E} product_{v in U} h_{v,U}[a_inc(v)]. (2)

This is a bilinear contraction of tensor entries; no extra conjugation of one
endpoint tensor is introduced. The matrix entries may be complex. Positivity
of H_v supplies t_U>=0, rather than entrywise positivity.

Graph Holder/Finner on the counting measures of the edge indices, with exponent
two at every vertex, gives

    0 <= t_U <= D^(-e) product_v ||h_{v,U}||_F <= product_v q_v. (3)

Every edge variable occurs in exactly two local arrays, so the reciprocal
exponents sum to one. This is an established inequality, not a new primitive.

## 3. An exact finite-phase unbiased estimator

Orient the internal edges arbitrarily. For each edge e and each coordinate
a in [Q], independently draw

    xi_{e,a} uniformly from {1,-1,i,-i}.

An endpoint receives xi_e if the edge points out of it and conjugate(xi_e)
if the edge points into it. Define the local multilinear polynomial

    L_v = sum_{a_inc(v)} h_{v,U}[a_inc(v)]
                         product_{e incident v} xi_{e,a_e}^{(v)},
    Y_U = D^(-e) product_{v in U} L_v.                      (4)

Here xi^(v) denotes the prescribed vector or its conjugate. For r_v=0, L_v is
the scalar h_v. As E xi_a conjugate(xi_b)=1[a=b], independence over edges
proves E Y_U=t_U exactly by expanding (4). Real(Y_U) is therefore a real
unbiased estimator. The imaginary part has zero mean.

The global normalization D^(-e), rather than a local D^(-r_v/2), avoids
irrational square roots for odd local degrees. With rational input, Y_U is a
complex rational number computed exactly using finitely many fair random bits.

## 4. Fourth moments and dimension-independent variance

For deterministic complex numbers c_j and independent four-phase xi_j,

    E |sum_j c_j xi_j|^4
      = 2(sum_j |c_j|^2)^2 - sum_j |c_j|^4
      <= 2(sum_j |c_j|^2)^2.                               (5)

This follows by expanding: E xi=E xi^2=0 and E|xi|^2=E|xi|^4=1. Only the two
matching pairings survive, with their common all-equal case counted once.

For any r-way complex array A and independent four-phase edge vectors, its
multilinear evaluation L_A satisfies

    E|L_A|^2 = ||A||_F^2,
    E|L_A|^4 <= 2^r ||A||_F^4.                             (6)

Proof of the fourth bound is induction on r. Condition on the first r-1 vectors
and write L_A=sum_j xi_j L_{A_j}. Equation (5) bounds the conditional fourth
moment by 2(sum_j|L_{A_j}|^2)^2. For each pair of slices, Cauchy--Schwarz and the
induction hypothesis give

    E |L_{A_i}|^2 |L_{A_j}|^2
      <= sqrt(E|L_{A_i}|^4 E|L_{A_j}|^4)
      <= 2^(r-1) ||A_i||_F^2 ||A_j||_F^2.

Summing proves (6). A conjugated input vector has the same law, so all endpoint
orientations obey the same bound. No independence between the L_v is claimed.

Apply graph Finner once more, now to the nonnegative functions |L_v|^2 of the
independent full edge-vector random variables. Each vector occurs at its two
endpoints, again with exponent two. Equations (1) and (6) give

    E|Y_U|^2
      <= D^(-2e) product_v (E|L_v|^4)^(1/2)
      <= D^(-2e) 2^(sum_v r_v/2) product_v ||h_v||_F^2
      <= 2^e product_v q_v^2
      <= (4q^2)^|U| <= 1.                                  (7)

The bound e<=2|U| uses maximum degree four. Thus Var(Re Y_U)<=1, independently
of D and of the topology of the induced cluster. The stronger bound in (7)
can improve constants, but is unnecessary for polynomial complexity.

For an absolute target delta, a mean of B=ceil(8/delta^2) independent samples
has failure probability at most 1/8 by Chebyshev. The median of an odd number
J>=2 log_2(M/beta)+3 of such block means has failure probability at most beta/M:
the union bound over bad block subsets is at most
2^J (1/8)^(J/2)=2^(-J/2). Clip the resulting rational estimate to
[0,q^|U|]. Since the true value lies there, clipping cannot increase its error.
Call the result that_U. Then

    P[ |that_U-t_U| > delta ] <= beta/M.                    (8)

One sample costs O(|U| D^8) elementary rational operations: a vertex of internal
degree r uses Q^r=D^(2r) terms, and r<=4. It consumes exactly 2Qe random bits,
at most 4|U|D^2. Computing exterior partial traces from explicit local matrices
also costs polynomial time, conservatively O(|U|D^8).

## 5. Zero-free disk, reconstructed independently of factorization

For S subset V put Z_S(z)=sum_{U subset S} (-z)^|U| t_U. Component factorization
and (3) give the polymer recurrence, for any v in S,

    Z_S = Z_{S\{v}} + sum_{gamma subset S connected, v in gamma}
                        (-z)^|gamma| t_gamma Z_{S\N[gamma]}. (9)

There are at most 16^(k-1) connected k-vertex sets containing a fixed vertex.
A rooted spanning tree can be encoded by a rooted plane tree (at most 4^(k-1)
possibilities) and a neighbor choice for each tree edge (at most 4^(k-1)).

The following deletion-ratio statement holds simultaneously for all S,v and
all |z|<=2:

    Z_S(z) != 0,
    |Z_S(z)/Z_{S\{v}}(z)-1| <= r=1/5.                    (10)

Induct on |S|. A term in (9), after division by Z_{S\{v}}, deletes at most
5|gamma|-1 further vertices. The induction hypothesis bounds its ratio by
(1-r)^(-5|gamma|+1). Summing the geometric series bounds the deviation by

    [2q(1-r)^(-4)] / [1-16*2q(1-r)^(-5)]
      = 0.160907... < 1/5,  q=1/128.                       (11)

The geometric-series denominator is positive. This proves (10). Consequently

    |Z_S(z)| >= (4/5)^|S|,                                (12)
    L_S(z)=log Z_S(z), L_S(0)=0 is analytic for |z|<=2,
    |L_S(z)| <= |S| log(5/4).                              (13)

The analytic logarithm is the sum of the logs of successive deletion ratios;
|log(1+u)|<=-log(1-|u|). Compactness gives a slightly larger zero-free open
neighborhood, so Cauchy's theorem applies on the radius-two circle. Let
ell_k=[z^k]L_V(z). Then

    |L_V(1)-sum_{k=1}^m ell_k| <= N log(5/4) 2^(-m).        (14)

Along z in [0,1] the actual contraction is continuous and cannot cross zero;
Z_V(0)=1. Hence Z=Z_V(1)>0 and L_V(1) is its real logarithm. Neither (9)--(14)
uses any local Schmidt-rank or separability assumption.

## 6. Connected coefficients and stable use of noisy moments

Define

    c_{S,k}=sum_{T subset S} (-1)^(|S|-|T|) [z^k]L_T(z).     (15)

Mobius inversion gives ell_k=sum_{S subset V} c_{S,k}. A disconnected S makes
this coefficient zero because log Z_T is a sum over the components and the
alternating sum annihilates every term missing one component. Also c_{S,k}=0
for |S|>k: a formal log term of z-degree k uses nonempty subsets whose total
size is k and whose union therefore has size at most k. The alternating sum
annihilates it unless that union equals S. Thus only connected |S|<=k matter.

For each connected S of size at most m, estimate every nonempty t_U with U
subset S using (8); t_empty is exactly one. Duplicates across different S may
be recomputed. A bound on the total number of calls is

    M <= N m 32^m.                                        (16)

On the joint event that every raw moment error is at most delta, construct
that_Z_T(z)=sum_{U subset T} (-z)^|U| that_t_U for every T subset S. For |z|<=2,

    |that_Z_T(z)-Z_T(z)| <= delta sum_{U subset T} 2^|U|
                              <= delta 3^m.               (17)

Combining (12) and (17) yields

    |(that_Z_T-Z_T)/Z_T| <= delta (15/4)^m =: alpha.         (18)

If alpha<=1/2 then that_Z_T has no zero on the radius-two disk, its logarithm
with value zero at the origin is well-defined, and

    |log that_Z_T-log Z_T| <= 2 delta (15/4)^m.             (19)

This bound applies even though the estimates no longer exactly factor across
disconnected components. The algorithm only sums the connected true supports;
it approximates each corresponding coefficient separately. It does not
assert that estimated disconnected coefficients vanish.

By Cauchy on radius two, the error in the order-k log coefficient is at most
2 delta (15/4)^m 2^(-k). Mobius summation over T subset S multiplies by at most
2^m, so each c_{S,k} error is at most 2 delta (15/2)^m. There are at most
N m 16^m connected sets through size m and at most m coefficient orders.
Therefore the error in the truncated logarithm is at most

    2 delta N m^2 120^m.                                  (20)

The use of analytic stability is essential: a naive count of ordered products
in the formal log expansion can introduce an unjustified m^m estimate. Here
every exponential base is a fixed numerical constant.

## 7. Complete algorithm, success probability, and cost

Choose

    m = ceil(log_2(64 N/epsilon)),
    delta = epsilon / (64 N m^2 120^m),
    M_bound = N m 32^m.

Use M_bound in the median-of-means confidence budget. Enumerate connected S
through size m; estimate all U subset S; build each that_Z_T, and compute its
log series through degree m. This can be done entirely by rational arithmetic:
if A(z)=1+sum a_j z^j and G(z)=log A(z)=sum g_j z^j, then

    g_k = a_k - (1/k) sum_{j=1}^{k-1} j g_j a_{k-j}.        (21)

Use (15) for the connected coefficients and form
Lhat=sum_{k=1}^m sum_{S connected, |S|<=k} that_c_{S,k}.

Before exponentiation, clip Lhat to the rational interval [-N,0]. The true
log Z lies in this interval, since (13) gives log Z>=-N log(5/4)>-N and
0<=tensor_v(I-H_v)<=I gives Z<=1. Clipping cannot increase its additive error.
This also bounds the output magnitude and exponential-evaluation cost on the
failed-estimation event, so the algorithm has polynomial runtime on every
random tape, rather than merely on its successful tapes.

The joint raw-moment event holds with probability at least 1-beta by (8) and
(16). On it, alpha<=1/2; (20) is at most epsilon/32 and (14) is less than
epsilon/256. Approximate exp(Lhat) by a positive rational to relative error
epsilon/16. These error budgets imply |Zhat/Z-1|<=epsilon for 0<epsilon<1.

There are polynomially many samples:

    number <= M_bound ceil(8/delta^2) O(log(M_bound/beta)).

Every sample uses O(mD^8) rational operations. Naively assembling every subset
polynomial costs 3^m poly(m) per connected S; log-series operations and Mobius
sums cost at most 4^m poly(m). Thus a safe total arithmetic bound is

    O( N m 32^m delta^(-2) mD^8 log(Nm32^m/beta)
       + N m 64^m poly(m) ).                              (22)

Substituting m=O(log(N/epsilon)) makes (22) polynomial jointly in N,D,1/epsilon
and log(1/beta). The enormous exponent is explicitly not a claim of practicality.
The improvement is the absence of D^m, D^(sqrt(m)), or m^m in any cost.

For finite-bit accounting, take the supplied rationals as exact. Partial traces
are rational sums and division by powers of D. Each phase equals a Gaussian
integer, so each Y_U is a finite rational expression with at most m local
factors, O(mD^8) summands, and denominator contributions O(m log D) in addition
to the input denominators. Common-denominator or fraction-free arithmetic
bounds all bit lengths by a polynomial in the total input bit length, m,
log D, and log(number of samples). Block averaging adds only polynomially
many denominator bits; medians and clipping are exact rational comparisons.
Equation (21) and finite Mobius sums likewise have polynomial bit growth.
This establishes polynomial bit cost, not just unit-cost arithmetic time.

A more explicit denominator bound is available. Let L be the total binary
length of the exact rational local input, and let Q0 be the product of all
input denominators, so log_2 Q0<=L. Every reduced local entry has denominator
dividing Q0 D^4. For |U|<=m every sample component therefore has denominator
dividing Q0^m D^(6m). Block means add the common integer factor B; medians
select an existing mean; clipping adds at most 128^m. Hence all raw estimates
can share a denominator of bit length O(mL+m log D+log B+m). Log-series
coefficients through order m are polynomials of degree at most m in those
estimates with integer coefficients and divisors at most lcm(1,...,m).
Their denominator and numerator bit lengths are bounded by
O(m^2 L+m^2 log D+m log B+m^2+log M), up to harmless polynomial factors for
input magnitudes. This is polynomial since log B=O(log(1/delta)).

Input checking is also charged. Check Hermiticity and rational PSD of H_v and
I-H_v, and compare sum of squared entry magnitudes with q^2 D^deg(v). Standard
exact symmetric elimination/LDL with zero-pivot handling has polynomial bit
complexity in the explicit matrix size and input length. The displayed norm
promise is therefore checkable; it is not an uncharged oracle. If the input
is a PEPS map C_v rather than its Gram W_v, first compute W_v=C_v* C_v, set
H_v=I-W_v, and run these checks; local scalar rescaling must be accounted in
the final norm. Acquiring any such representation from physical data remains
a different task.

By (13), |log Z|<=N log(5/4), so representing the possibly exponentially small
answer requires only O(N+log(1/epsilon)) magnitude/precision bits. A standard
range-reduced rational exponential achieves the final accuracy in polynomial
bit complexity.

## 8. Scope, examples, and open comparison gates

The method permits rank-deficient W_v=I-H_v: for any rank-one projector H_v on
the full four-leg space, q_v=D^-2, so D>=12 suffices, even if H_v is entangled
across every nontrivial local split. Such a W_v has exact zero eigenvalues and
||I-W_v||op=1. The claim therefore covers a class beyond uniform operator-norm
closeness to identity or strictly positive local singular-value assumptions.

For a rational physical realization choose any rational orthogonal projector
H_v and C_v=I-H_v; then C_v* C_v=I-H_v exactly. The phase theorem also covers
generic arbitrary dense PSD defects of sufficiently small normalized HS norm.
This comparison is about assumptions, not evidence that a particular example
is hard for every previous method.

What is obtained: relative approximation of the global norm for an explicit
checkable local input class, uniformly in bond dimension. Signed and complex
samples are allowed; controlled variance is supplied by (7), not by positivity
alone. The FPRAS does not require a global Gibbs mixing theorem or label sum.

What is not obtained: an FPRAS for arbitrary positive tensor networks; an
ordinary Born sampler for unrestricted physical fine measurements; learning
unknown tensors; an efficient physical preparation algorithm; or an externally
validated or historically novel result. Arbitrary measurement conditioning can
destroy the small-defect bound. Insertion/anchoring extensions require separate
proof and are being developed by another worker.

Prior ingredients requiring citation include Finner's graph Holder inequality,
random isotropic trace/contraction probes, fourth-moment/hypercontractive
bounds, median-of-means, polymer zero-free expansions, and connected-support
enumeration. The exact combination and operational class must be compared
against strongest primary literature before any priority claim.

## 9. Stronger physical scope: centered PSD weights and effective rank

The PSD assumption on the *defect* H is dispensable. Equations (1), (2), the
absolute version of (3), component factorization, the phase moment calculation,
and the deletion induction apply to arbitrary complex arrays H with normalized
Frobenius norm at most q. For Hermitian H the moments are real; replace the
moment clipping interval by [-q^|U|,q^|U|]. If W=I-H is PSD, its Bell contraction
is a physical norm and remains real and positive by the zero-free argument.
It need not be <=1. Clip the approximate logarithm to [-N,N], which contains
the true log by (13); all earlier runtime and relative-error arguments hold.

Thus the physical norm theorem extends to arbitrary rational PSD W_v obeying

    ||I-W_v||_F / sqrt(n_v) <= q,  n_v=D^deg_G(v).           (23)

This allows exact zero eigenvalues and eigenvalues as large as 1+q sqrt(n_v).
The condition controls average squared local spectral distortion, rather than
the worst local eigenvalue. For example, W=I+lambda P for a rank-r projector
obeys (23) whenever lambda sqrt(r/n_v)<=q. For rank one, lambda may grow as
qD^2 on an interior square-grid site. Norm contraction therefore covers local
spectral spikes which no uniform O(q) operator-norm perturbation allows.

Local positive scalar normalization can be optimized explicitly. Given nonzero
PSD W, write T1=Tr W and T2=Tr W^2. The scalar

    c=T2/T1

minimizes ||I-W/c||_F^2/n among all c>0. Its exact minimum is

    q_min^2=1 - T1^2/(n T2).                               (24)

Both c and q_min^2 are rational and computable from the input. Apply the
theorem to W_v/c_v, and multiply the output by product_v c_v to recover the
original norm. Consequently a checkable sufficient condition is

    r_eff(W_v):=(Tr W_v)^2/Tr W_v^2 >= (1-q^2)n_v.          (25)

This scalar optimization is elementary; it is a useful exact input interface,
not a claimed new spectral inequality. It also exposes a fundamental scope
limit. Cauchy--Schwarz on the nonzero eigenvalues gives r_eff(W)<=rank W.
Thus every admissible W has rank at least (1-q^2)n. If W=C* C for a local
physical PEPS map C into dimension p, then p>=rank W. At an interior vertex
p>=(1-q^2)D^4 is necessary. Fixed-small physical dimension at growing D is
therefore excluded, even with scalar rescaling or invertible local gauges.
The norm theorem is consequential as a broad explicit high-rank input class;
it is not a solution to low-physical-dimension PEPS contraction.

For completely general complex H, estimate real and imaginary moment parts
separately with the same variance bound, reduce their tolerances by a factor
two, and use a union confidence budget. The logarithm is then complex but
bounded by (13), so clip its real and imaginary coordinates to [-N,N] and
approximate its exponential. This gives relative complex error for the
nonzero contraction. It is a complex-partition-function extension, not an
ordinary physical norm or positive sampler.

## 10. Explicit noninjective families and a postselection obstruction

An entire arbitrary-subspace hard-filter family is covered. Let n=D^4 and
0<=r<=floor(q^2 n). Choose any explicitly supplied rational unitary U on C^n,
and let P=U diag(I_r,0) U*. Define C=E_allowed U*, where E_allowed selects the
last n-r coordinates. Then

    C* C=I-P,  H=P,  ||H||_F/D^2=sqrt(r/n)<=q.

Both C and H are rational, every rejected vector is an exact local kernel,
and U may entangle all four virtual legs. No tensor split is assumed. Rational
unitaries can be constructed, for example, by products of rational complex
Householder reflections. The local physical dimension is n-r, respecting the
effective-rank obstruction. This extends the directional rank-one example to
arbitrary forbidden subspaces of dimension proportional to D^4. It fails any
strict positive local singular-value hypothesis. The theorem approximates its
normalization uniformly in D; useful physical dynamics and priority are still
separate questions.

There is also an exact reason unrestricted postselection is a stronger task.
On a degree-four graph, start with *arbitrary* local maps C0_v on bond dimension
D0, scaled so that C0_v* C0_v<=I. Enlarge each virtual space to D=12D0 and let
P_v be the projector onto the tensor product of the original D0-dimensional
subspaces. In an orthogonal direct sum of physical output sectors, define

    Cbig_v = C0_v P_v + J_v(I-P_v),

where J_v is an isometry of the complement into the second output sector and
the first term is understood as the embedded original map. Orthogonality gives

    Wbig_v=Cbig_v* Cbig_v=I-Hbig_v,
    Hbig_v=embed(I-C0_v* C0_v),
    0<=Hbig_v<=I,
    ||Hbig_v||_F / D^2 <= D0^2/D^2=1/144<1/128.            (26)

Thus the enlarged PEPS norm has the FPRAS, for every choice of the original
maps. If every local physical output is postselected into its first sector,
the resulting state is the original PEPS. The unnormalized squared norm of
that branch is exactly

    (D0/D)^|E| Z0,

where Z0 uses normalized D0-dimensional bonds. The conditional branch
probability is this number divided by Zbig. The branch can be exponentially
rare or absent. Its local Gram matrices have low rank and leave the class.

For a general graph with minimum nonzero degree one, choose D/D0=128^2
instead: the bound is (D0/D)^(deg(v)/2)<=1/128. Isolated vertices are scalar
local factors and can be handled separately. On a square grid, one may instead
keep the degree-four active-region/identity-boundary interface explicit.

This construction does not prove hardness of unconditional approximate Born
sampling: a total-variation approximation may ignore an exponentially rare
branch. It proves the precise interface barrier that easy unconditional norm
contraction can contain arbitrary original PEPS under unrestricted local
postselection. A claimed sampler or conditioned-query algorithm must charge
the rare branch and re-check its local assumptions.

## 11. Primary prior-art comparison, checked 11 October 2026

1. H. Finner, *A Generalization of Holder's Inequality and Some Probability
   Inequalities*, Annals of Probability 20 (1992), 1893--1901,
   https://doi.org/10.1214/aop/1176989534 . This is the established product-space
   Holder principle used twice above. The journal full-text tool endpoint was
   unavailable; the theorem application is also independently reconstructed
   in the displayed graph exponent accounting.

2. M. Heddes, I. Nunes, T. Givargis, A. Nicolau, *Approximating Tensor Network
   Contraction with Sketches*, arXiv:2603.07387v1, 8 March 2026,
   https://arxiv.org/html/2603.07387v1 . Lemma 6 supplies an unbiased estimator
   for an arbitrary cyclic full contraction with variance bounded by
   3^e/m times the product of squared local Frobenius norms. Theorem 1 gives
   polynomial input dependence and exponential dependence on e. This already
   supplies an exp(O(k))poly(D) connected-moment approximation primitive for
   k-vertex bounded-degree clusters. The finite-phase proof here is a simple
   direct reconstruction with a complex 2^e second-moment bound; do not claim
   the general sketch/probe primitive as new. The source's output guarantee is
   additive relative to input tensor norms, not multiplicative relative to an
   arbitrary final scalar. The low-HS zero-free combination provides the latter.

3. V. Patel, G. Regts, *Deterministic polynomial-time approximation algorithms
   for partition functions and graph polynomials*, arXiv:1607.01167v2,
   https://arxiv.org/html/1607.01167v2 . Theorem 7.1 and Section 7.2 combine
   a zero-free disk and connected fragment computations for edge-coloring
   models. Their alphabet k and degree are fixed; the proof explicitly incurs
   O(k^(Delta ell)) per fragment at order ell=O(log(N/epsilon)). Thus this
   statement alone does not give joint polynomial complexity in growing bond
   dimension. Their sufficient class uses entrywise proximity to all-ones
   weights. The connected-support coefficient principle is established there.

4. G. Regts, *Zero-free regions of partition functions with applications to
   algorithms and graph limits*, arXiv:1507.02089v3,
   https://arxiv.org/html/1507.02089v3 . Theorem 6 and Corollary 6b give
   zero-free regions for tensor network contractions, including orthogonal
   transforms of tensors near a rank-one reference. Corollary 6b uses an
   entrywise neighborhood whose radius depends on the reference vector and
   dimension; it does not state the dimension-independent normalized-HS ball
   above. This is a substantial comparison, not an assertion of disjointness.

5. Recent quantum cluster-contraction comparisons preserved by root include
   Midha--Zhang, arXiv:2510.02290v2,
   https://arxiv.org/html/2510.02290v2 ; Midha et al.,
   arXiv:2604.21919v1, https://arxiv.org/html/2604.21919v1 ; and Midha et al.,
   arXiv:2604.03228, https://arxiv.org/abs/2604.03228 . Strong injectivity and
   constant-D assumptions must be compared at the exact theorem level. A
   local projector with a kernel definitively violates a strictly positive
   smallest-singular-value premise, but does not prove all prior algorithms
   fail on that instance.

6. S. Gonzalez-Garcia et al., *Random insights into the complexity of two-dimensional
   tensor network calculations*, arXiv:2307.11053v1,
   https://arxiv.org/html/2307.11053v1 . The paper already argues that random
   PEPS norms and correlations are generically tractable, using a replicated
   statistical-mechanics mapping controlled at large D together with numerical
   evidence. This prevents any first-generic-easiness claim here. Its displayed
   physics analysis must be distinguished from the exact supplied-input,
   confidence, bit-cost and joint-D FPRAS interface proved above.

7. J. Jiang, J. Chen, N. Schuch, D. Hangleiter, *Positive bias makes
   tensor-network contraction tractable*, arXiv:2410.05414v1 (STOC 2025),
   https://arxiv.org/html/2410.05414v1 . It rigorously supplies a quasi-polynomial
   multiplicative approximation for positively biased random tensor entries.
   This is a different model from PEPS Gram matrices and a different local
   norm certificate; it remains a necessary random-contraction comparison.

Chen et al.'s Sign Problem paper, arXiv:2404.19023v2,
https://arxiv.org/html/2404.19023v2 , explicitly observes in Section V.3 that
physical dimension p much larger than D^4 makes a random local map nearly
isometric, and gives a balanced separable positive-sum argument at p~D^6.
The latter establishes a BPP^NP approximate-counting interface; positivity
alone does not establish a variance/mixing-controlled FPRAS. Thus the random
PEPS p=O(D^4+log N) corollary being reconstructed by s05 is compared against
existing near-isometry insight, not presented as its discovery.

For arXiv:2604.21919v1, the supplementary Section S4 explicitly imposes
epsilon<1/D in Eq. S69 and its large-D threshold summary S1629. Combining this
displayed sufficient condition with Gaussian singular-value-ratio fluctuations
of order sqrt(D^4/p) suggests a sufficient p of order D^6 for that route. This
is a comparison of sufficient bounds, not a lower bound on any previous
algorithm's performance. The kernel family in Section 10 gives a clean
assumption-level distinction even without making this random asymptotic claim.

Remaining priority candidate: the joint polynomial dependence on input bond
dimension for the checkable normalized-HS/effective-rank class, via stable
randomized cluster coefficients. Every primitive has substantial prior art.
No absence-of-search-hit argument establishes novelty.

## 12. Verification record and unresolved obligations

The main proof is internally reconstructed above; no external theorem checker
or independent human reviewer has certified it. Root independently checked the
fourth-moment and analytic-stability arguments and saved an exact Gaussian-
integer diagnostic at work/root/finite_phase_check.py, with its output in
work/root/finite_phase_check.json. It exhausts 256 one-edge phase vectors and
65,536 coupled two-edge phase configurations, including genuinely complex
coefficients. A deliberately wrong endpoint-conjugation convention changes an
exact expected value by a factor five, so this is a useful orientation control.
These finite fixtures are diagnostics, not the general proof or priority
validation. No separate full FPRAS implementation or useful-runtime benchmark
has been completed by this worker.

Open obligations before an external capability claim are independent proof
review; stronger literature comparison on the combined HS/sketch/cluster
interface; a checked implementation of the full FPRAS; useful physical input
families with acquisition costs; and sampling/preparation results only where
their additional branch-stability or oracle assumptions are proved. The old
Wishart block-separability acquisition theorem remains separately in s03.md.

Provenance: root suggested Gaussian edge-vector moments and then the finite
four-phase substitution and analytic stability argument. s03 supplied the
explicit fourth-moment induction, orientation/normalization/finite-bit closure,
complete algorithm and cost reconstruction. The rare-defect norm and polymer
recurrence were developed by root and s06. This document is internal proof
work; model agreement and subsequent finite tests are scoped diagnostics only.
