"""Exact compact checks for the weighted all-coordinate palette obstruction.
Verifies the binary code and every difference/palette-pair overwrite template.
The full SF-free claim follows from the recorded triple-type proof, not a full
triple enumeration of the 230432-row example.
"""
import itertools
import json
from pathlib import Path
import random


def palette(q, d):
    return [(b, h) for b in (0, 1) for h in range(q) if h < (h ^ d)]


def cover(q, d, a, copies):
    b, r = a
    s = r ^ d
    t = next(u for u in range(q) if u not in (r, s))
    u0 = t ^ d
    tp = next(u for u in range(q) if u not in (r, s, t, u0))
    out = {}
    for u in range(q):
        if u not in (r, s, t, u0):
            e = t ^ u
            out[(e - 1) * copies + 1] = (b, min(t, u))
    e = u0 ^ tp
    out[(e - 1) * copies + 2] = (b, min(u0, tp))
    assert len(out) == q - 3
    seen = set()
    for j, (bb, h) in out.items():
        e = j // copies + 1
        assert bb == b and e != d and j % copies in (1, 2)
        assert h not in (r, s) and (h ^ e) not in (r, s)
        seen.update((h, h ^ e))
    assert seen == set(range(q)) - {r, s}
    return out


def main():
    q, copies = 16, 64
    width = copies * (q - 1)
    gadgets = width * q * (q - 1)
    bits = (gadgets - 1).bit_length()
    rng = random.Random(2026101105)
    generators = [rng.getrandbits(width) for _ in range(bits)]
    word, lo, hi = 0, width, 0
    for index in range(1, 1 << bits):
        changed = (index & -index).bit_length() - 1
        word ^= generators[changed]
        wt = word.bit_count()
        lo, hi = min(lo, wt), max(hi, wt)
    assert width // 4 <= lo <= hi <= 3 * width // 4
    overwrite_bound = copies + q - 3
    assert width // 4 > 3 * overwrite_bound
    templates = 0
    one_gadget_heavy_pair_checks = 0
    for d in range(1, q):
        symbols = palette(q, d)
        assert len(symbols) == q
        shared_mask = ((1 << copies) - 1) << ((d - 1) * copies)
        for a in symbols:
            base_cover = cover(q, d, a, copies)
            for other in symbols:
                if a == other:
                    continue
                # Copy zero is representative; arbitrary target-copy placement
                # is handled by the proof and permutation of copies of d.
                target = (d - 1) * copies
                overwritten = dict(base_cover)
                overwritten.update({target + k: a for k in range(copies)})
                overwritten[target] = other
                assert len(overwritten) == overwrite_bound
                agreement = [0] * (2 * q)
                for j, (b, h) in overwritten.items():
                    e = j // copies + 1
                    agreement[b * q + h] |= 1 << j
                    agreement[b * q + (h ^ e)] |= 1 << j
                r, s = a[0] * q + a[1], a[0] * q + (a[1] ^ d)
                target_bad = ((shared_mask & ~agreement[r]) |
                              ((agreement[r] ^ agreement[s]) & ~shared_mask))
                assert target_bad == 1 << target
                for u, v in itertools.combinations(range(2 * q), 2):
                    same_group = u // q == v // q
                    if same_group:
                        e = (u % q) ^ (v % q)
                        common = ((1 << copies) - 1) << ((e - 1) * copies)
                        bad = ((common & ~agreement[u]) |
                               ((agreement[u] ^ agreement[v]) & ~common))
                    else:
                        bad = agreement[u] | agreement[v]
                    assert bad
                    one_gadget_heavy_pair_checks += 1
                templates += 1
    result = {
        "q": q, "copies": copies, "width": width,
        "heavy_rows": 2 * q, "gadgets": gadgets,
        "binary_linear_code_dimension": bits,
        "nonzero_codewords_checked": (1 << bits) - 1,
        "minimum_nonzero_weight": lo, "maximum_nonzero_weight": hi,
        "overwrite_bound": overwrite_bound,
        "difference_palette_templates_checked": templates,
        "one_gadget_two_heavy_cases_checked": one_gadget_heavy_pair_checks,
        "all_coordinate_clique_size_by_proof": q,
        "status": "exact_ingredients_verified_not_full_triple_enumeration",
        "generators_hex": [hex(x) for x in generators]
    }
    out = Path(__file__).with_suffix('.json')
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'generators_hex'}))

if __name__ == '__main__':
    main()
