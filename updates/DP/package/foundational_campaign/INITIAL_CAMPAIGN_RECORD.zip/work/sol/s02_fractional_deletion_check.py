"""Exact finite check of the uniform complete-palette counterexample.
No infeasibility or asymptotic conclusion is inferred from these checks.
"""
from collections import Counter
from itertools import combinations
import json
from pathlib import Path


def valid(a, b, c, skip=None):
    return all(i == skip or len({u, v, z}) != 2
               for i, (u, v, z) in enumerate(zip(a, b, c)))


def example(m):
    functionals = list(range(1, 1 << m))
    lead_i = len(functionals)
    rows = []
    for x in range(1, 1 << m):
        lead = x.bit_length()
        prefix = tuple(0 if (x & f).bit_count() % 2 == 0 else x
                       for f in functionals) + (lead,)
        for t in range(1 << (m - lead)):
            tag = (0,) * (lead - 1) + tuple((t >> j) & 1 for j in range(m - lead))
            rows.append(prefix + tag)
    assert len(set(rows)) == len(rows) == m * (1 << (m - 1))
    edge_set = set()
    flowers = 0
    for a, b, c in combinations(rows, 3):
        if valid(a, b, c):
            flowers += 1
        if valid(a, b, c, lead_i):
            symbols = {a[lead_i], b[lead_i], c[lead_i]}
            if len(symbols) == 2:
                edge_set.add(tuple(sorted(symbols)))
    expected_edges = set(combinations(range(1, m + 1), 2))
    marginal = Counter(row[lead_i] for row in rows)
    assert flowers == 0
    assert edge_set == expected_edges
    assert set(marginal.values()) == {1 << (m - 1)}
    return {"m": m, "rows": len(rows), "width": len(rows[0]),
            "sunflower_triples": flowers,
            "leading_palette_edges": sorted(edge_set),
            "leading_symbol_counts": dict(sorted(marginal.items())),
            "status": "exact_finite_check_only"}

if __name__ == "__main__":
    results = [example(m) for m in (3, 4)]
    out = Path(__file__).with_name("s02_fractional_deletion_check.json")
    out.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results))
