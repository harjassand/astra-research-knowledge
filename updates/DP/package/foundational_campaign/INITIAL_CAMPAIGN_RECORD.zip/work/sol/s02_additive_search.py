"""Exact finite geometry; seeded heuristic and bounded SAT counterexample search.

Only a found witness is conclusive. A timeout is not evidence of infeasibility.
"""
import argparse
import itertools
import json
import random
import time


def geometry(m=6, maxdim=4):
    levels = [{1: ()}]
    for d in range(maxdim):
        nxt = {}
        for mask, basis in levels[-1].items():
            members = [x for x in range(1 << m) if (mask >> x) & 1]
            for v in range(1, 1 << m):
                if not ((mask >> v) & 1):
                    bigger = mask | sum(1 << (x ^ v) for x in members)
                    nxt.setdefault(bigger, basis + (v,))
        levels.append(nxt)
    planes = sorted(levels[2])
    spaces = []
    for d, lev in enumerate(levels):
        for mask, basis in sorted(lev.items()):
            hit = sum(1 << j for j, p in enumerate(planes)
                      if (p & mask).bit_count() == 2)
            spaces.append((d, mask, basis, hit))
    return planes, spaces


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['random', 'sat'], default='random')
    ap.add_argument('--seconds', type=float, default=45)
    ap.add_argument('--maxdim', type=int, default=4)
    ap.add_argument('--out', default='work/sol/s02_additive_search.json')
    args = ap.parse_args()
    started = time.monotonic()
    planes, spaces = geometry(maxdim=args.maxdim)
    full = (1 << len(planes)) - 1
    fixedmask = (1 << (1 << args.maxdim)) - 1
    fixed = next(i for i, s in enumerate(spaces) if s[1] == fixedmask)
    witness = None
    result = {'m': 6, 'w': 5, 'max_kernel_dimension': args.maxdim,
              'plane_count': len(planes), 'kernel_count': len(spaces),
              'fixed_kernel_basis': spaces[fixed][2], 'mode': args.mode}
    if args.mode == 'random':
        rng = random.Random(2026101102)
        candidates = [i for i, s in enumerate(spaces) if s[0] >= 2]
        best, tries, record = 0, 0, None
        while time.monotonic() - started < args.seconds:
            chosen = [fixed] + rng.sample(candidates, 4)
            union = 0
            for i in chosen:
                union |= spaces[i][3]
            score = union.bit_count()
            joint = (1 << 64) - 1
            for i in chosen:
                joint &= spaces[i][1]
            if joint != 1:
                continue
            for step in range(50):
                p = rng.randrange(1, 5)
                trial = rng.choice(candidates)
                base = 0
                new_joint = spaces[trial][1]
                for j in range(5):
                    if j != p:
                        base |= spaces[chosen[j]][3]
                        new_joint &= spaces[chosen[j]][1]
                if new_joint != 1:
                    continue
                value = (base | spaces[trial][3]).bit_count()
                if value >= score or rng.random() < 0.01:
                    chosen[p], score = trial, value
                tries += 1
                if score > best:
                    best, record = score, chosen[:]
                    print('best', best, [spaces[i][2] for i in record], flush=True)
                if score == len(planes):
                    joint = (1 << 64) - 1
                    for i in chosen:
                        joint &= spaces[i][1]
                    if joint == 1:
                        witness = chosen
                        break
            if witness is not None:
                break
        result.update(best_planes_covered=best, proposed_moves=tries,
                      best_kernel_bases=[spaces[i][2] for i in record] if record else None,
                      status='witness' if witness else 'no_witness_in_bounded_heuristic')
    else:
        import z3
        variables = [z3.Bool('K%d' % i) for i in range(len(spaces))]
        solver = z3.Solver()
        solver.set(timeout=int(args.seconds * 1000))
        solver.add(variables[fixed])
        solver.add(z3.PbEq([(x, 1) for x in variables], 5))
        for j in range(len(planes)):
            solver.add(z3.Or([variables[i] for i, s in enumerate(spaces)
                              if (s[3] >> j) & 1]))
        for x in range(1, 64):
            solver.add(z3.Or([variables[i] for i, s in enumerate(spaces)
                              if not ((s[1] >> x) & 1)]))
        status = solver.check()
        result['status'] = str(status)
        if status == z3.sat:
            model = solver.model()
            witness = [i for i, v in enumerate(variables) if z3.is_true(model[v])]
        elif status == z3.unknown:
            result['reason_unknown'] = solver.reason_unknown()
        result['solver_statistics'] = str(solver.statistics())
    if witness is not None:
        joint, union = (1 << 64) - 1, 0
        for i in witness:
            joint &= spaces[i][1]
            union |= spaces[i][3]
        assert joint == 1 and union == full and len(witness) == 5
        result['witness_kernel_bases'] = [spaces[i][2] for i in witness]
        result['verified_joint_kernel'] = [x for x in range(64) if (joint >> x) & 1]
        result['verified_blocked_planes'] = union.bit_count()
    result['elapsed_seconds'] = time.monotonic() - started
    with open(args.out, 'w') as out:
        json.dump(result, out, indent=2)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
