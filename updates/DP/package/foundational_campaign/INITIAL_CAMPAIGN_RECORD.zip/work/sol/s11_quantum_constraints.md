# Noncommuting dilute constraints: a fixed-pass theorem and an angle obstruction

Internal reconstruction, 11 October 2026, worker s09. Parent requested an
ambitious extension of the creation-parent mechanism to constructive quantum
Lovasz local lemma problems. No external validation or priority claim.

The positive result is preparation of the canonical purification after a
fixed number of ordered filtering passes, using a uniformly gapped alternative
parent. This does **not** prepare a state in the common constraint kernel in
general. An explicit rank-one, two-local example proves that extending the
result by repeating the same filters can require exponentially many passes in
the input bit length. It also separates exponentially small energy from
constant distance to the ground space. The example does not give a lower bound
against all ground-state algorithms: every gadget has an easy exact solution.

## 1. Exact interface

Supply n physical qudits of dimension d and m explicit rational Hermitian
projectors P_a. Every P_a acts on a set X_a of at most k qudits. Each qudit is
in at most r supports. The overlap graph G has one vertex per constraint and
an edge when two supports intersect. Its maximum degree is Delta, with
Delta <= k(r-1). Assume

    rank(P_a)/d^|X_a| <= p.                              (1)

Fix a proper coloring into c<=Delta+1 classes. Within each class supports are
disjoint. Choose the filtering order to be color by color, and let

    F = product_in_that_order (I-P_a).

All displayed ordered products use the same order, so the later filter acts
on the left. For one reference qudit per physical qudit set

    Omega = tensor_i Phi_d(i,i'),
    psi_F = (F tensor I)Omega / ||(F tensor I)Omega||.    (2)

Each physical-reference pair is one creation-algebra site, with vacuum Phi_d.
For an operator A on all physical qudits,

    ||(A tensor I)Omega|| = ||A||_F/d^(n/2).              (3)

The references are part of the preparation output. Tracing them out yields
FF^*/tr(FF^*). A common-kernel purification would instead use the orthogonal
projector G_0 onto intersection_a ker P_a in place of F.

Fixed k,r,Delta are algorithmic parameters. Local dimension d, the number of
constraints, input bit length, and requested precision are charged. Neither a
succinct matrix oracle nor free input acquisition is assumed.

## 2. Positive cluster-vector suppression for one pass

For U subset of constraints, let

    w_U = [ordered product_{a in U} (-P_a)] Omega,
    s = |U|.

In this section identities on unused pairs are implicit. Write the ordered
word as A_c ... A_1, where A_j is the product of the selected projectors in
color j. Every A_j is a projector on disjoint supports, and has operator norm
at most one. The ideal property of the Hilbert-Schmidt norm gives, for every j,

    ||A_c ... A_1||_F <= ||A_j||_F.

Normalized by the dimension of the union support, disjoint-support
factorization gives

    ||A_j||_F / sqrt(dim) <= p^(|U intersect color_j|/2).

Some class contains at least s/c selected projectors. Consequently

    ||w_U|| <= p^(s/(2c)).                               (4)

This proof does not commute projectors in different colors. If the overlap
graph on U has several components, those components act on disjoint qudits.
Their ordered words commute, and their vectors factor exactly.

For a vector f on l vacuum sites use the creation lift of s10.md:

    C(f) = sum_{J subset of those sites}
             |f_J><0_J| tensor I_outside_J,

where f_J are the orthogonal excitation-support sectors. The empty sector
is retained as a scalar identity term. Then

    C(f)Omega=f,
    ||C(f)|| <= 2^(l/2)||f||.

All creation lifts commute, including lifts whose supports overlap. They
factor on disjoint supports. Since w_U uses at most ks pair sites, taking

    A = 2^ceil(k/2),
    eta = A p^(1/(2c)),
    B_U = C(w_U),

gives the explicit dimension-independent bounds

    ||B_U|| <= eta^|U|,
    B_U = product_over_components B_component.          (5)

Thus noncommutation does not destroy the creation-parent construction for a
single color-ordered pass.

## 3. A quantitative fixed-pass preparation theorem

The following constants are deliberately conservative. They demonstrate a
closed regime rather than optimizing it. Suppose Delta>=1, and put

    b = 4 Delta,
    R = 128 b A r k,
    a_* = (1/10)(4/5)^(Delta+1)/(Delta+1),
    p <= [a_* /(R A)]^(2c).                              (6)

Then psi_F is nonzero and has a creation logarithm K with an exponentially
decaying connected-constraint expansion. There is an explicitly described
path of positive Hamiltonians on physical-reference pairs whose unique
ground state at its endpoint is psi_F and whose gap exceeds 0.97 uniformly
in n,d and input bit length. Truncating connected constraint supports at
size O(log(m/epsilon)) changes the normalized state by at most epsilon.
The cluster-block-encoding construction in s10.md and root's completed
preparation theorem then give a quantum circuit of cost polynomial in n,m,
the explicit local matrix input size, and 1/epsilon, for fixed k,r,Delta.
The Hamiltonians here are alternative parents, not the supplied sum_a P_a.

Here is a reconstruction of all new estimates needed for this extension.
Define, in the commutative creation algebra,

    W_T(z)=sum_{U subset T} z^|U| B_U.

For every |z|<=R, component factorization yields the polymer deletion
recurrence. There are at most b^(s-1) connected s-sets through a fixed
constraint, by counting rooted ordered spanning trees. A size-s polymer
deletes at most (Delta+1)s-1 vertices beyond the distinguished constraint.
With rho_0=1/5 and beta=R eta, the deletion-ratio induction is bounded by

    ||W_T W_(T\v)^(-1)-I||
      <= beta (1-rho_0)^(-Delta)
          /[1-b beta (1-rho_0)^(-(Delta+1))].             (7)

By (6), beta<=a_*. The numerator is at most (2/25)/(Delta+1),
and the denominator is at least 1-(2/5)Delta/(Delta+1)>3/5.
The right side of (7) is therefore at most 2/[15(Delta+1)]<1/5.
In particular all ratios are invertible and their branches of log are
analytic on a neighborhood of the closed disk. Writing c_0=log(5/4),

    ||log W_T(z)|| <= c_0 |T|,
    ||W_T(1)^(-1)|| <= (5/4)^|T|.                        (8)

For a connected constraint set S of size s, the coefficient K_(S,l) obtained
by Mobius inversion of [z^l]log W_T(z) vanishes for l<s, and obeys

    ||K_(S,l)|| <= c_0 s 2^(s-1) R^(-l).

Indeed Cauchy's bound gives c_0 |T| R^(-l) for each T subset S, and
sum_(T subset S) |T|=s2^(s-1). Disconnected S vanish by factorization.
Thus, with K_S=sum_(l>=s) K_(S,l),

    ||K_S|| <= c_0 s 2^(s-1) R^(-s)/(1-1/R),
    K=log W_V(1)=sum_(S connected) K_S,
    exp(K)Omega=F Omega.                                (9)

Every K_S has support on at most ks pair sites. Decomposing its action on
Omega into excitation-support sectors multiplies its norm sum by at most
A^s. Each nonempty sector has support size at most ks. At most
r b^(s-1) connected S touch a fixed physical-reference pair. Therefore the
pure-creation decomposition K=lambda I+sum_J K_J satisfies

    kappa := max_i sum_(J containing i) |J| ||K_J||
      <= [r k c_0/(2b(1-1/R))]
          sum_(s>=1) s^2 (2bA/R)^s.                     (10)

Our R gives x=2bA/R=1/(64rk)<=1/64 and R>=1024. Using
sum s^2 x^s=x(1+x)/(1-x)^3, the right side of (10) is less than 1/100.
The same bound holds for connected-support truncations of K. The scalar
lambda is kept throughout and excluded directly from kappa.

For vacuum-complement projectors h_i and K_i=[h_i,K], the creation-parent
lemma proved in s09_gap.md gives

    Q_i(t)=h_i-tK_i=exp(tK)h_i exp(-tK),
    H_alt(t)=sum_i Q_i(t)^*Q_i(t),
    gap H_alt(t)>=1-2kappa-2kappa^2>0.9798.              (11)

The common kernel is exactly span{exp(tK)Omega}. This proves the stated
weaker gap bound 0.97 without importing a dimension-dependent stability
theorem.

For K_<=L=sum_(connected |S|<=L) K_S and rho=2b/R<1, summing (9) over
connected sets gives

    ||K-K_<=L||
      <= [m c_0/(2b(1-1/R))]
          rho^(L+1) [(L+1)-L rho]/(1-rho)^2.             (12)

Because creation terms commute, the normalized-state trace error is at most
2(exp(delta_L)-1), where delta_L is the right side of (12). No factor
exp(||K||) occurs. Choose L=O(log(m/epsilon)). This proves the truncation
claim, with scalar coefficients retained in both logarithms.

The algorithmic interface differs from s10 only in constants. A cluster
with s constraints uses at most ks pair sites. Its vector is prepared by
s block encodings of explicit local projectors. Lifting all excitation
supports and summing U subset T uses exp(O(ks)) controlled operations and
normalization. Equation (8) bounds inverse conditioning by (5/4)^s.
Deletion ratios lie within 1/5 of identity by (7), so their logarithms use
uniformly convergent log series after inverse construction and block
amplification. All costs are exp(O(s)) poly(d^k,input bits,precision bits)
for fixed k,r,Delta. Enumerating connected sets and Mobius sums also costs
exp(O(s)), not s^s. With s<=L this is jointly polynomial. The truncated
Hamiltonian path inherits (11); its simulation and adiabatic errors are
allocated separately, as in root's completed preparation theorem. No
d^(kL) classical cluster matrix is formed. Direct postselection of all
filters, whose success probability can be exponentially small, is not the
algorithm claimed here.

For Delta=0 the supports are disjoint and every filtered local purification
can instead be computed and prepared separately from its explicit matrix;
the original constraints are then simultaneously satisfied. More generally,
any fixed number T of passes can be treated by applying the above theorem
to the occurrence graph. Its degree is at most T(Delta+1)-1, participation
is at most Tr, and the number of contiguous disjoint-support layers is Tc.
The resulting rank threshold depends on T. This is a fixed-T theorem, not a
uniform theorem as T grows with problem size or inverse gap.

## 4. Exact two-local example: tiny ranks and exponentially slow filtering

Take two d-dimensional qudits, with L=d^2>=4. Only their |00>,|11> sector is
used by the bad vectors. Define orthonormal vectors

    u=(|00>+|11>)/sqrt(2),
    w=(|00>-|11>)/sqrt(2).

For an integer B>=2 take

    t=2^(-B),
    c=(1-t^2)/(1+t^2),
    s=2t/(1+t^2),
    v=c u+s w,
    P=|u><u|,
    Q=|v><v|.                                           (13)

Here c^2+s^2=1, 0<c,s<1, and P,Q do not commute. Both are genuinely
two-local entangled rank-one projectors with relative rank p=1/L. Their
matrix entries in the computational basis are rational: the factors of
sqrt(2) cancel in the outer products. Nonzero entries have bit length O(B).
The remaining matrix entries are zero. Padding d makes p arbitrarily small
without changing the angle.

On span{u,w}, P+Q has eigenvalues 1+c and 1-c; elsewhere it is zero. Thus

    gap(P+Q)=1-c=2t^2/(1+t^2).                           (14)

The relative rank promise alone does not bound this gap, even with k=2,
r=2, and overlap degree one. This is already a local, exact obstruction to
inferring an original-Hamiltonian gap from the alternative-parent gap.

For t>0 the joint-kernel projector is

    G_0=I-|u><u|-|w><w|.

Let g=-s u+c w and F=(I-Q)(I-P). Then

    F=G_0+c|g><w|,
    F^T=G_0+c^(2T-1)|g><w|,            T>=1.            (15)

The second equality follows from <w|g>=c. No asymptotic estimate is used.
The normalized filtered purification and normalized common-kernel
purification have squared overlap

    (L-2)/(L-2+c^(4T-2)),

because their two matrix-vectorized components are orthogonal. Their pure
trace distance squared is c^(4T-2)/(L-2+c^(4T-2)).

One padded gadget has a small trace error, so take M=L-2 independent gadgets.
Each qudit remains in two constraints; the overlap graph is a disjoint union
of edges. Set sigma_T^2=c^(4T-2). The global squared overlap with the
normalized common-kernel purification is

    (1+sigma_T^2/M)^(-M),

and hence the global pure-state trace distance is exactly

    D_T = sqrt(1-(1+sigma_T^2/M)^(-M)).                  (16)

After tracing out the references, the physical output has outside
ground-space weight D_T^2. Its trace distance from its normalized
common-kernel projection equals D_T^2; this is also its minimum distance
from any density operator supported in the common kernel. The stronger
square-root distance (16) is the purification metric and must not be
attributed to the mixed physical state.

There is an elementary exponential lower bound on filtering passes. Since
c>=1-2t^2, Bernoulli's inequality gives, when T<=1/(16t^2),

    sigma_T^2 >= 1-8Tt^2 >= 1/2.

For M>=2, (1+1/(2M))^M >= (5/4)^2=25/16: the first three binomial terms
alone give 1+1/2+(M-1)/(8M)>=25/16. It follows that

    D_T^2 >= 9/25,
    D_T >= 3/5,
    distance(physical output, all ground-supported states) >= 9/25.   (17)

Thus purification trace error <=1/2 requires

    T > 4^B/16.                                         (18)

The exact mixed-state separation in (17) is constant as well. For any fixed
d (including a d large enough for any specified rank threshold), input size
grows only polynomially with B, while (18) is exponential in B. In dense
matrix accounting the M gadgets occupy O(d^6 B) input bits up to harmless
encoding constants; no succinct-oracle compression is needed for the claim.

The physical energy after T passes is nevertheless tiny. The last Q filter
is satisfied, <g|Q|g>=0, while <g|P|g>=s^2. Summing over M gadgets yields

    tr[H_original rho_T]
      = M sigma_T^2 s^2/(M+sigma_T^2)
      <= s^2 <= 4t^2.                                   (19)

Consequently an efficiently prepared one-pass state can have energy at most
4^(1-B) but remain a constant distance from every ground-supported state.
Using a small energy as a substitute for a ground-space guarantee would
therefore be incorrect without a gap or another conversion estimate.

## 5. Which cluster bounds fail, and which remain open

Repeated bad words exhibit the precise loss in a time-occurrence expansion:

    (QP)^T=c^(2T-1)|v><u|,
    ||[(QP)^T tensor I]Omega_L||=sqrt(p)c^(2T-1).         (20)

For T much smaller than t^(-2), this stays of order sqrt(p). There is no
uniform bound eta^(2T) with eta<1 depending only on p,k,r and the original
overlap graph. Repeating a single idempotent already warns against counting
occurrences as independent defects; (20) shows that a genuinely noncommuting
two-projector problem has the same issue after repetitions are combined.
The occurrence graph has a growing temporal clique, exactly as indicated by
the fixed-T constants above. The creation argument does not erase this cost.

For true intersections, write G_empty=I, G_P=I-P, G_Q=I-Q. The connected
second Mobius correction is

    B_PQ=G_0-G_P-G_Q+I=P+Q-(|u><u|+|w><w|).

In the u,w basis it is

    [[c^2, c s], [c s, -c^2]],

so its eigenvalues are +/-c and

    ||B_PQ||=c,
    ||(B_PQ tensor I)Omega_L||=sqrt(2p)c.                (21)

The product of the two singleton vector norms is p. Hence that stronger
product-decay hypothesis fails by an unbounded factor as p tends to zero.
There is also a discontinuity at t=0: the joint kernel excludes w for every
t>0 but includes it at t=0. Small commutators alone cannot control the exact
intersection projector continuously.

Scope matters. Equation (21) still fits a weaker color-dependent bound of
the form p^(|U|/(2c_colors)) when |U|=c_colors=2. It therefore does **not**
disprove every possible exponential bound on connected true-intersection
coefficients at bounded participation. No such bound was proved or refuted
here for arbitrarily large connected sets. The failure of (20), the original
gap bound (14), and the filtering lower bound (18) are the closed obstructions.

Nor is (18) a lower bound on every algorithm. In this example the common
kernel is explicit; |01> is already a ground state of each gadget, and a
general pair of explicit matrices on one L-dimensional space permits exact
joint-kernel computation by polynomial-time rational linear algebra. The
bit length B must be charged, but an inverse-angle iteration count is not
intrinsic to this finite-dimensional kernel computation.

## 6. Literature boundary and remaining invention gate

The color-class norm idea is not claimed as new. Mann and Waite's
[Approximate Counting in Local Lemma Regimes](https://opus.lib.uts.edu.au/bitstream/10453/195032/2/approximate-counting-in-local-lemma-regimes.pdf),
Section IV.C, Lemmas 10--12, use ordered finite-pass projector products,
an occurrence graph with degree T(Delta+1)-1, color-class Schatten bounds,
and a spectral-gap estimate to pass from filtering to the common kernel.
Their separate exact-intersection theorem assumes global inclusion-exclusion
stability. The present derivation applies the campaign's creation lift and
elementary gapped-parent lemma to a finite-pass **state**, and supplies an
exact bit-complexity obstruction to extrapolating that state theorem to
arbitrary repeated filtering. No counting or state-preparation priority is
asserted from this overlap.

Cubitt and Schwarz's
[constructive commutative QLLL and beyond](https://arxiv.org/abs/1112.1413)
provides a commuting constructive result and identifies additional issues
in its noncommuting extension. Gilyen and Sattath's
[constructive QLLL under a uniform gap](https://arxiv.org/abs/1611.08571)
has an explicit gap promise. These sources support keeping the original
constraint-kernel task separate from the alternative-parent preparation
theorem.

The genuinely ambitious remaining gate is a constructive, dimension-charged
description of a common-kernel state or of its true-intersection creation
coefficients under rank and bounded-participation assumptions alone. It
would have to combine nearly parallel local constraints without paying an
inverse-angle iteration count and prove decay on arbitrarily large connected
sets. The single-space example shows that exact local algebra can sometimes
remove the angle cost, so this gate remains open rather than impossible.

## 7. Reproduction and status

`s11_quantum_constraints_check.py` checks the gadget identities over exact
fractions, its projector rationality in the computational basis, all stated
spectra and vector formulas on small fixtures, and the finite-pass constants.
Its JSON report is a finite diagnostic, not the proof or external validation.

Closed internal results: (4)--(12), the explicit gap conversion from
`s09_gap.md`, and the exact obstruction (13)--(21). The circuit conclusion
uses the already reconstructed cluster implementation from `s10.md` and
root's completed preparation theorem with the explicitly stated changes.
Unresolved: efficient common-kernel preparation in the unrestricted
noncommuting low-relative-rank regime, and exponential suppression of
arbitrary connected true-intersection coefficients.
