"""Finite diagnostics for s09.md; the scalable dimension bound is symbolic."""

import itertools
import json
import math
from fractions import Fraction

import numpy as np


def cycle_state(local_map, bond, count):
    physical = local_map.shape[0]
    state = np.zeros(physical**count, dtype=complex)
    for edges in itertools.product(range(bond), repeat=count):
        term = np.array([1.0], dtype=complex)
        for v in range(count):
            local_column = edges[(v-1) % count]*bond + edges[v]
            term = np.kron(term, local_map[:, local_column])
        state += term/bond**(count/2)
    return state


def main():
    a, b, D, count = 2, 1, 3, 3
    active = np.zeros((a*a, a*a))
    active[0, 0] = active[0, 3] = 0.5
    active[1, 1] = 0.5
    active_indices = [left*D+right for left in range(a) for right in range(a)]
    padded = np.zeros((D*D, D*D))
    padded[np.ix_(active_indices, active_indices)] = active
    padded[8, 8] = 1.0
    W = padded.T@padded
    H = np.eye(D*D)-W
    q_squared = float(np.trace(H@H)/(D*D))
    q_bound = 1-(b/D)**2
    assert np.linalg.eigvalsh(H)[0] >= -1e-12
    assert np.linalg.eigvalsh(np.eye(D*D)-H)[0] >= -1e-12
    assert q_squared <= q_bound+1e-12
    chi = cycle_state(active, a, count)
    chi_embedded = np.zeros((D*D)**count, dtype=complex)
    for indices in itertools.product(range(a*a), repeat=count):
        source = np.ravel_multi_index(indices, [a*a]*count)
        target_indices = [active_indices[i] for i in indices]
        target = np.ravel_multi_index(target_indices, [D*D]*count)
        chi_embedded[target] = chi[source]
    inactive = np.zeros_like(chi_embedded)
    inactive[np.ravel_multi_index((8,)*count, [D*D]*count)] = 1
    actual = cycle_state(padded, D, count)
    expected = (a/D)**(count/2)*chi_embedded+(b/D)**(count/2)*inactive
    state_error = float(np.linalg.norm(actual-expected))
    assert state_error < 1e-12
    Z_chi = float(np.vdot(chi, chi).real)
    Z = float(np.vdot(actual, actual).real)
    Z_formula = (a/D)**count*Z_chi+(b/D)**count
    assert abs(Z-Z_formula) < 1e-12
    p = (a/D)**count*Z_chi/Z
    normalized = actual/math.sqrt(Z)
    active_set = set(active_indices)
    p_flag, p_two = 0.0, 0.0
    for indices in itertools.product(range(D*D), repeat=count):
        probability = abs(normalized[np.ravel_multi_index(indices, [D*D]*count)])**2
        if indices[0] in active_set:
            p_flag += probability
        if indices[0] in active_set and indices[1] in active_set:
            p_two += probability
    assert abs(p_flag-p) < 1e-12
    assert abs(p_two-p) < 1e-12
    trace_distance = math.sqrt(max(0.0, 1-abs(np.vdot(inactive, normalized))**2))
    assert abs(trace_distance-math.sqrt(p)) < 1e-12

    matrices = [np.eye(2)/2, np.array([[0, 0.5], [0, 0]]),
                np.zeros((2, 2)), np.zeros((2, 2))]
    columns = []
    for left, right in itertools.product(range(2), repeat=2):
        columns.append(np.array([(x@y)[left, right] for x in matrices for y in matrices]))
    Gamma = np.column_stack(columns)
    vectors, singular, _ = np.linalg.svd(Gamma, full_matrices=False)
    rank = int(np.sum(singular > 1e-12))
    projector = vectors[:, :rank]@vectors[:, :rank].T
    desired = np.zeros((16, 2))
    desired[0, 0] = 1
    desired[1, 1] = desired[4, 1] = 1/math.sqrt(2)
    local_range_error = float(np.linalg.norm(projector-desired@desired.T))
    assert rank == 2
    assert local_range_error < 1e-12
    spectra = []
    for size in [3, 4, 9]:
        laplacian = np.eye(size)
        for i in range(size):
            laplacian[i, (i+1) % size] -= 0.5
            laplacian[(i+1) % size, i] -= 0.5
        values = np.linalg.eigvalsh(laplacian)
        formula = sorted(1-math.cos(2*math.pi*k/size) for k in range(size))
        error = float(np.linalg.norm(values-formula))
        assert error < 1e-12
        spectra.append({"sites": size, "first_positive": float(values[1]),
                        "N_squared_upper_bound": 2*math.pi**2/size**2,
                        "formula_residual": error})
    D_promise = 65536
    promise_bound_squared = Fraction(2*a, D_promise)
    assert promise_bound_squared == Fraction(1, 128**2)
    return {
        "status": "finite_diagnostic_only",
        "small_fixture": {"a": a, "b": b, "D": D, "N": count,
                          "does_not_meet_q_promise": True,
                          "q_squared": q_squared, "q_squared_bound": q_bound,
                          "state_identity_residual": state_error,
                          "Z": Z, "Z_formula": Z_formula,
                          "single_flag_probability": p_flag,
                          "two_flag_probability": p_two,
                          "trace_distance_to_inactive": trace_distance,
                          "active_local_range_rank": rank,
                          "active_local_range_residual": local_range_error},
        "promised_scaled_cycle": {"a": a, "D": D_promise,
                                  "symbolic_q_squared_upper_bound": str(promise_bound_squared)},
        "one_excitation_spectra": spectra,
    }


if __name__ == "__main__":
    print(json.dumps(main(), indent=2))
