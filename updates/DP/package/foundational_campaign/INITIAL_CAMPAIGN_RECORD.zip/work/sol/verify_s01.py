"""Finite checks for S01's proved identities and explicit phase obstruction.

The asymptotic zero existence is proved by Rouche in s01.md. Newton residuals
are diagnostics, not certified complex-root enclosures or sunflower evidence.
Only the Python standard library is used.
"""
from collections import Counter
import cmath
from fractions import Fraction
import itertools
import json
import math
from pathlib import Path


def mm(a, b):
    return [[sum(x * y for x, y in zip(row, col)) for col in zip(*b)]
            for row in a]


def add(a, b):
    return [[x+y for x, y in zip(r, s)] for r, s in zip(a, b)]


def scale(c, a):
    return [[c*x for x in row] for row in a]


def tr(a):
    return sum(a[i][i] for i in range(len(a)))


def cube_trace(a):
    return tr(mm(mm(a, a), a))


def gram(vs):
    return [[sum(x*y for x, y in zip(u, v)) for v in vs] for u in vs]


def matrix_check():
    vectors = [(1, 2, 0), (0, 1, 1), (2, 1, 1), (1, 0, 2), (1, 1, 1)]
    labels = [0, 1, 2, 1, 0]
    blocks = []
    for a in sorted(set(labels)):
        vv = [v for v, label in zip(vectors, labels) if label == a]
        blocks.append([[sum(v[i]*v[j] for v in vv) for j in range(3)]
                       for i in range(3)])
    s = [[0]*3 for _ in range(3)]
    for a in blocks:
        s = add(s, a)
    phi = cube_trace(s)-3*sum(tr(mm(mm(a, a), s)) for a in blocks) \
        +3*sum(cube_trace(a) for a in blocks)
    remainder = sum(tr(mm(a, mm(add(s, scale(-2, a)),
                               add(s, scale(-2, a))))) for a in blocks)
    assert 4*phi == cube_trace(s)+3*remainder
    assert remainder >= 0
    k = gram(vectors)
    retained = sum(k[i][j]*k[j][l]*k[l][i]
                   for i, j, l in itertools.product(range(len(vectors)), repeat=3)
                   if len({labels[i], labels[j], labels[l]}) in (1, 3))
    assert retained == phi
    return {"trace_cube": cube_trace(s), "accepted": phi,
            "sos_remainder": remainder, "identity_exact": True}


def incidence_row(q, b, h):
    return tuple((b, min(h, h ^ d)) for d in range(1, q))


def exponent_profile(q):
    rows = [incidence_row(q, b, h) for b in range(2) for h in range(q)]
    profile = Counter()
    accepted = 0
    for x, y, z in itertools.product(rows, repeat=3):
        exponent = sum((a == b)+(a == c)+(b == c)
                       for a, b, c in zip(x, y, z))
        profile[exponent] += 1
        accepted += all(len({a, b, c}) in (1, 3) for a, b, c in zip(x, y, z))
    expected = Counter()
    expected[3*(q-1)] += 2*q
    expected[q+1] += 6*q*(q-1)
    expected[q-1] += 6*q*q
    expected[3] += 2*q*(q-1)*(q-2)
    expected[1] += 6*q*q*(q-1)
    assert profile == expected
    assert sum(expected.values()) == (2*q)**3
    assert accepted == 2*q
    return {"q": q, "profile": dict(sorted(profile.items())),
            "accepted": accepted, "exact": True}


def qpoly(z, q):
    n = 3*q-4
    return (z**n+3*(q-1)*z**q+3*q*z**(q-2)
            +(q-1)*(q-2)*z*z+3*q*(q-1))


def qderivative(z, q):
    n = 3*q-4
    return (n*z**(n-1)+3*(q-1)*q*z**(q-1)
            +3*q*(q-2)*z**(q-3)+2*(q-1)*(q-2)*z)


def phase_root(q):
    n = 3*q-4
    start = cmath.exp((math.log(4*q*q)+1j*math.pi)/n)
    z = start
    for _ in range(40):
        change = qpoly(z, q)/qderivative(z, q)
        z -= change
        if abs(change) < 2e-16:
            break
    return {"q": q, "root_real": z.real, "root_imag": z.imag,
            "argument": cmath.phase(z), "q_times_argument": q*cmath.phase(z),
            "distance_to_start": abs(z-start),
            "relative_residual": abs(qpoly(z, q))/(4*q*q),
            "diagnostic_only": True}


if __name__ == "__main__":
    result = {"matrix_identity": matrix_check(),
              "incidence_profiles": [exponent_profile(q) for q in (4, 8, 16)],
              "near_positive_roots": [phase_root(q) for q in (32, 64, 128, 256, 512)]}
    out = Path(__file__).with_name("s01_checks.json")
    out.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))
