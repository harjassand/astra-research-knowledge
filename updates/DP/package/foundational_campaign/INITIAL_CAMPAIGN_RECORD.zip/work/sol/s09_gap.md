# A dimension-independent gap for commuting creation parents

Internal proof, worker s09, 11 October 2026. Root supplied the creation-parent
mechanism and requested a uniform spectral-gap proof. The estimate below is an
elementary new reconstruction within this campaign, not a priority claim or
external validation. It is conditional only on the explicitly stated creation
interaction norm. It does not assume a lattice geometry or fixed local dimension.

## The theorem

Let I be a finite index set. At each index i supply a finite-dimensional Hilbert
space H_i with distinguished unit vector |0_i>. Put

    |0> = tensor_i |0_i>,
    h_i = I-|0_i><0_i|.

For each nonempty S subset I, supply a vector

    phi_S in tensor_{i in S} (|0_i> perpendicular),

and the corresponding pure creation operator, tensored with identity outside S,

    K_S = |phi_S><0_S|.

The zero vector and multiple terms on the same support are allowed; terms on
the same support can be combined. Define

    K = sum_S K_S,
    K_i = sum_{S containing i} K_S,
    kappa = max_i sum_{S containing i} |S| ||K_S||op.       (1)

For 0<=t<=1 set

    Q_i(t) = h_i-t K_i,
    H(t) = sum_i Q_i(t)^* Q_i(t).                          (2)

Then H(t) has the unique zero-energy state proportional to

    exp(tK)|0>,                                          (3)

and satisfies the operator inequality

    H(t)^2 >= [1-2t kappa-2t^2 kappa^2] H(t).             (4)

Consequently, whenever kappa < (sqrt(3)-1)/2,

    gap H(t) >= 1-2t kappa-2t^2 kappa^2
              >= 1-2kappa-2kappa^2 > 0                   (5)

uniformly along the entire path. The bound is independent of the number of
indices, all local Hilbert-space dimensions, and the underlying graph.

An arbitrary scalar lambda I may be added to K: it drops out of every K_i
(equivalently K_i=[h_i,K]) and only multiplies (3) by exp(t lambda). All
normalized states, kernels, and gap conclusions are unchanged. Keeping this
scalar in the logarithm is useful for norm and truncation estimates.

One convenient numerical choice is kappa<=1/10, giving gap >= 39/50=0.78.
The stronger norm in (1), with the factor |S|, is essential to the supplied
commutator row-sum estimate. A bound on max_i sum_{S containing i}||K_S|| alone
does not establish (5) by this proof.

## Proof of the creation algebra and the kernel

For every i and S,

    [h_i,K_S] = 1[i in S] K_S.                            (6)

If supports S,T overlap, K_S K_T=K_T K_S=0 because at an overlapping index
the bra |0_i> is orthogonal to every component of the created ket. If supports
are disjoint, the operators commute. Thus all K_S commute, as do K and K_i.

The finite-dimensional operator K is nilpotent: a nonzero product requires
pairwise disjoint supports, so K^(|I|+1)=0. In particular exp(tK) is invertible.
Equation (6) and the vanishing of the second nested commutator give exactly

    exp(tK) h_i exp(-tK) = h_i-t K_i = Q_i(t).             (7)

The Q_i(t) therefore commute and are idempotents:

    [Q_i(t),Q_j(t)]=0,       Q_i(t)^2=Q_i(t).             (8)

The common kernel of the h_i is the one-dimensional span of |0>. Similarity
by exp(tK) and (7) identify the common kernel of all Q_i(t) as the span of (3).
Since H(t) is a sum of squares, its kernel is exactly that common kernel.

## A general commuting-idempotent inequality

For any finite family of commuting idempotents Q_i, not assumed Hermitian,
put H=sum_i Q_i^*Q_i. Directly commuting Q_i past Q_j^* yields

    H^2 = sum_{i,j} (Q_i Q_j)^*(Q_i Q_j)
          + sum_{i,j} Q_i^* [Q_i,Q_j^*] Q_j.              (9)

The diagonal terms in the first sum equal H, by idempotence, and its other
terms are positive. Let

    c_ij = ||[Q_i,Q_j^*]||op,
    eta = max_i sum_j c_ij.

The matrix c is symmetric because [Q_i,Q_j^*]^*=[Q_j,Q_i^*]. For an arbitrary
vector x, setting a_i=||Q_i x|| and using 2a_i a_j<=a_i^2+a_j^2 gives

    |sum_{i,j} <Q_i x,[Q_i,Q_j^*]Q_j x>|
       <= sum_{i,j} c_ij a_i a_j
       <= eta sum_i a_i^2
       = eta <x,Hx>.

Therefore, as an operator inequality,

    H^2 >= (1-eta) H.                                    (10)

This is the sole spectral argument: if Hx=lambda x with lambda>0, then
lambda^2 >= (1-eta)lambda. No global norm of the perturbation is used.

## Commutator row sum for the creation parent

Suppress t momentarily. By (6),

    [Q_i,Q_j^*]
       = sum_{S containing i,j} (K_S+K_S^*)
         + [K_i,K_j^*].                                  (11)

Terms K_S and K_T^* with disjoint supports commute. In all cases

    ||[K_S,K_T^*]|| <= 2||K_S||||K_T||.

Writing k_S=||K_S||, summing the linear part of (11) over j gives

    sum_j 2 sum_{S containing i,j} k_S
       = 2 sum_{S containing i}|S| k_S
       <= 2 kappa.                                      (12)

For the quadratic part, use the overlap union bound:

    sum_j ||[K_i,K_j^*]||
      <= 2 sum_{S containing i} k_S
               sum_{T: T intersects S} |T| k_T
      <= 2 sum_{S containing i} k_S
               sum_{x in S} sum_{T containing x} |T| k_T
      <= 2 kappa sum_{S containing i}|S| k_S
      <= 2 kappa^2.                                     (13)

Replacing every K_S by tK_S gives eta(t)<=2t kappa+2t^2 kappa^2. Combining
(10)--(13) proves (4)--(5).

## Locality and size of the resulting Hamiltonian

Expanding one summand in (2) gives

    Q_i(t)^*Q_i(t)
      = h_i - t(h_i K_i + K_i^* h_i) + t^2 K_i^*K_i
      = h_i - t(K_i+K_i^*) + t^2 K_i^*K_i.              (14)

Thus

    H(t) = sum_i h_i
           - t sum_S |S|(K_S+K_S^*)
           + t^2 sum_{S,T} |S intersects T| K_S^*K_T.    (15)

Only overlapping S,T contribute to the last sum. The supports are S and
S union T respectively. Exponential decay of K in a sufficiently strong
support-weighted interaction norm therefore gives a quasi-local H(t).
The gap proof itself uses only the weaker finite kappa in (1).

For example, if

    max_i sum_{S containing i} |S| exp(mu |S|) k_S <= c,

then the linear terms and the overlap products have finite exponentially
weighted interaction norm, with an additional harmless support-size moment
if the chosen definition counts every site of S union T. One should allocate
part of mu to absorb that polynomial factor rather than suppress it in a cost
bound. All these operator-norm statements remain independent of local dimension.

The Hamiltonian is generally not a finite-range canonical PEPS parent. It has
arbitrarily long creation tails when K does, which is how an exact tiny cat
branch can coexist with a unique gapped state without contradicting `s09.md`.
Truncating K at support size m produces a finite-support Hamiltonian with the
same gap estimate for its own normalized state exp(t K_{<=m})|0>; proving that
state close to the desired full state still needs a separate normalized-state
tail bound. Here a bound on ||K-K_{<=m}|| is already sufficient, because all
creation terms commute. Put delta=||K-K_{<=m}|| and v_m=exp(K_{<=m})|0>.
Then exp(K)|0>=exp(K-K_{<=m})v_m, and

    ||exp(K)|0>-v_m|| <= (exp(delta)-1)||v_m||.

If delta<log 2, normalizing the two vectors changes them by at most
2(exp(delta)-1) in Euclidean norm, and therefore by at most that amount in
pure-state trace distance. There is no factor exp(||K||). A derivation of an
operator-norm tail from the supplied tensor input remains a separate step.

## Explicit gap constant for root's connected-log estimates

Root supplies the following bounds from the Banach polymer construction;
this subsection verifies their conversion into the weighted norm (1), not
the upstream polymer proof. Set eta=4sqrt(q), and choose R with R eta<=1/64.
For every connected vertex set S of size s and coefficient order k>=s,
assume its connected log operator obeys

    ||K_{S,k}|| <= c s 2^(s-1) R^(-k),    c=log(5/4),

and is supported on at most 4s edge indices. Its decomposition into pure
creation support pieces has norm sum at most

    2^((4s)/2)||K_{S,k}|0>|| <= 4^s ||K_{S,k}||,

by orthogonality of different excitation supports and Cauchy--Schwarz.
Each piece has support size at most 4s. At most 2*16^(s-1) connected vertex
sets of size s touch a fixed edge. It follows, for every full or degree-truncated
creation logarithm satisfying those estimates, that

    kappa <= [c/(4(1-1/R))] sum_{s>=1} s^2 (128/R)^s.     (16)

The factor 1/4 is exactly
2*4/(16*2): the two choices of an endpoint of the fixed edge, the 4s support
weight, and the shifted powers in 16^(s-1) and 2^(s-1). No local dimension
factor occurs.

For R=512 and q<=2^(-34), R eta<=1/64. At x=128/R=1/4,

    sum_{s>=1} s^2 x^s = x(1+x)/(1-x)^3 = 20/27.

Consequently the right side of (16) is approximately 0.0414037466 and is less
than 0.042. Equations (4)--(5) then give a uniform gap larger than 0.9124,
and in particular larger than 0.91, along the entire path.

Scalar convention: retain the scalar identity coefficient in the full
logarithm and its degree truncations. For a connected coefficient A=K_{S,k},
decompose A|0> into orthogonal excitation-support sectors, including the empty
one. The sum of squared norms over **nonempty** sectors is at most
||A|0>||^2<=||A||^2. Their norm sum is therefore at most 4^s||A|| as used above.
The empty sector is excluded directly from kappa and automatically from
K_i=[h_i,K]. No subtraction of a scalar from A in operator norm is performed,
so there is no factor-two loss. Full exponentials may retain the scalar;
normalization removes it, and the commuting tail argument remains valid.

## Bounds for an implemented preparation path

Writing M=|I|, the same norm supplies simple dimension-independent bounds

    ||H(t)|| <= M(1+kappa)^2,
    ||H'(t)|| <= 2 M kappa(1+kappa),
    ||H''(t)|| <= 2 M kappa^2.                            (17)

Indeed ||K_i||<=kappa, ||Q_i(t)||<=1+kappa,
H'=-sum_i(K_i^*Q_i+Q_i^*K_i), and H''=2sum_i K_i^*K_i.
These bounds, the known initial product ground state, and the constant gap are
the quantitative spectral premises for an ordinary finite-dimensional
adiabatic preparation theorem. Efficient Hamiltonian access must still be
constructed and charged; (17) alone is not an implemented circuit.

If a finite coefficient approximation is represented by exact pure creation
operators on the same supports, its Q_i are still commuting idempotents. Its
gap therefore obeys the same theorem with its actual weighted norm, rather than
requiring a global O(1/M) perturbation bound to preserve the gap. For comparing
its state to the exact creation state, the commuting operator-tail bound above
applies once the total error in K is controlled.

## What is and is not closed

Closed here: the dimension-independent uniform gap and uniqueness of the
creation-parent path, conditional on a small kappa in (1). The proof has no
external theorem dependency beyond finite-dimensional spectral calculus.

Separate gates handled elsewhere: deriving K from the supplied average-defect
tensors with a sufficiently small explicit q; stable finite-bit evaluation and
coherent implementation of its terms; normalized truncation error; Hamiltonian
simulation cost; and a complete preparation algorithm with all costs charged.
The q=1/128 norm-FPRAS promise alone has not been shown to imply kappa<0.366.

This proof is compatible with the consensus obstruction: the latter excludes
unique eigenstates for strictly k-local Hamiltonians, while (15) may contain
exponentially weak terms spanning the entire connected system.
