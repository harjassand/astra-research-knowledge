"""Exact rational fixture for the explicit block-separability certificate."""
import json
import sympy as s

I = s.I
eye = s.eye(2)
X = s.Matrix([[1, I], [0, 1]])
A = (X + X.adjoint()) / 2
B = (X - X.adjoint()) / (2 * I)
t = s.Integer(2)
R = 6 * eye - 2 * t * eye

Pp = s.Matrix([[1, 1], [1, 1]]) / 2
Pm = s.Matrix([[1, -1], [-1, 1]]) / 2
Qp = s.Matrix([[1, -I], [I, 1]]) / 2
Qm = s.Matrix([[1, I], [-I, 1]]) / 2
E0 = s.diag(1, 0)
E1 = s.diag(0, 1)
terms = [
    (E0, R), (E1, R),
    (Pp, t * eye + A), (Pm, t * eye - A),
    (Qm, t * eye + B), (Qp, t * eye - B),
]
actual = s.zeros(4)
for P, C in terms:
    actual += s.kronecker_product(P, C)
target = (6 * eye).row_join(X).col_join(X.adjoint().row_join(6 * eye))
assert actual == target
assert X * X.adjoint() != X.adjoint() * X
determinants = []
for P, C in terms:
    assert P == P.adjoint() and P.trace() == 1 and P.det() == 0
    assert P[0, 0] >= 0 and P[1, 1] >= 0
    assert C == C.adjoint()
    assert C[0, 0] > 0 and C[1, 1] > 0 and C.det() > 0
    determinants.append(str(C.det()))
print(json.dumps({
    "exact_reconstruction": True,
    "nonnormal_offblock": True,
    "product_term_count": len(terms),
    "tail_determinants": determinants,
    "all_factors_psd_by_exact_2x2_minors": True,
}, indent=2))
