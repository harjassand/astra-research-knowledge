#!/usr/bin/env python3
"""Finite exact diagnostics for s11_quantum_constraints.md, not a proof."""
from fractions import Fraction as Q
from pathlib import Path
import json
import math


def matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


def add(a, b, sign=1):
    return [[x + sign*y for x, y in zip(ar, br)]
            for ar, br in zip(a, b)]


def scale(a, x):
    return [[x*y for y in row] for row in a]


def outer(a, b):
    return [[x*y for y in b] for x in a]


def transpose(a):
    return list(map(list, zip(*a)))


def power(a, n):
    result = [[Q(int(i == j)) for j in range(len(a))]
              for i in range(len(a))]
    for _ in range(n):
        result = matmul(result, a)
    return result


def frob2(a):
    return sum(x*x for row in a for x in row)


def trace(a):
    return sum(a[i][i] for i in range(len(a)))


I = [[Q(1), Q(0)], [Q(0), Q(1)]]
P = [[Q(1), Q(0)], [Q(0), Q(0)]]  # u,w basis
checks = []
fixtures = []
for bits in (2, 4, 8, 12):
    t = Q(1, 2**bits)
    c = (1-t*t)/(1+t*t)
    s = 2*t/(1+t*t)
    assert c*c+s*s == 1
    v = [c, s]
    g = [-s, c]
    projector_q = outer(v, v)
    assert matmul(projector_q, projector_q) == projector_q
    assert matmul(P, P) == P
    commutator = add(matmul(P, projector_q), matmul(projector_q, P), -1)
    assert frob2(commutator) > 0
    # Rational computational-basis block on |00>,|11>.
    qc = [[(c+s)**2/2, (c+s)*(c-s)/2],
          [(c+s)*(c-s)/2, (c-s)**2/2]]
    pc = [[Q(1, 2), Q(1, 2)], [Q(1, 2), Q(1, 2)]]
    assert matmul(qc, qc) == qc
    assert trace(qc) == 1
    assert matmul(pc, pc) == pc
    assert (c+s)*(c-s) != 0  # Schmidt rank two.
    h = add(P, projector_q)
    assert trace(h) == 2
    assert h[0][0]*h[1][1]-h[0][1]*h[1][0] == (1-c)*(1+c)
    assert 1-c == 2*t*t/(1+t*t)
    mobius = add(h, I, -1)
    assert matmul(mobius, mobius) == scale(I, c*c)
    assert frob2(mobius) == 2*c*c
    F = matmul(add(I, projector_q, -1), add(I, P, -1))
    assert F == scale(outer(g, [Q(0), Q(1)]), c)
    pair_product = matmul(projector_q, P)
    pair_cases = []
    for repetitions in (1, 2, 5, 17):
        expected = scale(outer(g, [Q(0), Q(1)]), c**(2*repetitions-1))
        actual = power(F, repetitions)
        assert actual == expected
        assert frob2(actual) == c**(4*repetitions-2)
        expected_bad = scale(outer(v, [Q(1), Q(0)]),
                             c**(2*repetitions-1))
        assert power(pair_product, repetitions) == expected_bad
        sigma2 = c**(4*repetitions-2)
        for d in (2, 3, 5):
            local_dim = d*d
            gadgets = local_dim-2
            norm2 = Q(local_dim-2) + sigma2
            ground_overlap2 = Q(local_dim-2)/norm2
            distance2 = 1-ground_overlap2**gadgets
            energy = gadgets*sigma2*s*s/(gadgets+sigma2)
            assert 0 < distance2 < 1
            assert energy <= 4*t*t
            if repetitions <= 1/(16*t*t):
                assert sigma2 >= Q(1, 2)
                assert distance2 >= Q(9, 25)
        pair_cases.append({
            "T": repetitions,
            "sigma_squared": float(sigma2),
            "purification_trace_distance_d3_M7":
                math.sqrt(1-(1+float(sigma2)/7)**(-7)),
            "physical_ground_distance_d3_M7":
                1-(1+float(sigma2)/7)**(-7),
        })
    fixtures.append({
        "B": bits,
        "gap_exact": str(1-c),
        "gap_float": float(1-c),
        "mandatory_T_for_purification_error_half_lower_bound": 4**bits/16,
        "max_nonzero_entry_numerator_bits":
            max(abs(x.numerator).bit_length() for row in qc for x in row),
        "max_nonzero_entry_denominator_bits":
            max(x.denominator.bit_length() for row in qc for x in row),
        "passes": pair_cases,
    })

constant_checks = []
c0 = math.log(1.25)
for k in range(1, 7):
    for participation in range(1, 7):
        for degree in range(1, 13):
            a = 2**math.ceil(k/2)
            b = 4*degree
            radius = 128*b*a*participation*k
            beta = Q(1, 10)*Q(4, 5)**(degree+1)/(degree+1)
            deletion_bound = (
                beta*Q(4, 5)**(-degree)
                /(1-b*beta*Q(4, 5)**(-(degree+1))))
            assert deletion_bound < Q(1, 5)
            x = 2*b*a/radius
            series = x*(1+x)/(1-x)**3
            kappa = participation*k*c0/(2*b*(1-1/radius))*series
            assert kappa < .01
            constant_checks.append(kappa)

report = {
    "status": "all finite exact gadget assertions passed",
    "scope": "finite diagnostic; general statements use the accompanying proof",
    "gadget_fixtures": fixtures,
    "fixed_pass_constant_grid_count": len(constant_checks),
    "maximum_kappa_bound_on_grid": max(constant_checks),
    "minimum_alternative_parent_gap_bound_on_grid":
        1-2*max(constant_checks)-2*max(constant_checks)**2,
    "checks": [
        "exact rank-one projectors in u,w and computational bases",
        "nonzero exact commutator and Schmidt-rank-two bad vectors",
        "exact original gap determinant and trace identities",
        "exact alternating-filter power formula",
        "exact repeated bad-word formula",
        "exact connected Mobius correction norm",
        "constant global ground-distance and exponentially small energy",
        "finite-pass deletion and creation-interaction constants",
    ],
}
destination = Path(__file__).with_suffix(".json")
destination.write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps({"status": report["status"],
                  "fixtures": len(fixtures),
                  "constant_grid": len(constant_checks),
                  "maximum_kappa_bound": max(constant_checks),
                  "output": str(destination)}, indent=2))
