"""Finite numerical falsification of the block separability identity, not a proof.

Conventions: CN(0,1) has real/imaginary variance 1/2; W=G G*, no
trace normalization. The first subsystem labels contiguous b-by-b blocks.
"""
import json
from pathlib import Path
import numpy as np


def certificate(w, a, b):
    terms = []
    burden = np.zeros(a)
    for i in range(a):
        for j in range(i + 1, a):
            c = w[i*b:(i+1)*b, j*b:(j+1)*b]
            h = (c + c.conj().T) / 2
            k = (c - c.conj().T) / (2j)
            for matrix, phase in [(h, 1), (k, -1j)]:
                t = float(np.max(np.abs(np.linalg.eigvalsh(matrix))))
                t = np.nextafter(t, np.inf)
                burden[i] += t
                burden[j] += t
                for sign in [-1, 1]:
                    v = np.zeros(a, complex)
                    v[i], v[j] = 1, sign * phase
                    p = np.outer(v, v.conj()) / 2
                    terms.append((p, t*np.eye(b) + sign*matrix))
    residuals = []
    for i in range(a):
        p = np.zeros((a, a), complex)
        p[i, i] = 1
        r = w[i*b:(i+1)*b, i*b:(i+1)*b] - burden[i]*np.eye(b)
        residuals.append(r)
        terms.append((p, r))
    rebuilt = sum((np.kron(p, r) for p, r in terms), np.zeros_like(w))
    return {
        'relative_reconstruction_error': float(np.linalg.norm(rebuilt-w)/np.linalg.norm(w)),
        'min_residual_eigenvalue': min(float(np.linalg.eigvalsh(r).min()) for r in residuals),
        'min_factor_eigenvalue': min(float(np.linalg.eigvalsh(r).min()) for _,r in terms),
        'num_terms': len(terms),
        'diagonal_burden': burden.tolist(),
        'partial_transpose_min_eigenvalue': float(np.linalg.eigvalsh(w.reshape(a,b,a,b).transpose(2,1,0,3).reshape(a*b,a*b)).min()),
    }


def main():
    rng = np.random.default_rng(20261011)
    records = []
    for a,b in [(2,2),(3,3),(4,4),(2,8),(3,12)]:
        for ratio in [0.25,1,4,16]:
            s = max(1,int(ratio*a*a*b))
            g = (rng.normal(size=(a*b,s))+1j*rng.normal(size=(a*b,s)))/np.sqrt(2)
            w = g@g.conj().T
            row = {'a':a,'b':b,'environment':s,'s_over_a2b':ratio,**certificate(w,a,b)}
            assert row['relative_reconstruction_error'] < 1e-12
            if row['min_residual_eigenvalue'] > 1e-8:
                assert row['partial_transpose_min_eigenvalue'] > -1e-8
            records.append(row)
    out=Path(__file__).with_name('block_certificate_results.json')
    out.write_text(json.dumps({'scope':'Finite floating-point identity and falsification checks only; no general proof, novelty or certified PSD claim.','seed':20261011,'records':records},indent=2)+'\n')
    print(json.dumps({'cases':len(records),'max_relative_reconstruction_error':max(r['relative_reconstruction_error'] for r in records),'positive_residual_cases':sum(r['min_residual_eigenvalue']>0 for r in records),'output':str(out)}))


if __name__=='__main__': main()
