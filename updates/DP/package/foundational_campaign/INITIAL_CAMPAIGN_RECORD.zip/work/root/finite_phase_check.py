"""Exhaustive finite-phase diagnostics; Gaussian-integer arithmetic throughout.

These fixtures test conjugation and moments, not the general theorem or novelty.
Run with Python 3; no external dependencies.
"""
from itertools import product
from fractions import Fraction as F
from pathlib import Path
import json

def add(a, b): return (a[0] + b[0], a[1] + b[1])
def mul(a, b): return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])
def conj(a): return (a[0], -a[1])
def norm(a): return a[0]*a[0]+a[1]*a[1]
def dot(a, b):
    out = (0, 0)
    for x, y in zip(a, b): out = add(out, mul(x, y))
    return out

phases = ((1, 0), (-1, 0), (0, 1), (0, -1))
vectors = list(product(phases, repeat=4))
# H=|1,i><1,i|/512 and K=|1,1+i><1,1+i|/768.
# Both have sole nonzero eigenvalue 1/256, hence meet the degree-one promise.
A = ((1, 0), (0, -1), (0, 1), (1, 0))
B = ((1, 0), (1, -1), (1, 1), (2, 0))
den = 2*512*768
sum_y, sum_y2 = (0, 0), 0
for x in vectors:
    y = mul(dot(A, x), dot(B, tuple(map(conj, x))))
    sum_y = add(sum_y, y)
    sum_y2 += norm(y)
exact = dot(A, B)
wrong = dot(tuple(map(conj, A)), B)
assert sum_y == (256*exact[0], 256*exact[1])
assert exact == (1, 0) and wrong == (5, 0)
mean = F(sum_y[0], 256*den)
second = F(sum_y2, 256*den*den)
q2 = F(1, 2*256**2)
assert second <= 2*q2*q2

# A fully coupled two-edge local tensor, with complex integer entries.
T = [[((3*i + 2*j + 1) % 5 - 2, (i + 4*j + 2) % 5 - 2)
      for j in range(4)] for i in range(4)]
tf2 = sum(norm(t) for row in T for t in row)
s2 = s4 = 0
for x in vectors:
    row_eval = [dot(row, x) for row in T]
    for y in vectors:
        val = dot(row_eval, y)
        n = norm(val)
        s2 += n
        s4 += n*n
assert F(s2, 256**2) == tf2
fourth = F(s4, 256**2)
assert fourth <= 4*tf2*tf2

result = {
    'status': 'exact finite fixtures passed; not a general proof',
    'two_vertex_phase_vectors': len(vectors),
    'two_vertex_expectation': str(mean),
    'wrong_endpoint_conjugation_multiplier': 5,
    'two_vertex_second_moment': str(second),
    'two_vertex_second_moment_bound': str(2*q2*q2),
    'coupled_local_phase_pairs': 256**2,
    'local_second_moment': tf2,
    'local_fourth_moment': str(fourth),
    'local_fourth_moment_bound': 4*tf2*tf2,
}
Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
