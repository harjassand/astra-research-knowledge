"""Exact diagnostic for the rare-defect candidate; not a general theorem.

Six active rank-one holes lie in a 2x3 rectangle inside an identity boundary.
A=|0><0| on the left leg; B=|GHZ_D><GHZ_D| on up/right/down.
W=I-A tensor B is a rational projection and has an exact zero eigenvalue.
All boundary vertices outside the rectangle are identities. Identity-network
normalization is one. No dense D^4-by-D^4 matrix is materialized.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json

D = 12
ROWS, COLS = 2, 3
N = ROWS * COLS
ORDER = 12
vertices = list(range(N))
edges = [(i, j) for i in vertices for j in vertices if i < j
         and abs(i // COLS-j // COLS)+abs(i % COLS-j % COLS) == 1]


def members(mask):
    return [i for i in vertices if mask >> i & 1]


def subsets(mask):
    sub = mask
    while True:
        yield sub
        if sub == 0:
            break
        sub = (sub-1) & mask


def components(mask, vertical_only=False):
    remaining, result = set(members(mask)), []
    while remaining:
        todo = [remaining.pop()]
        comp = set(todo)
        while todo:
            i = todo.pop()
            near = [j for j in remaining if
                    abs(i // COLS-j // COLS)+abs(i % COLS-j % COLS) == 1
                    and (not vertical_only or i % COLS == j % COLS)]
            for j in near:
                remaining.remove(j)
                comp.add(j)
                todo.append(j)
        result.append(comp)
    return result


def moment(mask):
    """Direct delta-index contraction of these particular GHZ projectors.

    A vertical component has one free GHZ index unless one of its right
    neighbors is active, in which case the neighbor's left |0> fixes it.
    Exterior identity legs force equal bra/ket indices. Each active H has
    coefficient 1/D, and each touched normalized Bell edge contributes1/D.
    """
    active = set(members(mask))
    k = len(active)
    if not k:
        return F(1)
    internal = sum(i in active and j in active for i, j in edges)
    free = sum(not any(i % COLS < COLS-1 and i+1 in active for i in comp)
               for comp in components(mask, vertical_only=True))
    return F(D) ** (-5*k+internal+free)


def log_series(z, order):
    z = z + [F(0)] * (order+1-len(z))
    out = [F(0)] * (order+1)
    for n in range(1, order+1):
        out[n] = z[n] - sum((F(i)*out[i]*z[n-i] for i in range(1, n)), F(0))/n
    return out


moments = {s: moment(s) for s in range(1 << N)}
logs = {}
for s in range(1 << N):
    coeff = [F(0)] * (N+1)
    for t in subsets(s):
        coeff[t.bit_count()] += (-1)**t.bit_count() * moments[t]
    logs[s] = log_series(coeff, ORDER)

mobius = {}
for s in range(1 << N):
    mobius[s] = [sum((-1)**(s.bit_count()-t.bit_count()) * logs[t][k]
                    for t in subsets(s)) for k in range(ORDER+1)]
    if len(components(s)) > 1:
        assert all(x == 0 for x in mobius[s])
    for k in range(min(s.bit_count(), ORDER+1)):
        assert mobius[s][k] == 0

full = (1 << N)-1
for k in range(1, ORDER+1):
    reconstructed = sum(mobius[s][k] for s in range(1 << N)
                        if len(components(s)) == 1 and s.bit_count() <= k)
    assert reconstructed == logs[full][k]

for s, value in moments.items():
    assert 0 <= value <= F(1, D*D)**s.bit_count()
    product = F(1)
    for comp in components(s):
        product *= moments[sum(1 << i for i in comp)]
    assert product == value

# Independent exact 2x2 closed expression, including its first loop term.
square = (1 << 0) | (1 << 1) | (1 << COLS) | (1 << (COLS+1))
z_square = sum((-1)**t.bit_count() * moments[t] for t in subsets(square))
p = F(1, D**4)
assert z_square == (1-p)**4 + (D-1)*p**4
z = sum((-1)**t.bit_count() * moments[t] for t in subsets(full))
assert z > 0

result = {
    'scope': 'Exact finite diagnostic only; not a proof of the general FPTAS or novelty.',
    'D': D, 'active_vertices': N, 'subsets': 1 << N, 'formal_orders_checked': ORDER,
    'checks': ['component factorization', 'Finner bound', 'disconnected Mobius cancellation',
               'support-degree cancellation', 'connected-support log reconstruction',
               'independent 2x2 loop formula'],
    'q': str(F(1, D*D)), 'Z_exact': str(z), 'Z_decimal': float(z),
    'square_Z_exact': str(z_square), 'largest_required_matrix_dimension': 0,
}
output = Path(__file__).with_name('rare_defect_check.json')
output.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
