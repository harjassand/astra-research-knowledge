# CRAY non-Gaussian local design certificate

Start with `RESEARCH_NOTE.md`. The central result is finite-temperature, measurement-assisted, and restricted to local diagonal interventions. It is not a global ground-state solver or a validated material prediction.

## Contents

- `certificates.py`: numerical histogram/LP certificates and small helper routines.
- `run_diagnostics.py`: 640 random enclosure checks and a fixed-sector eight-site Hubbard validation, including simulated label counts.
- `kinetic_budget_checks.py`: 150 checks of the measured kinetic-energy improvement.
- `exact_fixture.py`: exact rational verification of the conditional statistical sign certificate.
- `diagnostics.json`, `kinetic_checks.json`, `exact_certificate.json`: recorded outputs.
- `CHECKPOINT.md`: precise continuation obligations and exclusions.
- `MANIFEST.json`: SHA-256 file hashes, excluding the manifest itself.

## Run

Python with NumPy and SciPy is required for numerical checks. The exact verifier uses only the Python standard library.

```sh
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python run_diagnostics.py
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python kinetic_budget_checks.py
python exact_fixture.py
```

Floating-point output is not automatically a rigorous numerical certificate. The exact verifier is conditional on the stated Gibbs-sampling, sector, calibration and intervention assumptions. Its input counts were simulated, not measured in a laboratory. Timing numbers are environment-dependent; regenerated JSON may differ in final floating digits and wall-clock time.
