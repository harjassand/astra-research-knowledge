# Electronic pressure isolation between sealed neutral-liquid ports

Date: 14 October 2026
Status: candidate physical composition; conditional linear-response derivations; executed algebraic/network checks. No physical device was built or measured. Historical novelty is unresolved. No Astra repository theorem is a premise.

## 1. Proposed capability and physical gate

Connect two spatially and chemically isolated liquid-flow interfaces to a passive, nonreciprocal electrical network. The target is a pressure-to-flow cross-response that differs on exchanging donor and receiver, with negligible reverse response in a chiral limit. No material is transported between the liquids. Source hydraulic work, not the static magnetic field, supplies any output work.

The wet interfaces must exhibit **unbiased, near-equilibrium, reciprocal coupling between neutral-liquid flow and terminal electronic current**. Flow-induced currents have experimental precedents, including a zero-longitudinal-bias, back-gated glycerol/graphene control. These precedents do not supply measured, bidirectional DC coefficients for the proposed devices. High coupling cannot be inferred from a slip length, an electron-cooling rate, or a large current measured under electrical bias.

The electrical network must be characterized at its actual terminals and operating frequency. A bulk Hall conductivity tensor is not its terminal admittance. A microwave Hall circulator is not evidence of efficient DC transfer.

## 2. Definitions and assumptions

For wet port i, p_i is pressure drop (Pa), Q_i volumetric flow (m^3/s), V_i terminal voltage (V), and I_i current entering the wet transducer (A). Sign conventions make p_i Q_i+V_i I_i power entering the transducer.

At a fixed temperature and fixed electrostatic gate setting, with no magnetic field at the wet interface, assume a measured linear constitutive law

    Q_i = K_i p_i + C_i V_i
    I_i = C_i p_i + G_i V_i.

Here K_i>0, G_i>0 and C_i^2<K_i G_i. The equality of cross-coefficients is an Onsager hypothesis to be experimentally checked in the selected operating regime. A biased nonlinear current response is not sufficient. Coefficients include the actual device's hydraulic, electronic and contact losses under the stated boundary conditions.

For N independent wet devices let K,C,G be the corresponding diagonal matrices. A passive electrical load has currents I=-Y V, where sym(Y) is positive semidefinite. The load must include its contacts, wiring, shunts and electrical reference terminal.

These assumptions describe a quasistatic lumped network. They do not imply arbitrary bandwidth, favorable material constants, room-temperature ideal chirality, or indefinitely stable interfaces.

## 3. Exact elimination and nonreciprocity transfer

Set A=G+Y. Its symmetric part is positive definite, so A is invertible. Eliminating terminal voltages gives

    V = -A^{-1} C p
    Q = H p
    H = K - C A^{-1} C.

The antisymmetric part satisfies

    H-H^T = C A^{-T} (Y-Y^T) A^{-1} C.

Proof: subtract H^T and use

    A^{-T}-A^{-1} = A^{-T}(A-A^T)A^{-1}.

If every C_i is nonzero, this is an invertible congruence. Consequently

    rank(H-H^T) = rank(Y-Y^T).

This is a statement about existence and rank, not useful signal amplitude. Cross-responses vanish quadratically as the wet couplings become small. A reciprocal electrical network cannot create nonreciprocity in these reciprocal wet devices.

If Y(-B)=Y(B)^T while wet coefficients remain unchanged by reversing the remote magnetic field, then

    H(-B)=H(B)^T.

### Passivity and conservation

The total hydraulic input is

    p^T Q = sum_i [p_i Q_i + V_i I_i] + V^T Y V >= 0.

The first term is wet-device dissipation, the second electrical-network dissipation. Antisymmetric response does not supply work. A static magnetic field is a time-reversal-breaking resource, not an energy source. Maintaining a cryogenic or electromagnetic environment still incurs external power that must be charged separately. If a cold Hall device is connected to warm wet interfaces, thermoelectric offsets and heat currents become additional ports. The isothermal efficiency ceiling cannot be applied unmodified if that temperature gradient supplies work.

For positive hydraulic compliance matrix S and unforced dynamics S dp/dt=-H p,

    E=p^T S p/2,
    dE/dt=-p^T sym(H) p <= 0.

This establishes stability in the stated quasistatic compliant model. At finite frequency, one must instead measure the full causal, positive-real response, including fluid inertia, capacitance, ionic relaxation and delays.

## 4. Contact-explicit chiral implementation

A three-contact chiral electrical conductor, with its third contact at the electrical reference potential, has the idealized terminal law

    Y = [[g_+ + g_-, -g_-],
         [-g_+, g_+ + g_-]],       g_+,g_- >= 0.

This is a contact-inclusive forward/backward transmission model, not a lossless gyrator. Its symmetric part is positive semidefinite. Reversing the magnetic field interchanges g_+ and g_-. The ideal chiral limit is g_-=0.

For two possibly unequal wet devices, exact elimination gives

    H_21/H_12 = g_+/g_-             (when the denominator is nonzero).

Thus directional contrast is inherited even with unequal wet conductances. The actual signal strength is not protected. In the ideal chiral limit H_12=0 while H_21 is nonzero if C_1 C_2 is nonzero. A change in receiver back-pressure then has no linear effect on donor flow. This is not a claim that thermal noise, substrate vibration, or nonlinear back-action disappear.

With g_-=0 and g_+=g, write a_i=G_i+g. The diagonal hydraulic conductances are

    kappa_i = K_i - C_i^2/a_i,

and the magnitude of the forward cross-coefficient is

    b = |C_1 C_2| g/(a_1 a_2).

After a harmless reversal of the receiver's hydraulic coordinate orientation,

    H = [[kappa_1, 0], [b, kappa_2]].

## 5. Sharp work-transfer bound for this implementation

Drive p_1 and connect the receiver to a passive hydraulic resistance R, so p_2=-R Q_2. Then

    Q_1=kappa_1 p_1,
    Q_2=b p_1/(1+kappa_2 R),
    eta(R)=R Q_2^2/(p_1 Q_1).

The maximum over R is attained at R=1/kappa_2, yielding

    eta_load,max = b^2/(4 kappa_1 kappa_2).

Define the measured whole-device coupling quantities

    chi_i = C_i^2/(K_i G_i),
    Z_i = chi_i/(1-chi_i),
    t_i = g/G_i.

Then

    b^2/(kappa_1 kappa_2)
      = product_i [chi_i t_i/((1+t_i)(1+t_i-chi_i))].

For 0<chi<1 the factor

    f(t)=chi t/((1+t)(1+t-chi))

has derivative with the sign of (1-chi)-t^2. Its unique maximum is at t=sqrt(1-chi), where

    f_max = (1-sqrt(1-chi))/(1+sqrt(1-chi))
          = (sqrt(1+Z)-1)/(sqrt(1+Z)+1)
          =: eta_c(Z).

Therefore

    eta_isolator <= eta_c(Z_1) eta_c(Z_2)/4 <= 1/4.

The first inequality is attainable within the model when both electrical matching conditions can be realized and the output hydraulic load is optimized. A fabricated pair may not permit simultaneous matching. For identical devices the bound is eta_c(Z)^2/4.

**Scope:** this is a ceiling for this specific contact-inclusive, grounded three-contact, quasistatic topology. It is not a universal 25% bound on all nonreciprocal transducers, active devices, hydraulic isolators, or finite-frequency circuits.

Conditional numerical benchmarks:

| Z for each wet transducer | Single-converter eta_c | Ideal chiral isolator eta_max |
|---:|---:|---:|
| 0.0004 | 0.0000999800 | 2.49900e-9 |
| 1 | 0.171573 | 0.00735931 |
| 11 | 0.551982 | 0.0761709 |
| 100 | 0.819002 | 0.167691 |
| 1000 | 0.938723 | 0.220300 |
| limit infinity | 1 | 0.25 |

The Z=0.0004 and Z=11 entries are conditional uses of published theoretical graphene/graphitic estimates, not measured complete transducers. Other finite entries are hypothetical dimensionless inputs. No material is asserted to achieve them.

## 6. Tempting but misleading lossless-Hall variant

For identical wet devices and an electrical two-port Y=d I+h J, with J=[[0,-1],[1,0]],

    H=kappa I+gamma J,
    kappa=K-C^2(G+d)/((G+d)^2+h^2),
    gamma=C^2 h/((G+d)^2+h^2).

An ideal lossless electrical gyrator d=0 would permit

    max |gamma|/kappa = Z/(2 sqrt(1+Z)),
    max eta_work_transfer = eta_c(Z)^2.

The hydraulic off-diagonal responses have opposite signs but equal magnitudes: this is a gyrator, not an isolator. Ordinary ohmically contacted Hall plates do not become lossless terminal gyrators merely because bulk longitudinal conductivity approaches zero. Known contact-loss obstructions invalidate the naive efficient-DC-machine interpretation. Capacitive Hall coupling changes the finite-frequency problem, not the DC conclusion.

## 7. Decisive experimental sequence

1. Fabricate and characterize two isolated liquid/electronic interfaces. Keep metal contact pads out of the liquid. Hold gate charge or voltage fixed; measure gate leakage and all supplied power. Measure K,C,G in both reciprocal directions near zero longitudinal electrical bias. Obtain a steady pressure-driven signal after charging transients, not only an oscillating droplet signal.
2. Bound ionic streaming, electrode chemistry, temperature gradients, contact electrification, strain-dependent conductance and displacement-current artifacts. Nominally pure water alone does not establish an ion-independent mechanism. Record electrical conductivity, leakage, temperature and fluid composition; use suitably matched insulating-interface controls and at least one low-conductivity nonaqueous liquid where feasible.
3. Independently measure the dry network's full terminal Y(B,omega), including its reference contact and wiring. Begin with a room-temperature lossy Hall element for a finite asymmetry demonstration. Near-perfect quantum-Hall chirality may be useful for a physics test, but its magnetic and refrigeration costs preclude treating it as an efficient installed machine without further evidence.
4. Predict H from the component measurements before connecting the devices. Test donor/receiver interchange, magnetic-field reversal, open wiring, reciprocal electrical substitutions, and circuit-load sweeps. In the two-transmission model, test the hydraulic/electrical asymmetry-ratio identity.
5. Load the receiver and measure delivered work -p_2 Q_2 simultaneously with p_1 Q_1 and every external power supply. Check the calculated efficiency ceiling. A signal exceeding it indicates an omitted source, invalid constitutive assumptions, or measurement error rather than extra free energy.

Confirmation would establish the composed transduction operation. It would not uniquely identify quantum friction rather than another reciprocal microscopic coupling. Identifying the microscopic mediator requires additional discriminating measurements.

## 8. Scaling and interpretation

A dimensionless coupling figure does not determine throughput. K_i and C_i must be acquired for a real device. Parallel replication of N identical wet channels multiplies K,C,G by N and leaves chi and Z unchanged. Without corresponding circuit-impedance scaling, even that replication does not preserve matching. It cannot remove the conversion-efficiency ceiling.

For sufficiently wide/slender slit channels in a continuum regime, the usual estimate is

    K_geom = N w h^3/(12 mu L) * (1+6 b_slip/h).

This is an estimate under a specified slip boundary condition, not a substitute for the coupled K in the measured transport law. It fails when entrance resistance, channel deformation, molecular layering, fouling or noncontinuum response dominates. The small confinement favorable to interfacial momentum transfer can simultaneously suppress throughput.

The full system energy boundary must include the source pump when used, electrical contacts, hydraulic manifolds, gate preparation/leakage, refrigeration, field generation, controls, cleaning and component recovery. Actual interface lifetime, drift, fabrication yield, chemical compatibility and maintenance are unmeasured.

Bulk pressure recovery is not a defensible near-term target: the derived DC limits compare poorly with established high-efficiency pressure exchangers. The possible distinctive use is passive, electrically reconfigurable back-pressure isolation or coupling among chemically isolated neutral-liquid nanofluidic units. Its superiority over conventional pump/valve control has not been established. Civilisation-scale significance remains a conditional aspiration, not a result of this calculation.

## 9. Reproducibility and provenance

`check_model.py` performs six groups of exact symbolic checks, 1,000 random four-port passive-network diagnostics, and a 40,804-point matching-grid check. `model_checks.json` contains the executed results. These computations test the declared network equations only. They do not constitute a fluid/material simulation, an independent proof audit, or experimental validation.

Selected primary-source anchors (bibliographic identifiers):

- Lizée et al., *Strong Electronic Winds Blowing under Liquid Flows on Carbon Surfaces*, Physical Review X 13, 011020 (2023), DOI 10.1103/PhysRevX.13.011020. Figure 4(f): glycerol/graphene current at zero longitudinal bias with a 10 V back gate.
- Coquinot, Bocquet and Kavokine, *Hydroelectric energy conversion of waste flows through hydroelectronic drag*, PNAS 121, e2411613121 (2024), DOI 10.1073/pnas.2411613121; arXiv:2403.20209v2. Coupled transport, reciprocal pumping proposal, and theoretical material estimates.
- Coquinot et al., *Momentum tunnelling between nanoscale liquid flows*, arXiv:2501.01253. Prior theory/simulation of solid-mediated liquid coupling; not this remote electrical topology.
- Viola and DiVincenzo, *Hall Effect Gyrators and Circulators*, Physical Review X 4, 021019 (2014), DOI 10.1103/PhysRevX.4.021019; arXiv:1312.5190v3. Contact losses and finite-frequency reactive alternatives.
- Büttiker, *Absence of backscattering in the quantum Hall effect in multiprobe conductors*, Physical Review B 38, 9375 (1988), DOI 10.1103/PhysRevB.38.9375. Multiprobe chiral transport framework.
- Mahoney et al., *On-Chip Microwave Quantum Hall Circulator*, Physical Review X 7, 011007 (2017), DOI 10.1103/PhysRevX.7.011007. Experimental microwave device; not a DC efficiency precedent.
- Keerthi et al., *Water friction in nanofluidic channels made from two-dimensional crystals*, Nature Communications 12, 3092 (2021), DOI 10.1038/s41467-021-23325-3. Fabricated slit geometries, slip variability and noncontinuum qualifications.
- Winn et al., *Unidirectional flow from continuous broken symmetries*, arXiv:2603.27474 (2026). Experimentally grounded nonlinear soft-valve alternative.
- Energy Recovery, *PX Q400 Product Brochure* (November 2024). Manufacturer-specified bulk comparator, not independently reproduced performance in this investigation.

No novelty claim is made for Onsager reciprocity, gyrators, quantum Hall chirality, hydraulic pressure exchange, standard network elimination, or their mathematical analogies. The candidate originality is the specific stationary-interface, neutral-liquid, remote electronic composition and its experimentally testable operating contract. The literature search did not establish historical priority.
