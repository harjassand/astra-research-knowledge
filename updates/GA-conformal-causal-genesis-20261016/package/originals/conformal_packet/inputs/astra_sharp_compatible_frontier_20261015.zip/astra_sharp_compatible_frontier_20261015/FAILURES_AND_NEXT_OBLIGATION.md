# Failed approaches and the next exact obligation

## Failures preserved without overinterpretation

The scalar-only six-dimensional invariant representation failed at the sharp endpoint in exploration. This did not establish failure of full corrected-heat positivity. Including the tensor bilinear coordinates and both acoustic-contact jets produced the exact universal certificate now supplied.

The fixed isotropic-metric endpoint search at r=-5/2 did not produce a positive matrix. This is not asserted to be a universal isotropic-heat impossibility. The adapted positive metric diag(-(2r+1)/3,1), derived from the two-contact symmetry, worked.

A positive-branch search at r=2 with the positive adapted metric diag((2r+1)/3,1) did not produce a PSD matrix in the chosen support. Its large ADMM residual and negative floating eigenvalues are not exact infeasibility certificates. They do not imply non-QC.

A finite Fourier search at r=-5/2 found no negative optimized compatible energy. It is not evidence for the universal theorem and was abandoned as a proof route. The accepted theorem instead has an all-variable exact identity and analytic heat proof.

An initial development version of the standalone verifier used the wrong sign in a two-by-two congruence matrix. The failing assertion and corrected development record are retained. The final congruence is [[1,1],[0,-1]], verified by direct multiplication. This was a verifier transcription correction, not a change to the theorem or the universal heat identity. All final groups pass.

## Sharp remaining mathematical obligation

For every r>0, the polynomial

    J_r = (3*r/(8*(r+2)))*H + (r*(r-1)/6)*u^2 + j^2 + r*u*j

is independently proved rank-one convex and non-polyconvex. Its acoustic determinant is 9*r^4*n^4*m^4. Its contacts have opposite determinant signs. Its QC status is not decided here.

Proving the all-background inequality for every such J_r would, by the exact three-term decomposition in the report, prove ROC=QC on the entire four-dimensional shear-contact face. Constructing an actual compatible perturbation with rigorously negative energy for one J_r would instead be a genuine planar counterexample. Merely raising alpha or changing another finite Gram search does not answer the question.

General non-trace-free invertible contacts, nontrivial singular-background strata, and the full nine-coefficient QC cone remain outside this classification. Sol's distinct exposed ray remains a separate PC/QC problem.

## No incorrect transfers

The sharp endpoint does not permit any positive H subtraction; it therefore does not inherit the old elliptic-subtraction margin at that endpoint. Positive definiteness of a reduced Gram does not imply positive quadratic acoustic curvature. Whether a separate pure fourth-order Jensen margin holds for the sharp core is not decided.

The nonspectrahedrality corollary concerns a direct finite LMI description of the ROC cone in the nine coefficients, without auxiliary variables. It does not exclude a semidefinite lift and does not classify the QC cone.
