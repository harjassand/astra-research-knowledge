import sympy as s,pickle,itertools,numpy as np,sys
from pathlib import Path
out=Path('/mnt/data/sharp_frontier');r=s.Rational(sys.argv[1]) if len(sys.argv)>1 else -s.Rational(5,2)
a,b,c,d=s.symbols('a b c d',real=True);x=s.Matrix([a,b,c,d]);z=s.symbols('z0:6');zv=s.Matrix(z);k=s.Symbol('k',real=True)
al=3*r/(8*(r+2));be=r*(r-1)/6;u=a*a+c*c;j=a*d-b*c;F=al*((a-d)**2+(b+c)**2)**2+be*u*u+j*j+r*u*j
M=s.hessian(s.expand((s.Matrix([1,k,0,0]).T*s.hessian(F,x)*s.Matrix([1,k,0,0]))[0]),x)/2
h=-(2*r+1)/3;A0=s.Matrix([0,-h,1,0]);a1=s.Matrix(s.symbols('v0:4'));v=s.linsolve(list(M.subs(k,0)*a1+M.diff(k).subs(k,0)*A0),list(a1));a1=s.Matrix(list(v)[0]).subs({i:0 for i in a1})
print('r',r,'alpha',al,'second A1',a1,flush=True)
curves=[(s.Matrix([1,-(r+1)*k,(r+1)*k,1]),s.Matrix([k*k,k,1,0,0,0])),(A0+k*a1,s.Matrix([1,k,k*k,0,0,0]))]
vecs=[]
for AA,zz in curves:
 for co,si in [(1,0),(0,1),(s.Rational(3,5),s.Rational(4,5))]:
  O=s.Matrix([[co,-si],[si,co]]);At=O*s.Matrix(2,2,list(AA));At=s.Matrix(list(At));Zt=O*s.Matrix(2,3,list(zz));Zt=s.Matrix(list(Zt));vv=s.kronecker_product(At,Zt)
  vecs.extend([vv.subs(k,0),vv.diff(k).subs(k,0)])
V=s.Matrix.hstack(*vecs);V=s.Matrix.hstack(*V.columnspace());C=s.Matrix.hstack(*V.T.nullspace());print('forced kernel',V.shape,'support',C.shape,flush=True)
# exact coefficient assembly by linear sparse expressions
vars=list(x)+list(z); monsA=list(itertools.combinations_with_replacement(range(4),2));monsZ=list(itertools.combinations_with_replacement(range(6),2));mons=list(itertools.product(monsA,monsZ));monindex={ (tuple(sorted((i,j))),tuple(sorted((k,l)))):ii for ii,((i,j),(k,l)) in enumerate(mons)}
bilinear=s.kronecker_product(x,zv);ll=C.T*bilinear
Svars=s.symbols('g0:'+str(C.cols*(C.cols+1)//2));pairs=list(itertools.combinations_with_replacement(range(C.cols),2));Sv=s.zeros(C.cols)
for val,(i,jj) in zip(Svars,pairs):Sv[i,jj]=Sv[jj,i]=val
# polynomial representation for products ll
Lterms=[]
for ii in range(C.cols):Lterms.append([(i//6,i%6,C[i,ii]) for i in range(24) if C[i,ii]!=0])
mat=s.zeros(226,len(Svars)+60)
for col,(i,jj) in enumerate(pairs):
 for ai,zi,ci in Lterms[i]:
  for aj,zj,cj in Lterms[jj]:mat[monindex[(tuple(sorted((ai,aj))),tuple(sorted((zi,zj))))],col]+=(1 if i==jj else 2)*ci*cj
B1=s.Matrix([z[0],z[1],z[3],z[4]]);B2=s.Matrix([z[1],z[2],z[4],z[5]]);wpairs=list(itertools.combinations(range(4),2));W=s.zeros(4);wv=s.symbols('w0:60');idx=0
for i,jj in wpairs:
 for aa,bb in monsA:
  W[i,jj]+=wv[idx]*x[aa]*x[bb];W[jj,i]-=wv[idx]*x[aa]*x[bb];idx+=1
omega=s.Poly(s.expand((B1.T*W*B2)[0]),*vars)
def mkey(exp):
 A=[];Z=[]
 for i,e in enumerate(exp[:4]):A.extend([i]*e)
 for i,e in enumerate(exp[4:]):Z.extend([i]*e)
 return tuple(A),tuple(Z)
for exp,coef in omega.terms():
 row=monindex[mkey(exp)]
 for i,vv in enumerate(wv):mat[row,len(Svars)+i]=-coef.coeff(vv)
row=210
for i,jj,kk in itertools.combinations(range(4),3):
 cl=s.Poly(s.diff(W[jj,kk],x[i])-s.diff(W[i,kk],x[jj])+s.diff(W[i,jj],x[kk]),*x)
 for xx in x:
  co=cl.coeff_monomial(xx)
  for i,vv in enumerate(wv):mat[row,len(Svars)+i]=co.coeff(vv)
  row+=1
E=s.Poly(s.expand((B1.T*s.hessian(F,x)*B1)[0]+(B2.T*s.hessian(F,x)*B2)[0]),*vars);rhs=s.zeros(226,1)
for exp,co in E.terms():rhs[monindex[mkey(exp)]]=co
print('linear solve',mat.shape,flush=True)
sol=s.linsolve((mat,rhs));print('sol done',flush=True)
if sol is s.EmptySet:print('EMPTY LINEAR');sys.exit()
sol=s.Matrix(list(sol)[0]);free=sorted(set().union(*(v.free_symbols for v in sol)),key=str);print('free dim',len(free),flush=True)
const=sol.subs({v:0 for v in free});coeff=sol.jacobian(free)
prefix='endpoint_'+str(r).replace('/','_').replace('-','m')
pack=dict(r=r,F=F,x=x,z=z,C=C,V=V,Svars=Svars,pairs=pairs,mat=mat,rhs=rhs,const=const,coeff=coeff,free=free,Wpairs=wpairs,Amons=monsA)
pickle.dump(pack,open(out/(prefix+'.pkl'),'wb'))
# alternating affine cone with ADMM
n=C.cols
def smat(vec):
 S=np.zeros((n,n));
 for val,(i,jj) in zip(vec,pairs):S[i,jj]=S[jj,i]=val
 return S
Q0=smat(np.array(const[:len(pairs)],float).flatten());dirs=np.stack([smat(np.array(coeff[:len(pairs),ii],float).flatten()) for ii in range(len(free))]);D=dirs.reshape(len(free),-1).T
proj=np.linalg.pinv(D);Q=Q0.copy();Y=np.zeros_like(Q);Z=Q.copy();best=1e9
for it in range(20000):
 pars=proj@(Z-Y-Q0).ravel();Q=Q0+np.einsum('i,ijk->jk',pars,dirs)
 lam,U=np.linalg.eigh(Q+Y);Z=(U*np.maximum(lam,0))@U.T;Y+=Q-Z
 err=np.linalg.norm(Q-Z)
 if it%1000==0:print(it,'err',err,'mineig',np.linalg.eigvalsh(Q)[0],flush=True)
 if err<1e-9:break
np.savez(out/(prefix+'_admm.npz'),pars=pars,Q=Q,err=err,it=it)
print('FINAL',it,err,np.linalg.eigvalsh(Q),flush=True)
