import sympy as s, pickle
r,k,t=s.symbols('r k t',real=True)
a,b,c,d=s.symbols('a b c d',real=True)
x=s.Matrix([a,b,c,d]);u=a*a+c*c;v=b*b+d*d;w=a*b+c*d;j=a*d-b*c;H=(u+v-2*j)**2
alpha,beta,gamma,delta=s.symbols('alpha beta gamma delta',real=True)
f=alpha*H+beta*u*u+gamma*j*j+delta*u*j
I={a:1,b:0,c:0,d:1}
HH=s.hessian(f,x)
print('Hessian row e12 at I',HH.subs(I)[1,:])
lam=s.symbols('lambda',real=True)
print('Translated Hessian row e12', (HH-lam*s.hessian(j,x)).subs(I)[1,:])
P=alpha*H+r*(r-1)/6*u*u+j*j+r*u*j
HHp=s.hessian(P,x)
Cvec=s.Matrix([t,0,0,-(r+1)*t]);Bvec=s.Matrix([1,0,0,1]);vv=Bvec+Cvec
res=s.expand(P.subs(dict(zip(x,vv)), simultaneous=True)-P.subs(I)-(s.Matrix([s.diff(P,y) for y in x]).subs(I).dot(Cvec))-(r+2)*s.det(s.Matrix(2,2,Cvec)))
q=r*(r+2);K=alpha*(r+2)**4+(r+2)**2/s.Integer(4)-q/s.Integer(12)
print('PC cubic:',s.factor(res), 'difference',s.factor(res-(-q*t**3/3+K*t**4)))
assert s.factor(res-(-q*t**3/3+K*t**4))==0
# First acoustic contact kernel constraints both in A and direction.
base=[u*u,v*v,u*v,w*w,u*w,v*w,u*j,v*j,w*j]
p=s.symbols('p0:9')
g=sum(pi*fi for pi,fi in zip(p,base));gg=s.hessian(g,x)
# direction R=e1 otimes (n,m), and acoustic quadratic in x
n,m=s.symbols('n m',real=True);rr=s.Matrix([n,m,0,0]);ac=s.expand((rr.T*gg*rr)[0]);Ma=s.hessian(ac,x)/2
acI=s.factor(ac.subs(I))
e1=s.Matrix([1,0]);e2=s.Matrix([0,1]);AI=s.Matrix([1,0,0,1])
contact_eq=list((Ma.subs({n:0,m:1})*AI)) + [s.diff(ac,n).subs(I).subs({n:0,m:1}),s.diff(ac,m).subs(I).subs({n:0,m:1})]
Aeq,beq=s.linear_eq_to_matrix(contact_eq,p)
print('first contact rank',Aeq.rank(), 'kernel',Aeq.nullspace())
assert Aeq.rank()==5
base4=[H,u*u,j*j,u*j]
# Coeff vectors by polynomial matching
mon=list(s.polys.monomials.itermonomials(list(x),4));mon=[mo for mo in mon if s.total_degree(mo)==4]
Z=s.Matrix([[s.Poly(fi,*x).coeff_monomial(mo) for fi in base] for mo in mon])
Bc=s.Matrix.hstack(*[Z.gauss_jordan_solve(s.Matrix([s.Poly(fi,*x).coeff_monomial(mo) for mo in mon]))[0] for fi in base4])
assert Aeq*Bc==s.zeros(Aeq.rows,4)
h=-(2*r+1)/3
Astar=s.Matrix([0,-h,1,0]);Ma4=Ma.subs(dict(zip(p,Bc*s.Matrix([alpha,beta,gamma,delta]))))
ceq=list(Ma4.subs({n:1,m:0})*Astar)+[s.diff((x.T*Ma4*x)[0],m).subs(dict(zip(x,Astar)),simultaneous=True).subs({n:1,m:0})]
print('Second eq',list(map(s.factor,ceq)))
E,bb=s.linear_eq_to_matrix(ceq,[alpha,beta,gamma,delta]);print('second rank',E.rank(),'null',E.nullspace())
sol=s.solve(ceq,[beta,delta]); print('second solution',sol)
assert s.factor(sol[delta]-4*alpha*(1-h))==0
assert s.factor(sol[beta]-alpha*(h*h-1))==0
J=P.subs(alpha,3*r/(8*(r+2)));MQ=s.hessian((rr.T*s.hessian(J,x)*rr)[0],x)/2
print('Sharp acoustic determinant',s.factor(MQ.det()))
# Factorized quartic at contacts
print('First rank/contact det',s.factor(MQ.subs({n:0,m:1}).det()),len(MQ.subs({n:0,m:1}).nullspace()))
print('First kernel',MQ.subs({n:0,m:1}).nullspace())
print('Second kernel',MQ.subs({n:1,m:0}).nullspace())
# express M1 on two-contact span J + tdet^2
L,mu=s.symbols('L mu',real=True)
M1=s.Matrix([[6*beta+delta,delta],[delta,gamma]])
sub={alpha:L*3*r/(8*(r+2)),beta:L*r*(r-1)/6,gamma:L+mu,delta:L*r}
print('M1 on two-contact face',M1.subs(sub),'det',s.factor(M1.subs(sub).det()))
print('rank-one value gives L',s.factor(J.subs({a:1,b:0,c:0,d:0})))
