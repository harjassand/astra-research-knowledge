import pickle,sympy as s
p=pickle.load(open('/mnt/data/sharp_frontier/scalar_identity.pkl','rb'))
t,k=s.symbols('t k',real=True,nonzero=True);x=p['x'];a,b,c,d=x
sub={p['P']:2*t*t,p['Q']:2*t*t*(13-t*t)/(3+t*t),p['L']:4*t}
F=p['F'].subs(sub);SS=p['S'].subs(sub);n=s.Matrix([1,k,0,0]);hh=s.hessian(F,x);E=s.expand((n.T*hh*n)[0]);M=s.hessian(E,x)/2
A0=s.Matrix([0,-1,t,0]);A1=s.Matrix(s.symbols('v0:4'))
sol=s.linsolve(list(M.subs(k,0)*A1+M.diff(k).subs(k,0)*A0),list(A1));print('A1',sol)
A1=s.Matrix(list(sol)[0]).subs({v:0 for v in A1});print('chosen',A1)
Zsub=dict(zip(x,A0+k*A1));Zsub.update(dict(zip(p['z'],[1,k,k*k,0,0,0])))
vp=p['zp'].subs(Zsub);vm=p['zm'].subs(Zsub)
print('zp0',vp.subs(k,0));print('zpd',vp.diff(k).subs(k,0).applyfunc(s.factor));print('zm0',vm.subs(k,0));print('zmd',vm.diff(k).subs(k,0).applyfunc(s.factor))
vs=[vp.subs(k,0),vp.diff(k).subs(k,0),vm.subs(k,0),vm.diff(k).subs(k,0)]
vv=s.Matrix.hstack(*vs).columnspace();print('kernel dim',len(vv))
free=sorted(SS.free_symbols-{t},key=str)
constraints=[s.factor(w) for v in vv for w in SS*v]
sol2=s.linsolve(constraints,free);print('free',free);print('solution',sol2)
if sol2 is not s.EmptySet:
 sol2=dict(zip(free,list(sol2)[0]));SF=SS.subs(sol2).applyfunc(s.factor)
 print('Ssharp',SF);print('free after',SF.free_symbols-{t})
 p.update(t=t,Ft=F,St=SF,cc_t=p['cc'].subs(sol2).subs(sub),kernel=s.Matrix.hstack(*vv))
 pickle.dump(p,open('/mnt/data/sharp_frontier/sharp_scalar.pkl','wb'))
