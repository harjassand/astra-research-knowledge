exec(open('/mnt/data/sharp_frontier/derive_acoustic.py').read().split("print('M=')")[0])
r=s.symbols('r', real=True);M=M.subs({ga:1,de:r,be:r*(r-1)/6});T=s.Matrix([[1,0,1,0],[0,-1,0,1],[0,1,0,1],[1,0,-1,0]])/2
MM=s.simplify(T.T*M*T);AA=MM[:2,:2]
print('A block',AA.applyfunc(s.factor));print('A det',s.factor(AA.det()))
red=(MM[2:,2:]-MM[2:,:2]*AA.inv()*MM[:2,2:]).applyfunc(s.factor)
print('Schur',red)
print('det',s.factor(red.det()))
z=s.symbols('z',real=True)
det=s.Poly(s.factor(red.det()),k)
for exp,coeff in det.terms():print(exp,s.factor(coeff))
print('r=-2.5 det',s.factor(red.det().subs(r,-s.Rational(5,2))))
