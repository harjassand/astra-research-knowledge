import sympy as s,pickle,numpy as np
p=pickle.load(open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','rb'));r=p['r'];ta=p['free'];sm={ta[0]:-r*(2*r+1)**2/(4*(r+2)),ta[1]:3*r/(4*(r+2)),ta[2]:0,ta[3]:3*(2*r+1)/(r+2)}
S=p['S'].subs(sm).applyfunc(s.factor);Sc=p['Sscalar'].subs(sm).applyfunc(s.factor);St=p['Stensor'].subs(sm).applyfunc(s.factor)
B=Sc.extract([0,2,4,6],[0,2,4,6]);print('block4',B);print('tensor2',St[:2,:2]);
for k in range(1,5):print('minor',k,s.factor(B[:k,:k].det()))
print('tensor det',s.factor(St[:2,:2].det()))
f=s.lambdify(r,S,'numpy')
for rr in [-2.001,-2.01,-2.1,-2.25,-2.5,-2.75,-3,-4,-5,-10,-100]: print(rr,np.linalg.eigvalsh(f(rr))[0])
p['simple_subs']=sm;p['Ssimple']=S;p['simple_block4']=B;p['simple_tensor2']=St[:2,:2];pickle.dump(p,open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','wb'))
