import sympy as s,itertools,pickle
from pathlib import Path
out=Path('/mnt/data/sharp_frontier')
a,b,c,d=s.symbols('a b c d', real=True);x=s.Matrix([a,b,c,d]);z=s.symbols('z0:6');B1=s.Matrix([z[0],z[1],z[3],z[4]]);B2=s.Matrix([z[1],z[2],z[4],z[5]])
u=a*a+c*c;v=b*b+d*d;w=a*b+c*d;j=a*d-b*c
P,Q,L=s.symbols('P Q L',real=True);F=u*u+v*v+P*w*w+Q*j*j-L*j*(u+v)
hess=s.hessian(F,x);E=s.expand((B1.T*hess*B1)[0]+(B2.T*hess*B2)[0])
zp=s.Matrix([a*z[0]+c*z[3], a*z[2]+c*z[5], b*z[1]+d*z[4], a*z[4]-c*z[1], b*z[3]-d*z[0], b*z[5]-d*z[2]])
zm=s.Matrix([-b*z[2]-d*z[5],-b*z[0]-d*z[3],-a*z[1]-c*z[4],b*z[4]-d*z[1],a*z[5]-c*z[2],a*z[3]-c*z[0]])
theta=s.Matrix([-c,-d,a,b]);zeta=s.Matrix([-b,a,-d,c]);ta=s.Matrix([-c,d,a,-b]);prim=[(u+v)*theta,j*theta,(u+v)*zeta,j*zeta,(u-v)*ta]
t=s.symbols('c0:5');omega=s.zeros(4)
for coeff,p in zip(t,prim):omega+=coeff*(p.jacobian(x).T-p.jacobian(x))
T=s.zeros(6);sv=s.symbols('s0:21');pairs=list(itertools.combinations_with_replacement(range(6),2))
for val,(i,jj) in zip(sv,pairs):T[i,jj]=T[jj,i]=val
expr=s.Poly(s.expand((zp.T*T*zp)[0]+(zm.T*T*zm)[0]-E-(B1.T*omega*B2)[0]),*x,*z)
eq=expr.coeffs(); A,rhs=s.linear_eq_to_matrix(eq,list(sv)+list(t));print(A.shape,A.rank())
sol=list(s.linsolve((A,rhs),list(sv)+list(t)))[0];solmap=dict(zip(list(sv)+list(t),sol));SS=T.subs(solmap);cc=s.Matrix(t).subs(solmap)
print('S',SS);print('correction',cc)
with open(out/'scalar_identity.pkl','wb') as f:pickle.dump(dict(x=x,z=z,B1=B1,B2=B2,F=F,P=P,Q=Q,L=L,E=E,zp=zp,zm=zm,prim=prim,S=SS,cc=cc),f)
