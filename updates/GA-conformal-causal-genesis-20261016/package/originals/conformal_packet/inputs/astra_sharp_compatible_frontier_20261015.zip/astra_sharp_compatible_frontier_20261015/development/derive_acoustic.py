import sympy as s
al,be,ga,de,k=s.symbols('alpha beta gamma delta k', real=True)
a,b,c,d=s.symbols('a b c d',real=True); x=s.Matrix([a,b,c,d]);
u=a*a+c*c;j=a*d-b*c;H=((a-d)**2+(b+c)**2)**2
F=al*H+be*u*u+ga*j*j+de*u*j
K=s.hessian(F,x); n=s.Matrix([1,k,0,0]); E=s.expand((n.T*K*n)[0]); M=s.hessian(E,x)/2
print('M=');print(M)
print('det factor',s.factor(M.det()))
print('family det',s.factor(M.subs({be:de*(de-ga)/(6*ga)}).det()))
# change conformance a=(p+x)/2,d=(p-x)/2,b=(y-q)/2,c=(y+q)/2
p,q,X,Y=s.symbols('p q X Y', real=True)
T=s.Matrix([[1,0,1,0],[0,-1,0,1],[0,1,0,1],[1,0,-1,0]])/2
MM=s.simplify(T.T*M*T)
print('conformal block',MM[:2,:2]);print('cross block',MM[:2,2:]);print('distortion block',MM[2:,2:]);
print('conf det',s.factor(MM[:2,:2].det()))
red=s.simplify(MM[2:,2:] -MM[2:,:2]*MM[:2,:2].inv()*MM[:2,2:])
print('Schur',red.applyfunc(s.factor))
open('/mnt/data/sharp_frontier/acoustic_repr.txt','w').write(str(M)+'\n'+str(red.applyfunc(s.factor)))
