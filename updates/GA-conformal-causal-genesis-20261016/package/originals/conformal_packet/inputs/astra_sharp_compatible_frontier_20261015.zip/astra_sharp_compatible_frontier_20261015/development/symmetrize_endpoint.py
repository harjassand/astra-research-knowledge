import sympy as s,pickle
p=pickle.load(open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','rb'));C=p['C'];S=p['S'];r=p['r'];free=p['free'];
Rs=[]
for co,si in [(1,0),(0,1),(s.sqrt(2)/2,s.sqrt(2)/2),(-s.sqrt(2)/2,s.sqrt(2)/2)]:
 O=s.Matrix([[co,-si],[si,co]]);T=s.kronecker_product(s.kronecker_product(O,s.eye(2)),s.kronecker_product(O,s.eye(3)));M=(C.T*T).applyfunc(s.cancel);R=M[:,12:];assert (M-R*C.T).applyfunc(s.cancel)==s.zeros(12,24);Rs.append(R)
Sav=(sum((R.T*S*R for R in Rs),s.zeros(12))/4).applyfunc(s.factor)
print('free invariance',s.linsolve([s.factor(v) for v in Sav-S],free),flush=True)
sol=s.linsolve([s.factor(v) for v in Sav-S],free)
sm=dict(zip(free,list(sol)[0]));print('sm',sm)
Ssym=S.subs(sm).applyfunc(s.factor);print('free new',Ssym.free_symbols-{r})
# parity zero
Ssym=Ssym.subs(s.Symbol('tau2'),0)
p['sym_subs']=sm;p['Ssym']=Ssym;p['Rs']=Rs
pickle.dump(p,open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','wb'))
print('Ssym',Ssym)
