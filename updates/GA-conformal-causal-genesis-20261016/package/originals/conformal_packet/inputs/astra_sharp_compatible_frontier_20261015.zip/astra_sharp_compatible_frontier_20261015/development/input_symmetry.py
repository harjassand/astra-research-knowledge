import sympy as s,pickle
p=pickle.load(open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','rb'));r=p['r'];C=p['C'];S=p['S'];h=-(2*r+1)/3
# Sinput = A0/sqrt(h), factor 1/sqrt(h) taken outside A action; Hess action rational.
B=s.Matrix([[0,-h],[1,0]]);TH=s.Matrix([[0,0,1/h],[0,-1,0],[h,0,0]])
T=s.kronecker_product(s.kronecker_product(s.eye(2),B.T),s.kronecker_product(s.eye(2),TH))
M=(C.T*T).applyfunc(s.cancel);R=M[:,12:];assert (M-R*C.T).applyfunc(s.cancel)==s.zeros(12,24)
ss=(R.T*S*R/h-S).applyfunc(s.factor);sol=s.linsolve(list(ss),p['free']);print(sol,flush=True)
sub=dict(zip(p['free'],list(sol)[0]));S2=S.subs(sub).applyfunc(s.factor);print('free2',S2.free_symbols-{r})
p['input_sym_subs']=sub;p['Sinput']=S2;p['input_R_scaled']=R;pickle.dump(p,open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','wb'))
print('reducedtensor',p['Stensor'].subs(sub).applyfunc(s.factor))
print('reducedscalar',p['Sscalar'].subs(sub).applyfunc(s.factor))
