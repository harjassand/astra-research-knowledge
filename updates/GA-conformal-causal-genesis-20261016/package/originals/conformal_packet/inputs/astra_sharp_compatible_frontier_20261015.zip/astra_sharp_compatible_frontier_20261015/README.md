# Astra sharp compatible-positivity frontier

Start with `RESEARCH_REPORT.md`.

The main result proves fixed-coefficient rank-one-convexity/quasiconvexity equivalence for the entire negative shear-contact sector delta <= 0. The common condition is two explicit 2x2 LMIs. The positive-delta QC question is not settled. Other results are a universal sharp-core heat identity for every r < -2; a cubic obstruction to unrestricted polyconvexity; extreme, non-exposed ROC rays; no direct finite LMI description of the full nine-coefficient ROC cone; and the sharp original-G distortion subtraction 9H/8.

## Replay

Python 3.10+ and SymPy are sufficient. From this directory:

```bash
python verify_frontier.py
python verify_peer_algebra.py
```

The main verifier reads the JSON, not any discovery code or pickle. It uses rational-function algebra and uniform polynomial sign checks, not floating eigenvalues or parameter sampling. It produces `VERIFICATION_RECEIPT.json`. The peer verifier has deliberately narrower scope and is not a premise of the new theorem.

`SHARP_CERTIFICATE.json` stores rational functions as numerator/denominator coefficient arrays in descending powers of r. It includes the full bilinear map, closed form, congruence and positive blocks. No coefficients are hidden in an optimizer state.

## Evidence limits

The all-background heat passage, polyconvex support implication, and convex duality/non-exposedness argument are mathematical proofs in the report; an arithmetic receipt does not replace their analytic review. Historical novelty and independent external correctness remain unknown. No formal proof-assistant verification is asserted. No repository write or merge was performed.

`INPUT_REPLAYS.json` records prior artifact hashes and replay results. `development/` preserves unsuccessful search states and exploration code, including floating matrices which are NOT proof premises. The small original archives in `inputs/` preserve the incoming work without modification.

`MANIFEST.json` records SHA-256 hashes for all packet files other than itself. `SOURCES.json` records pinned source routes and reading/replay scopes.
