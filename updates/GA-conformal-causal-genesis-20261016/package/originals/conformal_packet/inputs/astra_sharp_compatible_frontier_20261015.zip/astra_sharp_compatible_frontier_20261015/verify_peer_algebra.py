#!/usr/bin/env python3
"""Independent bounded replay of selected Sol algebra, not a full peer proof review.
Source pin: 8a1e001ac128468ae8d151c9a859b89ef3b9a664, N863.
Neither calculation is a premise of the new sharp-family theorem.
"""
from pathlib import Path
import sympy as s,json,time,hashlib
start=time.monotonic();a,b,c,d=s.symbols('a b c d');x=s.Matrix([a,b,c,d]);n,m=s.symbols('n m');
u=a*a+c*c;v=b*b+d*d;w=a*b+c*d;j=a*d-b*c
F=u*u+v*v+s.Rational(166,3)*u*v-s.Rational(460,9)*w*w-s.Rational(52,9)*j*(u-v)
R=s.Matrix([n,m,0,0]);ac=s.expand((R.T*s.hessian(F,x)*R)[0]);M=s.hessian(ac,x)/2
M11=M.subs({n:1,m:0});M22=M.subs({n:0,m:1});M12=(M.subs({n:1,m:1})-M11-M22)/2
K=s.zeros(4)
for (i,jj),val in zip([(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)],[8,8,0,0,-8,488]):K[i,jj]=s.Rational(val,9);K[jj,i]=-s.Rational(val,9)
Q=M11.row_join(M12+K).col_join((M12-K).row_join(M22));B=s.zeros(8,4)
for cidx,rows,vals in [(0,[0,3,5,6],[2,-1,2,-1]),(1,[0,3,5,6],[1,-9,-1,9]),(2,[1,2,4,7],[3,2,3,2]),(3,[1,2,4,7],[1,1,-1,-1])]:
 for i,val in zip(rows,vals):B[i,cidx]=val
assert Q==B*s.diag(s.Rational(8,3),s.Rational(4,3),s.Rational(8,9),s.Rational(4,9))*B.T
assert B.rank()==4
print('PASS: Sol exposed-ray acoustic rank-four factor (exposedness/operator obstruction NOT replayed)')
# Independently expand Sol's sharp heat-section four-square certificate.
z=s.symbols('z0:6');B1=s.Matrix([z[0],z[1],z[3],z[4]]);B2=s.Matrix([z[1],z[2],z[4],z[5]]);h=s.sqrt(3)
Fend=(u+v)**2+(12+8*h)*j*j
# Cubic primitive k*s*zeta+l*j*theta; coefficients are components of a one-form.
theta=s.Matrix([-c,-d,a,b]);zeta=s.Matrix([-b,a,-d,c]);prim=-2*h*(u+v)*zeta+(-16-12*h)*j*theta
W=s.Matrix(4,4,lambda i,jj:s.diff(prim[jj],x[i])-s.diff(prim[i],x[jj]))
L1=(h-1)/2*a*z[3]+(h+1)/2*a*z[5]-b*z[4]+(1-h)/2*c*z[0]-(1+h)/2*c*z[2]+d*z[1]
L2=(1+h)*a*z[4]-(2+h)*b*z[3]-b*z[5]-(1+h)*c*z[1]+(2+h)*d*z[0]+d*z[2]
L3=(3-h)/2*a*z[0]+(1-h)/2*a*z[2]+b*z[1]+(3-h)/2*c*z[3]+(1-h)/2*c*z[5]+d*z[4]
L4=(3+h)/3*a*z[1]-h/3*b*z[0]+b*z[2]+(3+h)/3*c*z[4]-h/3*d*z[3]+d*z[5]
HH=s.hessian(Fend,x)
assert s.expand((B1.T*HH*B1)[0]+(B2.T*HH*B2)[0]+(B1.T*W*B2)[0]-(16+8*h)*(L1*L1+L3*L3)-4*L2*L2-12*L4*L4)==0
al,be,kk,ll=s.symbols('alpha beta k ell')
q0=24*al+4*h*kk;q1=(32+16*h)*al+2*be-(4+2*h)*kk+(2+h)*ll;q2=32*al-8*be-8*kk-4*ll
assert s.expand((1+2*h/3)*q0+q1+(2+h)/4*q2-2*(1+h)*((12+8*h)*al-be))==0
print('PASS: Sol sharp heat section, four-square identity and positive dual combination')
out={'status':'PASS','pin':'8a1e001ac128468ae8d151c9a859b89ef3b9a664','scope':['exposed-ray acoustic factor only','sharp heat-section four-square identity and correction-parameter elimination only'],'not_replayed':['full operator separation','full exposedness proof','global PC/QC of Sol ray'],'used_as_premise_of_new_theorem':False,'elapsed_seconds':round(time.monotonic()-start,3),'source_paths':['updates/FV-positive-consequences-20261015/package/derived/workers/heat_cone_genesis_sol/PROOF.md','updates/FV-positive-consequences-20261015/package/derived/workers/heat_cone_adversary_sol/SHARP_HEAT_BOUNDARY.md'],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('PEER_ALGEBRA_RECEIPT.json').write_text(json.dumps(out,indent=2)+'\n')
