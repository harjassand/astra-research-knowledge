#!/usr/bin/env python3
"""Standalone exact verifier for the sharp shear-contact theorem.

Usage: python verify_frontier.py [--certificate PATH] [--receipt PATH]
Requires Python 3.10+ and SymPy. No optimizer, floating arithmetic, pickle,
network access, or discovery script is used. Analytic implications and cone
arguments are proved in RESEARCH_REPORT.md, not certified by a status string.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, platform, time
from pathlib import Path
import sympy as s


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parent
    parser.add_argument('--certificate', type=Path, default=root/'SHARP_CERTIFICATE.json')
    parser.add_argument('--receipt', type=Path, default=root/'VERIFICATION_RECEIPT.json')
    args = parser.parse_args()
    started = time.monotonic()
    raw = args.certificate.read_bytes()
    data = json.loads(raw)
    assert data['schema'] == 'astra-sharp-shear-contact/1'
    r = s.Symbol('r', real=True)
    a,b,c,d = x = s.symbols('a b c d', real=True)
    z = s.symbols('z0:6', real=True)
    def decode(obj):
        def pol(seq):
            assert isinstance(seq, list) and seq
            out=s.Integer(0)
            for q in seq:
                out=out*r+s.Rational(q)
            return out
        den=pol(obj['d'])
        assert den != 0
        return s.cancel(pol(obj['n'])/den)
    def matrix(obj):
        assert obj and all(len(row)==len(obj[0]) for row in obj)
        return s.Matrix([[decode(e) for e in row] for row in obj])
    def zero(e):
        return s.cancel(e)==0
    def zero_matrix(M):
        return all(zero(e) for e in M)
    def polynomial_zero(e, variables):
        P=s.Poly(s.expand(e), *variables)
        assert all(zero(c) for c in P.coeffs())
        return len(P.terms())
    checks=[]
    def passed(name, **detail):
        checks.append({'group':name,'status':'PASS',**detail})
        print('PASS:',name,flush=True)
    X=s.Symbol('X',positive=True)
    def positive_on_domain(expr):
        num,den=s.fraction(s.cancel(expr.subs(r,-2-X)))
        pc=s.Poly(num,X).all_coeffs(); qc=s.Poly(den,X).all_coeffs()
        assert all(v.is_Rational for v in pc+qc)
        same_positive = (all(v>=0 for v in pc) and any(v>0 for v in pc)
                         and all(v>=0 for v in qc) and any(v>0 for v in qc))
        same_negative = (all(v<=0 for v in pc) and any(v<0 for v in pc)
                         and all(v<=0 for v in qc) and any(v<0 for v in qc))
        assert same_positive or same_negative, ('sign failure',expr)
        return {'numerator_coefficients':list(map(str,pc)),
                'denominator_coefficients':list(map(str,qc))}
    C=matrix(data['C']); T=matrix(data['T']); L=matrix(data['L'])
    blocks=[matrix(b) for b in data['blocks']]
    W=matrix(data['omega_coefficients'])
    diff=[decode(q) for q in data['diffusion']]
    assert C.shape==(24,12) and T.shape==(12,12) and L.shape==(12,24)
    assert [B.rows for B in blocks]==[4,4,2,2]
    assert C[12:24,:]==s.eye(12)
    assert zero(T.det()-16)
    assert zero_matrix(T*L-C.T)
    for M in [C,T,L,W,*blocks]:
        for e in M:
            den=s.fraction(s.cancel(e))[1]
            # Either sign is permitted, but no zero of the denominator is.
            try: positive_on_domain(den)
            except AssertionError: positive_on_domain(-den)
    assert zero(diff[0]+(2*r+1)/3) and diff[1]==1
    for q in diff:positive_on_domain(q)
    passed('certificate dimensions, rank 12, invertible congruence, regular denominators, elliptic diffusion')

    # Independent reconstruction from the advertised polynomial and jets.
    u=a*a+c*c;v=b*b+d*d;j=a*d-b*c
    H=(u+v-2*j)**2
    ar=3*r/(8*(r+2));br=r*(r-1)/6
    J=ar*H+br*u*u+j*j+r*u*j
    Hess=s.hessian(J,x)
    B1=s.Matrix([z[0],z[1],z[3],z[4]])
    B2=s.Matrix([z[1],z[2],z[4],z[5]])
    Z=s.Matrix([xx*zz for xx in x for zz in z])
    pairs=list(itertools.combinations(range(4),2))
    mons=list(itertools.combinations_with_replacement(range(4),2))
    assert list(map(tuple,data['omega_pair_order']))==pairs
    assert list(map(tuple,data['quadratic_monomials']))==mons
    assert W.shape==(6,10)
    omega=s.zeros(4)
    for row,(i,k) in enumerate(pairs):
        val=sum(W[row,l]*x[p]*x[q] for l,(p,q) in enumerate(mons))
        omega[i,k]=val;omega[k,i]=-val
    density=(diff[0]*(B1.T*Hess*B1)[0]+diff[1]*(B2.T*Hess*B2)[0]
             +(B1.T*omega*B2)[0])
    gram=s.diag(*blocks)
    coordinates=L*Z
    polynomial_zero((coordinates.T*gram*coordinates)[0]-density, (*x,*z))
    for i,k,l in itertools.combinations(range(4),3):
        polynomial_zero(s.diff(omega[k,l],x[i])-s.diff(omega[i,l],x[k])
                        +s.diff(omega[i,k],x[l]), x)
    primitive=omega.T*s.Matrix(x)/4
    for i,k in pairs:
        polynomial_zero(s.diff(primitive[k],x[i])-s.diff(primitive[i],x[k])-omega[i,k],x)
    passed('universal rational-function heat identity, closed two-form and Euler primitive')

    minors=[]; sign_proofs=[]
    for B, claimed in zip(blocks,data['block_leading_minors']):
        assert B==B.T
        vals=[]
        for i in range(1,B.rows+1):
            det=s.factor(B[:i,:i].det())
            assert zero(det-decode(claimed[i-1]))
            sign_proofs.append(positive_on_domain(det))
            vals.append(str(det))
        minors.append(vals)
    assert blocks[2]==blocks[3]
    passed('all 12 Sylvester minors positive for EVERY r < -2',minors=minors,
           sign_method='r=-2-X, X>0; matching-sign polynomial coefficients',sign_proofs=sign_proofs)

    # Moving double-contact geometry and the exact acoustic threshold.
    n,m,k,t,al=s.symbols('n m k t alpha',real=True)
    R=s.Matrix([n,m,0,0])
    def acoustic(poly):
        q=(R.T*s.hessian(poly,x)*R)[0]
        return s.hessian(q,x)/2
    M=acoustic(J)
    assert zero(M.det()-9*r**4*n**4*m**4)
    AI=s.Matrix([1,0,0,1]);h=diff[0];AS=s.Matrix([0,-h,1,0])
    assert zero_matrix(M.subs({n:0,m:1})*AI)
    assert zero_matrix(M.subs({n:1,m:0})*AS)
    Mfirst=M.subs({n:0,m:1}); Msecond=M.subs({n:1,m:0})
    assert zero(Mfirst.extract([0,1,2],[0,1,2]).det()-27*r*r/(2*(r+2)**2))
    assert zero(Msecond.extract([0,1,3],[0,1,3]).det()-3*r*r*(2*r+1)**2/(2*(r+2)**2))
    positive_on_domain(27*r*r/(2*(r+2)**2))
    positive_on_domain(3*r*r*(2*r+1)**2/(2*(r+2)**2))
    cof=s.Matrix([d,-c,-b,a])
    assert (cof.subs(dict(zip(x,AI))).dot(s.Matrix([0,1,0,0])))==0
    assert (cof.subs(dict(zip(x,AS))).dot(s.Matrix([1,0,0,0])))==0
    AA=s.Matrix(2,2,x); Astar=s.Matrix(2,2,AS)
    polynomial_zero(J.subs(dict(zip(x,list(AA*Astar))),simultaneous=True)-h*h*J,x)
    # Full 12-dimensional kernel is exactly the contact value/tangent orbit span.
    curves=[(s.Matrix([1,-(r+1)*k,(r+1)*k,1]),s.Matrix([k*k,k,1,0,0,0])),
            (AS+k*s.Matrix([-3*(r+1)/(2*r+1),0,0,r+1]),s.Matrix([1,k,k*k,0,0,0]))]
    kernel=[]
    for Acurve,zcurve in curves:
        acoustic_curve=(s.Matrix([k,1,0,0]) if Acurve==curves[0][0] else s.Matrix([1,k,0,0]))
        aa=(acoustic_curve.T*Hess.subs(dict(zip(x,Acurve)),simultaneous=True)*acoustic_curve)[0]
        assert all(zero(s.diff(aa,k,l).subs(k,0)) for l in range(4))
        for co,si in [(s.Integer(1),s.Integer(0)),(s.Integer(0),s.Integer(1)),(s.Rational(3,5),s.Rational(4,5))]:
            O=s.Matrix([[co,-si],[si,co]])
            ax=list(O*s.Matrix(2,2,Acurve)); zz=list(O*s.Matrix(2,3,zcurve))
            zzv=s.Matrix([aa*bb for aa in ax for bb in zz])
            kernel.extend([zzv.subs(k,0),zzv.diff(k).subs(k,0)])
    V=s.Matrix.hstack(*kernel)
    assert V.shape==(24,12)
    vminor=s.factor(V[:12,:].det())
    vclaim=s.Rational(3072,390625)*(r+1)**2*(r+2)**2*(2*r+1)
    assert zero(vminor*vminor-vclaim*vclaim)
    positive_on_domain(vminor*vminor)
    assert zero_matrix(L*V)
    passed('two acoustic contacts, moving rank-12 kernel and adapted input symmetry',
           acoustic_determinant='9*r^4*n^4*m^4')

    # ROC sufficiency holds also for r>0: explicit Schur decomposition.
    P=al*H+br*u*u+j*j+r*u*j
    Mfull=acoustic(P).subs({n:1,m:k})
    # (p,q,X,Y) -> (a,b,c,d) = ((p+X)/2,(Y-q)/2,(Y+q)/2,(p-X)/2).
    U=s.Matrix([[1,0,1,0],[0,-1,0,1],[0,1,0,1],[1,0,-1,0]])/2
    MU=(U.T*Mfull*U).applyfunc(s.factor)
    Aconf=MU[:2,:2]
    conf_claim=s.Matrix([[(r+1)**2/2,-k*(r+1)/2],[-k*(r+1)/2,(3*k*k+r*(r+2))/6]])
    assert zero_matrix(Aconf-conf_claim)
    assert zero(Aconf.det()-r*(r+1)**2*(r+2)/12)
    Sschur=(MU[2:,2:]-MU[2:,:2]*Aconf.inv()*MU[:2,2:]).applyfunc(s.factor)
    B0=r*(5*r+4)/(24*(r+1)**2); C0=ar/(r+1)**2
    claimed=4*s.Matrix([[(al-C0)*k*k+3*(al-B0),(2*al-ar/(r+1))*k],
                         [(2*al-ar/(r+1))*k,3*al*k*k+al-ar]])
    assert zero_matrix(Sschur-claimed)
    ds=3*al*(al-C0)*k**4+6*al*(al-ar)*k*k+3*(al-B0)*(al-ar)
    assert zero(Sschur.det()-16*ds)
    assert zero(ar-B0-r*(2*r+1)**2/(24*(r+1)**2*(r+2)))
    assert zero(ar-C0-ar*r*(r+2)/(r+1)**2)
    passed('sharp ROC threshold via exact acoustic Schur complement, for r<-2 OR r>0')

    # The two LMIs and exact minimal-coefficient decomposition.
    be,ga,de,sg=s.symbols('beta gamma delta sigma',real=True)
    F=al*H+be*u*u+ga*j*j+de*u*j
    Fh=s.hessian(F,x)
    curve=s.Matrix([1,-sg*t,sg*t,1]);Rc=s.Matrix([t,1,0,0])
    qc=s.expand((Rc.T*Fh.subs(dict(zip(x,curve)),simultaneous=True)*Rc)[0])
    M1=s.Matrix([[6*be+de,de],[de,ga]])
    qclaim=2*(s.Matrix([1,1-sg]).T*M1*s.Matrix([1,1-sg]))[0]*t*t+2*sg*sg*(2*be+de)*t**4
    assert zero(qc-qclaim)
    # Acoustic principal block, in the (b,c) background coordinates at R=e11.
    K=acoustic(F).subs({n:1,m:0}).extract([1,2],[1,2])
    assert zero(K.det()-(8*al*(2*be+de)-de*de))
    U2=s.Matrix([[1,1],[0,-1]])
    assert zero_matrix(U2.T*K*U2-s.Matrix([[4*al,de],[de,2*(2*be+de)]]))
    r0=(6*be+de)/de;g0=de*de/(6*be+de);acrit=de*de/(8*(2*be+de))
    # Compare coefficients, avoiding substitution explosion in x.
    assert zero(g0*r0-de)
    assert zero(g0*r0*(r0-1)/6-be)
    assert zero(g0*3*r0/(8*(r0+2))-acrit)
    assert zero((ga-g0)*(6*be+de)-M1.det())
    passed('two exact face LMIs and decomposition at the ORIGINAL sharp coefficient')

    # Nonpolyconvexity is not inferred from failure of a certificate.
    I={a:1,b:0,c:0,d:1}; lam=s.Symbol('lambda')
    row=(s.hessian(P,x)-lam*s.hessian(j,x)).subs(I)[1,:]
    assert list(row)==[0,0,lam-r-2,0]
    Vt=s.Matrix([t,0,0,-(r+1)*t]);At=AI+Vt
    grad=s.Matrix([s.diff(P,y)for y in x]).subs(I)
    residual=P.subs(dict(zip(x,At)),simultaneous=True)-P.subs(I)-grad.dot(Vt)-(r+2)*s.det(s.Matrix(2,2,Vt))
    q=r*(r+2);Kpc=al*(r+2)**4+(r+2)**2/4-q/12
    assert zero(residual+q*t**3/3-Kpc*t**4)
    passed('explicit cubic obstruction to unrestricted polyconvex support for all finite alpha, r(r+2)>0',
           residual='-r*(r+2)*t^3/3 + (alpha*(r+2)^4+(r+2)^2/4-r*(r+2)/12)*t^4')

    # Full nine-dimensional contact face, not extremality of a particular Gram.
    w=a*b+c*d
    basis=[u*u,v*v,u*v,w*w,u*w,v*w,u*j,v*j,w*j]
    ps=s.symbols('p0:9'); G=sum(pi*fi for pi,fi in zip(ps,basis));MG=acoustic(G)
    acousticG=(s.Matrix(x).T*MG*s.Matrix(x))[0]
    eq=list(MG.subs({n:0,m:1})*AI)
    eq += [s.diff(acousticG,n).subs(I).subs({n:0,m:1})]
    E,_=s.linear_eq_to_matrix(eq,ps)
    assert E.rank()==5
    # The four proposed polynomials lie in the kernel; independently express them.
    monomials=sorted({mon for f in basis+[H] for mon,_ in s.Poly(f,*x).terms()})
    coefficient_map=s.Matrix([[s.Poly(f,*x).coeff_monomial(mon) for f in basis] for mon in monomials])
    facebasis=s.Matrix.hstack(*[coefficient_map.gauss_jordan_solve(s.Matrix([s.Poly(f,*x).coeff_monomial(mon) for mon in monomials]))[0] for f in [H,u*u,j*j,u*j]])
    assert facebasis.rank()==4 and E*facebasis==s.zeros(E.rows,4)
    MF=acoustic(F)
    eq2=list(MF.subs({n:1,m:0})*AS)
    eq2 += [s.diff((s.Matrix(x).T*MF*s.Matrix(x))[0],m).subs(dict(zip(x,AS)),simultaneous=True).subs({n:1,m:0})]
    E2,_=s.linear_eq_to_matrix(eq2,[al,be,ga,de])
    assert E2.rank()==2
    sol=s.solve(eq2,[be,de])
    assert zero(sol[de]-4*al*(1-h)) and zero(sol[be]-al*(h*h-1))
    lam2,mu=s.symbols('ell mu',real=True)
    restricted=M1.subs({be:lam2*br,ga:lam2+mu,de:lam2*r})
    assert zero(restricted.det()-lam2*mu*r*r)
    passed('full invariant cone: exposed two-dimensional face and extreme-ray algebra',
           first_contact_rank=5,second_contact_rank=2,
           face='cone{J_r,det^2}; non-exposedness also uses the analytic dual-cone proof in report')

    # One exact benchmark demonstrating the reduction from G's old alpha=3.
    rx=s.Rational(-5,2)
    assert ar.subs(r,rx)==s.Rational(15,8)
    assert ar.subs(r,-s.Rational(16,7))==3
    assert zero(3-ar-3*(7*r+16)/(8*(r+2)))
    GG=3*H+s.Rational(35,24)*u*u+j*j-s.Rational(5,2)*u*j
    assert s.expand(GG-J.subs(r,rx)-s.Rational(9,8)*H)==0
    # A rational negative support residual for J_{-5/2}.
    residualx=s.factor(residual.subs({r:rx,al:s.Rational(15,8),t:s.Rational(1,10)}))
    assert residualx<0
    passed('exact example: G-(9/8)H=J_{-5/2} is certified QC',
           negative_polyconvex_support_residual=str(residualx))
    kap=s.Symbol('kappa',real=True)
    Ast=AS.subs(r,rx)
    Rst=s.Matrix([1,0,0,0])
    curv=(Rst.T*s.hessian(GG-kap*H,x).subs(dict(zip(x,Ast)),simultaneous=True)*Rst)[0]
    assert zero(curv-s.Rational(4,9)*(s.Rational(9,8)-kap))
    xx1,xx2,hh1,hh2=s.symbols('xx1 xx2 hh1 hh2',real=True)
    xx=s.Matrix([xx1,xx2]);hh=s.Matrix([hh1,hh2]);dot=xx.dot(hh);nh=hh.dot(hh);nx=xx.dot(xx)
    breg=(xx+hh).dot(xx+hh)**2-nx**2-4*nx*dot-s.Rational(1,3)*nh**2
    assert s.expand(breg-6*(dot+nh/3)**2-2*(nx*nh-dot**2))==0
    assert s.Rational(4,1875)*s.Rational(9,8)==s.Rational(3,1250)
    assert s.Rational(9,8)/s.Rational(3,16000)==6000
    assert s.Rational(3,1250)/s.Rational(1,2500000)==6000
    passed('sharp G distortion subtraction and exact coercivity arithmetic',
           maximal_H_subtraction='9/8',G_coercivity_constant='3/1250',
           note='Beurling operator estimate and heat/density implications are analytic inputs proved or attributed in report; this does not assert the best Jensen constant')
    receipt={'schema':'astra-sharp-frontier-replay/1','status':'ALL_EXACT_GROUPS_PASS',
             'certificate_sha256':hashlib.sha256(raw).hexdigest(),
             'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'python':platform.python_version(),'sympy':s.__version__,
             'elapsed_seconds':round(time.monotonic()-started,3),
             'checks':checks,'scope':'Exact finite algebra and symbolic parameter identities. The report separately proves analytic heat, dual-cone, and support implications. No external review or historical priority claim.'}
    args.receipt.write_text(json.dumps(receipt,indent=2)+'\n')
    print('ALL',len(checks),'EXACT GROUPS PASS. Receipt:',args.receipt,flush=True)

if __name__=='__main__':
    main()
