import sympy as s,pickle
p=pickle.load(open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','rb'));C=p['C'];S=p['S'].subs(s.Symbol('tau2'),0);r=p['r'];J=s.Matrix([[0,-1],[1,0]])
T=s.kronecker_product(s.kronecker_product(J,s.eye(2)),s.eye(6))+s.kronecker_product(s.eye(4),s.kronecker_product(J,s.eye(3)))
G=(C.T*T)[:,12:];G=G.applyfunc(s.factor);print('Gker',len(G.nullspace()),'rank',G.rank(),flush=True)
# congruence basis scalar invariant in ell space (action R on ell; Gram commutation covariant). nullspaceG is spinzero field basis
N=s.Matrix.hstack(*G.nullspace());W=s.Matrix.hstack(*G.columnspace());Tt=N.row_join(W);BB=(Tt.T*S*Tt).applyfunc(s.factor);print('mixzero',BB[:N.cols,N.cols:]==s.zeros(N.cols,W.cols),flush=True)
print('scalarblock',BB[:N.cols,:N.cols]);print('tensorblock',BB[N.cols:,N.cols:]);
p['scalar_basis']=N;p['tensor_basis']=W;p['Sscalar']=BB[:N.cols,:N.cols];p['Stensor']=BB[N.cols:,N.cols:];pickle.dump(p,open('/mnt/data/sharp_frontier/symbolic_endpoint.pkl','wb'))
