import sympy as s,pickle
p=pickle.load(open('/mnt/data/sharp_frontier/sharp_scalar.pkl','rb'));x=p['x'];z=p['z'];B1=p['B1'];B2=p['B2'];t=p['t'];k=s.Symbol('k',real=True)
cs=s.symbols('c0:5');pr=sum((ci*form for ci,form in zip(cs,p['prim'])),s.zeros(4,1));W=pr.jacobian(x).T-pr.jacobian(x)
E=s.expand((B1.T*s.hessian(p['Ft'],x)*B1)[0]+(B2.T*s.hessian(p['Ft'],x)*B2)[0]+(B1.T*W*B2)[0]);J=s.hessian(E,z)/2
A0=s.Matrix([0,-1,t,0]);A1=s.Matrix([(t*t-3)/2,0,0,(t*t-3)/(2*t)]);zz=s.Matrix([1,k,k*k,0,0,0]);Ax=A0+k*A1
traj=(J.subs(dict(zip(x,Ax)))*zz)
eq=list(traj.subs(k,0))+list(traj.diff(k).subs(k,0))
sol=s.linsolve(eq,cs);print('pointwise correction',sol)
if sol is not s.EmptySet:
 sm=dict(zip(cs,list(sol)[0]));JJ=J.subs(sm).applyfunc(s.factor);print('free',JJ.free_symbols-set(x)-{t});
 print('rational witness A diag(1,-1)',JJ.subs(dict(zip(x,[1,0,0,-1]))).applyfunc(s.factor))
 pickle.dump(dict(t=t,x=x,z=z,J=JJ,cs=sm),open('/mnt/data/sharp_frontier/pointwise_heat_obstruction.pkl','wb'))
