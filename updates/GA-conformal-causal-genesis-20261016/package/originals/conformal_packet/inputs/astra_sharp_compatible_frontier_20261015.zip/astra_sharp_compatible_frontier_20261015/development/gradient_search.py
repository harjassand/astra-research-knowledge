"""Exploratory only; double precision is not proof."""
import sympy as s, numpy as np,torch,json,time
from pathlib import Path
out=Path('/mnt/data/sharp_frontier');torch.set_num_threads(1);torch.set_default_dtype(torch.float64)
a,b,c,d=s.symbols('a b c d');X=[a,b,c,d];r=-s.Rational(5,2);alpha=3*r/(8*(r+2));u=a*a+c*c;j=a*d-b*c
F=alpha*((a-d)**2+(b+c)**2)**2+r*(r-1)/6*u*u+j*j+r*u*j
T=np.zeros((4,4,4,4))
for i in range(4):
 for jj in range(4):
  for k in range(4):
   for l in range(4):T[i,jj,k,l]=float(s.diff(F,X[i],X[jj],X[k],X[l])/24)
T=torch.tensor(T)
m=3;N=4*m+1;xx,yy=np.meshgrid(np.arange(N)*2*np.pi/N,np.arange(N)*2*np.pi/N,indexing='ij');
modes=[(p,q) for p in range(m+1) for q in range(-m,m+1) if p>0 or q>0]
Db=[]
for p,q in modes:
 theta=(p*xx+q*yy).flatten();
 for fun in [-np.sin(theta),np.cos(theta)]:Db.append(np.array([p*fun,q*fun]))
Db=torch.tensor(np.stack(Db)) # ncoeff x 2 x grid

def calc(C):
 # C output x coef
 h=torch.einsum('oi,ijg->ojg',C,Db).reshape(4,-1).T
 mom2=torch.einsum('gi,gj->ij',h,h)/len(h)
 mom3=torch.einsum('gi,gj,gk->ijk',h,h,h)/len(h)
 Q=6*torch.einsum('ijkl,kl->ij',T,mom2)
 v=4*torch.einsum('ijkl,jkl->i',T,mom3)
 base=torch.einsum('ijkl,gi,gj,gk,gl->',T,h,h,h,h)/len(h)
 B=-.5*torch.linalg.solve(Q+1e-12*torch.eye(4)*torch.trace(Q),v)
 E=base+.5*v@B
 norm=(h.square().sum(dim=1)**2).mean()
 return E/norm,B,Q,base/norm
records=[]; best=1e9
for seed in range(15):
 torch.manual_seed(seed);C=torch.nn.Parameter(torch.randn(2,len(Db))/3)
 opt=torch.optim.LBFGS([C],max_iter=100,line_search_fn='strong_wolfe',tolerance_grad=1e-10)
 def closure():
  opt.zero_grad(); loss,*_=calc(C);loss.backward();return loss
 try:opt.step(closure)
 except Exception as e:print('error',seed,str(e),flush=True);continue
 loss,B,Q,base=calc(C);val=float(loss.detach()); records.append([seed,val,float(base.detach()),float(torch.linalg.eigvalsh(Q)[0].detach())]);print(records[-1],flush=True)
 if val<best:
  best=val;np.savez(out/'gradient_search_best.npz',C=C.detach().numpy(),B=B.detach().numpy(),modes=modes,m=m,r=float(r),alpha=float(alpha),loss=val)
 json.dump(records,open(out/'gradient_search_log.json','w'),indent=2)
