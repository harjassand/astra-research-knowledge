from pathlib import Path
import sympy as s,pickle,json
src=Path('/mnt/data/sharp_frontier');dst=Path('/mnt/data/astra_sharp_compatible_frontier_20261015')
p=pickle.load(open(src/'symbolic_endpoint.pkl','rb'));r=p['r'];T=p['congruence'];C=p['C'];L=p['bilinear_map'];S=p['Ssimple'];B=(T.T*S*T).applyfunc(s.factor)
blocks=[B[:4,:4],B[4:8,4:8],B[8:10,8:10],B[10:12,10:12]]
assert s.diag(*blocks)==B
Wv=(p['const'][78:,:]+p['coeff'][78:,:]*s.Matrix(p['free'])).subs(p['simple_subs']).applyfunc(s.factor)
W=s.Matrix(6,10,list(Wv))
def encode(e):
 n,d=s.fraction(s.cancel(e));return {'n':[str(v) for v in s.Poly(n,r).all_coeffs()], 'd':[str(v) for v in s.Poly(d,r).all_coeffs()]}
def mat(m):return [[encode(e) for e in list(m.row(i))]for i in range(m.rows)]
cert={'schema':'astra-sharp-shear-contact/1','date':'2026-10-15','repository_pin':'8a1e001ac128468ae8d151c9a859b89ef3b9a664',
'claim_status':'internally_proved_exact_algebra_replayed; external_review_and_priority_unknown',
'parameter':'r < -2','matrix_order':['a','b','c','d'],'jet_order':['phi1_xx','phi1_xy','phi1_yy','phi2_xx','phi2_xy','phi2_yy'],
'bilinear_order':'matrix outer, jet inner','rational_encoding':'n and d contain rational polynomial coefficients in descending powers of r; no expression evaluation',
'integrand':'(3*r/(8*(r+2)))*H+(r*(r-1)/6)*u^2+j^2+r*u*j',
'diffusion':[encode(-(2*r+1)/3),encode(s.Integer(1))],
'omega_pair_order':p['Wpairs'],'quadratic_monomials':p['Amons'],
'C':mat(C),'T':mat(T),'L':mat(L),'blocks':[mat(b)for b in blocks],'omega_coefficients':mat(W),
'block_leading_minors':[[encode(s.factor(b[:i,:i].det()))for i in range(1,b.rows+1)]for b in blocks],
'identity':'(L Z)^T diag(blocks)(L Z)=sum_i diffusion_i D2J_r(A)[B_i,B_i]+omega_A(B1,B2)',
'nonclaims':['No fixed coefficient theorem for delta>0','No general nine-coefficient QC classification','No isotropic |A|^4 subtraction','No positive H subtraction at the sharp endpoint','No external review or priority clearance']}
(dst/'SHARP_CERTIFICATE.json').write_text(json.dumps(cert,indent=2)+'\n')
print((dst/'SHARP_CERTIFICATE.json').stat().st_size)
