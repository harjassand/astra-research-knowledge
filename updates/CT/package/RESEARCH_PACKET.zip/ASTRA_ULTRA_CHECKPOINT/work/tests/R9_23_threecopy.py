"""Exact n=3 rank-two Hessian at |000><000|+|111><111|."""
import sympy as s
from itertools import product

D=3
states=list(product(range(3), repeat=3))
ix={x:i for i,x in enumerate(states)}
W=[ix[(0,0,0)], ix[(1,1,1)]]
J=[i for i in range(27) if i not in W]
# Local L(E_ab)=E_ab for a!=b; L(E_aa)=E_aa - I/2.
L=s.zeros(9,9)
for a in range(3):
  for b in range(3):
    col=3*a+b
    if a!=b: L[col,col]=1
    else:
      for k in range(3): L[3*k+k,col]=s.Rational(1 if k==a else 0)-s.Rational(1,2)
# Local operator tensor cube; index (row multi-index, column multi-index).
# Apply L tensorwise to computational operator matrix units.
labels=[(r,c) for r in range(27) for c in range(27)]
pos={v:i for i,v in enumerate(labels)}
# build only the tangent restriction using local product transition rule

def local_trans(a,b):
  if a!=b: return [(a,b,s.Integer(1))]
  return [(k,k,s.Rational(1 if k==a else 0)-s.Rational(1,2)) for k in range(3) if s.Rational(1 if k==a else 0)-s.Rational(1,2)]

def transitions(r,c):
  rr=states[r]; cc=states[c]
  out=[((),(),s.Integer(1))]
  for a,b in zip(rr,cc):
    nxt=[]
    for ro,co,v in out:
      for u,w,t in local_trans(a,b): nxt.append((ro+(u,),co+(w,),v*t))
    out=nxt
  return [(ix[ro],ix[co],v) for ro,co,v in out if v]

# Tangent coordinates are all W rows or all W columns; A(4), B(50), D(50).
T=[(r,c) for r in range(27) for c in range(27) if r in W or c in W]
assert len(T)==104
Tpos={v:i for i,v in enumerate(T)}
G=s.zeros(104,104)
for j,(r,c) in enumerate(T):
  for rr,cc,v in transitions(r,c):
    if (rr,cc) in Tpos: G[Tpos[(rr,cc)],j]+=v
assert G==G.T
# H0=L^tensor3(C0), diagonal entries.
C0diag={W[0]:1,W[1]:1}
h=[]
for r in range(27):
  h_r=sum(s.prod(s.Rational(1 if states[r][k]==states[t][k] else 0)-s.Rational(1,2) for k in range(3)) for t in W)
  h.append(s.factor(h_r))
# N symmetric holomorphic second-fundamental contribution: pairs D_(j,a) and B_(a,j).
N=s.zeros(104,104)
for a,w in enumerate(W):
  for j in J:
    d=Tpos[(j,w)] # lower-left D
    b=Tpos[(w,j)] # upper-right B
    N[d,b]=N[b,d]=h[j]
# Taylor quadratic Q(z)=z*G*z + Re(z^T N z). Convert to real variables x,y:
# real symmetric Q matrix S satisfies Q=[x;y]^T S [x;y].
Gr=s.re(G); Gi=s.im(G)
Nr=s.re(N); Ni=s.im(N)
S=s.zeros(208,208)
S[:104,:104]=Gr+Nr
S[104:,104:]=Gr-Nr
S[:104,104:]=-Gi-Ni
S[104:,:104]=Gi-Ni
assert S==S.T
print('W',W,'J',len(J),'tangent complex',len(T))
print('h0 diagonal multiplicities', {x:h.count(x) for x in set(h)})
print('G rank',G.rank(),'N rank',N.rank(),'S rank',S.rank())
print('S eigenvalues exact',S.eigenvals())
print('S charpoly factored',s.factor(S.charpoly().as_expr()))
print('negative principal witnesses')
for i in range(208):
  if S[i,i]<0: print(i,S[i,i]); break
print('kernel dimension',len(S.nullspace()))
# Exact chart-ray audit for a basis of the 38-dimensional Hessian kernel.
t=s.symbols('t', real=True)
K=S.nullspace()
def chart_from_real(v):
  z=[s.simplify(v[i]+s.I*v[104+i]) for i in range(104)]
  A=s.eye(2); B=s.zeros(2,25); Dm=s.zeros(25,2)
  for k,(r,c) in enumerate(T):
    if r in W and c in W: A[W.index(r),W.index(c)]=z[k] + (1 if r==c else 0)
    elif r in W: B[W.index(r),J.index(c)]=z[k]
    else: Dm[J.index(r),W.index(c)]=z[k]
  C=s.zeros(27,27)
  blocks=[[A,B],[Dm,Dm*A.inv()*B]]
  for ii,rr in enumerate((W,J)):
    for jj,cc in enumerate((W,J)):
      block=blocks[ii][jj]
      for a,r in enumerate(rr):
        for b,c in enumerate(cc): C[r,c]=block[a,b]
  return C

def qmatrix(C):
  val=0
  for (r,c),cin in zip(labels, [C[r,c] for r,c in labels]):
    if cin==0: continue
    for rr,cc,m in transitions(r,c):
      val += s.conjugate(C[rr,cc])*m*cin
  return s.factor(s.expand_complex(val))
print('kernel ray q(t)')
for a,v in enumerate(K):
  C=chart_from_real([t*x for x in v])
  qt=qmatrix(C)
  num,den=s.fraction(s.factor(qt))
  p=s.Poly(num,t)
  first=None if p.is_zero else next(((k,p.coeff_monomial(t**k)) for k in range(p.degree()+1) if p.coeff_monomial(t**k)!=0),None)
  print(a, s.factor(qt), 'leading',first)
