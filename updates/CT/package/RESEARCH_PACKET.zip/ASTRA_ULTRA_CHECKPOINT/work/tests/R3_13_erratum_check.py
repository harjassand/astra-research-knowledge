"""Exact integer/Fraction check for the rank-two block example in R3-13."""
from fractions import Fraction

# U has 3 first-site blocks, each a 3 x 2 matrix. Columns are
# u_1 = |1,1> + |2,3>, u_2 = |1,2> (zero-based basis labels).
U = [[0, 0] for _ in range(9)]
U[0 * 3 + 0] = [1, 0]
U[0 * 3 + 1] = [0, 1]
U[1 * 3 + 2] = [1, 0]
C = [[sum(U[i][k] * U[j][k] for k in range(2)) for j in range(9)] for i in range(9)]

# C_{ab} are 3x3 blocks; Tr over first site is sum_a C_aa.
D = [[sum(C[a * 3 + i][a * 3 + j] for a in range(3)) for j in range(3)] for i in range(3)]
# Tr over second site is sum_i C_(a,i),(b,i).
E = [[sum(C[a * 3 + i][b * 3 + i] for i in range(3)) for b in range(3)] for a in range(3)]

fro2 = lambda M: sum(x * x for row in M for x in row)
tr = lambda M: sum(M[i][i] for i in range(len(M)))
q1 = lambda M: Fraction(fro2(M), 1) - Fraction(tr(M) ** 2, 2)
q2_direct = Fraction(fro2(C), 1) - Fraction(fro2(D) + fro2(E), 2) + Fraction(tr(C) ** 2, 4)
block_sum = sum(q1([[C[a * 3 + i][b * 3 + j] for j in range(3)] for i in range(3)]) for a in range(3) for b in range(3))
q2_rec = block_sum - q1(D) / 2

assert sum(row[0] * row[1] for row in U) == 0
assert fro2(C) == 5
assert D == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
assert fro2(D) == 3
assert E == [[2, 0, 0], [0, 1, 0], [0, 0, 0]]
assert fro2(E) == 5
assert tr(C) == 3
assert q1(D) == Fraction(-3, 2)
assert block_sum == Fraction(5, 2)  # Includes nonzero C_12 and C_21.
assert q2_direct == q2_rec == Fraction(13, 4)
print({"rank_C": 2, "fro2_C": fro2(C), "trace_first": D, "fro2_first": fro2(D),
       "trace_second": E, "fro2_second": fro2(E), "trace_C": tr(C),
       "q1_D": str(q1(D)), "block_sum": str(block_sum), "q2": str(q2_direct)})
