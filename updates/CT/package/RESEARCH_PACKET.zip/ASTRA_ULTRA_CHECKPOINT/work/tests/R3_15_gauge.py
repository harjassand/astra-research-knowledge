from itertools import combinations
from fractions import Fraction

# Legal physical EPR* weights: b=a+c+d.
a, c, d = 4, 4, 1
b = a + c + d
assert (a, b, c, d) == (4, 9, 4, 1)

# Flattened gate matrix has 2x2 blocks with eigenvalues a±d and b±c.
s = sorted([a+d, abs(a-d), b+c, b-c], reverse=True)
assert s == [13, 5, 5, 3]

# Any parity-supported nonnegative 4-ary signature has two 2x2 blocks.
# Matchgate cone inequalities imply for each block pair (u,v), with other block (w,z):
#   uv = |p_i-p_j| <= p_k+p_l <= (w^2+z^2)/2.
# Test the first inequality for every partition of the four singular values.
pairings = [((s[0],s[1]),(s[2],s[3])),
            ((s[0],s[2]),(s[1],s[3])),
            ((s[0],s[3]),(s[1],s[2]))]
checks=[]
for (u,v),(w,z) in pairings:
    lhs=Fraction(u*v)
    rhs=Fraction(w*w+z*z,2)
    checks.append((lhs,rhs,lhs<=rhs))
assert checks == [(Fraction(65),Fraction(17),False),
                  (Fraction(65),Fraction(17),False),
                  (Fraction(39),Fraction(25),False)]
print('singular values:',s)
print('required block-pair inequalities uv <= (w^2+z^2)/2:')
for row in checks: print(row)
print('No independent O(2) transform on the four ports can enter the nonnegative 4-ary matchgate cone.')
