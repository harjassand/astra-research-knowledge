"""Finite diagnostic for COORDINATOR_ENERGY_DERIVATION.txt; not proof/novelty."""
import json
import math
from fractions import Fraction

largest_ratio = 0.0
for n in (1, 2, 3, 4, 8, 16, 32, 64):
    weights = [math.comb(n, w) / (2 ** n) for w in range(n + 1)]
    for L in (1, 2, 3, 4, 8, 16, 32, 64, 128):
        theta = math.pi / (L + 1)
        c = [math.sqrt(2 / (L + 1)) * math.sin(theta * (k + 1))
             for k in range(L)]
        p = [0.0] * n + [x * x for x in c]
        q = [0.0] * (len(p) + n)
        for r, prob in enumerate(p):
            for w, weight in enumerate(weights):
                q[r + w] += prob * weight
        p += [0.0] * n
        overlaps = [sum(c[k] * c[k + w] for k in range(max(0, L - w)))
                    for w in range(n + 1)]
        A = sum(prob * overlap for prob, overlap in zip(weights, overlaps))
        D = math.sqrt(max(0.0, 1 - A * A))
        Fopt = sum(math.sqrt(x * y) for x, y in zip(p, q))
        Dopt = math.sqrt(max(0.0, 1 - Fopt * Fopt))
        tv = sum(abs(x - y) for x, y in zip(p, q)) / 2
        mu = n + (L - 1) / 2
        support_lower = n / (2 * (L + n - 1))
        mean_lower = n / (8 * math.e * (mu + n))
        uniform_upper = min(1, math.sqrt((1 - math.cos(theta)) * n * (n + 1) / 2))
        assert abs(sum(p) - 1) < 1e-12
        assert abs(sum(q) - 1) < 1e-12
        assert Dopt <= D + 1e-12
        assert tv <= Dopt + 1e-12
        assert support_lower <= tv + 1e-12
        assert mean_lower <= tv + 1e-12
        assert D <= uniform_upper + 1e-12
        for s in (0.001, 0.01, 0.1, 1, 2, 1 / (mu + n)):
            witness = math.exp(-s * mu) * (1 - ((1 + math.exp(-s)) / 2) ** n)
            assert witness <= tv + 1e-12
        flat = sum(Fraction(math.comb(n, w), 2 ** n) * max(Fraction(0), 1 - Fraction(w, L))
                   for w in range(n + 1))
        if n <= L:
            assert flat == 1 - Fraction(n, 2 * L)
        largest_ratio = max(largest_ratio, D / uniform_upper)

example = {"n": 1, "L": 2, "sequential_overlap": 0.75,
           "sector_optimal_overlap": 0.5 + math.sqrt(0.125)}
print(json.dumps({"status": "PASS", "parameter_pairs": 72,
                  "largest_observed_D_over_upper": largest_ratio,
                  "nonoptimality_example": example,
                  "scope": "floating diagnostics plus exact flat-profile rational identities; not a general proof"}, indent=2))
