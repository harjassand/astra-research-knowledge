"""Exact finite checks of selector trace, tree baseline, and variance witness.

This enumerates small fixtures; it does not prove all-size assertions.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json


def selector_trace(nqubits, edges, labels):
    # Four ports per gate: output i, output j, input i, input j.
    size = 4 * len(edges)
    parent = list(range(size))
    xor = [0] * size

    def find(x):
        if parent[x] != x:
            p = parent[x]
            parent[x], p_xor = find(p)
            xor[x] ^= p_xor
        return parent[x], xor[x]

    def join(x, y, parity):
        rx, px = find(x)
        ry, py = find(y)
        if rx == ry:
            return px ^ py == parity
        parent[rx] = ry
        xor[rx] = px ^ py ^ parity
        return True

    local = {
        0: ((0, 2, 0), (1, 3, 0)),  # I
        1: ((0, 1, 1), (2, 3, 1)),  # C = 2 |psi+><psi+|
        2: ((0, 3, 1), (1, 2, 1)),  # D = (X tensor X) SWAP
    }
    for e, label in enumerate(labels):
        for i, j, parity in local[label]:
            if not join(4 * e + i, 4 * e + j, parity):
                return 0
    idle = 0
    for q in range(nqubits):
        ports = [(4 * e + edges[e].index(q), 4 * e + 2 + edges[e].index(q))
                 for e in range(len(edges)) if q in edges[e]]
        if not ports:
            idle += 1
        for i in range(len(ports)):
            if not join(ports[i][0], ports[(i + 1) % len(ports)][1], 0):
                return 0
    return 2 ** (idle + len({find(i)[0] for i in range(size)}))


def moments(n, edges, weights):
    z = Q(0)
    weighted_square = Q(0)
    for labels in product(range(3), repeat=len(edges)):
        w = Q(1)
        for i, label in enumerate(labels):
            w *= weights[i][label]
        tr = selector_trace(n, edges, labels)
        z += w * tr
        weighted_square += w * tr * tr
    normalization = Q(1)
    for w in weights:
        normalization *= sum(w)
    return z, normalization * weighted_square


results = []
for k in range(1, 5):
    eps = Q(1, 100 * k)
    pairs = [(2 * j, 2 * j + 1) for j in range(k)]
    bridges = [(2 * j + 1, 2 * j + 2) for j in range(k - 1)]
    edges = pairs + bridges
    weights = [(Q(4), Q(4), Q(1))] * k + [(Q(1), eps, eps)] * (k - 1)
    z, second = moments(2 * k, edges, weights)
    expected = 26 ** k * (1 + eps) ** (k - 1)
    lower_ratio = Q(189, 169) ** k * ((1 + 2 * eps) / (1 + eps) ** 2) ** (k - 1)
    assert z == expected
    assert second / z ** 2 >= lower_ratio
    # Reverse chronological order as an independent order fixture.
    reverse_z, reverse_second = moments(2 * k, edges[::-1], weights[::-1])
    assert reverse_z == expected
    assert reverse_second == second
    results.append({'k': k, 'epsilon': str(eps), 'z': str(z),
                    'relative_second_moment': str(second / z ** 2),
                    'certified_lower_bound': str(lower_ratio),
                    'selector_configurations': 3 ** len(edges), 'status': 'PASS'})

# Nonbipartite odd-twist fixture: compare a triangle against explicit matrices.
import sympy as s
I = s.eye(4)
C = s.Matrix([[0,0,0,0],[0,1,1,0],[0,1,1,0],[0,0,0,0]])
D = s.Matrix([[0,0,0,1],[0,1,0,0],[0,0,1,0],[1,0,0,0]])


def embed(op, edge, n=3):
    ans = s.zeros(2 ** n)
    i, j = edge
    for x in range(2 ** n):
        col = 2 * ((x >> i) & 1) + ((x >> j) & 1)
        for row in range(4):
            y = x & ~(1 << i) & ~(1 << j)
            y |= (row >> 1) << i
            y |= (row & 1) << j
            ans[y, x] = op[row, col]
    return ans


triangle = [(0, 1), (1, 2), (2, 0)]
embedded = [[embed(op, edge) for op in (I, C, D)] for edge in triangle]
zero_count = 0
for labels in product(range(3), repeat=3):
    op = s.eye(8)
    for e, label in enumerate(labels):
        op = embedded[e][label] * op
    tr = int(s.trace(op))
    assert tr == selector_trace(3, triangle, labels)
    zero_count += tr == 0
assert zero_count > 0
results.append({'fixture': 'triangle_parity_vs_dense_trace', 'cases': 27,
                'zero_traces_from_parity': zero_count, 'status': 'PASS'})
result = {'status': 'PASS; finite checks only', 'fixtures': results}
Path('work/tests/R4_24_connected_loop_result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
