from itertools import combinations
from random import Random


def phase_sum(n, triples):
    total = 0
    vals = []
    for x in range(1 << n):
        p = 0
        for a, b, c in triples:
            p ^= ((x >> a) & 1) & ((x >> b) & 1) & ((x >> c) & 1)
        z = -1 if p else 1
        total += z
        vals.append(z)
    return total, vals


def derivative_quadratic_sums(n, vals):
    sums = []
    for h in range(1 << n):
        s = 0
        for x in range(1 << n):
            s += vals[x] * vals[x ^ h]
        sums.append(s)
    return sums


def translation_cancellers(n, vals):
    return [h for h in range(1 << n)
            if all(vals[x] * vals[x ^ h] == -1 for x in range(1 << n))]


def cubic_polar_rank(n, triples):
    # Matrix of the trilinear polarization with first argument a basis vector,
    # indexed by unordered pairs (b,c). Rank is the rank of h -> T(h,.,.).
    pairs = list(combinations(range(n), 2))
    cols = []
    for h in range(n):
        col = []
        for b, c in pairs:
            z = 0
            for a, d, e in triples:
                if len({a, d, e}) == 3:
                    # T(e_h,e_b,e_c) is 1 iff {h,b,c} is a cubic monomial.
                    z ^= int(set((a, d, e)) == {h, b, c})
            col.append(z)
        cols.append(col)
    # rank of the n columns over F2
    pivots = {}
    for col in cols:
        v = sum(bit << i for i, bit in enumerate(col))
        while v:
            p = v.bit_length() - 1
            if p in pivots:
                v ^= pivots[p]
            else:
                pivots[p] = v
                break
    return len(pivots)


def main():
    # Cubic block family: each block has a nonzero cubic term; translation
    # pairing has no constant-derivative direction, while full polar map has
    # no radical (each coordinate is detected by a pair in its block).
    for blocks in (1, 2):
        n = 3 * blocks
        triples = [(3*i, 3*i+1, 3*i+2) for i in range(blocks)]
        s, vals = phase_sum(n, triples)
        ds = derivative_quadratic_sums(n, vals)
        assert sum(ds) == s*s
        assert translation_cancellers(n, vals) == []
        print(f"block n={n}: S={s}, S^2={s*s}, distinct derivative sums={len(set(ds))}, translation cancellers=0")

    rng = Random(20261010)
    n = 7
    all3 = list(combinations(range(n), 3))
    triples = [t for t in all3 if rng.randrange(2)]
    s, vals = phase_sum(n, triples)
    ds = derivative_quadratic_sums(n, vals)
    assert sum(ds) == s*s
    print(f"seeded dense n={n}: monomials={len(triples)}, polar-map-rank={cubic_polar_rank(n, triples)}, S={s}, distinct derivative sums={len(set(ds))}, translation cancellers={len(translation_cancellers(n, vals))}")

    # Sampling audit: empirical mean estimates S/2^n additively, but resolving
    # a normalized amplitude of magnitude 2^-n/2 needs Omega(2^n) samples.
    print("sampling scale: Hoeffding needs O(eps^-2) samples for normalized additive eps; for eps=2^-n/2 this is O(2^n).")

if __name__ == '__main__':
    main()
