from fractions import Fraction
from itertools import product

# One self-loop gate: the four even subgraphs have weights a,b,b,a.
a, b = Fraction(4), Fraction(9)
weights = [a, b, b, a]
Z = sum(weights)
mean = sum(weights) / len(weights)
second = sum(w*w for w in weights) / len(weights)
relative_second = second / mean**2
assert Z == 26
assert relative_second == Fraction(194, 169)
assert relative_second - 1 == Fraction(25, 169)

# Matched determinant baselines from the exact N190/N191 calculations.
raw_relative_second = Fraction(626, 169)
tuned_relative_second = Fraction(194, 169)
assert relative_second == tuned_relative_second

# Product of k independent copies: relative second moments multiply.
for k in (1, 2, 5, 10):
    got = relative_second**k
    assert got == Fraction(194**k, 169**k)

# The global optimal proposal q(T)=w(T)/Z has zero variance, but uses Z.
q = [w / Z for w in weights]
importance_values = [w / qi for w, qi in zip(weights, q)]
assert all(x == Z for x in importance_values)
assert sum(q) == 1
print('Z=', Z, 'uniform R2=', relative_second, 'raw determinant R2=', raw_relative_second)
print('matched tuned determinant R2=', tuned_relative_second)
print('k=10 uniform loop-space R2=', relative_second**10)
print('optimal importance weight is constant Z=', Z)
