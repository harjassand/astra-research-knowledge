import sympy as s
from itertools import combinations

E=s.Matrix([[0,1],[-1,0]])
J=s.kronecker_product(E,E)
F=s.Matrix([[4,0,0,1],[0,9,4,0],[0,4,9,0],[1,0,0,4]])
S=lambda M: s.simplify(M*J*M.T*J)
assert s.factor(S(F).charpoly().as_expr()) == (s.Symbol('lambda')-169)*(s.Symbol('lambda')-25)**2*(s.Symbol('lambda')-9)

# Exact complex GL(2)^4 transformation: check the claimed congruence law.
i=s.I
A1=s.Matrix([[1+i,2],[1,1]])
A2=s.Matrix([[2,1-i],[1,1]])
A3=s.Matrix([[1,1],[i,2]])
A4=s.Matrix([[2+i,1],[1,1]])
As=[A1,A2,A3,A4]
assert all(A.det()!=0 for A in As)
L=s.kronecker_product(A1,A2)
R=s.kronecker_product(A3,A4)
delta=s.prod(A.det() for A in As)
Mp=s.simplify(L*F*R.T)
assert s.simplify(S(Mp)-delta*L*S(F)*L.inv()) == s.zeros(4)
assert delta != 0

# Generic nonnegative even target: verify its characteristic polynomial factors
# according to the two complementary-product pairs.
p,q,r,t,u,v,w,z=s.symbols('p q r t u v w z', nonnegative=True)
l=s.symbols('l')
Me=s.Matrix([[p,0,0,q],[0,u,v,0],[0,w,z,0],[r,0,0,t]])
char=s.factor(S(Me).charpoly(l).as_expr())
expected=(((l-p*t-q*r)**2-4*p*q*r*t)*((l-u*z-v*w)**2-4*u*v*w*z))
assert s.cancel(char/expected)==1

# Generic nonnegative odd target: its two blocks give nonpositive eigenvalues
# and the same complementary-product pairing structure.
a,b,c,d,e,f,g,h=s.symbols('a b c d e f g h', nonnegative=True)
Mo=s.Matrix([[0,a,b,0],[c,0,0,d],[e,0,0,f],[0,g,h,0]])
char_o=s.factor(S(Mo).charpoly(l).as_expr())
expected_o=((l+a*h+b*g)**2-4*a*b*g*h)*((l+c*f+d*e)**2-4*c*d*e*f)
assert s.cancel(char_o/expected_o)==1

# Serial grouping: F commutes with J, so S(F^k)=F^(2k); its square-root
# spectrum is {13^k,5^k,5^k,3^k}. Every bad pairing remains bad.
assert F*J==J*F
for k in range(1,8):
    fk=F**k
    ev=sorted([13**k,5**k,5**k,3**k], reverse=True)
    pp=[((ev[0],ev[1]),(ev[2],ev[3])),((ev[0],ev[2]),(ev[1],ev[3])),((ev[0],ev[3]),(ev[1],ev[2]))]
    vals=[(x*y,s.Rational(z*z+w*w,2)) for (x,y),(z,w) in pp]
    assert all(lhs>rhs for lhs,rhs in vals)
    assert s.factor(S(fk).charpoly().as_expr()) == s.factor((s.Symbol('lambda')-13**(2*k))*(s.Symbol('lambda')-5**(2*k))**2*(s.Symbol('lambda')-3**(2*k)))

# Exact obstruction for every partition of the square-root spectrum.
roots=[13,5,5,3]
partitions=[((roots[0],roots[1]),(roots[2],roots[3])),
            ((roots[0],roots[2]),(roots[1],roots[3])),
            ((roots[0],roots[3]),(roots[1],roots[2]))]
checks=[]
for (a,b),(c,d) in partitions:
    checks.append((a*b,s.Rational(c*c+d*d,2)))
assert checks==[(65,17),(65,17),(39,25)]
assert all(lhs>rhs for lhs,rhs in checks)
print('delta=',delta)
print('spectrum S(F)=',S(F).eigenvals())
print('all product-triangle necessary inequalities fail:',checks)
print('verified S(LFR^T)=delta*L*S(F)*L^-1 for exact complex GL(2)^4 example')
print('verified generic even-target characteristic-polynomial formula')
