"""Dimensionless checks for the near-field resolution tradeoff in round1/06.txt."""
import math

# Compare 2 delta_0 with delta_{-d/2} + delta_{d/2} in a scalar Helmholtz
# boundary-source model. Their source Fourier transforms differ by
# 2*cos(q*d/2)-2. For q <= k this is O((k*d)^2); at q=pi/d it equals -2.
for kd in (0.02, 0.1, 0.25):
    q_far = kd  # set d=1, so k=kd
    diff_far = abs(2 * math.cos(q_far / 2) - 2)
    assert diff_far <= kd * kd / 4 + 1e-15
    assert abs(diff_far - (kd * kd / 4)) < kd**4 / 100 + 1e-14

q_delta = math.pi  # d=1, accessible at sensor pitch <= 1/2
source_difference = abs(2 * math.cos(q_delta / 2) - 2)
assert math.isclose(source_difference, 2.0)

# Evanescent Green multiplier is exp(-q*h)/(2q). Near standoff h=c*d
# retains an O(d) absolute signal, while fixed h suppresses it exponentially.
d = 1.0
q = math.pi / d
near_h = 0.25 * d
near_signal = source_difference * math.exp(-q * near_h) / (2 * q)
assert math.isclose(near_signal / d, math.exp(-math.pi / 4) / math.pi)
fixed_h = 1.0
fixed_signal = source_difference * math.exp(-q * fixed_h) / (2 * q)
assert fixed_signal < near_signal

print({"farfield_difference_bound_tested": True,
       "nearfield_source_spectrum_at_q_pi_over_d": source_difference,
       "nearfield_signal_over_d": near_signal / d,
       "fixed_standoff_signal_over_d": fixed_signal / d})
