"""Exact smoke test of lattice acquisition and bivariate interpolation."""
import sympy as s
x,y=s.symbols('x y')
polys=[4*x**2+3*x*y-y**2+2*x-5*y+7,
       -2*x**3+5*x*y**2+3*y**2-11]
for f in polys:
    d=s.Poly(f,x,y).total_degree()
    vals={(i,j):int(f.subs({x:i,y:j})) for i in range(d+1) for j in range(d+1)}
    # Iterated Lagrange interpolation, exact over Q.
    gx=lambda i: s.prod((x-r)/(i-r) for r in range(d+1) if r!=i)
    gy=lambda j: s.prod((y-r)/(j-r) for r in range(d+1) if r!=j)
    rec=s.expand(sum(vals[i,j]*gx(i)*gy(j) for i in range(d+1) for j in range(d+1)))
    assert s.expand(rec-f)==0
    for v in vals.values():
        assert round(v+0.3)==v and round(v-0.3)==v
print('exact interpolation and strict 0.3 rounding pass')
