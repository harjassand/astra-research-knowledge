"""Finite sanity check for the N=2 Gaussian/permanent construction."""
from itertools import permutations


def permanent(A):
    n = len(A)
    return sum(__import__('math').prod(A[i][p[i]] for i in range(n))
               for p in permutations(range(n)))


def build_B(A, t):
    n = len(A)
    cols = []
    for i in range(n):
        for j in range(i + 1, n):
            if A[i][j]:
                col = [0] * n
                col[i] = col[j] = 1
                cols.append(col)
    for i in range(n):
        assert t >= sum(A[i])
        for _ in range(t - sum(A[i])):
            col = [0] * n
            col[i] = 1
            cols.append(col)
    return [[col[i] for col in cols] for i in range(n)]


def cmul(a, b):
    return (a[0] * b[0] - a[1] * b[1],
            a[0] * b[1] + a[1] * b[0])


def add_poly(dst, exp, coeff):
    old = dst.get(exp, (0, 0))
    new = (old[0] + coeff[0], old[1] + coeff[1])
    if new == (0, 0):
        dst.pop(exp, None)
    else:
        dst[exp] = new


def complex_polynomial(B):
    n, k = len(B), len(B[0])
    zero = (0,) * (2 * k)
    poly = {zero: (1, 0)}
    for i in range(n):
        factor = {}
        for j, value in enumerate(B[i]):
            if value:
                ex = [0] * (2 * k)
                ex[j] = 1
                factor[tuple(ex)] = (value, 0)
                ex = [0] * (2 * k)
                ex[k + j] = 1
                factor[tuple(ex)] = (0, value)
        nxt = {}
        for a, ca in poly.items():
            for b, cb in factor.items():
                exp = tuple(x + y for x, y in zip(a, b))
                add_poly(nxt, exp, cmul(ca, cb))
        poly = nxt
    return poly


def gaussian_moment(power):
    if power % 2:
        return 0
    value = 1
    for j in range(1, power, 2):
        value *= j
    return value


def complex_l2_norm(poly):
    """E[|P(X+iY)|^2] by exact monomial-pair Gaussian moments."""
    exponents = list(poly)
    total = (0, 0)
    for a in exponents:
        ca = poly[a]
        for b in exponents:
            cb = poly[b]
            moment = 1
            for x, y in zip(a, b):
                moment *= gaussian_moment(x + y)
                if not moment:
                    break
            conjugate_cb = (cb[0], -cb[1])
            term = cmul(ca, conjugate_cb)
            total = (total[0] + moment * term[0],
                     total[1] + moment * term[1])
    assert total[1] == 0
    return total[0]


def main():
    for bit in (0, 1):
        # n=1 input M=[bit], hence N=2 and A=[[0,bit],[bit,0]].
        A = [[0, bit], [bit, 0]]
        for t in range(2, 5):
            B = build_B(A, t)
            gram = [[sum(B[i][k] * B[j][k] for k in range(len(B[0])))
                     for j in range(2)] for i in range(2)]
            assert gram == [[t, bit], [bit, t]]
            lhs = complex_l2_norm(complex_polynomial(B))
            rhs = (2 ** 2) * permanent(gram)
            assert lhs == rhs, (bit, t, lhs, rhs)
    print('passed: N=2 exact Gaussian Wick norm and Gram construction for all 1x1 0/1 matrices, t=2,3,4')


if __name__ == '__main__':
    main()
