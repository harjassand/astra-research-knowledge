"""Exact regression test for the frozen Round-8 determinant-volume candidate."""
import itertools
import sympy as sp


def minors(A):
    out = []
    for t in range(1, min(A.rows, A.cols) + 1):
        for I in itertools.combinations(range(A.rows), t):
            for J in itertools.combinations(range(A.cols), t):
                out.append(int(A.extract(I, J).det()))
    return out


def check(T, U, V):
    A = T + U * V
    r, m = A.shape
    assert A.rank() == r
    # Fixture-level structural certificate audit: TU means every square minor is 0, +/-1.
    assert set(minors(T)) <= {-1, 0, 1}
    bases = []
    for B in itertools.combinations(range(m), r):
        d = int(A[:, B].det())
        if d:
            bases.append((B, d))
    G = A * A.T
    Z = int(G.det())
    assert Z == sum(d * d for _, d in bases) > 0

    k = U.cols
    L = sum(
        sp.binomial(r, j) ** 2 * sp.binomial(k, j) * sp.factorial(j) ** 2
        for j in range(min(k, r) + 1)
    )
    assert max(abs(d) for _, d in bases) <= L

    P = A.T * G.inv() * A
    assert P * P == P and P.trace() == r
    probs = []
    for B, d in bases:
        detP = sp.factor(P.extract(B, B).det())
        assert detP == sp.Rational(d * d, Z)
        probs.append(detP)
    assert sum(probs) == 1

    # Enumerate all ordered generation paths. Conditional mass at j is the
    # projection residual determinant ratio divided by remaining rank.
    paths = []
    for order in itertools.permutations(range(m), r):
        prob = sp.Integer(1)
        S = []
        for t, j in enumerate(order):
            prior = sp.Integer(1) if not S else sp.factor(P.extract(S, S).det())
            S2 = S + [j]
            after = sp.factor(P.extract(S2, S2).det())
            prob *= (after / prior) / (r - t) if prior else 0
            S = S2
        paths.append((tuple(sorted(order)), prob))
    for B, d in bases:
        assert sum(p for b, p in paths if b == B) == sp.Rational(d * d, Z)
    assert sum(p for _, p in paths) == 1

    # Exact inverse-weight moments and claimed variance bound.
    mu = sp.Rational(len(bases), Z)
    second = sum((sp.Rational(1, d * d) for _, d in bases), sp.Rational(0)) / Z
    relvar = sp.factor(second / mu**2 - 1)
    assert relvar >= 0
    assert relvar <= sp.Rational(Z, len(bases)) - 1
    assert sp.Rational(Z, len(bases)) <= L**2
    return A, bases, Z, L, relvar


# Rank-three network/TU matrix with a one-dimensional signed update.
T = sp.Matrix([[1, 0, 0, 1, 0],
               [0, 1, 0, 0, 1],
               [0, 0, 1, 0, 0]])
U = sp.Matrix([[1], [1], [0]])
V = sp.Matrix([[1, 0, 1, 0, 1]])
A, bases, Z, L, relvar = check(T, U, V)
assert A == sp.Matrix([[2, 0, 1, 1, 1],
                       [1, 1, 1, 0, 2],
                       [0, 0, 1, 0, 0]])
assert [(B, d) for B, d in bases] == [
    ((0, 1, 2), 2), ((0, 2, 3), 1), ((0, 2, 4), -3),
    ((1, 2, 3), 1), ((1, 2, 4), 1), ((2, 3, 4), 2)]
assert (Z, L, relvar) == (20, 10, sp.Rational(163, 162))

# Degenerate update rank k=0 must reduce to the exact TU identity.
T0 = sp.Matrix([[1, 0, 1], [0, 1, 1]])
U0 = sp.zeros(2, 0)
V0 = sp.zeros(0, 3)
_, b0, z0, l0, v0 = check(T0, U0, V0)
assert l0 == 1 and z0 == len(b0) and v0 == 0
print(f"PASS: k=1 fixture: bases={len(bases)}, Z={Z}, L={L}, relvar={relvar}")
print(f"PASS: k=0 TU degeneration: bases={len(b0)}, Z={z0}, L={l0}, relvar={v0}")
