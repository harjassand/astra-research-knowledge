"""Exact Hessian of q_2 on the local rank-2 chart at P tensor |0><0|."""
import sympy as s

I=s.I
N=9
base=[0,3]                 # (a,i)=(0,0),(1,0), a-major ordering
other=[i for i in range(N) if i not in base]
P=s.diag(1,1,0)
E=s.diag(1,0,0)
C0=s.kronecker_product(P,E)

def qbil(X,Y):
    # Real polarization of q(X)=||X||^2 - 1/2(sum partial-trace norms)+1/4|tr X|^2
    z=sum(s.conjugate(X[i,j])*Y[i,j] for i in range(N) for j in range(N))
    def ptr1(A):
        # trace first subsystem: result indexed second-subsystem coords
        return s.Matrix(3,3,lambda i,j: sum(A[3*a+i,3*a+j] for a in range(3)))
    def ptr2(A):
        return s.Matrix(3,3,lambda a,b: sum(A[3*a+i,3*b+i] for i in range(3)))
    for T in (ptr1,ptr2):
        U,V=T(X),T(Y)
        z -= s.Rational(1,2)*sum(s.conjugate(U[i,j])*V[i,j] for i in range(3) for j in range(3))
    z += s.Rational(1,4)*s.conjugate(s.trace(X))*s.trace(Y)
    return s.re(s.expand_complex(z))

# Coordinates: real and imaginary parts of A-I (2x2), D (7x2), E (2x7).
shapes=[(2,2),(7,2),(2,7)]
vars=[]
for label,shape in zip(('a','d','e'),shapes):
    for i in range(shape[0]):
      for j in range(shape[1]): vars.append((label,i,j,'r'))
for label,shape in zip(('a','d','e'),shapes):
    for i in range(shape[0]):
      for j in range(shape[1]): vars.append((label,i,j,'i'))
dim=len(vars)

def chart(vals):
    A=s.eye(2); D=s.zeros(7,2); F=s.zeros(2,7)
    for val,(lab,i,j,part) in zip(vals,vars):
        z=val if part=='r' else I*val
        if lab=='a': A[i,j]+=z
        elif lab=='d': D[i,j]+=z
        else: F[i,j]+=z
    blocks=[[A,A*F],[D*A,D*A*F]]
    C=s.zeros(9,9)
    # chart block order [base;other]
    for ii,rr in enumerate((base,other)):
      for jj,cc in enumerate((base,other)):
        B=blocks[ii][jj]
        for i,r in enumerate(rr):
          for j,c in enumerate(cc): C[r,c]=B[i,j]
    return C

zero=[s.Integer(0)]*dim
Cv=chart(zero)
assert Cv==C0
# Directional first and mixed second derivatives, obtained by substituting t*u+s*v.
t,w=s.symbols('t w', real=True)
H=s.zeros(dim,dim)
for i in range(dim):
  ui=[s.Integer(0)]*dim; ui[i]=1
  Ci=chart([t*x for x in ui])
  Ui=Ci.diff(t).subs(t,0)
  for j in range(i,dim):
    uj=[s.Integer(0)]*dim; uj[j]=1
    if i==j:
      Cij=Ci.diff(t,2).subs(t,0)
    else:
      Cij=chart([t*x+w*y for x,y in zip(ui,uj)]).diff(t,w).subs({t:0,w:0})
    h=2*qbil(Ui, (chart([w*x for x in uj])).diff(w).subs(w,0)) + 2*qbil(C0,Cij)
    H[i,j]=H[j,i]=s.factor(h)
print('dimension',dim,'rank',H.rank())
print('diagonal',sorted(set(H[i,i] for i in range(dim))))
print('eigenvalues',H.eigenvals())
print('kernel basis')
for v in H.nullspace(): print([x for x in v if x!=0], 'support', [k for k,x in enumerate(v) if x])
print('characteristic polynomial',s.factor(H.charpoly().as_expr()))
print('coordinate order',vars)
print('kernel-ray polynomials')
for kk,v in enumerate(H.nullspace()):
    Ct=chart([t*x for x in v])
    qt=s.factor(qbil(Ct,Ct))
    print(kk, s.factor(qt))
import random
K=H.nullspace()
random.seed(23)
neg=[]
for trial in range(100):
    coeff=[random.randint(-2,2) for _ in K]
    if not any(coeff): continue
    v=[sum(coeff[a]*K[a][i] for a in range(len(K))) for i in range(dim)]
    qt=s.factor(qbil(chart([t*x for x in v]), chart([t*x for x in v])))
    if qt!=0 and s.Poly(qt,t).coeff_monomial(t**4)<0: neg.append((coeff,qt)); break
print('sampled-negative',neg)
