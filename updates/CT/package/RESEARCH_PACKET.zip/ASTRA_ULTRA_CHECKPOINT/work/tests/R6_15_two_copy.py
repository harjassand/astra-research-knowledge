"""Exact audit of the canonical two-copy coefficient-square measure on an EPR triangle."""
from functools import lru_cache
import itertools
import sympy as s

@lru_cache(None)
def pf_flat(entries, n):
    M = s.Matrix(n, n, entries)
    if n == 0:
        return s.Integer(1)
    if n % 2:
        return s.Integer(0)
    out = 0
    for j in range(1, n):
        keep = [i for i in range(n) if i not in (0, j)]
        minor = M.extract(keep, keep)
        out += (-1) ** (j + 1) * M[0, j] * pf_flat(tuple(minor), n - 2)
    return s.expand(out)

def pf(M):
    return pf_flat(tuple(M), M.rows)

# Chronological triangle gates (01),(12),(20), ports (out_i,out_j,in_i,in_j).
z = s.symbols('z0:6')
wires = [((0, 0), (2, 3)), ((2, 1), (0, 2)),
         ((0, 1), (1, 2)), ((1, 0), (0, 3)),
         ((1, 1), (2, 2)), ((2, 0), (1, 3))]
A = s.zeros(12)
for t in range(3):
    entries = {(0, 1): s.Rational(1, 2), (2, 3): s.Rational(1, 2),
               (0, 2): s.Rational(3, 2), (1, 3): s.Rational(3, 2),
               (0, 3): s.Integer(1), (1, 2): s.Integer(1)}
    for (i, j), v in entries.items():
        A[4*t+i, 4*t+j] = v
        A[4*t+j, 4*t+i] = -v
for k, (p, q) in enumerate(wires):
    i, j = 4*p[0]+p[1], 4*q[0]+q[1]
    A[i, j] += z[k]
    A[j, i] -= z[k]

P = s.Poly(pf(A), *z)
W = s.expand(sum(c**2 * s.prod(z[i] for i, e in enumerate(mon) if e)
                 for mon, c in P.terms()))
expected = (16*z[0]*z[1]*z[2]*z[3]*z[4]*z[5]
 +81*z[0]*z[1]*z[2]*z[3]+81*z[0]*z[1]*z[4]*z[5]+81*z[0]*z[1]
 +z[0]*z[2]*z[4]+z[0]*z[2]*z[5]+z[0]*z[3]*z[4]+16*z[0]*z[3]*z[5]
 +16*z[1]*z[2]*z[4]+z[1]*z[2]*z[5]+z[1]*z[3]*z[4]+z[1]*z[3]*z[5]
 +81*z[2]*z[3]*z[4]*z[5]+81*z[2]*z[3]+81*z[4]*z[5]+16)/16
assert s.expand(W-expected) == 0
ones = {q: 1 for q in z}
assert W.subs(ones) == s.Rational(139, 4)
assert 64 * W.subs(ones) == 2224  # physical Z = prod a_v * E|Pf|^2
D01 = s.diff(W, z[0])*s.diff(W, z[1]) - W*s.diff(W, z[0], z[1])
assert D01.subs(ones) == -s.Rational(2085, 8)

# Encode each wire's physical 0/1 choice by exactly one of u_i,z_i.
u = s.symbols('u0:6')
choice_vars = (*u, *z)
Q = s.expand(sum(c*s.prod((z[i] if mon[i] else u[i]) for i in range(6))
                 for mon, c in s.Poly(W, *z).terms()))
Hess = s.hessian(Q, choice_vars).subs({v: 1 for v in choice_vars})
eigs = Hess.eigenvals()
# Three positive Hessian eigenvalues: 695/8, 185/8 (twice).
assert eigs[s.Rational(695, 8)] == 1
assert eigs[s.Rational(185, 8)] == 2
# A log-concave homogeneous polynomial has Hessian with at most one
# positive eigenvalue at any positive point; this natural global encoding fails.

# The untuned determinant estimator's exact second moment on the same loop.
ys = []
for signs in itertools.product((-1, 1), repeat=6):
    ys.append(s.expand(pf(A.subs(dict(zip(z, signs))))**2))
EY = sum(ys)/64
EY2 = sum(y*y for y in ys)/64
assert EY == s.Rational(139, 4)
assert EY2 == s.Rational(115909, 16)
assert EY2/EY**2 == s.Rational(115909, 19321)

# Odd cycle transfer partition function for a=b? Physical F=(a,b,c,d)=(4,9,4,1).
for n in (1, 3, 5, 7):
    Zn = 13**n + 3**n
    assert Zn == 2**0 * (13**n + 3**n)
print('exact triangle norm, Z=2224, Rayleigh defect=-2085/8,')
print('fixed-choice Hessian has >=3 positive eigenvalues; odd-cycle Z_n=13^n+3^n')
print('untuned triangle relative second moment=115909/19321')
