"""Small dense diagnostic for the EPR-Hamiltonian gap; not a proof."""
from itertools import combinations
import numpy as np


def gap(n, edges, s):
    dim = 1 << n
    A = np.zeros((dim, dim), dtype=float)
    for i, j in edges:
        for x in range(dim):
            bi, bj = (x >> i) & 1, (x >> j) & 1
            if bi == bj:
                A[x, x] += 1.0 if bi == 0 else s * s
                A[x, x ^ (1 << i) ^ (1 << j)] += s
    vals = np.linalg.eigvalsh(A)
    return vals[-1] - vals[-2]


def dumbbell(n):
    h = n // 2
    left = [(i, j) for i in range(h) for j in range(i + 1, h)]
    right = [(i, j) for i in range(h, n) for j in range(i + 1, n)]
    return left + right + [(h - 1, h)]


if __name__ == "__main__":
    for n in (8, 10):
        edges = dumbbell(n)
        for s in (0.8, 0.95, 0.99):
            g = gap(n, edges, s)
            print(f"dumbbell n={n} s={s}: gap={g:.12g}, bound={1-s*s:.12g}")

    # Exhaustive connected simple graphs through n=5 at a small set of s.
    for n in (3, 4, 5):
        all_edges = list(combinations(range(n), 2))
        checked = 0
        for mask in range(1, 1 << len(all_edges)):
            edges = [e for k, e in enumerate(all_edges) if (mask >> k) & 1]
            seen = {0}
            while True:
                grown = seen | {v for a, b in edges for u, v in ((a, b), (b, a)) if u in seen}
                if grown == seen:
                    break
                seen = grown
            if len(seen) != n:
                continue
            checked += 1
            for s in (0.2, 0.5, 0.8, 0.95):
                g = gap(n, edges, s)
                assert g >= 1 - s * s - 1e-9, (n, edges, s, g)
        print(f"exhaustive n={n}: checked {checked} connected graphs")
