"""Exact finite checks of the coordinator's LY product norm inequality.

These are consistency checks; the all-size proof is in COORDINATOR_COMPLEX_LY.
Each one-qubit factor has weighted nonconstant coefficient l1 at r=2 <=1,
so the strict open-polydisk triangle inequality certifies LY(2).
Tensor products and independent input/output wire permutations preserve LY.
"""
from pathlib import Path
import json
import sympy as S

R = S.Rational
factors = [S.Matrix([[1,R(1,20)],[R(1,20),R(1,5)]]),
           S.Matrix([[1,R(1,20)],[0,-R(1,5)]]),
           S.Matrix([[1,0],[-R(1,20),R(1,5)]]),
           S.diag(1,R(1,4))]
for A in factors:
    assert 2*(abs(A[0,1])+abs(A[1,0]))+4*abs(A[1,1]) <= 1

def norm_sq(A):
    return sum(x*x for x in A)

checks = 0
for n in (1,2,3):
    d = 2**n
    M = S.eye(d)
    # A cyclic output-wire permutation changes inter-layer pairing.
    perm = [((x<<1)&(d-1)) | (x>>(n-1)) for x in range(d)]
    P = S.zeros(d)
    for x in range(d):
        P[perm[x],x] = 1
    for t in range(1,17):
        K = factors[t % len(factors)]
        for j in range(1,n):
            K = S.kronecker_product(K,factors[(t+j)%len(factors)])
        K = P*K if t%2 else K*P.T
        M = K*M
        assert M[0,0] != 0
        col = M[:,0]
        B = col*M[0,:]/M[0,0]
        lhs = norm_sq(M-B)
        rhs = 4*5**n*R(1,16)**t*norm_sq(col)
        assert lhs <= rhs, (n,t,lhs,rhs)
        checks += 1

# A genuinely complex, nonnormal factor with a direct LY(2) certificate.
A = S.Matrix([[1,S.I/20],[0,S.I/5]])
assert 2*abs(A[0,1])+4*abs(A[1,1]) < 1
M = S.eye(2)
for t in range(1,17):
    M = (A if t%2 else A.T)*M
    col = M[:,0]
    B = col*M[0,:]/M[0,0]
    lhs = S.simplify(sum(x*S.conjugate(x) for x in M-B))
    rhs = S.simplify(20*R(1,16)**t*sum(x*S.conjugate(x) for x in col))
    assert lhs <= rhs, (t,lhs,rhs)
    checks += 1

# Sharp eigenvalue ratio example, with boundary zeros allowed by open LY.
assert S.diag(1,R(1,4)).eigenvals() == {S.Integer(1):1,R(1,4):1}
result = {'status':'PASS','exact_product_checks':checks,'qubits':[1,2,3],
          'max_layers':16,'radius':2,'complex_nonnormal_included':True,
          'scope':'Finite consistency checks only; no novelty or algorithm validation'}
Path('work/tests/R6_LY_transfer_result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
