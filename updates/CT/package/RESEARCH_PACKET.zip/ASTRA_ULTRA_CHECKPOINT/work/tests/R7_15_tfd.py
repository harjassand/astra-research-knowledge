"""Exact pure-field TFD parent gap and postselection checks."""
import sympy as s

n=2
mu,beta=s.symbols('mu beta', positive=True)
t=s.exp(2*beta*mu)
D=2**n
# Q=I-|Omega><Omega|/D. K^{-1} multiplies |x,y> by exp(beta*mu*|x|).
Omega=s.zeros(D**2,1)
for x in range(D): Omega[x*D+x]=1
Q=s.eye(D**2)-Omega*Omega.T/D
L=s.diag(*[s.exp(beta*mu*bin(x).count('1')) for x in range(D) for _y in range(D)])
P=s.simplify(L*Q*L)
# K|Omega> has entries exp(-beta mu |x|) on |x,x>; P kills it.
psi=s.zeros(D**2,1)
for x in range(D): psi[x*D+x]=s.exp(-beta*mu*bin(x).count('1'))
assert all(s.simplify(v)==0 for v in P*psi)
# Every off-diagonal |x,y>, x!=y is an eigenvector with eigenvalue exp(2 beta mu |x|).
for x in range(D):
 for y in range(D):
  if x!=y:
   idx=x*D+y
   assert s.simplify(P[idx,idx]-t**bin(x).count('1'))==0
   assert all(s.simplify(P[j,idx])==0 for j in range(D**2) if j!=idx)
assert P[0*D+1,0*D+1]==1
assert s.simplify(P[3*D+2,3*D+2]-t**2)==0

# Shifted pure-field partition function and postselection probability.
z=s.symbols('z', positive=True) # z=exp(-2 beta mu)
Zshift=(1+z)**n
p=Zshift/D
assert s.simplify(p-((1+z)/2)**n)==0
# Low-temperature entropy tail for a gap Delta>=2mu.
eps=s.symbols('eps', positive=True)
threshold=s.log(3*(D-1)/eps)/(2*mu)
assert s.simplify((D-1)*s.exp(-2*mu*threshold)-eps/3)==0
print('pure-field parent has positive eigenvalues 1 and exp(2 beta mu n);')
print('normalized gap <= exp(-2 beta mu n); postselection p=[(1+e^-2beta_mu)/2]^n')
print('low-temperature tail bound reaches eps/3 at stated beta threshold')
