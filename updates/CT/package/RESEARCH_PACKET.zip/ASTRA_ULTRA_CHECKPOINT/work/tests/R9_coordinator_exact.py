"""Exact finite checks for the stated lift, skew zeroes and sector obstruction.

These fixtures supplement, and do not establish, the all-size proofs.
"""
from itertools import product
from collections import defaultdict
import json
import random
import sympy as s

rng = random.Random(901)

def q(C, n):
    states = list(product(range(3), repeat=n))
    nonzero = [(states[i], states[j], C[i,j])
               for i in range(3**n) for j in range(3**n) if C[i,j] != 0]
    answer = 0
    for mask in range(1 << n):
        traced = [k for k in range(n) if mask >> k & 1]
        kept = [k for k in range(n) if not (mask >> k & 1)]
        entries = defaultdict(lambda: s.S.Zero)
        for a,b,v in nonzero:
            if all(a[k] == b[k] for k in traced):
                entries[tuple(a[k] for k in kept), tuple(b[k] for k in kept)] += v
        norm = sum(s.expand(v*s.conjugate(v)) for v in entries.values())
        answer += (-s.Rational(1,2))**len(traced) * norm
    return s.simplify(answer)

def vec(d):
    return s.Matrix([rng.randint(-2,2)+s.I*rng.randint(-2,2) for _ in range(d)])

lifts = []
for m in (1,2):
    d = 3**m
    for trial in range(3):
        a,v,u,b = [vec(d) for _ in range(4)]
        X = a*v.H + u*b.H
        R = u*v.H
        t = s.Rational(trial+1, trial+2)
        U = s.zeros(3*d,2)
        V = s.zeros(2,3*d)
        U[:d,0] = u
        U[:d,1] = t*a
        U[d:2*d,1] = u
        V[0,:d] = v.H
        V[0,d:2*d] = t*b.H
        V[1,d:2*d] = v.H
        C = U*V
        assert (C[:d,:d]-R).applyfunc(s.expand).is_zero_matrix
        assert (C[:d,d:2*d]-t*X).applyfunc(s.expand).is_zero_matrix
        assert (C[d:2*d,d:2*d]-R).applyfunc(s.expand).is_zero_matrix
        actual = q(C,m+1)
        expected = t*t*q(X,m)
        assert actual == expected
        lifts.append({'m':m,'trial':trial,'value':str(actual)})

zeros = []
eps = s.Matrix([[0,1],[-1,0]])
for n in (1,2,3):
    d = 2**n
    J = s.Matrix([[1]])
    for _ in range(n):
        J = s.kronecker_product(J,eps)
    u,v = vec(d),vec(d)
    K = u*v.T-v*u.T
    Cb = K*J.inv()
    assert K.rank() == 2 and ((Cb*J).T+Cb*J).applyfunc(s.expand).is_zero_matrix
    assert (J*Cb.T*J.inv()-(-1)**(n+1)*Cb).applyfunc(s.expand).is_zero_matrix
    C = s.zeros(3**n)
    ids = [sum(bit*3**(n-1-k) for k,bit in enumerate(bits))
           for bits in product(range(2),repeat=n)]
    for i,r in enumerate(ids):
        for j,c in enumerate(ids):
            C[r,c] = Cb[i,j]
    assert q(C,n) == 0
    zeros.append({'n':n,'rank':2,'q':'0'})

sectors = []
for n in range(2,9):
    d = 2**n
    # Explicitly average the 2^n partial swaps of each endpoint tensor.
    projection = defaultdict(lambda: s.S.Zero)
    for a,b in ((0,d-1),(d-1,0)):
        for mask in range(d):
            aa = (a & ~mask) | (b & mask)
            bb = (b & ~mask) | (a & mask)
            projection[aa,bb] += s.Rational(1,d)
    entries = {key:-value for key,value in projection.items()}
    entries[0,d-1] += 1
    entries[d-1,0] += 1
    assert all(c == (d-1)^r for r,c in entries)
    squares = sorted((value**2 for value in entries.values()),reverse=True)
    ratio = s.factor(sum(squares[:2])/sum(squares))
    assert ratio == 1-s.Rational(2,d)
    sectors.append({'n':n,'top_two_ratio':str(ratio)})

result = {'status':'PASS_EXACT_FINITE_CHECKS_ONLY','lifts':lifts,
          'binary_skew_zeros':zeros,'sector_concentration':sectors}
print(json.dumps(result,indent=2))
