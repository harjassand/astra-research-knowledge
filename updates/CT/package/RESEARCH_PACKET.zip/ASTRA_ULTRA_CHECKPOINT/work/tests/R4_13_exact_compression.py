"""Exact finite diagnostics for branch-preserving Choi compression.
Not a proof of asymptotic complexity, completeness, or novelty.
"""
import json
from math import lcm
import sympy as s


def vec(b):
    return b.reshape(b.rows*b.cols, 1)


def proj(b):
    v = vec(b)
    return (v*v.conjugate().T).applyfunc(s.expand)


def real_coordinates(p):
    z = [s.re(p[i,i]) for i in range(p.rows)]
    for i in range(p.rows):
        for j in range(i+1,p.cols):
            z += [s.re(p[i,j]), s.im(p[i,j])]
    assert len(z) == p.rows**2
    assert all(x.is_Rational for x in z)
    return s.Matrix(z)


def run(name, instruments, expected_rank_one):
    d = instruments[0][0].rows
    ident = s.eye(d)
    for inst in instruments:
        assert sum((k.conjugate().T*k for k in inst), s.zeros(d)) == ident
    branches = [ident]
    numerators = [1]
    den = 1
    direct = proj(ident)
    eliminated = 0
    peak_bits = 1
    sizes = []
    for inst in instruments:
        candidates, nums = [], []
        for b,n in zip(branches,numerators):
            for k in inst:
                c = (k*b).applyfunc(s.expand)
                if c != s.zeros(d):
                    candidates.append(c)
                    nums.append(n)
        direct = sum((s.kronecker_product(k,ident)*direct*s.kronecker_product(k.conjugate().T,ident)
                      for k in inst), s.zeros(d*d)).applyfunc(s.expand)
        while len(candidates) > d**4:
            mat = s.Matrix.hstack(*(real_coordinates(proj(b)) for b in candidates))
            hq = mat.nullspace()[0]
            common = lcm(*(int(x.q) for x in hq))
            h = [int(x*common) for x in hq]
            assert any(x>0 for x in h) and any(x<0 for x in h)
            j = min((i for i,x in enumerate(h) if x>0), key=lambda i:s.Rational(nums[i],h[i]))
            nums_new = [a*h[j]-nums[j]*hi for a,hi in zip(nums,h)]
            assert all(a>=0 for a in nums_new)
            den *= h[j]
            kept = [(b,a) for b,a in zip(candidates,nums_new) if a]
            candidates = [b for b,a in kept]
            nums = [a for b,a in kept]
            eliminated += 1
            peak_bits = max(peak_bits,den.bit_length(),max(a.bit_length() for a in nums))
        branches,numerators = candidates,nums
        comp = sum((s.Rational(n,den)*proj(b) for b,n in zip(branches,numerators)),s.zeros(d*d))
        assert (comp-direct).applyfunc(s.expand) == s.zeros(d*d)
        assert s.expand(s.trace(comp)) == d
        assert sum((s.Rational(n,den)*b.conjugate().T*b for b,n in zip(branches,numerators)),s.zeros(d)).applyfunc(s.expand) == ident
        sizes.append(len(branches))
    all_rank_one = all(b.rank()==1 for b in branches)
    assert all_rank_one == expected_rank_one
    if all_rank_one:
        effects = [s.Rational(n,den)*b.conjugate().T*b for b,n in zip(branches,numerators)]
        states = [b*b.conjugate().T/s.trace(b*b.conjugate().T) for b in branches]
        assert sum(effects,s.zeros(d)).applyfunc(s.expand)==ident
        mp = sum((s.kronecker_product(state,effect.T) for state,effect in zip(states,effects)),s.zeros(d*d))
        assert (mp-direct).applyfunc(s.expand)==s.zeros(d*d)
    return {'fixture':name,'d':d,'stages':len(instruments),'support_sizes':sizes,
            'eliminations':eliminated,'peak_common_integer_bits':peak_bits,'final_all_rank_one':all_rank_one}

I=s.eye(2)
R=s.Matrix([[s.Rational(3,5),-s.Rational(4,5)],[s.Rational(4,5),s.Rational(3,5)]])
S=s.diag(1,s.I)
mix=[I/3,2*R/3,2*S/3]
loss=[s.diag(1,s.Rational(3,5)),s.Matrix([[0,s.Rational(4,5)],[0,0]])]
measure=[s.diag(1,0),s.diag(0,1)]
K=[s.diag(1,1,0),s.Matrix([[0,0,1],[0,0,0],[0,0,0]])]
L=[s.diag(1,0,1),s.diag(0,1,0)]
X=s.Matrix([[0,1],[1,0]])
Y=s.Matrix([[0,-s.I],[s.I,0]])
Z=s.diag(1,-1)
results=[run('noncommuting_rational_complex_unitary_mixture',[mix]*8,False),
         run('mixture_then_loss_then_projective_measurement',[mix]*5+[loss]*3+[measure],True),
         run('two_non_EB_channels_with_rank_one_composite',[K,L],True),
         run('EB_depolarizing_channel_full_rank_instrument',[[k/2 for k in (I,X,Y,Z)]],False)]
print(json.dumps({'status':'PASS','scope':'exact finite channel equality, TP and rank diagnostics; not universal proof or novelty','fixtures':results},indent=2))
