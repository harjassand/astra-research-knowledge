"""Finite checks of Luna 03's matched-index Laurent identity and cost."""
from random import Random


def direct(a, b):
    n = len(a)
    return [[min(a[i][k] + b[k][j] for k in range(n)) for j in range(n)] for i in range(n)]


def tagged_expansion(a, b):
    n = len(a)
    out = [[None] * n for _ in range(n)]
    expanded = 0
    retained = 0
    for i in range(n):
        for j in range(n):
            # F_i has terms (A_ik, +k); G_j has terms (B_lj, -l).
            vals = []
            for k in range(n):
                for ell in range(n):
                    expanded += 1
                    if k - ell == 0:
                        retained += 1
                        vals.append(a[i][k] + b[ell][j])
            out[i][j] = min(vals)
    return out, expanded, retained


def cases(n):
    rng = Random(3026)
    # Large signed, wide-spread weights with independently generated entries.
    yield "dense_signed_wide", [[rng.randrange(-10**12, 10**12) for _ in range(n)] for _ in range(n)], [[rng.randrange(-10**12, 10**12) for _ in range(n)] for _ in range(n)]
    # Every candidate ties: catches multiplicity or cancellation assumptions.
    yield "all_ties", [[0] * n for _ in range(n)], [[0] * n for _ in range(n)]
    # Separable weights; a structured case where specialized methods can exploit structure.
    u = [rng.randrange(-10**6, 10**6) for _ in range(n)]
    v = [rng.randrange(-10**6, 10**6) for _ in range(n)]
    x = [rng.randrange(-10**6, 10**6) for _ in range(n)]
    y = [rng.randrange(-10**6, 10**6) for _ in range(n)]
    yield "separable", [[u[i] + v[k] for k in range(n)] for i in range(n)], [[x[k] + y[j] for j in range(n)] for k in range(n)]
    # Unique winner k=j for output (i,j), by making A's diagonal zero and off-diagonal costly.
    yield "unique_diagonal_winners", [[0 if i == k else 10**9 + i + k for k in range(n)] for i in range(n)], [[0 if k == j else 10**9 + k + j for j in range(n)] for k in range(n)]


def main():
    for name, a, b in cases(24):
        expected = direct(a, b)
        got, expanded, retained = tagged_expansion(a, b)
        assert got == expected, name
        print(f"{name}: exact_match=yes outputs={len(a)**2} direct_candidates={len(a)**3} tagged_pair_terms={expanded} zero_tag_terms={retained}")


if __name__ == "__main__":
    main()
