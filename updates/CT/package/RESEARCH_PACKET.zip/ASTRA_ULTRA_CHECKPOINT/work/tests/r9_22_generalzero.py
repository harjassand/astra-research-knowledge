import numpy as np
from itertools import product

def null_space(A, rcond=1e-12):
  U,s,Vh=np.linalg.svd(A,full_matrices=True)
  rank=np.sum(s>rcond*(s[0] if len(s) else 1))
  return Vh[rank:].T
n=3; d=3; D=2**n; N=3**n
pairs=[(a,b) for a in range(d) for b in range(d)]
L=np.zeros((d*d,d*d),float)
for j,(a,b) in enumerate(pairs):
  L[j,j]=1
  if a==b:
    for i in range(d): L[pairs.index((i,i)),j]-=.5
M=np.kron(np.kron(L,L),L)
E=np.array([[0.,1.],[-1.,0.]])
J=np.kron(np.kron(E,E),E)
idx=[]
for r in range(N):
 rr=[(r//(3**(n-1-i)))%3 for i in range(n)]
 for c in range(N):
  cc=[(c//(3**(n-1-i)))%3 for i in range(n)]; k=0
  for i in range(n): k=k*9+rr[i]*3+cc[i]
  idx.append(k)
order=np.argsort(idx)
def iv(C): return C.reshape(-1)[order]
def univ(x):
 out=np.empty(N*N,dtype=complex); out[order]=x
 return out.reshape(N,N)
def apply(C): return univ(M@iv(C))
def orth(A): return np.linalg.qr(A)[0][:,:A.shape[1]]
binidx=np.array([sum(bit*(3**(n-1-i)) for i,bit in enumerate(bits)) for bits in product(range(2),repeat=n)])
nonbin=np.array([i for i in range(N) if i not in set(binidx)])
Ubin=np.eye(N)[:,binidx]

def calc(u,v):
 K=np.outer(u,v)-np.outer(v,u); C=np.zeros((N,N),complex); C[np.ix_(binidx,binidx)]=K@J.T
 U=orth(Ubin@np.column_stack([u,v])); V=orth(Ubin@np.column_stack([J@u,J@v]))
 Uc0=Ubin@null_space(U.T@Ubin); Vc0=Ubin@null_space(V.T@Ubin)
 Ufull=np.column_stack([U,Uc0,np.eye(N)[:,nonbin]]); Vfull=np.column_stack([V,Vc0,np.eye(N)[:,nonbin]])
 A=U.T@C@V; invA=np.linalg.inv(A)
 # Restrict tangent arms to ambient nonbinary row/column vectors.
 Bcoords=[(i,2+6+k) for i in range(2) for k in range(len(nonbin))]
 Dcoords=[(2+6+k,j) for k in range(len(nonbin)) for j in range(2)]
 nb=len(Bcoords); nd=len(Dcoords); nr=2*(nb+nd)
 Hb=[]; MHb=[]; Bm=[]; Dm=[]
 # Real-coordinate basis ordered B-re,B-im,D-re,D-im.
 for typ,coords,phase in [('B',Bcoords,1),('B',Bcoords,1j),('D',Dcoords,1),('D',Dcoords,1j)]:
  for a,b in coords:
   B=np.zeros((2,N-2),complex); DD=np.zeros((N-2,2),complex)
   if typ=='B': B[a,b-2]=phase
   else: DD[a-2,b]=phase
   H=U@B@Vfull[:,2:].conj().T+Ufull[:,2:]@DD@V.conj().T
   Hb.append(iv(H)); MHb.append(M@iv(H)); Bm.append(B); Dm.append(DD)
 Hb=np.array(Hb); MHb=np.array(MHb)
 Q=np.real(Hb.conj()@MHb.T)
 # Add chart-curvature B-D bilinear: 2 Re <C, L(D A^-1 B)>.
 LC=apply(C)
 # For every B/D pair, compute complex scalar coefficient via Frobenius pairing
 # curvature is linear in one B and one D; compute four phase combinations exactly.
 iB0=0; iB1=nb; iD0=2*nb; iD1=2*nb+nd
 for ib in range(nb):
  for idd in range(nd):
   # K coefficient for unit-real B_ib and unit-real D_idd, so qcurv=2 Re T.
   curv=Ufull[:,2:]@Dm[iD0+idd]@invA@Bm[iB0+ib]@Vfull[:,2:].conj().T
   T=np.vdot(iv(C),M@iv(curv))
   for pb,ipb in [(1,iB0+ib),(1j,iB1+ib)]:
    for pd,ipd in [(1,iD0+idd),(1j,iD1+idd)]:
     # phase relative to base T
     factor=pb*pd
     val=2*np.real(factor*T)
     Q[ipb,ipd]+=val/2; Q[ipd,ipb]+=val/2
 ev=np.linalg.eigvalsh((Q+Q.T)/2)
 return ev,Q,C,A

rng=np.random.default_rng(20261010)
for t in range(8):
 u=rng.integers(-3,4,size=D).astype(float); v=rng.integers(-3,4,size=D).astype(float)
 if np.linalg.matrix_rank(np.column_stack([u,v]))<2: continue
 ev,Q,C,A=calc(u,v)
 print(t,'qC',float(np.vdot(iv(C),M@iv(C)).real),'min',ev[0],'neg',sum(ev < -1e-8),'zero',sum(abs(ev)<1e-8),flush=True)
