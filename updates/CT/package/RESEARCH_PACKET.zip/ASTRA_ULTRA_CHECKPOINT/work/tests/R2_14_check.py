import random

# Two independent dense random graph blocks joined by one bridge.
rng = random.Random(140210)
r = 120
n = 2 * r
A = [[0] * n for _ in range(n)]
for base in (0, r):
    for i in range(r):
        for j in range(i + 1, r):
            if rng.getrandbits(1):
                A[base+i][base+j] = A[base+j][base+i] = 1
A[r-1][r] = A[r][r-1] = 1

# Exact rank over GF(2), Gaussian elimination.
B = [row[:] for row in A]
rank = 0
for col in range(n):
    pivot = next((i for i in range(rank, n) if B[i][col]), None)
    if pivot is None:
        continue
    B[rank], B[pivot] = B[pivot], B[rank]
    for i in range(n):
        if i != rank and B[i][col]:
            B[i] = [x ^ y for x, y in zip(B[i], B[rank])]
    rank += 1

mins = [min(sum(A[i]) for i in range(r)), min(sum(A[i]) for i in range(r, n))]
# Every induced subgraph with minimum degree d has treewidth at least d:
# repeatedly eliminate a minimum-degree vertex in a degeneracy ordering;
# treewidth >= degeneracy.
cut = 1
vol = min(sum(sum(A[i]) for i in range(r)), sum(sum(A[i]) for i in range(r, n)))
print(f"n={n}, edges={sum(map(sum,A))//2}, GF2_rank={rank}, block_min_degrees={mins}, bridge_conductance={cut/vol:.6g}")
assert rank >= n // 2
assert min(mins) >= r // 3
assert cut / vol <= 1 / (r * (r-1) / 4)
