from pathlib import Path

p = Path('work/status_round7_archived.txt')
text = p.read_text()

def replace(old, new):
    global text
    assert text.count(old) == 1, (old, text.count(old))
    text = text.replace(old, new)

replace('Initial reports preceded scientific catalogue/literature consultation.', '''Round eight added twenty independently written opportunities and source
challenges across control, computational physics, chemistry, algorithms,
inference and inverse problems. Their mechanisms either matched established
methods or retained decisive acquisition, scaling or feasibility premises.
None passed. Round nine returned to NPT zero geometry with four investigators
and focused extensions. It produced the local theorem and exact obstructions
below, while leaving the global problem unresolved. Tests at more general
entangled binary zeroes gave no negative direction but no uniform proof.

Initial reports preceded scientific catalogue/literature consultation.''')
replace('The coordinator developed the six retained arguments below, challenged',
        'The coordinator developed the seven retained arguments below, challenged')
replace('PRECISE UNSOLVED GATES', '''7. Local nonnegativity at GHZ-type NPT zeroes for every fixed copy number.

Set C0=|0^n><0^n|+(-1)^(n+1)|1^n><1^n| and
q_n(C)=sum_S(-1/2)^|S| ||Tr_S C||_F^2. For every fixed n there is a
neighborhood of C0 on the complex rank-at-most-two variety where q_n>=0.
The local zero set is a smooth critical manifold of real dimension
4*2^n-6+4n. The proof identifies the entire Hessian kernel with the tangent
to rank-two skew-spin-flip operators on moving local qubit planes, proves
strictly positive normal curvature, and controls all higher orders using
adapted coordinates and Taylor's integral formula.

This is a local theorem; it does not cover arbitrary rank-two matrices,
give a uniform neighborhood in n, or establish bound entanglement. Its
spin-flip ingredient has known antecedents, and novelty is unestablished.
Two-copy global positivity is already proved in July 2026 primary sources.
Sources: https://arxiv.org/html/2607.23416v1 and
https://arxiv.org/abs/1704.03385 . Gate: NOT PASSED.

Two exact route obstructions accompany the proof. A rank-two curve through
diag(uv*,uv*,0) obeys q_(m+1)(C(t))=t^2 q_m(X) for arbitrary rank-two X;
uniform Hessian positivity at all such points already contains the lower-
copy target. A high-rank vector in the union of nontrivial even swap sectors
has top-two singular-value mass fraction 1-2^(1-n), so the direct extension
of the two-copy half-concentration certificate fails from n=3 onward.
This is not a negative rank-two witness for q_n.

PRECISE UNSOLVED GATES''')
replace('  premise that can honestly be called progress through this obstruction.',
'''  premise that can honestly be called progress through this obstruction.
  The later local theorem covers only specified neighborhoods. Extending it
  globally remains the decisive gap; the exact lift exposes a circular
  all-zero Hessian strategy and the sector example rejects a direct reuse
  of the known two-copy certificate. No candidate passed this gate.''')
replace('RETAINED_MATHEMATICS.txt contains the six complete scoped derivations and',
        'RETAINED_MATHEMATICS.txt contains the seven complete scoped derivations and')
replace('The full source text of openai/math\'s September 23, 2026 general-graph',
'''Round-nine root replay verifies the exact 208-real-coordinate three-copy
Hessian spectrum, six complex rational lift fixtures, three exact skew-zero
fixtures, and the swap-sector concentration examples for n=2 through 8.
The all-n local theorem rests on the written analytic proof, including
stationarity and higher-order control, not these finite checks. General-zero
random probes are explicitly numerical and have not established positivity.

The full source text of openai/math's September 23, 2026 general-graph''')
Path('outputs/RESEARCH_STATUS.txt').write_text(text)

with Path('work/VERIFICATION.txt').open('a') as f:
    f.write('''
ROUNDS EIGHT AND NINE

python3 work/tests/R9_23_threecopy.py
  PASS: exact 208-real-coordinate chart quadratic coefficient at the n=3
  GHZ zero has spectrum 0^38, (1/4)^26, (1/2)^48, (3/4)^40,
  1^40, (5/4)^16. All 38 individual kernel-basis rays were also checked:
  26 have q identically zero and 12 have q=t^4/8. Ray checks alone do not
  prove local nonnegativity. Root output: R9_23_threecopy_root.out.

python3 work/tests/R9_coordinator_exact.py
  PASS: six exact complex rational lift identities (m=1,2); rank-two skew
  zeroes for n=1,2,3; explicitly averaged swap-sector examples n=2..8
  with top-two singular mass fraction 1-2^(1-n). The initial structural
  SymPy equality check required expansion; no mathematical mismatch remained.
  Root output: R9_coordinator_exact.out.

COORDINATOR_NPT_LOCAL.txt contains the all-fixed-n analytic proof, including
all tangent coordinates, stationarity of the moving zero manifold, exact
kernel identification, immersion and higher-order Taylor control. Two
internal audits examined it. No formal proof assistant or external expert
validation was performed. Random general-zero probes are separately labelled
numerical, with no inferred theorem and no root replay claimed for them.

Checkpoint reconciliation: a later live RESEARCH_STATUS.txt was observed to
contain the older three-result text. Its cause was not established. The
round-seven version was recovered from the existing verified archive before
adding rounds eight and nine. No research result was inferred from this
file-management event.
''')

with Path('work/ERRATA.txt').open('a') as f:
    f.write('''
ROUNDS EIGHT AND NINE

round8 reports remain preliminary. Many independently proposed mechanisms
were subsequently recognized as established methods; no novelty follows
from writing a pre-source draft. ROUND8_BRIEF was written after some reports
had returned; direct assignment messages were operative. It is not a
preregistration.

round9/21: an initial proposed positivity justification involving the
partially transposed Werner state was incorrect; the relevant positive
operator in its factorized Hessian is product_j(I-F_j/2). The report was
corrected. Its uniform-over-R local route contains the lower-copy target,
as the exact lift in COORDINATOR_NPT_LOCAL shows.

round9/22_weighted: negative Walsh coefficients do not by themselves imply
failure of positivity on admissible moments. They only prevent the suggested
direct termwise positivity argument. No sufficient global certificate was
derived. The high-rank sector obstruction is not a negative rank-two matrix.

round9/23_alln has a missing printed plus sign in the displayed quadratic
Taylor coefficient; the second curvature term is ADDED to the ambient term.
COORDINATOR_NPT_LOCAL has the correct complete formula. The earlier 21 audit
requested an all-n transverse calculation; it was subsequently supplied and
the audit updated. Exact PSD Hessians and kernel-ray checks alone are not
local-minimum proofs; the retained proof additionally establishes the smooth
critical manifold and controls all normal Taylor remainders.

Two-copy NPT positivity is prior July 2026 work. Spin-flip antistate
cancellation and local-minimum strategies also have prior literature.
No foundational novelty is established by the retained local theorem.
''')
