from pathlib import Path
import datetime, hashlib, json, zipfile

root = Path.cwd()
out = root / 'outputs'
out.mkdir(exist_ok=True)
sections = [
    ('1. JOINT RETURN OF A QUANTUM ENERGY REFERENCE', 'work/COORDINATOR_ENERGY_DERIVATION.txt'),
    ('2. EXACT GAUSSIAN NORM EVALUATION AND PERMANENT', 'work/round3/04_gaussian_reduction.txt'),
    ('3. COMPLEX INVERTIBLE LOCAL-GAUGE OBSTRUCTION', 'work/COORDINATOR_GL_OBSTRUCTION.txt'),
    ('4. EXACT TEST AND COMPRESSION OF RANK-COLLAPSING KRAUS HISTORIES', 'work/COORDINATOR_CHANNEL_COMPRESSION.txt'),
    ('5. CONNECTED PHYSICAL COUNTEREXAMPLE TO IID LOOP SAMPLING', 'work/COORDINATOR_LOOP_VARIANCE.txt'),
    ('6. COMPLEX LEE-YANG SPECTRAL AND FINITE-PRODUCT BOUNDS', 'work/COORDINATOR_COMPLEX_LY.txt'),
    ('7. ALL-COPY LOCAL NPT MINIMA AND GLOBAL-EXTENSION OBSTRUCTIONS', 'work/COORDINATOR_NPT_LOCAL.txt'),
]
intro = '''RETAINED MATHEMATICS — ASTRA ULTRA, 10 OCTOBER 2026

Status: internal mathematical derivations, not the requested foundational
breakthrough. No novelty or independent external validation is claimed.
Each statement must be read with its model, imported results and limitations.
Finite checks supplement the written proofs; they do not replace them.

The exact Gaussian construction was proposed by the coordinator and written
out in the investigator's focused audit reproduced below. Its only imported
complexity theorem is the #P-completeness of Boolean permanent:
L. G. Valiant (1979), The Complexity of Computing the Permanent,
https://doi.org/10.1016/0304-3975(79)90044-6 . No claim about approximate
permanents, approximate norms, or identity testing is inferred.

For the energy proof, 'commutes with total energy' means that U preserves the
spectral subspaces of H_S+H_R, hence commutes with its bounded functional
calculus. This fixes the intended meaning for the unbounded ladder operator.

Paths beginning work/ below are relative to the unzipped checkpoint root.
See RESEARCH_STATUS.txt for the unachieved mission and work/ERRATA.txt for
errors in the preliminary reports. These seven scoped derivations take
precedence over conflicting exploratory statements in their respective areas.
'''
parts = [intro]
for title, rel in sections:
    parts += ['\n' + '=' * 74 + '\n' + title + '\n' + '=' * 74 + '\n', (root / rel).read_text()]
(out / 'RETAINED_MATHEMATICS.txt').write_text('\n'.join(parts))

reports = []
for rd in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11):
    pattern = '[0-9][0-9]_independent.txt' if rd in (8, 10, 11) else '[0-9][0-9].txt'
    for p in sorted((root / 'work' / f'round{rd}').glob(pattern)):
        reports.append({'path': p.relative_to(root).as_posix(), 'round': rd,
                        'investigator': p.stem[:2], 'foundational_gate': 'NOT_PASSED',
                        'evidence_status': 'PRELIMINARY; errata and focused audits take precedence'})
state = {
    'mission_status': 'NOT_ACHIEVED',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'goal_marked_complete': False,
    'selected_foundational_candidate': None,
    'luna_investigators': 48,
    'initial_luna_investigators': 24,
    'additional_fresh_luna_investigators_round10': 24,
    'reused_luna_investigators_round11': 8,
    'sol_depth_investigators_deployed': 0,
    'investigator_tasks_running_at_checkpoint': 0,
    'independent_round1_reports': 24,
    'different_round2_reports': 21,
    'round3_main_reports': 6,
    'round4_independent_opportunities': 20,
    'round4_source_informed_matching_audits': 3,
    'round4_source_informed_epr_extension': 1,
    'round5_independent_opportunities': 24,
    'round6_source_informed_epr_main_reports': 5,
    'round6_lee_yang_gap_complex_and_dynamic_audits': 9,
    'round7_thermal_consequence_investigations': 4,
    'round8_independent_opportunities': 20,
    'round9_npt_main_investigations': 4,
    'round10_independent_opportunities': 24,
    'round11_capability_first_attempts': 8,
    'latest_selection_review': 'work/COORDINATOR_ROUNDS10_11_REVIEW.txt',
    'current_research_direction': 'NONE SELECTED; seek a genuinely different complete mechanism, not a restricted extension of rejected candidates.',
    'shelved_tracks': [{'track': 'NPT local geometry', 'reason': 'User-directed pivot; resume only if a concrete mechanism gives a credible route to the full global theorem.'}],
    'round8_brief_timing': 'Direct assignments were operative; written brief added after some reports returned and is not a preregistration.',
    'scientific_literature_and_catalogue_after_initial_generation': True,
    'independence_limitations': [
        'Coordinator read general integrity memory before generation.',
        'Investigators 13 and 19 disclosed early unintended memory-registry queries; reported not using them.',
        'No controlled blind-comparison experiment or version-complete immutable freeze was performed.',
        'Round10 investigator23 disclosed correcting its nominal frozen file after literature review.',
        'Round11 reused eight round10 investigators with prior context; not a fresh blind round.'
    ],
    'external_validation': False,
    'scientific_experiments_performed': False,
    'novelty_established': False,
    'retained_scoped_derivations': [
        {'id': 'joint_energy_reference', 'scope': 'Theta(n/epsilon) supplied mean-energy order for same-reference joint return',
         'proof': sections[0][1], 'novelty': 'NOT_ESTABLISHED; construction has known antecedents'},
        {'id': 'exact_gaussian_norm', 'scope': 'Polynomial-time Turing reduction from Boolean permanent to exact circuit Gaussian squared norms',
         'proof': sections[1][1], 'novelty': 'UNKNOWN; no approximation or PIT hardness conclusion'},
        {'id': 'local_gl_obstruction', 'scope': 'No nonnegative four-port matching signature in GL(2,C)^4 orbit of displayed F or F^k for integer k>=1',
         'proof': sections[2][1], 'novelty': 'UNKNOWN; no global counting hardness conclusion'},
        {'id': 'exact_branch_compression', 'scope': 'Polynomial-bit rank-one history test and positive reweighting of at most d^4 actual Kraus products preserving the terminal channel',
         'proof': sections[3][1], 'novelty': 'NOT_ESTABLISHED; standard exterior algebra and conic elimination; polynomial in dense d only'},
        {'id': 'connected_loop_variance', 'scope': 'Relative second moment at least exp(-.02)*(189/169)^k for iid selector estimator on connected physical path instances with an exact polynomial-time baseline',
         'proof': sections[4][1], 'novelty': 'UNKNOWN; estimator-specific, not counting hardness'},
        {'id': 'complex_lee_yang_transfer', 'scope': 'Sharp modulus spectral ratio for arbitrary complex LY(r) operators; uniform relative Frobenius rank-one bound for time-varying products',
         'proof': sections[5][1], 'novelty': 'NOT_ESTABLISHED; adapts the existing July 2026 squeezing mechanism; no efficient normalization or physical preparation algorithm'},
        {'id': 'npt_ghz_local_minima', 'scope': 'For every fixed n, q_n has a nonnegative neighborhood on rank<=2 near E_0n,0n+(-1)^(n+1)E_1n,1n; smooth critical zero manifold of real dimension 4*2^n-6+4n. Exact lower-copy lift and multicopy sector obstruction also proved.',
         'proof': sections[6][1], 'novelty': 'NOT_ESTABLISHED; spin-flip and local-minimum approaches have prior literature; no global rank-two positivity or NPT bound-entanglement theorem'}
    ],
    'unresolved_gates': [
        {'track': 'NPT boundary Werner state', 'statement': 'For every n>=1 and rank(C)<=2 in M_(3^n)(C): sum_S (-1/2)^|S| ||Tr_S C||_F^2 >= 0',
         'failure': 'All-copy GHZ local-minimum theorem gives no global control. Uniform stability at diag(uv*,uv*,0) already contains the lower-copy target through q_(m+1)(C(t))=t^2 q_m(X). Direct union-of-even-swap-sector half-concentration bound fails for n>=3. General entangled binary-zero Hessian has only finite numerical evidence.'},
        {'track': 'EPR normalization', 'statement': 'Polynomial-cost global normalization and controlled relative variance on the stated physical family',
         'failure': 'Tested local GL route excluded; iid selectors have exponential relative second moment even on connected easy paths; forest-factor proposals have no arbitrary-network bound.'},
        {'track': 'Intrinsic quantum channel acquisition', 'statement': 'Broad scalable construction of a useful rank-one or otherwise efficiently simulable representation from ordinary local channel inputs',
         'failure': 'Supplied-instrument exterior test misses depolarizing full-rank gauges; exact branch compression is polynomial in dense d, exponential in qubit count; qubit PPT repair is known fixed-dimension theory.'},
        {'track': 'Circuit PIT', 'statement': 'Efficiently acquired deterministic hitting representation for general circuits',
         'failure': 'Good direction acquisition unresolved; exact norm primitive encodes counting.'},
        {'track': 'KLS heat observation', 'statement': 'Dimension-free sufficient weighted control of E[Var(f(X)|Y) ||Cov(X|Y)||op]',
         'failure': 'Proposed simple closure fails exponential-prior tail test; average covariance insufficient.'},
        {'track': 'Finite-noise nonlinear identification', 'statement': 'Uniform charged recovery including weak coupling, precision and certified root isolation',
         'failure': 'Exact accessible germs do not establish finite-noise sample/compute guarantees.'},
        {'track': 'Finite-temperature Suzuki-Fisher computation', 'statement': 'Polynomial-cost Gibbs/partition approximation from ordinary local inputs over the full stated temperature regime',
         'failure': 'LY product collapse neither acquires a state/normalizer nor controls finite-temperature excited-state entropy; proposed inverse-filter and recursive-reflection routes have uncharged or exponential costs.'}
    ],
    'source_pins': [json.loads((root / 'work/sources' / n).read_text()) for n in ('astra_pin.json', 'openai_math_pin.json')],
    'evidence_precedence': ['RETAINED_MATHEMATICS.txt within its stated scope', 'work/ERRATA.txt and focused errata/audits', 'preliminary reports'],
    'root_replayed_checks': ['work/tests/coordinator_energy.py', 'work/tests/R3_04_gaussian_reduction_check.py',
                             'work/tests/R3_13_erratum_check.py', 'work/tests/R3_15_GL_audit.py',
                             'work/tests/R4_13_exact_compression.py', 'work/tests/R4_24_connected_loop_check.py',
                             'work/tests/R6_15_two_copy.py', 'work/tests/R6_LY_transfer_check.py', 'work/tests/R7_15_tfd.py',
                             'work/tests/R9_23_threecopy.py', 'work/tests/R9_coordinator_exact.py',
                             'work/tests/R10_03_algebra.py'],
    'round10_algorithm_source': {
        'source': 'https://arxiv.org/html/2610.06783v1',
        'status': 'SOURCE_REPORTED, section5.2 read; full paper not independently validated here',
        'correction': 'Source already includes real-input Las Vegas min-plus/APSP in Theorem35; initial investigator omission corrected.',
        'our_contribution': 'No foundational algorithm. Pivoted interval-greedy construction fails to give subcubic cost in the required small-prefix regime; pivot acquisition and witness isolation remain unresolved.'
    },
    'npt_prior_work': {
        'two_copy_theorem': 'https://arxiv.org/html/2607.23416v1',
        'other_two_copy_source': 'https://arxiv.org/html/2607.24479v1',
        'spin_flip_antecedent': 'https://arxiv.org/abs/1704.03385',
        'local_minimum_antecedents': ['https://arxiv.org/abs/0711.2613', 'https://arxiv.org/html/2402.18037v1'],
        'two_copy_status': 'SOURCE THEOREM, not this campaign discovery; main Song-Chen argument read, no external validation claim',
        'our_result': 'Internally proved local all-fixed-n theorem and two route obstructions; novelty unestablished and foundational gate not passed'
    },
    'lee_yang_prior_work': {
        'source': 'https://arxiv.org/abs/2607.14401',
        'version': 'v1, 15 July 2026',
        'status': 'Primary proof read; ground-energy algorithm and PSD spectral bound credited to authors',
        'other_source': 'https://arxiv.org/abs/2607.10765',
        'old_thesis_gap_route_novelty': 'RETIRED after July source check',
        'our_extension': 'Internally proved scoped complex and dynamic corollaries; no foundational pass'
    },
    'later_source_review': {
        'matching_preprint': 'work/sources/matching113/main.tex',
        'status': 'SOURCE_REPORTED; full theorem not independently verified; scoped sections internally audited',
        'audits': ['work/round4/21_matching_audit.txt', 'work/round4/22_matching_audit.txt', 'work/round4/23_matching_audit.txt'],
        'new_discovery_claim': False,
        'epr_reduction_obtained': False
    },
    'verification_record': 'work/VERIFICATION.txt',
    'reports': reports,
    'continuation_rule': 'Honor the user-directed pivot away from local NPT geometry unless a credible full-theorem route appears. Invent substantive new acquired, charged leverage or conduct a fundamentally different exploration. No selected candidate; do not deploy Sol on scoped lemmas, oracle reductions or new source theorems.'
}
assert len([r for r in reports if r['round'] == 1]) == 24
assert len([r for r in reports if r['round'] == 2]) == 21
assert len([r for r in reports if r['round'] == 3]) == 6
assert len([r for r in reports if r['round'] == 4]) == 20
assert len([r for r in reports if r['round'] == 5]) == 24
assert len([r for r in reports if r['round'] == 6]) == 5
assert len([r for r in reports if r['round'] == 7]) == 4
assert len([r for r in reports if r['round'] == 8]) == 20
assert len([r for r in reports if r['round'] == 9]) == 4
assert len([r for r in reports if r['round'] == 10]) == 24
assert len([r for r in reports if r['round'] == 11]) == 8
(out / 'RESEARCH_STATE.json').write_text(json.dumps(state, indent=2, ensure_ascii=False) + '\n')

readme = '''ASTRA ULTRA — UNACHIEVED FOUNDATIONAL MISSION CHECKPOINT

Read RESEARCH_STATUS.txt first. RETAINED_MATHEMATICS.txt holds seven scoped
internal derivations. RESEARCH_STATE.json records the exact unresolved gates.

The work/ folder contains preliminary reports, source extracts and tests.
Read work/ERRATA.txt before any raw report. Internal or source-reported
statements must not be relabelled as externally verified or novel.

The source snapshot is selective, not a complete repository mirror. Some
linked full proofs and code were unavailable. See each source-informed report
for the limits of what was retrieved. Public primary-source material is
preserved for reproducibility with its attribution; it is not our invention.

To replay the twelve coordinator-run checks from this unzipped directory:
  python3 work/tests/coordinator_energy.py
  python3 work/tests/R3_04_gaussian_reduction_check.py
  python3 work/tests/R3_13_erratum_check.py
  python3 work/tests/R3_15_GL_audit.py
  python3 work/tests/R4_13_exact_compression.py
  python3 work/tests/R4_24_connected_loop_check.py
  python3 work/tests/R6_15_two_copy.py
  python3 work/tests/R6_LY_transfer_check.py
  python3 work/tests/R7_15_tfd.py
  python3 work/tests/R9_23_threecopy.py
  python3 work/tests/R9_coordinator_exact.py
  python3 work/tests/R10_03_algebra.py
The eight checks from R3_15_GL_audit through R9_coordinator_exact need SymPy
(observed version 1.14.0); the other four use the standard library.
Python 3.14.3 was used in the coordinator's replay. Do not infer the
all-size statements from these finite checks: read the proofs.

MANIFEST.json records SHA-256 values for content integrity only. A matching
hash does not validate a mathematical claim, novelty, or physical feasibility.

No accepted foundational candidate and no Sol depth-team deployment resulted.
Rounds ten and eleven pivoted away from NPT. The local theorem remains
shelved; read work/COORDINATOR_ROUNDS10_11_REVIEW.txt before resuming research.
'''
files = [(p.relative_to(root).as_posix(), p) for p in sorted((root / 'work').rglob('*'))
         if p.is_file() and '__pycache__' not in p.parts]
files += [(p.name, p) for p in sorted(out.iterdir()) if p.suffix in ('.txt', '.json')]
manifest = [{'path': name, 'bytes': p.stat().st_size,
             'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for name, p in files]
archive = out / 'RESEARCH_PACKET.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    prefix = 'ASTRA_ULTRA_CHECKPOINT/'
    for name, p in files:
        z.write(p, prefix + name)
    z.writestr(prefix + 'README.txt', readme)
    z.writestr(prefix + 'MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        data = z.read('ASTRA_ULTRA_CHECKPOINT/' + item['path'])
        assert hashlib.sha256(data).hexdigest() == item['sha256']
print(json.dumps({'status': 'CHECKPOINT_CREATED; MISSION_NOT_ACHIEVED',
                  'archive_members': len(manifest) + 2, 'archive_bytes': archive.stat().st_size,
                  'reports_by_round': {str(rd): sum(r['round'] == rd for r in reports) for rd in (1,2,3,4,5,6,7,8,9,10,11)},
                  'output_files': [p.name for p in sorted(out.iterdir())]}))
