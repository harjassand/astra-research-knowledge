Associated claim corrections (exact catalog associations; source text remains historical): [{"card_id": "N250-circuit-log-contact-gate", "reported_claim_status": "source_derived_unreviewed", "proof_availability": "proof_text_located_not_completeness_audited", "material_updates": [{"target": "N280-binomial-log-contact-and-pullback", "relation": "refines_with_scoped_AS_result_or_obstruction", "source_card": "N280-binomial-log-contact-and-pullback", "whole_claim_invalidated": false, "scope": "Sharp contact on binomial/product classes and rational pullback alphabet costs are scoped advances; general small-circuit contact remains open.", "relation_status": "source_supported_scoped_notice_not_correctness_promotion"}, {"target": "N289-finite-contact-determinant-obstruction", "relation": "refines_with_scoped_AS_result_or_obstruction", "source_card": "N289-finite-contact-determinant-obstruction", "whole_claim_invalidated": false, "scope": "Exact P4 no rank-one-variable determinant at any matrix size excludes one finite compression route; it is not a uniform small-circuit counterfamily.", "relation_status": "source_supported_scoped_notice_not_correctness_promotion"}], "dependency_alerts": [], "status_path": "frontier/cards/N250-circuit-log-contact-gate.json", "evidence_scope": "Full hash-pinned evidence and relations in status_path; no correction is silently truncated.", "external_correctness": "unverified; newer claims do not certify older ones"}]# ASTRA: logarithmic PIT and exact realization complexity

**Research date:** 8 October 2026 (Australia/Brisbane).  
**Foundational target:** deterministic polynomial-time black-box identity testing for general polynomial-degree commutative arithmetic circuits in characteristic zero.  
**Outcome:** no resolution of this target, and no certified foundational discovery. This state contains complete representation theorems and barriers, a reconstructed hitting-set theorem that the novelty check identified as existing work, exact finite verification, and the specific remaining sufficient lemma. None of the barriers is a lower bound against arbitrary commutative circuits or arbitrary PIT algorithms.

## 0. Provenance, scope, and status

Astra repository: `harjassand/astra-research-knowledge`, pinned at
`d20c4b040f63c2fb0c8da76362046d1946d0a2b9`.

OpenAI mathematics source repository: `openai/math`, pinned at
`fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

The investigation began with `00_START_HERE.txt`. It used the frontier priorities, topic routes, cross-field card and its source-status metadata, and the corrected direct-finiteness/Bernoulli audit. It did not treat repository claims as externally certified. No parallel subagents, formal proof assistants, or remote repository writes were used. The exact finite verifier is a separate standard-library Python implementation. Discovery calculations for the contact examples used SymPy; the delivered verifier rechecks their coefficients independently with `fractions.Fraction`.

### Claim ledger

| ID | Claim | Mathematical status | Novelty status |
|---|---|---|---|
| F1 | General polynomial-degree commutative circuit PIT in deterministic polynomial time | Unresolved in this investigation | No discovery claimed |
| T1 | Total derivative-span dimension equals shuffle-Hankel rank, minimum linear automaton size, logarithmic branch-span dimension, and minimum rational ODE/system order | Complete proof, Section 3 | Not established as new; classical ingredients |
| T2 | A genuinely nonpolynomial rational function of independent logarithms is not D-finite over C(z) | Complete proof, Section 4 | Not established as new |
| T3 | Symmetric lift of a squarefree monomial has exact state dimension 2^n and an exponential constant-error approximation barrier | Complete proof, Section 5 | Nisan-style rank method; not a new general lower-bound technique |
| T4 | Fixed-order sorted lifting and regular multiplicative sections do not give the hoped-for efficient transfer | Complete proofs, Section 6 | Not established as new |
| K1 | Polynomial-size scalar hitting sets for small total derivative span | Reconstructed, Section 7 | **Existing result:** Bhardwaj–Saptharishi, 28 September 2026 |
| C1 | Polynomial size-sensitive logarithmic contact bound implies explicit polynomial-size hitting sets for general circuits | Complete conditional reduction, Section 8 | Sufficient condition only; hypothesis unproved |
| T5 | Rational pullback cannot amplify contact while preserving a logarithmic alphabet with at least three punctures | Complete restricted obstruction, Section 9 | Classical ramification argument |
| E1 | Finite Hankel, shuffle, translation, jet, and hitting-set checks | Replayed exactly by `verify.py` | Finite evidence, not all-parameter proof |

Theorems T1–T5 do not depend on the correctness of the released group constructions or zero-free-region manuscript. The source construction for noncommutative PIT motivated the investigation; the representation obstructions have their own proofs below.

## 1. Opportunity comparison and selection

Three genuinely distinct routes received initial consideration.

**Analytic number theory.** The inspected introduction and proof roadmap of OpenAI family 003 report a uniform 7/8 zero-free region for the relevant Dirichlet and Hecke L-functions. The potential foundational target was RH, not another fixed improvement in the zero-free exponent. The source uses completed/reflected kernels and a further prime-compensation stage. The first decisive requirement would be a valid amplification or new kernel estimate whose exponent reaches 1/2 while preserving every uniformity condition. The first-stage gain does not itself supply such an iteration. Only part of the very large source was inspected, and its complete theorem was not independently certified. No RH deduction was obtained.

**Ergodic theory and group algebras.** The corrected Astra audit assumes a genuine witness `ab=1`, `ba!=1` in F_q[G]. It derives an exact Haar splitting of the full shift X as X × K and a strict finite upper bound for the group's supremal Rokhlin entropy. The potential foundational target was unequal-entropy Bernoulli conjugacy, or a decisive entropy invariant forbidding universal collapse. The necessary bridge is a genuinely Bernoulli independent component, an actual measurable conjugacy, or an entropy/rank-density theorem. Iterating a Haar splitting does not establish any of these. The corrected audit itself records the missing step and the unverified status of the entire group construction. This line was not used as a premise.

**Algebraic complexity — selected.** OpenAI family 116 provides a concrete mechanism: faithful iterated-integral encoding plus a polynomial-dimensional differential representation and a multiplicity bound. The target was general commutative PIT. The first decisive test was whether passing from ordered words to commutative monomials preserves the representation complexity on which the multiplicity theorem depends. Unlike the other two routes, this test admits exact algebraic examples and a complete representation characterization.

This was not a survey of every frontier or a claim that these are the world's three best opportunities. It was a focused selection followed by a proof campaign. The noncommutative mechanism was examined first; after proving its linear-transfer obstruction, the campaign turned to direct nonlinear contact bounds, which do not assume a small linear realization.

The historical importance of PIT comes in part from hardness–randomness connections, including Kabanets–Impagliazzo. No claim here equates an arithmetic-oracle algorithm with an unrestricted polynomial-bit Boolean algorithm. Degree promises, constant encodings, and evaluation costs must be retained when applying those connections.

## 2. The imported mechanism, reconstructed in the needed scope

Fix n >= 1 and characteristic zero. Define

\[
\ell_i(z)=\log(1+z/i),\qquad
\mathcal J_i f(z)=\int_0^z\frac{f(t)}{t+i}\,dt.
\]

The formal Taylor coefficients of every function used below are rational. For a word w, let `h_empty=1` and `h_iw=J_i h_w`. The family of finite words is linearly independent under this encoding. Crucially, this is a linear encoding of the free associative algebra, not a homomorphism from the commutative polynomial algebra into scalar power series with ordinary multiplication.

For example,

\[
h_{12}-h_{21}=-z^3/24+O(z^4).
\]

Thus taking an arbitrary syntax-level noncommutative lift of a commutative circuit can turn the zero polynomial into a nonzero encoded function.

The useful analytic input is the following multiplicity lemma, attributed in the source to Moura and proved there using derivative rows and Wronskians.

### Multiplicity lemma

Let `G'=A(z)G`, `G(0)=I_m`, where

\[
 A(z)=P(z)/q(z),\quad \deg q=n,\quad q(0)\ne0,
 \quad\deg P_{ij}\le n-1.
\]

If a constant row u and column v give a nonzero `f=uGv`, then

\[
\operatorname{ord}_0f\le (n-1)\binom m2+m-1. \tag{2.1}
\]

**Proof reconstruction.** Put `h=uG` and let k be the constant-field dimension of the span of its components. Define `R_0=u` and `R_{j+1}=R_j'+R_jA`, so `h^(j)=R_jG`. Write `R_j=Z_j/q^j`; then

\[
 Z_{j+1}=qZ_j'-jq'Z_j+Z_jP,
 \qquad \deg Z_j\le j(n-1).
\]

Let B consist of rows `R_0,...,R_{k-1}` and `S=binom(k,2)`. Each maximal minor of B has denominator `q^S` and numerator degree at most `(n-1)S`. At least one is nonzero, because some k components of h form a basis and have nonzero Wronskian. Therefore the minimum order delta among nonzero maximal minors is at most `(n-1)S`.

Multiplication by the invertible formal matrix G preserves that minimum order: Cauchy–Binet gives one inequality, and multiplication back by `G^-1` gives the reverse. A minor of BG attaining the minimum is a Wronskian of a basis of the component span. Choose a basis with distinct increasing orders `a_1<...<a_k`. Its Wronskian has order

\[
\delta=\sum_{j=1}^k a_j-\binom k2
       =\sum_{j=1}^k(a_j-j+1).
\]

This follows by factoring leading powers and using the Vandermonde determinant of falling factorials. Every summand is nonnegative, so every nonzero element of the span, including f, has order at most
`a_k <= delta+k-1 <= (n-1)binom(k,2)+k-1`.
This implies (2.1). The proof is formal in characteristic zero.

For a small noncommutative path program, the differential system can have few states. General commutative multiplication is precisely where this advantage can be lost.

## 3. Exact realization theorem: the same invariant controls all linear routes

For a nonzero polynomial `P in C[x_1,...,x_n]`, define

\[
 W_P=\operatorname{span}_{\mathbb C}
       \{\partial^\alpha P:\alpha\in\mathbb N^n\},
 \qquad r(P)=\dim_{\mathbb C}W_P.
\]

This is also the dimension of the finite quotient of the constant-coefficient differential-operator algebra by the annihilator of P, often called its apolar algebra. Only the displayed elementary definition is needed.

Define a noncommutative polynomial `Sh(P)` as follows. If `P=sum_alpha c_alpha x^alpha`, assign to every word w of multidegree alpha the coefficient

\[
[w]\operatorname{Sh}(P)=\alpha!\,c_\alpha,
\quad \alpha!=\prod_i\alpha_i!.
\]

The empty-word coefficient is `P(0)`. This is the raw shuffle lift, not the normalized section of abelianization.

### Theorem T1

The following quantities are equal:

1. `r(P)`.
2. The rank of the coefficient Hankel matrix of `Sh(P)`.
3. The minimum number of states in a linear weighted-automaton realization of `Sh(P)`, allowing cyclic as well as acyclic realizations.
4. The complex dimension of the span of the analytic branches of `P(ell_1(z),...,ell_n(z))`.
5. The minimum order of a nonzero homogeneous scalar linear differential equation over `C(z)` annihilating that function.
6. The minimum dimension of a homogeneous rational linear differential system representing that function with a rational linear readout.

A constant nonzero polynomial has r=1; the minimum homogeneous ODE order is 1, not 0.

### Proof: algebraic independence of the logarithms

A loop about `-i` adds `kappa=2*pi*i` to `ell_i` and leaves the other logarithms unchanged. Independent loops realize every translation by `kappa k`, `k in Z^n`.

Suppose a polynomial Q in the logarithms vanished. Continuing the zero germ around all these loops gives `Q(ell(z)+kappa k)=0` for every integer vector k. At any common nonsingular base point, this is a polynomial in k vanishing on the whole integer lattice. That polynomial is zero, which forces Q to be zero. The same argument works with rational functions of z as coefficients, since those coefficients are single-valued; one chooses an ordinary base point avoiding their poles. Thus the logarithms are algebraically independent even over `C(z)`.

This concerns functions, not numerical logarithms at one fixed algebraic point. No conjecture about transcendence of numerical logarithms is being invoked.

### Proof: Hankel rank and linear states

If a prefix has multidegree beta and a suffix has multidegree gamma, their Hankel entry is

\[
(\beta+\gamma)!\,c_{\beta+\gamma}.
\]

The coefficient of `x^gamma` in `partial^beta P` is that entry divided by `gamma!`. Repeated columns arising from words of the same multidegree do not change the rank, and nonzero column rescaling by `gamma!` does not change it either. The Hankel row space is consequently exactly the derivative span, in coefficient coordinates. Its rank is r(P).

Any m-state representation `[w]f=u A_w v` factors the Hankel matrix through an m-dimensional space, so m >= r(P). Conversely, use W_P as the state space. Each `partial_i` acts on W_P, the initial state is P, and the final functional is evaluation at zero. On a word of multidegree alpha, the output is `partial^alpha P(0)=alpha! c_alpha`. This constructs an r(P)-state realization. Cycles cannot beat the Hankel lower bound.

### Proof: branch span

Taylor translation gives

\[
P(x+a)=\sum_\alpha\frac{a^\alpha}{\alpha!}\partial^\alpha P(x).
\]

Thus all translates lie in W_P. Conversely, polynomial interpolation in the translation parameters on a sufficiently large integer grid recovers every coefficient in this Taylor expansion. Hence the span of the lattice translates is exactly W_P. Algebraic independence makes evaluation at the logarithms injective, so the span of analytic branches has dimension r(P).

### Proof: lower bound for any rational linear ODE or system

An order-m homogeneous rational ODE has an m-dimensional local solution space at any ordinary point. Analytic continuation of a solution remains in that solution space. The branch span therefore has dimension at most m, and m >= r(P).

For an m-dimensional rational system and rational linear readout, choose a local fundamental matrix. All continued outputs lie in the span of its m scalar readouts, again bounding the branch span by m. Allowing a different basis, rational output coefficients, apparent singularities away from the chosen ordinary point, or cyclic linear representations cannot remove this lower bound.

### Proof: matching upper bound

Choose a basis `Q_1,...,Q_r` of W_P. Write

\[
\partial_i Q_j=\sum_k (C_i)_{jk}Q_k.
\]

The matrices C_i commute and are nilpotent, because partial differentiation commutes and eventually kills every polynomial. The vector `y_j(z)=Q_j(ell(z))` satisfies

\[
y'=\left(\sum_{i=1}^n\frac{C_i}{z+i}\right)y. \tag{3.1}
\]

This is an r-dimensional rational system representing P(ell). An elimination among the first r+1 derivative rows gives a scalar rational ODE of order at most r. The lower bound makes the order exactly r. This completes T1.

### Consequences relevant to the foundational target

For `P=x_1...x_n`, the partial derivatives are the 2^n distinct squarefree submonomials. Therefore

\[
r(P)=2^n.
\]

Yet P has a formula with n variable leaves and n-1 multiplication gates. Every rational linear realization of its logarithmic image needs 2^n states.

More generally, for `P=prod_i x_i^{d_i}`,

\[
r(P)=\prod_i(d_i+1),
\]

and this is the exact minimal scalar ODE order for the logarithmic product.

**Essential limitation:** a large minimal differential order is not a large vanishing order. For the squarefree product,

\[
\operatorname{ord}_0\prod_i\ell_i(z)=n,
\]

despite the minimal ODE order being 2^n. This explicitly prevents using T1 as a disproof of an efficient direct Taylor-jet identity test. Indeed, the vector `(1, ell_1, ..., ell_n)` itself satisfies an `(n+1)`-dimensional rational linear system; P is a nonlinear polynomial readout of that vector. The obstruction concerns **linear** readouts and representations, not the ability to store the logarithms in a small state space or evaluate a circuit with a nonlinear output.

## 4. Rational readouts of logarithms do not restore small D-finite representations

### Theorem T2

Let `R in C(x_1,...,x_n)` be reduced as a rational function. Then `R(ell(z))` is D-finite over C(z) if and only if R is a polynomial. Here D-finite means satisfying a nonzero homogeneous linear ODE with rational coefficients; meromorphic germs are allowed.

**Proof.** Polynomial R is covered by T1. Conversely, suppose `R(ell)` is D-finite. Its branches span a finite-dimensional complex vector space, so, by algebraic independence, the rational functions

\[
\{R(x+\kappa k):k\in\mathbb Z^n\}
\]

span a finite-dimensional complex vector space as well. Choose a finite basis for that space. The poles of every member of the space lie in the union of the finitely many irreducible polar hypersurfaces of the basis functions.

It follows that the set of all polar hypersurfaces of all translates of R is finite and is permuted by integer translations. Any irreducible component of the polar divisor thus has a finite-index translation stabilizer. In particular, for each coordinate i it is invariant under a nonzero translation by `N_i kappa e_i`.

If q is an irreducible defining polynomial of this component, invariance gives `q(x+N_i kappa e_i)=c_i q(x)`. Comparison of highest-degree terms forces `c_i=1`. A polynomial periodic under a nonzero additive translation in characteristic zero is independent of that coordinate. Applying this in every coordinate would make q constant, a contradiction. Thus there are no poles and R is a polynomial.

When using monodromy, paths can avoid the isolated poles of individual meromorphic branches, and ordinary base points can be chosen. Under the assumed finite-order ODE, all branches must lie in its finite-dimensional solution space. This justifies the branch-span step even when a displayed rational expression has a denominator vanishing at z=0.

**Scope.** This classifies rational scalar functions of the chosen logarithms. It does not classify arbitrary free rational formulas with matrix-only domains, arbitrary nonlinear state systems, or unrelated transcendental generators. It is not an impossibility theorem for rational-function PIT.

## 5. Symmetric lifting: exact and approximate exponential state barriers

Let

\[
S_n=\frac1{n!}\sum_{\pi\in\mathfrak S_n}
 x_{\pi(1)}\cdots x_{\pi(n)}.
\]

Its commutative image is the very easy polynomial `x_1...x_n`.

### Exact dimension

For each subset A of [n], let u_A be its letters in increasing order. For each subset B, let v_B be the letters of `[n] minus B` in increasing order. Then

\[
[u_Av_B]S_n=\frac1{n!}\mathbf1_{A=B}.
\]

This exhibits a diagonal 2^n by 2^n Hankel minor. Every linear realization requires at least 2^n states. The subset automaton, which records the set of used letters, attains 2^n states. This is an exact minimum, not merely a lower bound for one particular construction.

A multidegree-preserving, variable-relabeling-equivariant linear section of abelianization must send `x_1...x_n` to S_n: relabeling makes all n! word coefficients equal, and abelianization makes their sum one. Therefore such a section cannot preserve polynomial linear-state size.

In characteristic p <= n, the same equivariance conditions would require `n! c=1`, which is impossible. This is a failure of that section, not a lower bound for all positive-characteristic PIT.

### Approximation barrier

Fix k. Flatten the degree-n coefficient tensor into prefixes of length k and suffixes of length n-k. Nonzero rows and columns correspond to injective words. Partition them by the subset of letters used in the prefix. There are

\[
R_k=\binom nk
\]

disjoint rank-one blocks, each a `k! by (n-k)!` all-ones matrix scaled by `1/n!`. Hence every nonzero squared singular value equals

\[
\sigma^2=\frac{k!(n-k)!}{(n!)^2}.
\]

If an m-state series approximates the degree-n coefficients in relative Euclidean error at most epsilon, the same cut of its coefficient tensor has rank at most m. For a matrix with R_k equal nonzero singular values, every rank-m approximation has squared error at least `(R_k-m) sigma^2`.

For completeness, project onto the row space of the approximation. The component of the target orthogonal to that row space already has this much squared norm, since an m-dimensional projection captures at most m of the R_k equal singular directions. Dividing by the target squared norm `R_k sigma^2` gives

\[
m\ge(1-\varepsilon^2)\binom n{\lfloor n/2\rfloor}. \tag{5.1}
\]

Thus constant relative error does not rescue polynomial linear-state size.

**Quantifier warning.** The exact whole-series minimum is 2^n. The approximation result as stated only controls the degree-n coefficients and gives the central-binomial bound. It does not assert an approximate 2^n lower bound for arbitrary cyclic series with unrestricted coefficients at other degrees.

These are recognizable-series/linear-state bounds, not general commutative circuit lower bounds. The method is classical coefficient/Hankel rank in the tradition of Nisan.

## 6. Other attempted commutativizations

### 6.1 Fixed-order sorting

Order the variables `x_1<...<x_n<y_1<...<y_n`. The commutative polynomial

\[
P_n=\prod_{i=1}^n(x_i+y_i)
\]

has a linear-size formula. Its lift obtained by sorting every monomial is

\[
Q_n=\sum_{A\subseteq[n]} x_A y_{[n]\setminus A},
\]

where each block is internally increasing. The Hankel submatrix with rows x_A and columns `y_[n]minusB` is the identity matrix of size 2^n. Thus the sorted lift requires at least 2^n linear states. For any fixed global variable order, the same construction applies after pairing variables from its first and second halves.

This rules out fixed-order sorting as a universally efficient linearization. It does not rule out a circuit-dependent asymmetric transformation with a different correctness mechanism.

### 6.2 A regular multiplicative section cannot exist

There is no algebra-homomorphic section of abelianization into the free noncommutative formal power-series algebra, regular at the scalar origin, when n >= 2. Such a section would send

\[
x_i\longmapsto x_i+\text{terms of degree at least two}.
\]

The images of x_1 and x_2 would have to commute, but their commutator has degree-two component `[x_1,x_2]`, which is nonzero. Higher-degree corrections cannot cancel it.

The qualification about regularity matters. This argument does not automatically apply to arbitrary rational expressions whose inverse operands have no scalar evaluation domain.

## 7. A positive theorem, then a decisive novelty correction

T1 and the multiplicity lemma yield a complete positive result.

### Reconstructed low-derivative-span hitting theorem K1

Suppose `r(P)<=r`, and put

\[
L=(n-1)\binom r2+r,\qquad
\phi_{i,L}(z)=\sum_{k=1}^{L-1}\frac{(-1)^{k-1}z^k}{k i^k}.
\]

Every nonzero P satisfying the promise has `P(phi_1,L,...,phi_n,L)` nonzero. If a degree bound D is supplied, then

\[
\mathcal H_{n,r,D}=
\{(\phi_{1,L}(t),...,\phi_{n,L}(t)):
 t=0,...,D(L-1)\}
\]

is a hitting set of at most `D(L-1)+1` rational points.

**Proof.** The system (3.1) has dimension at most r and the coefficient degrees required by (2.1). Algebraic independence ensures `P(ell)` is nonzero, and (2.1) makes its order less than L. Truncating each logarithm modulo `z^L` preserves the composition modulo `z^L`. The resulting nonzero polynomial has degree at most `D(L-1)`, so it cannot vanish at all the displayed distinct rational values.

For P nonzero, `deg(P)+1 <= r(P)`: choose a direction on which the top homogeneous part is nonzero; successive directional derivatives have distinct degrees and are independent. Therefore the construction can also use `D=r-1` and has polynomial size in n and r alone. The r=1 case consists of constants and is hit by the origin.

The rational generator can be constructed in polynomial bit time in n,r,D. For example, `(L-1)! i^(L-1)` clears each coordinate's denominators. At the displayed integer parameters, both numerator and denominator have polynomial bit length. This statement is about producing the hitting set; it does not silently assign polynomial bit cost to arbitrary black-box answers or to repeated-squaring circuits with enormous constants.

The characteristic-zero statement extends beyond C. All series have rational coefficients, and every finite-rank certificate persists after characteristic-zero field extension. Equivalently, the finitely generated field of coefficients occurring in a particular polynomial and its finite derivative data can be embedded into C; matrix ranks are preserved by field extension.

### Novelty finding — do not promote K1

The search located:

**Shubham Bhardwaj and Ramprasad Saptharishi, _Hitting Sets for Polynomials with Small Partial Derivative Spaces_, arXiv:2609.34436v1 / ECCC TR26-217, submitted 28 September 2026.**

The paper already proves polynomial-size hitting sets for this same class. Its explicit generator consists of truncated logarithms `-log(1-it)`, and its argument uses a derivation with trivial constant field and a Wronskian/multiplicity estimate. Its main proof was read, not inferred merely from a title. Changing the pole parameters to `-i`, or tracking the sharper coefficient in (2.1), does not make the underlying theorem a discovery from this investigation.

The conclusion is unambiguous: **K1 is existing research capital, not a new foundational result here.**

The published derivation argument can be handled without any potentially ambiguous instruction to merely sort an arbitrary basis by degree: choose a basis adapted to the degree filtration, or use the commuting nilpotent differentiation matrices and their trace-zero action on the determinant. This is a proof-presentation detail, not evidence that the theorem is false.

For a sum of k degree-D powers of affine linear forms, the derivative span is at most `k(D+1)`, so K1 yields a polynomial-size black-box test. This consequence is also explicitly covered by the existing preprint. General circuits can have exponentially larger derivative span, as the squarefree product already proves.

### Why no automatic bootstrap to general circuits was claimed

Known PIT bootstrapping results concern exact restricted classes and quantitative hypotheses. For example, tiny **diagonal depth-four** models allow powers of non-linear low-degree polynomials, not merely powers of linear forms. The small derivative-span bound for depth-three powering circuits cannot simply be substituted into those theorems. The relevant literature was consulted for this distinction, but no full bootstrap proving F1 was reconstructed.

Introducing an independent new variable for each bottom monomial does not solve the issue. Their intended substitutions obey toric algebraic relations, so a nonzero polynomial in the new variables can become zero after substitution. A hitting set for the unconstrained new variables does not enforce those relations.

## 8. Remaining foundational route: contact complexity rather than state complexity

The previous obstruction does not rule out direct nonlinear processing of the logarithmic circuit. It only shows that total derivative-span dimension cannot universally be replaced by a polynomial in circuit size in a faithful linear realization.

### Missing hypothesis C1

Does there exist an explicit polynomial B(n,s,D) such that every nonzero n-variable degree-at-most-D polynomial computed by a commutative circuit of size at most s satisfies

\[
\operatorname{ord}_0 P(\ell_1(z),...,\ell_n(z))<B(n,s,D)? \tag{8.1}
\]

The constants hidden in 'polynomial' must be uniform, not depend on P, its coefficients, n, s, or D. The claim is meaningful for arbitrary characteristic-zero coefficient fields, with the usual exact algebraic interpretation.

**Neither a proof nor a counterexample to (8.1) was obtained.** The existence of the series injection is not the missing ingredient. An effective size-sensitive truncation bound is.

### Conditional reduction — complete

If (8.1) holds, use `L=B(n,s,D)` in the truncated-log construction of Section 7. Then the same set of `D(L-1)+1` scalar rational points hits every circuit in the target class. The coordinate bit lengths and generator running time are polynomial in n,s,D. No noncommutative evaluation oracle or infinite-precision logarithm oracle is required.

Thus proving (8.1) would resolve the selected polynomial-degree black-box PIT target. The converse was not shown: other PIT algorithms may exist even if this particular logarithmic bound fails.

### Why an input-size parameter is essential

Let `M=binom(n+D,D)`, the dimension of all polynomials of total degree at most D. The first M-1 Taylor coefficients of `P(ell)` are M-1 linear constraints on M polynomial coefficients. There is therefore a nonzero P satisfying them. Algebraic independence prevents its composition from being identically zero, so

\[
\operatorname{ord}_0P(\ell)\ge M-1.
\]

Consequently there is no general polynomial bound depending only on n and D. This does not refute (8.1): the resulting P may require a large circuit.

### Exact experiments on multiaffine contact

The delivered contact examples have orders 1,3,7,15 for n=1,2,3,4. Two readable instances are

\[
P_2=x_1x_2+2x_1-4x_2,
\]

with order 3, and

\[
\begin{aligned}
P_3={}&66x_1x_2x_3-506x_1x_2+1617x_1x_3+311x_1\\
&-1506x_2x_3-1648x_2+1539x_3,
\end{aligned}
\]

with order 7. The integer coefficients of P_4 are stored in `contact_examples.json`, rather than hidden behind numerical fitting. The verifier checks the vanishing coefficients and the first nonzero coefficient exactly.

These examples demonstrate cancellation beyond the polynomial's degree. They do **not** constitute a uniform family of small circuits with superpolynomial contact. No asymptotic counterexample is being extrapolated from four examples.

A potentially decisive continuation is either an explicit polynomial-size circuit family contradicting (8.1), or a proof controlling contact under circuit operations without expanding the complete derivative closure. Merely reducing the coefficient in a bound polynomial in r(P) will not address this obligation.

## 9. A second attempted escape: rational pullback/contact amplification

One possible construction of high-contact counterexamples would iterate a ramified rational substitution while keeping the logarithmic alphabet fixed. This specific method has an exact obstruction.

### Theorem T5

If `R:P^1 -> P^1` is a rational map of degree d>1 and a finite set S satisfies `R^-1(S) subset S`, then `|S|<=2`.

**Proof.** Counting preimages with ramification multiplicity gives

\[
d|S|=\sum_{x\in R^{-1}(S)} e_x
\le |S|+\sum_{x\in\mathbb P^1}(e_x-1)
=|S|+2d-2.
\]

The final equality is the genus-zero ramification formula. Rearranging yields `(d-1)(|S|-2)<=0`.

For the logarithms used here, `S={-1,...,-n,infinity}`. If each `log(1+R(z)/i)` is expressible as a constant plus a linear combination of the original logarithms, differentiation forces the divisor of `1+R(z)/i` to be supported on S. For all i this gives `R^-1(S) subset S`. When n>=2, d>1 is impossible. A degree-one substitution fixing the ordinary base point has local degree one and cannot multiply contact order.

This is a restricted failed approach. It does not exclude introducing new poles, structured large alphabets, nonlinear changes of representation, or unrelated generators. More quantitatively, the same count gives
`|R^-1(S)| >= d(|S|-2)+2`, so preserving all logarithmic divisor information under degree-d pullback generally forces the alphabet to grow.

## 10. Verification record

The command

```
python verify.py --output verification_results.json
```

completed with `ALL CHECKS PASSED`.

It checks:

- Eight subset-Hankel certificates for n=1,...,8, including every entry of their displayed diagonal minors.
- Twenty-seven exact coefficient cut ranks for n=1,...,6, and Gram-matrix identities underlying the equal-singular-value calculation for n<=4.
- Ten finite translation-orbit polynomial models, including repeated-power products.
- Five exact shuffle identities and the nonzero commutator coefficient `-1/24`.
- Four high-contact examples using a standard-library replay distinct from their SymPy discovery calculation.
- Eighteen logarithmic-generator fixtures, including constants, univariate boundary cases, products, and cancellation examples.

No floating-point rank decisions, randomized experiments, asymptotic extrapolations, or claimed Lean verification are used. The computations illustrate and test the proofs; they do not substitute for the quantified arguments in Sections 3–9.

## 11. Final research judgment

The selected foundational problem remains unresolved. The investigation establishes an exact account of why the most direct transfer from noncommutative matrix hitting points fails for general commutative circuits, even though it succeeds for small derivative span. The positive result encountered on that restricted class was identified as existing literature and has not been counted as new.

The strongest internally complete result is the common-invariant theorem T1, with its rational-readout and robust finite-state consequences. Historical novelty of these representation statements has not been established; they should not be described as a foundational breakthrough or sent to specialists with a priority claim.

The viable unproved route retained here is (8.1). It concerns nonlinear contact complexity and is not invalidated by exponential differential-system dimension. No actual removal of that final obstruction has been demonstrated. This research state is therefore a rigorous continuation point, not completion of the user's foundational objective.

## 12. Source ledger

The accompanying `sources.json` gives pinned repository URLs, available blob identifiers, access scope, and their role. Principal sources:

1. Astra `00_START_HERE.txt`, frontier status files, `W-frontier-crossfield`, and corrected direct-finiteness audit, at the pinned Astra revision.
2. OpenAI, _One Rational Matrix Hitting Point for Noncommutative Formulas_, September 24, 2026, at the pinned source revision. The introduction, iterated-integral section, and complete multiplicity proof were inspected. No claim is made that every release family or formalization was checked.
3. Bhardwaj–Saptharishi, _Hitting Sets for Polynomials with Small Partial Derivative Spaces_, arXiv:2609.34436v1, September 28, 2026. The main HTML proof was inspected. This is the decisive novelty collision.
4. Deneufchatel, Duchamp, Minh, Solomon, _Independence of hyperlogarithms over function fields via algebraic combinatorics_, arXiv:1101.4497, 2011. Historical context; the particular independence needed here is proved directly.
5. Nisan, _Lower Bounds for Non-Commutative Computation_, STOC 1991, DOI 10.1145/103418.103462. Historical coefficient-rank context; the needed rank proofs are included here.
6. Kabanets–Impagliazzo, _Derandomizing Polynomial Identity Tests Means Proving Circuit Lower Bounds_, Computational Complexity 13 (2004). Historical significance and model-sensitive hardness–randomness context, not a proved new consequence of C1 here.
7. Agrawal, Forbes, Ghosh, Saxena, _Small hitting-sets for tiny arithmetic circuits or: How to turn bad designs into good_, ECCC TR17-035. Used to avoid conflating depth-three powering with the exact tiny depth-four bootstrapping classes.
8. DiPasquale, Flores, Peterson, _The apolar algebra of a product of linear forms_, arXiv:2002.04818. Terminology and classical apolar context, not evidence of priority for T1.

Only source pointers and this investigation's mathematics are bundled; full copies of external papers are not included. Internet access is not needed to run the verifier.
