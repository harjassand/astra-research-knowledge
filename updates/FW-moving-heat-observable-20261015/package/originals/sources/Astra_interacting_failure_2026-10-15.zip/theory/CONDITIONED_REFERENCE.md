# Implicit continuation bounds for interacting, irreversible reliability systems

15 October 2026. A task-specific construction and computational fixture, not a historical novelty claim or experimentally validated materials model.

## Outcome and scope

A nonexchangeable n-component interacting process admits on-demand two-sided continuation bounds, and an unbiased full-horizon estimator with a constant relative-second-moment bound, without visiting its 2^n states or waiting for passive failures. The tractable regime is low incidence: k = O(sqrt(n)) irreversible failures, pair influence O(1/n), and (for signed interactions) total baseline exposure O(1). This is a genuine interacting target, although the proposal uses an exactly tractable independent reference. The robust box optimizer is not needed. The mathematical engine is established reference-model importance sampling and stopped likelihood comparison; do not market the bounded-likelihood principle itself as new.

A constant-factor initial continuation enclosure necessarily is already a constant-factor deterministic approximation to the target probability. No method can satisfy a literal demand for useful relative initial bounds that convey no equivalent probability information. Here the distinction is meaningful: a factor 2.51 enclosure does not determine the requested 1% target probability, and conditional sampling supplies unbiased refinement at a cost unrelated to 1/p.

## 1. Model

Let x in {0,1}^n record irreversibly failed components. When x_i=0, i fails at rate

    a_i(x) = lambda_i [1 + sum_j w_ij x_j].

Initially x=0. All lambda_i>0. For the main theorem, 0<=w_ij<=beta/n, and w_ii=0. The entries and baseline rates may be arbitrary heterogeneous values; neither exchangeability nor low rank is required. Stop at tau_k, the kth failure. The target is p=P(tau_k<=T).

This is an explicit load-sharing/activation reliability model: each failed element weakly modifies intact-element hazard. It can represent phenomenological distributed damage or activation, but no real material is claimed to obey it without calibration. Dense heterogeneous W has n^2 input values; the model is implicit in state-space size, not sublinear in its input. Macroscopic failure thresholds, fast local cascades, healing, and hidden channels are outside the main theorem.

## 2. Reference and exact conditional proposal

Under P0, components fail independently at rates lambda_i. Put b_i=1-exp(-lambda_i T). Then

    h0 = P0(tau_k<=T) = P(sum_i Bernoulli(b_i)>=k).

Compute suffix tails F(i,r)=P(sum_{j>=i} Bernoulli(b_j)>=r), with F(i,0)=1 and F(n+1,r>0)=0, by

    F(i,r)=(1-b_i)F(i+1,r)+b_i F(i+1,r-1).

This costs O(nk) arithmetic and O(nk) memory for conditional sampling; a single tail value needs O(k) rolling memory.

To draw the entire reference trajectory conditional on tau_k<=T:
1. Start with need=k. For each i, select final failure indicator with probability b_i F(i+1,need-1)/F(i,need), if need>0; otherwise select with its ordinary probability b_i. Decrement need upon selection.
2. For selected i draw an independent exponential time conditional on being <=T: t_i=-log(1-U_i b_i)/lambda_i.
3. Retain the first k ordered failure times and stop there.

The sequential Bernoulli rule is ordinary conditional probability. Conditional on the final indicators the independent exponential times retain independence and the specified truncations. Therefore the stopped trajectory is exactly distributed as Q=P0(. | tau_k<=T). This is not a rejection sampler, and it does not wait 1/h0 trials.

## 3. Full continuous-time likelihood, with no omitted holding term

Let x_s be the state after s failures, i_(s+1) the next failed component, and Delta_s its waiting time; s=0,...,k-1 on a successful path. Let

    A(x)=sum_{i:x_i=0} a_i(x),
    B(x)=sum_{i:x_i=0} lambda_i.

The Radon-Nikodym likelihood on this stopped path is

    L = product_s [a_i_(s+1)(x_s)/lambda_i_(s+1)]
        * exp[-sum_s (A(x_s)-B(x_s)) Delta_s].

This follows directly from exponential competing-clock path densities. There is no survival factor after tau_k because both path laws stop there. On event tau_k<=T, dP/dQ=h0 L. Consequently Y=h0 L is unbiased for p.

At stage s, every rate ratio lies in [1,1+beta*s/n], and A-B>=0. Thus

    0<L<=C_k,    C_k=product_{s=0}^{k-1}(1+beta*s/n)
                   <=exp(beta*k*(k-1)/(2n)).

A monotone coupling with the independent baseline gives p>=h0: the true hazard of every intact component is at least its reference hazard. Let mu=E_Q L=p/h0>=1. Since L^2<=C_k L,

    E_Q[Y^2]/p^2 = E_Q[L^2]/mu^2 <= C_k/mu <= C_k.

Both the entire holding-time history and all k events are charged in this bound. There is no accumulation of unaccounted local box factors, no deterministic discretization of continuous time, and no horizon tail truncation.

For k<=c sqrt(n) and fixed beta, C_k<=exp(beta*c^2/2). The relative Monte Carlo error is uniformly controlled even when h0 is extraordinarily small. For example, Hoeffding gives a conservative fixed-sample relative-error guarantee using N>=C_k^2 log(2/alpha)/(2 epsilon^2), since mu>=1. This bound assumes exact mathematical draws and weights; implementation error must be budgeted separately. Observed small empirical variance is not a substitute for the analytic guarantee.

## 4. On-demand continuation intervals from any encountered state

At a state x with r<k failures and time remaining t>0, freeze its CURRENT intact rates:

    nu_i = lambda_i [1+sum_{j:x_j=1} w_ij],  i intact.

For future failures, the actual rate can be rewritten

    a_i(x union z) = nu_i [1+sum_{j:z_j=1} w_ij/(1+sum_{old j}w_ij)].

The adjusted nonnegative influences are still <=beta/n. Let m=k-r, and h0(x,t) be the independent Poisson-binomial tail with these frozen nu_i and threshold m. Repeating the stopped-likelihood proof gives

    h0(x,t) <= h(x,t) <= min(1,C_m h0(x,t)).

This is a fresh O((n-r)m) DP at the queried state, with no table of unvisited interacting states. Freezing current rates removes the penalty from past failures; the enclosure improves as the threshold approaches. Terminal states have exact continuation 1, and t=0 before threshold has exact continuation 0.

The same conditioned-reference sampler started at x refines h(x,t) with relative second moment <=C_m. This does not assert that a policy that repeatedly refreshes its reference after every jump inherits the same bound; the proven sampler freezes one reference at the start of each requested continuation simulation.

For certified numerical intervals, enclose each exp(-nu_i t) and -expm1(-nu_i t) with directed rounding, then use outward-rounded nonnegative DP operations. If h0 is enclosed by [l0,u0], return [l0,min(1,C_m u0)]. The interval implementation added in Section 9 supplies this reference-DP step. The separate floating-point path checks below remain validation fixtures, not certified exact samples. Because the DP has nonnegative terms, precision can be increased without cancellation in its tail recursion; accurate expm1 evaluation matters when rates times time are small. Bit precision, random-bit sampling error and likelihood rounding must be charged in any production theorem, rather than hiding them in unit-cost arithmetic.

## 5. Signed interactions: the holding-time obstruction can be bounded

Suppose instead |w_ij|<=beta/n and beta*(k-1)/n<1. The stopped process has positive rates on all pre-threshold states. Put gamma=beta/n and Lambda=sum_i lambda_i. The jump-ratio products lie between product_s(1-gamma*s) and product_s(1+gamma*s). Also

    |A(x_s)-B(x_s)| <= gamma*s*Lambda.

Since the successful stopped duration is <=T,

    L_minus = product_s(1-gamma*s) exp[-gamma*(k-1)*Lambda*T]
    <= L <=
    L_plus  = product_s(1+gamma*s) exp[ gamma*(k-1)*Lambda*T].

Therefore L_minus*h0<=p<=L_plus*h0. There is no monotone lower bound h0 now. For any random variable L in [a,b] with a>0, (L-a)(L-b)<=0 gives E L^2 <=(a+b)mu-ab. Maximizing this divided by mu^2 over mu in [a,b] gives

    E_Q[Y^2]/p^2 <= (L_plus+L_minus)^2/(4 L_plus L_minus).

For k=O(sqrt(n)) and Lambda*T=O(1), log(L_plus/L_minus)=O(1), so this remains a constant. Inhibitory interactions are thus covered in a narrower, explicitly charged exposure regime. At arbitrary starting x one may freeze current nu_i again, but must replace gamma by beta/[n min_intact(1+sum_old w_ij)] and require gamma*(m-1)<1; positivity and the changed total exposure must be checked. Unbounded or unmodeled negative interactions invalidate these inequalities.

## 6. Full-horizon computational resources

- Read/store an explicit dense W: O(n^2) time and memory. This cannot be omitted.
- Initial reference suffix DP: O(nk) arithmetic and memory; reusable over all samples from the same state/time.
- Conditional subset draw: O(n) arithmetic per sample, including sampling ordinary indicators after the threshold is met.
- Time draws: at most n logarithms. Sort all selected times in O(n log n), as in check.py, or select the first k in O(n) expected time and sort those in O(k log k).
- Likelihood: maintain load_i=sum_failed w_ij. At each of k events add one W column and calculate the alive weighted excess hazard. This is O(nk) arithmetic per path, not O(k) for dense interactions. The reference proposal requires no additional state-space solve.
- A fresh nonempty starting state needs its loads, O(nr) arithmetic without a maintained state; after this its bounds cost O((n-r)(k-r)).
- Full sample count depends on the certified relative-moment bound and requested precision/confidence, not 1/p. There is no hidden physical preparation cost in this mathematical simulation model; using it for physical inference requires a separate model/calibration error budget.

## 7. Computational checks

Run: OPENBLAS_NUM_THREADS=1 python check.py. Seed 721.

Three nonexchangeable positive-interaction systems with n=9,11,12 were compared against exact sparse-generator calculations over all pre-threshold states (used only to validate small fixtures). A tilted generator has off-diagonal entries lambda_i*(a_i/lambda_i)^2 and diagonal B-2A; its absorbed mass equals E_P0[1_A L^2]. Hence h0 times this mass divided by p^2 gives the exact relative second moment, up to numerical exponential error. All probability enclosures and moment inequalities passed. Their actual relative second moments were 1.00332, 1.01279 and 1.02205.

Large fixture: n=400, k=20, beta=2, T=.005, lambda_i uniform on [.5,1.5], arbitrary dense heterogeneous w_ij uniform on [0,beta/n]. State space size is 2^400 and the relevant pre-threshold subset is also enormous; none is enumerated. The baseline exposure is about two failures.

    h0 = 5.104187187104102e-14
    C_k = 2.510662313729246
    3,000-sample mean L = 1.5269716930232247
    standard error of mean L = 0.0005639938069938464
    empirical relative second moment = 1.0004091317313788
    largest observed L = 1.6380602719127135 < C_k

The resulting point estimate p is approximately 7.794e-14. The empirical standard error is descriptive and is not a rigorous 1% certification. Reference preparation took about .001 seconds and all 3,000 samples about one second in this environment; no baseline-method speed benchmark is claimed.

Two additional signed-interaction exact small checks (n=10,12) passed the signed enclosures and Kantorovich moment bound. Their p/h0 were .9411 and .9532; relative second moments 1.0203 and 1.0647. See results.json for all parameters and numbers.

## 8. Comparison and decisive remaining obstruction

Independent reference factorization is computational machinery, not an assertion that the interacting target factorizes. Heterogeneous W generally prevents count lumping. h0 is known, p is not; their ratio is computed by genuinely interacting path likelihoods. The deterministic factor-C enclosure already settles some coarse questions, while 1% refinement remains meaningful.

This is a standard structural route to strong efficiency: approximate a conditional/zero-variance path law and bound the likelihood. Blanchet and Glynn (2008) explicitly use state-dependent approximations and Lyapunov bounds for a different rare-event class; our calculation should be compared against that tradition rather than described as its invention. Primary source: https://web.stanford.edu/~glynn/papers/2008/BlanchetG08.pdf . More general approximate zero-variance mean-square bounds are studied by Awad, Glynn and Rubinstein, https://doi.org/10.1287/moor.1120.0569 . No comprehensive reliability-specific priority search has been completed.

Adaptive multilevel splitting (Cérou and Guyader, 2007, https://doi.org/10.1080/07362990601139628) and weighted ensemble (Zhang, Jasnow and Zuckerman, 2010, https://pmc.ncbi.nlm.nih.gov/articles/PMC2830257/) provide established trajectory methods. They do not require this independent reference. Our attraction on this restricted fixture is an explicit a priori full-horizon relative-moment bound and direct event-conditioned draws; it is not evidence of superiority over tuned splitting or WE. The WE primary paper establishes statistical exactness broadly; statistical exactness alone is not a uniform relative-cost bound. No empirical comparison against optimized implementations was performed.

The box-optimizer compiler does not create the useful operation here: the direct stopped likelihood already proves its cost. Feeding independent continuation boxes through a conservative per-step verifier can discard correlations and worsen the certificate. Do not force the new optimizer into this example merely to claim an application.

The precise obstruction at macroscopic k=theta*n is log C_k=Theta(n) for fixed positive beta. In the homogeneous model, short-horizon path ratios approach the jump product as T tends to zero, so this particular uniform upper bound cannot simply be replaced by a constant. That does NOT prove sampling itself is inefficient: a nearly constant large likelihood can still have tiny relative variance. It proves the current comparison certificate no longer establishes strong efficiency. A next substantive target is to capture a collective interacting reference (for example a count-dependent load-sharing baseline) while retaining heterogeneous residual-error control and cheap conditional path sampling. Homogeneous count dynamics alone are exactly tractable and not a breakthrough. The difficult operation is a certified conditional sampler for the interacting collective reference with bounded heterogeneous residuals, without restoring state enumeration.

For local strong couplings a single failed neighbor can change hazard by O(1), so the current bounded pair-influence premise fails even when n is huge. For reversible damage/recovery or rare transport with many loops, the number of likelihood factors is not bounded by k; repeated events and occupation-time defects need a new argument. Unmodeled channels, unknown interaction signs/magnitudes, non-Markovian history dependence and parameter uncertainty invalidate the exact likelihood unless incorporated explicitly. Bounds on the nominal model cannot be presented as bounds on the physical world without that step.

## 9. Added numerical enclosure and confidence calculation

`interval_check.py` now supplies the reference DP with mpmath's interval arithmetic at 60 decimal digits. Inputs from `fixture.npz` are interpreted as the exact dyadic values represented by those floating-point inputs; T in the underflow stress test is the exact decimal 1e-20. This uses outward interval exp and expm1 primitives and nonnegative DP arithmetic. It is an interval implementation of the previously specified acquisition step, relying on the correctness of that interval library, not a formally verified numerical kernel. It does NOT turn the separate NumPy conditional sampler into an exact sampler.

For the n=400 fixture the enclosure is centered at 5.1041871871040990383905951434e-14 and has relative width less than 1.14e-58, in about .09 seconds. The first conditional Bernoulli probability is enclosed near .05631921875119. With T=1e-20, the same n,k,beta give h0 near 3.4951738076162048077e-367, below double underflow; its relative enclosure width is below 1.19e-58, in about .11 seconds. The conditional first-failure probability remains near .05603345699893. Thus tiny absolute rare probabilities do not intrinsically defeat the DP or the conditional probabilities. See interval_results.json. These checks cover initial reference acquisition; arbitrary-state acquisition uses the same recurrence after enclosing current-rate sums.

For ideal i.i.d. L samples, fixed in advance at N=3000, the two-sided empirical Bernstein radius at confidence 1-alpha is

    R = sqrt(2 S^2 log(4/alpha)/N)
        + 7 C_k log(4/alpha)/(3(N-1)),

where S^2 is the unbiased sample variance. This follows by applying Maurer and Pontil (2009), Theorem 4, to L/C_k and 1-L/C_k and using a union bound. Primary theorem inspected: https://www.cs.mcgill.ca/~colt2009/papers/012.pdf . This is a fixed-sample bound, not an optional-stopping confidence sequence.

Putting the fixture's numerical moments into this theorem gives R=.01022945574087 and R/(mean L-R)=.00674436. The corresponding ideal-sampling 95% p interval is [7.7417363e-14,7.8461624e-14], narrow enough for a 1% relative estimate. This is a theorem-backed diagnostic conditional on exact i.i.d. sampling and exact weights, NOT a rigorous computed confidence claim for the floating-point implementation. We did not run a larger experiment merely to conceal that distinction.

Numerical error can be controlled at the conditioned, bounded-likelihood scale. Suppose an implemented weight Lhat is clipped into [0,C_k] and coupled to an ideal draw L so that |Lhat-L|<=zeta except on probability at most eta. Then

    |E Lhat-E L| <= zeta+C_k*eta.

If hhat has relative error at most rho from h0, the resulting expectation has relative bias at most

    rho + (1+rho)(zeta+C_k*eta),

using E L>=1. Thus eta need not be O(p). An approximate path law at total variation eta is sufficient, but not necessary, for such a contract. Crucially, floating time grids have total variation distance one from a continuous path law, so their error must be handled by a functional coupling, interval/refinement construction, or another explicit argument. The current NumPy sampler does not yet provide this error contract. Its PRNG is also a reproducibility device, not a mathematical proof of independent random bits.

A production exact-bit construction can refine interval Bernoulli probabilities against successively revealed uniform bits, refine truncated exponential time intervals until their order is resolved, and evaluate likelihood intervals until their widths meet the allocated budget. Bernoulli thresholds and time ties have probability zero under ideal uniforms, so each individual decision terminates almost surely. A uniform expected-bit/runtime analysis and implementation are still required before claiming a fully certified bit-complexity sampler.

## 10. More specific reliability prior art

Cancela, L'Ecuyer, Rubino and Tuffin (2010), “Combination of Conditional Monte Carlo and Approximate Zero-Variance Importance Sampling for Network Reliability Estimation,” https://www.informs-sim.org/wsc10papers/116.pdf , assumes independent static link failures and combines conditional sampling with approximate zero-variance IS. Proposition 1 proves bounded relative error for suitable constant-factor continuation approximations, and its proof explicitly accumulates likelihood factors. That paper is strong evidence against any novelty claim for conditioning plus approximate zero variance or for the generic bounded-relative-error argument.

The exact distinguishing fixture here is a time-dependent, heterogeneous, interacting irreversible failure CTMC, including its holding-time likelihood, with an explicit dimension-dependent bound that remains constant for k=O(sqrt(n)). This distinguishes the mathematical assumptions and conclusion; it does not establish historical novelty. A reliability-specific prior-art search beyond the cited comparator remains necessary.

## 11. Conditional extension to strongly interacting local blocks

Partition components into independent reference blocks. Within each block allow arbitrary attractive irreversible failure rates a_i^0(x_block), including strong local cooperation. Let the target rate be a_i^0(x_block)*(1+delta_i(x)) with 0<=delta_i(x)<=beta*|x|/n. If one can sample the independent-block reference conditioned on k total failures before T, the stopped likelihood and monotone-coupling proof above are unchanged: internal rates cancel in jump ratios, the holding term is <=1, and C_k is the same.

For block size b, local probabilities can be computed using 2^b-state CTMC generators; block terminal-count distributions can be convolved, then local trajectories conditioned on their terminal counts can be drawn and merged. This suggests polynomial arithmetic for b=O(log n), but the required conditional CTMC bridges, matrix-exponential precision and their complete runtime bounds must be supplied. This is a conditional theorem/next construction, not an implemented extension. It would address strong local interactions that the all-pairs-small fixture excludes without pretending that arbitrary strong global interactions have been solved.

## 12. Equal-load-sharing fiber specialization: deterministic jump normalization

A more physically motivated specialization suggested during review is

    a_i(x)=lambda_i g(|x|),  g(r)=(1-r/n)^(-rho), rho>0.

Under constant total load each surviving fiber carries stress multiplied by (1-r/n)^(-1); a power-law stress-dependent rupture hazard gives this multiplier. Time-dependent fiber-bundle models with power-law failure rates and equal versus local load sharing are explicitly studied by Newman and Phoenix (2001), https://pubmed.ncbi.nlm.nih.gov/11308498/ . The heterogeneous lambda_i variant here is a mathematical model, not a calibrated material. Its count process generally is not Markov because the remaining sum of baseline rates depends on the identities of broken fibers.

A useful additional cancellation occurs. On every successful k-failure path the jump product is the SAME number

    C = product_{r=0}^{k-1} g(r).

Writing L=C Z, the remaining normalized weight is

    Z=exp[-sum_r (g(r)-1) B(x_r) Delta_r].

It lies in [exp(-D),1], with D=(g(k-1)-1)*Lambda*T. Therefore

    h0*C*exp(-D) <= p <= min(1,h0*C),
    E[Y^2]/p^2 <= cosh(D/2)^2,
    Y=h0*C*Z.

The relative-moment conclusion does NOT depend on C being small. The earlier generic jump-product bound is unnecessarily pessimistic for this model. For k=alpha*n with any fixed alpha<1, fixed rho, and Lambda*T=O(1), D stays bounded, so the method remains strongly efficient even at a macroscopic damage fraction. This is an exact mathematical extension beyond k=O(sqrt(n)), obtained from the special common multiplier. At k=n, D generally blows up; this argument does not certify complete catastrophic bundle failure efficiently.

At an arbitrary current state with r failures, take frozen rates nu_i=lambda_i*g(r), remaining m=k-r, and reference h0(x,t). Replace the jump product by product_{s=0}^{m-1} g(r+s)/g(r) and D by [g(k-1)/g(r)-1]*(sum_alive nu_i)*t. The same interval and normalized-moment proof holds.

`els_check.py` runs this specialization using the same 400 heterogeneous baseline rates, k=100, rho=2 and T=.005. Results:

    baseline total exposure = 2.02648
    h0 = 4.3175785e-135
    log C = 27.10321
    D = 1.55225
    certified relative second moment <= 1.73347
    3,000-sample mean Z = .58255065
    empirical relative second moment = 1.00115221
    estimated p = 1.4837131e-123

Preparation was about .001 seconds, sampling about 1.10 seconds, and interval reference acquisition about .28 seconds. The outward interval deterministic enclosure is approximately [5.39364e-124,2.54693e-123]. It does not already settle 1% p. Again the Monte Carlo numbers are floating-point fixtures, not a numerically certified confidence claim.

A strong competitor is permutation Monte Carlo / conditional holding-time integration. Because the same g(r) multiplies all intact rates, the next failed identity has probability lambda_i/B(x), unaffected by g. Thus sample a size-biased failure permutation and integrate the sum of exponential holding times with rates g(r)B(x_r) analytically/numerically. This produces another unbiased estimator, often with favorable variance. Even simple count-rate comparisons use bounds on sums of remaining lambda_i to provide deterministic scalar pure-birth brackets. A matched implementation benchmark is required before claiming an advantage over these established reductions. Conditioning and deterministic normalization alone are not new scientific capability.

Finally, “100 failures among 400 fibers” is a damage-threshold event. It can be consequential only if a specified engineering service limit or observable is attached to that threshold. It is not automatically equivalent to catastrophic bundle failure or material fracture. The new result is a rigorously bounded computational model capability, not a demonstrated materials discovery.
