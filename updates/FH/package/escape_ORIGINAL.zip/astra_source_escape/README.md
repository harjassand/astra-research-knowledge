# Astra source–escape acquisition checkpoint

Start with `RESEARCH_NOTE.md`. This is a research prototype for a specified kinetic Ising family, not molecular-prediction software.

## Reproduce

Python 3, NumPy, SciPy and SymPy are required. No network access is used by the scripts. The authoritative certificate uses Python exact rational arithmetic; a floating sparse solve only proposes the witness.

```bash
cd astra_source_escape
OPENBLAS_NUM_THREADS=1 python acquisition.py 24 1000 acquired_example.json
OPENBLAS_NUM_THREADS=1 python preparation.py 24 1000 prepared_example.json
```

The experiment and audit drivers currently write to `/mnt/data/astra_source_escape`, matching this checkpoint environment. Change the single `root` assignment in `experiments.py` and the corresponding output paths in `audit.py` when reproducing elsewhere. Core modules and the commands above accept explicit output paths and do not require that directory.

`collective_sector.py` is the final two-dimensional slow-closure backend. `acquisition.py` recovers an unknown cycle from exact weight/energy queries under the declared pairwise class. `preparation.py` treats an all-closed point preparation. `experiments.py` records independent rarity, dimension, clocks, preparation and uncertainty variations. `audit.py` explicitly enumerates small systems for checks only; that work is not part of the non-enumerative candidate.

`probe_moments.py`, `slow_sector.py`, `refine_sector.py`, `polynomial_sector.py`, and `defect_sector.py` retain earlier mechanisms and failed trials. Do not treat an exploratory result as the authoritative final certificate. `experiments.json` and `acquired_*.json` are the final main results. `audit_results.json` and `audit_run.log` record the final verifier run.

## Limitations

Exact pairwise structure and the microscopic heat-bath law are premises. Energy probes cannot establish absence of unmodeled higher-order traps or arbitrary kinetic prefactors. The main structural complement proof applies to a symmetric homogeneous ring. Error propagation for bounded symmetry-breaking energy uncertainty is derived and evaluated, but a general noisy graph-inference backend is not implemented. No WE, TAMMBER, AIMMD or tensor head-to-head benchmark was executed.
