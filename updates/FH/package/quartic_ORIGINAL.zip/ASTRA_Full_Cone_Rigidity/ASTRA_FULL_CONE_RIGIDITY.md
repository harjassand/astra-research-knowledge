# ASTRA Meta-Genesis: nullspace closure and full-cone quartic rigidity

Research date: 14 October 2026 (Australia/Brisbane).

## Status and scope

This note develops an analytic route that does not require a positive heat-dissipation certificate. Its results are:

1. A nullspace-closure theorem for homogeneous quartics whose admissible directions are the zero set of one indefinite quadratic form. It applies to **all 35 coefficients** of planar quartics, without rotational invariance.
2. A classification, across the **entire nine-dimensional left-SO(2)-invariant rank-one-convex quartic cone**, of the exceptional integrands that admit a singular averaged Hessian with a balanced second moment of rank at least three.
3. A genuine Jensen inequality for every compatible periodic or zero-boundary gradient whose averaged Hessian is singular. The construction is either an explicit polyconvex decomposition or a two-phase rank-one Jensen argument.
4. An explicit compatible field showing why monotonicity under any one fixed, constant-coefficient, uniformly parabolic linear diffusion cannot be a universal proof mechanism, even for uniformly quasiconvex quartics.

**The implication rank-one convexity => quasiconvexity for the full nine-coefficient cone is not proved. No planar compatible counterexample is constructed. The unresolved sector has positive-definite averaged Hessian; sequences approaching a singular face also require quantitative analysis not supplied here. Historical novelty, external review and proof-assistant formalization are not established.**

The new analytic arguments below do not depend on the correctness of the previous sharp one-parameter theorem. Its standalone exact verifier was nevertheless replayed successfully. The included new verifier checks polynomial identities, complete invariant-basis dimensions, exact examples, and the finite algebra used in the classification. It does not replace the analytic proofs.

## 1. Definitions and the actual variational object

Identify V=R^(2x2) with R^4 in row-major order. Write A=(x|y) and identify each output column with a complex number x_C,y_C. Put

    u=|x|^2, v=|y|^2, w=x.y, q=det A.

A left-SO(2)-invariant homogeneous quartic has the general form

    F=A_c u^2+B_c v^2+C uv+E w^2+G uw+H vw
      +L qu+M qv+N qw.                                      (1.1)

No equality between L and M and no vanishing of N is assumed anywhere in the full-cone theorems.

Rank-one convexity (ROC) of a C^2 function is equivalent to

    D^2F(A)[R,R]>=0 whenever rank R<=1.                       (1.2)

For planar matrices, rank R<=1 is exactly q(R)=0. For a smooth periodic potential phi on a flat two-dimensional torus, let X=Dphi and use normalized spatial averages E. Then

    E X=0,    E q(X)=0.                                     (1.3)

The second identity follows by writing

    det Dphi = partial_1(phi_1 partial_2 phi_2)
             - partial_2(phi_1 partial_1 phi_2).

The same identities hold for W^{1,4} periodic potentials and zero-boundary potentials by density.

Define the real symmetric 4x4 matrices and cubic vector

    C=E[vec(X) vec(X)^T],
    H=E[D^2F(X)],
    b=E[DF(X)],       c=E[F(X)].                              (1.4)

Here C is the covariance because X has mean zero. We use the same second-moment notation for abstract probability laws when a mean is not specified.

Quartic polarization gives the exact identity

    E[F(B+X)-F(B)] = c+b:B+(1/2) B:H B.                       (1.5)

Crucially, the Hessian is evaluated at X, not at the affine background B. The identity follows from homogeneity:

    F(B+X)=F(B)+DF(B)[X]+(1/2)D^2F(X)[B,B]+DF(X)[B]+F(X).

The first-order term averages to zero. Equation (1.5) by itself is only an expansion, not a quasiconvexity theorem. The following results prove what happens on its degenerate faces.

## 2. A known quadratic ingredient, with a self-contained proof

### Lemma 2.1: one indefinite quadratic constraint

Let q and Q be real quadratic forms on a finite-dimensional vector space. Suppose q takes both positive and negative values and Q>=0 wherever q=0. Then

    Q=P+lambda q,       P>=0                                (2.1)

for some real lambda.

This is the indefinite, non-strict Finsler lemma. Its indefiniteness hypothesis is important; the assertion is false for arbitrary semidefinite q without additional conditions. This established quadratic ingredient is credited to the Finsler/S-lemma literature [1], not claimed as new.

**Proof.** For q(x)>0 and q(y)<0, the restriction of q to span{x,y} is indefinite and nondegenerate. In coordinates where it is s^2-t^2, write Q=a s^2+2c st+b t^2. The null-cone hypothesis gives a+b>=2|c|. Thus, with lambda=(a-b)/2, Q-lambda q is positive semidefinite on this plane. In particular,

    Q(y)/q(y) <= Q(x)/q(x).

Consequently

    sup_{q(y)<0} Q(y)/q(y) <= inf_{q(x)>0} Q(x)/q(x).

Both endpoints are finite: fix one positive-q and one negative-q vector and use the displayed ordering. Any lambda between the endpoints makes Q-lambda q nonnegative on q>0 and q<0; the null-cone hypothesis handles q=0. QED.

### Lemma 2.2: quadratic vanishing on an indefinite null cone

If q is indefinite, including possibly a radical, and a quadratic form B vanishes on {q=0}, then B is a scalar multiple of q.

**Proof.** Diagonalize q into positive squares, negative squares, and zeros, rescaling the nonzero entries to +/-1. Tests on e_i+/-e_j with opposite signs force the corresponding mixed entries of B to vanish and match its diagonal entries with those of q. Tests on linear combinations of two coordinates with the same sign and one with the opposite sign remove the remaining mixed entries. Translating null vectors along radical directions removes mixed radical entries; radical vectors themselves remove the radical block. Thus B=lambda q. QED.

### Lemma 2.3: cubic integrability kills quadratic proportionality

Let U be a real vector space and q|U indefinite. If a homogeneous cubic C on U satisfies

    D^2C(Y)[R,R]=0 for every Y in U and R in U with q(R)=0,

then C=0 on U.

**Proof.** Lemma 2.2 gives D^2C(Y)=lambda(Y) q as quadratic forms. The scalar lambda is linear in Y. In diagonal coordinates for q, choose for each k an index i!=k with q_ii!=0; this is possible because an indefinite quadratic form has at least two nonzero diagonal entries. Symmetry of the cubic tensor gives

    lambda(e_k) q_ii
       = D^2C(e_k)[e_i,e_i]
       = D^2C(e_i)[e_k,e_i]
       = lambda(e_i) q_ki = 0.

Thus lambda=0. The Hessian of C is identically zero, and homogeneity makes C=0. This proof includes indefinite restrictions having a nontrivial radical. QED.

## 3. The nullspace-closure operation

### Theorem A: one-quadric quartic closure

Let V be any finite-dimensional real vector space, q an indefinite quadratic form on V, and F a homogeneous quartic satisfying

    D^2F(A)[R,R]>=0 for every A and every R with q(R)=0.

Let nu be a probability law with finite fourth moment and integral q(X) dnu=0. Then

    H_nu := integral D^2F(X) dnu >= 0.                       (3.1)

Furthermore,

    A in ker H_nu  =>  DF(X)[A]=0 for nu-almost every X.      (3.2)

The pointwise almost-everywhere assertion is stronger than cancellation of the averaged cubic vector. No rotational invariance, heat flow, finite Fourier support, or assumed positive moment completion is required.

**Proof.** Fix A. Homogeneous quartic polarization gives the reciprocity identity

    D^2F(A)[X,X]=D^2F(X)[A,A].                               (3.3)

Apply Lemma 2.1 to Q_A(X)=D^2F(A)[X,X]:

    Q_A(X)=P_A(X)+lambda_A q(X),    P_A>=0.                   (3.4)

Averaging and using the quadratic moment identity gives

    A:H_nu A = integral P_A(X) dnu >=0.

This proves (3.1).

Suppose now A is in the kernel. The nonnegative polynomial P_A vanishes nu-almost everywhere, so nu is supported on U=ker P_A. If R belongs to U and q(R)=0, then D^2F(A)[R,R]=0. The function

    t -> D^2F(A+tY)[R,R]

is a globally nonnegative quadratic polynomial, with value zero at t=0. Its derivative there is zero:

    D^3F(A)[Y,R,R]=0 for every Y.                            (3.5)

Put C_A(X)=DF(X)[A], a homogeneous cubic. Quartic tensor symmetry gives

    D^2C_A(Y)[R,R]=D^3F(A)[Y,R,R].                           (3.6)

If q|U is indefinite, Lemma 2.3 applied on U gives C_A|U=0. If q|U is positive or negative semidefinite, its zero mean under a law supported on U forces q(X)=0 almost everywhere. For each such X, put R=Y=X in (3.5); by quartic homogeneity this forces DF(X)[A]=0. The identically zero restriction is included. Thus (3.2) holds in every case. QED.

### Algebraic form retained for the classification

The proof also establishes a measure-free statement: whenever (3.4) holds, if q restricted to ker P_A is indefinite, then

    DF(X)[A]=0 for every X in ker P_A.                       (3.7)

This stronger algebraic restriction is what constrains the quartic itself in Section 4.

### Corollary A.1: exact background deflation

For any centered law in Theorem A, b=E DF(X) belongs to ran H. Therefore (1.5) is constant along every direction in ker H, has a finite attained minimum, and

    min_B E[F(B+X)-F(B)] = c-(1/2) b^T H^dagger b.            (3.8)

All minimizers are B=-H^dagger b+ker H. This includes singular H without an assumed compatibility between b and H: that compatibility was proved, even pointwise on the law's support.

Equation (3.8) does not assert that the minimum is nonnegative. Theorem A closes the nullspace coupling, not the whole fourth-order inequality. It applies to arbitrary determinant-balanced laws in the planar case, including laws that are not gradients and may violate quasiconvex Jensen inequalities. Actual differential compatibility remains essential later.

## 4. A low-rank classification in the full invariant cone

Define the exceptional class

    E = { F(A)=gamma (det A)^2+|alpha x_C+beta y_C|^4 :
          gamma>=0, alpha,beta in C }.                       (4.1)

A nonnegative coefficient on the fourth power can be absorbed into alpha,beta. Zero coefficients are allowed. Every member is polyconvex: the fourth power is convex in the entries, and the other term is convex in the determinant. The class is preserved by invertible real input-coordinate changes A->AS.

### Lemma B: classification of a rank-at-most-one PSD remainder

Let F be a left-SO(2)-invariant ROC homogeneous quartic. Suppose at some A!=0,

    D^2F(A)[X,X]=P(X)+lambda det X,
    P>=0, rank P<=1.                                        (4.2)

Then F belongs to E.

This assertion has no coefficient restrictions within (1.1).

### Proof, part 1: rank-one A

Reciprocity makes D^2F(A) positive semidefinite when A is rank one. If lambda!=0, the form lambda det has two negative directions. A PSD form of rank at most one cannot eliminate negativity on their whole two-dimensional subspace. Hence lambda=0 and rank D^2F(A)<=1.

Homogeneity and left rotations imply, with J=[[0,-1],[1,0]],

    D^2F(A) A=3 DF(A),
    D^2F(A)(JA)=J DF(A).                                    (4.3)

If F(A)>0 then DF(A)!=0, and DF(A),JDF(A) are linearly independent. Thus the Hessian would have rank at least two. Rank-one convexity ensures F(A)>=0 on rank-one matrices, so F(A)=0.

The binary rank-one restriction P_0(s,t)=F(e_1 tensor (s,t)) is a convex nonnegative quartic with a nonzero zero direction. Its fourth root is the gauge of its convex balanced unit sublevel set, hence a seminorm. A zero direction is a translation-invariant direction of this seminorm. After an invertible input-coordinate change,

    P_0(s,t)=c s^4, c>=0.

Comparing coefficients in (1.1) then gives

    F=c u^2+lambda_0 q^2+q(Lu+Mv+Nw).

Its Hessian at e_12 is

    [ 0  0   -N     M ]
    [ 0  0   -3M    0 ]
    [-N -3M  2lambda_0 0]
    [ M  0    0     0 ].

This matrix is PSD because e_12 is rank one and reciprocity applies. Its zero diagonal entries force M=N=0. At e_11 the Hessian becomes

    [12c 0   0    3L]
    [0   0  -L     0]
    [0  -L   4c    0]
    [3L  0   0  2lambda_0].

PSD forces L=0 and lambda_0>=0. This is (4.1), and undoing the input-coordinate change preserves (4.1).

### Proof, part 2: invertible A and the forced Hessian

Replace F(B) by F(BA), sending the distinguished matrix to I. This preserves all hypotheses and the conclusion, including the rank of P. Use the real matrix basis

    I, J=[[0,-1],[1,0]], K=diag(1,-1), L0=[[0,1],[1,0]].

Write B=i I+j J+k K+l L0. Then

    det B=i^2+j^2-k^2-l^2.

Set f=F(I), a=DF(I)[K], b=DF(I)[L0]. Relations (4.3) force the first two Hessian rows and columns to have the form

    [12f  0   3a  3b]
    [0    4f  -b   a]
    [3a   -b   *   *]
    [3b    a   *   *].                                      (4.4)

Write P(X)=(v.X)^2, allowing v=0. Comparing (4.2) with (4.4) gives

    v0 v1=0,
    v0 v2=3a, v0 v3=3b,
    v1 v2=-b, v1 v3=a,
    8f=v0^2-v1^2.                                          (4.5)

Consequently a=b=0. There are three cases.

**Case f<0.** Only v1 can be nonzero, and ker P={j=0}. The determinant is indefinite on this subspace. Equation (3.7) then forces DF(X)[I]=0 on it. Taking X=I gives 4f=0, a contradiction.

**Case f>0.** Only v0 can be nonzero, lambda=4f, and P=8f i^2.

**Case f=0.** Here lambda=0, v0=v1=0, and P is a PSD form of rank at most one on the (k,l)-plane.

### Proof, part 3: complex coordinates finish both remaining cases

Put $z=i+\mathrm{i}j$ and $w=k+\mathrm{i}l$, where $i,j,k,l$ are the real coordinates above and $\mathrm{i}$ denotes the imaginary unit. Equivalently,

    z=(x_C-i y_C)/2,  w=(x_C+i y_C)/2,
    det B=|z|^2-|w|^2.

Both z,w acquire the same phase under a left rotation. Every invariant real quartic therefore has the complete nine-real-parameter representation

    F=alpha_0 |z|^4+beta_0 |z|^2|w|^2+gamma_0 |w|^4
      +Re(delta z^2 conjugate(w)^2
          +epsilon |z|^2 z conjugate(w)
          +eta |w|^2 z conjugate(w)).                       (4.6)

Completeness follows from bidegree (2,2) in (z,w) and their conjugates; the exact verifier also computes the full 35-monomial rotation kernel and obtains dimension nine.

When f>0, the Hessian already determined in (4.5) forces

    F=f q^2+g |w|^4+Re(eta |w|^2 z conjugate(w)).

On ker P={Re z=0}, the cubic DF(X)[I] equals

    |w|^2 Re(eta conjugate(w)).

The determinant is indefinite on this kernel, so (3.7) forces eta=0. On rank-one matrices q=0; rank-one convexity forces g>=0. Thus F=f q^2+g|w|^4 belongs to E.

When f=0, (4.6) has alpha_0=epsilon=0. The PSD rank-at-most-one condition on its (k,l) Hessian gives beta_0>=0 and |delta|=beta_0. A conjugation by real rotations fixing I changes the phase of w and lets us take delta=beta_0. Hence

    F=2beta_0 [Re(z conjugate(w))]^2+gamma_0|w|^4
      +|w|^2 Re(eta z conjugate(w)).                        (4.7)

F and DF vanish on w=0. For every (z,w), the segment from (z-w,0) in direction (w,w) is a rank-one line, because |w|^2-|w|^2=0. Convexity along that line gives F(z,w)>=0. Setting w=1,z=it forces Im eta=0; write eta=h real.

At the background z=iZ,w=iW, use the rank-one direction (delta z,delta w)=(sigma,1), sigma=+1 or -1. Direct differentiation gives

    D^2F[(sigma,1),(sigma,1)]
      =2[(4beta_0 sigma+h)ZW+(2gamma_0+h sigma)W^2].          (4.8)

For W!=0 and arbitrary Z, nonnegativity for both signs forces beta_0=h=0. Nonnegativity then gives gamma_0>=0. Thus F=gamma_0|w|^4, again in E. This completes the classification. QED.

## 5. The full-cone averaged-Hessian rank gap

Let J_det be the symmetric 4x4 matrix representing the determinant in row-major coordinates, with (J_det)_{14}=(J_det)_{41}=1/2 and (J_det)_{23}=(J_det)_{32}=-1/2. Let

    K={ C>=0 : tr(J_det C)=0 }.

Because D^2F(X) is quadratic in X, its average depends only on C=E XX^T. Denote this linear map by H_F(C). Every C in K is the second moment of a finite centered law, for example by its spectral decomposition with symmetric +/- atoms. Theorem A gives H_F(C)>=0.

### Theorem B: exact exceptional-class characterization

For every ROC F in the full left-SO(2) quartic cone, the following are equivalent:

1. There is C in K of rank at least three with H_F(C) singular.
2. There are three linearly independent rank-one matrices R1,R2,R3 such that sum_j D^2F(Rj) is singular.
3. F belongs to E in (4.1).

In particular,

    F not in E and rank C>=3  =>  H_F(C)>0.                  (5.1)

This characterizes an exact exception, not a sufficient inequality imposed on a chosen coefficient slice.

**Proof of 1 => 3.** Choose A!=0 in ker H_F(C). By Lemma 2.1,

    D^2F(A)[X,X]=P_A(X)+lambda_A det X, P_A>=0.

The moment identity and reciprocity give tr(P_A C)=0. For two PSD matrices this implies ran C is contained in ker P_A. Hence rank P_A<=4-rank C<=1. Lemma B proves F in E.

**Proof of 2 => 1.** Take C=sum_j vec(Rj)vec(Rj)^T. It is PSD of rank three and has zero determinant moment. By definition its image under H_F is the displayed Hessian sum.

**Proof of 3 => 2.** Write F=gamma q^2+|ell(A)|^4, where ell is a complex-linear functional of the two complex columns. Choose A!=0 in its real kernel. For rank-one R,

    D^2F(R)[A,A]=2gamma[(cof A):R]^2.

There are three linearly independent rank-one matrices in the hyperplane (cof A):R=0. If A is invertible, reduce to A=I; one possible triple is

    R1=[[0,1],[0,0]], R2=[[0,0],[1,0]],
    R3=[[1,1],[-1,-1]].

They are trace-free, rank one, and independent. If A has rank one, reduce it to e_11; use e_11,e_12,e_21. Invertible input/output coordinate changes preserve rank and the polar determinant condition, so these constructions cover every nonzero A. For gamma=0 any independent triple of rank-one matrices suffices. Each D^2F(Rj) is PSD by reciprocity, and vanishes in the A direction. Their sum is singular. QED.

### Sharp compatible example for the exceptional class

The trace-free triple above is not merely an arbitrary law. It is realized by

    phi(x,y)=(sin y+sin(x+y), sin x-sin(x+y)),
    Dphi=R1 cos y+R2 cos x+R3 cos(x+y).

For F=q^2+|w|^4 in the complex coordinates of Section 4, the resulting covariance has rank three and the averaged Hessian has rank three with I in its kernel. The verifier checks both ranks exactly. Thus the exception is necessary even for an actual three-direction resonant gradient.

## 6. From the classification to a genuine global Jensen theorem

### Lemma 6.1: gradients confined to a planar matrix subspace

Let G=Dphi be a mean-zero periodic planar gradient taking its values in a real linear subspace L of matrix space, dim L<=2. Then every continuous rank-one-convex quartic satisfies

    E F(A0+G)>=F(A0) for every A0.                           (6.1)

**Proof.** If det vanishes identically on L, every direction in L is rank one. The restriction of F to A0+L is convex, so ordinary Jensen applies.

If det|L is nonzero semidefinite, its mean zero forces G almost everywhere into its nullspace, of dimension at most one. This is either the zero field or a rank-one line, and Jensen again applies.

The remaining case is dim L=2 with det|L indefinite. Its rank-one cone is the union of two distinct lines spanned by R1=a1 tensor b1 and R2=a2 tensor b2. Their input directions b1,b2 must be independent: otherwise the whole plane L would have rank at most one.

For each Fourier frequency k, compatibility gives G_hat(k)=i phi_hat(k) tensor k. Its real and imaginary parts belong to L and are rank-one matrices with the same real input direction k. Hence that coefficient lies on one of the two rank-one lines, and k is parallel to the corresponding b_j. Any direction that occurs can be represented by a primitive integer frequency k_j. Thus

    G(x)=R1 g1(k1.x)+R2 g2(k2.x),

with mean-zero scalar periodic profiles. Since k1,k2 are independent integer vectors, the map from the spatial torus to its two phases sends Haar measure to product Haar measure. Integrate first over phase one and apply rank-one Jensen, then over phase two. This proves (6.1). Smooth approximation preserving L gives the W^{1,4} case. QED.

The general use of rank-one subspaces and low-wave laminate geometry has substantial prior art [3]. No novelty is claimed for that background. The new classification is what forces this geometric situation for arbitrary F in the full cone when its averaged Hessian degenerates.

### Theorem C: global positivity on every singular averaged-Hessian face

Let F be any left-SO(2)-invariant ROC homogeneous quartic, with all nine coefficients unrestricted. Let phi be periodic W^{1,4}, or belong to W^{1,4}_0(Omega;R^2) for a bounded Lipschitz domain. If

    H=E D^2F(Dphi) is singular,

then

    integral [F(A0+Dphi)-F(A0)] >=0 for every constant A0.    (6.2)

**Proof.** If F belongs to E, use its explicit polyconvex decomposition (4.1): ordinary Jensen controls the convex fourth power, and determinant preservation followed by scalar Jensen controls gamma q^2.

If F is not in E, Theorem B forces rank C<=2. Since C is the second moment, every vector in ker C has zero squared pairing with G almost everywhere. Thus G takes values in ran C, a subspace of dimension at most two. Lemma 6.1 supplies the positive Jensen construction.

For zero-boundary phi, extend it by zero into a larger periodic square. Homogeneity gives D^2F(0)=0, so the new averaged Hessian is a positive scalar multiple of the original one and remains singular. The relative energy is zero outside Omega. Apply the periodic conclusion and use density. QED.

This is an actual global variational inequality, not a test of an acoustic Gram matrix. It includes arbitrary numbers of Fourier modes in the allowed profiles and does not assume a fixed bandwidth. It does not classify all homogeneous gradient Young measures obtained as limits of nearly singular fields; that quantitative/limit issue remains explicit.

### Consequence for the unresolved counterexample mechanism

Any actual compatible counterexample inside the nine-coefficient cone must have

    rank C>=3 and H>0,

and F cannot belong to E. In that sector the affine background can be minimized exactly by (3.8). A cubic term cannot exploit an exactly flat averaged-Hessian direction: it vanishes there by Theorem A, and the complete compatible variational gap is nonnegative there by Theorem C.

This excludes exact flat-face escape, not all near-flat sequences. It supplies neither a universal lower bound for the positive-definite Schur remainder nor an a priori lower bound on the smallest eigenvalue of H for normalized candidates.

## 7. Why one monotone linear diffusion is not a universal operation

The following is a failure of a broad proof mechanism, not a quasiconvexity counterexample and not the principal advance of this note.

### Theorem D: a strictly coercive polyconvex example defeats every fixed constant-coefficient linear parabolic monotonicity rule

Set

    F_eta(A)=(det A)^2+eta |A|^4, eta=1/10000.

It is polyconvex and satisfies the uniform zero-boundary Jensen estimate

    integral [F_eta(A0+Dphi)-F_eta(A0)]
       >= (eta/3) integral |Dphi|^4.                        (7.1)

Nevertheless no one real constant-coefficient operator

    Lf=sum_{i,j=1}^2 C^{ij} partial_i partial_j f

with uniformly positive symmetric principal symbol can make integral F_eta(Df) nonincreasing for every smooth periodic f under partial_t f=Lf. The C^{ij} may be arbitrary real 2x2 output matrices, not just scalar diffusivities.

**Exact compatible heat increase.** Take the smooth periodic potential

    phi_1=cos x+cos y,
    phi_2=(cos 2x+cos 2y)/2
          +(4/3)[cos(x+y)+cos(x-y)].                        (7.2)

Under ordinary heat let a=e^{-t}, b=e^{-4t}, c=(4/3)e^{-2t}. Its gradient is

    [ -a sin x,                    -a sin y                 ]
    [ -2 sin x(b cos x+c cos y),    -2 sin y(b cos y+c cos x)].

Direct exact trigonometric averaging gives

    E q(Dphi_t)^2 = (1/2)a^2(c-b)^2,

    E |Dphi_t|^4 = (5/4)a^4+2a^2b^2+4a^2c^2
                  +(5/4)b^4+10b^2c^2+5c^4.

Their derivatives at zero are respectively 1/3 and -34621/81. Consequently

    d/dt E F_eta(Dphi_t)|_{t=0}
       = 235379/810000 >0.                                 (7.3)

All numbers in this display are checked using rational polynomial and trigonometric-moment arithmetic.

**Why changing a fixed linear metric does not cure universality.** The energy F_eta is invariant under both output and input O(2), including reflections. If a fixed operator L were energy-decreasing for every periodic field, each operator obtained by conjugating output and square-torus dihedral symmetries would also be energy-decreasing for every field. The derivative of the energy is linear in the operator's coefficients, so averaging these inequalities preserves the property.

Output dihedral averaging sends any real 2x2 matrix M to (tr M/2)I, including when M has a skew part. Input dihedral averaging then sends the coefficient tensor to kappa delta_{ij} I. Uniform strong parabolicity implies kappa>0. Thus kappa times the ordinary Laplacian would have to decrease the energy universally, contradicting (7.3).

Exact differential forms, arbitrary polynomial divergences, or tensor Gram representations cannot change this integrated derivative. The theorem concerns fixed linear parabolic monotonicity, not nonlinear flows, nonlocal temporal certificates, sums of separately controlled energies, or direct polyconvexity. Indeed (7.1) is already a direct proof for this example. QED.

The estimate (7.1) follows from determinant Jensen and the elementary identity

    |A+B|^4-|A|^4-4|A|^2 A:B
      = |B|^4/3+6(A:B+|B|^2/3)^2
        +2(|A|^2|B|^2-(A:B)^2) >= |B|^4/3.

## 8. The specific algebraic feature that makes the closure planar

Theorem A exploits one indefinite quadratic equation, not a generic expectation that all null-Lagrangian constraints control higher moments. This distinction can be seen on an actual compatible 3x2 field.

Let

    G(x,y)=[ cos x       0          ]
           [ 0           cos y      ]
           [ cos(x+y)    cos(x+y)   ].                      (8.1)

It is the gradient of (sin x,sin y,sin(x+y)). In the three-dimensional matrix subspace

    X(s,t,r)=[[s,0],[0,t],[r,r]],

the three minors are st,sr,-tr. Thus the rank-one set is the union of the three coordinate axes. The cubic C(s,t,r)=str has zero second derivative in each of those rank-one directions, yet

    E C(cos x,cos y,cos(x+y))=1/4.

All three quadratic minor means are zero. Thus the cubic-closure argument genuinely fails for this multiple-quadric geometry. This is the familiar three-direction structure behind the higher-dimensional obstruction discussed in [3], not a newly claimed counterexample to Morrey's problem. It explains why the single-quadric integrability step cannot simply be transported to arbitrary matrix dimensions.

## 9. Experiments, failed transfers, and the remaining mechanism

Two distinct exploratory routes were run before the analytic argument was isolated.

**Constructive dissipation.** The computation allowed unequal orientation terms, general cubic differential primitives, variable positive input metrics, and output-rotating diffusion. Some numerical certificates succeeded after allowing a real variable metric. The output-rotating terms were not demonstrated to add power in the retained comparisons: the same successful inputs also admitted purely real variable-metric numerical certificates. Other searches retained significant residuals. Neither residuals nor finite iterations prove infeasibility, and no full-cone heat inclusion was obtained.

A separate attempt combined a general polynomial SOS polyconvex support certificate with a corrected-heat component. This was motivated by the fact that a polynomial polyconvex function need not admit a convex polynomial lift at any degree, as emphasized in [4]. Some sampled inputs admitted the combined numerical construction; a universal decomposition was not established. Polynomial lift restrictions are not identified with polyconvexity.

**Compatible counterexample search.** Quartic polarization was used to eliminate the affine background, leaving a finite Fourier optimization over actual gradient coefficients. One retained full-cone numerical candidate was tested with cutoff three, a 13x13 dealiased grid, eight starts, and 800 Adam steps per start. The smallest directly reevaluated Jensen gap was approximately 0.0188792416110866. No negative gap was found. The numerical solve used a 10^-12 identity regularizer; the reported backgrounds were then evaluated directly. The candidate's general mathematical status and the search minima were not promoted to exact theorems. These observations are not lower bounds over the search class and not QC certificates.

The new exact results remove the singular-cubic coupling and classify the corresponding invariant quartic exceptions. They do not establish the positive-definite inequality

    c >= (1/2)b^T H^{-1}b

for every compatible gradient. That is the remaining nondegenerate obstruction, not a theorem inferred from the current computations.

The strongest retained extension is **quantitative closure near the nullspace**, combined with the genuinely resonant fourth-order information that distinguishes gradients from arbitrary determinant-balanced laws. The distinct counterexample route remains exact Fourier acquisition after minimizing the affine background, now with the theorem that an actual violation must have H>0 and rank C>=3. Neither route is claimed completed.

## 10. Supported conclusions about discovery

The productive representation change was to exchange background and perturbation in the quartic Hessian, then use the determinant's one-quadric geometry to propagate acoustic equality into a cubic identity. A rank-one positivity condition thereby supplied an almost-everywhere nullspace constraint, not merely an SDP representation.

In the invariant cone, rotation covariance then made low-rank Hessian remainders rigid. This produced the explicit exceptional class and an actual compatible Jensen proof on every singular averaged-Hessian face. The steps cover all nine coefficients; the underlying closure covers all 35 planar quartic coefficients.

The compatible heat-increase example shows why the previous successful certificate cannot be elevated to a universal monotone linear-flow principle. It does not show that positive completion, quasiconvexity, or a more general flow is impossible. The current theorems are structural progress, not a claim to have met the full exceptional-theorem objective.

## 11. Verification and provenance

Run:

    python verify_rigidity.py

The standalone script uses SymPy, with every definition written explicitly. It does not load exploratory matrices, optimizers, pickle files, or external sources. It checks twelve grouped identities, including all 35 monomial reciprocity/Taylor identities, the dimension-nine invariant kernel, all finite normal-form calculations, the exact resonant exceptional example, and the exact heat obstruction.

The analytic Finsler, cubic closure, measure support, and Fourier-Jensen arguments are proved in this note, not delegated to those finite checks. No independent external validation or historical priority is asserted. The prior sharp verifier replay is a retained continuity check, not a premise of Theorems A-C.

The selective repository searches did not supply a directly applicable additional theorem. No repository write was performed. No third-party manuscripts are redistributed.

### References and attribution boundary

[1] T. J. Meijer, K. J. A. Scheres, S. van den Eijnden, T. Holicki, C. W. Scherer and W. P. M. H. Heemels, *A General Non-Strict Finsler's Lemma*, arXiv:2403.10306v1 (2024), especially the established indefinite case stated as Lemma 2. The quadratic implication used here is prior mathematics; a short proof is supplied in Section 2.

[2] G. Bruno and F. Pasqualotto, *Quasiconvexity for the Dacorogna-Marcellini Energy*, arXiv:2608.06367v1 (2026). The heat/exact-form strategy and the left-and-right-SO(2) quartic theorem are prior work, not contributions of this note.

[3] A. Guerra and R. Teixeira da Costa, *Numerical evidence towards a positive answer to Morrey's problem*, arXiv:2006.09063. Relevant background on rank-one subspaces, the higher-dimensional three-direction construction, low-wave laminates, and numerical limitations. No novelty is claimed for those classical geometric ingredients.

[4] *Polyconvexity with Moments and Sums of Squares*, arXiv:2604.11124v1 (2026). The distinction between polynomial polyconvex functions and convex polynomial lifts is prior work; its SOS support framework was used only as exploratory context.

[5] Prior conversation artifact, *ASTRA Meta-Genesis: a sharp anisotropic quartic quasiconvexity theorem*, 14 October 2026. Internally exact-checked one-parameter theorem; the broader cone was explicitly unresolved. Its verifier was replayed in this investigation.

A targeted literature search did not establish priority for the nullspace-closure/rank-gap combination. This is not a complete historical audit, and absence of a matching retrieved theorem is not evidence of novelty.
