# ASTRA — Static-matched spectral substitution

**Status: research proposal with internally executed reference calculations. No laboratory experiment, superconductivity prediction, demonstrated technological advantage or established priority.** Prepared 14 October 2026.

## Result in one paragraph

The candidate operation is to invert a mechanically balanced isotope laminate, thereby changing its dynamic surface response while preserving isotope inventory, nominal geometry, contact chemistry and specified static mechanical response coefficients. A complementary eight-layer h10BN/h11BN pair matches linear-laminate stretching, extension–bending and bending coefficients even when the two isotopes have different elastic constants. A reference Maxwell calculation gives measurable near-field spectral contrast while a mass-only dielectric model has identical static reflection. The first intended scientific task is a controlled test of dynamical-environment sensitivity in the organic superconductor kappa-(BEDT-TTF)2Cu[N(CN)2]Br, abbreviated kappa-ET. Its response to this particular intervention remains unmeasured. Large optical contrast is NOT a prediction of large equilibrium electronic change.

The proposed contribution is this constrained experimental substitution, not isotope heterostructuring, cavity control, Thue–Morse optics, transfer matrices or fluctuation–dissipation theory, all of which have prior art. Specialist novelty review remains necessary.

## Research basis and selection

Several opportunities were screened: force-gated mechanochemistry, pressure-quenched superconductivity, nanoscale spin-noise control, barocaloric response and cavity materials. Each has experimental leverage, but no independent new consequential operation was established in the first four during this investigation. The selected obstruction is the difficulty of changing a retarded material interaction without simultaneously changing composition, contact, static screening or mechanical loading.

Keren et al. [1] report a reduced local Meissner response in hBN-covered kappa-ET (Tc 11.5 K), with coupling near the target C=C mode at 1470 cm^-1. The inferred effective superfluid suppression is large, but its depth profile is not determined. Their controls and optical measurements motivate, rather than validate, the proposed substitution. Chen et al. [2] demonstrated isotope-stack-dependent phonon-polariton dispersions. Falin et al. [3] measured different hBN elastic properties for different boron isotopes, which makes naive 'isotope means no mechanical change' reasoning unacceptable.

The Astra repository was consulted selectively at commit ace0cfc4437fe91c20ccd24d69e0ee4bb335e871 (technology/README.md). No previous result was reused as validation. No repository write was performed.

## 1. Physical construction

Let L denote h10BN and H denote h11BN. Read from the face nearest the target:

    A = C | L H H L H L L H | C
    B = C | H L L H L H H L | C

C is an identical h10BN end cap. The reference calculation uses eight 10 nm internal slabs and two 5 nm caps: 90 nm total. Each isotope occupies 40 nm internally. B is both the complement and the reversal of A.

These are proposed dimensions, not a fabricated specimen. Multi-slab isotope heterostructures and dry transfer are established [2]; a qualified ten-piece capped laminate and its matched interfaces are not established by that work.

A practical matched pair would use two regions cut from the same prefabricated parent laminate, mounting one face up and the other face down on randomly assigned nearby target regions. This reduces growth and thickness differences but does not guarantee identical buried interfaces. A live in-situ flipping device is NOT assumed. A homogeneous-isotope sham laminate must undergo the same orientation and transfer process.

## 2. Why mechanical matching survives different isotope moduli

For signed sequence s = (1,-1,-1,1,-1,1,1,-1),

    sum_j s_j j^n = 0, n=0,1,2.

The generating polynomial is

    sum_j s_j x^j = (1-x)(1-x^2)(1-x^4).

Its third-order zero at x=1 proves the moment identities. They also hold for the exact layer integrals over equally thick adjacent intervals. This is a known Prouhet/Thue–Morse construction, not a new mathematical sequence [8,9].

For a common-orientation, perfectly bonded linear plate with reduced in-plane stiffness Q(z), the laminate matrices are

    A_el = integral Q(z) dz,
    B_el = integral z Q(z) dz,
    D_el = integral z^2 Q(z) dz.

The difference Q_A(z)-Q_B(z) is a piecewise signed multiple of Q_L-Q_H. All three matrices are therefore equal for A and B, for arbitrary fixed isotope-dependent Q_L and Q_H. Thermal force and bending resultants also match when each isotope has a fixed local Q alpha product and temperature is uniform. The code verifies the underlying moment identities with unequal coefficients and includes an unbalanced equal-inventory counterexample.

This is a statement about a restricted static mechanical model. It does not match interfacial slip, adhesion, wrinkles, twist-domain response, local strain near an edge, spatially variable contamination, nonlinear bending or dynamic acoustic surface response. Nuclear-spin-dependent environmental effects are also not removed merely by matching isotope counts. They require separate bounds if a specifically electromagnetic interpretation is claimed.

Using arbitrary unequal coefficients in the identity tests is not a claim that monolayer elastic moduli can be inserted unchanged into a 90 nm bulk laminate. The equality is coefficient-independent within the model. Actual film stiffness and strain must be measured.

## 3. Static dielectric matching and dynamic contrast

A mass-only polar dielectric oscillator has

    epsilon(omega) = epsilon_infinity
      + (n Z*^2 / epsilon_0) / (K - M omega^2 - i M gamma omega).

At omega=0 its ionic contribution depends on K, not M. All isotope layers then have the same static permittivity; permuting their order changes no electrostatic reflection, even at finite lateral wavevector. At finite frequency their dielectric tensors differ.

The actual two species need not have identical static or high-frequency permittivity after quantum structural renormalisation. Therefore the code includes BOTH an exactly mass-scaled dielectric model and a reference using the published in-plane endpoints for h11BN. Static equality is an ideal-model theorem; actual equality is an experimental tolerance, not an assumption.

The retarded normal wavevector of a uniaxial layer is

    kz_j = sqrt(epsilon_t,j k0^2 - epsilon_t,j q^2/epsilon_z,j),

with nonnegative imaginary part. The p-polarized interface coefficient is

    r_ij = (epsilon_t,j kz_i - epsilon_t,i kz_j)
           / (epsilon_t,j kz_i + epsilon_t,i kz_j).

Layer coefficients are combined by the usual finite-thickness reflection recursion. The distinction arises from ordered, noncommuting layer propagation, not from inventing a new favourable material parameter.

In symmetric external media the unloaded structure and its geometric mirror share the overall mode spectrum. Their fields and coupling at a specified face need not be equal. When attached to an asymmetric target, the full loaded modes must be recomputed; unloaded isospectrality is not promised for the target system.

### Reference optical inputs

| Quantity | h10BN | h11BN in reference | Status |
|---|---:|---:|---|
| epsilon_infinity, in-plane | 5.1 | 5.1 | h10 model used in [4]; shared h11 value is an approximation |
| in-plane TO, cm^-1 | 1394.5 | 1359.8 | published endpoints [2,4] |
| in-plane LO, cm^-1 | 1650 | 1608.7 | published endpoints [2,4] |
| in-plane damping, cm^-1 | 1.8 | 1.8 | h10 literature reference; h11 equality not measured here |
| epsilon_infinity, normal | 2.5 | 2.5 | reference approximation |
| normal TO/LO, cm^-1 | 785 / 845 | both multiplied by 1359.8/1394.5 | h10 literature reference; h11 pure-mass approximation |
| normal damping, cm^-1 | 1.0 | 1.0 | reference approximation |

Loss sensitivity multiplies BOTH axes' damping by 1, 3 and 6. No low-temperature improvement in linewidth is assumed. In the ideal model, h11 LO is instead scaled by exactly the same factor as its TO, producing exact DC matching. This table is not a measured dielectric tensor of the proposed specimen. It must be replaced by a joint optical fit before manufacturing a performance claim.

## 4. Calculated optical intervention, with its scope

The validation geometry is a laminate in vacuum, not a fitted kappa-ET stack. The quantity

    I(z,nu) = integral q^2 exp(-2qz) Im r_p(q,nu) dq

is an evanescent quasistatic dipole-kernel proxy. It is not full radiative LDOS, a superfluid susceptibility or a prediction of the target's electron–phonon kernel. The integral uses q from 1.2e6 to 1e9 rad/m, above the light line across the tested band.

At 1470 cm^-1, 20 nm witness height and nominal damping:

    (I_A-I_B) / ((I_A+I_B)/2) = approximately -0.13295.

The difference remains about -0.13086 at six times the nominal damping. A Gaussian spectral witness with 10 cm^-1 standard deviation, integrated over 1430–1510 cm^-1, gives about -0.13397. This is not dependent on resolving one infinitesimal resonance.

At q=51 rad/micrometre, the nominal Im r values are approximately 2.0047 and 8.1703. These are local resonant response amplitudes, not energy-gain factors. They are not presented as a superconductivity enhancement.

The ideal static reflection discrepancy is below 3e-16 numerically. Using the slightly non-mass-scaled published h11 in-plane endpoints gives a maximum relative DC mismatch near 1.92e-5 over the tested q grid. Neither number is a real fabrication tolerance or an experimental guarantee.

The reference code verifies passivity on the sampled evanescent grid, homogeneous-layer subdivision invariance, elastic moment equality, and numerical convergence. The 10,000 versus 20,000 point q-grid witness difference is below 1e-12 for the nominal case. The sampled imaginary-frequency maximum is not a rigorous global maximum.

## 5. The important negative result: real-frequency contrast does not imply a large equilibrium effect

For the same ideal dielectric reference, the largest relative difference of r_p(i xi) over xi=0.01–1e5 cm^-1 and q=1e6–4e8 rad/m is about 4.13e-4 (0.0413%). The response difference near a real polariton resonance is therefore a poor surrogate for the size of the equilibrium perturbation. No target response is calculated from the 13% witness contrast.

A useful independent harmonic bound makes this explicit. For a common positive stiffness matrix K and two positive mass matrices satisfying

    r^-1 M_A <= M_B <= r M_A,

the zero-temperature displacement covariance obeys

    C(M) = hbar/pi integral_0^infinity (K + xi^2 M)^-1 dxi,
    r^-1/2 C(M_A) <= C(M_B) <= r^1/2 C(M_A).

Proof: bound the resolvent by matrix monotonicity, integrate, and substitute sqrt(r) xi for uniformly scaled M. No weak-coupling or well-separated-mode assumption enters this finite-dimensional harmonic result. The code checks the integral against normal modes and tests the bound for 60 positive stiffness matrices, including stiff/soft spectra.

For moving boron masses 10 and 11 while leaving every other mass unchanged, r=1.1 is a conservative nominal-mass bound. The factors are about 0.95346 and 1.04881. This bounds displacement covariance only when K and the coordinate/coupling definition are unchanged. It is NOT a bound on Tc, critical susceptibility, all electromagnetic observables or anharmonic electronic order. Actual isotope-dependent equilibrium geometry violates the common-K hypothesis.

In a classical configurational equilibrium distribution with a fixed potential and position-independent masses, mass permutation changes no configurational expectation: momentum integrals only supply normalisation factors. Hence a claim of a large classical equilibrium material change driven solely by mass reassignment would be inconsistent.

The mass bound is a guard against hidden gain. It does not make the material sensitivity needed for an important measurement available for free.

## 6. Common physical accounting

A complete description must include the target electronic/vibrational Hamiltonian, isotope-layer kinetic energies and force constants, Coulomb and photon coupling, elastic contact, dissipative reservoirs, sample temperature and the measurement probe. In an electromagnetic reduction, the same measured complex dielectric tensor defines the Green tensor, optical loss and equilibrium noise through fluctuation–dissipation [7]. One cannot choose a large field enhancement and an unrelated negligible linewidth/noise.

For example, the symmetrized electric-field covariance is proportional to

    (hbar mu_0/pi) integral_0^infinity omega^2
      coth[hbar omega/(2 k_B T)] Im G(omega) domega.

For differences between causal, statically matched environments, Kramers–Kronig similarly constrains spectral redistribution: assuming Delta r(infinity)=0,

    Delta r(0) = (2/pi) integral Im Delta r(omega) / omega domega.

A positive change in one spectral interval is not an unconstrained addition of fluctuations everywhere.

The target many-body response is NOT supplied or simulated. The decisive unknown is its response to the measured change of environment, after independently bounded contact, strain, charge, temperature and probe effects. Contact-transmitted acoustic changes remain an alternative retarded mechanism. A positive result alone would not uniquely establish an electromagnetic mechanism or identify pairing glue.

The assembly is passive while interrogating equilibrium. This does not imply zero total energy: enrichment/material production, fabrication, cryogenic refrigeration, optical qualification and probe operation all cost energy. Full laboratory wall-plug cost has not been measured. This is a measurement proposal, not an energy source or a demonstrated low-energy technology.

## 7. Decisive experiment

### Qualification before the target measurement

Prepare A/B parent-derived matched regions and homogeneous-isotope sham pairs. Measure actual layer thicknesses and alignment. Fit both optical responses with one consistent dielectric model, including uncertainties; use withheld frequencies/momenta to test the fit. Require a robust, prespecified spectral intervention, for example at least 10% difference over the mean in a preregistered witness integral with less than 2 percentage points uncertainty. This is a chosen engineering gate, not a published result.

Measure static capacitance/contact potential, laminate force–curvature response, target-relevant nonresonant strain markers, surface/edge contamination and temperature stability. Matching A_el/B_el/D_el is not a substitute for these measurements. Optical characterisation is performed before dark equilibrium measurement or at decreasing powers with recovery tests; the s-SNOM tip and illumination are not assumed nonperturbative.

### First scientific output

On kappa-ET, compare raw magnetic force gradients Y=dFz/dz at registered heights and several temperatures, including above Tc. Do not turn a local force contrast immediately into a bulk superfluid-density percentage: depth inversion is model dependent.

Use a difference-in-differences observable

    D = [Y_A(Ts)-Y_B(Ts)] - [Y_A(Tn)-Y_B(Tn)],

where Ts is superconducting and Tn is normal. Normal-state subtraction is not assumed to cancel every temperature-dependent electrostatic or magnetic background. Multiple heights and temperatures, contact-potential compensation, sham inversions and blinded assignment are needed.

A provisional minimum useful target is |D|=2 pN/micrometre. This is a detection target, NOT a predicted material effect. With k=2.8 N/m and representative f0=77 kHz from the existing apparatus [1], it corresponds to a frequency contrast of 0.0275 Hz. A five-standard-error test requires a standard error no larger than 0.0055 Hz, apart from bounded systematic error.

Require a combined independently calibrated systematic budget below 0.4 pN/micrometre. A bound should be formed from measured derivatives, not assumed tolerances:

    B_sys >= |dY/dz| delta_z + |dY/dT| delta_T
           + |dY/dV| delta_V + sum_ab |dY/dstrain_ab| delta_strain_ab
           + probe and transfer/background terms.

Strain sensitivities and thermal responses must be calibrated on comparable regions. The resonant target mode itself cannot serve as an unqualified strain thermometer, because changing its dynamics is part of the intended intervention. If independent bounds cannot be acquired, no clean attribution is established.

### Sample cost

Let sigma_pair be the standard deviation of a complete independent paired D estimate, including material variability. For a planning Gaussian model,

    N_pairs >= (5 sigma_pair / D_target)^2.

At D_target=2 pN/micrometre, sigma_pair values 0.5, 2 and 10 give about 2, 25 and 625 pairs. At an ASSUMED eight minutes per complete pair, acquisition times are 0.27, 3.33 and 83.33 hours. These are conditional arithmetic, not measured throughput. Two pairs would not support robust variance or nuisance inference; the low-noise row is not a recommendation to use only two. Fabrication, optical qualification, cooling, independent repeats and failed devices are extra. Image pixels and repeat scans of one defective interface are not independent material pairs.

### Rejection and interpretation

Reject the device pair before superconductivity testing if spectral contrast collapses under measured damping/thicknesses, or if static/elastic/interface matching cannot meet the error budget. A matched optical signal alone is not success on the scientific task. If the target contrast is below the acquisition budget, report a directional upper bound at the achieved uncertainty, not a universal refutation of cavity effects.

A positive result exceeding controls establishes sensitivity to the particular external dynamical substitution within bounded alternatives. It does not prove attractive pairing, specify the whole interaction kernel, uniquely establish electromagnetic rather than acoustic coupling, or demonstrate improved Tc. A useful next-level study would compare several independently qualified balanced thickness patterns to distinguish specific competing target models whose predicted signals exceed the error budget.

## 8. Best-method comparison and limits of the novelty claim

Existing hBN-versus-other-cover comparisons [1] are simpler and have already revealed a large contrast. They change cover chemistry and mechanical response. The proposed pair instead seeks a more restricted spectral intervention, at substantially greater fabrication cost.

Target isotope substitution directly probes mass sensitivity but changes the material under investigation. Here the target isotope inventory is unchanged. This is not automatically a better probe of pairing.

The hovering-cavity quantum Hall experiment [5] already offers same-sample, in-situ tuning of electromagnetic coupling. Its reversibility is superior to separately transferred isotope patches. This proposal's distinct goal is frequency/momentum reweighting at nearly matched static loading, not the first example of external control of quantum matter.

Isotope-stack spectral engineering [2], Thue–Morse multilayer optics [8,9] and fluctuation–dissipation [7] are prior art. The proposed simultaneous mechanical/static matching and surface-spectrum substitution requires priority review. A different control construction is not yet a demonstrated scientific advantage.

## 9. What has and has not been established

**Established internally:** moment matching in the stated laminate model; electrostatic matching in the ideal dielectric model; surviving optical contrast in a sourced-but-approximate reference; its sensitivity to damping; a harmonic covariance limit; a quantitative experiment and acquisition gate.

**Experimentally established elsewhere:** constituent isotope heterostructuring and polariton measurements; isotope mechanical differences; an hBN/organic-superconductor response motivating the task; competing cavity-control methods.

**Not established:** fabrication of this balanced pair, actual matching of its interfaces, the target's response, lower total cost than the best alternative for a consequential output, exceptional technological benefit or historical novelty.

The precise next missing scientific measurement is the dark-equilibrium target response to a spectrally qualified, nuisance-bounded pair. The optical proof does not manufacture that response.

## Reproduction

Run:

    python validate_operation.py

The code writes results.json, reference_spectrum.csv and validation_log.txt. It requires NumPy and SciPy. environment.json records the actual executed environment, not a claimed minimum supported version. The result log reports 73 assertions. Checks are internal numerical consistency tests, not external validation.

## Primary references

[1] Keren et al., Cavity-altered superconductivity, Nature 650, 864–868 (2026). DOI: 10.1038/s41586-025-10062-6. https://www.nature.com/articles/s41586-025-10062-6

[2] Chen et al., Van der Waals isotope heterostructures for engineering phonon polariton dispersions, Nature Communications 14, 4782 (2023). DOI: 10.1038/s41467-023-40449-w. https://www.nature.com/articles/s41467-023-40449-w

[3] Falin et al., Anomalous isotope effect on mechanical properties of single atomic layer Boron Nitride, Nature Communications 14, 5331 (2023). DOI: 10.1038/s41467-023-41148-2. https://www.nature.com/articles/s41467-023-41148-2

[4] Zhang et al., Observation of Edge-Confined Acoustic Hyperbolic Polaritons in van der Waals Materials, Advanced Science 13, e20556 (2026). DOI: 10.1002/advs.202520556. The h10 optical parameters were retrieved from the indexed primary article's numerical methods, not fitted to our specimen. https://advanced.onlinelibrary.wiley.com/doi/10.1002/advs.202520556

[5] Enkner et al., Tunable vacuum-field control of fractional and integer quantum Hall phases, Nature 641, 884–889 (2025). DOI: 10.1038/s41586-025-08894-3. https://www.nature.com/articles/s41586-025-08894-3

[6] Pavlidis et al., Experimental confirmation of long hyperbolic polariton lifetimes in monoisotopic (10B) hexagonal boron nitride at room temperature, APL Materials 9, 091109 (2021). DOI: 10.1063/5.0061941. https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=932855

[7] Callen and Welton, Irreversibility and Generalized Noise, Physical Review 83, 34 (1951). DOI: 10.1103/PhysRev.83.34. https://journals.aps.org/pr/abstract/10.1103/PhysRev.83.34

[8] Liu, Propagation of light waves in Thue–Morse dielectric multilayers, Physical Review B 55, 3543 (1997). DOI: 10.1103/PhysRevB.55.3543. https://doi.org/10.1103/PhysRevB.55.3543

[9] Moretti et al., Photonic band gaps analysis of Thue–Morse multilayers made of porous silicon, Optics Express 14, 6264–6272 (2006). DOI: 10.1364/OE.14.006264. https://pubmed.ncbi.nlm.nih.gov/19516799/

[10] Xu et al., Quantum materials QED with van der Waals crystals, arXiv:2610.02514 (1 October 2026), preprint. Cited as additional scope/prior-art context, not used as validated design data. https://arxiv.org/abs/2610.02514
