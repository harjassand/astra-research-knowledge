# CRAY: Frozen-reservoir lifting and constructive nonlocal transport certificates

Research record, 13 October 2026. This is a derivation and reproducible computational certificate, not a peer-reviewed result or an independently established publication-priority claim.

## 1. Result and boundary of the result

This investigation constructs a legal, globally admissible, genuinely nonlocal current for the **original hard two-dimensional Kob–Andersen model with two-vacancy facilitation**. It provides positive, completely numerical lower bounds on its infinite-volume **bulk variational diffusion coefficient**. All model-dependent finite identities are checked exactly. The nonlocal completion is explicit and has an analytically proved, computable energy tail.

The construction has three parts:

1. A finite legal configuration-space current whose divergence is a prescribed difference of two port occupations, rather than zero.
2. A nonlocal spatial current obtained by making an affine stream potential constant on connected components of closed dual edges.
3. A frozen-reservoir lifting operation that makes the first current inherit the conservation of the second, despite changes to local gate status during legal microscopic transitions.

For the finite module constructed here, the resulting bound is positive for every particle density **0 < p <= 2/5**. The displayed lower endpoints are rounded down:

| Particle density p | Certified lower bound | Elementary upper bound |
|---:|---:|---:|
| 0.10 | 0.208740656430 | 0.998001 |
| 0.20 | 0.077629966716 | 0.984064 |
| 0.25 | 0.030189748264 | 0.968994140625 |
| 0.30 | 0.008932514941 | 0.946729 |
| 0.35 | 0.001628331275 | 0.916088265625 |
| 0.40 | 0.000010861655 | 0.876096 |

These are broad certificates, not accurate predictions. The upper column uses the zero corrector, not the strongest specialized upper-bound calculation. This investigation does **not** establish a useful result in the dense glassy regime, a speedup over the strongest simulation or variational implementation, or the first positive lower bound for KA. Existing work already proves positivity and uses cooperative droplets, coarse percolation and legal multistep comparisons [1,2].

The preserved methodological result is the explicit finite-to-nonlocal certificate transformation, its error theorem, the verified hard-KA input module, and the executed output. Whether this particular transformation is literature-new remains to be independently assessed.

## 2. Mechanisms investigated

### Direct projection of a conservation defect

One can formally project a legal current onto the orthogonal complement of microscopic correctors. That description is not an algorithm with a certified error: an arbitrarily small residual may live in an arbitrarily small spectral mode. In the elementary model A=diag(delta,1), the vector e_1 has residual delta e_1 but unit correction cost. A residual-norm argument therefore cannot silently substitute for a proved inverse or inf-sup estimate. No such estimate is assumed here.

### A hierarchy of weakly conserved currents

Weak compactness could yield a conserved limiting current if every fixed local defect tends to zero and energies remain bounded. This observation alone neither constructs the needed bounded-energy sequence nor provides a finite error certificate. It was not used as a substitute for nonlocal construction.

### Prescribed unbounded paths

Unbounded comparison paths and their information-loss/congestion analysis are already substantive prior art [1–3]. Forward path length alone does not bound the number of initial configurations whose routes traverse a given transition. The implementation below instead constructs the complete finite signed source–sink flow and evaluates its exact weighted energy. Its nonlocal part is a separate spatial operation with a proved tail.

## 3. Target and normalization

Let eta be in {0,1}^{Z^2}, with 1 denoting a particle. The equilibrium is product Bernoulli measure mu_p; q=1-p and chi=pq. For a nearest-neighbor bond {x,y}, the hard rate is

\[
c_{xy}(\eta)=
\mathbf 1\{\exists z\sim x,\ z\ne y:\eta_z=0\}
\mathbf 1\{\exists z\sim y,\ z\ne x:\eta_z=0\}.
\]

An exchange of equal occupations does nothing. This rate is invariant under exchanging the two endpoint occupations. It is exactly the hard rule: no softening parameter or artificial transitions are introduced.

In the horizontal direction, put a_i=(eta_0-eta_{e_i}) delta_{i1}, and

\[
G_i f=\sum_{z\in\mathbb Z^2}\nabla_{0,e_i}\tau_z f.
\]

For local f this sum is finite. The mathematical target is

\[
D(p)=\frac1{2\chi}\inf_{f\ \mathrm{local}}
\mathbb E_p\sum_{i=1}^2 c_i(a_i+G_i f)^2. \tag{1}
\]

Rate-one simple exclusion has D=1 in this convention. This is the collective/bulk coefficient, not tagged-particle self-diffusion. Identifying (1) with a hard-constraint hydrodynamic limit under specified initial conditions is a separate theorem; no such additional hydrodynamic assertion is made here. The existing variational and Thomson principles are background, not the invention [1,3,4].

If J is antisymmetric under its own bond exchange, legal (zero wherever the hard rate is zero), square integrable, translation covariant, and satisfies

\[
\mathbb E\sum_i J_i G_i f=0\quad\text{for every local } f, \tag{2}
\]

completion of the square and optimal scalar rescaling give

\[
D(p)\ge \frac{\langle a,J\rangle^2}{2\chi\|J\|^2},
\quad \|J\|^2=\mathbb E\sum_i J_i^2. \tag{3}
\]

The hard rates equal one on the support of J, so this is the c^{-1} energy norm. None of the construction below assumes a spectral gap or a supplied completion-error estimate.

## 4. The finite source–sink module

### Ports and independent reservoirs

Tile the lattice by L by L square blocks, with one fixed port per block. The remaining sites of a block are its reservoir. A gate g(omega) in {0,1} depends only on reservoir occupations, never the port. Different blocks' gates are therefore independent under mu_p.

For adjacent blocks u and v, let Q be their union. A module is a collection H_b(zeta) of currents on bonds contained in Q, satisfying:

- antisymmetry under its bond exchange;
- legality even when all sites outside Q are occupied;
- the exact configuration-space source identity

\[
\sum_{b\subset Q}H_b(\zeta)
=(\zeta_{s_u}-\zeta_{s_v})g(\omega_u)g(\omega_v).
\tag{4}
\]

The sum in (4) is the divergence of a signed current on the finite configuration graph: H_b(zeta) is its outgoing value from configuration zeta. It is not a spatial divergence. Crucially, it is **not required to vanish**.

Legality with occupied exterior is sufficient for legality in any exterior configuration in KA: adding exterior vacancies cannot disable a permitted move. Equation (4) also allows H to pass through states whose gates are bad; its divergence, rather than its support, is restricted to good endpoint reservoirs.

### The executed 3 by 3 gate

Take L=3 and the center as port. A reservoir is good exactly when each of the following five sets contains at least one vacancy:

- each of the four outer sides of the 3 by 3 block;
- the four nearest neighbors of its center.

These five sets do not contain the port. Index the eight reservoir sites row by row, omitting the center. The corresponding forbidden fully occupied bit masks are 7, 41, 90, 148 and 224. Thus the gate can be evaluated by five bit operations; no learned classifier or fitted equilibrium law is involved.

Exactly 154 of the 256 reservoir patterns are good. Their counts by particle number are

\[
(1,8,28,52,49,16,0,0,0).
\]

Consequently their exact probability is

\[
\gamma(p)=q^8+8pq^7+28p^2q^6+52p^3q^5+49p^4q^4+16p^5q^3,
\quad b(p)=1-\gamma(p). \tag{5}
\]

The gate is invariant under square rotations/reflections and decreases when vacancies are filled. Its validity is not inferred from these properties: the actual source identity (4) is verified on every finite configuration.

### Constructing and checking H

The horizontal module is a 6 by 3 rectangle with 18 sites, ports at zero-based coordinates (1,1) and (4,1). Its graph contains 262,144 configurations and 998,400 unoriented legal configuration edges. There are 47,432 nonzero source entries: two port orientations for each of 154 squared reservoir pairs.

For a microscopic bond within one block, define its assembly-overlap weight w_b=4. For a bond crossing the middle interface between the blocks, put w_b=1. These are exactly the numbers of pair modules that can cover the bond in a fixed tiling.

A sparse electrical-flow solve proposes a module minimizing sum w_b H_b^2 subject to its sources. The configuration graph conserves particle number. Product-equilibrium weights are constant within each fixed-particle-number sector, so the same proposed flow can be evaluated at every density.

Floating-point optimization is only a proposal. Each edge current is rounded to denominator 2^40. Its integer divergence residual is then routed through a deterministic spanning forest, making (4) exact. All component-root residuals must be zero; otherwise construction fails.

The independent checker `verify_module.py` does not use the graph-component labels or the numerical optimizer. It checks every stored transition against the original hard KA rule with occupied exterior, rejects duplicate edges, checks all 262,144 source equations using exact integer arithmetic, recomputes both energy polynomials with Python integers, and verifies the transport normalization polynomial. A proved int64 bound is checked before vectorized incidence accumulation; energy sums use arbitrary precision.

The vertical module is the coordinate transpose of the horizontal module. Square symmetry of the gate makes its source identity and energy identical.

Define the exact module cost

\[
C(p)=\frac{1}{2\chi\gamma(p)^2}
\mathbb E_{p,Q}\sum_{b\subset Q} w_b H_b^2.
\tag{6}
\]

If F_e is the stored integer current on an unoriented configuration edge e, n(e) its particle count, d_0=2^40 and

\[
E_n=\sum_{e:n(e)=n} w_e F_e^2,
\]

then

\[
C(p)=\frac{\sum_{n=0}^{18}E_n p^nq^{18-n}}
{d_0^2\chi\gamma(p)^2}. \tag{7}
\]

The factor two from the two configuration-edge orientations cancels that in (6). All 19 integers E_n are supplied and independently recomputed. At p=0.30, C is approximately 4.319126590793206. This decimal is descriptive; the lower-bound evaluation uses (7) as an exact rational number.

## 5. A constructive spatial completion on the coarse lattice

Declare a coarse edge open when both endpoint blocks are good. Its being closed is therefore determined by an independent Bernoulli-b field of bad sites.

Draw the dual edges crossing closed primal edges. Each bad site contributes a square of four closed dual edges. These squares belong to the same connected component exactly when the associated bad sites can be joined using eight-neighbor, or star, adjacency.

For a dual vertex z, let C_z be its closed-dual component, allowing isolated vertices, and let

\[
R_z=\max_{w\in C_z}\|w-z\|_\infty.
\]

When C_z is finite, define

\[
\Psi(z)=\frac1{|C_z|}\sum_{w\in C_z} w_2,
\qquad \beta(z)=\Psi(z)-z_2. \tag{8}
\]

Then take the rotated discrete gradient of Psi. In integer labels for dual plaquettes,

\[
k_h(x,y)=\Psi(x,y)-\Psi(x,y-1),
\quad
k_v(x,y)=\Psi(x-1,y)-\Psi(x,y). \tag{9}
\]

It has zero spatial divergence identically. It is zero on a closed edge because its two dual endpoints belong to the same component and hence have the same Psi.

The correction beta is stationary. If it is integrable, stationarity gives E k_h=1 and E k_v=0, since the affine part contributes exactly the unit horizontal current.

### Explicit tail from a finite path automaton

This step does not invoke an unspecified subcritical percolation theorem.

If R_z >= r, a bad star-connected path from one of the four sites adjacent to z reaches a dual vertex at distance r. Such a path has at least r distinct bad sites. Choose a shortest path to that far site. No two nonconsecutive vertices can be star neighbors, since that would provide a shortcut.

A necessary local restriction is that a path cannot make a two-step shortcut. When the previous step is cardinal, the next step has one cardinal and two diagonal choices. When the previous step is diagonal, there are two cardinal and three diagonal choices. Thus a two-state counting matrix is

\[
M=\begin{pmatrix}1&2\\2&3\end{pmatrix}. \tag{10}
\]

The checker independently enumerates the eight possible step directions to verify these four counts. The matrix overcounts globally chordless self-avoiding paths; this is valid because each actual path has r distinct sites and hence probability b^r. We do not assign b^r to repeated-site walks and then treat their probabilities as independent.

With u=(1,1)^T and A=bM,

\[
\mathbb P(R_z\ge1)\le4b,
\qquad
\mathbb P(R_z\ge r)\le16b^2 u^T A^{r-2}u\quad(r\ge2).
\tag{11}
\]

The largest eigenvalue of M is 2+sqrt(5). Therefore the condition for this explicit summable tail is

\[
\Delta(b):=1-4b-b^2>0,
\quad\text{equivalently }b<\sqrt5-2. \tag{12}
\]

All components C_z are finite almost surely under this condition, by (11) and a countable union over z. No unknown cluster-size constant remains.

Summing (2r-1) times (11) gives

\[
\mathbb E R_z^2\le
m_2(b):=4b+\frac{32b^2(3-4b+b^2)}{(1-4b-b^2)^2}. \tag{13}
\]

For completeness, S=(I-A)^{-1} exists with nonnegative entries,

\[
u^TSu=\frac2\Delta,
\quad
\sum_{r\ge2}(2r-1)u^TA^{r-2}u
=u^T(3S+2AS^2)u,
\]

which gives (13) by direct rational simplification.

Since |beta(z)| <= R_z, stationarity and (9) imply

\[
K:=\mathbb E(k_h^2+k_v^2)
=1+\mathbb E|\nabla\beta|^2
\le 1+8m_2(b)=:\mathcal K(b). \tag{14}
\]

The initial investigation used the weaker seven-choice self-avoiding-path count. Equation (10) replaces it; all headline bounds in this record use the stronger two-state certificate.

## 6. Frozen-reservoir lifting theorem

The central issue in combining the objects is that microscopic transitions inside a module may change whether its reservoirs are good. Multiplying its flow by k_e evaluated on the unmodified gate field would not in general preserve the source identity.

For a coarse edge e=(u,v), define Gamma^{e+} to be the gate field with **both u and v forced good**, keeping every other block gate unchanged. Put

\[
F_e(\omega_{Q_e^c})=k_e(\Gamma^{e+}). \tag{15}
\]

This coefficient is independent of all occupations inside Q_e, including both reservoirs and both ports. In a fixed tiling define the lifted microscopic current

\[
J_b^{\mathrm{tile}}(\eta)
=\sum_{e: b\subset Q_e}F_e(\omega_{Q_e^c})H_b^e(\eta_{Q_e}). \tag{16}
\]

At most four modules contribute to a bond. Finally average over the L squared translated tilings. The resulting J is covariant under every unit lattice translation, not only block translations.

### Theorem

Suppose a finite module obeys (4), with legality in arbitrary exteriors, product-equilibrium port/reservoir independence, square-symmetric orientations, and finite C(p) in (6). If (12) holds, (15)–(16) construct a legal, antisymmetric, square-integrable globally admissible current. It satisfies

\[
\langle a,J\rangle=\frac{2\chi}{L},
\quad
\|J\|^2\le\frac{2\chi C(p)}{L^2}\mathcal K(b).
\tag{17}
\]

Consequently

\[
\boxed{D(p)\ge\frac1{C(p)\mathcal K(b(p))}.} \tag{18}
\]

### Proof of exact global admissibility

Legality follows term by term. Antisymmetry holds because an exchange inside Q_e changes H antisymmetrically but does not change its coefficient F_e.

On nonzero module demands both endpoint gates are good, so

\[
F_e g_u g_v=k_e(\Gamma). \tag{19}
\]

We prove conservation in expectations against every local test function, not by asserting that an infinite pointwise sum telescopes.

For a local test f, antisymmetry and translation covariance transform its pairing with Gf into minus twice the sum over microscopic bonds of E[J_b f]. Only bonds touching the support of f have nonzero expectations; all other terms vanish by exchange symmetry.

Substitute (16), group the finitely many relevant module terms, and use (4) and (19). The result, apart from the harmless common factor, is

\[
\sum_{e=(u,v)}\mathbb E[k_e(\Gamma)(\sigma_u-\sigma_v)f]. \tag{20}
\]

Condition on all reservoirs. The port occupations sigma are independent Bernoulli-p variables, whereas k is now fixed. Set

\[
m_u(\omega)=\mathbb E_{\mathrm{ports}}[(\sigma_u-p)f].
\]

The sequence m_u has finite support: it is zero at every port on which f does not depend. Conditional expectation turns (20) into

\[
\sum_{e=(u,v)}k_e(m_u-m_v)
=\sum_u m_u\operatorname{div}_{\mathrm{space}}k(u)=0.
\]

Every effective sum is finite, and integrability follows from the energy bound below. This proves (2). In particular, conservation is not checked merely against the finite functions used to discover H.

### Response and energy accounting

Finite-graph integration by parts with the particle first moment gives, for a horizontal module,

\[
\mathbb E_Q\sum_{b=(x,y)\subset Q}(y_1-x_1)(\eta_x-\eta_y)H_b
=2\chi L\gamma^2. \tag{21}
\]

Its vertical response is zero. Both identities are also verified coefficient by coefficient as polynomials in p in the supplied checker.

Because the reservoirs of u and v are independent of the other reservoirs,

\[
\mathbb E F_e=\frac{\mathbb E k_e}{\gamma^2},
\qquad
\mathbb E F_e^2=\frac{\mathbb E k_e^2}{\gamma^2}. \tag{22}
\]

One module per direction occupies a coarse-cell density 1/L squared. Equations (21)–(22), and the unit mean horizontal coarse flux, give the response in (17).

For a physical bond, Cauchy–Schwarz bounds the square of its sum in (16) by its covering multiplicity times the sum of individual squares. That covering multiplicity is precisely w_b used in (6). Sum over a fundamental cell and divide by its L squared sites. Product independence then gives

\[
\|J\|^2\le\frac1{L^2\gamma^2}
\mathbb E_Q\sum_b w_bH_b^2\,
\mathbb E(k_h^2+k_v^2)
=\frac{2\chi C(p)}{L^2}K.
\]

Averaging the tiling phases can only decrease energy and preserves response. Apply (14), then (3), to obtain (18). This accounts explicitly for overlap congestion rather than assuming different modules' currents do not interfere.

## 7. Finite computation with a proved nonlocal error

The exact current is not finite range, as required by the previous box-closure no-go theorem. Nevertheless it has finite-radius legal approximations with a computable tail.

Define beta_R(z)=beta(z) when C_z lies entirely within radius R of z, and zero otherwise. This decision can be made by exploring the component up to the boundary of the radius-R window, with a finite guard layer. An unresolved component need not be explored further.

Let k_R be the rotated gradient of z_2+beta_R, multiplied by the open-edge indicator. Multiplication is essential: truncation decisions at the two dual endpoints can differ. The truncated current remains legal but in general is **not** conserved.

Put

\[
T_R(b)\ge\mathbb E[R_z^2\mathbf1\{R_z>R\}].
\]

An explicit rational choice is T_0=m_2(b) and, for R>=1,

\[
T_R=16b^2u^TA^{R-1}
\left[(R+1)^2I+(2R+3)AS+2A^2S^2\right]u,
\quad S=(I-A)^{-1}. \tag{23}
\]

This follows by summing the tail identity

\[
\mathbb E[R_z^2\mathbf1_{R_z>R}]
=(R+1)^2\mathbb P(R_z\ge R+1)
+\sum_{r\ge R+2}(2r-1)\mathbb P(R_z\ge r)
\]

against (11). Only a two by two rational matrix inverse and power are required.

Stationarity and open-edge clipping give

\[
\mathbb E|k-k_R|^2\le8T_R. \tag{24}
\]

Lift k_R using the same forced-good operation to obtain J_R. The exact same finite module-overlap calculation now proves

\[
\boxed{\|J-J_R\|^2\le\frac{16\chi C(p)}{L^2}T_R(b).} \tag{25}
\]

Thus the completion error is an output of the construction, not an input oracle.

For the normalized current F=LJ, which has response 2chi, the checker finds the following sufficient cutoffs for ||F-F_R|| <= 10^-6:

| p | Sufficient coarse radius R |
|---:|---:|
| 0.10 | 8 |
| 0.20 | 18 |
| 0.25 | 27 |
| 0.30 | 46 |
| 1/3 | 74 |
| 0.35 | 101 |
| 0.40 | 1280 |

The deterioration near the explicit counting threshold is real. These are rigorous ensemble L2 error statements, not pointwise worst-case error bounds on arbitrary configurations.

If a finite calculation evaluates ||J_R||, a sharper valid certificate follows from the known full-current response:

\[
D(p)\ge\frac{(2\chi/L)^2}
{2\chi\left(\|J_R\|+4\sqrt{\chi C(p)T_R}/L\right)^2}. \tag{26}
\]

A cheaper alternative evaluates only E|k_R| squared and bounds K by
(sqrt(E|k_R| squared)+sqrt(8T_R)) squared. Either can tighten the energy of this particular witness. Neither proves that the resulting lower hierarchy converges to the true diffusion coefficient. The ordinary local primal hierarchy remains available for upper bounds.

### A broader completion operation

For a fixed gate field, component averaging

\[
(\mathcal A_\Gamma\psi)(z)=|C_z|^{-1}\sum_{w\in C_z}\psi(w)
\]

is a linear idempotent operation on vertex potentials. It makes the potential constant across closed dual edges. It can act on z_2+phi_z, where phi is any bounded local stationary field, not only zero. The affine mean flux survives because the correction remains stationary and integrable.

For |phi|<=B, truncating this operation on unresolved components has squared scalar error at most

\[
2T_R+8B^2\mathbb P(R_z>R),
\]

and hence coarse-current error at most eight times this expression. Equation (11) supplies the remaining probability. This allows finite local stream modifications to be completed into globally legal conserved currents before they are evaluated or optimized. It is not a universal completion theorem for arbitrary defects, and no density theorem for the resulting family is claimed.

## 8. Exact output and its scope

At p=2/5, gamma=0.77213952 and b=0.22786048. The exact rational quantity 1-4b-b squared is positive. Since the five-clause gate is decreasing in particle occupations, b(p) is increasing, so the certificate condition holds for every 0<p<=2/5.

Equations (5), (7), (13), (14) and (18) therefore form a finite, completely evaluable lower-bound formula throughout that interval. No trajectory, system-size extrapolation, fitted decay length or numerical percolation threshold is part of its validity.

The elementary upper bound is

\[
D(p)\le(1-p^3)^2. \tag{27}
\]

To derive it, put f=0 in (1). The rate requires a vacancy in each of two disjoint triples of neighbors, independent of the exchanged occupations. Therefore E[c a^2]=2chi(1-p cubed) squared. Better specialized variational upper bounds already exist [4]; (27) is displayed only to show the present enclosure's width.

`certified_bounds.json` stores the exact rational lower and upper endpoints, gate probabilities, module costs, coarse-energy bounds and cutoffs. Displayed decimals are not used as evidence. The theoretical proof and the arithmetic certificate require independent mathematical review; a separate checker is not the same thing as independent peer review.

## 9. Resources, boundary handling and precision

A complete regeneration from the fixed five-clause gate, including graph construction, flow proposal, integer repair, independent verification, exact lower-bound evaluation, and adversarial/geometric tests, was run as

```
OPENBLAS_NUM_THREADS=1 /usr/bin/time -v python reproduce.py
```

The measured full-process wall time was **11.08 seconds** and peak resident memory was **247,264 KiB (241.47 MiB)**. The separate finite verification itself took approximately **1.03 seconds**, excluding process startup, in the final run. `reproduction_resources.txt` and the accompanying logs preserve the measurements. These timings measure regeneration and verification, not the research/literature investigation. They are not portable performance guarantees.

The finite certificate has 998,400 edge entries. Each current has denominator 2^40. Numerical convergence is not a correctness assumption; a poorer proposal simply gives a more expensive exact repaired flow. The verifier rejects a one-integer-unit corrupted current and checks a bound excluding int64 overflow before incidence accumulation. All moment sums are arbitrary-precision integers.

The tested environment was Python 3.13.5, NumPy 2.3.5 and SciPy 1.17.0. Only generation needs SciPy. Checking and evaluating the supplied witness need NumPy and the Python standard library.

### Honest scaling

For an L by L block, a complete two-block binary configuration graph has 2^(2L squared) states, with a polynomial-in-L factor in the number of edges. The current implementation pays this cost at L=3. It provides no polynomial algorithm in arbitrary block size.

For fixed L, evaluating a finite-radius current at one configuration requires only O(R squared) coarse gate queries, each of which reads at most L squared minus one reservoir bits. Matrix bounds (23) involve only two by two rational matrices. Fraction bit lengths and the stored current's denominator must still be paid for.

Exact expectation of a general truncated current may require enumeration of exponentially many radius-R gate configurations: 2^O(R squared), even though evaluating it at one configuration is inexpensive. No claim of polynomial accuracy complexity is made. At a fixed subcritical gate probability, R grows logarithmically in inverse desired L2 error up to logarithmic corrections, but exact moment enumeration can still be exp(O(log squared(1/epsilon))).

For the headline lower bounds, that expectation enumeration is unnecessary: the explicit majorant (14) already closes the proof. The full-current pointwise evaluator is almost surely finite under (12), with expected exploration size controlled by the proved radius moment. It can fail to terminate on exceptional infinite-obstacle configurations; finite-cutoff evaluation is uniformly finite.

Occupied exterior in the finite module is a conservative legality device, not a simulation boundary condition used to approximate the physical coefficient. The nine-phase average removes partition artifacts. Reservoir forcing prevents intermediate-state changes from invalidating current coefficients. The overlap weights account for simultaneous module use. These are all parts of the certificate, not post-processing assumptions.

## 10. What changed relative to the local no-go theorem

The earlier theorem rules out finite-range exactly conserved legal currents with positive transport in box-closed dynamics. This construction does not contradict it.

A finite module has an explicitly nonzero source–sink defect. A finite-radius spatial current can also have nonzero divergence; the tests exhibit a defect of magnitude one. The actual nonlocal current cancels those defects through spatial conservation after conditioning on the reservoirs. The convergence to it has the explicit energy tail (25).

Thus finite computation no longer tries to represent the final current inside an exact local kernel. It represents a finite source law, a nonlocal completion rule, and a quantitative tail certificate. The appropriate finite object is the **defect together with its completion interface**, not an already conserved local current.

## 11. Decisive remaining theorem for dense cooperative transport

The demonstrated density interval is not the dense glassy regime. At large p the current small-block gate is too rare. For example, at p=0.80 its exact probability is only 0.08380672; asymptotically gamma(1-q)=16q^3+O(q^4). Better numerical optimization of this same module cannot change that fact. A demand-compatibility search, which allowed componentwise source balancing rather than requiring a prescribed swap path, returned the same gate in the tested cases; this is a numerical diagnostic, not an independently verified global optimality theorem.

The next consequential mathematical target is a **compressed cooperative module theorem**. For a specified dense p, construct a port-independent reservoir predicate g_L and a legal source–sink module satisfying (4), with all of the following certified as part of a compact representation:

- an explicit gate probability high enough for a proved closed-cluster tail, for example b<sqrt(5)-2 under the present completion;
- exact legality and source balance for every configuration represented by the module, including bad intermediate gate states;
- an explicit weighted energy C_L(p), including all congestion and information loss;
- construction and verification costs that avoid enumerating 2^(2L squared) configurations, together with enough quantitative strength to yield informative transport bounds.

This is not a request to assume a corrector or spectral gap. These are the finite inputs to the proved theorem above. Once supplied, global admissibility, response normalization and a completion tail follow constructively.

Good-box, frameability and cooperative-droplet mechanisms already supply important geometric ingredients and asymptotic comparisons [1,2]. Their existence is not new. The remaining task is to turn appropriate mechanisms into a compact exact source–sink/energy certificate with useful costs; no claim is made that the literature lacks every ingredient of such a theorem.

One can separately tighten the bad-cluster counting/completion bound at moderate density. That improves the current certificate but does not by itself fix the rarity of the small-block gate in dense systems. A larger finite graph without structural compression would merely move the exponential cost elsewhere.

## 12. Comparison and novelty status

Shapira's Thomson principle and legal path lifting [3] are established prior art. Shapira's bulk KA lower bound [1] already uses coarse percolation and quantifies multistep information loss. Ertul–Shapira [2] constructs port-independent coarse connectivity and frameable/good-box mechanisms for tagged diffusion; those geometric ideas are relevant, but tagged and bulk diffusion are not being identified. Arita–Krapivsky–Mallick [4] already supplies specialized finite-dimensional primal calculations.

This investigation does not claim to have invented any of those facts or to supersede their high-density scope. No external optimized implementation was benchmarked head to head, and no claim is made that the displayed numerical bounds are the best known.

The candidate methodological contribution is the combined **finite defect-module compiler, frozen-reservoir lifting identity, explicit cluster-quotient completion and finite-radius energy certificate**, instantiated and checked end to end for hard cooperative KA. The exact finite-module energy replaces a guessed routing/congestion cost in this implementation. The chordless-path automaton supplies a completely numerical nonlocal tail. Independent priority review remains necessary.

The linked Astra and OpenAI repositories were searched selectively for relevant transport/percolation capital. No retrieved repository result is used as an unverified proof dependency. There is no claimed quantum-transport transfer.

## References

[1] Assaf Shapira, *Hydrodynamic limit of the Kob–Andersen model*, arXiv:2003.08495. Especially the variational coefficient, Theorem 2.3, and Section 4's multistep/percolation comparison. Author-hosted text consulted: https://assafshap.github.io/papers/KA_hydrodynamic_limit.pdf

[2] Anatole Ertul and Assaf Shapira, *Self-Diffusion Coefficient in the Kob–Andersen Model*, arXiv:2003.02531. Especially Definitions 3.3–3.8 and Lemma 3.9. https://arxiv.org/abs/2003.02531

[3] Assaf Shapira, *A Thomson-type variational principle for diffusion coefficients*, arXiv:2606.04636, including Section 5.3's unbounded-path construction and inverse-path control. https://arxiv.org/abs/2606.04636

[4] Chikashi Arita, P. L. Krapivsky and Kirone Mallick, *Bulk diffusion in a kinetically constrained lattice gas*, arXiv:1711.10616; see also *Variational calculation of transport coefficients in diffusive lattice gases*, arXiv:1611.07719. https://arxiv.org/abs/1711.10616

[5] Prior conversation artifact, *CRAY GENESIS: Translation-orbit compilation of infinite-lattice transport certificates*, 13 October 2026, especially its box-closure no-go theorem. This is prior internal research, not external validation.
