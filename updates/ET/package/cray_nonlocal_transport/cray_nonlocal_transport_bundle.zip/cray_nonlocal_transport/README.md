# Constructive nonlocal transport certificates for hard KA

This bundle contains a finite source–sink current, an explicit nonlocal completion,
and a separate integer/rational checker for a lower bound on the infinite-volume
bulk variational diffusion coefficient of the hard square-lattice KA model.

**Read `REPORT.md` for the mathematical proof and its limitations.** The verifier
checks the finite certificate; it does not substitute for independent review of
the infinite-volume proof. No publication-priority claim is made.

## Check the supplied certificate

Requires Python 3.10+ and NumPy:

```sh
python verify_module.py
python certificate_bounds.py
python selftest.py
```

The checker verifies every transition's hard legality, all 262,144 source equations,
the gate rule and its probability polynomial, exact energy coefficients, and both
transport moments. The tests reject a corrupted current and check the constructed
nonlocal geometry, microscopic antisymmetry, legality and unit-translation covariance.

`certified_bounds.json` contains exact rational bounds. For example,

```
D(0.30) >= 0.008932514941
D(0.40) >= 0.000010861655
```

Both displayed decimals are rounded down. These are broad lower certificates, not
accurate predictions or solutions of dense glassy transport.

## Regenerate everything

Requires NumPy and SciPy:

```sh
OPENBLAS_NUM_THREADS=1 python reproduce.py
```

The builder starts with the five-clause gate, enumerates the finite hard-KA graph,
proposes an electrical flow numerically, and repairs its integer divergence exactly.
No discovery-search output or precomputed graph component file is needed.

The complete regeneration/check/test process was measured at **11.08 seconds**
wall time and **247,264 KiB (241.47 MiB)** peak resident memory in this container.
See `reproduction_resources.txt`. These are regeneration measurements, not total
research time or portable performance guarantees.

Tested versions: Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0.

## Main files

- `REPORT.md`: definitions, all proof steps, exact formulas, prior art and limitations.
- `module_flow.npz`, `module_metadata.json`: rational current and moment coefficients.
- `verify_module.py`: separate exact finite checker, without a numerical optimizer.
- `certificate_bounds.py`: exact gate, nonlocal-tail and diffusion-bound evaluation.
- `coarse_flow.py`: cluster-quotient current and finite-radius legal approximations.
- `completed_current.py`: evaluates the actual lifted microscopic current.
- `selftest.py`, `reproduce.py`: adversarial tests and full regeneration.
- `exploration/`: optional discovery records, not proof dependencies.

The finite configuration graph is exponential in larger block size. Exact moments
of arbitrary radius-R approximations can be exponential in R squared. The current
module certifies the interval 0<p<=0.40; it does not cover dense high-p regimes.
The nonlocal error is a derived two-state matrix bound, not an assumed spectral gap
or a supplied completion oracle.
