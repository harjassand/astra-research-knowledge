# Cumulative strain, cubic noncommutation, and parabolic growth

**Astra Primitive Genesis — research note, 12 October 2026**

## Status and scope

This note contains a complete analytic derivation of a matrix growth estimate, its parabolic extension, and explicit counterexamples to stronger statements. The main local coefficient is sharp. The cubic order of the noncommutative correction is necessary. Neither the global constant nor the parabolic gradient coefficient is claimed optimal.

The exponential change of variables is the classical first Fer transform, not a new invention. The priority of the particular growth estimate and PDE criteria below remains unresolved. No independently major foundational consequence, global fluid regularity theorem, computational speedup, or independent validation is claimed. The accompanying computations are diagnostics, not proofs of the general results.

The independent search compared collective-move sampling, local quantum response without a global spectral gap, and temporal cancellation in PDE amplification. The first two did not yield a closed, independently stronger mechanism in this investigation. The third yielded the results recorded here. No theorem from an unreviewed Astra or OpenAI manuscript is used as a premise.

Repository snapshots consulted:

- Astra: `01eda4be0686e9fe4dc650af7137efc3c88ba0fb`.
- OpenAI/math: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`.

Astra's branch ledger and relevant theoretical branch view did not identify this precise target. That is a check of published checkpoints, not knowledge of every unpublished run. Repository searches were selective, not exhaustive. The source files remain unchanged; this is a local research artifact.

## 1. The obstruction and the retained principle

For a real symmetric matrix-valued driver, consider

\[
\dot U(t)=S(t)U(t),\qquad U(0)=I,\qquad S(t)^T=S(t).
\]

The elementary estimate obtained by taking norms before integrating is

\[
\|U(t)\|\leq \exp\!\left(\int_0^t\|S(s)\|\,ds\right).
\]

It discards cancellation in time. Set

\[
B(t)=\int_0^t S(s)\,ds.
\]

One cannot simply replace the exponent by \(B(t)\): ordered products do not reduce to the exponential of an integral. However, after the exact transformation \(V=e^{-B}U\), the first commutator is skew-symmetric and does not change Euclidean length. The symmetric part of the transformed generator starts with

\[
\frac13[B,[B,S]].
\]

The retained principle is therefore specific: **once the integrated symmetric driver is accounted for, a rigorous upper bound on additional amplification can be charged to a double-commutator action.** This is an upper-bound principle, not an assertion that every nonzero double commutator causes growth.

All unqualified matrix norms below are Euclidean operator norms. For a symmetric matrix \(B\), let

\[
r(B)=\lambda_{\max}(B)-\lambda_{\min}(B)
\]

be its spectral width. Define the entire even function

\[
c(r)=\begin{cases}
\dfrac{r\cosh r-\sinh r}{r^3},&r>0,\\[4pt]
\dfrac13,&r=0.
\end{cases}
\]

Its expansion is

\[
c(r)=\frac13+\frac{r^2}{30}+\frac{r^4}{840}+\cdots.
\]

## 2. Matrix theorem

### Theorem 1 — growth-tensor comparison

Let \(S:[0,T)\to\operatorname{Sym}(n)\) be locally integrable in operator norm. Define \(B(t)=\int_0^t S(s)\,ds\), and let \(U\) solve the equation above. Put

\[
\Lambda(t)=\int_0^t
 c(r(B(s)))\,\|[B(s),[B(s),S(s)]]\|\,ds.
\]

Then, for every \(t<T\),

\[
\boxed{
 e^{-2\Lambda(t)}e^{2B(t)}
 \preceq U(t)U(t)^T
 \preceq e^{2\Lambda(t)}e^{2B(t)}.
}
\tag{1}
\]

Here \(\preceq\) denotes the order on symmetric matrices defined by nonnegative quadratic forms. In particular,

\[
\|U(t)\|\leq
 e^{\lambda_{\max}(B(t))+\Lambda(t)},
\qquad
\sigma_{\min}(U(t))\geq
 e^{\lambda_{\min}(B(t))-\Lambda(t)}.
\tag{2}
\]

There is no smallness assumption on \(\int_0^t\|S\|\), and no convergence assumption on an infinite Magnus or Fer product. The single transformed generator used in the proof is exact.

The same proof applies to bounded self-adjoint operators on a real or complex Hilbert space, with adjoints replacing transposes and norm-Bochner-integrable drivers. It does not automatically apply to unbounded operators with time-dependent domains.

### Proof

Set \(V=e^{-B}U\). Differentiating the matrix exponential gives

\[
\dot V=RV,
\qquad
R=e^{-B}Se^B-\int_0^1e^{-\theta B}Se^{\theta B}\,d\theta.
\tag{3}
\]

Equation (3) is the classical first Fer remainder [1, Section 2.10.1, equations (99)–(101)]. It is reproduced to specify the exact starting identity, not as a novelty claim.

Write \(\operatorname{ad}_B(X)=[B,X]\). Because \(B,S\) are symmetric, odd iterates \(\operatorname{ad}_B^{2j+1}S\) are skew-symmetric and even iterates are symmetric. Therefore

\[
\begin{aligned}
\operatorname{sym}R
&=\left(\cosh(\operatorname{ad}_B)
 -\frac{\sinh(\operatorname{ad}_B)}{\operatorname{ad}_B}\right)S\\
&=\sum_{j=1}^{\infty}
 \frac{2j}{(2j+1)!}\operatorname{ad}_B^{2j}S.
\end{aligned}
\tag{4}
\]

The quotient is interpreted by its entire power series, so there is no division by a singular operator. The first terms of the full remainder are

\[
R=-\frac12[B,S]+\frac13[B,[B,S]]
 -\frac18[B,[B,[B,S]]]+\cdots.
\]

For every matrix \(X\), centering \(B\) at the midpoint of its spectrum gives

\[
\|[B,X]\|\leq r(B)\|X\|.
\tag{5}
\]

Factoring two commutators out of (4), applying (5) to the remaining ones, and summing the positive series yields

\[
\begin{aligned}
\|\operatorname{sym}R\|
&\leq \sum_{j=1}^{\infty}
 \frac{2j\,r(B)^{2j-2}}{(2j+1)!}
 \|[B,[B,S]]\|\\
&=c(r(B))\|[B,[B,S]]\|.
\end{aligned}
\tag{6}
\]

For any solution \(v(t)=V(t)v_0\),

\[
\frac{d}{dt}|v|^2=2v^T(\operatorname{sym}R)v.
\]

Thus

\[
e^{-\Lambda(t)}|v_0|\leq |V(t)v_0|
\leq e^{\Lambda(t)}|v_0|.
\]

All singular values of \(V\) lie between these bounds. Consequently

\[
e^{-2\Lambda}I\preceq VV^T\preceq e^{2\Lambda}I.
\]

Congruence by \(e^B\), using \(U=e^BV\), proves (1). Equation (2) follows. The differentiations are valid almost everywhere for the stated locally integrable driver, or first for smooth drivers and then by local approximation. ∎

### Sharpness of the local coefficient

Take

\[
B=\begin{pmatrix}r/2&0\\0&-r/2\end{pmatrix},
\qquad
S=\begin{pmatrix}0&1\\1&0\end{pmatrix}.
\]

Then \([B,[B,S]]=r^2S\), while

\[
\operatorname{sym}R=
 \left(\cosh r-\frac{\sinh r}{r}\right)S.
\]

Equality holds in (6). Hence \(c(r)\) is the smallest universal coefficient depending only on the spectral width for that pointwise inequality. This does not prove that all global constants in (1) are optimal.

### Geometric interpretation

At a time when a differentiable eigenframe exists, write \(B=QDQ^T\), with \(D=\operatorname{diag}(b_i)\) and \(\Omega=Q^T\dot Q\) skew-symmetric. Then

\[
Q^TSQ=\dot D+[\Omega,D].
\]

In this frame,

\[
\bigl(Q^T[B,[B,S]]Q\bigr)_{ij}
=-(b_i-b_j)^3\Omega_{ij}\quad(i\ne j),
\]

and the diagonal is zero. The correction measures eigenframe rotation weighted by the **cube** of the integrated anisotropy gap. Radial/eigenvalue changes alone do not contribute to it. Equation (6), unlike this interpretation, needs no smooth choice of eigenvectors and remains valid at degeneracies.

For a nonsymmetric driver \(A=S+W\), with \(W^T=-W\), an exact orthogonal frame \(O'=WO\) reduces the equation to the symmetric driver \(O^TSO\). The theorem then concerns its co-rotating primitive. Acquiring that frame is an additional task; it must not be treated as free data.

## 3. Why cubic noncommutation is necessary

### Proposition 2 — a zero-integral pulse cycle with positive growth

Let

\[
X=\begin{pmatrix}1&0\\0&-1\end{pmatrix},\qquad
Z=\begin{pmatrix}0&1\\1&0\end{pmatrix},
\]

and, for \(\varepsilon>0\), set

\[
A_\varepsilon=e^{\varepsilon X},\quad
B_\varepsilon=e^{\varepsilon Z},\quad
C_\varepsilon=A_\varepsilon B_\varepsilon
 A_\varepsilon^{-1}B_\varepsilon^{-1},
\]

\[
D_\varepsilon=A_\varepsilon C_\varepsilon
 A_\varepsilon^{-1}C_\varepsilon^{-1}.
\tag{7}
\]

The product \(D_\varepsilon\) consists of ten exponentials of symmetric trace-zero matrices. The sum of the ten exponent matrices is zero. It is realized by a piecewise constant symmetric driver with zero primitive at the end of the cycle (use the reverse order of the written factors as chronological order).

Direct multiplication gives

\[
\det D_\varepsilon=1,\qquad
\operatorname{tr}D_\varepsilon
 =2+16\sinh^6\varepsilon\cosh^2\varepsilon>2.
\tag{8}
\]

Its eigenvalues are positive and reciprocal, and

\[
\boxed{
\log\rho(D_\varepsilon)
=2\operatorname{arsinh}
 (2\sinh^3\varepsilon\cosh\varepsilon)
=4\varepsilon^3+O(\varepsilon^5).
}
\tag{9}
\]

In particular, repeating the cycle \(m\) times gives

\[
\|D_\varepsilon^m\|\geq
 \exp\{m\log\rho(D_\varepsilon)\},
\]

although the cumulative driver returns to zero after every cycle and remains bounded by \(\sqrt5\,\varepsilon\) throughout all repetitions.

An exact check of (8) can be made with \(q=e^\varepsilon\):

\[
\operatorname{tr}D_\varepsilon-2
=\frac{(q-1)^6(q+1)^6(q^2+1)^2}{16q^8}.
\]

On one cycle,

\[
\int\|[B,[B,S]]\|\,dt=K\varepsilon^3,
\]

where

\[
K=8\sqrt5+4\sqrt2+16\operatorname{arsinh}(1/2)
 +2\operatorname{arsinh}2+4\operatorname{arsinh}1
\approx37.6575525689.
\]

Thus both the certified correction and an actual positive growth exponent occur at cubic order. A general fourth-order replacement would be false.

### Smooth finite-time obstruction with a primitive tending to zero

The obstruction is not only an infinite-time, discontinuous-driver phenomenon. The expansion of the same matrix is

\[
D_\varepsilon=I+4\varepsilon^3 Z
 +8\varepsilon^4\begin{pmatrix}0&1\\-1&0\end{pmatrix}
 +O(\varepsilon^5).
\]

For all sufficiently small positive \(\varepsilon\), its entries are nonnegative and

\[
D_\varepsilon\mathbf1\geq
 (1+2\varepsilon^3)\mathbf1
\]

componentwise. Choose \(\varepsilon_j=\delta(j+1)^{-1/3}\), with \(\delta\) sufficiently small. Realize cycle \(j\) inside an interval of length \(2^{-j}\), using disjoint smooth scalar bumps for the ten matrix pulses. Each bump has the required matrix integral and vanishes to every order at its endpoints. The propagator is unchanged by this reparameterization.

The resulting driver is smooth on \([0,T)\) for a finite \(T\). Its primitive returns to zero after every cycle and tends to zero as \(t\uparrow T\), because its excursion on cycle \(j\) is at most \(\sqrt5\varepsilon_j\). Nevertheless, the product acting on \(\mathbf1\) grows at least as

\[
\prod_j(1+2\varepsilon_j^3)=\infty.
\]

Therefore even a bounded primitive that extends continuously to zero at the endpoint does not control amplification in the general symmetric matrix equation. Its divergent cubic action identifies the failure.

Conversely, taking \(\varepsilon_j=\delta(j+1)^{-2/5}\) in the same construction gives finite total cubic action but divergent \(\int\|S\|\) and divergent \(\int\|[B,S]\|\). Theorem 1 still bounds the propagator and its inverse. This proves a strict improvement over those absolute-action sufficient conditions at the matrix level.

These are matrix-system counterexamples. They are not constructions of finite-energy Euler or Navier–Stokes singularities.

## 4. Parabolic extension

Let the spatial domain be a flat torus \(\mathbb T^d\), and define

\[
\mathcal L=\partial_t+v\cdot\nabla-\nu\Delta,
\qquad \nu\geq0.
\]

For the pointwise maximum estimate, take all coefficients and solutions smooth on compact subintervals of \([0,T)\). For the integrated energy estimate also assume \(\nabla\cdot v=0\). Let \(S(t,x)\) be a real symmetric \(n\times n\) matrix field, and suppose

\[
\mathcal Lz=Sz,
\qquad
\mathcal LB=S,
\qquad B(0,x)=0.
\tag{10}
\]

The auxiliary equation preserves symmetry. Define

\[
a(r)=\int_0^1e^{r\theta}\,d\theta
 =\frac{e^r-1}{r},
\]

\[
h(r)=2\int_0^1\theta e^{r\theta}\,d\theta
 =\frac{2((r-1)e^r+1)}{r^2},
\]

with \(a(0)=h(0)=1\). All coefficient functions in this note are nondecreasing for \(r\geq0\), as follows from their nonnegative power series or integral representations.

For \(r=r(B(t,x))\), put

\[
\mathcal D(t,x)=\|[B,[B,S]]\|,\qquad
\mathcal G(t,x)=\sum_{i=1}^d\|\partial_iB\|^2,
\]

\[
q(t,x)=c(r)\mathcal D
 +\nu\bigl(h(r)+a(r)^2\bigr)\mathcal G.
\tag{11}
\]

### Theorem 3 — scalar domination after the matrix gauge

For \(y=e^{-B}z\),

\[
\boxed{\mathcal L|y|^2\leq2q|y|^2.}
\tag{12}
\]

Consequently,

\[
\|z(t)\|_\infty
\leq
\exp\!\left\{
 \sup_x\lambda_{\max}(B(t,x))
 +\int_0^t\|q(s)\|_\infty\,ds
\right\}\|z(0)\|_\infty.
\tag{13}
\]

The norm on vector fields uses Euclidean fiber length. Equation (12) is stronger than (13): it permits any justified scalar positive-evolution or potential estimate to replace the crude time integral of the spatial supremum. Such further potential estimates are not supplied automatically by the matrix identity.

### Proof

Set \(E=e^B\), \(C_i=\partial_iB\), and use \(D\exp_B\), \(D^2\exp_B\) for the first and second Fréchet derivatives. The diffusion chain rule gives

\[
\mathcal LE=D\exp_B[S]
 -\nu\sum_iD^2\exp_B[C_i,C_i].
\]

The product rule applied to \(z=Ey\) yields

\[
\mathcal Ly=
 \left(R+\nu\sum_i\Theta_i\right)y
 +2\nu\sum_i\Gamma_i\partial_i y,
\tag{14}
\]

where \(R\) is exactly the matrix remainder (3) at each point, and

\[
\Gamma_i=e^{-B}D\exp_B[C_i],\qquad
\Theta_i=e^{-B}D^2\exp_B[C_i,C_i].
\]

The integral formulas for exponential derivatives imply

\[
\|\Gamma_i\|\leq a(r)\|C_i\|,
\qquad
\|\Theta_i\|\leq h(r)\|C_i\|^2.
\tag{15}
\]

For completeness, the first formula is

\[
\Gamma_i=\int_0^1e^{-sB}C_i e^{sB}\,ds.
\]

The second is

\[
\Theta_i=2\int_{\substack{s_1,s_2\geq0\\s_1+s_2\leq1}}
 e^{-(s_1+s_2)B}C_i e^{s_1B}C_i e^{s_2B}\,ds_1ds_2.
\]

Centering \(B\) at its spectral midpoint bounds the integrand norm in the second formula by
\(e^{r(s_1+s_2)}\|C_i\|^2\). Integrating first along \(s_1+s_2=s\) gives \(h(r)\).

Now

\[
\begin{aligned}
\mathcal L|y|^2
={}&2y^T\left(R+\nu\sum_i\Theta_i\right)y
 +4\nu\sum_i y^T\Gamma_i\partial_i y
 -2\nu\sum_i|\partial_i y|^2.
\end{aligned}
\]

Completing a square gives, for any vector \(w\),

\[
4y^T\Gamma_iw-2|w|^2
\leq2|\Gamma_i^Ty|^2.
\]

Combining this with (6) and (15) proves (12). The scalar maximum principle on the torus proves (13). No commutation assumption between \(B\), \(S\), and spatial derivatives of \(B\) was made. ∎

### A stronger form-bounded version for the viscous case

Retaining part of the gradient dissipation gives

\[
\mathcal L|y|^2+\nu\sum_i|\partial_i y|^2
\leq2q_E|y|^2,
\tag{16}
\]

where

\[
q_E=c(r)\mathcal D+
 \nu\bigl(h(r)+2a(r)^2\bigr)\mathcal G.
\]

Indeed, use
\(4y^T\Gamma_iw\leq|w|^2+4|\Gamma_i^Ty|^2\)
instead of completing the previous square.

Assume \(\nabla\cdot v=0\) and that, for every scalar \(f\in H^1(\mathbb T^d)\),

\[
\int q_E(t,x)|f|^2\,dx
\leq\frac\nu4\int|\nabla f|^2\,dx
 +\alpha(t)\int|f|^2\,dx,
\qquad \alpha\in L^1(0,T).
\tag{17}
\]

Apply (17) componentwise to \(y\) and integrate (16). Then

\[
\frac{d}{dt}\|y\|_2^2+\frac{\nu}{2}\|\nabla y\|_2^2
\leq2\alpha(t)\|y\|_2^2,
\]

so

\[
\|z(t)\|_2
\leq e^{\sup_x\lambda_{\max}(B(t,x))+
 \int_0^t\alpha(s)ds}\|z(0)\|_2.
\tag{18}
\]

This avoids demanding a spatial supremum of \(q_E\). For example, on \(\mathbb T^3\), a sufficiently small uniform \(L^{3/2}\) norm of \(q_E\) supplies (17) by the Sobolev inequality, with an integrable lower-order constant. This is a critical-form condition, not a consequence of the ordinary fluid energy inequality.

## 5. Diffusion really requires an extra term

The inviscid estimate cannot simply be applied to the parabolic primitive while deleting \(\mathcal G\), even when every matrix commutes.

Take the circle of period \(2\pi\), zero drift, \(\nu>0\), and scalar potential

\[
S(x)=\nu a\cos x,\qquad a>0.
\]

The canonical zero-initial primitive is

\[
b(t,x)=a(1-e^{-\nu t})\cos x,
\qquad
(\partial_t-\nu\partial_{xx})b=S.
\]

It is uniformly bounded by \(a\), and every commutator vanishes. Nevertheless the scalar operator

\[
L=\nu\partial_{xx}+\nu a\cos x
\]

has a positive top eigenvalue. For the test function \(f=1+a\cos x\), its Rayleigh quotient, using normalized spatial integration, is

\[
\frac{\langle f,Lf\rangle}{\langle f,f\rangle}
 =\frac{\nu a^2}{2+a^2}>0.
\]

This self-adjoint elliptic operator has compact resolvent and therefore has an eigenfunction with positive eigenvalue, and a corresponding solution grows exponentially. Thus bounded \(b\) plus zero commutators cannot give a time-uniform growth bound.

Embedding \(S\) and \(b\) into \(\operatorname{diag}(S,-S)\) and \(\operatorname{diag}(b,-b)\) makes this a symmetric trace-zero matrix example. It remains an example of a prescribed parabolic system, not a self-consistent incompressible fluid.

In the scalar gauge equation the term is visible directly:

\[
\partial_t y=\nu\partial_{xx}y
 +2\nu b_x\partial_x y+\nu b_x^2y.
\]

Spatial gradients of the primitive supply genuine amplification. The new parabolic term is not merely an artifact of an uncareful extension of the ODE proof.

## 6. Consequences for full three-dimensional fluid equations

Let \(u\) be an unforced classical incompressible Euler or Navier–Stokes solution on \(\mathbb T^3\), smooth on \([0,T)\), where \(0<T<\infty\), with initial data in \(H^s\), \(s>5/2\). Write

\[
\omega=\nabla\times u,\qquad
S=\tfrac12(\nabla u+\nabla u^T),
\qquad
\mathcal L=\partial_t+u\cdot\nabla-\nu\Delta.
\]

The skew part of \(\nabla u\) annihilates its own vorticity vector, so the full vorticity equation is

\[
\mathcal L\omega=S\omega.
\tag{19}
\]

Let the symmetric auxiliary field satisfy

\[
\mathcal LB=S,\qquad B(0)=0.
\tag{20}
\]

It also has zero trace. Set

\[
M=\sup_{0\leq t<T}\|B(t)\|_{L^\infty_x},
\]

\[
D(t)=\|[B,[B,S]]\|_{L^\infty_x},\qquad
G(t)=\left\|\sum_i\|\partial_iB\|^2\right\|_{L^\infty_x}.
\]

### Corollary 4 — conditional fluid continuation

If

\[
M<\infty,
\qquad
\int_0^T\bigl(D(t)+\nu G(t)\bigr)\,dt<\infty,
\tag{21}
\]

then \(\omega\) is uniformly bounded on \([0,T)\), with

\[
\|\omega(t)\|_\infty
\leq\|\omega_0\|_\infty
\exp\!\left[
M+c(2M)\int_0^tD(s)ds
+\nu\bigl(h(2M)+a(2M)^2\bigr)\int_0^tG(s)ds
\right].
\tag{22}
\]

Consequently the classical fluid solution continues beyond \(T\), by the usual vorticity continuation criterion [2, Theorem 1 and Section 2.1]. For Euler \(\nu=0\), so there is no spatial-gradient condition; \(B\) is simply the strain integral along particle trajectories.

For Navier–Stokes \(\nu>0\), the weaker form-bounded condition (17), together with bounded \(B\), is another sufficient criterion. It bounds \(\|\omega\|_2\) by (18), hence bounds \(\|u\|_{H^1}\); the standard viscous continuation result then applies [2, Section 2.1]. This latter inference is not valid for Euler.

These statements apply to the full equations under explicit additional hypotheses. They do **not** prove that those hypotheses hold for general initial data. The matrix counterexamples do not establish fluid blow-up or fluid realizability of the pulse histories.

The matrix \(U\) associated with the symmetric vorticity equation is an amplification propagator. It should not be identified with the complete material deformation gradient, which evolves under \(\nabla u\), unless the skew part is included through the co-rotating-frame reduction.

## 7. The precise missing estimate

A foundational fluid consequence would require a noncircular way to control (21) or the form condition (17) in a consequential class not already handled by established estimates. No such closure has been proved here.

There is one useful automatic estimate, but it falls short. For \(\nu>0\), multiply (20) by \(B\), use the Frobenius inner product, and integrate. Symmetry and periodic integration by parts give

\[
\frac12\frac{d}{dt}\|B\|_{L^2,F}^2
 +\nu\|\nabla B\|_{L^2,F}^2
=\int B:S
=-\int (\operatorname{div}B)\cdot u.
\]

Since \(\|\operatorname{div}B\|_2\leq\sqrt3\|\nabla B\|_{L^2,F}\),

\[
\boxed{
\|B(t)\|_{L^2,F}^2
 +\nu\int_0^t\|\nabla B\|_{L^2,F}^2ds
\leq\frac3\nu\int_0^t\|u(s)\|_2^2ds
\leq\frac{3t}{\nu}\|u_0\|_2^2.
}
\tag{23}
\]

Thus the ordinary velocity energy provides a spatially averaged primitive bound and a spatially averaged gradient action. It does **not** provide bounded \(B\), the supremum-type gradient action in (21), or the quadratic-form control in (17). It also gives no bound on the cubic noncommutative action. Upgrading (23) while respecting the self-consistent relation \(S=\operatorname{sym}\nabla u\) is the exact unresolved mathematical step in this route.

Replacing those missing bounds by assumptions and then invoking the corollary would be a conditional regularity criterion, not a solution of the underlying fluid problem. Treating arbitrary matrix pulse histories as finite-energy fluid histories would be a different invalid shortcut.

## 8. Acquisition and computational scope

The ODE certificate requires the actual matrix history, or rigorous approximations and error bounds sufficient to certify the primitive and its double-commutator action. For dense \(n\times n\) matrices, ordinary matrix multiplication computes each commutator in \(O(n^3)\) arithmetic operations. A time-discrete certificate must additionally bound quadrature error and unresolved temporal variation. Highly oscillatory input is not acquired for free.

For the PDE, obtaining \(B\) requires solving an auxiliary matrix transport or advection–diffusion equation driven by the actual strain. A numerical field alone does not certify continuum spatial suprema, derivatives, or the quadratic-form inequality. The theorem is not a shortcut around resolving or rigorously bounding those quantities, and it does not yield an automatic sublinear-time or subresolution fluid simulator.

The gain established here is mathematical: ordinary norm-first estimates can diverge while the new action stays finite. The smooth shrinking-pulse example in Section 3 proves that distinction. A demonstrated algorithmic advantage for self-consistent physical dynamics remains unestablished.

## 9. Reproducible checks

Run `python verify.py`. The script uses NumPy, SciPy, and SymPy, and writes `verification_results.json`.

The recorded run checked:

- 120 random matrix and parabolic first-jet cases in dimensions 2, 3, 5, and 8;
- equality cases for the sharp local coefficient at five spectral widths;
- 36 nonzero-final-primitive trajectory comparisons;
- five pulse amplitudes against the exact spectral-radius formula;
- the determinant and trace identity in (8) by exact symbolic rational arithmetic.

All assertions passed in the recorded run. The largest relative discrepancy in the transformed-generator identity was approximately `1.38e-15`. These finite calculations test algebraic implementation and examples; they do not constitute a proof of the universal theorem, an independent review, a PDE simulation, or a formal verification.

## 10. Priority and significance boundary

Known starting machinery: the exponential derivative formula, Fer factorization, symmetric/skew-symmetric decomposition, the matrix logarithmic-norm energy argument, scalar maximum principles, quadratic-form energy estimates, and fluid continuation criteria.

The candidate contribution to be checked for priority is the particular spectral-width-sharp double-commutator growth bound, its integrated tensor comparison, and the canonical parabolic-primitive formulation with an explicit diffusion penalty. The presence of a derivation in this note does not establish historical originality. Selective searches did not resolve whether an equivalent result is already present in matrix evolution, geometric integration, weighted parabolic systems, or fluid-regularity literature.

The strongest retained result is an internally proved, cancellation-sensitive growth and continuation estimate with sharp matrix-level obstructions. The independently major consequence is missing: a noncircular estimate for the new geometric quantities in the actual nonlinear problem.

## References

[1] S. Blanes, F. Casas, J. A. Oteo, J. Ros. *The Magnus expansion and some of its applications*. Physics Reports 470 (2009), 151–238; arXiv:0810.5488. Section 2.10.1, equations (99)–(101), gives the exact Fer transform used here. F. Fer's original construction is from 1958; that operation is not claimed as new.

[2] J. D. Gibbon, A. Gupta, N. Pal, R. Pandit. *The role of BKM-type theorems in 3D Euler, Navier–Stokes and Cahn–Hilliard–Navier–Stokes analysis*. arXiv:1706.10099v2 (2017). Theorem 1 states the Euler vorticity continuation criterion; Section 2.1 explains the viscous criteria used here. This note uses these mathematical criteria, not historical statements in that article about the current status of fluid problems.

[3] J. T. Beale, T. Kato, A. Majda. *Remarks on the breakdown of smooth solutions for the 3-D Euler equations*. Communications in Mathematical Physics 94 (1984), 61–66. Original source of the Euler criterion, referenced through [2] in this investigation; its original full text was not retrieved.

[4] Astra research knowledge repository, pinned revision stated above: `00_START_HERE.txt`, `state/branches.tsv`, `state/branches/theoretical-pro.txt`, lexical routing, and selective source searches. Published branch checkpoints are not an exhaustive real-time worker registry.

[5] OpenAI mathematical research repository, pinned revision stated above: README and selective searches. The repository explicitly distinguishes manuscripts at different verification stages. No manuscript theorem from this collection is assumed in the proofs above.
