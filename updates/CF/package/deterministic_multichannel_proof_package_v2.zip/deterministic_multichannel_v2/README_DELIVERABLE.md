# Deterministic propagation through coalescing multichannel crossings

Research package, 2026-10-09 UTC. Version 2, with the original version preserved.

## Result in one paragraph

A constructive theorem draft gives a deterministic algorithm for the full endpoint propagator of an explicitly supplied rational Hermitian matrix polynomial. The proposed bit-work bound is polynomial in the matrix dimension, polynomial degree, coefficient encoding length, frequency encoding length, and requested number of accuracy bits. It covers coalescing multichannel scales without free eigenbasis, phase, gap, or connection-matrix oracles. One focused internal end-to-end check found no blocking mathematical gap after the implementation addendum and small mesh/input repairs now incorporated in version 2.

The operational promise is coherent transition matrices at useful precision without paying directly for every carrier oscillation or the inverse width of a narrow crossing. This is a supplied-model computational result. It does not acquire an accurate physical model or remove exponential many-body matrix dimension.

## What changed the resource conclusion

The earlier randomized construction required work proportional to inverse squared error. The present deterministic mechanism is different:

1. Algebraic discriminant roots acquire a geometric mesh using the bit length of narrow scales.
2. Finite-valency complex analysis bounds spectral rotation and relative gap variation on those panels, with only a polynomial radius shrink.
3. Precision-dependent clustering leaves bounded-action blocks; separated blocks admit finite-order superadiabatic decoupling.
4. Original algebraic scalar phases are integrated separately. Polynomial-size Taylor-jet circuits acquire the nonpolynomial transformed generators and all endpoint conversions.

This changes the accuracy dependence to a polynomial in the requested number of bits. The conservative constants do not establish a useful runtime.

## Reading order

1. `NATIVE_DETERMINISTIC_THEOREM_v2.md`: corrected theorem, exact input/output contract, complete construction and complexity/error accounting.
2. `algebraic_rotation_gap_lemma.md`: the height-independent analytic-scale bound and an explicit obstruction to a stronger false fixed-radius bound.
3. `local_superadiabatic_contraction.md`: local contraction and separated-group contour estimates.
4. `INDEPENDENT_END_TO_END_REVIEW_v1.md`: focused internal check and constructive addendum. Sections 5–6 specify the ambient n-squared projector-jet solve and noncircular guard-bit bound.
5. `OPERATIONAL_INTERFACE_AND_PRIOR.md`: operational meaning, closest checked primary-source interfaces, and practical limitations.
6. `BENCHMARK_SPEC_v1.md` and `benchmark_manifest.json`: bounded, fair future execution contract. These are specifications, not benchmark results.

`NATIVE_DETERMINISTIC_THEOREM_v1.md` is included byte-identically for provenance. The SHA-256 expected from the independent check is `6e4a6a1ff335f856c465aa5cbf11ff6caeee40125ee853c5e17b3a3ffbe18609`.

## Reproducible exact evidence

Run the small supplied Python scripts with SymPy (and mpmath where used):

    python verify_three_channel_scaling.py
    python verify_review_projector_jets.py
    python make_benchmark_manifest.py

The saved JSON records show:

- exact rescaling of the genuinely irreducible three-channel quadratic family;
- exact su(3) Lie rank eight;
- a degree-twelve discriminant with exactly zero real roots;
- five exact nonzero projector-jet orders and the transport sign identity.

Numerical complex-root locations in the scaling record are labeled approximate. These checks validate identities and an adversarial input family, not the full propagation algorithm or its complexity experimentally.

## Validation and performance status

- Internal mathematical check: one focused end-to-end check, positive after the included repairs.
- Formal proof verification: not performed.
- External mathematical validation: not performed.
- Historical priority: not established. The component analytic estimates and superadiabatic recurrence have explicit antecedents.
- Executable interval-certified implementation: not yet completed.
- Practical speedup: not demonstrated. Modern phase-function methods already exhibit practical frequency independence on supported problems.

This package deliberately excludes the subsequent exploratory numerical prototype and its outputs. Those use high-precision floating-point calculations and heuristic indicators; they cannot be substituted for the interval-certified algorithm in the theorem.

## Primary-source pointers

- Roytwarf–Yomdin, Bernstein classes: https://www.numdam.org/article/AIF_1997__47_3_825_0.pdf
- Friedland–Yomdin, nonvanishing finite-valency distortion statement: https://arxiv.org/pdf/1503.00325
- Joye–Pfister, superadiabatic renormalization: https://www-fourier.univ-grenoble-alpes.fr/~joye/jpjmp.pdf
- Hu–Bremer, frequency-independent systems solver: https://www.math.toronto.edu/bremer/papers/scalar2.pdf
- Stojimirovic–Bremer, accelerated scalar solver: https://academic.oup.com/imajna/advance-article/doi/10.1093/imanum/draf128/8472808

See the included prior/interface document and check for exactly which claims each source supports. No external publication, contact, paid computation, repository push or deployment was performed.
