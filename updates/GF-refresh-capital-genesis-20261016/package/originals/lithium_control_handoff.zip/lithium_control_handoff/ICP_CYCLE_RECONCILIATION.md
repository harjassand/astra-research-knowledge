# Independent ICP cycle-budget reconciliation

## Result
The Figure 5A processing workbook implies less cumulative recovered Li under pulsed operation over the ten recorded cycles: 10.2573839662 versus 12.7700421941 in the workbook’s formula-implied mg/g units for CC, ratio 0.8032380638. This is a workbook-derived, ten-cycle net-recovery comparison with unresolved dilution and inventory factors; absolute mg/g values are not independently validated. It is not a validated lifetime yield, measured electrode-life endpoint, or equal-clock-time throughput comparison.

The same workbook reproduces the paper's capacity retention: 32.7453142% pulse versus 13.1384160% CC. Both divide cycle 10 by each mode's own cycle 1. Pulse begins with a smaller recovery increment. Pulse exceeds CC in individual cycles 6–10 but has not caught up cumulatively by cycle 10.

## Source and methods
Public sources: https://zenodo.org/records/23064370 and https://doi.org/10.1021/acssuschemeng.6c04447 . Original workbook paths relative to this directory: `figure 05/raw data/Li uptake experiments/Figure 5A/processing.xlsx` (Sheet2) and matching `raw data.xlsx` (Sheet1). No workbook was changed. Primary-runtime Python/openpyxl was used read-only. Newly authored extraction/reconciliation code is `reconcile_icp.py`; auditable extracted cells and results are `icp_cycle_reconciliation.json`.

Processing D3,D5,...,D21 use (B_odd−B_previous)*0.1/0.158. J3,J5,...,J21 use the corresponding H cells. D23=D21*100/D3 and J23=J21*100/J3. Raw headers identify ppm; sample labels identify recovery solution at 0 and 0.5 h, not feed depletion. Raw Mean cells reconcile the processing concentration values except the discrepancies below. Each instrument measurement also has numbered readings and SD/RSD. These must not be counted as independent electrode experiments.

## Cycle results (workbook formula units mg/g)
Cycle, CC, pulse:
1, 2.85021097, 1.91350211
2, 2.36919831, 1.06329114
3, 1.94725738, 1.64978903
4, 1.54324895, 0.78797468
5, 1.30590717, 1.03481013
6, 0.75105485, 0.96202532
7, 0.75738397, 0.90189873
8, 0.58016878, 0.61708861
9, 0.29113924, 0.70042194
10, 0.37447257, 0.62658228

## Denominator and inventory limitations
- Paper Experimental section explicitly defines working-electrode mass as active material, conductive additive, and binder, i.e. full electrode mass. Thus values must not be casually recast per g of active LFP.
- Both processing columns use 0.158 g. Associated November Ch3 LFPC files in `figure 04/analysis/EC-LAB/cycle stability/LFPC` identify 161.1 mg, while Ch1 pulse files in sibling `LFP-C Pulsed` identify 158.8 mg. If those filenames are the correct actual masses, changing only those denominators yields CC 12.5243120 and pulse 10.2057095 mg/g, ratio 0.8148718644. This is a sensitivity calculation, not an authorized correction of the original data.
- The formula-implied ten-cycle Li amounts before mass normalization are CC 2.017666667 mg and pulse 1.620666667 mg, assuming each recovery batch is 0.1 L and the ppm values are undiluted solution concentrations. The workbook does not provide explicit dilution multipliers, sample volumes, replacement volumes, or a complete liquid inventory. Absolute recovered masses remain unverified.
- The paper describes recovery electrolyte as 100 mL, 10 mM LiCl, approximately 70 mg Li/L using the workbook's atomic mass 7. The raw cycle baselines are approximately 5.4–5.7 ppm. This is an unresolved concentration/dilution or protocol discrepancy; do not invent a dilution factor to reconcile it. A common multiplicative dilution factor would cancel in the pulse/CC ratio and own-mode retention. Differential factors would not; pulse would need a factor >1.24496 relative to CC to reverse the workbook's total ratio before filename-mass adjustment.
- Separate initial recovery baselines are subtracted each cycle. The raw series does not show progressively accumulated recovery-solution concentration across these ten cycles. Do not sum gross final concentrations or treat initial Li in the recovery solution as newly extracted Li.
- Pretreatment settings exist for both CC and pulse, with filenames documenting −0.6 V 2 h and +1.0 V 2 h. The paper describes initial delithiation. These conditioning steps are not included in the ten-cycle processing totals. Electrode-residual Li, conditioning inventory, feed loss, rinse loss, sample removal, and residual terminal electrode inventory are not closed by this workbook. It therefore cannot by itself establish total source-Li mass balance or asymptotic lifetime yield.
- EC-Lab metadata 'Mass of active material: 7000 mg' in the checked pulse file conflicts with filename masses and looks like generic battery metadata (also referring to 18650 and GITT). Do not use it as measured electrode mass.

## Raw-to-processing discrepancies
1. Pulse cycle 2 final processing H5=7.25 ppm and I5=24.7 ppm. Raw Mean Li cells D338,D351,D361 are 7.20,7.04,7.09, averaging 7.11. The processing pair exactly matches one numbered instrument reading D333=7.25, E333=24.7, rather than the available sample means. Reason for this choice is not documented in the supplied readme.
2. Pulse cycle 5 final processing H11=7.15 and I11=25.4 average the first three Mean rows (D826,D836,D846 and corresponding E cells). A fourth available Mean row D856=7.13, E856=25.2 is omitted. All four Li means average 7.145. Do not assume whether the extra measurement was deliberately excluded.
3. Averaging every available numeric raw Mean for each named sample gives CC 12.7700421941 and pulse 10.1656118143 mg/g under the workbook conversion. This sensitivity remains below CC. It is not a statistically justified replacement estimator.

## Feed impurity ratio
Figure5A selectivity formulas E3:E21 and K3:K21 multiply molar recovery-increment Li/Na by 2000. This is distinct from the 1000 feed ratio used in the pulse-optimization comparison. The companion investigator located cycle feed filenames recording 0.5 mM Li and 1000 mM Na; that matches 2000. Do not combine the two experiments as the same feed composition.

## Scale-up Figure 5E/F is separate
The eight-cycle processing workbook has initial Li B2=13.3 and final B10=52.3 ppm. H10=27.857142857 is net Li molarity after subtracting initial Li and applying factor 5/7. H11=B10*5/7=37.357142857 is gross Li including the initial solution. H12's product composition uses H11. This is a separate accumulated-solution experiment, not the ten-cycle CC/pulse comparison. Its seed-inclusive purity must not be confused with fraction of newly recovered Li.

## Safe conclusion
The released calculations support better own-initial capacity retention and later-cycle recovery increments for pulse, but do not support a measured ten-cycle cumulative-yield advantage. A full lifetime-productivity claim requires more cycles or a defensible endpoint model plus dilution, volume, conditioning, and mass reconciliation. The numerical ratio is fairly insensitive to the small filename-mass mismatch and identified averaging choices, but is conditional on comparable sample handling and conversion factors.
