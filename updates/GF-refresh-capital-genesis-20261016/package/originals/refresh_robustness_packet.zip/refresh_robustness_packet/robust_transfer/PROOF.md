# Robust local refresh: rare-event product and exact support transfer

Date: 2026-10-16. Conditional mathematical result, not a device qualification or a new physical refresh primitive.

## Verdict

There is a useful local robustness theorem. A global additive sum of channel errors is unnecessary when the errors have a composable local interface. For parent i, let f_i be a certified ideal tester value (the supplied general-Schur two-gap F, maximized over entering labels when required, is one example). Let its imperfect slots have full-joint half-diamond errors epsilon_ik. Then

    F_R <= [product_(i in R) min{1, f_i + sum_k epsilon_ik}] I.       (1)

This is an unconditional full-input subset-effect bound with arbitrary shared persistent bath and staggered own-entry/retirement, under the locality and lifecycle hypotheses below. The error contribution is local to each parent, rather than a global error added to an exponentially small product.

Diamond closeness alone does not prove the support conclusion. With exact actual entry and exit syndrome projections, the support conclusion DOES survive arbitrary coherent refresh imperfections if the entire propagated memory-error footprint C_i satisfies

    Pauli(C_i) intersect Centralizer(G_i) subset phase times S_code.  (2)

All actual refresh/gate Kraus operators must have the stated footprint, up to exact stabilizer-algebra factors. C_i includes the old weak footprint and every actual noisy refresh/control footprint. This is stronger than merely reserving those resources. Under (2), actual endpoint-good records still define genuine correctable CP branches, without a stochastic fault flag.

If the footprint supports an undetected logical operator, or if actual endpoint instruments are only close to trusted projections, generic diamond error cannot replace these exact support premises. A genuine CP good/fault refinement or a new approximate-error-correction argument is then needed. Exact counterexamples are in Section 7.

## 1. The local composable contract

Keep the scheduled-memory assumptions from memory_support_transfer_audit/AUDIT.md and the original measurement_randomizer_bridge/REPORT.md:

1. Each selected parent has an actual exact trusted entering instrument and intended correction, and an actual exact final full-G_i syndrome instrument. Its bad flag is b_i=1[t_i != r_i]. Geometry, windows, node order, and action envelopes are fixed/exogenous. Generated outcomes are never normalized away.
2. Concurrent selected parents have disjoint FULL reservations D_i. Any subsequent physical reuse starts after actual retirement. Every persistent environment/controller that can return is included in the modeled bath B. Initial memory, bath, and reference correlations are arbitrary.
3. On replacing the selected imperfect refresh slots by their reference maps T_ik, the existing independent-tester simulation applies with unchanged ideal action budgets and singleton values f_i. Reference refresh environments are independent and inaccessible as in the supplied proof. References may include already-qualified free parity-preserving operations around the actual Schur node; they need not be literally the identity on B if that extra reference evolution is already in the embedding.
4. An imperfect node N_ik is a CPTP map on D_i tensor B, tensored with identity on all other active memory reservations. Its reference T_ik has the same typed input/output boundary. Records and retained controller registers are included. The bound

       (1/2)||N_ik - T_ik||_diamond <= epsilon_ik

   holds uniformly on this complete joint boundary, with arbitrary additional reference. It is not a reduced-memory distance at one prepared bath state. All action envelopes for the other parents remain uniform after any allowed bath change.
5. The chronology is a composition of such replacement slots and the already allowed controls. An end-to-end finite-window comparison is a slot only after proving it has this local interface. A general concurrent window is not localized merely because an instantaneous perturbing Hamiltonian initially has local support. A portwise strategy/comb comparison, or the primitive-local sufficient construction in Section 8, can be used instead.

The literal tensor-identity requirement in item 4 is a simple sufficient locality assumption. More general interfaces are possible if every replacement map, including its positive majorant, is demonstrably simulable without access to the remaining testers' private parities except through their parity-preserving message interfaces. That generalization is not assumed merely from a norm estimate.

Actual errors may share B, may depend on its entire history, and need not have independent stochastic flags. The uniform joint map bound is what prevents a rare initial bath trigger from evading the contract. Reference ideal noise stays private; the actual device need not be declared perfectly isolated if all departures are included in its qualified joint defect.

## 2. Exact channel-distance/CP-majorant lemma

Write A <=_CP B when B-A is completely positive. For two CPTP maps N,T on the same boundary, define epsilon=(1/2)||N-T||_diamond. Then there are CPTP maps E_+,E_- on that same boundary such that

    N - T = epsilon (E_+ - E_-),
    N <=_CP T + epsilon E_+.                              (3)

For epsilon=0 this means N=T. Importantly, (3) is an upper comparison, NOT a physical decomposition of N into an ideal component and a faulty component.

Proof. Put Delta=N-T, using unnormalized Choi matrices with output first. The channel-difference discrimination SDP is

    epsilon = min ||Tr_out Z||_infinity,
    subject to Z >= 0, Z >= J(Delta).                     (4)

This is Watrous, *Semidefinite programs for completely bounded norms* (2009), Section 4, author PDF printed pp. 14-15:
https://cs.uwaterloo.ca/~watrous/Papers/SDPforCBnorms.pdf

Choose an optimal Z. Let Phi_+ and Phi_- have Choi matrices Z and Z-J(Delta). Both are CP. Since Delta is trace-annihilating, they have the same input effect A=Phi_+^*(I)=Phi_-^*(I), with 0<=A<=epsilon I. Let L be any CP map with L^*(I)=epsilon I-A, for example L(X)=Tr[(epsilon I-A)X] sigma for a fixed output state sigma. Then epsilon E_+=Phi_++L and epsilon E_-=Phi_-+L are CP with effect epsilon I, hence E_+,E_- are channels. Their difference is Delta, proving (3).

Conversely, if N<=_CP T+epsilon E for a channel E, then E_-=(T+epsilon E-N)/epsilon is a channel. The triangle inequality gives ||N-T||_diamond<=2epsilon. Thus the least additive CP-majorant cost is EXACTLY the half-diamond distance. This equivalence is about additive upper domination only. It says nothing about an ideal CP minorant or a probability of an actual fault.

The decomposition is taken on D_i tensor B, so E_+ acts on that space and is identity on other active reservations. This locality of the construction is essential.

## 3. First-fault/erasure theorem

A slightly more general useful contract is

    N_ik <=_CP a_ik T_ik + b_ik E_ik,                    (5)

with a_ik,b_ik>=0 and E_ik a normalized local channel on the same boundary. Define, in the own chronological slot order,

    A_i = product_k a_ik,
    B_i = sum_k b_ik product_(ell<k) a_iell,
    g_i = A_i f_i + B_i.                               (6)

Then every selected subset obeys

    F_R <= [product_(i in R) min{1,g_i}] I.             (7)

For diamond errors, a_ik=1 and b_ik=epsilon_ik, giving (1). There is no product of (1+epsilon) within a parent.

Proof. First fix a finite circuit approximation of the supplied own-entry/retirement tester simulation. Traverse the actual chronology. Initially every selected parent is marked clean. At each imperfect slot of a still-clean parent use (5), replacing that positive circuit term by two positive terms. On its T branch multiply by a_ik and keep the parent clean. On its E branch multiply by b_ik and mark that parent erased. Never expand later imperfect slots of an erased parent: keep their actual normalized N maps.

At a parent's first E branch, drop its acceptance requirement and release its entire private tester, records, labels, and garbage to the joint prover. Equivalently remove that tester from the construction from the outset for this term. Its physical reservation, including all coherences, can be reconstructed as prover memory. Its E map and every later actual node can then be executed by that prover. They cannot flip any remaining tester's private parity because the other active full reservations are disjoint. Earlier ideal operations of the erased parent can also be simulated by the prover; discarding its outcome is an enlargement of the allowed strategy.

The nonerased parents have exactly their original independent reference testers. The joint prover may contain the entire bath and all erased systems, and is already allowed arbitrary correlations and causal adaptive processing. Positive causal domination from the supplied theorem bounds this term by the product of f_i over the nonerased parents. No conditional probability on another tester's future success is used.

A parent that is never erased contributes A_i f_i. A parent first erased at its kth slot contributes b_ik times its preceding a_iell factors, with no subsequent factors. Summing these possibilities factors across parents and gives product_i g_i. This grouping remains valid when the slots of different parents interleave.

Every substitution is a CP-order inequality inside a positive circuit, so summing and pairing with any initial state preserves the inequality. Uniformity over every input vector, including the bath/reference, gives the asserted full-input effect inequality. Norm-convergent circuit limits pass it to the original integrable dynamics just as in the source proof.

Finally let R' contain only i in R with g_i<1. The all-R event is contained in the all-R' event. Apply the same theorem to R', treating all other parents as prover-side physical dynamics. This gives the coordinatewise cap in (7), rather than merely capping the whole product.

The proof is an application of standard positive channel/strategy domination and first-fault grouping. No priority claim is made for those tools. Its specific output is the robust scheduled-memory interface with support separated from probability.

## 4. What different CP assumptions actually buy

These three contracts must not be conflated:

- Generic full-joint diamond error gives N<=_CP T+epsilon E and hence f+epsilon for one node. The comparison E is virtual. It is not an observed event and cannot by itself be charged as a support fault.
- Genuine mixture N=(1-r)T+rE gives an actual latent CP flag. Its one-node factor is (1-r)f+r. With multiple independent-at-the-map-level mixtures, or simply such uniform joint map identities at every slot, (6) gives

      1-(1-f) product_k(1-r_k).

  Shared bath action in E is allowed. An actually independent classical physical fault process is stronger than necessary; the displayed complete map identity is sufficient.
- Multiplicative domination N<=_CP lambda T gives factor lambda f, with no additive floor. It is much stronger and often impossible: Choi support of N must be contained in that of T. An arbitrarily small generic coherent rotation or population-changing error can violate this support inclusion.

A more general actual refinement N=G+F with G<=_CP T and F^*(I)<=rI supports a genuine good/fault event and the conservative factor f+r, after completing F/r to a channel. To use its good branch for support, G must obey the required syndrome/footprint/correctability contract. An upper majorant alone does not imply such a refinement.

For noisy entry/exit instruments, the same CP-majorant argument can bound events formed from their actual reported records if the reference instruments are exact and the replacement slots remain local. This does NOT make those noisy records trusted syndrome projections. Their support transfer needs an actual qualified good/fault refinement (charge faulty boundaries as full-parent faults), or a separate support proof. The main positive support theorem below retains actual exact endpoints.

## 5. Exact support despite arbitrary coherent internal refresh errors

Let C_i be the full propagated memory-error footprint for parent i. It contains its weak interaction footprint and every noisy data/control/reset footprint that can affect its data before completion. Assume C_i subset D_i, and (2). It is enough that the actual Kraus operators throughout the parent lie in the stabilizer-dressed local module

    span{ E g tensor B : E in Pauli(C_i), g in G_i, B a bath operator },

or in the analogous module with exact code-stabilizer factors already admitted by the original support proof. In particular any arbitrary channel on C_i tensor B has the required Pauli expansion. Exact Schur channels have stabilizer-algebra Kraus factors and are also admitted. Noise propagating through non-Pauli controls must be included in C_i; an elementary-gate footprint is not automatically a propagated footprint.

Fix every genuine classical record and every actual Kraus/environment index, without normalizing the branch. Expand the weak and noisy-node operators in memory Paulis on C_i, keeping all bath coefficients in their original chronological order. Exact stabilizer-algebra factors act as scalars or zero on each encoded Pauli-history sector. Products of the remaining parent memory Paulis remain supported on C_i. Move only those memory factors across operations on disjoint concurrent reservations; never reorder bath factors.

The actual exact entry and final projections imply, term by term,

    syndrome_Gi(E_i) = t_i xor r_i.                     (8)

On an endpoint-good parent the right side is zero, so (2) makes E_i a code stabilizer up to phase. It acts as a scalar on each encoded Pauli orbit, independently of the logical vector. Thus that parent adds no support birth, even though its actual internal noise may be coherent, bath-dependent, population-changing, and non-Schur.

For an endpoint-bad parent, any two Pauli terms with the same (8) differ by a Pauli on C_i commuting with G_i, hence by a code stabilizer under (2). Choose one patch representative for each realized syndrome difference, and set the zero representative to I. The original common-decoder support-history proof then applies with C_i in place of the old A_i. Actual endpoint records select complete CP branches. Summing those branches is a genuine TNI good subchannel with a CP complement; no virtual majorant-error label is used.

All geometric charges, conflicts, full reservations, pending prefixes, terminal strip rules, reset and measurement durations remain. If C_i is larger than the old A_i, check or recompute the patch representative charge and all conflict/guard constants even if C_i was already physically inside D_i. The original REPORT explicitly exempted D_i\A_i from condition (2) only because those extra operations were exact. Arbitrary faults remove that exemption.

This theorem is about encoded-input/common-decoder support. The subset-effect theorem remains uniform on the complete physical input and does not require it to be initially encoded. These are separate claims, as in the supplied framework.

## 6. Staggered lifecycle and records

The own-entry/retirement construction is unchanged for every nonerased tester: it begins with a private good bit only at its own actual entry; its physical input is initially prover-side; it retires only after the actual final syndrome instrument. Later reuse and record-controlled operations occur on reconstructed physical data. Generated records are retained in the complete causal strategy and never treated as independent input randomness.

In a CP-majorant branch where a parent is erased, it may be removed from the tester system entirely. Its eventual record is unconstrained for the upper bound, but all remaining parents still receive their real input through their own future entry instruments. A fault can contaminate a later-reused patch or the bath; those are arbitrary inputs already covered by the later tester. What it cannot do under the stated contract is directly access another currently active private reservation or its ideal refresh environment.

For a nontranslation-invariant Schur reference, use f_i=max_r F_(C_i^(r)) and a uniform defect over the classical entering-label control. For independent-generator Schur kernels, translation symmetry removes that max as in the supplied audit. No generated-label averaging is inserted into the product.

## 7. Exact obstructions and sharp distinctions

### 7.1 Marginal closeness permits a common rare catastrophe

Take n syndrome qubits initialized good, ideal complete Z dephasing, no weak actions, and a persistent classical bath bit B with Pr(B=1)=epsilon. At every parent's own node, dephase and then apply X_i iff B=1, preserving B. Each reduced single-qubit channel at this bath preparation is

    (1-epsilon)D_Z + epsilon Ad_X D_Z,

with half-diamond distance epsilon from D_Z. Nevertheless all n endpoint flags are bad with probability epsilon, not epsilon^n. The full joint channel on qubit i plus B has distance ONE from D_Z tensor id_B, witnessed by input B=1. Thus it fails the actual joint contract, despite perfect marginal calibration and arbitrarily small epsilon.

### 7.2 Full-joint small error without influence locality also fails

A single slot N=(1-epsilon)T+epsilon Ad_(X_1 ... X_n) T has full half-diamond distance epsilon from T (orthogonal outputs witness equality) and makes all initially-good coordinates bad with probability epsilon. A defect touching n reservations cannot be charged epsilon separately to n parents. It must be a joint/hyperedge fault, a declared conflict, or grouped into one larger tester. A uniform per-parent epsilon^n claim would force a fictitious local rate at least epsilon^(1/n).

### 7.3 Syndrome-invisible coherent logical error

Use a syndrome qubit S, an untouched logical qubit L, code stabilizer Z_S, and old weak footprint A={S}. Its old full-footprint condition holds. Let the ideal node be D_ZS tensor id_L and actual node

    N = D_ZS tensor Ad_(U_theta),
    U_theta = exp(-i theta X_L), 0<theta<pi/2.

With no weak actions and exact entry/final projections, every endpoint flag is good. Yet the actual logical channel is U_theta, and its full half-diamond distance from the ideal node is sin(theta), arbitrarily small. Its actual footprint contains L, and the enlarged condition (2) fails precisely because X_L is an undetected logical.

Moreover, after restricting to the good encoded syndrome, the channel is a unitary channel with rank-one Choi matrix |U_theta>><<U_theta|. Every CP subchannel below it is proportional to that same ray. The ideal identity Choi ray is distinct. There is therefore NO nonzero identity CP subchannel below the actual logical channel. A decomposition into an exact old-decoder-good CP piece of weight 1-O(epsilon) and a small bad CP piece does not exist. This is relative to the stated common decoder/support certificate; it does not claim a known isolated unitary could never be actively inverted by a different authorized recovery.

For U=cI-isX, in the normalized vec(I),vec(X) basis,

    det[J(Ad_U)-a J(Id)] = -4 a s^2 < 0  for every a>0.

This explicitly disproves N>=(1-r)T for every r<1, even while N is arbitrarily diamond-close to T. It also disproves finite multiplicative upper domination by T.

A stochastic logical flip variant gives actual logical error probability epsilon with all flags zero, but the coherent rank-one version makes the no-CP-minorant obstruction stronger.

### 7.4 The additive local floor cannot be removed

For f_i=0, independent actual channels (1-epsilon_i)D_Z+epsilon_i Ad_X D_Z satisfy the complete local contract and have all-bad probability product_i epsilon_i. Thus a generic diamond-robust theorem must allow a local epsilon_i floor; replacing it by o(epsilon_i) is false.

### 7.5 Compiled Pauli endpoints do not make baseline drift free

The separately checked finite_pulse_obstruction/PROOF.md supplies a fully finite two-qubit witness. G=<ZZ,XX>, good state Phi+, baseline H0=J(I-XX)/2, control Hc=(Omega/2)(Z1+Z2), duration tau=pi/Omega, and J=sqrt(5) Omega. H0 preserves every stabilizer and has zero old coarse-odd action. Without H0 the control endpoint is -ZZ. With H0, the pulse branch leaves the good sector with probability 4/9; a private fair pulse/no-pulse choice gives 2/9, versus ideal refresh value zero. In the Phi+/Phi- subspace the Hamiltonian is [[0,Omega],[Omega,J]], making the calculation elementary. The intermediate pulse path, unlike its final Pauli product, does not preserve the full good sector.

This is a counterexample to charging only the original odd interaction during an arbitrary compilation, not a lower bound against every optimized pulse path. It shows why the next qualification must include path-noncommuting baseline terms.

## 8. A sufficient finite-pulse qualification route

For a genuine local finite operation with a fixed complete input/output boundary, suppose a common dilation compares the actual branch b to a reference branch through a residual Hermitian generator K_b(t), with

    delta_b = integral ||K_b(t)|| dt.

The Fubini-Study angle between the two dilated pure outputs is at most delta_b, uniformly on input plus reference. Pure-state trace distance is the sine of that angle; contraction under discarded environments gives

    (1/2)||N_b-T_b||_diamond <= sin(min{delta_b,pi/2}).  (9)

For a genuinely private independent seed with weights w_b, convexity gives epsilon<=sum_b w_b sin(min{delta_b,pi/2}). The simpler epsilon<=min{1,max_b delta_b}, or a correctly weighted linear bound, is also valid. A phase multiple of the identity may be removed from K_b; a bath evolution may be removed only if the same permitted reference continuation accounts for it. Average fidelity, T1/T2, or a reduced coherence multiplier do not upper-bound delta_b.

For a physical hidden I/S pulse, K_b must include control residuals, leakage, bath-boundary couplings, and every baseline term that fails to commute with the WHOLE ideal pulse path. It is generally not the old coarse-odd part of the drift. Ancillas that retain or later reveal the seed belong to the process boundary or must be proved isolated. A virtual Pauli-frame update is not the physical random unitary.

There is a narrower sufficient primitive-local route even with concurrent other-parent evolution. Suppose the ideal control path C_i,b(t) acts only on D_i; the retained free baseline commutes with every active C_i,b(t); other-parent interactions act on their disjoint reservations plus B; and all offending drift during i's pulse can be assigned as Hermitian K_i(t) supported on D_i tensor B, with a uniform bound integral ||K_i(t)||dt<=delta_i. Joint terms touching multiple reservations must instead be grouped/conflict-charged. Reference seeds are private independent, and any seed dependence of K_i is confined to i and uniformly bounded.

First change frame using only the known LOCAL ideal control paths, the product of active C_i,b(t), controlled by their own private seed registers. Do NOT use the full interacting global propagator. The reference baseline is unchanged by the stated path-commutation assumption. Other-parent terms are unchanged because their memory supports are disjoint and the control paths do not act on B. Each offending term becomes C_i,b(t)^dagger K_i(t) C_i,b(t), still on D_i tensor B and i's own seed/controller, with exactly the same norm. All own noncommuting weak drift during the pulse is included in K_i; it is not left as an uncharged reference term. Resetting this mathematical control frame at the end of the pulse gives the intended instantaneous S_i^b endpoint. In the no-defect reference, averaging the independent private seeds therefore realizes the stipulated Schur node, with seed-independent allowed dynamics between nodes.

Now time-slice this LOCAL toggling-frame model before compressing any whole window. Trotter-split each transformed perturbation from the reference evolution. Its primitive unitary channel has half-diamond distance at most ||K_i||dt+o(dt) from the identity, uniformly on D_i,B and i's private controller. The primitive reference identity neither accesses nor changes that private seed. Apply Section 3's first-fault expansion to these primitive slots, grouped by parent. At a first fault, erase that parent's entire private controller and data as well as its tester. All other private seed registers stay private. Surviving testers are precisely the stipulated ideal node testers in the already-transformed reference; no later commutation of control paths through an arbitrary enlarged prover is assumed. The norm-convergent Trotter limit gives local additive charge delta_i, together with any other slot charges.

This is a sufficient restricted construction, not a qualification of arbitrary concurrent finite-width gadgets. If the baseline cannot be decomposed this way, a whole-window full-system diamond estimate does not automatically preserve local factors: in an interaction picture a perturbation can spread through other active odd couplings. One must provide a local portwise/strategy comparison, group the influence region, or change the schedule.

## 9. Practical next gate

The next experimentally meaningful deliverable is an explicit, confidence-bounded COMPLETE operation/process contract containing:

1. Exact typed input/output systems, persistent bath/controller/ancilla inventory, and which environments are truly discarded. Single-time reduced tomography cannot certify no future return.
2. A local full-joint or appropriate portwise bound epsilon_ik, or a bounded primitive-local residual action. A model-based locality/isolation argument is required; do not infer it from average gate fidelity.
3. The propagated footprint C_i for every actual noisy pulse, measurement/control path and crosstalk term, with the algebraic test (2). A larger C_i may change every geometry and resource constant.
4. Actual trusted entry/correction and final syndrome instruments, or a genuine CP qualified good/fault refinement for their failures. Small instrument diamond distance alone does not make outcomes trustworthy for support.
5. Fixed chronological interfaces and enough reset/measurement time in the reservation; no adaptive outcome-selected geometry or omitted unfinished boundary.
6. A numerical comparison of the local imperfection charge with the intended f_i. To retain leading ideal rare-event scaling, sum_k epsilon_ik must be small relative to f_i. To resolve refinements of order p_i q_i in the exact Schur optimization, uncertainty must be smaller still; a high-dimensional Schur reconstruction cannot repair a larger device error floor.

The 2011/2024 physical-refresh leads inspected in physical_refresh_interface/REPORT.md do not presently supply these inputs. No threshold or hardware lifetime follows from this theorem alone.

## 10. Inputs, verification, and limitations

Read inputs:
- general_schur_refresh_audit/PROOF.md: exact Schur singleton and tester embedding.
- memory_support_transfer_audit/AUDIT.md: actual endpoint event, own-entry/retirement, support transfer.
- measurement_randomizer_bridge/REPORT.md: original complete-footprint/common-decoder argument and resource caveats.
- physical_refresh_interface/REPORT.md: empirical missing qualification.
- finite_pulse_obstruction/PROOF.md: independently rechecked finite control witness.

check_exact.py performs exact SymPy channel/Choi and support-counterexample checks and finite-pulse algebra. The proof, not those finite examples, establishes the general theorem. A separate internal reviewer checked the half-diamond constant, coordinatewise cap, erasure locality, and first-fault sum; this is not external validation.

The underlying strategy-norm domination is also established prior art: Gutoski, *On a measure of distance for quantum strategies* (2010), https://arxiv.org/abs/1008.4636 . A full portwise application must preserve the relevant local interfaces; this note does not equate terminal channel distance with multiround strategy distance.
