# Conditional transfer to the measured scheduled-memory interface

Date: 2026-10-16. Local mathematical audit; no hardware or threshold claim.

## Verdict

A literal replacement of the partial-boundary theorem's ANY-block-mismatch constant by the new one-node endpoint F_K is false. An exact counterexample is below. There are nevertheless two valid conditional improvements:

1. Complete internal syndrome pinchings, including the successful cuts in the old independent latent-pattern refinement: replace the old capped sum of squared block actions by Q = 1 - product_B cos^2(min(a_B, pi/2)), keeping its ANY-block-mismatch predicate.
2. One scalar full-syndrome partial-pinch node: change the parent predicate to entering-versus-final full-syndrome mismatch, retain actual exact entering and final syndrome pinchings, and use F_K on this new CP refinement. The original REPORT support proof extends to this endpoint-based refinement. This changes the certificate, not the physical channel.

Both need the own-entry/retirement embedding described below. The common-initial-time projector theorem alone is not a proof of either full-input scheduled-memory claim.

## A. Exact obstruction to unchanged-event substitution

Use a memory syndrome qubit with stabilizer Z and an untouched logical spectator. The weak footprint is the syndrome qubit, so its commuting Paulis are I and Z and the full-footprint/no-local-logical condition holds. Enter in |0>, apply U=exp(-i pi X/6), then T=(Id+D_Z)/2, then U, and perform the actual final Z pinching. Correction is identity. All resources may be reserved in one clean parent.

The stipulated channel has its old canonical independent skip/complete-pinch refinement. On a retained middle pinch, the event of at least one block mismatch has probability 1-(3/4)^2=7/16. On a skipped middle pinch, the sole block mismatch probability is sin^2(pi/3)=3/4. Thus the OLD parent event has probability 19/32.

The new binary endpoint formula gives F_1(pi/6,pi/6,1/2)=9/16=18/32. Indeed the actual endpoint mismatch probability is (1/2)(2(1/4)(3/4))+(1/2)(3/4)=18/32. The omitted 1/32 consists of retained-pinch paths that leave and return to the entering syndrome. They are bad in the old event and good in the new endpoint event. Consequently F_1 cannot bound the old event even for a single parent and trivial bath.

This is not a controller, geometry, or logical-error counterexample. It isolates exactly the predicate mismatch.

## B. Scheduled interface that must be retained

Use the actual assumptions of REPORT.md and the qualified boundary channels of PARTIAL_DEPHASING_BOUNDARY_THEOREM.md:

- Exact trusted entering-sector preparation/refinement AFTER the prescribed exact correction; its label r_i is genuinely supplied by the existing premeasurement and intended Pauli correction, or an actual postcorrection pinching.
- Actual full-syndrome final pinching at the parent's completion; later physical reuse occurs only afterward. Outcomes can be latent if their reservoirs are isolated and unused, as qualified by UNREAD_MEASUREMENT_REFINEMENT.md.
- Fixed/exogenous parent windows, nodes, groups, and action envelopes. Geometry selection is independent of all selected private refresh noise. No adaptive outcome-selected schedule is silently fixed by conditioning.
- All concurrently active selected parents have disjoint FULL reservations, not merely disjoint weak footprints. Bath sharing remains unrestricted.
- Each V_i acts on its entire weak footprint A_i and bath, with integrated envelope a_ik. Full-footprint condition Pauli(A_i) intersect Centralizer(G_i) subset phase times S_code remains necessary.
- Extra internal discarded measurement/dephasing environments are inaccessible to all later controls. Initial and completed trusted records may drive later fixed classical controls. No normalized generated-record conditioning is used in the subset-effect theorem.
- All actual boundary reservoirs are fresh and independent where a product of their scalar pattern averages is claimed. Actual channel identities hold jointly with the persistent bath/reference.

The coarse parity for an ACTIVE parent is Z_i(r_i)=2P_(i,r_i)-I. Regard immutable r_i as a classical control register. Different active coarse parities commute because their full physical reservations are disjoint. Split

    V_i^odd = (V_i-Z_i V_i Z_i)/2,
    V_i^even = (V_i+Z_i V_i Z_i)/2.

The odd term is own-odd and other-even, and ||V_i^odd||<=||V_i||, so no action is increased. All even terms, bath dynamics, and allowed remote operations preserve every active coarse parity. The K_i other full G_i syndromes refine the coarse bad sector. Here K_i is the number of nonzero syndrome sectors other than r_i (at most |G_i|-1); padding may retain empty sectors if desired, which only weakens the bound.

The scalar full-group node eta Id+(1-eta)D_G is therefore exactly the fine-sector node in the new multisector theorem. Generic independent-generator dephasing is NOT that scalar channel; do not use F_K for it. Section G below supplies the separate general-Schur reduction.

## C. Own-entry and retirement reduction to independent causal testers

Initialize all mathematical tester bits A_i in |0> at one common initial time, while placing the ENTIRE actual input memory, persistent bath, and any reference on the prover side. Dormant testers have no charged rotations or acceptance opportunities. They do not purport to describe the physical syndrome before their own entries.

At entry i, implement the actual entering instrument and correction on the prover's physical data, retaining its genuine classical record. It acts block diagonally in every already-active tester parity because its full reservation is disjoint from theirs. On its resulting r_i branch, physical data lie in P_(i,r_i). Choose a sector-coordinate isometry identifying this good physical sector with tester A_i=0 and an auxiliary sector space. Equalize dimensions by finite padding, as in the source unchanged-action proof. Since a new reservation commutes with all active coarse parities, these identifications can be chosen separately within their joint sectors; changes of coordinates are block diagonal in all previously active bits. Thus entry needs no rotation of A_i and consumes no odd action. It does not normalize or postselect the r_i branch: implement the complete entering instrument with all records in the prover dilation.

More explicitly, for a full reservation D_i and entering label r, choose fixed isometries e_(i,r,0):P_r H_(D_i)->E_i and e_(i,r,1):(I-P_r)H_(D_i)->E_i into one common sufficiently large sector space. Define the coordinate embedding

    e_(i,r) psi = |0>_Ai e_(i,r,0) P_r psi
                  + |1>_Ai e_(i,r,1) (I-P_r) psi.

The two ranges in E_i need not be disjoint because A_i separates them. At entry, only the first summand is occupied, so the prover applies e_(i,r,0) to its physical sector and the already-private |0> is unchanged. While active, the padded embedded dynamics leave the physical embedded subspace invariant. At retirement the actual postpinching supplies a classical t and hence b=1[t!=r]. The prover applies the inverse of e_(i,r,b) on its occupied sector space, controlled on the classically copied b, reconstructing D_i without accessing the now-terminal private bit. An isometric extension handles unused dimensions. The original physical tensor factor D_i can then be used again. Concurrent active D_i factors are disjoint, so take tensor products of these local embeddings, tensor identity on all remaining physical data, and retain completed classical bits separately. When parent footprints overlap only at different times, the prior inverse has already reconstructed the physical tensor factors before the next local embedding. This gives one explicit representation through the entire chronology without any future-record conditioning.

While i is active, use the source copy/prover/uncompute interface to implement every joint-coarse-diagonal propagator. Simulate each V_i^odd by the source equal-dimensional contraction decomposition and Lie-Trotter limits, with exactly its old own-gap action. Keep all prescribed actual nodes in chronological order. Fine-sector nodes use PRODUCT_EMBEDDING_AUDIT.md's W / local-label pinch / W-dagger construction; both W gates preserve every active coarse parity. The fine label is returned to the prover only after the tester's isolated node channel, while its discarded noise environment stays private. The honest simulator implements the entire joint channel including arbitrary reference entanglement, not just a marginal probability.

At actual final full-syndrome pinching, record the tester's coarse endpoint bit. The honest simulator may send a classical copy of this completed bit and its fine syndrome label to the prover, matching the actual protected controller record. This is AFTER that tester's acceptance decision; no subsequent operation changes it. Physical data can now be represented entirely in prover memory again, controlled on the classical endpoint label. There is no cloning of parity coherence: the actual final pinching has removed it. Future physical reuse and arbitrary subsequent controls act on this reconstructed data, leaving the tester's saved decision untouched. They can affect later testers, as an arbitrary joint causal prover already may. A later parent receives its own fresh private tester bit at its own entry.

This construction is a time-dependent sector-coordinate representation, not an added physical preparation, randomizer, measurement, or bath reset. Each change of coordinates at entry/retirement preserves all other active private parities. Full output records and conditional bath maps are preserved in the honest simulation. All finite padding and approximation steps are mathematical only.

To formalize with fixed registers, preallocate all private bits, all classical entry/exit records, and sufficiently large auxiliary sector spaces. Each entry instrument is a parity-preserving isometry on prior active coordinates; each retirement isometry is controlled on the already-classical endpoint label. Extend these isometries on unused padded spaces. On the reachable subspace they implement exactly the physical process; outside it the enlarged prover is arbitrary. Acceptance operators remain tensor products of LOCAL tester decisions. This supplies the independent-tester premise missing from a bare common-initial-sector theorem.

For any fixed complete input vector |psi> on the original memory-bath-reference, the honest simulator is one compatible joint-prover strategy. Positive causal domination therefore gives Pr(all selected accept)<=product_i p_i. Its uniformity over |psi> implies the full-input effect inequality F_R<=product_i p_i I. No initial syndrome restriction on the physical input, initial product-state assumption, normalized branching, or conditional-on-other-success estimate appears.

## D. Complete pinchings: same history event and improved Q

For a fixed successful-boundary pattern, set a_iB to the sum of old weak actions in each merged block. At every successful full-syndrome cut, tester i can privately set a permanent flag if its coarse bit relative to the ORIGINAL entering r_i is 1. The event of any successive full-syndrome mismatch is exactly the event that at least one such sampled syndrome differs from r_i. Before the first difference, the private parity is good; the full conditional auxiliary/bath state is arbitrary. Each next gap has mismatch probability at most s_iB=sin^2(min(a_iB,pi/2)). Therefore no mismatch probability is at least product_B(1-s_iB), and each arbitrary single-tester strategy's flag acceptance is at most

    Q_i(pattern)=1-product_B cos^2(min(a_iB,pi/2)).

This proof works for full fine pinchings, not only binary ones. A skipped stabilizer-algebra remainder is retained as an actual parity-preserving intervention; it is not replaced by identity. Tensor causal domination yields the product Q_i for the SAME old history event. It is sharper than min(1,sum_B a_iB^2).

Averaging independent parent pattern families gives p_i=E Q_i(pattern). Fully partial endpoints still require the old conservative charge:

    p_i=1-q_in,i q_out,i + q_in,i q_out,i E Q_i(pattern).

Endpoint-failure branches use the trivial bound and full-parent support charge. These scalar pattern averages require exactly the old independence assumptions, and do not apply to merely matching marginal boundary channels.

## E. One partial full-syndrome node: new endpoint predicate

With actual exact entering and final pinchings, one internal scalar node eta_i Id+(1-eta_i)D_Gi, and pre/post action budgets a_i,b_i, use the multisector formula F_Ki(a_i,b_i,eta_i) and define

    b_i^end = 1[t_i != r_i].

The own-entry/retirement tester reduction proves the full-input subset effect with product_i F_Ki. Intermediate latent labels can be kept in a complete Kraus refinement, but they are NOT part of this bad predicate. The binary F_1 is generally wrong for K_i>1.

Why this new predicate still supports a good CP subchannel: fix every actual/latent Kraus label and expand all weak insertions in memory Paulis, retaining all bath factors in their original chronological order. Internal stabilizer-algebra Kraus operators (I or P_s for scalar partial pinchings) act scalar or zero on each encoded Pauli-history sector. A parent's net weak memory Pauli E_i is supported on A_i; its actual endpoint projections force syndrome_Gi(E_i)=t_i xor r_i. On a good endpoint branch E_i therefore lies in the full-footprint centralizer and is a code stabilizer up to phase. It acts scalar on every encoded Pauli orbit and adds no completion support. On a bad branch use the same bounded patch representative/support charge as REPORT.md. Concurrent other memory operations commute by full-reservation disjointness; never reorder shared-bath coefficients.

Consequently the common support-history decoder works on the new endpoint-good records. Summing these COMPLETE actual-channel Kraus branches gives a genuine TNI CP good subchannel and its CP complement, even though some paths that leave and return are now good. This is a reproof of the support implication for a coarser predicate, not an inequality between the old bad effects.

If endpoints are only qualified mixtures, condition on their independent complete-pinch components and charge failure exactly as before, replacing the conditional internal constant by F_K. Do not call that expression an endpoint mismatch probability on failed-endpoint branches; it is a conservative latent event.

## F. Cost and limits

No additional physical operation is needed for either improvement when the old actual endpoint pinchings and qualified internal channels are already present. All original total durations, reset, controller, full-generator reservations, dirty/pending rules, terminal-strip treatment, and geometry constants remain charged. If changing the implementation or boundary duration, recompute them. These improved scalar parent budgets may enter the old conditional contour/common-decoder composition only after all those unchanged imports are checked.

If an entering sector refinement or final full-syndrome pinching is absent, it cannot be inserted mathematically. The minimum missing operation for this transfer is the corresponding actual qualified full-syndrome boundary channel (or a separately proved equivalent preparation at entry). A final decoder later in time cannot substitute before intervening interactions/reuse. If actual intermediate outcomes control schedules or environments return, the tester independence/interface needs a new proof rather than these constants. If reservations overlap, the own-odd/other-even splitting need not hold: classify a conflict or qualify a different interface.

No numerical threshold, noisy detector qualification, autonomous controller, or physical lifetime is proved here.


## G. Narrow extension: one actual general-Schur node

The prerequisite general_schur_refresh_audit/PROOF.md proves the two-gap endpoint value for the specified full-joint channel

    T_C(X)=sum_(j,k) C_jk P_j X P_k,
    C positive semidefinite, C_jj=1.

Its node environment must be inaccessible and independent across parents; the node is at a fixed exogenous time. This section does not identify a finite-width noisy operation with that channel. Keep all actual entering/final syndrome boundaries and the endpoint predicate of Section E.

For an entering syndrome r, relabel the sectors by a permutation pi_r with pi_r(0)=r, and put C^(r)_jk=C_(pi_r(j),pi_r(k)). Write

    C^(r) = [[1,c_r†],[c_r,B_r]],
    p=sin²(min(a,pi/2)), q=sin²(min(b,pi/2)),
    Q=p+q-pq, h=sqrt(pq(1-p)(1-q)).

The applicable endpoint constant is

    F_(C^(r))(p,q)
      =Q+max_(||z||_1<=1) [2h Re(c_r†z)-pq z†B_r z].

For a general nontranslation-invariant specified C, use the UNIFORM parent constant

    f_i=max_(possible entering r) F_(C_i^(r))(p_i,q_i).

The entry outcome cannot simply be fixed by normalized conditioning and then averaged as if independent across parents. A precise independent-tester implementation first receives and measures a classical r message at entry, saves that immutable local label, and later applies the fixed controlled family of local Schur channels indexed by r. The honest prover sends the actual r. Even an arbitrary prover can do no better than max_r F_(C^(r)): conditional on its chosen entry r, the tester starts good with an arbitrary bath/reference and obeys the stated two-gap singleton theorem. Keeping that choice fixed locally prevents later adaptive kernel changes. This is one fixed independent tester per parent, so causal all-pass domination gives the full-input product_i f_i, without conditioning away correlated generated records. This argument assumes the prescribed action envelopes and node schedule are uniform/fixed as in Section B, not retrospectively record-selected.

For independent binary-generator dephasing with labels in {0,1}^m and qualified coherence multipliers eta_a, the ACTUAL Schur kernel is

    C_jk=product_a eta_a^((j xor k)_a).

Taking pi_r(j)=j xor r leaves C invariant. Therefore f_i=F_(C_i), without a max penalty or any assumption that the entering syndromes are independent. This directly uses the actual generator-wise channel, not a scalar identity/full-group-pinch surrogate. It has K_i=2^m-1 bad fine sectors when all generator labels are present. The general constrained optimization may cost exponentially in m; the source proves no generic polynomial-in-generator-count evaluation algorithm.

The label W / local-Schur / W-dagger identity in the source is a complete joint-channel identity with J reset, so it plugs into Section C unchanged and adds no odd action. The support proof also survives: take a Gram/Kraus factorization C_jk=sum_l d_(l,j) conjugate(d_(l,k)). The actual node has Kraus operators L_l=sum_j d_(l,j)P_j, all in the code-stabilizer algebra. On a definite encoded Pauli-history sector each L_l acts as a scalar, possibly zero. Thus fixed endpoint-good Kraus records still have net patch Pauli in Centralizer(G_i), with every bath coefficient kept chronological. The same common-decoder good CP construction applies. Unlike the scalar skip/pinch case, this proof does not invent a latent middle full-pinch record or any ANY-block-mismatch event.

If actual endpoints have only the independently qualified complete-pinch mixture components of the old theorem, charge their failure and use

    p_parent=1-q_in q_out+q_in q_out f_i

on the successful-endpoint component. All independence, support, duration, reservation, and pending rules remain as in Sections B and F.

This corollary imports the general-Schur singleton and auxiliary-label product proofs. It establishes a conditional scheduled endpoint-effect/support interface only. No arbitrary marginal decoherence calibration, uncontrolled concurrent boundary noise, noisy detector circuit, controller qualification, threshold, or new physical operation follows.
