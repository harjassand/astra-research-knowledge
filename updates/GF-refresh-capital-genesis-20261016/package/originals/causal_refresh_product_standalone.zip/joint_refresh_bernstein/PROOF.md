# Finite-action joint parity bounds via Bernstein's inequality

Date: 2026-10-16. Independent bounded mathematical investigation. No repository code was executed or edited, and no external communications or changes were made.

## Findings

1. **The two-coordinate one-gap product is true and sharp:** the all-flipped effect is at most `sin²(min(a₁,π/2)) sin²(min(a₂,π/2))` times the initial-sector projector, for arbitrary finite shared baths and the stated cross-parity commutation assumptions.
2. **The full product `∏ᵢQᵢ` is true and sharp for synchronized pinch schedules**, for any finite number of selected coordinates and common gaps. The proof bounds the stronger event that every coordinate has at least one recorded mismatch.
3. **The full product `Q₁Q₂` is also true and sharp if either coordinate has no internal pinch**, while the other has any finite fixed schedule.
4. For arbitrary, possibly asynchronous schedules, the original deletion-null argument improves rigorously to the product of the individually capped sums of gap sine-squares. This does **not** prove the desired product `Q₁Q₂` in that remaining case.

No counterexample to the full asynchronous product was established. No numerical observation is used as a proof.

All upper bounds hold for every admitted finite bath. Sharpness/minimax statements take the supremum over the arbitrary-finite-bath uncertainty class; they do not assert attainability in each separately fixed smaller bath space.

**Priority and implementation limits.** The Bernstein inequality is classical. This report supplies a transfer new to the inspected packet, not a claim of historical novelty; no exhaustive prior-art search was performed. The synchronized theorem concerns the stipulated ideal complete-pinch model and its qualified private-sign averaged-channel representation. It supplies no finite-width pulse model, noisy-controller qualification, scalable hardware construction, or uncharged simultaneous-control capability.

## Contract

Let `Z₁,Z₂` be commuting Hermitian involutions on a finite joint memory/bath space. A reference may be tensored throughout. Let

`H(t)=H₀(t)+V₁(t)+V₂(t)`,

where `[H₀,Zᵢ]=0`, `{Vᵢ,Zᵢ}=0`, `[Vᵢ,Zⱼ]=0` for `i≠j`, and `||Vᵢ(t)||≤jᵢ(t)`, with nonnegative integrable envelopes. We need a well-defined sector-preserving unitary propagator for `H₀`; no smallness bound on it is needed. The bounded integrable perturbations then have their usual Dyson propagators. Initial states are supported in a specified joint sector `P_s`.

Internal operations are only the prescribed complete pinches, or fixed dilated operations that preserve the same deletion property. Their timing and coefficients do not depend on selected private signs. Record spaces below are mathematical Stinespring output spaces, not measured feedback available to the Hamiltonian.

Write `s(a)=sin²(min(a,π/2))` and `Qᵢ=1−∏ₖ(1−s(aᵢₖ))`.

## 1. A scalar-to-operator sine lemma

**Lemma.** Let `F(z)` be an entire function with values in finite-dimensional operators (rectangular operators are allowed), of exponential type at most `σ`, with `sup_{x∈R}||F(x)||≤M`, and `F(0)=0`. Then for real `t`,

`||F(t)||≤M sin(min(σ|t|,π/2))`.

Here “type at most σ” can be checked by `||F(z)||≤Cε exp((σ+ε)|z|)` for every positive ε. The growth prefactor may depend on other parameters held fixed.

**Proof.** For fixed unit vectors `u,v` and a phase θ, let `f(z)=e^(−iθ)⟨u,F(z)v⟩` and let

`g(z)=(f(z)+overline(f(overline(z))))/2`.

This is a real entire function of the same type, bounded in absolute value by M on the real axis, with `g(0)=0`. The sharp real Bernstein inequality is

`g'(x)²+σ² g(x)²≤σ²M²`.

Integration of `|(arcsin(g/(M+ε)))'|≤σ`, followed by ε decreasing to zero, gives `|g(t)|≤M sin(σ|t|)` for `σ|t|≤π/2`. Choose θ so that `g(t)=|⟨u,F(t)v⟩|`, and take the supremum over unit vectors. Outside this interval use the real-axis bound. The cases M=0 and σ=0 follow by constancy/continuity.

**Verified primary mathematical source.** R. M. Redheffer, “On a theorem of Plancherel and Pólya,” *Pacific Journal of Mathematics* 3 (1953), 823–835, Theorem 11 on p. 832, with its proof continuing on p. 833. It states the squared function-plus-derivative inequality for real entire functions of exponential type bounded on the real axis. Theorem 10 gives its stronger complex-plane form. These are credited there to Duffin, Schaeffer, and Boas.

https://msp.org/pjm/1953/3-4/pjm-v3-n4-p11-s.pdf

The argument above uses the classical inequality and supplies the endpoint-phase/dual-functional reduction needed for complex operator amplitudes. It does not incorrectly apply the sharpened real inequality directly to complex derivatives.

## 2. Why the Hamiltonian amplitude has the required entire type

On one gap put

`H(z₁,z₂;t)=H₀(t)+z₁V₁(t)+z₂V₂(t)`.

The Dyson series in the interaction picture of H₀ is locally uniformly convergent in the complex parameters, so the propagator is entire. To bound the type in z₁, fix z₂=y real and write z₁=x+iv. The real part `H₀+xV₁+yV₂` has a unitary propagator. In its interaction picture, the extra generator is `v V₁` rather than a skew-adjoint term; its norm growth is at most `exp(|v|a₁)`, where `a₁=∫j₁`. Consequently

`||U(x+iv,y)||≤exp(|v|a₁)`.

The analogous statement holds for z₂ with the other parameter fixed real. Thus taking one real scale to 1 does not change the exponential type in the remaining scale. No commutation between the bath operators has been used. Arbitrarily large real scales are legitimate proof parameters because the corresponding Hamiltonians remain Hermitian.

For multiple pieces separated by fixed record isometries, the same bound multiplies over pieces. If one variable scales Vᵢ only on one chosen own gap, its type is that gap's action; if it scales Vᵢ everywhere, its type is the total action. Fixed isometries and output projectors have norm at most one.

## 3. Sharp two-coordinate one-gap theorem

Let `P_flip` select both parities opposite to the entering sector and define

`F(z₁,z₂)=P_flip U(z₁,z₂)P_s`.

For real z₁,z₂, `||F||≤1`. Deleting V₁ preserves Z₁, so `F(0,z₂)=0`; similarly `F(z₁,0)=0`. The first identity holds even for complex z₂ because every remaining term still preserves Z₁ algebraically.

Fix any real y. Applying the sine lemma in z₁ gives

`||F(1,y)||≤sqrt(s(a₁))`.

This bound is uniform over the **whole** real y-axis. Now view `F(1,z₂)` as an entire function of type at most a₂, bounded on that axis by `sqrt(s(a₁))`, and zero at z₂=0. Apply the lemma again:

`||P_flip U P_s||≤sqrt(s(a₁)s(a₂))`.

Squaring gives the operator-effect inequality

`P_s U†P_flip U P_s≤s(a₁)s(a₂)P_s`.

**Sharpness.** Take two physical qubits, no bath, `H₀=0`, and independent commuting drives `Vᵢ(t)=jᵢ(t)Xᵢ`, stopped once their accumulated action reaches π/2. Starting in 00, the double-flip probability is exactly `s(a₁)s(a₂)`. This works for unequal, overlapping, or nonoverlapping envelope supports. It is independent of any private signs.

The same induction gives a product of sine-squares for any finite number of one-gap selected parities, provided deleting each own term preserves its parity. This is a direct consequence of the same lemma, not an additional physical independence assumption.

## 4. Exact product Q for synchronized schedules

Suppose both coordinates are completely pinched at the same internal nodes. Retain their joint sector outcomes after every common gap, including the endpoint. Let `Bᵢ` record whether coordinate i has had **any** mismatch between successive recorded labels. This flag is permanent, even if the physical parity later flips back.

We prove, backwards over the common gaps, that conditional on every entering classical record and arbitrary normalized entering bath/reference state, the chance that both flags are eventually set is at most

`∏_{i:Bᵢ=0} qᵢ`,

where `qᵢ=1−∏_{remaining gaps k}(1−s(aᵢₖ))`. An empty product is one. At the end, this is exactly the indicator that both flags are set.

For one induction step, let `vᵢ` denote the corresponding remaining probability after the current gap, and let `Aᵢ` be the event that the current gap mismatches coordinate i. If both flags are still unset, the inductive upper value after this gap is

`v₁v₂+(1−v₁)v₂ 1_A₁+v₁(1−v₂)1_A₂+(1−v₁)(1−v₂)1_(A₁∩A₂)`.

All coefficients are nonnegative. The entering state lies in one recorded joint sector, so the one-gap theorem and singleton lemma give

`Pr(A₁)≤s₁`, `Pr(A₂)≤s₂`, `Pr(A₁∩A₂)≤s₁s₂`,

where `sᵢ=s(aᵢ,current)`. Thus the expected value is at most

`[v₁+(1−v₁)s₁][v₂+(1−v₂)s₂]`.

If only one flag is unset, the singleton estimate gives the corresponding one-factor recurrence; if neither is unset, the value is one. Zero-probability records are omitted. Every nonzero conditional bath state is admissible because the estimates are uniform over the entire entering sector.

The recurrence is exactly the product Q recurrence. Hence

`effect(B₁=B₂=1)≤Q₁Q₂P_s`.

Both endpoint parities flipped implies both flags set, giving the desired endpoint bound. Tensoring two independent finite sink-bath constructions from PR105 attains `Q₁Q₂`: bath dimensions `(m+1)` for each coordinate suffice when there are m common gaps, and first mismatches never return. Thus the fixed-schedule worst case is exactly `Q₁Q₂` in this synchronized class.

This conditional argument is valid because the conditioning is on actual preceding isolated records, after a complete **joint** pinch. It does not condition on a future bad event.

### Any finite selected set

The same argument proves the synchronized result for any finite selected set S. Let U be the set of coordinates whose first-mismatch flags are still unset. The conditional continuation bound after a gap is

`∏_{i∈U}[vᵢ+(1−vᵢ)1_Aᵢ]`

`= Σ_{R⊆U} [∏_{i∈R}(1−vᵢ) ∏_{i∈U\R}vᵢ] 1_(∩_{i∈R}Aᵢ)`.

All coefficients are nonnegative. For every subset R, the one-gap entire-function proof gives `Pr(∩_{i∈R}Aᵢ)≤∏_{i∈R}sᵢ`. Applying it to the current conditional entering state therefore bounds the expectation by

`∏_{i∈U}[vᵢ+(1−vᵢ)sᵢ]`.

The entering state is in one recorded joint selected sector. Its bath may contain all unselected coordinates and an arbitrary reference, and may depend on the complete prior record. The one-gap inequalities are uniform over exactly these states. Every statement is conditional only on the past record, so ordinary finite-record conditional probability and the tower property are legitimate. Unselected terms preserve all selected parities and can be included in the baseline. This establishes

`effect(every selected coordinate ever mismatches)≤(∏_{i∈S}Qᵢ)P_s`.

Tensor products of the independent sink witnesses give equality for both this event and the terminal all-flipped event, with finite bath dimension `(m+1)^|S|` for m common gaps. Hence the fixed-common-schedule worst case is exactly the product.

### Common-slot optimization when envelopes are proportional

If `jᵢ(t)=cᵢw(t)` for nonnegative constants cᵢ and one known nonnegative integrable profile w, common equal-w-action cuts give equal own actions `aᵢ/m` simultaneously. They minimize every individual Qᵢ and thus their product among common m-gap schedules. The resulting exact minimax value within this synchronized scheduling class is

`∏ᵢ [1−cos^(2m)(min(aᵢ/m,π/2))]`.

This includes zero-action and saturated factors. When an action vanishes the product is zero regardless of the schedule, so uniqueness is not implied. Different nonproportional envelopes need not permit simultaneous equal-action cuts, and no common-slot optimizer is asserted for them. This conclusion also does not optimize over asynchronous schedules; the latter is the unresolved larger class.

## 5. One unpinched coordinate and any schedule for the other

Assume coordinate 1 has no internal pinch; let coordinate 2 have any fixed finite pinch schedule. Keep all coordinate-2 records and write W(x) for the resulting isometry when V₁ is replaced by xV₁. Let F(x) be W(x) projected onto both terminal flips and restricted to the entering joint sector.

For every real x, coordinate 2's singleton theorem still applies: `H₀+xV₁` preserves Z₂. Thus

`||F(x)||≤sqrt(Q₂)` for all real x.

Deleting V₁ makes the first flip impossible, so F(0)=0. F is entire of type at most `a₁=∫j₁`, including all fixed record isometries. The sine lemma gives

`||F(1)||²≤s(a₁)Q₂=Q₁Q₂`.

Independent one-gap and multi-gap sink witnesses show equality. By symmetry either coordinate can be the unpinched one.

## 6. Improved bound for arbitrary schedules

For each selected coordinate choose one of its own gaps. Work in the full common record dilation, and let R be the output projector onto mismatch across every chosen gap. Independently scale each chosen interaction restriction by a real/complex variable. The projected amplitude has norm at most one on the full real parameter domain. It vanishes whenever any chosen variable is zero, by the source's whole-input deletion-null property. Its type in that variable is the chosen gap action, even if the gaps overlap or other-coordinate pinches occur inside them.

Iterating the sine lemma therefore bounds the chosen-gap joint effect by the product of its `s(aᵢₖ)` factors. A positive union over one mismatching gap per selected coordinate then gives

`effect(all selected have some recorded mismatch)`

`≤ ∏ᵢ min(1, Σₖ sin²(min(aᵢₖ,π/2))) P_s`.

Dropping coordinates whose sums are at least one justifies the individual caps. This sharpens the former sum-of-squared-actions certificate. It still exceeds the target product Q in general because `1−∏(1−sₖ)≤Σsₖ` and the inequality can be strict.

## 7. The remaining asynchronous obstruction

When both coordinates have distinct internal pinch times, a coordinate's next own gap can begin or end while the other coordinate remains coherent between its own records. The synchronized induction cannot simply split at the union of their nodes: inserting the other missing pinch changes the channel. The selected-gap sine improvement only supplies a union bound, without the survival discounts present in Q.

A tempting substitute is false: one cannot assume that, after conditioning on the other coordinate's eventual bad event, an own mismatch remains bounded by its original singleton factor. Here is an exact admissible example, already with no bath and one gap:

- First apply `exp(−ia X₁)`.
- Then apply `exp(−ib |1⟩⟨1|₁⊗X₂)`.

Each drive is odd only in its own parity and commutes with the other parity. Its coefficient is predetermined, and it reads no private sign. Starting in 00,

`Pr(flip₁)=sin²a`, `Pr(flip₂)=Pr(flip₁ and flip₂)=sin²a sin²b`.

For positive a,b below π/2, `Pr(flip₁ | flip₂)=1`, exceeding `sin²a`. This does **not** refute the product theorem, which it saturates. It refutes the postselected conditional-contraction shortcut.

For example, choose `sin a=3/5` and `sin b=5/13`. Then the joint probability is exactly `9/169`, while the conditional probability is exactly one and the original first-coordinate singleton bound is `9/25`.

The outstanding task is therefore an asynchronous argument that preserves each own-gap survival discount despite intervening coherent other-coordinate histories, or an admissible counterexample. Neither a product of marginal bounds nor the ordinary singleton survival proof after future postselection supplies that argument.

## 8. Private-sign/Fourier scope

For the source's additive private-sign model, the virtual-seed dilation has `Vᵢ=X_seed,i⊗Aᵢ`, and the selected initial-sign Walsh amplitude is exactly the corresponding virtual endpoint block, with normalization `2^(−|S|)`. Averaging independent fair refresh bits gives the declared complete pinches. Thus the proven one-gap, synchronized-schedule, one-unpinched-coordinate, and gap-sine certificate statements apply to the original averaged positive Walsh effects in their respective classes.

The more general parity theorem allows conditional block couplings, whereas the virtual-seed lift itself has its additional factorized seed structure. No arbitrary parity-dependent coupling is asserted to be a literal virtual-seed Hamiltonian. The conditional example above is a warning about a proof technique in the stated broad parity contract, not a claimed Fourier counterexample.

Privacy, the absence of selected-sign-product terms, and cross-parity commutation are preserved throughout. No spatial-fault interpretation or hardware qualification is inferred from a virtual endpoint label.

## Inputs and verification boundary

Read: `pr105_minimax_audit/AUDIT_REPORT.md`; the received PR105 `FINITE_GRID_FRAME_THEOREM.md` and `FIXED_REFRESH_MINIMAX.md`; and the PR104 shared-bath audit's proof reconstruction, theorem, and audit summary. The primary entire-function theorem was independently checked from the publisher's PDF. The own authored checker and its numerical outputs are adjacent files. They are diagnostics only; the claims above rest on the analytic arguments.

The checker uses 16 deterministic four-sector/shared-qubit-bath cases, consisting of four explicitly prescribed noncommuting conditional-block Hamiltonian families in each of four schedule classes. It computes the largest endpoint-effect eigenvalue over the initial bath space rather than testing a single bath vector. The maximum commutation/norm-hypothesis residual is `1.67×10⁻¹⁶`. The four asynchronous rows are diagnostics only. The separate rational-angle one-gap equality and three-gap product-sink equality have absolute numerical errors below `6×10⁻¹⁷`. The exact conditional-shortcut example also evaluates to conditional probability one. No acquired code, optimizer, random sweep, or install was used.
