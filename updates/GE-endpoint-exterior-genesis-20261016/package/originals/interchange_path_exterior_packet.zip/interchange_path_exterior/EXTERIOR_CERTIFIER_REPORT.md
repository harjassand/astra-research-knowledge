# Removing the dense physical-pair bottleneck on paths

## Executed result

The killed-pair certificate can be evaluated without forming or powering the pair matrix on a weighted nearest-neighbor path. Composing the classical nonintersection/exterior-square identity with exact integer heat-kernel enclosures gives a **verified full-correlated-endpoint TV certificate below 0.046565375 on a 20-site graded path**.

The single bounded comparison used exactly the same input graph, horizon, averaging block and tolerance:

- Sites 0 through 19; path-edge rates `10^0,...,10^18`; horizon 1.
- Average vertices 2 through 19, retaining rates 1 and 10.
- Intermediate rates are `[1,10]` followed by seventeen copies of `10^20`.
- Absolute TV tolerance 0.05, uniformly over initial permutations and all color projections.
- Original ideal expected swap-attempt count: 1,111,111,111,111,111,111. Averaged ideal count: 11. This is an operation-count comparison, not a measured SSA speedup.

**Completed exterior certifier:** 3.627 seconds, 31.9 MiB peak process RSS, 194,000 stored integer power entries, 74 integration intervals and 75 survival queries per generator. Fixed denominators use 355 and 370 bits. Its exact Duhamel upper bound is approximately 0.04656537436987052. The independent classical averaging tail is exactly `262441/10^20`; the unchanged finite-bit sampler contributes less than 2.438e-10. Their exact rational sum is approximately **0.046565374613655695**. Exact numerators and denominators are in `exterior_receipt.json`.

**Unchanged delivered dense certifier:** stopped at the predeclared 240-second comparison limit without producing a certificate; peak process RSS reached 532.4 MiB. The receipt reports elapsed 240.015 seconds and termination signal 15. This is a completed-run versus timeout observation, not a claimed measured ratio of two completed runs. Its static dimensions require 13,754,100 stored power entries and approximately 2.60 billion scalar multiplication terms in preprocessing. The old code was imported unchanged. The new method even uses more conservative, rate-sensitive precision than the old baseline.

The 20-site pair matrix has 190 states; the permutation space has 2,432,902,008,176,640,000 states. Neither implementation enumerates permutations. The improvement is removal of the *dense pair* representation, not another claim about avoiding permutations.

This remains a mathematical model workload. The graph was chosen to stress the established certifier's scaling, not as a claimed materials dataset or a practical scientific application. Arbitrary branching graphs remain an open implementation target.

## 1. Classical structure: use the one-walker heat kernel

Let `L` be the weighted path Laplacian and `K(t)=exp(-tL)`. Order vertices along the path. The killed unordered-pair generator in the original report is precisely the induced exterior-square generator:

`H = L∧I + I∧L`, restricted to basis vectors `e_x∧e_y`, `x<y`.

A nearest-neighbor jump cannot pass the other walker without landing on it. Noncolliding jumps therefore have the ordinary negative off-diagonal generator entries. A jump onto the other walker vanishes in the exterior algebra, while its contribution stays in the diagonal. Both meeting directions together give killing rate `2 r_xy`, exactly as required.

The semigroup identity gives

`[exp(-tH)]_{xy,uv} = K_xu(t) K_yv(t) - K_xv(t) K_yu(t)`, for `x<y`, `u<v`.

Thus

`S_xy(t) = Σ_{u<v} [K_xu K_yv - K_xv K_yu] = K_x J K_y^T`,

where `J_uv=sign(v-u)`. A prefix sum evaluates this bilinear form in O(n) operations per starting pair. Only the n−1 physical path-edge pairs are needed here.

This is the classical Karlin–McGregor/nonintersecting-walk determinant, equivalently the free-fermion/exterior-square construction. It is not a new determinant identity, sampler, or exponential algorithm. The original [Karlin–McGregor paper (1959), p. 1109](https://msp.org/pjm/1959/9-4/pjm-v9-n4-p12-s.pdf) gives the noncoincidence probability as a transition-kernel determinant. A later primary discussion of inhomogeneous birth-and-death nonintersection kernels is [Assiotis, Random surface growth and Karlin–McGregor polynomials](https://arxiv.org/abs/1709.10444). The contribution tested here is the finite-bit composition with the graph-specific two-sided Duhamel certificate.

## 2. Integer enclosure without assuming rounded determinants stay positive

Choose `Λ=max_i L_ii`, `N=2^m≥Λ`, `Q=2^p`, with `p≥m`. The exact Euler transition matrix is `P=I−L/N`. Store `M_0=QP`, then

`M_{j+1}=floor(M_j M_j/Q)` entrywise.

All stored entries are nonnegative integers and row sums are at most Q. Powers and binary products are entrywise lower approximations to the corresponding Euler kernels. No pair matrix is stored.

### Rounding proof

At each matrix product, rounding loses less than n/Q in row ℓ1 norm. Substochastic multiplication does not amplify this norm. Consequently the stored power error is at most `(2^j−1)n/Q`. Forming a binary product for k Euler steps adds at most `kn/Q≤Nn/Q`: the contributions of the selected powers plus one rounding allowance per multiplication sum to that bound. The code uses this bound, not a floating estimate of the error.

### Euler-to-heat proof

Uniformize a one-walker path at rate Λ. In one interval of length 1/N, couple a Bernoulli(Λ/N) event count with a Poisson(Λ/N) event count. Their TV distance is at most `(Λ/N)^2`. For k≤N intervals, the mismatch probability is at most `Λ²/N`. Therefore each full heat-kernel row differs from the exact Euler row by at most `2Λ²/N` in ℓ1 norm.

Combining these gives, for each approximate row `m_x=M_x/Q`,

`||K_x−m_x||_1 ≤ ε_row = 2Λ²/N + nN/Q`.

Both true and approximate row ℓ1 norms are at most one. Since `|J_uv|≤1`,

`|K_x J K_y^T − m_x J m_y^T| ≤ 2 ε_row`.

The survival enclosure radius is therefore

`η = 4Λ²/N + 2nN/Q`.

This avoids an n² entrywise-error penalty. In particular, down-rounded heat matrices need not remain totally positive: their 2×2 minors may be negative. The implementation computes the signed integer bilinear value, adds/subtracts the proved norm bound, and only then intersects the result with `[0,1]`.

Every survival value has denominator `Q²`, every integration endpoint is dyadic, and every quadrature operation uses Python integer/Fraction arithmetic. Displayed decimals and resource timings play no role in accepting the certificate.

### Rate bits are charged

Let `D=Σ_e |r_e−q_e|` and `b=bitlength(D)+40`. The implementation sets

- `m=bitlength(Λ²)+b+3`
- `p=m+b+bitlength(n)+5`

(up to a harmless minimum m=1). Thus `η<2^(-b)`. The precision grows with both rate size and the rate-change weight rather than hiding a fixed absolute rounding floor behind arbitrarily large rates. The present exact input rates occupy 577 bits in total before delimiters; the intermediate rates occupy 1,144 bits. No real-number oracle or unit-cost unbounded integer assumption is made.

## 3. The endpoint proof and sampler are unchanged

The two-sided Duhamel certificate from the original packet remains

`TV(P_r(1),P_q(1)) ≤ Σ_e |r_e−q_e| ∫_0^1 S_r,e(u) S_q,e(1−u) du`.

Monotonicity bounds each integrand over `[a,b]` using opposite endpoint values, exactly as in the delivered certifier. The interval with largest upper-minus-lower gap is bisected until the total upper bound including the classical tail passes the target. The largest dyadic denominator depth in this run was 65. There is still no graph-uniform bound on the adaptive interval count.

For the s=18 fast path, the independent Aldous-gap estimate uses `λ≥4W/s²`. An integer upper bound for `sqrt(s!−1)/2` and the inequality `log A≤ceil(log2 A)` give the same classical tail mechanism as the delivered report. Its contribution here is `2.62441e−15`.

The existing `fair_bit_sampler.py` already accepts any `n≥3`, so no sampler algorithm changed. The error expression explicitly includes the n-dependent bounded-rejection failures for boundary selection and Fisher–Yates shuffling. For n=20 it gives less than 2.438e−10. A sample uses at most 64 Poisson-grid bits plus 20,320 bounded-rejection bits, hence at most **20,384 fair bits**, and outputs all 20 labels. Its theorem assumes independent fair input bits. A separate 1,000-sample execution using `secrets.randbits` preserved every label, took 0.061 seconds, and consumed 298,464 random bits in total. Those execution observations are diagnostics, not the TV proof.

## 4. Resource scaling and its limits

Let J be the number of survival nodes and M(p) the bit cost of multiplying p-bit integers.

- Old pair preprocessing: O(n⁶ m) integer products; power storage O(n⁴ m p) bits.
- New path preprocessing: O(n³ m) integer products; power storage O(n² m p) bits.
- Old survival node: O(n⁴ m) products in the worst case.
- New node: O(n³ m) products to form the one-walker kernel, plus O(n²) bilinear work for all physical edges.
- New cached survival outputs require O(J n p) bits. The full heat matrices at query nodes are temporary, not cached.

Each product carries the corresponding integer arithmetic cost, including M(p), accumulation, and exact flooring; the code does not claim these are constant-time. A dyadic time typically uses fewer than m products, as the receipts count explicitly.

The method still uses dense n×n one-walker powers. It is structure-exploiting, not a general sparse exponential-action solver, and it does not establish practical scaling to very large physical n. Its next bottlenecks are one-walker dense heat computation and quadrature, rather than a hidden n²-dimensional dense matrix.

## 5. Strong incumbents and an exact rejection of a floating proposal

**Sparse uniformization** is already a standard positive exponential-action method. It avoids dense storage, but direct Poisson summation needs an event-count range on the scale of Λt. On the boosted pair chain here Λ=4×10²⁰; at t=1/2 the mean is 2×10²⁰. Sparsity alone does not make that direct representation useful. Established comparison: [Sidje–Stewart, large sparse matrix exponentials in Markov chains](https://doi.org/10.1016/S0167-9473(98)00062-0).

**Taylor/scaling exponential action** is an important incumbent, not something this work invents. It avoids forming the matrix exponential but replaces matrix squaring by repeated action steps. Norm estimation, backward error, and finite-precision evaluation still require a rigorous bridge to the demanded absolute survival intervals. See [Al-Mohy–Higham](https://eprints.maths.manchester.ac.uk/1591/).

**Rational Krylov/shift-and-invert** can have convergence bounds independent of the matrix norm. It is therefore a serious alternative for arbitrary sparse pair graphs; dismissing it merely because rates are large would be incorrect. The cost shifts to accurate sparse shifted solves, basis storage, and a verified remainder. See [van den Eshof–Hochbruck](https://na.math.kit.edu/download/papers/preexp.pdf). No superiority over a carefully implemented arbitrary-precision validated rational Krylov method is claimed here.

**CRAM** uses rational approximation on the negative real axis and sparse complex shifted solves. For symmetric H, a proved scalar uniform approximation error transfers to the spectral operator norm. Published coefficients, coefficient rounding, solve error, and the conversion to componentwise survival bounds must all be charged. The coefficient issue is material: [Pusa's correction and Table 2](https://arxiv.org/html/1206.2880) documents an earlier coefficient error and supplies CRAM-16 data.

A bounded check ran ordinary double-precision CRAM-16 on the *same n=20 graph*, at the single node t=1/2, for both generators. Eight sparse complex LU solves per generator were followed by exact Fraction residual evaluation using the original integer H and the exact binary values returned by the solver. Against the certified adjacent-edge intervals, the floating CRAM values missed by up to approximately **0.783** (original graph) and **0.605** (boosted graph). Individual certified shifted-solve error bounds were as large as **7.21** and **19.89**, so those proposals must be rejected. Files retain every shift residual and the observed discrepancies.

For positive-real shift a+ib, the M-matrix maximum principle yields `||(tH+(a+ib)I)^−1||_∞≤1/a`. For other nonreal shifts, symmetry gives the spectral bound `1/|b|`, followed by norm conversion. Residuals were evaluated exactly as rational real/imaginary components; no floating residual was promoted to a certificate. The test does **not** validate the scalar CRAM approximation and does **not** refute high-precision or better-conditioned CRAM. It shows that unvalidated sparse double precision is insufficient on this exact stiff input.

**Validated exponential action / backward residuals** are standard and remain promising for arbitrary graphs. If an approximate differentiable trajectory v(t) has defect `d=v′+Hv`, substochastic contractivity gives

`||v(t)−exp(−tH)1||_∞ ≤ ||v(0)−1||_∞ + ∫_0^t ||d(s)||_∞ ds`.

An executable certificate must enclose the entire defect integral, not sample it at a few points. Rational Krylov and polynomial-in-time approximations can supply such trajectories, with all solve, projection, interpolation and rounding errors included. [Jawecki–Auzinger–Koch](https://arxiv.org/abs/1809.03369) gives a rigorous defect-bound treatment in Krylov spaces. Building that full sparse, arbitrary-graph finite-bit pipeline is still open here; the path method is a successful distinct representation with an explicitly narrower structural contract.

## 6. Cycle extension and a branching obstruction

The ordered-path restriction can be extended to cycles by a standard parity/twist construction. For a weighted n-cycle, let `L_anti` have the ordinary degree diagonal, negative off-diagonals on consecutive edges, and a positive off-diagonal on the wrap edge. A wrap jump reverses the pair order; its exterior-basis sign cancels the altered wrap sign. Hence the killed pair H is the exterior-square generator of `L_anti`.

Let C be the ordinary positive 2n-cycle Laplacian whose weights repeat twice, and `T=[I;−I]`. The exact identity `CT=T L_anti` implies

`exp(−tL_anti)=exp(−tC)_{first,first}−exp(−tC)_{first,second}`.

Rows of this signed kernel have ℓ1 norm at most one, since they are differences of disjoint parts of a stochastic row. The same integer heat enclosure on 2n states therefore gives the same `2 ε_row` bilinear error bound after the projection. This extension has an exact proof and independent small integer-generator/heat checks, but an end-to-end cycle Duhamel certificate was not executed in this bounded comparison.

A branching star shows why no fixed one-particle edge-sign gauge can universally repair this representation. On edges 0–1, 0–2, 0–3 consider the valid pair loop

`(1,2)→(0,2)→(2,3)→(0,3)→(1,3)→(0,1)→(1,2)`.

It exchanges the two labelled walkers, so the exterior reordering signs multiply to −1. Every physical edge is traversed twice, so any fixed physical-edge ±1 gauge contributes +1 around the loop. A diagonal gauge on pair states also cancels around a loop. The mismatch cannot be repaired in that restricted representation. This is **not** a lower bound against all sparse algorithms, tensor methods, or larger covers; it identifies the boundary of this one-particle exterior-square construction.

## 7. Reproduction and audit trail

Run in `/workspace/shared/interchange_path_exterior` with the existing Python/NumPy/SciPy/mpmath installation:

1. `python exterior_certificate.py --n 20 --output exterior_receipt.json`
2. `python run_dense_bounded.py` (one 240-second comparison, imports original code unchanged)
3. `python verify_exterior.py`
4. `python check_incumbent_residuals.py`
5. `python check_sampler.py`

Exact verification passed five weighted-path generator identities, 33 exact rational rounding checks, and two invalid-input tests. Twenty-five separate 90-digit mpmath heat comparisons were also checked; those are diagnostics only. `resource_counts.json` gives static counts. The independent cycle/star proof and checks are included under `cycle_extension/`. A manifest pins the portable scripts, the tested source snapshots, and byte-identical original dependencies. The portable entrypoint was replayed: the exact Duhamel bound, total rational bound and interval count all matched; the replay took 3.996 seconds at 31.9 MiB peak RSS. Paths default to the bundled `original_dependencies/` directory, with an optional `PAIR_CERTIFICATE_BASE` environment override.

No packages were installed, no acquired executable source was run, no external state was changed, and no floating diagnostic was used to certify the endpoint sampler. Historical priority for the overall certificate composition remains unestablished.

## Next discriminating gate

Use a supplied scientific workload whose generator really has fixed, symmetric exchange rates, with an endpoint observable and tolerance that matter to its owner. First determine whether that observable is already solved more cheaply by a validated one-particle heat method, an exact conditional sampler, or an established averaged solver. A one-point mean generally does not justify constructing a full correlated endpoint sampler. Only a workload needing correlations or full labelled/color output should bear the full certificate and output costs. Include certificate setup, rate-bit precision, output size, repeated-query amortization, and the strongest validated incumbent in the comparison. No further synthetic scale benchmark is needed before that decision.
