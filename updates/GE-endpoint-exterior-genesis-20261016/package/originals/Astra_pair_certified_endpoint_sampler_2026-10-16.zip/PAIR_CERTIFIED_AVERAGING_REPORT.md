# Pair-certified finite-time averaging for symmetric exchange

## Result and exact scope

A working mathematical-computational lead has emerged: certify a useful accelerated **full correlated endpoint sampler** by solving only a two-discrepancy problem. The sampler itself is standard conditional-uniform averaging. The candidate contribution is a graph-specific, two-sided perturbation certificate that permits aggressive averaging even when a direct mixing-gap/renewal certificate on the original graph is uninformative.

This is a model result, not a materials experiment or a demonstrated civilization-changing technology. Historical priority remains open. No acquired external code was executed. All executable checks here are original code with existing Python/NumPy/SciPy packages.

For the six-site path with rates `[1,10,100,1000,10000]`, horizon 1, averaging vertices 2–5 is certified with total-variation error below **0.029185**, uniformly over initial permutations and all color projections. The implemented finite-bit sampler adds less than **4.4e-15**. It uses 11 expected boundary attempts rather than 11,111 original swap attempts. An independent 720-state floating-point calculation gives actual TV 0.003522492 for the identity initial permutation. This numerical calculation is a diagnostic, not the proof.

For a twelve-site path with rates `10^0,...,10^10`, averaging vertices 2–11 is certified below **0.045426**, including a classical averaging tail; finite-bit sampling adds less than **4.8e-12**. The certificate uses 66 pair states rather than 479,001,600 permutation states. One run took approximately 5.4 seconds and 64 MiB peak process RSS. The original expected attempt count is 11,111,111,111; the reduced sampler uses 11. This is an operation-count comparison, **not** a measured billion-fold wall-clock speedup or a claim to beat every existing exact coarse-graining method.

The contract is: explicitly supplied undirected graph; nonnegative, state-independent symmetric swap rates; deterministic initial labeling; endpoint at a specified horizon; absolute TV accuracy. Exclusion occupancies are projections. Bias, configuration-dependent energies, chemical reactions, trajectories, time-integrated currents, and rare-event relative accuracy are outside this contract. Real vacancy-mediated multicomponent diffusion need not be an interchange process: fictitious swaps of two occupied particle labels must not be presented as physical tracer motion.

## Capital and acquired input identities

- N727 source, pinned at `2688d7a383502df4fc1e64001d04bb76e6ec05e5`: [interchange rate saturation proof](https://github.com/harjassand/astra-research-knowledge/blob/2688d7a383502df4fc1e64001d04bb76e6ec05e5/updates/EI/package/interchange_rate_saturation/DERIVED_PDF_TEXT.txt). Its key capital is reversible group inversion, transposition factorization, and two-sided Duhamel smoothing. Its global rate cap is polynomial in bit input size but generally impractical.
- Inputs for the present mathematical test are the exact integer graphs stated above, not invented material-response data. Their endpoint generators can be constructed independently from the model definition.
- Independent small-model evaluator: full 720-state generator exponentiation, and a separately constructed 30-state averaged quotient. The twelve-site averaged quotient has 132 states. These are serious direct samplers on these small/reduced models, not competitors to be ignored.
- Primary ingredient: Caputo, Liggett and Richthammer, [Proof of Aldous' spectral gap conjecture](https://arxiv.org/abs/0906.1238), Theorem 1.1, equality of random-walk and interchange gaps on weighted graphs.

## 1. Pair survival replaces the worst-case cap constant

Rescale the requested horizon to 1. For edge/transposition e, let A_e=I−T_e and L_r=Σ_e r_e A_e; P_r(t)=exp(−tL_r). Let H_r be the killed generator on unordered distinct vertex pairs {x,y}. Its transitions are those of two independent graph walkers before meeting:

- moving x to z≠y has rate r_xz;
- moving y to z≠x has rate r_yz;
- meeting kills the pair at rate 2r_xy.

Thus H_r is a symmetric positive semidefinite M-matrix of dimension d=n(n−1)/2. Define

S_r,e(t) = [exp(−tH_r) 1]_e.

Couple two interchange configurations initially differing only by transposition e. Use the same edge clocks away from the two discrepancy positions. On the edge joining the discrepancies, use independent clocks until the first one fires, at total rate 2r_xy, which coalesces the configurations. The discrepancy pair before coalescence has generator H_r. Therefore the initial-transposition endpoint TV is at most S_r,e(t), uniformly in all other labels and colors.

Reversibility on the permutation group gives p_r(t,g)=p_r(t,g^−1). Inversion exchanges the forward row gradient and the backward initial-state gradient, so

||δ_σ P_r(t)A_e||_1 ≤ 2S_r,e(t),
||A_e P_r(t)f||_∞ ≤ 2S_r,e(t)||f||_∞.

Because A_e²=2A_e, finite-difference Duhamel yields the central certificate:

sup_σ TV(P_r(1)(σ,·), P_q(1)(σ,·))
≤ Σ_e |r_e−q_e| ∫_0^1 S_r,e(u) S_q,e(1−u) du.        (1)

Unlike a one-sided perturbation norm, this charges the probability that a rate-change discrepancy survives smoothing from **both** ends of the observation interval. The pair generator is shared by all changed edges; only its starting row changes. No full-configuration generator is needed to evaluate the right-hand side.

This bound is valid for arbitrary finite graph rate changes, including newly added edges. It may be loose or fail to certify a proposed acceleration. No uniform guarantee that the adaptive quadrature cost is polynomial in rate bit-length is claimed here.

## 2. Accelerate through a finite boost, then take a conventional averaging limit

For the six-site test, choose q=[1,10,10^6,10^6,10^6]. Formula (1), enclosed below by exact integers, bounds original→boosted TV by 0.0287032355502554.

Write L_W=W A+B for the boosted internal graph and retained edges. Let Π be the orthogonal projection onto functions constant under permutations of each boosted component. For every fixed t>0,

exp(−tL_W) → Π exp(−t ΠBΠ) Π.

One finite-dimensional proof uses the decomposition ker A ⊕ (ker A)^⊥. For z>0, the lower-right block of zI+L_W has inverse norm at most 1/(z+Wλ_A). The Schur complement therefore converges to z+ΠBΠ, and the cross blocks vanish. Finite-dimensional resolvent convergence gives the displayed semigroup limit. This is ordinary singular perturbation/averaging, not a new mechanism.

The reduced process is implementable without quotient enumeration. Keep the labels currently in the fast block. At a retained boundary event, draw a uniform label from that block and exchange it with the external endpoint. At the final time uniformly shuffle the block. Retained events whose endpoints are outside the block are simulated normally. Initial/final Π are represented by the initial block label set and the final shuffle. State-independent attempt clocks include null swaps for repeated colors.

For the specific six- and twelve-site models there are two retained clocks: rate 1 swaps outside vertices 0,1; rate 10 swaps vertex 1 with a uniform block label. A Poisson(11) count with iid edge choices produces their exact event order over time 1. This samples the endpoint, not the trajectory of the original process.

## 3. Independent classical control of the boosted→averaged tail

If δ_i(t) bounds the full conditional-permutation mixing distance of component i, and Γ_i is its incident retained-attempt rate, a boundary-gap coupling gives

error_i ≤ δ_i(1)+Γ_i(Γ_i+2) ∫_0^1 δ_i(u) du.            (2)

More exactly, the expected sum of initial, final and consecutive Poisson-gap defects is

e^(−Γ)δ(1)+2Γ∫e^(−Γu)δ(u)du+Γ²∫(1−u)e^(−Γu)δ(u)du.

For the boosted four-path, Aldous' theorem and the elementary path spectrum give gap λ=(2−√2)W≥W/2. Reversible L² mixing gives δ(t)≤min(1,(√23/2)e^(−λt)). Since √23/2<e, its integral is at most 4/W. For W≥24, δ(1)≤1/W. With Γ=10 and W=10^6, (2) is at most 481/10^6=0.000481. Total six-site model error is therefore at most **0.0291842355502554**.

For a boosted path with s vertices, λ≥4W/s². The code computes a rational amplitude upper bound A≥√(s!−1)/2 and an integer k with A≤2^k. Thus log A≤k, ∫δ≤(k+1)s²/(4W), and δ(1)≤1/W whenever W≥A s^4/8. This gives an independently classical tail for the twelve-site test, approximately 3.3e−8. The larger, separately derived local-saturation tail is retained as a cross-check.

## 4. Finite-bit enclosure, not floating-point confidence

For a killed-pair H with Λ=max diagonal H, choose N=2^m large enough that Λ²/N is tiny, and Q=2^p. The Euler matrix P=I−H/N is substochastic. Integer input rates and p≥m make its Q-scaled entries exact integers. Repeated squaring with entrywise downward rounding retains a nonnegative substochastic lower matrix.

Poisson/Bernoulli clock coupling bounds the error of any survival event at dyadic t=j/N by Λ²/N. A conservative accumulated row error from all stored powers and binary matrix-vector products is (2Nd+m+2)/Q. All lower/upper survival values are represented as integer numerators over Q. Cached powers are computed once per graph. Each dyadic node evaluates all pair survival rows together.

For interval [a,b], monotonicity gives the rigorous product enclosure

S_r,e(b) S_q,e(1−a) ≤ S_r,e(u) S_q,e(1−u)
≤ S_r,e(a) S_q,e(1−b).

Interval integration, multiplication by exact rate differences and summation use Python rational integers. The largest upper-minus-lower segment is bisected until the total error budget is met. The six-site calculation used 23 intervals / 24 nodes per graph, with 189–204-bit fixed denominators. Its integral enclosure is [0.0035713689, 0.0287032356]. The twelve-site calculation used 45 intervals / 46 nodes and 229–244-bit denominators.

The implementation explicitly rejects noninteger/negative rates rather than silently truncating. Rational general input can be handled by rescaling, but a generic input parser is not provided in this prototype.

## 5. Finite-bit executable sampler

`fair_bit_sampler.py` avoids floating Poisson or exponential calls in the claimed sampler. It computes a rational lower bound for exp(−11) as the reciprocal of an upper Taylor bound for exp(11), floors Poisson probabilities for counts 0,...,64 onto a 64-bit grid, and assigns unused mass to count zero. The Poisson tail, lower-bound error and grid floors are charged explicitly.

Edge choices and Fisher–Yates choices use uniform bits and bounded rejection (32 attempts); the probability of reaching the fallback is charged by a union bound. The theorem assumes independent fair input bits, as usual for a randomized sampler. The runnable implementation uses Python's system-backed `secrets.randbits`; a seeded PRNG is only used in the separate diagnostic sampler.

Total sampler error: <4.4e−15 for six sites, <4.8e−12 for twelve sites. One 10,000-sample twelve-site fair-bit run took approximately 0.28 seconds and preserved every label. This timing excludes the approximately 5.4-second certificate precomputation and is not a direct-SSA benchmark.

## 6. Strong incumbents and what was rejected

- Direct SSA/uniformization retains every clock, including null swaps.
- Exact component equilibrium is a uniform permutation and can be sampled by a shuffle. It does not require enumerating a configuration basin.
- Standard boundary-event stochastic averaging is the actual accelerated sampler used here. It decisively beats local rate capping on clean-gap examples.
- MCAMC, absorbing-chain/mean-residence-time basin elimination, stochastic averaging, adaptive-scaling KMC and graph reductions are established acceleration families; the sampler mechanism must not be claimed new.
- On the graded six-path, averaging vertices 1–5 already has numerical endpoint TV 0.0488908 at retained intensity 1, and averaging vertices 2–5 has TV 0.00352249 at intensity 11. The new certificate has not established that the intensity-1 choice is safe. It selects the stronger certifiable choice, not the empirically fastest one.
- A direct original-graph spectral-gap/renewal bound failed to certify any nonsingleton partition at tolerance .05. That shows a useful distinction from this **specific** standard bound, not impossibility for every previous averaging analysis.

Primary literature inspected includes [Aldous–Fill, interchange coupling](https://www.stat.berkeley.edu/~aldous/RWG/Book_Ralph/Ch14.S5.html), [Jung, perturbations of symmetric exclusion](https://arxiv.org/abs/math/0309237), [Zeifman et al., continuous-time perturbation bounds](https://arxiv.org/abs/1911.03355), [eOn coarse-graining documentation](https://eondocs.org/user_guide/coarse_graining), and [Katsoulakis et al., coarse-grained KMC error analysis](https://arxiv.org/abs/math/0509228). A bounded search did not establish a precise prior equivalent of (1) as an executable all-color averaging certificate; it also cannot establish novelty.

## Reproduce

Run from this directory with the existing Python packages:

1. `python rigorous_pair_certificate.py` — six-site exact-rational certificate.
2. `python fair_bit_sampler.py` — finite-bit executable sampler and explicit sampler-error receipt.
3. `python boundary_shuffle_sampler.py` — separate 200,000-sample software diagnostic against the exact averaged quotient.
4. `python large_pair_check.py` — twelve-site certificate and process resource receipt.
5. `python pair_profile_check.py` — floating profile-versus-full-endpoint checks on four graded six-site models.

Exact receipts are JSON files alongside each script. The independent worker's `LOCAL_SATURATION_PROOF.md`, `RESULTS.md`, `run_checks.py`, and graded-path generator arrays preserve the earlier local-cap development and its unfavorable clean-gap comparator.

## Bounded accuracy curve

Two stricter six-site tests were run after the main packet was complete. At target 0.001, averaging vertices 3–5 was certified below 0.000972 by the classical-tail route, at retained intensity 111; the calculation used 43 quadrature intervals and about 0.09 seconds. At target 0.0001, averaging vertices 4–5 was certified below 0.00007973, at retained intensity 1,111; 49 intervals took about 0.10 seconds. These are certificates for the corresponding standard averaged kernels. The packaged fair-bit sampler specifically handles retained rates 1 and 10; the stricter variants require the same routine with a different Poisson table/event selector and are not claimed to be implemented by that particular sampler.

`accuracy_curve_check.py` and `accuracy_curve_results.json` contain these additional receipts. They show the expected accuracy/work tradeoff rather than an unconditional permission to discard all fast events.

## Next discriminating gate

The next useful step is neither another favorable toy graph nor a broad materials claim. It is to identify a real scientific workload whose supplied generator genuinely obeys state-independent symmetric exchange, then compare the pair-certified accelerated sampler against the best available exact/averaged solver at matched endpoint TV, including certificate setup, full-output cost and repeated-query amortization. Separately, a systematic prior-art review and independent theorem audit are needed before any novelty claim. There are O(n²) pair states, but the current implementation is dense: it stores O(n⁴ log N) integer entries, performs O(n⁶ log N) preprocessing arithmetic, and uses O(n⁴ log N) arithmetic per survival node, with integer precision charged separately. Adaptive quadrature node count is additional. This can become the next computational obstruction; the present test does not solve that scaling problem.
