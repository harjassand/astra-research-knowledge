# Tolerant prediction from local ports: a superpolynomial information barrier

**ASTRA THEORETICAL — 12 October 2026**

## Status and principal conclusion

This note supplies a self-contained proof construction, with separately labelled finite numerical diagnostics. It is not independently reviewed, formally verified, or cleared for historical priority. Chebyshev interpolation, Jacobi inverse spectral representations, locality estimates, and statistical two-point arguments are established mathematics. The potential contribution is the task-specific separation below, including its active, many-body observation contract and its quantitative accounting of fresh experiments.

The experiment uses ordinary real-time evolution, not an imaginary-time filter. The unknown system is a connected nearest-neighbour interacting qubit chain with bounded terms, a unique product vacuum, and a uniform gap above that vacuum. The candidate is a known onsite rotation. The prediction target is only the reduced trajectory of one qubit, from a product input.

For this target, exact-agreement certification has a polynomial local test. However, a test that must also accept every approximately correct trajectory can require superpolynomially many short local-port experiments. The hard alternatives are exactly isospectral and known up to one bit. The lower bound permits arbitrary controls at the available ports, arbitrarily large quantum memory, and even complete quantum readout at the end of an experiment.

This is a worst-case theorem for restricted spatial access and restricted duration per fresh experiment. It is not a lower bound against all-site addressability, arbitrary bath preparation, long coherent experiments, or thermal-state access. The constructed interaction strengths are inverse-polynomially bounded below, not uniformly bounded below. No generic-disorder or fixed-decoherence robustness is asserted.

## 1. Definitions and resource contract

We set hbar=1. For density matrices, D(rho,sigma)=||rho-sigma||_1/2. Let n_x=|1><1| on qubit x and let N=sum_x n_x. Our known candidate is

    K=N.

The prediction input is

    psi=|+>_a tensor |0>_(all other qubits),

where a is an accessible qubit. For an unknown, time-independent Hamiltonian H define

    E_T(H)=sup_(0<=t<=T) D(rho_H^a(t),rho_K^a(t)).                 (1)

Here rho_H^a is the reduced state on a after evolving the full input psi. A tolerant certifier must accept with probability at least 2/3 whenever E_T(H)<=eta, and reject with probability at least 2/3 whenever E_T(H)>=3/4. It may behave arbitrarily in the intermediate region. The candidate, tolerances and prediction horizon are fixed before the validation observations.

### 1.1 Available experiments

Fix a set S of controllable sites containing a. A fresh experiment starts with all sites outside S in the known vacuum. Within S, the experimenter may prepare an arbitrary state entangled with arbitrary retained quantum memory. During the experiment, the system evolves under H. Arbitrary known controls, joint operations, measurements, resets and feedback on S plus the memory are allowed. These controls have no strength bound. No operation may prepare or act on the other system sites during this evolution.

The total native evolution time in one fresh experiment is at most tau. Dividing a coherent run into pieces does not reset this cap. All feedback operations are counted within that same experiment. A new experiment requires a fresh vacuum outside S. A previous bath state cannot be reinserted as the next bath.

For the lower bound we grant MORE terminal information than local readout: at the end, the entire system state may be handed to the experimenter as a quantum output, with arbitrary subsequent collective processing and quantum memory. Thus the lower bound includes protocols using only local measurements. All discarded experiments and all postselected failures count. No inverse of the unknown dynamics is supplied.

The raw experiment count is a worst-case cap. Experiment duration can be selected adaptively from earlier classical outcomes. Within an experiment the controls may use feedback. The supplementary expected-total-duration lower bound in Section 7 assumes the duration is selected at the start of each experiment; it does not assert an optional-stopping theorem for arbitrary outcome-dependent termination within a run.

Bath preparation, port operations, readout and classical computation are granted free in the lower bound. Charging their actual costs cannot invalidate it. The theorem assumes a fixed, memoryless unknown Hamiltonian across fresh experiments.

### 1.2 An ambient class for the exact/tolerant comparison

The polynomial upper bound will hold whenever H conserves excitation number, annihilates the vacuum, and restricts on the one-excitation sector to I+C with ||C||<=2. The relevant lower-bound chains lie in this class. The ambient class allows zero hopping. Exact-null examples therefore exist, including H=N plus arbitrary occupation-diagonal interactions that vanish on the vacuum and one-excitation sectors. Exact completeness is not asserted for a class in which the null hypothesis has been excluded by a strict nonzero-hopping promise.

## 2. Main results

**Theorem 1 (active local-port tolerant lower bound).** Let d>=1 and 0<eta<=1/8. Put

    delta=eta^2/(64d^2),
    T=4/delta=256d^2/eta^2.

There are two connected nearest-neighbour Hamiltonians H_g,H_b on 2(d+1) qubits with these properties:

1. All interaction terms are bounded by an absolute constant. There are nonzero hopping terms on every edge and positive nearest-neighbour density-density interactions. The vacuum is a common unique product ground state, with spectral gap greater than 0.9.
2. H_g and H_b are related by a reflection of the chain. Their entire many-body spectra, including multiplicities, coincide.
3. All coefficients agree except for interchanging the onsite terms at the two outermost sites. The entire alternatives may be supplied in advance; their assignment is the sole unknown bit.
4. With the simple K and product psi in Section 1,

       E_T(H_g)<eta,       E_T(H_b)>3/4.                         (2)

5. Label the two arms from their adjacent central sites as L_0,...,L_d and R_0,...,R_d. Allow control of both prefixes through r, where 0<=r<d, and set R=d-r. For 0<tau<=R/2, every tolerant certifier in the stated access model uses at least

       N >= (2R+1)(R!)^2 / (144 tau^(2R+1))                     (3)

   fresh experiments in the worst case.

In particular, for fixed eta, fixed positive tau and r<=d/2, this is

       N >= exp(Omega(d log d))
         = exp(Omega(sqrt(T) log T)).                           (4)

Equation (3) is a lower bound, not a matching minimax formula. Its exact expression is preferable when tau grows with R.

For experiment durations chosen before each run, the average, under the two hypotheses, of the expected total native evolution time obeys

    Sbar >= (2R+1)(R!)^2 / (144 tau^(2R)).                       (5)

There is also a matched dyadic version with O(log(d/eta)) bits per bounded coefficient, retaining (2)-(5), exact reflection isospectrality and a gap greater than 0.9. This version has inverse-polynomial, shared-coefficient precision tolerance, not a full fixed-noise perturbation neighbourhood.

**Theorem 2 (polynomial exact-agreement certificate with one-qubit operations).** In the ambient class of Section 1.2, suppose h=min(tau,1/2)<=T. Prepare psi, evolve for time h, undo the known candidate phase on a, and measure X_a. Let p be the probability of the minus outcome. Then

    E_T(H) <= min(1, (2T/h) sqrt(p)).                            (6)

If E_T(H)=0, p=0. Thus, observing no minus result in

    ceil[4T^2/(h^2 epsilon^2) log(1/alpha)]                       (7)

independent shots is a sound certificate for E_T<=epsilon with error probability alpha. It has exact completeness and uses only a one-qubit preparation, a one-qubit phase, and one-qubit readout. It need not accept every approximately correct trajectory.

Theorems 1 and 2 concern the same experimental interface and a common ambient model class. In particular, at fixed eta and tau, allowing true model tolerance can change a polynomial exact-null task into one requiring superpolynomially many experiments. This statement does not claim that every exact Hamiltonian-verification task is polynomial.

## 3. The elementary exact-null upper bound

Since the vacuum is fixed and the one-excitation Hamiltonian is I+C,

    U_H(t)psi=(|vac>+exp(-it)exp(-itC)|a>)/sqrt(2).

Let nu be the probability spectral measure of C at a and let

    F(t)=<a,exp(-itC)a>=integral exp(-itx) dnu(x).

After undoing K at time h, the expectation of X_a is Re F(h). Hence

    p=(1/2) integral [1-cos(hx)] dnu(x).

Since |x|<=2 and h<=1/2, |hx|<=1. The elementary bounds

    1-cos y >= y^2/4  for |y|<=1,
    1-cos y <= y^2/2  for every real y

give

    p >= h^2 <a,C^2 a>/8.

The squared distance of the two full state vectors at time t is

    ||U_H(t)psi-U_K(t)psi||^2 = 1-Re F(t)
                            <= t^2 <a,C^2 a>/2.

Partial trace contracts trace distance, and pure-state trace distance is bounded by vector distance. Therefore E_T^2<=4T^2p/h^2, proving (6). Exact local agreement implies the measured X outcome has p=0 at h. The probability of no rejection in N shots is (1-p)^N<=exp(-Np), proving (7).

No candidate many-body simulation or filter is used. Each successful positive-certificate shot requires a fresh vacuum bath supplied by the experimental interface. If its actual reset cost is C_reset, preparation/readout/gate cost is C_local, and native duration is h, the total resource bill includes N(C_reset+C_local) and native duration Nh. Neither vacuum preparation nor gate calibration is asserted to be universally free in the laboratory. This proof is a survival/second-moment argument; that ingredient is not claimed as new.

## 4. A positive spectral construction with optimally small contamination

Let m=2d and define the shifted Chebyshev-Lobatto nodes

    x_j=delta+(1-delta)[1-cos(j pi/m)]/2,   j=0,...,m.

For each j, let w_j be the Lagrange interpolation coefficient at zero:

    w_j=product_(k!=j) (-x_k)/(x_j-x_k).

For every polynomial p of degree at most m,

    p(0)=sum_j w_j p(x_j).                                     (8)

The nodes are positive and increasing, so sign(w_j)=(-1)^j, and sum w_j=1.

Define q(x)=T_m((1+delta-2x)/(1-delta)), where T_m is the Chebyshev polynomial. Then q(x_j)=(-1)^j. Consequently,

    Lambda=sum_j |w_j|
          =T_m((1+delta)/(1-delta))
          =cosh(2m artanh(sqrt(delta))).                        (9)

Put A=(Lambda+1)/2. Define two positive probability measures:

    nu_g=[delta_0 + sum_(j odd) |w_j| delta_(x_j)]/A,
    nu_b=[sum_(j even) w_j delta_(x_j)]/A.                       (10)

Each has d+1 support points. Their moments agree through degree 2d by (8). The good measure has mass 1-rho at zero, where

    rho=1-1/A=(Lambda-1)/(Lambda+1)
       =tanh^2(m artanh(sqrt(delta)))
       <=eta^2/9.                                              (11)

For the last inequality, sqrt(delta)=eta/(8d), artanh z<=4z/3 for z<=1/2, and tanh z<=z. Also

    w_0=product_(k>0) x_k/(x_k-delta) >=1,

so nu_b has mass at least 1-rho at x_0=delta.

For all real t,

    1-Re integral exp(-itx)dnu_g(x) <=2rho.                      (12)

At t_star=pi/delta<T,

    Re integral exp(-it_star x)dnu_b(x) <=-1+2rho.               (13)

Thus one response stays close to an exact onsite rotation for all time, while the other accumulates an almost opposite phase before T. Moment matching alone would not prove the active-access lower bound; Sections 6-7 prove the necessary channel statement.

### 4.1 Exact extremal meaning of the contamination

The value in (11) is optimal for the following purely polynomial problem. If a probability measure mu_g has mass 1-rho at zero and all its other mass in [delta,1], a probability measure mu_b is supported in [delta,1], and their moments agree through degree m, then

    rho >= (Lambda-1)/(Lambda+1).

Indeed, q(0)=Lambda while |q(x)|<=1 on [delta,1]. Matching q expectations gives

    (1-rho)Lambda-rho <= integral q dmu_g
                       = integral q dmu_b <=1.

The measures (10) attain equality. This is an explicit application of Chebyshev extremality, not a separate claim of a newly discovered approximation theorem.

## 5. Local, connected, interacting, isospectral realization

### 5.1 Jacobi matrices differing at only one boundary

For either measure in (10), orthonormalize 1,x,...,x^d. Multiplication by x in this basis is a real symmetric tridiagonal Jacobi matrix. After a fixed alternating sign gauge, write them as A_g,A_b with negative neighbouring couplings and seed e_0.

The diagonal at j depends on moments through degree 2j+1. The bond from j to j+1 depends on moments through degree 2j+2. Equality of moments through 2d therefore makes every bond and all diagonal entries except the last identical. Both spectra lie in [0,1]. Trace comparison gives the exact difference

    A_b-A_g=a_delta |d><d|,     a_delta=(1+delta)/2.                        (14)

To verify the trace calculation, the even-indexed nodes have sum (d+1)(1+delta)/2; the odd-indexed nodes have sum d(1+delta)/2; nu_g additionally has eigenvalue zero. The corresponding cosine sums are zero. Endpoint spectral weights are the measures in (10).

Every bond has magnitude at most 1/2: subtracting I/2 gives an operator with norm at most 1/2, bounding each off-diagonal entry.

### 5.2 No exponentially small coefficients are required

The Chebyshev-Lobatto barycentric weights have magnitudes proportional to c_j, where c_0=c_m=1/2 and the interior c_j=1. This follows by differentiating the nodal polynomial proportional to (1-y^2)U_(m-1)(y) at its roots y=cos(j pi/m). The Lagrange coefficients at zero consequently obey

    |w_j|=kappa c_j/x_j

for a common positive kappa. Since w_0=kappa/(2delta)>=1, every |w_j|>=delta. As A<=2, every atom in either measure has weight at least delta/2.

The smallest gap between eigenvalues within either measure is at least 1/(8d^2). This follows from the smallest consecutive Chebyshev-node spacing, using sin y>=2y/pi on [0,pi/2]; the additional zero in nu_g is no closer to its next support point.

We use an elementary Jacobi estimate. If a Jacobi matrix has simple eigenvalue gaps at least Delta and first-site weights at least alpha, every bond b satisfies

    |b| >= Delta sqrt(alpha)/3.                                (15)

Split the chain across b. The left principal block has fewer eigenvalues than the full matrix. Intervals of radius Delta/3 around its eigenvalues can cover at most one full eigenvalue apiece. Choose a full eigenvalue lambda not covered. Its normalized eigenvector v then satisfies

    ||v_left|| <= 3|b|/Delta,
    alpha <= |v_0|^2 <= ||v_left||^2.

This proves (15), and here yields

    eta/(300d^3) <= |b_j| <=1/2.                                (16)

### 5.3 Reflection doubling and a weak connecting bond

Let gamma=eta/(16T). On two arms define the one-excitation corrections

    C_g=A_g direct-sum A_b
        -gamma(|L_0><R_0|+|R_0><L_0|),
    C_b=P C_g P^*,                                             (17)

where P exchanges L_j and R_j. The graph is a path with ordering L_d,...,L_0,R_0,...,R_d. Only the two outermost diagonal coefficients differ between C_g and C_b. The hopping row sums are at most one. Also

    -gamma I <=C_g,C_b<=(1+gamma)I.

Promote this to the spin Hamiltonians

    H_s=sum_x [1+(C_s)_(xx)] n_x
        +sum_(edges xy) (C_s)_(xy)(sigma_x^+ sigma_y^-+sigma_y^+ sigma_x^-)
        +sum_(edges xy) n_x n_y,     s in {g,b}.                 (18)

The density-density terms have strength one. Hence these are genuinely interacting Hamiltonians, although the requested prediction lies in the invariant vacuum-plus-one-excitation sector, where those interaction terms vanish. We do not claim a hard interacting finite-density prediction theorem.

Every edge has nonzero hopping. Reflection exchanges H_g and H_b exactly, proving full many-body isospectrality. In particular,

    H_b-H_g=a_delta(n_(L_d)-n_(R_d)),                                 (19)

up to exchanging the labels g and b.

On a path, the Jordan-Wigner transformation maps the hopping and onsite part to a quadratic fermion Hamiltonian with one-particle matrix I+C_s. Diagonalizing this matrix writes that part as sum_j lambda_j f_j^dagger f_j with lambda_j>=1-gamma. Therefore it is at least (1-gamma)N. The remaining density interactions are nonnegative. The vacuum is consequently the unique ground state, with gap at least 1-gamma>0.9. This proves the stated gap without an assumed many-body gap conjecture.

### 5.4 The prediction gap

Set a=L_0. First omit the central hopping in the one-excitation sector. Equation (12) gives

    sup_t ||U_(H_g)(t)psi-U_K(t)psi|| <=sqrt(2rho)<eta/2.

Equation (13), tested by X_a after undoing the candidate phase, gives

    D(rho_(H_b)^a(t_star),rho_K^a(t_star)) >=1-rho.

Restoring the connecting bond changes the one-excitation generator by operator norm gamma. Duhamel's identity bounds its state-vector effect by gamma t, and hence its trace-distance effect by at most gamma t. Since gamma T=eta/16,

    E_T(H_g) <eta/2+eta/16<eta,
    E_T(H_b) >=1-rho-eta/16>3/4.                                (20)

Notice that the common gap is a gap above the vacuum. The two long-lived responses use closely spaced EXCITED energies. A vacuum gap does not rule out this mechanism.

## 6. A controlled occupation bound

We next prove the full active observation statement, not just agreement of a passive scalar correlator.

Consider a number-conserving hopping Hamiltonian with arbitrary occupation-diagonal interactions, and arbitrary controls on S plus an auxiliary memory. Write B_(xy)=|J_(xy)| for its nonnegative hopping adjacency matrix. Assume its row sums are at most one, as in (18). All sites outside S start in the vacuum.

For a purified state define

    p_x(t)=<n_x>,       q_x(t)=sqrt(p_x(t)).

For x outside S, the control terms and all occupation-diagonal terms commute with n_x. For a hopping edge, Cauchy-Schwarz applied to sigma_x^-|Psi> and sigma_y^-|Psi> gives

    |d p_x/dt| <=2 sum_y B_(xy) sqrt(p_x p_y).

Thus in the upper-Dini-derivative sense

    d q_x/dt <=sum_y B_(xy)q_y.                                 (21)

One may justify points where p_x=0 by replacing sqrt(p_x) by sqrt(p_x+epsilon^2), applying the comparison inequality, and taking epsilon down to zero. At sites in S simply use q_x<=1. Arbitrary local instruments are purified and their records retained; they do not change an outside occupation expectation instantaneously.

Let y(t)=exp(tB)1_S. On S, y>=1; outside S, y'=By; and q(0)<=y(0). The comparison principle proves q<=y. If dist(x,S)>=R, powers B^k 1_S vanish at x for k<R, while their entries are at most one for all k. Therefore

    q_x(t) <=Q_R(t):=sum_(k>=R) t^k/k!.                         (22)

For 0<=t<=R/2,

    Q_R(t)<=2t^R/R!.                                           (23)

This proof permits arbitrary port-control strength, entanglement between ports and memory, many excitations injected at the ports, and density-density interactions throughout the chain. It bounds all inputs uniformly. If V_s(t) is the resulting isometry from input ports and memory to the joint output, then

    ||n_x V_s(t)|| <=Q_R(t).                                   (24)

The arbitrary interacting controls are NOT restricted to the one-excitation sector used in constructing the target prediction.

## 7. The active channel overlap and adaptive information bound

Use the same control protocol under H_g and H_b. Let V_g(t),V_b(t) be its forward Stinespring isometries, with all control and measurement records retained. Common known operations preserve cross overlaps. Between those operations,

    d(V_g(t)^* V_b(t))/dt=i V_g(t)^*(H_g-H_b)V_b(t).

By (19), the difference is supported on two remote number projectors. For each endpoint x,

    ||V_g^* n_x V_b|| <=||n_x V_g|| ||n_x V_b|| <=Q_R(t)^2.

It follows that an experiment of duration u<=tau<=R/2 obeys

    ||I-V_g(u)^* V_b(u)||
        <=2a_delta integral_0^u Q_R(t)^2 dt
        <=8u^(2R+1)/[(2R+1)(R!)^2]
        =:zeta(u).                                             (25)

The SQUARED arrival amplitude is important. The lower bound is not inferred by treating scalar moment matching as equality of quantum states. Equation (25) directly controls the entire forward experiment, even when the complete chain is returned.

Purify an arbitrary adaptive sequence of at most N fresh experiments. All inter-experiment processing is hypothesis-independent and preserves the inner product of the two purifications. Each new experiment changes this overlap by at most zeta(tau), even with arbitrarily entangled input memory. Therefore

    D_final^2 <=min(1,2N zeta(tau)).                             (26)

More explicitly, the overlap has distance at most N zeta from one; when that bound is useful, 1-|overlap|^2<=2N zeta. When it is not useful, the trivial bound D<=1 suffices. Retaining or discarding measurement records cannot increase accessible distinguishability beyond the purified bound.

A certifier satisfying (2) distinguishes the equally likely hypotheses with probability at least 2/3. Optimal binary discrimination therefore requires D_final>=1/3. Combining with (26) gives (3).

### 7.1 Accounting for total native duration

Suppose the duration u of each run is selected from the prior classical history. Decompose each query input into orthogonal history blocks x_g(h),x_b(h). Put

    kappa_tau=8tau^(2R)/[(2R+1)(R!)^2].

Since zeta(u)<=kappa_tau u, a history block changes the overlap by at most

    kappa_tau u ||x_g(h)|| ||x_b(h)||
      <=(kappa_tau u/2)(||x_g(h)||^2+||x_b(h)||^2).

Summing over histories and experiments bounds overlap loss by kappa_tau Sbar, where Sbar is the average expected total duration under the two hypotheses. Thus D_final^2<=2kappa_tau Sbar and D_final>=1/3 yields (5). No number of unsuccessful or discarded runs is omitted from this accounting.

### 7.2 Why this is more than a passive light-cone example

Locality supplies the controlled arrival bound. The positive spectral construction supplies a different requirement: the two indistinguishable systems must lie on OPPOSITE SIDES of a genuine tolerance promise relative to an extremely simple candidate, with one system uniformly close throughout the whole future interval. Exact-agreement certificates can reject that good system, but a tolerant certifier cannot. This is what creates the separation from Section 3.

## 8. Finite coefficients and robustness actually proved

Use a dyadic step q=2^(-b) satisfying

    q<=min{eta/(96T), eta/(1200d^3)}.

Round common diagonal coefficients once and reuse them on both arms. Round hopping magnitudes and the central hopping down to the grid, and construct the other hypothesis by reflection. The active matrix changes by operator norm at most 3q, since at most two hopping errors and one diagonal error enter each row. All hopping row sums remain at most one.

Equation (16) and q<=eta/(1200d^3) keep every arm hopping positive. Also q<=gamma/6 keeps the central hopping positive. The endpoint difference remains bounded by one. Thus the controlled channel estimate is unchanged. Reflection isospectrality is exact, rather than approximately preserved.

Duhamel bounds the target-trajectory change through T by 3qT<=eta/32. The margins in (20) retain (2), and the vacuum gap remains at least 1-gamma-3q>0.9. Since all coefficients are bounded and b=O(log(d/eta)), the family admits a polynomial-size finite classical specification.

The Jacobi construction uses d-dimensional polynomial orthogonalization of explicitly specified positive measures. The diagnostic implementation uses arbitrary-precision numerical arithmetic and then matched dyadic rounding. It is not a general interval-certified compiler. The theorem proves existence of the displayed finite-precision family; it does not claim a compiled quantum circuit or a laboratory realization.

This is a SHARED-BULK perturbation statement. Independent changes near the observed ports can reveal the hypothesis immediately, and constant errors can accumulate over the long prediction horizon. We do not claim robustness to arbitrary fixed-strength disorder, finite-temperature background excitations, or decoherence. The center hopping is gamma=eta/(16T), and the construction is inhomogeneous rather than translation invariant.

## 9. Interventions that cross the proved boundary

### 9.1 One additional far-end preparation

Suppose the experimenter may also prepare |+> at L_d with vacuum elsewhere and read that qubit. The two hypotheses have an onsite difference a_delta>=1/2 there. In the one-excitation sector ||C_s||<=2. Taylor expansion with its unitary remainder gives

    exp(-itC_s)=I-itC_s+R_s(t),     ||R_s(t)||<=2t^2.

Therefore the imaginary parts of the two endpoint return amplitudes differ by at least

    a_delta t-4t^2 >=t/4,      0<t<=1/16.                             (27)

After undoing K, this is a difference in a one-qubit Y expectation. With t_0=min(tau,1/32), O(t_0^(-2) log(1/alpha)) shots identify the supplied binary alternative. There is no dependence on d or T at fixed t_0 and confidence, and no microscopic reconstruction is required. For the dyadic variant the endpoint difference remains bounded below by an absolute constant, with the same order and an adjusted constant.

This is an explicit escape for this family, not a theorem that one far-end probe identifies every unknown Hamiltonian.

### 9.2 Waiting for the requested prediction time

Allowing one coherent experiment of duration t_star=pi/delta also defeats the explicit pair: the same initial product state and one-qubit rotating-frame X readout give a constant signal separation. This uses native time of order T. It is testing the system at the forecast time, not certifying that forecast from short experiments.

### 9.3 Systematic errors in the simple positive certificate

If calibration and readout errors can change each ideal rejection probability by at most beta, an upper confidence bound p_U on the observed rejection rate gives

    E_T <=(2T/h) sqrt(p_U+beta).

To certify error epsilon by this route requires beta=O(h^2 epsilon^2/T^2). Long-horizon model tolerance is not the same as tolerance to SPAM error. The lower bound already holds for ideal, noiseless experiments; hardware error cannot be its explanation.

## 10. Comparison with existing access models

The following primary sources were inspected. Their results remain credited; none is imported as an unproved premise of the construction.

1. **Zubida, Yitzhaki, Lindner and Bairey, Optimal short-time measurements for Hamiltonian learning**, arXiv:2108.08824. This studies Hamiltonian learning from short-time evolution with product preparation and local measurement. It prevents claiming that local product experiments, by themselves, are a new route to generator acquisition. Our lower bound instead restricts WHERE preparation and in-run control are available and asks for tolerant prediction of one state, not reconstruction.

2. **Bluhm et al., Certifying and learning local quantum Hamiltonians**, arXiv:2603.29809v1, version inspected displaying 24 August 2026. It gives O(1/epsilon) total-time tolerant certification in normalized Frobenius norm for fixed locality, using general time-evolution access and candidate-dependent processing. Ancilla-free variants are included; lack of an ancilla is not our claimed obstruction. A Frobenius-norm tolerance condition on H-K differs from tolerating the requested one-qubit trajectory. General/systemwide control and the coherent experiment duration also differ from Section 1. The paper explicitly discusses certification from local probes as a separate question.

3. **Shin and Tong, Hamiltonian Learning and Certification via Eigenphase Engineering**, arXiv:2609.26596, submitted 22 September 2026. It develops learning and tolerant certification with single-qubit operations and forward dynamics, without ancillas. Its addressability is not confined to the protected local ports here. Small simulation steps are not a bound on the total coherent duration of a fresh controlled experiment. Our result neither subsumes nor contradicts it.

4. **Chen, Cotler and Huang, Quantum Probe Tomography**, arXiv:2510.08499. This studies local quantum probes, including learning structured, symmetry-constrained many-body systems from tunable Gibbs-state and dynamics access, with identifiability and conditioning assumptions. Our inhomogeneous worst-case chain, fixed vacuum bath, and short per-run lifetime do not satisfy that entire interface. Our theorem does not rule out its structured or generic reconstruction guarantees.

5. **Liu et al., Learning Many-Body Hamiltonians Using a Local Probe**, arXiv:2610.02157v1, 1 October 2026. This is a particularly important recent comparison: one measurable/resettable qubit suffices under fast single-qubit controls THROUGHOUT the register, a connected reference backbone, and coherent information routing. A restricted global-control variant is also given. Thus a single readout site alone is not an information obstruction. The present lower bound restricts preparation and in-run control, not just readout, and imposes a per-fresh-experiment duration cap. Its constant-strength density interactions could serve as a reference backbone if appropriate systemwide rotations were supplied; those rotations are deliberately outside our access contract.

6. **Gong, Ma, Chen, Cotler and Huang, Out-of-control Hamiltonian Learning**, arXiv:2610.06709v1, 5 October 2026. It reconstructs generic two-local Hamiltonians using uniform single-qubit preparation/measurement settings across the whole system, and gives separate computational-basis results for specified X/Z interaction families. Restricted settings do not imply restricted spatial support: preparing and measuring the entire bath, and the stated genericity/structure guarantees, differ from the vacuum-bath local-port model here.

7. **Escudero Gutierrez, Lee and Zur, Hamiltonian locality testing and certification do not achieve the Heisenberg limit**, arXiv:2610.03205v2, 9 October 2026. Its abstract states quadratic precision lower bounds for forward-only testing in normalized Frobenius norm, without the present fixed-local-family promise. We inspected the abstract, not its complete proof, and do not import its adversary theorem or identify its problem with ours. In particular, it must not be conflated with the fixed-locality positive guarantee in item 2.

8. **Gao et al., Quantum Hamiltonian Certification**, arXiv:2505.13217. Certification being less expensive than full Hamiltonian learning is prior work, not a new principle claimed here.

The meaningful comparison is joint: WHERE one may act, HOW LONG a fresh system may retain coherent influence, WHAT state family can initialize the bath, WHICH distance is certified, and WHETHER approximately correct predictions must be accepted. Merely labelling both interfaces “local measurements” erases these differences.

## 11. Relationship to the preceding Astra work

The prior active imaginary-time result uses a programmable heralded filter and candidate-dependent coherent many-body preparations. Its one-sided residual certificate does not accept every approximately correct trajectory. It remains a distinct proof candidate for independent establishment.

The present theorem removes imaginary-time filtering altogether and gives an obstruction under ordinary active real-time local-port experiments. The full-channel overlap estimate (25), rather than the earlier logarithm identity, is its information argument. The isospectrality here is established directly by the reflection in (17)-(18); no scalar Genesis lower bound is silently combined with a quantum-snapshot theorem.

The already completed Genesis vector interface bridge remains preserved in the prior active-prediction note. It is not a premise of any new theorem here.

Research capital checked: Astra revision f12638af678bb8f3cc4039f10de78a55476a3a0c, including the branch index and the supplied complete active-prediction note; selective OpenAI/math catalogue search. The inherited OpenAI/math revision in this conversation is fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb. No result from either repository is imported as a mathematical premise. A failed search is not a priority determination. No repository was modified.

## 12. Evidence, exact limits and reproducibility

`check_core.py` generated `diagnostics.json` using 110-decimal-digit arithmetic and seeded NumPy/SciPy calculations. It passed 690 multiprecision and 751 floating-point assertions (1,441 total). Eighteen spectral constructions use d from 1 through 24 and eta in {0.125,0.04}. Checks include positive weights, moments, Jacobi prefixes, boundary changes, coefficient floors, connected and rounded target dynamics, and small interacting many-body systems with joint port-control pulses. The controlled simulations check uniform operator bounds over all input vectors on the two central qubits, rather than only one chosen state.

The largest multiprecision matched-moment error was about 1.0e-110; the largest reported Jacobi boundary error was about 2.1e-110. These are finite numerical diagnostics, NOT exact arithmetic, independent proof review, or proof of an untested general statement. The general arguments are Sections 3-9. `check_interfaces.py` additionally passed 1,061 floating-point assertions for the exact-null certificate, off-subspace freedom, far-end readout, and a finite dyadic example. The package therefore contains 2,502 numerical assertions in total; 690 are multiprecision, not exact arithmetic. `example_d4.json` records a ten-qubit finite coefficient instance.

The strongest established scope is a worst-case, task-specific impossibility and an exact-versus-tolerant separation. No matching upper bound for the tolerant problem is claimed. No universal tolerant certifier with all-site local access is excluded. No lower bound under all Gibbs-state preparations, translation invariance, uniform nonzero hopping, natural disorder or generic many-body inputs is proved. Classical computation is unrestricted in the lower bound, so its difficulty is acquiring the one missing bit, not simulating the fully specified small active matrices.
