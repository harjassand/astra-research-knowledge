# Peak certificate and ideal-model minimax sharpness

Author: gc_peak_genesis. Date: 2026-10-16. Status: internally derived analytic theorem; external correctness and historical priority UNKNOWN.

## 1. Contract and source reconstruction

Read-only capital pin: `9dbe934e5475f415c2d160a6c0715534aafa546b` in `/Users/harjas/Documents/ChatGPT/ultra/work/astra-positive-memory-20261016`. The incoming addendum optimizes a sufficient certificate, not observed physical error. Its proof is correct under its stated constant action envelope and deterministic intensity constraints.

Write T for duration, J for the constant interaction norm envelope, a=JT, L>0 for the peak of the **latent complete-pinch intensity**, and Λ for its integral. Admissible rates satisfy 0≤λ(t)≤L almost everywhere and ∫λ=Λ, with 0≤Λ≤LT. The certificate is

    C[λ] = J² ∫₀ᵀ∫₀ᵀ exp(−|u(t)−u(s)|) dt ds,
    u(t)=∫₀ᵗλ(v)dv.

Push Jdt through u to a positive measure μ on [0,Λ]. Its mass is a. For every nonnegative Borel f, absolute-continuity substitution gives

    ∫ f dμ = J∫ f(u(t))dt
            ≥ (J/L)∫ f(u(t))u'(t)dt
            = (J/L)∫₀^Λ f(v)dv.

Thus μ≥d dv, d=J/L. Plateaus, inverse singularities, and zero-rate pieces are allowed. Optimization over that larger measure class is a valid lower bound; the minimizers below are realized by actual admissible rates.

The exponential kernel is strictly positive definite on finite signed measures. An elementary representation is

    exp(−|u−v|)=exp(−u)exp(−v)
      +2∫₀^min(u,v) exp(−u+x)exp(−v+x)dx.

Its quadratic form is a square plus an integral of squares. Strictness also follows from its strictly positive Fourier transform 2/(1+ω²).

If Λ≤LT≤Λ+2, set q=(a−dΛ)/2, so 0≤q≤d. The minimizer is

    μ*=d dv+qδ₀+qδ_Λ,
    V*(v)=2d+(q−d)[e^(−v)+e^(−(Λ−v))].

The bracket is maximal at the endpoints. Hence V* is minimized there. Every feasible μ=d dv+ν has ν≥0 and mass 2q. Consequently ∫V* d(μ−μ*)≥0, and

    E(μ)−E(μ*)=2∫V* d(μ−μ*)+E(μ−μ*)≥0.

The exact minimum is

    C*=2d²(Λ−1+e^(−Λ))
       +4dq(1−e^(−Λ))+2q²(1+e^(−Λ)).              (1)

An attaining rate holds at zero for h=(T−Λ/L)/2 at both ends, and equals L on the middle interval of length Λ/L.

If LT≥Λ+2, the unconstrained equilibrium measure

    μ*=a/(Λ+2)[dv+δ₀+δ_Λ]

obeys the floor μ*≥d dv and has constant potential. Its exact minimum is

    C*=2a²/(Λ+2).                                 (2)

It is attained by zero-rate holds of length h=T/(Λ+2) at both ends and middle rate (Λ+2)/T. The formulas agree at LT=Λ+2. At Λ=LT the constant maximal rate is forced. At Λ=0, u is constant, both endpoint atoms coincide, and C*=a². J=0 and T=0 are trivial; L=0 forces Λ=0; Λ>LT is infeasible.

The equality argument proves uniqueness of the minimizing measure when a>0 and Λ>0. No claim that every measure above the floor is realizable is needed.

## 2. New theorem: uniform actual-error lower witness

This section supplies an **additional** ideal-model physical lower bound. It does not retrospectively identify the certificate with physical error. It uses a concrete model allowed by the exact source hypotheses.

For a known nonnegative integrable envelope j(t), let a=∫j(t)dt. On one actual qubit take

    H(t)=j(t)X,
    dρ/dt=−i[H(t),ρ]+(λ(t)/2)(ZρZ−ρ),
    ρ(0)=|0><0|.

The physical telegraph-Z realization has jump intensity γ(t)=λ(t)/2. Put ξ(t)=(−1)^{N(t)}, with ξ(0)=+1. Moving Z jumps through the Hamiltonian changes its sign. All remaining Hamiltonians are multiples of X, so the conditional final flip probability is sin²S, where

    S=∫₀ᵀ j(t)ξ(t)dt,
    |S|≤a.

The final Z product changes only the phase of a parity outcome. Therefore the **actual** final Born probability is

    p_λ=E sin²S.                                  (3)

For t≥s, independent Poisson increments give

    E ξ(t)ξ(s)=exp(−∫ₛᵗλ(v)dv).

It follows exactly that

    E S²=C[j,λ]
      :=∫∫j(t)j(s)exp(−|u(t)−u(s)|)dt ds.          (4)

For 0≤a<π, define κ(a)=(sin(a)/a)² with κ(0)=1. The function sin(x)/x is positive and decreasing on [0,π]: the derivative numerator x cos x−sin x has derivative −x sin x≤0 and vanishes at zero. Thus

    κ(a)x²≤sin²x≤x²  for |x|≤a<π.

Averaging yields the schedule-uniform, nonasymptotic sandwich

    κ(a) C[j,λ] ≤ p_λ ≤ C[j,λ].                  (5)

There is also the simple bound p_λ≥(1−a²/3)C[j,λ] when that coefficient is nonnegative, from sin²x≥x²−x⁴/3 and S⁴≤a²S².

Equation (5) has an actual admissible physical-qubit witness on its lower side, whereas the source's certificate theorem supplies a universal upper side for arbitrary allowed finite baths and reference states. These are different logical steps.

## 3. Exact-model minimax consequence

Let 𝒜 be any nonempty class of deterministic rate schedules. For each λ define W(λ) as the supremum of actual final parity-flip probability over all finite-dimensional Hamiltonians/baths/allowed initial states satisfying the source's single-parity conditions with envelope j(t): [H₀,Z]=0, {V,Z}=0, ||V(t)||≤j(t). The rate schedule is chosen using the supplied envelope, not the unknown Hamiltonian. Dephasing is exactly the stipulated generator. Define

    C_𝒜=inf_(λ∈𝒜) C[j,λ],
    W_𝒜=inf_(λ∈𝒜) W(λ).

The source's universal endpoint upper bound and the fixed witness (3) prove

    κ(a) C_𝒜 ≤ W_𝒜 ≤ min(1,C_𝒜),               (6)

where the upper statement uses approximating schedules if the infimum is not attained. For the fixed-J peak class, (1)-(2) give C_𝒜 exactly and an attaining schedule λ*. Therefore

    W(λ*)/W_𝒜 ≤1/κ(a)  when C_𝒜>0,
    W_𝒜/C_𝒜→1 as a→0.                           (7)

This proves asymptotic minimax optimality for actual endpoint error, uniformly over the peak and integrated-intensity parameters. It does **not** prove finite-a equality W_𝒜=C_𝒜, identify the finite-a optimal schedule, or provide a physical device error floor.

For target W_𝒜≤δ and a<π, the uncapped equilibrium lower bound supplies the necessary ideal-model resource condition

    Λ≥max(0, 2κ(a)a²/δ−2).                        (8)

If physical Z kicks implement the exact dephaser, their mean interior count is Λ/2, so (8) is mean count ≥max(0,κ(a)a²/δ−1). A detector implementation of actual full pinches instead has mean count Λ. Peak λ is neither physical Hamiltonian strength nor energy.

## 4. Selected-subset extension, including coupled budgets

Take r selected parities, each with envelope j_i, action a_i<π, and independent dephasing clocks with deterministic rates λ_i. The admissible **schedule class may couple** the rates through constraints such as ∑λ_i(t)≤LΣ or ∑∫λ_i=ΛΣ. Clock independence once the rates are fixed remains required.

For each schedule let C_i=C[j_i,λ_i]. The source gives the actual every-selected-flip effect ≤∏min(1,C_i). A permitted tensor-product witness takes H=∑j_i(t)X_i, H₀=0 and a product |0> input; it yields actual joint probability ∏p_i. Thus

    (∏κ(a_i)) inf_𝒜∏C_i
       ≤ inf_𝒜 sup_allowed_H Pr(all selected flip)
       ≤ inf_𝒜∏min(1,C_i).                        (9)

If every a_i≤1, then C_i≤a_i²≤1, so the right side is exactly inf_𝒜∏C_i. The certificate optimizer of **any** coupled admissible class is uniformly asymptotically minimax for the actual selected endpoint event as max a_i→0, for a fixed selected set. No independence of actual physical errors is assumed in the universal upper proof.

For constant J_i on one duration T, consider the coupled class

    ∑λ_i(t)≤LΣ,
    ∑∫λ_i(t)dt=ΛΣ.

In the regime LΣT≥ΛΣ+2r, its uncapped product certificate has the exact optimum

    C_joint*= (∏a_i²) [2r/(ΛΣ+2r)]^r.             (10)

Indeed C_i≥2a_i²/(Λ_i+2), and AM-GM bounds ∏(Λ_i+2)≤[(ΛΣ+2r)/r]^r. Equality is realized by Λ_i=ΛΣ/r for every selected coordinate and the same two endpoint holds, each of length rT/(ΛΣ+2r), with each middle rate (ΛΣ+2r)/(rT). Their aggregate middle rate is (ΛΣ+2r)/T≤LΣ. This exact equal-allocation rule is for the **all-selected product** objective; it does not optimize a sum of marginal errors or a weighted utility.

The coupled cap-active regime LΣT<ΛΣ+2r is not solved here. A coordinatewise peak-cap formula cannot be inserted as if aggregate cap and individual cap were interchangeable. If some a_i=0 the selected event vanishes, and uniqueness/equal-allocation claims are unnecessary.

## 5. Unknown profile obstruction

The known envelope is a substantive information interface. If the controller knows only total action a and permits arbitrary nonnegative j with that integral, then every finite latent peak L has

    inf_λ sup_(j≥0,∫j=a) C[j,λ]=a².               (11)

For any fixed admissible λ, take j_ε=a/ε on a time interval of width ε and zero elsewhere. Since |u(t)−u(s)|≤Lε on that interval,

    C[j_ε,λ]≥e^(−Lε)a²→a²,

while C≤a² always. The pulse location can be fixed independently of any private clock realization. A finite collection of deterministic refresh slots likewise has an open gap containing the pulse and gives C=a² exactly.

For the actual physical-qubit model, with 0<a≤π/2, the corresponding minimax supremum is sin²a. The parity-subspace angle bound gives p≤sin²a on every Z-kick trajectory. The concentrated pulse has no physical Z kick with probability at least e^(−Lε/2), giving p≥e^(−Lε/2)sin²a→sin²a. For a≥π/2 the supremum is one because the allowed interaction may use only π/2 of its envelope action. Thus no control-count suppression is uniform after discarding the pointwise envelope. This countermodel deliberately lies outside the original fixed-J contract when ε→0; it diagnoses the invalid transfer rather than refuting that contract.

## Scope

All physical-error claims above concern the exact stipulated finite-dimensional model. No microscopic dephaser, measurement, finite-width pulse, private-controller isolation, support/completion theorem, reset cost, useful memory threshold, or superiority over all acquired hardware incumbents has been established. The rate identity λ=2γ is retained throughout.
