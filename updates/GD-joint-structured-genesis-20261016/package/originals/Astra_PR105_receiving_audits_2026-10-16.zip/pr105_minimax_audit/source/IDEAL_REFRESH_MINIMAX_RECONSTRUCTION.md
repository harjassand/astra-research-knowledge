# Root reconstruction of exact ideal singleton minimax and its boundaries

2026-10-16. Internal analytic reconstruction of the construction in gc_peak_genesis, following a separate fixed-grid receiving deduction by gc_control_adversary. Random refresh/DD protocols are established primary prior art from2005. No new hardware, practical threshold or historical originality is claimed.

## Model and exact question

Choose N public deterministic refresh slots before the Hamiltonian is selected. An independent fair private bit toggles the frame at each slot; an initial private uniform frame and exact final tracked inverse are supplied. Every complete process, seed independence/coarse graining, covariance and support promise is retained. In virtual seed coordinates the fixed slots apply complete parity pinching, without acquiring a physical syndrome detector or observing a latent outcome. A fixed Hamiltonian may depend on public slots but may not read the private bits. It includes an arbitrary finite shared bath and syndrome-preserving baseline; its own parity-changing term has norm bounded by a known integrable j(t).

Let a_k be the action in gap k, m=N+1. For the singleton final odd-character effect, the exact worstcase over this admitted model is

    Q(a_1,...,a_m)=1-product_k cos^2(min(a_k,pi/2)).

For fixed total action a, the best public slot placement has equal-action gaps and minimax value

    Q_N(a)=1-cos^(2(N+1))(min(a/(N+1),pi/2)).

This is a singleton result. The previously proved shared-bath all-subset product of squared gap actions remains the receiving theorem for joint events. A product of singleton sine improvements is not asserted without a separate proof.

## Upper bound

In the interaction picture of the syndrome-preserving baseline, the subspace-angle bound gives ||P_minus U P_plus||<=sin(min(a_k,pi/2)). Its elementary proof integrates |p'|<=2j sqrt(p(1-p)) from p=0, equivalently arcsin(sqrt p)<=a_k, and applies to arbitrary input/bath/reference vectors. Thus ||P_plus Uv||>=cos(min(a_k,pi/2))||v|| for every vector in P_plus.

Compose the branch in which all pinch records retain the initial plus parity. Its norm on every initial joint vector is at least the product of these cosines. The good-history effect is therefore at least product cosines squared times identity on the admitted initial sector. Final odd parity implies a mismatch somewhere, so its whole-input effect is at most Q times identity. Normalized conditioning and independent quantum errors are not used.

## Adversarial bath attaining the bound

Use memory qubit M and bath states u,d_1,...,d_m. On gap k use

    H_k(t)=j(t) X_M tensor (|d_k><u|+|u><d_k|),

with zero baseline and initial |0_M,u>. If a_k exceeds pi/2, stop its interaction after pi/2 action, which respects the norm envelope. A good branch rotates by a_k from |0,u> to |1,d_k>. Every earlier |1,d_l> with l!=k is dark for the subsequent interaction. A first flip is consequently retained and cannot coherently return through a later bath channel. The final memory-flip probability is exactly Q, for every private sign realization; the correct Walsh effect has the same weight. A bath of dimension m+1=N+2 suffices. Exact minimax is over the admitted arbitrary-finite-bath class, or a fixed bath large enough to contain this witness. For a separately imposed smaller fixed bath, the upper bound survives but exact saturation has not been proved. This is an allowed time-dependent adversary, not a laboratory acquisition.

The bath construction shows why a bound for a constant, known Hamiltonian is a weaker comparator. An ideal deterministic echo can cancel a known fixed drive, while a fixed deterministic sign path fails against a time-dependent drive following that public path. Fresh private randomness changes the unknown-H information contract.

## Optimization and actual resource boundary

On [0,pi/2), log cos is concave. Jensen makes the product cos^2 largest at equal a_k and minimizes Q. If any a_k>=pi/2, Q=1; if a/m>=pi/2 every partition has such a gap and minimax1 is attained. Nonnegative integrable j admits equal-action cuts by continuity of its cumulative integral (zero-action intervals need no special cost assertion).

For small a, Q_N(a)=a^2/(N+1)+O(a^4). Internal actual toggles are bounded by N and have expectation N/2. N fresh bits/slots and initial/final wrappers are still paid. The fixed-grid all-subset certificate is sum gap-action squared, minimized at a^2/(N+1). At equal mean actual flips n, use N=2n for integer2n; its certificate a^2/(2n+1) improves the cap-inactive Poisson certificate a^2/(n+1). This is an exact ideal resource comparison, not a qualified finite-width controller advantage. A Poisson latent pinching rate lambda is twice the actual telegraph flip rate gamma; these counts must not be conflated.

For Poisson control, a constant singleton drive JX gives physical p=E sin^2(J integral xi), while C=J^2 E(integral xi)^2. If a=JT<pi, sinc^2(a)C<=p<=C. Thus sinc^2(a)C_star<=inf_schedule sup_admitted_H p<=C_star. The incoming peak-cap optimizer is asymptotically minimax as a tends to zero; it need not optimize finite-a error for a known Hamiltonian. The explicit finite-a counterexample in gc_control_adversary preserves this distinction.

For the constant envelope, 0<a<=pi/4 and integer N>=1, there is a strict actual ideal-model comparison at matched mean internal flips N/2: Q_N<=a²/(N+1)<sinc²(a)*2a²/(N+2)<=the optimal Poisson worst-case error. Indeed sinc²(a)>=8/pi²>3/4, and (N+2)/(2(N+1))<=3/4. This uses a universal fixed-grid upper and a constant-drive Poisson lower, not a comparison of upper certificates alone. These are different ideal timing classes: instantaneous grid updates do not satisfy a bounded continuous dephasing rate, and no common physical bandwidth/cost advantage has been established.

Finite-width ramps, residual action, endpoint errors, retained record access, actual peak pulse bandwidth, reset/entropy/energy and physical support still require an acquired complete model. No exact ideal-identity CP coin is inferred from ordinary gate infidelity. An exact ideal minimax theorem does not supply those missing operations.
