# Independent adversarial review: universal pair-clock ticket envelope

Reviewed exact source SHA-256 `d837200b12c7c2f4b725e0a850dbb7aa5033c14cfa6e55a9d188c94bd241fb09`. No acquired program was executed. This review covers the local universal domination and certificate-service argument, not the imported global percolation/decoder results or priority.

## Result

I found no counterexample to the local claim. The simultaneous Pauli-history domination survives the reset, retained coupon mask, separate CSS-clock, monotonicity, and independent-certificate challenges, under the stated cycle-syndrome geometry, fault-boundary coverage, independent physical Poisson streams, and a fault-free guarded finite height region for clearance certificates. Below is an explicit proof of the potentially delicate parts. This is stronger evidence than the bounded checks, but not a verification of the final diamond-norm theorem.

## 1. Exact reset-epoch invariant

Fix one sector and a vertex v. Partition its evolution into intervals between full resets to `(2,Omega)`. Within such an interval every actual incoming edge at v is constant, and the set of actual outgoing edges can only decrease through v's own legal pair actions.

Indeed a fault capable of changing an incident edge resets v by the stipulated boundary box. Any correction changing an incident edge at v, other than one centered at v, has v as a side or far corner. Immediately before a legal correction at w, the two outgoing checked edges make w and both side vertices incident. The inductive support invariant makes all three ticket states positive. The conservative three-source rule therefore resets both sides and the far corner. This is true whether the changed edge is added or removed. Thus no noncentral actual incident-edge change can occur inside a reset epoch.

If a reset epoch contains a progress tick, all envelope predecessors at that tick are zero. By support domination there are no actual incoming edges then. The constancy just proved implies that there were no incoming edges anywhere in that reset epoch. The actual outgoing set is consequently even, by the cycle constraint. Each coupon phase completing in that epoch has seen every pair label. Unless its outgoing set was already empty, either some pair action occurred, removing two edges, or the unchanged nonempty even outgoing set contains a pair whose visited label would have forced an action, a contradiction. Two completed phases clear all at most four outgoing edges. At the final progress tick incoming edges are absent as well.

A transient positive predecessor between center marks is therefore harmless: it either reflects a real incident-edge change, which resets the complete ticket immediately, or it reflects no such change, and the reset-epoch invariant remains valid. No assumption that predecessors remained zero between ticks is used.

This induction is pointwise for each schedule and each Pauli history. Its ticket evolution contains no Pauli choices, so the same schedule-dependent envelope dominates all histories simultaneously. Separate sector copies are essential. Opposite-sector actions preserve this sector's syndrome and do not supply a coupon.

## 2. Monotonicity of the complete simultaneous maps

For equal phase numbers, deleting the same label preserves mask inclusion unless the smaller mask finishes the phase; in that case its new phase is smaller. For unequal phases, the only potentially adverse case is phase two completing: its result is the maximum phase-one state, above every ticked phase-one state. Zero is preserved.

The center predecessor-block predicate is increasing. When only the larger input is blocked it resets to top, dominating the smaller output. When neither is blocked the preceding tick argument applies; when both are blocked both outputs are top. Positivity at the center causes no exception because an uninfected center remains zero. Each downstream reset predicate is increasing, and otherwise its target persists. These coordinatewise facts establish monotonicity even with all old-state reads performed simultaneously.

## 3. An explicit independent-certificate construction

Work in a finite increasing-height DAG with a permanently healthy lower boundary and no further fault births or unaccounted external influence. For each site v define recursively:

- `T_v = max U_p` over its predecessor certificates, with boundary times zero.
- Starting at T_v, wait for one occurrence of each of v's six labels; then wait for another full collection. Call the elapsed time D_v and set `U_v = T_v + D_v`.

By induction all predecessors are permanently healthy after T_v. A side reset into v would require its already healthy anchor predecessor to be positive. A far reset into v would require two already healthy immediate predecessors of v to be positive. Neither is possible. Therefore v clears by U_v even if its ticket at T_v is top, and remains clear thereafter.

Crucially, T_v is a function only of lower-height certificate streams, not v's stream. Conditional on all lower-height streams, each v starts at a fixed time in an independent stationary Poisson process. Its six residual waits are independent exponentials. The second collection starts at a stopping time of that site's process, so independent increments/strong Markov gives the same fresh law. Conditional joint laws across sites of the same height are products and do not depend on the lower-height streams. Inducting over heights proves that the D_v are mutually independent and identically distributed. This does not assert independence of actual clearance times or actual ticket states, which can have lateral dependence.

For a collection `M=max(E_1,...,E_6)`, `M <= sum E_i` implies `E exp(kappa M/2) <= 2^6`. Thus `E exp(kappa D_v/2) <= 2^12`. The maximum-predecessor recurrence expresses U_v as a maximum of path sums of independent D's. A union bound over at most 4^h paths of length h, followed by a geometric sum for h<=H, gives the displayed conservative bound `2*(16384)^H*exp(-kappa*t/2)`.

The source's phrase "at the time its predecessors clear" should be read as these recursively defined certificate completion times. An explicit recurrence would eliminate possible confusion with random actual clearances. The recurrence supplies the claimed result; it is not a new substantive assumption beyond the local fault-free DAG setting.

## 4. Scope and checks

The proof uses valid even-degree CSS cycle syndromes and the usual four positive-edge plaquette boundary incidence. It is not a proof for unconstrained arbitrary edge subsets. The clearance certificate also needs the guard argument to exclude fresh faults and outside interference. Whether the imported guard, torus replay, LSS, and decoder interfaces actually meet those hypotheses remains separate.

The independently written `check_ticket.py` exhaustively checked 32,556 comparable-state/label tick inequalities. A finite state exploration representing all arbitrarily repeated label words from every even outgoing subset reached 319 local states; every completed two-phase ticket had an empty outgoing set. These checks corroborate the algebra, not the global or asymptotic theorem.

## 5. New local derivation: sharper certificate constants

This refinement is not quoted from the acquired source. It changes quantitative upper-bound constants only, with no new global conclusion.

A complete coupon phase starting at a valid certificate start time has duration `M = max(E_1,...,E_6)`, for independent rate-kappa exponential residual waits. The six ordered exponential spacings are independent with rates `6*kappa,5*kappa,...,kappa`. Therefore its exact moment at `theta=kappa/2` is

`E exp(kappa*M/2) = product_{j=1}^6 j/(j-1/2) = 1024/231`.

Completion of the first full collection is a stopping time for the site's six Poisson processes. Strong Markov supplies six fresh independent residual exponential waits for the second collection. Thus the two complete collection durations are independent, and the exact moment for the deliberately dominating certificate duration D is

`B = E exp(kappa*D/2) = (1024/231)^2 = 1048576/53361 = 19.650606248008845...`.

This is the MGF of the full two-collection certificate, not necessarily of actual service from a partially completed ticket. The lower-height conditioning argument in section 3 still proves the required joint independence of these D's.

Set

`K = 4*B = 4194304/53361 = 78.60242499203538...`.

For height H, the same path union bound gives `sum_{h=1}^H K^h * exp(-kappa*t/2)`. Since `K>2`, the finite geometric sum is at most `K^H*K/(K-1) < 2*K^H`, so the same conservative tail form survives:

`P(delay>t) <= 2*K^H*exp(-kappa*t/2)`.

Consequently the service-failure term in displayed equation (4) can be sharpened to

`2*b^4*exp((5*log(K)-C/2)*b)`.

The sufficient condition is now `C > 10*log(K) = 43.644025512752094...`. Replace `16384` by K in the service/path expressions and their logarithms. Do not automatically replace the numerically coincident `4096` in the separate guard condition `R >= 4096*e*C + 10`: that guard constant also protects the ordered dependency-chain estimate, whose combinatorial constants have not been improved here. The existing R condition can simply be retained with the selected C.

The LSS tolerance and final threshold remain qualitative. The calculation does not establish a useful numerical noise threshold, improve an independently unverified global interface, or change the conditional status of the claimed theorem.
