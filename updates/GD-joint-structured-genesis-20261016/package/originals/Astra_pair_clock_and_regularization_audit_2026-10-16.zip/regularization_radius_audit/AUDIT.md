# Exact fixed-rate channel-compiler radius

Independent audit, 16 October 2026. Verdict: the proposed factor-two refinement and minimax claim are correct, with the scope and norm conventions below. No canonical source was edited.

## Statement and conventions

Let d >= 2, nu > 0, and let E: M_d(C) -> M_d(C) be complex-linear, Hermiticity preserving and trace annihilating (Tr E(X)=0 for every X). Use the ordinary, unhalved diamond norm, for which channels have norm 1 and channel distances are at most 2. Define

J(Phi) = (Phi tensor Id)(|Omega><Omega|),  |Omega> = d^(-1/2) sum_k |k,k>.

Then the largest eta such that D + E/nu is CPTP for every such E with ||E||_diamond <= eta is exactly 2 nu/d^2. Here D(X)=Tr(X) I/d. The closed ball at equality is included.

The source REGULARIZED_ROBUST_MEMORY.md explicitly uses normalized Choi and a channel-distance bound 2, so these conventions match. Its current nu/d^2 sufficient bound is valid but not sharp.

## Sufficiency, including the lost factor two

H=J(E) is Hermitian and has zero partial trace over the output, hence Tr H=0. Its Jordan decomposition H=H_+ - H_- satisfies

Tr H_+ = Tr H_- = ||H||_1/2.

Consequently ||H||_op <= ||H||_1/2. In addition, the normalized maximally entangled projector has trace norm 1, so the diamond-norm definition directly gives ||J(E)||_1 <= ||E||_diamond. Therefore

J(D+E/nu) >= (1/d^2 - ||E||_diamond/(2 nu)) I >= 0.

Complete positivity follows from the Choi criterion, and trace preservation follows from trace annihilation of E. Trace zero alone would suffice for this spectral inequality, but the stronger partial-trace-zero condition is essential for the trace-preserving conclusion.

## Sharpness

Choose Hilbert–Schmidt orthogonal unitaries U,V, i.e. Tr(U^* V)=0, and denote their conjugation channels by C_U,C_V. Their normalized Choi vectors u=(U tensor I)Omega and v=(V tensor I)Omega are orthonormal. The maximally entangled input proves

||C_V-C_U||_diamond >= || |v><v| - |u><u| ||_1 = 2.

The triangle inequality and channel norm 1 give the reverse bound. Thus E=(eta/2)(C_V-C_U) has diamond norm exactly eta, is HP and trace annihilating, and its Choi matrix has eigenvalues -eta/2,+eta/2,0,...,0. The minimum eigenvalue of J(D+E/nu) is exactly 1/d^2-eta/(2 nu), negative whenever eta>2 nu/d^2.

For d=2 take U=I,V=Z. In a Bell basis J(D+E/nu) has diagonal entries 1/4-eta/(2 nu), 1/4+eta/(2 nu), 1/4, 1/4. At eta=nu/2 it is positive semidefinite with eigenvalues 0,1/2,1/4,1/4; every larger eta fails CP.

## Minimax among fixed CPTP baselines

For a CPTP baseline N, define r(N) as the supremum of radii eta for which N+E/nu is CPTP for every admissible E in that diamond ball. Choose the d^2 Weyl unitaries X^a Z^b; their normalized Choi vectors {u_i} form an orthonormal basis for every integer d, not only prime d. Since Tr J(N)=1, some i has

<u_i,J(N)u_i> <= 1/d^2.

Choose any j unequal to i and E=(eta/2)(C_j-C_i). The preceding norm calculation applies, and

<u_i,J(N+E/nu)u_i> <= 1/d^2-eta/(2 nu).

Thus every eta>2 nu/d^2 fails universally for every N. Combined with sufficiency for D,

max_{N CPTP} r(N) = r(D) = 2 nu/d^2.

The proof establishes an optimizer, not uniqueness or nonuniqueness. Say “uniqueness is not addressed,” rather than suggesting that other optimizers have been demonstrated.

## Scope limits and useful stress test

- For d=1 the admissible perturbation space is {0}, so the universal radius is unbounded, not 2 nu.
- With a half-diamond-distance convention, the numerical radius is nu/d^2. With an unnormalized Choi matrix all intermediate Choi quantities gain a factor d; the standard-diamond answer remains 2 nu/d^2.
- The minimax baseline is fixed before E is selected. The statement does not cover E-dependent baselines, adaptive or increased proposal rates, multiple alternative compiler structures, restricted perturbation classes, or other norms.
- Importantly, in the depolarizing sharpness example U=I one has E=(eta/2)(C_V-Id), itself a Lindblad proposal generator. The full generator nu(D-Id)+E is then Lindblad at every eta>=0 and can be compiled at total rate nu+eta/2. Its failure at the original fixed rate nu is not nonphysicality or a logical-error lower bound.
- Hence d^2 is unavoidable for this fixed-rate affine uniform-ball compiler, not a universal obstruction to robust quantum memories. The source's other probability, topology, and recovery premises are outside this audit.

## Verified mathematical references

John Watrous, The Theory of Quantum Information (2018), Chapter 2, Theorems 2.22 and 2.26 (Choi positivity and trace-preserving characterization): https://cs.uwaterloo.ca/~watrous/TQI/TQI.2.pdf . Watrous uses unnormalized Choi matrices; divide by d here.

Chapter 3, Definition 3.43 (completely bounded trace/diamond norm): https://cs.uwaterloo.ca/~watrous/TQI/TQI.3.pdf . The maximally entangled lower bound used above is immediate from this definition.

These references support the standard ingredients, not an independently checked historical priority claim for this exact minimax formulation. The factor-two and minimax arguments above are self-contained.
