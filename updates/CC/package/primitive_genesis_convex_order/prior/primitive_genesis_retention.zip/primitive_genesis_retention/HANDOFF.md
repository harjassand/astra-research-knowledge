# Research handoff — no status promotion

## Strongest reusable mechanism

For a compact group acting orthogonally on a real inner-product space, keep the relation between a supplied action g and its stochastic transition P_g by using the transfer

(A_P z)_i = integral rho(g)^(-1) sum_j P_g(i,j) z_j dmu(g).

Its dual propagates unnormalized conditional means. Positivity gives a one-step orbit-quantization contraction; independent actions compose the actual transfers. Uniform small-ball bounds must hold for **all normalized conditional means**, not just the initial orbit.

For sphere rotations the exact coefficient is eta_(m,d), and maximum retained directional information is eta_(m,d)^T. For unitary conjugation on traceless Hermitian matrices, a uniform eigenvalue-gap-to-Grassmann argument gives 1-kappa_(m,D) of order m^(-1/(D-1)). It does not prove exact attainment of kappa^T. The separate polytope construction gives the matched state complexity T^(D-1).

## Exact theorem contract

Fix D>=2, delta in (0,1/(D^2-1)], epsilon in (0,delta/[2(D^2-1)]). Preparations are all density matrices, queries are the displayed weak binary effects, and gates are arbitrary supplied unitaries. Simulation is sequential, finite-state, Markov, and uniformly accurate for all words through T. Transitions may depend arbitrarily and measurably on time and current gate. They cannot use an uncharged persistent seed, correlated external noise, earlier inputs or a stored continuous state.

Minimum classical states: Theta_(D,delta,epsilon)(T^(D-1)). Static size: exactly D^2. Quantum Hilbert-space dimension: D. Classical bits: (D-1)log_2 T + O_(D,delta,epsilon)(1).

## Single next mathematical obligation

Prove or refute the sharp linear state law for the fixed qubit rotation alphabet

{I,R_x,R_x^(-1),R_z,R_z^(-1)},

where the two nonidentity rotations have cosine 3/5 and sine 4/5 about the named axes, at delta=1/3 and epsilon=1/72.

The supplied finite-alphabet block profile is a proved interface, not a solution. Do not silently use the continuous-Haar one-step coefficient for this finite alphabet: it becomes one once the state count exceeds the alphabet size. The target is unresolved in this investigation, without any claim that it is globally new or open in the literature.

The alphabet is dense in SO(3): if its rotation angle were a rational multiple of pi, then 2cos(theta)=6/5 would be a rational algebraic integer, hence an integer, a contradiction. Its powers are therefore dense in each of two perpendicular axis circles; those circles generate SO(3). This establishes density, not a quantitative simulation lower bound.

## Branch transfers

Theoretical Pro: use the uniform spectral-orbit estimate, the static/dynamic positive-realization separation, and the fixed-alphabet obligation. Do not use the unreviewed Astra N507 source theorem as a proved dependency.

Ultra: implement the polytope compiler only with explicit net, triangulation, barycentric, arithmetic and sampling costs. A state-count theorem is not an efficient practical algorithm or a computational quantum speedup.

Natural-Sciences Pro: the bounded output score is a model-class witness only after all correlated memory and observational access are specified. No new physical law or empirical discovery is established.

## Provenance and validation

Astra pin: 8aed7fd74eb14622ed5a0a3635a799374296e32a.
OpenAI/math pin: fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb.
The latter was used for navigation/comparison only; no manuscript result was imported.

497 distinct finite checks were replayed, with a preserved symbolic-checker correction. Analytical proofs were developed in one session. No external audit, formal proof, complete priority review or historic breakthrough is certified. Keep this packet provisional in any shared research system.
