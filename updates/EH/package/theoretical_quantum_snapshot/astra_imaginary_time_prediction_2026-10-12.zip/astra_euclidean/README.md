# ASTRA imaginary-time prediction package

Read `research_note.md` for the access model, theorem statements, complete derivations, finite-bit variant, coherent-query corollary, counterexample to arbitrary-seed generalization, and limitations.

`check_construction.py` runs finite diagnostics, not an independent verification of the theorem. `check_results.json` is the captured output. To replay in a suitable Python environment:

```sh
python -m pip install -r requirements.txt
python check_construction.py
```

The requirements record the package versions in the successful execution environment. The script overwrites `check_results.json`. Neither historical novelty nor independent mathematical correctness has been certified. No files were written to either research repository.
