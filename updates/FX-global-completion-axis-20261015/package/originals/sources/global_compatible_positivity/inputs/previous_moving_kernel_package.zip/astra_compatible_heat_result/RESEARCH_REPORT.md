# Moving acoustic kernels: an exact compatible-heat family beyond G

**Research date:** 15 October 2026.  
**Status:** Proof and exact rational certificates constructed in this investigation. The portable algebraic verifiers pass. Independent external mathematical review, formal proof verification, and historical priority are unresolved.

## Executive result

Write

\[
 A=\begin{pmatrix}a&b\\c&d\end{pmatrix},\quad
 u=a^2+c^2,\quad v=b^2+d^2,\quad w=ab+cd,\quad j=ad-bc,
\]

and

\[
 H(A)=(u+v-2j)^2=((a-d)^2+(b+c)^2)^2.
\]

For

\[
 -\frac{21}{8}\le r\le-\frac52,
 \qquad F_r=3H+\frac{r(r-1)}6u^2+j^2+r\,uj,
 \qquad \kappa=\frac3{16000},
\]

the exact certificate in this package proves that **\(F_r-\kappa H\) is quasiconvex at every affine background**. The endpoint \(F_{-5/2}\) is Astra's G. Every \(F_r\) in the interval is non-polyconvex and acoustically degenerate, yet

\[
 \int_\Omega [F_r(B+D\phi)-F_r(B)]
 \ge \frac1{2500000}\int_\Omega |D\phi|^4
\]

for every constant B and every \(\phi\in W^{1,4}_0(\Omega;\mathbb R^2)\), on every bounded Lipschitz planar domain. The same constant works on periodic rectangles and on zero-end-profile periodic strips of arbitrary finite width.

A four-parameter consequence is an exact rank-one-convexity/quasiconvexity equivalence on a specified coefficient sector. This does not resolve the full nine-coefficient cone. The genuinely new certificate step is to move the six-dimensional kernel forced by the acoustic geometry, rather than merely changing the positive matrix in the old fixed support.

## 1. Source reconstruction and attribution

The following repository materials were read rather than inferred from status summaries:

* N850 dossier and `updates/FT-direction-transport-20261015/synthesis/nonlinear_qc/G_QUASICONVEXITY_PROOF.md`.
* All load-bearing C, S, diffusion, and two-form coefficients in `G_EXACT_HEAT_CERTIFICATE.json`.
* N860 dossier and Sections 1–3 of `updates/FU-regularization-clock-pressure-20261015/package/workers/qc_genesis_astra/REPORT.md`.
* The coefficient representation and acoustic normalization in the N850 isotropic-transfer obstruction note.

The source certificate coefficients were transcribed from the retrieved source ranges into `reconstruct.py`. Exact checking establishes the resulting mathematical identity; this was not a byte-for-byte download of the source JSON, and the original claimed SHA-256 was not independently recomputed. The new exported certificate has its own hash in the verification receipt.

The reconstructed source identity is

\[
 Z^TCSC^TZ=d_1D^2G(A)[B_1,B_1]+d_2D^2G(A)[B_2,B_2]
                  +\omega_A(B_1,B_2),
\]

with

\[
 d_1=4897/5000,\qquad d_2=5103/5000,
\]

\[
 B_1=(z_0,z_1,z_3,z_4),\quad
 B_2=(z_1,z_2,z_4,z_5),\quad Z=(a,b,c,d)\otimes(z_0,\ldots,z_5).
\]

Here matrix vectors use row-major ordering, C is 24 by 18 of rank 18, S is positive definite, and omega is a closed two-form with homogeneous quadratic coefficients. Reconstruction checks the full polynomial identity, closedness, the primitive \(\alpha=\iota_E\omega/4\), and all 18 positive rational LDL pivots. It also checks the rank-two subtraction used in N860.

**Inherited ingredients.** Bruno–Pasqualotto's paper develops the heat-flow/exact-two-form operation and proves the rank-one-convexity/quasiconvexity equivalence for quartics with both left and right rotational invariance. N850 supplies the particular anisotropic G certificate. N860 supplies the elliptic-distortion subtraction and its general coercivity implication. Neither the general heat method nor the elliptic-subtraction principle is claimed as new here. The present additions are the moving-kernel family certificate, its coefficient-sector characterization, and the scoped structural limitations below.

## 2. Main coefficient-sector theorem

Define

\[
 F_{\alpha,\beta,\gamma,\delta}
 =\alpha H+\beta u^2+\gamma j^2+\delta uj.
\]

### Theorem 1

Assume

\[
 \gamma\ge0,\qquad \alpha\ge3\gamma,
 \qquad -\frac{21}{8}\gamma\le\delta\le-\frac52\gamma.
\]

Then the following are equivalent:

\[
 F_{\alpha,\beta,\gamma,\delta}\text{ is rank-one convex},
\]

\[
 F_{\alpha,\beta,\gamma,\delta}\text{ is quasiconvex},
\]

\[
 \boxed{\begin{pmatrix}6\beta+\delta&\delta\\\delta&\gamma\end{pmatrix}
 \succeq0.}
\]

When \(\gamma>0\), the matrix condition is exactly

\[
 \boxed{\beta\ge\frac{\delta(\delta-\gamma)}{6\gamma}.}
\]

For every member satisfying these conditions,

\[
 F_{\alpha,\beta,\gamma,\delta}-\gamma\kappa H
 \quad\text{is quasiconvex},
\]

and its affine Jensen gap is at least

\[
 \frac{\gamma}{2500000}\int |D\phi|^4.
\]

The coefficient set is explicitly spectrahedral: it is cut out by linear scalar inequalities and the displayed 2 by 2 positive-semidefinite matrix. It is a four-dimensional coefficient sector, or a three-dimensional section after positive homogeneous normalization; it is not an open subset of the full nine-dimensional invariant space.

### Proof: necessity

For \(\gamma>0\), put \(r=\delta/\gamma\), and consider the matrix and rank-one direction

\[
 A_t=\begin{pmatrix}1&-(r+1)t\\(r+1)t&1\end{pmatrix},
 \qquad R_t=e_1\otimes(t,1).
\]

Direct differentiation gives the exact identity

\[
 \begin{split}
 D^2F_{\alpha,\beta,\gamma,\gamma r}(A_t)[R_t,R_t]
 ={}&(12\beta-2\gamma r^2+2\gamma r)t^2\\
 &+2(r+1)^2(2\beta+\gamma r)t^4.
 \end{split}
\]

Rank-one convexity therefore requires the coefficient of \(t^2\) to be nonnegative, yielding the threshold. This is an independently checkable necessary condition, not an inference from certificate failure.

When \(\gamma=0\), the wedge forces \(\delta=0\). At A=I, the H term has zero Hessian, and a rank-one direction with a nonzero first-column variation tests \(\beta\ge0\). This is precisely the positive-semidefinite condition in that case.

### Proof: sufficiency

For \(\gamma>0\), write

\[
 F_{\alpha,\beta,\gamma,\delta}
 =\gamma F_r+(\alpha-3\gamma)H
 +\left(\beta-\frac{\gamma r(r-1)}6\right)u^2.
\]

Both H and \(u^2=|(a,c)|^4\) are convex functions of A. The moving certificate proves \(F_r-\kappa H\) quasiconvex. Positive addition proves the claimed quasiconvexity and subtraction margin. Quasiconvexity implies rank-one convexity. When \(\gamma=0\), the integrand is a nonnegative combination of H and \(u^2\), hence convex.

**A slightly larger certified sector.** The same equivalence remains valid after replacing \(\alpha\ge3\gamma\) by \(\alpha\ge(3-\kappa)\gamma\). In that sector the directly available subtraction is

\[
 \bigl[\alpha-(3-\kappa)\gamma\bigr]H,
\]

so its guaranteed pure-fourth-order Jensen constant is this bracket multiplied by \(4/1875\). At the lower alpha boundary that particular bound is zero. The value \(3-\kappa\) is a sufficient floor, not the optimal alpha threshold.

## 3. Acoustic geometry and the moving kernel

Every left-SO(2)-invariant homogeneous quartic has the nine-coefficient representation

\[
 f_0u^2+f_1v^2+f_2uv+f_3w^2+f_4uw+f_5vw+f_6uj+f_7vj+f_8wj,
\]

using \(uv=w^2+j^2\). If such a polynomial is rank-one convex and has the contact

\[
 D^2F(I)[e_{12},e_{12}]=0,
\]

the first derivatives of its nonnegative acoustic form at this zero must vanish. Exact linear elimination gives

\[
 f_1=-f_7/4,\qquad f_2+f_3=-f_7/2,\qquad f_4=f_5=f_8=0.
\]

These five conditions leave exactly the four-dimensional space in Theorem 1. Thus the family is selected by an acoustic contact, not merely by choosing a convenient collection of monomials.

On the threshold \(\beta=\gamma r(r-1)/6\), the same acoustic test becomes

\[
 D^2F(A_t)[R_t,R_t]
 =\frac23\gamma r(r+1)^2(r+2)t^4.
\]

Its second-order term vanishes. This fourth-order flatness forces a kernel in every positive Gram heat representation.

To see this, choose a target rotation \(R_\theta\), let the rank-one compatible second jet have target vector \(R_\theta e_1\) and spatial vector \(\xi_t=(t,1)\), and set

\[
 Z_\theta(t)=\operatorname{vec}(R_\theta A_t)
 \otimes\bigl((R_\theta e_1)\otimes\xi_t^{\otimes2}\bigr),
\]

with the six Hessian entries ordered as above. B1 and B2 are proportional, so every two-form correction vanishes on this jet. A positive Gram Q consequently satisfies

\[
 Z_\theta(t)^TQZ_\theta(t)=O(t^4).
\]

Since Q is positive semidefinite, first \(QZ_\theta(0)=0\), then \(QZ'_\theta(0)=0\). The six vectors obtained from \(\theta=0,\pi/2,\pi/4\) are independent for \(r\ne-1\). An explicit six-row minor is \(-(r+1)/4\). They therefore force a six-dimensional nullspace in every such Gram certificate, for any fixed positive input diffusion.

The columns of \(C_r\) in the new certificate are precisely a basis for the orthogonal complement of this forced kernel. Relative to the source C, only four entries change:

\[
 C_r[5,5]=C_r[8,5]=-\frac1{r+1},\qquad
 C_r[5,10]=C_r[8,10]=\frac1{r+1},
\]

with zero-based indices. All other entries stay fixed. At \(r=-5/2\), these reduce to the original \(\pm2/3\). A fixed 18-row submatrix of \(C_r\) is the identity, so its rank is always 18 on the interval. The structural verifier checks both the six forced vectors and this full-column-rank assertion.

**Interpretation.** On this flat acoustic stratum, the correct Gram support is geometrically determined and varies with r. Freezing it freezes most of the mathematics.

## 4. Exact certificate on the whole parameter interval

The portable file `MOVING_ACOUSTIC_CERTIFICATE.json` contains polynomial numerator matrices for

\[
 C_r=\frac{C_N(r)}{r+1},\qquad
 S_r=\frac{S_N(r)}{-(r+1)},\qquad
 W_r=\frac{W_N(r)}{-(r+1)}.
\]

Here C_N has degree at most one; S_N and W_N have degree at most three. W_r supplies the 60 coefficients of the quadratic two-form. Entries are rational strings, with explicit row, jet, monomial, and form orderings.

The full identity is

\[
 Z^TC_rS_rC_r^TZ
 =d_1D^2F_r(A)[B_1,B_1]+d_2D^2F_r(A)[B_2,B_2]
 +\omega_{r,A}(B_1,B_2),\qquad d\omega_r=0.
\]

It holds symbolically in r, A, and all six independent compatible jet coordinates. The verifier multiplies away denominators and checks every coefficient, rather than checking sample fields or parameter values.

For the scalar convex quartic \(h(A)=(a-d)^4\), set

\[
 v_1=e_0-e_{12}+e_{16},\qquad v_2=-e_{13}+e_{17},
 \qquad K=12d_1v_1v_1^T+12d_2v_2v_2^T.
\]

The same, r-independent matrix K gives

\[
 Z^TC_rKC_r^TZ
 =d_1D^2h(A)[B_1,B_1]+d_2D^2h(A)[B_2,B_2].
\]

Let \(\epsilon=1/2000\). The crucial positivity statement is

\[
 S_r-\epsilon K\succ0
 \quad\text{for every }r\in[-21/8,-5/2].
\]

This is proved by an exact finite interval certificate. Put

\[
 T_r=-(r+1)(S_r-\epsilon K),\qquad
 t=8(r+21/8)\in[0,1].
\]

T is a cubic matrix polynomial. The verifier reconstructs its Bernstein representation

\[
 T_r=\sum_{i=0}^3\binom3i t^i(1-t)^{3-i}\mathsf B_i.
\]

All four constant rational matrices \(\mathsf B_i\) have exact positive LDL factorizations: **72 strictly positive rational pivots** in total. Every Bernstein weight is nonnegative and their sum is one. Hence T, and therefore \(S_r-\epsilon K\), is positive definite on the entire interval, endpoints included.

The initial discovery calculation fixed 48 free certificate coefficients at their source values and solved the remaining 183 equations over the rational-function field. That procedure is not a theorem premise: the standalone verifier reads only the exported JSON and reconstructs all required identities and positivity conditions.

## 5. Analytic implication and coercivity

Fix a compactly supported smooth perturbation phi and a constant B, and evolve

\[
 \phi_\tau=e^{\tau(d_1\partial_{xx}+d_2\partial_{yy})}\phi,
 \qquad A_\tau=B+D\phi_\tau.
\]

For \(\widetilde F_r=F_r-\epsilon(a-d)^4\), use relative energy

\[
 E(\tau)=\int_{\mathbb R^2}
 [\widetilde F_r(A_\tau)-\widetilde F_r(B)
 -D\widetilde F_r(B):D\phi_\tau].
\]

The closed homogeneous-quadratic two-form has the global primitive
\(\alpha_r=\iota_E\omega_r/4\). Its pullback by \(A_\tau\) is exact and rapidly decreasing after differentiation; its integral is zero. Integration by parts therefore yields

\[
 E'(\tau)=-\int Z_\tau^TC_r(S_r-\epsilon K)C_r^TZ_\tau\le0.
\]

For p=2,3,4, the anisotropic Gaussian estimate
\(\|D\phi_\tau\|_p\le C\tau^{-(1-1/p)}\|D\phi\|_1\) and quartic Taylor growth show \(E(\tau)\to0\) as \(\tau\to\infty\). Strong L2, L3, L4 continuity at zero gives \(E(0)\ge0\). The integrated linear term vanishes. Strong W1,4 approximation proves the bounded-domain statement. Periodic heat and Stokes prove the periodic statement. No pointwise nonnegativity of the uncorrected dissipation is assumed.

F_r is left-SO(2)-invariant. Average \(\widetilde F_r(R_\theta A)\) at the four target rotations \(0,\pi/4,\pi/2,3\pi/4\). For h=a-d and k=b+c,

\[
 \frac14\left[h^4+k^4+\frac{(h+k)^4+(h-k)^4}{4}\right]
 =\frac38(h^2+k^2)^2.
\]

It follows that \(F_r-\kappa H\) is quasiconvex, with \(\kappa=3\epsilon/8\).

The quartic Bregman inequality

\[
 |x+h|^4-|x|^4-4|x|^2x\cdot h\ge\frac13|h|^4
\]

follows by subtracting the right side and obtaining

\[
 6(x\cdot h+|h|^2/3)^2+
 2(|x|^2|h|^2-(x\cdot h)^2)\ge0.
\]

Consequently the affine Jensen gap of F_r is at least
\(\kappa\|\mathcal C D\phi\|_4^4/3\), where
\(\mathcal C A=(a-d,b+c)\).

For \(f=\phi^1+i\phi^2\), use \(\partial f=\mathcal B\bar\partial f\),
\(2\bar\partial f=\mathcal C D\phi\), and
\(|D\phi|^2=2(|\partial f|^2+|\bar\partial f|^2)\). The complex-valued bound
\(\|\mathcal B\|_{L^4\to L^4}\le\sqrt{24}\) is Theorem 1.1 of Bañuelos–Janakiraman, not the sharp-norm conjecture. It gives

\[
 \|D\phi\|_4^2\le\frac{25}{2}\|\mathcal C D\phi\|_4^2,
 \qquad \int|D\phi|^4\le\frac{625}{4}\int|\mathcal C D\phi|^4.
\]

Combining inequalities gives \(\kappa(4/1875)=1/2500000\).

Zero extension gives the same whole-plane bound for W0 data. For periodic data, multiply a periodic extension by large smooth cutoffs, divide by the corresponding area factor, and let the cutoff scale tend to infinity. The cutoff derivative terms vanish and the common averaging factors cancel. A zero-end-profile strip can be periodized across its zero traces, so neither the heat proof nor the elliptic estimate introduces a duration-dependent constant.

The affine minimizer is therefore unique under its affine boundary values, and every minimizing sequence with vanishing excess energy converges to it strongly in gradient L4. This is **pure fourth-order coercivity**; it is not a positive quadratic Legendre–Hadamard margin.

## 6. Non-polyconvexity, genuine extension, and extreme-ray scope

Every base member satisfies

\[
 F_r(I)=\frac{(r+2)(r+3)}6<0,
 \qquad F_r(J_0)=49+\frac{r(r-1)}6-r,
 \quad J_0=\operatorname{diag}(1,-1).
\]

On the certified interval,

\[
 F_r(I)\le-5/128,\qquad F_r(J_0)\le6811/128.
\]

Give each of \(+40I,-40I\) probability \(1/[2(1+40^2)]\), and each of \(+J_0,-J_0\) probability \(40^2/[2(1+40^2)]\). Then mean A and mean det A are zero, while

\[
 \mathbb EF_r(A)=\frac{1600}{1601}\,[1600F_r(I)+F_r(J_0)]<0,
\]

because the bracket is at most \(-1189/128\). This violates convex Jensen in the lifted variables (A,det A), hence proves non-polyconvexity. The law is not a compatible gradient law and is not a quasiconvexity counterexample.

The core new family is not obtained by simply adding a rank-one-convex function to a positive multiple of G. For \(r\ne-5/2\), the acoustic curve in Section 2 gives

\[
 D^2G(A_t)[R_t,R_t]=2(r+5/2)^2t^2+O(t^4),
\]

whereas the corresponding expression for F_r is O(t4). Thus, for every \(\lambda>0\),

\[
 F_r-\lambda G\quad\text{is not rank-one convex}.
\]

This excludes the specific positive-addition explanation; it does not prove exclusion from every transformed orbit cone in the literature.

All these quartics remain acoustically degenerate:

\[
 F_{\alpha,\beta,\gamma,\delta}(I+t e_{12})
 =F_{\alpha,\beta,\gamma,\delta}(I)+\alpha t^4.
\]

Since \(|I+t e_{12}|^4=4+4t^2+t^4\), no positive subtraction \(\eta|A|^4\) can be rank-one convex. The elliptic-distortion subtraction is materially different.

The F_r are **not extreme rays of the full rank-one-convex cone**: the nontrivial decomposition
\(F_r=(F_r-\kappa H)+\kappa H\) already proves this. They lie on a curved acoustic-degeneracy boundary; no stronger extreme-ray classification is claimed.

## 7. A precise fixed-support obstruction

Keep the original source C and original diffusion fixed, but allow every symmetric reduced matrix S' and every homogeneous-quadratic closed two-form. The allowable quartic coefficient space is exactly

\[
 \boxed{\operatorname{span}\{G,H\}.}
\]

This is a linear-algebra obstruction before imposing positivity. There are 171 symmetric Gram variables and 60 form variables. Matching the 210 A-quadratic/jet-quadratic coefficients and the 16 closedness coefficients gives a matrix of rank 183. Adding the nine quartic coefficient columns raises rank to 190. The resulting seven independent conditions are

\[
 \begin{aligned}
 f_0+\tfrac7{12}f_6-\tfrac13f_7&=0,&
 f_1+\tfrac14f_7&=0,\\
 f_2+\tfrac25f_6+\tfrac{11}{10}f_7&=0,&
 f_3-\tfrac25f_6-\tfrac35f_7&=0,\\
 f_4=f_5=f_8&=0.
 \end{aligned}
\]

Their solution space is the displayed span. The structural verifier regenerates this entire exact linear system. Repeatedly enlarging a search within this fixed Gram support cannot reach the other seven coefficient directions.

This result concerns that fixed support and diffusion. It does not rule out other supports, other diffusions, positive densities without an SOS Gram, or other variational operations.

## 8. Two scoped limitations of smooth local corrections

These are specialized arguments supplied here. They sit within the established null-Lagrangian tradition; historical originality of the lemmas is not asserted.

### Proposition 2: local quadratic-Hessian null corrections are closed-form pullbacks

Let N(A,z) have C2 coefficients in A and be homogeneous quadratic in the six compatible Hessian entries z. Suppose

\[
 \int_{\mathbb R^2}N(B+D\phi,D^2\phi)=0
\]

for every B and every compactly supported smooth phi. Then there is a unique C2 two-form omega on matrix space such that

\[
 N(A,z)=\omega_A(B_1(z),B_2(z)),\qquad d\omega=0.
\]

Conversely, every such closed form gives a null correction.

**Proof.** Substitute epsilon phi and take the quadratic term. For each fixed B, N(B,D2phi) has zero integral. Plane-wave symbol testing therefore gives
\(N(B,a\otimes\xi^{\otimes2})=0\) for all target vectors a and spatial vectors xi. The map from the 21 quadratic polynomials in z to the 15 coefficients of a-bidegree-two/xi-degree-four polynomials has rank 15. Its six-dimensional kernel has basis

\[
 z_0z_2-z_1^2,\quad z_0z_4-z_1z_3,\quad z_0z_5-z_1z_4,
\]
\[
 z_1z_4-z_2z_3,\quad z_1z_5-z_2z_4,\quad z_3z_5-z_4^2.
\]

These are precisely the six coordinate two-form pullbacks. Hence omega exists uniquely with the regularity of N.

It remains to force closedness, not merely constant-coefficient nullness. Write
\(d\omega=\sum T_{ijk}\,dx_i\wedge dx_j\wedge dx_k\). The first variation of the pullback integral is
\(\int d\omega(D\eta,B_1,B_2)\), up to an exact boundary term. The Euler equation for the first component of eta contains terms linear in arbitrary third jets. With y6=phi2_xyy and y7=phi2_yyy, its coefficients of
\(z_0y_6,z_0y_7,z_3y_6,z_3y_7\) are, up to a common sign,
\(-T_{012},-T_{013},T_{023},T_{123}\). Terms differentiating T contain only second jets and cannot cancel these third-jet coefficients. Arbitrary local jets force all four T coefficients to vanish. This calculation is included in the structural verifier. Conversely, closed forms on R4 are exact, and Stokes gives the null integral. QED.

Thus a nonclosed form whose integral supposedly vanishes only because A is a gradient does not enlarge this smooth local quadratic-Hessian class. Terms of different jet order or nonlocal dependence are outside the proposition.

### Proposition 3: smooth nonlinear coefficient dependence reduces to degree two

Let F be a homogeneous quartic and let D be a fixed positive diffusion. Suppose a closed two-form omega with C2 coefficients near A=0 satisfies

\[
 \mathcal D_{D,F}(A,z)+\omega_A(B_1,B_2)\ge0
\]

for all z and all A near zero. Then its homogeneous-quadratic Taylor part omega2 is closed and satisfies the same inequality for every A,z.

**Proof.** At A=0 the heat density vanishes. The quadratic form in z supplied by omega0 is nonnegative, and vanishes on every rank-one Hessian jet because B1 and B2 are proportional. Those jets span the six-dimensional jet space. A positive-semidefinite quadratic form vanishing on a spanning set is zero; independence of the six coordinate pullbacks gives omega0=0.

Next apply positivity at tA and -tA and let t tend to zero. The heat term is O(t2), so the linear Taylor coefficient of the correction must vanish. Injectivity of the pullback representation gives Domega(0)=0. Dividing by t2 and passing to the limit proves the inequality for
\(\omega_2(A)=\frac12D^2_{\rm coeff}\omega(0)[A,A]\). Closedness passes to this homogeneous Taylor coefficient. Homogeneity extends the result to every A. QED.

Therefore higher polynomial degrees or smooth nonlinear A-dependence do not, by themselves, enlarge the constant-heat/local-two-form positivity cone for homogeneous quartics. This is **not** an assertion that every nonnegative corrected biquadratic form is SOS. Singular angular corrections, nonlinear diffusions, nonlocal operations, and higher-jet mechanisms are not excluded.

## 9. Failed case and remaining obligations

The particular rational continuation used here is not positive everywhere. At r=-8/3, its unmodified reduced matrix S_r has a negative exact quadratic value. `FAILED_CONTINUATION_WITNESS.json` records the rational vector and value, and `verify_structure.py` verifies them.

That witness establishes only failure of this selected Gram continuation. It does not establish failure of all Gram representations, failure of pointwise positivity on actual bilinear jets, failure of compatible-heat monotonicity, or failure of quasiconvexity. No compatible negative gradient has been constructed.

The next mathematical obligation is structural rather than a larger sample search: characterize the feasible correction/Gram cone on the **geometrically forced moving kernel**, without freezing the 48 free coefficients used here. Determine the optimal alpha threshold and parameter reach, and then analyze other acoustic-contact strata in the nine-coefficient cone. A genuine separation theorem for all local quadratic-form certificates would need a dual obstruction against the entire allowed coefficient space, not the present failed matrix alone.

The normalized coefficient functional inherited from the repository becomes
\(\Lambda(F)=64\alpha+16\beta+4\gamma\) on this four-dimensional space. The theorem can be intersected with Lambda=1 directly. It covers a three-dimensional normalized sector, not the full eight-dimensional normalized left-invariant cone.

## 10. Reproduction and provenance

Run, with SymPy installed:

```sh
python verify_moving_acoustic.py
python verify_structure.py
python reconstruct.py
```

The first command reads only `MOVING_ACOUSTIC_CERTIFICATE.json`. It verifies universal identities, closedness, a primitive, scalar subtraction, the continuum Bernstein certificate, acoustic necessity, the source-positive-addition obstruction, and the lifted non-polyconvexity witness. The second regenerates the fixed-support restriction and local null-form calculations and checks the failed-continuation witness. The third reconstructs the displayed original coefficients.

The package also preserves the discovery scripts. They are not required for verification. Their temporary pickle files are not distributed and are regenerated only when the optional construction scripts run in order.

Primary sources consulted:

1. Astra repository, N850 and N860 paths identified in Section 1. Repository head observed through the GitHub API: `a6190a1083f688a7e4bf64adbc5244ef150ff2c4`. https://github.com/harjassand/astra-research-knowledge
2. Giuseppe Bruno and Federico Pasqualotto, *Quasiconvexity for the Dacorogna–Marcellini Energy*, arXiv:2608.06367v1, especially Theorem 2 and Sections 2–3. https://arxiv.org/html/2608.06367v1
3. Rodrigo Bañuelos and Prabhu Janakiraman, *Lp-bounds for the Beurling–Ahlfors transform*, Theorem 1.1. https://www.math.purdue.edu/~banuelos/Papers/Beur_Ahl.pdf
4. Ball, Currie, and Olver, *Null Lagrangians, weak continuity, and variational problems of arbitrary order*, Journal of Functional Analysis 41 (1981), 135–174. Publisher abstract inspected for broader attribution, not used as a premise for Propositions 2–3. https://www.sciencedirect.com/science/article/pii/0022123681900859

The external search and inspected references do not establish priority for the family or structural lemmas. The claimed result is the explicit argument and certificate here, not an inference that no prior theorem could imply it. No original repository files were modified.
