# Primary sources and reading ledger

Checked 12 October 2026. This is a selective comparison, not a novelty or priority determination. No third-party manuscripts are redistributed in this packet.

## Main sources

**S1.** Michael Mandl, *Correctness criteria for complex Langevin*, arXiv:2604.12388, JHEP08(2026)110, published 13 August 2026.
- https://arxiv.org/abs/2604.12388
- https://arxiv.org/html/2604.12388v1
- https://doi.org/10.1007/JHEP08%282026%29110
- Read: HTML v1 introduction, section 3 correctness criteria, section 3.6 observable bounds, selected failure discussions, and conclusions. Latest abstract/publication metadata checked. HTML v2 retrieval returned an error; do not represent v2 as fully read.
- Use: distinction between convergence and correct cycle; limitations of diagnostics. No theorem from this paper is imported into the proposed proof.

**S2a.** Erhard Seiler, Denes Sexty, Ion-Olimpiu Stamatescu, *Complex Langevin: Correctness criteria, boundary terms, and spectrum*, Physical Review D109014509 (2024).
- https://doi.org/10.1103/PhysRevD.109.014509
- Read: publisher HTML introduction, mathematical discussion, spectrum and integration-cycle cautions. Some equations were not exposed completely in parsed text; exact external equations are not reused as premises.

**S2b.** Erhard Seiler, *Complex Langevin: Boundary terms at poles*, Physical Review D102094507 (2020).
- https://doi.org/10.1103/PhysRevD.102.094507
- Read: publisher HTML discussion of analytic-time counterexamples and function spaces.
- Use: avoid assuming joint time analyticity merely from a holomorphic drift.

**S3.** Gert Aarts, Pietro Giudice, Erhard Seiler, *Localised distributions and criteria for correctness in complex Langevin dynamics*, Annals of Physics337238–260 (2013), arXiv:1306.3075v1.
- https://arxiv.org/abs/1306.3075
- https://doi.org/10.1016/j.aop.2013.06.019
- Read: primary abstract and publisher description; full source proof not exhaustively reviewed. Prior strip-confinement analysis is explicitly credited. This source prevents claiming invariant strips themselves as a new operation.

**S4.** Michael Mandl, Erhard Seiler, Denes Sexty, *Necessary and sufficient conditions for correctness of complex Langevin*, J.Phys.A58 495202 (2025), arXiv:2508.14512v2 (10 December 2025).
- https://arxiv.org/abs/2508.14512
- https://doi.org/10.1088/1751-8121/ae2245
- Read: latest primary abstract and detailed description of its observable-bounds criterion in S1. Full proof not exhaustively reviewed.
- Use: general mathematical sufficiency criteria already exist; practical verification and coefficient certification are distinct claims.

**S5.** Daniel Alvestad, Rasmus Larsen, Alexander Rothkopf, *Stable solvers for real-time Complex Langevin*, JHEP08(2021)138, arXiv:2105.02735v1.
- https://arxiv.org/abs/2105.02735
- https://doi.org/10.1007/JHEP08%282021%29138
- Read: primary abstract and metadata. Implicit solvers and their application to real-time complex Langevin are established prior art.

**S6.** Zhenning Cai, Xiaoyu Dong, Yang Kuang, *On the Validity of Complex Langevin Method for Path Integral Computations*, SIAM J.Sci.Comput.43 A685–A719 (2021), arXiv:2007.10198.
- https://arxiv.org/abs/2007.10198
- https://epubs.siam.org/doi/abs/10.1137/20M1363224
- Read: primary abstract/metadata, not full proof. Prior localisation, compact-group and gauge-cooling analysis noted.

**S7.** David Gamarnik, *Correlation decay and the absence of zeros property of partition functions*, Random Structures & Algorithms62 155–180 (2023), arXiv:2011.04915v2.
- https://arxiv.org/abs/2011.04915
- https://onlinelibrary.wiley.com/doi/full/10.1002/rsa.21083
- Read: primary abstract and publisher discussion of interpolation, correlation decay, and graph polynomial representations.
- Use: zero-free interpolation is a strong comparator, not a new consequence invented here; direct coverage of the continuous interacting quartic model has not been established in this run.

## Other comparisons screened

- Hansen, Michael Mandl, Erhard Seiler, Denes Sexty, *Role of integration cycles in complex Langevin simulations*, Physical Review D111074502 (2025). https://doi.org/10.1103/PhysRevD.111.074502 . Primary publisher result inspected for cycle dependence; no external proof imported.
- Scott Lawrence, Yukari Yamauchi, *Normalizing flows and the real-time sign problem*, arXiv:2101.05755. https://arxiv.org/abs/2101.05755 . Primary search abstract inspected; no claimed head-to-head implementation.
- Angxiu Ni, *Fast adjoint algorithm for linear responses of hyperbolic chaos*, SIAM J.Applied Dynamical Systems (2024). Primary publisher search result used only to reject treating parameter-independent adjoint response as newly invented. Exact bibliographic details beyond the retrieved title should be verified before external publication.

## External capital

- Astra pinned observed revision: https://github.com/harjassand/astra-research-knowledge/tree/a33fc7e1db8f42873025fa29882f85f2d4503695
- OpenAI mathematical search-result revision: https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb
- Only selective search/navigation used for current topic. No unreviewed repository theorem is a premise. No writes performed.
