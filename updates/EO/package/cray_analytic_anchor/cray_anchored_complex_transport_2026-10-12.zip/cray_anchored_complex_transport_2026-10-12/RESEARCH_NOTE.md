# CRAY — Analytic anchoring of complex stochastic computation

**Research date:** 12 October 2026.  
**Status:** proof candidate with explicit sufficient coefficient certificate, quantitative algorithmic reduction, exact finite algebra checks, and floating-point implementations. Historical priority, independent proof review, a practically sharp error certificate, and competitive advantage remain unresolved.

## 0. What this run does and does not establish

The surviving mathematical mechanism is **analytic anchoring**: prove that the invariant expectations of a complex stochastic family depend holomorphically on a parameter; identify those expectations on a real positive-probability interval; and transport that identity to a complex target. This selects the intended integration cycle without estimating an exponentially small normalising constant or assuming the spectrum of a complex Fokker–Planck operator.

Complex Langevin, implicit integration, invariant strips, thermodynamic integration, analytic continuation, and Gaussian concentration are established tools. They are not claimed as inventions here. The candidate research contribution is their particular constructive connection, together with a coefficient-checkable multivariate paired-quartic certificate and complete accounting of its algorithmic consequences. The literature search is selective, not priority clearance.

A proof candidate is given for an explicitly specified interacting continuous-field family. This is not a general solution of the sign problem, a claim about ordinary quantum matter at arbitrary coupling, or experimental validation. It is not a sampler for a complex signed probability law: it computes specified holomorphic integrals using an ordinary positive stochastic law on complex variables.

The paired-quartic terms used below must be part of the supplied target model. Adding them to another model changes the answer and is not a free stabilisation operation.

The tests materially limit the significance claim. On a connected ten-site chain, specialised transfer quadrature was about 191 times faster than the tested stochastic procedure, with a more accurate reference result. An explicit conservative rigorous-error recipe is catastrophically expensive even on the two-variable example. Thus the user’s major operational-breakthrough standard is NOT claimed to have been met.

## 1. Independent opportunity screening and prior capital

The initial screen considered goal-directed inverse problems, response derivatives of chaotic systems, multireference imaging, and oscillatory field integrals. Avoiding complete parameter reconstruction and parameter-independent adjoint derivatives already have strong specialised methods; they were not relabelled as new inventions. The selected problem is cancellation-dominated integration with an additional correctness obstruction: a converged stochastic process can compute the wrong integration cycle.

The earlier Gaussian-crossing, low-rank-spin, and hidden-kinetic constructions are retained as capital but are not premises. Repository consultation occurred after the independent mechanism was chosen. Astra was observed at revision `a33fc7e1db8f42873025fa29882f85f2d4503695`. OpenAI mathematical search results were at revision `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`. A targeted Astra code search for the exact phrase “complex Langevin” returned no matches; this does not establish absence or originality. No repository was modified.

## 2. Scientific input and output

Let G be a finite simple graph with n vertices and maximum degree D >= 1. Input consists of a graph and rational coefficients:

* a real symmetric strictly row-diagonally-dominant matrix A;
* a real symmetric matrix C with off-diagonal support contained in G;
* positive numbers a and c.

The drift can be evaluated sparsely when A also has bounded-degree support. The certificate allows dense A; its evaluation cost must then be counted separately.

Define

\[
V(x)=\tfrac12x^TAx+\tfrac a4\sum_i x_i^4
+\tfrac c4\sum_{\{i,j\}\in E}\{(x_i+x_j)^4+(x_i-x_j)^4\},
\]
\[
W(x)=\tfrac12x^TCx,\qquad S_\zeta(x)=V(x)-\zeta W(x),
\qquad Z(\zeta)=\int_{\mathbb R^n}e^{-S_\zeta(x)}dx.
\]

C can have full rank and either-sign entries. There is no rank parameter in the results.

The main output is

\[
L=\log[Z(i)/Z(0)],
\]

where the logarithm is continuously continued from zeta=0. It need not equal a blindly evaluated principal logarithm in a large system. An additive complex error at most epsilon in L gives relative complex error at most exp(epsilon)-1 in the represented ratio. The output can instead be the intensive quantity L/n, or a finite list of fixed-degree holomorphic polynomial expectations.

Reading the explicit input costs at least its bit length. Learning a material’s microscopic action is not solved here. This run supplies neither physical calibration data nor a laboratory control protocol. All clocks below are algorithmic Langevin time, not experimentally observed physical time.

## 3. A finite coefficient certificate

Choose rational r>0, u0>0, v0>1, and consider the open rectangle

\[
\Omega=\{\zeta:|\Re\zeta|<u_0,\ |\Im\zeta|<v_0\}.
\]

Write

\[
m=\min_i(A_{ii}-\sum_{j\ne i}|A_{ij}|),\quad
c_1=\max_i\sum_j|C_{ij}|,\quad
c_2^2=\max_i\sum_j C_{ij}^2,
\]
\[
m_*=m-u_0c_1,\qquad
\theta_*=\min\{3a/(1+2D),3c\}.
\]

The test accepts only if both rational numbers below are positive:

\[
\lambda=m_*-(3a+24cD)r^2>0, \tag{3.1}
\]
\[
\eta=m_*r-(a+8cD)r^3-
\frac{v_0^2c_2^2}{4r\theta_*}>0. \tag{3.2}
\]

The graph support, symmetry, and all inequalities are directly checkable from the input; no hidden gap, stationary law, partition function, or oracle is used. Certificate discovery is not automatic for arbitrary inputs. Given a desired rectangle, radius acquisition reduces explicitly to a concave quadratic in s=r^2: m_* s-(a+8cD)s^2-v0^2 c2^2/(4 theta_*)>0, intersected with 0<s<m_* /(3a+24cD). Maximising this quadratic on that interval either rejects the sufficient test or gives a strictly feasible s. Dyadic square-root bracketing then supplies a rational r. The implemented `acquire_radius` performs this exact rational reduction; it was separately checked on all 20 generated graphs. Failure of this sufficient test is NOT a computational hardness result.

### Lemma 3.1 — invariance of the complex box

Let T={z=x+iy: |y_i|<=r for all i}. For every zeta in Omega, the process

\[
dX_t=-\nabla S_\zeta(X_t)dt+\sqrt2\,dB_t,
\tag{3.3}
\]

with real n-dimensional Brownian motion and initial point in T, remains in T.

**Proof.** On the upper face y_i=r, the quadratic contribution to Im partial_i S is at least m_*r-v (C_i x), where v=Im zeta. The onsite quartic contributes 3ar x_i^2-ar^3. One incident paired quartic contributes exactly

\[
6cr(x_i^2+x_j^2)+12cy_jx_ix_j-2cr^3-6cr y_j^2.
\]

Since |y_j|<=r, this is bounded below by

\[
6cr(|x_i|-|x_j|)^2-8cr^3.
\]

The elementary inequality

\[
x_i^2+\sum_{j\sim i}x_j^2
\le (1+2D)x_i^2+2\sum_{j\sim i}(|x_i|-|x_j|)^2
\]

shows that all nonnegative quadratic terms dominate

\[
r\theta_*\sum_{j\in\{i\}\cup N(i)}x_j^2.
\]

Completing the square against -v C_i x yields a lower bound -v0^2 ||C_i||_2^2/(4r theta_*). Combining terms gives Im partial_i S >= eta. Reflection of the imaginary coordinates proves the reversed inequality on the lower face. The noise has no imaginary component, so these deterministic inward bounds imply invariance. Localisation and the dissipative estimate in the next lemma exclude finite-time explosion. QED.

### Lemma 3.2 — strong accretivity

For z,z' in T,

\[
\Re\langle z-z',\nabla S_\zeta(z)-\nabla S_\zeta(z')\rangle
\ge\lambda\|z-z'\|_2^2. \tag{3.4}
\]

Here the inner product conjugates its first argument.

**Proof.** For a quartic g(v.z)^4/4 with real v, the Hermitian part of its complex Hessian is

\[
3g\{(v.x)^2-(v.y)^2\}vv^T.
\]

The onsite negative part is at worst -3ar^2 I. For each edge, |y_i +/- y_j|<=2r, and

\[
(e_i+e_j)(e_i+e_j)^T+(e_i-e_j)(e_i-e_j)^T
=2(e_ie_i^T+e_je_j^T).
\]

Thus the edge negative parts total no worse than -24cDr^2 I. The Hermitian part of A-zeta C is A-(Re zeta)C >=m_* I. Equation (3.1) bounds the full Hessian from below on the convex tube. Integration along the segment from z' to z proves (3.4). QED.

Synchronous coupling immediately gives

\[
\|X_t-X'_t\|\le e^{-\lambda t}\|X_0-X'_0\|. \tag{3.5}
\]

This is a pathwise result, not a claim of ellipticity in all 2n real directions.

## 4. Moments, stationary laws, and an implementable analytic map

Let F_zeta=gradient S_zeta. It is an odd holomorphic cubic polynomial and F_zeta(0)=0. Standard stopped Ito estimates from (3.4) give nonexplosion and moments of every fixed polynomial order uniformly in time and uniformly in zeta in Omega. One explicit recursion for U=||X||^2 is

\[
\mathcal L U^p\le-2p\lambda U^p+2p(n+2p-2)U^{p-1}.
\]

Tightness plus contraction gives a unique invariant law mu_zeta and convergence of polynomial moments. It is not necessary that this law have a smooth density in all complex directions.

A particularly useful construction avoids assuming analyticity in Langevin time, which is not generally justified in complex Langevin [S2]. For h>0 define the **implicit resolvent**

\[
R_{h,\zeta}(w)+hF_\zeta(R_{h,\zeta}(w))=w,
\qquad w\in T, \tag{4.1}
\]

and the chain

\[
Y_{k+1}=R_{h,\zeta}(Y_k+\sqrt{2h}\,\xi_k),
\quad \xi_k\sim N(0,I_n). \tag{4.2}
\]

This is a known implicit numerical architecture [S5], not the claimed new invention.

### Lemma 4.1 — resolvent existence, uniqueness, and holomorphy

A unique solution to (4.1) exists in T, lies in its imaginary interior for every w in T, and

\[
\|R_{h,\zeta}(w)-R_{h,\zeta}(w')\|
\le q_h\|w-w'\|,\qquad q_h=(1+h\lambda)^{-1}. \tag{4.3}
\]

For w in the open tube, R is jointly holomorphic in w and zeta.

**Proof.** Regard I+hF as a real 2n-dimensional, strongly monotone map on the closed convex tube. Coercivity gives a solution to its variational inequality, first on sufficiently large truncations and then without a real-coordinate cutoff. At an upper imaginary face, Im(v+hF(v)-w)>=h eta>0. The corresponding residual has the wrong sign to be supported by an outward normal cone; a variational-inequality solution therefore cannot lie on this face. The lower face is analogous. It is consequently an ordinary zero of I+hF-w. Strong monotonicity gives uniqueness and (4.3). The complex derivative I+h DF has Hermitian part at least (1+h lambda)I, hence is nonsingular. The holomorphic implicit-function theorem gives local holomorphy, and uniqueness patches these local functions throughout the domain. QED.

### Gaussian concentration and coordinate moments

As a function of the Gaussian innovations, a coordinate of Y_N has squared Euclidean Lipschitz constant at most

\[
2h\sum_{j=1}^Nq_h^{2j}
\le \frac{2}{\lambda(2+h\lambda)}\le\lambda^{-1}. \tag{4.4}
\]

Oddness gives mean zero. The standard Gaussian concentration inequality thus makes every real coordinate sub-Gaussian with parameter 1/lambda. There is no circular dependence on the sharper coordinate bounds here: first use the global Ito moments above and polynomial growth of F,H,G to obtain a provisional finite version of the strong convergence estimate in Section 6. Pass (4.4) to the continuous limit using that provisional estimate, and only then use the improved coordinate bounds to sharpen its constants. This gives the same concentration conclusion for X_t. Imaginary coordinates lie in [-r,r]. In particular, with

\[
v_2=\lambda^{-1}+r^2,
\quad K_p=2\sqrt{p/\lambda}+r,
\tag{4.5}
\]

we have E||X_t||^2,E||Y_k||^2<=n v2 and ||(X_t)_i||_Lp,||(Y_k)_i||_Lp<=K_p for p>=2. The displayed Kp is deliberately loose. The same bounds hold for invariant laws. Gaussian concentration is used here as a standard inequality, not a new result.

## 5. Analytic anchoring: selecting the actual real integration cycle

### Theorem 5.1

Under (3.1)–(3.2), for every holomorphic polynomial O,

\[
Z(\zeta)\,\mathbb E_{\mu_\zeta}O(X)
=\int_{\mathbb R^n}O(x)e^{-S_\zeta(x)}dx
\qquad(\zeta\in\Omega). \tag{5.1}
\]

Moreover, Z has no zeros in Omega, and

\[
L=\int_0^1 i\,\mathbb E_{\mu_{it}}W(X)\,dt. \tag{5.2}
\]

This is the central proof candidate.

**Proof.** Each finite implicit chain, started at zero, is holomorphic in zeta for each fixed finite sequence of innovations. Uniform polynomial moments allow expectations to be interchanged with contour integrals in the parameter plane. More explicitly, on a compact parameter contour, the integral of E|O(Y_N)| is bounded uniformly; Fubini and the pathwise holomorphy give a zero contour integral of E O(Y_N). Continuity follows from pathwise continuity plus uniform higher moments. Morera’s theorem proves holomorphy of the finite-chain expectation.

Contraction and polynomial moment bounds give locally uniform convergence as N tends to infinity, so its stationary expectation f_{h,O}(zeta) is holomorphic. The uniform-in-time strong estimate proved in Section 6 gives locally uniform convergence f_{h,O} -> f_O as h tends to zero. For a degree-d polynomial, use

\[
|O(z)-O(w)|\le C\|z-w\|(1+\|z\|^{d-1}+\|w\|^{d-1})
\]

and Cauchy–Schwarz with the moment estimates. Weierstrass’ theorem proves that f_O(zeta)=E_mu O is holomorphic. This argument uses parameter analyticity, not a Taylor series in stochastic time.

For real zeta in (-u0,u0), the chain’s continuous limit is the ordinary real gradient diffusion in the strongly convex potential S_zeta. Its unique invariant law is exactly e^{-S_zeta}/Z(zeta), so (5.1) holds on a real interval. Quartic confinement implies that both Z(zeta) and the unnormalised observable integral are entire functions of zeta. Thus the two sides of (5.1) are holomorphic on Omega and agree there by the identity theorem.

There was no division by Z in this extension. Taking O=W and differentiating the original absolutely convergent real integral gives

\[
Z'(\zeta)=Z(\zeta)f_W(\zeta). \tag{5.3}
\]

Since f_W is holomorphic and Z(0)>0, uniqueness of this scalar linear differential equation implies that Z never vanishes in the simply connected rectangle. Dividing (5.3) is now legitimate. Integrating along zeta=it proves (5.2), with its specified continued logarithm. QED.

### Why this is not merely checking equilibration

The theorem identifies the integration cycle through a real positive anchor, not just stationarity identities. Existing work shows that wrong integration cycles can survive otherwise persuasive diagnostics [S1–S4]. General sufficient observable-space correctness criteria already exist [S4]; this work does not claim otherwise. The proposed distinction is a finite check on explicit coefficients that suffices for a particular multivariate family, rather than verifying an entire unknown observable-space bound.

## 6. Quantitative discretisation and statistical costs

The following elementary derivation is included so that no convergence-rate oracle is supplied for free.

Let H=DF and G=-HF+Delta F, where Delta differentiates twice in the real-noise directions. Suppose

\[
\sup_t E\|H(X_t)\|_F^2\le H_2,
\qquad \sup_t E\|G(X_t)\|^2\le G_2.
\]

The bounds below acquire H2 and G2 from coefficients and coordinate moments.

Couple (4.2) and (3.3) with identical Brownian increments. On one step, their endpoint mismatch has residual

\[
\mathcal R_k=\int_{t_k}^{t_k+h}(s-t_k)G(X_s)ds
+\sqrt2\int_{t_k}^{t_k+h}(s-t_k)H(X_s)dB_s.
\]

The drift part has squared expectation at most h^4 G2/4. The martingale part has squared expectation at most 2h^3 H2/3 and has zero cross term with the old adapted error. The resolvent inequality and Young’s inequality give, for h<=1,

\[
E\|e_{k+1}\|^2\le q_h E\|e_k\|^2+q_h^2h^3D_0,
\quad
D_0=G_2/(4\lambda)+G_2/2+4H_2/3.
\]

Summing the geometric series from identical initial states proves

\[
\sup_N(E\|X_{Nh}-Y_N\|^2)^{1/2}
\le h\sqrt{D_0/\lambda}. \tag{6.1}
\]

### Explicit local constants

Set s=2, q=1+2D, g=max(a,c), and

\[
a_0=\max_i\sum_j|A_{ij}|+(u_0+v_0)c_1,
\]
\[
F_p=a_0K_p+qgs^3K_{3p}^3,
\]
\[
H_{loc}=a_0+3qgs^3K_4^2,
\]
\[
G_{loc}=a_0F_2+3qgs^3K_8^2F_4+6qgs^2K_2.
\]

Minkowski, Holder, and the finite support of each quartic give H2<=n Hloc^2 and G2<=n Gloc^2. For example, a quartic Hessian row times F contains (v.X)^2 (v.F); its L2 norm is bounded by s^2 K8^2 times s F4. All terms are explicitly accounted for.

Define

\[
C_{step}=\left[\frac1\lambda\left(
\frac{G_{loc}^2}{4\lambda}+\frac{G_{loc}^2}{2}+
\frac{4H_{loc}^2}{3}\right)\right]^{1/2}.
\]

Then the strong error is at most h sqrt(n) Cstep, and for W

\[
|E W(X_{Nh})-E W(Y_N)|
\le n c_1\sqrt{v_2}\, C_{step}h. \tag{6.2}
\]

A conservative stationary-start coupling gives continuous-time mixing bias at most n c1 v2 exp(-lambda T). The discrete chain has analogous bias at most n c1 v2 q_h^N.

For either real or imaginary part of the endpoint estimator iW(Y_N), Gaussian Poincare applied to the innovations gives

\[
\operatorname{Var}\le n c_1^2v_2/\lambda. \tag{6.3}
\]

This is a variance bound for independent restarted endpoints, not permission to treat consecutive chain observations as independent.

### Parameter quadrature

Put g(t)=i f_W(it). It is analytic whenever it lies in Omega, and |g(t)|<=K=n c1 v2/2. Choose a Bernstein ellipse of radius R>1 for [0,1] whose imaginary semiaxis (R-R^{-1})/4 is below u0 and whose real extent lies within (-v0,v0). On that ellipse the same bound applies. M-point positive Gauss–Legendre quadrature has error bounded by

\[
\frac{4K R^{-(2M-1)}}{R-1}. \tag{6.4}
\]

This follows by approximating g with a polynomial of degree 2M-1 via its Chebyshev series and using positive weights with total mass one. Thus M=O(log(n/epsilon)) for fixed rectangle width. Nodes, weights, and their finite precision are additional computations; a Cauchy derivative bound on a smaller ellipse controls node-rounding error.

### Endpoint count

At every node, use independent trajectories from zero. With variance bound v, a block average over at least 8v/tau^2 endpoints has probability at most 1/8 of coordinate error exceeding tau. Medians of an odd number of blocks give exponential confidence amplification. Both real and imaginary coordinates and all quadrature nodes are union-bounded. There is no inverse-average-phase term.

An explicit conservative allocation uses h<=epsilon/[8n c1 sqrt(v2) Cstep], a burn-in making the mixing error <=epsilon/8, quadrature error <=epsilon/8, and per-coordinate median error <=epsilon/16. Root residuals, Gaussian generation, and quadrature rounding use the remaining budget. The constants can be loosened to rational upper bounds, as in `audit.py`.

For bounded degree, bounded local coefficients, and fixed positive margins, the ideal numbers scale as:

* M=O(log(n/epsilon)) parameter nodes;
* O(n epsilon^{-2} log(M/delta)) independent endpoints per node;
* O(n epsilon^{-1} log(n/epsilon)) implicit steps per endpoint;
* O(n) coefficient arithmetic per sparse drift evaluation.

With the bounded-domain solver below this gives a tilde-O(n^3 epsilon^{-3}) arithmetic construction for absolute error in L, with constants determined by the displayed quantities. Tildes hide logarithms and finite-bit factors, NOT inverse certificate margins or arbitrarily large coefficients.

For error epsilon in the intensive L/n, the step requirement instead has h=O(epsilon), the endpoint variance is O(1/n), and the ideal sparse work is tilde-O(max(n,epsilon^{-2}) epsilon^{-1}), with a minimum number of endpoints for confidence amplification. This is a different and weaker output contract: it does not estimate Z to relative epsilon.

## 7. Finite precision, root acquisition, memory, and calibration

### No implicit-root oracle

On the imaginary tube, I+hF is strongly monotone. A root with residual at most tau_root has Euclidean error at most tau_root/(1+h lambda). Contractivity limits accumulated perturbation after arbitrarily many steps to tau_root/(h lambda). For instance, choosing tau_root<=h lambda e_state allocates at most e_state state error. Use the polynomial W difference bound to convert this to output bias, including the small quadratic error term.

For a guaranteed fallback implementation, intersect the tube with a large real-coordinate box [-Rbox,Rbox]^n and solve the strongly monotone variational inequality by projected gradient. Its step can be chosen from the acquired monotonicity constant mu=1+h lambda and a Lipschitz bound LA for I+hF on that box. Projection of v-(mu/LA^2)(I+hF(v)-w) contracts at most sqrt(1-mu^2/LA^2). Thus O((LA/mu)^2 log(initial_error/tau_root)) iterations suffice.

The ideal chain’s centered Gaussian-coordinate tail gives, across Dtot ideal states,

\[
\Pr(\exists k,i:|\Re Y_{k,i}|>R_{box})
\le2nD_{tot}\exp(-\lambda R_{box}^2/2).
\]

Choose a rational upper bound for the radius making this probability a prescribed small part of delta, and add a unit padding to accommodate the accumulated finite-precision state error (allocated to be less than one). On this event’s complement the box root is the desired unrestricted root. For bounded-degree bounded-coefficient actions, LA is polynomial in Rbox^2 and h, hence polylogarithmic in the total work. Projection and gradient evaluation cost O(n+|E|+nnz(A)+nnz(C)). The radius may be chosen from a prior upper bound for the work, avoiding circular scheduling. A still larger global polynomial bound is an alternative.

The delivered Newton implementation is NOT this fully certified fallback. It checks floating residuals and tube membership, but floating residuals do not enclose rounding error.

### Randomness and arithmetic

Normal innovations can be generated to prescribed total-variation accuracy delta/(n Dtot) using truncated, discretised one-dimensional normal laws with rational exponential bounds and rejection or inverse-CDF bisection. The truncation radius is O(sqrt(log(n Dtot/delta))). Couple discretised Gaussian draws to ideal draws; their total failure probability is charged. Add deterministic rounding tolerance separately through the resolvent perturbation inequality. Required precision grows logarithmically with Dtot, inverse tolerances and margins, and numerical coefficient magnitudes. Polynomial evaluations on bounded boxes admit direct rational/interval error bounds.

This is a finite-bit reduction, not an executed arbitrary-precision normal engine. No binary-strength independence theorem is claimed: very large local coefficients and tiny lambda, eta can make both root solves and step counts expensive even if their encodings are short.

Sequential memory is O(n+nnz(A)+nnz(C)+|E|+M) numbers plus polynomial-logarithmic precision and streaming group summaries. An n-entry observable list costs at least n outputs; the single log ratio does not require expanding exponentially large or small values into ordinary decimal notation.

### Physical parameter uncertainty

For an interpolation of actions that stays inside a uniformly certified region, derivative of log Z with respect to a local quadratic or quartic coefficient is a corresponding degree-two or degree-four expectation. Equations (4.5) and (5.1) bound those derivatives. Coefficient errors therefore propagate at most polynomially, typically O(number_of_terms times local_error) with explicit moment factors. This avoids requiring exponentially precise coefficients solely because Z(i)/Z(0) is small. It does not solve the scientific problem of acquiring those coefficients or validating the action; those remain outside this computational input contract.

## 8. Counterexamples and alternative operations

### 8.1 Contraction without the real anchor gives a wrong answer

For S(z)=z^4/4-z^2/2, choose a constant complex kernel -1 and imaginary noise:

\[
dZ=(Z^3-Z)dt+i\sqrt2 dB.
\]

Starting on Z=iY gives

\[
dY=-(Y^3+Y)dt+\sqrt2 dB.
\]

This real diffusion is strongly contracting and samples exp(-y^4/4-y^2/2). Consequently E Z^2=-E Y^2<0. The desired real-cycle expectation of x^2 under exp(-x^4/4+x^2/2) is strictly positive. Quadrature gives approximately -0.46791991697 and +1.04179729649 respectively. Stability does not determine the integration cycle. This is a failure witness for dropping the anchor, not an assertion that constant-kernel failure was previously unknown.

### 8.2 Endpoint reweighting pays exponentially

With phi=e^{iW(X)}, X distributed as e^{-V}/Z(0), let a_phase=E phi=Z(i)/Z(0). Then

\[
\frac{E|\bar\phi-a_{phase}|^2}{|a_{phase}|^2}
=\frac{|a_{phase}|^{-2}-1}{N}.
\]

For independent copies of any nontrivial block, the continuous positive base density and nonconstant phase imply strictly |a_block|<1. Replication yields exponential relative variance. The test block has computed log|a_block|=-0.0080567020736191. For 10,000 blocks, log|a_phase| is about -80.5670 and the relative-variance coefficient is about exp(161.134).

This is a rigorous scaling failure of direct reweighting, not a separation from the strongest algorithms. Block factorisation solves that example cheaply. No advantage is claimed by hiding it from the comparator.

### 8.3 A rigid contour translation is insufficient

For V(z)=z^2/2+z^4/4 and an imaginary linear source ibz, substitution z=x+iy makes the phase

\[
(b-y+y^3)x-yx^3.
\]

For b nonzero no constant y makes this phase independent of x. Every fixed translation retains strict phase cancellation. This does not rule out nonlinear contour deformation or a different positive representation.

### 8.4 Why onsite confinement did not solve the multivariate problem

For onsite quartics only and C_ij nonzero, on a proposed face y_i=r_i take x_i=0 and x_j arbitrarily large. The imaginary gradient contains -Im(zeta) C_ij x_j, which is unbounded in both signs. No finite rectangular imaginary tube can be invariant. This is a precise failure of that representation, not hardness of the integral.

The paired quartic family is a different operation on the proof: its face derivative supplies positive quadratic control of every neighbouring real direction and absorbs this linear forcing. It removes the box obstruction when those quartics are actual model terms. It cannot be imposed on a different model without paying for the modification.

### 8.5 Why naive quadratic whitening is not the missing general operation

For a scalar action S(z)=(m-i c)z^2/2+g z^4/4, the change z=(m-i c)^{-1/2}w makes the quadratic coefficient real but makes the quartic coefficient g/(m-i c)^2 complex. Generically the imaginary gradient then has a leading cubic term with opposite signs as Re w tends to plus or minus infinity, defeating any fixed imaginary strip. Thus simply moving the complex phase from the quadratic to the quartic term does not give the required certificate.

A curved tube depending on real coordinates also cannot be assumed invariant under full horizontal Brownian noise: at a regular boundary point with a nonzero real normal component, the noise has nonzero normal variance and can cross instantly. A generalised operation must change the noise directions as well as its drift, and account for the resulting Ito terms.

## 9. Executed tests

All recorded tests were executed locally. Numerical quadrature and stochastic calculations are floating-point diagnostics unless explicitly identified as rational arithmetic.

### 9.1 Exact finite algebra checks

`audit.py` generated 20 rational graph instances with seed 901781, checked acceptance, evaluated rational face and Hessian inequalities at independent rational points, and verified an unshielded outward-drift witness. All **841 exact finite assertions passed**. These check the implementation and examples, not the universal proof.

### 9.2 Two-variable independent quadrature comparison

The fixture has

\[
A=\begin{pmatrix}2.4&-0.4\\-0.4&2.4\end{pmatrix},\quad
C=\begin{pmatrix}0.4&0.2\\0.2&0.4\end{pmatrix},\quad
(a,c,r,u_0,v_0)=(0.5,0.2,0.45,0.1,1.1).
\]

The rational certificate gives lambda=2657/4000 and eta=297179/720000. Tensor Gauss–Hermite orders 64,100,160 agree to the displayed accuracy; additional 180,220,300 checks agree. This agreement is not an interval enclosure.

Reference:

\[
L\approx-0.0080567020736191+0.1232516328466937i.
\]

Six Gauss–Legendre parameter nodes were used. Results:

| step h | measurement time per node | real estimate | imaginary estimate | trajectory seconds |
|---|---:|---:|---:|---:|
| .02 | 600 | -.0083754256 | .1223170593 | 1.2514 |
| .01 | 2400 | -.0079919531 | .1207463450 | 8.9666 |
| .005 | 2400 | -.0079255675 | .1212422942 | 16.6865 |

Burn-in was 20 algorithmic time units. Reported batch standard errors only describe empirical fluctuation; they do not bound time-discretisation bias or establish independent block laws. Results are not monotonically ordered by h, and no monotone convergence claim is made. Some discrepancies exceed several reported statistical standard errors, consistent with unremoved discretisation error and finite sampling. No root failures occurred; residuals were evaluated in floating point with threshold 1e-11.

### 9.3 Matched specialised baseline on an independently generated connected chain

`connected_test.py` generated a ten-site heterogeneous chain with seed 802367, full-rank C on its allowed tridiagonal support, and a coefficient certificate. The inference procedure receives the same A,C,quartics as the baseline.

The comparator is direct transfer quadrature, not a tensor-product grid over all ten coordinates. It propagates a quadrature vector through local integral kernels, costs O(n p^2), and exploits the chain structure. Orders 64,100,160 give

\[
L\approx-0.0175976252822831+0.4275274950568466i.
\]

The tested complex process with h=.005, six parameter nodes, and measurement time 600 per node gave

\[
\widehat L=-0.0177927459807436+0.4247324300634479i.
\]

Empirical batch standard errors were approximately .0001096274 and .0013647439. The absolute component errors were .0001951207 and .0027950650, respectively. Transfer reference computation took .125614 seconds across all three quadrature orders; stochastic trajectories took 23.974548 seconds. Both timings are single-run measurements. The specialised comparator wins decisively in this executed regime.

### 9.4 Quantitative certificate versus observed practicality

`audit.py` implements the conservative recipe at n=2, epsilon=.01, delta=.01, using rational upper bounds for all square roots in local constants. It gives Cstep<=40,528,311 and chooses

\[
h=1/77,814,357,120\approx1.2851\times10^{-11}.
\]

It prescribes 28 parameter nodes, 128,455,084,912 independent endpoints, and approximately **3.3106 x 10^23 ideal implicit resolvent calls**, before inner root work and bit overhead. This is an explicit valid but extremely pessimistic recipe, NOT a lower bound on any implementation. It is not executed. The inexpensive tests above are not substitutes for it.

## 10. Matched prior-art comparison and scope

[S1] and [S2] document the difference between convergence and correctness. [S3] already establishes invariant-strip analysis for one-dimensional quartic examples. [S4] gives general necessary-and-sufficient observable-space conditions; their existence precludes claiming the first mathematical correctness criterion. [S5] already uses implicit solvers for complex Langevin. The intended distinction here is the directly acquired multivariate coefficient condition plus analytic real-cycle identification and finite-cost estimator reduction.

Contour deformation, positive representations, kernel learning, and zero-free interpolation must also be considered. No complexity lower bound or head-to-head result against their strongest implementations has been established. A zero-free region itself is already algorithmically useful in specialised interpolation frameworks [S7]; it would be incorrect to assume that competing methods receive no benefit from this same certificate. Our base quartic law is interacting, so its high derivatives at the anchor are not free either, but this observation is not a proof of superiority.

The certificate describes a uniformly massive/accretive regime. It neither reaches a critical continuum limit with vanishing lambda for free, nor treats arbitrary nonconvex phases or drift poles. It does not prove practical savings for QCD, chemical reaction dynamics, or general real-time many-body dynamics.

## 11. Exact continuation obligation

The retained new-mechanism candidate is the **analytic-anchor theorem**, not the claim that a restricted field example meets the mission.

A consequential next theorem would provide an acquired, same-answer stochastic geometry for conventional onsite-quartic fields with generic imaginary neighbour couplings, without requiring the paired quartics that made (3.2) easy and without moving the missing cost into a supplied transport map.

One precise candidate interface is a holomorphic symmetric kernel K_zeta=B_zeta B_zeta^T with generator

\[
\mathcal L_\zeta O=
\sum_{ij}K_{ij}\partial_i\partial_j O+
\sum_i\left(\sum_j\partial_jK_{ij}-\sum_jK_{ij}\partial_jS_\zeta\right)\partial_iO.
\]

The kernel and its derivatives must be acquired from input coefficients. On a real parameter interval K must be real positive definite so that the physical real Gibbs anchor is valid. Throughout an open complex connecting domain, prove nonexplosion, an invariant domain with diffusion-vector tangency at its boundary, quantitative contraction or another sufficient uniform mixing property, polynomial moments and holomorphic expectations. Poles, Jacobians, Ito drift corrections, geometry acquisition, and finite-bit implementation must all be charged. A learned kernel passing finite diagnostics is not this theorem.

Quadratic whitening fails for the stated reason; a merely curved tube with unchanged horizontal noise fails the tangency test. These are concrete obstacles to the next operation, not a reason to abandon the broad problem.

Separately, the quantitative constants must be reduced enough to produce nonvacuous error guarantees at the actual tested resources, and the method must beat a matched specialised competitor on nonfactorising instances where that competitor is genuinely expensive. Existing runs do not establish either requirement.

## 12. Sources and priority record

Source descriptions are deliberately short. Full source metadata, reading scope, and URLs are in `SOURCES.md`.

[S1] Mandl, *Correctness criteria for complex Langevin*, arXiv:2604.12388; published JHEP08(2026)110. V1 HTML inspected; latest abstract/publication metadata checked; v2 HTML retrieval failed. Necessary diagnostics can miss wrong cycles; general observable bounds exist but are difficult to use as practical proofs.

[S2] Seiler, Sexty, Stamatescu, *Complex Langevin: Correctness criteria, boundary terms, and spectrum*, PRD109014509 (2024); Seiler, *Complex Langevin: Boundary terms at poles*, PRD102094507 (2020). Used for failure mechanisms and the danger of assuming stochastic-time analyticity, not imported as a premise of the new proof.

[S3] Aarts, Giudice, Seiler, *Localised distributions and criteria for correctness in complex Langevin dynamics*, Annals of Physics337238–260 (2013), arXiv:1306.3075. Prior invariant-strip work credited.

[S4] Mandl, Seiler, Sexty, *Necessary and sufficient conditions for correctness of complex Langevin*, J.Phys.A58 495202 (2025), arXiv:2508.14512. General observable-space correctness conditions credited.

[S5] Alvestad, Larsen, Rothkopf, *Stable solvers for real-time Complex Langevin*, JHEP08(2021)138, arXiv:2105.02735. Implicit complex Langevin solvers credited.

[S6] Cai, Dong, Kuang, *On the validity of complex Langevin method for path integral computations*, SIAM J.Sci.Comput.43 A685–A719 (2021), arXiv:2007.10198. Prior rigorous localisation and gauge-cooling analysis credited; abstract/metadata read, full proof not reviewed here.

[S7] Gamarnik, *Correlation decay and the absence of zeros property of partition functions*, Random Structures & Algorithms62 155–180 (2023), arXiv:2011.04915. Zero-free interpolation and correlation-decay connections credited; not asserted to directly cover this continuous quartic class.

**Final status:** a proof candidate and reproducible handoff, not independently verified mathematics or historical novelty; an explicit computational correctness mechanism, not an achieved foundational scientific breakthrough.
