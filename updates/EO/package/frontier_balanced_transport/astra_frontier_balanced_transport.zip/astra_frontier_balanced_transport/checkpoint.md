# Research checkpoint — 12 October 2026

**Objective retained:** affordable certified physical predictions/design decisions, not reconstruction for its own sake.

**Changed interface:** bounded-range translation-invariant interacting spin matter with on-site dephasing and tracial half-filled response. Optional calibration uses controlled local preparations and Ramsey measurements, not passive Gibbs copies.

**Completed mathematical derivations:** exact balanced primal–dual response and sum-of-squares gap; exact exclusion Poisson operator for undamped populations; fixed-degree rational compiler; positive finite-volume noise-response spectral measure; existence and two-sided bound for the infinite-chain long-time second moment; finite-data local decision certificate.

**Most important proof boundary:** Section 7 does not identify unregularized finite-ring DC values with the thermodynamic coefficient. It takes infinite size at positive Laplace parameter, proves the zero-parameter limit through the parity Schur operator, and uses positivity plus an explicit Tauberian argument for the second moment. This does not prove Gaussian hydrodynamics or a convergence rate.

**Failed interfaces retained:** ignoring a diagonal residual produces a false lower bound even in a two-block example; small off-diagonal trial families need not provide tight intervals; strong-noise data cannot be extrapolated freely to zero noise; physical-structure calibration is not inferred from the statistical interval.

**Next decisive theorem:** G1, polynomial total construction/verification of high-precision balanced witnesses at fixed finite range, bounded interactions and strictly positive dephasing, without a strong-noise assumption. Both Pauli growth and diagonal-pressure degree must be charged. Thermodynamic precision additionally needs quantitative transfer. G2 is a quantitative Gaussian density-response limit.

**Evidence status:** complete written derivations, exact rational examples, finite floating diagnostics, synthetic statistical fixture. No independent proof review, historical-priority clearance, physical experiment or superior-method benchmark. No external repository writes.
