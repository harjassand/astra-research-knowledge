# Response-error jets: reproducibility package

This package predicts and optimizes the **full macroscopic second-moment transport coefficient** of the interacting pure-dephasing chain specified in `research_note.md`. It is not a Hodge-energy-only calculation.

## Main outputs

- `results/global_design.json`: exact continuous-domain uniqueness, optimizer bracket, regret, improvement, calibration and matched-value comparison.
- `results/fresh/witness.npz` and `.json`: central exact dyadic response-jet packet and complete rational residual Gram matrices.
- `results/anchors/*.npz` and matching `.json`: seven newly solved global-exclusion packets.
- `results/resource_ledger.json`: measured cost and complete scope qualifications.
- `results/standalone_verification.json`: optimizer-independent rerun of all exact packet checks.
- `results/mathematical_checks.json`: separate finite symbolic/numerical and encoding diagnostics.

The coefficient is not measured experimentally. Proof review, formal verification, device calibration and historical novelty remain open. Uniform inexpensive termination is not proved.

## Environment used

Python 3.13.5; NumPy 2.3.5; SciPy 1.17.0; SymPy 1.14.0; Numba 0.65.1. Other compatible installations may work; the recorded versions are in `requirements-recorded.txt`. Code uses native arbitrary-precision Python integers and `fractions.Fraction` for final certificates. Use normal Python execution, **not `python -O`**, because invariant checks are assertions.

Run from the package directory, with these thread settings:

```sh
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
```

## Verify the stored result without discovery

```sh
python code/verify_artifacts.py results
python code/certify_global_design.py results
python code/mathematical_checks.py
```

The first command recomputes all full commutators and exact residual quantities from the witness coefficients, including output words outside the trial basis. The second checks the continuous parameter intervals, exact gradient signs and global regret. Its input scalar metadata is trusted only after the first command passes. The third tests the finite algebra against separately written implementations and symbolic examples.

Hash checking ensures file consistency; it is not a substitute for these calculations or for the mathematical theorem.

## Reproduce full fresh acquisition in a new directory

```sh
python code/fresh_benchmark.py rerun/fresh
python code/build_anchors.py rerun/anchors rerun/fresh/witness.npz
python code/certify_global_design.py rerun
python code/verify_artifacts.py rerun
```

The first command acquires the central basis from all allowed span-eight words, runs ten adaptive enrichments, solves orders 0–3 and produces an exact packet. No prior response packet is used. The second computes five small anchors from span-eight dictionaries and two larger anchors using the already charged central dictionary. All response coefficients are solved anew.

The recorded 193.4354 seconds is the sum of the three solver-stage measurements on the supplied machine with existing compiler caches. Your runtime, coefficient rounding and file hashes may differ. Exact certificates, not bit-identical floating optimizer trajectories, are the scientific output. The fixed center and heuristic enrichment settings were selected in exploratory development, which is outside that timing.

## Limits of the implementation

The fast exact checker is intentionally restricted to the t=1, d=2, rational ZZ/ZIZ fixture with input word span at most 18. It rejects unsupported spans. The discovery commutator compiler has a wider internal guard to handle generated residuals safely. Arbitrary finite-range models require an appropriately generalized and checked compiler; the wider mathematical statements are not a claim that such a compiler is implemented here.

All final numerical uncertainty is charged by exact rational residuals. No stochastic confidence parameter, physical time cutoff, matrix-product rank assumption, unknown relaxation gap, or added physical damping occurs in these certificates.

## Provenance

`fast_algebra.py`, `local_solver.py` and the arithmetic helpers in `prior_exact.py` derive from the earlier conversation's local translation-certificate compiler. The packed-key width and range guard were revised here and retested. They are code dependencies, not externally reviewed mathematics. No old response coefficients are inputs to the fresh benchmark.

See `research_note.md` for the full derivation and prior-art comparison and `checkpoint.md` for the retained frontier. External repositories were read but not modified.
