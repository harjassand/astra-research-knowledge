# Internal audit and failure log

**Date:** 10 October 2026, Australia/Brisbane. Author-internal work only.

## Mathematical derivation checks

The construction was checked in two representations: regrouping actual tensor powers, and explicit normalized occupation-number isometries. Kraus completeness is verified on the full direct sum; the analysis does not define a nonlinear map only on the promised family. Off-diagonal input blocks are physically dephased.

The EB lower bound is derived by composing an arbitrary EB channel with a fixed physical decoder. It does not restrict the EB channel's measurement, outcome count, prepared states, runtime, or knowledge of the finite family. The prior is fixed before the comparator is selected.

Commuting replacement is treated separately, since measure-and-prepare channels may output noncommuting states. The final support-moment bound sums projection masses over an arbitrary orthonormal basis. The finite prior exactly reproduces the required moment operators, so one ensemble handles all comparators simultaneously.

For the cq consequence, the competing classical state's X marginal is not fixed. The proof explicitly allows arbitrary q_x and controls the changed weights by a classical overlap/Cauchy–Schwarz estimate. This prevents a hidden fixed-prior restriction in the distance-to-classical-state theorem.

## Consequential negative controls

1. The construction is not global cloning. Exact product-target distance is 1−(L−1)/L^m.
2. It is not globally nearly idempotent: a state in sector H_2 gives orthogonal Φ and Φ² outputs, hence diamond defect 2.
3. It has unbounded Holevo capacity and large actual-prior information loss. It cannot be used to close the entropy-loss gate or refute the bounded-capacity theorem.
4. Six Pauli eigenstates reproduce the required low moments in an exact fixture but do not form a fourth-order design. The script includes this failed higher-moment claim as a negative control.
5. At d=2,L=2 the final second-moment commuting upper bound is capped at one and is trivial. Its numerical basis fixtures are checks of an identity/inequality, not evidence of a nontrivial asymptotic separation at those small parameters.

## Implementation failure history

- An early parameter check attempted to construct the integer 2**K at L=100, K=2**100. That process hit a 200-second timeout. It was replaced by an equivalent bit-length comparison. The final second-moment proof eliminates that older high-moment condition altogether.
- A subsequent run completed the numerical work but failed to serialize a NumPy int64 offset to JSON. The offsets were explicitly converted to Python integers.
- The corrected first script passed 96 checks. That version and its receipt are retained under `history/`.
- Explicit global-cloning-distance fixtures were added, producing the final 112-check script.
- The first commuting-family derivation used a higher moment and an ambient-dimension estimate. A later exact block-mass summation improved the bound to a second moment and reduced the required design order from K² to 2K. The earlier 52-check finite-design script and receipt remain under `history/`. The final finite-design script has 44 checks; it tests smaller complete designs appropriate to the stronger proof.
- The final two scripts were executed under `python -O`, with 112 and 44 checks passing. A check count is not a count of independent mathematical validations.

The failed pre-correction draft bytes were not retained; this log records the observed failures without claiming byte-level preservation of those drafts.

## Competing opportunities and discarded computational route

NPT Werner all-copy positivity was examined before concentration on broadcasting. Astra N525 supplies a rank-two witness-to-flat-projection reduction but no universal lower bound. A weight-enumerator linear-programming relaxation was explored in `exploration/werner_enumerator_lp.py`. Its relaxed negativity does not supply a realizable rank-two projector: nonlinear compatibility/decomposability constraints are absent. Large-copy floating runs also exhibited constraint-residual problems. No LP minimum from this exploration is presented as a proof or a physical counterexample, and no raw LP output receipt was preserved.

Astra N529's Boolean coordinate-selection counterexample was inspected as another direction. It refutes the stated auxiliary selection criterion, not FEI. No new Boolean theorem is claimed and the full referenced Boolean proof was not reconstructed in this session.

## Literature and provenance limitations

The standard pure-state estimation inequality is credited and reproved rather than imported from an unread full proof. Exact no-broadcasting, local no-broadcasting, quantitative entropic broadcasting, finite/asymptotic broadcasting, and embezzlement were considered as predecessors. Historical novelty remains unknown; the literature search was targeted, not exhaustive.

Some primary HTML pages were readable earlier in the session but returned cache misses when reopened near completion. Bibliographic and read-depth metadata preserve that distinction. Direct runtime downloading of repository source bytes was unavailable during this session; source Git revisions and connector-read paths are pinned, but raw source SHA-256 fields remain null.

No external peer review, independently authored audit, proof-assistant kernel run, experimental realization, or demonstrated discovery-capability gain occurred.
