# ASTRA Primitive Genesis: state-independent marginal clocks

**Date:** 12 October 2026  
**Status:** internally derived conditional theorem and exact counterexamples; not independently reviewed, not a foundational breakthrough, and not a historical-priority claim. The universal irredundant-cover balance condition remains unproved. No repository was modified.

## 1. Research decision and decisive objective

Independent exploratory directions were general arithmetic circuit lower bounds, resolution of singularities in positive characteristic, rigorous critical three-dimensional Ising universality, and exponential sunflower bounds. Proposed operations were, respectively, cancellation-aware complexity accounting; a blowup invariant resistant to Frobenius-induced residual-order increases; controlled renormalisation preserving the observables needed for a scaling theorem; and correlated sampling that removes unnecessary independent-sampling losses. No general construction was established for the first three. The sunflower route produced an exact obstruction, recorded in Appendix A.

The selected mathematical objective emerged from investigating dependent coordinate representations:

> If N affine hyperplanes form an irredundant cover of F_p^d and their normal vectors span dimension r, prove r log p <= C N, with C absolute.

All logarithms in this note are natural. An irredundant cover covers every point and gives each hyperplane a private point covered by no other hyperplane. Write the normal vectors as the columns of A, and let W = ker A <= F_p^N. Then r = codim W and the objective is |F_p^N/W| <= exp(C N).

The attraction is not a small-parameter theorem: a successful operation would remove the entire logarithmic loss in this covering problem. This is nevertheless a narrower objective than general circuit lower bounds or resolution of singularities. No implications for those problems, or for a civilisation-changing technology, have been established.

### Prior mathematics and an important correction

Nagy–Pach–Tomon's 2021 precursor proves a log-log-loss covering bound through group-ring identities and arithmetic-set compression. Its mechanism constructs representatives from a product alphabet of size O(log p). The 2026 published paper *Hyperplane covers of finite spaces and applications* reports the corresponding Omega(r log p / log log p) hyperplane bound. The exact 2021 proofs were inspected; the 2026 publication and abstract were checked, but the full published PDF could not be retrieved in this run. [R1, R2]

Their distinct 2022 preprint *Irredundant hyperplane covers* was withdrawn. Its arXiv notice reports an error invalidating most of the paper. It cannot supply the desired exponential theorem. The reset-and-double coordinate chain used below already appears in that withdrawn argument: it is NOT claimed as a new invention. The proposed repair is an exact marginal-generator lift with a separately stated feasibility condition. [R3, R4]

## 2. Operation and its exact input contract

Let p be an odd prime, N >= 1, and W <= F_p^N. For x in (F_p^*)^N define the nonzero legal directions

    D(W,x) = (W intersect product_i {0, x_i, -x_i}) minus {0}.

For a direction w, let s(w) in {0,1}^N be its support indicator. Define the support cone

    C(W,x) = cone {s(w): w in D(W,x)}.

The usable hypothesis is the existence of a **common positive clock vector**:

    there exists r in R_{>0}^N such that
    r belongs to C(W,x) for every x in (F_p^*)^N.                 (CB)

Equivalently, for every x there are nonnegative coefficients lambda_{x,w} satisfying

    sum_w lambda_{x,w} 1_{w_i != 0} = r_i, for every i.          (1)

The r_i may differ between coordinates; they must not depend on the current state. The stronger unit-balance condition takes r = (1,...,1).

Conic feasibility, linear programming, and generator intertwining are established mathematical tools. Naming the cone does not constitute a new primitive. The candidate operation is the construction of a coset-preserving process with exactly prescribed scalar marginal generators, provided (CB) can actually be established from structural information.

### Complexity boundary

There are finitely many x, so choices of coefficients exist as ordinary finite mathematical data under (CB). A conic representation can be chosen with at most N directions at each x. However, enumerating states, legal directions, or all scaling classes can be exponential. No efficient direction oracle, polynomial-time LP acquisition, mixing-time bound, or efficient representative sampler is proved. This is a conditional existence theorem, not an efficient algorithm hidden behind a supplied oracle.

## 3. Conditional entropy theorem

**Theorem 1.** Under (CB),

    log |F_p^N/W| <= h_0 N,
    h_0 = log 3 + (4/3) log 2.

Consequently,

    p^(codim W) <= K_0^N < 8^N,
    K_0 = 3 * 2^(4/3) = 7.559526299369239...

The prime p = 2 also satisfies the stated cardinality bound trivially, without requiring this construction.

### Proof: construction of the joint generator

For a state z in F_p^N, put

    x_i(z) = z_i when z_i != 0, and x_i(z) = 1 when z_i = 0.

Use a solution of (1) for x(z). For each legal direction w, introduce transitions

    z -> z+w and z -> z-w,

at rate lambda_{x(z),w}/2 each. Duplicate destinations have their rates added. Every transition remains in the same coset of W. The total rate is finite; indeed sum_w lambda_{x,w} <= sum_i r_i because every legal direction is nonzero.

Let Q denote this finite-state generator. For a scalar function f:F_p->R and the coordinate projection pr_i, direct evaluation gives

    Q(f o pr_i)(z) = r_i Lf(z_i),                              (2)

where

    Lf(b) = [f(0)+f(2b)-2f(b)]/2,    b != 0,
    Lf(0) = [f(1)+f(-1)-2f(0)]/2.

Indeed, each direction active at a nonzero coordinate replaces its value by 0 or twice its value, with equal rates. At a zero coordinate, the two destinations are 1 and -1. Summing the active rates gives exactly r_i.

Equation (2) is the essential interface. It does not assert independence of coordinates. It proves that every coordinate has the correct generator in ordinary elapsed time, not merely when observed at its own jumps.

### Proof: the scalar stationary law

Every nonzero b resets to zero at rate 1/2. From zero the scalar process enters +1 or -1, and successive non-reset moves double the current value. Therefore its unique recurrent class is

    Omega = {0} union {+2^k, -2^k : k >= 0} mod p.

All states reach this class; within it every state can reach zero and every state can be reached from zero. Hence L has a unique stationary law pi.

An explicit description of pi is:

* output 0 with probability 1/3;
* with probability 2/3, draw a uniform sign S in {-1,+1} and an independent integer T >= 0 with Pr(T=k)=2^(-k-1), then output S 2^T mod p.

To verify stationarity directly, let nu be the law of S 2^T. The geometric identity gives nu = (1/2)law(S) + (1/2)law(2Y), where Y has law nu. Combined with pi(0)=1/3 and pi on nonzero states equal to (2/3)nu, this is exactly pi L=0. Modular collisions only combine masses; the verification does not require the signed powers to be distinct.

The sign entropy is log 2 and the geometric entropy is 2 log 2. Encoding the mixture before reducing modulo p gives

    H(pi) <= h(1/3) + (2/3)(log 2 + 2 log 2)
          = log 3 + (4/3)log 2
          = h_0.                                               (3)

Here h denotes binary entropy. Passing from the encoding to a residue cannot increase entropy.

### Proof: quotient entropy without independence

For each coset c, choose any stationary probability measure mu_c for the restriction of Q to c. Such a measure exists on every nonempty finite state space; irreducibility of the joint chain is unnecessary.

Stationarity and (2) imply, for every i and every f,

    0 = E_{mu_c} Q(f o pr_i) = r_i E_{mu_c} Lf(Z_i).

Since r_i > 0, the i-th marginal is stationary for L and therefore equals pi.

Now choose a coset label C uniformly from F_p^N/W and sample Z from mu_C. The coset label is determined by Z. Every coordinate of Z has marginal pi. Thus

    log |F_p^N/W| = H(C)
                  <= H(Z)
                  <= sum_i H(Z_i)
                  = N H(pi)
                  <= h_0 N.

This proves the theorem. No mixing estimate, product distribution, or independence approximation is used. QED.

### A weaker sufficient hypothesis

It actually suffices to choose a separate fixed positive vector r^(c) for each coset, provided it belongs to C(W,x(z)) for every z in that coset. The same proof works because multiplying a scalar generator by a positive constant does not change pi. The common global vector (CB) is a convenient stronger interface, not a logically necessary condition for the entropy conclusion.

The counterexample in Section 5 defeats even this coset-specific fixed-clock relaxation in at least one coset. It does not exclude arbitrary other stochastic constructions or other proofs of the quotient bound.

## 4. Why a correct jump chain is not enough

A coordinate can have the right transition law at its successive jumps while its occupation law at ordinary times is wrong, because the waiting time can depend on its current state or on other coordinates.

For a two-state illustration, the embedded jump chain alternates 0,1,0,1,... regardless of rates. The continuous-time chain with rate epsilon from 0 to 1 and rate 1 from 1 to 0 has stationary law

    pi(0)=1/(1+epsilon),  pi(1)=epsilon/(1+epsilon).

Thus the jump chain alone does not determine the physical-time marginal. This elementary example establishes the logical distinction; it is not itself a counterexample to every claim of the withdrawn paper. The exact generator identity in Theorem 1 avoids the inference entirely.

## 5. Exact obstruction: versatility does not provide balanced clocks

A subspace W is called versatile here when, for every nonzero scaling x and every coordinate j, some w in W satisfies w_i in {0,+x_i,-x_i} for all i and w_j=x_j. This is the established local movement property arising in the group-ring covering argument. [R1, R4]

Consider the three-dimensional subspace of F_5^5 with row basis

    B = [1 0 0 4 3]
        [0 1 0 1 1]
        [0 0 1 2 0].

Equivalently,

    W = {(a,b,c,-a+b+2c,3a+b): a,b,c in F_5}.

It is the kernel of

    A = [1 4 3 1 0]
        [2 4 0 0 1].

### 5.1 Analytic proof of versatility

The normal columns are v_1=(1,2), v_2=(4,4), v_3=(3,0), v_4=(1,0), and v_5=(0,1). Columns 3 and 4 are horizontal. Columns 1, 2 and 5 have three distinct nonhorizontal directions.

A basic fact used twice is that any two three-element subsets of F_5 sum to F_5: for any target t, the first set and the translate t minus the second set must intersect.

Fix arbitrary nonzero x_i. To prescribe w_j=x_j for a nonhorizontal column j in {1,2,5}, choose the other two nonhorizontal coefficients from their respective three-element symmetric sets to cancel the prescribed vertical component. Then choose the two horizontal coefficients to cancel the remaining horizontal component. Both choices use the three-set fact.

To prescribe a horizontal column, examine the three scaled nonzero vertical components of columns 1, 2 and 5. There are only two sign classes in F_5^*, so two of these components agree up to sign. Their columns can therefore produce 0 or either sign of a nonzero horizontal vector h, with the vertical components cancelled. The horizontal vector is nonzero because those columns have distinct directions. Combine {0,+h,-h} with the symmetric three-set from the other horizontal column to cancel the prescribed target. This proves versatility for every scaling and every coordinate.

### 5.2 Failure of unit balance

At x=(1,1,1,1,1), the nonzero legal support vectors are exactly

    (0,1,0,1,1),
    (0,1,1,1,1),
    (1,1,0,0,1).

They satisfy

    s_1+s_4=s_2=s_5.

Every vector in their cone satisfies the same equations. The all-ones vector does not. An exact rational separating vector is

    y=(-1,1,0,-1,0),

whose dot product with every legal support is zero but whose dot product with the all-ones vector is -1. This is an exact infeasibility certificate, not a conclusion based on a numerical LP status.

### 5.3 Failure of all common positive clocks

At x'=(2,2,2,2,1), the legal support vectors are exactly

    (1,0,0,1,1),
    (1,0,1,1,1),
    (1,1,1,0,1),
    (1,1,1,1,1).

Every vector in this cone satisfies r_1=r_5.

At x''=(2,2,2,2,2), scalar invariance gives the same support cone as at the all-ones scaling, so

    r_1+r_4=r_2=r_5.

Any vector in both cones must have r_4=0. Their intersection therefore contains no strictly positive vector. Unequal but state-independent coordinate speeds do not repair the problem.

The same two cone types occur within a single coset. Indeed,

    z'  = (2,3,3,2,1),
    z'' = (3,2,2,3,3),
    A z' = A z'' = (0,2) mod 5.

Their coordinatewise symmetric sets are precisely those of x' and x'', respectively. Consequently even assigning a different fixed clock vector to each coset cannot repair this example.

### 5.4 Scope of the counterexample

These five normal vectors do not form an irredundant affine cover. Five affine lines in F_5^2 have total incidence capacity 25, so covering all 25 points would require them to be pairwise disjoint, hence parallel. These normals have rank two and are not parallel.

The example refutes the claimed implication from versatility to clock balance. It does NOT refute the cover-specific balance gate, the target exponential covering theorem, or the possibility of another operation.

## 6. Infinite amplification: bounded clock distortion also fails

Versatility is preserved when two versatile subspaces are glued along one coordinate. To activate a coordinate in the first subspace, take a legal vector there. Its shared coordinate is either 0 or plus/minus the prescribed scale. Extend by the zero vector in the second subspace in the first case, or by a legal vector activating the shared coordinate with the required sign in the second case. The argument is symmetric.

In the five-coordinate example, regard coordinate 2 as a root, coordinates 1 and 4 as its two children, and coordinates 3 and 5 as auxiliary coordinates. At the all-ones scaling, every nonzero legal direction activates the root and exactly one child; if the root is zero, the entire local direction is zero.

Glue one copy at every internal vertex of a full binary tree with L=2^h leaves. The resulting versatile subspace has

    N = 1+4(L-1) = 4L-3,
    dim W = 1+2(L-1) = 2L-1.

The dimension count follows because fixing a gadget's root leaves two free parameters. Every nonzero global legal direction at the unit scaling activates the root and exactly one leaf. Thus every nonnegative combination r of legal supports satisfies

    r_root = sum_{leaf ell} r_ell.

If all coordinates are positive, then

    max_i r_i / min_i r_i >= L.

Hence even a dimension-independent bound on clock distortion cannot be inferred from versatility. The obstruction is not just a missing constant in one five-coordinate example.

## 7. A constructive closure property of unit balance

Unit balance itself is preserved under the same coordinate gluing, which provides a nonvacuous compositional property of the operation.

For fixed scaling, split each component's balanced direction measure into directions inactive at the shared coordinate and directions active there. The active measures each have total mass one. Reverse signs if necessary so every active representative has the prescribed positive shared value. Couple the two active measures with their product measure and glue each pair. Extend each inactive direction by zero in the other component.

The shared coordinate now has activity one, counted once. Every other coordinate retains exactly its original activity. All glued directions are legal kernel vectors. Since the construction works at every scaling, unit balance is preserved. This argument does not establish unit balance for indecomposable irredundant covers.

## 8. The precise unproved gate

**Cover-balance gate (strong version).** For every prime p and every irredundant affine hyperplane cover with normal matrix A,

    1_N belongs to C(ker A,x), for every x in (F_p^*)^N.         (G)

A weaker sufficient gate asks only for a common strictly positive vector; a still weaker one asks for positive fixed clocks separately in each coset. All remain unproved for general irredundant covers.

The known local versatility statement does not establish (G); Sections 5 and 6 rigorously exclude that shortcut. The counterexample cannot be passed off as a counterexample to (G), because it fails the cover assumption.

### Exact falsification format

For fixed p,A,x, failure of unit balance has a rational separating certificate y with

    y dot s(w) >= 0 for every w in D(ker A,x),
    sum_i y_i < 0.

To falsify (G), supply p,A, affine offsets, a proof that every point is covered, a private point for every hyperplane, the scaling x, and the separator with an exact verification against all legal supports. The presence of affine offsets and private witnesses is essential: a bare versatile subspace is not a valid counterexample.

### Conditional consequences if the gate is proved

Theorem 1 would immediately give r log p <= h_0 N for all irredundant affine hyperplane covers. A published reduction from prime-field hyperplane covers to irredundant coset covers of finite abelian groups would then give an exponential intersection-index bound. This is a conditional use of an existing reduction, not a new proof of it. [R1, Section 4]

There is also a direct conditional matrix-avoidance consequence. Suppose M_1,...,M_k are invertible n-by-n matrices over F_p and each coordinate of each M_j x has at most m forbidden values. If no x avoids all forbidden values, the forbidden-value hyperplanes contain an irredundant subcover of size N'. Among these normals, some matrix contributes at least N'/k rows counting repetitions, hence at least N'/(km) distinct independent rows. Their rank is therefore at least N'/(km). The cover inequality would imply log p <= h_0 km. Consequently, under (G), p > K_0^(km) guarantees an avoiding vector. This does not assert a polynomial-time algorithm or the stronger forbidden-set conclusions of the withdrawn paper.

## 9. Reproducible exact finite evidence

The supplied Python program performs exact core checks, optional numerical witness discovery, and separate rational certificate replay.

Command used:

    python astra_clock_lift_verify.py --search --trials 40 --scales 12 \
      --output astra_clock_lift_results.json

Seed: 20261012. The fresh, preserved run produced:

| Family | Covers checked | Scaling certificates |
|---|---:|---:|
| Standard six-line central pencil in F_5^2 | 1 | 64, all sign classes |
| Random greedy irredundant affine covers of F_5^2 | 40 | 598 |
| Random greedy irredundant central covers of F_5^3 | 39 | 619 |
| Total | 80, including the separate pencil | 1,281 |

One additional central cover had size 11 and was skipped by the configured size cap of 10. The affine size cap was 9. Small covers used all sign classes; larger covers used sampled scalings. Distinct rows in the table do not assert distinct isomorphism types or disjoint certificate sets.

All accepted coefficients were reconstructed as rational numbers and checked exactly against legal finite-field directions. An additional replay used only Python integers and fractions.Fraction:

    python astra_clock_lift_verify.py --replay astra_clock_lift_results.json

All 1,281 positive certificates passed this replay. No numerical LP infeasibility report was accepted as a proof. The five-coordinate counterexample was checked in all 32 sign classes and has the separate analytic proof above.

In the standard pencil, 24 of the 64 scaling classes had no full-support legal direction but did have an exact fractional balancing certificate. Thus balancing cannot be replaced indiscriminately by searching for a single fully supported move.

**Limitations:** these are small-field, nonexhaustive tests, not evidence of the required large-prime asymptotic theorem. In particular K_0>5, so the entropy inequality itself is numerically weaker than the trivial p^N bound over F_5; the tests concern feasibility of the mechanism, not a nontrivial asymptotic rank improvement. Internal exact replay is not independent expert review or a proof-assistant verification.

## 10. Selective mining of Astra and OpenAI proof capital

Astra was inspected at commit:

    5ab60ff49af6da752fe8452031996410a50f00b4

The exact source inspected was

    updates/EL/package/primitive_genesis/reaction_clock_integration/INTEGRATION_PROOF.md
    source lines 1-150, especially the projection and conditioning arguments.

That source explicitly uses Q'(f o projection) = Qf o projection to retain physical-time laws, and separates legitimate event-content conditioning from clock-dependent conditioning. Only the exact generator-interface mechanism is reused here. No chemical-reaction compiler theorem, rate-query bound, or idealised random-variate complexity claim transfers to this finite-field problem. The source itself is internally reconstructed and not independently audited. [R5]

OpenAI's repository was inspected at:

    fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb

The exact file was

    lean/OAI/Combinatorics/ParityLifts/Flowers.lean
    source lines 1-260.

Its maximal-disjoint-family proof of the rank-two sunflower bound and the core-reattachment operation were read. They provide exact fixed-rank mechanisms, not a uniform exponential-in-rank sunflower result or a proof of (G). The Lean code was not compiled in this run. [R6]

## 11. Claim ledger and next decisive mathematical task

| Claim | Status |
|---|---|
| Common positive marginal clocks imply the K_0^N quotient bound | Complete proof in this note; not independently reviewed |
| The five-coordinate subspace is versatile | Analytic proof and exhaustive finite check |
| Versatility implies unit balance | False, with exact separator |
| Versatility implies common positive clocks, even separately in every coset | False, with exact two-state same-coset obstruction |
| Versatility implies bounded clock distortion | False, with explicit infinite gluing family |
| Unit balance is preserved under coordinate gluing | Complete constructive argument |
| Every irredundant affine cover satisfies (G) or a sufficient weaker gate | Unproved |
| An unconditional exponential hyperplane/coset-cover theorem has been established here | No |
| A fundamentally new mathematical primitive or historical priority has been established | No |
| An efficient algorithm follows from the construction as currently supplied | No |

The next decisive task is to use the full irredundant-cover structure—not merely local versatility—to prove one of the sufficient clock-lift conditions or to produce an exact cover counterexample. If all fixed-clock variants fail, the operation must be replaced; weakening the target to another fixed-rank calculation would not meet the objective.

## Appendix A. A failed sunflower surrogate, with exact proof

A probability law on subsets is R-spread if Pr(S subset X) <= R^(-|S|) for every finite S. The proposed shortcut was that sufficiently large constant spread might force disjoint samples. It is false even for the existence of a disjoint pair.

Take q>=2 and m>=q^q disjoint blocks, each of size q. A set in the family fills one block completely and chooses exactly one element in each other block. Choose the full block uniformly and all other choices independently and uniformly. Every set has size k=m+q-1; there are m q^(m-1) distinct sets.

Any two members intersect: the second member meets the full block of the first.

Set R=q/(1+(q-1)/m). If S has at least two elements in each of two blocks, its inclusion probability is zero. If S has u>=2 elements in one block and s singleton elements in other blocks, the inclusion probability is m^(-1)q^(-s), at most R^(-(u+s)) because m>=q^q>=R^u and R<=q. If S has singleton elements in t distinct blocks, its inclusion probability is

    q^(-t) [1+(q-1)t/m]
      <= q^(-t) [1+(q-1)/m]^t
      = R^(-t),

by the binomial inequality. Thus the family is R-spread with arbitrarily large R, yet pairwise intersecting. The construction does not rule out sunflowers with a common core.

A second rejected move was to define an entropy-minimising coupling supported on sunflower triples and hope for a universal O(k) divergence bound. For a sunflower-free k-uniform family, such a coupling with uniform identical marginals is necessarily diagonal and its divergence from the independent product is 2 log |F|. Merely asking for the needed O(k) bound therefore reinstates the difficult exponential sunflower bound instead of supplying a mechanism.

## References and source scope

[R1] J. Nagy, P. P. Pach, I. Tomon. *Additive bases, coset covers, and non-vanishing linear maps*, arXiv:2111.13658v1 (2021). Exact relevant proofs inspected in Sections 2 and 4. https://arxiv.org/html/2111.13658v1

[R2] J. Nagy, P. P. Pach, I. Tomon. *Hyperplane covers of finite spaces and applications*. Transactions of the AMS 379 (2026), 137-156. DOI 10.1090/tran/9483. Publication/abstract checked; full final PDF retrieval failed. Author version: https://cs.bme.hu/~ppp/publications/Hyperplane_covers.pdf

[R3] Withdrawal notice for *Irredundant hyperplane covers*, arXiv:2205.03389v2 (31 October 2022). https://arxiv.org/abs/2205.03389

[R4] The authors' earlier withdrawn preprint, inspected as historical failed-proof material, especially printed page 8. https://www.researchgate.net/publication/360462814_Irredundant_hyperplane_covers/fulltext/627885da973bbb29cc6d6cba/Irredundant-hyperplane-covers.pdf

[R5] Astra source at the commit pinned above. https://github.com/harjassand/astra-research-knowledge/blob/5ab60ff49af6da752fe8452031996410a50f00b4/updates/EL/package/primitive_genesis/reaction_clock_integration/INTEGRATION_PROOF.md

[R6] OpenAI source at the commit pinned above. https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/OAI/Combinatorics/ParityLifts/Flowers.lean

[R7] H. Hauser, S. Perlega. *Cycles of Singularities appearing in the Resolution Problem in positive Characteristic*. https://arxiv.org/abs/1802.05010

[R8] P. Amireddy et al. *Low-depth arithmetic circuit lower bounds via shifted partials*. https://arxiv.org/abs/2211.07691

[R9] S. Lovett. PCMI sunflower lecture notes (2025). https://www.ias.edu/sites/default/files/Sunflowers%20Lecture%20Notes_1.pdf

All candidate results in this packet are research output from this run, not externally established findings. Priority remains unverified.
