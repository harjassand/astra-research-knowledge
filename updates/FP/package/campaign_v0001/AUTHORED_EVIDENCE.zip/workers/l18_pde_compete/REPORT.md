# L18 — Turbulent design under finite acquisition: incumbent map and lower bound

**Status:** no new capability found. A recent incumbent already optimizes statistical steady-state objectives in a high-dimensional turbulent PDE when the governing model and target statistic are supplied. The actual boundary I can support is narrower: finite measurements cannot certify a robust global design over an unrestricted but smooth response class. The lower bound below is exact for its stated oracle model; it is not a Navier–Stokes-specific theorem.

## 1. Output and information contract

Take a scalar design variable \(a\in[0,1]\), such as an actuator/forcing setting, and a scalar long-run response

\[
 J(a)=\lim_{T\to\infty}\frac1T\int_0^T q(u_a(t))\,dt,
\]

where \(q\) can represent a mean drag, pressure loss, transport, or another design-relevant statistic. The input to an acquisition procedure is a sequence of at most \(n\) selected settings \(a_i\) and the corresponding exact values \(J(a_i)\). Assume only that \(J\in C^1([0,1])\) and \(\lVert J'\rVert_\infty\le L\), with known \(L\). The required output is a design \(\hat a\) and a uniform certificate that

\[
J(\hat a)-\min_{a\in[0,1]}J(a)\le \varepsilon
\]

for every response consistent with the acquired values. This is already generous to the method: each query returns the exact infinite-time mean, free of finite-horizon, sampling, measurement, discretization, or model errors. In an experiment or DNS study, each such value requires a costly operating condition and enough flow time to estimate the mean.

This contract captures optimization with unresolved closure/model uncertainty only if that uncertainty is represented by the admissible response class. If the complete PDE, closure, coefficients, and boundary/forcing conditions are supplied exactly, this uncertainty class is too broad; direct simulation and the methods below apply instead.

## 2. Finite-acquisition lower bound

Let a deterministic adaptive procedure make at most \(n\) exact queries and return \(\hat a\). Run it on \(J_0(a)\equiv0\), so its query sequence and output are fixed. Sort the query locations together with \(\hat a\) and the interval endpoints 0 and 1. These at most \(n+3\) points create at most \(n+2\) gaps, so one gap \([b,b+w]\) has length

\[
w\ge \frac1{n+2}.
\]

Use the \(C^2\) compact bump

\[
\phi(t)=\begin{cases}(1-t^2)^3,&|t|<1,\\0,&|t|\ge1,\end{cases}\qquad
C_\phi:=\lVert\phi'\rVert_\infty=\frac{96}{25\sqrt5}.
\]

With \(c=b+w/2\), define a second response

\[
J_1(a)=-A\,\phi\!\left(\frac{2(a-c)}{w}\right),\qquad
A=\frac{Lw}{2C_\phi}.
\]

Then \(\lVert J_1'\rVert_\infty\le L\). The bump vanishes at every query location and at \(\hat a\), so \(J_0\) and \(J_1\) give the procedure the same transcript and the same returned design. Yet \(J_1(c)=-A\) and \(J_1(\hat a)=0\), hence its regret in the second world is

\[
J_1(\hat a)-\min J_1=A\ge \frac{L}{2C_\phi(n+2)}.
\]

Thus no procedure using \(n\) exact scalar-mean acquisitions can guarantee regret below this amount uniformly over the stated class. A randomized procedure also has worst-case expected regret at least \(L/[8C_\phi(n+1)]\): put equal-width bumps in \(2(n+1)\) disjoint cells and choose the cell uniformly. On its all-zero transcript, at most \(n\) queries plus the returned design can touch \(n+1\) cells; at least half the hidden bump locations then have the same observations and incur the full bump depth \(L/[4C_\phi(n+1)]\). The same covering argument in \(d\) design dimensions gives the usual \(\Omega_d(Ln^{-1/d})\) scale for a Lipschitz response class.

This is an information limit, not a chaos argument: it applies to smooth responses whether the underlying dynamics are stable or turbulent. It proves no impossibility for a fully specified Navier–Stokes model, nor does it say that useful ensemble means cannot be estimated. A known structural class, a physical prior, a validated closure, or enough targeted experiments can shrink the ambiguity set. The bound says a robust certificate must account for the acquisition needed to do that.

### Adjacent reliability bound

If the requested design must satisfy a failure-probability constraint \(p\le\varepsilon\), even \(n\) independent high-fidelity trials with zero observed failures only give the distribution-free one-sided bound \(p\le1-\delta^{1/n}\) at confidence \(1-\delta\). To certify \(p\le\varepsilon\) from zero failures requires

\[
n\ge\frac{\log\delta}{\log(1-\varepsilon)}\approx\frac{\log(1/\delta)}{\varepsilon}.
\]

For example, \(\varepsilon=10^{-3}\) and 95% confidence require 2,995 independent trials at the selected operating conditions. Rare-event methods and a validated physical tail model can reduce this cost, but then their coverage/model assumptions and acquisitions must be charged. This is a separate high-reliability output from mean-response optimization.

## 3. Strongest existing methods and their actual interfaces

| Method and primary result | Output it already obtains | Acquired information and cost | Boundary relevant to this task |
|---|---|---|---|
| **Online gradient flow (OGF), Hickling et al.** [arXiv:2507.05149](https://arxiv.org/abs/2507.05149) | Optimizes time-averaged statistics directly in a chaotic PDE. In forced homogeneous isotropic turbulence at \(Re=120\), \(Ma=0.25\), on a \(256^3\) grid (five fields, \(8.4\times10^7\) DoF), it recovers one forcing-variance parameter to 0.73% RMSE with minibatch 8 and reports \(J=3.37\times10^{-5}\); minibatch 64 gives 1.00% RMSE and \(J=5.88\times10^{-6}\). | Assumes an ergodic PDE and a target statistic \(F^*(x)\). It advances \(3N_pN_{mb}\) independent forward trajectory copies for \(N_p\) parameters and batch size \(N_{mb}\), uses finite differences, and trades more simulation cost for lower gradient noise. The fHIT target statistic is generated by another DNS of the same model at the known target parameter. The target-generation horizon and full machine-hours/energy are not itemized. | This defeats any broad claim that chaos prevents useful steady-state design/optimization. The example is one-parameter recovery within a supplied model family, not a global optimum over unknown closures or a robust design certificate. The paper presents numerical evidence; deterministic-PDE convergence analysis is explicitly left for future work. |
| **NILSS / NILSAS shadowing** [Ni & Wang, arXiv:1611.00880](https://arxiv.org/abs/1611.00880); [Blonigan, JCP 2017](https://doi.org/10.1016/j.jcp.2017.08.002); [Ni & Talnikar, JCP 2019](https://doi.org/10.1016/j.jcp.2019.06.035) | Computes long-time-average sensitivities without the exponentially diverging conventional tangent/adjoint. NILSS is demonstrated on a backward-facing step (about 12,000 cells); adjoint shadowing has been applied to a turbulent channel and weakly turbulent 3-D cylinder flow. | Requires the base-flow/tangent or adjoint trajectory and the unstable-subspace calculation. NILSS cost and memory scale with the number of positive Lyapunov exponents, which grows with Reynolds number in turbulent shear flows; LSS itself carries a trajectory-horizon-wide linear solve. | Excellent derivative incumbent for a supplied model and local design steps; it supplies neither global optimality nor model/closure uncertainty coverage. |
| **Reynolds-averaged mean adjoint (RA-ANS), Wang & Zaki 2026** [arXiv:2606.25399](https://arxiv.org/abs/2606.25399) | Produces the mean domain of dependence of a wall-stress measurement. An eddy-viscosity-closed mean adjoint was compared with 5,000 adjoint realizations; it aligned with their mean at about 0.7 correlation in the converged window. The authors find distinct Orr-type and streak structures and Reynolds-number scaling across \(Re_\tau=180,590,10^3,10^4\). | Uses a mean channel profile and a Cess/linear-eddy-viscosity closure. The direct reference comparison uses a long statistically stationary DNS sampled into 5,000 base-flow realizations. At longer backward times the sampled mean develops high-frequency noise and loses convergence. | Strong evidence that useful averages and reduced sensitivities survive chaotic trajectories. Its output is a specific sensor sensitivity structure under a selected closure, not a robust controller or model-free design optimum. |
| **Multilevel Monte Carlo (MLMC) for turbulent-flow UQ, Chen & Ming** [arXiv:1608.05338](https://arxiv.org/abs/1608.05338) | Estimates uncertain Antarctic Circumpolar Current volume transport more efficiently by telescoping coupled/coarse grid statistics. The authors observe cross-grid correlation for averaged volume transport even though pointwise velocity solutions are uncorrelated. | Requires a supplied uncertain-parameter law, a grid hierarchy, and enough paired simulations to estimate level-difference variances and bias. Turbulence closures may change with grid resolution. | Useful for the expectation of a specified QoI under a specified model/prior; it does not discover an unknown closure or certify values at unacquired design settings. Its variance reduction is observable-dependent, not a universal turbulence transfer. |
| **Fourier neural operator (FNO), Li et al.** [arXiv:2010.08895](https://arxiv.org/abs/2010.08895) | Learns a parametric PDE solution operator and transfers across mesh resolutions. In one 2-D Navier–Stokes inverse problem, it reports 0.005 s per surrogate evaluation versus 2.2 s for the solver; 30,000 MCMC forward evaluations take 2.5 minutes versus over 18 hours. | The cited low-viscosity Navier–Stokes training set uses 10,000 solver-generated pairs; the inverse example reports 12 hours for data generation plus training. This is a 2-D incompressible vorticity problem, not a 3-D long-time turbulence-control validation. | Inference speed is downstream of acquired simulation data and a specified PDE family. Mesh super-resolution does not establish OOD closure validity or the correct invariant measure for a different physical system. |

OGF is the closest incumbent on the central output. It already handles chaotic time-averaged optimization at \(84\) million state degrees of freedom. Its acquisition-inclusive contract starts with the PDE/model family, a target statistic, and repeated simulation trajectories; the numerical target was generated from the same simulator. The remaining useful target is therefore uncertainty-aware certification under unobserved model/closure or operating-condition variation, not another method for getting a mean gradient from a known flow solver.

## 4. Claim status and next decisive gate

- **Established by this work:** the response-class finite-query lower bound above, with explicit \(C^2\) witnesses and acquisition count. The executable example checks the construction for a fixed zero-transcript query set.
- **Supported by primary literature:** current computational incumbents can obtain useful long-time means, sensitivities, mean adjoints, multilevel UQ for selected aggregate outputs, and fast learned PDE surrogates under their stated model/data assumptions.
- **Not established:** that the full physical response family of a particular turbulent facility contains the adversarial bump pair; that OGF or RA-ANS is globally convergent or robust to arbitrary closure shift; that a proposed alternative improves physical experiments; novelty of the lower bound beyond standard information-based optimization; or any physical validation here.
- **Decisive next test:** choose one real plant/control (for example, one wall-stress or drag-reduction intervention), one QoI and uncertainty set for unresolved forcing/closure, and a fixed acquisition budget. Construct two plausible closures that agree on all supplied/acquired baseline and training observables but imply separated robust optima. If a conservative discrepancy bound or a targeted new experiment separates them, charge that experiment and compare its complete cost against OGF/MLMC/ROM. If no physically credible pair survives, keep the no-free-lunch result abstract and do not advertise it as a turbulence impossibility.

The principal resource exclusion in all existing methods is **not** necessarily runtime of the downstream algorithm: it is acquisition of the governing closure/parameter support and target/reference statistics. Any actual comparison must count target DNS or laboratory runs, spin-up, independent initial conditions, sensor calibration, finite-time bias, level coupling, training pairs, held-out validation, precision, compute hours, and energy. For the cited OGF/FNO/RA-ANS sources, the papers do not supply a complete joule- or facility-cost ledger.

## 5. Local capital and evidence notes

The capital checkout was read at pinned local revision 5ddabf53324159aa6c88e4fef3b75bc7b8b6c4ff, beginning with its AGENTS.md and 00_START_HERE.txt. The inspected PDE dossiers concern other theorem families; the N30 Gaussian memory candidate concerns finite statistical-experiment compression and is marked source-derived/unreviewed with its underlying proof packet missing. None supplies a premise for the turbulent design claim here. No other current worker report was used.

The sources below are primary manuscripts or publisher records. Web access returned the OGF and arXiv HTML/PDF, FNO and MLMC arXiv HTML, and the publisher record for the 2017 adjoint-NILSS article. No experimental turbulent dataset was downloaded and no flow solver was run. The only executable result is the exact response-oracle illustration in lower_bound_demo.py; it is an algebraic demonstration, not a numerical-fluid result.

### Primary sources

1. T. Hickling, J. F. MacArt, J. Sirignano, D. Waidmann, “OGF: An Online Gradient Flow Method for Optimizing the Statistical Steady-State Time Averages of Unsteady Turbulent Flows,” [arXiv:2507.05149v2](https://arxiv.org/abs/2507.05149).
2. A. Ni, Q. Wang, “Sensitivity analysis on chaotic dynamical systems by Non-Intrusive Least Squares Shadowing,” [arXiv:1611.00880](https://arxiv.org/abs/1611.00880).
3. P. J. Blonigan, “Adjoint sensitivity analysis of chaotic dynamical systems with non-intrusive least squares shadowing,” [Journal of Computational Physics 348 (2017)](https://doi.org/10.1016/j.jcp.2017.08.002).
4. A. Ni, C. Talnikar, “Adjoint sensitivity analysis on chaotic dynamical systems by Non-Intrusive Least Squares Adjoint Shadowing,” [Journal of Computational Physics (2019)](https://doi.org/10.1016/j.jcp.2019.06.035).
5. Q. Wang, T. A. Zaki, “Mitigating adjoint chaos in wall turbulence,” [arXiv:2606.25399](https://arxiv.org/abs/2606.25399).
6. Q. Chen, J. Ming, “The multi-level Monte Carlo method for simulations of turbulent flows,” [arXiv:1608.05338](https://arxiv.org/abs/1608.05338).
7. Z. Li et al., “Fourier Neural Operator for Parametric Partial Differential Equations,” [arXiv:2010.08895v3](https://arxiv.org/abs/2010.08895).
