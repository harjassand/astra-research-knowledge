#!/usr/bin/env python3
"""Finite-query smooth-response lower-bound witness (illustrative only).

The theorem is in REPORT.md. This script constructs a C^2 compact bump in a
largest gap between exact scalar-mean queries and the algorithm's selected
design. It checks that all acquired values and the selected value coincide
with the zero-response world, while the hidden optimum has positive regret.
It is not a Navier--Stokes simulation or an external physical validation.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import Iterable


LIPSCHITZ = 1.0
C_PHI = 96.0 / (25.0 * sqrt(5.0))


def phi(t: float) -> float:
    """C^2 unit bump: max 1 at 0, support [-1, 1]."""
    if abs(t) >= 1.0:
        return 0.0
    return (1.0 - t * t) ** 3


def phi_prime_abs(t: float) -> float:
    if abs(t) >= 1.0:
        return 0.0
    return abs(-6.0 * t * (1.0 - t * t) ** 2)


@dataclass(frozen=True)
class Witness:
    left: float
    right: float
    center: float
    width: float
    amplitude: float
    action: float
    query_values: tuple[float, ...]
    action_value: float
    optimum: float
    lipschitz_bound: float


def build_witness(queries: Iterable[float], action: float) -> Witness:
    points = sorted({0.0, 1.0, action, *queries})
    gaps = [(left, right) for left, right in zip(points, points[1:])]
    left, right = max(gaps, key=lambda pair: pair[1] - pair[0])
    width = right - left
    center = (left + right) / 2.0
    amplitude = LIPSCHITZ * width / (2.0 * C_PHI)

    def hidden_response(a: float) -> float:
        return -amplitude * phi(2.0 * (a - center) / width)

    checked_queries = tuple(hidden_response(a) for a in queries)
    action_value = hidden_response(action)
    derivative_bound = amplitude * (2.0 / width) * C_PHI

    return Witness(
        left=left,
        right=right,
        center=center,
        width=width,
        amplitude=amplitude,
        action=action,
        query_values=checked_queries,
        action_value=action_value,
        optimum=hidden_response(center),
        lipschitz_bound=derivative_bound,
    )


def main() -> None:
    queries = [0.10, 0.24, 0.36, 0.51, 0.78]
    action = 0.61
    witness = build_witness(queries, action)
    deterministic_bound = LIPSCHITZ / (2.0 * C_PHI * (len(queries) + 2))

    print(f"query_count={len(queries)}")
    print(f"selected_action={witness.action:.12f}")
    print(f"largest_unseen_gap=[{witness.left:.12f},{witness.right:.12f}]")
    print(f"gap_width={witness.width:.12f}")
    print(f"query_values={witness.query_values}")
    print(f"selected_action_value={witness.action_value:.12f}")
    print(f"hidden_optimum={witness.optimum:.12f}")
    print(f"hidden_world_regret={witness.action_value - witness.optimum:.12f}")
    print(f"analytic_lipschitz_bound={witness.lipschitz_bound:.12f}")
    print(f"guaranteed_bound_L_over_2Cphi_nplus2={deterministic_bound:.12f}")

    assert all(value == 0.0 for value in witness.query_values)
    assert witness.action_value == 0.0
    assert witness.optimum < 0.0
    assert abs(witness.lipschitz_bound - LIPSCHITZ) < 1e-12
    assert witness.action_value - witness.optimum >= deterministic_bound - 1e-12
    assert abs(max(phi_prime_abs(i / 10000) for i in range(-10000, 10001)) - C_PHI) < 1e-7


if __name__ == "__main__":
    main()
