# Divertor buffer operation: park detachment at a secondary X-point

**Status: candidate operation, not a demonstrated reactor capability. Novelty: UNKNOWN.** This independent investigation identifies a concrete exhaust-control opening and a quantitative rejection test. It does not establish a net energy gain or an operating advantage over current divertor control.

## Real limitation

A detached divertor reduces target heat by radiating and recombining plasma power in the divertor volume, but its front must stay between the target and the main X-point. If it returns to the target, the heat load can exceed component limits; if it moves toward the core, radiation and impurity penetration can degrade confinement. ITER's 2024 research plan describes a narrow operating window at high-Q conditions, a 10 MW m^-2 target design load, and target loads that can be sustained for less than one second after detachment is lost. Ne seeding is the reference actuator, with Ar and N2 as options. The same plan reports that gas takes about 0.40–0.45 s to arrive at the divertor and roughly 0.6–1.0 s to reach two-thirds of its requested flow, although re-detachment can then occur within 8 ms. This leaves a real interval in which a rapid disturbance outruns the control actuator.

A published ITER divertor power estimate sends about 100 MW into the scrape-off layer and radiates 60–70 MW in the divertor volume to hold target loads near 10 MW m^-2. That estimate is scenario-specific; the newer ITER plan also discusses later-phase edge power flows around 50–60 MW. The operation below must therefore be tested against the actual full discharge balance rather than treating one SOL number as universal.

For a Q=10 D-T reference, the source balance is approximately 500 MW fusion power = 400 MW neutron power + 100 MW alpha power, with 50 MW of auxiliary power coupled to the plasma. A useful accounting identity is `P_sep ≈ P_aux,abs + P_alpha,dep − P_rad,core − dW/dt − P_fast-particle escape`, with each term measured for the shot. The quoted 100 MW SOL case is one design estimate, not an identity implied by Q alone. XPT changes where outgoing power lands or radiates; it does not change the identity or make neutron power available to divertor control.

## Candidate operation

Use a secondary X-point in the outer divertor leg (the X-Point Target, XPT, geometry) as a passive buffer for the detachment front. Pre-position the radiating/ionization front near the secondary null, where increased connection length and poloidal flux expansion flatten the front-position response to changes in upstream density, impurity fraction, or heat flux. Continue ordinary D/T fuelling and impurity seeding, but let the XPT geometry absorb a fast disturbance while the slower gas and impurity actuators respond. This is a divertor operating point and control policy, not an energy source.

The intended result is a larger stable detachment window and more time before the front reaches either hard boundary. The action is specific: set the magnetic equilibrium and strike-point split so that the measured front occupies the secondary-null region; monitor the total target and wall heat map; use existing seeding and heating actuators to return the front to that setpoint after a disturbance. Because the front is expected to become hard to observe there, the controller cannot rely on a single carbon-emission front measurement. It needs a fused observer using spectroscopic line ratios, bolometry, divertor thermography at every strike point, neutral-pressure measurements, and magnetic reconstruction.

### Input/output and cost contract

- **Inputs:** matched upstream plasma conditions and total separatrix power; D/T fuelling; Ne (with Ar/N2 scans as controls); optional ECRH perturbation; reconstructed XPT equilibrium including the separation of the relevant separatrices, `dR_u,x2`; and time-resolved radiation and heat-flux diagnostics.
- **Output:** time-resolved position of the detachment front, peak heat flux on every divertor target and first-wall sector, total divertor radiation, core stored energy/confinement, and impurity content.
- **Resources to charge:** extra poloidal-field shaping and equilibrium-control effort; gas/impurity flow and pumping; any added ECRH electrical draw and coupled plasma power; diagnostic/control hardware; and heat moved to secondary strike points or the first wall. The geometry only redistributes/displaces power. It does not remove energy from the plant.

## Evidence and strongest incumbent

The closest experimental evidence is a June 2026 TCV preprint comparing XPT with a single-null divertor. In Ohmic cases, D2-driven front sensitivity near the secondary X-point was estimated to fall by a factor of three. In high-power L-mode cases, a 300 kW ECRH modulation at 25.7–44.6 Hz produced a clear front response in single-null operation while the tracked XPT front stayed nearly stationary. A separate N2-seeding perturbation also left the XPT front near the secondary X-point. These are direct perturbation experiments and support the buffer hypothesis.

The comparison does not yet establish an energy or target-load advantage. It used TCV L-mode and reversed toroidal field; the paper notes that the cross-field drifts may change in forward field. In its high-power seeding comparison, the reported average coupled plasma power was about 2.69 MW in XPT and 0.89 MW in single-null, almost a factor of three apart. The authors flag unequal scenarios, ECRH cut-outs, and density-control feedback as reasons a quantitative transfer-function comparison cannot be made there. The XPT paper also says its CIII proxy can miss a hot, under-dense separatrix heat channel, and that shape fluctuations can change the power split between strike points. At TCV the separatrix spacing was about 1.0 ± 0.5 mm versus a 4 mm heat-flux width; ITER near-SOL width is uncertain, with estimates ranging from about 1 mm to 5–6 mm. A low CIII-front motion is therefore not proof of low target flux.

The strongest incumbent is present partial-detachment control with D2 fuelling and Ne seeding, plus measured feedback strategies demonstrated across JET, DIII-D, EAST, AUG, and TCV. Super-X and other alternative divertor geometries are also strong comparisons because they already address heat spreading, detachment access, and front sensitivity. The XPT candidate's distinct claim is passive rejection of fast disturbances at one front location. It cannot claim lower total exhaust power unless a full balance shows lower plant-side losses; its likely value is buying response time and widening an operating window.

## Quantitative falsifier

Run a matched forward-field, high-power H-mode comparison on a device able to operate both XPT and single-null (and include a long-leg/Super-X case where available). Hold `P_sep`, upstream density, impurity concentration, core confinement target, and average actuator power within measurement uncertainty. Excite D2/Ne-seeding and ECRH perturbations from 3.75 to 50 Hz, including the TCV-tested 6–19 Hz gas and 26–45 Hz heating bands. Sweep XPT separatrix spacing through at least ± one measured `lambda_q` around the operating point.

The candidate fails as a control buffer if any of these occur:

1. Across the measured band, the XPT does not reduce the transfer gain from the disturbance to front motion by at least a factor of three at the secondary-null setpoint, or the result disappears in forward field / H-mode.
2. The front appears stationary while the peak heat flux at any target or first-wall sector rises or exceeds 10 MW m^-2, or detachment is lost for longer than the approximately 1 s target tolerance in the ITER plan.
3. The reduction in front motion requires higher average `P_aux`, impurity throughput, or pump load than the matched single-null baseline without a larger measured reduction in maximum target heat flux or an expanded stable operating window.
4. A full power balance cannot close within 5% over the perturbation cycle: `P_sep` must be reconciled with divertor and core radiation, all target and first-wall loads, stored-energy change, and measurement uncertainty. A shift from the nominal strike point to an uninstrumented branch counts as failure, not mitigation.

A qualifying result would be sustained detachment and lower *maximum* heat flux across all wetted surfaces under the same total input power and actuator budget, with the factor-three disturbance attenuation confirmed above noise. Until then, XPT is a promising geometry-dependent buffer with an unresolved sensor/actuator integration problem.

## Alpha-channeling comparison and energy balance

A separate alpha-wave operation is less mature for this exhaust objective. At ITER's nominal Q=10 point, 500 MW fusion power corresponds to roughly 100 MW in charged 3.5 MeV alphas and 400 MW in neutrons. For `n_e ≈ 10^20 m^-3` and `T_e ≈ 10 keV`, a recent JET D-T analysis gives an alpha slowing-down time near 0.37 s and a critical energy near 330 keV. An idealized scheme that removes every alpha only after it reaches 330 keV could divert at most `330/3500 × 100 MW ≈ 9.4 MW` of its birth power at that stage; most alpha energy has already heated the plasma. This is a ceiling before RF launch, transmission, unintended bulk damping, and conversion losses. If the channeling wave damps onto fuel ions, that power remains in the plasma and later contributes to exhaust. To reduce divertor power, it would have to export wave energy or deposit it in a controlled remote radiator, neither of which is established by the cited experiments.

JET D-T experiments did show RF-related changes to the alpha distribution under 3.5–5 MW ICRH, with no measured increase in alpha losses in the studied cases; modeled changes in alpha heating were less than 1% of total auxiliary power. A 2021 ITER guiding-center study found that cyclotron cooling could add losses above 3.5 MeV comparable to prompt loss, while the cooled low-energy alphas remained deep in the core; transporting those cooled particles to the edge without also losing hot alphas was its hardest challenge. Alpha channeling and energy-selective alpha removal are already substantial prior art, so a new alpha-wave slogan would not clear novelty or show an exhaust advantage.

## Claim ledger

| Claim | Status | Evidence/boundary |
|---|---|---|
| Detachment control has a real timing gap between divertor response and gas delivery. | Supported | ITER research-plan timings: 0.40–0.45 s gas arrival, 0.6–1.0 s to two-thirds flow, versus sub-second target tolerance after detachment loss. |
| An XPT can passively reduce detachment-front response near its secondary null. | Supported at TCV L-mode scale | 2026 TCV preprint reports estimated 3× gain reduction and stationary tracked CIII front under tested heating/seeding modulations; low SNR limits quantification. |
| XPT lowers the maximum heat flux at matched total power in forward-field H-mode. | Unknown | Not shown; all-branch heat flux and first-wall accounting needed. |
| XPT improves net plant energy output. | Not supported | Geometry redistributes power; TCV XPT comparison used substantially different coupled power. |
| RF alpha channeling can reduce reactor exhaust with positive net power. | Not supported | No demonstrated exported-wave interface; damping to fuel ions recycles energy into the plasma; known channeling studies retain an ash-removal/wall-loss bottleneck. |
| A novel capability has been achieved. | No | The XPT effect is an active published candidate and has not passed the stated matched test; alpha-channeling ingredients are established prior art. |

## Sources

1. ITER Organization, [ITER Research Plan within the Staged Approach (2024), ITR-24-005](https://www.iter.org/sites/default/files/media/2024-04/itr-24-005-ok1.pdf), especially pp. 24–25 (target load, impurity seeding, gas actuator delays) and p. 115 (50–60 MW edge-flow discussion).
2. M. Winkel et al., [Detachment dynamics and disturbance rejection in the TCV X-Point Target divertor](https://arxiv.org/abs/2606.23432), arXiv:2606.23432 (2026 preprint; TCV perturbation results and caveats).
3. O. Myatra et al., [The role of divertor magnetic topology in detachment control in the MAST-U Super-X geometry](https://scientific-publications.ukaea.uk/papers/the-role-of-divertor-magnetic-topology-in-detachment-control-in-the-mast-u-super-x-geometry/), UKAEA-CCFE-PR(24)237 (2024 preprint; published in Plasma Physics and Controlled Fusion).
4. [Radiative power loading in the ITER divertor](https://doi.org/10.1016/j.fusengdes.2011.07.008), Fusion Engineering and Design 86 (2011), scenario estimate of 60–70 MW divertor radiation from 100 MW entering the SOL.
5. K. Kirov et al., [Analysis of fusion alphas interaction with RF waves in D-T plasma at JET](https://scientific-publications.ukaea.uk/wp-content/uploads/UKAEA-CCFE-PR2402.PDF), UKAEA-CCFE-PR2402 (2024 preprint; DTE2 measurements and TRANSP analysis).
6. R. White et al., [Alpha particle channeling in ITER](https://doi.org/10.1063/5.0033497), Physics of Plasmas 28 (2021), 012507.
7. A. Bierwage et al., [Energy-selective confinement of fusion-born alpha particles during internal relaxations in a tokamak plasma](https://doi.org/10.1038/s41467-022-31589-6), Nature Communications 13 (2022), 3941.

I did not retrieve raw TCV shot files or independently reprocess the authors' analysis; the shot-level conclusions are reported as source claims.
