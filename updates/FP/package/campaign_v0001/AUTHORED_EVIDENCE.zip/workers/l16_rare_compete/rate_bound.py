#!/usr/bin/env python3
"""Reproduce the passive rare-transition Poisson acquisition calculations."""
from math import log, exp

lam = 1e-6  # illustrative s^-1, not an empirical rate
alpha_seen = 0.95
bayes_error_target = 0.10
factor = 2.0

t_one_event = -log(1 - alpha_seen) / lam
kl_per_lambda_exposure = 1 - log(factor)  # KL(P_lam || P_factor*lam)/(lam*S)
t_factor_two_lower = 2 * (1 - 2 * bayes_error_target) ** 2 / (lam * kl_per_lambda_exposure)

print(f"illustrative_rate_per_s={lam:.6g}")
print(f"mean_wait_days={1 / lam / 86400:.4f}")
print(f"exposure_for_95pct_at_least_one_days={t_one_event / 86400:.4f}")
print(f"factor_two_10pct_Bayes_error_necessary_exposure_days={t_factor_two_lower / 86400:.4f}")
print("parallel_copies,calendar_hours_at_factor_two_lower,total_reactor_days")
for copies in (1, 10, 100):
    print(f"{copies},{t_factor_two_lower / copies / 3600:.4f},{t_factor_two_lower / 86400:.4f}")

p = 1e-9
n_95 = log(1 - alpha_seen) / log(1 - p)
q, levels, n_level = 0.1, 9, 1000
relvar_split = (1 + (1 - q) / (n_level * q)) ** levels - 1
n_direct_equal_relvar = (1 - p) / (p * relvar_split)
print(f"direct_trials_for_95pct_success_at_p_1e-9={n_95:.4g}")
print(f"ideal_split_relative_sd={relvar_split**0.5:.4f}")
print(f"direct_trials_for_same_idealized_relative_variance={n_direct_equal_relvar:.4g}")

# Sanity checks on the stated formulas, not empirical tests.
assert abs(exp(-lam * t_one_event) - 0.05) < 1e-12
assert abs((lam * t_factor_two_lower) * kl_per_lambda_exposure - 1.28) < 1e-12
