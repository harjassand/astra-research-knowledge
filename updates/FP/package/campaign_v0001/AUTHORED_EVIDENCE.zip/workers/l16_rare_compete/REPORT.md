# Rare transitions with unknown mechanisms: competitor and barrier audit

**Scope.** Compare adaptive multilevel splitting (AMS), weighted ensemble (WE), milestoning, enhanced sampling, direct rate inference, and active experiments for a rare transition whose mechanism is not known at the start. The question is whether any of these defeats the cost of acquiring physical evidence, and what trajectory cloning buys. This is an instructed independent investigation; isolation from other current workers was not technically enforced. I did not use the Astra capital checkout.

**Finding.** No general new operation is established here. AMS and WE are strong, often dramatically more efficient computational estimators when the stochastic dynamics, restartable state, and enough path information are available. They preserve or estimate path probabilities by splitting/reweighting; neither estimates hidden microscopic structure from no signal. Milestoning and enhanced sampling can accelerate computation but require a useful coordinate, interfaces, or bias with valid kinetic correction. Passive physical replication reduces elapsed time by adding total instrument-time; it does not improve information per molecule-second. A real intervention or an observable precursor can break the barrier, so this is a conditional acquisition lower bound, not a claim that rare transitions are universally inaccessible.

## Exact contract and lower bound

Take a black-box reactant basin with a target transition whose observed event process is Poisson with unknown rate \(\lambda\). The only observation is whether/when the transition occurs. Before the event, the measured record is constant. Resetting to the reactant basin is allowed. The allowed experimental actions do not change \(\lambda\) and do not expose a precursor or microscopic state that predicts the event. These assumptions model a mechanism-blind, passive assay; they are deliberately explicit because many rare-event algorithms have stronger access.

Suppose the scientific output is to distinguish \(H_0:\lambda=\lambda_0\) from \(H_1:\lambda=2\lambda_0\). Let an adaptive policy choose which at-risk copy to observe from past data, and let \(S\) be the (possibly random) total at-risk exposure. The log likelihood ratio for the event record is \(-N\log 2+\lambda_0S\), where \(N\) is the event count. Under \(H_0\), the counting-process compensator gives \(\mathbb E_0[N]=\lambda_0\mathbb E_0[S]\), hence

\[
D(P_0\Vert P_1)
= \mathbb E_0[S]\lambda_0(1-\log 2).
\]

For equal prior probabilities, Bayes error is \((1-\mathrm{TV})/2\). Pinsker gives \(\mathrm{TV}\le\sqrt{D/2}\), so error at most 0.1 requires at least

\[
\mathbb E_0[S]\lambda_0 \ge \frac{2(1-2(0.1))^2}{1-\log 2}=4.17.
\]

Thus any such procedure with equal prior error at most 0.1 needs \(\mathbb E_0[S]\ge 4.17/\lambda_0\). This is a necessary information bound, not a sufficient experimental budget. For a fixed, precommitted exposure \(S\), event times add no information beyond \(N\sim\mathrm{Poisson}(\lambda S)\). If no event is observed over fixed exposure \(S\), the exact one-sided 95% Poisson upper limit is \(\lambda\le -\log(0.05)/S\simeq 2.996/S\); it is not evidence for zero rate.

Rate inference and mechanism identification are different outputs. For the latter, compare two hidden models under the same sensor: model U has one unobserved route from reactant to product at rate \(\lambda\); model UV has two unobserved competing routes, each at rate \(\lambda/2\). In both models the observed event process is exactly Poisson(\(\lambda\)); only the hidden route label differs. The observed-data KL divergence is zero for every exposure, so no amount of passive observation identifies which route operated. A route-resolved sensor or an intervention that selectively perturbs one route changes the information contract and can remove this nonidentifiability.

**Numerical instance.** For an illustrative (not empirically asserted) rate \(\lambda_0=10^{-6}\,\mathrm{s}^{-1}\), one expected waiting time is 11.57 days. A 95% chance of seeing at least one event needs 34.67 reactor-days. The necessary factor-of-two discrimination bound above is 48.28 reactor-days. One hundred independent copies can reduce calendar duration to about 11.6 hours at that bound, but require the same 48.28 total reactor-days and 100 setups. Thus copies help throughput and calendar time when parallel hardware is available; they do not reduce the total exposure lower bound. Script `rate_bound.py` reproduces these calculations.

A familiar direct-sampling scale is \(p=10^{-9}\): \(N\) independent trials see at least one success with probability \(1-(1-p)^N\), so 95% detection needs \(N\ge 2.996\times10^9\). Cérou–Guyader note that naive Monte Carlo becomes unreasonable below this probability scale. This cost is the right benchmark for methods that merely add independent initial-state copies.

## What the strongest methods actually buy

| Method | Information and control it needs | What it can buy | Limitation when the mechanism is unknown |
|---|---|---|---|
| **AMS** | A stochastic path generator, ability to continue/restart paths from full states with fresh randomness, target set, and a score \(\xi\) whose high values lead toward the target. Adaptive quantile levels reduce the need to preselect thresholds. | Replaces a probability \(p\ll1\) by a product of moderate conditional probabilities. Can estimate rare-event probabilities/path ensembles far more efficiently than direct simulation when the score is informative. | Adaptive levels adapt thresholds of the supplied score; they do not discover a hidden reaction coordinate. With a score independent of success, selection leaves the conditional success probability at \(p\), so splitting gives no exponential gain. Physical experiments generally cannot checkpoint a molecular configuration and replay its future with independent noise. |
| **WE** | Correct dynamics plus a restartable state/path ensemble; resampling bins or another partition; weights maintained through split/merge. | Resampling is statistically exact for broad Markov and non-Markov path processes. Bins can be adaptive and need not change the expected observable; good bins can increase target flux and parallelize work. | Exactness is not efficiency. A partition that does not separate future event propensity leaves rare-target variance high. WE cloning creates weighted computational replicas, not extra physical probability mass. A steady-state rate still needs enough flux/effective samples and correct initial/equilibrium weighting. |
| **Milestoning** | Interfaces/milestones along a pathway, local trajectory launches from the correct crossing distributions, and treatment of memory/recrossings. | Reconstructs long-time kinetics from short local trajectories and parallelizes independent inter-milestone calculations. | The interfaces and launch distributions encode pathway knowledge. Unknown bypasses, hidden slow variables, or invalid renewal/Markov assumptions can bias reconstructed kinetics or leave a route unsampled. |
| **Enhanced sampling** (e.g. metadynamics) | A physical or simulated model, selected collective variables, biasing forces, and valid reweighting; kinetic rates need additional correction. | Escapes free-energy minima and explores barriers along chosen variables; may expose candidate mechanisms efficiently in simulation. | An orthogonal hidden barrier is not removed by bias on an uninformative variable. Exploration/free-energy recovery does not by itself validate physical kinetics or establish a mechanism. |
| **Direct rate inference** | Independent exposure and event/censoring records. | Honest estimates and confidence/upper bounds with minimal modeling. | With zero or few events, information grows only with \(\lambda S\); it cannot deliver a precise rare rate from short exposure. |
| **Active experiments** | Controllable perturbations and a measurement whose response differs across mechanism/rate hypotheses. | Can reveal an intermediate, discriminate causal routes, or deliberately raise event probability; can defeat the passive lower bound because the experiment changes or informs the system. | If all allowed interventions preserve the same hazard and observation law, adaptivity has no information to exploit. A screen also pays for interventions, controls, calibration, assay sensitivity, and multiple comparisons. |

The AMS and WE advantage can be quantified in an idealized benchmark. If a useful score decomposes \(p=10^{-9}\) into nine levels with conditional survival \(q=0.1\), then a product of nine independent binomial estimates based on \(n=1000\) samples per level has relative variance

\[
\left(1+\frac{1-q}{nq}\right)^9-1\simeq0.084,
\]

or about 29% relative standard deviation. Direct Bernoulli sampling needs on the order of \(1/(p\,0.084)\simeq1.2\times10^{10}\) trials for that same relative variance. This is the genuine power of informative splitting, not a general result for unknown mechanisms: it assumes score levels with the stated conditional probabilities, and a restartable simulator that correctly samples the dynamics. AMS has its own genealogical dependence and path-length costs, so this is a binomial idealization rather than a claimed AMS benchmark.

The countercase is exact: if the only pre-event score \(\xi\) is independent of success \(Y\), then for every threshold \(c\) with nonzero support,
\[
\Pr(Y=1\mid \xi\ge c)=\Pr(Y=1)=p.
\]
Repeated adaptive selection on that score does not make the target less rare. WE with bins measurable only in the same uninformative observation has the same issue. An informative hidden coordinate would change the conclusion, but acquiring that coordinate is precisely the missing work.

## Does physical cloning help?

There are three distinct operations:

1. **Independent physical copies from the reactant ensemble.** With \(m\) identical reactors run for time \(t\), total exposure is \(S=mt\), event count is Poisson with mean \(\lambda mt\), and the no-event probability is \(e^{-\lambda mt}\). Parallel copies shorten calendar time at fixed total exposure; they do not increase information per total molecule-time. Setup, reagent, calibration, and readout costs grow with \(m\).
2. **Computational trajectory splitting.** If the full state and correct dynamics can be restarted, multiple fresh continuations from an informative partial path, with weights preserving the original path law, can greatly reduce estimator variance. This is AMS/WE’s real advantage. It is legal because it draws from a known/supplied stochastic model, and it still charges every generated continuation.
3. **Physical cloning of a rare precursor/state.** This could be powerful if the precursor can be identified, captured, stably copied, and its continuation law remains representative. Under the stated unknown-mechanism contract there is no signal for finding or cloning it. If it is found via a rare event, acquisition cost must be included; if cloning changes its chemistry or environment, calibration is required. No general physical cloning primitive copies a molecule’s complete phase-space microstate and gives independent, correctly distributed future noise.

Therefore cloning helps only when it creates additional *informative* continuations from an acquired state or parallel exposure. It cannot turn an unobserved, uninformative state into evidence. A valid proposed accelerator should report the discovery probability and cost of its seed state, continuation costs, weights/reweighting error, assay calibration, and total rather than only per-branch compute.

## Status and limits

- **Established here:** exact Poisson/Le Cam lower-bound derivation under the explicit passive black-box contract; numerical scale and source-backed competitor comparison.
- **Supported by prior primary work:** AMS consistency/variance analysis in its stated stochastic-process setting; WE statistical exactness for broad dynamics; milestone-based kinetic reconstruction; metadynamics for exploring free-energy surfaces along collective variables.
- **Not established:** a universal barrier for all experiments, a new rare-event algorithm, a physically validated rate, an empirical speedup, or novelty. Active perturbations, precursor sensing, a correct generative simulator, or a predictive score are explicit ways out of the lower-bound contract.
- **Evidence access:** publisher pages for some older journal articles were blocked or abstract-only in this pass; the cited DOI and author/arXiv/PMC records identify the primary work. No experimental data were downloaded or independently reanalyzed.

## Primary sources

- Cérou & Guyader (2007), [Adaptive Multilevel Splitting for Rare Event Analysis](https://doi.org/10.1080/07362990601139628); author manuscript: [PDF](https://perso.lpsm.paris/~aguyader/files/papers/cg2.pdf). The abstract states the adaptive-level method and its consistency/asymptotic variance results, and notes the rare-event direct-Monte-Carlo regime.
- Aristoff, Lelièvre, Mayne & Teo (2015), [Adaptive Multilevel Splitting in Molecular Dynamics Simulations](https://doi.org/10.1051/proc/201448009). Primary molecular-dynamics study. AMS can remain valid asymptotically across reaction-coordinate choices, while finite-budget variance and practical efficiency depend on the score’s quality.
- Huber & Kim (1996), [Weighted-Ensemble Brownian Dynamics Simulations for Protein Association Reactions](https://doi.org/10.1016/S0006-3495(96)79552-8). The original WE proposal and protein-association example.
- Zhang, Jasnow & Zuckerman (2009), [The “weighted ensemble” path sampling method is statistically exact for a broad class of stochastic processes and binning procedures](https://arxiv.org/abs/0810.1963). Primary derivation of path-space resampling exactness, including adaptive bins.
- Faradjian & Elber (2004), [Computing time scales from reaction coordinates by milestoning](https://doi.org/10.1063/1.1738640). Primary milestone method paper.
- Vanden-Eijnden, Venturoli, Ciccotti & Elber (2008), [On the assumptions underlying milestoning](https://pmc.ncbi.nlm.nih.gov/articles/PMC2646510/). Primary analysis of milestone assumptions, memory, and exact MFPT implications.
- Laio & Parrinello (2002), [Escaping free-energy minima](https://doi.org/10.1073/pnas.202427399); [open PMC record](https://pmc.ncbi.nlm.nih.gov/articles/PMC130499/). Primary metadynamics paper; method is based on coarse-grained dynamics in selected collective coordinates with history-dependent bias.
- Huber & Kim (1996) gives the classical computational cloning/weighting proposal; Zhang et al. (2009) provide the path-probability argument underlying why resampling changes computational representation but preserves the target path law.
