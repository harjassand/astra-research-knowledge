"""Recompute sister-survival dependence from the published Figshare workbooks.

Run with a Python installation that has openpyxl installed:
    python analyze_lineage.py

Only reads the downloaded source workbooks and prints JSON to stdout.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import openpyxl


ROOT = Path(__file__).resolve().parent
SOURCES = {
    "WT": ("raw_processed_wt.xlsx", "63679aca04cfd7c57eab35e097dd4ea1"),
    "delta_tolC": ("raw_processed_tolc.xlsx", "6a0ab67715477f03ed027d1df2759827"),
}
PLATES = ("Plate 1", "Plate 2", "Plate 3")
# In the source workbook, F:I are the (survive,survive), (survive,die),
# (die,survive), (die,die) counts for the two daughter cells.
ROWS = {"history_0": 9, "history_1": 10}


def md5(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def summarize(counts: list[int]) -> dict[str, float | int]:
    both, older_only, younger_only, neither = counts
    n = sum(counts)
    p_both = both / n
    p_older = (both + older_only) / n
    p_younger = (both + younger_only) / n
    independence = p_older * p_younger
    return {
        "n_pairs": n,
        "counts_11_10_01_00": counts,
        "p_both_survive": p_both,
        "p_older_survives": p_older,
        "p_younger_survives": p_younger,
        "independent_product": independence,
        "joint_minus_product": p_both - independence,
        "joint_over_product": p_both / independence if independence else float("inf"),
    }


def read_workbook(path: Path) -> dict[str, object]:
    workbook = openpyxl.load_workbook(path, data_only=False, read_only=True)
    result: dict[str, object] = {}
    for history, row in ROWS.items():
        plate_results = {}
        pooled_counts = [0, 0, 0, 0]
        for plate in PLATES:
            sheet = workbook[plate]
            counts = [int(sheet.cell(row, column).value) for column in range(6, 10)]
            plate_results[plate] = summarize(counts)
            pooled_counts = [a + b for a, b in zip(pooled_counts, counts)]
        all_sheet = workbook["All"]
        all_counts = [int(all_sheet.cell(row, column).value) for column in range(6, 10)]
        result[history] = {
            "plate_results": plate_results,
            "pooled_from_three_plates": summarize(pooled_counts),
            "source_All_tab": summarize(all_counts),
            "All_tab_equals_plate_sum": pooled_counts == all_counts,
            "plate_sum_minus_All_counts": [a - b for a, b in zip(pooled_counts, all_counts)],
        }
    return result


def main() -> None:
    output: dict[str, object] = {"source": "Figshare dataset 28877642, version 1"}
    for strain, (filename, expected_md5) in SOURCES.items():
        path = ROOT / filename
        actual_md5 = md5(path)
        if actual_md5 != expected_md5:
            raise ValueError(f"MD5 mismatch for {filename}: {actual_md5}")
        output[strain] = {"file": filename, "md5": actual_md5, **read_workbook(path)}
    output["direct_sampling_cost_examples"] = {
        f"p={p:g}": {
            "n_for_100_expected_events": 100 / p,
            "n_for_95pct_chance_of_at_least_one": __import__("math").ceil(
                __import__("math").log(0.05) / __import__("math").log1p(-p)
            ),
        }
        for p in (1e-3, 1e-6, 1e-9)
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
