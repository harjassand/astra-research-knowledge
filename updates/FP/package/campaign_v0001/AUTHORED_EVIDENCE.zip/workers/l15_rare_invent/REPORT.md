# L15 — physical branching for rare antibiotic survival

**Disposition: `NOT_ACHIEVED`.** I found a physically grounded candidate operation and a useful data-backed obstruction to coarse branching. I did not establish a new rare-event capability, a speedup over weighted ensemble or adaptive multilevel splitting with the same acquired state, or a novelty claim.

## Target and candidate operation

The target is the probability that an *E. coli* founder leaves a surviving lineage through $g$ divisions during one sustained, standardized cefsulodin exposure. A useful finite-horizon version is $p_g(h)$, the probability that at least one descendant remains viable at the horizon, conditional on a recorded founder history $h$. This is not the probability that a single cell survives one pulse. Survival in a family tree depends on joint sister outcomes, inherited cell state, and any environment shared across descendants. This operational endpoint is an in-vitro lineage outcome, not a patient-level treatment-failure probability.

The candidate is a **history-conditioned physical branching assay**. Use a microfluidic device to image and retain daughter lineages, record observed ancestry and cell-age history, and route sister cells into independently controlled but identically calibrated cefsulodin channels. Randomize channel assignment within each parent-history stratum, retain each family’s inclusion probability and barcode, and run any dose perturbations as separate prespecified arms. This reduces shared local exposure as an explanation for correlated sister fates; it does not by itself identify inheritance as the cause, since other persistent family factors may remain. The sister pair directly measures the joint offspring outcome rather than multiplying two marginal survival rates. In a discovery pass, test whether the proposed score/history is predictive-state sufficient: at fixed score, do standardized sister outcomes still depend on older histories? If so, enrich the recorded state before doing rare-event estimation.

For a finite set of acquired history states $h$, let $K_h(c)$ be the measured distribution of a challenge’s joint offspring configuration $c=(h_1,\ldots,h_k)$, with $k$ allowed to be 0, 1, or 2. If daughter subtrees are conditionally independent once the state includes every persistent shared influence, the finite-horizon extinction probability satisfies

\[
e_0(h)=0,\qquad e_{g+1}(h)=\sum_c K_h(c)\prod_{j=1}^{k(c)} e_g(h_j),\qquad p_g(h)=1-e_g(h).
\]

The empty product is 1. This is a small exact dynamic program **after** the joint offspring kernels and a valid state representation have been acquired. If a shared environmental variable persists after the sisters split, it belongs in the family state; dropping it breaks the product recursion and can make the state count grow with the whole tree.

If the target is a terminal event $A$ and histories are sampled in strata $H=h$, the physical assay’s unbiased stratified estimator is

\[
\widehat p=\sum_h w_h\,\overline Y_h,\qquad w_h=\Pr(H=h),\quad
\overline Y_h=n_h^{-1}\sum_{i=1}^{n_h}\mathbf 1\{A_{hi}\},
\]

provided the $w_h$ come from an independent baseline census (or are otherwise known) and the independent units for uncertainty are founder families, not individual sister cells. For adaptive selection, the design must retain the known inclusion probabilities and use a design-unbiased weighted estimator. State discovery, baseline stratum frequencies, lineage tracking, and failed/censored families are part of the acquisition cost.

## Data-backed result

I retrieved the published E. coli lineage study’s processed WT and ΔtolC workbooks from [Figshare dataset 28877642](https://doi.org/10.6084/m9.figshare.28877642.v1), whose data-availability record points to the study’s source data. The primary study exposed cells to cefsulodin, tracked lineages, and reported positive survival correlation among relatives. The workbooks contain three plate-level contingency tables for the number (D\in\{0,1,2\}) of surviving daughters, conditional on one prior generation’s robustness, (R_{N=1}). The article defines this as a conditional family-fate probability and reports that robust histories enrich subsequent robust outcomes. See the [primary study](https://www.nature.com/articles/s41467-025-59807-x).

I independently recomputed the one-step joint survival probability and the product of marginal sister-survival probabilities from the three plate sheets. For the robust-history stratum (R_{N=1}=1):

| Strain and dose in source study | Plate 1: joint vs product | Plate 2: joint vs product | Plate 3: joint vs product | Sum of plate counts: joint vs product |
|---|---:|---:|---:|---:|
| WT, 32 µg/mL | 0.4846 vs 0.4606 | 0.4837 vs 0.4505 | 0.4468 vs 0.4382 | 0.4715 vs 0.4484 |
| ΔtolC, 13 µg/mL | 0.3920 vs 0.3782 | 0.3549 vs 0.3332 | 0.5248 vs 0.4960 | 0.4812 vs 0.4534 |

The joint event is higher than the independence product in all six plate-level comparisons. On the summed plate counts, the difference is 0.0231 for WT and 0.0278 for ΔtolC, or about 5.2% and 6.1% above the respective products. This directly supports using the *joint* offspring law in a lineage calculation. It does not show rare-event acceleration: these one-round pair outcomes have probabilities around 0.4–0.5, and the workbook does not identify a validated state model for deep rare events. The paper used 32 µg/mL for WT but 13 µg/mL for ΔtolC to match mean survival, so these two strains are not a matched drug-dose comparison.

There is a small but material source-data reconciliation issue. For WT, the workbook’s `All` tab does not equal the sum of its three plate tabs: at `R_N=1`, its `[11,10,01,00]` counts differ by `[0,1,0,1]`; at `R_N=0`, by `[0,1,0,6]`. The ΔtolC `All` tab does match the plate sum. The calculation above uses the explicit sum of the plate-level counts and preserves this discrepancy in [analysis_results.json](analysis_results.json); it does not use the WT `All` tab as a pooled check. All three individual WT plate comparisons still show positive covariance, so the direction of this local diagnostic is insensitive to the discrepancy.

The [reproducible analysis script](analyze_lineage.py) checks the source-file MD5 values reported by Figshare and computes each pair table from the plate tabs. The source article reports time-lapse imaging every five minutes at 37°C and 12,512 WT plus 14,866 ΔtolC cells with known fates across its three repeats. I analyzed only the processed outcome workbooks, not raw movies or the accompanying `.mat` file. No new physical assay was run.

## Exact obstruction and where the candidate stops

Consider two mechanisms with the same observable founder history and the same responses to every intervention available before a terminal challenge. Mechanism $P_0$ has no hidden high-risk mode. Mechanism $P_1$ assigns each independent founder an unobserved mode $Z\sim\mathrm{Bernoulli}(\eta)$, with the rare failure certain iff $Z=1$. For $n$ independent founders, the only distinguishing transcript is the appearance of a failure, whose probability under $P_1$ is

\[
1-(1-\eta)^n\le n\eta.
\]

Thus the transcript total-variation distance between $P_0$ and $P_1$ is at most $n\eta$; for $n\eta\ll1$, no estimator or adaptive intervention restricted to the shared observable state can distinguish zero failure risk from risk $\eta$ reliably. Cloning a known $Z=0$ branch does not expose $Z=1$. A marker, a state-setting intervention, a mechanistic restriction, or enough independent founders is necessary. This is a simple acquisition lower bound for a hidden-mode interface, not an impossibility result for rare-event estimation generally.

For scale, direct sampling at $p=10^{-9}$ needs about $3.0\times10^9$ independent founders just for a 95% chance of one event, and $10^{11}$ for 100 expected events. Those are binomial scale calculations, not measurements from the bacterial study. An adaptive physical splitter could reduce cost only if it acquires an observable precursor/history with enough predictive power, can continue from it without resetting the relevant cell state, and can account for the baseline weight of that state. The current data demonstrate ancestry dependence but do not meet these conditions for a rare multi-generation target.

## Strongest comparator and claim status

For a supplied, validated microscopic state and dynamics, the exact Doob transform uses the committor and yields the zero-variance path proposal; adaptive multilevel splitting and weighted ensemble approximate this with corrected trajectory weights. The proposed assay does not beat these methods under matched acquired information. For an acquired finite-type branching model, the offspring-generating-function recursion above is an even stronger small-state comparator because it computes finite-horizon probabilities without path sampling. These standard methods still need a sufficient state and a trustworthy transition law; the proposed assay’s only plausible advantage is *physical acquisition* when no adequate simulator exists.

The closest application precedent is already strong: the 2025 E. coli study measured lineage-conditioned survival and built a genealogical population model with a phenotypically healthy state. Its design therefore overlaps the system-identification portion of this proposal. The experimental split-channel intervention plus an explicitly weighted rare-event estimator may be useful, but it is an incremental combination of lineage tracking, conditional sampling, and standard branching/splitting machinery until a matched benchmark establishes otherwise. Novelty is `UNKNOWN`.

| Claim | Status |
|---|---|
| The source dataset has positive sister-outcome dependence in all six plate-level `R_N=1` tables | Recomputed from the public processed workbooks; descriptive and source-sheet reconciliation is noted above |
| Coarse independence can misstate the one-step joint survival outcome | Demonstrated on the reported contingency tables; no multi-generation extrapolation made |
| A joint offspring kernel plus a sufficient finite history state admits the displayed finite-horizon recursion | Exact conditional identity under the stated branch-independence/shared-state assumption; imported standard branching-process structure, not a novelty claim |
| Independent-channel sister intervention separates shared environment from inherited state | Proposed assay; not run or externally validated |
| History-conditioned physical branching beats AMS/WE/committor/Doob at equal information and full cost | `NOT_ESTABLISHED` |
| Rare-event probability for clinically relevant deep lineage persistence | `NOT_ESTABLISHED`; available source data cover shallow descriptive lineage tables only |
| Novelty, physical feasibility, external validation, and transformation-level significance | `UNKNOWN` |

## Prior-art and acquisition audit

The closest capital routes in the local Astra snapshot at `5ddabf53324159aa6c88e4fef3b75bc7b8b6c4ff` are N490–N492 (finite-state path/certificate acquisition, a small chemical diagnostic, and the unresolved high-dimensional certificate-acquisition gate) and N539 (a distinct low-order-marginal rare-failure obstruction). They make clear that finite certificates and favorable small-model calculations do not supply a scalable acquired model. I therefore did not reuse the chemical toy as this task’s positive result.

The main external comparator references are the [weighted-ensemble review](https://pmc.ncbi.nlm.nih.gov/articles/PMC5896317/), [adaptive committor learning with rare-path sampling](https://epubs.siam.org/doi/10.1137/24M1654750), and the primary E. coli lineage paper. Sister-lineage microfluidics also predates this proposal; see the [“sisters machine” study](https://pmc.ncbi.nlm.nih.gov/articles/PMC7932692/). This review was targeted, not exhaustive, so it does not support a novelty clearance.

The physical budget is not measured here. A real campaign must charge founder preparation, genetic barcoding, microfluidic setup, channel isolation, antibiotic concentration and flow calibration, imaging time, cell tracking and lost lineages, replicate plates, and all state-discovery rounds. Moving from the source study’s agarose-pad exposure geometry to separated microfluidic channels is itself a mechanistic intervention that needs validation; transfer to other growth or treatment settings requires a new exposure calibration. The article supplies imaging conditions and processed outcomes, but not an end-to-end sampler-versus-baseline resource comparison, assay energy use, or deep rare-event uncertainty.

## Evidence files

- `analyze_lineage.py` — source checksum and plate-table recomputation.
- `analysis_results.json` — full numerical output, including every plate and the WT `All`-tab mismatch.
- `raw_processed_wt.xlsx`, `raw_processed_tolc.xlsx`, `rawsix_plate.mat` — files downloaded from the public Figshare dataset; only the two processed workbooks were analyzed.
- Source records: [dataset 28877642](https://doi.org/10.6084/m9.figshare.28877642.v1), [associated code item 28877669](https://doi.org/10.6084/m9.figshare.28877669.v1), and [study DOI](https://doi.org/10.1038/s41467-025-59807-x).
