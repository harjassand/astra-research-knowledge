# Experimental science competitor and access lane

## Finding

The strongest experimental lane I found is prediction of the remaining module-propagation time after the first lithium-ion cell vents, conditioned on state of health (SOH), cell chemistry, module geometry, state of charge, and abuse trigger. This is safety-relevant for electric vehicles and stationary storage, and it has a fresh, openly accessible experiment dataset. The candidate interpretation is that ageing can make the first vent occur earlier while changing the time left before propagation. The available experiment reports that pattern, but one module was tested at each SOH, so it is a hypothesis rather than a replicated effect.

The simplest “expansion force warns earlier than surface temperature” claim is already known. Jin et al. (2024) report a pouch-module force-based early-warning method, compare it with voltage and surface temperature, and report detection in under two minutes. Other published work reports force-rise warnings hundreds of seconds before venting or runaway. The 2026 public dataset can help test how SOH changes the time between venting and propagation. It does not establish a new warning capability or a general law.

## Target and resource contract

The scientific output worth testing is a calibrated prediction interval for the time from the first cell vent to the first module-level propagation event, measured in seconds. A separate output is the time between propagation onset and failure of the remaining cells. The 2026 dataset reports approximately 478 seconds from first vent to propagation onset for its fresh module and 1,039 seconds for its aged module, while the four-cell modules are reported to be consumed within 40 seconds after propagation begins. The estimated vent-to-propagation interval therefore differs by 561 seconds, or about 2.17-fold, in one run per condition. These numbers come from the paper, not the audit script.

Inputs required for a genuine prediction are the synchronized force or pressure, voltage, internal and surface temperature, trigger input, SOC, SOH and ageing history, cell geometry, module preload, and exact event labels. The output must be scored on held-out modules from independently repeated conditions. The method must be compared with the published adaptive force-warning baseline and with the strongest direct internal-sensing protocol below. All sensors, calibration, cell preparation, test repetition, computation, and failed channels count toward cost.

## Open experiment and reproduced audit

Kwak et al. (2026) released the raw dataset at [OSF, DOI 10.17605/OSF.IO/C2HNQ](https://doi.org/10.17605/OSF.IO/C2HNQ). I downloaded its `Dataset_TR.zip` into this worker directory. The 2.18 MB archive passed ZIP integrity checking. It contains 16 data files, 5.44 MB uncompressed: 12 XLSX files for individual-cell tests and four CSV files for the two NMC pouch-module tests. The archive SHA-256 is `e25dcfb17d508b4f201abf6855ed281e7b28da5f16e5302d2b5aca795c2d29dc`.

The reproducible read-only audit is [audit_dataset.py](audit_dataset.py), with machine-readable output in [dataset_audit.json](dataset_audit.json). It uses the bundled Python runtime with `openpyxl` and NumPy. The audit found:

- Fresh-module force has 4,966 rows with an integer counter from 1 to 4,966. The first force drop crossing a threshold fixed from the initial 1,500 differences is at counter 2,112, with a one-sample change of −232.1 N.
- Aged-module force has 3,876 rows with a counter from 1 to 3,876. The corresponding first drop is at counter 1,617, with a one-sample change of −60.1 N.
- The two module temperature files contain 22,069 and 23,589 observations. Their `ms` field cycles through 0, 200, 400, 600, and 800; row order implies 5 Hz, but the files do not contain a monotonic absolute timestamp. The force files have a sample counter rather than an explicit common clock.

If the force counter is treated as seconds, the force drops occur 25 seconds before the paper’s 2,137-second fresh-module vent marker and 48 seconds after the paper’s 1,569-second aged-module marker. These mismatches are evidence that the published files are insufficient to certify precise cross-channel warning times without the original DAQ clock mapping and event definitions. They do not prove the paper’s timing is wrong. The aged force change is 60.1 N, below the paper’s reported combined 95% force uncertainty of ±88 N. Common-mode calibration error could cancel in a time difference, but the release does not quantify this.

The data paper reports eight thermal-runaway tests, two channel failures excluded from the release, only two representative SOH levels, and no post-mortem chemical characterization. Its mechanistic interpretation therefore depends on cited chemistry rather than direct chemical analysis. The module comparisons have one fresh and one aged module, so they cannot estimate between-module variability or support a trained predictor.

The 2026 testbed records cylindrical-cell canister pressure and temperature at 10 Hz, with reported 95% uncertainties of ±0.06 MPa and ±1.6 °C. The pouch force bench reports ±88 N at 95% confidence. This pressure is measured in the external canister after gases leave the cell; it is not the cell’s internal pressure. The fixture force is transmitted through the test plates; it is not an internal-pressure measurement.

## Strongest existing hardware and protocol

The most informative direct sensor benchmark I found is Gulsoy et al. (2024), [Journal of Power Sources 617, 235147](https://doi.org/10.1016/j.jpowsour.2024.235147). It inserts an R-type thermocouple at the cell core and routes in-cell gas pressure to a transducer, while recording cell voltage, three surface thermocouples, infrared video, and high-definition video. Internal temperature is sampled at 1 kHz; pressure and voltage at 10 kHz; surface temperature at 10 Hz; video at 30 frames/s. The pressure sensor is 100 bar full scale with stated accuracy ±0.5% FS (±0.5 bar). It is calibrated at 0–50 bar. The sensor assembly adds less than 1% of cell volume, and reference-performance tests check cell capacity and resistance after instrumentation.

This in-cell protocol is a measurement reference, not a matched-information software baseline for a non-invasive warning system: the inserted hardware supplies core temperature and internal pressure that ordinary BMS sensors do not see. Any candidate that uses those signals must pay for them. The matched-information algorithmic baseline remains the published force method above.

That study ran three externally heated 21700 NCA/graphite-SiOx cells from one manufacturing batch at 95–99% SOC. It found first pressure peaks of 19.85–19.96 bar before soft venting. The second pressure peak was 4.19–4.54 bar in the two runs where the bottom vent activated, and 28.74 bar in the single run where it did not. This roughly 6.6-fold spread makes vent architecture a major physical confound for any universal pressure threshold. The article reports internal-pressure rise rates around 2.6 mbar/s and 5.4 mbar/s in early stages. At 5.4 mbar/s, the stated ±0.5 bar full-scale accuracy corresponds to about 93 seconds of pressure rise. This is only a scale comparison, not a measured detection delay; the paper does not report noise or alert-latency confidence at that level.

The 2024 article says its original raw data are available on request. A later [Data in Brief dataset](https://doi.org/10.1016/j.dib.2025.112190) makes processed MATLAB data for the three tests public at [Mendeley Data](https://data.mendeley.com/datasets/rgfhdhcd9k/1). The reference protocol is physically stronger than the 2026 OSF release for internal-state measurement, but it remains three cells under one external-heating protocol and lacks varied ageing, module propagation, and gas-composition analysis. The 2024 authors explicitly leave gas-composition quantification for future work.

For warning against ordinary BMS signals, the closest published algorithmic competitor is Jin et al. (2024), [“Expansion force signal based rapid detection of early thermal runaway for pouch batteries”](https://doi.org/10.1016/j.energy.2024.133685). It compares force against terminal voltage and surface temperature under operating conditions, uses an electromechanical coupling model with a Kalman filter and adaptive threshold, and reports warnings in under two minutes. A separate 2024 comparison reports force-rise warnings more than 80 seconds before vent and 444 seconds before runaway for its thermal-abuse tests ([Applied Energy article](https://www.sciencedirect.com/science/article/pii/S0306261924012017)). Any force-only early-warning proposal must beat these methods on held-out ageing paths and triggers.

## Physical and inferential failure gates

The apparent interpretations fail at specific interfaces:

1. **The fresh/aged propagation-time difference is one run each.** The 478-to-1,039-second shift could reflect cell variation, preload, geometry, sensor timing, or trigger history. It is not an SOH law.
2. **Pressure and force are not interchangeable.** The 21700 pressure sensor in the 2026 experiment measures pressure in the external airtight canister, whose effective volume is 0.002829 m³. Pouch-module force is a fixture load-cell reading transmitted through plates. The two measurements do not represent the same internal state.
3. **The channels are split across rigs and formats.** Temperature and pressure are paired for cylindrical cells; temperature and force are paired for pouch cells and modules. The paper says a future bench should acquire force, temperature, voltage, and current together. No single released test provides a complete set of those signals.
4. **Trigger coverage is narrow.** The 2026 dataset uses a 5.5 °C/min external heating ramp, within the cited UL 9540A ramp range. It does not test internal short, overcharge, mechanical damage, or real field duty cycles. The 2024 in-cell benchmark also uses external heating at 40 W.
5. **A sensor event is not a chemical diagnosis.** Neither pressure nor fixture force names the gases or reaction path. The 2026 dataset has no post-mortem chemical analysis; the strongest in-cell sensor paper calls gas composition future work.
6. **Existing force warning is prior art.** Earlier force-based models already compare against voltage and surface temperature. Rebranding the signal or adding a new fitted threshold does not create a new output.
7. **Timing is not reconstructible to a strict warning margin from the published module CSVs alone.** Temperature timestamps are modulo one second and force has a sequential counter. Recover DAQ logs before asserting sub-minute lead time.

## Decisive follow-up test

The promising unmeasured output is not “force detects runaway.” It is whether an intervention-ready, SOH-conditioned distribution for vent-to-propagation time transfers across independently repeated modules and across thermal, electrical, and mechanical triggers.

The next experiment should recover the original monotonic DAQ timebase for the public runs, lock the definitions of first vent and propagation onset, and replay the published adaptive force-warning baseline against the strongest available internal pressure/core-temperature/voltage signals. Then repeat the same module geometry across independently aged units, record cell voltage/current and high-speed vent imagery, and collect gas-species samples or post-mortem chemistry. Hold out whole modules and at least one trigger class. A proposal fails if its calibrated lead-time interval does not improve on the force-warning baseline after timing uncertainty, trigger energy, SOH preparation, sensor cost, and failed channels are included.

## Claim status

- Open raw experiment data were obtained and integrity-checked: **ESTABLISHED**.
- The module trace audit above was executed locally: **ESTABLISHED within the stated file and timestamp assumptions**.
- Force signals can warn earlier than surface temperature in some pouch-cell thermal-abuse protocols: **ALREADY IN PRIOR ART**.
- Ageing changes the module propagation window: **REPORTED ONCE PER CONDITION; NOT REPLICATED**.
- Pressure/force signatures identify a unique internal chemical mechanism: **NOT ESTABLISHED**.
- A new operation beats the strongest acquired-information comparator after full hardware, calibration, and acquisition cost: **NOT ESTABLISHED**.
