#!/usr/bin/env python3
"""Read-only audit of the public OSF thermal-runaway dataset.

Uses the bundled workspace Python runtime (openpyxl, numpy). The downloaded
source archive remains unchanged under data/Dataset_TR.zip.
"""

from __future__ import annotations

import csv
import hashlib
import json
import zipfile
from pathlib import Path

import numpy as np
import openpyxl


HERE = Path(__file__).resolve().parent
ARCHIVE = HERE / "data" / "Dataset_TR.zip"
ROOT = HERE / "data" / "Dataset_TR"
OUT = HERE / "dataset_audit.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def inspect_xlsx(path: Path) -> dict:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    first = rows[0] if rows else None
    last = rows[-1] if rows else None
    nonempty = sum(v is not None and v != "--" for row in rows for v in row)
    missing = sum(v is None or v == "--" for row in rows for v in row)
    return {
        "path": str(path.relative_to(HERE)),
        "sheet": ws.title,
        "row_count": ws.max_row,
        "column_count": ws.max_column,
        "first_row": list(first) if first else None,
        "last_row": list(last) if last else None,
        "nonempty_cells": nonempty,
        "missing_or_dash_cells": missing,
    }


def inspect_csv(path: Path) -> dict:
    with path.open(newline="") as f:
        rows = list(csv.reader(f))
    if path.name.endswith("_Force.csv"):
        data = np.asarray([[float(v) for v in row] for row in rows], dtype=float)
        times, values = data[:, 0], data[:, 1]
        d = np.diff(values)
        # Use the first 1,500 increments as a pre-event baseline. The 10 N
        # floor keeps sub-noise changes out of the event list; it does not
        # assert that an event at this threshold is physically resolvable.
        baseline = d[: min(1500, len(d))]
        med = float(np.median(baseline))
        mad = float(np.median(np.abs(baseline - med)))
        threshold = max(5.0 * 1.4826 * mad, 10.0)
        event_idx = np.flatnonzero(d < med - threshold) + 1
        return {
            "path": str(path.relative_to(HERE)),
            "data_rows": len(data),
            "columns": 2,
            "first_sample": [float(x) for x in data[0]],
            "last_sample": [float(x) for x in data[-1]],
            "counter_is_unit_step": bool(np.all(np.diff(times) == 1.0)),
            "time_counter_min": float(times.min()),
            "time_counter_max": float(times.max()),
            "signal_min": float(values.min()),
            "signal_max": float(values.max()),
            "baseline_derivative_median": med,
            "baseline_derivative_mad": mad,
            "drop_threshold_n": threshold,
            "first_drop_indices": [
                {"counter": float(times[i]), "delta_signal": float(d[i - 1]), "value": float(values[i])}
                for i in event_idx[:10]
            ],
        }

    header = rows[0]
    data = np.asarray([[float(v) for v in row] for row in rows[1:]], dtype=float)
    phases = data[:, 0]
    canonical = np.asarray([0.0, 200.0, 400.0, 600.0, 800.0])
    repeated_phase = len(data) >= len(canonical) and bool(
        np.allclose(phases[: (len(data) // 5) * 5].reshape(-1, 5), canonical)
    )
    inferred_seconds = (len(data) - 1) / 5.0 if repeated_phase else None
    return {
        "path": str(path.relative_to(HERE)),
        "header": header,
        "data_rows": len(data),
        "columns": len(header),
        "phase_values_first_10": [float(x) for x in phases[:10]],
        "phase_values_unique": sorted(float(x) for x in np.unique(phases)),
        "phase_repeats_0_200_400_600_800_ms": repeated_phase,
        "elapsed_seconds_if_row_order_is_5_hz": inferred_seconds,
        "temperature_min_c": float(np.nanmin(data[:, 1:])),
        "temperature_max_c": float(np.nanmax(data[:, 1:])),
        "timestamp_note": "The published first column cycles within each second; it is not a monotonic global clock.",
    }


def main() -> None:
    with zipfile.ZipFile(ARCHIVE) as zf:
        bad_member = zf.testzip()
        members = [
            {"name": x.filename, "bytes": x.file_size}
            for x in zf.infolist()
            if not x.is_dir()
        ]

    files = sorted(p for p in ROOT.rglob("*") if p.is_file())
    spreadsheet_audits = [inspect_xlsx(p) for p in files if p.suffix == ".xlsx"]
    csv_audits = [inspect_csv(p) for p in files if p.suffix == ".csv"]

    reported_vent_counter_comparisons = []
    for item in csv_audits:
        if not item["path"].endswith("_Force.csv") or not item["first_drop_indices"]:
            continue
        basename = Path(item["path"]).name
        reported = {"M1_Force.csv": 2137.0, "M2_Force.csv": 1569.0}.get(basename)
        if reported is not None:
            observed = item["first_drop_indices"][0]["counter"]
            reported_vent_counter_comparisons.append({
                "file": item["path"],
                "first_force_drop_counter": observed,
                "paper_reported_first_vent_s": reported,
                "counter_minus_reported_s_if_counter_is_seconds": observed - reported,
            })

    results = {
        "source_url": "https://doi.org/10.17605/OSF.IO/C2HNQ",
        "archive": str(ARCHIVE.relative_to(HERE)),
        "archive_bytes": ARCHIVE.stat().st_size,
        "archive_sha256": sha256(ARCHIVE),
        "zip_testzip_bad_member": bad_member,
        "zip_member_count": len(members),
        "zip_uncompressed_bytes": sum(x["bytes"] for x in members),
        "members": members,
        "xlsx_files": spreadsheet_audits,
        "csv_files": csv_audits,
        "reported_vent_counter_comparisons": reported_vent_counter_comparisons,
        "analysis_contract": {
            "force_drop_rule": "First differences below baseline median minus max(5*1.4826*MAD, 10 N), with baseline from first 1,500 increments.",
            "temperature_time_reconstruction": "Assume CSV rows are evenly sampled at 5 Hz from the observed 0,200,400,600,800 ms phase cycle. This is an inference, not an explicit complete timestamp.",
            "interpretation_limit": "Threshold crossings identify abrupt force changes only; cell venting and cross-channel lead times are not independently certified by this computation.",
        },
    }
    OUT.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "archive_sha256": results["archive_sha256"],
        "zip_member_count": results["zip_member_count"],
        "zip_uncompressed_bytes": results["zip_uncompressed_bytes"],
        "bad_member": bad_member,
        "xlsx_count": len(spreadsheet_audits),
        "csv_count": len(csv_audits),
        "force_first_drops": [
            (x["path"], x["first_drop_indices"][:1])
            for x in csv_audits
            if x["path"].endswith("_Force.csv")
        ],
        "module_temperature_clock": [
            (x["path"], x["data_rows"], x["phase_values_unique"], x["elapsed_seconds_if_row_order_is_5_hz"])
            for x in csv_audits
            if x["path"].endswith("_Temperature.csv") and "/Module/" in x["path"]
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
