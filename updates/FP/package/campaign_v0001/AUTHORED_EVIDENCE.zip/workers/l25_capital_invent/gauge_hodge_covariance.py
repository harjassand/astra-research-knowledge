#!/usr/bin/env python3
"""Finite exact-model check for the N759/N764 gauge-Hodge interface.

This checks a finite fixed-particle Lindblad resolvent, not the infinite-chain
Hodge theorem. The research report explains the proof transfer and scope.
"""
from __future__ import annotations

import itertools
import json
from copy import deepcopy
from pathlib import Path

import numpy as np


def make_sector(n: int, k: int):
    states = [bits for bits in itertools.product((0, 1), repeat=n) if sum(bits) == k]
    where = {bits: i for i, bits in enumerate(states)}
    return states, where


def hopping_matrix(states, where, n: int, bond: int):
    d = len(states)
    t = np.zeros((d, d), dtype=complex)
    for col, bits in enumerate(states):
        if bits[bond] == 1 and bits[bond + 1] == 0:
            out = list(bits)
            out[bond], out[bond + 1] = 0, 1
            t[where[tuple(out)], col] = 1.0
    return t


def local_tables(u, a):
    n = len(u) + 1
    tables = []
    for j, aj in enumerate(a):
        ul = u[j - 1] if j > 0 else 1.0 + 0.0j
        ur = u[j + 1] if j + 2 < n else 1.0 + 0.0j
        table = {}
        for zl in (-1, 1):
            for zr in (-1, 1):
                table[(zl, zr)] = aj * ul**zl * ur**(-zr)
        tables.append(table)
    return tables


def hopping_from_tables(tables, states, where, n):
    """Build the fixed-particle hopping block directly from local table data."""
    d = len(states)
    h = np.zeros((d, d), dtype=complex)
    bond_hamiltonians = []
    for j, table in enumerate(tables):
        hj = np.zeros((d, d), dtype=complex)
        for col, bits in enumerate(states):
            if bits[j] == 1 and bits[j + 1] == 0:
                zl = 1 - 2 * bits[j - 1] if j > 0 else 1
                zr = 1 - 2 * bits[j + 2] if j + 2 < n else 1
                out = list(bits)
                out[j], out[j + 1] = 0, 1
                row = where[tuple(out)]
                amp = table[(zl, zr)]
                hj[row, col] = amp
                hj[col, row] = np.conj(amp)
        h += hj
        bond_hamiltonians.append(hj)
    return h, bond_hamiltonians


def check_gauge_tables(tables, n: int, tol=1e-12):
    """Check local rank-one phase tables and shared u_l^2 proposals."""
    proposals = [[] for _ in range(n - 1)]
    amplitudes = []
    for j, table in enumerate(tables):
        order = [(1, 1), (-1, 1), (1, -1), (-1, -1)]
        vals = [table[x] for x in order]
        if max(abs(abs(x) - abs(vals[0])) for x in vals) > tol:
            return False, None
        if abs(vals[0] * vals[3] - vals[1] * vals[2]) > tol:
            return False, None
        if abs(vals[0]) <= tol:
            if any(abs(x) > tol for x in vals):
                return False, None
            amplitudes.append(0.0)
            continue
        amplitudes.append(abs(vals[0]))
        r_left = table[(1, 1)] / table[(-1, 1)]
        r_right = table[(1, -1)] / table[(1, 1)]
        if j > 0:
            proposals[j - 1].append(r_left)
        elif abs(r_left - 1) > tol:
            return False, None
        if j + 1 < n - 1:
            proposals[j + 1].append(r_right)
        elif abs(r_right - 1) > tol:
            return False, None
    for ps in proposals:
        if ps and max(abs(x - ps[0]) for x in ps) > tol:
            return False, None
        if ps and abs(abs(ps[0]) - 1) > tol:
            return False, None
    return True, amplitudes


def vec(x):
    return np.asarray(x).reshape(-1, order="F")


def liouvillian(h, z_ops, d_rate):
    d = h.shape[0]
    eye = np.eye(d, dtype=complex)
    # L(X) = i[H,X] + (d_rate/4) sum_i (Z_i X Z_i - X).
    L = 1j * (np.kron(eye, h) - np.kron(h.T, eye))
    for z in z_ops:
        L += (d_rate / 4.0) * (np.kron(z.T, z) - np.eye(d * d))
    return L


def finite_frequency_response(h, current, z_ops, d_rate, omega):
    dim = h.shape[0]
    L = liouvillian(h, z_ops, d_rate)
    B = -L + 1j * omega * np.eye(dim * dim)
    y = np.linalg.solve(B, vec(current))
    return float(np.vdot(vec(current), y).real / dim), float(np.linalg.cond(B))


def run():
    n, kpart = 5, 3
    states, where = make_sector(n, kpart)
    dim = len(states)
    bonds = [hopping_matrix(states, where, n, j) for j in range(n - 1)]
    t = 1.0
    h0 = -t * sum((b + b.conj().T for b in bonds), np.zeros((dim, dim), complex))
    # Two translation-invariant diagonal interactions on this open finite cut.
    z_diag = [np.asarray([1.0 - 2.0 * s[site] for s in states])
              for site in range(n)]
    u_nn, v_nnn = 0.73, -0.31
    for dist, coupling in ((1, u_nn), (2, v_nnn)):
        for j in range(n - dist):
            h0 += np.diag(coupling * z_diag[j] * z_diag[j + dist])

    # A nonuniform, nontrivial diagonal density gauge; W is never needed by the
    # table recognizer, but is used here to create the held-out physical model.
    theta = np.asarray([0.137, -0.221, 0.309, 0.173])
    u = np.exp(2j * theta)
    tables = local_tables(u, [-t] * (n - 1))
    accepted, amplitudes = check_gauge_tables(tables, n)
    assert accepted and np.max(np.abs(np.asarray(amplitudes) - t)) < 1e-12

    wdiag = []
    for s in states:
        z = np.asarray([1 - 2 * bit for bit in s])
        wdiag.append(np.exp(1j * np.dot(theta, z[:-1] * z[1:])))
    w = np.diag(wdiag)
    hhop, gauge_bonds = hopping_from_tables(tables, states, where, n)
    h = hhop + (h0 - sum((-t * (b + b.conj().T) for b in bonds),
                         np.zeros((dim, dim), complex)))
    h_covariance_residual = np.linalg.norm(h - w @ h0 @ w.conj().T)

    n_ops = []
    z_ops = []
    for site in range(n):
        n_ops.append(np.diag([float(s[site]) for s in states]).astype(complex))
        z_ops.append(np.diag([1.0 - 2.0 * s[site] for s in states]).astype(complex))
    j0 = np.zeros((dim, dim), dtype=complex)
    jg = np.zeros((dim, dim), dtype=complex)
    bond = 2
    b = bonds[bond]
    j0 = 1j * ((-t * (b + b.conj().T)) @ n_ops[bond + 1]
               - n_ops[bond + 1] @ (-t * (b + b.conj().T)))
    # Construct the physical bond current from the gauged Hamiltonian and the
    # same physical density, including all phase-conditioned hops.
    hg_bond = w @ (-t * (b + b.conj().T)) @ w.conj().T
    hg_bond = gauge_bonds[bond]
    jg = 1j * (hg_bond @ n_ops[bond + 1] - n_ops[bond + 1] @ hg_bond)

    d_rate, omega = 2.0, 0.7
    kap0, cond0 = finite_frequency_response(h0, j0, z_ops, d_rate, omega)
    kapg, condg = finite_frequency_response(h, jg, z_ops, d_rate, omega)

    broken_tables = deepcopy(tables)
    broken_tables[bond][(-1, -1)] *= np.exp(0.12j)
    broken_ok, _ = check_gauge_tables(broken_tables, n)
    broken_hhop, broken_bonds = hopping_from_tables(broken_tables, states, where, n)
    diagonal = h0 - sum((-t * (b + b.conj().T) for b in bonds),
                        np.zeros((dim, dim), complex))
    broken_h = broken_hhop + diagonal
    bj = 1j * (broken_bonds[bond] @ n_ops[bond + 1]
               - n_ops[bond + 1] @ broken_bonds[bond])
    broken_response, broken_condition = finite_frequency_response(
        broken_h, bj, z_ops, d_rate, omega)
    covariance_residual = np.linalg.norm(jg - w @ j0 @ w.conj().T)
    density_commutator = max(np.linalg.norm(w @ a - a @ w) for a in n_ops)
    dephasing_commutator = max(np.linalg.norm(w @ a - a @ w) for a in z_ops)
    result = {
        "scope": "finite fixed-particle finite-frequency Lindblad-resolvent covariance check only",
        "N": n,
        "particle_number": kpart,
        "sector_dimension": dim,
        "theta_radians": theta.tolist(),
        "diagonal_couplings": {"nearest": u_nn, "next_nearest": v_nnn},
        "dephasing_d": d_rate,
        "probe_angular_frequency": omega,
        "recognizer_accepts_tables": accepted,
        "global_gauge_reconstructed_by_operation": False,
        "recovered_hopping_magnitudes": amplitudes,
        "table_to_conjugated_hamiltonian_residual_frobenius": h_covariance_residual,
        "current_covariance_residual_frobenius": covariance_residual,
        "max_density_commutator_frobenius": density_commutator,
        "max_dephasing_operator_commutator_frobenius": dephasing_commutator,
        "base_finite_frequency_response_normalized_hs": kap0,
        "gauged_finite_frequency_response_normalized_hs": kapg,
        "absolute_finite_frequency_response_difference": abs(kap0 - kapg),
        "defect_control": {
            "one_entry_phase_perturbation_radians": 0.12,
            "recognizer_rejects_defect": not broken_ok,
            "defective_finite_frequency_response_normalized_hs": broken_response,
            "absolute_shift_from_base": abs(broken_response - kap0),
            "condition_number": broken_condition
        },
        "base_condition_number": cond0,
        "gauged_condition_number": condg,
        "note": "All displayed numerical values are finite diagnostics, not an infinite-chain transport result or physical validation."
    }
    out = Path(__file__).with_name("gauge_hodge_covariance_results.json")
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run()
