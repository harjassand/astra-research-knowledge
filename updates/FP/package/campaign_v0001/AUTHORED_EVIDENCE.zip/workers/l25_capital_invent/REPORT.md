# Independent Astra Capital intersection search

**Disposition:** One exact, testable cross-route interface survives. It transfers a scoped infinite-domain transport certificate to a recognizable correlated-hopping family without constructing the global gauge. This is a real expansion of the model presentation accepted by the certificate, but it does not beat the strongest same-information competitor and does not close the transport-cost gate. Treat it as a research lead, not a capability result.

This search followed the 15 October frontier brief independently. I used current dossiers, their load-bearing ranges, and their open gates; I did not read other workers' reports. The capital checkout was at `5ddabf53324159aa6c88e4fef3b75bc7b8b6c4ff`. The workspace's generated inventory reports its access projection from `ace0cfc4437fe91c20ccd24d69e0ee4bb335e871`. No capital files were changed.

## Routes read and intersections screened

I read the local model, exact gauge reconstruction and covariance ranges for N759 (`GAUGE_MATH.md`, SHA-256 `99a14abe96107776942fe493f12052a755808c3575f701482531597b9803564d`, lines 1–79 and 81–160), plus its open review gate `G-ES-N759-INDEPENDENT-REVIEW`. I read N764's retained generator and response setup (research note lines 24–76), infinite Hodge certificate and actual-output interval (lines 343–424), its primary-source boundary (lines 515–535), and open gates `G-EW-N764-INDEPENDENT-REVIEW` and `G-EW-N764-CAPABILITY`. Both dossiers label their mathematical status `source_derived_unreviewed`; exact source location and replay receipts do not establish independent correctness or physical capability.

Two apparent intersections were discarded as already present in the capital. N764–N775 is explicitly recorded as the source-word/tensor-rank obstruction in `SN-EZ-N764-SOURCE-TENSOR-TRANSFER`; N786–N788 is explicitly recorded as the loaded-equilibrium-information qualification in `SN-FC-N786-N788-SCOPED`. I did not recycle either. N759's and N764's current connection records contain no bridge between them.

## Candidate operation: phase-blind infinite Hodge response transfer

N759 recognizes nearest-neighbor hopping terms of the form

\[
H_{\rm hop}=\sum_j\left[\tau_j(Z_{j-1},Z_{j+2})T_j+\overline{\tau_j(Z_{j-1},Z_{j+2})}T_j^\dagger\right],
\]

when local four-entry tables admit

\[
\tau_j(z_L,z_R)=a_j u_{j-1}^{z_L}u_{j+1}^{-z_R},\qquad |u_\ell|=1.
\]

It then has a diagonal finite-depth gauge \(W=\exp(i\sum_\ell\theta_\ell Z_\ell Z_{\ell+1})\), with \(u_\ell=e^{2i\theta_\ell}\), such that \(H_{\rm hop}=W H_{0,\rm hop}W^\dagger\). The capital has a separate transport route, N764, for uniform nearest-neighbor hopping plus finite-range diagonal interactions and local Z-dephasing. Its current source and the full infinite-domain response use the normalized product trace.

The nontrivial interface is that the extra interaction terms rejected by N759's *quadratic dynamics* need not be discarded. If \(V(Z)\) is any translation-invariant finite-range diagonal interaction in the N764 class, then \([V,W]=0\). Also \([Z_j,W]=[n_j,W]=0\). Consequently, for

\[
H=W(H_0+V)W^\dagger,\quad
\mathcal L_H(O)=i[H,O]+\frac d4\sum_j(Z_jOZ_j-O),
\]

the product-trace Hilbert-space map \(\alpha_W(O)=WOW^\dagger\) is unitary and

\[
\mathcal L_H\alpha_W=\alpha_W\mathcal L_{H_0+V},\qquad
J_H=\alpha_W(J_{H_0+V}),\qquad
\langle J_H,(-\mathcal L_H)^{-1}J_H\rangle
=\langle J_{H_0+V},(-\mathcal L_{H_0+V})^{-1}J_{H_0+V}\rangle.
\]

Here \(J\) is the charge current obtained from the density continuity equation. The identity follows because the local densities are fixed by \(W\), so their continuity currents transform covariantly; the trace is unchanged by the inner automorphism. In the infinite translation-invariant setting, \(W\) is used as a finite-range, trace-preserving quasi-local automorphism on local observables, not as an asserted finite-norm infinite tensor product. The identity therefore transfers the entire response functional and its Hodge bounds, not just a finite-time expectation. If the recovered \(a_j\) have arbitrary phases but common magnitude \(t\), an open-line site-number phase rotation removes them; it also commutes with diagonal \(V\) and Z-dephasing. The target is an infinite line, with no ring flux.

The operation takes exact local hopping tables, exact diagonal couplings, and calibrated \(d>0\). It checks the table class and \(|a_j|=t\), then runs the existing N764 certificate on the real-hopping base model. A phase-blind membership check can avoid constructing \(W\): require equal table magnitudes; the local rank-one identity \(\tau_j(++ )\tau_j(--)=\tau_j(-+)\tau_j(+-)\); consistent overlapping proposals for each \(u_\ell^2\) from the ratios in N759's equation (C4); and the appropriate boundary condition for a finite open cut. These are sufficient because each unit-modulus proposal has a square root and the original four-entry table is then verified. The exact computation only needs the class witness and base parameters; it does not need the chosen roots or a gauge circuit. For the infinite homogeneous case, acquire/verify the translation-invariant table and diagonal interaction coefficients, rather than infer them from a finite sample.

This uses more than N759's quadratic algorithm: N759 explicitly says an added density interaction cannot be treated as an invisible phase in its finite-time free-fermion readout. Here that diagonal interaction remains in the base model and is handled by the distinct N764 response construction. The gain is an exact model-class transfer for a global transport output, not a free-fermion simulation of the added interaction.

## Derived output and finite check

For the N764 full-model pipeline's stated parameters \((t,U,V_{\rm next},d)=(1,4,1,2)\), let \(H_0\) be exactly its translation-invariant diagonal-interaction model and set

\[
H_\theta=\exp\!\left(i\theta\sum_j Z_jZ_{j+1}\right)H_0
\exp\!\left(-i\theta\sum_j Z_jZ_{j+1}\right),\qquad \theta=\pi/10.
\]

Its internal hopping table is \(\tau_j(z_L,z_R)=a\,e^{2i\theta(z_L-z_R)}\), up to the source's bond orientation convention, and it satisfies N759's factorization. The above exact transfer therefore gives the same source-reported infinite transport interval:

\[
\frac{140954601070728830357387227}{309485009821345068724781056}
\;\le D(H_\theta)\le\;
\frac{1588048260850271901671073557}{2475880078570760549798248448},
\]

or approximately \([0.4554488799056763,0.6414075845575675]\), with exact width
\(460411452284441258811975741/2475880078570760549798248448\) (about 0.18596). These fractions are from N764's `nonlocal_transport_trial.json` (its source reports a broad pipeline demonstration, not a precision improvement). Their transfer to \(H_\theta\) is the new deduction here. The interval is conditional on the N764 derivation and is not independently validated by this search.

I wrote and ran [gauge_hodge_covariance.py](gauge_hodge_covariance.py), which builds the local table Hamiltonian directly in a 5-site, 3-particle sector, adds nearest- and next-nearest-neighbor diagonal interactions, and checks its finite-frequency Lindblad resolvent against the conjugated base model. It does not reconstruct the global gauge inside the recognizer. At \(d=2\), probe frequency 0.7, and sector dimension 10, the finite-frequency response was 0.06985063481419274 for both models; the table-to-conjugated-Hamiltonian residual was \(8.36\times10^{-16}\), and the current-covariance residual was \(4.39\times10^{-16}\). Perturbing one local table entry by phase 0.12 radians caused the recognizer to reject; the same finite diagnostic moved by \(1.57\times10^{-5}\). The saved output is [gauge_hodge_covariance_results.json](gauge_hodge_covariance_results.json). This only checks a finite algebraic instance; the test is not the infinite Hodge result, an experiment, or an external proof review.

## Competitor, costs, and scientific scope

The strongest same-information competitor is direct square-root recovery of the local \(u_\ell\) values, construction of the gauge, and a run of the same N764 solver on \(H_0+V\). N759's recognizer is already linear in the number of local tables, so the phase-blind check saves at most reconstruction/output work. It does not save table acquisition, improve the N764 interval, reduce its asymptotic solve cost, or prove a new lower bound. A specialist transport solver in the base frame also receives the same \(H_0+V,d\). N764's own comparator reports the compact sparse certificate was faster and, at the tested radius-128 setting, narrower than its geometric dictionary; its full \(D\)-interval above is broad. I found no matched reason to claim superiority over tensor-network, operator-backflow, exact small-system, or other response solvers.

Costs that remain part of the contract:

- Acquire or certify every nonzero complex hopping-table entry, the diagonal interaction coefficients and range, homogeneity, the local Z-dephasing rate, and the full absence of unmatched off-diagonal terms. The finite precision/readout and physical model-acquisition costs are not supplied.
- The table scan and phase-compatibility checks take \(O(L)\) arithmetic and \(O(L)\) storage for a length-\(L\) chain; homogeneous input may be represented by constant data. No \(W\)-gate is prepared. Exact membership is required: an approximate factorization has no robust infinite-transport error bound here.
- All N764 witness discovery, tensor rank, pole/bit-length, truncation and verification costs remain. Its gate still asks for an economical near-minimum-energy response and a full-\(D\) cost bound. This bridge does not close that requirement.

The scientifically important output is an infinite-system transport certificate for a class whose physical-basis hopping is density-conditioned and looks interacting. The practical mission bar remains unmet: the input family is a known gauge-solvable one; the best baseline maps it back using the same information; the interval is wide; and there is no acquired material instance, uncertainty margin, external mathematical audit, prior-art clearance, or matched end-to-end performance result. Status: **valid conditional extension if the source proofs survive review; capability and novelty UNKNOWN**.

## Primary sources and prior art

- H. J. Schulz and B. S. Shastry, [“A new class of exactly solvable interacting fermion models in one dimension”](https://arxiv.org/abs/cond-mat/9707135), 1997. The source establishes the established unitary gauge-solvable principle; it does not establish this Hodge-response application.
- A. Osterloh, L. Amico, and U. Eckern, [“Exact solution of generalized Schulz–Shastry type models”](https://arxiv.org/abs/cond-mat/0003099), 2000. This broadens/characterizes the correlated-gauge hopping models; it does not provide the N764 infinite-domain certificate.
- R. Kubo, [“Statistical-Mechanical Theory of Irreversible Processes. I”](https://doi.org/10.1143/JPSJ.12.570), 1957. Kubo response is established; the unitary-covariance step above is shown directly rather than imported as a new theorem.
- N764 itself credits tensor trains, Hodge projection, Galerkin methods, FDAOE and operator backflow as prior methods and leaves external proof review and priority open. Its cited primary comparator papers are Bachmayr–Kazeev ([arXiv:1802.09062](https://arxiv.org/abs/1802.09062)), Kuo et al. ([arXiv:2311.17148](https://arxiv.org/html/2311.17148v2)) and von Keyserlingk–Pollmann–Rakovszky ([arXiv:2111.09904](https://arxiv.org/abs/2111.09904)).

**Next decisive step:** independently audit the source proofs, then verify the phase-blind recognizer and unitary transfer on the infinite product-trace/Hodge domain and run the exact rational N764 witness for a transferred nonzero gauge. In parallel, compare against direct gauge recovery plus the strongest same-information response methods and require exact or interval-certified local coupling acquisition. Until that work passes, preserve this as a conditional bridge only.
