# L19 — short-time paired-intervention assay

**Status: useful scoped operation, but no new capability established.** A very close paper accepted on 7 October 2026 already claims the core discriminator below. I found a possible experimental packaging improvement—terminal endpoint readout with interventions multiplexed across matched cells—but did not find evidence that it improves information per total resource. Treat the idea as preempted at the mathematical level and the packaging advantage as `UNKNOWN`.

## Candidate operation and exact output

For a system with two independently addressable candidate causes A and B and a measured target Y, randomize matched preparations into four arms: paired AB pulse, A-only, B-only, and sham. Quench or read each preparation after a short delay T. Estimate the non-additive response

`D(T) = mean(Y_AB) - mean(Y_A) - mean(Y_B) + mean(Y_0)`.

Repeat over at least three short delays and estimate the leading power p in `D(T) ~ c T^p`. In a smooth dynamical model, p=1 is evidence for an instantaneous or irreducible interaction in the measured state variables; p=2 is consistent with an interaction mediated through an unmeasured state or an eliminated dynamical variable. The output is a scoped `direct-like / mediated-like / unresolved` classification plus c, a confidence interval, and the measured delay and actuator calibrations. It is not a causal graph and does not prove the hidden state is the unique mediator.

This is an experimental operation, not a hypothesis-ranking system. A possible lower-disturbance implementation uses orthogonal optogenetic inputs, a short randomized pulse, and a terminal phospho-protein or other fixed endpoint assay. Multiplexing the four arms in mapped regions of one culture could reduce batch drift and allow one endpoint acquisition to serve all arms. A two-input actuator pair with adequate spectral isolation, matched dose, and measured quench latency is still a feasibility gate; I have not located an already validated pair for a particular scientific target.

## Why this might matter, and the incumbent

Hidden feedback and eliminated fast variables can make a measured three-body term look like a primitive direct coupling. The proposed contrast would help decide whether to pursue direct molecular/circuit mechanisms or search for hidden intermediates, while avoiding a continuous reporter during the perturbation. The specific scientific output is the origin classification and coefficient of a candidate non-additive interaction, not generic discovery acceleration.

The strongest incumbent I found is unusually close: Kumarasamy, Joseph, and Pisarchik, *Interventional identifiability of irreducible higher-order interactions in nonlinear dynamical systems*, APS Open Science, accepted 7 October 2026, [accepted-paper page](https://journals.aps.org/apsos/accepted/10.1103/lmky-xzc4). Its abstract says paired interventions restore identifiability lost on phase-locked trajectories, and a short-time response growing linearly versus quadratically separates irreducible from hidden/effective three-body terms. It reports a four-oscillator test at phase noise up to 0.03 and, for mean-field networks up to 50 units, a preparation count proportional to the number of three-body coefficients, with each preparation resolving about seven. The abstract therefore preempts the central mathematical operation. The APS page says supplemental materials will be available with the version of record; I could not audit the full proof, code, or raw results in this pass.

An established physical interface exists for signaling perturbations: optogenetic activation of isolated Ras/ERK nodes and single-cell dose/frequency response were demonstrated by Toettcher et al., [*Using Optogenetics to Interrogate the Dynamic Control of Signal Transmission by the Ras/Erk Module*](https://pmc.ncbi.nlm.nih.gov/articles/PMC3925772/) (2013). A reusable pulse dataset also exists: [Zenodo 7472959](https://zenodo.org/records/7472959) contains single-cell ERK-KTR measurements after 100 ms optoFGFR pulses; the listed archive is 695.9 MB and contains one actuated input, so it cannot evaluate the proposed two-input interaction contrast. This establishes a nearby actuator/readout platform, not a completed dual-input experiment.

## Mathematical check and decisive limitation

The independent, analytic check is in [`pulse_order_scaling_demo.py`](pulse_order_scaling_demo.py). For an ideal instantaneous response `D_1(T)=T`, the ratio `D(T)/D(T/2)=2`. For one integrated hidden state `D_2(T)=T^2/2`, it is 4. The code confirms both exactly.

The exponent is confounded by measurement dynamics. If the direct state obeys (\dot x=1), but the reporter obeys (\dot r=(x-r)/\tau), then the observed endpoint is

`r(T) = T - tau*(1 - exp(-T/tau)) = T^2/(2*tau) + O(T^3)`.

At `T=0.1*tau`, the direct pathway's observed ratio is 3.9347, close to the mediated value 4. A reporter lag can therefore reverse the proposed classification. Conversely, a hidden mediator much faster than the shortest measured delay appears direct. This requires calibrated reporter/quench response and a resolvable time window; absent those, the correct output is `unresolved`.

There is also a steep acquisition cost. Under the simple four-arm model with independent per-cell endpoint noise sigma=1, a five-sigma estimate of the contrast requires `n >= (10*sigma/D)^2` cells per arm. At unit gain, T=0.1 needs 10,000 cells/arm for the direct signal and 4,000,000/arm for the mediated signal. Halving T multiplies these requirements by 4 and 16 respectively. This is a toy Gaussian bound, but it exposes the small-time and precision cost; multiplexing arms does not remove the cell-count requirement.

## Resources, comparison, and evidence status

Supplied inputs: a specified state/cell preparation, two independently addressable interventions, a calibrated terminal assay, and a shortlist of candidate A, B, and Y. Acquired inputs include expression/transduction or actuator construction, pulse-dose and spectral-crosstalk calibration, washout/reset characterization, sham and single-pulse controls, terminal-assay precision, and at least three short-delay cohorts. Costs are cell preparations, actuator illumination, quench/sample handling, assay reagents/instrument time, replicate cells, fitting, and uncertainty checks. The endpoint format may remove repeated reporter exposure, but this has not been measured against live-cell time series under matched total cells, light dose, and precision.

The serious incumbent is the October 2026 APS intervention-and-short-time-scaling method, followed by direct time-resolved optogenetic system identification. The proposed terminal/multiplexed format has no demonstrated advantage over either at equal acquired inputs and full resources. An additional nearby theoretical route is Mahadevan's [June 2026 preprint on latent-confounded causal discovery via Lie-bracket geometry](https://arxiv.org/abs/2606.19610), which treats bracket features as a candidate screen and warns that graph extraction can remain unstable; it reinforces that a bracket or non-additivity witness is not, by itself, a mechanism attribution.

| Claim | Status |
|---|---|
| Ideal direct and one-stage mediated responses have different leading powers | `DERIVED` in explicit toy models; checked by script |
| An uncalibrated reporter lag can make direct response appear mediated | `DERIVED`; numeric ratio 3.9347 vs 4 at T=0.1*tau |
| Short-time intervention can separate irreducible/effective three-body terms in oscillator models | `SOURCE-REPORTED`, APS accepted abstract only; proof/results not independently audited |
| A dual-input terminal assay can be assembled for a chosen biological target | `PLAUSIBLE`, exact actuator pair and quench interface unverified |
| It reduces total cost or improves discovery output against the incumbent | `UNKNOWN`; no matched experiment or public two-input dataset found |
| Novelty of the core operation | `PREEMPTED / UNKNOWN` because the accepted paper states the same discriminator; no novelty claim |

## Reproducible check and limits

Run from the workspace root with `python3 research/2026-10-15-frontier-capability-v1/workers/l19_discovery_invent/pulse_order_scaling_demo.py`. It prints ideal ratios, the reporter-lag counterexample, and the Gaussian per-arm sample counts above. The script is analytic/toy evidence only; it does not replay APS results, use the Zenodo data, validate biological feasibility, or establish an advantage. The Zenodo pulse dataset has only one intervention channel. The APS full text/supplement was not available from the accepted-paper page at inspection.
