#!/usr/bin/env python3
"""Small analytic check for a paired-intervention time-scaling assay.

This is a model demonstration, not experimental data.  It contrasts an
instantaneous interaction with a one-stage hidden mediator and shows how an
uncalibrated first-order reporter can make the direct interaction look
quadratic at short times.
"""

from __future__ import annotations

import math


def direct_response(t: float, gain: float = 1.0) -> float:
    """D_AB(t) = gain*t for an instantaneous paired-input interaction."""
    return gain * t


def hidden_mediator_response(t: float, gain: float = 1.0) -> float:
    """D_AB(t) = gain*t^2/2 after integration through one hidden state."""
    return gain * t * t / 2.0


def filtered_direct_response(t: float, sensor_tau: float, gain: float = 1.0) -> float:
    """Readout of x'=gain after x is passed through r'=(x-r)/sensor_tau."""
    return gain * (t - sensor_tau * (-math.expm1(-t / sensor_tau)))


def scale_ratio(response, t: float) -> float:
    """R(t)/R(t/2), which tends to 2 for order 1 and 4 for order 2."""
    return response(t) / response(t / 2.0)


def samples_per_arm(signal: float, sigma: float = 1.0, z: float = 5.0) -> int:
    """Equal n/arm for a 5-sigma four-arm contrast with iid noise sigma.

    The contrast variance is 4*sigma^2/n, so SNR = signal*sqrt(n)/(2*sigma).
    """
    if signal <= 0:
        raise ValueError("signal must be positive")
    return math.ceil((2.0 * z * sigma / signal) ** 2)


def main() -> None:
    t = 0.1
    tau = 1.0
    print("At T=0.1, ideal response ratios R(T)/R(T/2):")
    print(f"  direct, order 1: {scale_ratio(direct_response, t):.6f}")
    print(f"  hidden, order 2: {scale_ratio(hidden_mediator_response, t):.6f}")
    print("With an uncalibrated tau=1 first-order reporter:")
    print(f"  filtered direct: {scale_ratio(lambda s: filtered_direct_response(s, tau), t):.6f}")
    print("  hidden, order 2: ", f"{scale_ratio(hidden_mediator_response, t):.6f}", sep="")

    for t in (0.1, 0.05, 0.025):
        d1 = direct_response(t)
        d2 = hidden_mediator_response(t)
        print(
            f"T={t:g}: direct signal={d1:.8g}, hidden signal={d2:.8g}, "
            f"5-sigma n/arm={samples_per_arm(d1)} vs {samples_per_arm(d2)}"
        )

    assert math.isclose(scale_ratio(direct_response, t), 2.0, rel_tol=1e-12)
    assert math.isclose(scale_ratio(hidden_mediator_response, t), 4.0, rel_tol=1e-12)
    # For T << tau, a direct pathway plus sensor lag has the same apparent
    # order-of-vanishing as a hidden one-stage mediator.
    filtered_ratio = scale_ratio(lambda s: filtered_direct_response(s, tau), 0.1)
    assert abs(filtered_ratio - 4.0) < 0.1


if __name__ == "__main__":
    main()
