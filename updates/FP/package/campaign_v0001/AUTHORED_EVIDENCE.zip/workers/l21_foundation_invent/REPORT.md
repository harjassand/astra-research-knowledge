# L21 — Switch commutator screen and the noisy-channel correction

**Status: NOT ACHIEVED.** The forward-only unitary-switch statistic is mathematically correct, but it is already an established OTOC/commutator measurement. Extending its interpretation to noisy channels as ordinary channel-order noncommutativity is false. The exact counterexample below is independently derived and is also adjacent to current prior art; no new capability is claimed.

**Independence:** I followed the assigned lane and did not consult other current workers' reports. This was instruction-level independence in a shared workspace, not technically enforced isolation.

## Candidate output and input contract

The initial candidate scientific output was the normalized squared commutator of two unknown $d$-dimensional unitaries,

\[
  \kappa(U,V)=d^{-1}\|UV-VU\|_F^2\in[0,4].
\]

Equivalently, for the standard infinite-temperature OTOC $F=d^{-1}\operatorname{Tr}(U^\dagger V^\dagger UV)$,
$\kappa=2-2\operatorname{Re}F$. Thus the proposed scalar is precisely a standard OTOC re-expression.

The input contract is black-box forward access to one use each of $U,V$ per trial, a coherent two-order switch, control initialized to \(|+\rangle\), and target initialized to \(I/d\). Measuring control in the $X$ basis gives

\[
 p_- = \frac14\operatorname{Tr}\!\left[\frac{I}{d}[U,V]^\dagger[U,V]\right]
      = \frac{\kappa(U,V)}4.
\]

One can prepare $I/d$ as a classical mixture or purify it with a $d$-dimensional reference; the latter adds \(\log_2 d\) qubits. Each Bernoulli trial uses one call to each black box. Hoeffding's inequality gives

\[
 \Pr(|4\widehat p_- - \kappa|\ge\epsilon)
 \le 2\exp(-N\epsilon^2/8),\qquad
 N\ge 8\epsilon^{-2}\ln(2/\delta).
\]

At additive error \(0.1\) and failure probability \(0.05\), this is 2,952 switch trials, or 2,952 calls to each unitary (5,904 calls total). This counts oracle uses and statistical shots, not state-preparation, switch-routing, visibility calibration, or control-error costs. Those hardware costs cannot be evaluated without a platform specification.

## Decisive noisy-channel correction

For CPTP maps with Kraus families \(\{A_i\}\), \(\{B_j\}\), the standard switch has Kraus operators

\[
 S_{ij}=|0\rangle\!\langle0|\otimes B_jA_i
       +|1\rangle\!\langle1|\otimes A_iB_j.
\]

With control \(|+\rangle\), an arbitrary target state \(\rho\), and a Hadamard followed by a \(|-\rangle\) readout, its probability is

\[
 p_- = \frac14\sum_{ij}\operatorname{Tr}\!\left(\rho\,[A_i,B_j]^\dagger[A_i,B_j]\right).
\]

This is a Kraus-pair commutator energy. It is not, in general, a measure of the superoperator commutator \(\mathcal A\circ\mathcal B-\mathcal B\circ\mathcal A\). The Kraus-pair sum is invariant under isometric changes of Kraus representation, so the issue is not representation gauge dependence: it is a difference in what the statistic measures.

**Exact counterexample.** Let both channels be the qubit completely depolarizing channel

\[
 \mathcal D(\rho)=\frac14(I\rho I+X\rho X+Y\rho Y+Z\rho Z)
                 =\frac{I}{2}\operatorname{Tr}\rho.
\]

Then \(\mathcal D\circ\mathcal D=\mathcal D\), so the channel-order commutator vanishes exactly in every norm. Use Kraus operators \(I/2,X/2,Y/2,Z/2\) for each copy and target \(\rho=I/2\). Six ordered pairs of distinct nonidentity Paulis anticommute. For each such pair, \([A_i,B_j]^\dagger[A_i,B_j]=I/4\), hence its contribution to the trace is \(1/4\). All other pairs contribute zero. Therefore

\[
 p_- = \frac14\left(6\cdot\frac14\right)=\frac38,
\]

despite exact equality of the two fixed-order composite channels. Thus the noisy-channel claim cannot be “the switch estimates whether the CPTP maps commute”; the output is instead sensitive to the channel's noncommuting Kraus processes. This is a decisive counterexample, not a finite numerical check.

## Strongest incumbent and prior-art screen

The unitary candidate is already covered in both theory and experiment:

- Azado et al., [“Measuring unitary invariants with the quantum switch”](https://arxiv.org/abs/2508.02345), give the same unitary commutator/OTOC control statistic and a protocol for arbitrary-order Bargmann invariants. Their paper explicitly connects these invariants to OTOCs and notes that a Hadamard-test simulation of a unitary switch can use the input unitaries and their inverses. Full text was accessible through arXiv HTML.
- Gao et al., [“Measuring Incompatibility and Clustering Quantum Observables with a Quantum Switch,” PRL 130, 170201 (2023)](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.130.170201), already use the switch to estimate measurement incompatibility and quantify noncommutativity of arbitrary quantum processes. The APS article and abstract were accessible.
- Gärttner et al., [Nature Physics 13, 781–786 (2017)](https://www.nature.com/articles/nphys4119), experimentally measured OTOCs and multiple-quantum spectra in a trapped-ion Ising simulator with more than 100 ions using time reversal of the dynamics. NIST also provides the publication record and accessible full text/PDF.
- Quintino et al., [“Higher-Order Process Matrix Tomography of a Passively-Stable Quantum Switch,” PRX Quantum 5, 010325 (2024)](https://doi.org/10.1103/PRXQuantum.5.010325), experimentally reconstructed a quantum-switch process matrix using almost 10,000 estimated probabilities. This is a much heavier incumbent when the desired output is the whole process rather than one scalar.
- Chen and Ma, [“Commutator Geometry and Information Preservation in the Quantum Switch,” arXiv:2609.21310 (submitted 18 September 2026)](https://arxiv.org/abs/2609.21310), is especially close current prior art. Its exact Kraus-commutator identities explicitly distinguish commuting CPTP maps from noncommuting Kraus operators and analyze how that geometry changes information preservation. It is a recent preprint; its claims are treated as prior-art adjacency, not as independently peer-reviewed validation.

The depolarizing example above is a useful exact correction to an overbroad channel-level interpretation, but its general phenomenon is not novel. In particular, coherent order of depolarizing channels and access to Kraus-level noncommutativity have been studied since the switch-assisted communication results, and the September 2026 preprint directly analyzes commutator geometry.

## Resources, evidence limits, and claim status

- **Derived:** the unitary-switch probability identity, Bernoulli sample bound, Kraus-switch probability identity, and exact depolarizing counterexample.
- **Established by cited literature:** switch-based unitary-invariant/OTOC estimation, measurement/process noncommutativity estimation, switch process tomography, and information effects tied to Kraus commutators.
- **Not done:** no physical switch was run, no hardware noise or calibration was measured, no new experiment or dataset was produced, and no literature novelty claim is made.
- **Acquisition/resource boundary:** each switch trial calls each channel once. The probability identity assumes a valid coherent switch and the stated target preparation; it does not price engineering access to the switch, characterize noise, or establish a gravitational/spacetime interpretation.
- **Overall:** candidate capability **not achieved**; first candidate is known, and the noisy-channel interpretation fails as a map-level commutativity test.

## Root handoff

File: `research/2026-10-15-frontier-capability-v1/workers/l21_foundation_invent/REPORT.md`. The proposed unitary output costs 2,952 calls to each black box for \(\pm0.1\) accuracy at 95% confidence, but Azado et al. 2025 and earlier switch/OTOC work already cover it. For noisy channels, two qubit depolarizing maps commute exactly while their switch has \(p_-=3/8\); the correct formula is the Kraus-pair commutator sum, not the superoperator commutator. Chen–Ma (arXiv:2609.21310, 2026-09-18) is close current prior art. **No new capability claimed.**
