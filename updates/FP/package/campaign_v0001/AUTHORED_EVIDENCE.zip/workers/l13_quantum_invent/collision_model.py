#!/usr/bin/env python3
"""Exact three-qubit causal-break example for the l13 quantum investigation.

R is a retained reference, S is the probed system, and E is an environment.
The protocol prepares Bell(R,S)|0>_E, swaps S and E, resets S to |0>,
optionally dephases E, swaps S and E again, then traces out E.  SymPy keeps
the resulting two-qubit states and moments exact.
"""

from sympy import I, Matrix, kronecker_product, sqrt, trace, simplify


def kron(*matrices):
    result = matrices[0]
    for matrix in matrices[1:]:
        result = kronecker_product(result, matrix)
    return result


def outer(vector):
    return vector * vector.conjugate().T


def partial_trace(matrix, dims, traced):
    """Partial trace in the declared tensor-factor order."""
    kept = [i for i in range(len(dims)) if i not in traced]
    out_dim = 1
    for i in kept:
        out_dim *= dims[i]
    out = Matrix.zeros(out_dim, out_dim)
    for row in range(matrix.rows):
        row_digits = []
        remainder = row
        for dim in reversed(dims):
            row_digits.append(remainder % dim)
            remainder //= dim
        row_digits.reverse()
        for col in range(matrix.cols):
            col_digits = []
            remainder = col
            for dim in reversed(dims):
                col_digits.append(remainder % dim)
                remainder //= dim
            col_digits.reverse()
            if any(row_digits[i] != col_digits[i] for i in traced):
                continue
            out_row = 0
            out_col = 0
            for i in kept:
                out_row = out_row * dims[i] + row_digits[i]
                out_col = out_col * dims[i] + col_digits[i]
            out[out_row, out_col] += matrix[row, col]
    return out


def partial_transpose_a(rho):
    out = Matrix.zeros(4, 4)
    for a in range(2):
        for b in range(2):
            for ap in range(2):
                for bp in range(2):
                    out[2 * a + b, 2 * ap + bp] = rho[2 * ap + b, 2 * a + bp]
    return out


def swap():
    result = Matrix.zeros(4, 4)
    for s in range(2):
        for e in range(2):
            result[2 * s + e, 2 * e + s] = 1
    return result


I2 = Matrix.eye(2)
SWAP = swap()
P0 = Matrix([[1], [0]])
PHI = Matrix([1, 0, 0, 1]) / sqrt(2)
X = Matrix([[0, 1], [1, 0]])
U = -I * SWAP  # full partial-SWAP angle theta=pi/2, global phase irrelevant


def run(dephase_environment):
    # Tensor order is R,S,E.
    psi = kron(PHI, P0)
    rho = outer(psi)

    first = kron(I2, U)
    rho = first * rho * first.conjugate().T

    # Reset S by tracing it out and preparing |0>; preserve R,E coherences.
    re = partial_trace(rho, [2, 2, 2], [1])
    if dephase_environment:
        q0 = kron(I2, Matrix([[1, 0], [0, 0]]))
        q1 = kron(I2, Matrix([[0, 0], [0, 1]]))
        re = q0 * re * q0 + q1 * re * q1
    reset = Matrix.zeros(8, 8)
    for r in range(2):
        for e in range(2):
            for rp in range(2):
                for ep in range(2):
                    reset[4 * r + e, 4 * rp + ep] = re[2 * r + e, 2 * rp + ep]

    second = kron(I2, U)
    rho = second * reset * second.conjugate().T
    rs = partial_trace(rho, [2, 2, 2], [2])
    ptrans = partial_transpose_a(rs)
    spectrum = ptrans.eigenvals()
    trace_norm = sum(abs(value) * multiplicity for value, multiplicity in spectrum.items())
    negativity = simplify((trace_norm - 1) / 2)
    c4 = simplify(trace(ptrans ** 4) - trace(rs ** 4))
    xx = simplify(trace(rs * kron(X, X)))
    return rs, negativity, c4, xx


if __name__ == "__main__":
    for name, dephase in (("coherent environment", False), ("dephased environment", True)):
        rho, negativity, c4, xx = run(dephase)
        print(name)
        print("rho_RS =", rho)
        print("negativity =", negativity)
        print("C4 = Tr[(rho^T_R)^4] - Tr[rho^4] =", c4)
        print("single-copy correlator <X_R X_S> =", xx)
