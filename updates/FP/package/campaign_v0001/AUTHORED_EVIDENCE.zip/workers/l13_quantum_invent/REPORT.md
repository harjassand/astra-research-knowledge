# L13: Multi-copy quantum operation search

**Status: `NOT_ACHIEVED` for the assigned invention gate.** I found a concrete, experimentally buildable multi-copy operation that certifies coherent environmental memory after a causal break, and derived an exact qubit collision example. It fails the decisive comparison: in the example, one adaptive single-copy correlator separates the coherent and classical environments, while the proposed witness consumes four process preparations per shot. The underlying components also have close prior art. No new operation with a proven total-resource advantage over a classical adaptive comparator is established.

I worked only from the brief, local memory, and primary literature; I did not read other current workers' reports. The brief correctly says isolation is instructed rather than technically enforced. This investigation does not use the previous local-MPS response or spectral-gap route.

## Candidate operation: causal-break replica-chirality witness

The scientific output would be a direct certificate that a device's environment retained *quantum* information across a system reset, distinguishing coherent bath memory from classical correlated noise. This is useful for locating memory that can invalidate Markovian noise models and quantum error-correction assumptions. Ordinary relaxation spectra or a fitted one-time channel do not establish that the environment preserved quantum coherence through an intervention.

The experiment is a causal-break memory test. Prepare a reference qubit $R$ maximally entangled with a probe $S$. Let the unknown device and environment interact. At an intermediate time, reset $S$ to a fixed state while retaining $R$, allow the device to evolve again, then read out $R$ and the final probe. Repeated runs must reproduce the same initial state, device preparation, timing, and reset. If the device's memory is classical, the induced $R\to S$ map after the reset is entanglement-breaking, so the final state $\rho_{RS}$ must be separable, assuming no reference leakage or external quantum side channel.

For two-qubit $\rho_{RS}$ define

\[
C_4(\rho_{RS})=\operatorname{Tr}[(\rho_{RS}^{T_R})^4]-\operatorname{Tr}[\rho_{RS}^4]
=8\operatorname{Tr}[\Omega_R\Omega_S\,\rho_{RS}^{\otimes4}],
\]

where $\Omega$ is the symmetric sum of scalar spin-chirality operators over triples of copies. The 2026 spin-chirality preprint proves the identity and the tight two-qubit separable bound $|C_4|\le 1/27$. Thus an estimate whose confidence interval lies wholly above $1/27$ or below $-1/27$ certifies that the environment conveyed quantum memory through the causal break. It is a sufficient witness, not a complete test: for example, the same source gives Werner states that are entangled for $p>1/3$, while this witness clears the separable threshold only for $p>(4/81)^{1/3}\approx0.367$.

This readout uses four independently re-prepared copies of the post-intervention process state and cyclic-permutation/controlled-SWAP measurements. The output $C_4(t,\tau)$, repeated over reset-to-readout delay $\tau$, would give a lower bound on quantum-memory lifetime. It avoids reconstructing the full process tensor when only this witness is required.

## Exact collision calculation

I implemented an exact three-qubit model in [collision_model.py](collision_model.py). Start with $|\Phi^+\rangle$ on $R,S$ and $|0\rangle$ on environment $E$. Apply a full SWAP between $S,E$, reset $S$ to $|0\rangle$, then apply a second full SWAP and trace out $E$.

- With a coherent environment, the first SWAP moves the Bell pair to $R,E$; the reset leaves that pair intact; the second SWAP returns it to $R,S$. The exact output is $|\Phi^+\rangle$, with negativity $1/2$ and $C_4=-3/4$.
- Insert complete dephasing of $E$ between the two SWAPs. The exact output becomes $(|00\rangle\langle00|+|11\rangle\langle11|)/2$, with zero negativity and $C_4=0$.

The script reproduces both matrices and invariants with SymPy. This validates only the finite algebra of the example, not a hardware demonstration or general lower bound. Crucially, the best classical adaptive comparator for this example needs only one single-copy setting: ⟨X_R X_S⟩ is 1 for the coherent environment and 0 for the dephased environment. It needs one system preparation per shot; the four-copy operation needs four, plus cross-copy entangling gates. The example proves the witness is sound, but also decisively rules out a sample or total-resource advantage on its simplest target.

## Strongest comparators and prior art

The core construction composes known results. Giarmatzi and Costa already characterize classical versus quantum memory through separability of a process Choi operator and entanglement witnesses. A 2020 IBM process-tensor experiment used causal breaks to detect non-Markovian memory in five-qubit devices and to identify memory duration. The spin-chirality preprint supplies the four-copy invariant and its separable bound. Combining them gives a plausible measurement, but is not by itself a new mathematical operation.

The direct adaptive comparator is stronger than comparing against full process tomography. For a two-qubit $\rho_{RS}$, ordinary single-copy Pauli tomography uses 15 nontrivial Pauli expectations, or a task-specific witness can use fewer settings; both require $O(\epsilon^{-2}\log(1/\delta))$ preparations at fixed confidence and accuracy. That is the same asymptotic shot order as estimating one bounded four-copy moment, while $C_4$ consumes four post-reset process runs per sample and adds multi-copy gates. Full process tomography is not the right baseline for this one-bit certification task.

There are already quantum-memory operations with provable adaptive-classical separations on different tasks. Chen et al. prove separations for learning Pauli observables and dynamics. Cotler, Gong, and Kannan's 2026 noisy-learning paper shows that generic purity-testing advantages collapse under local depolarizing noise and gives a more nuanced noise-dependent advantage for Pauli learning. Seif et al.'s 2026 process-learning work experimentally learns Pauli-channel noise with entanglement-enhanced measurements: it reports hypothesis testing through 32 system qubits on hardware emulation, process-noise learning through a 16-qubit gate layer, and measured overhead $(1.33\pm0.05)^w$ versus an entanglement-free lower bound $2^w$ for Pauli weight $w$. These are close, successful existing operations; they do not establish novelty for a new chirality memory test.

The candidate's weakest physical assumption is state reproducibility across copies. The system must be re-preparable, the intermediate reset must be performed without resetting the environment, the retained reference must remain isolated, and drift must be bounded. The 2026 chirality experiment demonstrates multi-copy controlled-SWAP measurements on IBM hardware but reports substantial calibration needs: $10^5$ shots for negativity/chirality configurations, 4,000 shots per circuit across 684 circuits for its bound-entanglement classifier, and circuit depths from 3 to 333 gates. Its reported classifier recall is for specified known $3\times3$ state families; it is not an adaptive single-copy lower bound or an experiment on a naturally occurring open-system memory. Therefore those numbers do not establish the feasibility or superiority of this process application.

## Claim ledger

| Claim | Status | Evidence or missing gate |
|---|---|---|
| A causal break isolates environment-mediated return of information | **Established under the stated intervention model** | Process-memory witness literature; requires a genuine reset and no side channel. |
| Classical memory cannot produce entanglement between retained reference and later probe | **Established** | Classical memory induces an entanglement-breaking (R\to S) map after the reset. |
| $|C_4|>1/27$ certifies quantum memory for a two-qubit output | **Source-derived conditional witness; not independently reproved** | The arXiv:2605.14515 preprint gives the exact two-qubit separable bound and four-copy identity; it is not a complete detection criterion. |
| A coherent collision can pass the witness while a dephased classical collision fails | **Derived and exactly reproduced** | `collision_model.py`; Bell output $C_4=-3/4$ versus separable output $C_4=0$. |
| The multi-copy readout beats adaptive single-copy methods on the toy scientific task | **Refuted for the chosen example** | ⟨XX⟩ separates the outputs with one setting; the proposed readout consumes four process preparations per shot. |
| It beats adaptive single-copy process characterization for a larger physical memory | **Unknown** | Need an explicit process family, a defined target gap, and a matching lower bound after preparation, reset, calibration, and noise costs. |
| The application is novel | **Unknown; strong overlap** | Existing process-memory entanglement witnesses and multi-copy moment protocols cover both ingredients. No priority claim made. |
| A physical quantum-memory lifetime was measured here | **Not done** | Only an exact finite-dimensional calculation was run; no external device or natural-system experiment was accessed. |

## Decisive next gate

Do not promote this as a breakthrough unless a higher-dimensional/many-body process family is identified for which (i) the output is a consequential memory or error-model quantity, (ii) the state/process can be re-prepared at a measured cost, (iii) multi-copy noise and reset backaction are calibrated, and (iv) a theorem proves a sample or total-resource separation against arbitrary adaptive single-copy measurements with the same preparation access. The current two-qubit witness does not meet (iv), and increasing dimension without proving that comparison would only move the missing argument.

## Primary sources and access notes

- Tulewicz, Bartkiewicz, Nori, *Spin chirality across quantum state copies detects hidden entanglement*, arXiv:2605.14515 (14 May 2026): https://arxiv.org/abs/2605.14515 . Primary preprint, not independently reviewed here. It says raw measurements/training data and circuit/calibration/classifier code accompany the manuscript, with a Zenodo deposit and GitHub release planned; no raw-data or code replay was performed for this report.
- Giarmatzi and Costa, *Witnessing quantum memory in non-Markovian processes*, Quantum 5, 440 (2021), https://doi.org/10.22331/q-2021-04-26-440 ; arXiv:1811.03722 https://arxiv.org/abs/1811.03722 . Primary theoretical source for the classical/quantum process-memory split via separability.
- White et al., *Demonstration of non-Markovian process characterisation and control on a quantum processor*, Nature Communications 12, 573 (2021), https://doi.org/10.1038/s41467-020-20113-3 . Primary IBM five-qubit process-tensor experiment; its causal-break CMI is a memory lower bound but does not alone distinguish classical from quantum memory.
- Chen, Cotler, Huang, Li, *Exponential separations between learning with and without quantum memory*, FOCS 2021 / arXiv:2111.05881, https://arxiv.org/abs/2111.05881 . Primary lower bounds that explicitly allow adaptive per-copy measurements in the no-quantum-memory model.
- Cotler, Gong, Kannan, *Noisy quantum learning theory*, Nature Communications 17, 6979 (2026), https://doi.org/10.1038/s41467-026-73693-x ; arXiv:2512.10929 https://arxiv.org/abs/2512.10929 . Primary source for noise-dependent limits on multi-copy state/process learning.
- Seif et al., *Entanglement-enhanced learning of quantum processes at scale*, Nature Communications 17, 9000 (2026), https://doi.org/10.1038/s41467-026-75553-0 ; arXiv:2408.03376 https://arxiv.org/abs/2408.03376 . Primary noisy-hardware demonstration of adaptive-classical sample advantages for Pauli process learning.
- Reascos et al., *Quantum circuits to measure scalar spin chirality*, Physical Review Research 5, 043087 (2023), https://doi.org/10.1103/PhysRevResearch.5.043087 . Primary source for direct single-copy chirality measurement on an encoded quantum processor; this further weakens any claim that a chirality-derived output inherently needs a multi-copy protocol.
