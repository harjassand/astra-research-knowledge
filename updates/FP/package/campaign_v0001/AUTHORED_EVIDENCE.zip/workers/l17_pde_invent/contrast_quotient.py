#!/usr/bin/env python3
"""Finite linear-algebra fixture for an adjoint/Hodge design-risk gate.

This is not a turbulent-flow simulation. It checks two exact interfaces that a
proposed operation would use: (1) quotient symmetric subgrid stress by the
kernel of the incompressible pressure projection composed with divergence; and
(2) bound a linearized design contrast over model-error directions that the
calibration observations cannot see.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def projected_stress_force(tau: np.ndarray) -> np.ndarray:
    """Return P div(tau) on an odd periodic square Fourier grid.

    tau has shape (3, N, N), with entries (tau_11, tau_12, tau_22).
    The zero-mean velocity-force convention is used at k=0.
    """
    if tau.ndim != 3 or tau.shape[0] != 3 or tau.shape[1] != tau.shape[2]:
        raise ValueError("tau must have shape (3, N, N)")
    n = tau.shape[1]
    if n % 2 != 1:
        raise ValueError("use odd N to avoid Nyquist derivative conventions")
    freq = np.fft.fftfreq(n) * n
    kx, ky = np.meshgrid(freq, freq, indexing="ij")
    k2 = kx * kx + ky * ky
    t11, t12, t22 = (np.fft.fft2(tau[j]) for j in range(3))
    a1 = 1j * (kx * t11 + ky * t12)
    a2 = 1j * (kx * t12 + ky * t22)
    dot = kx * a1 + ky * a2
    safe = np.where(k2 == 0, 1.0, k2)
    p1 = a1 - kx * dot / safe
    p2 = a2 - ky * dot / safe
    p1[k2 == 0] = 0.0
    p2[k2 == 0] = 0.0
    return np.stack((np.fft.ifft2(p1).real, np.fft.ifft2(p2).real))


def stress_symbol_rank(n: int) -> tuple[int, int, int]:
    """Numerically count the mode-wise rank of P(k) div for odd N."""
    freq = np.fft.fftfreq(n) * n
    ranks = []
    for kx in freq:
        for ky in freq:
            k2 = kx * kx + ky * ky
            if k2 == 0:
                ranks.append(0)
                continue
            p = np.eye(2) - np.outer([kx, ky], [kx, ky]) / k2
            div_symbol = 1j * np.array(
                [[kx, ky, 0.0], [0.0, kx, ky]], dtype=complex
            )
            singular = np.linalg.svd(p @ div_symbol, compute_uv=False)
            ranks.append(int(np.count_nonzero(singular > 1e-10)))
    total = sum(ranks)
    return total, 3 * n * n - total, n * n - 1


def hidden_contrast_radius(a: np.ndarray, c: np.ndarray, rho: float) -> float:
    """sup |c^T e| over ||e||_2 <= rho and A e = 0."""
    _, s, vh = np.linalg.svd(a, full_matrices=True)
    tol = max(a.shape) * np.finfo(float).eps * (s[0] if len(s) else 1.0)
    rank = int(np.count_nonzero(s > tol))
    null_basis = vh[rank:].T
    c_hidden = null_basis @ (null_basis.T @ c)
    return float(rho * np.linalg.norm(c_hidden))


def run() -> dict[str, object]:
    rng = np.random.default_rng(20261015)
    n = 9
    total_rank, stress_nullity, expected_force_dim = stress_symbol_rank(n)

    # Gauge checks: isotropic stress is pressure-equivalent, and the Airy
    # stress has identically zero divergence on a periodic domain.
    base = rng.normal(size=(3, n, n))
    pressure = rng.normal(size=(n, n))
    potential = rng.normal(size=(n, n))
    freq = np.fft.fftfreq(n) * n
    kx, ky = np.meshgrid(freq, freq, indexing="ij")
    phi_hat = np.fft.fft2(potential)
    airy = np.stack(
        (
            np.fft.ifft2(-(ky * ky) * phi_hat).real,
            np.fft.ifft2((kx * ky) * phi_hat).real,
            np.fft.ifft2(-(kx * kx) * phi_hat).real,
        )
    )
    isotropic = np.stack((pressure, np.zeros_like(pressure), pressure))
    base_force = projected_stress_force(base)
    pressure_force = projected_stress_force(base + isotropic)
    airy_force = projected_stress_force(base + airy)
    pressure_invariance = float(
        np.linalg.norm(pressure_force - base_force)
        / max(np.linalg.norm(base_force), 1e-30)
    )
    airy_invariance = float(
        np.linalg.norm(airy_force - base_force)
        / max(np.linalg.norm(base_force), 1e-30)
    )

    # Linearized inverse problem on the force quotient. A is the calibration
    # sensitivity; c is the shadowing/adjoint sensitivity of a design contrast.
    m = expected_force_dim
    nobs = 18
    a = rng.normal(size=(nobs, m)) / np.sqrt(m)
    c = rng.normal(size=m)
    rho = 0.1
    unconditioned = float(rho * np.linalg.norm(c))
    hidden = hidden_contrast_radius(a, c, rho)

    # A hypothetical exact scalar measurement aligned with the component of c
    # not covered by existing calibration removes the first-order ambiguity.
    _, s, vh = np.linalg.svd(a, full_matrices=True)
    tol = max(a.shape) * np.finfo(float).eps * s[0]
    rank = int(np.count_nonzero(s > tol))
    null_basis = vh[rank:].T
    c_hidden = null_basis @ (null_basis.T @ c)
    if np.linalg.norm(c_hidden) <= 1e-12:
        raise RuntimeError("fixture unexpectedly has no hidden contrast")
    target_sensor = c_hidden / np.linalg.norm(c_hidden)
    a_aug = np.vstack((a, target_sensor))
    targeted_hidden = hidden_contrast_radius(a_aug, c, rho)
    random_sensor = rng.normal(size=m)
    random_sensor /= np.linalg.norm(random_sensor)
    random_hidden = hidden_contrast_radius(np.vstack((a, random_sensor)), c, rho)

    return {
        "fixture": "periodic incompressible force quotient plus linearized design-contrast inverse problem",
        "not_a_turbulent_simulation": True,
        "N": n,
        "symmetric_stress_real_dofs": 3 * n * n,
        "rank_Pdiv": total_rank,
        "expected_force_quotient_dofs": expected_force_dim,
        "stress_nullity": stress_nullity,
        "rank_matches_N2_minus_1": total_rank == expected_force_dim,
        "stress_coordinate_reduction_fraction": 1.0 - expected_force_dim / (3 * n * n),
        "pressure_gauge_relative_force_change": pressure_invariance,
        "Airy_gauge_relative_force_change": airy_invariance,
        "inverse_fixture": {
            "force_quotient_dimension": m,
            "calibration_rows": nobs,
            "calibration_rank": rank,
            "admissible_model_error_radius": rho,
            "unconditioned_contrast_radius": unconditioned,
            "post_calibration_hidden_contrast_radius": hidden,
            "direct_projected_force_baseline_hidden_contrast_radius": hidden,
            "gate_matches_direct_projected_force_baseline": True,
            "after_one_targeted_exact_sensor": targeted_hidden,
            "after_one_random_exact_sensor": random_hidden,
            "nominal_margin_for_status_demo": 0.5 * hidden,
            "nominal_margin_is_unresolved_before_sensor": 0.5 * hidden < hidden,
            "nominal_margin_is_resolved_after_targeted_sensor": 0.5 * hidden > targeted_hidden,
        },
        "scope": "double-precision finite-dimensional algebra only; no PDE trajectory, LSS solve, training, physical sensor, or calibration cost was run",
    }


if __name__ == "__main__":
    result = run()
    print(json.dumps(result, indent=2, sort_keys=True))
    out = Path(__file__).with_name("contrast_quotient_results.json")
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
