# l17 — Predictive turbulent / multiscale physical design

**Status: candidate mechanism specified; no capability advantage demonstrated. Novelty is UNKNOWN.** The executed check is finite-dimensional algebra, not a turbulent-flow experiment. It falsifies the idea that conservation constraints by themselves make a learned stress closure identifiable or improve long-horizon design prediction.

## Proposed operation: contrast-targeted conservative model-error gate

The requested scientific output should be a design comparison for a long-time statistic, not an asserted pointwise trajectory far beyond the predictability horizon. For two design choices (d_1,d_0), let

\[
\Delta(d_1,d_0)=\lim_{T\to\infty}\frac1T\int_0^T
  [g(u(t;d_1))-g(u(t;d_0))]dt,
\]

where the modeled dynamics include an unresolved momentum flux \(\tau\):
\[
\partial_t u+\mathbb P\nabla\!\cdot( u\otimes u-\nu\nabla u+\tau)=\mathbb P f_d,
\qquad \nabla\!\cdot u=0.
\]

Here \(\mathbb P\) is the Leray projector. The operation returns either a robust interval for \(\Delta\), a strict design ordering, or `UNKNOWN` plus a proposed feasible calibration measurement.

1. Parameterize only the **effective closure acceleration** \(a=\mathbb P\nabla\!\cdot\tau\). This quotients stress fields that change pressure or have zero divergence and therefore cannot change velocity.
2. Use held-out calibration data to define a stated uncertainty set for model-error coefficients \(e\), after measurement noise, finite sampling, and discretization errors are separated.
3. For each design contrast, compute the long-time response covector \(c=\nabla_e\Delta\) with a shadowing/long-time adjoint method. Let \(A e\) be the linearized effect of closure error on acquired calibration observations.
4. In the local ellipsoid fixture \(\|e\|_2\le\rho\), with exact calibration equations \(Ae=0\), the unobserved first-order contrast error is exactly
   \[
   \sup_{\|e\|_2\le\rho,\ Ae=0}|c^Te|
      =\rho\|\Pi_{\ker A}c\|_2.
   \]
   Add a separately justified bound for the nonlinear remainder, finite-time sampling error of the statistic, and spatial/time discretization. A ranking is certified only if the nominal margin exceeds the full error radius. Otherwise, select a physically feasible experiment whose observation row most reduces the remaining adjoint-sensitive uncertainty per acquisition cost.

This is a candidate contract, not a deployed method. In a real implementation, sensor rows are determined by the measurement system; the ideal adjoint-aligned row in the toy check is not presumed physically available. The long-time derivative is not obtained by ordinary trajectory backpropagation.

## Exact conservation quotient and executable check

For a periodic two-dimensional incompressible grid with odd side length \(N\), a symmetric stress has \(3N^2\) real coordinates. At each nonzero Fourier wavevector \(k\),
\[
\widehat{\mathbb P\nabla\!\cdot\tau}(k)
=\Big(I-\frac{kk^T}{|k|^2}\Big)i
\begin{pmatrix}k_x&k_y&0\\0&k_x&k_y\end{pmatrix}
\begin{pmatrix}\hat\tau_{11}\\\hat\tau_{12}\\\hat\tau_{22}\end{pmatrix}.
\]
The symbol has rank one for every nonzero \(k\), and the zero mode is set to zero under the zero-mean-force convention. Thus the effective force space has real dimension \(N^2-1\), and the stress-to-force map has nullity \(2N^2+1\). This is an exact linear-algebra fact for this periodic discretization. It does not identify the effective closure force from sparse physical measurements or constrain its model error.

The script [contrast_quotient.py](contrast_quotient.py) checks the Fourier-symbol rank at \(N=9\), applies two explicit stress gauges (isotropic pressure and an Airy stress), and runs a seeded linear inverse-problem fixture. The saved output is [contrast_quotient_results.json](contrast_quotient_results.json).

Measured result: 243 stress coordinates collapse to 80 effective force coordinates (67.08% removed); the mode rank is exactly 80. Adding either gauge changed the projected force by relative \(2.52\times10^{-16}\) and \(1.57\times10^{-15}\). In an 80-dimensional linearized model-error space with 18 calibration rows and radius \(\rho=0.1\), the contrast uncertainty radius fell from 0.9337 unconditioned to 0.7091 after calibration. The seeded nominal margin was 0.3545, so the gate returned unresolved. An idealized exact scalar sensor aligned with \(\Pi_{\ker A}c\) reduced the first-order radius to \(3.46\times10^{-16}\); one random exact sensor left 0.7079. This confirms the algebraic active-measurement rule in this fixture, not its value or feasibility for turbulent design.

## Strongest competitor and falsification

The stress quotient is not a surviving advantage against a strong incumbent. A method that parameterizes \(\mathbb P\nabla\cdot\tau\) directly already works in the 80-dimensional identifiable force space and gets the same reduction. Bayesian RANS model-form uncertainty has already represented Reynolds-stress perturbations subject to physical constraints and assimilated sparse observations to propagate uncertainty to QoIs ([Xiao et al., JCP 2016](https://arxiv.org/abs/1508.06315)). Long-time statistics already have dedicated shadowing sensitivity methods, including LSS and NILSS ([Blonigan et al. 2014](https://arxiv.org/abs/1401.4163), [Ni & Wang 2016](https://arxiv.org/abs/1611.00880)). Conservative nonlinear reduced models already enforce invariants ([Anderson & Farazmand 2021](https://arxiv.org/abs/2104.13515)). Recent 3D turbulence neural-operator work explicitly evaluates uncertainty, error propagation, and initial-perturbation sensitivity and reports improved long-horizon stability for its F-IFNO model ([Zou et al. 2025](https://arxiv.org/abs/2506.04898)). These are strong separate components; I found no primary-source evidence that joining them under this interval gate beats a direct projected-force Bayesian/LSS/multilevel implementation.

Accordingly, the decisive finding is negative: **the quotient is exact bookkeeping, and the target-specific interval is a useful decision interface, but neither was shown to obtain a design output beyond the strongest equal-information competitor.** In the executable inverse fixture, the direct projected-force baseline and the proposed gate return the identical hidden-contrast radius, 0.7090845, because both see the same observation operator and coefficient space. Conservation-preserving reparameterization does not supply a calibrated model-error set, a long-time response bound, or a feasible sensor that resolves it. No theorem here removes those obstacles.

The strongest plausible implementation baseline is: high-fidelity calibration ensemble; direct projected-force or invariant stress posterior; LSS/NILSS gradients for long-time QoIs; and multilevel sampling for statistical uncertainty. The proposed gate should be compared to that whole pipeline on the same calibration observations, design family, solver calls, and physical/sensor access. A weak POD or one-step FNO comparator would be insufficient.

## Input, output, and full cost contract

**Required supplied inputs:** a specified flow and design family; discretization and boundary conditions; exact invariants; the statistic and averaging regime; the high- and low-fidelity solvers; observation locations/times/noise; the admissible closure-error set and its metric; and a feasible set of next measurements.

**Acquired inputs:** high-resolution trajectories or physical measurements for calibration and holdout; statistical mixing/independent-block evidence; the effective closure-error posterior or bound; and derivative/adjoint solves. None may be treated as free merely because it enters a surrogate.

**Required reported costs:**

- calibration/holdout: all high-fidelity trajectory lengths, solver steps and degrees of freedom, observation/sensor hardware, calibration, bandwidth, and measurement noise;
- closure and reduced basis: stress or effective-force parameter count, preprocessing, training, tuning, and held-out acquisitions;
- long-time response: each LSS/NILSS/adjoint solve, horizon, unstable-subspace size or linear-solver work, and estimator bias/variance;
- uncertainty: independent trajectory blocks, integrated autocorrelation time, multilevel sample counts and per-level solve costs;
- design: all candidate evaluations, optimizer steps, and final high-fidelity confirmation.

The fixture ran no training, solver trajectory, physical acquisition, adjoint/LSS solve, multilevel estimator, or sensor-calibration procedure. Its costs are only one small set of NumPy FFTs/SVDs; therefore it supports no wall-clock, memory, energy, or physical-efficiency claim. All full-system costs remain unmeasured.

## Data and literature access

The Johns Hopkins Turbulence Database offers time-resolved forced-isotropic and channel-flow DNS, with point queries and cutouts. The access page notes that some workflows require a SciServer account or an authorization token; the published testing identifier is limited to requests below 4096 points ([official database access](https://turbulence.idies.jhu.edu/database), [dataset descriptions](https://turbulence.pha.jhu.edu/datasets.aspx)). I did not query/download it: those datasets provide fixed flow configurations, not matched design variations and calibrated model-error labels, so a point cutout would not test this operation's design claim. A suitable next benchmark would pair one design-variable DNS/experiment family with held-out closure regimes; fixed-flow JHTDB data could only supply a closure-calibration component, not the design-response truth.

## Status and next decisive check

- Mathematical status: the Fourier rank and the finite-dimensional uncertainty-radius identity are reconstructed and executed in the stated fixtures. They are elementary finite-dimensional statements, not independently reviewed physical theorems.
- Scientific capability: `NOT_DEMONSTRATED`.
- Novelty: `UNKNOWN`; the operation is a synthesis of established projection, Bayesian model-error estimation, shadowing, and active measurement ideas.
- Physical validation: none.
- Next gate: use a matched parameterized, time-resolved turbulent design dataset and actual feasible observation operators. Compare (i) the complete contrast-targeted gate; (ii) direct projected-force Bayesian calibration plus LSS/NILSS; (iii) matched full-resolution ensemble/multilevel estimation; and (iv) a conservative ROM. Hold out both design values and a closure regime. Report rank errors and interval coverage alongside total acquisition, training, calibration, solver, adjoint, and hardware costs. Stop if direct projected-force calibration yields the same uncertainty with no additional acquisition reduction.

## Sources checked

- Blonigan, Gomez & Wang, [Least Squares Shadowing for Sensitivity Analysis of Turbulent Fluid Flows](https://arxiv.org/abs/1401.4163), arXiv:1401.4163 (2014). Reports LSS on homogeneous isotropic turbulence and Kuramoto–Sivashinsky; also identifies linear-solver efficiency as a scaling limitation.
- Ni & Wang, [Sensitivity analysis on chaotic dynamical system by Non-Intrusive Least Square Shadowing (NILSS)](https://arxiv.org/abs/1611.00880), arXiv:1611.00880 (2016). Provides the strongest reduced unstable-subspace shadowing competitor located in this search.
- Xiao et al., [Quantifying and Reducing Model-Form Uncertainties in Reynolds-Averaged Navier-Stokes Simulations](https://arxiv.org/abs/1508.06315), arXiv:1508.06315v3 / JCP 324 (2016), 115–136. Direct stress-space Bayesian calibration and QoI uncertainty propagation.
- Anderson & Farazmand, [Evolution of nonlinear reduced-order solutions for PDEs with conserved quantities](https://arxiv.org/abs/2104.13515), arXiv:2104.13515v2 (2021). RONS enforces PDE conserved quantities in nonlinear reduced solutions.
- Zou et al., [Uncertainty quantification and stability of neural operators for prediction of three-dimensional turbulence](https://arxiv.org/abs/2506.04898), arXiv:2506.04898v3 / JCP (2025). 3D forced-HIT uncertainty/stability benchmark.
- JHTDB, [database access](https://turbulence.idies.jhu.edu/database), [datasets](https://turbulence.pha.jhu.edu/datasets.aspx). Official data access and scope; no data queried in this turn.

The capital route N731 was also checked. Its claimed theorem is scoped to exact coarse Fourier initial data, unforced 2D Navier–Stokes, full low-mode path error, and an initial layer; its open gate explicitly leaves causal acquisition/noise and physical prediction costs open. It is not evidence for the turbulent long-horizon operation above.
