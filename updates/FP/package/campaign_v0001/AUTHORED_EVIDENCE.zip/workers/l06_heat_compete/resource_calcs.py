#!/usr/bin/env python3
"""Reproduce the report's explicitly derived COP, exergy and area figures.

Source-reported inputs are copied into the constants below. Derived outputs do
not combine performance maxima from different operating points.
"""

import json


def refrigeration_point(th_k: float, tc_k: float, cop: float, qc_w: float = 1_000.0):
    cop_carnot = tc_k / (th_k - tc_k)
    w_min = qc_w * (th_k / tc_k - 1.0)
    w_actual = qc_w / cop
    q_hot = qc_w + w_actual
    return {
        "Th_K": th_k,
        "Tc_K": tc_k,
        "Qc_W": qc_w,
        "COP_reported": cop,
        "COP_Carnot": cop_carnot,
        "W_min_reversible_W": w_min,
        "W_actual_on_reported_COP_basis_W": w_actual,
        "Q_hot_W": q_hot,
        "second_law_efficiency_fraction": cop / cop_carnot,
        "exergy_destruction_W_on_reported_basis": w_actual - w_min,
    }


def heat_driven_prototype(qc_w: float, cop_heater_basis: float, cop_with_aux: float):
    heater_input = qc_w / cop_heater_basis
    total_input = qc_w / cop_with_aux
    return {
        "Qc_zero_lift_W": qc_w,
        "COP_external_heater_maintenance_basis": cop_heater_basis,
        "implied_electric_heater_maintenance_W": heater_input,
        "COP_with_auxiliary_servos": cop_with_aux,
        "implied_total_electrical_input_with_aux_W": total_input,
        "implied_auxiliary_electrical_input_W": total_input - heater_input,
        "source_temperature_C": 130,
        "no_load_device_span_K_separate_point": 2.2,
    }


def main():
    # Values: Zhou et al. 2025 Nature; COP assumes full work recovery and
    # excludes actuator efficiency. This reproduces that basis, not wall power.
    ec_10k = refrigeration_point(297.0, 287.0, 0.9)

    # Han et al. 2024 Nature: finite-span 4 K operation, stated approximate COP.
    polymer_4k = refrigeration_point(300.0, 296.0, 24.0)
    polymer_4k["reported_thermodynamic_efficiency_percent"] = 32.0

    # Hsiau et al. 2026 Nature Energy supplement: external 130 C source case,
    # 2.09 mW counter-heating cooling point and COPs on distinct stated bases.
    driven_film = heat_driven_prototype(0.00209, 5.60e-3, 3.17e-4)
    driven_film["reported_full_system_exergetic_efficiency_with_aux_percent"] = 1.22e-4

    # Ma et al. 2026 Nature Communications: the 272.6 W and COP 0.75 point is
    # explicitly the zero-span water-chiller point.
    conifer = {
        "Qc_zero_span_W": 272.6,
        "COP_system_zero_span": 0.75,
        "implied_input_on_reported_system_basis_W": 272.6 / 0.75,
        "separate_cooling_power_W_at_0_1K_span": 183.9,
        "separate_load_free_regenerator_span_K": 45.5,
        "heat_sink_C": 45,
    }

    # Yao et al. 2024 Nature Communications: the 4.2 W / COP 1.27 point is
    # zero span at 0.12 Hz; 4.5 W at 0.17 Hz and 25.4 K are separate points.
    roller_driven_ec = {
        "Qc_at_system_COP_point_zero_span_W": 4.2,
        "COP_system_zero_span_electrical_actuator_boundary": 1.27,
        "implied_electrical_actuator_input_at_that_point_W": 4.2 / 1.27,
        "separate_zero_span_max_cooling_power_W": 4.5,
        "separate_no_load_temperature_span_K": 25.4,
        "reported_work_recovery_fraction": 0.78,
    }

    # Raman 2014 measured ambient-temperature cooling flux; So 2022 value is
    # a no-nonradiative-loss calculation based on measured optical spectra.
    radiative = {
        "Raman_reported_ambient_cooling_flux_W_m2": 40.1,
        "Raman_area_m2_per_1kW_at_that_flux": 1_000.0 / 40.1,
        "So_reported_optical_calculation_W_m2": 70.6,
        "So_area_m2_per_1kW_if_sustained": 1_000.0 / 70.6,
        "So_flux_excludes_nonradiative_transfer": True,
        "2026_biocomposite_reported_theoretical_cooling_power_W_m2": 106.0,
        "2026_biocomposite_area_m2_per_1kW_if_sustained": 1_000.0 / 106.0,
        "2026_biocomposite_reported_24h_subambient_drop_C": 7.2,
        "2026_biocomposite_reported_peak_day_subambient_drop_C": 8.8,
        "2026_flux_is_calculated_not_loaded_test": True,
    }

    # Zhang et al. 2026 TPV: compare reported device efficiency with the
    # emitter-to-300 K Carnot ceiling only, not upstream heat-source efficiency.
    te = 2162.0 + 273.15
    tc_ambient = 300.0
    tpv_carnot = 1.0 - tc_ambient / te
    te_2024 = 1435.0 + 273.15
    tpv_carnot_2024 = 1.0 - tc_ambient / te_2024
    tpv = {
        "2026_emitter_temperature_K": te,
        "receiver_temperature_K": tc_ambient,
        "2026_reported_device_efficiency_fraction": 0.4716,
        "2026_reported_uncertainty_fraction": 0.0112,
        "2026_Carnot_efficiency_fraction": tpv_carnot,
        "2026_efficiency_fraction_of_Carnot": 0.4716 / tpv_carnot,
        "2024_air_bridge_reported_cell_efficiency_fraction": 0.44,
        "2024_emitter_temperature_K": te_2024,
        "2024_Carnot_efficiency_fraction": tpv_carnot_2024,
        "2024_efficiency_fraction_of_Carnot": 0.44 / tpv_carnot_2024,
    }

    output = {
        "elastocaloric_10K_per_1kW_cooling": ec_10k,
        "electrocaloric_polymer_4K": polymer_4k,
        "external_heat_driven_film": driven_film,
        "conifer_chiller_zero_span": conifer,
        "roller_driven_elastocaloric_refrigerator": roller_driven_ec,
        "daytime_radiative_cooling": radiative,
        "thermophotovoltaic_cell": tpv,
        "notes": [
            "Zero-span cooling power, finite-span temperature span, and maximum COP may be different operating points.",
            "Reported COP boundaries are preserved; implied inputs are algebraic deductions, not new measurements.",
            "Radiative area scaling applies only to the stated flux and does not include deployment losses.",
            "No full wall-plug optical-refrigerator COP is computed because simultaneous payload heat lift is UNKNOWN.",
        ],
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
