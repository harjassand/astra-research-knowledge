#!/usr/bin/env python3
"""Small, transparent calculations for a defect-removal selectivity gate.

No fitted material parameters are used. Inputs are the desired survival fractions
of the target defect population and the useful microstructure feature.
"""

from math import log

K_B_EV_PER_K = 8.617333262e-5


def selectivity(target_survival: float, feature_retention: float) -> float:
    """Minimum integrated first-order hazard ratio for the requested outcome."""
    if not (0.0 < target_survival < 1.0):
        raise ValueError("target_survival must lie strictly between 0 and 1")
    if not (0.0 < feature_retention < 1.0):
        raise ValueError("feature_retention must lie strictly between 0 and 1")
    return log(1.0 / target_survival) / log(1.0 / feature_retention)


def effective_barrier_gap_eV(rate_ratio: float, temperature_K: float) -> float:
    """Barrier difference kT ln(rate_ratio), assuming equal prefactors."""
    if rate_ratio <= 0 or temperature_K <= 0:
        raise ValueError("rate_ratio and temperature_K must be positive")
    return K_B_EV_PER_K * temperature_K * log(rate_ratio)


def characteristic_spacing_nm(number_density_m3: float) -> float:
    """Cubic-root spacing n^(-1/3), not a measured nearest-neighbour distance."""
    if number_density_m3 <= 0:
        raise ValueError("number_density_m3 must be positive")
    return 1e9 * number_density_m3 ** (-1.0 / 3.0)


def main() -> None:
    T = 450.0 + 273.15
    print("First-order hazard gate (target defects / useful feature)")
    print("target_removed, feature_retained, required_selectivity, effective_barrier_gap_eV_at_450C")
    for removed in (0.52, 0.60, 0.64, 0.90):
        ratio = selectivity(1.0 - removed, 0.95)
        gap = effective_barrier_gap_eV(ratio, T)
        print(f"{removed:.2f},0.95,{ratio:.3f},{gap:.4f}")
    print("\nIllustrative ODS particle spacing from reported number density")
    for density in (2.9e23, 4.7e23):
        print(f"n={density:.2e} m^-3 -> n^(-1/3)={characteristic_spacing_nm(density):.2f} nm")


if __name__ == "__main__":
    main()
