#!/usr/bin/env python3
"""Reproduce the per-film and scale-up arithmetic for the soap-film claim.

Inputs are taken from the original JACS supporting information: 2 cm wand
diameter, 6.5 um assumed film thickness, and 1.67 +/- 0.16 mM H2O2 per film.
The cylinder model and complete peroxide recovery are assumptions, not new
measurements.
"""

from math import pi

diameter_cm = 2.0
thickness_um = 6.5
concentration_mM = 1.67
concentration_sd_mM = 0.16
film_time_s = 2.0  # 1 s immersed + 1 s exposed, as reported in the SI
target_liters = 1.0

radius_cm = diameter_cm / 2
thickness_cm = thickness_um * 1e-4
film_volume_cm3 = pi * radius_cm**2 * thickness_cm
film_volume_l = film_volume_cm3 * 1e-3
film_mol = concentration_mM * 1e-3 * film_volume_l
film_sd_mol = concentration_sd_mM * 1e-3 * film_volume_l
molar_mass_h2o2_g_mol = 34.0147
film_mass_g = film_mol * molar_mass_h2o2_g_mol
film_mass_sd_g = film_sd_mol * molar_mass_h2o2_g_mol

target_mol = concentration_mM * 1e-3 * target_liters
cycles_for_target = target_mol / film_mol
seconds_for_target = cycles_for_target * film_time_s
days_for_target = seconds_for_target / 86400

print(f"Assumed cylindrical film volume: {film_volume_l * 1e6:.3f} uL")
print(
    "Claimed H2O2 per film: "
    f"{film_mol * 1e9:.3f} +/- {film_sd_mol * 1e9:.3f} nmol "
    f"({film_mass_g * 1e6:.3f} +/- {film_mass_sd_g * 1e6:.3f} ug)"
)
for cycles in (50, 300):
    amount_mol = cycles * film_mol
    mass_g = amount_mol * molar_mass_h2o2_g_mol
    print(
        f"{cycles} cycles: {amount_mol * 1e9:.3f} nmol, "
        f"{mass_g * 1e6:.3f} ug H2O2"
    )
print(
    f"Cycles to reach {concentration_mM:.2f} mM in {target_liters:g} L "
    f"at the claimed per-film output: {cycles_for_target:,.0f}"
)
print(
    f"Time at {film_time_s:g} s/cycle: {days_for_target:.2f} days "
    "of uninterrupted single-wand operation"
)
print(
    "Collection volume needed to dilute the 300-cycle claimed output below "
    f"1 uM: {(300 * film_mol / 1e-6):.3f} L"
)
print(
    "Collection volume needed to dilute it below 50 nM: "
    f"{(300 * film_mol / 50e-9):.3f} L"
)
