# Soap-film peroxide as a low-energy production operation

**Status (15 October 2026): NOT ACHIEVED.** The proposed operation is not supported by the strongest available replication. A 2025 paper reports millimolar hydrogen peroxide (H2O2) in soap films; a close 2026 replication reports no film-attributable peroxide after 300 cycles using direct NMR and several independent assays. The negative study is an arXiv preprint, so this is a strong failure signal rather than a settled consensus. No physical experiment was performed in this investigation.

## Candidate and operation contract

The candidate was to make a small, on-demand oxidant stream by repeatedly drawing soap films through air with a handheld wand. The surprising claim is that a benign gas–liquid interface makes H2O2 without added oxidant, catalyst, voltage, or light. If reproducible, this could provide a simple local oxidant source for cleaning or small-volume treatment.

The published input is more specific than “water and air”: 0.1% (v/v) Triton X-100 in 200 mM phosphate-buffered saline near pH 6.4, plus repeated mechanical wand motion. The original supporting information describes one-second immersion and one-second exposure per cycle and estimates a 6.5 μm film thickness. It reports an average film concentration of 1.67 ± 0.16 mM for a plastic wand. It derives that concentration from peroxide accumulated after 50 film cycles; it does not directly assay a single intact film. No mechanical work, cycle throughput, collected-batch concentration, or mass output per operating hour is reported.

The supply contract therefore includes concentrated salt buffer, surfactant, a wand, and manual mechanical work. The output is a reported concentration inside microlitre-scale films. At the reported 2 cm wand diameter and assumed 6.5 μm thickness, the cylinder approximation gives about 2.04 μL per film. The claimed concentration then corresponds to only 3.41 ± 0.33 nmol, or 0.116 ± 0.011 μg, of H2O2 per film. The reported concentration is 56.8 mg/L, but reaching 1 L at that concentration would require about 490,000 such films, roughly 11.4 days at the reported two-second cycle time for a single wand. These are conditional calculations, not a demonstrated scale-up; the uncertainty shown propagates only the reported concentration error, not the unreported geometric uncertainty. Reproduce them with `python3 derive_bounds.py`.

## Primary evidence and falsifier

The positive report is Eldeeb, Berbille, and Dick, “No Microdroplets? No Problem. Soap Films Amplify the Interface and Produce Hydrogen Peroxide,” *JACS* (2025), [article](https://doi.org/10.1021/jacs.5c05887), with [open supporting information](https://doi.org/10.1021/jacs.5c05887.s001). Its SI describes Triton X-100/PBS, multiple wand materials, the iodide colorimetric assay, and the inferred per-film concentration. The 2025 paper also reports test-strip and NMR checks, but its SI shows the concentration was computed by scaling an accumulated bulk measurement over a presumed film volume.

The strongest falsifier found is Eatoo et al., “Soap Films Amplify the Air-Water Interface but Neither Produce Detectable H2O2 Nor Enhance Reduction of Gold Ions,” [arXiv:2610.03774](https://arxiv.org/abs/2610.03774), submitted 29 September 2026. This is a preprint. The authors prepared 0.1% Triton X-100 in 200 mM PBS near pH 6.4, used a commercial plastic wand, and cycled films back into the parent solution up to 300 times. They report no increase over the bulk control by 1H NMR, peroxide strips, iodometric analysis, potassium titanium oxalate, Amplex Red, or a commercial H2O2 assay. Their reported NMR limit is 50 nM in water; they also recover a 1 μM H2O2 spike in the soap matrix. They identify Triton X-100/PBS background as a source of apparent low-level fluorescence-assay signal.

Under the original study’s 2 cm geometry and film-concentration claim, 300 cycles would contain about 1.02 μmol H2O2 before dilution or loss. Dilution alone would require more than 1.02 L of collection solution to put that amount below the 1 μM matrix-spike level, or about 20.5 L to put it below 50 nM. The negative study used a Petri-dish-scale setup, so its null is difficult to reconcile with the claimed yield under otherwise comparable conditions. Exact wand diameter and collection volume are not stated in the negative paper’s accessible methods; the numerical comparison is conditional on matching the original 2 cm film geometry. The independent nondetection itself does not depend on this calculation.

## Why the operation did not pass

The output does not survive a close replication with matrix-matched spike recovery and orthogonal measurements. The positive work also reports concentration per estimated film volume rather than a process throughput; under its own geometry that is sub-microgram product per cycle. Neither paper provides an energy-normalized production rate or a system comparison against direct H2O2 dosing or an electrochemical generator. A measured concentration alone cannot establish a useful production process.

Material-specific chemistry remains possible: the positive article reports several wand materials, while the negative study used a different commercial plastic wand. The negative result therefore challenges the general “soap film interface” effect and the most accessible handheld implementation; it does not exclude every combination of wand material, surfactant, gas composition, or solution chemistry. That residual possibility is not evidence of an operation. Novelty and any surviving special-condition effect remain UNKNOWN.

## Decisive next experiment if the route is reopened

The next test should match one positive condition exactly, including the same wand material and 2 cm diameter, the same Triton X-100/PBS formulation, and the original two-second cycle. Collect the first film and the 50- and 300-cycle samples separately. Record film area, thickness, cycle time, and collected solution volume. Split each sample for direct 1H NMR and the original iodide assay, with a same-matrix peroxide spike and a bulk solution that experiences the same wand contact without film formation. Instrument the wand so the mechanical work per cycle and output mass per hour are measured. A reproducible film-minus-bulk signal consistent with the claimed 1.67 mM film concentration is the pass condition; a null or a signal explained by the bulk-contact blank is a fail. Any pass would still need an energy and throughput comparison before claiming practical value.

## Claim ledger and access limits

- **Soap films contain 1.67 ± 0.16 mM H2O2:** reported by the 2025 JACS study; not reproduced by the 2026 arXiv study under a closely matched recipe. **CONTESTED.**
- **Air–water interface itself makes the peroxide:** not isolated from all solid-contact, solution-matrix, or assay explanations. **NOT ESTABLISHED.**
- **Handheld soap-film peroxide generation is a usable oxidant process:** no reproduced product and no work-normalized throughput. **NOT ACHIEVED.**
- **A specific wand or matrix may produce peroxide:** not excluded by the negative preprint. **UNKNOWN.**
- **Novel process or scientific discovery:** no new mechanism or useful operation was established here. **UNKNOWN / NOT CLAIMED.**

The JACS article page was available as an abstract; its SI was available through ACS Figshare and is retained locally as `ja5c05887_si_001.pdf`. The arXiv preprint and full PDF were directly accessible and retained as `soap_film_counterexample.pdf`. The original studies do not provide raw numerical assay tables for every plotted result in the materials reviewed here; the scale calculations above use only the stated concentration, wand geometry, film thickness, and cycle timing.

Local-source SHA-256 values are recorded here for byte-level identification (they do not validate the scientific claims):

- `ja5c05887_si_001.pdf`: `23431f684ee78ce28d47f0335f3c077893b0a5c0aed14876210afbf70c386f7e`
- `soap_film_counterexample.pdf`: `fd358aab460d2d31c8d77ea308f3676c197767ad0453031d797a3f104db20043`
