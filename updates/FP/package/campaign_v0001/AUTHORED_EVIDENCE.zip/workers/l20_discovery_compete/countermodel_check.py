"""Exact finite check of the hidden-feedback observational equivalence.

The proof in REPORT.md is by induction and covers arbitrary horizons and
action policies. This script only enumerates short open-loop action schedules
as a transparent arithmetic check of the displayed rational parameters.
"""

from fractions import Fraction as F
from itertools import product


WORLDS = {
    "stable_open_loop": {"a": F(4, 5), "b": F(1), "k": F(-3, 10), "gamma": F(1, 10)},
    "unstable_open_loop": {"a": F(6, 5), "b": F(1), "k": F(-7, 10), "gamma": F(1, 10)},
}
VALUES_V = (F(-1), F(0), F(1))
VALUES_Q = (0, 1)
HORIZON = 5


def trace(world, schedule, x0=F(1)):
    x = x0
    states = [x]
    readouts = []
    for v, q in schedule:
        x = (world["a"] + world["b"] * world["k"] + world["gamma"] * q) * x + world["b"] * v
        states.append(x)
        if q:
            readouts.append(x)
    return tuple(states), tuple(readouts)


def main():
    worlds = tuple(WORLDS.values())
    assert worlds[0]["a"] < 1 and abs(worlds[0]["a"]) < 1
    assert abs(worlds[1]["a"]) > 1
    assert all(w["a"] + w["b"] * w["k"] == F(1, 2) for w in worlds)

    actions = tuple(product(VALUES_V, VALUES_Q))
    checked = 0
    for schedule in product(actions, repeat=HORIZON):
        assert trace(worlds[0], schedule) == trace(worlds[1], schedule)
        checked += 1

    print(f"checked_schedules={checked}")
    print(f"closed_loop_multiplier={worlds[0]['a'] + worlds[0]['b'] * worlds[0]['k']}")
    print(f"open_loop_multipliers={worlds[0]['a']},{worlds[1]['a']}")
    print("exact_pathwise_equivalence=True")


if __name__ == "__main__":
    main()
