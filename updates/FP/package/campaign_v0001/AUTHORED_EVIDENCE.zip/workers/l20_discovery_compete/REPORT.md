# Strong incumbent for mechanism discovery with hidden feedback and invasive sensing

## Finding

The strongest incumbent is an intervention-aware model discrimination pipeline, not free-form proposal generation. It combines (i) dynamic system identification under randomized, measured excitation; (ii) cyclic causal-model search with explicit latent-variable and intervention identifiability checks; (iii) tracer design and structural flux-identifiability analysis; and (iv) sequential optimal experiment design that prices interventions, sampling, sensors, calibration, and analysis together. The scientific output is the identifiable causal/flux quantity supported by the acquired experiment, or a surviving equivalence class when the data do not separate mechanisms.

There is a strict same-information obstruction. I give two hidden-feedback systems with different open-loop stability and exactly the same observations under every allowed control and sensor schedule. The equivalence is pathwise, so more samples, stronger inference, or a more capable AI cannot resolve it. Resolution requires an additional acquired variable or an intervention that breaks the equivalence.

## Target and information contract

Use the following discrete-time model as a transparent benchmark for a hidden feedback mechanism. The state `x_t∈ℝ` is not directly accessible except through an invasive reporter. A known experimental input (v_t) is added to an unobserved feedback command (u_t):

\[
u_t=kx_t+v_t,\qquad
x_{t+1}=a x_t+b u_t+\gamma q_t x_t+w_t
          =(a+bk+\gamma q_t)x_t+bv_t+w_t.
\]

Here `q_t∈{0,1}` is the known reporter-on schedule; when `q_t=1`, the reporter also perturbs the next-step dynamics by an unknown back-action coefficient `γ`. The acquired readout, only when the reporter is on, is

\[
y_t=x_t+\epsilon_t\quad(q_t=1).
\]

The noise laws and initial-state law are shared across candidate mechanisms, with `E[w_t]=0`. The allowed interventions are arbitrary sequences `(v_t,q_t)`, chosen in advance or adaptively from past readouts. They do not directly set the hidden feedback gain `k`, nor measure `u_t`. This is a deliberately explicit interface: an intervention on `k`, a calibrated feedback readout, or direct measurement of `u_t` would be additional information and changes the result.

The requested scientific output is whether the open-loop plant is stable after removing its feedback, i.e. whether `|a|<1`, and the one-step counterfactual mean `E[x_{t+1} | do(k=0), q_t=0, v_t=0, x_t=1]=a`. This output is distinct from the closed-loop response under the actual controller.

## Exact same-information obstruction

Fix `b=1` and `γ=1/10`. Consider

\[
H_S:(a,k)=(4/5,-3/10),\qquad
H_U:(a,k)=(6/5,-7/10).
\]

Both have `a+bk=1/2`, but `H_S` has `|a|<1` and `H_U` has `|a|>1`. Under either world and every schedule,

\[
x_{t+1}=(1/2+q_t/10)x_t+v_t+w_t.
\]

Starting from the same `x_0` and coupling the same noise realization, induction gives `x_t^(S)=x_t^(U)` at every time for every possible `(v,q)` sequence. The reporter readouts therefore agree path by path as well. The equality remains true for adaptive policies: identical histories cause the policy to select the same next action under both worlds.

Thus the full transcript distributions satisfy

\[
P_{H_S}^{\pi}=P_{H_U}^{\pi}\quad\text{and}\quad
\mathrm{TV}(P_{H_S}^{\pi},P_{H_U}^{\pi})=0
\]

for every allowed policy `π`, every duration, and every sample count. With equal prior probability, every test of open-loop stability has Bayes error exactly `1/2`; no uniformly correct estimator of `a` exists on this two-point class. The mechanism-level counterfactual differs: setting the hidden feedback gain to zero gives next-step multipliers `4/5` and `6/5`.

The obstruction is structural, not finite-sample. In general the observed plant-input response identifies the composite `c=a+bk`, while the transformation

\[
(a,k)\mapsto(a+b\delta,k-\delta)
\]

preserves `c` for every `δ`. A known or calibrated sensor effect `γq_t` can be identified by varying `q_t`, but it cannot separate `a` from the hidden feedback term `bk`. This is why invasive sensing must be represented in the dynamics and why sensing more frequently does not by itself solve hidden feedback.

## Strongest attainable incumbent

### Dynamic causal identification and system ID

For a specified linear cyclic model with latent variables, randomized interventions can identify the model when the intervention targets and measured-variable overlap satisfy explicit identifiability conditions. Hyttinen, Eberhardt, and Hoyer give necessary and sufficient conditions and a complete search procedure for their model class; the method also discusses what remains when identifiability fails. Closed-loop system-identification methods recover open-loop dynamics when the controller/feedback dynamics are known and closed-loop excitation is informative. These are strong comparators because they use interventions and dynamic structure rather than passive correlations alone. Their assumptions expose the missing inputs in this counterexample: the controller gain or plant input is hidden, and no permitted action removes it.

The baseline experiment should use a persistently exciting randomized `v_t`, record every delivered plant input if possible, randomize reporter-on/off or reporter dosage `q_t`, and model reporter back-action. If a target-specific feedback interruption is safe and possible, include a randomized `do(k=0)` arm. If direct feedback measurement or interruption is unavailable, report the identified composite `a+bk` and refrain from assigning open-loop stability.

### Stable-isotope tracing and metabolic flux identifiability

For an isotope experiment with flux vector `θ`, tracer input design `L`, and acquired isotopomer measurement map `Φ_L(θ)`, the exact identifiability target is whether `Φ_L` is injective on the declared feasible flux class. A local rank test is applied to its Jacobian where the regularity assumptions hold; rank deficiency leaves locally indistinguishable flux perturbations. The chosen label matters: Isermann and Wiechert derive structural identifiability procedures for measured steady-state isotopomer systems and explicitly analyze the effect of input labeling and measurement subsets. That is a more honest output than returning one fitted flux vector from a nonidentifiable fit.

Tracer controls are experimental actions. The comparison must charge isotope preparation/dose, equilibration or pulse duration, destructive extraction and sample loss, mass-spectrometer calibration and resolution, isotope natural-abundance correction, and the number of biological replicates. A tracer can reveal hidden pathway routing only if candidate routes make distinguishable labeled-product predictions under the measured fragments and the actual chosen label. Unobserved exchange pools or hidden feedback remain model components to test, not free nuisance variables to assume away.

### Sequential optimal experiment design

Given explicit candidate mechanisms `M_1,…,M_m`, action `e` (including input, tracer, sensor schedule, and sampling plan), and predictive law `P_i^e` for all acquired data, a strong minimax one-step comparator is

\[
e^*\in\arg\max_{e\in\mathcal E}\;\min_{i\ne j}
\frac{C(P_i^e,P_j^e)}{\operatorname{Cost}(e)},
\]

where `C` is a preregistered discrimination criterion such as Chernoff information; a Bayesian alternative maximizes expected posterior-entropy reduction per total cost. Recompute after each sample batch, with the action set constrained by biological safety and sensor burden. This is the model-discrimination design program of Atkinson and Fedorov, extended to the experiment's actual dynamic and measurement model. For adaptive designs, accumulated pairwise log-likelihood ratios add across conditionally independent episodes; when all feasible `P_i^e` are equal, every information criterion is zero and the experiment must stop with an equivalence class.

Cost must include: specimen/culture preparation; intervention delivery and washout; tracer acquisition and isotopic equilibration; reporter expression/loading and reporter-associated perturbation; illumination or other readout energy; destructive sampling; calibration standards and controls; failed/contaminated samples; instrument time and bandwidth; analysis time/memory; and the full matched comparator's own costs. “Same information” means the compared methods receive the same raw histories, intervention labels, calibrations, and sensor outputs, not a privileged fitted model or hidden simulator.

## Stronger hidden-kinetics comparator already preserved in the capital

The pinned local capital contains a source-reported candidate for global intervention design in finite hidden continuous-time Markov kinetics: card **N744**, at capital HEAD `5ddabf53324159aa6c88e4fef3b75bc7b8b6c4ff`; its source is `updates/EN/package/cray_flux_design/recovered/cray_flux_design/RESEARCH_NOTE.md` (SHA-256 `4ce59bec1e9b685ce3b6dff2383d3e78df3d680f3962ec1a4c2ade85c8bc6229`). Its narrow contract is unusually strong: distinct microscopic intervention sources, fixed destination laws for every combination, additive nonnegative rates, unique normalized stationary law, a reproducible reset, and acquired source indicators, bounded output, and tagged intervention-event counts. Under that contract, isolated or full-rank mixed probe fluxes yield an exact feasible control polytope and an LP-based global output/regret certificate. It explicitly charges reset, preparation, count, calibration, and validation costs.

The preserved report gives a synthetic 160-state, four-control run with `4.4×10^6` episodes, a source-reported nominal 99% conditional-confidence global-regret bound of `0.0368124`, and `4.4×10^6` expected physical time units at reset rate `ρ=1`. It also records a five-state counterexample where all isolated source/output/event laws agree but joint-control outputs differ by `0.985173` at rate `100`; isolated agreement alone therefore does not verify the required actuator structure. Mixed probing found a rare channel's flux rising from about `9.22×10^-10` to `0.490`, but the recorded finite-data upper bound was vacuous (`1`).

This candidate is the right computational baseline for a finite-state kinetic-design claim; it is **source-derived and unreviewed**, not established physical capability. It does not apply automatically to continuous-valued state-space biology, unknown controller policies, sensors that change the mechanism outside the declared generator family, unreset metastable dynamics, or unverified source-selective actuation. An unknown feedback controller violates the most important “same intervention under all combinations” and measured-source assumptions unless separately acquired and bounded.

## Physical sensor relevance

The reporter term is not just a mathematical nuisance. Yang et al. experimentally reported that the calmodulin domain in GCaMP interferes with L-type calcium-channel gating/signaling and changes calcium dynamics and gene expression in neurons; they engineered GCaMP-X to reduce those effects. This demonstrates a concrete reporter-mediated path that can alter a feedback mechanism. It does not imply that every reporter is invasive, or quantify \(\gamma\) for another biological system. Reporter dose, expression time, localization, light dose, target engagement, and a matched nonbinding/rescue reporter belong in the acquisition model.

## Decision and next discriminating experiment

The candidate output is **not uniquely obtainable** under the stated information contract. The truthful deliverable is the closed-loop coefficient `c=a+bk`, the calibrated reporter effect only if `q`-variation supports it, and the stability/output of the actually measured closed-loop system. Open-loop stability remains nonidentified.

The least additional information that breaks this particular equivalence is one of:

1. An acquired, calibrated plant-input record `u_t` with state readout and sufficient randomized excitation, so the plant relation `x_{t+1}=a x_t+b u_t+…` is separately estimable;
2. A validated randomized intervention that sets `k=0` (or to a known value) while preserving the rest of the system; or
3. An independently acquired controller model `k` and plant gain `b`, with uncertainty small enough for the stability decision.

Before any physical run, enumerate rival mechanisms and calculate predicted data distributions for these arms, then select a costed sequential design that maximizes the worst-case discrimination rate. Include reporter dose/on-off and nonbinding/rescue controls to estimate back-action. Stop if all feasible arms leave the models observationally equivalent. For isotope-tracing variants, first run the structural identifiability calculation on the actual atom map, tracer input, and measured fragments; use only flux combinations that are identifiable or provide a new label/readout that removes a specific null direction.

## Claim ledger

| Claim | Status | Scope / limit |
|---|---|---|
| Two parameter worlds give identical acquired paths for every admissible `v,q` sequence | Proved directly in the displayed scalar model | No direct intervention on `k`, no `u_t` record; shared noise and initial law |
| (a) and open-loop stability are not identifiable in this model class | Proved by two-point observational equivalence | Not a universal impossibility for systems with direct controller readout or interventions |
| Cyclic causal discovery with latent variables can use interventions under exact identifiability conditions | Established primary-literature comparator | Hyttinen et al. model family/assumptions only |
| Dynamic closed-loop identification can recover open-loop plant given known feedback dynamics and informative excitation | Established primary-literature comparator | Does not grant a known controller when hidden |
| Isotope tracer choice and measured isotopomer subset determine structural flux identifiability | Established primary-literature comparator | Steady-state ILS class; empirical noise and model error remain |
| Costed optimal design is the strongest fair experiment-selection baseline | Standard primary-literature method plus explicit proposed objective | Requires a candidate set, valid predictive distributions, feasible actions, and measured cost model |
| N744 hidden-kinetic polytope is a validated physical capability | **Not claimed** | Capital status is `source_derived_unreviewed`; physical/priority gates remain open |
| A scientific breakthrough or novelty has been established | **No** | This is a comparator and impossibility result in a restricted model |

## Primary sources and internal evidence

1. A. C. Atkinson and V. V. Fedorov, “Optimal design: Experiments for discriminating between several models,” *Biometrika* 62(2), 289–303 (1975), [doi:10.1093/biomet/62.2.289](https://doi.org/10.1093/biomet/62.2.289). Primary source for sequential rival-model experiment design.
2. A. Hyttinen, F. Eberhardt, and P. O. Hoyer, “Learning Linear Cyclic Causal Models with Latent Variables,” *JMLR* 13 (2012), 3387–3439, [paper](https://www.jmlr.org/papers/v13/hyttinen12a.html). Primary source with necessary/sufficient identifiability conditions and complete search for its cyclic linear model class.
3. N. Isermann and W. Wiechert, “Metabolic isotopomer labeling systems. Part II: structural flux identifiability analysis,” *Mathematical Biosciences* 183(2), 175–214 (2003), [doi:10.1016/S0025-5564(02)00222-5](https://doi.org/10.1016/S0025-5564(02)00222-5). Primary source for steady-state isotope-flux identifiability and input-labeling dependence.
4. M. Phan, J.-N. Juang, L. G. Horta, and R. W. Longman, “System identification from closed-loop data with known output feedback dynamics,” NASA-TM-107604 (1992), [NASA NTRS](https://ntrs.nasa.gov/citations/19920014992). Primary technical report for identifying open-loop systems from closed-loop excitation when feedback dynamics are known.
5. Y. Yang et al., “Improved calcium sensor GCaMP-X overcomes the calcium channel perturbations induced by the calmodulin in GCaMP,” *Nature Communications* 9, 1504 (2018), [doi:10.1038/s41467-018-03719-6](https://doi.org/10.1038/s41467-018-03719-6). Primary experimental example of sensor-mediated perturbation.
6. Internal capital packet: N744 dossier `frontier/dossiers/N744.txt`, base revision `4ae225b0bf2a07e1ced2952a3e1399d4b45e039c`; exact note hash given above. I read the contract, proof of the measured control polytope, reset acquisition and count bounds, rate-cap bound, synthetic result, mixed-probe result, and five-state structural counterexample. Intake status remains source-derived/unreviewed. Capital checkout HEAD read as `5ddabf53324159aa6c88e4fef3b75bc7b8b6c4ff`.

## Access and validation limits

Primary source pages/abstracts were accessible online; full publisher text for the OED and isotope-identifiability articles may be paywalled. The JMLR article and NASA technical memorandum are openly accessible. I did not access or analyze any current worker's report or raw experimental data. The N744 synthetic numbers above are producer-reported and were not independently replayed here. The counterexample in this report has a direct inductive proof and an exact-rational finite enumeration script; that script checks finite schedules and is supplementary to the proof. Run `python3 workers/l20_discovery_compete/countermodel_check.py`; it checks 7,776 five-step schedules and reports an exact match.

