#!/usr/bin/env python3
"""Transparent, conditional bounds for acoustic steering of diamond vacancies.

Inputs are deliberately exposed: the hop prefactor and defect elastic dipole
are NOT measurements supplied by the cited vacancy-migration experiments.
"""

import json
import math
from pathlib import Path
from statistics import NormalDist

KB_EV_K = 8.617333262145e-5
A_CUBIC_M = 3.56712e-10
HOP_M = A_CUBIC_M * math.sqrt(3) / 4
WAVE_SPEED_M_S = 9560.0  # 2026 AlScN-on-diamond, lambda=1 um
WAVELENGTH_M = 1.0e-6
ATTEMPT_S = 1.0e13  # illustrative generous vibrational-scale prefactor
TARGET_SIGMA_M = 5.0e-9
T_K = 1100.0 + 273.15


def row(temperature_k, migration_ev):
    kbt = KB_EV_K * temperature_k
    gamma = ATTEMPT_S * math.exp(-migration_ev / kbt)
    diffusivity = HOP_M**2 * gamma / 6.0
    wave_hz = WAVE_SPEED_M_S / WAVELENGTH_M
    return {
        "temperature_C": temperature_k - 273.15,
        "migration_eV": migration_ev,
        "kBT_eV": kbt,
        "hop_rate_s-1": gamma,
        "D_m2_s-1": diffusivity,
        "wave_frequency_Hz": wave_hz,
        "wave_cycles_per_hop": wave_hz / gamma,
        "maximum_hop_speed_m_s-1": HOP_M * gamma,
        "wave_speed_over_hop_speed": WAVE_SPEED_M_S / (HOP_M * gamma),
        "rms_3D_diffusion_after_1s_m": math.sqrt(6.0 * diffusivity),
    }


def cosine_well_energy(temperature_k, wavelength_m, sigma_m):
    """Harmonic curvature needed for one-coordinate thermal standard deviation."""
    return KB_EV_K * temperature_k * (wavelength_m / (2.0 * math.pi * sigma_m)) ** 2


def hard_well_energy(temperature_k, catch_radius_m, target_radius_m, occupancy):
    """Best-case 3D flat-bottom equilibrium well against uniform exterior."""
    volume_ratio = (catch_radius_m / target_radius_m) ** 3 - 1.0
    return KB_EV_K * temperature_k * math.log(occupancy / (1 - occupancy) * volume_ratio)


def hop_fidelity_needed(steps, whole_route_success):
    """Open-loop independent step model; no site readout or corrective steps."""
    p = whole_route_success ** (1.0 / steps)
    one_wrong_rate_ratio = 3.0 * p / (1.0 - p)
    return {
        "steps": steps,
        "whole_route_success": whole_route_success,
        "minimum_correct_step_probability": p,
        "minimum_correct_to_all_wrong_rate_ratio": p / (1.0 - p),
        "minimum_correct_to_each_wrong_rate_ratio_if_three_equal_wrong_bonds": one_wrong_rate_ratio,
        "thermal_saddle_split_eV_at_1100C_if_equal_prefactors": KB_EV_K * T_K * math.log(one_wrong_rate_ratio),
    }


def random_nitrogen_gate():
    """Poisson N positions in a pre-specified +/-5 nm cube; before conversion."""
    volume_nm3 = (2.0 * TARGET_SIGMA_M * 1e9) ** 3
    mean_for_90pct_any = math.log(10.0)
    return {
        "target_cube_volume_nm3": volume_nm3,
        "maximum_probability_exactly_one_N_in_cube_over_any_density": 1.0 / math.e,
        "mean_N_needed_for_90pct_at_least_one": mean_for_90pct_any,
        "density_cm-3_needed_for_90pct_at_least_one": mean_for_90pct_any / volume_nm3 * 1e21,
        "probability_two_or_more_N_at_that_density": 1.0 - 0.1 * (1.0 + mean_for_90pct_any),
    }


def main():
    data = {
        "model": "neutral vacancy activated hops; cosine elastic potential; not a device simulation",
        "assumptions": {
            "diamond_cubic_lattice_m": A_CUBIC_M,
            "nearest_neighbor_hop_m": HOP_M,
            "attempt_frequency_s-1_illustrative": ATTEMPT_S,
            "SAW_phase_speed_m_s": WAVE_SPEED_M_S,
            "SAW_wavelength_m": WAVELENGTH_M,
        },
        "hop_sensitivity": [
            row(t, e)
            for t in [800 + 273.15, 1000 + 273.15, 1100 + 273.15]
            for e in [2.0, 2.3, 2.6]
        ],
        "trap_at_1100C": {
            "target_one_coordinate_sigma_m": TARGET_SIGMA_M,
            "minimum_U0_eV_90pct_independent_3D_within_5nm_each_lambda_1um": (
                cosine_well_energy(T_K, WAVELENGTH_M, TARGET_SIGMA_M)
                * NormalDist().inv_cdf((1.0 + 0.9 ** (1.0 / 3.0)) / 2.0) ** 2
            ),
            "minimum_U0_eV_by_wavelength": {
                f"{lam_m * 1e9:g}_nm": cosine_well_energy(T_K, lam_m, TARGET_SIGMA_M)
                for lam_m in [1e-6, 0.5e-6, 0.1e-6, 0.05e-6]
            },
            "harmonic_sigma_estimate_m_for_U0_0p1eV_lambda_1um_not_valid_when_U0_lt_kBT": (
                WAVELENGTH_M / (2 * math.pi)
                * math.sqrt(KB_EV_K * T_K / 0.1)
            ),
            "harmonic_sigma_estimate_m_for_U0_1eV_lambda_1um": (
                WAVELENGTH_M / (2 * math.pi)
                * math.sqrt(KB_EV_K * T_K / 1.0)
            ),
            "hard_well_min_depth_eV_90pct_in_r5nm_of_r100nm": hard_well_energy(
                T_K, 100e-9, 5e-9, 0.9
            ),
            "P_eV_required_for_cosine_well_at_strain_1pct_lambda_1um": (
                cosine_well_energy(T_K, WAVELENGTH_M, TARGET_SIGMA_M) / 0.01
            ),
            "strain_required_if_P_100eV_per_strain_lambda_1um": (
                cosine_well_energy(T_K, WAVELENGTH_M, TARGET_SIGMA_M) / 100.0
            ),
        },
        "rescue_directional_hop_gate": [
            hop_fidelity_needed(n, 0.9) for n in [30, 130]
        ],
        "random_nitrogen_supply_gate": random_nitrogen_gate(),
        "room_temperature_unassisted_hop_rate_s-1_at_2p3eV": row(300.0, 2.3)["hop_rate_s-1"],
    }
    output = Path(__file__).with_name("RESULTS.json")
    output.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    print(output)
    print(json.dumps({
        "central_1100C": data["hop_sensitivity"][-2],
        "trap_at_1100C": data["trap_at_1100C"],
        "rescue_directional_hop_gate": data["rescue_directional_hop_gate"],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
