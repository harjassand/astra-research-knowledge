#!/usr/bin/env python3
"""Exact small-model tradeoffs for proofread molecular construction.

All kinetic-proofreading numbers are consequences of the explicitly stated
memoryless checkpoint model below, not measurements of a ribosome. The
algorithmic-assembly global-yield calculation uses independent per-site
errors; its union-bound threshold is valid without independence.
"""

from __future__ import annotations

import json
import math


def ceil_log_ratio(numerator: float, denominator: float) -> int:
    """Smallest integer m >= 0 such that denominator**m <= numerator."""
    if not (0.0 < numerator < 1.0 and 0.0 < denominator < 1.0):
        raise ValueError("inputs must be in (0, 1)")
    return max(0, math.ceil(math.log(numerator) / math.log(denominator)))


def proofreading_model(
    *,
    correct_progression_probability: float,
    wrong_offrate_ratio: float,
    correct_feed_fraction: float,
    checkpoints: int,
    progression_rate_per_s: float = 1.0,
) -> dict[str, float | int]:
    """Renewal model: each failed candidate dissociates and is replaced.

    At each of m checkpoints, a common forward step at rate a competes with
    substrate-dependent rejection d_i. A forward step consumes one unit of
    fuel. The next candidate is independently drawn from the feed mixture.
    """
    r = correct_progression_probability
    theta = wrong_offrate_ratio
    f_correct = correct_feed_fraction
    if not (0.0 < r < 1.0 and theta > 1.0 and 0.0 < f_correct < 1.0):
        raise ValueError("require 0<r<1, theta>1, and 0<f_correct<1")
    if checkpoints < 1 or progression_rate_per_s <= 0:
        raise ValueError("checkpoints and progression rate must be positive")

    a = progression_rate_per_s
    d_correct = a * (1.0 - r) / r
    d_wrong = theta * d_correct
    p_correct = a / (a + d_correct)
    p_wrong = a / (a + d_wrong)
    f_wrong = 1.0 - f_correct

    y_correct = p_correct**checkpoints
    y_wrong = p_wrong**checkpoints
    product_probability_per_attempt = f_correct * y_correct + f_wrong * y_wrong
    wrong_product_fraction = f_wrong * y_wrong / product_probability_per_attempt

    # Expected time until a candidate either dissociates or commits. A candidate
    # reaches checkpoint j with probability p_i**(j-1), then waits Exp(a+d_i).
    time_correct_s = (1.0 - y_correct) / d_correct
    time_wrong_s = (1.0 - y_wrong) / d_wrong
    mean_attempt_time_s = f_correct * time_correct_s + f_wrong * time_wrong_s
    product_rate_per_enzyme_s = (
        product_probability_per_attempt / mean_attempt_time_s
    )
    correct_product_rate_per_enzyme_s = (
        f_correct * y_correct / mean_attempt_time_s
    )

    def expected_forward_steps(p: float) -> float:
        return p * (1.0 - p**checkpoints) / (1.0 - p)

    mean_fuel_per_attempt = (
        f_correct * expected_forward_steps(p_correct)
        + f_wrong * expected_forward_steps(p_wrong)
    )
    fuel_per_product = (
        mean_fuel_per_attempt / product_probability_per_attempt
    )
    fuel_per_correct_product = (
        mean_fuel_per_attempt / (f_correct * y_correct)
    )

    return {
        "checkpoints": checkpoints,
        "p_correct_survives_one_checkpoint": p_correct,
        "p_wrong_survives_one_checkpoint": p_wrong,
        "wrong_product_fraction_among_committed_products": wrong_product_fraction,
        "correct_candidate_commit_probability": y_correct,
        "wrong_candidate_commit_probability": y_wrong,
        "mean_attempt_duration_s": mean_attempt_time_s,
        "product_rate_per_enzyme_s": product_rate_per_enzyme_s,
        "correct_product_rate_per_enzyme_s": correct_product_rate_per_enzyme_s,
        "fuel_per_product": fuel_per_product,
        "fuel_per_correct_product": fuel_per_correct_product,
    }


def main() -> None:
    sites = 1_000_000
    target_whole_object_success = 0.95
    measured_4r_error_upper_bound = 1e-3
    empirical_error_reduction_per_added_layer = 3.0
    per_site_error_needed_iid = 1.0 - target_whole_object_success ** (1.0 / sites)
    extra_layers = math.ceil(
        math.log(
            measured_4r_error_upper_bound / per_site_error_needed_iid,
            empirical_error_reduction_per_added_layer,
        )
    )

    # The model targets >=95% fully correct output over a 100-residue chain.
    chain_length = 100
    chain_success_target = 0.95
    per_site_error_target = 1.0 - chain_success_target ** (1.0 / chain_length)
    r = 0.90
    theta = 10.0
    p_correct = r
    p_wrong = r / (theta - (theta - 1.0) * r)
    one_checkpoint_error = p_wrong / (p_correct + p_wrong)
    per_checkpoint_wrong_to_correct = p_wrong / p_correct
    checkpoints_for_chain_target = ceil_log_ratio(
        per_site_error_target / (1.0 - per_site_error_target),
        per_checkpoint_wrong_to_correct,
    )

    kpr_one = proofreading_model(
        correct_progression_probability=r,
        wrong_offrate_ratio=theta,
        correct_feed_fraction=0.5,
        checkpoints=1,
    )
    kpr_target = proofreading_model(
        correct_progression_probability=r,
        wrong_offrate_ratio=theta,
        correct_feed_fraction=0.5,
        checkpoints=checkpoints_for_chain_target,
    )
    kpr_target["per_residue_error"] = kpr_target[
        "wrong_product_fraction_among_committed_products"
    ]
    kpr_target["whole_chain_exact_probability_iid"] = (
        1.0 - float(kpr_target["per_residue_error"])
    ) ** chain_length
    kpr_target["relative_product_rate_vs_one_checkpoint"] = (
        float(kpr_target["product_rate_per_enzyme_s"])
        / float(kpr_one["product_rate_per_enzyme_s"])
    )
    kpr_target["relative_fuel_per_correct_product_vs_one_checkpoint"] = (
        float(kpr_target["fuel_per_correct_product"])
        / float(kpr_one["fuel_per_correct_product"])
    )

    # kTAM illustrative rates: correct growth attaches with two bonds and
    # detaches at rate exp(-2 Gse); an erroneous one-bond attachment competes
    # with its detachment. Energies are dimensionless in kBT units.
    kTAM = []
    tau = 1.95
    for g_se in (3.0, 5.0, 7.0):
        g_mc = tau * g_se
        q_bad_lock = 1.0 / (1.0 + math.exp(g_mc - g_se))
        net_growth_rate_over_kfhat = math.exp(-g_mc) - math.exp(-2.0 * g_se)
        kTAM.append(
            {
                "Gse_kbt": g_se,
                "Gmc_over_Gse": tau,
                "bad_tile_lock_in_probability_toy_race": q_bad_lock,
                "correct_net_growth_rate_over_kfhat": net_growth_rate_over_kfhat,
                "growth_affinity_per_correct_tile_kbt": 2.0 * g_se - g_mc,
            }
        )

    result = {
        "assembly_global_yield": {
            "logical_sites": sites,
            "per_site_error_model": "iid Bernoulli; local error events measured equally",
            "4R_per_bit_error_input_upper_bound": measured_4r_error_upper_bound,
            "expected_errors_at_4R": sites * measured_4r_error_upper_bound,
            "log10_probability_zero_errors_at_4R_iid": (
                sites * math.log10(1.0 - measured_4r_error_upper_bound)
            ),
            "maximum_site_error_for_95pct_whole_object_success_iid": per_site_error_needed_iid,
            "maximum_site_error_sufficient_by_union_bound": (
                (1.0 - target_whole_object_success) / sites
            ),
            "required_improvement_from_0p1pct_upper_bound": (
                measured_4r_error_upper_bound / per_site_error_needed_iid
            ),
            "extra_layers_at_empirical_factor3_each": extra_layers,
            "predicted_error_after_extra_layers_if_factor3_persists": (
                measured_4r_error_upper_bound
                / empirical_error_reduction_per_added_layer**extra_layers
            ),
            "total_redundancy_level_if_starting_at_4R": 4 + extra_layers,
            "1D_physical_tile_overhead_vs_4R_at_13R": (4 + extra_layers) / 4,
            "2D_area_overhead_vs_4x4_at_13x13": ((4 + extra_layers) / 4) ** 2,
        },
        "kinetic_proofreading": {
            "contract": {
                "feed_correct_fraction": 0.5,
                "forward_rate_s_inverse": 1.0,
                "correct_one_checkpoint_pass_probability": r,
                "wrong_to_correct_rejection_rate_ratio": theta,
                "one_fuel_unit_per_forward_checkpoint_transition": True,
                "chain_length": chain_length,
                "whole_chain_correct_target": chain_success_target,
            },
            "one_checkpoint": kpr_one,
            "target_checkpoint_count": checkpoints_for_chain_target,
            "target": kpr_target,
        },
        "kinetic_tile_assembly": {
            "model_scope": "kTAM-style single growth site; common attachment prefactor; ideal two-bond cooperativity",
            "dimensionless_parameter_sweep": kTAM,
            "equations": {
                "single_wrong_tile_lock_in_race": "q=1/(1+exp(Gmc-Gse))",
                "correct_net_growth": "v/kfhat=exp(-Gmc)-exp(-2*Gse)",
                "correct_growth_affinity": "2*Gse-Gmc kBT per net tile",
            },
        },
        "limitations": [
            "The 3x-per-layer empirical reduction was measured only over redundancy levels 1 to 4; extrapolation is a scenario, not evidence.",
            "The 2D area overhead is the general k-by-k proofreading block scaling, not a measured 13x13 design.",
            "Global-yield multiplication assumes independent site errors; correlated output errors need direct measurement.",
            "KPR and kTAM numbers are exact only under the model contracts; they are not experimental performance claims.",
        ],
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
