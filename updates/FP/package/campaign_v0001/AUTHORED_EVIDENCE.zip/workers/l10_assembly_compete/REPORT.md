# Error-controlled molecular assembly: strongest incumbent and remaining gap

**Status:** the incumbent is strong and experimentally grounded; the requested high-fidelity, large-area output is not demonstrated. This is a scoped comparison, not a new manufacturing capability or a novelty claim. Novelty remains **UNKNOWN**.

## Exact task contract

Use a finite digital program to make a `10 μm × 10 μm` molecular sheet with a binary label at each `10 nm × 10 nm` addressable site (`N = 10^6` sites). A product passes only if every label is correct, with probability at least 0.95 per sheet. The supplied inputs are the program and feedstock specification. The process must use a seed or template and local chemical rules; it may not externally address each site during growth. The manufacturing output is the patterned molecular lattice itself. Converting the DNA pattern into an arbitrary inorganic or covalent material is a separate, currently unclosed interface.

The precise challenge is global product fidelity. A low local mismatch fraction can still make nearly every large object defective. No impossibility theorem for the stated geometry is claimed; “inaccessible” here means outside the demonstrated performance of the best directly relevant open primary experiment under the stated contract.

## Strongest relevant incumbent

The strongest direct assembly incumbent is seeded, algorithmic DNA-tile growth with redundant encoding and kinetic proofreading. A crystal seed supplies the initial pattern. DNA double-crossover tiles, each formed from 4–6 oligonucleotide strands, bind through sequence-specific sticky ends. A tile attached by one matching bond is transient; a correctly placed tile can gain two bonds. In proofreading blocks, a wrong attachment creates a stalled boundary and must be followed by additional unfavorable attachments before it can lock in. Most such partial errors detach, allowing correct growth to resume. This combines templating, a local kinetic checkpoint, and error-correcting redundancy; it is a substantially stronger competitor than an equilibrium histogram or passive one-bond assembly.

Schulman, Wright, and Winfree tested this mechanism in seeded zig-zag DNA ribbons that copied short bitstrings. They report a roughly threefold fall in bitwise error at each added redundancy level and less than 0.1% error per copied bit at fourfold redundancy. Their study directly observed the benefit, while also finding that the measured improvement was much smaller than their simulations predicted. The ribbons were six tiles wide, the encoded sequence was short, and the experiment did not demonstrate a million-site two-dimensional material or an error-free whole object. The methods report 50–75 AFM images per redundancy level; the paper summarizes counts over 25 images of 1 μm ribbons as about 5,000–10,000 ribbon rows. Errors were defined as a copied bit change persisting for at least three columns, and the reported measurement confidence interval was two standard deviations. This supports a local rate estimate, not a 0.95 whole-sheet success claim.

The seed is an acquired physical template. In the experiment, 2 nM pre-assembled seeds were used; their estimated yield was at most about 8% of DNA material, and the estimated fraction of full-sized or large partial seed structures that were well formed was about 40%. Seeding increased the desired 0101/1010 ribbon pattern frequency by about tenfold, but the 0000 pattern still occurred most often in the reported comparison. Tile assembly used 50 nM per strand, 12.5 mM magnesium acetate, and a very slow staged anneal (including a 40-to-20 °C ramp at 0.1 °C per 6 minutes). The stated conditions are evidence of the demonstrated protocol, not a claim that they are optimal. Tile assembly yield was at least 80%; seed yield and target-pattern quality are separate quantities and must not be hidden inside the per-bit error rate.

For sequence-defined covalent products, the strongest autonomous comparator is the ribosome/transfer-RNA system. Messenger RNA templates the order, aminoacyl-transfer-RNA synthetases charge the adaptors and edit some wrong amino acids, and the ribosome applies local selection before and after GTP hydrolysis by EF-Tu. Single-molecule measurements resolve the checkpoints. In the classic isoleucyl-transfer-RNA synthetase experiment, ATP hydrolysis averaged 1.5 ATP per correct Ile-tRNA product versus 270 ATP per Val-mischarged tRNA; the authors infer a 180-fold proofreading reduction, taking a fundamental discrimination near 10^-2 to an overall charging error near 10^-4. This is physical evidence that local proofreading can sharply lower error, with the wrong substrate paying a large energy and time cost.

The biological example is a strong incumbent for making linear biopolymers. It does not provide a general constructor for arbitrary inorganic chemistry, arbitrary three-dimensional atom placement, or a process that repairs any defect in an already grown solid. Its supplied mRNA, tRNA set, enzyme machinery, fuel, salts, and feedstocks are part of the system contract.

## Global fidelity calculation for the stated sheet

Use the experimentally reported upper bound `p = 10^-3` per copied bit as the direct 4-redundancy benchmark. If site errors are independent and have that rate, then

```text
E[number of wrong sites] = N p = 1,000
P(whole sheet correct) = (1-p)^N ≈ 10^-434.5.
```

For 95% probability of no errors under the same explicit independent-site model, the per-site rate must satisfy

```text
p <= 1 - 0.95^(1/N) = 5.13 × 10^-8.
```

The same `5 × 10^-8` is a sufficient per-site threshold by the union bound without independence. The current 4-redundant point therefore needs about `1.95 × 10^4` more suppression using the paper’s conservative explicit 0.1% bound. If the observed roughly 3× reduction per extra redundancy level persisted, nine further levels (4R to 13R) would reach that value in the toy extrapolation. That extrapolation is **not a measured result**: the experiment only covered redundancy 1–4, and it reports that observed gains lagged the model.

The physical price is not hidden. One-dimensional sequence-copying redundancy lowers logical bits per assembled width. General two-dimensional proofreading constructions replace a logical tile by a `k × k` block, giving quadratic area growth and, in the general construction discussed in the literature, quadratic tile-type growth. A hypothetical change from 4R to 13R would multiply physical width by 3.25 for a one-dimensional code, or area by about 10.6 for a two-dimensional `k × k` block, before paying for material supply, slow growth, seed production, and quality control. These are scaling consequences of the construction, not a fabricated 13R design.

For correlated errors, `(1-p)^N` is not valid. The correct acceptance quantity is measured whole-object yield or a joint error model; a marginal local error rate alone does not determine it. Spatial correlations, facet errors, spurious nucleation, tile depletion, malformed components, and seed mistakes can dominate the independent-site model.

## Exact kinetic proofreading model and speed/fuel frontier

To put numbers on the local feedback cost, `model.py` implements a renewal model with equal correct and wrong feed fractions. At each of `m` checkpoints, a candidate advances at common rate `a` or is rejected at a substrate-specific rate. Let the correct candidate’s pass probability per checkpoint be `r = a/(a+d_c)`, and let the wrong candidate’s rejection rate be `d_w = θ d_c`. Then

```text
p_c = r
p_w = r / (θ - (θ-1)r)
error among committed outputs = p_w^m / (p_c^m + p_w^m).
```

Each forward checkpoint consumes one fuel unit with chemical work `Δμ`; a rejected candidate returns to the feed, and a fresh candidate is tried. The expected time for a type-`i` candidate to reject or commit is `(1-p_i^m)/d_i`. The renewal rate is therefore

```text
J_product = (f_c p_c^m + f_w p_w^m) / [f_c(1-p_c^m)/d_c + f_w(1-p_w^m)/d_w].
```

The expected forward fuel steps per candidate are `Σ_{j=1}^m p_i^j`. Dividing the feed-averaged fuel rate by correct-product flux gives exact fuel per correct product under this model. These equations expose the price of repeated checks without pretending the model is a ribosome measurement.

Illustrative contract: equal feed, `r=0.90`, `θ=10`, `a=1 s^-1`, one fuel unit per advance, and a 100-residue chain with at least 95% exact-chain yield. Twelve checkpoints per residue give a modeled per-residue error `4.52 × 10^-4` and exact-chain probability `0.9558` under independent residue errors. The per-enzyme product rate falls from `1.00 s^-1` at one checkpoint to `0.0384 s^-1` at twelve, a factor of 26.0; fuel per correct residue rises from `1.53` to `26.05` fuel units, a factor of 17.1. A real polymerization cycle has different rate constants and chain-elongation details; these values are an exact result only for the declared renewal model.

The elementary rate/accuracy law is also explicit. At one checkpoint the correct-to-wrong product odds gain is `θ-(θ-1)r`, while correct candidate survival is `r`. At fixed weak discrimination, pushing `r` toward one retains more correct candidates but drives this odds gain toward one. Adding stages compounds the gain as `[θ-(θ-1)r]^m`, while the probability that one correct candidate traverses all stages is `r^m`. Retrying rejected molecules prevents this survival factor from being mistaken for final polymer yield, but the renewal calculation shows the resulting delay and fuel burden.

The model of Murugan, Huse, and Leibler gives an important improvement over a naive “more checkpoints always means exponentially slower” account. In a ladder network, the traditional bounded-walk regime reaches error `η ~ exp[-(n+1)Δ]` but has completion time `T_R ~ λ ξ^n` and high dissipation. Their mixed regime makes correct candidates progress while incorrect candidates keep backtracking: `η ~ exp[-Δ] exp[-nΔ(1-α)]` while `T_R ~ 2 n λ`. In the original one-loop Hopfield network they identify a faster limit with `T_R ~ k_12^-1` and `η ~ exp[-2Δ] γ θ_23 < exp[-Δ]`. In Hopfield's ideal two-stage calculation, reducing an initial discrimination error `f0≈10^-2` to approximately `f0²≈10^-4` requires an effective driven discrimination factor of at least `1/f0≈100`; under ideal tight coupling this corresponds to at least `ln(100)≈4.61 kBT` of chemical work. This is a model condition, not a measured universal minimum for repair or manufacturing. These are asymptotic statements for their stated kinetic networks, not universal physical bounds or measured factory performance. They establish that a serious incumbent should tune a substrate-asymmetric local-feedback network; a generic passive-assembly comparison is too weak.

## Passive growth rate and error floor

The kinetic tile assembly model (kTAM) supplies an additional explicit limit. Let `G_se` be the one-sticky-end binding free-energy parameter and `G_mc` the concentration/free-monomer penalty, in units of `kBT`. In the ideal model, tile attachment has rate `k̂_f exp(-G_mc)`, two-bond detachment has rate `k̂_f exp(-2G_se)`, and the net correct growth rate at a single site is

```text
v/k̂_f = exp(-G_mc) - exp(-2 G_se),  with G_mc < 2 G_se.
```

A one-bond mismatch competes with detachment. The simple race estimate for it to be locked in by a later attachment is

```text
q = exp(-G_mc) / [exp(-G_mc) + exp(-G_se)]
  = 1 / [1 + exp(G_mc-G_se)].
```

The multi-attachment proofreading factor is an approximation because real tiles can detach and reattach and bond cooperativity is imperfect. The cited experiment confirms that these nonidealities matter: theoretical/simulated improvements exceeded the measured roughly 3× per added layer. To preserve near-threshold fidelity while raising `G_se`, `G_mc` must also rise toward `2G_se`; tile concentration then falls as `exp(-G_mc)`, and net speed tends to zero at the threshold. Redundancy trades some of that kinetic slowdown for larger objects and more supplied components; it does not erase the resource cost.

## What remains out of reach

The important open output is a user-programmed, large two- or three-dimensional structure that is both globally correct and composed of the requested durable material, produced autonomously from ordinary precursor molecules. Existing sources separately establish DNA-tile information copying, ribosomal sequence-directed polymer synthesis, and local kinetic proofreading. They do not establish an integrated route from a general digital specification to arbitrary site-specific covalent or inorganic matter, with a verified full-object error probability and local repair after chemical conversion.

For the explicitly stated million-site contract, the paper's conservative `p=10^-3` benchmark is about `1.95×10^4` above the independent-site 95% target; because the paper reports an error rate below 0.1%, this is a comparison to its stated upper-bound benchmark, not the exact measured factor. Published redundancy predicts an appealing route but the measured reduction already falls below its ideal scaling, and the 2D volume/tile complexity costs grow with redundancy. Seeded runs also retain target-selection and seed-quality limitations. A post-growth material conversion adds another error channel, which must be measured rather than assumed to preserve the DNA pattern. That combined physical interface, not the existence of a sophisticated algorithm or a template, is the unresolved capability.

The information input has a hard floor: an arbitrary one-of-`2^N` binary target map requires at least `N` bits of distinguishable specification somewhere in the seed, tile library, or external control history. Algorithmic assembly can compactly manufacture patterns with short descriptions; it cannot generate every arbitrary map from a fixed short program and a fixed seed. The target in this report is therefore supplied explicitly and charged as input.

## Claim ledger

| Claim | Status | Scope |
|---|---|---|
| Local algorithmic DNA assembly can copy programmed information and redundancy can reduce its measured errors. | Source-demonstrated | Seeded 6-row DNA zig-zag ribbons, copied short bitstrings, tested redundancy 1–4. |
| Fourfold redundancy in that experiment has less than 0.1% error per copied bit. | Source-demonstrated | Per-bit local statistic; not whole-object yield. |
| Kinetic proofreading reduces error by about 180× in the IleRS/Ile/Val experiment at the stated ATP stoichiometries. | Source-reported primary experiment | Aminoacyl-tRNA charging; not a general chemical manufacturing process. |
| A 10^6-site output with local error 10^-3 has about 10^3 expected errors and negligible defect-free probability under independence. | Derived | Bernoulli site model. |
| Twelve modeled KPR checkpoints yield 95.6% exactness for a 100-unit chain with the stated renewal rates. | Derived | Idealized memoryless model only. |
| Enough redundancy will make arbitrary, large 2D/3D material manufacture reliable at useful throughput. | UNKNOWN | The experiment did not demonstrate the necessary scale, chemistry conversion, throughput, or global yield. |
| A new capability or novelty advantage has been established. | NO | No new mechanism or matched practical advantage has been demonstrated. |

## Decisive next experiment

Run a matched scale-up of the strongest incumbent before testing any proposed competing mechanism. Use a known 2D binary design with an explicit seed, and compare ordinary tiles, 2R/4R proofreading, and one local-feedback/repair arm at the same tile feed, geometry, temperature trajectory, and measurement resolution. Measure full-object correct yield, local error clusters, spurious nucleation, growth speed, DNA consumed per accepted object, seed production yield/quality, and ATP or other fuel consumed. Then apply the proposed material-conversion chemistry to the best DNA pattern and remeasure every site and edge. The falsifier is clear: if redundancy cannot lower whole-object error without unacceptable feature inflation or throughput loss, it is not a viable bridge to reliable materials manufacture; if the material conversion corrupts the code geometry, the broader manufacturing route fails at its interface.

## Primary sources and access

1. J. J. Hopfield, “Kinetic Proofreading: A New Mechanism for Reducing Errors in Biosynthetic Processes Requiring High Specificity,” *PNAS* 71(10), 4135–4139 (1974), [DOI 10.1073/pnas.71.10.4135](https://doi.org/10.1073/pnas.71.10.4135), [accessible PDF](https://garcialab.berkeley.edu/courses/papers/Hopfield1974.pdf). Read the model assumptions and derived double-discrimination result, PDF pp. 1–3.
2. J. J. Hopfield, T. Yamane, V. Yue, and S. M. Coutts, “Direct experimental evidence for kinetic proofreading in amino acylation of tRNAIle,” *PNAS* 73(4), 1164–1168 (1976), [DOI 10.1073/pnas.73.4.1164](https://doi.org/10.1073/pnas.73.4.1164), [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC430221/). Primary measurements of ATP/tRNA stoichiometry and inferred error reduction.
3. A. Murugan, D. A. Huse, and S. Leibler, “Speed, dissipation, and error in kinetic proofreading,” *PNAS* 109(30), 12034–12039 (2012), [DOI 10.1073/pnas.1119911109](https://doi.org/10.1073/pnas.1119911109), [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC3409783/). Read model and asymptotic speed/error regimes, PDF pp. 1–5; it reports no new manufacturing device.
4. R. Schulman, C. Wright, and E. Winfree, “Increasing Redundancy Exponentially Reduces Error Rates during Algorithmic Self-Assembly,” *ACS Nano* (2015), [DOI 10.1021/nn507493s](https://doi.org/10.1021/nn507493s), [author-hosted full PDF](https://www.dna.caltech.edu/Papers/zig-zag-proofreading2015.pdf). Read pp. 1–10 for the empirical rates, kTAM approximations, seed quality, anneal, and measured caveats.
5. M. Johansson, M. Lovmar, and M. Ehrenberg, “Evolutionary optimization of speed and accuracy of decoding on the ribosome,” *PNAS* 108(41), 16565–16570 (2011), [DOI 10.1073/pnas.1017422108](https://doi.org/10.1073/pnas.1017422108), [PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC3193211/). Review/model context for measured speed–fidelity tradeoffs; not used as a substitute for the primary proofreading experiments above.

The author-hosted primary PDFs and PMC records were accessible during this read. No private data, physical materials, or instrument measurements were available. `model.py` and `results.json` are reproducible standard-library calculations; their outputs establish only the stated models.
