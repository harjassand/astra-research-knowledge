# L11 materials invention: a pressure-window capture route for BC8 carbon

**Status: NOT ACHIEVED.** I found a physically specified experiment that could make BC8 carbon directly observable in a short-lived, high-pressure sample, but no evidence that it has been made, recovered, or shown to be useful as an engineering material. The route below is a hypothesis for a decisive experiment, not a synthesis result. Novelty is UNKNOWN.

**Independence:** this was an assigned independent investigation; isolation from other current workers is instructed, not technically enforced. I did not use their reports.

## Target and why it is still inaccessible

The candidate output is carbon in the eight-atom body-centred cubic BC8 structure. Its scientific use is to measure a predicted post-diamond phase and carbon equation of state relevant to extreme-pressure physics, planetary interiors, and inertial-confinement-fusion targets. Predicted superhardness or technological value is not established here.

The obstacle is kinetic access, not only pressure. Carbon diamond remains metastable well beyond its equilibrium stability range. In simulations, BC8 appears only after diamond locally premelts and a liquid-like region nucleates and crystallizes. The synthesis window is narrow: the quantum-accurate 2024 study estimated a lower pressure near 1.2 TPa and a temperature range around 3,700–6,300 K; its proposed nanocrystalline-diamond double shock goes from about 350 GPa, 2,950 K to 1,200 GPa, 6,019 K. That puts the final point close to the calculated hot boundary. The authors' direct piston-driven simulations did not reproduce an earlier double-shock result and argued that the earlier result could be an artifact of its compression method. [Nguyen-Cong et al., *J. Phys. Chem. Lett.* (2024)](https://doi.org/10.1021/acs.jpclett.3c03044); [Shi et al., *Phys. Rev. Lett.* (2023)](https://doi.org/10.1103/PhysRevLett.131.146101).

Recent decaying-shock experiments have reached 1.6 TPa and support a diamond–BC8–liquid phase-boundary interpretation, but the authors explicitly leave direct BC8 structural confirmation by in-situ X-ray diffraction open. This is the present access gap: the needed pressure has been approached, and thermodynamic evidence has improved, but a resolved BC8 diffraction signature is still missing. [Sun et al., *The Innovation* (2026)](https://doi.org/10.1016/j.xinn.2026.101572).

## Proposed operation: three-wave pressure-window capture

Use a nanocrystalline-diamond foil with approximately 5 nm grains, driven by three timed compression/release waves and probed by a synchronized nanosecond X-ray pulse. The distinctive move is to shape the pressure–temperature path through the narrow BC8 nucleation window, rather than treating peak pressure or a final quench as the control variable.

1. **Precondition the nucleation sites.** Use the 5 nm nanocrystalline-diamond microstructure already used in high-energy-density target research. Its grain boundaries promote local premelting. Include an adjacent lane of hexagonal-diamond-rich carbon if a suitably characterized precursor can be prepared; this tests a 2026 metadynamics prediction that hexagonal diamond orders into BC8 more readily. Do not assume the hexagonal lane is phase-pure.
2. **Precompress below the transformation window.** Set the first shock near the published nanocrystalline-diamond state of 350 GPa and 2,950 K. This preserves a compressed solid with defects and grain boundaries.
3. **Use a shaped second and third wave to enter, then dwell inside, the BC8 window.** A stepped flyer or layered impedance target supplies a second compression followed by a short pressure shelf. Hydrodynamic design should aim for a measured central state near 1.3–1.6 TPa and 4,000–5,000 K for roughly 1 ns, then release. The exact wave speeds must be solved with a validated equation of state and measured, because published models disagree on which nominal double-shock trajectory reaches the required state. Avoid overshooting above roughly 2 TPa: simulations find the simple-cubic competitor increasingly favoured there. The 2024 and 2026 works provide the state window, but not a validated flyer design.
4. **Measure structure during the shelf.** Time an XFEL pulse to the pressure shelf and collect full-angle diffraction plus temperature/density diagnostics. BC8 requires several indexed reflections consistent with its `Ia-3` lattice and exclusion of diamond, simple cubic, and liquid-like scattering; reflectivity or a Hugoniot fit alone is not structural identification. Use repeated shots with a small pressure–temperature ladder to map the boundary and avoid selecting one favourable trace after the fact.
5. **Treat recovery as a separate gate.** If in-situ BC8 is observed, make a second set of shots with controlled release profiles and ex-situ diffraction/Raman checks. The 2026 metadynamics paper finds BC8 dynamically stable for 5 ns at 300 K and zero pressure, but that is only a short simulated trajectory, not a lifetime measurement or recovered sample. A material-level claim requires phase identification after release and a measured room-temperature lifetime.

This is an engineering proposal assembled from published pathways, not a claim that the three-wave design is novel or that it will work. The useful initial deliverable is a direct diffraction result for a high-pressure phase; a room-temperature BC8-carbon coupon is a much harder, currently unsupported extension.

## Quantitative output and cost envelope

For a concrete diagnostic target, take an active cylinder 100 µm in diameter and 50 µm thick. At 3.5 g cm⁻³ starting density, this contains about 1.4 µg of carbon in a volume of 3.9×10⁻¹³ m³ (about 7×10¹⁶ atoms). A 20–25 km s⁻¹ wave traverses 50 µm in about 2–2.5 ns, leaving a plausible one-nanosecond timing window if the rear interface and pulse shape retain the pressure shelf. These are design scales, not demonstrated BC8 yields.

At 1.8 TPa, `P V` for that volume is about 0.7 J; `½ m v²` at 25 km s⁻¹ is about 0.43 J. These are mechanical energy scales, not a complete shock-driver budget. Actual work depends on the compressed equation of state and pressure history. Coupling losses, the shaped laser/flyer, target fabrication, diagnostics, and facility overhead dominate. For scale only, LLNL's FY2025 report says NIF's maximum laser energy was temporarily lowered from 2.2 MJ to 1.9 MJ; that is facility context, not the energy required by this target or a per-sample efficiency claim. [LLNL NIF FY2025 report](https://annual.llnl.gov/fy-2025/national-ignition-facility-2025).

**Expected product if the experiment succeeds:** a roughly 1.4 µg region under 1.3–1.6 TPa and 4,000–5,000 K, with a BC8 fraction large enough for indexed in-situ diffraction, held for order 1 ns. A reasonable preregistered threshold is at least 10 vol% BC8 in the probed region, but the literature does not let us predict that yield quantitatively. This is a high-energy-density science specimen, not a manufacturing route. Ambient lifetime, phase purity, hardness, band structure, and device usefulness remain unknown.

The helper [cost_model.py](cost_model.py) reproduces the geometry, mass, transit time, and energy-scale arithmetic.

## Strongest competitors and why this proposal differs

- **Direct double shock from diamond:** Shi et al. proposed compression to 584 GPa followed by a faster shock; their machine-learning molecular dynamics predicted BC8 solidification on an approximately 1 ns scale. This is the closest experimental competitor. Nguyen-Cong et al.'s later quantum-accurate simulations did not reproduce the nominated trajectory in direct piston-driven shock simulations and proposed a different NCD path. The three-wave design is meant to set and hold a measured P–T point, resolving this model/trajectory sensitivity rather than simply repeating the same nominal two-shock setpoints.
- **NCD double shock to 1.2 TPa:** The 2024 work already proposed a route at NIF-like scale. Its simulation predicts the target endpoint but does not establish experimental formation. Our proposed extra shaping and diffraction ladder are an attempt to control the narrow temperature window; they are not yet shown superior.
- **Decaying-shock phase-boundary mapping:** The 2026 experiment reaches 1.6 TPa and sharply constrains thermodynamics. It is a stronger diagnostic baseline than older shock work, but its published abstract still says direct BC8 diffraction is open. A shaped pressure shelf and X-ray structural measurement target that remaining gap.
- **Silicon BC8 is not a clean target for this mission:** phase-pure bulk BC8-Si in millimetre-scale samples has been reported under high-pressure synthesis, and a 2025 paper reports gram-scale dual-phase nanosilicon containing BC8-Si after dynamic high-pressure shearing. Thus “make BC8 silicon stably obtainable” is already substantially accomplished, even though application claims and phase-pure scalable device integration need independent assessment. [Li et al., *Mater. Lett.* (2020)](https://doi.org/10.1016/j.matlet.2019.127195); [Fu et al., *J. Mater. Res. Technol.* (2025)](https://doi.org/10.1016/j.jmrt.2025.07.287).

## Decisive test and failure conditions

Run a blinded pressure–temperature ladder with at least three lanes: the published-like two-shock control, the shaped three-wave path, and an off-window control. Collect diffraction at multiple delays around the pressure shelf and report temperature, pressure, texture, phase fractions, and raw detector images. The key predicted change is a reproducible BC8 diffraction pattern in the shaped path at lower temperature / longer in-window dwell, relative to the control, not merely more diffuse scattering or a reflectivity change.

The operation fails its first gate if the target cannot reach the stated P–T point without shock-induced damage to diagnostics, if the window is shorter than nucleation/growth, or if diffraction shows only liquid/simple-cubic/diamond signatures. It fails the “stable material” gate if BC8 is not observed after release. Even a positive in-situ pattern would establish access to a high-pressure phase, not a useful room-temperature material.

## Claim ledger

| Claim | Status | Evidence boundary |
|---|---|---|
| BC8 carbon is a predicted high-pressure phase and is relevant to high-pressure carbon physics. | Supported, conditional on theory | Phase-diagram calculations and simulations. |
| Diamond-to-BC8 formation can proceed through a premelted/liquid-like intermediate. | Simulation-supported | Multiple machine-learning-potential studies; not direct structural observation. |
| Direct BC8 structural confirmation is still open as of 15 Oct 2026. | Supported | The Sep 2026 shock paper says in-situ XRD confirmation remains open. |
| A three-wave dwell in the 1.3–1.6 TPa, 4–5 kK region will produce enough BC8 for diffraction. | Hypothesis | No experiment, pulse design, or quantitative yield model here. |
| BC8 carbon can be recovered at ambient pressure. | UNKNOWN | 2026 metadynamics shows only 5 ns dynamic stability at 300 K, not a recovered specimen. |
| BC8 carbon is a useful superhard/semiconductor material. | UNKNOWN | No measured mechanical or device property is established by this investigation. |
| The operation is novel. | UNKNOWN | It recombines current simulation results into a testable drive/diagnostic design; novelty search is incomplete. |

## Sources and access

1. J. Shi et al., “Double-Shock Compression Pathways from Diamond to BC8 Carbon,” *Phys. Rev. Lett.* 131, 146101 (2023), [DOI](https://doi.org/10.1103/PhysRevLett.131.146101). Abstract and pathway available; APS full text/supplement access restricted in this session.
2. K. Nguyen-Cong et al., “Extreme Metastability of Diamond and its Transformation to the BC8 Post-Diamond Phase of Carbon,” *J. Phys. Chem. Lett.* 15, 1152–1160 (2024), [DOI](https://doi.org/10.1021/acs.jpclett.3c03044). Full text accessible through public author-hosted manuscript/search indexing; supporting information not fully retrieved.
3. R. Martoňák et al., “From diamond to BC8 to simple cubic and back: Kinetic pathways to post-diamond carbon phases from metadynamics,” *Phys. Rev. B* 113, L220101 (2026), [journal DOI](https://doi.org/10.1103/djft-jvvn), [arXiv full text](https://arxiv.org/html/2509.00423). Open full text. The method uses metadynamics; its trajectory times are not treated here as unbiased experimental rates.
4. L. Sun et al., “Diamond melting and thermodynamic evidence for BC8 carbon at terapascal pressures,” *The Innovation* (online 9 Sep 2026), [DOI](https://doi.org/10.1016/j.xinn.2026.101572). Abstract accessible; structural confirmation remains explicitly open.
5. LLNL, “National Ignition Facility – 2025,” [annual report](https://annual.llnl.gov/fy-2025/national-ignition-facility-2025). Facility-scale energy context only.
6. X. Li et al., “Phase-pure bulk BC8 silicon prepared through secondary phase transition method under high pressure,” *Mater. Lett.* 262 (2020), [DOI](https://doi.org/10.1016/j.matlet.2019.127195). Abstract accessible; reports 3 mm by 0.5 mm phase-pure BC8-Si.
7. M. Fu et al., “Bandgap and impedance barriers overcome by shear-synthesized metastable silicon…,” *J. Mater. Res. Technol.* 38 (2025), [DOI](https://doi.org/10.1016/j.jmrt.2025.07.287). Abstract accessible; BC8-Si dual-phase nanosilicon result informs target selection.
