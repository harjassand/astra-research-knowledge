#!/usr/bin/env python3
"""Reproduce the order-of-magnitude sample budget in REPORT.md."""

from math import pi

diameter = 100e-6       # m
thickness = 50e-6       # m; chosen for roughly 2 ns wave transit
rho_start = 3500        # kg m^-3; ambient diamond density for mass estimate
pressure = 1.8e12       # Pa; target pressure scale
wave_speed = 25e3       # m s^-1; shock velocity scale from published pathway

volume = pi * (diameter / 2) ** 2 * thickness
mass = rho_start * volume
atoms = mass / (12.0 * 1.66053906660e-27)
transit_time = thickness / wave_speed
pv_scale = pressure * volume
kinetic_scale = 0.5 * mass * wave_speed**2

print(f"volume_m3={volume:.3e}")
print(f"mass_kg={mass:.3e}")
print(f"carbon_atoms={atoms:.3e}")
print(f"shock_transit_s={transit_time:.3e}")
print(f"pressure_volume_scale_J={pv_scale:.3g}")
print(f"kinetic_energy_scale_J={kinetic_scale:.3g}")
