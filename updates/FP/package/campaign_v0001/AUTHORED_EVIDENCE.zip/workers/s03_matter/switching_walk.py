#!/usr/bin/env python3
"""Conditional 1D vacancy random-walk comparison with and without uniform field.

Charge state is independently sampled each second. This models rapid switching
and ignores traps, surfaces, nitrogen capture and field-dependent chemistry.
The paired samples reuse identical diffusion noise to expose the effect of the
uniform field on location and spread. This is an in-silico experiment only.
"""

import json
import math
import random
from pathlib import Path

from defect_control import K_B_EV_PER_K, effective_transport


def mean_and_sd(xs):
    avg = sum(xs) / len(xs)
    return avg, math.sqrt(sum((x - avg) ** 2 for x in xs) / len(xs))


def main():
    seed = 20261015
    rng = random.Random(seed)
    n = 5000
    seconds = 660
    f0 = 0.1
    temp_k = 1123.15
    d0 = 17.0
    delta_barrier_ev = 0.6  # one scenario, close to 1995 DFT difference
    field = 1e8  # unvalidated high-field scenario
    _, _, vminus = effective_transport(delta_barrier_ev, 0, field, d0, temp_k)
    ratio = math.exp(-delta_barrier_ev / (K_B_EV_PER_K * temp_k))
    dminus = d0 * ratio
    zero = [0.0] * n
    driven = [0.0] * n
    charge_time = [0] * n
    for _ in range(seconds):
        for i in range(n):
            neutral = rng.random() < f0
            if not neutral:
                charge_time[i] += 1
            d = d0 if neutral else dminus
            jump = rng.gauss(0.0, math.sqrt(2 * d))
            zero[i] += jump
            driven[i] += jump + (0.0 if neutral else vminus)
    m0, s0 = mean_and_sd(zero)
    m1, s1 = mean_and_sd(driven)
    result = {
        "status": "synthetic, conditional 1D simulation; no physical validation",
        "seed": seed,
        "particles": n,
        "seconds": seconds,
        "neutral_fraction": f0,
        "barrier_difference_eV": delta_barrier_ev,
        "field_V_per_m": field,
        "switching_model": "independent charge draw each second",
        "no_field_mean_nm": m0,
        "no_field_sd_nm": s0,
        "uniform_field_mean_nm": m1,
        "uniform_field_sd_nm": s1,
        "mean_shift_nm": m1 - m0,
        "sd_change_nm": s1 - s0,
        "mean_charged_seconds_per_particle": sum(charge_time) / n,
        "analytic_mean_shift_nm": (1 - f0) * vminus * seconds,
        "analytic_no_field_sd_nm": math.sqrt(2 * (f0 * d0 + (1 - f0) * dminus) * seconds),
    }
    path = Path(__file__).resolve().parent / "switching_walk.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
