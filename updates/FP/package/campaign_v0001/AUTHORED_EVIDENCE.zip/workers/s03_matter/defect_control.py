#!/usr/bin/env python3
"""Transparent parameter study for vacancy steering in diamond.

This is a conditional model, not a fitted experiment. All energies and fields
other than the explicitly cited baseline values are scenario parameters.
"""

import csv
import json
import math
from pathlib import Path

K_B_EV_PER_K = 8.617333262145e-5
EV_J = 1.602176634e-19
ROOT = Path(__file__).resolve().parent


def effective_transport(delta_barrier_ev, neutral_fraction, field_v_per_m, d0_nm2_s, temp_k):
    """Rapid charge exchange, Einstein mobility and equal attempt prefactors.

    delta_barrier_ev = E_m(V-) - E_m(V0). The electric field affects V- only.
    This excludes field-dependent charge conversion, electrode leakage,
    anisotropic hops, space charge, capture and damage.
    """
    thermal_ev = K_B_EV_PER_K * temp_k
    ratio = math.exp(-delta_barrier_ev / thermal_ev)
    dminus = d0_nm2_s * ratio
    deff = neutral_fraction * d0_nm2_s + (1 - neutral_fraction) * dminus
    # q E / kT in nm^-1; q E per nm is E*1e-9 electron-volts.
    force_over_thermal_nm = field_v_per_m * 1e-9 / thermal_ev
    v_nm_s = (1 - neutral_fraction) * dminus * force_over_thermal_nm
    return ratio, deff, v_nm_s


def main():
    temp_k = 850 + 273.15
    anneal_s = 11 * 60
    d0 = 17.0  # Kim et al., fitted vacancy diffusivity, nm^2/s
    field = 1.0e8  # aggressive scenario, not an experimentally validated condition
    length_nm = 20.0
    kT = K_B_EV_PER_K * temp_k
    vacancy_volume_a3 = 5.67  # scenario atomic-volume proxy, not a measured relaxation volume
    bulk_modulus_gpa = 439.2  # Ikuta et al. 2022
    bulk_modulus_times_vol_ev = bulk_modulus_gpa * 1e9 * vacancy_volume_a3 * 1e-30 / EV_J
    doped_layer_ppm_nm = 98.0  # Kim et al.; ppm*nm areal dose
    carbon_density_nm3 = 176.0  # ~3.52 g/cm^3 diamond converted to atom density
    nitrogen_density_nm2 = carbon_density_nm3 * doped_layer_ppm_nm * 1e-6

    rows = []
    for delta_ev in (0.5, 0.8, 1.1):
        for f0 in (1.0, 0.5, 0.1, 0.01, 0.001):
            ratio, deff, v = effective_transport(delta_ev, f0, field, d0, temp_k)
            rows.append({
                "delta_barrier_eV": delta_ev,
                "neutral_fraction": f0,
                "Dminus_over_D0": ratio,
                "D_eff_nm2_s": deff,
                "rms_x_nm_11min": math.sqrt(2 * deff * anneal_s),
                "mean_drift_nm_11min": v * anneal_s,
                "Pe_20nm": v * length_nm / deff,
                "time_for_rms_20nm_s": length_nm**2 / (2 * deff),
            })
    with (ROOT / "charge_sweep.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    strain = []
    # U(r) = DeltaU (r/R)^2, stationary x/y sigma = R sqrt(kT/(2 DeltaU)).
    for r_nm in (50.0, 65.0, 100.0, 140.0):
        for sigma_nm in (46.0, 33.0, 15.0, 10.0):
            delta_u_ev = kT * r_nm**2 / (2 * sigma_nm**2)
            strain.append({
                "well_radius_nm": r_nm,
                "target_sigma_nm": sigma_nm,
                "required_edge_depth_eV": delta_u_ev,
                "required_volumetric_strain_if_relaxation_volume_one_atomic_volume":
                    delta_u_ev / bulk_modulus_times_vol_ev,
            })
    with (ROOT / "strain_requirements.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=strain[0].keys())
        writer.writeheader()
        writer.writerows(strain)

    n_caps = []
    for density_fraction in (1.0, 0.1, 0.01):
        for r_nm in (10.0, 15.0, 20.0):
            expected_n = nitrogen_density_nm2 * density_fraction * math.pi * r_nm**2
            n_caps.append({
                "density_fraction_of_Kim_2025": density_fraction,
                "radius_nm": r_nm,
                "expected_N_atoms": expected_n,
                "P_at_least_one_N_if_Poisson": -math.expm1(-expected_n),
            })
    with (ROOT / "nitrogen_presence.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=n_caps[0].keys())
        writer.writeheader()
        writer.writerows(n_caps)

    summary = {
        "status": "conditional calculation only; no physical experiment or advantage claim",
        "T_K": temp_k,
        "kT_eV": kT,
        "D0_nm2_s_literature": d0,
        "anneal_s_literature": anneal_s,
        "unbiased_one_coordinate_rms_nm": math.sqrt(2 * d0 * anneal_s),
        "field_V_per_m_scenario": field,
        "E_drop_over_20nm_eV": field * length_nm * 1e-9,
        "bulk_modulus_GPa_literature": bulk_modulus_gpa,
        "atomic_volume_A3_scenario": vacancy_volume_a3,
        "K_times_one_atomic_volume_eV": bulk_modulus_times_vol_ev,
        "hydrostatic_2pct_linear_strain_energy_eV_if_one_atomic_volume":
            bulk_modulus_times_vol_ev * 0.06,
        "maximum_harmonic_well_radius_for_15nm_sigma_under_that_scenario_nm":
            15.0 * math.sqrt(2 * bulk_modulus_times_vol_ev * 0.06 / kT),
        "maximum_harmonic_well_radius_for_10nm_sigma_under_that_scenario_nm":
            10.0 * math.sqrt(2 * bulk_modulus_times_vol_ev * 0.06 / kT),
        "nitrogen_areal_density_nm_minus_2": nitrogen_density_nm2,
        "limitation": "No fitted V- diffusivity or defect relaxation volume; scenario values are not material measurements.",
    }
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
