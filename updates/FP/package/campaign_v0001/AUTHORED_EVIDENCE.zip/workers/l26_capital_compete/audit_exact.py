from fractions import Fraction as F


def zeros(m, n):
    return [[F(0) for _ in range(n)] for _ in range(m)]


def transpose(A):
    return [list(row) for row in zip(*A)]


def matmul(A, B):
    Bt = transpose(B)
    return [[sum((x * y for x, y in zip(row, col)), F(0)) for col in Bt] for row in A]


def subtract(A, B):
    return [[x - y for x, y in zip(row_a, row_b)] for row_a, row_b in zip(A, B)]


def diagonal(values):
    out = zeros(len(values), len(values))
    for i, value in enumerate(values):
        out[i][i] = value
    return out


def check_n713():
    Q = [[F(x, 16) for x in row] for row in [
        [-11, 3, 5, 3],
        [3, -11, 3, 5],
        [3, 5, -13, 5],
        [5, 3, 5, -13],
    ]]
    E = transpose([[1, 0, 1, 0], [0, 1, 0, 1]])
    R = diagonal([F(1, 4)] * 4)
    mu = [F(1, 2), F(1, 2)]
    M_inv = diagonal([1 / x for x in mu])
    QE = matmul(Q, E)
    L = matmul(M_inv, matmul(transpose(E), matmul(R, QE)))
    B = subtract(QE, matmul(E, L))
    Gamma = matmul(transpose(B), matmul(R, B))
    P = matmul(E, matmul(M_inv, matmul(transpose(E), R)))
    I = diagonal([F(1)] * 4)
    reverse_coupling = matmul(P, matmul(Q, subtract(I, P)))
    expected = [[F(1, 64), F(-1, 64)], [F(-1, 64), F(1, 64)]]
    assert L == [[F(-1, 2), F(1, 2)], [F(1, 2), F(-1, 2)]]
    assert Gamma == expected
    assert all(x == 0 for row in reverse_coupling for x in row)
    return L, Gamma, reverse_coupling


def check_n713_response_identity():
    Q = [[F(x, 16) for x in row] for row in [
        [-11, 3, 5, 3],
        [3, -11, 3, 5],
        [3, 5, -13, 5],
        [5, 3, 5, -13],
    ]]
    E = transpose([[1, 0, 1, 0], [0, 1, 0, 1]])
    R = diagonal([F(1, 4)] * 4)
    pi = [[F(1, 4)] * 4]
    QE = matmul(Q, E)
    C2 = matmul(transpose(E), matmul(R, matmul(Q, matmul(Q, E))))
    response_gram = zeros(2, 2)
    for a in range(2):
        indicator = [E[i][a] for i in range(4)]
        V = zeros(4, 4)
        for i in range(4):
            for j in range(4):
                if i != j:
                    V[i][j] = Q[i][j] * (indicator[j] - indicator[i]) / 2
            V[i][i] = -sum((V[i][j] for j in range(4) if j != i), F(0))
        time_second_derivative = matmul(V, Q)
        VQ_plus_QV = [[time_second_derivative[i][j] + matmul(Q, V)[i][j] for j in range(4)] for i in range(4)]
        for b in range(2):
            response_gram[a][b] = sum((pi[0][i] * VQ_plus_QV[i][j] * E[j][b]
                                       for i in range(4) for j in range(4)), F(0))
    rhs = matmul(transpose(QE), matmul(R, QE))
    assert subtract([[-2 * response_gram[i][j] - C2[i][j] for j in range(2)] for i in range(2)], rhs) == zeros(2, 2)
    return response_gram, C2, rhs


def check_n718():
    Q = [[F(x, 16) for x in row] for row in [
        [-11, 3, 5, 3],
        [3, -11, 3, 5],
        [3, 5, -13, 5],
        [5, 3, 5, -13],
    ]]
    nu = [F(1, 10), F(2, 10), F(3, 10), F(4, 10)]
    labels = [0, 1, 0, 1]
    gains = [
        [F(1), F(1, 2), F(1), F(2, 3)],
        [F(3, 2), F(1), F(2), F(1)],
        [F(1), F(2, 3), F(1), F(1, 2)],
        [F(2), F(1), F(3, 2), F(1)],
    ]
    weights = [F(14, 5), F(-175, 12), F(85, 4), F(-35, 3), F(11, 5)]
    assert sum(weights, F(0)) == 0

    omega = [[nu[i] * Q[i][j] for j in range(4)] for i in range(4)]
    residual = F(0)
    for i in range(4):
        for j in range(4):
            if i == j:
                continue
            v = F((1 if labels[j] == 0 else 0) - (1 if labels[i] == 0 else 0), 2)
            synthesized = sum((weights[u] * gains[i][j] ** u for u in range(5)), F(0))
            residual += omega[i][j] * (synthesized - v) ** 2

    E = transpose([[1 if label == a else 0 for label in labels] for a in range(2)])
    R = diagonal(nu)
    mu = [sum((nu[i] for i in range(4) if labels[i] == a), F(0)) for a in range(2)]
    M_inv = diagonal([1 / x for x in mu])
    QE = matmul(Q, E)
    L = matmul(M_inv, matmul(transpose(E), matmul(R, QE)))
    B = subtract(QE, matmul(E, L))
    Gamma = matmul(transpose(B), matmul(R, B))
    expected = [[F(5, 384), F(-5, 384)], [F(-5, 384), F(5, 384)]]
    assert residual == 0
    assert Gamma == expected
    return residual, Gamma


if __name__ == "__main__":
    L, Gamma_passive_pair, reverse_coupling = check_n713()
    response, passive_jet, recovered_gram = check_n713_response_identity()
    residual, Gamma_nonstationary = check_n718()
    print("N713 L:", L)
    print("N713 Gamma:", Gamma_passive_pair)
    print("N713 passive invariance P Q (I-P):", reverse_coupling)
    print("N713 active-response identity inputs:", response, passive_jet)
    print("N713 recovered ||Q E||^2 Gram:", recovered_gram)
    print("N718 product-polynomial residual:", residual)
    print("N718 nonstationary Gamma:", Gamma_nonstationary)
    print("all exact rational assertions passed")
