# Capital competition audit: hidden kinetics and active control

Date: 15 October 2026. Capital checkout inspected at `5ddabf53324159aa6c88e4fef3b75bc7b8b6c4ff` (the requested starting HEAD; clean). Scope: current dossiers for acquired operator representations, hidden-bath limits, channel information order, kinetic acquisition, and controlled prediction. The current worker reports for this campaign were not used.

The exact routes checked were `frontier/dossiers/N713.txt` (open `G-EC-N713-INDEPENDENT-REVIEW`), `N718.txt` (open `G-EE-N718-INDEPENDENT-REVIEW`), `N744.txt` (open `G-EN-N744-CAPABILITY` and `G-EN-N744-INDEPENDENT-REVIEW`), `N708.txt` (open `G-DZ-N708-REVIEW-AND-ACQUISITION`), `N721.txt` (open `G-EG-N721-REVIEW-AND-ACQUISITION`), `N772.txt` (open `G-EZ-N772-REVIEW` and `G-EZ-N772-CAPABILITY`), `N158.txt` (scoped blocker `B-AE-ARCHIVE-PREPARATION`), `N675.txt`/`N676.txt` (N675 is unreviewed; its reported hardness is conditional on the imported MIP*=RE construction), and `N180.txt` (open `G-THERMAL-SQRT-WINDOW`). Their source-derived and open-gate labels remain in force at the inspected revision.

Selected proof-bearing source bytes read: N713 `updates/EC/package/active_closure/recovered/astra_active_closure/proof_note.md` (SHA-256 `98a827bc6e911aa9b2d94015e77a520ebabe6708355a8742894330833ca2ff12`); N718 `updates/EE/package/genesis_intervention_products/astra_intervention_products/proof_note.md` (`0eed3af3b847667f3569fe470cf229c6014bf4b464ed52a65bc89085dae24f8a`); N744 `updates/EN/package/cray_flux_design/recovered/cray_flux_design/RESEARCH_NOTE.md` (`4ce59bec1e9b685ce3b6dff2383d3e78df3d680f3962ec1a4c2ade85c8bc6229`); N708 `updates/DZ/package/high_leverage_invention/outputs/high_leverage/rare_event/RESULT.md` (`993afb65a10fb76b23fde447112992825630cdbca46d8544894be54ec039d59b`); N721 `updates/EG/package/frontier_campaign/root/HIDDEN_CHANNEL_BOUND.txt` (`b65d66d38d5cd11024e88d4b3bca7657d3b569f52485cdc0d5c7c40a0fa53dae`); N772 `updates/EZ/package/source_spectrum/recovered/astra_source_spectrum/research_note.md` (`cca2871464dbedc23ba9cc7925921cc85bf17ae78678dc53626b34225939a207`).

## Finding

The strongest remaining non-quantum capability candidate is the N713→N718 family: acquire a quantitative strong-lumpability defect from visible data and use it to certify the error of a reduced feedback model. Its sharpest advantage is exact and narrow: passive observations can be identical for two hidden generators with different strong-lumpability defects, even with an infinite record. A label-aware active perturbation separates the four-state witness. N718 extends the measurement to unknown heterogeneous controls through a product-setting law.

This is a real information-access capability under its stated interface, not yet a demonstrated physical advantage. The exact product law, selective microscopic actuator or all-event sensor, repeatable preparation, rate bounds, and deployment-coverage condition are substantial. The closest published active test is the nonlinear fluctuation-dissipation test of Engbring et al.; it tests a different, weaker target. The closest algorithmic competitor when the generator is known is direct lumpability/coarse-graining analysis. No source here establishes that the active method beats the strongest experiment with matched active access, or that a physical actuator satisfies the model.

N744 is the closest capital result with a direct control-design output: a measured table compiles to a global LP and a confidence-valid regret bound. Its synthetic benchmark reports actual regret 0.0086 and a conditional certified bound 0.0369 after 4.4 million episodes. At the stated reset rate, expected assay duration alone is 4.4 million time units; preparation, calibration, reset/readout, and detector costs add to it. A full-generator occupation-measure LP is much faster once the model is supplied. Thus its possible advantage is access to optimization without receiving the hidden generator; no matched black-box baseline or physical system was demonstrated. The rare-pathway mixed-probe fixture still returns the vacuous upper bound 1 at 900,000 episodes.

## Exact best capability: N713 and N718

### Contract and output

For a finite CTMC with row generator (Q), a supplied partition into (k) visible labels, and repeatable preparation ν, let (E) contain the label indicators, (R=\operatorname{diag}(\nu)), (M=\operatorname{diag}(\nu E)), and

\[
L=M^{-1}E^T RQE,\qquad B=QE-EL,\qquad \Gamma_\nu=B^TRB.
\]

The matrix (L) is the averaged visible generator. The PSD matrix \(\Gamma_\nu\) is the weighted Gram matrix of within-label variation in aggregate exit rates. If every hidden state has positive \(\nu\)-mass, \(\Gamma_\nu=0\) iff the partition is strongly lumpable. With partial support the zero conclusion applies only \(\nu\)-almost everywhere. This is a model-adequacy output; it does not identify (Q).

N713 obtains this residual from stationary visible correlation and response jets under a specific geometric label-rate pulse. If (C_{ab}(t)=\mathbb E_\pi[e_a(X_0)e_b(X_t)]) and \(\chi_{ab}(t)\) is the response of the visible-label mean to a pulse conjugate to (e_a\), then

\[
\Gamma=-2\chi''(0)-C''(0)-A^TM^{-1}A,\qquad A=C'(0).
\]

The load-bearing actuator law is (q^h_{ij}=q_{ij}\exp(h(e_a(j)-e_a(i))/2)), with symmetric kinetic prefactors held fixed. The source also gives a fixed finite-amplitude extraction using rate multipliers (2,1/2,3/2,2/3); this avoids an infinitesimal-field oracle but still requires the stated microscopic action and sufficient time resolution.

N718 removes individual gain calibration, but replaces the geometric pulse by a different, stronger interface. Actual controls (K_u) must multiply each hidden transition rate by an unknown (g_u(i,j)\ge0); a separately runnable product setting must multiply by (g_u(i,j)g_v(i,j)). Sequentially running (K_u) then (K_v) is not the product interface. One must also either (S) guarantee all within-label gains equal one or (A) measure an activity bit for every microscopic jump. Rates in all used settings have supplied upper bounds.

Writing \(\omega_{ij}=\nu_iq_{ij}\), (v_a(i,j)=(e_a(j)-e_a(i))/2), the measured product responses give (H_{uv}=\sum\omega_{ij}g_u(i,j)g_v(i,j)); ordinary response gives (b_{a,u}=\sum\omega_{ij}v_a(i,j)g_u(i,j)); and the baseline gives (c_a=\sum\omega_{ij}v_a(i,j)^2), with the sums restricted to cross-label edges in version S and including all edges in version A. Therefore

\[
E_a(w)=w^THw-2b_a^Tw+c_a
      =\sum_{i\ne j}\omega_{ij}\left(\sum_u w_ug_u(i,j)-v_a(i,j)\right)^2\ge0.
\]

The control data themselves give a positive certificate for how well available gains synthesize the needed hidden edge field. The operation does not assume the gains are individually known. An \(\ell_1\) coefficient budget is essential: a nearly singular gain basis can have zero population residual but enormous coefficient and sampling costs. A gain collision across edges with different (v_a) leaves a strictly positive irreducible residual; increasing polynomial degree cannot remove it.

For nonstationary ν, the mixed-time correction is necessary. Set (T_{ab}=\nu QD_aQe_b), (C^{(2)}_{ab}=\nu D_aQ^2e_b), and (Z_{ub}=\nu K_uQe_b). The exact identity

\[
\langle Qe_a,Qe_b\rangle_\nu=T_{ab}-C^{(2)}_{ab}-2\nu V_aQe_b
\]

combined with a synthesized (V_a) recovers the predictive Gram matrix and hence \(\Gamma_\nu\). This also shows why the product response is not a generic appeal to linear response: it constructs a positive quadratic certificate over unknown edge gains.

If tested actions have defects (d_j=\operatorname{tr}\Gamma^j_\nu) and all deployed hidden marginals up to time (T) obey \(\mathcal L(X_t)\le C\nu\), the source claims

\[
\operatorname{TV}(P_{\rm hidden}^{\rm policy,[0,T]},P_{\rm reduced}^{\rm policy,[0,T]})
\le CT\sqrt{(k-1)\sum_jd_j}.
\]

For exact zero and full support, every tested action is strongly lumpable, so any well-posed visible-history policy using those actions has the exact reduced visible intensities. Unprobed actions are outside the theorem. The domination bound, preparation law, and sensor corrections are inputs or acquired conditions, not consequences of a small measured residual.

Finite samples do not prove exact zero. In the N718 source protocol, the derivative step and tolerance are

\[
\tau=\frac{\eta^2\rho^2}{10^6(p+1)k^4(1+W)^2},\quad
h=\frac{\tau}{100k},\quad
\beta=\frac{\tau h^2}{100k},
\]

with (O(p^2k^2\kappa^4\beta^{-2}\log(pk/(\zeta\beta)))) raw trials. Since \(\beta\) is cubic in \(\tau\), even the displayed accuracy factor is roughly \(\eta^{-12}\); the powers of (k,p,W,\rho^{-1},\kappa) are also steep. The source explicitly charges preparation, mixing if used, product-rate growth, sensor calibration, timing, and event access. This is a theorem-shaped resource bound, not an affordable-lab claim.

### Exact passive obstruction and active separation

The four-state witness in the N713 note has uniform stationary law, visible labels ((0,1,0,1)), and

\[
Q=\frac1{16}\begin{pmatrix}-11&3&5&3\\3&-11&3&5\\3&5&-13&5\\5&3&5&-13\end{pmatrix}.
\]

Its reduced generator is \(L=\bigl(\begin{smallmatrix}-1/2&1/2\\1/2&-1/2\end{smallmatrix}\bigr)\), but

\[
\Gamma=\frac1{64}\begin{pmatrix}1&-1\\-1&1\end{pmatrix},\qquad \operatorname{tr}\Gamma=1/32.
\]

The identity (P Q(I-P)=0) means the stationary projected path is the same two-state Markov chain as the strongly lumpable two-state model (L). Thus every passive statistic, at every horizon, is identical although one model has \(\Gamma=0\) and the other does not. The source gives an active pulse response

\[
\chi_Q(t)=1-e^{-t}-\frac{\epsilon^2}{2}[1-(1+t)e^{-t}],\qquad \epsilon=1/4,
\]

while the two-state model gives \(1-e^{-t}\). Their difference at (t=1) is \((1-2/e)/32\approx0.00826\). This is the strongest exact non-match found: no passive estimator can certify strong lumpability over a class containing this pair, even with unlimited samples.

I independently recomputed this witness and the N718 nonstationary example with rational arithmetic in [audit_exact.py](audit_exact.py). The check confirms (P Q(I-P)=0), the displayed (L,\Gamma), the N713 jet identity (-2\chi''(0)-C''(0)=(QE)^TR(QE)), and the N718 quartic product-gain synthesis residual is exactly zero with
\(\Gamma_\nu=(5/384)\bigl(\begin{smallmatrix}1&-1\\-1&1\end{smallmatrix}\bigr)\). This is an independent exact fixture check, not a reconstruction of all general proofs or a physical test.

## Strongest competitor and claim boundary

Cardelli et al. give an algorithm for lumpability under bounded, nondeterministic CTMC rate intervals. Those interval constraints are supplied model information, not acquired product-control data, so the paper is a useful uncertainty-aware baseline but does not close the N718 acquisition problem. [Cardelli et al., QEST 2021](https://doi.org/10.1007/978-3-030-85172-9_21).

**For known (Q), direct aggregation is the strongest baseline.** Compute each source state's rates into each visible block, compare them with (L_{ab}), and form \(\Gamma\) directly. It is exact and avoids acquisition. Classic strong lumpability conditions and modern quantitative coarse-graining assume a generator/model object; Hilder and Sharma's 2024 theorem constructs effective dynamics with error bounds from a CTMC, while N713/N718 target the case where the hidden generator is withheld. [Ball and Yeo, “Lumpability and marginalisability for continuous-time Markov chains” (1993)](https://doi.org/10.2307/3214762); [Hilder and Sharma, “Quantitative Coarse-Graining of Markov Chains”](https://doi.org/10.1137/22M1473996).

**For active black-box diagnostics, the closest published competitor is Engbring et al.** Their PRX 2023 nonlinear fluctuation-dissipation relation uses a finite-amplitude perturbation and observed stationary densities/response to test Markovianity, including a bristlebot experiment. The author manuscript describes the relation as necessary but not sufficient. I found no theorem in that paper that outputs the hidden-partition \(\Gamma\), certifies strong lumpability over all initial states, or bounds policy-uniform path error as above. Its experiment is also not the N713 microscopic geometric rate law or the N718 unknown-gain product law. This marks a difference in target and interface; it does not prove that no active experimental method could match the result. [Engbring et al., PRX 13, 021034 (2023)](https://doi.org/10.1103/PhysRevX.13.021034), [author manuscript](https://people.physik.hu-berlin.de/~lindner/PDF/Engbring_PhysRevX_2023.pdf).

**For N744 design, the known-generator occupation LP is decisive whenever (Q) is available.** The capital's own synthetic benchmark reports a full-model occupation LP solve of about 0.0057 s; the acquired workflow uses 4.4M episodes and expected assay duration of 4.4M time units before preparation/calibration overhead. Its possible use is when the transition generator is unavailable but source-selective controls and tagged-event counts exist. CTMDP occupation-measure linear programs are established prior art, so the candidate advance is the acquisition/certificate interface and its proof, not the LP. [Wei and Chen, “Continuous-time Markov Decision Processes with Finite-horizon Expected Total Cost Criteria”](https://arxiv.org/abs/1408.5497).

No general matched-access theorem or benchmark found in the inspected capital proves N713/N718 or N744 beats all strong black-box intervention-learning methods. The honest statement is conditional interface separation: passive data provably cannot do what N713's active geometric pulse does on its exact witness; N718 and N744 could add more if their physical interfaces are acquired and the certificates are nonvacuous.

## Capital candidates rejected as immediate leads

- **N708/N721, hidden route/capacity acquisition.** These are useful exact negative mathematics, not a new accelerator. In N708, (M=2^d) named local-rate queries hide one dominant corridor while the full stationary law, endpoints, topology, and all other rates are known. Relative mean-time estimation at 25% accuracy needs at least ((1-2\alpha)M) queries; route sampling is near (M); full first-passage-law approximation needs (q/M\ge1/2-12/M-2\delta). Querying all (M) channels and solving is an (O(M)) incumbent matching the lower-bound order. A sparse microscopic force or low-degree fit does not certify the effective kinetic response. A real opening requires an acquired globally valid representation with controlled elimination width, plus the acquisition and bit costs.
- **N721 path-flow certificate.** The cross-flux identities are classical variational/electrical principles; the proposed interval fails without full energy-measure support. On two parallel edges with (c=(1,M)), (u=(0,1)), and a unit flow (j=(1,0)), sampling (q_e\propto j_e\Delta_e) sees only the first edge and reports energy 1 while capacity is (1+M). The source's stronger incumbent is Berman–Konsowa, which already gives a path-flow lower bound at least as strong as the Thomson endpoint. No acquired global channel-coverage class was supplied. [Berman and Konsowa, SIAM J. Discrete Math.](https://doi.org/10.1137/0403026); [den Hollander and Jansen, Berman–Konsowa principle for reversible Markov jump processes](https://arxiv.org/abs/1309.1305).
- **N772 source-spectrum recursion.** The theorem assumes an actually supplied/proved operator inequality (T^*T\le g_a(TT^*+BB^*)), and the positive recursion certifies an abstract operator bound. The dossier explicitly lacks an acquired physical source comparison, tensor-rank bound, KLS theorem, or task speedup. Source rank, source words, inner products, and precision remain paid. This is not a cheap spectral-gap acquisition route.
- **N158 interacting archive.** Spectral spaces are acquired in the stated proof, but dense matrix dimension, setup, workspace, and output are charged and can be enormous. Apparatus, decoder, and preparation can be outside the retained-memory count; a known invariant may be reset; unknown multiplicity can encode a qubit. Internal results do not supply a practical sampler or preparation method.
- **N675/N676 complete information order.** The reported generic POVM hardness is still source-derived and unreviewed; N676's finite quadratic reference cutoff is an exact-decision theorem with no efficiency claim, and its hardness consequence depends on N675. These are mathematical classification candidates, not an operational scientific advantage. No quantum-response direction was reopened.
- **N180 thermal heat witness.** The all-separable-probe lower bound is a scoped critical bath result, not a complete separability law or finite-(N) guarantee. Its (c_w\approx0.3281137) is a witness crossing, not an intrinsic separability threshold. A physically usable collective protocol and matched quantum-metrology incumbent remain unspecified.

These dossiers remain source-derived and unreviewed at the inspected capital revision. The calculations above do not promote their general proofs, external priority, device feasibility, or novelty.

## Primary prior art checked

- Cardelli, Grosu, Larsen, Tribastone, Tschaikowski, and Vandin, “Lumpability for Uncertain Continuous-Time Markov Chains,” QEST (2021), [publisher DOI](https://doi.org/10.1007/978-3-030-85172-9_21), [author PDF](https://www.iris.santannapisa.it/retrieve/dd9e0b32-58f9-709e-e053-3705fe0a83fd/qest2021.pdf).
- Engbring, Boriskovsky, Roichman, and Lindner, “A Nonlinear Fluctuation-Dissipation Test for Markovian Systems,” *Physical Review X* 13, 021034 (2023), [publisher page](https://journals.aps.org/prx/abstract/10.1103/PhysRevX.13.021034), [author PDF](https://people.physik.hu-berlin.de/~lindner/PDF/Engbring_PhysRevX_2023.pdf).
- Ball and Yeo, “Lumpability and marginalisability for continuous-time Markov chains,” *Journal of Applied Probability* 30(3), 518–528 (1993), [publisher page](https://www.cambridge.org/core/journals/journal-of-applied-probability/article/abs/lumpability-and-marginalisability-for-continuoustime-markov-chains/52418B77E531D0733B6792D967E1BB6E), [DOI](https://doi.org/10.2307/3214762).
- Hilder and Sharma, “Quantitative Coarse-Graining of Markov Chains,” *SIAM Journal on Mathematical Analysis* 56 (2024), [publisher page](https://epubs.siam.org/doi/abs/10.1137/22M1473996), [arXiv](https://arxiv.org/abs/2201.10256).
- Berman and Konsowa, “Random Paths and Cuts, Electrical Networks, and Reversible Markov Chains,” *SIAM Journal on Discrete Mathematics*, [publisher page](https://epubs.siam.org/doi/abs/10.1137/0403026); den Hollander and Jansen, “Berman-Konsowa principle for reversible Markov jump processes,” *Markov Processes and Related Fields* 22, 409–442 (2016), [arXiv:1309.1305](https://arxiv.org/abs/1309.1305).
- Wei and Chen, “Continuous-time Markov Decision Processes with Finite-horizon Expected Total Cost Criteria,” [arXiv:1408.5497](https://arxiv.org/abs/1408.5497), for the established occupation-measure/LP comparator.

## Recommendation to the campaign

Treat N713/N718 as the best capability seed only if the campaign can name an actual system where label-directed interventions, product settings or all-event activity, repeatable starts, and rate/coverage bounds are experimentally observable. The decisive experiment should compare the active response and \(\Gamma\)-based path prediction against both the nonlinear-FDR diagnostic and a best-fit coarse Markov model on a predeclared hidden-state benchmark. Otherwise, retain the passive-equivalence result and use N708/N721 to reject under-acquired shortcuts. For N744, require a nonvacuous mixed-probe regret certificate at a budget measured in physical time, and compare against a black-box policy optimizer under the same access.
