#!/usr/bin/env python3
"""Reproduce the stated idealized neutrino-mass rate and error budgets.

Numbers are analytic illustrations, not a detector simulation or experiment.
All energies and momenta use eV and c=1; time uses years.
"""

import json
import math


def idealized_poisson_information(amplitude: float, q: float, cutoff: float):
    """Fisher information for theta=m^2 from lambda(w)=A(w^2-theta/2).

    At theta=0, w is the missing neutrino energy and cutoff <= w <= q.
    The second result profiles out unknown positive amplitude A.
    """
    if not (amplitude > 0 and q > cutoff > 0):
        raise ValueError("Require A>0 and Q>cutoff>0")
    known_a = amplitude * (1 / cutoff - 1 / q) / 4
    profiled_a = known_a - 3 * amplitude * (q - cutoff) ** 2 / (
        4 * (q**3 - cutoff**3)
    )
    return known_a, profiled_a


def missing_mass_events(energy: float, sigma_energy: float, sigma_momentum: float,
                        mass: float):
    """SNR-one N for the mean of measured m^2, with independent Gaussian errors.

    This excludes unknown bias and small quadratic-error terms. It is a
    benchmark for the specified measurement model, not a universal lower bound.
    """
    theta = mass**2
    p = math.sqrt(energy**2 - theta)
    sigma_theta = 2 * math.hypot(energy * sigma_energy, p * sigma_momentum)
    return sigma_theta, (sigma_theta / theta) ** 2


def main():
    mass = 0.05
    energy = 10_000.0
    sigma = 1.0
    sigma_theta, n = missing_mass_events(energy, sigma, sigma, mass)
    q_ag = 405.0
    branching = 3.07e-8
    delta = 1.0
    endpoint_fraction_ag = (delta / q_ag) ** 3
    useful_fraction_ag = branching * endpoint_fraction_ag
    parent_atoms = 1e9  # 10^12 cm^-3 in 1 mm^3; generous 2016 source scenario
    half_life_tritium_year = 12.32
    decay_per_year = parent_atoms * math.log(2) / half_life_tritium_year
    fi = {
        str(q): {
            "known_amplitude": idealized_poisson_information(1.0, q, delta)[0],
            "profiled_amplitude": idealized_poisson_information(1.0, q, delta)[1],
        }
        for q in (10.0, 405.0, 1_000.0)
    }
    assert fi["10.0"]["profiled_amplitude"] < fi["405.0"]["profiled_amplitude"]
    assert fi["405.0"]["profiled_amplitude"] < fi["1000.0"]["profiled_amplitude"]
    print(json.dumps({
        "model": "Independent Gaussian E_nu and parallel p_nu error; allowed-decay constant electron factor",
        "mass_eV": mass,
        "m_squared_eV2": mass**2,
        "bulk_neutrino_energy_eV": energy,
        "sigma_each_eV": sigma,
        "sigma_single_m_squared_eV2": sigma_theta,
        "events_for_SNR_one_if_unbiased": n,
        "tritium_atoms_in_example_source": parent_atoms,
        "tritium_decays_per_year_before_acceptance": decay_per_year,
        "years_at_example_source_before_acceptance": n / decay_per_year,
        "Ag110m_q_eV": q_ag,
        "Ag110m_branching_model_estimate": branching,
        "Ag110m_1eV_endpoint_fraction_of_branch_constant_factor": endpoint_fraction_ag,
        "Ag110m_1eV_endpoint_fraction_of_all_decays": useful_fraction_ag,
        "Ag110m_all_decays_per_one_1eV_window_event": 1 / useful_fraction_ag,
        "toy_poisson_FI_per_amplitude_with_1eV_cutoff": fi,
    }, indent=2))


if __name__ == "__main__":
    main()
