# Foundational opening: absolute neutrino mass without an endpoint bottleneck

**Status, 15 October 2026: NOT ACHIEVED.** I investigated whether event-by-event missing-mass reconstruction, then an ultra-low-Q redesign, can directly determine the effective electron-antineutrino mass near 50 meV with better complete-system resources than existing methods. Both operations have substantial prior art. The proposed advantage fails quantitative rate and resolution audits. The derivations below are scoped internal mathematics, not a novelty or physical-validation claim.

This was instructed independence, not enforced isolation: I initially read no other current workers' files. I read capital AGENTS.md and 00_START_HERE.txt for protocol orientation only. I changed no capital files.

## Scientific output and exact contract

The desired output is an independently calibrated laboratory determination or upper limit on the beta-decay parameter $m_\beta^2=\sum_i |U_{ei}|^2m_i^2$ at or below $(0.05\,\mathrm{eV})^2=0.0025\,\mathrm{eV}^2$, with stated confidence coverage and a standard weak-decay interpretation. Oscillation measurements determine mass-squared *differences*, so this absolute-mass output remains scientifically important. No such output was produced here.

The attempted input is a prepared tritium parent source; calibrated parent four-momentum, decay Q, electron and daughter-recoil four-momenta for *each matched event*; daughter charge and excitation state; detector response, efficiencies and backgrounds; and enough source decays. Isotope acquisition, source preparation and replenishment, cryogenics, fields, trapping, event matching, recoil scattering, source temperature, calibration, digitization, uncertainty, time, memory, power and heat belong in the resource bill. The matched competitor may use the same isotopes and calibration resources, including an atomic source. No neutrino state or source property is supplied free.

## Strongest existing comparators and prior art

- **Demonstrated direct incumbent:** KATRIN's tritium endpoint spectroscopy gave $m_\beta<0.45$ eV at 90% confidence from five campaigns, with 36 million recorded electrons in 259 measurement days and explicit background/systematic treatment [KATRIN Collaboration, Science 388, 180–185 (2025)](https://arxiv.org/abs/2406.13516). My source search found no verified newer direct limit; that is a search limit, not a claim that none exists.
- **Serious prospective direct route:** Project 8's cyclotron-radiation electron spectroscopy with atomic tritium targets about 40 meV sensitivity and addresses molecular final-state broadening. The 40 meV number is a goal, not an achieved result [Project 8 Collaboration](https://arxiv.org/abs/2203.07349).
- **Direct novelty challenge:** reconstructing missing mass from the electron and recoiling daughter was proposed decades ago for keV sterile neutrinos [historical proposal discussion, section D](https://inspirehep.net/files/4e63a3d9e2513b7cfc3e34a0da701a78). A detailed ColTRIMS analysis identifies source temperature, unobserved photons, recoil scattering, source luminosity and coincidences; for specified small-source schemes it estimates $10^6$–$10^8$ tritium decays/year [2016 review, pp. 162–163](https://lss.fnal.gov/archive/2016/pub/fermilab-pub-16-068-t.pdf). These are historical example designs, not a bound on all current designs.
- **Low-Q novelty challenge:** isotope selection, ionization tuning, and the near-independence of absolute endpoint event count from Q at fixed allowed nuclear matrix element are explicit in [Kopp and Merle, Phys. Rev. C 81, 045501 (2010), section III](https://arxiv.org/html/0911.3329v2). A measured ultra-low-Q candidate, $^{110}\mathrm{Ag}^m\to{}^{110}\mathrm{Cd}^*$, has $Q=405(135)$ eV. Its $2.23^{+5.24}_{-1.28}\times10^7$-year partial half-life and $3.07^{+4.16}_{-2.15}\times10^{-8}$ branching fraction are *calculations*, not measured branch rates [Ruotsalainen et al., Phys. Rev. Lett. 134, 172501 (2025)](https://arxiv.org/abs/2409.11203).
- Other serious routes include $^{163}$Ho electron-capture calorimetry and radiative neutrino-pair emission. The latter proposes prepared macroscopic coherence and must suppress electromagnetic backgrounds [example primary RENP paper](https://link.springer.com/article/10.1140/epjc/s10052-019-7430-z). Cosmological inferences target a related mass combination with greater model dependence. I did not perform full matched cost comparisons against every route; no universal dominance claim follows.

## Operation 1: fully reconstructed missing four-momentum

For a parent at rest in a definite known state, set $c=1$. Let $P,p_e,p_d$ be the parent, electron and daughter four-momenta. Then

\[
q=P-p_e-p_d,\qquad m_i^2=q^2=E_\nu^2-|\mathbf p_\nu|^2.
\]

This operation genuinely uses bulk decays only if four-momentum measurement is precise enough. Its first-order error is

\[
\delta m^2=2E_\nu\delta E_\nu-2\mathbf p_\nu\cdot\delta\mathbf p_\nu+O(|\delta q|^2).
\]

Take an **illustrative specified detector model** with independent, unbiased Gaussian 1 eV standard deviations in missing energy and in the component of missing momentum parallel to the neutrino. At neutrino energy 10 keV, the per-event standard deviation in $m^2$ is approximately $2\sqrt{2}\times10^4=2.83\times10^4\,\mathrm{eV}^2$. For $m=0.05$ eV, an unbiased mean needs

\[
N\approx\left(\frac{2.83\times10^4}{0.0025}\right)^2
 =1.28\times10^{14}
\]

fully matched events for signal-to-noise *one*. This excludes efficiency loss, non-Gaussian tails, missing photons, and systematic bias. The unknown bias in the light-cone deficit $E_\nu-|\mathbf p_\nu|$ must stay below $m^2/(2E_\nu)=1.25\times10^{-7}$ eV at 10 keV to avoid exceeding the entire target mass-squared signal. Correlated errors or a directly measured light-cone deficit can change this error model. This is a model-specific obstruction, not a universal measurement no-go theorem.

For a concrete source scale, $10^{12}$ tritium atoms/cm³ in 1 mm³ gives $10^9$ atoms. The [NNDC evaluated 12.32-year half-life](https://www.nndc.bnl.gov/ensnds/3/H/adopted.pdf) yields $5.63\times10^7$ decays/year before collection, within the historical study's quoted order of magnitude. The $1.28\times10^{14}$ coincidences would require $2.28\times10^6$ years from that one volume at 100% acceptance, stable source replenishment and zero dead time. Source scaling changes recoil time-of-flight, accidental-coincidence and scattering costs; I have not proved that all architectures are blocked.

A coherent-source repair also has a precise limit. If the outgoing state is $\sum_i U_{ei}^*|e,d;\nu_i\rangle$ and only electron/daughter observables are measured, tracing out orthogonal mass eigenstates leaves $\rho_{ed}=\sum_i|U_{ei}|^2\rho_{ed}^{(i)}$. Cross-mass interference terms vanish for a detector blind to the neutrino. Source coherence can alter each channel, but a claim based on a *relative phase between unobserved neutrino masses* needs another interaction/measurement path and its costs.

## Operation 2: compressing beta-decay Q

The redesign asks whether an ultra-low-Q allowed transition makes many more *absolute* mass-sensitive events. Let $T$ be electron kinetic energy, $w=Q-T$, and $\theta=m_\beta^2$. A simplified allowed beta spectrum is

\[
\frac{d\Gamma}{dT}
 = C\,p_eE_eF(Z,E_e)\,w\sqrt{w^2-\theta}.
\]

For sufficiently slow beta-minus electrons under strong Coulomb attraction, $F\propto1/v_e$, so $p_eE_eF$ is approximately constant over a low-Q branch. Absorb it into $A$. At $\theta=0$, $d\Gamma/dw=Aw^2$, hence

\[
\Gamma(0<w<Q)=\frac{AQ^3}{3},\qquad
\Gamma(0<w<\Delta)=\frac{A\Delta^3}{3},\qquad
\frac{\Gamma_{\rm tail}}{\Gamma_{\rm branch}}
 =\left(\frac{\Delta}{Q}\right)^3.
\]

Lowering Q increases the *fraction* of endpoint events as $Q^{-3}$ while slowing the branch as $Q^3$. At fixed $A$, the **absolute** near-endpoint event rate per parent stays $A\Delta^3/3$. This is known prior art in Kopp–Merle, derived here to expose the failed resource claim. Atomic exchange, screening, daughter excitations and changes of nuclear matrix element can change $A$ or the shape; lower background/systematics might still help a particular isotope.

A local information check gives the same result in a fixed-resolution idealization. Observe $w\in[\Delta,Q]$, where $Q>\Delta>m$, with known Q, perfect energy readout, and Poisson intensity $\lambda_\theta(w)=A(w^2-\theta/2)+O(\theta^2/w^2)$. At $\theta=0$, the Fisher information per unit exposure with known $A$ is

\[
I_{\theta\theta}
 =\frac{A}{4}\left(\frac1\Delta-\frac1Q\right).
\]

Fitting unknown $A$ as a nuisance gives

\[
I_{\theta\mid A}
 =\frac{A}{4}\left[
 \frac1\Delta-\frac1Q
 -\frac{3(Q-\Delta)^2}{Q^3-\Delta^3}
 \right].
\]

The second expression is nonnegative and cannot increase when reducing Q at fixed $A,\Delta$: it is the minimum weighted squared score residual, and adding a nonnegative observation interval cannot lower that minimum. This is a local theorem for the stated constant-electron-factor toy model. It is **not** a full Fisher comparison to KATRIN, whose electron factor, source strength, resolution and background differ.

For silver with $Q=405$ eV and an illustrative 1 eV endpoint window, this toy model gives a branch fraction $(1/405)^3=1.51\times10^{-8}$. Multiplying by the *calculated* branching fraction gives $4.62\times10^{-16}$ window events per all-isomer decay: about $2.16\times10^{15}$ total isomer decays per one window event before efficiencies. No silver mass measurement or acquired deployed source was found. The presently quoted 135 eV Q uncertainty is far above 50 meV; a proposed experiment must fit or independently calibrate its endpoint rather than hide that input.

## Decision and falsification gate

**NOT ACHIEVED.** Full-event missing-mass reconstruction is known and in the specified independent-1-eV-error source scenario requires about $1.28\times10^{14}$ matched coincidences plus sub-microelectronvolt control of bulk light-cone bias. Low-Q decay is known, and its endpoint-fraction gain alone does not increase the absolute event rate at fixed transition strength. Neither route delivers the output or a demonstrated resource advantage over KATRIN or Project 8.

A genuine continuation on the **same output** needs an *acquired* operation measuring the bulk light-cone deficit with controlled sub-µeV bias at a rate and complete cost competitive with atomic-tritium endpoint spectroscopy, or an independently measured low-Q branch with sufficiently high absolute mass-sensitive event rate and superior matched detector/background systematics. A simulation of mass extraction, attractive Q alone, or a conditional coherence argument does not cross this gate. Novelty and physical feasibility of any future repair remain UNKNOWN.

## Reproduction, access limits and claim ledger

Running Python 3 on [kinematic_audit.py](./kinematic_audit.py) reproduces [RESULTS.json](./RESULTS.json), including the arithmetic and an idealized Fisher-information table. It uses the standard library. It does not simulate a detector, calibrate a source, establish physical feasibility, or prove novelty. I accessed public abstracts/full HTML/PDF, not restricted experimental raw data or detector response files.

| Claim | Status |
|---|---|
| Direct 50 meV absolute-mass output | NOT ACHIEVED |
| Missing-four-momentum identity and local error expansion | DERIVED |
| $1.28\times10^{14}$ SNR-one coincidences | MODEL DEPENDENT, specified independent errors |
| Low-Q rate–fraction compensation | DERIVED WITH ASSUMPTIONS; KNOWN PRIOR ART |
| Silver $Q=405(135)$ eV | EXTERNAL MEASUREMENT REPORTED |
| Silver $3.07\times10^{-8}$ branch | EXTERNAL MODEL ESTIMATE, not measured |
| Superiority to strongest direct methods | NOT ESTABLISHED |
| New physical operation or validation | NOT ACHIEVED |
