#!/usr/bin/env python3
"""Dimensionless break-even calculation for scaffold-templated gap repair.

This is an explicit rate/error accounting model, not a fit to measured kinetics.
All rates are normalized to the effective pseudo-first-order repair rate of the
incumbent missing-staple exchange reaction. The script is intentionally stdlib
only so the reported table can be regenerated without external packages.
"""

from __future__ import annotations

import math


def pol_rate_ratio_for_faster_repair(gap_nt: int, binding_ratio: float) -> float:
    """Minimum v/lambda_exchange for lower mean time than strand exchange.

    Mean proposed repair time is 1/(k_bind[P]) + gap_nt/v. Mean incumbent
    time is 1/lambda_exchange. v is the polymerase extension rate in nt/time.
    """
    if gap_nt <= 0:
        raise ValueError("gap_nt must be positive")
    if binding_ratio <= 1.0:
        return math.inf
    return gap_nt / (1.0 - 1.0 / binding_ratio)


def pol_rate_ratio_with_ligation(gap_nt: int, binding_ratio: float,
                                  ligation_ratio: float) -> float:
    """Break-even extension ratio if a ligase step is required.

    This is a conservative extension of the core model. Structural repair by
    gap filling can leave a nick, so ligation is optional for the proposed
    operation and is not included in the main table.
    """
    if gap_nt <= 0:
        raise ValueError("gap_nt must be positive")
    remaining = 1.0 - 1.0 / binding_ratio - 1.0 / ligation_ratio
    if remaining <= 0:
        return math.inf
    return gap_nt / remaining


def max_per_base_error(total_bases: int, allowed_batch_error: float) -> float:
    """Exact independent-error threshold for a batch with no wrong bases.

    Solves (1-epsilon)**total_bases >= 1-allowed_batch_error.
    """
    if total_bases <= 0:
        raise ValueError("total_bases must be positive")
    if not 0.0 < allowed_batch_error < 1.0:
        raise ValueError("allowed_batch_error must lie strictly between 0 and 1")
    return 1.0 - (1.0 - allowed_batch_error) ** (1.0 / total_bases)


def main() -> None:
    print("Dimensionless mean-time break-even; lambda_exchange = 1")
    print("Assumed polymerase binding ratio k_bind[P]/lambda_exchange = 100")
    print("gap_nt  required_v/lambda_exchange  required_v_if_lambda_exchange=0.01/s (nt/s)")
    for gap_nt in (10, 20, 30, 60):
        ratio = pol_rate_ratio_for_faster_repair(gap_nt, 100.0)
        print(f"{gap_nt:6d}  {ratio:27.6f}  {ratio * 0.01:43.6f}")

    print("\nOptional ligation sensitivity; binding ratio=100, ligation ratio=10")
    print("gap_nt  required_v/lambda_exchange")
    for gap_nt in (10, 20, 30, 60):
        ratio = pol_rate_ratio_with_ligation(gap_nt, 100.0, 10.0)
        print(f"{gap_nt:6d}  {ratio:27.6f}")

    print("\nIndependent polymerase misincorporation ceiling for >=99% exact batch")
    print("total_inserted_bases  max_effective_error_per_base")
    for total_bases in (100, 1_000, 10_000):
        epsilon = max_per_base_error(total_bases, 0.01)
        print(f"{total_bases:20d}  {epsilon:27.9g}")


if __name__ == "__main__":
    main()
