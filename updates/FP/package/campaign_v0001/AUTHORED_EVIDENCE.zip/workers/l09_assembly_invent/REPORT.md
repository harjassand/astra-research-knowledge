# L09 — Scaffold-templated repair of molecular assembly defects

**Status:** candidate operation identified; capability advantage and novelty remain **UNKNOWN**. No wet-lab work was performed. The strongest obstacle is prior art: polymerase gap filling already synthesizes origami complements in situ, while DNA-origami self-healing already repairs unknown staple damage using excess matching staples. The proposed delta is to use that gap-fill chemistry as damage-triggered repair without supplying the missing site-specific oligos. That delta is plausible but untested.

## Target output and why it matters

Target: restore structural continuity in a folded DNA-origami object after an unknown *vacancy* removes one unmodified, linear staple interval, without imaging the object or identifying the vacancy's sequence address externally. A production line would benefit if one common repair bath could restore many defective objects without maintaining or dosing a high-concentration, design-specific library of all possible repair staples.

This is a narrow DNA-nanostructure operation. It does not claim atom-by-atom construction of arbitrary materials. It targets a costly known limitation of present origami use: staple damage can be partly self-healed with free staples, while rapid degradation and scaffold damage remain problems.

## Proposed operation: scaffold-templated, gap-addressed polymerase repair

For an eligible missing staple interval of length `ell`, the intact scaffold supplies the exact complementary base sequence. If a retained neighboring staple exposes a correctly oriented 3'-OH primer at one boundary, and a retained duplex blocks polymerase at the far boundary, then an ordinary DNA polymerase can extend the primer along the exposed scaffold template. The vacancy itself supplies the local address: the enzyme has a primer-template substrate only where complement coverage is absent. Polymerization consumes dNTPs and copies the scaffold sequence. The resulting strand may terminate in a nick beside the retained staple; ligation can be added if the required output demands a continuous backbone, at extra ATP/NAD+ and enzyme cost.

The exact eligibility condition is restrictive. The scaffold bases across the interval must remain intact and continuous; the gap must be a contiguous template run; an accessible 3'-OH must face into it; extension must not have to create a missing staple crossover, chemical modification, docking label, or other sequence-discontinuous feature. Adjacent missing intervals must still leave a primed flank. Use a polymerase whose extension and strand-displacement behavior is compatible with the packed origami geometry. A proofreading polymerase is a plausible writer, but its effective error rate and completion probability must be measured in the actual geometry.

The sequence recovery is exact at the abstract chemistry level: if `s_i` is the scaffold base at position `i`, the required complement is `comp(s_i)`. An extension over `i=a,...,b` creates `comp(s_b)...comp(s_a)` from the boundary primer. This recovers the sequence without an external position map. It does not establish that an enzyme can traverse every chosen origami geometry.

## Input/output/resource contract

**Inputs:** folded origami with intact scaffold and qualifying missing staple interval(s); polymerase with compatible buffer and divalent ion; four dNTPs. Optional ligase and cofactor are required only for backbone sealing. No fluorescence readout, microscopy, per-vacancy label, or repair-oligo library is an input to the proposed local reaction.

**Output:** polymerase-extended complement across each successful eligible gap. The structural pass criterion must be specified by the application (for example, recovery of a chosen shape or function); sequence copying alone is not product validation.

**Material and energy:** for `B` copied bases, the repair consumes `B` dNTP molecules stoichiometrically and dissipates their triphosphate free energy; enzymes, buffer, salts, temperature control, incubation, purification, and failed reactions count. Optional ligation consumes one activated cofactor per nick under the chosen ligase chemistry. The incumbent also pays upstream synthesis for replacement staples and may discard a large excess. At the reported 300-fold dose, each target vacancy receives 300 replacement-strand equivalents, or 299 equivalents beyond one incorporated strand; this is an experimental condition, not a proven lower bound for the incumbent. Both routes ultimately provide roughly `B` new complementary nucleotide residues per fully repaired object. This work therefore establishes no full-energy advantage. It only identifies a possible reduction in custom-oligo inventory and excess repair-strand dosing; that is an economic/process hypothesis, not a demonstrated physical-energy reduction.

## Strongest incumbent and prior art

Scheckenbach et al. demonstrated structural self-healing of DNA origami with excess matching staple strands. A 12-helix-bundle nanoruler with nine deliberately omitted central staples was treated at 50 °C followed by slow cooling with a 300-fold excess of the missing staples. The defective fraction fell from 63% to 32% by AFM classification and from 72% to 38% by DNA-PAINT classification. In 0.2% fetal bovine serum, a full set of matching staples at 5 μM total (22.5 nM per staple) preserved the three-mark fraction at 76% after 11 days; at 10% serum the specific self-healing advantage disappeared and matching and nonmatching DNA gave comparable stabilization. This is a strong incumbent for unknown staple vacancies and presently has direct random-damage evidence. [Primary paper, open full text](https://doi.org/10.1002/anie.202012986)

The central chemistry is already established: Agarwal et al. deliberately designed single-stranded scaffold gaps and used DNA polymerase to make their complementary sequences in situ. They report a T4 DNA-polymerase gap-fill reaction completed in under three minutes and fewer required synthetic staples. Their work supports attainable synthesis and a possible reagent-supply advantage, but it studies designed gaps/shape transitions rather than random post-assembly vacancy repair. [Primary paper and abstract](https://doi.org/10.1021/acsnano.7b08345)

Yan et al. also used DNA polymerase, exonuclease, and ligase to create local-to-global state changes in DNA nanostructures. This establishes additional enzyme addressability in folded origami; it does not demonstrate the proposed unknown-vacancy repair operation. [Primary paper](https://doi.org/10.1093/nar/gkaa488)

Thus the broad concepts “DNA-origami self-healing,” “polymerase gap filling,” and “enzyme-driven origami reconfiguration” are not novel here. The only possible contribution is a design-and-process combination that makes *unanticipated missing linear staples* into usable polymerase substrates so a common enzyme/dNTP bath can repair them without a sequence-specific replacement pool. Novelty is **UNKNOWN** pending a focused priority search and experiment.

## Exact rate and fidelity conditions

Let `lambda_s` be the effective pseudo-first-order repair rate for incumbent staple exchange at the actual concentration and geometry. Let `k_b[P]` be the polymerase binding rate to a primed vacancy, `v` its successful extension speed in bases/time, `ell` the vacancy length, and `epsilon` the effective per-base misincorporation probability after any proofreading. Ignoring dissociation, enzyme competition among vacancies, structural failure, and diffusion limitation, a mean-time model gives

`T_poly = 1/(k_b[P]) + ell/v`, while `T_staple = 1/lambda_s`.

Writing `alpha = k_b[P]/lambda_s` and `beta = v/lambda_s`, polymerase repair is faster in this model exactly when `1/alpha + ell/beta < 1`. If ligation is required and its pseudo-first-order rate is `k_l[L]`, add `1/gamma`, where `gamma = k_l[L]/lambda_s`, to the left side. This is a break-even condition, not a rate prediction: none of these rates were measured for random vacancies in origami.

If `B` bases are synthesized and independent effective base errors are assumed, batch exactness is `(1-epsilon)^B`. To obtain batch exactness at least `1-delta`, the writer must satisfy `epsilon <= 1-(1-delta)^(1/B)`. At a 1% batch-error allowance, this requires effective error at most `1.005e-5` per base for 1,000 copied bases and `1.005e-6` for 10,000 bases. Correlated failures, incomplete extension, wrong-primer extension, and whole-object structural loss make this optimistic bound stricter, not looser.

`gap_repair_break_even.py` computes these dimensionless break-even and fidelity bounds. Its default `alpha=100` and the example `lambda_s=0.01 s^-1` are illustrative scaling choices, not empirical estimates. Under those choices, the mean-time condition requires `v > 0.202 nt/s` for a 20-base gap; requiring ligation with `gamma=10` raises it to `0.225 nt/s`. A rate advantage only matters if the geometry, processivity, and batch error constraints also pass. The script output is in `model_output.txt`.

## Claim ledger

| Claim | Status | Evidence or missing gate |
|---|---|---|
| Polymerase can fill designed DNA-origami scaffold gaps | **Source-reported** | Agarwal et al. report <3 min optimized fill; these were designed gaps. |
| Missing staples can be repaired in assembled origami with excess matching staples | **Source-reported** | Scheckenbach et al.; quantified repair/stabilization with stated conditions. |
| A missing linear staple can in principle expose a primed, template-addressed site | **Conditional derivation** | Requires retained, correctly oriented primer, intact continuous scaffold, and compatible access. |
| Common polymerase bath repairs random unknown staple vacancies at high yield | **UNKNOWN** | No physical experiment; crossovers and tight origami geometry are open. |
| The operation beats incumbent throughput | **UNKNOWN** | Need same-design time-course and concentration series; symbolic rate thresholds only. |
| The operation lowers total energy | **Not established** | dNTP hydrolysis, enzyme production, cofactor, buffer, temperature, and purification were not balanced against oligo synthesis and its excess. |
| Novelty | **UNKNOWN** | Neighboring gap-fill and self-healing capabilities are published. |

## Decisive next experiment

Use one 2D or wireframe origami with at least 20 mechanically equivalent, contiguous non-crossover staple intervals and deliberately omit a randomized subset after folding. Keep the scaffold intact. Randomize which intervals are omitted without telling the analyst running the repair; split matched aliquots across: (a) polymerase + dNTP, (b) 300× matching missing-staple pool at the published 50 °C/slow-cool protocol, (c) polymerase without dNTP, and (d) buffer only. Quantify exact fill at each site by strand-specific sequencing or mass-tagged sequencing plus independent morphology/function readout. Include intact structures plus polymerase/dNTP to measure false extension and damage. Sweep enzyme and dNTP dose to stoichiometric plus modest excess. Measure time to 50% and 90% recovered sites, per-base misincorporation, unfilled fraction, aggregation, and total nucleotide/cofactor consumption. The operation clears the first gate only if the unknown locations are repaired with no site-specific oligo, high batch correctness, and equal or better output quality. The full-energy claim additionally needs a process-level ledger that includes polymerase/ligase production and purification.

## Access and evidence limits

- Scheckenbach et al. full text was accessible through PMC; exact quantified conditions and limitations are summarized above.
- Agarwal et al. publisher abstract and bibliographic metadata were accessible; publisher lists supplementary design files, but I did not retrieve the full paid article or test files.
- Yan et al. DOI/abstract metadata were accessible; no full kinetic/resource ledger was extracted.
- No data were downloaded, no wet-lab operation was performed, and no public claim of novelty or practical advantage is justified.
