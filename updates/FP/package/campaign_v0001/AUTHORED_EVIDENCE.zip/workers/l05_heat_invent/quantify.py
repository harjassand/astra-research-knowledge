#!/usr/bin/env python3
"""Reproducible scale checks for the candidate polariton heat bus.

The spectral overlap is a design screen, not a coupling calculation.
The SiO2 nanoribbon numbers are an empirical throughput benchmark from a
different material and temperature, not a prediction for alpha-MoO3/GaN.
"""

from math import ceil

C = 299_792_458.0  # m s^-1
H = 6.626_070_15e-34  # J s
EV = 1.602_176_634e-19  # J


def spectroscopic_units(wavenumber_cm: float) -> tuple[float, float]:
    frequency_hz = C * 100.0 * wavenumber_cm
    energy_ev = H * frequency_hz / EV
    return frequency_hz, energy_ev


def main() -> None:
    # alpha-MoO3 first Reststrahlen band and wurtzite-GaN LO Raman lines.
    rb1 = (545.0, 850.1)  # cm^-1
    gan_lo = (735.0, 742.0)  # cm^-1: A1(LO) through E1(LO)
    rb1_hz = tuple(spectroscopic_units(v)[0] for v in rb1)
    rb1_ev = tuple(spectroscopic_units(v)[1] for v in rb1)
    gan_hz = tuple(spectroscopic_units(v)[0] for v in gan_lo)
    gan_ev = tuple(spectroscopic_units(v)[1] for v in gan_lo)
    overlap = (max(rb1[0], gan_lo[0]), min(rb1[1], gan_lo[1]))
    assert overlap[0] <= overlap[1]

    # Published SiO2 surface-phonon-polariton nanoribbon benchmark:
    # k_app=2.14 W m^-1 K^-1; 34% above bulk; t=22 nm, W=0.93 um,
    # L=49 um, measured at 550 K.
    k_app = 2.14
    enhancement = 1.34
    k_bulk = k_app / enhancement
    t = 22e-9
    width = 0.93e-6
    length = 49e-6
    area = t * width
    g_total = k_app * area / length
    g_increment = (k_app - k_bulk) * area / length
    delta_t = 100.0
    q_total = g_total * delta_t
    q_increment = g_increment * delta_t
    n_total_for_1w = ceil(1.0 / q_total)
    n_increment_for_1w = ceil(1.0 / q_increment)

    t_hot, t_sink = 400.0, 300.0
    exergy_fraction = 1.0 - t_sink / t_hot

    print(f"alpha-MoO3 RB1: {rb1[0]:.1f}-{rb1[1]:.1f} cm^-1; "
          f"{rb1_hz[0]/1e12:.3f}-{rb1_hz[1]/1e12:.3f} THz; "
          f"{rb1_ev[0]*1e3:.2f}-{rb1_ev[1]*1e3:.2f} meV")
    print(f"GaN LO lines: {gan_lo[0]:.1f}-{gan_lo[1]:.1f} cm^-1; "
          f"{gan_hz[0]/1e12:.3f}-{gan_hz[1]/1e12:.3f} THz; "
          f"{gan_ev[0]*1e3:.2f}-{gan_ev[1]*1e3:.2f} meV")
    print(f"spectral intersection: {overlap[0]:.1f}-{overlap[1]:.1f} cm^-1")
    print(f"SiO2 SPhP benchmark G_total: {g_total*1e9:.3f} nW/K")
    print(f"SiO2 SPhP benchmark G_increment over bulk: {g_increment*1e9:.3f} nW/K")
    print(f"at deltaT={delta_t:.0f} K: total {q_total*1e9:.1f} nW; "
          f"increment {q_increment*1e9:.1f} nW per channel")
    print(f"arithmetic channels for 1 W at deltaT={delta_t:.0f} K: "
          f"{n_total_for_1w:,} (total) or {n_increment_for_1w:,} "
          f"(increment only)")
    print(f"1 W at {t_hot:.0f} K to {t_sink:.0f} K has at most "
          f"{exergy_fraction:.1%} Carnot work potential; a passive heat bus "
          "does not extract that work")


if __name__ == "__main__":
    main()
