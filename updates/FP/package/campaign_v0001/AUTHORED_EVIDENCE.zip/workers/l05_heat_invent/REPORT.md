# L05 — Polariton heat-bus for a hot GaN drain

## Finding

I investigated a static mode-matched heat-export path for a GaN high-electron-mobility transistor (HEMT): couple the drain hot spot into an anisotropic phonon-polariton guide, carry that energy laterally to a deliberately lossy terminal bonded to the package heat sink, and measure the energy delivered there. The physical opening is the mismatch between hot optical/near-field energy generated at a nanoscale drain and the slow, local acoustic-phonon route that ordinarily spreads it. A polariton guide could in principle route energy before it thermalizes into that local diffusive channel.

This is a concrete assembly of demonstrated ingredients, not a novelty-cleared operation. The closest papers already establish near-field hot-source-to-polariton transfer, polariton heat-waveguides, and α-MoO₃/GaN interface modes. The proposed end-to-end device is untested, and the strongest measured waveguide throughput is far too small for a high-power HEMT at the demonstrated geometry. No capability advantage is established; mission status is **NOT_ACHIEVED**.

## Contract and proposed mechanism

**Input.** A powered GaN HEMT with a drain-side hot region and a measured mode-resolved nonequilibrium distribution (n_s(\omega,\mathbf{k},t)), together with a remote package sink at (T_0). The candidate targets the GaN longitudinal-optical phonon window around 735–742 cm⁻¹ (about 22 THz, 91–92 meV) and near-field emission from the hot drain/contact.

**Operation.** Place an oriented α-MoO₃ strip at the drain-side interface. Its first Reststrahlen band spans 545–850 cm⁻¹ and therefore covers the GaN LO lines. Its anisotropic HPhP dispersion is oriented to carry the coupled mode laterally along the strip. Terminate the strip in a mode-matched lossy absorber bonded to the package sink, so guided energy becomes ordinary lattice heat at a remote, larger-area contact. No temporal modulation is used: the intended channel is passive and energy conserving, with no pump work or frequency lift.

The transport contract is an end-to-end heat current, not a temperature change at the source alone. In a linearized mode picture,

\[
\dot Q_{s\to 0}=\sum_m\int \frac{d\omega}{2\pi}\,\hbar\omega\,\mathcal T_m(\omega)
\big[n_s(\omega)-n_B(\omega,T_0)\big],
\]

where \(\mathcal T_m\) includes source-to-guide coupling, propagation survival, and terminal absorption. For a nonequilibrium source, \(n_s\) must be measured or acquired from a validated device model. The target output is lower drain peak temperature and increased energy delivered to the package sink at the same footprint, RF/electrical load, and sink temperature.

**Full resource boundary.** Charge GaN/α-MoO₃ interface preparation, crystal-axis registration, polariton-guide and terminal fabrication, MoO₃ adhesion and survival through HEMT processing, added footprint, defects and edge scattering, mode overlap and spectral selectivity, thermal contact to the package, and the complete device’s electrical input. The proposed passive channel has no modulation-power cost; it still destroys exergy when it dumps heat. At (T_h=400\,\mathrm K) and (T_0=300\,\mathrm K), one joule of heat has at most 25% of its energy as work potential. This heat bus extracts none of that work: it only transfers heat. Its entropy production for a heat amount (Q) dumped from (T_h) to (T_0) is (Q(1/T_0-1/T_h)), with exergy destruction (T_0Q(1/T_0-1/T_h)). Any later device-level comparison must include all source, sink and package paths.

## Why this mechanism is physically plausible

1. Hutchins et al. experimentally observed transient transfer from a pumped 50 nm Au pad into hBN hyperbolic phonon-polaritons. Their spectral and timing controls support a near-field radiative channel across an all-solid interface. The early-time signal was tens of picoseconds; the authors’ three-temperature fit used an assumed 500 MW m⁻² K⁻¹ Au-to-polariton TBC. That number is a fitted model parameter, not an independently measured conductance for a GaN device.
2. α-MoO₃ supports an anisotropic HPhP band from 545 to 850 cm⁻¹. Primary GaN Raman measurements place A₁(LO) at 735 cm⁻¹ and E₁(LO) at 743 cm⁻¹, so the candidate has a real frequency overlap. Frequency overlap alone does not establish polarization, momentum, or energy-transfer probability.
3. Hybridized hyperbolic surface phonon-polaritons have already been demonstrated at α-MoO₃ interfaces with polar dielectrics including GaN. That makes the proposed coupling route materially plausible and makes broad novelty claims untenable.
4. A separate experiment measured surface-phonon-polariton conduction in SiO₂ nanoribbon guides over roughly 50–100 μm and showed that guide geometry and terminal absorption control whether the energy reaches the load. This is evidence for the waveguide component, but not for α-MoO₃/GaN or a transistor heat sink.

The proposed advance would be the *end-to-end* operation: harvest a device’s own hot drain modes, propagate them through a mode-matched in-plane route, and absorb them at a remote package contact. No retrieved paper demonstrates that whole chain in an operating HEMT. The ingredients are close enough that novelty remains **UNKNOWN** pending a broader search and specialist review.

## Decisive quantitative screen

The executable [quantify.py](quantify.py) converts the cited wavenumbers and reconstructs the thermal conductance scale of the closest measured polariton waveguide. It returns:

- α-MoO₃ first band: 16.34–25.49 THz, or 67.6–105.4 meV.
- GaN LO modes: 22.04–22.25 THz, or 91.1–92.0 meV; both fall inside that band.
- For the measured SiO₂ guide with (t=22\) nm, (W=0.93\) μm, (L=49\) μm, and apparent (k=2.14\) W m⁻¹ K⁻¹ at 550 K, (G=kWt/L=0.894\) nW K⁻¹. This corresponds to 89 nW at a 100 K temperature difference.
- The paper reports this conductivity as 34% above the SiO₂ phonon limit. The inferred excess is 0.227 nW K⁻¹, or 22.7 nW at 100 K. A purely arithmetic scale-up to 1 W at 100 K would require about 11.2 million identical guides for the full measured conductance, or 44.1 million guides for the polariton increment alone. These are not feasible-device predictions: the guide is SiO₂ at 550 K, channel independence fails at scale, and α-MoO₃/GaN transport is unknown. They show that the current measured guide is a throughput warning, not a demonstrated high-power cooler.

The bottleneck shifts from launching energy into the guide to carrying and absorbing enough energy at the far end. The Au–hBN paper’s fitted 500 MW m⁻² K⁻¹ entrance parameter cannot fix this mismatch; using it as the full-device conductance would omit the guide and terminal resistances. At a 1 μm² source interface and 100 K difference it would correspond to 50 mW, while the measured SiO₂ guide geometry carries only tens of nanowatts. That cross-paper comparison is illustrative only, not an apples-to-apples material prediction.

The series path must satisfy

\[
G_{\rm net}^{-1}=G_{\rm source}^{-1}+G_{\rm guide}^{-1}+G_{\rm terminal}^{-1}+G_{\rm package}^{-1}.
\]

An excellent source interface cannot overcome a nW K⁻¹ guide. Higher-density parallel waveguides, shorter paths, stacked slabs, or more strongly absorbing terminals may change this scaling, but each changes the footprint, mode leakage, and fabrication cost. None has yet been calculated or measured for the candidate materials.

## Strongest competitor and closest prior art

For a high-power GaN transistor, the strongest practical comparator is an optimized GaN-on-diamond or GaN-on-SiC heat-spreader stack with a low-resistance bonding/interlayer design, evaluated at matched die, package, heat load, and sink conditions. Diamond integration and its interface limits are established; the α-MoO₃/PhP link must show a net peak-temperature or safe-duty-cycle advantage after counting its own interface, guide, and terminal resistances. A GaN/InGaN/GaN quantum-well result also engineered emitted interface phonons to favor faster-moving modes, a close competitor in hot-phonon handling.

The 2025 Au–hBN experiment already demonstrates early-time polaritonic heat extraction at a solid interface; the 2023 SiO₂ nanoribbon work already demonstrates a polariton thermal guide; and the 2021 α-MoO₃/GaN study already demonstrates hybridized interface modes. Therefore the candidate is not a new underlying carrier or a new thermodynamic cycle. Its only unestablished claim is a practical system-level combination that achieves useful exported heat current in a device footprint.

Time-modulated radiative-transfer designs were not selected. A 2026 Floquet theory already treats their frequency-conversion sidebands as active modulation. For an event that shifts frequency by \(\Omega\), the actuator exchanges \(\hbar\Omega\) per converted quantum; that work belongs in the input ledger. A sideband-enhanced radiative flux is not a free heat-removal gain. The passive guide avoids that particular cost but remains limited by transmission and absorption.

## Decisive next experiment / fail conditions

Build matched GaN HEMT test coupons: (A) α-MoO₃ guide aligned to the drain, (B) same stack with the crystal axis rotated to suppress propagation toward the sink, (C) the same polar dielectric without a guide, and (D) optimized diamond/SiC reference. Put a calibrated lossy sink at the guide end and measure both drain transient and terminal calorimetric power under identical pulsed and steady electrical loads. Acquire mode-resolved source occupation, source-to-guide coupling, end-to-end transmission, terminal absorption, and package parasitics. Use spectral detuning and polarization controls to establish that any differential energy current is carried by the proposed polariton mode.

Fail the capability claim if the sink does not receive more energy than the matched controls, if drain cooling is only a local redistribution into the nearby crystal, if the guide conductance remains orders below the matched substrate route, if an effect requires external optical pumping, or if the device loses enough area/electrical performance to erase the thermal benefit. A temperature dip at the source alone is not a successful output.

## Claim ledger

| Claim | Status | Evidence or missing item |
|---|---|---|
| GaN LO energy lies inside α-MoO₃ HPhP band 1 | **Established spectroscopic overlap** | Published Raman and dielectric-band values; computed unit conversions in `quantify.py`. |
| GaN/α-MoO₃ hybridized surface polaritons exist | **Established adjacent physics** | 2021 Nano Letters interface study; it is not a thermal-load experiment. |
| A transient hot metal source can transfer energy to HPhPs in a solid interface | **Experimentally demonstrated in a different system** | 2025 Au/hBN experiment; operating HEMT source distribution and steady-state rate remain unmeasured. |
| A polariton can carry measurable heat along a waveguide to a sink | **Experimentally demonstrated in SiO₂ at 550 K** | 2023 nanoribbon study; measured guide throughput is sub-nW K⁻¹ at the listed narrow geometry. |
| The assembled GaN/α-MoO₃ heat bus lowers drain peak temperature at fixed load and footprint | **UNKNOWN / untested** | Requires matched transistor experiment and end-to-end calorimetry. |
| The operation beats optimized GaN-on-diamond/SiC at full-system cost | **UNKNOWN** | No matched thermal resistance, reliability, area, or electrical-performance comparison. |
| Novelty or civilization-scale significance | **UNKNOWN / not established** | Mechanistic ingredients are already in the literature; only system-level operation is untested. |

## Sources and access limits

- W. Hutchins et al., “Ultrafast evanescent heat transfer across solid interfaces via hyperbolic phonon–polariton modes in hexagonal boron nitride,” *Nature Materials* 24 (2025), https://doi.org/10.1038/s41563-025-02154-5. Full paper and source data were accessible; its 500 MW m⁻² K⁻¹ value is a fit assumption for Au–hBN, not measured GaN performance.
- L. Li et al., “Low-dimensional heat conduction in surface phonon polariton waveguide,” *Nature Communications* 14 (2023), https://doi.org/10.1038/s41467-023-43736-8. Full paper and data availability statement were accessible; the measured guide is SiO₂, with suspended geometry and engineered absorbers.
- Q. Zhang et al., “Hybridized Hyperbolic Surface Phonon Polaritons at α-MoO₃ and Polar Dielectric Interfaces,” *Nano Letters* (2021), https://doi.org/10.1021/acs.nanolett.1c00281. The abstract and supporting-information listing were accessible; this supports polariton mode existence, not heat conduction.
- T. Azuhata et al., “Polarized Raman spectra in GaN,” *Journal of Physics: Condensed Matter* 7 (1995), https://doi.org/10.1088/0953-8984/7/10/002. Abstract/metadata were accessible; it reports A₁(LO)=735 cm⁻¹ and E₁(LO)=743 cm⁻¹.
- Shuichi Hiza et al., “Development of GaN-HEMT using a diamond substrate as a heat spreader,” *Oyo Buturi* 90 (2021), https://doi.org/10.11470/oubutsu.90.3_167. Abstract and summary were accessible.
- “Confined and interface optical phonon emission in GaN/InGaN double barrier quantum well heterostructures,” 2019, https://pmc.ncbi.nlm.nih.gov/articles/PMC6472874/. Search-indexed abstract was accessible; the primary article endpoint challenged direct opening in this session.
- R. Messina and P. Ben-Abdallah, “Many-body Floquet theory for radiative heat transfer in time-modulated systems,” *Physical Review B* 113 (2026), https://doi.org/10.1103/sr25-xxbs. Abstract and bibliographic record were accessible; full article requires credentials.

## Reproducibility

Run `python3 workers/l05_heat_invent/quantify.py` from the workspace root. It checks spectroscopic conversion, overlap, a measured SiO₂-guide conductance scale, arithmetic channel counts, and the Carnot fraction. It is an order-of-magnitude screen only; it does not model GaN/α-MoO₃ coupling, full electromagnetic transmission, fabrication, or device performance.
