# L04 — fusion exhaust, alpha waves, and recirculating power audit

**Date:** 15 October 2026 (Brisbane)  
**Status:** research audit; no new experimental result; novelty and reactor readiness UNKNOWN.  
**Independence:** completed independently as instructed. This is instructed independence, not technically enforced isolation.

## Finding

Divertor heat-flux mitigation has a strong experimental incumbent: controlled detachment with impurity seeding has reduced DIII-D target peak heat flux by more than 85% to about 0.3 MW m⁻² while retaining a high-confinement core in the reported discharge. Alpha-to-ion heating by itself cannot claim a further reduction in *total* exhaust power: it changes where fusion energy is deposited inside the plasma, while the steady-state energy balance still sends that energy to the exhaust, radiation, or another counted output.

The consequential opening is narrower and testable: use fusion-alpha free energy to amplify a correctly directed lower-hybrid wave and replace external current-drive power. For a 500 MW D-T plant, a 10 MW net-electric gain requires at least **5.70 MW of alpha-powered, useful plasma wave power** under the explicit reference efficiencies below—5.73% of the 99.43 MW alpha budget—before any incremental wave, fuel-conditioning, pumping, or maintenance load. Fisch–Rax theory supplies a mechanism, but present experiments do not establish this operating point.

The newest direct competitor is the July 2026 arXiv model of spin-polarized D-T fuel plus alpha channeling. Its ARC-class profile calculation reports 2.0–2.2× fusion power under stiff transport, and a 2.6× net-electric increase (290 to 660 MW) at channeling efficiency 0.5. That is an important quantitative target, but still a model projection: reactor-throughput polarized-fuel production and delivery are unsolved; polarization survival is not experimentally measured in a burning plasma; its wave-access and self-consistent spectrum are left open; and the several wave configurations used for channeling, current drive, and fuel-ion damping are not one demonstrated system.

## Exact output that could matter

Define the candidate operation as **alpha-powered co-current LH drive**: an alpha distribution transfers energy to the directional LH spectrum that supplies the same noninductive current profile as a reference RF system. Keep fusion power, core profiles, current profile, confinement, divertor geometry, and measured peak and integrated target loads matched. The new output is a reduction in *net electric recirculation*; a reduction in divertor heat flux is a separate claim that must be measured separately.

For D-T, the reaction releases 17.6 MeV, of which 3.5 MeV is alpha kinetic energy and 14.1 MeV is neutron energy. Thus

\[
f_\alpha=3.5/17.6=0.19886,\qquad
P_\alpha=0.19886P_{\rm fus},\qquad
P_n=0.80114P_{\rm fus}.
\]

At \(P_{\rm fus}=500\) MW, \(P_\alpha=99.43\) MW and \(P_n=400.57\) MW. This is the maximum charged-particle source available to alpha-wave schemes; the neutron blanket stream is not available to them.

Use a 46% wall-plug-to-launched-LH efficiency from the ARIES-RS conceptual RF design and the 42% heat-to-electric conversion used in the 2026 ARC-class spin-fuel projection. These are reference assumptions, not universal or measured plant efficiencies. Replacing \(\Delta P_{\rm LH}\) of external launched power with alpha-supplied wave power gives the optimistic marginal estimate

\[
\Delta P_{\rm net,e}
=\Delta P_{\rm LH}\left(\eta_{\rm LH,wp}^{-1}-\eta_{\rm th}\right)
-P_{\rm added,e}.
\]

The first term saves RF wall-plug electricity; the second subtracts the thermal-cycle electricity lost because the displaced external RF would otherwise have become plasma heat. With \(\eta_{\rm LH,wp}=0.46\), \(\eta_{\rm th}=0.42\), and a target \(\Delta P_{\rm net,e}=10\) MW, setting added loads to zero gives:

| Quantity | Required value |
|---|---:|
| External LH power displaced at plasma | 5.70 MW |
| Fraction of 500 MW-DT alpha power | 5.73% |
| Avoided LH wall electricity | 12.39 MW |
| Lost thermal-cycle electricity | 2.39 MW |
| Net-electric margin before new loads | 10.00 MW |

Every new electric load must fit inside that 10 MW margin. More generally, the operation passes the plant gate only if
\(P_{\alpha\to\mathrm{LH,useful}}\geq 5.70 + P_{\rm added,e}/(1/0.46-0.42)\) MW at this 500 MW reference point. This sets a concrete scale; it is not evidence that such gain is obtainable.

The accompanying script [`quantify_gate.py`](quantify_gate.py) recomputes these figures. It deliberately treats alpha-to-current-drive coupling as an input measurement, not as an assumed efficiency.

## Why ordinary exhaust claims fail

At steady state, the plasma energy balance has \(dW/dt=0\). Changing alpha deposition from electron collisions to a wave that heats fuel ions changes the **partition**, not the total source. If the wave energy is absorbed in the plasma, that energy is still part of the thermal energy that must leave through radiation and exhaust. Therefore “alpha channeling heats ions, so divertor heat flux falls” does not follow. To support a heat-flux claim, the operation must also change an independently measured edge quantity: the fraction radiated before the target, the exhaust footprint/width, strike-point distribution, or another measured export such as net current-drive work. Peak flux alone must be paired with integrated target energy, radiated power, confinement, and duration; otherwise a lower peak may be simple spreading or a transient.

The strongest retrieved exhaust control is Wang et al. (DIII-D, 2021): nitrogen-seeded full detachment reduced steady-state peak target heat flux by >85% to about 0.3 MW m⁻², with target \(T_e\leq5\) eV and reported \(H_{98}\sim1.5\), \(\beta_N\sim3\). The heat-flux measurement was near its threshold; the paper also reports core radiation near 25% of total heating power and \(Z_{\rm eff}\sim3\) for the cited discharge. This is an excellent comparator, not a proof of reactor-duration performance. The TCV real-time feedback experiment by Ravensbergen et al. separately demonstrated tracking of an impurity-emission front by controlling gas fueling in L- and H-mode. A proposed wave controller must beat this measured control envelope under a matched upstream power and confinement contract, rather than compare against an attached, uncontrolled target.

## Alpha-wave evidence and its exact scope

1. **Fisch & Rax, PRL 69, 612 (1992), theory.** Lower-hybrid waves are a demonstrated current-drive actuator; their reactor calculation finds conditions where alphas damp little or amplify the wave, improving current drive. The paper is theoretical. Its full APS article was not accessible in this audit; the APS abstract and DOI were accessible. The candidate above adopts the paper’s *current-drive* output rather than rebranding ion heating as exhaust reduction.

2. **Cianfrani & Romanelli, “On the optimal conditions for alpha channelling” (2018 manuscript), Fokker–Planck theory.** In its simplified high-frequency-wave model, negligible low-energy outward alpha flux limits channelled wave power to about 20% of alpha power for an extended source (about 35% for a localized source). Extracting the full perpendicular component, up to 2/3 in the model, requires a tuned outward flux at the resonance threshold; that flux and its edge loss are part of the mechanism, not a free input. The authors explicitly state that a quantitative real-plasma prediction needs the spectrum that produces this outward flux. These limits are model-specific, not universal bounds for every later scheme.

3. **JET DTE2, Kirov et al., Nuclear Fusion (2024), experiment plus TRANSP.** ICRH/alpha synergistic interaction modified the measured/modelled alpha distribution, but fast-ion loss diagnostics found no additional alpha losses. The model predicted up to 42% more alpha-electron heating and 25% more alpha-ion heating; relative to total auxiliary heating in the studied JET pulses the effect was <1%. This is relevant evidence that RF can interact with fusion alphas, but it is not a demonstration of alpha-powered wave gain, current drive, or reactor-scale channeling. It is also a constraint on claims that ordinary ICRH synergy already supplies a large useful output.

4. **Qin & Fisch, arXiv:2609.07732v2 (September 2026), linear collisionless theory.** A new root-pole instability is thresholdless only at exact noncommensurate resonance in an ideal collisionless model. Their proton/alpha LAPD-parameter example uses a 2% cold ring near \(3\Omega_\alpha=1.5\Omega_p\); a finite-detuning scan has a threshold at \(n_\alpha/n_{\alpha0}=0.62\). Their computed 99.96% transfer is into a *coherent proton response*, which the paper says is not yet irreversible proton heat; collisions, phase mixing, trapping, damping, or nonlinear conversion must finish that step. The mechanism requires an energetic-ion harmonic distinct from every thermal-ion harmonic. In ordinary D-T fuel, \(\Omega_\alpha=2e/(4m_p)\approx e/(2m_p)=\Omega_D\), so every alpha harmonic overlaps a deuterium harmonic. The proton/alpha example therefore cannot be transferred directly to a D-T mixture without a new multi-species dispersion calculation; realistic slowing-down distributions, finite width, detuning, collision damping, and leakage must also be included. This does not rule out other alpha-wave mechanisms.

5. **Parisi, Diallo & Cook, arXiv:2607.25313 (July 2026), model projection.** This is the strongest retrieved direct contender. Vector-aligned D-T fuel raises the calculated cross section by up to 1.5× and makes alpha births more perpendicular; the paper calculates about 1.5× greater alpha-channeling efficiency for the same wave. Its simplified fixed-gradient profile model gives 2.2× fusion power at \(\eta_{\rm ch}=0.5\); it projects 290 to 660 MW net electric power for an ARC V3A plant while using 42% heat conversion and 100 MW fixed recirculation. At 1.13 GW baseline fusion power, a 50% alpha-channeling fraction corresponds to roughly 112 MW routed from the roughly 225 MW alpha source. The paper also quantifies an important limitation: its single-wave calculation gives only \(\eta_{\rm ch}\approx0.09\); the \(0.5\) scenario requires stronger or multi-wave operation, with \(\eta=0.5\) described as optimistic. It states alpha channeling has not been demonstrated experimentally, reactor-rate polarized-fuel production/delivery is unsolved, wave accessibility is not addressed, and the wave amplitude is not evolved self-consistently. The ARC model reuses a fixed recirculating-power assumption; any new polarization, injection, antenna, spectrum-control, or maintenance loads must be included in a full plant comparison. The authors also state that one wave performing amplification, extraction, and fuel-ion damping remains to be designed.

## Decisive falsification plan

The candidate passes only if a matched alpha-on/off or resonance-on/off experiment closes all of these measurements in the same operating window:

1. **Wave source:** a species-resolved balance shows positive net work by fusion alphas into the co-current LH spectrum, after reflected, parasitic, and seed power are included. An alpha distribution change alone is insufficient.
2. **Useful function:** the wave replaces at least 5.70 MW launched-power-equivalent per 500 MW of D-T fusion output (5.73% of alpha power) while preserving the specified noninductive current profile. Use the measured fusion alpha source to normalize smaller-machine results.
3. **Full-system electricity:** subtract the changed thermal-cycle conversion, wave sources and transmission losses, antenna cooling, fuel polarization and delivery, helium/ash pumping, cryogenics, and any extra control loads. The 10 MW target is lost if these added loads exceed the computed net margin.
4. **Exhaust claim:** independently measure upstream/SOL power, bolometric radiation, peak and integrated divertor heat flux, target temperature, confinement, and pulse duration against the best detached feedback baseline. If only the alpha heating partition changes, or the target load merely moves in space/time, the exhaust claim is falsified.

For the specific Qin–Fisch root-pole proposal, first falsify or confirm the finite-temperature D-T dispersion problem. Sweep detuning, alpha density and ring width with D/T species, then add collision and finite-length damping. If no positive growth rate exceeds combined damping/leakage, the ideal thresholdless mode is inaccessible in that reactor regime. Even if it grows, fail the useful-energy claim unless the coherent wave demonstrably damps on the intended species and the measured integrated transfer meets the plant threshold.

## Claim ledger

| Claim | Status | Evidence boundary |
|---|---|---|
| Controlled detachment can sharply lower peak divertor target heat flux while preserving high confinement in a DIII-D discharge | **Experimentally demonstrated, device/discharge scope** | >85% reduction to ~0.3 MW m⁻²; not a reactor lifetime demonstration |
| Feedback can track an impurity emission front on TCV | **Experimentally demonstrated, device/sensor scope** | Gas fueling actuator; not direct measurement of a plant net-power gain |
| Fusion alpha/RF interaction exists in D-T | **Experiment/model supported** | JET DTE2; <1% of auxiliary heating in the reported heating comparison and no added losses |
| Alpha-amplified LH current drive can reduce recirculating power | **Theory candidate; UNKNOWN experimentally** | Fisch–Rax mechanism; no alpha-powered current-drive gain at the threshold scale measured here |
| Spin-polarized alpha channeling yields 2.6× net electric ARC output | **Model projection, not plant result** | Assumed polarization/channeling, simplified transport, fixed recirculation; important added costs and shared-wave design open |
| D-T exhaust heat flux falls merely because alpha energy is routed to fuel ions | **Rejected by steady-state energy accounting** | Energy is repartitioned and remains in plasma unless radiated/exported or converted to an independently useful output |
| Qin–Fisch thresholdless pole mode directly applies to D-T | **Not established; direct transfer is obstructed** | Their condition requires distinct harmonics; D and alpha cyclotron frequencies coincide, while real D/T, broad alpha distributions, collisions and leakage require a new calculation |

## Sources and access limits

- Wang et al., DIII-D full detachment with improved confinement, *Nature Communications* (2021): <https://doi.org/10.1038/s41467-021-21645-y> — open-access article; this browser pass exposed full search text but Nature’s page fetch redirected behind a cookie gate.
- Ravensbergen et al., real-time impurity-front feedback on TCV, *Nature Communications* 12, 1105 (2021): <https://doi.org/10.1038/s41467-021-21268-3> — open full text.
- Ren et al., DIII-D small-angle-slot detachment heat flux, *Nuclear Materials and Energy* 26, 100887 (2021): <https://doi.org/10.1016/j.nme.2020.100887> — abstract and measurements accessible.
- Fisch & Rax, “Interaction of energetic alpha particles with intense lower hybrid waves,” *Physical Review Letters* 69, 612 (1992): <https://doi.org/10.1103/PhysRevLett.69.612> — APS abstract accessible; full article subscription-gated.
- Cianfrani & Romanelli, “On the optimal conditions for alpha channelling” (2018 manuscript): <https://scipub.euro-fusion.org/wp-content/uploads/eurofusion/WP17ERPR1619501_accepted_merged.pdf> — full manuscript accessible.
- Kirov et al., “Analysis of fusion alphas interaction with RF waves in D-T plasma at JET,” *Nuclear Fusion* (2024): <https://doi.org/10.1088/1741-4326/ad4b3c> — UKAEA/UPC accepted manuscript accessible.
- Qin & Fisch, “Thresholdless IBW Emission and Alpha-to-Thermal-Ion Energy Channeling via Pole Resonance of Fusion-Product Ions,” arXiv:2609.07732v2 (15 Sep 2026): <https://arxiv.org/abs/2609.07732> — full preprint accessible; not treated as experimental or peer-reviewed validation.
- Parisi, Diallo & Cook, “Enhanced alpha channeling with spin-polarized fuel,” arXiv:2607.25313 (28 Jul 2026): <https://arxiv.org/abs/2607.25313> — full preprint accessible; model claims and caveats cited separately above.
- Mau et al., ARIES-RS heating and current drive system (SOFE 1997): <https://qedfusion.org/LIB/REPORT/CONF/SOFE97/mau-1/> — conceptual design projects 46% wall-plug efficiency for lower-hybrid power; used only as an explicit numerical reference.

