#!/usr/bin/env python3
"""Power threshold for alpha-supplied LH current-drive substitution.

This is an accounting calculator, not a plasma model. It assumes one-for-one
replacement of launched LH power, with all displaced plasma input otherwise
available to the thermal cycle. Alpha-to-wave coupling and extra plant loads
are inputs to measure, not inferred by this script.
"""

import argparse


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fusion-mw", type=float, default=500.0)
    parser.add_argument("--net-target-mw", type=float, default=10.0)
    parser.add_argument("--lh-wall-efficiency", type=float, default=0.46)
    parser.add_argument("--thermal-electric-efficiency", type=float, default=0.42)
    parser.add_argument("--added-electric-loads-mw", type=float, default=0.0)
    args = parser.parse_args()

    if args.fusion_mw <= 0 or args.net_target_mw < 0:
        parser.error("fusion power must be positive and target must be nonnegative")
    if not (0 < args.lh_wall_efficiency <= 1):
        parser.error("LH wall efficiency must be in (0, 1]")
    if not (0 <= args.thermal_electric_efficiency <= 1):
        parser.error("thermal electric efficiency must be in [0, 1]")
    if args.added_electric_loads_mw < 0:
        parser.error("added electric loads cannot be negative")

    alpha_fraction = 3.5 / 17.6
    neutron_fraction = 14.1 / 17.6
    p_alpha = alpha_fraction * args.fusion_mw
    p_neutron = neutron_fraction * args.fusion_mw
    marginal_net_per_lh_mw = (
        1.0 / args.lh_wall_efficiency - args.thermal_electric_efficiency
    )
    if marginal_net_per_lh_mw <= 0:
        parser.error("selected efficiencies do not give a positive net-power benefit")

    required_lh = (args.net_target_mw + args.added_electric_loads_mw) / marginal_net_per_lh_mw
    wall_saved = required_lh / args.lh_wall_efficiency
    thermal_electric_lost = required_lh * args.thermal_electric_efficiency
    net_gain = wall_saved - thermal_electric_lost - args.added_electric_loads_mw

    print(f"fusion power:                         {args.fusion_mw:.3f} MW")
    print(f"alpha power budget (3.5/17.6):        {p_alpha:.3f} MW")
    print(f"neutron power (14.1/17.6):            {p_neutron:.3f} MW")
    print(f"LH plasma power that must be replaced: {required_lh:.3f} MW")
    print(f"share of alpha power required:         {100 * required_lh / p_alpha:.3f}%")
    print(f"avoided LH wall electricity:           {wall_saved:.3f} MW")
    print(f"lost thermal-cycle electricity:        {thermal_electric_lost:.3f} MW")
    print(f"added electric loads:                  {args.added_electric_loads_mw:.3f} MW")
    print(f"net electric gain:                     {net_gain:.3f} MW")


if __name__ == "__main__":
    main()
