#!/usr/bin/env python3
"""Synthetic identifiability check for phase-binned catalytic product sampling.

This is an analytic counterexample, not experimental data.  Two dynamic states
have identical cycle means in structure, adsorbate coverage, desired product,
and total product, yet their phase-resolved product/structure relation differs.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path


OUT = Path(__file__).resolve().parent
N_PER_CYCLE = 12000
N_BINS = 8
PERIOD_S = 20.0
X0 = THETA0 = 0.5
AMP_X = AMP_THETA = 0.4
PHASES = {"plus_60deg": math.pi / 3, "minus_60deg": -math.pi / 3}


def mean(values: list[float]) -> float:
    return sum(values) / len(values)


def run_case(phi: float) -> tuple[list[dict[str, float]], dict[str, float]]:
    rows: list[dict[str, float]] = []
    phase_stats = []
    nbin = N_PER_CYCLE // N_BINS
    for j in range(N_BINS):
        x_values = []
        theta_values = []
        desired = []
        total = []
        for i in range(j * nbin, (j + 1) * nbin):
            t = PERIOD_S * i / N_PER_CYCLE
            angle = 2.0 * math.pi * t / PERIOD_S
            x = X0 + AMP_X * math.cos(angle)
            theta = THETA0 + AMP_THETA * math.cos(angle - phi)
            r_desired = x * theta
            r_total = x  # competing branch closes the site-level rate balance
            x_values.append(x)
            theta_values.append(theta)
            desired.append(r_desired)
            total.append(r_total)
        row = {
            "phase_case": "",
            "phase_bin": float(j),
            "phase_mid_deg": 360.0 * (j + 0.5) / N_BINS,
            "mean_active_structure": mean(x_values),
            "mean_intermediate_coverage": mean(theta_values),
            "desired_product_rate": mean(desired),
            "total_product_rate": mean(total),
            "desired_selectivity": mean(desired) / mean(total),
        }
        rows.append(row)
        phase_stats.append(row)

    # Exact whole-cycle moments, evaluated on the same dense periodic grid.
    all_x = []
    all_theta = []
    all_desired = []
    all_total = []
    for i in range(N_PER_CYCLE):
        t = PERIOD_S * i / N_PER_CYCLE
        angle = 2.0 * math.pi * t / PERIOD_S
        x = X0 + AMP_X * math.cos(angle)
        theta = THETA0 + AMP_THETA * math.cos(angle - phi)
        all_x.append(x)
        all_theta.append(theta)
        all_desired.append(x * theta)
        all_total.append(x)
    means = {
        "mean_active_structure": mean(all_x),
        "mean_intermediate_coverage": mean(all_theta),
        "mean_desired_product_rate": mean(all_desired),
        "mean_total_product_rate": mean(all_total),
        "mean_desired_selectivity": mean(all_desired) / mean(all_total),
    }
    return rows, means


def main() -> None:
    all_rows: list[dict[str, float | str]] = []
    means_by_case = {}
    profiles = {}
    for name, phi in PHASES.items():
        rows, means = run_case(phi)
        for row in rows:
            row["phase_case"] = name
            all_rows.append(row)
        means_by_case[name] = means
        profiles[name] = [r["desired_selectivity"] for r in rows]

    mean_gap = max(
        abs(means_by_case["plus_60deg"][key] - means_by_case["minus_60deg"][key])
        for key in means_by_case["plus_60deg"]
    )
    phase_profile_rms_gap = math.sqrt(
        mean(
            [
                (a - b) ** 2
                for a, b in zip(profiles["plus_60deg"], profiles["minus_60deg"])
            ]
        )
    )
    # Ideal phase-bin sampling is an integral, so these are exact in this
    # noiseless periodic model. Real work requires an outlet RTD calibration.
    result = {
        "status": "synthetic_identifiability_check_only",
        "period_s": PERIOD_S,
        "phase_bins": N_BINS,
        "samples_per_cycle": N_PER_CYCLE,
        "input_phases": {name: math.degrees(phi) for name, phi in PHASES.items()},
        "cycle_means_by_case": means_by_case,
        "max_difference_in_pooled_cycle_means": mean_gap,
        "rms_difference_in_phase_binned_selectivity": phase_profile_rms_gap,
        "interpretation": (
            "Pooled cycle means are identical (up to floating-point error), while "
            "the phase-binned product/structure relation changes with relative lag. "
            "This establishes only a measurement identifiability point in a toy model."
        ),
    }
    with (OUT / "phase_bins.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_rows[0]))
        writer.writeheader()
        writer.writerows(all_rows)
    (OUT / "phase_bin_demo.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
