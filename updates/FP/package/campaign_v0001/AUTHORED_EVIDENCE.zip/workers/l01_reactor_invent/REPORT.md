# L01 — Phase-resolved liquid-product readout during catalyst restructuring

**Status: NOT ACHIEVED as a new frontier capability.** I found a plausible measurement operation for a real gap in pulsed Cu CO2 electroreduction, derived and tested its information advantage in a synthetic identifiability check, and then found close prior art that blocks any novelty or performance claim. No physical experiment or raw-data reanalysis was completed.

## Target and candidate operation

The target output is **liquid-product selectivity by phase of a repeated restructuring cycle**, aligned to an operando structural/adsorbate signal. In Cu CO2 electroreduction, potential cycling can change Cu oxidation/coordination and adsorbate populations on subsecond-to-second scales, while ethanol/formate are often quantified only in samples accumulated over much longer intervals. A cycle-averaged product assay cannot tell whether the target product was emitted while a proposed active structure was present, during its transition, or after the structure had relaxed.

The candidate operation is **phase-binned effluent fractionation**. During a repeatable potential/feed waveform, a low-dead-volume side stream from the catholyte outlet is routed by a phase-locked valve into one of K collection loops. Each loop receives only the same phase window on every cycle. After N cycles, each pooled fraction is quantified by calibrated HPLC/LC-MS or quantitative NMR. Fast gas products are measured separately by synchronized MS/GC. Quick-XAS or surface-sensitive Raman is collected on the same waveform, with its acquisition clock and the liquid outlet clock synchronized. An inert tracer pulse measures the liquid residence-time distribution (RTD), so valve windows are shifted and, where resolution permits, deconvolved for transport lag and dispersion.

For cycle period T and phase window j of width Δ, the phase-specific product flux estimate is

\[
\widehat J_{p,j}=\frac{M_{p,j}}{N\,Q_s\,\Delta\,\eta_p},\qquad
M_{p,j}=\sum_{n=0}^{N-1}\int_{nT+\tau_j}^{nT+\tau_j+\Delta}
Q_s(t)\,c_p(t)\,dt,
\]

where Q_s is the sampled side-stream flow and η_p is the measured recovery for product p. Under a stable periodic state, this is the cycle-repeat average over that phase window. Selectivity is computed from molar product fluxes, not signal fractions. If h(t) is the measured outlet RTD, the sample signal is h*c; the experiment must fail its phase-resolution gate if h is too broad to distinguish adjacent windows. A practical initial design could use the published 20 s Cu potential cycle as a reference and K=8 (2.5 s bins), but these are design values, not a demonstrated operating protocol.

The eventual control use would be slow supervisory adjustment across repeated blocks: extend or shorten the cathodic/anodic windows only if the phase-binned product flux and a calibrated structural marker show a repeatable favorable overlap. This is not subcycle feedback. XAS beamline measurement and offline liquid assays are too slow for that claim; a lab-ready live controller would need a separately calibrated high-rate structural proxy, such as Raman, and a fast product sensor.

## Derivation and executable check

The executable synthetic counterexample is in [phase_bin_demo.py](phase_bin_demo.py), with machine-readable output in [phase_bin_demo.json](phase_bin_demo.json) and the eight-bin profiles in [phase_bins.csv](phase_bins.csv).

The toy model sets

\[
x(t)=0.5+0.4\cos(\omega t),\quad
\theta(t)=0.5+0.4\cos(\omega t-\phi),\\
r_D(t)=x(t)\theta(t),\quad r_{tot}(t)=x(t),\quad r_B(t)=x(t)(1-\theta(t)).
\]

For \(\phi=+60^\circ\) and \(-60^\circ\), the cycle means are exactly the same:

\[
\bar x=\bar\theta=0.5,\quad
\bar r_D=0.25+0.08\cos\phi=0.29,\quad
\bar r_{tot}=0.5,\quad
\bar r_D/\bar r_{tot}=0.58.
\]

Yet the eight phase-bin selectivity profiles reverse their structure/product alignment. In the executable check the RMS difference between those binned selectivity profiles is 0.484, while the maximum difference across all pooled cycle means is 0. The result is an information/identifiability demonstration only: rates, noise, transport, spectra, catalyst, and collection chemistry are synthetic. It shows exactly what the proposed sampler could recover and what pooled assays erase; it does **not** show a catalyst benefit or a real measurement limit.

## Strongest competitors and what they already do

| Competitor | Demonstrated capability | Consequence for this candidate |
|---|---|---|
| Hejral et al., *Nature Catalysis* (2022), DOI [10.1038/s41929-022-00760-z](https://www.nature.com/articles/s41929-022-00760-z) | Potential-pulsed Cu2O-derived CO2RR with subsecond operando QXAS and XRD; identifies a narrow pulse-duration window with about 2× ethanol formation versus stationary operation. Liquid products are measured after electrolysis by HPLC. | This is the strongest same-system competitor. It already performs structural control and average selectivity optimization. Phase bins would add temporal localization of the liquid branch, not establish that pulsing or structural control is new. |
| Hejral et al., *JACS* (2021), DOI [10.1021/jacs.1c03443](https://doi.org/10.1021/jacs.1c03443) | Pulsed CO2RR in a gas-fed flow cell, varying anodic pulse potential; reports switching between C1 and C2 products and combines operando XAS/SERS with microscopy. | Pulse amplitude/timing as a selectivity control is established. |
| Zhang et al., *Angew. Chem. Int. Ed.* (2023), DOI [10.1002/anie.202312607](https://onlinelibrary.wiley.com/doi/10.1002/anie.202312607) | Synchronized electrochemistry–soft-ionization MS captures transient CO, H2, ethylene and methane signals on the seconds scale and aligns them to the potentiostat. | Fast, phase-aligned gaseous product measurement exists. The remaining niche is the nonvolatile liquid-product channel. |
| Zhu et al., *ACS Catalysis* (2025), DOI [10.1021/acscatal.5c00355](https://pubs.acs.org/doi/full/10.1021/acscatal.5c00355) | Inline benchtop NMR quantifies formate and ethanol during high-current eCO2RR. The reported liquid loop/probe volume is about 5.8 mL; at 2.5 mL/min this gives a 2.3 min transport delay, and its reported ethanol protocol averages repeated spectra for sensitivity. | This addresses real-time liquid product trends, but does not resolve seconds-scale pulse phase. The 2.3 min figure is a delay; actual phase smearing depends on the full RTD and acquisition window, which must be measured rather than inferred from volume alone. |
| Espinoza et al., *ChemCatChem* (2022), DOI [10.1002/cctc.202200337](https://chemistry-europe.onlinelibrary.wiley.com/doi/full/10.1002/cctc.202200337) | Automated periodic reactor profiling combines local gas analysis, temperature, and operando XRD; XRD scans were acquired at 1 s intervals under periodic operation. | Phase-resolved structure/gas analysis in periodic catalysis is established. This weakens any broad “first phase-resolved operando” claim, though their demonstrated products are gas-phase and their reported profiles are often averaged. |
| Kaps et al., *ChemCatChem* (2026), DOI [10.1002/cctc.202501403](https://chemistry-europe.onlinelibrary.wiley.com/doi/10.1002/cctc.202501403) | Models and experimentally applies simultaneous phase-shifted modulation of two reactor inputs for Cu/ZnO/Al2O3 methanol synthesis; reports +4.4% productivity and +4.6% yield at matched mean reactant amounts in one comparison. | A phase-shifted multi-input catalytic control law is already demonstrated. Do not claim that choosing a favorable phase lag is a new operation. |
| Rakita et al., *JACS* (2020), DOI [10.1021/jacs.0c09418](https://doi.org/10.1021/jacs.0c09418) | Real-time in situ XAS feedback adjusts O2:H2 composition to reach a target average Cu oxidation state. | State-feedback to a mean structural/redox target already exists. Product-conditioned, phase-specific liquid output is the narrower distinction here. |
| MES/phase-sensitive detection and SSITKA/TAP | Periodic excitation and phase-sensitive detection select responsive species; isotope transients and sequential pulses probe surface inventories and kinetics. | Periodic perturbation, stroboscopic analysis, and isotope/pulse kinetics are not novel by themselves. The proposed fractionator must be evaluated against a synchronized phase-bin liquid assay, not advertised as a new pulsing paradigm. |

The two-input phase-shifted methanol work is especially important: it defeats the tempting alternate invention of “measure a lag and tune two pulse trains.” That route was set aside.

## Exact experiment and gates

**Inputs:** catalyst/electrode under a fixed repeatable operating waveform; measured potential/current; stable feed and electrolyte; XAS or Raman time series; a low-volume catholyte side stream; phase-locked multiport valve or equivalent; internal standards and product-specific calibration curves; inert tracer for RTD; offline LC-MS/HPLC/qNMR for liquid products; online synchronized MS/GC for gas products.

**Outputs:** phase-bin product molar fluxes and selectivities; phase-aligned structural/adsorbate descriptors; cycle-averaged mass balance; uncertainty from assay, sampling split, flow, timing, and catalyst drift. This remains ensemble-level information and cannot assign turnover to an individual nanoparticle or atomic site.

**Required controls:** (1) measure the full RTD and valve latency under operating flow; require the RTD width to be shorter than the bin width or widen bins/slow the cycle; (2) quantify side-stream recovery and ensure sampling does not change electrode pressure, flow, or potential; (3) use blank and standard additions to catch adsorption or loss in loops; (4) measure current and structural-cycle repeatability while pooling; (5) use a phase-scrambled/constant-potential comparator and a whole-cycle pooled fraction; (6) account for gas/liquid carbon balance and any product crossover; (7) randomize or block waveform conditions so catalyst aging is not confounded with phase. If state drift during the pooling window is comparable to the within-cycle state change, the estimator is invalid and the run must stop or use shorter blocks.

**Resource accounting:** no experiment was run, so no beamtime, instrument, chemical, or person-hour costs are claimed. A real run needs synchrotron time if QXAS is the structural reference, enough repeated cycles to exceed the measured liquid assay LOQ, and extra time for RTD/recovery calibration and catalyst-aging controls. Required N depends on product concentration, sampled flow, collection duty fraction, recovery, and assay LOQ; those values must be measured first. The protocol consumes added electrolyte/product material and can disturb hydraulics if the side-stream is not a nonperturbing split. The long pooling interval is the main risk.

## Evidence, access limits, and claim ledger

- Literature searches and accessible article/SI pages were used for prior-art checks. No synchronized raw data set pairing subsecond structure with phase-resolved liquid selectivity for pulsed Cu CO2RR was located. Some papers provide figures or supporting information; several relevant papers state raw data are available on request. I did not request data or contact authors.
- The executable check uses only analytic synthetic equations. It is reproducible with the Python standard library. It is not a fitted kinetic model, physical validation, or evidence of novelty.
- **Established:** the published methods demonstrate subsecond operando structure in pulsed Cu CO2RR; fast synchronized MS for gaseous products; inline NMR for liquid products at much slower loop/acquisition times; phase-shifted two-input periodic control; and average-redox XAS feedback.
- **Supported only by the toy model:** pooled means can be exactly non-identifying for the phase relationship between a structural coordinate, an intermediate coordinate, and product flux; phase bins recover that relationship in the ideal periodic case.
- **Plausible but untested:** an immediate outlet side stream with a calibrated, sufficiently narrow RTD can stroboscopically accumulate phase-specific liquid products over many cycles without changing the operating cell.
- **Unknown / not claimed:** first-in-field status, practical LOQ at 2.5 s bins, liquid recovery, effect on selectivity, transferable catalyst control, site specificity, and any improvement over existing methods. The candidate does not yet meet the mission bar because the apparatus has not been built/tested and close phase-resolved periodic-profile prior art exists.

This investigation was performed independently as assigned. That independence is an instruction, not enforced isolation; I did not inspect other current workers' reports.
