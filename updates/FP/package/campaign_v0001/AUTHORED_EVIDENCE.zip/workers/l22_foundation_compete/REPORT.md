# L22 — Foundation / incumbent audit

## Finding

I did not find a new physical or computational operation that clears the campaign's capability bar. The strongest existing mathematics gives a sharp boundary for what a representation can do after acquisition: a parameter-independent channel cannot increase decision-relevant distinguishability. The most promising foundational gap is therefore a *joint, acquisition-inclusive* frontier for adaptive measurement, computation, and physical resource cost. Existing theory handles these pieces separately, and Landauer's principle does not supply the missing universal energy law.

There is a recent close preprint, Akdemir's December 2025 *Approximate Computation via Le Cam Simulability*. It proposes a computational-deficiency language, but its physical-energy link is explicitly conjectural. I found a counterexample to the printed main “No-Free-Transfer” inequality. The exact lower bound below is established; the proposed joint frontier is only a research direction.

## Contract and strongest existing mathematics

Consider a parameter or scientific state \(\theta\), an acquired observation \(X\sim P_\theta\), and an operation \(K\) that maps the acquired observation into a representation or output \(Z\). Here \(K\) may be randomized and is independent of \(\theta\); a classical physical implementation is a stochastic channel, and a quantum implementation followed by readout is a quantum channel plus measurement. The output is judged by a declared loss \(\ell(\theta,a)\). Acquisition and representation are distinct: changing the sensor or issuing another probe changes the experiment, while applying \(K\) to already acquired data does not.

The incumbent foundations are already strong in their respective scopes:

| Question | Strongest relevant result | What it does not establish |
|---|---|---|
| Can one representation preserve every decision available from another experiment? | Blackwell's comparison theorem characterizes finite experiments by parameter-independent randomization; Le Cam deficiency quantifies the best worst-case total-variation simulation error and hence bounded-loss risk transfer. | It is an information/decision comparison. The unrestricted deficiency infimum does not charge the runtime, memory, acquisition, calibration, precision, or energy of a simulator. |
| Can a physical operation create statistical distinguishability? | Classical data processing and Lindblad's quantum relative-entropy data-processing inequality say no. Equality conditions and Petz sufficiency/recovery characterize when information discarded by a coarse-graining can be recovered on the stated family. | They do not say how cheaply a sufficient output can be computed or physically measured. |
| Is there a minimal adaptive representation? | For a specified stationary process and the full future-prediction task, computational mechanics defines causal states as the minimal predictive sufficient representation. | The process law and prediction target are specified. The theorem is not a finite-sample acquisition guarantee, a universal representation for every later task, or a physical implementation result. |
| What energy must computation use? | Landauer bounds the heat cost of logically irreversible erasure. Bennett constructs reversible general-purpose computation with saved history and reverse uncomputation. | There is no universal positive energy cost per logical step or per unit reduction in statistical deficiency. Finite-speed, reliability, preparation, measurement, and reset costs need a physical model. |

This division is the exact incumbent limitation: the information theorems prohibit post-acquisition gains, while the computational and thermodynamic theories do not jointly bound the cost of finding or implementing a useful representation. A scalar information score also cannot select a task-independent best representation. For example, with \(\Theta=\{A,B,C\}\) uniform, the one-bit experiments \(X_A=1[\theta=A]\) and \(X_B=1[\theta=B]\) both have \(I(\Theta;X)=h_2(1/3)\). Yet for the task “is \(\theta=A\)?”, \(X_A\) has zero error and \(X_B\) has minimum error \(1/3\); the reverse holds for the B-task. There is no single optimal one-bit representation without specifying the downstream task or a distribution over tasks.

## Exact fixed-acquisition lower bound

For any two hypotheses \(\theta_0,\theta_1\), if \(Z\) is produced from \(X\) by a parameter-independent channel \(K\), data processing gives

\[
D(P_{\theta_0}K\|P_{\theta_1}K)\le D(P_{\theta_0}\|P_{\theta_1}),\qquad
\|P_{\theta_0}K-P_{\theta_1}K\|_{TV}\le\|P_{\theta_0}-P_{\theta_1}\|_{TV}.
\]

With equal prior probabilities and 0–1 loss, the optimal testing error is \((1-\|P_{\theta_0}-P_{\theta_1}\|_{TV})/2\). Therefore *no downstream representation or physical computation on the same acquired data can achieve error below the raw-data optimum*. This is the requested real lower bound; it is exact and independent of how ingenious the post-processing is.

Concrete fixture: let \(\theta\in\{0,1\}\), and acquire one sensor bit \(Y=\theta\oplus N\), where \(N\sim\mathrm{Bernoulli}(\varepsilon)\), \(0<\varepsilon<1/2\). The raw-data decision error is exactly \(\varepsilon\), and \(\|P_0-P_1\|_{TV}=1-2\varepsilon\). Every deterministic or randomized representation \(K(Y)\) has error at least \(\varepsilon\). At \(\varepsilon=0.1\), the best possible error is 10%. To improve it, one must change the experiment, for example by acquiring further observations; that action has a cost and is not free representation learning.

For an \(n\)-sample family with per-sample \(D(P_0\|P_1)\le\kappa\), the transcript KL is at most \(n\kappa\). Le Cam's two-point bound and Pinsker yield

\[
P_e^*\ge \max\!\left\{0,\frac{1-\sqrt{n\kappa/2}}{2}\right\}.
\]

For adaptive probes, the same argument applies to the *full action/outcome transcript*: its KL is the sum of expected conditional KL increments. Thus adaptivity can improve the acquired experiment by choosing more informative probes, but it cannot make an already fixed transcript more informative. To make this an energy or time lower bound, one still needs a proven platform-specific constraint relating each probe's conditional KL to its complete acquisition cost.

This gives a clean artifact test. First compare the candidate against the raw acquired experiment on the declared task. If the raw experiment supports lower risk than the incumbent representation, the incumbent discarded useful information and the gap is representational. If the raw-data Le Cam bound already exceeds the target risk, no representation of that data can meet the target; new acquisition or side information is required. If raw data is informative but the candidate is faster or lower energy, information theory alone cannot adjudicate the claim: complete computation and physical costs must be compared.

## Audit of the closest recent framework

Akdemir, *Approximate Computation via Le Cam Simulability*, arXiv:2512.24860v1 (submitted 31 Dec 2025), defines computational deficiency by restricting Le Cam's simulator to polynomial-time kernels. This is a useful *proposal* for separating statistical simulability from efficient simulability. It is not a physical-computation result: the preprint's “Le Cam Limit” claim that reducing deficiency by \(\delta\) requires energy proportional to \(\log(1/\delta)\) is explicitly listed as a conjecture/open problem, and Landauer's erasure bound does not imply it.

One printed theorem is false as stated. The body of Theorem 5.1 uses the **marginal** invariance term \(\|T_\#P_S-T_\#P_T\|_{TV}\). Take the two-state fixture above under a uniform prior, let the source experiment \(E_S\) be noiseless \(X=\theta\), the target experiment \(E_T\) be the BSC(\(\varepsilon\)) observation, and let \(T\) be identity. The source and target marginals are both Bernoulli(1/2), so that invariance term is zero; each representation-fidelity term is zero because identity preserves each experiment. But, with the preprint's own definition \(\delta(E,F)=\inf_K\sup_\theta\|P_\theta K-Q_\theta\|_{TV}\), the directed deficiency \(\delta(E_T,E_S)=\varepsilon>0\): the best simulator of a noiseless label from the BSC output has worst-case error \(\varepsilon\). Thus the displayed inequality would assert \(0\ge C\varepsilon\) for some \(C>0\), a contradiction.

The appendix silently replaces the marginal term with \(\sup_\theta\|Q^S_\theta-Q^T_\theta\|_{TV}\). This conditional version avoids the counterexample and follows from the triangle inequality for deficiency, but it is not the same statement as the body theorem and does not yield a physical cost bound. The mismatch is a precise example of why invariance of an averaged representation is not a substitute for comparison of the conditional experiment.

The preprint's use of a broad decision-robust metric is also a design choice rather than a universal optimum. For a particular scientific output, deficiency over *all* bounded decision problems can be unnecessarily stringent; a task-specific risk, prior, or restricted decision class may be the right target. Conversely, a held-out empirical risk gap cannot certify a supremum over all parameters or decisions without explicit uniform-convergence assumptions. Its own Appendix A.3 calls the consistency argument heuristic and defers those details.

## Best surviving opportunity and status

The foundational opening is to define and prove a **resource-indexed adaptive experiment frontier** for one concrete scientific measurement system. The object would be the complete adaptive transcript, not just a compressed data representation. Its coordinates should include (i) task-specific deficiency/risk, (ii) probe and calibration information acquired, (iii) algorithmic time/memory/precision, and (iv) measured or derived physical work, reset, and output cost. The basic lower-bound spine is already available: data processing for each representation, chain-rule KL for adaptive probes, and Le Cam testing bounds for task error. The missing theorem is a justified link from the actual platform's physical budget to its per-action information increments, paired with an operation that reaches a better cost-risk frontier than the strongest full-system incumbent.

That is not yet an exceptional capability or a new theorem. No physical platform, open dataset, or acquisition law was specified in this foundational lane, so I did not invent one or claim a bench result. The next valid step requires a specific assay/device and target output; then test the raw transcript bound, optimize an adaptive representation, and compare it with the best static and task-specific incumbent while charging calibration and acquisition. Until that operation exists and wins the matched comparison, status is **NOT_ACHIEVED** and novelty is **UNKNOWN**.

## Claim ledger

| Claim | Status |
|---|---|
| Fixed-acquisition representation cannot improve binary decision error beyond raw-data TV/Le Cam limit. | **PROVED** here from standard data processing and Le Cam's two-point argument. |
| The BSC(\(\varepsilon\)) sensor example has raw and best post-processed error exactly \(\varepsilon\). | **PROVED**; closed-form finite example. |
| The body version of Akdemir Theorem 5.1 fails on a noiseless-versus-BSC pair under a uniform prior. | **COUNTEREXAMPLE** to the printed statement; appendix uses a different conditional term. |
| A universal thermodynamic deficiency/energy law follows from Landauer. | **NOT_SUPPORTED**; Landauer concerns logically irreversible erasure, and reversible computation is known. |
| A new acquisition-computation-thermodynamic operation beats incumbents on a scientific output. | **NOT_ACHIEVED**. No concrete device/assay/output was supplied or tested. |
| Novelty of a resource-indexed adaptive experiment frontier. | **UNKNOWN**; close preprint and adjacent literatures require a deeper priority review before any novelty statement. |

## Sources and access

Primary sources used for the mathematical and physical baseline:

- D. Blackwell, “Comparison of Experiments,” *Proceedings of the Second Berkeley Symposium on Mathematical Statistics and Probability* (1951), pp. 93–102, [publisher DOI](https://doi.org/10.1525/9780520411586-009), [Berkeley scan](https://digicoll.lib.berkeley.edu/record/112749/files/math_s2_article-08.pdf). The publisher metadata and scan route were located; the browser tool blocked the PDF fetch.
- D. Blackwell, “Equivalent Comparisons of Experiments,” *Annals of Mathematical Statistics* 24(2) (1953), 265–272, [DOI](https://doi.org/10.1214/aoms/1177729032). The result record and theorem statement were accessible; the Project Euclid PDF fetch was blocked.
- L. Le Cam, “Sufficiency and Approximate Sufficiency,” *Annals of Mathematical Statistics* 35(4) (1964), 1419–1455, [DOI](https://doi.org/10.1214/aoms/1177700372). Original publication metadata verified; full-text access was not available through the browser tool.
- G. Lindblad, “Completely Positive Maps and Entropy Inequalities,” *Communications in Mathematical Physics* 40 (1975), 147–151, [DOI](https://doi.org/10.1007/BF01609396). Publisher page blocked; title/metadata and monotonicity result verified from the indexed paper record.
- D. Petz, “Sufficient Subalgebras and the Relative Entropy of States of a von Neumann Algebra,” *Communications in Mathematical Physics* 105 (1986), 123–131, [DOI](https://doi.org/10.1007/BF01212345), [author-hosted PDF](https://math.bme.hu/~petz/pdf/29suff.pdf). Full primary text was accessible.
- R. Landauer, “Irreversibility and Heat Generation in the Computing Process,” *IBM Journal of Research and Development* 5(3) (1961), 183–191, [DOI](https://doi.org/10.1147/rd.53.0183), [full reprint scan](https://www.cpt.univ-mrs.fr/~verga/pdfs/Landauer-1961uq.pdf). Full paper text was accessible.
- C. H. Bennett, “Logical Reversibility of Computation,” *IBM Journal of Research and Development* 17(6) (1973), 525–532, [DOI](https://doi.org/10.1147/rd.176.0525), [author-adjacent full text](https://www.cs.princeton.edu/courses/archive/fall04/cos576/papers/bennett73.html). Browser fetch of the full page was blocked; abstract and bibliographic record were indexed.
- C. R. Shalizi and J. P. Crutchfield, “Computational Mechanics: Pattern and Prediction, Structure and Simplicity,” *Journal of Statistical Physics* 104 (2001), 817–879, [DOI](https://doi.org/10.1023/A:1010388907793), [arXiv primary manuscript](https://arxiv.org/abs/cond-mat/9907176). Abstract and full manuscript listing were accessible.
- D. Akdemir, “Approximate Computation via Le Cam Simulability,” [arXiv:2512.24860v1](https://arxiv.org/abs/2512.24860), [full v1 HTML](https://arxiv.org/html/2512.24860v1). The full primary preprint was accessible. It is cited as a preprint, not peer-reviewed validation.

No source scripts, external datasets, simulations, or physical apparatus were used. The principal evidence is the closed-form counterexample and exact information bound above.
