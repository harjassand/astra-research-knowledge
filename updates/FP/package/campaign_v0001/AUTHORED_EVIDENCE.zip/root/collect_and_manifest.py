"""Collect current campaign sources without overwriting any differing bytes."""
from pathlib import Path
import hashlib, json, shutil, zipfile

BASE=Path(__file__).resolve().parents[1]
WORKSPACE=BASE.parents[1]
EXTERNAL=['l01_reactor_invent','l05_heat_invent','l06_heat_compete',
 'l07_defects_invent','l08_defects_compete','l10_assembly_compete',
 'l11_materials_invent','l14_quantum_compete','l15_rare_invent',
 'l17_pde_invent','l20_discovery_compete','l22_foundation_compete']
WORKERS=['l01_reactor_invent','l02_reactor_compete','l03_nuclear_invent',
 'l04_nuclear_compete','l05_heat_invent','l06_heat_compete',
 'l07_defects_invent','l08_defects_compete','l09_assembly_invent',
 'l10_assembly_compete','l11_materials_invent','l12_materials_compete',
 'l13_quantum_invent','l14_quantum_compete','l15_rare_invent',
 'l16_rare_compete','l17_pde_invent','l18_pde_compete',
 'l19_discovery_invent','l20_discovery_compete','l21_foundation_invent',
 'l22_foundation_compete','l23_experiment_invent','l24_experiment_compete',
 'l25_capital_invent','l26_capital_compete','s01_mechanism',
 's02_computation','s03_matter','s04_foundations','s05_adversary','s06_capital']

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def include(p):
    parts=p.relative_to(BASE).parts
    return ('__pycache__' not in parts and p.suffix!='.pyc'
            and 'package' not in parts[2:4]
            and p.name not in ['MANIFEST.json','EVIDENCE.zip','AUTHORED_MANIFEST.json','AUTHORED_EVIDENCE.zip'])

def main():
    origin=[]
    for name in EXTERNAL:
        src=WORKSPACE/'workers'/name
        dst=BASE/'workers'/name
        for p in sorted(src.rglob('*')):
            if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc': continue
            q=dst/p.relative_to(src)
            q.parent.mkdir(parents=True,exist_ok=True)
            if q.exists():
                if sha(p)!=sha(q): raise RuntimeError('Differing existing source: '+str(q))
            else: shutil.copy2(p,q)
            origin.append({'original_absolute_path':str(p),'collected_path':str(q.relative_to(BASE)),
                           'sha256':sha(p),'status':'byte-identical source collection'})
    (BASE/'SOURCE_COLLECTION.json').write_text(json.dumps(origin,indent=2)+'\n')
    reports=[]
    for name in WORKERS:
        p=BASE/'workers'/name/'REPORT.md'
        if not p.is_file(): raise RuntimeError('Missing report: '+str(p))
        reports.append({'worker':name,'model':'gpt-6-luna' if name.startswith('l') else 'gpt-6-sol',
                        'reasoning_effort':'max','report':str(p.relative_to(BASE)),
                        'report_sha256':sha(p),'status':'worker-authored internal research; external correctness and novelty UNKNOWN'})
    index={'mission_status':'NOT_ACHIEVED','initial_worker_count':32,
           'initial_model_allocation':{'gpt-6-luna_max':26,'gpt-6-sol_max':6},
           'independence':'instructed initial independence, not access isolation; later selective collaboration',
           'model_tokens':None,'pure_inference_time_seconds':None,'model_energy_joules':None,
           'capital_initial_head':'5ddabf53324159aa6c88e4fef3b75bc7b8b6c4ff',
           'capital_fetched_main':'1c45f77e32d6fbd72483aed5014061c7bda4f372',
           'report':'REPORT.md','workers':reports,
           'replay_receipt':'root/REPLAY_RECEIPTS_v0004.json',
           'replay_scope':'27 distinct calculations succeeded in 29 attempts; two initial missing-openpyxl failures retained; no physical or novelty certification'}
    (BASE/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
    files=[p for p in sorted(BASE.rglob('*')) if p.is_file() and include(p)]
    records=[{'path':str(p.relative_to(BASE)),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
    manifest={'scope':'retained campaign sources, reports, code, data and replay outputs; transient replay package copies omitted',
              'scientific_status':'NOT_ACHIEVED; hashes establish integrity only','files':records}
    (BASE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    files.append(BASE/'MANIFEST.json')
    with zipfile.ZipFile(BASE/'EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in files: z.write(p,str(p.relative_to(BASE)))
    print(json.dumps({'workers':len(reports),'files':len(files),'archive_sha256':sha(BASE/'EVIDENCE.zip'),
                      'archive_bytes':(BASE/'EVIDENCE.zip').stat().st_size},indent=2))

if __name__=='__main__': main()
