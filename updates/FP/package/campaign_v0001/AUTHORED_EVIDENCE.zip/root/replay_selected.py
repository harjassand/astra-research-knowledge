"""Replay selected local finite calculations from copies; preserve source bytes."""
from pathlib import Path
import concurrent.futures, hashlib, json, shutil, subprocess, sys, time

BASE=Path(__file__).resolve().parents[1]
WORKSPACE=BASE.parents[1]
TASKS=[
 ('root','repair_model.py'),
 ('workers/s02_computation','benchmark.py'),
 ('workers/s05_adversary','verify_boundary.py'),
 ('workers/s06_capital','verify_cycle_scaling.py'),
 ('workers/s01_mechanism','bounds.py'),
 ('workers/s03_matter','defect_control.py'),
 ('workers/s03_matter','switching_walk.py'),
 ('workers/s04_foundations','kinematic_audit.py'),
 ('workers/l26_capital_compete','audit_exact.py'),
 ('workers/l25_capital_invent','gauge_hodge_covariance.py'),
 ('workers/l13_quantum_invent','collision_model.py'),
 ('workers/l09_assembly_invent','gap_repair_break_even.py'),
 ('workers/l19_discovery_invent','pulse_order_scaling_demo.py'),
 ('workers/l18_pde_compete','lower_bound_demo.py'),
 ('workers/l16_rare_compete','rate_bound.py'),
 ('workers/l23_experiment_invent','derive_bounds.py'),
 ('../../workers/l01_reactor_invent','phase_bin_demo.py'),
 ('../../workers/l05_heat_invent','quantify.py'),
 ('../../workers/l07_defects_invent','selectivity_budget.py'),
 ('../../workers/l10_assembly_compete','model.py'),
 ('../../workers/l11_materials_invent','cost_model.py'),
 ('../../workers/l17_pde_invent','contrast_quotient.py'),
 ('../../workers/l20_discovery_compete','countermodel_check.py'),
]

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def run(entry):
    folder,name=entry
    src=(BASE/folder).resolve()
    label=src.name+'__'+Path(name).stem
    dst=BASE/'root'/'replays'/label
    dst.mkdir(parents=True,exist_ok=False)
    package=dst/'package'
    if folder=='root':
        package.mkdir()
        shutil.copy2(src/name,package/name)
    else:
        shutil.copytree(src,package,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    started=time.monotonic()
    try:
        p=subprocess.run([sys.executable,name],cwd=package,capture_output=True,timeout=90)
        code=p.returncode; stdout=p.stdout; stderr=p.stderr; state='completed'
    except subprocess.TimeoutExpired as e:
        code=None; stdout=e.stdout or b''; stderr=e.stderr or b''; state='timed_out'
    (dst/'stdout.txt').write_bytes(stdout)
    (dst/'stderr.txt').write_bytes(stderr)
    return {'source':str(src/name),'source_sha256':sha(src/name),
            'python':sys.executable,'command':[sys.executable,name],
            'copy_cwd':str(package),'state':state,'exit_code':code,
            'elapsed_wall_seconds':time.monotonic()-started,
            'stdout_sha256':sha(dst/'stdout.txt'),'stderr_sha256':sha(dst/'stderr.txt'),
            'receipt_dir':str(dst.relative_to(BASE)),
            'scope':'finite model execution only; no physical, prior-art or all-proof certification'}

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        rows=list(pool.map(run,TASKS))
    out={'scope':'copy-first finite replay only','results':rows,
         'passed':sum(r['exit_code']==0 for r in rows),'attempted':len(rows)}
    (BASE/'root'/'REPLAY_RECEIPTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'attempted':len(rows),'passed':out['passed'],
                      'failures':[r for r in rows if r['exit_code']!=0]},indent=2))
