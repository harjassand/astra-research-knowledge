"""Verify retained bytes in either the complete or authored extraction."""
from pathlib import Path
import hashlib,json

base=Path(__file__).resolve().parents[1]
name='AUTHORED_MANIFEST.json' if (base/'AUTHORED_MANIFEST.json').exists() else 'MANIFEST.json'
manifest=json.loads((base/name).read_text())
errors=[]
for row in manifest['files']:
    p=base/row['path']
    if not p.is_file(): errors.append({'path':row['path'],'error':'missing'})
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
        errors.append({'path':row['path'],'error':'hash mismatch'})
print(json.dumps({'manifest':name,'checked':len(manifest['files']),'errors':errors,
                  'scope':'byte integrity only; not scientific validation'},indent=2))
raise SystemExit(bool(errors))
