# Astra scientific computational investigation
## Rare-event kinetic computation: validated incumbent and sharp pathwise obstruction

**Date:** 16 October 2026. **Status:** research obstruction and reproducibility package, not a foundational invention or a demonstrated new scientific capability.

## Outcome

This invocation independently screened several computational frontiers, acquired a published spatial reaction model, implemented a standard rare-event incumbent, ran it on the full eight-site lattice, and derived exact limitations on a possible learned-committor route. It did not establish superiority to the strongest current algorithms. The strongest retained mathematical result is a general branching-routing obstruction, with two exact stability thresholds and a work/second-moment inequality. Full proofs are in `PROOFS.md`.

The intended conceptual shortcut was to predict the probability of a successful transition and use that information to guide rare trajectories, rather than reconstruct the entire evolving molecular-count distribution. Approximate Doob transforms already implement this idea. The question investigated here was whether a compact, uniformly accurate committor approximation would provide a robust path to affordable kinetic answers. The answer is negative without additional control of pathwise likelihood accumulation and excursion cost.

Removing clock reweighting was investigated as a repair. It cures the two-state example but fails on a branching triangle, and a general irreducible-chain argument shows the failure is not specific to that triangle. Contracting entire excursions was then examined as a mathematically different operation; it solves the diagnostic examples but reduces to established block resolvents and graph transformation. No acquisition-efficient new contraction for the full reaction configuration graph was obtained.

## 1. Opportunity screen

| Scientific output | Incumbent check | Decision in this invocation |
|---|---|---|
| Nonlinear turbulent heat transport in stellarators | Published GX–DESC workflows directly optimize nonlinear heat flux, not merely linear growth-rate proxies. | No nonlinear gyrokinetic incumbent executed; no proposed replacement validated. |
| Spin gaps or reaction energetics in correlated-electron chemistry | Selected-CI and other problem-specific calculations must be compared on identical integrals and model spaces. | No decisive molecule/integral acquisition plus incumbent execution completed. Not selected for a numerical novelty claim. |
| Spectral observables inferred from Euclidean data | Lawrence's 2024 Lagrange-dual framework already bounds observables without reconstructing a unique spectral function. Recent causal/kernel-bound work was also screened. | Rejected “avoid full spectral reconstruction” as a new primitive by itself. |
| Switching in spatial stochastic chemical kinetics | Published NNCME-2 provides a model, source, and full eight-site setting; direct-event simulation and splitting can be executed. | Selected for an incumbent experiment and a precise investigation of a possible algorithmic obstruction. |

This was an opportunity screen, not proof that kinetics is the most consequential remaining frontier. In particular, an accessible benchmark is not evidence of an unavailable scientific capability. The full strongest-method comparison and the connection to a calibrated technological decision remain open gates.

## 2. Acquired governing model and output contract

The model is the spatial Schlögl reaction network in Weng et al., *Tracking large chemical reaction networks and rare events by neural networks*, arXiv:2512.10309v1. The upstream source file `NNCME-2/nncme/systems/Schlogl_2d.py` was retrieved through the GitHub connector; its Git blob SHA is `91ddf7778cca22beb83d261e372eb85ea32f44f0`. This pins the system-definition file, not the entire upstream training environment. The published parameters, initial state, and grid construction were inspected. No neural-network code was executed.

The executed model has a 2x4 open-boundary grid and eight integer counts. Each site has four chemical channels; there are 20 directed diffusion channels. The SSA kernel combines pairs of channels that cause the same state change, giving 16 local state-change channels plus 20 diffusion channels. This aggregation preserves the Markov dynamics.

At a site with count n, the combined birth and death propensities are

\[
b(n)=2.676n(n-1)+108.102,
\]
\[
a(n)=0.040n(n-1)(n-2)+37.881n.
\]

A directed nearest-neighbor diffusion event from site i has rate 8.2207 n_i. The source's parameter `Para` is set to one. The falling-factorial convention has no additional factorial divisors. Initial counts are all 50. Rates are implemented in IEEE floating point; the JSON model contract records the decimal coefficients as strings.

The explicitly selected output is

\[
p_1=\Pr_{(50,\ldots,50)}(\tau_B\le1),
\qquad B=\{n:\max_i n_i\le15\}.
\]

This is first entry before a deadline, not probability of being in B at the deadline, not a stationary population, and not an asymptotic transition rate. Elapsed times are carried through splitting resampling. The paths are not artificially reset to time zero at an interface.

**Model-match limitation:** the executed SSA allows unbounded counts. NNCME-2's table uses M=85, and its text defines supported counts as 0,...,M-1. The published neural run also targets an evolving distribution rather than this explicitly absorbing first-passage problem. Therefore its reported 102.82 V100 GPU hours is not a matched timing baseline and is not used to claim a speedup. Our simulations observed counts as high as 109 in the main repetitions, so an upper population cutoff cannot simply be ignored.

This is a published mechanistic reaction benchmark, not a calibrated catalyst, protein, reactor or manufacturing process. No measured rate uncertainties or governing-model discrepancies were supplied. The result does not directly determine a real technological design.

## 3. Executed incumbent

`kinetics.py` implements the direct stochastic simulation algorithm, with exact-event scheduling in the mathematical algorithm and floating numerical rates/RNG. Standard fixed-level sequential splitting follows nested interfaces max(n)<=47,45,...,15. At each interface, successful complete states and their accumulated times are resampled with replacement. Every subsequent segment follows the original physical dynamics. No learned potential, learned rate, neural policy, or approximation to the generator is used.

The product of stage survival fractions is the standard fixed-level normalizing-constant estimator. It is unbiased in the ideal algorithm. The usual proof uses conditional expectation of the resampled empirical measure at each stage; resampling preserves its expected unnormalized measure. Stage-wise binomial standard errors cannot simply be multiplied because descendants share ancestors. Independent full repetitions were therefore used for the reported empirical uncertainty.

A 128-particle coarse-interface pilot was used to choose more closely spaced fixed interfaces. It is excluded from the 12-repetition mean below. Each independent repetition used 256 particles at each of the 17 fixed interfaces. Seeds are recorded and were set before the validation repetitions.

| Quantity | Executed result |
|---|---:|
| Independent full-lattice repetitions | 12 |
| Mean probability estimate | 3.8060689122e-8 |
| Empirical standard error of that mean | 1.4263316151e-8 |
| Relative empirical standard error | 37.475% |
| Smallest repetition | 8.5358673741e-11 |
| Largest repetition | 1.6924329184e-7 |
| Total simulated primitive reaction events | 1,283,689,381 |
| Sum of per-repetition measured wall times | 163.407 seconds |
| Highest count observed | 109 |

The high repetition dispersion is a central result, not a detail to conceal. Twelve skewed rare-event estimates do not support a rigorous uncertainty certificate. The descriptive Student-t interval retained in the JSON is not asserted to have rigorous 95% coverage. Neither the mean nor any individual small error bar should be promoted to a certified scientific answer. Further coordinate/particle optimization might greatly improve this established incumbent; this invocation did not determine its best possible efficiency.

The 163.4 seconds excludes literature/source acquisition, reasoning, code writing, some compilation/import overhead, diagnostic runs, and a failed 40-second reference attempt. It is a kernel/workflow measurement, not total research cost. Per-process peak RSS was not recorded. `environment.json` lists versions, processor information, timing scope and known failed attempts. No matched resource superiority claim is made.

## 4. Independent sampler diagnostic

A two-site instance with the same local chemistry and diffusion was used ONLY to validate the implementation. It does not replace the full eight-site benchmark. At T=0.2, a sparse master-equation finite-state projection includes all count pairs up to 120, makes B absorbing, and sends every outward transition to an absorbing overflow sink.

The resulting 14,387-state, 100,004-nonzero matrix exponential gave

- hit probability mass: 0.007557201299307495;
- overflow probability mass: 2.5728592541872614e-9;
- total probability: 0.9999999999992616.

The analytic finite-state-projection inequality is hit_mass <= true hitting probability <= hit_mass+overflow_mass. The calculation here used floating `expm_multiply`, not outward-rounded interval arithmetic, so the displayed narrow bracket is a numerical FSP bracket rather than a fully rigorous computer certificate.

For comparison, 65,536 independently simulated untruncated SSA trajectories produced 504 hits, estimate 0.0076904296875. The exact-binomial 95% interval for that Bernoulli experiment is [0.0070358548,0.0083891420], containing the numerical master-equation value. Sixteen independent two-site splitting runs gave mean 0.0078946993 and empirical standard error 0.0006075461, also statistically consistent. This is a useful independent diagnostic, not a proof that the eight-site tail estimate is accurate.

The smaller cap-100 FSP test is retained too. Its overflow mass is about 1.495e-4, demonstrating why truncation must be accounted for instead of silently imposed. A cap-100 T=1 attempt timed out at 40 seconds; the successful diagnostic uses T=0.2 explicitly.

## 5. Retained mathematical result

For a chain with two internal states interconverting at rate one and state-independent absorption hazard kappa, the exact committor is p. A relative approximation p(1+delta),p(1-delta), inserted into the ordinary approximate Doob transform, has finite likelihood-estimator variance exactly when

\[
\delta^2<\frac{\kappa}{4(1+\kappa)}.
\]

Thus arbitrarily small fixed relative errors can fail as trapping becomes longer. At kappa=10^-6, delta=0.01 and p=10^-12 the estimator is unbiased but has infinite variance.

Removing waiting-time reweighting makes this two-state example stable for squared errors approaching 1/2. However, for a fully connected three-state internal chain and relative multipliers (1+delta,1,1-delta), even the clock-marginalized estimator is stable exactly when

\[
\delta^2<\frac{\kappa(\kappa+2)^2}{\kappa^3+4\kappa^2+7\kappa+4}.
\]

The same one-percent example fails. A rational vector certifies spectral growth without relying on floating eigenvalues.

The general result is stronger than either fixture: if a positive committor approximation changes the relative routing between possible internal destinations in an irreducible finite chain, then sufficiently weak absorption produces infinite second moment even after clocks are marginalized. The proof uses a strict Cauchy-Schwarz row inequality and Perron–Frobenius theory. Its local critical scale is governed by the stationary average of the conditional variance of the approximation error over the next internal step.

A second result separates statistical rarity from actual trajectory work:

\[
\mathbb E_Q C\;\frac{\mathbb E_Q W^2}{p^2}
\ge(\mathbb E_{P(\cdot\mid B)}\sqrt C)^2.
\]

For successful paths requiring a geometric number of primitive jumps with mean of order 1/kappa, bounded normalized second moment still leaves expected per-path work of that order. This is a path-explicit importance-sampling statement, not an impossibility theorem for analytic contraction, control variates, or all computational methods. It uses second moment, not variance alone.

`verify_algebra.py` passed 17 exact symbolic/rational checks supporting the identities and witnesses. The general arguments are analytic proofs in `PROOFS.md`, not finite-test extrapolations and not Lean-verified theorems. No independent reviewer or historical-priority clearance was obtained.

## 6. Strongest competition and failed novelty claims

| Candidate claim | Check and disposition |
|---|---|
| A compact committor creates a new rare-event operation. | Doob changes of measure are established. A new representation requires an actual acquisition/cost advantage. |
| Uniform relative committor accuracy ensures reliable reweighting. | False over unrestricted stopping-time networks; exact counterexamples and general routing theorem supplied. |
| Marginalizing clocks removes the instability. | True on the alternating two-state fixture, false on the triangle and general branching family. Also existing embedded-chain machinery. |
| Small variance means small total computation. | False for explicit long-path sampling; work/second-moment bound supplied. |
| Contract whole excursions instead. | Works on the exact fixtures, but is ordinary lumpability/block-resolvent/graph-transformation machinery. No new scalable contraction was demonstrated. |
| This outperforms NNCME-2 or current control/tensor approaches. | Not established: original neural training, tensor-network kinetics, and 2026 control-policy implementations were not executed under a matched contract. |

Kuruganti and Strickland already study Markov-chain variance computation and embedded-chain importance sampling. Hartmann and Richter study sensitivity to suboptimal proposals. Hartmann et al.'s September 2026 paper directly addresses unbounded stopping times, long-trajectory reweighting, variance-versus-duration tradeoffs, and control-based formulations without that reweighting. These competitors prevent promotion of the broad conceptual observation as new. State elimination and first-passage-distribution contraction likewise have substantial prior art.

## 7. What a genuine enabling operation still has to accomplish

A useful target is an efficiently acquired, composable **joint exit-time/exit-channel operator** for metastable modules of an implicit reaction configuration graph. A formal dense inverse is not a solution. Such an operator must preserve rare reactive channels with relative accuracy, retain deadline information, charge model acquisition and module construction, control numerical and statistical errors, and beat existing direct solvers, splitting, control, tensor representations and graph elimination under the same output contract.

This is a precise uncompleted mathematical objective, not a claim that the operation was invented here. The present results exclude an insufficient route and distinguish two costs that a surviving operation must address. The full eight-site experiment supplies an executable reference setting, but not evidence that all serious incumbents are exhausted or that a calibrated technological decision has become attainable.

**Promotion decision:** retain the benchmark implementation, sharp obstruction proofs, exact witnesses and failure history as research capital. Do not promote this invocation to a foundational invention, strongest-method advantage, or extraordinary scientific/technological capability.

## Primary sources

- Weng et al., *Tracking large chemical reaction networks and rare events by neural networks*, https://arxiv.org/html/2512.10309v1.
- Upstream system source: https://github.com/Machine-learning-and-complex-systems/NNCME/blob/main/NNCME-2/nncme/systems/Schlogl_2d.py, blob SHA recorded above.
- Kim et al., *Optimization of Nonlinear Turbulence in Stellarators*, https://arxiv.org/abs/2310.18842.
- Lawrence, *Model-free spectral reconstruction via Lagrange duality*, https://arxiv.org/abs/2408.11766.
- Kuruganti and Strickland (1996), https://www.informs-sim.org/wsc96papers/036.pdf.
- Hartmann and Richter, https://arxiv.org/abs/2102.09606.
- Hartmann et al., https://arxiv.org/html/2601.01489v2.
- Trygubenko and Wales, https://arxiv.org/abs/cond-mat/0603830.
- Woods et al., https://pmc.ncbi.nlm.nih.gov/articles/PMC10200351/.
- Woods and Wales (2024), https://pubmed.ncbi.nlm.nih.gov/38059562/.

Astra and OpenAI's math repositories were consulted at their entry/navigation level. No theorem from either repository is a premise of this note. Their publication or inclusion was not treated as independent proof validation.
