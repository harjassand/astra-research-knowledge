#!/usr/bin/env python3
"""Independent finite reconstruction of Sol's permitted-mold fixture.
This is a scoped proof-route check, not a quasiconvexity counterexample.
Only the Python standard library is required.
"""
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
U=[[0,4],[2,3]];V=[[1,0],[0,2]]
def gradients(grid):
    out=[]
    for y in range(2):
        for x in range(2):
            a=grid[y][x];b=grid[y][(x+1)%2];c=grid[(y+1)%2][x];d=grid[(y+1)%2][(x+1)%2]
            out.extend([(2*(b-a),2*(c-a)),(2*(d-c),2*(d-b))])
    return out
ug=gradients(U);vg=gradients(V)
assert ug==[(8,4),(2,-2),(-8,-2),(-2,4),(2,-4),(8,2),(-2,2),(-8,-4)]
assert vg==[(-2,-2),(4,4),(2,4),(-4,-2),(4,2),(-2,-4),(-4,-4),(2,2)]
assert all(sum(z[i] for z in ug)==sum(z[i] for z in vg)==0 for i in range(2))
pairs=[(0,3),(2,1),(4,7),(6,5),(0,5),(2,7),(4,1),(6,3)]
for num,(a,b) in enumerate(pairs):
    normal=(1,0) if num<4 else (0,1)
    for g in (ug,vg):
        dx=g[a][0]-g[b][0];dy=g[a][1]-g[b][1]
        assert dx*normal[1]-dy*normal[0]==0
assert all(sum(i in pair for pair in pairs)==2 for i in range(8))
assert 2*Fraction(1,48)==Fraction(1,24) and 6*Fraction(1,48)==Fraction(1,8)
# Differences of barycentres at mandatory consecutive interface pairs (4,1),(6,3).
vals=[]
for a,b,c,d in product([0,1],repeat=4):
    ux,uy=4,-6-2*a+2*b
    vx,vy=8,6-2*c+2*d
    det=ux*vy-uy*vx
    assert det==72+16*a-16*b-8*c+8*d
    vals.append(det)
assert min(vals)==48
# The displayed determinant is affine in each independent fraction, so corners
# give its exact minimum on the entire [0,1]^4 box, a superset of feasible weights.
receipt={'status':'PASS','gradient_arrays':{'u':ug,'v':vg},'box_determinant_minimum':48,
 'scope':'Reconstructs source nodal fixture, relevant interface compatibilities, mass arithmetic, and universal subtree separation. Primary Section 4 labeling permission and Definition 6.1 are reviewed in the report. Does not refute planar ROC=>QC.'}
(ROOT/'evidence'/'peer_reconstruction.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS: nodal gradients, relevant interface compatibility, uniform masses, and exact determinant >=48')
