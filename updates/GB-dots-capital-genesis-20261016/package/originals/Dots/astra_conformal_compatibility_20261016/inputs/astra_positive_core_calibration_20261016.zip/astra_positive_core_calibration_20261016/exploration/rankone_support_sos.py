import sympy as s,numpy as np,json,time,sys
from pathlib import Path
root=Path(__file__).parent
r=s.Rational(sys.argv[1]) if len(sys.argv)>1 else s.Integer(1)
x,y,c,d,p,q=s.symbols('x y c d p q');X=(x,y,c,d,p,q)
a=x+p;b=y+q;u=a*a+c*c;v=b*b+d*d;j=a*d-b*c
al=3*r/(8*(r+2));be=r*(r-1)/6
F=al*(u+v-2*j)**2+be*u*u+j*j+r*u*j
p0=al*(p*p+q*q)**2+be*p**4
la=r*p*p-4*al*(p*p+q*q)
R=s.Poly(s.expand(F-p0-s.diff(p0,p)*x-s.diff(p0,q)*y-la*j),X)
mons=[]
for i in range(6):
 for jj in range(i,6):
  if i>=4:continue
  e=[0]*6;e[i]+=1;e[jj]+=1;mons.append(tuple(e))
n=len(mons);expidx={};groups=[]
for i,ei in enumerate(mons):
 for jj,ej in enumerate(mons):
  ex=tuple(a+b for a,b in zip(ei,ej));
  if ex not in expidx:expidx[ex]=len(groups);groups.append([])
  groups[expidx[ex]].append(i*n+jj)
assert set(R.monoms())<=set(expidx)
bb=np.array([float(R.coeff_monomial(ex)) for ex in expidx]);count=np.array([len(g) for g in groups]);rows=np.array([expidx[tuple(a+b for a,b in zip(ei,ej))] for ei in mons for ej in mons]);den=np.array(count)[rows]
def aff(Q):
 v=Q.ravel();res=bb-np.bincount(rows,weights=v,minlength=len(bb));return Q+(res[rows]/den).reshape(n,n)
def psd(Q):
 eig,U=np.linalg.eigh(Q);return (U*np.maximum(eig,1e-7))@U.T
# Douglas Rachford
Q=aff(np.eye(n));t0=time.time()
for it in range(60000):
 P=psd(Q);A=aff(2*P-Q);Q+=A-P
 if it%1000==0:
  E=aff(P);mi=np.linalg.eigvalsh(E)[0];err=np.linalg.norm(E-P)
  print(it,mi,err,flush=True)
  if mi>1e-10 and err<1e-6:break
E=aff(psd(Q));print('FINAL',it,np.linalg.eigvalsh(E),time.time()-t0,flush=True)
np.savez(root/f'rankone_support_r{str(r).replace("/","_")}.npz',Q=E,mons=mons,r=str(r))
# Rationalize selected free entries and reconstruct coefficient constraints independently for each exponent.
Qr=s.zeros(n)
for i in range(n):
 for jj in range(i,n): Qr[i,jj]=Qr[jj,i]=s.Rational(float(E[i,jj])).limit_denominator(10**7)
for ex,idx in expidx.items():
 pairs=[(k//n,k%n) for k in groups[idx] if k//n<=k%n];i,jj=pairs[0]
 residual=R.coeff_monomial(ex)-sum((1 if u==v else 2)*Qr[u,v] for u,v in pairs)
 Qr[i,jj]+=residual/(1 if i==jj else 2);Qr[jj,i]=Qr[i,jj]
try:
 LL,DD=Qr.LDLdecomposition(hermitian=False);piv=[DD[i,i] for i in range(n)];passed=all(p>0 for p in piv)
except Exception as exc: print('ldl fail',str(exc));passed=False;piv=[]
print('RATIONAL POSITIVE',passed,flush=True)
if passed:
 zz=s.Matrix([s.prod(v**e for v,e in zip(X,ex)) for ex in mons]);assert s.Poly((zz.T*Qr*zz)[0]-R.as_expr(),X).is_zero
 (root/f'RANKONE_SUPPORT_r{str(r).replace("/","_")}.json').write_text(json.dumps({'r':str(r),'variables':[str(v) for v in X],'monomials':mons,'gram':[[str(Qr[i,j]) for j in range(n)] for i in range(n)],'ldl_pivots':[str(p) for p in piv]},indent=2))
