# Positive sharp-core background calibration

Start with `RESEARCH_REPORT.md` and `RESEARCH_STATE.json`.

The complete positive-coupling all-background quasiconvexity problem remains unresolved. This packet proves fixed-coefficient results on an explicit affine-background cone, including every singular background, and records the surviving contact-background obligation.

## Exact replay

```sh
python -m pip install sympy
python verify_calibration.py
python verify_peer_obstruction.py
```

The first command verifies all 24 exact algebraic groups. Positivity and Sobolev passage proofs are in the report. The peer check is a separate, attributed proof-route reconstruction, not a Morrey counterexample.

`CALIBRATION.json` contains the compact universal coefficient formulas. `VERIFICATION_RECEIPT.json` and `evidence/verification.log` record the executed replay.

## Exploratory data

`SEARCH_SUMMARY.json` and `exploration/` preserve 200 local numerical searches over compatible Fourier and periodic P1 maps. None is a global lower bound or a QC proof. The recorded search loss used a regularized moment inverse. The saved candidates were separately re-evaluated at their actual backgrounds; the three rounded P1 candidates also have exact rational positive-energy receipts.

Rechecking saved candidates requires NumPy and SymPy:

```sh
python audit_saved_searches.py
```

The original optional optimization scripts additionally require PyTorch. They are not needed to verify the mathematical certificate.

No repository was modified. Source pins, reading scope, attribution, and unresolved external-review/priority status are recorded in `SOURCES.json` and the report.
