"""Exploratory Fourier search. No floating result is a proof."""
import torch,numpy as np,sympy as s,json,time,sys
from pathlib import Path
root=Path(__file__).parent
torch.set_num_threads(1);torch.set_default_dtype(torch.float64)
r=float(sys.argv[1]) if len(sys.argv)>1 else 1.;m=int(sys.argv[2]) if len(sys.argv)>2 else 3
nseeds=int(sys.argv[3]) if len(sys.argv)>3 else 20
steps=int(sys.argv[4]) if len(sys.argv)>4 else 200
N=4*m+1
x,y=np.meshgrid(np.arange(N)*2*np.pi/N,np.arange(N)*2*np.pi/N,indexing='ij')
modes=[(p,q) for p in range(m+1) for q in range(-m,m+1) if p>0 or q>0]
Db=[]
for p,q in modes:
 th=(p*x+q*y).flatten()
 for fun in [-np.sin(th),np.cos(th)]: Db.append(np.array([p*fun,q*fun])/np.sqrt(p*p+q*q))
Db=torch.tensor(np.stack(Db))
X=s.symbols('a b c d');a,b,c,d=X;rr=s.Rational(str(r));u=a*a+c*c;j=a*d-b*c
F=3*rr/(8*(rr+2))*((a-d)**2+(b+c)**2)**2+rr*(rr-1)/6*u*u+j*j+rr*u*j
T=np.zeros((4,4,4,4))
for i in range(4):
 for j1 in range(4):
  for k in range(4):
   for l in range(4): T[i,j1,k,l]=float(s.diff(F,X[i],X[j1],X[k],X[l])/24)
T=torch.tensor(T)
def calc(C,exact=False):
 V=torch.einsum('oi,ijg->ojg',C,Db).reshape(4,-1).T
 v2=V[:,:,None]*V[:,None,:]
 K=6*torch.einsum('ijkl,kl->ij',T,v2.mean(0))
 # avoid opt-einsum bottleneck
 grad=4*torch.einsum('ijkl,gjk,gl->gi',T,v2,V)
 c=grad.mean(0)
 base=(grad*V).sum()/len(V)/4
 eps=0 if exact else 1e-13
 B=-.5*torch.linalg.solve(K+eps*torch.eye(4)*torch.trace(K),c)
 E=base+.5*c@B
 norm=V.square().sum(1).square().mean()
 return E/norm,B,K,base/norm
records=[];best=1e9;t0=time.time()
for seed in range(nseeds):
 torch.manual_seed(seed)
 C=torch.nn.Parameter(torch.randn(2,len(Db)))
 # boundary-biased seeds occasionally
 if seed%5==4:
  with torch.no_grad(): C[1,:]*=1e-2
 opt=torch.optim.LBFGS([C],max_iter=steps,line_search_fn='strong_wolfe',tolerance_grad=1e-11,tolerance_change=1e-14)
 def closure():
  opt.zero_grad(); loss,*_=calc(C);loss.backward();return loss
 try:opt.step(closure)
 except Exception as e:print('error',seed,str(e),flush=True);continue
 with torch.no_grad():
  loss,B,K,base=calc(C);val=float(loss);mine=float(torch.linalg.eigvalsh(K)[0]);normB=float(torch.linalg.vector_norm(B))
  rec={'seed':seed,'gap_normalized':val,'zero_background':float(base),'min_K_eigenvalue':mine,'B_norm':normB}
  print(rec,flush=True);records.append(rec)
  if val<best:
   best=val;np.savez(root/f'fourier_r{r}_m{m}_best.npz',C=C.numpy(),B=B.numpy(),modes=modes,m=m,r=r,loss=val)
  (root/f'fourier_r{r}_m{m}.json').write_text(json.dumps({'r':r,'m':m,'N':N,'iteration_limit':steps,'seeds_completed':len(records),'elapsed':time.time()-t0,'records':records},indent=2))
