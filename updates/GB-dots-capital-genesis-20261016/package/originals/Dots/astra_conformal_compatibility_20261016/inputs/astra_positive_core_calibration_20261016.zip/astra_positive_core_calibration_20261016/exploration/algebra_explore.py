import sympy as s
a,b,c,d,r,L=s.symbols('a b c d r L', real=True);X=[a,b,c,d]
u=a*a+c*c;j=a*d-b*c
F=3*r/(8*(r+2))*((a-d)**2+(b+c)**2)**2+r*(r-1)/6*u*u+j*j+r*u*j
F1=s.expand(F.subs(r,1));C=s.expand(s.diff(F1,a)+s.diff(F1,d));print('C',s.factor(C));print('C div free',s.factor(C.subs(d,-2*a)))
Q=s.expand(sum(s.diff(F1,x,y)*v*w for x,v in zip(X,[1,0,0,1]) for y,w in zip(X,[1,0,0,1]))/2);print('Q',s.factor(Q));print('C with d=L-2a',s.Poly(C.subs(d,L-2*a).expand(),L,c))
print('positive general C',s.factor(s.diff(F,a)+s.diff(F,d)))
