#!/usr/bin/env python3
"""Re-evaluate saved compatible candidates independently of the optimizer.
Numerical entries are diagnostics. Rational P1 evaluations are exact but only
for the three specified rounded fields/backgrounds, not global optimization.
"""
from pathlib import Path
from fractions import Fraction as Q
import itertools,json
import numpy as np
import sympy as s
ROOT=Path(__file__).resolve().parent

def tensor(r):
    x=s.symbols('a b c d');a,b,c,d=x;rr=s.Rational(str(r));u=a*a+c*c;j=a*d-b*c
    F=3*rr/(8*(rr+2))*((a-d)**2+(b+c)**2)**2+rr*(rr-1)/6*u*u+j*j+rr*u*j
    T=np.empty((4,4,4,4))
    for ids in itertools.product(range(4),repeat=4):T[ids]=float(s.diff(F,*(x[i] for i in ids))/24)
    return T

def J(A,r):
    a,b,c,d=A;u=a*a+c*c;j=a*d-b*c
    return 3*r/(8*(r+2))*((a-d)**2+(b+c)**2)**2+r*(r-1)/6*u*u+j*j+r*u*j
records=[]
for f in sorted((ROOT/'exploration').glob('*_best.npz')):
    if not f.name.startswith(('fe_r','fourier_r')):continue
    data=np.load(f);C=data['C'];B=data['B'].reshape(4);r=float(data['r']);T=tensor(r)
    if f.name.startswith('fe_'):
        C10=np.roll(C,-1,0);C01=np.roll(C,-1,1);C11=np.roll(C10,-1,1)
        grad=np.stack([np.stack([C10-C,C11-C10],-1),np.stack([C11-C01,C01-C],-1)],0).reshape(-1,4)
    else:
        m=int(data['m']);N=4*m+1;x,y=np.meshgrid(np.arange(N)*2*np.pi/N,np.arange(N)*2*np.pi/N,indexing='ij')
        Db=[]
        for p,q in data['modes']:
            th=(p*x+q*y).flatten()
            for fun in (-np.sin(th),np.cos(th)):Db.append(np.array([p*fun,q*fun])/np.hypot(p,q))
        grad=np.einsum('oi,ijg->ojg',C,np.array(Db)).reshape(4,-1).T
    moment=np.einsum('gi,gj->ij',grad,grad)/len(grad)
    K=6*np.einsum('ijkl,kl->ij',T,moment)
    gg=4*np.einsum('ijkl,gj,gk,gl->gi',T,grad,grad,grad)
    c=gg.mean(0);a=(gg*grad).sum()/len(grad)/4;norm=np.mean(np.sum(grad*grad,1)**2)
    actual=(a+c@B+B@K@B)/norm
    ev=np.linalg.eigvalsh(K)
    rec={'file':f.name,'r':r,'actual_moment_gap_at_saved_background_float':float(actual),
         'max_abs_gradient_mean':float(np.abs(grad.mean(0)).max()),
         'det_gradient_mean':float(np.mean(grad[:,0]*grad[:,3]-grad[:,1]*grad[:,2])),
         'K_min_eigenvalue':float(ev[0]),'K_max_eigenvalue':float(ev[-1])}
    if ev[0]>1e-14*ev[-1]:
        Bopt=-np.linalg.solve(K,c)/2
        rec['unregularized_optimized_moment_gap_float']=float((a+c@Bopt+Bopt@K@Bopt)/norm)
    if f.name.startswith('fe_'):
        D=10**6;N=C.shape[0];cq=np.empty(C.shape,dtype=object)
        for idx in np.ndindex(C.shape):cq[idx]=Q(int(round(float(C[idx])*D)),D)
        bq=[Q(int(round(float(z)*D)),D) for z in B];rq=Q(str(r));G=[]
        for i in range(N):
            for j in range(N):
                v00=cq[i,j];v10=cq[(i+1)%N,j];v01=cq[i,(j+1)%N];v11=cq[(i+1)%N,(j+1)%N]
                for dx,dy in [(v10-v00,v11-v10),(v11-v01,v01-v00)]:
                    G.append([dx[0],dy[0],dx[1],dy[1]])
        assert all(sum(row[i] for row in G)==0 for i in range(4))
        assert sum(row[0]*row[3]-row[1]*row[2] for row in G)==0
        energy=sum(J([bq[i]+g[i] for i in range(4)],rq)-J(bq,rq) for g in G)/len(G)
        normq=sum(sum(z*z for z in g)**2 for g in G)/len(G)
        rec['rational_p1_rounding_denominator']=D
        rec['rational_p1_jensen_gap']=str(energy)
        rec['rational_p1_normalized_gap']=str(energy/normq)
        rec['rational_p1_sign']='POSITIVE' if energy>0 else 'NONPOSITIVE'
    records.append(rec)
(ROOT/'evidence'/'saved_search_recheck.json').write_text(json.dumps({'status':'CANDIDATE_RECHECK_ONLY','records':records},indent=2)+'\n')
for z in records:print(z['file'],z['actual_moment_gap_at_saved_background_float'],z.get('rational_p1_sign','float only'))
