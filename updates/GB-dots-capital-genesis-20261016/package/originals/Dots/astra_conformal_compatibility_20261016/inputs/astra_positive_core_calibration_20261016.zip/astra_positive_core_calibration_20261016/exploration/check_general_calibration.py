import sympy as s
r,k=s.symbols('r k',real=True); a,b,c,d,p,q,m,n=s.symbols('a b c d p q m n',real=True)
x=[a,b,c,d];A=s.Matrix([[a,b],[c,d]]);B=s.Matrix([[p,q],[m,n]]);V=A-B
u=a*a+c*c;v=b*b+d*d;w=a*b+c*d;j=a*d-b*c
u0=p*p+m*m;v0=q*q+n*n;w0=p*q+m*n;j0=p*n-q*m
al=3*r/(8*(r+2));be=r*(r-1)/6;t=(2*r+1)/3
F=al*(u+v-2*j)**2+be*u*u+j*j+r*u*j
fb=F.subs(dict(zip(x,list(B))),simultaneous=True)
gb=s.Matrix([s.diff(F,z) for z in x]).subs(dict(zip(x,list(B))),simultaneous=True)
lam=(2+8*al+4*al*k)*j0+(r-4*al)*u0-4*al*v0
M=s.Matrix([[t*t,1-k,2*t],[1-k,1,-2],[2*t,-2,4+2*k+1/al]])
L=s.Matrix([[t*t*u0+(1-k)*v0+2*t*j0,k*w0],[k*w0,(1-k)*u0+v0-2*j0]])
z=s.Matrix([u-u0,v-v0,j-j0])
rhs=al*(z.T*M*z)[0]+2*al*k*(w-w0)**2+2*al*sum((V[i,:]*L*V[i,:].T)[0] for i in range(2))
res=F-fb-(gb.T*s.Matrix(list(V)))[0]-lam*V.det()
assert s.cancel(s.expand(res-rhs))==0
print('GENERAL AFFINE CALIBRATION IDENTITY PASS')
g=A.T*A;g0=B.T*B;Z=V*B.adjugate();defect=s.Matrix([Z[0,0]-Z[1,1],Z[0,1]+Z[1,0]])
assert s.expand((g-g0).det()-(j-j0)**2+defect.dot(defect))==0
print('DETERMINANT OF GRAM-DIFFERENCE IDENTITY PASS')
