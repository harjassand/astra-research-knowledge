"""Actual periodic continuous P1 gradients; exploratory floating optimization only."""
import torch, numpy as np, sympy as s, json, sys, time
from pathlib import Path
root=Path(__file__).parent;torch.set_num_threads(1);torch.set_default_dtype(torch.float64)
r=float(sys.argv[1]);N=int(sys.argv[2]);seeds=int(sys.argv[3]);steps=int(sys.argv[4])
X=s.symbols('a b c d');a,b,c,d=X;rr=s.Rational(str(r));u=a*a+c*c;j=a*d-b*c
F=3*rr/(8*(rr+2))*((a-d)**2+(b+c)**2)**2+rr*(rr-1)/6*u*u+j*j+rr*u*j
T=np.zeros((4,4,4,4))
for i in range(4):
 for jj in range(4):
  for k in range(4):
   for l in range(4):T[i,jj,k,l]=float(s.diff(F,X[i],X[jj],X[k],X[l])/24)
T=torch.tensor(T)
def calc(C):
 V00=C;V10=C.roll(-1,0);V01=C.roll(-1,1);V11=V10.roll(-1,1)
 dx1=V10-V00;dy1=V11-V10;dx2=V11-V01;dy2=V01-V00
 V=torch.stack([torch.stack([dx1,dy1],-1),torch.stack([dx2,dy2],-1)],0).reshape(-1,4)
 v2=V[:,:,None]*V[:,None,:];K=6*torch.einsum('ijkl,kl->ij',T,v2.mean(0))
 g=4*torch.einsum('ijkl,gjk,gl->gi',T,v2,V);c=g.mean(0);A=(g*V).sum()/len(V)/4
 B=-.5*torch.linalg.solve(K+1e-13*torch.trace(K)*torch.eye(4),c)
 E=A+.5*c@B;norm=V.square().sum(1).square().mean()
 return E/norm,B,K,A/norm
records=[];best=1e30;t0=time.time()
for seed in range(seeds):
 torch.manual_seed(seed+1324);C=torch.nn.Parameter(torch.randn(N,N,2))
 opt=torch.optim.LBFGS([C],max_iter=steps,line_search_fn='strong_wolfe',tolerance_grad=1e-11,tolerance_change=1e-14)
 def closure():
  opt.zero_grad();val,*_=calc(C);val.backward();return val
 try: opt.step(closure)
 except Exception as e:print('error',seed,str(e),flush=True);continue
 with torch.no_grad():
  val,B,K,zer=calc(C);rec={'seed':seed,'gap_normalized':float(val),'zero_background':float(zer),'min_K_eigenvalue':float(torch.linalg.eigvalsh(K)[0]),'B_norm':float(torch.linalg.vector_norm(B))};records.append(rec);print(rec,flush=True)
  if val<best:best=float(val);np.savez(root/f'fe_r{r}_N{N}_best.npz',C=C.numpy(),B=B.numpy(),r=r,N=N,loss=float(val))
  (root/f'fe_r{r}_N{N}.json').write_text(json.dumps({'r':r,'N':N,'iteration_limit':steps,'seeds_completed':len(records),'elapsed':time.time()-t0,'records':records},indent=2))
