import sympy as s
r,k=s.symbols('r k', real=True); a,b,c,d,p,q=s.symbols('a b c d p q', real=True)
A=s.Matrix([[a,b],[c,d]]); B=s.Matrix([[p,q],[0,0]]); V=A-B
u=a*a+c*c; v=b*b+d*d; w=a*b+c*d; j=a*d-b*c
al=3*r/(8*(r+2)); be=r*(r-1)/6; t=(2*r+1)/3
F=al*(u+v-2*j)**2+be*u*u+j*j+r*u*j
fb=F.subs({a:p,b:q,c:0,d:0}, simultaneous=True)
grad=s.Matrix([s.diff(F,z) for z in [a,b,c,d]])
gb=grad.subs({a:p,b:q,c:0,d:0}, simultaneous=True)
lam=r*p*p-4*al*(p*p+q*q)
res=F-fb-(gb.T*s.Matrix(list(V)))[0]-lam*V.det()
M=s.Matrix([[t*t,1-k,2*t],[1-k,1,-2],[2*t,-2,4+2*k+1/al]])
L=s.Matrix([[t*t*p*p+(1-k)*q*q,k*p*q],[k*p*q,(1-k)*p*p+q*q]])
z=s.Matrix([u-p*p,v-q*q,j])
rhs=al*(z.T*M*z)[0]+2*al*k*(w-p*q)**2+2*al*sum((V[i,:]*L*V[i,:].T)[0] for i in range(2))
assert s.cancel(s.expand(res-rhs))==0
print('universal support identity PASS')
for name,kval in [('small',(r+2)/3),('large',1)]:
 mm=M.subs(k,kval); ll=L.subs(k,kval)
 print(name,[s.factor(mm[:i,:i].det()) for i in range(1,4)], s.factor(ll.det()))
 print('xxLxx',s.factor((s.Matrix([[p,q]])*ll*s.Matrix([p,q]))[0]))
R1=s.factor(res.subs(r,1))
z1=(u-p*p+2*j)**2/8+(v-q*q-2*j)**2/8+(w-p*q)**2/4+s.Rational(3,4)*j*j+((V*s.Matrix([p,q])).dot(V*s.Matrix([p,q])))/4
assert s.expand(R1-z1)==0
print('r1 simplified identity PASS')
D=M.subs({r:1,k:1})/8-s.diag(s.Rational(1,24),s.Rational(1,24),s.Rational(1,12))
print('Q lower bound LDL',D.LDLdecomposition(hermitian=False)[1])
