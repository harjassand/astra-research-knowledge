#!/usr/bin/env python3
"""Exact algebra for the positive-core background calibration.
Requires SymPy. No optimization, numerical eigenvalues, or parameter sampling.
The accompanying report supplies the analytic positivity and Sobolev arguments.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parent
checks=[]
def check(name: str, condition: bool=True) -> None:
    if not condition:
        raise AssertionError(name)
    checks.append(name)
    print('PASS:',name,flush=True)
def zero(expr) -> bool:
    if isinstance(expr,s.MatrixBase):
        return all(s.cancel(s.expand(e))==0 for e in expr)
    return s.cancel(s.expand(expr))==0

def main() -> None:
    cert=json.loads((ROOT/'CALIBRATION.json').read_text())
    r,k=s.symbols('r k',real=True)
    a,b,c,d,p,q,m,n=s.symbols('a b c d p q m n',real=True)
    xs=[a,b,c,d]
    A=s.Matrix([[a,b],[c,d]]);B=s.Matrix([[p,q],[m,n]]);V=A-B
    ua=a*a+c*c;va=b*b+d*d;wa=a*b+c*d;ja=a*d-b*c
    ub=p*p+m*m;vb=q*q+n*n;wb=p*q+m*n;jb=p*n-q*m
    env={'r':r,'k':k,'uB':ub,'vB':vb,'wB':wb,'jB':jb}
    alpha=s.sympify(cert['alpha'],locals=env);beta=s.sympify(cert['beta'],locals=env)
    t=s.sympify(cert['t'],locals=env);env.update(alpha=alpha,t=t)
    M=s.Matrix([[s.sympify(e,locals=env) for e in row] for row in cert['M']])
    L=s.Matrix([[s.sympify(e,locals=env) for e in row] for row in cert['L_B']])
    lam=s.sympify(cert['lambda_B'],locals=env)
    F=alpha*(ua+va-2*ja)**2+beta*ua**2+ja**2+r*ua*ja
    grad=s.Matrix([s.diff(F,x) for x in xs]);hess=s.hessian(F,xs)
    sub=dict(zip(xs,list(B)));FB=F.subs(sub,simultaneous=True);gB=grad.subs(sub,simultaneous=True)
    z=s.Matrix([ua-ub,va-vb,ja-jb]);dw=wa-wb
    residual=F-FB-(gB.T*s.Matrix(list(V)))[0]-lam*V.det()
    rhs=alpha*(z.T*M*z)[0]+2*alpha*k*dw**2+2*alpha*sum((V[i,:]*L*V[i,:].T)[0] for i in range(2))
    check('universal original-coefficient identity for arbitrary A,B,r,k',zero(residual-rhs))
    dg=A.T*A-B.T*B;Z=V*B.adjugate();C=s.Matrix([Z[0,0]-Z[1,1],Z[0,1]+Z[1,0]])
    check('Gram-difference determinant identity, arbitrary full-rank or singular B',zero(dg.det()-(ja-jb)**2+C.dot(C)))
    check('left-output rotation infinitesimal invariance',zero(-c*grad[0]-d*grad[1]+a*grad[2]+b*grad[3]))

    dp=9*r*k*k+6*(r+2)**2*k-4*(r+2)**2
    minors=[s.factor(M[:i,:i].det()) for i in range(1,4)]
    expect=[t*t,(1+t-k)*(t+k-1),2*(-3*k+2*r+4)*dp/(27*r)]
    check('three exact M Sylvester minors and determinant factorization',all(zero(x-y) for x,y in zip(minors,expect)))
    # The positive root lies strictly between max(0,1-t) and min(1,(t+1)/2).
    check('root sign certificates',zero(dp.subs(k,0)+4*(r+2)**2)
          and zero(dp.subs(k,1)-(2*r*r+17*r+8))
          and zero(dp.subs(k,(r+2)/3)-3*r*(r+2)**2)
          and zero(dp.subs(k,1-t)+12*r*(2*r+1)))
    y=s.symbols('y',real=True)
    root=4*(r+2)/(3*(y+r+2))
    num=s.together(dp.subs(k,root)).as_numer_denom()[0]
    check('radical root formula',s.rem(s.Poly(num,y),s.Poly(y*y-(r*r+8*r+4),y)).is_zero)
    check('L decreases with k by the cofactor Gram matrix',zero(s.diff(L,k)+(B.T*B).adjugate()))
    # Specializing B=e1 tensor (p,q) is no loss for singular backgrounds by left rotations.
    Lsing=L.subs({m:0,n:0});xsig=s.Matrix([p,q])
    check('singular-background determinant and radial direction',
          zero(Lsing.det()-((1-k)*(t*p*p-q*q)**2+(t+1)*(t+1-2*k)*p*p*q*q))
          and zero((xsig.T*Lsing*xsig)[0]-(t*t*p**4+2*p*p*q*q+q**4)))
    for label,kk,expected in [
        ('0<r<=1',(r+2)/3,[t*t,r*(r+2)/3,2*(r+2)**3/9]),
        ('r>=1',s.Integer(1),[t*t,t*t,2*(r+8)*(2*r+1)**2/(27*r)])]:
        mm=M.subs(k,kk)
        check('rational strictly positive M specialization '+label,
              all(zero(mm[:i,:i].det()-expected[i-1]) for i in range(1,4)))

    rational_k=s.Rational(2,3)
    mm=M.subs(k,rational_k)
    check('one rational positive matrix for every r>0: k=2/3',
          all(zero(mm[:i,:i].det()-ee) for i,ee in enumerate(
              [t*t,4*r*(r+1)/9,16*(r+1)/27],start=1))
          and zero(dp.subs(k,rational_k)-4*r))

    # Independent ROC reconstruction at the unchanged sharp coefficient.
    zeta=s.symbols('zeta',real=True)
    direction=s.Matrix([1,zeta,0,0])
    acoustic=s.hessian((direction.T*hess*direction)[0],xs)/2
    U=s.Matrix([[1,0,1,0],[0,-1,0,1],[0,1,0,1],[1,0,-1,0]])/2
    Q=s.simplify(U.T*acoustic*U)
    Ac=s.Matrix([[(r+1)**2/2,-zeta*(r+1)/2],[-zeta*(r+1)/2,(3*zeta*zeta+r*(r+2))/6]])
    check('independent conformal acoustic block',zero(Q[:2,:2]-Ac))
    br=r*(5*r+4)/(24*(r+1)**2);cr=alpha/(r+1)**2
    Sc=4*s.Matrix([[(alpha-cr)*zeta*zeta+3*(alpha-br),(2*alpha-alpha/(r+1))*zeta],
                   [(2*alpha-alpha/(r+1))*zeta,3*alpha*zeta*zeta]])
    check('independent exact acoustic Schur complement for r>0',zero(Q[2:,2:]-Q[2:,:2]*Ac.inv()*Q[:2,2:]-Sc))
    check('positive acoustic determinant and sharp contact',
          zero(Ac.det()-r*(r+1)**2*(r+2)/12)
          and zero(Sc.det()-48*alpha*(alpha-cr)*zeta**4)
          and zero(acoustic.det()-9*r**4*zeta**4))

    # Explicit coercivity at every singular background for r=1.
    R1=residual.subs({r:1,m:0,n:0}) # independent of k because jB=0
    VV=V.subs({m:0,n:0});vxi=VV*xsig
    explicit=(ua-p*p+2*ja)**2/8+(va-q*q-2*ja)**2/8+(wa-p*q)**2/4+s.Rational(3,4)*ja**2+vxi.dot(vxi)/4
    check('r=1 short sum-of-squares at every singular background',zero(R1-explicit))
    S,X=s.symbols('S X',real=True)
    check('pure fourth-power 1/32 coefficient',zero((S+2*X)**2/16+X**2/4-S*S/32-(S+4*X)**2/32))
    L23=Lsing.subs({r:1,k:s.Rational(2,3)})
    check('quadratic margin 1/12 at r=1',zero(L23-(p*p+q*q)*s.eye(2)/3-2*xsig*xsig.T/3))
    check('mixed margin 1/44 arithmetic',s.Rational(1,44)*(12+32)==1)
    mm=M.subs({r:1,k:s.Rational(2,3)})
    check('positive rational matrix for mixed margin',
          [s.factor(mm[:i,:i].det()) for i in range(1,4)]==[1,s.Rational(8,9),s.Rational(32,27)])

    # r=1 full-background cone and its orientation-uniform condition-number subcone.
    U0,V0,W0,J0=s.symbols('U0 V0 W0 J0',real=True)
    LM=s.Matrix([[U0+(1-k)*V0+2*J0,k*W0],[k*W0,(1-k)*U0+V0-2*J0]])
    detexpected=(1-k)*(U0+V0)**2-2*k*(U0-V0)*J0-(4-k*k)*J0*J0
    check('explicit r=1 background cone',zero(LM.det()-detexpected-k*k*(U0*V0-W0*W0-J0*J0)))
    e=s.symbols('e',real=True)
    check('orientation-uniform singular-value threshold',zero(((2-k)*(1+e*e)-k*(1-e*e)-4*e)/2-((1-e)**2-k)))
    check('r=1 endpoint parameter',zero(dp.subs(r,1)-9*(k*k+6*k-4)))

    # Fixed-coefficient supporting-plane obstruction at the remaining conformal background.
    h=s.symbols('h',real=True);I=s.eye(2);W=h*s.diag(1,-r-1)
    fi=F.subs({a:1,b:0,c:0,d:1});gi=grad.subs({a:1,b:0,c:0,d:1})
    D=I+W
    cubic=F.subs(dict(zip(xs,list(D))),simultaneous=True)-fi-(gi.T*s.Matrix(list(W)))[0]-(r+2)*W.det()
    target=-r*(r+2)*h**3/3+(alpha*(r+2)**4+(r+2)*(r+3)/6)*h**4
    check('nonpolyconvexity cubic residual, r>0',zero(cubic-target))
    # Known moment reduction, specialized to the simplest unresolved background.
    F1=F.subs(r,1);g1=grad.subs(r,1);H1=hess.subs(r,1);ivec=s.Matrix([1,0,0,1])
    C1=(ivec.T*g1)[0]
    Cexp=a**3+5*a*a*d-4*a*b*c+a*c*c+2*a*d*d-2*b*c*d+c*c*d
    check('exact conformal-background cubic and acoustic gate',zero(C1-Cexp)
          and zero((ivec.T*H1*ivec)[0]/2-(2*a+d)**2-c*c-3*ja))
    receipt={'status':'ALL_EXACT_GROUPS_PASS','groups':checks,'number_of_groups':len(checks),
             'certificate_sha256':hashlib.sha256((ROOT/'CALIBRATION.json').read_bytes()).hexdigest(),
             'scope':'Exact symbolic algebra only. Report supplies positivity, integration, and strictness proofs. Full positive-core QC not proved.',
             'sympy_version':s.__version__}
    (ROOT/'VERIFICATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(f'ALL {len(checks)} EXACT GROUPS PASS')

if __name__=='__main__':
    main()
