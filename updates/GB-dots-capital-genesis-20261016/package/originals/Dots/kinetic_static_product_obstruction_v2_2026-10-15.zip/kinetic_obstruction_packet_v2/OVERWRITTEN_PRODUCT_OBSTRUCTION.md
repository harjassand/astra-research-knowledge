# Actual-boundary static product obstruction

## Stronger result
The exact native-product obstruction extends to the stronger, actual-target-boundary class: arbitrary positive static product factors on continuation states, with the target prescribed exactly one. No restrictions on low-count factor values are imposed.

Every such exponential-time barrier has initial value at least exp(−δ), with exact rational δ=2.666777495494622…×10^−22<3×10^−22. Thus it exceeds 1−3×10^−22. Adding the existing overflow allowance and clipping at one yields only one. This quantifies failure of this entire static product interface, not a lower bound on the actual first-hit probability.

## Class and time orientation
On continuation states n∉A let g(t,n)=exp(λ(1−t)+F(n)), where F(n)=Σ_iφ_i(n_i) and every φ_i(0),…,φ_i(162) is a finite unrestricted real number. On A prescribe g=1, and at overflow prescribe g=0. Require the full actual generator supercaloric inequality ∂_t g+Qg≤0 on continuation states for0≤t≤1. Nonnegative terminal continuation values are automatic.

For λ≥0 the target-entry ratio exp(−λ(1−t)−F(n)) is largest at t=1. All other generator ratios are independent of time. Therefore the all-time condition is equivalent to the static terminal-boundary condition Qhat exp(F)/exp(F)≤λ, with target value one and overflow zero. In particular this terminal residual condition is necessary even if only times below1 are imposed, by continuity.

Negative λ loses no candidates: replace λ by zero and F by F+λ. Initial values are unchanged. The new target-entry ratios equal the old ones at t=0, which were maximal when λ<0, while all continuation ratios are unchanged. The old residual at t=0 was≤λ<0, so the new residual is≤0. Thus λ≥0 is without loss here too.

Convex averaging over graph automorphisms again reduces arbitrary site factors to two profiles: corners and internal-column sites. The new target-entry term is rate×exp(−F(n)), also convex in the log profiles. The objective and constraints are invariant under those automorphisms. This reduction requires no low-count normalization. A constant shift from the corner profile to the inner profile leaves F unchanged and accounts for one redundant coordinate.

## Exact finite certificate
For each selected actual continuation state s, form qhat_s as follows:
- A continuation-to-continuation transition s→y contributes rate×(F(y)−F(s)).
- A target-entry transition contributes −rate×F(s), since its ratio is exp(−F(s)).
- An overflow transition has zero log derivative and contributes its negative rate to the constant term.

Let k_s be the total overflow rate. The elementary inequality exp(x)≥1+x gives Qhat exp(F)/exp(F)≥qhat_s·φ−k_s. This includes all target-entry mechanisms: local death16→15 and diffusion from a unique count16 into an adjacent count≤14.

The self-contained file `overwritten_product_exact_dual.json` contains325 positive rational weights on actual continuation states satisfying

 c+Σ_sπ_s qhat_s=0 in all326 profile coordinates,
 Σ_sπ_s=0.7227216769616307…<1,
 Σ_sπ_s k_s=δ<3×10^−22,

where c has value four at each orbit's count50 coordinate. Multiplying λ≥qhat_s·φ−k_s byπ_s and summing proves

 λ+c·φ≥(1−Σπ_s)λ−δ≥−δ.

No constraints or numerical bounds on φ were used. Exponentiating establishes the result.

The exact reconstruction used201 core states with counts≤100 and124 sparse tail states covering101,…,162. The discovery used a tail occupation construction and exact integer-plus-rank-two reconstruction; the expanded certificate makes those discovery steps unnecessary for verification. `test_overwritten_dual.py` performs numerical support discovery; `reconstruct_overwritten_dual.py` reconstructs rational weights and checks exact identities. The expanded artifact can be checked independently using only actual reactions and rational arithmetic. Independent audit passed the full326-coordinate identity and also the full1304 site-specific identity after expanding the four graph automorphisms. Its standalone checker and result are in `certificate/overwritten/`. The expanded certificate has exactly two target-entering support states and two overflow-support states.

## What remains open
This result covers arbitrary static one-site product shapes, with a common exponential time factor and the exact target boundary, for the actual eight-site killed process. It also covers native-boundary candidates because replacing a native target value≥1 by one reduces entering-target drift. It does not rule out genuinely time-dependent local profiles, sums of products, pair factors, or richer tensor representations. The actual rare-event probability remains uncertified beyond the established overflow control.

This is standard exponential Lyapunov convexity plus an exact finite occupation-measure certificate, not a new general optimization framework. It supplies a precise representation obstruction and explains why further static-product optimization is unproductive for this benchmark.

## Horizon consequence
Let W=Σπ_s, the exact rational certificate mass. For any deadline T≥W≈0.7227216769616307, the same proof gives Tλ+c·φ≥(T−W)λ−δ≥−δ after the same negative-λ normalization with shiftλT. Thus the same near-one floor applies throughout that horizon range. This is an intrinsic limitation of the specified barrier class, not a claim that the actual process hits the target by timeW.

## Replay packaging
The discovery/reconstruction programs mentioned above are not required by or bundled in this compact packet. The complete expanded rational certificate and independent standard-library checker are in certificate/overwritten/. The intermediate native proof is in PROOF.md.
