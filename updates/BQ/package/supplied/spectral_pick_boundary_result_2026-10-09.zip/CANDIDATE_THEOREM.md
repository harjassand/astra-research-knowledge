# Candidate: a monotone Pick boundary for unknown semicircular noise

2026-10-09. Derived and self-tested by an AI research worker. One focused AI-assisted check has now completed; see FOCUSED_CHECK_2026-10-09.md. This is not external expert review, formal verification, priority certification, or real-data validation. The targeted primary-prior search did not locate this exact construction, but priority remains provisional. This is a new branch, unrelated to the closed fragmentation work.

## Practical target and current baseline

Given the spectral distribution of a large deformed Wigner matrix A+sqrt(t) W, recover t and a k-atomic limiting spectral law of A. This is already an established inference problem. Ying (2025), *Sparse free deconvolution under unknown noise level via eigenmatrix*, ACHA 79, 101802, section 3.2, explicitly searches a nonconvex singular-value objective over noise scale, then performs sparse recovery. Its finite-N examples know k. Primary source: https://web.stanford.edu/~lexing/fdc1.pdf ; DOI https://doi.org/10.1016/j.acha.2025.101802 . The proposed distinction is global monotone feasibility and an exact positive realization from k complex transform samples, not first identification of noise or first sparse deconvolution.

Classical Gaussian deconvolution already estimates variance from a first Hankel-rank boundary (Gassiat/Gautherat and successors); broadly claiming a new boundary-variance principle would be wrong. Exact free/Pick priority remains unverified.

Completion criterion: (1) establish the finite-sample-transform theorem and its true assumptions; (2) compare with strongest known methods, including finite-matrix sampling error, not just noiseless transforms; (3) demonstrate a meaningful computational or inference advantage or close as a routine reconstruction. No broad novelty claim before this gate.

## Observation and notation

Let nu be a probability measure on the real line. At distinct z_1,...,z_m in the open upper half-plane observe exact

    g_i = G_nu(z_i) = integral (z_i-x)^(-1) nu(dx).

Then Im g_i<0. For t>=0 put w_i(t)=z_i-t g_i and define

    K_ij(t) = -(g_i-conj(g_j))/(w_i(t)-conj(w_j(t)))
    S(t) = K(t)-g g*.

All denominators are nonzero, since Im w_i(t)>0. Matrices are Hermitian. Entrywise (not matrix-functional) identity:

    K(t) = K(0)/(1+t K(0)).

K(0) is the Gram matrix of phi_i(x)=(z_i-x)^(-1), and S(0) its covariance matrix. Thus S(0)>=0. At t>0,

    0 < K_ii(t) = b_i/(y_i+t b_i) < 1/t,
    b_i=-Im g_i>0, y_i=Im z_i>0.

No generic forward PSD-preservation or generic Loewner monotonicity is asserted.

## Lemma 1: exact downward feasibility and strictness

If S(t)>=0 and 0<=s<t, then S(s)>0.

Proof. K(t)>=g g*>=0. Set delta=t-s. PSD gives |K_ij(t)|<=sqrt(K_ii(t)K_jj(t)); hence delta max_i K_ii(t)<1. The following entrywise series therefore converges absolutely:

    K(s) = sum_(r>=1) delta^(r-1) K(t)^(Hadamard r).

The Schur product theorem makes every term PSD. Consequently

    S(s) = S(t) + sum_(r>=2) delta^(r-1) K(t)^(Hadamard r).

It remains to prove the latter sum is positive definite. Write K_ij(t)=<v_i,v_j> in a finite dimensional complex Hilbert space. Diagonal positivity makes every v_i nonzero. If v_i=v_j, the three entries K_ii(t),K_ij(t),K_jj(t) coincide. Applying the inverse entrywise map u -> u/(1-t u) implies that the same three entries of K(0) coincide. But their Gram difference is

    integral |(z_i-x)^(-1)-(z_j-x)^(-1)|^2 nu(dx)>0

for distinct z_i,z_j, a contradiction. Thus the v_i are distinct and nonzero. There exists a complex linear functional ell such that a_i=ell(v_i) are all distinct and nonzero: avoid finitely many proper hyperplanes. If a vector c has zero quadratic form under the sum, positivity of each summand yields sum_i c_i v_i^(tensor r)=0 for every r>=2 (with the equivalent conjugation convention if needed). Applying ell^(tensor r), r=2,...,m+1, gives sum_i c_i a_i^r=0. The coefficient matrix is an invertible Vandermonde times diag(a_i^2), so c=0. QED.

This argument does not require distinct g_i. Distinct transform arguments need not have distinct transform values.

## Theorem 2: exact variance from finitely many transforms

Suppose nu=mu free-additive-convolved with SC_(t0), where t0>=0 and mu is a probability measure on exactly k distinct real atoms with positive weights. If m>=k and the z_i are distinct upper-half-plane points, then

    {t>=0 : S(t)>=0} = [0,t0].

In particular t0 is the globally identifiable feasibility boundary and can be found by bisection without nonconvex optimization. No atom locations or weights enter the feasibility test. An operational guarantee requires knowing k or an upper bound so that m>=k is assured. The tested prototype takes known k and m=k; it is not an atom-count-free estimator. Rank reduction for m>k is not implemented.

Proof. Free semicircular subordination gives g_i=G_mu(w_i(t0)). Thus K(t0) is the Gram matrix of the k-dimensional Cauchy feature vectors and S(t0) their covariance. It is PSD with rank at most k-1<m. Lemma 1 gives feasibility for all t<t0. If any t>t0 were feasible, Lemma 1 would force S(t0)>0, a contradiction. QED.

A finite upper bound follows from diagonal constraints:

    t <= min_i [1/|g_i|^2 - y_i/b_i].

This is nonnegative for probability-transform data by Cauchy-Schwarz. The theorem identifies planted noise only in the stated atomic class. With an arbitrary non-atomic signal, an unknown removable semicircular component confounds the planted variance. No claim is made that arbitrary finite empirical spectral measures are exact semicircular convolutions.

## Theorem 3: positive realization when m=k

For the exact model with m=k, K(t0) is positive definite. Indeed the subordination points w_i are distinct: equal w implies equal g and then equal z. A square Cauchy matrix on distinct nonreal w_i and distinct real atoms is invertible.

Set K=K(t0), w=w(t0), and

    L = diag(w) K - 1 g*.

The defining Pick identity makes L Hermitian. In the true model,

    K=B diag(p) B*, L=B diag(p x) B*.

Let A=K^(-1/2) L K^(-1/2), e=K^(-1/2)g. The eigenvalues of Hermitian A are the atoms; if U diagonalizes A, their weights are |U*e|^2, automatically nonnegative and summing to one.

This realization also works for arbitrary probability-transform data at a finite boundary t_hat whenever K(t_hat)>0 and S(t_hat) is singular. Rank-one subtraction implies ||e||^2=1. For completeness, put H=K^(1/2), D=diag(w). The identity DK-L=1g* becomes DH-HA=1e*. Row i of H is therefore e*(w_i I-A)^(-1), since A is Hermitian and Im w_i>0. Multiplying by e gives, for each i,

    g_i = e* (w_i I-A)^(-1) e.

Thus the constructed atomic probability measure interpolates every transformed sample exactly. This is a Hermitian rational realization/Loewner construction, a classical tool; its use alone is not claimed novel. Degenerate K requires rank reduction and is not handled by the current prototype.

## Algorithm and costs

Evaluate g from the observed eigenvalues, O(Nm) arithmetic. Bisection evaluates an m-by-m Hermitian eigenvalue test, O(m^3 log(U/epsilon)) arithmetic; final realization O(m^3). No eigen-decomposition of the original N-by-N data matrix is included if only its spectrum is input; if the matrix is input, that upstream cost must be included for every method. Only k transforms are needed for exact k-atom inversion. Floating implementation uses ordinary NumPy/SciPy Hermitian eigensolvers and is not an interval certificate. Ill-conditioned K or tiny boundary slope can defeat ordinary precision.

## Finite-N and statistical boundary

For a finite deformed-Wigner realization, empirical g differs from its free-convolution limit. The algorithm is an exact interpolant of the finite set of empirical transforms, not an exact finite-N likelihood fit. Atomic signal misspecification, unknown atom count, correlated matrix noise, non-Wigner ensembles, and extreme finite-size effects are outside the exact theorem. The exact theorem does not apply to finite-N data. A separate conservative, conditional fixed-node high-imaginary GOE error budget is developed in STABILITY_AND_FINITE_N.md; it is not a confidence guarantee for the adaptive-node comparisons. Finite-matrix comparisons are necessary.

Current exact smoke test: k=3 and 5, variances .0625 and .5625, equally spaced transform real parts in [-1.4,1.4] and height .6. Errors range from 1e-15 to 4e-12 in double precision. This checks implementation algebra only and does not establish practical superiority. See pick_inverse.py and exact_smoke_results.json.
