"""Full finite-noise free-convolution forward fitting with analytic derivatives.
This fits limiting transforms, not exact finite-N GOE eigenvalue likelihood.
"""
import numpy as np
from scipy.optimize import least_squares
from scipy.special import softmax
from pick_inverse import free_stieltjes

def fit(z,g,k,atoms_init,weights_init,variance_init,support,upper,max_nfev=500):
    def pack(a,p,t):return np.r_[a,np.log(p[:-1]/p[-1]),t]
    def unpack(x):return x[:k],softmax(np.r_[x[k:2*k-1],0.]),x[-1]
    x0=pack(atoms_init,np.maximum(weights_init,1e-8)/np.sum(np.maximum(weights_init,1e-8)),variance_init)
    lower=np.r_[np.full(k,support[0]),np.full(k-1,-12.),0.]
    higher=np.r_[np.full(k,support[1]),np.full(k-1,12.),upper]
    x0=np.maximum(lower+1e-10,np.minimum(x0,higher-1e-10))
    last_x=None;last_r=None;last_j=None
    calls=0
    def evaluate(x):
        nonlocal last_x,last_r,last_j,calls
        if last_x is not None and np.array_equal(x,last_x):return last_r,last_j
        calls+=1
        a,p,t=unpack(x);gm=free_stieltjes(z,a,p,t,tol=1e-13)
        den=z[:,None]-t*gm[:,None]-a
        D=np.sum(p/den**2,axis=1);Q=1-t*D
        Ja=(p/den**2)/Q[:,None]
        Jp=(1/den)/Q[:,None]
        ds=np.diag(p)-np.outer(p,p)
        Jl=Jp@ds[:,:-1]
        Jt=(gm*D/Q)[:,None]
        J=np.column_stack([Ja,Jl,Jt]);r=gm-g
        last_x=x.copy();last_r=np.r_[r.real,r.imag];last_j=np.r_[J.real,J.imag]
        return last_r,last_j
    result=least_squares(lambda x:evaluate(x)[0],x0,jac=lambda x:evaluate(x)[1],bounds=(lower,higher),max_nfev=max_nfev,ftol=1e-12,xtol=1e-12,gtol=1e-12)
    a,p,t=unpack(result.x);order=np.argsort(a)
    return {'atoms':a[order],'weights':p[order],'variance':float(t),'cost':float(result.cost),'optimality':float(result.optimality),'nfev':int(result.nfev),'forward_calls':calls,'success':bool(result.success),'message':result.message}

if __name__=='__main__':
    # Analytic derivative checked against central finite differences by fitted exact data.
    a=np.array([-1,.2,1]);p=np.array([.25,.5,.25]);t=.5625
    z=np.linspace(-1.4,1.4,32)+.6j;g=free_stieltjes(z,a,p,t)
    print(fit(z,g,3,[-.8,0,.8],[1/3]*3,.3,(-2.5,2.5),1.5))
