# Conditional transform stability and a finite-GOE error budget

2026-10-09. Derived/self-checked only. This note is separate from the exact interpolation theorem. Constants are conservative. The finite-GOE probability bound below concerns fixed, nonrandom transform nodes. The comparison experiment chooses nodes from observed spectral extent, so it is not covered by that fixed-node statement without an additional uniform-in-node argument. No data-driven confidence intervals are claimed.

## 1. Simple boundary for the exactly determined k-node design

Use the notation of CANDIDATE_THEOREM.md, m=k and t0>0. At the true atomic law, K(t0)>0 and S(t0) has rank k-1. Let v be a unit null vector of S(t0), and let Delta be its smallest positive eigenvalue (for k=1 omit gap constraints below).

Entrywise differentiation gives

    S'(t) = -K(t) Hadamard-multiplied by K(t).

The simple zero eigenvalue therefore has derivative -c, where

    c = v* (K(t0) Hadamard K(t0)) v > 0.

Strictness is important and follows directly from the atomic Cauchy structure, not just from PSD. Write F(x)=sum_i conj(v_i)/(w_i-x). The covariance-null condition means F(a_l)=b for all k atoms. The square Cauchy matrix is invertible, so b cannot vanish. The rational function F(x)-b has exactly those k distinct zeros and numerator of degree k with nonzero leading coefficient. Thus F'(a_l) is nonzero for every atom. The identity

    c = sum_(l,r) p_l p_r |sum_i conj(v_i)/((w_i-a_l)(w_i-a_r))|^2
      = sum_l p_l^2 |F'(a_l)|^2

uses divided differences for l!=r, whose terms vanish. Hence c>0. This formula also displays the loss of conditioning when atoms coalesce or weights shrink.

## 2. Explicit perturbation bound for the Pick covariance

Let eta=min_i Im z_i>0 and Z=max_i |z_i-a| for any fixed real center a. Suppose g and g_hat both have negative imaginary parts and max_i |g_hat_i-g_i|<=epsilon. Put G=max_i |g_i|. For every t>=0, both transformed denominators have modulus at least 2 eta. The exact cancellation identity for n=-(g_i-conj(g_j)), d=z_i-conj(z_j)+t n gives

    K_hat_ij(t)-K_ij(t)
      = (n_hat-n)(z_i-conj(z_j))/(d_hat d).

Consequently, uniformly in t>=0,

    ||S_hat(t)-S(t)||_2 <= E(epsilon)
      := k [epsilon Z/eta^2 + 2G epsilon + epsilon^2].

This is a worst-case bound; actual errors are correlated across nodes and often much smaller.

## 3. Local variance bound with an explicit sufficient neighborhood

Set M=G/eta, C1=k M^2 and C2=2k M^3. For t>=0, entrywise differentiation gives ||S'||<=C1 and ||S''||<=C2. For k>1 choose

    r <= min(t0/2, Delta/(4 C1), c/[2(C2+4 C1^2/Delta)]).

Weyl's inequality keeps the lowest eigenvalue simple on [t0-r,t0+r], separated by at least Delta/2. The standard second derivative formula for a simple Hermitian eigenvalue bounds its second derivative by C2+4 C1^2/Delta, so its derivative remains <=-c/2. For k=1 use r<=min(t0/2,c/(2C2)); the scalar case has no spectral gap term.

If g_hat is itself the transform of a probability measure, has distinct fixed nodes, and E(epsilon)<c r/2, its normalized PSD boundary t_hat satisfies

    |t_hat-t0| <= 2 E(epsilon)/c.

Indeed the signs of the lowest eigenvalue at t0-r and t0+r are preserved. The backward-feasibility theorem forces the unique PSD endpoint to lie in this interval. Comparing its zero eigenvalue to the true eigenvalue and integrating the slope gives the bound. This is a sufficient local stability theorem, not a uniform bound over all k-atom signals.

Atom/weight recovery additionally depends on the conditioning of K and on eigenvalue separation in the realized Hermitian A. Classical generalized-eigenvalue and eigenvector perturbation bounds apply. No uniform atom-recovery guarantee is asserted. The variance claim does not require choosing a particular basis for eigenvectors.

## 4. Elementary fixed-node finite-GOE transform budget

Let H=A+sqrt(t0/(2N))(Z+Z^T), Z_ij independent standard real Gaussians, A deterministic symmetric. Assume its empirical law is exactly the desired finite atomic law (weights can depend on N). Let

    g_N(z)=N^(-1) Tr (zI-H)^(-1),  m_N(z)=E g_N(z),

and let g_infinity be the free convolution transform for that same empirical law of A. This comparison does not silently replace rounded finite-N weights by their asymptotic targets.

For fixed Im z>=eta, Gaussian Poincare and resolvent derivatives give

    E |g_N-m_N|^2 <= 2t0/(N^2 eta^4),
    E |R_ii-E R_ii|^2 <= 2t0/(N eta^4).

Gaussian concentration of the real and imaginary parts (each at most sqrt(2t0)/(N eta^2)-Lipschitz as a function of Z) gives, simultaneously at k fixed nodes with probability >=1-delta,

    max_i |g_N(z_i)-m_N(z_i)|
      <= sqrt(8t0 log(4k/delta))/(N eta^2).

A simple bias bound is available in the high-imaginary region eta^2>t0. Gaussian integration by parts in the resolvent identity yields

    (z-a_i-t0 m_N) E R_ii
      = 1 + t0 Cov(g_N,R_ii) + (t0/N) E (R^2)_ii

in an eigenbasis of A. The covariance uses no complex conjugate, but its magnitude is bounded by Cauchy-Schwarz with the variances above. Averaging and using |z-a_i-t0 m_N|>=eta gives

    |m_N - N^(-1) sum_i (z-a_i-t0 m_N)^(-1)|
      <= t0/(N eta^3) + 2t0^2/(N^(3/2) eta^5).

The Pastur fixed-point map is t0/eta^2-Lipschitz on the lower half-plane. Therefore

    |m_N-g_infinity|
      <= [t0/(N eta^3) + 2t0^2/(N^(3/2) eta^5)]/(1-t0/eta^2).

Adding concentration and bias supplies epsilon for section 3. This is an elementary O(1/N) high-imaginary transform budget, not an optimal local law. It does not apply as written at the low-imaginary nodes used in some practical tests, and increasing eta makes inversion conditioning worse. This tradeoff is real. For a general non-GOE Wigner ensemble, a suitable resolvent approximation theorem would be needed instead.

## 5. Important limits

- Known k is used equally by the candidate and comparison methods, as in Ying's finite-N examples.
- For m>k, the exact variance theorem remains true, but K(t0) is singular. Mathematically exact rank reduction gives the k-dimensional realization, but it is not implemented in the prototype. Under noisy data, m>k generally gives an m-atom interpolant and can make the endpoint extremely sensitive. Current practical estimator deliberately sets m=k.
- An arbitrary non-atomic signal can carry genuine semicircular divisibility. Then the maximal removable variance is not necessarily the planted noise variance.
- Empirical spectral transforms automatically satisfy S(0)>=0. Arbitrarily perturbed complex transform values need not. Such inputs must be checked/rejected or projected with an explicit additional observation model. The present tests do not silently PSD-project or smooth them.
- Ordinary floating-point eigenvalue signs near zero are not certified. A rigorous numerical bracket would require interval or backward-error eigenvalue bounds, plus an explicit statistical tolerance if the target is the population boundary.
