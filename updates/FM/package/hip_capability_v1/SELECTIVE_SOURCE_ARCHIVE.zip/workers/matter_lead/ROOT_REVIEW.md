# Independent review of root pressure-access derivation and scripts

14 October 2026. Reviewed `root/PRINCIPAL_DERIVATION.md`,
`root/pressure_access.py`, and `root/audit_public_morphology.py`. Both scripts
were rerun successfully. This is a mathematical/code and local-data audit,
not physical validation.

## Actionable corrections

1. **The exact witnesses do not physically seal under their stated radius law.**
   Both set `z=ln(a0/a)`, so `a=a0 exp(-z)>0` at every finite `z`.
   Declaring a hermetic seal at `z=ln 2` leaves `a=a0/2`; the compressible
   witness declares it at `z=0.1`, leaving `a≈0.905a0`. The algebra showing
   different reachability of these finite thresholds is correct, but a
   cylindrical throat remains gas-conducting. Relabel the event a *stipulated
   closure criterion*, or add an explicit independently calibrated finite-z
   bridging/contact transition that changes conductance to zero. State that
   the event cannot establish durable bonded closure without that extra law.
   This is the main physical-interpretation limit of the witness.

2. **Qualify the universal slew-bound sentence.** The barrier argument is
   correct for `D>0`, `Delta(0)≤D`, `P'≤Rmax`, `C(t)≥Cmin>0`, `p≥0`, and
   `c+theta≥0`. But the sentence “In particular Delta≤sqrt(Rmax/Cmin)”
   additionally needs `Delta(0)≤sqrt(Rmax/Cmin)`. In general the bound is
   `Delta(t)≤max{Delta(0),sqrt(Rmax/Cmin)}`. Also `Delta≤D` excludes
   *exceeding* `D`; to exclude reaching an operational threshold `Y`, use
   `D<Y` and specify that the local deformation law has no relevant
   pressure-differential-driven closure below `Y`. The displayed critical
   radius is a lower bound for exclusion: under fixed acquired geometry,
   `a≥a_critical` makes `C D²≥Rmax`. As already noted in the derivation,
   an initially measured `C` cannot be used if `a(t)` later narrows.

3. **The largest-radius numerical end lag is discretization dominated.** The
   500-nm row in `pressure_access_results.json` gives 1,250 Pa at 40,000
   midpoint steps and 2,500 Pa at 20,000 steps, while the local quasi-steady
   value `R/(2 C P_end)` is 85.33 Pa. Independent reruns of the same numerical
   routine gave 139.11 Pa at 400,000 steps and 85.94 Pa at 4,000,000 steps.
   The *maximum* early-ramp lag converged near 89.52 kPa and is a different
   quantity. Do not cite the 1,250-Pa end lag as a converged physical result;
   use adaptive stepping, an analytic error envelope, or omit that number.

4. **Keep the threshold law and Kelvin alternative conditional.** A `Y` in
   the slew argument must refer to the *differential-pressure contribution to
   local throat closure* at the acquired hot stress state; a generic alloy
   yield stress is insufficient. The trapped-gas relation
   `V_f/V_s≥(p_s/P_f)(T_f/T_s)` is a necessary quasistatic bound only when
   gas inventory is fixed and no capillary/other inward traction is available.
   Adding a bounded inward traction `Pi_max` changes the denominator to
   `P_f+Pi_max`; it does not grant a material-independent floor. The derivation
   already says this, and should preserve that limitation in any summary.
   Kelvin-selected deposition is source-supported for polymer/oxide
   nanocavities, not a HIP-stable metallic gas-tight bridge.

## Checks that passed

- The compressible ideal-gas capillary equation has the correct `1/16`
  coefficient under its stated assumptions. `C` has units `1/(Pa·s)`, and
  `a_critical` has units of length. Transforming to `q=p/P` gives the displayed
  equation. The slew barrier follows from
  `Delta'=P'-C Delta(P+p)-(c+theta)p` at a positive crossing.
- The fixed-inventory post-seal equation and conditional pressure-balance
  inequality are algebraically correct. The linear witness reaches its
  stipulated `z=ln 2` threshold with exact `p=3/128` for `m=10`, whereas
  `m=0.1` stalls at `z=-ln(3/5)/4<ln 2`; its formal `p=75/32` is correctly
  labelled nonphysical. The full compressible invariant
  `ln(1+q)=(1-exp(-4z))/(4 lambda tau)` is also correct.
- The normalized single-cavity step-response inversion and coefficient
  interval are correct if the entire normalized-reading error, baseline and
  equilibrium scale are independently bounded. The script returns `UNKNOWN`
  when no hot transfer interval is supplied. Neither fitting nor tracer
  uptake alone establishes closure.
- `audit_public_morphology.py` reran with the acquired ZIP. It contains 35
  CSV members; `sample 1.csv` has one metadata row, one schema row and exactly
  17,222 indexed data rows, all five columns wide. The reported member name,
  MD5, units, diameter quantiles and 10,000-fold hypothetical conductance-time
  sensitivity match the local data and fourth-power model. The script
  correctly withholds real throat, hot-response, intervention and fatigue
  labels. Equality applies to the supplied five-column table, not raw CT
  projections, equilibrium pycnometry, or all possible nondestructive tests.

## Status

These corrections leave the central conclusion intact: the public morphology
and room tracer alone do not identify an action-changing hot closure law. The
finite-z contact/bridging law, gas access at hot ramp conditions, retained
bonding and mechanical endpoint remain unacquired; no new HIP repair
capability is established by the derivation or scripts.

## Recheck after root corrections

Root preserved the initial errors in `root/CORRECTIONS_v0001.md` and repaired
the live derivation and script. I reran `pressure_access.py` on the revision.
The witness now calls finite `z` a geometric/contact criterion and explicitly
requires an independently acquired gas-tight contact/bond law. The general
slew bound now uses `max{Delta(0),sqrt(Rmax/Cmin)}`, and `a>=a_critical` is
stated as the exclusion direction under fixed acquired geometry. These close
findings 1 and the main part of 2 above.

The numerical ramp now uses the positive analytic root of the endpoint
implicit-Euler quadratic

    (h C) p_(n+1)^2 + p_(n+1) = p_n + (h C) P_(n+1)^2.

For the 500-nm row, the rerun gives 85.33344257 Pa end lag at both 20,000
and 40,000 steps, versus the independently calculated near-equilibrium
85.33333333 Pa. This closes the end-lag artifact in finding 3. The reported
*early-ramp maximum* remains a sampled, first-order numerical result:
88.451 kPa at 40,000 steps versus 89.513 kPa at 4,000,000 steps in an
independent refinement. It should not be presented as a high-precision
physical number, though its approximately 90-kPa scale and the conservative
slew bound are unaffected.

Two wording refinements remain if the derivation is polished further:
`Delta<=D` excludes *exceeding* D, while exclusion of attaining a required
threshold uses a strict `Y>D`; and the heading “Exact action-changing
ambiguity” is conditional on the independently acquired finite-z contact
law. These are claim-scope edits, not new algebraic failures. No physical
HIP closure outcome or superior repair action follows from the repaired
toy model alone.
