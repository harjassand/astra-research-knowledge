# ASTRA HIP prior-art adversary: connected pores surviving HIP

**Date:** 2026-10-14
**Scope:** Focused literature and patent search for the hypothesis: measure gas access into open or sub-voxel connected pores in additively manufactured metal, then apply a rapid external pressure pulse so that the pore closes before its gas pressure equalizes. This is an adversarial prior-art screen, not a legal patentability opinion or an exhaustive systematic review.

## Judgment

The broad problem and proposed remedy are not new. Primary AM studies have already established that surface-connected flaws can survive HIP because pressurizing gas enters them; one study explicitly traces retained pores to connections below XCT resolution. Coating/encapsulation before HIP has been tested directly on AM parts and can close some formerly surface-connected flaws when the coating seals them. Rapid hot hydrostatic pressure application is also longstanding apparatus/process art, including patents that place a cover or capsule between a hot blank and pressurized liquid before a rapid pressure rise.

A potentially distinct and unverified operation remains: **measure the gas-access/equilibration time of a particular open pore network, then choose a pulse duration and ramp such that metal creep/closure outruns gas equalization**. I found no primary result demonstrating that time-scale inequality on a dense AM component, nor a validated access-contrast method that localizes a sub-voxel connected pore in a real part. Do not claim novelty, efficacy, or capability until that distinction is experimentally measured against matched HIP and sealing controls.

## Prior art with the closest mechanism overlap

| Source | What it establishes | Mechanism overlap | Important distinction / consequence |
|---|---|---|---|
| Tammas-Williams et al. (2016), Ti EBM, [DOI](https://doi.org/10.1007/s11661-016-3429-3), [full text PDF](https://d-nb.info/1092189572/34) | Surface-breaking tunnel defects persisted after HIP; XCT views made some narrow linking ligaments look disconnected, while manual inspection found surface connections. The paper says the pressurized Ar infiltrated those defects and prevented closure. It notes coating before HIP as a route to turn surface-connected voids into internal ones. | Almost exact problem physics: connected tunnel porosity defeats HIP; small connection paths can be missed by imaging. | Does not test a pressure-access measurement or a pulse timed against gas equalization. Nevertheless, the problem statement “connected AM pores survive HIP” and the “seal the access first” intuition are established. |
| Balasubramanian et al. (2023), AlSi10Mg LPBF, [DOI](https://doi.org/10.1007/s10853-023-08907-4) | Tracks 274,886 pores across eight HIP settings using registered pre/post XCT. The paper attributes some remaining pores to surface connection and says some connections can be below the XCT resolution. | Strongest direct prior art for the **sub-resolution connectivity** part of the task. | It is pore tracing/diagnosis, not an access-time measurement or transient-pressure intervention. Data access and matching quality are limitations noted by the paper. |
| du Plessis & Macdonald (2020), LPBF, [DOI](https://doi.org/10.1016/j.addma.2020.101191), [author PDF](https://blogs.sun.ac.za/duplessis/files/2020/06/HIP-LPBF-cubes.pdf) | XCT shows internal pores close while surface-connected pores and pores connected through cracks persist; large open lack-of-fusion regions show little improvement. | Confirms the boundary condition: HIP works on enclosed voids but not gas-accessible porosity. | No transient pulse strategy. Some reported residuals are resolution- and geometry-dependent. |
| Čegan et al. (2020), 316L SLM, [DOI/full text](https://doi.org/10.3390/ma13194377) | Compares HIP at 1125 °C/4 h and 137 or 190 MPa. The authors report that Ar enters open, interconnected lack-of-fusion pores and these are not removed by plastic deformation; the higher pressure mainly improves closed porosity. | Direct AM-metal test that increasing HIP pressure alone does not rescue open connected defects. | Does not test rapid pressure ramps. Its optical area-fraction measurements should not be overread as proof that each open pore grew. |
| Zeng et al. (2020), EBM Alloy 718, [DOI/full text](https://doi.org/10.3390/ma13051226), [PDF](https://hv.diva-portal.org/smash/get/diva2%3A1416898/FULLTEXT01.pdf) | Applies a nominal 500 μm HVAF coating before HIP (1120 °C, 100 MPa, 4 h). Some previously surface-connected defects close when sealed; others remain where the coating is imperfect or cracked. | Directly tests the obvious access-blocking intervention on AM material and reports partial closure. | Supports sealing as known art, but does not establish rapid-pulse closure or full densification. It also supplies a decisive control for any new pulse experiment. |
| Tillmann et al. (2015), [DOI](https://doi.org/10.1179/0032589915Z.000000000250) | Describes Arc-PVD and HVOF coatings to encapsulate laser-melted Inconel 718 for post-compacting HIP. | Earlier coating/encapsulation route aimed specifically at open pores. | Abstract-level evidence in this screen; use Zeng for outcome claims. |
| King (1992), Sheffield Hallam thesis, [record](https://shura.shu.ac.uk/19916/) | Tests closed and surface-connected porosity in CuNi; surface-connected pores require encapsulation. It reports that successive short cycles can outperform a single cycle with the same total duration for large pores. | Pressure cycling and encapsulation both predate the proposed operation. | Different alloy and casting context; does not measure pore gas-access lag or show the proposed transient differential. |
| US3931382A, [“Method for rapid isostatic pressing”](https://patents.google.com/patent/US3931382A/en) | Describes rapid hot isostatic pressing by preheating, rapidly filling with liquid, and raising pressure; claims minute-scale rather than conventional hour-scale treatment. | Rapid external pressure history during hot consolidation is old process/equipment art. | The described purpose is rapid processing / liquid-vapor and heat-transfer management; examples use canned powder. It does not teach timing an AM-pore pulse against pore-network gas equalization. |
| EP1372876B1 / WO2002026409A2, [“A method and a system for hot hydrostatic pressing”](https://patents.google.com/patent/EP1372876B1/en) | Priority 2000. Uses a metallic capsule or breakable cover, prepressurized working liquid, then a rapid hot hydrostatic pressure rise after contact; includes hot hydrostatic pressing/extrusion. The patent discusses reaching stabilization pressure in less than a fraction of a second. | Closest sequence-level overlap to “protect/seal a hot body, then apply a rapid external pressure pulse.” It makes a broad pulse-plus-cover concept especially hard to distinguish. | The stated mechanism is stabilizing the liquid/vapor cushion and transmitting pressure through a capsule, not exploiting delayed gas access into AM pore ligaments. It does not demonstrate pore-specific closure. |
| BAE Systems, [Powder HIP cycle patent publication](https://patents.justia.com/patent/20230339021) | Proposes cold prepressurization of encapsulated atomized powder before heating, to reduce deformation of trapped closed bubbles in powder particles. | Pressure trajectory is itself a design variable in HIP prior art. | This is canned powder and closed bubbles, not open connected pores in an AM solid; the patent's pressure-ramp concept is not a direct disclosure of the hypothesized access-time differential. |

### Measurement overlap

Gas-access metrology is also established independently of the proposed treatment. [ASTM F3637-23](https://store.astm.org/f3637-23.html) discusses gas pycnometry on surface/interconnected porosity and warns that accessible pores affect the measured skeletal volume; it also describes XCT resolution limits and the possibility of missing smaller pores. Balasubramanian et al. use registered XCT pore tracing to infer sub-resolution surface connections. These methods support a **bulk or post hoc accessibility diagnosis**, but the sources above do not provide a validated, spatially local gas-pressure-access contrast for identifying an individual sub-voxel pore in a finished component.

## Adversarial novelty boundary

Claims that are already contradicted by prior art:

- “Surface-connected pores survive HIP because the pressurizing gas reaches them.”
- “Sub-voxel connectivity can explain residual pores after HIP.”
- “Seal or coat the AM surface-connected defect before HIP so it can close.”
- “Pressure cycling or a fast hot hydrostatic pressure ramp is a new HIP concept.”

A narrow candidate claim that remains a hypothesis, not a finding:

> A calibrated, sample-specific gas-access transient identifies a connected-pore equilibration time; an external pressure pulse selected so that metal creep closes the limiting throat before the pore gas equilibrates yields more closure than matched conventional HIP, pressure-ramp controls, and a seal-only control.

Even this formulation needs careful claim scoping. Pressure access tests used for bulk permeability or pycnometry do not localize a particular sub-resolution defect. A coating can itself close off access and is known prior art. A successful transient pressure pulse alone would not prove that the specific gas-lag mechanism caused closure.

## Decisive next experiment / evidence gate

Before describing this as a capability, require a blinded, matched experiment on AM coupons containing independently verified surface-connected pore networks:

1. Measure access/equilibration time before treatment with a calibrated gas-pressure transient; include sealed and deliberately open positive/negative controls. Establish spatial attribution or explicitly limit the claim to a bulk-network time constant.
2. Measure or bound the hot-metal throat closure time under the proposed temperature and pressure, independently of the access assay. The mechanism requires a reproducible window with closure faster than pore-gas equilibration.
3. Randomize matched coupons to standard HIP, same-endpoint slow-ramp HIP, pulse HIP, and sealed/coated HIP. Match alloy, geometry, total pressure-temperature exposure, and starting pore population.
4. Use registered high-resolution XCT plus a connectivity-sensitive post-test assay. Report detection limit, open/closed status, residual pore size, and whether defects reopen; do not infer metallurgical bonding or mechanical performance from pore-volume reduction alone.
5. Pre-register the primary outcome and replicate across builds. If the pulse benefit disappears against matched ramp or seal controls, retire the differential-pressure mechanism.

## Search limits

This was a focused search of primary AM HIP studies, patents, a primary thesis, and metrology guidance through 2026-10-14. It does not establish global novelty or patent freedom to operate. The closest exact evidence is the direct AM pore-survival/encapsulation literature; the rapid-pressure patents establish broad process overlap but their stated mechanisms differ. A formal novelty opinion would require claim-by-claim patent-family and prosecution-history review.
