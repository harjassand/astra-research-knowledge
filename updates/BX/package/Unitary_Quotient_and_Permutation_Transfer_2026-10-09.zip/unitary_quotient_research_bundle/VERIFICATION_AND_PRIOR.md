# Quotient embedding: focused adversarial and closest-prior verdict

Checked 2026-10-09. The standalone proof is maintained separately in `UNITARY_PERMUTATION_QUOTIENT_EMBEDDING.md`; this note records an independent algebra check, conventions, the closest prior interfaces, and application-status limits.

## Verdict

**No flaw found in the proposed dimension-independent distortion-3 embedding.** The exact statement below follows by the stated Birkhoff argument and three-term telescoping. The checked sources do not establish priority for this quantitative estimate. Encoding an unordered orthonormal basis by its copying comultiplication is established prior art, and odeco perturbation theory is closely related, but the specific global normalized-Frobenius orbit inequality is not a direct consequence of the cited odeco theorem.

The result supplies the one-sided-unitary-quotient **squared-distance Poincaré inequality** mentioned in Chapman–Lubotzky §6.4, under the natural quotient normalized-HS metric. That geometric conclusion is independent of property (T) and of any representation assumption. A complete application to efficient permutation presentations still requires the separate unitary-repair-to-permutation reduction and its parameter bookkeeping.

## 1. Exact statement and independent algebra check

Let S_d be the permutation matrices, let Δe_i=e_i⊗e_i, and define

Φ(U S_d)=(U⊗U)ΔU*/√d,

q(U S_d,V S_d)=min_{P∈S_d} ||U−VP||_F/√d.

The target is the Hilbert space Hom(C^d,C^d⊗C^d) with its ordinary Frobenius norm. Then

q(U S_d,V S_d) ≤ ||Φ(U S_d)−Φ(V S_d)||_F ≤ 3q(U S_d,V S_d).

Checks:

1. `(P⊗P)ΔP*=Δ`, so right multiplication by permutations does not change Φ. Independent representative changes in q are absorbed by the minimization and unitary invariance.
2. For Q=U*V, the target inner product is `(1/d)Σ_ij |q_ij|² q_ij`, or its complex conjugate depending on inner-product convention. Its real part is identical in either convention. Both target vectors have norm 1, giving squared target distance `2−(2/d)ReΣ_ij |q_ij|²q_ij`.
3. The matrix `B_ij=|q_ij|²` is doubly stochastic. Therefore `Σ B_ij Re(q_ij)` is at most the maximum permutation-assignment sum of `Re(q_ij)`. The latter is exactly the trace maximization in `min_P ||I−QP||_F²`. This proves the lower estimate and injectivity.
4. Put W=VP for a minimizing P. Expand `(U⊗U)ΔU*−(W⊗W)ΔW*` into the three factors U−W. Every summand has Frobenius norm exactly `||U−W||_F`: in the first two terms use that Δ's i-th column is e_i⊗e_i, and in the last use Δ*Δ=I. The triangle inequality gives 3.

These checks are global. No smallness assumption, compact-group averaging, or degree-dependent estimate enters.

## 2. Convention traps to avoid

- `U(d)/S_d` here means the right-multiplication equivalence U~UP, whose cosets are conventionally called **left cosets** U S_d. For the left-multiplication quotient S_d\U(d), use U↦Φ(U*). Inversion is an isometry between the two quotients.
- This is not a conjugation quotient, a double quotient, or a quotient by monomial matrices. The copying tensor retains the phases of the basis vectors. In dimension 1 the map is simply z↦z.
- The Hilbert embedding is bi-Lipschitz for q, the unsquared normalized-HS quotient metric. Squaring gives `q²≤||ΔΦ||²≤9q²`. Do not describe q² as the same metric or claim that it itself embeds with distortion 3.
- The normalization is `1/√d`, because ||Δ||_F²=d. It is not `1/√(d³)` arising from the ambient tensor dimension.
- For a finite regular graph X with the convention in Chapman–Lubotzky I, Lemma 5.4, `E_edges||F(x)−F(y)||² ≥ γ(X) E_pairs||F(x)−F(y)||²`, the consequence is

  `E_pairs q(f(x),f(y))² ≤ [9/γ(X)] E_edges q(f(x),f(y))²`.

  For definitions using variance around the mean rather than pairwise averages, move the usual factor 2 explicitly; it is unrelated to dimension.

## 3. Closest prior: exact basis encoding

Coecke–Pavlovic–Vicary, _A new description of orthogonal bases_, equation (1), Theorem 5.1, and §6. Source: https://arxiv.org/pdf/0810.0812.

They encode an orthonormal basis {u_i} by the copying map u_i↦u_i⊗u_i and characterize these structures through commutative special dagger-Frobenius algebras. In fixed coordinates the copying map is precisely `(U⊗U)ΔU*`. Thus the map itself and its exact identification of a basis up to permutation should not be presented as new. Their theorem is an algebraic characterization; the inspected statements do not supply a degree-uniform bi-Lipschitz estimate for the quotient HS metric.

## 4. Closest prior: Auddy–Yuan odeco perturbation

Auddy–Yuan, _Perturbation Bounds for (Nearly) Orthogonally Decomposable Tensors_, arXiv v2 Theorem 2.4, equations (19)–(20), and Theorem 2.5. Source: https://arxiv.org/pdf/2007.09024. The published article is _Information and Inference_ 12 (2023), 1044 ff.; theorem numbering differs between versions.

The cited theorem matches components of two **real** odeco tensors by one permutation and bounds each factor's sine-angle error by `C||T−T̃||_op/λ_i`, with C≤17 independent of dimension and tensor order. The tensor norm is the unnormalized multilinear spectral norm. Angles are taken in [0,π/2], so this interface controls lines rather than oriented/phase-sensitive vectors.

### Why its stated interface does not give the present estimate directly

For equal unnormalized weights λ_i=1, direct summation gives RMS factor-angle error O(||E||_op). Replacing spectral norm by Frobenius gives O(||E||_F), whereas the quotient theorem needs O(||E||_F/√d). Thus that direct conversion loses √d. Equivalently, after normalizing tensors by √d, the weights become 1/√d and the same factor returns in the denominator. Also, real line-angle control is not immediately the mixed-complex, phase-sensitive matching in U(d)/S_d.

This is an interface comparison, not proof that no strengthening is implicit anywhere in their argument. A Frobenius-energy summation refinement or another existing result might recover an orbit-matching theorem. In the focused check, neither a global normalized-Frobenius orbit theorem nor the doubly-stochastic assignment inequality was located in the cited statements. The safe claim is **not a direct corollary of the cited odeco theorem; priority unestablished**.

## 5. The application is currently more nuanced than the 2024 motivation

**Chapman–Lubotzky II, §6.4.** Source: https://arxiv.org/html/2311.06706v3#S6. The authors request a dimension-independent Poincaré inequality on U(n)/Sym(n) as a way to transfer quantum tensor-code results to permutations, and contrast it with a negative result for M(n)/Sym(n). For the natural quotient normalized-HS metric, the theorem above supplies the specified geometric inequality. It does not supply an analogous embedding of all matrices modulo column permutations.

**Chapman–Vidick–Yuen, _Efficiently Stable Presentations from Error-Correcting Codes_, v2 dated 19 July 2026, introduction and Theorem 1.** Source: https://arxiv.org/html/2311.04681v2#S1. Their recent version proves efficiently stable unitary presentations of Z₂^k via Reed–Muller codes, with quasi-polynomial presentation size in k and stability modulus polynomial in log k and the error. Its introduction explicitly says the analogous efficient-stability problem for permutation representations remains open. This is primary evidence that the desired permutation application was not claimed there as settled in July 2026. It does not establish the novelty of this embedding.

**Bowen–Chapman–Vidick, _The Aldous–Lyons Conjecture II: Undecidability_, Theorem 1.1 and §1.1.** Source: https://arxiv.org/pdf/2501.00173. The broader Aldous–Lyons goal has been reached by a different route: tailored-game compression preserves special perfect permutation strategies while establishing quantum soundness, and the companion reduction gives non-sofic unimodular networks. This does not amount to a general unitary-to-permutation repair theorem. The paper explicitly says it does not settle existence of non-sofic groups. Its application therefore supersedes the old “this could refute Aldous–Lyons” motivation, while leaving the efficient-permutation-presentation interface distinct.

## Final classification

- **Correctness of geometric theorem:** independent algebra check passed.
- **Match to CL quotient-Poincaré request:** yes for the natural one-sided normalized-HS quotient and squared-distance Poincaré convention.
- **Map's conceptual originality:** not new; copying-comultiplication basis encoding is prior art.
- **Dimension-free quantitative estimate's priority:** unresolved by this focused lookup; not obtained directly from the checked Auddy–Yuan interface.
- **Efficient permutation-presentation application:** still explicitly presented as open in CVY v2, July 2026; do not mark it completed merely from the embedding.
- **Aldous–Lyons motivation:** already superseded by a different proof route.

## 6. Addendum: finite code-presentation transfer audit

Checked 2026-10-09 against `FINITE_GROUP_CODE_TRANSFER.md` and `COPY_TENSOR_TRANSFER_CANDIDATE.md`. **The finite transfer passes this focused check.** This updates the earlier application-status verdict: the separate reduction has now been checked for the precise finite-code hypotheses and the formal CVY parameter/error statement, without asserting a broader floor-free theorem or historical priority.

### Common-space construction and normalization

Assume (A) in the finite-transfer note, with eta<=1/2. Put E=ww*, A=w*w, B=I_d-A, a=d-r and b=D-r. The second rank deficiency gives `(1-eta)D<=r<=d`, hence `D<=d/(1-eta)` and `b<=eta D<=2eta d`.

The embedding into the original-coordinate space H=C^d direct-sum C^b can be made explicit. Choose any isometry v from `(I_D-E)C^D` onto C^b and define

`Jy=(w*y, v(I_D-E)y)`.

Then J*J=I_D and JJ*=A direct-sum I_b. Therefore

`sigma(g)=J rho(g) J* + (B direct-sum 0)`

is an exact unitary representation on dimension ell=d+b=d+D-r. This rotates only the embedded exact representation; the original coordinate vectors and every original permutation label remain intact. Its upper-left block is `A_i+B`, where `A_i=w*rho(s_i)w`.

Since BA_i=A_iB=0,

`||A_i+B-P_i||_F^2 = ||A_i-P_i||_F^2 + a - 2 Re Tr(P_i* B) <= ||A_i-P_i||_F^2+3a`.

The two off-diagonal blocks each have squared Frobenius norm at most b, and the lower-right contraction differs from I_b by squared Frobenius norm at most 4b. Thus, with P_i'=P_i direct-sum I_b,

`E_i ||sigma(s_i)-P_i'||_F^2/ell <= (eta d+3a+6b)/ell <=16eta`.

All norms in this estimate are ordinary Frobenius norms before the explicit division by ell. No conversion to an arbitrary basis of the permutation matrices is made.

### Gap, finite completion, and numerical constants

For G=F_2^L/C^perp, its character group is C. A nonzero codeword c has generator energy `L^(-1) sum_i |(-1)^(c_i)-1|^2=4 wt(c)/L>=4Delta`. Every constituent of sigma tensor sigma tensor bar(sigma) is again a character. Consequently the displayed energy-gap hypothesis holds with kappa=4Delta, including multiplicities and the added trivial summand.

The image sigma(G) is finite. Becker–Chapman Theorem 1.2 therefore applies literally to its nearest-permutation map: this application does not use, or depend on, the compact/Borel extension. Its 1218 growth and 2039 distance constants use the same charged, larger-degree-denominator Hamming metric. Source: https://arxiv.org/pdf/2005.06652.

Substitution in the mixed-copy theorem gives

- `N/ell-1 <= 789264 eta/Delta`;
- `E_i d_h(P_i',h(s_i)) <=16eta+1321416 eta/Delta`.

Since ell/d<=1+2eta<=2 and Delta<=1, these imply

- `N/d-1 <=1578530 eta/Delta`;
- `E_i d_h(P_i,h(s_i)) <=1321434 eta/Delta`.

For the second inequality the additional padding charge is at most b/ell<=2eta. More directly, the difference between the two charged distances is the number of correctly matched padded labels divided by N, which is at most b/N. Hence 2,000,000 bounds both quantities with room to spare.

### Exact source interface and parameter floor

CVY Definition 2.2 gives exactly the two normalized rank defects and compressed squared-HS estimate used in (A). Starting from M_d, its finite-trace amplified corner has finite matrix rank D. Section 4 uses uniform coordinate generators and its specified, nonuniform relation distribution. Sections 3.2–3.3 identify the binary concatenated code and give the stated distance lower bound. Theorem 4.1 retains both the q^(-c) floor and the presentation-dependent linear alternative. Source: https://arxiv.org/html/2311.04681v2#S4.

The permutation relation defect converts exactly as `epsilon_HS=2epsilon_Hamming`, so eta=f(2epsilon) is correct. Restricting this invocation to epsilon<=1/2 respects the modulus domain. The nontrivial branch `2,000,000 eta/Delta<1` automatically has eta<1/2; all other cases use the trivial action on the original d labels. Thus neither a large-eta dilation nor an out-of-domain modulus is needed.

The sequence m=r=s, t=s^2 has log k=Theta(s log s), log_2 L=Theta(s^3), Delta>=1/4, and relation length O(log k), as claimed. The floor is absorbed for epsilon>=2^(-c s^2/b); below it only the separate presentation-dependent linear bound guarantees convergence to zero. In particular, the checked conclusion is the charged flexible permutation counterpart of the **formal** CVY Theorem 4.1, preserving its floor and sampling distributions. It is not a uniform floor-free poly(log k) epsilon^b result.
