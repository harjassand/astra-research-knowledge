# Exact local dual completion for a ferromagnetic spin chain

## Result

For the periodic spin-1/2 chain with singlet-projector terms

\[
P_j=|s\rangle\!\langle s|_{j,j+1},\qquad
H=\sum_{j=0}^{N-1}P_j,\qquad P_j^2=P_j,
\]

the response to the localized source

\[
|F\rangle=|\uparrow\rangle^{\otimes N},\qquad
|u_0\rangle=S^-_0|F\rangle,\qquad
|b\rangle=[H,S^-_0]|F\rangle=H|u_0\rangle
\]

has the exact static susceptibility

\[
\chi=b^\dagger H^+b=1\quad (N\ge3).
\]

This gives an exact finite-range dual certificate. With \(Lx=(P_0x,\ldots,P_{N-1}x)\), set \(w_j=P_j u_0\). Only \(j=N-1,0\) are nonzero; each is a single singlet tensor on that bond with the other spins up. Then

\[
L^\dagger w=\sum_jP_jw_j=\sum_jP_j^2u_0=Hu_0=b,
\qquad
\|w\|^2=\sum_j\|P_ju_0\|^2=\langle u_0|H|u_0\rangle=1.
\]

The matching primal witness \(x=u_0\) gives

\[
2\operatorname{Re}\langle b,x\rangle-\|Lx\|^2=2-1=1.
\]

Thus both bounds meet without using a floating-point residual as a bound. The exact dual identity above is the certificate. The computed residuals are diagnostics only.

## Ground space and frustration-free structure

Every \(|v\rangle^{\otimes N}\) is annihilated by every \(P_j\). These bond-dimension-one MPS ground states span the fully symmetric spin-\(N/2\) subspace, of dimension \(N+1\). The bond swaps generate all permutations, so the common kernel of the adjacent singlet projectors is exactly this symmetric subspace. The code imposes the zero-mean gauge in the one-down-spin sector, which removes its Dicke ground vector and returns \(H^+b\). It does not assume a unique ground state.

The terms are noncommuting: adjacent projectors overlap. The independent full-Hilbert checks find nonzero \(\|[P_0,P_1]\|_F\) for every tested ring. The chain is frustration free because each term annihilates the product MPS ground state.

## Exact and numerical checks

`dual_completion.py` and `results.json` contain the executable reference. SymPy solves the augmented one-magnon system exactly over rationals for \(N=3,\ldots,12\); all cases give \(\chi=1\), exact primal value 1, exact dual norm squared 1, and exact zero residual in \(L^\dagger w=b\). A separate NumPy diagonalization of the full \(2^N\)-dimensional Hamiltonian for \(N=3,\ldots,8\) gives kernel dimension \(N+1\), susceptibility 1 to floating-point precision, and zero reported dual residual. The smallest eigenvalue is numerically zero up to roundoff; no positivity or upper-bound claim is inferred from that roundoff.

The dense check also constructs the full Dicke MPS span and checks it is annihilated by \(H\), verifies source orthogonality to that span, and checks the adjacent-term commutator. These checks support the algebraic derivation; they do not replace it.

## Comparator and resource count

The standard response comparator is unpreconditioned conjugate gradients on the same Hamiltonian, first in the invariant one-magnon sector and also as a matrix-free full-space solve using the same local projector matvec. On even rings the one-magnon CG run terminates in \(N/2\) matvecs for this source. At \(N=256\), it uses 128 matvecs, about \(458{,}752\) real scalar operations under the script's explicit per-iteration count, and five length-\(N\) work vectors (1,280 real entries). The local certificate uses two active bond tensors, two adjoint contractions, and two norm contractions; for fixed source support this is constant work and constant tensor storage as \(N\) grows. The full-space reference solver has the same Krylov iteration count but stores five vectors of length \(2^N\) and visits \(N2^N\) bond-state pairs per matvec; at \(N=8\), that is 4 matvecs, 1,280 stored reals, and 8,192 bond-state visits.

The one-magnon CG is the fairer and stronger comparator because it uses the known conserved-spin sector. Its arithmetic grows quadratically in \(N\) for this particular source, while the local certificate remains constant-size. However, the source is engineered as \(H\) applied to a local MPS tangent excitation. A solver that recognizes this construction can write down the same response directly. The experiment therefore demonstrates an exact local dual mechanism for a structured source, not a new general-purpose inverse-Hamiltonian method or a demonstrated advantage over the strongest source-aware solver.

## Locality boundary check

As a negative control, the script uses the natural one-site spin-flip source projected off the ground space,

\[
q=(I-P_{\ker H})|u_0\rangle=|u_0\rangle-\frac1N\sum_j|u_j\rangle.
\]

The exact susceptibility is \((N^2-1)/(6N)\). A dual ansatz restricted to the two bonds incident on site zero is infeasible: the exact squared least-squares residual is \(2/15\), \(5/24\), and \(1/4\) at \(N=5,8,12\). These residuals are not upper bounds and are not promoted as certificates. This control shows that exact finite-range completion depends on the source structure; local support of a source before ground projection alone does not guarantee it.

## Scope

This is a finite-dimensional exact identity for a deliberately structured source and a simple noncommuting frustration-free chain. It does not establish that arbitrary local observables admit finite-range dual completions, nor does it establish a benefit over a source-aware analytic response solver. A next useful test would require a source family that is naturally specified independently of \(H x\), then compare optimized finite-range certificates with the best sector-aware response method while accounting for source preparation.
