# Astra Capital intake schema audit

Read-only audit completed 2026-10-14. I did not change the Astra Capital checkout.

## Pins and current integration state

- Capital checkout: `/Users/harjas/Documents/Codex/2026-10-13/new-chat/work/astra-capital`, clean `main` at `ace0cfc4437fe91c20ccd24d69e0ee4bb335e871` (`origin/main`). This is the checked base used for the FC-era records, not the latest available integration state.
- Live PR #83 is open and draft, based on that main SHA, with head `3c9c5564fc7f51cdbaa0a5a5b5b54ee9382dcd8d`. Its cumulative changes add update areas `FD`, `FE`, `FG`–`FK` and claim IDs `N791`–`N811`. `FF` is absent. Recheck this PR or the refreshed `main` before reserving IDs; the next plausible card number is `N812+`, and the next plausible update directory is `FL`.
- The Ultra source commit `788beabca49c9821a86c8237b1328a53313a22c5` is in the separate `/Users/harjas/Documents/ChatGPT/ultra` repository. It commits `research/2026-10-14-capability-v1/` (“Preserve task-first HIP capability audit, countermodels and data receipts”). Its `ASTRA_CAPITAL_HANDOFF_v0001.json` explicitly says `canonical_capital_integration: NOT_PERFORMED` and `shared_publication: NOT_PERFORMED`; it pins Capital main at `ace0cfc...`. I found no HIP packet, `788beab` reference, or HIP claim in Capital main. The Capital card `N788` is an unrelated coupled-equilibrium-histogram result, not this HIP packet.
- The current PR's `N792` (covalent isotope fractionation) and `N810` (thermal-anchor/response acquisition) are possible search hits by vocabulary, but their contracts are different. N792 is a stripping-hazard/isotope-separation model; N810 is a lattice thermal-response and Gibbs-observation contract. Read their current dossier and proof routes before asserting any relation. Do not reuse N788, N792, or N810 as a card for the HIP work.

The HIP packet itself reports a conditional pressure/gas-access derivation (C02), exact model obstructions (C03 and C07), prior-art collisions (C04/C06), a bounded public-data parse (C08), and no new physical capability (C10). Preserve source-established literature and internally derived mathematics separately. A model obstruction defeats only the stated access/mechanism; it does not prove every HIP route impossible. The Ultra packet is not a Capital integration or a scientific-status promotion.

## Capital records needed for substantive results

Use the current update/claim pattern, not just a branch handoff. On the latest PR head, the likely integration area is `updates/FL/`; verify no later work has claimed it first. Keep the pinned Ultra source commit and its source manifest in the Capital intake provenance. Copy committed source bytes from `788beab...`, not mutable or untracked working-tree files.

For each distinct substantive result, create a unique stable claim ID after checking the refreshed claim ledger and open PR. A conditional positive bound and a model-specific negative obstruction have different statements, interfaces and falsifiers, so they should normally be separate cards; do not merge them merely because both concern the same HIP mission. Candidate claims from this packet are C02 (conditional pressure/access bound), C03 (hot contact/action non-identifiability under the specified observations), and C07 (finite isotope counts do not identify general last-ingress/seal time). C01/C04/C06 are credited prior art, C08 is bounded data processing, and C10 is the mission result/status; none should be relabelled as a new theorem.

The core record set is:

- `updates/FL/SOURCE_MANIFEST.json`, preserved package bytes, `DERIVED_MANIFEST.json`, `CLAIMS.json`, `SYNTHESIS.md`, and `VALIDATION.json`. `CLAIMS.json` follows `astra.intake-claim-map.v1`: `intake_id`, pinned `base_revision`, and per-claim `id`, `source_path`, `source_id`, full `source_sha256`, status, `missing_artifacts`, checkpoint, and optional workflow trace/proof source fields. Follow `updates/FD/`–`updates/FK/` for current field-level practice.
- `cards/<new-id>.txt`: readable exact mathematical statement, quantifiers, assumptions, supplied versus acquired inputs, output, costs, proof route, failures, comparator, limitations and next gap. `agent/audits/w04_schema.md` describes the richer `astra-card/1` extraction ontology; use `UNKNOWN` for fields the packet does not establish.
- `frontier/cards/<new-id>.json`: current sidecar shape is the `schema_version: 1` card record. Include `card_id`, `card_path`, `card_sha256`, title/topics, `claim_status`, exact `scientific_scope_status`, `proof_availability` with hashed line-scoped evidence, validation/status boundaries, `reported_failed_attempts`, dependencies, `material_updates`, `supersedes`, and `invalidates`. Keep supersession and invalidation empty unless a precise, evidence-backed scope warrants them.
- Append one row per claim to `indexes/claims.jsonl`; add a matching `frontier/CURRENT_CLAIM_STATUS.jsonl` row and `indexes/agent_catalog.json` entry with identical ID/title/status/card hash/dependency routes. Add graph nodes/edges only for explicit, evidenced relations. Update applicable topic/review routes and the web/source indexes through the repository's current intake process.
- Add scoped `agent/SEMANTIC_NOTICES.jsonl` entries and reciprocal `material_updates` only when a real prior-card relation is established. Each notice pins source refs and names the exact affected scope. Do not infer theorem transfer or supersession from shared words.
- Add open `frontier/OPEN_PROOF_GATES.jsonl` rows for unresolved proof review and physical/capability acquisition as applicable; each needs a unique `gate_id`, `card_ids`, exact question/pass condition, evidence, `status: open`, empty `completion_evidence`, and an explicit validation boundary. N788 uses separate review and capability gates. Never close a gate on hashes, internal replay, finite fixtures or same-team criticism alone.
- Use `updates/FL/BRIDGES.json` / canonical `mechanisms/bridge_candidates.json` only for an explicit paired transfer, with both source and destination interfaces, assumptions, costs, missing lemma, falsifier and evidence. It is not mandatory for a standalone result.
- Add a Capital-side branch checkpoint under `state/checkpoints/worker-fl-hip-capital-synthesis/<unique-id>.json` using `agent/templates/BRANCH_CHECKPOINT.json`. This is an independent intake handoff, not an assertion about the original Ultra worker's branch identity. The current Capital `ultra` head is still `2026-10-11-sampler-encoder-gates`; it describes other work. If source-side Ultra continuity is also needed, append to that branch separately rather than treating one record as the other.

For checkpoint evidence refs, paths must be Capital-repository-relative, hashes full SHA-256, line ranges one-based/inclusive, and statuses scoped. The checkpoint validator's `source_revision` field verifies `git show <revision>:<path>` inside the Capital repository. Since `788beab...` is from a different repository, pin it in `SOURCE_MANIFEST.json` as the source-repository commit and leave checkpoint `source_revision` null for copied artifacts unless a Capital commit actually contains and verifies the same bytes.

## Build, validation and publication commands

First refresh and choose the actual base. To extend PR #83, work from its latest head; otherwise wait for merge and use refreshed `origin/main`. Never branch from stale `ace0cfc...` while PR #83 has already allocated N791–N811.

After adding authoritative claim/status/catalog/gate/notice records and their source/card files, regenerate the bounded public projections and check them:

```sh
python3 frontier/build_access.py build --base-revision <full-checked-capital-base>
python3 frontier/build_access.py check --base-revision <full-checked-capital-base>
python3 updates/FL/validate.py
python3 frontier/retrieve.py dossier <new-route-ID>
python3 frontier/retrieve.py connections <new-route-ID>
```

The generated dossier, connection, concept, gate/blocker views and access manifest come from `frontier/build_access.py`; do not hand-edit those outputs. The intake validator should check hashes, source/card/status/catalog agreement, line ranges, open gates, unique IDs, append-only ledgers and the new checkpoint independently. Add technology/workflow validators only if the intake actually creates those record types.

The normal checkpoint command documented in `state/CONTINUITY.md` is:

```sh
python3 state/publish_checkpoint.py publish /path/to/completed-record.json \
  --base-revision <full-checked-out-HEAD> --expected-parent NONE
```

For the existing Capital checkout, this currently hits inherited `unsupported checkpoint schema` records and fails before publishing. `python3 state/publish_checkpoint.py validate --immutable-base <full-PR-base>` has the same inherited failure; report it as failed/inherited, never as a pass. The three pinned malformed records are `state/checkpoints/worker-conditional-copy-hierarchy/2026-10-11-conditional-copy-hierarchy.json`, `worker-mixed-state-classicalization/...`, and `worker-weighted-union-uniformization/...`; their exact hashes are in `updates/FC/PUBLICATION_STATUS.json`. Do not repair, rewrite or delete them.

The existing FD–FK PRs used a new-only fallback: branch absent, empty parent list, current checked-out HEAD and remote main recorded, `state.publish_checkpoint.validate_record(record, root)` passed, then the new checkpoint and its branch view were exclusively created and only its new row was appended to `state/branches.tsv`. Their update-specific validators individually revalidated the record; `PUBLICATION_STATUS.json` records global validation as failed/inherited. For a new `worker-fl-...` branch, follow that documented precedent, keep the draft outside `state/checkpoints/` until complete, and preserve all existing branch views/rows. Do not run the global `rebuild` and overwrite branch registry views via a one-branch projection. If adding to an existing branch, the fallback's empty-parent precondition does not apply; reconcile all current heads explicitly or use the prescribed publisher after the inherited issue is resolved.

Before any merge/publication, record the current PR/main revisions, run the update validator and access `check`, inspect `git diff --name-only <base> -- cards frontier/cards state/checkpoints updates indexes agent`, and verify old cards/checkpoints/source bytes are additions-only. The existing publisher's self-test checks publication software behavior only; it does not validate mathematics. Any inherited global failure remains reported as a failure.

## Relevant repository references

- Capital instructions: `AGENTS.md`, `00_START_HERE.txt`, `agent/ACCESS.txt`, `state/CONTINUITY.md`, `UPDATE_PROTOCOL.txt`.
- Current claim/card precedents: `updates/FC/CLAIMS.json`, `updates/FC/PUBLICATION_STATUS.json`, `updates/FC/VALIDATION.json`, `frontier/cards/N788-equilibrium-histogram-design-and-coherence-conditioned-comparison.json`, `frontier/gates/G-FC-N788-REVIEW.json`, `frontier/gates/G-FC-N788-CAPABILITY.json`.
- Latest unmerged intake examples: PR #83, `updates/FD/`–`updates/FK/`, checkpoint branches `worker-fd-capital-synthesis` through `worker-fk-capital-synthesis`.
- Source packet: `/Users/harjas/Documents/ChatGPT/ultra/research/2026-10-14-capability-v1/ASTRA_CAPITAL_HANDOFF_v0001.json`, `CLAIM_LEDGER.json`, `REPORT.txt`, `root/PRINCIPAL_DERIVATION.md`, `root/ISOTOPE_OPERATION.md`, and `root/CORRECTIONS_v0001.md`, all pinned in Ultra commit `788beabca49c9821a86c8237b1328a53313a22c5`.
