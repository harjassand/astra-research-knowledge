# Foundational line kept alive: relative area–tilt in a smooth ambient metric

14 October 2026. Status: **candidate operation and open theorem gate, not a proof of the varifold dimension bound**. This is a lead-level independent calculation, distinct from the geometry scout's manuscript audit.

## Exact target and source boundary

For every locally finite stationary integral \(m\)-varifold \(V\) in every smooth finite-dimensional Riemannian ambient \((U,g)\), with a regular point meaning that the *entire local varifold* is \(q\) times one smooth embedded minimal disk, ask whether

\[
\dim_{\mathrm H}\operatorname{Sing}(\operatorname{spt}V)\le m-1.
\]

There is no sample or bit-complexity input here: the output is a universal mathematical theorem or a stationary counterexample, with no stability, minimizing, orientation, or density cap premise. Two transverse \(m\)-planes show that \(m-1\) would be sharp in Euclidean space.

Astra N427 records this smooth-ambient claim as **source-derived, unreviewed** from a programme summary, with its full cited proof packet unavailable in that capital snapshot. A publicly pinned OpenAI Math manuscript dated 5 October 2026 claims the Euclidean version; its available overview explicitly says it is not a full independent proof review and carefully limits the sharp theorem to Euclidean ambient space. The Euclidean manuscript is the strongest existing comparator, not a new result of this note. Historical priority and full correctness remain **UNKNOWN** here. The September 2026 De Lellis–Hirsch–Lihn–Spolaor primary paper constructs a smooth-metric stationary integral varifold with a multiplicity-two *flat tangent plane at a singular point*, so a flat tangent cannot simply be declared regular. Its one-point example does not refute the \(m-1\) dimension target.

## A concrete correction suggested by second variation

The Euclidean candidate's signed operation compares twice the projected mass defect against normal tilt, preserving cancellation that separate absolute estimates lose. A smooth metric adds a Jacobi potential to this cancellation. The following calculation is fully restricted to a smooth, two-sided embedded minimal **hypersurface** \(S\), a compactly supported smooth normal displacement \(u\nu\), and its normal graph \(S_t\); it says nothing yet about an unlabelled singular varifold.

Let \(A(t)=\operatorname{Area}_g(S_t)\). Measure the leading normal tilt of the graph relative to \(S\) by \(D(t)\), using normal parallel transport in a fixed tubular chart. For a fixed smooth \(u\), standard first and second variation and the tangent-graph expansion give

\[
2[A(t)-A(0)]
=t^2\!\int_S\bigl(|\nabla_Su|^2-(|A_S|^2+\operatorname{Ric}_g(\nu,\nu))u^2\bigr)\,d\mu_S+O_u(t^3),
\]
\[
D(t)=t^2\!\int_S|\nabla_Su|^2\,d\mu_S+O_u(t^3).
\]

Thus the *corrected* signed quantity

\[
2[A(t)-A(0)]-D(t)
+t^2\!\int_S (|A_S|^2+\operatorname{Ric}_g(\nu,\nu))u^2\,d\mu_S
=O_u(t^3).
\]

This identifies an actual term a smooth-ambient transfer must track; simply treating curved stationarity as Euclidean bounded mean curvature loses it. For normal graphs of size \(ar\) on scale \(r\) around a fixed smooth reference with bounded curvature, the curvature-potential term is of relative order \(r^2a^2\). Dividing an *uncorrected* geometric error of order \(r^2\) by the height-square scale \(a^2\) is uncontrolled when \(a\ll r\). The calculation supplies a plausible covariant signed-defect primitive, but it is classical second variation in a restricted smooth-graph class, not a new all-varifold estimate.

An exact sanity check shows why the correction is necessary even for a smooth reference. Take the equator of the unit round two-sphere, a minimal one-dimensional submanifold, and move it a constant geodesic normal distance \(t\). The latitude has length \(2\pi\cos t\), while its transported tangent has zero normal tilt relative to the equator. Therefore the uncorrected signed defect is \(4\pi(\cos t-1)=-2\pi t^2+O(t^4)\), not \(o(t^2)\). Here \(|A_S|=0\), \(\operatorname{Ric}(\nu,\nu)=1\), and the correction is exactly \(2\pi t^2\) at quadratic order. This is a counterexample to importing the *Euclidean cancellation formula unchanged*; it is not a counterexample to the singular-dimension theorem.

## Decisive gate

Construct a reference-dependent, measure-valued correction that applies to *every* sufficiently flat stationary integral varifold at the prescribed scales retained by a Frostman measure of singular centers. Its error, after height-square normalization, must be \(o(1)\) or integrable in \(dr/r\) **without** a lower bound on the height-to-radius ratio. It must accommodate variable integer multiplicity, no global sheet labels, failed fits, and center-dependent fitted minimal references. Then reconstruct the Euclidean source's signed inequality, normalized positive height, center-density inequality and frequency argument with the correction, or exhibit a smooth-metric stationary counterexample to the claimed bound. The existing smooth graph expansion alone passes none of these gates.

The matched comparison is the complete pinned Euclidean manuscript plus established Jacobi second variation and the same smooth-ambient input; a generic bounded-mean-curvature theorem is insufficient. De Lellis' primary 2025/26 remarks report Allard–Brakke examples with positive \(\mathcal H^m\) singular measure under merely bounded mean curvature. They do not automatically become stationary in a smooth metric, but they invalidate a transfer that only obtains a bounded Euclidean mean-curvature error.

## Sources and provenance

- Astra capital checkout `ace0cfc4437fe91c20ccd24d69e0ee4bb335e871`, dossiers N427 and N428, read-only; both remain source-derived and unreviewed.
- [Pinned original Euclidean manuscript PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-Codimension-One-Bound-for-the-Singular-Set-of-a-Stationary-Integral-Varifold-October-5-2026/varifold-singular-dimension.pdf) and [limited-scope overview](https://lowrank.github.io/latent-seminar/OpenAI-Math/346-stationary-varifold-singularities).
- [De Lellis–Hirsch–Lihn–Spolaor, *Stationary varifolds with singularities II*, arXiv:2609.20647](https://arxiv.org/abs/2609.20647), Theorem 1.1 and introduction.
- [De Lellis et al., *Remarks and Conjectures on Stationary Varifolds*](https://www.math.ias.edu/delellis/sites/math.ias.edu.delellis/files/final-2.pdf), introduction and Conjectures 1.1–1.5 (a pre-October-2026 source).
- [De Lellis–Spadaro, Jacobi normal functional for multiple-valued sections](https://www.math.ias.edu/delellis/sites/math.ias.edu.delellis/files/Salvatore.pdf), equation (1.1), supplies the standard curvature/second-fundamental-form comparator.

No full manuscript proof was verified here, and no smooth-ambient theorem or historical novelty is claimed.
