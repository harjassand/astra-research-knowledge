# Local dual construction: exact cluster-state response, scoped comparator

Status: an exact, scalable construction is established for a commuting-projector MPS family. A separate exact finite AKLT calculation now gives a feasible two-sided R=3 dual at N=6, with a close norm upper bound; exact span membership is also checked for N=7–9. This is not yet an all-N AKLT construction or a novelty claim.

## Contract

For an open chain of (N\ge 2) qubits, let

\[
 |C_N\rangle=\prod_{i=1}^{N-1}CZ_{i,i+1}|+\rangle^{\otimes N}
\]

be the 1D cluster state. Its stabilizers are (K_1=X_1Z_2), (K_i=Z_{i-1}X_iZ_{i+1}) for (1<i<N), and (K_N=Z_{N-1}X_N). Write (P_i=(I-K_i)/2). For supplied positive rational squares (\gamma_i=s_i^2) and real/rational local-field coefficients (v_i), take

\[
 H=\sum_{i=1}^N s_i^2P_i=\sum_i L_i^\dagger L_i,\qquad L_i=s_iP_i,
 \qquad V=\sum_i v_i Z_i.
\]

The ground state is the explicit bond-dimension-2 MPS (\psi=|C_N\rangle), unique because the (K_i) form a complete independent stabilizer set.

## Exact dual

For (|i\rangle=Z_i\psi), the stabilizer syndrome has only (K_i=-1): (P_j|i\rangle=\delta_{ij}|i\rangle). Distinct syndromes are orthogonal and (\langle\psi|V|\psi\rangle=0). Therefore

\[
 b=V\psi=\sum_i v_i|i\rangle,\qquad
 H^+b=x=\sum_i\frac{v_i}{s_i^2}|i\rangle,\qquad
 \chi=b^\dagger H^+b=\sum_i\frac{v_i^2}{s_i^2}.
\]

Set (w_i=(v_i/s_i)|i\rangle). Every component is the same bond-2 MPS with one local physical tensor multiplied by (Z_i); it has a local tensor description and needs no full-state inverse. Directly,

\[
 \sum_i L_i^\dagger w_i=\sum_i s_iP_i\frac{v_i}{s_i}|i\rangle=b,
 \qquad \sum_i\|w_i\|^2=\sum_i\frac{v_i^2}{s_i^2}=\chi.
\]

The dual is exactly feasible and norm-optimal. The construction takes (O(N)) tensor/parameter operations and response contractions, plus the bit cost of the acquired (s_i,v_i). It uses the local syndrome eigenvalue (s_i^2), not a global gap bound. For example, (s_i=2^{-i}) gives a global gap (4^{-N}) while the same formula constructs the certificate with (O(N))-bit coefficients. No uniform gap premise or residual-to-response gap inequality is used.

## Scope and decisive limit

This works because the perturbation creates mutually orthogonal, exactly localized stabilizer syndromes and (H) is diagonal on them. It is a transparent counterexample to a blanket claim that local dual certificates always require a global inverse or uniform gap. It does **not** establish a generic injective-MPS theorem. The AKLT finite certificate below is a positive instance, while its extension to all N remains the decisive open construction question.

For a general exact feasible dual (w) and any primal trial state (x), the primal-dual gap is

\[
 \|w\|^2-\bigl(2\operatorname{Re}\langle b,x\rangle-\langle x,Hx\rangle\bigr)
 =\|w-(L_jx)_j\|^2.
\]

Thus, once exact feasibility is proved, closeness can be certified by a local/tensor contraction of the primal-dual residual; no spectral-gap conversion is needed. The cluster family has zero gap exactly.

## Finite AKLT certificate and transfer-matrix lead

For the periodic spin-1 AKLT MPS with integer-gauge tensors in `aklt_r3_exact_certificate.py`, take source (b=S^z_0\psi), parent rows (P^{(2)}_{j,j+1}), and the R=3 local row space with **both** possible pair placements inside each three-site window. The exact N=6 Gram solve gives a feasible dual with normalized cost

\[
 U=\frac{159740147}{109636215}=1.4570016577095442,
 \qquad \chi=\frac{287145511231}{197956185875}=1.4505508376096863,
 \qquad U/\chi=1.0044471520284584.
\]

The response value here is computed by an exact finite-sector inverse solely as a validation reference; the dual is independently constructed from the local row Gram matrix. A tangent-space primal gives (L=4243/3050=1.3911475409836065), hence (L\le\chi\le U), with no gap premise. The exact certificate is saved in `aklt_r3_exact_certificate_n6.json`; its builder is `aklt_r3_exact_certificate.py`. Exact source-span membership for the same two-placement row space was separately checked for N=6,7,8,9, with ranks respectively 85,109,125,141 and matching augmented ranks. The earlier N=6 **right-only** failure does not apply to the two-placement ansatz. Conversely, restricting the N=6 sum to only bonds near the source fails, so the completion is chain-wide even though each row has fixed radius.

The exact covariance identity is (S^z A^m=[J_z,A^m]), with (J_z=\mathrm{diag}(1/2,-1/2)). If (\eta_j) denotes the periodic MPS with (J_z) inserted on virtual bond (j), then the site-source state obeys (b_j=S^z_j\psi=\eta_{j-1}-\eta_j), so (\sum_j b_j=0). The normalized AKLT transfer channel has eigenvalue (-1/3) on the traceless/spin-1 virtual sector. These exact current identities are saved and checked by `aklt_virtual_current_identity.py`.

The missing step is a local parent-peeling identity that turns this virtual current into rows of the form (P^{(2)}_{j,j+1}w_j), with each (w_j) in the fixed-width outside-Schmidt-support ansatz. The transfer eigenvalue by itself does not imply this span membership; no all-N AKLT feasibility theorem is established here. Exact N=6 checks also show the completion needs a chain-wide tail: both placements restricted to bonds ({0}), ({0,1}), ({0,5}), ({0,1,5}), or ({0,1,2,5}) fail to contain the source, while the full ring succeeds. Ranks are saved in `aklt_n6_local_support_probe.json`.

## Prior-art boundary

MPS tangent-space and DMRG linear-response methods already provide efficient variational response spaces and response solvers; see Haegeman et al., [Time-Dependent Variational Principle for Quantum Lattices](https://arxiv.org/abs/1103.0936), and Nakatani et al., [Linear Response Theory for the Density Matrix Renormalization Group](https://arxiv.org/abs/1311.1646). Those works make tangent-space response a necessary baseline, but they do not by themselves give the exact dual feasibility/norm certificate above for a generic MPS source.

The primal-dual/Hodge viewpoint and explicit feasible-flow versus minimum-energy distinction are already present in Astra's N764 route: [N764 card](../../../../work/astra-capital-frontier-genesis/cards/N764-tensor-conservation-completion-and-certified-infinite-hodge-response.txt) and its recovered note. The present cluster-state identity is simpler and fully exact, but it is a commuting stabilizer calculation. No advantage over standard stabilizer evaluation, MPS linear response, sparse linear solves, or existing quantum-flow methods is established. Inputs are supplied mathematical tensors/couplings; this is not an acquired material model or experiment.

## Status

The cluster family has an exact algebraic derivation for all finite (N\ge2). AKLT has an exact norm certificate at N=6 and exact span membership checks at N=6–9, but no all-N derivation; the finite response inversion is validation only. No independent implementation or external peer review was performed. No practical advantage over a matched variational response baseline has been established.
