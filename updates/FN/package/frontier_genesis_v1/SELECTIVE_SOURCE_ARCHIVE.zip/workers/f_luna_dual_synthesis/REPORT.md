# Exact dual completion for local MPS response: transfer, gapless witness, and limits

**Disposition:** A gap-independent exact certificate is available for a strict but useful image class: if a local/tensor operator $K$ gives $HK\psi=b$, then $w=FK\psi$ is the exact minimum-norm dual witness, with $Fx=(L_jx)_j$. Frustration-freeness makes $w$ local when $K$ is local. This is a verifier/search target, not a general solver for arbitrary local $V$. An independent stoquastic route turns the response into a reversible Markov Poisson problem and Thomson flow; an explicit full-support product-MPS example has a unique ground state whose gap is at most $O(N^{-2})$ and admits exact constant-bond response certificates. The general capability and novelty gates remain open.

## Exact input/output contract

For each finite chain of $N$ sites, take the following as supplied exact data:

- local Hilbert dimension $d$, local rows $L_j$, and $H=F^\dagger F=\sum_j L_j^\dagger L_j$;
- a normalized ground-state MPS $\psi$, with its tensors, boundary convention, coefficient field, and an exact check that $L_j\psi=0$ for every row;
- a local observable $V$, and $b=(V-\langle V\rangle_\psi)\psi$.

The desired output is a succinct $w=(w_j)_j$ satisfying $F^\dagger w=\sum_jL_j^\dagger w_j=b$, with its exact value $\chi=\sum_j\|w_j\|^2=b^\dagger H^+b$. Feasibility alone certifies only $\chi\le\|w\|^2$; an exact result also needs a short optimality witness. If $b\not\perp\ker H$, the dual constraint is infeasible and the unconstrained variational supremum is infinite; the Moore–Penrose quadratic alone omits this kernel component.

For every finite-dimensional $F$, the primal/dual identity is

\[
 b^\dagger H^+b
 =\sup_x\{2\operatorname{Re}\langle b,x\rangle-\|Fx\|^2\}
 =\min_{F^\dagger w=b}\|w\|^2,
 \qquad (b\in\operatorname{ran}H).
\]

An exact pair $(x,w)$ with $Hx=b$ and $w=Fx$ proves equality. Indeed $F^\dagger w=b$, while $w\in\operatorname{ran}F\perp\ker F^\dagger$, so every other feasible $w+z$ has squared norm $\|w\|^2+\|z\|^2$. This is the right acceptance condition: a short feasible completion without the range/optimality witness is just an upper bound.

## Local frustration-free completion

Assume every $L_j$ is supported on at most $\ell$ consecutive sites and $L_j\psi=0$. Let $K$ be supported on a fixed block $S$, put $x=K\psi$, and suppose the exact local identity

\[
 \sum_{j:\,\operatorname{supp}(L_j)\cap S\ne\varnothing}
 L_j^\dagger L_j K\psi
 = (V-\langle V\rangle_\psi)\psi
 \tag{1}
\]

holds. For every disjoint row, \(L_jK\psi=K L_j\psi=0\). Therefore (1) is exactly \(Hx=b\), and

\[
 w_j=L_jK\psi,\qquad
 \chi=\sum_{j:\,\operatorname{supp}(L_j)\cap S\ne\varnothing}
 \|L_jK\psi\|^2=\langle K\psi,b\rangle.
 \tag{2}
\]

Only \(O(|S|+\ell)\) row components are nonzero. Overlapping rows inside this window need not commute: their contributions add in \(H x\), and their row-vector norms add in \(\|F x\|^2\). No gap or detectability estimate appears. If \(H\) has extra zero modes, exact (1) itself puts \(b\) in \(\operatorname{ran}H\); replacing \(x\) by its kernel-orthogonal representative leaves \(Fx\) and (2) unchanged.

For an explicit MPS, a fixed-radius search for \(K\) is a finite exact linear-algebra problem. Choose a basis of local operators on the window touched by \(K\), all active rows, and \(V\); contract its Gram matrix against the MPS left/right environments; solve for coefficients in the input's exact number field; and verify the squared norm of the full residual in (1) is exactly zero. The equality is global as a vector identity, but all terms are local-operator insertions on the supplied MPS and reduce to a finite window plus two boundary environments. The response norm uses the same contractions. A truthful cost bound must include MPS bond \(D\), window length, local dimension, active-row count, coefficient bit lengths/intermediate growth, local solve and residual contractions. With fixed windows it is polynomial in these explicit parameters; discovering the MPS or a candidate \(K\) from measurements is an additional acquisition cost.

If the residual is merely small, it does not give a response error bound without a spectral lower bound on the nonzero spectrum of \(H\). The exact zero-residual gate is what removes the global-gap dependency.

## Independent stoquastic / Thomson route

There is an exact transfer when \(H\) is real symmetric stoquastic in a supplied configuration basis and its ground vector has strictly positive entries. Set \(D=\operatorname{diag}(\psi_s)\), \(\pi_s=\psi_s^2\), and

\[
 Q=-D^{-1}HD,\qquad
 q_{st}=-H_{st}\frac{\psi_t}{\psi_s}\quad(s\ne t),\qquad
 c_{st}=\pi_s q_{st}=-\psi_s\psi_t H_{st}.
\]

Then \(Q\mathbf1=0\), \(q_{st}\ge0\), and detailed balance holds. For diagonal \(V\), let \(f(s)=V(s)-\mathbb E_\pi V\), so \(b=D f\). With \(x=Dg\), \(Hx=b\) is exactly \(-Qg=f\), and

\[
 \chi=\langle f,(-Q)^+f\rangle_\pi
 =\min_{\nabla^*j=\pi f}\sum_{\{s,t\}}\frac{j_{st}^2}{c_{st}}.
 \tag{3}
\]

The minimizer is \(j_{st}=c_{st}(g_s-g_t)\); every other feasible current differs by a divergence-free current orthogonal to this gradient. Equation (3) transfers the exact output, not just an analogy: quantum response becomes a classical Poisson solve on the configuration graph, and the quantum dual witness becomes an electrical current. The graph may have \(d^N\) vertices, so scalability requires \(\pi\), \(f\), and \(j\) to be given or discovered in a contractible tensor/automaton form. Zeros in \(\psi\), complex signs, nonstoquastic entries, or non-diagonal probes without a compact componentwise ratio break this route.

### Explicit unique-ground, gapless, full-support example

For \(N\ge3\) qubits define

\[
 H_N=| -\rangle\langle - |_1
   +\sum_{i=1}^{N-1}|s\rangle\langle s|_{i,i+1},
 \quad | -\rangle=(|0\rangle-|1\rangle)/\sqrt2,
 \quad |s\rangle=(|01\rangle-|10\rangle)/\sqrt2.
 \tag{4}
\]

Every term is a projector, so it is also an \(L_j\) in \(H=\sum_jL_j^\dagger L_j\). It is stoquastic in the computational basis. The exact ground MPS is \(\psi=|+\rangle^{\otimes N}\), bond one and strictly positive on all \(2^N\) configurations. The adjacent singlet constraints force the fully symmetric subspace; the boundary constraint then leaves only \(|+\rangle^{\otimes N}\), so the ground state is unique.

The induced reversible chain is simple exclusion (each adjacent unequal pair swaps at rate \(1/2\)) plus a flip of site 1 at rate \(1/2\), with uniform stationary measure. It is gapless: for \(G(s)=\sum_{i=1}^N i(n_i-1/2)\), \(\operatorname{Var}_\pi G=N(N+1)(2N+1)/24\), while its Dirichlet energy is \((N+1)/8\). Thus

\[
 \operatorname{gap}(H_N)\le
 \frac{\mathcal E(G)}{\operatorname{Var}_\pi G}
 =\frac{3}{N(2N+1)}\longrightarrow0.
 \tag{5}
\]

For an interior site \(2\le k\le N-1\), take the three-site diagonal observable

\[
 V_k(s)=n_k-\tfrac12(n_{k-1}+n_{k+1}),
 \qquad g_k(s)=n_k-\tfrac12.
\]

The local generator identity is \(-Qg_k=V_k\). Therefore \(x=g_k\psi\) and \(w=F x\) are exact, only the two swap rows touching site \(k\) are nonzero, and \(\chi=\mathbb E_\pi[V_kg_k]=1/4\), independent of \(N\), despite (5). In the flow form, \(j_{st}=c_{st}(g_k(s)-g_k(t))\) uses only those two local transition families; its exact energy is \(1/4\). The configuration graph is exponential, but the certificate is a constant-size local rule.

This is a real gapless response witness, but a deliberately structured one: the probe is a local generator derivative \(-Qg\). It does not show that an arbitrary local observable has a local preimage. For example, for \(f=n_N-1/2\), the unique mean-zero Poisson solution is

\[
 g(s)=\sum_{i=1}^N(2i-1)(n_i-\tfrac12),
 \qquad -Qg=f,\qquad \chi=\mathbb E_\pi[f g]=(2N-1)/4.
 \tag{6}
\]

This follows by solving the exact tridiagonal equations on the degree-one occupation subspace: after multiplying by two, the interior recurrence is \(2a_i-a_{i-1}-a_{i+1}=0\), the left equation is \(3a_1-a_2=0\), and the right equation is \(a_N-a_{N-1}=2\). The resulting potential is global and the response grows with \(N\), even though its additive representation remains low-bond. The example both validates the gap-independent certificate and blocks any claim that locality of \(V\) alone makes the inverse local.

## What does and does not transfer

| Route | Exact structure that transfers | Missing condition for the proposed operation |
|---|---|---|
| Thomson / reversible networks | Minimum energy among currents with prescribed divergence; the exact Markov ground-state transform (3) supplies conductances and injections. | General quantum \(L_j\) rows are not scalar configuration-graph edges. Stoquasticity, positive full-support \(\psi\), diagonal (or compact transformed) probes, and a succinct current rule are needed. |
| Local chain homology / Hodge | A source \(b=\partial w\), cycle freedom, and orthogonal projection onto gradients give feasible upper bounds and exact minimum-energy witnesses. | \(H=F^\dagger F\) alone does not make the \(L_j\) a boundary map with \(\partial^2=0\), nor provide a low-rank exact filling. A tensor-train divergence repair can be compact yet high-energy. |
| Span programs | The minimum squared norm of a witness solving a linear span equation and its dual are the same norm optimization pattern. | Query-model witness size assumes a supplied span program/input access model; it does not find or certify an exact local/MPS decomposition of this physical \(b\), and its query cost is not a tensor contraction or state-acquisition cost. |
| MPS injectivity / parent left inverse | A blocked injective MPS map has a finite-dimensional left inverse on its image and gives local support/parent-projector constructions. | That left inverse is not \(H^+\). It covers the MPS map's image, not arbitrary \(V\psi\), and canonical-parent gap results do not apply to every FF Hamiltonian sharing the same injective MPS. Example (4) has an injective bond-one ground MPS but a gapless nonminimal FF Hamiltonian. |
| Detectability lemma | Layered products of local projectors approximate the ground-space projector for frustration-free systems, with quantitative dependence on the gap. | It approximates a projector, not an exact solution of \(Hx=b\). Its gap dependence cannot certify the requested no-gap response, and noncommuting overlaps are handled by its own bounds rather than erased by a tensor analogy. |

The nearest internal capital is already substantial: N764 supplies exact matrix-product/tensor-train completion of a prescribed divergence in an exclusion-gap graph, proves a no-gap Hodge lower/upper certificate, and records an executed infinite-graph current-energy interval. It explicitly says that feasible repair is not the minimum-energy inverse, the compact sparse comparator was faster on its two-gap example, and the full interacting response/rank gate remains open. Its model is a translation-invariant quantum transport problem reduced to gap-coordinate currents, not a generic local MPS parent-Hamiltonian pseudoinverse. This makes broad novelty claims for “tensor Hodge response” unsafe; a new claim would need to isolate exact MPS row-map completion beyond that scoped result and beyond established flow/tensor methods. See the local source and its exact scope at [N764 research note](../../../../work/astra-capital-frontier-genesis/updates/EW/package/frontier_separable/recovered/astra_frontier_separable_completion/research_note.md), especially lines 8–20, 115–182, 343–365, 404–424, and 489–523.

## Cost gate and next decisive test

The practical candidate should be stated as a fixed-radius (or fixed-bond) exact completion recognizer/solver:

1. Inputs are the acquired exact local rows, supplied normalized ground MPS, local \(V\), arithmetic field, and a stated radius/bond cap.
2. Search solves a finite local linear system for \(K\), or a finite tensor ansatz for \(x\); the verifier checks the full exact residual \(Hx-b=0\) through MPS contractions and emits \(w=Fx\).
3. Output is the exact rational/algebraic \(\chi=\|w\|^2\), the row tensors, the dual identity and the range witness. Failure to find a witness within the cap returns `UNKNOWN`, not a conclusion that no compact witness exists.

Charge MPS/source acquisition, construction of all local rows, local solve and tensor contraction, exact-arithmetic bit growth, output storage, and verification. Compare against (a) sparse/structured linear solves for the same finite chain, (b) standard MPS tangent-space or variational response methods where applicable, and (c) in the stoquastic case, the strongest known Poisson/electrical-network solver on the same configuration graph. Example (4) is a validation fixture, not an advantage result; the direct Poisson solution is equally easy there. A decisive pass is a nontrivial family where exact bounded-resource dual completions are discoverable from the stated input and outperform those matched methods without a gap promise. A decisive fail is a bounded-support probe family whose exact solution needs growing bond/bit resources, or a local residual that cannot be certified without importing a gap.

## Primary-source anchors and status

- Berman and Konsowa, “Random Paths and Cuts, Electrical Networks, and Reversible Markov Chains,” *SIAM J. Discrete Math.* 3(3), 311–319 (1990), [DOI:10.1137/0403026](https://doi.org/10.1137/0403026). Thomson’s minimum-energy current principle is the exact comparison for (3).
- Kipnis and Varadhan, “Central Limit Theorem for Additive Functionals of Reversible Markov Processes and Applications to Simple Exclusions,” *Commun. Math. Phys.* 104, 1–19 (1986), [DOI:10.1007/BF01210789](https://doi.org/10.1007/BF01210789). The reversible exclusion setting is established; no new Markov theorem is claimed here.
- Henley, “From classical to quantum dynamics at Rokhsar–Kivelson points,” *J. Phys.: Condens. Matter* 16, S891 (2004), [arXiv:cond-mat/0311345](https://arxiv.org/abs/cond-mat/0311345), and Castelnovo et al., “From quantum mechanics to classical statistical physics: generalized Rokhsar–Kivelson Hamiltonians and the ‘stochastic matrix form’ decomposition,” [arXiv:cond-mat/0502068](https://arxiv.org/abs/cond-mat/0502068). These establish the classical dynamics / stochastic-matrix-form bridge; equation (3) is also derived directly above.
- Pérez-García, Verstraete, Wolf, and Cirac, “Matrix Product State Representations,” *Quantum Inf. Comput.* 7, 401–430 (2007), [arXiv:quant-ph/0608197](https://arxiv.org/abs/quant-ph/0608197). MPS canonical forms, injectivity and frustration-free parent constructions are established; they are not an inverse theorem for arbitrary FF sums.
- Reichardt, “Span programs and quantum query complexity: The general adversary bound is nearly tight for every boolean function,” [arXiv:0904.2759](https://arxiv.org/abs/0904.2759). Witness-norm optimization is a structural comparison, not a physical input/output transfer.
- Aharonov, Arad, Landau, and Vazirani, “The Detectability Lemma and Quantum Gap Amplification,” [arXiv:0811.3412](https://arxiv.org/abs/0811.3412). Its quantitative projector approximation does not provide the exact no-gap Poisson solve requested here.

The algebra and example above are an internal derivation, not an independent peer review, formal proof, novelty clearance, or production implementation. The status of the broad operation is **candidate / not established**.
