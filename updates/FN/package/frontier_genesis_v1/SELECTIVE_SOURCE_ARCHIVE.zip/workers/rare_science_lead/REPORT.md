# Rare-transition computation: acquired trajectories expose the rate bottleneck

**Status, 2026-10-14:** A reproducible model-only acquisition test was run. It did not establish a new rare-event algorithm, an acquisition-inclusive speedup, a physical transition rate, or a control advantage. The live opportunity is conditional on a physical or open-data system with a demonstrably accessible state-preparation and time-resolved event interface. No such interface was validated in this branch.

## Exact consequential operation

For a named bistable stochastic reaction or material system, start from a specified low-state preparation, choose a target threshold and ask for the first-transition time or finite-horizon failure risk under one accessible control. The computational output must include uncertainty sufficient to choose an intervention. The **input** is acquired jump/trajectory data, the preparation and observation protocol, the control-to-propensity relation, and the target predicate. A supplied generator, rates, committor, or ideal reset is privileged information and cannot be silently excluded from acquisition cost.

One precise benchmark here is the Schlögl reaction network \(A+2X\rightleftharpoons3X\), \(B\rightleftharpoons X\) with buffered \(A,B\). The target is \(\mathbb E_{n=85}[\tau_{400}]\), where \(\tau_{400}\) is first arrival at \(n=400\). The source-published benchmark propensities are

\[
\lambda_n=k_1A\binom n2+k_3B,\qquad
\mu_n=k_2\binom n3+k_4n,
\]

with \((k_1,k_2,k_3,k_4,A,B)=(3\cdot10^{-7},10^{-4},10^{-3},3.5,10^5,2\cdot10^5)\). These parameter values are used **only inside the simulator** and for a withheld-answer check. The inference routine sees accumulated occupation times and up/down jump counts from generated paths, plus the **assumed mass-action functional form**. That assumption is substantial and would have to be independently checked for a real system. Even an observed \(X\) path does not label which of the two birth or death channels fired; the polynomial form is what permits four-coefficient identification.

## Acquisition test actually run

[`acquire_schlogl.py`](acquire_schlogl.py) implements exact Gillespie SSA for this source-defined model, positive Poisson maximum-likelihood fits of the four coefficients from path records, and the birth-death backward Poisson recurrence

\[
d_0=1/\lambda_0,\qquad d_n=(1+\mu_nd_{n-1})/\lambda_n,\qquad
\mathbb E_{85}[\tau_{400}]=\sum_{n=85}^{399}d_n.
\]

The last step is the strongest simple comparator when the one-dimensional acquired generator is trusted; it is not a proposed new solver. The withheld exact-model value is **50,269.627 s**. A short-event sanity check gave SSA mean \(1.543\pm0.110\) s (standard error) from 256 paths for \(85\to100\), versus exact Poisson recurrence \(1.486\) s.

Twelve independent acquisitions used the same three nested budgets. All source trajectories were freshly generated from the simulator; no fitted rates or matrix were passed to the inference routine.

| Acquired path budget per replicate | Median observed jumps | Fitted \(85\to400\) MFPT range across 12 replicates | Retrospective median Fisher/delta log-MFPT SD |
|---|---:|---:|---:|
| 40 independent 2-s paths prepared at \(n=85\) | 49,752 | 125 s to \(4.47\times10^{16}\) s | 9.25 |
| Same plus 10 independent 0.5-s paths prepared at \(n=570\) | 100,131 | 9,945 to 796,896 s | 1.16 |
| Same plus 10 independent 0.5-s paths prepared at \(n=248\) | 111,151 | 13,042 to 1,117,244 s | 1.10 |

The native-path maximum state across replicates was 131–181: none reached the \(n\approx248\) saddle. The high-state preparation constrains the cubic death propensity, but it is a simulator reset to the other basin. The small additional barrier-preparation budget did **not** improve the empirical estimate range; any statement that it solves acquisition would be false. The Fisher/delta figures are retrospective local-asymptotic diagnostics computed at the withheld true parameters, **not** confidence intervals or finite-sample guarantees. A 0.1% perturbation of the first birth coefficient changes MFPT by about 10%, and a 0.1% perturbation of the linear death coefficient changes it by about 14%; accurate local rates alone do not imply an accurate rare-transition time.

Raw aggregate exposure and jump counts for replicate 0 are in [`schlogl_acquired_paths_first_rep.json`](schlogl_acquired_paths_first_rep.json); every replicate's fitted values, costs, and diagnostics are in [`schlogl_results.json`](schlogl_results.json). Rerun with `python3 research/2026-10-14-frontier-genesis-v1/workers/rare_science_lead/acquire_schlogl.py` from the workspace root. The seeds and fit algorithm are fixed in the script. Runtime on this host was about four seconds for the 12-replicate calculation; the meaningful cost is the number of simulated reaction firings and the ability to prepare/observe them.

## Current best comparators and why they matter

The published source paper already uses **weighted ensemble** (WE) on this Schlögl benchmark and reports rare-state and MFPT estimates from path resampling. Its method uses the same forward simulator class without requiring a fitted global birth-death operator. **Forward-flux sampling** (FFS), transition-interface sampling, and adaptive multilevel splitting are likewise established ways to get rare transitions from stochastic trajectories. A matched algorithmic claim must beat tuned WE/FFS at equal simulated reaction-firing budget, including interface/bin tuning, genealogy and uncertainty. This experiment did not run those methods, so it makes **no** speedup claim.

If a validated low-dimensional generator can be acquired, solve the backward Poisson equation for MFPT or the committor equation for hit probabilities; transition-path theory returns reactive flux and paths. In this one-dimensional benchmark that solve is cheap. Ideal committor/Doob importance sampling makes rare paths accessible but has the expensive committor as an input. Current stochastic-reaction-network work already learns importance-sampling controls and compares variance. Common-reaction-path coupling and Girsanov/likelihood-ratio methods already treat parameter response; generic paired-control contrast is not new. Kubo/linear-response and Harada–Sasa type dissipation relations cover different scoped response outputs and do not infer an unobserved large-barrier MFPT for free. The independent [path/control](../rare-path-control.md), [representation](../rare-representation.md), and [comparator adversary](../rare-comparator-adversary.md) reports make these collisions explicit. The representation scout tested a known polynomial supermartingale/SOS route on a 1D diffusion; its certificate is a bounded hit probability conditional on a supplied drift/diffusion, not an acquired kinetic rate or novelty claim.

## Complete interface bill and decisive next gate

The local SSA source permits arbitrary \(n=570\) and \(n=248\) preparations and resolves individual jumps. A physical counterpart must pay for **reaction-network discovery, chemostat composition, kinetic calibration, repeatable low/high/barrier-state preparation, high-bandwidth molecule or reaction-state measurement, missed-jump correction, resets, failed runs, and material/energy throughput**. Around \(n=570\) the published model has about \(10^4\) jumps/s, so the assumed jump-resolved observation corresponds to resolving sub-millisecond events. Slower projected-coordinate records can conceal distinct reaction channels and memory; a fitted one-species Markov model then lacks its claimed semantics. The Schlögl network is a canonical hypothetical bistable model, not evidence of a deployed chemical control system.

To continue, identify one real system or open raw trajectory collection with measured interventions and state preparation. Predeclare \(A,B,T\), the action, sensor bandwidth, and the decision loss. Acquire rates or simulator inputs from a training cohort; keep a fresh cohort for transition and response validation. Compare (1) native SSA/direct experimental counts, (2) backward Poisson/committor on the acquired model, (3) WE/FFS or adaptive splitting using the same forward dynamics, (4) a learned importance-sampling policy with all training paths charged, and (5) any proposed new operation. Score the **same** hit-risk or MFPT error with calibrated intervals and count simulation steps, preparations, instrument time, computation, and physical energy separately. Include a hidden-channel/slow-mode adversary: observing one transition route or a short apparent plateau must not be accepted as a complete rare-rate estimate.

The current local result is a **negative screen**: short native trajectories do not support a rare MFPT despite tens of thousands of events, and cheap extra state preparations do not yield a reliable estimate in this pilot. No scientifically consequential new computational operation has yet cleared acquisition, prior-art, and matched-baseline gates. The task remains open only as an explicitly costed empirical acquisition challenge.

## Open experimental-data audit

The independent [open-simulator/data scout](../rare-open-simulator/REPORT.md) located and acquired the [KinSoftChallenge archive](https://doi.org/10.5281/zenodo.5701310), whose three experimental donor/acceptor smFRET sets contain **134, 163, and 118 traces** and **36,604, 37,067, and 43,512 points**. I independently read the zip entries and confirmed those file/point counts. These are actual measured fluorescence signals, whereas the archive's synthetic sets have known generating labels. The associated [blind benchmark](https://doi.org/10.1038/s41467-022-33023-3) compares eleven kinetic-analysis tools and explicitly says the experimental sets have no ground truth. The source files sampled here advance their first-column timestamps by 0.1, while the published Figure 5 caption states 33 Hz/30 ms; that cadence mismatch is unresolved. The traces are already cut to their non-bleached intervals and have no controlled rare-transition intervention. They permit honest state/rate **inference comparisons**, but cannot independently validate an absolute rare-event MFPT or control improvement. A separate [DNA-hairpin transition-path archive](https://doi.org/10.6084/m9.figshare.14897091.v1) contains selected crossing paths; without basin dwell times or source flux, those paths alone also cannot determine a rate.

## Primary sources checked

- [Donovan, Sedgewick, Faeder & Zuckerman, *J. Chem. Phys.* 139, 115105 (2013)](https://arxiv.org/abs/1303.5986): source benchmark reaction scheme/parameters, WE implementation, and model-only rare-event comparisons.
- [Gillespie, *J. Phys. Chem.* 81, 2340–2361 (1977)](https://doi.org/10.1021/j100540a008): exact SSA conditional on specified propensities.
- [Allen, Frenkel & ten Wolde, *J. Chem. Phys.* 124, 024102 (2006)](https://doi.org/10.1063/1.2140273): original FFS interface-path methods and stochastic rare-event comparisons.
- [Metzner, Schütte & Vanden-Eijnden, *Multiscale Model. Simul.* 7, 1192–1219 (2009)](https://doi.org/10.1137/070699500): Markov-jump TPT, committors, reactive flux.
- [Ben Hammouda et al., *Statistics and Computing* (2023)](https://doi.org/10.1007/s11222-023-10222-6): stochastic-control importance sampling for reaction networks.
- [Rathinam, Sheppard & Khammash, *J. Chem. Phys.* 132, 034103 (2010)](https://doi.org/10.1063/1.3280166): common-reaction-path coupling for sensitivities.
- [Gupta & Khammash, *J. R. Soc. Interface* 11, 20140979 (2014)](https://doi.org/10.1098/rsif.2014.0979): Girsanov and coupled sensitivity comparisons.
- [Kubo, *J. Phys. Soc. Japan* 12, 570 (1957)](https://doi.org/10.1143/JPSJ.12.570) and [Harada & Sasa, *Phys. Rev. Lett.* 95, 130602 (2005)](https://doi.org/10.1103/PhysRevLett.95.130602): primary linear response and scoped dissipation-response comparators.
- [Metzner, Noé & Schütte, *Phys. Rev. E* 80, 021106 (2009)](https://doi.org/10.1103/PhysRevE.80.021106): transition-model sampling uncertainty affects committors and other derived quantities.
- [Endres, *PLOS One* 10, e0121681 (2015)](https://doi.org/10.1371/journal.pone.0121681): primary discussion of the Schlögl system as a minimal model without direct experimental implementation.
- [KinSoftChallenge data archive](https://doi.org/10.5281/zenodo.5701310) and [its blind-analysis paper](https://doi.org/10.1038/s41467-022-33023-3): observed smFRET trace acquisition with experimental ground truth unavailable.
