# Finite-field molecular selection benchmark

`build_benchmark.py` generates two fresh H6/STO-3G Hamiltonians with PySCF 2.14.0, then compares selected determinant subspaces against exact FCI. The asymmetric geometry is included so the field response has a nonzero odd component. The inherited H4 input is copied unchanged into this directory.

The run covers the inherited H4 case at `F=0.005`, two fresh H6 geometries at `F=0.0025, 0.005, 0.01`, and an additional H4 `K=4` comparison. The H6 determinant space has 400 determinants. Main selected runs use `K=12` and a cap of 6,000 unique symmetric Hamiltonian-element queries per field point.

The ordinary baseline is zero-field CIPSI-style selection using the Epstein–Nesbet second-order contribution, with its selected set reused across `−F, 0, +F`. For one bounded same-information comparison, asymmetric H6 at `F=0.005`, `K=12`, the code also runs independent field-specific CIPSI and pooled three-field CIPSI. Each selects 12 determinants per field; the pooled method shares one 12-address set, while field-specific runs have 36 selected memberships and may use up to 36 unique addresses across the three fields. Both ordinary field-aware methods selected the same 12-address support as zero-field CIPSI in this case and produced the same curvature error.

At that asymmetric H6 point, exact FCI gives `ΔE = −5.0194798e−4 Ha`, `α_linear-response = 20.0622597 a.u.`, and `α_FD = 20.0779191 a.u.`; the odd energy difference `E(+F)−E(−F)` is `−1.3277068e−2 Ha`. Zero-field, field-specific, and pooled CIPSI all have `|ΔE_error| = 4.8713937e−4 Ha`. Their measured query totals are 4,890, 14,202, and 14,202 respectively; their selection visit totals are 4,334, 13,002, and 4,334 (the pooled method scores each visit at all three fields). Single-run method times were about 0.009 s, 0.022 s, and 0.021 s. These tiny timings are descriptive only.

The response-aware greedy oracle uses the exact full-CI second difference as its target. It reaches an error near `9e−16 Ha` at the same `K=12`, but this is privileged target information: exact FCI uses 80,200 unique matrix elements per field in the 400-determinant space, and the oracle's field-element queries total 14,202. It scanned 4,334 external candidates and performed 13,002 three-field Ritz evaluations; its selection time was about 0.19 s, excluding the exact-reference run. Treat its result as an optimistic feasible upper bound on the globally best `K=12` error, not as a matched-information algorithm or global optimum.

For the inherited H4 space (`N=36`), the exact common-space `K=4` oracle exhaustively checks all 58,905 subsets and attains `|ΔE_error| = 1.03619e−6 Ha`; the greedy exact-target oracle at the same `K` has error about `3.70e−4 Ha`. This global optimum is certified only for H4 and `K=4`.

Direct sum-over-states linear response separates basis error from finite-field truncation. At inherited H4 and `F=0.005`, exact FCI has `α_LR=16.6890172 a.u.` and `α_FD=16.7085886 a.u.`, a `0.0195714 a.u.` truncation difference. At asymmetric H6 and `F=0.005`, the difference is `0.0156594 a.u.`. The symmetric H4 `E(+F)−E(−F)` is zero to roundoff; asymmetric H6 visibly breaks that symmetry.

The method counters gate unique element queries through an accessor, but the full Hamiltonian matrices are materialized first to provide exact FCI references and serve as backing arrays. They do not model memory isolation or end-to-end matrix-element construction. Per-field query counts, repeated candidate scans, FCI costs, and elapsed method times are saved in `benchmark_results.json`. The systems remain tiny minimal-basis hydrogen chains; this is a computation and accounting exercise, not evidence of scalable selected-CI performance.

Reproduce with:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  /Users/harjas/Documents/ChatGPT/ultra/research/2026-10-14-frontier-genesis-v1/workers/f_sol_molecular/.venv/bin/python \
  build_benchmark.py
```
