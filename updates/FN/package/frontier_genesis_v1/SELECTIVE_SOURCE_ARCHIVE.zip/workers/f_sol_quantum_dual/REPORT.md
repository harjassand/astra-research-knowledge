# Quantum susceptibility dual: exact construction and novelty gate

**Status: exact scoped constructions, including compact nonintegrable AKLT finite certificates; consequential new capability not established.** The Dicke-chain certificate is mathematically valid but reduces to known symmetric exclusion/electrical flow. A separate periodic AKLT calculation gives a rational, gap-free two-sided interval for six sites; compact transfer-matrix algebra certifies exact local-dual feasibility through twenty sites. There is no all-size theorem, physical acquisition, or matched advantage over existing response methods.

## Contract and duality

Let `H=Σ_e L_e†L_e` be finite-dimensional positive semidefinite, and let `b` be orthogonal to **every** vector in `ker H`. Then, with `χ=<b,H⁺b>`,

`χ = sup_x [2 Re<b,x> − Σ_e ||L_e x||²] = inf_{Σ_e L_e†w_e=b} Σ_e ||w_e||²`.

The equalities are ordinary quadratic/Fenchel duality. Feasible `w` supplies an unconditional upper bound; arbitrary `x` supplies a lower bound. For a feasible pair the gap is exactly `Σ_e ||w_e−L_e x||²`. A small residual `r=b−ΣL_e†w_e` is **not** an upper certificate: its missing correction can grow as `||r||²/ε` along a mode of energy `ε→0`. A local or observable-specific coercivity bound, or an exact completion for `r`, is needed. If `b` has a ground-space component, the displayed supremum is infinite even though the Moore–Penrose expression discards that component. For degenerate ground spaces, the physical adiabatic susceptibility also needs a specified state/sector and perturbation protocol.

## Explicit noncommuting frustration-free example

On `n` spin-1/2 sites in a connected graph `G=(V,E)`, let `P^-_{ij}=(I−SWAP_{ij})/2`, `H=Σ_(ij) P^-_{ij}`. Adjacent bond projectors do not commute. In the fixed `m`-particle sector (`0<m<n`), the exact zero-energy state is the Dicke state `|D_m> = C(n,m)^(-1/2) Σ_|η|=m |η>`. The input is a fully specified synthetic Hamiltonian and state; it is not physically acquired material data.

Set `b=(n_k−m/n)|D_m>`, `q=e_k−1/n`, `c=m(n−m)/[n(n−1)]`, and let `L_G` be the ordinary graph Laplacian. For every coefficient vector `f` with `Σ_i f_i=0`, define `X_f=(Σ_i f_i n_i)|D_m>`. Direct calculation gives

`<X_f,X_g>=c f·g`, `H X_f=(1/2) X_(L_G f)`, and `b=X_q`.

Thus the *entire* response to this observable lies in an `(n−1)`-dimensional invariant sector, despite the fixed-particle Hilbert dimension `C(n,m)` and full dimension `2^n`. Solve `L_G f=q`, `Σ_i f_i=0`, and set

`x=2X_f`, `w_(ij)=(f_i−f_j)(n_i−n_j)|D_m>`.

Because `P^-_(ij) x=w_(ij)` and `Σ_(ij) w_(ij)=b`, this is an exact primal/dual pair. The resulting output is

`χ=2c qᵀL_G⁺q = 2c (L_G⁺)_(kk)`.

For the six-site path, `m=3`, `k=1`, the exact answer is `11/12`; all five bond flows are needed. `validate_dicke_flow.py` builds the 20-by-20 many-body Hamiltonian with exact rationals, checks noncommutation and every flow equality, and independently calculates `bᵀH⁺b/C(6,3)=11/12` using SymPy's matrix pseudoinverse. The full Hilbert dimension is 64. Running it with Python/SymPy takes under a second locally.

The output has no excitation-spectrum reconstruction or global gap input. The acquisition/compute ledger is nonetheless modest: the graph and projector couplings are supplied; the Dicke state is analytic; constructing the graph Laplacian costs `O(n+|E|)`; solving its Poisson equation determines all coefficients; exact verification uses graph and combinatorial identities. For a path, currents and `χ` are computed in `O(n)` arithmetic. These are ordinary electrical-network costs, not a quantum speedup.

## Strongest comparators and priority

1. The symmetric exclusion process maps to a spin-1/2 ferromagnetic Heisenberg chain, and its one-point functions have the affine occupation closure used above. The graph Poisson/electrical-flow solution is therefore an equally informed direct comparator. [SEP self-duality primary article](https://link.springer.com/article/10.1007/s10955-018-2090-1); [Heisenberg/SEP primary source](https://pure.mpg.de/rest/items/item_3238820/component/file_3238821/content); [graph Laplacian pseudoinverse and electrical flows](https://doi.org/10.1103/PhysRevE.96.032311).
2. For nonintegrable MPS chains, tangent-space methods already target excitations and spectral functions, while correction-vector DMRG and Krylov methods directly solve the response equation. An exact local dual must beat these at equal information, accuracy, and full wall time. [MPS tangent-space primary paper](https://doi.org/10.1103/PhysRevB.88.075133); [DMRG correction-vector Krylov paper](https://arxiv.org/abs/1607.03538).
3. AKLT is a sensible noncommuting parent-Hamiltonian test, but its exact staggered spin-2 magnon and scar tower are already known. Using that source would only rediscover an existing exact excitation. We instead tested a local `S_z` field; the finite result is below. [Original AKLT exact-excitation paper](https://arxiv.org/abs/1708.05021).
4. Global-gap-free *approximate* local response also has direct recent prior art: the local-gap response theory of localized perturbations. That result does not itself provide our finite-size exact dual certificate, but it narrows any claimed conceptual novelty. [Primary article](https://link.springer.com/article/10.1007/s10955-026-03703-1).
5. The finite-patch spectral-gap method used in the matched residual comparator is established AKLT-specific prior art. [Knabe's original article](https://doi.org/10.1007/BF01019721).

## AKLT local-field result: exact finite repair and remaining gap

For the periodic spin-1 AKLT parent Hamiltonian `H=Σ_j P2_(j,j+1)` with its exact bond-dimension-two MPS ground state, take `b=S_z(0)|ψ>`. This source is local and is not the known exact staggered spin-2 magnon. For each physical bond `j`, form the span of `P2_j` applied within either contiguous three-site block containing that bond, tensored with the exact outside Schmidt support of `|ψ>`. The two placements overlap and must be **merged within each bond** before assigning a dual norm.

The right-hand placement alone fails exactly at `N=6`: in the total-`S_z=0` sector, the rational column matrix has rank `71`, while adjoining `b` raises rank to `72`. `aklt_r3_obstruction.py` supplies an explicit 59-entry integer left-null vector with dot product `−3552` against `b`; the JSON stores its full basis coefficients. This is a precise failure of that *one-placement* ansatz only.

With both placements merged, exact rational rank membership succeeds at `N=6,7,8,9`. The respective sector dimensions are `141,393,1107,3139`; the dual-span ranks are `85,109,125,141`; adding `b` leaves every rank unchanged. The ranks `109,125,141` follow `16N−3` for `N=7,8,9`, suggesting a bounded local tensor module, but these finite checks do not prove the pattern or feasibility for all sizes. At `N=9`, using only bonds in any radius-two neighborhood of the source fails rank membership, while a radius-three set containing eight of nine bonds succeeds. Exact completion has a chain-scale tail even though each term has width three.

For `N=6`, `aklt_n6_interval.py` forms a rational orthogonal projector `Π_j` onto each merged bond span and solves `(Σ_j Π_j)y=b` exactly. Then `w_j=Π_j y` satisfies `P2_j w_j=w_j` and `Σ_j w_j=b`. A six-step exact Krylov primal vector gives

`1.450337335573352 ≤ χ ≤ 1.457001657709544`,

with exact endpoints and the exact primal-dual gap identity in `aklt_n6_certified_interval.json`. The interval width is `0.4595%` of its lower endpoint. The six-site Hilbert dimension is `729`, and all certificate arithmetic is rational inside the 141-dimensional conserved sector. No global spectral-gap estimate or full excitation reconstruction enters the certificate construction. The direct dense exact-response value from an independent exploratory calculation is about `1.450550837609682`; that comparison is finite validation, not the source of the bounds.

The dual projector construction is a *finite* positive result. `aklt_compact_gram.py` removes its exponential sector basis. It represents each width-three local dual column as a small MPS defect, contracts inner products with exact `4×4` transfer matrices, and forms a block-cyclic Gram matrix with only physical-bond separations `0,1,2`: when `P2_i` is disjoint from the local operator creating column `u_j=P2_jO_j|ψ>`, `P2_i u_j=O_jP2_i|ψ>=0`, so `<u_i,u_j>=0`. The source column has overlap only with bonds touching site zero. For fixed MPS bond dimension and block width, every nonzero block takes polynomial arithmetic and the global Gram has `O(N)` dimensions; the exact rational solve and bit growth remain part of the computational cost. The actual Hilbert vector and excitation spectrum are never constructed.

The exact membership test is `Kc=g` and `h−gᵀc=0`, where `K=A†A`, `g=A†b`, and `h=||b||²`. The transfer matrix has eigenvalues `3,−1,−1,−1`, giving the integer-gauge ground norm `3^N+3(−1)^N` and normalized source norm `2/3`. After merging the two placements within each physical bond, the sum of bond norms has a separate block-diagonal metric `M`, not `K`; its minimum over the affine solution set is found from the nullspace equation `ZᵀMZ z=−ZᵀMc₀`. This exact compact computation reproduces the independent six-site dense upper `159740147/109636215`. At twelve sites, a `240×240` Gram of rank `189` and nullity `51` gives exact zero membership residual and optimal within-ansatz upper `627710130295322/439731204269175 ≈ 1.42748598280`. At twenty sites, an earlier RREF-only run of the compact code gave a `400×400` Gram of rank `317` and exact zero membership residual; its saved `aklt_compact_gram_n20.json` receipt is explicitly version-marked, and no optimized twenty-site norm was completed. The Hilbert dimensions `3^12=531441` and `3^20=3486784401` were never built. These are finite calculations; the observed `16N−3` rank for `N=7,8,9,12,20` and exact membership do not constitute an all-`N` theorem.

The local-field AKLT model is supplied analytically, not acquired from a material or device. A matched certified baseline decisively beats the six-site local-dual bound: an exact four-site patch check proves `H_open4²−(2/5)H_open4⪰0`, and the finite-size Knabe inequality gives ring gap `γ≥1/10` for `N≥6` in this projector normalization. Applying the ordinary residual estimate to the *same* six-step Krylov vector, with exact normalized residual squared `524653851310201365424617396462424916096771/1558498639600697433999182440532018486272367120`, gives upper `1.453703741150996`, tighter than the local-dual upper `1.457001657709544`. This baseline interval width is `0.2321%` of the lower bound versus `0.4595%` for the local dual. The patch proof and algebraic gap derivation are in `../../root/knabe_response_baseline.py` and its JSON receipt. Its patch acquisition and finite solve costs must be charged, and this one-size quality comparison is not a full MPS runtime study; it does establish that the proposed local dual currently lacks accuracy advantage on its strongest tested model.

## Decision

Do not promote either finite case as the requested breakthrough. The AKLT two-placement result now has finite compact tensor verification and exact bondwise norm evaluation; the remaining mathematical target is a size-uniform feasibility identity. It also needs a genuine advantage against the matched gap-plus-Krylov baseline and correction-vector/Krylov DMRG at equal information, accuracy, and total acquisition cost. A consequential application additionally needs an interacting, nonintegrable *acquired* Hamiltonian rather than an analytic parent model. The present evidence is a finite exact certificate and a failed priority gate.
