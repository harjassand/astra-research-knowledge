# Astra Capital cross-domain retrieval

## Retrieval boundary

Main was read at `ace0cfc4437fe91c20ccd24d69e0ee4bb335e871` in `/Users/harjas/Documents/Codex/2026-10-13/new-chat/work/astra-capital`; the worktree was clean. `agent/CURRENT.txt` reports generated-input ancestor `b34e22e8f8ef8bd853595952fcbd9c74c5ace306` and snapshot input hash `d234854d8eb9005c00dfdd5b054114458fa8ab04fa28a48964bc3765ed4c8ab4`. Main's recent ledger ends at N790. Dossier snapshot metadata also names its generated base; citations below pin both the fetched main SHA and the source-file SHA/range.

I inspected draft PR #83 because it contains the newer carrier-control lead. It is **open and draft**, based on main `ace0cfc4437fe91c20ccd24d69e0ee4bb335e871`, at head `3c9c5564fc7f51cdbaa0a5a5b5b54ee9382dcd8d`, and allocates N791–N811. None of its claims are in main. I assign no IDs. See [PR #83](https://github.com/harjassand/astra-research-knowledge/pull/83). The PR description itself says no new physical operation or civilization-enabling breakthrough has been acquired.

Using the stated v1 failure as a selection guardrail: a useful lead needs a concrete operation, acquired input interface, measurable retained output, equal-information comparator, full cost boundary, and an early falsifier. Potential significance and mathematical elegance do not substitute for those items.

The prior HIP route remains parked. This retrieval does not revive it or use topical overlap as a new capability claim.

## Retrieval result

The most concrete *physical experiment route* I found is the draft-only N811 carrier-gated dislocation reaction-selection proposal. Its useful mathematical operation is a committor-defect test for whether a schedule can change an eventual reaction outcome, paired with an exact pulse-order counterexample to constant-flux control in a small reduced model. It is a testable bridge from an already reported carrier-sensitive mobility effect to reaction selection, but the compatible target/competitor, state-dependent reaction law, and retained endpoint are all still unmeasured. Treat it as an experiment proposal, not as an achieved capability or novelty claim.

The strongest *decision certificate* on main is the existing N788+N790 composition: common latent weights yield an O(k)-size linear-fractional program for comparing diagonal interventions, and a likelihood-mixture confidence sequence makes the decision valid under adaptive stopping. This is a real mathematical interface between equilibrium observations, thermodynamic design, and sequential decision-making. It is already a recorded composition, has only a small synthetic control, and remains blocked by Gibbs-state acquisition, rare overlap, and absent matched performance. It is a baseline for future Genesis work, not a fresh discovery.

| Route | Exact operation | Status and selection decision |
|---|---|---|
| N811, PR #83 draft | State-dependent committor defect plus pulse-order path steering for carrier-controlled reaction selection | Best physical assay target among the retrieved routes; keep at falsifiable-experiment stage. Same-network causal map and retained product are absent. |
| N788 + N790, main | Shared-latent free-energy contrast LP plus anytime-valid histogram confidence | Strongest reusable decision mathematics; already integrated, and no real-material decision or affordable overlap has been shown. |
| N789, main | Minimax recoil margin, Gaussian ROC selectivity bound, and global-write survival bound | Park pending same-specimen controls and full-state acquisition; Te actuator and retained-response interface are missing. |
| N787, main | Finite marked genealogy and signed-density-to-sampler construction | Keep as a narrow kinetic-sampling result; no transfer to spatial/reactive dynamics or practical solver advantage is established. |

## N811: carrier-gated dislocation reaction selection (PR #83 only)

### Operation and contract

For a full material state `X=(G,q,c,T,d,w)`—dislocation graph and topology, glide coordinates, carrier/core occupations, temperature, damage, and specimen history—an admissible global illumination flux `Phi(t)` changes the coupled glide, noise, heat, pinning, and reaction process. The intended output is the probability of reaching a *predeclared retained target set* before competing sinks, after a stated operating-condition hold. The target must have compatible Burgers content and identified fault/slip state; first contact, line motion, contrast loss, or pair-count change is not the output.

For a baseline control with committor `h0`, the exact model identity is

`P^pi_x(X_tau in A) - h0(x) = E^pi_x integral_0^tau (L^{u_t} h0)(X_t) dt`.

If every control scales the **entire** generator by a positive scalar, eventual reaction probabilities are invariant: it changes only the clock. A nonzero determinant between two glide vectors permits path steering in the reduced drift model, but does not establish selection. A policy matters only if the integrated committor defect changes the target probability before competing sinks.

The draft's exact dimensionless witness uses `q=(x,y)`, `dot q=(2-Phi,1)`, `Phi in [0,1]`, a target disk centered at `(3,2)` with radius `1/5`, and a competing sink at `(2,4/3)` with radius `21/100`. Equal-dose dark-then-light reaches the target and avoids the sink; reversing the pulses hits the sink; every constant-flux ray that reaches the target hits the sink first. The coordinates and velocities are explicitly illustrative, not fitted ZnS coefficients, and the model does not simulate retained material.

### Full input, output, norms, and costs

- **Input:** A real pre-mapped network containing a Burgers/core/slip-compatible target and competitor; actual `G,q,c,T,d,w`; legal global flux/stress controls; carrier capture/release, pinning, glide drift/noise, heat, reaction rates and post-reaction state updates. The control has `0 <= Phi(t) <= Phi_max` and total fluence at most `D_max`.
- **Output:** A change in the full-state target committor and, ultimately, retained target yield/function after a declared hold, with residual junction/fault, boundary events, plastic distortion, damage, and failed specimens counted. The draft specifies a scalar reachability probability and an endpoint distribution; it supplies no norm error bound for physical estimation.
- **Norm/precision:** The path model's kinetic/geometry quantities use their physical units only after calibration. The witness is dimensionless and exact. No calibrated error bar, outward numerical certificate, or physical precision is available. Do not interpret the witness clearance or determinant as a predicted yield.
- **Acquisition/preprocessing/calibration:** Map the same network before treatment using multiple diffraction/Burgers circuits; assign line directions, Burgers vectors, slip planes, core classes, pinning, and actual compatible reactions. Calibrate the same-network `Phi(t)` to carrier state, temperature, stress, glide/noise, target and competitor hazards, and post-reaction graph/history. Keep beam/readout controls separate and use one irreversible treatment per randomized window or sister specimen.
- **Complexity:** For an acquired finite-state discretization, the draft writes the reachability Bellman equation. It gives no state-size, discretization, or algorithmic cost bound. The 2D pulse witness has a short exact geometric verification; that does not bound the real hybrid optimal-control problem. Full acquisition and experiment cost dominate and are currently unknown.
- **Comparator:** Optimized physically available dark/stress/thermal control; full constant-flux and dose-duration sweep; equal-dose dark-to-light versus light-to-dark; constant-average flux; dark-heater temperature-matched control; matched imaging/readout dose. Compare target yield and qualified retention per full input, not mobility alone.
- **Resource boundary:** Optical wall and absorbed energy, heating/cooling, applied electrical energy, mechanical work, preparation, readout and beam-induced motion, control electronics, failed/damaged material, and total input per retained target. The PR does not supply those measured costs.

### Exact pins, gates, and dependency

These are PR #83 head artifacts, not main artifacts:

- Dossier: `frontier/dossiers/N811.txt` at `3c9c5564fc7f51cdbaa0a5a5b5b54ee9382dcd8d`; status `source_derived_unreviewed`.
- Proof source: `updates/FK/synthesis/reaction_control/REPORT.md`, SHA-256 `51eb775d2da2606f16d9e822574b3fee6827d03a8ca40f09c767ae24506a8f28`. Exact indexed routes: `frontier/proof_ranges/53a524bf4d6d5afddbd1fc9a.txt` (source lines 69–108, committor identity and time-change obstruction); `frontier/proof_ranges/62c8dba93d8ae6a5ec4fd04e.txt` (121–139, pulse-order witness); `frontier/proof_ranges/8b200ddf18106e18b78895c5.txt` (140–152, falsifiers and controls); `frontier/proof_ranges/6e0464b9b8c9500d18c6676f.txt` (153–169, missing inputs and decisive experiment).
- Physical contract: `updates/FK/package/physical/RESEARCH_LEDGER.md`, SHA-256 `d879c1adb7e4a2614792b016a72b47a90550d0aa0666124f95df87a8f3fd4ce7`; exact routes in the N811 dossier cover lines 9–22 (proposed operation), 55–68 (smallest experiment and full physical accounting).
- Open gate: `G-FK-N811-CAPABILITY` (and `G-FK-N811-REVIEW`). It requires a same-platform compatible target and competitor, randomized schedule/heat/readout controls, calibrated topology/fault/slip and retained functional endpoint, and complete per-target input. The explicit stop rule is to stop at mobility if no same-network causal selection map is obtained.
- The draft technology record `technology/records/T-carrier-gated-retained-reaction-selection/v0001.json` remains at stage `simulation`; experiment evidence is absent.
- Transfer: `FK_glide_to_retained_reaction` is a **CANDIDATE CONNECTION**. N777's common-committor invariance and N783's retained-reward/accounting are antecedents, not proof that carrier control selects a retained reaction. The decisive missing item is the measured full-state map from flux to `L^Phi h_dark` or enough acquired data to calculate it.

### Fatal gap and why this remains only a lead

The source platform reports 365-nm light changing Zn/S core glide response, which is a real actuator lead; it does not show switching between two compatible reactions in the same mapped network. The reduced witness supplies no material rates, no noise survival, no calibrated target capture geometry, and no retained endpoint. A state-dependent policy can only be compared once those data and a legally reachable actuator set exist. The current experiment may stop before selection is even defined. Historical novelty and complete-cost advantage remain unknown. Therefore the next action is the mapped-network falsifier in the open gate, not a claim of a new physical capability.

## N788 + N790: adaptive thermodynamic design certificate (main baseline)

### Exact operation and contract

For a finite fixed conserved sector and `beta>0`, let `H=D+T` and let `P_i` be finite diagonal-label projectors. Acquire the actual reference Gibbs label histogram `p_i=Tr(P_i rho)` and a valid coherence/mixing budget `C >= Z_H/Z_D`. For a diagonal intervention `V(v)=sum_i v_i P_i`, set `u_i=exp(-beta v_i)`. With a confidence set `P_N` for `p`, the output interval is

`-log(max_{p in P_N} p.u)/beta <= Delta F(H,V) <= -log(min_{p in P_N, 0<=w<=p, sum w>=1/C} w.u)/beta`.

For a pair of interventions, retain their shared latent weights and optimize `(w.u_1)/(w.u_0)` via a Charnes-Cooper transformation. The result is a free-energy contrast interval; return a sign only if zero is excluded, otherwise `UNKNOWN`. N790's Beta/Dirichlet likelihood mixture gives simultaneous coverage for all sample counts and later data-chosen interventions when every label is an independent draw from the same fixed reference distribution.

- **Input/output:** Same-sector reference Gibbs labels, `beta`, candidate diagonal shifts and acquired reference/target mixing bounds; output is an energy-valued `Delta F` or paired contrast interval plus an error-controlled sign/`UNKNOWN` decision.
- **Norm/precision:** Scalar absolute free-energy interval in native energy units; statistical failure `alpha`, plus separately budgeted coherence, model, calibration and readout errors. This is not a state/operator norm certificate. Rational outward intervals can support exact finite arithmetic, but exponent/log/root certification and its precision cost are not implemented.
- **Acquisition/calibration:** Establish actual same-sector equilibrium and independent samples from one fixed reference distribution; calibrate `beta`, projectors, diagonal shifts, label readout, and `C`. Reference kinetic data alone do not provide target coherence budgets `C_j`. Changing temperature, gate, ensemble or reference changes the sampling law and needs its own protocol. A quiet trace or stationarity does not certify Gibbs weights.
- **Complexity:** The paired shared-latent ratio becomes two LPs with `k+1` variables and `O(k)` constraints; a histogram confidence box still gives `O(k)` variables/constraints. The capital makes no end-to-end polynomial bit-cost claim: exponentially large `beta|v|`, ill-conditioning, tiny margins, and outward exp/log/root certification remain charged. Full Dirichlet confidence regions are generally nonlinear. N790 makes no finite stopping guarantee.
- **Comparator:** Existing reference-ensemble reweighting/thermodynamic methods, charge sensing, and equally informed embedding/correlated-sampling/electronic-structure methods. The exact four-label source control shows a positive contrast certified by shared weights where independent interval subtraction straddles zero; this is not a materials benchmark. Confidence sequences and rare-overlap free-energy estimation have direct established prior art.
- **Cost:** Equilibrium preparation, sample independence, label readout, coherence/kinetic acquisition, calibration, target residuals, interval arithmetic, stopping, and rare-overlap shots. Under fixed-reference-only access, the explicit counterfamily requires `Omega(exp(beta B))` expected draws for a strong-shift sign decision. Other gate settings, importance ensembles, target preparations, and full Hamiltonian access are outside that lower bound and must be separately charged.

### Pins, gates, and transfer limits

- N788 dossier `frontier/dossiers/N788.txt`; N790 dossier `frontier/dossiers/N790.txt`; both main at `ace0cfc4437fe91c20ccd24d69e0ee4bb335e871` and `source_derived_unreviewed`.
- N788 primary argument: `updates/FC/package/nongaussian_design/recovered/cray_nongaussian/RESEARCH_NOTE.md`, SHA-256 `e3eb4c9c25dea5bcf31fff066ebcfe79f1daecc20e8114066f3d211684bbf63d`; exact `frontier/proof_ranges/1c9ffbd31e86ed037947ba54.txt` (source lines 137–204, conditional reweighting theorem).
- N788 shared-latent proof: `updates/FC/synthesis/design/SHARED_LATENT_CONTRAST.md`, SHA-256 `98dbcc312cb42dd5ebb138eeb6dc57209bf9f70c20835cfe408325fe4e23a8b8`, exact `frontier/proof_ranges/93af342d8ad973bc62e9e9c5.txt` (source lines 73–115, strict improvement control). Contract/LP route: same file lines 7–72; exact routes `frontier/proof_ranges/bf78b3fe1fbcd73c89f74a28.txt` and `frontier/proof_ranges/bcdd1b64769527e08f55cf59.txt`.
- N790 anytime certificate: `updates/FC/synthesis/root/SEQUENTIAL_DECISIONS_AND_RARE_OVERLAP.md`, SHA-256 `0de047728c0c487ab881ddbfff78c856e92c4fec2b26bfa1b4cda6ea27524c4d`, exact `frontier/proof_ranges/aa360c821fe2dac251b93612.txt` (source lines 11–91). Rare-overlap expected-sample lower bound: exact `frontier/proof_ranges/b3a0341e7579ccb5e57baed1.txt` (128–160).
- Open gates: `G-FC-N788-CAPABILITY`, `G-FC-N790-CAPABILITY`; current technology record `technology/records/T-coupled-equilibrium-design-certificates/v0001.json` has stage `simulation`, experiment gate open.
- Routes: `FC_histogram_and_coherence_to_design` and `FC_confidence_sequence_to_adaptive_decision` are recorded logical dependencies. `FC_small_label_model_to_cheap_amplification` is explicitly a **REFUTED TRANSFER**; the adaptive confidence result does not remove rare-overlap acquisition cost.

### Selection judgment

This is a strong mathematical decision primitive where a real fixed-reference ensemble exists and intervention margins are not hidden in exponentially rare labels. Its actionable transfer requires an actual consequential target for which the Gibbs histogram and coherence bounds are cheaper or more informative than the strongest equally informed methods. Current capital has no such acquisition or result, so it should remain a comparator and proof route rather than a Genesis capability claim.

## N789: recoil-addressing route remains parked

Main N789 combines three exact conditional operations: for acquired mass-weighted velocity subspace and contrast rows, optimal worst-class first-order recoil margin is `sqrt(2E) dist(0, conv{g_i})`; a common-covariance *full response state* has the sharp ROC boundary `p_unwanted >= Phi(Phi^-1(p_target)-d)`; and a symmetric irreversible model has global all-target success at most `product_{k=1}^n kR/(kR+m)`, even with adaptive stopping. This joins convex control geometry, hypothesis-testing geometry, and a supermartingale reliability bound into a decision frontier for a possible selective-write mechanism.

The full contract is deliberately narrow. Inputs are the acquired legal mass-weighted velocity subspace, contrast rows and energy budget; the entire mapped equal-covariance response states and common retained kernel; and, for the write bound, full-state conditional rates satisfying `r_t <= R r_u`. Outputs are a first-order margin in energy units, a selectivity/false-positive probability frontier parameterized by Mahalanobis distance, and an all-target terminal success probability. The norms are respectively mass-weighted `l2` under `||u||^2/2 <= E`, Mahalanobis norm, and event probability. The geometry theorem is exact inside the supplied control ball; the Gaussian theorem is exact only under its full-state common-covariance/kernel premises; the product bound is exact for its symmetric irreversible model. The local Te response also has finite-angle/linearization remainders, and the dossier's finite checks do not certify the physical model or numerical precision.

Acquisition must include controllable modes and phase, actual joint state/covariance and retention map, and full-state target/unwanted rates. The capital gives no end-to-end cost or solver-complexity bound: finite convex geometry and an `O(n)` product do not cover fitting the state or the operation. Comparator evidence includes direct 60 keV Si/graphene bond inversion and a magnetic-bit electron-fabrication report, but no same-specimen Te comparison. Transfer routes `FC_legal_velocity_to_recoil_margin`, `FC_joint_gaussian_to_selectivity_frontier`, and `FC_full_state_rates_to_global_write` are logical dependencies inside their written models; `FC_conditional_recoil_to_retained_operation` remains a candidate physical bridge.

As a selection filter, the Te phase-dependent mode, covariance, retained-event kernel, and amplitude-energy consistency must be acquired before using this frontier. The strongest source amplitude is a 3 K polycrystal measurement; its literal harmonic coherent energy exceeds its quoted absorbed-energy estimate by about 2.11. A restrictive 300 K scalar model rules out simultaneous `.99/.01` single-opportunity performance under its stated energy ceiling; this is not a Te no-go. No matched Te advantage is shown.

Pins: N789 dossier `frontier/dossiers/N789.txt`, gate `G-FC-N789-CAPABILITY` open; report SHA-256 `4ab1c67fc2f638df31c2db7f8df5a1850dc0317f330a5970c888edf767435f33`. Exact ranges: `frontier/proof_ranges/b4f7865897636ed686bf2a0c.txt` (lines 89–130, convex geometry); `frontier/proof_ranges/0e48e9c2218ba298f598a90e.txt` (189–245, Gaussian ROC); `frontier/proof_ranges/12a3142e21617608f9281e29.txt` (246–308, global write); `frontier/proof_ranges/fc6ae686fabb66d6fc2b798c.txt` (309–347, comparator and resource boundary). `FC_conditional_recoil_to_retained_operation` remains a candidate connection. Do not select from mathematical completeness alone.

## N787: narrow exact-sampler result, no consequential transfer yet

N787's unfamiliar operation shares finite collision marks across a Gaussian-mixture genealogy so nonseparating ancestors integrate out; it has at most `k-1` effective splits, `2k-1` nodes, and `k` initial draws independently of collision time. A signed relative-density query, positive envelope, and credited Bernoulli factory yield an ideal exact sample for a narrow homogeneous isotropic Maxwell/Gaussian-mixture class with `0<a<b<3a/2`; broader n-mark output has a stated total-variation error. This is continuous ideal arithmetic with unbounded worst-case work, not a finite-bit certified or spatial/reactive solver.

Its input/output contract requires the supplied latent initial sampler on known `[a,b]`, the homogeneous isotropic Maxwell equation and exact signed-density/envelope queries; output is one ideal velocity sample or an n-mark approximation with TV error at most `sqrt(15/2)*Var(V0)*(1-exp(-t/3))/(4*a^2*n)`. The narrow sampler's cost is at most `19 C^2 I` expected signed queries and `C` proposals (`I=int(q/ell)`), uniformly in `t`, not a worst-case cap. Initial-law acquisition, real/random access, output bits, precision, and finite-bit certification remain charged or absent. The natural comparators are moment, spectral and recursive kinetic solvers; no matched solver comparison or spatial/reactive extension exists.

The potentially general converter needs a bounded pointwise density ratio, known positive envelope, integrated cost, and an expected-to-hard-cap conversion. `FC_operator_action_to_full_law` is only a candidate; N687 operator actions do not supply these. N787's open `G-FC-N787-CAPABILITY` requires external proof review, quantized/observation-law output with bit cost, and a matched solver comparison. No physical or practical capability is established.

Pins: N787 dossier `frontier/dossiers/N787.txt`; primary argument `updates/FC/package/collision_dual/recovered/astra_collision_dual/RESEARCH_NOTE.md`, SHA-256 `650e9c8deea9c693ac518403e6f354e4f7eaade9fd731c82a85d8fb47c6ca385`; exact genealogy range `frontier/proof_ranges/b306fd1c19202a4dc9e46a4f.txt` (lines 68–105) and ideal-sampling range `frontier/proof_ranges/9d70cae8e1b62a6b0d1a869c.txt` (124–254). The acquisition and comparison requirements are in open gate `G-FC-N787-CAPABILITY`.

## Decision for the Frontier team

Use N811 only as a draft-source lead for one decisive same-network reaction-selection/retention experiment, if the platform is actually reachable. Stop at mobility characterization if the compatible target/competitor or committor-defect map cannot be acquired. Use N788+N790 as a reusable decision-theory baseline, preserving the exponential rare-overlap limit. Keep N789 parked until full-state acquisition and a realistic energy/event-rate operating point exist. None passes the capability gate; no source supports a novel, civilization-enabling capability claim.
