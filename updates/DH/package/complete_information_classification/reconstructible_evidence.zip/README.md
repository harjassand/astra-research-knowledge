# Reconstruction package

The authoritative exposition is outputs/research_report.pdf (editable .tex alongside it).
Read outputs/ASTRA_HANDOFF.json for claim dependencies and exact unresolved gates.
These are complete internally reconstructed proposed proofs, not formal or external certification.
Generic endpoint decidability has prior rational-positivity machinery; sharp bounds and fixed-generator localization have unresolved priority.
All hardness relying on Dots is explicitly conditional.

## Contents and provenance

- work/manuscript/channel_order_undecidability.pdf: unchanged supplied source, SHA256 in manifest and handoff.
- work/manuscript/channel_order_undecidability.txt: lossy extraction; PDF controls fraction bars and conjugations.
- work/manuscript/astra_operational_extensions.tex: pinned internal antecedent, not external validation.
- work/investigations/: five complementary mathematical investigations, selected proofs, adversarial reviews and finite diagnostics.
- work/literature/: focused original-source receipts. They are research notes, not an exhaustive priority survey.
- SHA256SUMS.json: integrity hashes of every included file except the manifest itself.

The report supersedes developmental status wording in earlier investigation notes.
No Git repositories or bulk third-party source caches are included. Repository revisions are pinned in the handoff.
All source PDFs and quoted mathematics remain attributed to their original sources.

## Replay finite diagnostics

From the extracted package root, Python with numpy, sympy and mpmath is sufficient.
Observed runtimes: Python3.14.3/numpy2.5.3/sympy1.14.0/mpmath1.3.0;
root numerical checks also replayed on bundled Python3.12.14/numpy2.3.5.
Small last-digit floating-point differences across BLAS/platforms are possible.

    python3 work/investigations/root_general_f_check.py
    python3 work/investigations/rld_cutoff_diagnostic.py
    python3 work/investigations/sol03_boundary_check.py
    python3 work/investigations/sol05_verify.py
    python3 work/investigations/sol01_checks.py
    python3 work/investigations/sol01_rank_checks.py
    python3 work/investigations/sol04_packing_falsification.py

Some scripts write a sibling .json result; others print JSON. Captured original results are included.
These executions verify finite algebra/identities only. The proofs must be reconstructed from the mathematics.

## Compile the standalone proof report

The Codex built-in compiler returned success. The exported PDF was also compiled with TeXLive2024 pdflatex;
the final log had no undefined references or overfull boxes, and all pages were rendered for layout review.
With a TeX installation, from the extracted package root:

    pdflatex -interaction=nonstopmode -halt-on-error outputs/research_report.tex
    pdflatex -interaction=nonstopmode -halt-on-error outputs/research_report.tex

work/build_report.py reconstructs the report from the root derivation and campaign exposition.
SHA256 integrity, successful compilation, finite replays and AI-review agreement do not establish correctness or originality.
