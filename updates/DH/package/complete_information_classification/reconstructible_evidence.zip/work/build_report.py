from pathlib import Path

base = Path(__file__).resolve().parent.parent
root = (base / 'work/investigations/root_universality.tex').read_text()
core = root.split(r'For positive matrices define', 1)[1]
core = 'For positive matrices define' + core.split(r'\paragraph{Computational consequence and dependence.}', 1)[0]
core = core.replace(r'\begin{theorem}[Proposed fixed-generator universality]', r'\begin{theorem}[Fixed-generator universality]')
core = core.replace('Pure quadratic generators are excluded from this theorem, rather than asserted to separate the orders.', 'The pure quadratic case is treated separately in Theorem~\\ref{thm:rld}.')
core = core.replace(r'For positive matrices define', r'\section{Definitions and fixed-generator universality}' + '\nFor positive matrices define', 1)
core = core.replace(r'\begin{lemma}[Exact saturated denominator Hessian]', r'\subsection{The coherent-reference localization mechanism}' + '\n' + r'\begin{lemma}[Exact saturated denominator Hessian]')
core = core.replace(r'\begin{theorem}[Petz R\'enyi, Umegaki and Chernoff comparison]', r'\subsection{Entropic and testing instances}' + '\n' + r'\begin{theorem}[Petz R\'enyi, Umegaki and Chernoff comparison]')
# The general representing-measure proof is the primary argument. The independent
# fixed-alpha proof and its endpoint/tail details remain in the evidence archive.
start = core.index(r" Alternatively the R\'enyi reverse implication")
end = core.index('\n\nSLD dominance compares', start)
core = core[:start] + core[end:]

preamble = r'''\documentclass[11pt]{article}
\usepackage[a4paper,margin=25mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,microtype}
\usepackage{amsmath,amssymb,amsthm,mathtools,booktabs,array,longtable}
\usepackage[colorlinks=true,linkcolor=blue,urlcolor=blue,citecolor=blue]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{lemma}{Lemma}
\newtheorem{corollary}{Corollary}
\newcommand{\Tr}{\operatorname{Tr}}
\newcommand{\id}{\operatorname{id}}
\newcommand{\SLD}{\mathrm{SLD}}
\newcommand{\RE}{\mathrm{RE}}
\newcommand{\RLD}{\mathrm{RLD}}
\newcommand{\Herm}{\operatorname{Herm}}
\newcommand{\supp}{\operatorname{supp}}
\setlength{\emergencystretch}{2em}
\title{A computability boundary in complete quantum information comparison\\
\large Coherent-reference localization versus finite inverse-action compression}
\author{Astra independent research campaign\\\small Internally reconstructed proofs; external review and priority unresolved}
\date{11 October 2026}
\begin{document}
\maketitle
\begin{abstract}
The strongest result developed in this campaign is a structural classification,
not a new capacity or Hamiltonian undecidability claim. For finite-dimensional
channels, complete dominance for any single finite-at-zero operator-convex
standard Petz divergence with a nonzero interior resolvent component is
equivalent to complete SLD dominance. A coherent auxiliary reference localizes
the generator's representing measure at one chosen support point. At the pure
quadratic endpoint, a different elementary operation compresses every violation:
reference dimension at most $1+b^2$ suffices when the target channel has effective
output dimension $b$, improving to $1+v$ for a target POVM with $v$ outcomes.
Consequently quadratic comparison is exactly decidable on rational POVMs.
These two proofs do not require Dots' nonlocal-game reduction. If that reduction
is valid, they give a sharp decidable/\(\mathrm{coRE}\)-complete boundary, including
Petz R\'enyi parameter $2$ versus every fixed parameter in $(0,2)$.
The manuscript received targeted adversarial reconstruction, and one complex
coordinate convention needs correction. Its hardness is retained as a named
dependency, not promoted to an independently certified theorem. No result here
establishes historic 9--10/10 significance.
\end{abstract}

\paragraph{Read first.}
The complete mathematical arguments are in Sections 1--3. Section 4 records
the source reduction's exact status and correction; Sections 5--7 give the
consequences, falsification results, and research decision. Every claim is
either proved below, explicitly inherited, or marked conditional/unresolved.
The proofs were developed and cross-checked by AI agents in this campaign.
Agreement, compilation, and finite numerical checks are not external or formal
certification. The attached evidence archive preserves the independent
investigations, diagnostics, literature receipts, and unchanged source PDF.

\paragraph{Computational interface.}
An input measurement channel is a finite list of rational complex Hermitian
effects summing to the identity. ``Strictly positive'' means each effect is
positive definite. Physical dimension and outcome count may grow with the
encoded machine. References are arbitrary finite-dimensional untouched quantum
systems, and their states/matrices are universally quantified, not supplied as
bounded auxiliary input. State pairs may have unequal reference marginals.
Exact decision and fixed-additive numerical approximation are distinct tasks.
No polynomial-time construction is asserted when a succinct nonlocal game is
expanded to its explicit rational table.
'''

representation = r'''
\subsection{Why this covers the whole finite-at-zero operator-convex class}
The standard representation theorem \cite[Theorem 7.1]{hiai} writes a continuous
operator-convex function on $[0,\infty)$ as
\[
 f(x)=f(0)+a_0x+c x^2+
 \int_{(0,\infty)}\left(\frac{x}{1+s}-\frac{x}{x+s}\right)d\mu(s),
 \qquad \int\frac{d\mu(s)}{(1+s)^2}<\infty.
\]
The elementary identity
\[
 \frac{x}{1+s}-\frac{x}{x+s}
 =\frac{x-1}{(1+s)^2}
 +\frac{s}{(1+s)^2}\frac{(x-1)^2}{x+s}
\]
puts it in Theorem~\ref{thm:main}'s form, with
$d\nu(s)=s(1+s)^{-2}d\mu(s)$. Both required integrability bounds follow
immediately. Conversely, that form has finite value at zero and is operator
convex. Thus, modulo affine terms, exactly three cases occur: zero; a positive
pure quadratic; or nonzero interior resolvent mass (with or without a quadratic
part). The proof does not require the measure to have a density or infinitely
many support points. A single resolvent atom already belongs to the last case.
This is a classification for a fixed chosen generator; it is not an algorithm
for recognizing a generator from an arbitrary function oracle.
'''

endpoint = r'''
\section{The quadratic endpoint admits finite compression}
Write
\[
 \mathcal G_A(K)=\Tr KA^{-1}K,
 \qquad D_2(A\Vert B)=\log\Tr A^2B^{-1}.
\]
All inverses are on the effective output support. This is standard Petz
R\'enyi order two, not the sandwiched divergence or an unspecified quantum
$\chi^2$. The associated quadratic generator is $(x-1)^2$.

\begin{theorem}[Explicit finite reference cutoff]\label{thm:rld}
Let $P,Q$ be finite-dimensional channels with common input, and let $b$ be the
effective output dimension of $Q$. If complete Petz $D_2$ dominance of $P$ over
$Q$ fails on faithful pairs, it fails with a reference of dimension at most
$1+b^2$. For POVMs $E,F$, if the target $F$ has $v$ nonzero outcomes, the bound
improves to $1+v$. Hence complete $D_2$ dominance of rational complex strictly
positive POVMs is decidable by a total exact algorithm.
\end{theorem}

\begin{proof}
First, for a faithful state $\rho$ and traceless Hermitian $H$,
\[
 \Tr[\Phi_R(\rho+tH)]^2[\Phi_R(\rho)]^{-1}
 =1+t^2\mathcal G_{\Phi_R(\rho)}(\Phi_R(H)). \tag{2}
\]
The linear term is $2t\Tr H=0$ and there is no remainder. Conversely every
faithful pair is of this form with $\rho=\sigma$, $H=\alpha-\sigma$, $t=1$.
Since logarithm is increasing, complete $D_2$ order is exactly complete
comparison of these RLD quadratic forms.

Suppose the quadratic comparison fails at a faithful input $R$ and Hermitian
traceless tangent $H$ on $\mathbb C^a\otimes\mathbb C^n$. Put
\[
 W=\Tr_a R>0,\quad
 \widetilde R=(I\otimes W^{-1/2})R(I\otimes W^{-1/2}),\quad
 h=(I\otimes W^{-1/2})H(I\otimes W^{-1/2}).
\]
Then $\widetilde R>0$, $\Tr_a\widetilde R=I_n$, and $h=h^*$.
For $\Phi=P,Q$ put $A_\Phi=\Phi_R(\widetilde R)$ and
$K_\Phi=\Phi_R(h)$. Reference congruence commutes with the channels.
Put $C=I\otimes W^{1/2}$. The exact cancellation identity
\[
 \Tr (CK_\Phi C)(CA_\Phi C)^{-1}(CK_\Phi C)
 =\Tr W\Tr_{\rm out}(K_\Phi A_\Phi^{-1}K_\Phi)
\]
shows that the original violation is $\Tr W\mathcal D<0$, where
\[
 \mathcal D=\Tr_{\rm out(P)}K_PA_P^{-1}K_P
       -\Tr_{\rm out(Q)}K_QA_Q^{-1}K_Q.
\]
Consequently some unit reference vector $\xi$ satisfies
$\langle\xi,\mathcal D\xi\rangle<0$.

Fix an orthonormal basis $(e_c)_{c=1}^b$ of the target effective output and set
\[
 z_c=A_Q^{-1}K_Q(e_c\otimes\xi).
\]
Let $S$ span $\xi$ and every reference component of these $b$ vectors. Each has
$b$ reference components, so $d=\dim S\le1+b^2$. Choose an isometry
$V:\mathbb C^d\longrightarrow\mathbb C^n$ onto $S$, and compress the entire
physical baseline and tangent:
\[
 \widetilde R'=(I_a\otimes V^*)\widetilde R(I_a\otimes V),\qquad
 h'=(I_a\otimes V^*)h(I_a\otimes V).
\]
This preserves faithfulness, Hermiticity, and $\Tr_a\widetilde R'=I_d$.
For either output, $A_\Phi'$ and $K_\Phi'$ are the corresponding common
reference compressions. Write $\xi'=V^*\xi$.

Every $z_c$ lies in $\mathbb C^b\otimes S$. Therefore
\[
 A_Q'(I_b\otimes V^*)z_c
 =(I_b\otimes V^*)K_Q(e_c\otimes\xi)
 =K_Q'(e_c\otimes\xi').
\]
Thus the compressed target inverse problem has exactly the compressed solution,
and each target scalar quadratic term is preserved. For a source basis vector,
use
\[
 \langle u,A^{-1}u\rangle
 =\sup_z\{2\operatorname{Re}\langle u,z\rangle-\langle z,Az\rangle\}.
 \tag{3}
\]
Compression restricts this supremum to the source output tensored with $S$,
so each source term can only decrease. Summing the partial-trace basis terms
gives $\langle\xi',\mathcal D'\xi'\rangle<0$.

For POVMs the output matrices are block diagonal. A target inverse solution for
outcome $j$ occupies only its own classical block and has the one reference
component $z_j=(r_j^F)^{-1}k_j^F\xi$. Hence
$S=\operatorname{span}\{\xi,z_1,\ldots,z_v\}$ suffices, and $d\le1+v$.

To restore a physical scalar witness, choose sufficiently small $\eta>0$ and
the faithful reference state
\[
 W_\eta=(1-\eta)|\xi'\rangle\langle\xi'|+\eta I_d/d.
\]
Then $\Tr W_\eta\mathcal D'<0$. Undo the congruence:
\[
 R'=(I_a\otimes W_\eta^{1/2})\widetilde R'(I_a\otimes W_\eta^{1/2}),\qquad
 H_0'=(I_a\otimes W_\eta^{1/2})h'(I_a\otimes W_\eta^{1/2}).
\]
The matrix $R'$ is faithful and has trace one. Set
$H'=H_0'-(\Tr H_0')R'$. This is traceless and preserves the difference, since
\[
 \mathcal G_A(K-cA)=\mathcal G_A(K)-2c\Tr K+c^2\Tr A
\]
and both channels preserve trace. For small nonzero $t$, $R'+tH'$ is also a
faithful state; (2) gives the required finite-reference state-pair violation.

Finally fix a reference dimension $d\le1+v$. Existence of a violation is a
first-order real-algebraic sentence in the real and imaginary coordinates of
$R'>0$, $H'=H'^*$, $\Tr R'=1$, $\Tr H'=0$, and output inverse variables.
Introduce $T_iM_i(R')=I_d$ for each output block. Strict positivity of the
baseline and nonzero effects ensure the inverses exist. Negativity of the
source-minus-target quadratic form is a polynomial inequality. Rational
complex effects give rational real coefficients. Real quantifier elimination
decides the sentence. Testing the finitely many dimensions $1,\ldots,1+v$
therefore decides complete order. No efficiency claim is made.
\end{proof}

The theorem is independent of the nonlocal-game reduction. It needs no
condition-number promise, no free Positivstellensatz, and no substitution of
arbitrary operator tuples for physical reference states. The mathematical bound
also holds for nonzero, possibly singular POVM effects because a faithful
physical-reference input makes each nonzero measurement block invertible.
The effective-support convention handles general channels.

\begin{corollary}[Explicit unconditional endpoint separation for general channels]
Complete Petz $D_2$ order is strictly weaker than complete SLD order on finite
channels, even on rational channel data. This separation does not assume Dots'
hardness theorem.
\end{corollary}
\begin{proof}
For a POVM with invertible effects, define the efficient instrument
$\mathcal I_E(\rho)=\bigoplus_i\sqrt{E_i}\rho\sqrt{E_i}$.
For any finite reference put $C_i=\sqrt{E_i}\otimes I_R$.
Since $\sum_i C_i^2=I$, cyclicity gives, for faithful $\alpha,\beta$,
\[
 \sum_i\Tr(C_i\alpha C_i)^2(C_i\beta C_i)^{-1}
 =\sum_i\Tr C_i^2\alpha\beta^{-1}\alpha
 =\Tr\alpha^2\beta^{-1}.
\]
Thus $\mathcal I_E$ and the identity channel are completely $D_2$-equivalent.
Take the rational channel
\[
 \mathcal I_E(\rho)=\frac15
 \begin{pmatrix}2&0\\0&1\end{pmatrix}\rho
 \begin{pmatrix}2&0\\0&1\end{pmatrix}
 \ \oplus\ \frac15
 \begin{pmatrix}1&0\\0&2\end{pmatrix}\rho
 \begin{pmatrix}1&0\\0&2\end{pmatrix}.
\]
It is the instrument for $E_\pm=(I\pm\frac35 Z)/2$ and has rational
superoperator and Choi entries. At $\rho=I/2$, $H=X/2$ the identity channel's
SLD information is 1. Each instrument block contributes $8/25$, hence the
total is $16/25<1$. Therefore $\mathcal I_E$ does not SLD-dominate the identity.
The SLD-to-quadratic implication was already proved, so this is strictness.
\end{proof}
This example was developed in the operational investigation and independently
checked in the endpoint investigation. It also falsifies a proposed route
from instrument preservation of RLD information to relative-entropy
preservation. The analogous strict separation with \emph{both channels POVMs}
is still obtained here only conditionally from Dots' hardness theorem.
'''

classification = r'''
\section{The resulting classification and its exact dependency}
\begin{corollary}[Finite-at-zero classification]\label{cor:classification}
Fix a continuous operator-convex generator on $[0,\infty)$, and compare its
standard modular Petz divergence after two channels, on every faithful state
pair and every finite untouched reference. Modulo affine terms:
\begin{enumerate}
\item If the generator is zero, comparison is trivial.
\item If it is a positive pure quadratic, comparison has the finite cutoff of
Theorem~\ref{thm:rld}; it is decidable for rational strictly positive POVMs.
\item If it has nonzero interior resolvent mass, comparison is exactly complete
SLD order by Theorem~\ref{thm:main}.
\end{enumerate}
Assuming Dots' claimed complete-SLD hardness reduction is correct, the third
case is $\mathrm{coRE}$-complete on the identical rational strictly positive
POVM input class. Cases 1--3 exhaust the stated generator class.
\end{corollary}

\begin{proof}
The representation and its affine normalization were proved above. Affine
divergences give the same constants at both outputs. A positive quadratic
multiple induces precisely $D_2$ order, and all remaining functions have
nonzero interior measure. The identity map on the two input POVM lists transfers
the manuscript's SLD predicate to each fixed generator in case 3. Membership
and hardness are inherited from that equivalent predicate; no numerical
evaluation or effective reconstruction of the fixed representing measure is
needed. This last conclusion assumes the named hardness theorem, whereas the
classification of preorders does not.
\end{proof}

In particular, on rational strictly positive POVMs,
\[
 \boxed{0<\alpha<2:\ \mathrm{coRE}\text{-complete, conditionally};
 \qquad \alpha=2:\ \text{decidable, independently}.}
\]
This refers to \emph{each fixed standard Petz R\'enyi parameter}. It is not a
promise problem in which the algorithm is supplied an arbitrary real parameter.
The Umegaki and Chernoff instances induce the same complete preorder.

An arbitrarily small fixed resolvent component changes the decision boundary.
For any fixed rational $\varepsilon>0$, let
\[
 f_\varepsilon(x)=(x-1)^2+\varepsilon\frac{(x-1)^2}{x+1}.
\]
Its complete order is SLD order, whereas $f_0$ has the finite cutoff above.
The rational instrument example explicitly separates these two orders for
every $\varepsilon>0$, without invoking the hardness reduction.
This is a qualitative, universally quantified order statement. It does not
give a uniform numerical separation as $\varepsilon\downarrow0$ and does not
establish fixed-error hardness for a new bounded defect.

\paragraph{Finite certificates.}
For a rational POVM pair, failure of SLD order at a fixed reference dimension
is real algebraic and decidable. Strict violations have rational approximants,
so unrestricted failure is recursively enumerable. More generally, in an
effective hierarchy of decidable fixed levels, a total decision procedure for
universal validity is equivalent to a computable sufficient level cutoff:
given a decision procedure, output 1 on valid instances and otherwise search
decidable levels until finding the first failure; conversely, test all levels
up to the cutoff. Thus, conditional on the hardness reduction, case 3 admits
no computable universal cutoff or sound recursively enumerable certificate
system complete for its positive instances. If both validity and failure were
recursively enumerable the predicate would be decidable. This is an exact
computability obstruction, not an efficiency lower bound.

\paragraph{Why the two operations differ.}
For the quadratic form, normalization by the reference marginal makes the
comparison operator-valued. A negative direction can be retained by storing
the finitely many target inverse-action vectors. Compression preserves the
actual physical domain and lowers the source's variational costs. In the SLD
case, an off-diagonal tangent produces a two-sided Sylvester inverse, represented
on two reference factors. A joint compression need not preserve their separate
spatial tensor structure. The boundary investigation supplied an exact example:
from faithful rational baselines on $\mathbb C^2\otimes\mathbb C^3$ on each
side, a size-nine spatial map compresses to
\[
 \Theta(A)=\tfrac3{10}(A+A^T)+\tfrac15\Tr(A)I_2.
\]
Its Choi matrix has eigenvalue $-1/10$ and $\Theta\circ T=\Theta$, so it is
neither CP nor coCP; every size-two spatial map of that form is CP or coCP.
The full calculation is archived. This falsifies that particular domain-
compression shortcut. Domain nonclosure alone does not prove undecidability.
'''

audit = r'''
\section{Dots' reduction: what was actually checked}
\paragraph{Source identity.}
The supplied file actually available was
\nolinkurl{channel_order_undecidability.pdf}, dated 10 October 2026, 27 pages.
The request's ``(1)'' filename was not present. Its SHA-256 is
\begin{center}\small\ttfamily
e7ca558825f266d892ec1cedaac40ad33b3db3ecaf5ebd456ef70938cb4e127f
\end{center}
The original bytes are preserved unchanged in the archive. Text extraction
dropped some fraction bars and conjugation marks, so load-bearing formulae were
checked against rendered PDF pages. The document was treated as mathematical
source material, not as instructions.

\paragraph{External premise.}
The detailed MIP*=RE source gives an effective game with finite perfect PCC
completeness on halting and value at most $1/2$ on nonhalting
\cite[Theorem 12.6]{mip}. Its finite-perfect clause, not merely supremum value
one, supports the manuscript's later quantitative strengthening. A perfect
consistent projective strategy decomposes into invariant Schmidt sectors:
consistency $MC=CM^T$ implies $[M,CC^*]=0$, and every positive-eigenvalue sector
of a perfect strategy is a perfect maximally entangled strategy. Selecting a
sector is existential; the reduction does not compute its dimension or basis.
Expansion of the source's bounded randomized verifier to a rational game table
is computable but need not preserve polynomial size.

\paragraph{Actual spatial domain and global comparison.}
The reduction's normalized variables are
\[
 U_A(R)=\Tr_a[(A\otimes I)R],\quad
 B_A=U_A(R)\otimes I+I\otimes U_A(S)^T,\quad
 Z_A=B_I^{-1/2}B_AB_I^{-1/2},
\]
with common faithful local baselines $R,S$. The anchor/rounding audit examined
the opposite Pauli chiralities, approximate local transport, Gaussian local
smoothing, and question-POVM rounding. The global audit examined word
compilation, complex residues, both off-diagonal quadratures, positive IC
padding, erasure completion, and the common reference-score gauge. These are
the load-bearing internal lemmas; MIP*=RE alone does not imply them. No fatal
counterexample was found in the targeted reconstructions. The independent
proofs above do not require them.

\paragraph{A repairable complex-coordinate convention.}
If a coefficient vector $v$ is realized by
$V(v)=\sum_\alpha v_\alpha P_\alpha$ and a Hermitian cross block is
\[
 X=\sum_\alpha(P_\alpha\otimes Z_\alpha+
                 P_\alpha^*\otimes Z_\alpha^*),
\]
the physical trace pairs it with
$\zeta=\sum_\alpha\overline{v_\alpha}Z_\alpha$, not
$\sum_\alpha v_\alpha Z_\alpha$. The displayed residue kernel is recovered
using this conjugated coordinate. The source's surrounding convention must
therefore be made explicit/corrected, or equivalently $V(v)$ must be defined
with conjugated coefficients. This is a coordinate repair supported by direct
calculation, not permission to replace complex residues by real ones. The
coefficient in PDF Equation (54) is $8/\lambda$; an extracted ``$8\lambda$''
was an extraction error, not a manuscript error. No source bytes were edited.

\paragraph{Fixed-error strengthening.}
The quantitative audit reconstructed the perfect maximally entangled sector,
the cancellation of unknown strategy dimension in the normalized Fisher gap,
the reference-filter entropy margin, its Taylor remainder, and tensor-power
amplification. It found no obstruction in Sections 11--14 conditional on the
earlier bridge. The computed entropy margin is positive \emph{per game};
tensor amplification converts it to the claimed fixed $1/4$ barrier for the
manuscript's bounded defect. This does not prove fixed-error hardness for every
new divergence or for ordinary capacities.

\paragraph{Overall source verdict.}
The imported MIP premise checks; the identified coordinate issue has an explicit
repair; the targeted analytic and quantitative audits found no fatal gap.
The complete universal game-to-POVM theorem nevertheless remains an internally
reconstructed candidate requiring independent specialist or formal validation.
All complexity statements in this report name it as a dependency. There is no
newly discovered fatal gap used to discard the manuscript, and no claim of
unconditional downstream hardness based only on model agreement.
'''

consequences = r'''
\section{Consequences and independent investigations}
\paragraph{What the main result adds.}
The central mathematical mechanism is that an unrestricted finite quantum
reference can localize the representing measure of a \emph{single fixed}
modular Petz divergence. This identifies many apparently different complete
information preorders, while the explicit quadratic cutoff proves that the
endpoint has a different finite-certification mechanism. It answers a structural
comparison question rather than adding a list of unrelated hard tasks.

The SLD quantity is the Fisher information of a local state family, and the
Petz/Chernoff divergences are distinguishability measures. Equality of their
complete channel preorders means that their universal ranking of two devices
coincides under the stated reference interface. It does not say that they take
the same numerical values, that a reference can be prepared cheaply, or that
one channel physically simulates the other. The cutoff gives a finite exact
algorithm only at the quadratic endpoint and gives no practical complexity
guarantee.

\paragraph{Five Sol investigations and the selection decision.}
\begin{enumerate}
\item \textbf{Stronger undecidability.} A complete conditional construction makes
both POVMs informationally complete, equal-trace, and arbitrarily close to a
common uniform measurement, with scalar deviations of rank at most four. It
gives fixed-additive hardness of a pre-existing relative conditional information
coefficient and an instance-dependent robust informative-margin promise.
The coefficient is finite per input but unbounded over the input class.
This useful robustness result still imports Dots' Sections 3--9, and is not
hardness of a bounded $[0,1]$ SDPI coefficient. Its full construction is archived.
\item \textbf{Operational consequences.} A complete zero-rate stabilizer-code
argument replaces any finite half-erasure helper by finitely many uses of the
same qubit half-erasure channel $\mathcal S_2$. Together with established
Smith--Yard coding \cite{smithyard} it gives the internally proved characterization
$N^c\succeq^c_{\RE}N$ if and only if
$P(N\otimes\mathcal S_2)=0$ if and only if $Q(N\otimes\mathcal S_2)=0$.
The fixed-helper refinement's priority is unresolved; variable-helper
activation is prior work. For genuine channels the receiver and environment
must be complementary. The
manuscript supplies two chosen POVMs, not such a complementary pair. A
complement-preserving compiler is the indispensable missing step for ordinary
private/quantum-capacity hardness. No such compiler was developed. Designated-
output wiretap statements are a different interface and are kept separate.
\item \textbf{Computability boundary.} Exact spatial-domain compression failure,
its decomposable matrix-convex hull, and finite independent-source cases were
developed. These investigations helped expose why an unrestricted free-
positivity shortcut changes the problem. The main advance selected from this
direction is the elementary quadratic cutoff proved above.
\item \textbf{Foundational transfer.} A standalone two-contraction packing and a
conditional fixed six-dimensional Jordan carrier yield a fixed operator system
with a hard growing matrix cone. Broad fixed-generator positivity and norm
noncomputability already have MIP*-based predecessors \cite{mehta,goldbring}.
The exact carrier is a specialized sharpening, not a demonstrated resolution
of an independent major operator-algebra problem. It also does not give fixed
physical input dimension for the eventual POVM channel pair.
\item \textbf{Radical invention.} The fixed Petz-parameter proof, exact Chernoff
flag, and elementary inverse-action compression closed into the two main
theorems. Independent constructions also show that extending the Petz-parameter
collapse indiscriminately beyond $2$ fails. Root's additional contribution is
the general representing-measure localization and the combined classification.
\end{enumerate}

\paragraph{Transfers that were rejected.}
Strictly positive POVM channels are entanglement breaking: their ordinary
quantum and private capacities vanish, and their ordinary classical capacity
has a separate finite optimization interface. Thus the source does not give
ordinary capacity undecidability merely by changing terminology. No
locality-preserving Hamiltonian compiler, major open-problem resolution, or
general theory of all quantum information quantities was produced. Known
finite decision/guessing comparison theorems concern stronger experiments and
do not supply a finite reference bound for this weaker entropy order. Complete
entropy comparison is also not generally CPTP degradation.

\section{Falsification and priority assessment}
\paragraph{Strongest mathematical attacks.}
The localization proof was tested against a purely quadratic generator, a
single atomic representing measure, diffuse and singular measures, rank-
deficient numerators, and tail integrability. The quadratic Hessian is killed
exactly by $F_m(0)=0$, so it cannot falsely produce SLD from the endpoint. The
support-point exponential tilt handles singular measures; the stated finite-
at-zero condition justifies numerator regularization. Generators infinite at
zero remain outside the theorem. Independent fixed-parameter derivations
check the signs on both sides of $\alpha=1$; the Umegaki case uses its own
nonzero measure rather than a vanishing power-Hessian formula.

The explicit rational instrument above also establishes strict endpoint
separation for general channels without invoking undecidability.
The cutoff proof was attacked at normalization, trace gauge, common compression,
target preservation, source decrease, and faithful restoration. Its crucial
inequality follows from the elementary inverse variational principle, not an
unjustified equality after compression. A noncommuting numerical instance
compressed reference dimension 11 to 3: target quadratic errors were below
$5.7\times10^{-14}$ and both source terms decreased. This is a finite diagnostic
only. The general Hessian formula was also checked on 50 random finite matrix
instances with maximal relative discrepancy below $8\times10^{-16}$, and the
Chernoff flag on ten instances. Exact symbolic checks support separate domain
and packing calculations. None replaces the displayed universal proofs.

\paragraph{Closest primary literature.}
The 2022 complete less-noisy framework already identifies unrestricted
reference relative-entropy comparison and tensorizes it \cite{hrs}.
Hirche's October 2026 preprint proves the coherent-qubit SLD-to-entropy direction
\cite[Theorem 3.2, Proposition 3.5]{hirche}; the reverse from a single preassigned
modular Petz generator is the relevant proposed addition here. The earlier
Astra operational note proves simultaneous all-generator comparison, whose
converse simply selects a resolvent; that is weaker than recovering SLD from
each one fixed generator. Hirche--Tomamichel's coefficient collapse concerns
their hockey-stick-integral divergences, a different definition
\cite[Proposition 4.8]{ht}. Petz sufficiency/recovery results compare equality
in data processing for one channel, a different quantifier pattern
\cite{hiai}. The endpoint's qualitative decidability can also be reconstructed
from Vol\v ci\v c's quantitative rational Positivstellensatz
\cite[Theorem 5.2, Remark 5.3]{volcic}: normalized positive baselines form a
monic free spectrahedron, Hermitian tangents are unrestricted free variables,
and the operator-valued RLD difference is rational with positive denominators
on the strictly positive POVM domain. Thus a generic computable cutoff is
already a consequence of that prior machinery. The elementary $1+b^2$ and
$1+v$ bounds, and the combined classification, are the more specific potential
additions; their exact historical priority remains under review.
No matching predecessor for those precise claims has been located in the
focused search; that is not proof of originality.

\paragraph{Research allocation and limits.}
Sixteen distinct Luna Max literature investigations were deployed in organized
waves (one repeatedly disconnected), with five Sol Max mathematical
investigations. Targeted follow-ups reviewed the load-bearing manuscript and
the selected new proofs. Primary-source searches spanned nonlocal games,
statistical experiments, finite-reference theorems, capacities, entanglement,
resource theories, free positivity, operator algebras, logic, and physics.
Only decision-changing findings are reported here; source notes are archived.
Worker count is a resource receipt, not evidence of correctness. Searches were
finite and do not establish complete priority coverage. All reference-filter
dimensions, coefficient magnitudes, preparation requirements, and game-table
expansion costs remain part of the interface; no efficient physical access to
the witnesses has been established.

\section{Significance and the next indispensable gate}
The strongest defensible outcome is a potentially original structural theorem
with a sharp computational endpoint, supported by complete internally
reconstructed proofs. The classification is broader than a specialist
parameter extension: it explains why an entire operator-convex class induces
the same complete comparison and why one exceptional endpoint permits finite
certification. Conditional on Dots' core, it puts exact decidability and
\(\mathrm{coRE}\)-completeness arbitrarily close in a generator family.

There is currently no basis for rating this a civilization-changing 9--10/10
discovery. The hardness derives from established MIP*=RE machinery; no new
computational power, major independently important conjecture resolution, or
capacity/physical no-go transfer has been completed. Priority and independent
validation could substantially change the assessment. Even if all claims
survive, the evidence presently supports a substantial mathematical research
result, not historic significance.

The next indispensable gate is narrow: specialist proof reconstruction of
Theorem~\ref{thm:main}'s Hessian/localization and
Theorem~\ref{thm:rld}'s endpoint, an exact predecessor check, and validation of
Dots' shared spatial-domain-to-global-POVM bridge with the conjugation
convention corrected. A stronger physical claim additionally needs a
complement- or locality-preserving compiler. Those gaps are explicit; they
were not filled by inference from shared channels or by numerical checks.

\paragraph{Reconstruction and provenance.}
The archive contains the unchanged manuscript, five substantive mathematical
investigations, primary-literature notes, the root derivation, independent
reviews, executable finite diagnostics with results, a SHA-256 manifest, and
\texttt{ASTRA\_HANDOFF.json}. Repositories were read at
\href{https://github.com/harjassand/astra-research-knowledge/tree/902172b63c13874f5572e4f1336afad3694ea328}{Astra revision 902172b6}
and
\href{https://github.com/openai/math/tree/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb}{openai/math revision fd4aeeb2}.
No scientific claim was published and no commit, push, or pull request was made.

\clearpage
\begin{thebibliography}{99}
\bibitem{mip} Z. Ji, A. Natarajan, T. Vidick, J. Wright, H. Yuen.
\emph{MIP*=RE}. \href{https://arxiv.org/abs/2001.04383v3}{arXiv:2001.04383v3},
especially Theorem 12.6 and Definitions 5.9--5.11.
\bibitem{hiai} F. Hiai, M. Mosonyi, D. Petz, C. B\'eny.
\emph{Quantum f-divergences and error correction}.
\href{https://arxiv.org/abs/1008.2529v4}{arXiv:1008.2529v4}, especially Section 7.
\bibitem{hrs} C. Hirche, C. Rouz\'e, D. Stilck Fran\c ca.
\emph{On contraction coefficients, partial orders and approximation of capacities
for quantum channels}. Quantum 6, 862 (2022).
\href{https://arxiv.org/abs/2011.05949}{arXiv:2011.05949}.
\bibitem{hirche} C. Hirche. \emph{Quantum estimation, channel orders, and private
capacity}. \href{https://arxiv.org/abs/2610.03706v1}{arXiv:2610.03706v1},
2 October 2026, preprint.
\bibitem{ht} C. Hirche, M. Tomamichel. \emph{Quantum R\'enyi and f-divergences
from integral representations}. Commun. Math. Phys. 405, 208 (2024).
\href{https://arxiv.org/abs/2306.12343}{arXiv:2306.12343}.
\bibitem{mehta} V. Mehta, W. Slofstra, Y. Zhao.
\emph{Positivity is undecidable in tensor products of free algebras}.
\href{https://arxiv.org/abs/2312.05617v2}{arXiv:2312.05617v2}.
\bibitem{goldbring} I. Goldbring, T. Sinclair.
\emph{On definability of C*-tensor norms}.
\href{https://arxiv.org/abs/2509.15086v1}{arXiv:2509.15086v1},
Corollaries 5.5 and 5.8.
\bibitem{volcic} J. Vol\v ci\v c. \emph{Hilbert's 17th problem in free skew fields}.
Forum of Mathematics, Sigma 9, e61 (2021).
\href{https://arxiv.org/abs/2101.02314v2}{arXiv:2101.02314v2},
Theorem 5.2 and Remark 5.3.
\bibitem{smithyard} G. Smith, J. Yard.
\emph{Quantum communication with zero-capacity channels}.
\href{https://arxiv.org/abs/0807.4935}{arXiv:0807.4935},
Science 321, 1812--1815 (2008), including supplementary equations S1--S4.
\end{thebibliography}
\end{document}
'''

out = preamble + core + representation + endpoint + classification + audit + consequences
(base / 'outputs/research_report.tex').write_text(out)
print(f'Wrote {len(out)} characters to outputs/research_report.tex')
