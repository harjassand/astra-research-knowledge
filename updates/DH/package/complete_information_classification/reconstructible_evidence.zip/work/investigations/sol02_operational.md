# Operational consequences of complete channel comparison

Prepared 11 October 2026. Status: internally reconstructed proofs; conditional complexity consequences; historical priority unconfirmed.

Source manuscript: [channel_order_undecidability.txt](../manuscript/channel_order_undecidability.txt), especially Sections 2, 6–10 and 12–14. The manuscript is an AI-generated, unreviewed research note. Its full game-to-POVM reduction is an inherited premise here, not a theorem independently certified by this report.

## Result and boundary

The strongest operational statement reconstructed here is a fixed-helper characterization. Let \(N:A\to B\) be any finite-dimensional quantum channel, and let \(N^c:A\to E\) be its **full Stinespring complement**. Let \(\mathcal S_2\) be the fixed qubit erasure channel with erasure probability \(1/2\). Then

\[
 N^c\succeq_{\mathrm{RE}}^c N
 \quad\Longleftrightarrow\quad
 P(N\otimes\mathcal S_2)=0
 \quad\Longleftrightarrow\quad
 Q(N\otimes\mathcal S_2)=0.                                      \tag{A}
\]

All capacities in (A) are ordinary unassisted, asymptotic capacities of the displayed finite channel. No external quantum reference is supplied to the communication protocol. A violating reference is encoded into finitely many uses of the same qubit helper. The number of uses can depend on the violating reference and information gap and is not uniformly bounded here.

The implication involving quantum capacity is proved below, including the Smith–Yard entropy identity and the replacement of its finite-dimensional erasure helper by finitely many qubit helpers. It uses the regularized private- and quantum-capacity coding theorems. It does not identify the two numerical capacities.

For an arbitrary designated-output quantum wiretap broadcast \(W:A\to BE\), with privacy assessed only against its stated \(E\) output, the corresponding statement is

\[
 W_E\succeq_{\mathrm{RE}}^c W_B
 \quad\Longleftrightarrow\quad
 P(W\otimes\mathcal S_2)=0.                                     \tag{B}
\]

Combining (B) with the manuscript's claimed computable reduction gives **RE-complete positivity and coRE-complete vanishing of private capacity**, even for rational quantum-input/classical-output broadcasts \(W\) with \(P(W)=0\), when paired with this one fixed helper. This is a conditional consequence of the manuscript, proved in detail below.

The distinction between (A) and (B) is indispensable. The broadcast constructed from the manuscript has a measurement receiver marginal. That receiver marginal is antidegradable relative to its full complement, as is its product with \(\mathcal S_2\). Consequently its ordinary complementary-channel private and quantum capacities are always zero. The designated-output hardness theorem is **not** an undecidability theorem for the usual private or quantum capacity of a quantum channel.

The variable-dimension erasure-assisted private-capacity characterization is already in Hirche, Section 4.2, equations (4.8)–(4.9), [arXiv:2610.03706v1](https://arxiv.org/html/2610.03706v1). The refinement to one fixed qubit helper, proved here using a critical-erasure stabilizer construction, was not located in the primary sources checked. That absence does not establish novelty.

## 1. Definitions, inherited facts, and independent ingredients

Entropies and capacities use natural logarithms; converting to bits changes positive constants, not zero-versus-positive conclusions. All individual spaces and ensembles are finite. Reference dimensions and coding blocklengths may range over all finite values.

For channels \(M,N\) with a common input, complete relative-entropy order means

\[
 M\succeq_{\mathrm{RE}}^c N
 \iff
 D(M_R\alpha\Vert M_R\beta)\ge
 D(N_R\alpha\Vert N_R\beta)
\]

for every untouched finite reference \(R\) and all input states. Here \(M_R=M\otimes{\rm id}_R\). The equivalent complete less-noisy statement is

\[
 I(U:MR)\ge I(U:NR)                                             \tag{1}
\]

for every finite classical ensemble on the joint input-reference space. A proof is supplied in Section 2.

For a designated-output broadcast \(W:A\to BE\), define

\[
 P^{(1)}(W)=\sup_{\{p_u,\rho_u\}}
       [I(U:B)-I(U:E)],\qquad
 P(W)=\sup_{r\ge1}\frac1rP^{(1)}(W^{\otimes r}).                 \tag{2}
\]

The usual quantum wiretap coding theorem identifies (2) with the private communication capacity against the designated \(E\) output. In particular positivity is equivalent to a strictly positive private information at some finite blocklength. The wiretap model allows trusted discarded systems outside \(BE\). This convention and regularized formula are explicit in Tikku–Berta–Renes, [arXiv:2002.06580v2](https://arxiv.org/html/2002.06580v2), equations (1)–(3) and the setting in Section 2.

For a genuine channel, \(E\) is the full complement. Its quantum capacity satisfies

\[
 Q(N)=\sup_{r\ge1}\frac1r\sup_\theta
       I_c(N^{\otimes r},\theta),\qquad
 I_c(N,\theta)=S(N\theta)-S(N^c\theta),\qquad Q(N)\le P(N).
                                                                    \tag{3}
\]

The coding results are external, established ingredients; see Devetak,
[The private classical capacity and quantum capacity of a quantum channel](https://arxiv.org/abs/quant-ph/0304127).

The source manuscript supplies the following claims.

1. From a machine/input it computes strictly positive rational POVMs \(E,F\) with nonhalting implying \(E\succeq_{\mathrm{RE}}^cF\) and halting implying failure. Its Section 2 identifies complete SLD and complete RE order. The full reduction and this equivalence remain inherited premises for complexity claims in this report.
2. In its halting case, Sections 12–13 construct faithful states \(\alpha,\beta\) with
   \[
   D(F_R\alpha\Vert F_R\beta)-D(E_R\alpha\Vert E_R\beta)
       \ge\varepsilon_G>0,\qquad \alpha\le C_G\beta,               \tag{4}
   \]
   where positive rational \(\varepsilon_G,C_G\) are computable from the game. The original reference dimension is unknown.
3. Its Section 11 proves that the complete entropy defect \(V(E,F)\) is finite, and Section 14 claims no uniform approximation even at additive error \(1/4\).

The statements below about stabilizer codes, capacity activation, the broadcast interface, scalar reference restriction, and exact tensor additivity are reconstructed explicitly. Their use of the manuscript's game reduction is marked conditional.

## 2. Complete entropy order, ensembles, and a constant physical marginal

### 2.1 Relative entropy and classical labels

If complete RE order holds, apply it separately to each ensemble member \(\rho_u\) and its average \(\bar\rho=\sum p_u\rho_u\), then sum:

\[
 I(U:MR)=\sum_u p_uD(M_R\rho_u\Vert M_R\bar\rho)
       \ge I(U:NR).                                             \tag{5}
\]

Conversely, suppose a pair \(\alpha,\beta\) has a strictly positive finite entropy difference
\[
 d=D(N_R\alpha\Vert N_R\beta)-D(M_R\alpha\Vert M_R\beta)>0.
\]
It suffices to consider faithful pairs. Indeed common regularization by the maximally mixed input makes both outputs faithful on their fixed supports. For a finite original relative entropy, joint convexity gives the appropriate upper limit, and lower semicontinuity gives the matching lower limit. If the original value is infinite, lower semicontinuity forces divergence. Thus any failure of order has a finite faithful failure after a sufficiently small regularization.

Use the binary ensemble consisting of \(\alpha\) with probability \(p\) and \(\beta\) with probability \(1-p\), and write \(\mu_p=(1-p)\beta+p\alpha\). Donald's identity gives, for either channel \(\Phi\),

\[
 I(U:\Phi R)
   =pD(\Phi_R\alpha\Vert\Phi_R\beta)
      -D(\Phi_R\mu_p\Vert\Phi_R\beta).                            \tag{6}
\]

In fixed dimension with faithful denominator the last term is \(O(p^2)\). The target-minus-source information difference is therefore \(pd+O(p^2)>0\) for sufficiently small \(p\). This proves (1) and the equivalence of complete RE and complete ensemble order without invoking the manuscript's SLD theorem.

### 2.2 Removing the unassisted physical signal

Given any violating ensemble \(\{p_x,\rho_x^{AR}\}_{x\in\mathbb Z_m}\), let \(U\) be uniform on \(\mathbb Z_m\), introduce a classical register \(K\), and encode

\[
 \sigma_u^{ARK}=\sum_xp_x\rho_x^{AR}
                    \otimes|x-u\rangle\langle x-u|_K.            \tag{7}
\]

Its \(AR\) marginal is independent of \(u\). In particular its \(A\) marginal is constant, so \(I(U:B)=I(U:E)=0\) after any two channels on \(A\). Given \(K=k\), the variable \(U=X-k\) has the original distribution \(p_x\). The chain rule therefore gives

\[
 I(U:BRK)-I(U:ERK)
  =I(U:BR\mid K)-I(U:ER\mid K)
  =I(X:BR)-I(X:ER)>0.                                          \tag{8}
\]

The \(I(U:K)\) terms cancel; they need not vanish. No shared secret key is assumed: \(K\) is part of the helper input. Equations (7)–(8) are the finite-dimensional masking construction already used by Hirche in the cited Section 4.2. They are reproduced to fix the exact interface.

### 2.3 The manuscript's entropy witnesses already have the required marginal

Section 13, equation (74), has

\[
 \alpha=\rho_{AR}\otimes\sigma_{\eta_0},\qquad
 \beta=\frac{\rho_{AR}\otimes W+tH_{AR}\otimes L}{Z_0},
 \quad Z_0={\rm Tr}\,W,\quad {\rm Tr}\,L=0.                     \tag{9}
\]

Let \(C\) denote both the old reference and the new auxiliary factor. Then

\[
 \alpha_A=\rho_A,\qquad
 \beta_A=\frac{Z_0\rho_A+
                  t({\rm Tr}_RH)({\rm Tr}\,L)}{Z_0}
        =\rho_A.                                               \tag{10}
\]

This conclusion does **not** require \({\rm Tr}_RH=0\), or any claim that the physical-cross tangent remains cross after filtering. It survives arbitrary choices of the poles and leaf vectors because \(L\) remains centre-to-leaf off-diagonal and traceless. The common physical marginal follows from tracing the auxiliary register. The reference marginals can differ, as the source explicitly permits.

Thus the faithful entropy witnesses of Section 13 directly yield a constant-\(A\)-marginal binary ensemble through (6), without masking. This observation is exact, but its positive gap and computable constants are inherited from the manuscript's Lemma 13.1.

## 3. A fixed qubit half-erasure can replace any finite half-erasure for positivity

Write \(\mathcal S_d(X)=\frac12X\oplus\frac12{\rm Tr}(X)|e\rangle\langle e|\). A dilation sends the input to Bob in one branch and to Eve in the other, with orthogonal flags at both outputs. At \(p=1/2\), Bob and Eve's marginal channels are the same after identifying output spaces.

The following coding lemma is the central additional ingredient.

### Lemma 1: almost all patterns belong to one correctable side

Fix \(k\ge1\). For every \(\eta>0\), there are an \(n\ge k\) and an isometric encoding of \(k\) logical qubits into \(n\) physical qubits such that, under independent qubit erasures of probability \(1/2\):

* the patterns on which Bob can recover the entire logical system have probability \(q\);
* the patterns on which Eve can recover it have the same probability \(q\);
* these sets are disjoint;
* the remaining probability \(b=1-2q\) is less than \(\eta\).

On each recoverable side, recovery is exact. The other side's entire helper output is a fixed state independent of the logical input.

**Proof.** Use a uniformly Clifford-conjugated \([[n,k]]\) stabilizer code. Modulo phases, Pauli operators are the vectors of \(\mathbb F_2^{2n}\), with the nondegenerate symplectic commutation form. Its stabilizer subspace \(S\) has dimension \(n-k\); its normalizer \(S^\perp\) has dimension \(n+k\).

An erased set \(T\) of \(m\) qubits is correctable exactly when no Pauli supported on \(T\) lies in \(S^\perp\setminus S\). To see this, the operators supported on \(T\) are spanned by its Pauli operators. The Knill–Laflamme condition says each has a scalar compression to the code. A Pauli anticommuting with a stabilizer has zero compression; a stabilizer has scalar compression; a member of \(S^\perp\setminus S\) is a nontrivial logical Pauli. This proves the criterion.

For any fixed nonzero Pauli \(v\), transitivity of Clifford conjugation on nonzero Paulis gives

\[
 \Pr[v\in S^\perp\setminus S]
    =\frac{2^{n+k}-2^{n-k}}{4^n-1}
    \le 2^{k-n}.                                               \tag{11}
\]

There are \(4^m-1\) nonzero Paulis supported on \(T\). A union bound yields

\[
 \Pr_{\rm code}[T\text{ not correctable}]
      \le(4^m-1)2^{k-n}\le2^{2m-n+k}.                          \tag{12}
\]

Fix an integer \(t>0\). If \(m\le(n-k)/2-t\), the last bound is at most \(2^{-2t}\). If \(m\ge(n+k)/2+t\), the same bound applies to the complementary set of \(n-m\) qubits.

For a fixed code, call a pattern good for Bob if its erased set \(T\) is correctable, and good for Eve if \(T^c\) is correctable. The two events cannot occur together: their two local decoders would clone an arbitrary state of a \(2^k\)-dimensional logical system. Complementation \(T\mapsto T^c\) interchanges them and preserves the uniform pattern distribution, so their probabilities are equal.

Let \(b(C)\) be the probability neither side is good for a code \(C\). Averaging (12) over \(M\sim{\rm Bin}(n,1/2)\) gives the conservative estimate

\[
 {\mathbb E}_C b(C)
 \le \Pr\!\left[|M-n/2|\le k/2+t+1\right]+2^{1-2t}.             \tag{13}
\]

For fixed \(k,t\), the central interval contains a bounded number of integers, and the maximum binomial point mass tends to zero. First choose \(t\) so the second term is small, then choose \(n\) so the first is small. Some finite code has \(b(C)<\eta\). All correctability tests and probabilities are finite combinatorial quantities; exhaustive search could find such a code given \(k,\eta\).

For completeness, exact correctability also gives the claimed full-environment decoupling. Let \(V:C\to DF\) be the isometry of the encoded input to the two surviving subsystems for a fixed pattern, and let a channel on \(D\) recover \(C\) exactly. Dilate the recovery to an isometry \(U:D\to C G\). The marginal channel \(C\to C\) is the identity, so uniqueness of a Stinespring dilation of the identity gives

\[
 (U\otimes I_F)V|\psi\rangle
       =|\psi\rangle_C\otimes|\zeta\rangle_{GF}                 \tag{14}
\]

for a fixed pure state \(|\zeta\rangle\), independent of \(|\psi\rangle\). Equation (14) holds also on inputs correlated with arbitrary other systems. Consequently the full \(F\) output is constant, not merely inaccessible to a chosen Eve decoder. The roles reverse on Eve-good patterns. \(\square\)

This is a zero-rate, critical-erasure construction. Bob's recovery probability tends to \(1/2\), not to one. It is consistent with \(Q(\mathcal S_2)=P(\mathcal S_2)=0\).

### Lemma 2: private information survives fixed-helper replacement

Let \(W:A\to BE\) be any finite broadcast, and suppose an ensemble \(\{p_u,\sigma_u^{AC}\}\) has a common \(A\) marginal and

\[
 \Delta=I(U:BC)-I(U:EC)>0.                                    \tag{15}
\]

Then for some finite \(n\), one use of \(W\) and \(n\) qubit half-erasure helpers have strictly positive private information.

**Proof.** Embed \(C\) into \(k\ge1\) qubits and use Lemma 1. The erasure pattern is an input-independent classical flag available to both sides. On a Bob-good pattern, reversibility of the helper channel and (14) give Bob's information exactly \(I(U:BC)\). Eve's complete helper output is constant, while her \(E\) marginal is independent of \(U\) because the \(A\) marginal is common. Thus Eve's information is zero.

On an Eve-good pattern the contribution reverses: Bob's information is zero and Eve's information is exactly \(I(U:EC)\). On any bad pattern, Bob's information is nonnegative and Eve's is at most \(H(U)\). Averaging over flags therefore gives

\[
 I(U:BD)-I(U:EF)
       \ge q\Delta-bH(U)
       =\frac{1-b}{2}\Delta-bH(U).                             \tag{16}
\]

Choose \(b<\Delta/(\Delta+2H(U))\). The lower bound is positive. No output of Eve has been discarded or artificially decoded in this estimate. \(\square\)

Padding the remaining \(n-1\) copies of \(W\) with fixed, input-independent states embeds this protocol in \(n\) uses of \(W\otimes\mathcal S_2\). The unchanged positive private information divided by \(n\) is a positive asymptotic rate by (2).

## 4. Complete order exactly characterizes fixed-helper private incapacity

### Theorem 1

For every finite designated-output broadcast \(W:A\to BE\),

\[
 W_E\succeq_{\mathrm{RE}}^cW_B
    \iff P(W\otimes\mathcal S_2)=0.                            \tag{17}
\]

Equivalently the left side holds precisely when \(P(W\otimes H)=0\) for every finite genuine antidegradable helper \(H\), using the full complement of \(H\) as part of Eve's output.

**Proof.** Complete RE order tensorizes. To verify this directly, for any joint input-state pair telescope

\[
 D(M_1M_2\alpha\Vert M_1M_2\beta)
 \ge D(N_1M_2\alpha\Vert N_1M_2\beta)
 \ge D(N_1N_2\alpha\Vert N_1N_2\beta),                           \tag{18}
\]

using every untouched output and reference as the reference for each comparison. Faithful regularization handles support limits.

An antidegradable helper's environment dominates its receiver completely by data processing, and \(\mathcal S_2\) is self-complementary. Thus the left side of (17) implies complete environmental dominance for the product and every tensor power. Equation (5) makes every finite-block private information nonpositive. A constant label attains zero, so the capacity is zero.

If the left side fails, Section 2 provides a finite violating ensemble, and (7) makes its physical marginal constant while preserving the positive information difference. Lemma 2 supplies a finite positive private-information block for the fixed qubit helper. Its capacity is positive. This also disproves the asserted vanishing for every antidegradable helper. \(\square\)

No assumption \(P(W)=0\) is needed for Theorem 1. That promise will hold in the hardness construction.

## 5. Genuine channels: full derivation of the quantum-capacity equivalence

This section requires \(E\) to be the full complement. It cannot be applied to a designated-output broadcast with a trusted discarded residual.

### Lemma 3: the Smith–Yard conversion

For a finite genuine channel \(T:A\to B\) and any ensemble \(\{p_x,\rho_x^A\}\), some finite \(d\) and state \(\theta^{AC}\) satisfy

\[
 I_c(T\otimes\mathcal S_d,\theta)
       =\tfrac12[I(X:B)-I(X:E)].                               \tag{19}
\]

This is the established Smith–Yard theorem, [arXiv:0807.4935](https://arxiv.org/html/0807.4935), supplementary equations (S1)–(S4). The derivation is included to make the hypotheses explicit.

**Derivation.** Choose purifications \(|\phi_x\rangle^{AC_x}\) in mutually orthogonal subspaces \(C_x\), and put \(C=\bigoplus_xC_x\), so \(d=\sum_x{\rm rank}\rho_x\). Set
\[
 \theta^{AC}=\sum_xp_x|\phi_x\rangle\langle\phi_x|,\qquad
 |\Omega\rangle^{XAC}=\sum_x\sqrt{p_x}|x\rangle|\phi_x\rangle.
\]
After a Stinespring isometry of \(T\), the state on \(XBEC\) is pure. Tracing \(C\) removes cross terms, so \(XB\) and \(XE\) are classical in \(X\). Purity gives \(S(EC)=S(XB)\) and \(S(BC)=S(XE)\). The erasure flag entropies cancel, leaving
\[
\begin{aligned}
 I_c(T\otimes\mathcal S_d,\theta)
 &=\tfrac12[S(BC)-S(E)]+\tfrac12[S(B)-S(EC)]\\
 &=\tfrac12[S(B)-S(XB)+S(XE)-S(E)]\\
 &=\tfrac12[I(X:B)-I(X:E)].
\end{aligned}
\]
The equalities use a pure full dilation, not an arbitrary joint broadcast. \(\square\)

### Lemma 4: positive coherent information survives fixed-helper replacement

If \(I_c(T\otimes\mathcal S_d,\theta)=c>0\), then for some \(n\) the same input with its \(C\) system encoded across \(\mathcal S_2^{\otimes n}\) has positive coherent information.

**Proof.** Purify \(\theta^{AC}\) by a finite \(K\), and use Lemma 1. Condition on the erasure pattern. On a Bob-good pattern, (14) factorizes the decoded helper output as the original \(C\) tensored with a fixed pure bipartite ancillary state. The ancillary marginal entropies on the two sides are equal. Therefore the branch coherent information is exactly
\[
 a=S(BC)-S(E).
\]
The raw receiver output has the same entropy as its isometrically decoded output. On an Eve-good pattern the analogous value is
\[
 a'=S(B)-S(EC).
\]
Neither argument discards an uncontrolled environmental subsystem. Since \(q=(1-b)/2\), the two good sets contribute
\[
 q(a+a')=(1-b)c.                                               \tag{20}
\]

For a bad pattern, the complete conditioned channel still arises from an isometry on \(AC\), with purification \(K\). Thus its coherent information is \(-S(K\mid BD)\), which is at least \(-S(K)\) by subadditivity. Pattern flags have the same probability distribution at receiver and environment, so their entropy contributions cancel. Consequently

\[
 I_c(T\otimes\mathcal S_2^{\otimes n},\theta_{\rm encoded})
       \ge (1-b)c-bS(K).                                      \tag{21}
\]

Choose \(b<c/(c+S(K))\). This is strictly positive. \(\square\)

### Theorem 2

For every finite genuine channel \(N\),

\[
\begin{aligned}
 N^c\succeq_{\mathrm{RE}}^cN
 &\iff P(N\otimes\mathcal S_2)=0\\
 &\iff Q(N\otimes\mathcal S_2)=0.                              \tag{22}
\end{aligned}
\]

**Proof.** The first equivalence is Theorem 1. Its zero case also gives \(Q=0\) by \(Q\le P\).

In the opposite case, put \(M=N\otimes\mathcal S_2\). Theorem 1 gives \(P(M)>0\). By (2), some finite block \(T=M^{\otimes r}\) has a finite ensemble with strictly positive private information. Lemma 3 gives \(c>0\) for \(T\otimes\mathcal S_d\); Lemma 4 replaces the extra \(\mathcal S_d\) by \(n\) copies of \(\mathcal S_2\) while retaining positive coherent information.

Embed that channel in \(M^{\otimes(r+n)}\): use its first \(r\) pairs for \(T\), its remaining \(n\) helpers for the replacement encoding, and put the remaining \(n\) copies of \(N\) on independent **pure** fixed inputs. Each padded genuine-channel input has zero coherent information, since its receiver and environment arise from a pure bipartite output and have equal entropy. Coherent information is additive on these independent padding factors. Thus \(M^{\otimes(r+n)}\) has positive coherent information. Equation (3) implies \(Q(M)>0\). \(\square\)

If the manuscript's complete SLD/RE equivalence is accepted, complete SLD may replace complete RE in (22). The proof of (22) itself requires no game reduction or SLD equivalence.

The statement is about positivity, not a uniform activation rate, a one-use qubit-helper witness, or an effective bound on the required blocklength.

## 6. Conditional RE-complete private superactivation for designated broadcasts

### 6.1 A rational compatible broadcast for any POVM pair

For POVMs \(E=(E_i)\) and \(F=(F_j)\) on \(A\), define the joint classical-output channel

\[
\begin{aligned}
 W_{E,F}(\rho)
  ={}&\sum_i\tfrac12{\rm Tr}(E_i\rho)
       |e\rangle\langle e|_B\otimes|i\rangle\langle i|_E\\
    &+\sum_j\tfrac12{\rm Tr}(F_j\rho)
       |j\rangle\langle j|_B\otimes|e\rangle\langle e|_E .
\end{aligned}                                                   \tag{23}
\]

Its joint POVM consists of \(E_i/2,F_j/2\), so it is normalized and rational when the input POVMs are. Its marginals are

\[
 W_B=\tfrac12F\oplus\tfrac12\mathcal R_e,\qquad
 W_E=\tfrac12E\oplus\tfrac12\mathcal R_e,                         \tag{24}
\]

where \(\mathcal R_e(\rho)={\rm Tr}(\rho)|e\rangle\langle e|\).
For faithful input-reference pairs, direct-sum relative entropy gives

\[
\begin{aligned}
 &D(W_{B,R}\alpha\Vert W_{B,R}\beta)
       -D(W_{E,R}\alpha\Vert W_{E,R}\beta)\\
 &\hspace{12mm}=\tfrac12[
 D(F_R\alpha\Vert F_R\beta)-D(E_R\alpha\Vert E_R\beta)].
\end{aligned}                                                   \tag{25}
\]

The two erasure branches contribute the same
\(\frac12D(\alpha_R\Vert\beta_R)\), which cancels. Equation (25) is used only for finite divergences. For extended-valued order, the forward implication follows by adding the same nonnegative term and the reverse follows from a finite faithful violating pair. Hence

\[
 E\succeq_{\mathrm{RE}}^cF
      \iff W_E\succeq_{\mathrm{RE}}^cW_B.                        \tag{26}
\]

This is a compatible broadcast construction; it does not assume that two arbitrary POVMs can be measured simultaneously with their original marginals.

### 6.2 The manuscript's hard pairs have ordinary dominance in both cases

The following extra promise follows from the scalar restriction of the manuscript's actual polynomial construction. It is useful because it makes \(P(W_{E,F})=0\) even in the halting case.

On reference sizes \(n=m=1\), the three normalized Pauli letters \(T_i\) of source equations (13)–(18) are scalars. Their vector is a convex combination of two qubit Bloch vectors, one with the prescribed transposed Pauli orientation. Each Bloch vector has Euclidean norm at most one. Thus
\[
 \sum_{i=X,Y,Z}T_i^2\le1,\qquad [T_i,T_j]=0,\qquad
 \Delta_{\rm anchor}=3-\sum_iT_i^2\ge2.                         \tag{27}
\]
The transposition changes an orientation, not this norm bound.

Source equation (41) has \(E_{\rm op}\ge\Delta_{\rm anchor}\) and \(H_{\rm op}\ge0\). The source's extracted observables have norms at most \(9\), so its game-score polynomial obeys
\[
 \|B\|\le81M^2K^2.                                              \tag{28}
\]
Indeed the \(M^2\) prefactor multiplies a probability-weighted sum with at most \(K^2\) answer pairs and product norms at most \(81\).

The reduction uses \(r=3/4,\gamma=1/4\) and
\[
 \mathcal F=rI-B+\lambda_EE_{\rm op}+\lambda_HH_{\rm op},\qquad
 \lambda_E=\lceil2C_2^2/\gamma\rceil,\quad
 C_2=C_1C_ss_0\ge10M^2K^2 .
\]
Consequently \(\lambda_E\ge800M^4K^4\) and throughout the scalar domain
\[
 \mathcal F\ge\tfrac34-81M^2K^2+2\lambda_E\ge\tfrac18.          \tag{29}
\]

This bound is independent of the game's value. The fixed compiler of Section 7 was built for gap \(1/8\), so its positive kernel estimate holds on this scalar domain for every game. The subsequent completion only invokes the kernel gap at the same reference size: in Section 8 it uses \(K(R_{\rm eff},R_{\rm eff})\), and in Section 9 the gauge, pinching and paired inverse estimates do not enlarge the reference. Therefore restricting that argument to reference dimension one proves **ordinary SLD dominance \(E\succeq_{\mathrm{SLD}}F\) for every produced pair**, regardless of halting.

For measurement channels without a quantum reference the outputs are classical. Their SLD and BKM quadratic forms both equal \(\sum_i h_i^2/p_i\). Integrating that Hessian on the input segment from \(\beta\) to \(\alpha\) gives ordinary RE dominance:
\[
 D(E\alpha\Vert E\beta)\ge D(F\alpha\Vert F\beta).               \tag{30}
\]
Strict positivity of all effects makes the output probabilities positive, including at boundary input states. Thus the integration and its boundary extension are legitimate.

This scalar-domain deduction is conditional on the correctness of the source's compiler and completion. It does not use its MIP* soundness bound and is not an extra external hardness premise.

### 6.3 Ordinary dominance suffices for zero capacity of this classical broadcast

For a quantum-input/classical-output broadcast \(W:A\to BE\), ordinary less-noisy dominance \(I(U:E)\ge I(U:B)\) for every ensemble implies \(P(W)=0\).

To prove this even for entangled block inputs, use the exact telescoping identity
\[
 I(U:B^r)-I(U:E^r)
  =\sum_{i=1}^r[
 I(U:B_i\mid B_{<i}E_{>i})-
 I(U:E_i\mid B_{<i}E_{>i})].                                   \tag{31}
\]

All conditioning systems here are classical, because the joint broadcast outputs are classical. For each value \(c\) of \(B_{<i}E_{>i}\), the measurements on the other inputs produce a legitimate conditional ensemble on \(A_i\), with probabilities \(p(u\mid c)\). The \(i\)-th local channel acts on that ensemble. Ordinary less-noisy dominance makes its summand nonpositive after averaging over \(c\). Hence every block private information is at most zero, while a constant message attains zero.

Apply (30), (5) without reference, and (24). It follows that every hard-game broadcast produced by (23) has
\[
 P(W_{E,F})=0,\qquad P(\mathcal S_2)=0.                         \tag{32}
\]

### Theorem 3: conditional capacity classification

Assume the manuscript's finite rational game-to-POVM reduction is correct. On finite rational quantum-input/classical-output broadcasts \(W\), the language
\[
 \{W:P(W\otimes\mathcal S_2)>0\}
\]
is RE-complete, and its zero-capacity complement is coRE-complete. Hardness persists under the promise \(P(W)=0\).

**Proof.** Given a machine/input, compute the source POVMs and then (23). In the nonhalting case, (26) and Theorem 1 imply product private capacity zero. In the halting case, (26) fails, so Theorem 1 implies strictly positive product private capacity. Equation (32) proves the individual zero-capacity promise on both branches.

For the RE upper bound, enumerate finite blocklengths, finite rational probability distributions, and rational input density matrices for finite ensembles. Quantum entropy in a fixed finite dimension is computable with certified accuracy, including at zero eigenvalues. Any strict positive information difference is eventually certified. Any real finite positive witness has a rational faithful approximation retaining the sign by continuity of entropy. The capacity formula (2) guarantees that every positive capacity has some such finite positive witness. Thus positivity is RE; the halting reduction proves RE-hardness. \(\square\)

The output channel is a finite rational channel. The reduction does not output the activating code, a sufficient blocklength, or a positive lower bound on the ordinary capacity. Those depend on a reference/strategy dimension not supplied by the reduction.

## 7. Exact impossibility of promoting this broadcast to the full environment

Let \(\mathcal M(\rho)=\sum_b{\rm Tr}(M_b\rho)|b\rangle\langle b|\) be any measurement channel, in particular the receiver marginal \(W_B\) of (24). A Stinespring isometry is

\[
 V|\psi\rangle
   =\sum_b|b\rangle_B|b\rangle_J\sqrt{M_b}|\psi\rangle_L.
\]

Its full complement is
\[
 \mathcal M^c(\rho)
    =\bigoplus_b\sqrt{M_b}\rho\sqrt{M_b}.
\]
Measuring the register \(J\) and reporting \(b\) simulates \(\mathcal M\) exactly. Hence \(\mathcal M\) is antidegradable. Every equivalent full complement has the same simulation property after the corresponding environmental isometry.

Since \(\mathcal S_2\) is antidegradable and antidegradability is closed under tensor products,
\[
 P(W_B\otimes\mathcal S_2)=Q(W_B\otimes\mathcal S_2)=0            \tag{33}
\]
as capacities of ordinary genuine channels, for **every** POVM pair \(E,F\).

Thus an attempted promotion that preserves the measurement receiver marginal is impossible. The designated \(E\) output in (23) omits a trusted residual from the full dilation. Revealing that residual to Eve changes the operational problem and destroys the hardness conclusion.

An ordinary quantum-channel capacity undecidability theorem would require a new computable map
\[
 (E,F)\longmapsto N_{E,F}
 \quad\text{with}\quad
 N_{E,F}^c\succeq_{\mathrm{RE}}^cN_{E,F}
       \iff E\succeq_{\mathrm{RE}}^cF,                          \tag{34}
\]
with a receiver containing an appropriate genuine quantum output. No such map is established here. Equation (34), rather than the fixed-helper activation implication, is the indispensable missing reduction.

## 8. A serious failed complementary-channel construction

There is an attractive algebraic cancellation which does not solve (34).

For a strictly positive POVM \(E\), its efficient instrument is
\[
 \mathcal I_E(\rho)=\bigoplus_i\sqrt{E_i}\rho\sqrt{E_i}.
\]
It is a complement of its measurement channel. For the RLD form
\[
 q_\rho(H)={\rm Tr}(H\rho^{-1}H)
\]
on Hermitian \(H\), invertible congruence and \(\sum E_i=I\) give exactly
\[
 q_{\mathcal I_E(\rho)}(\mathcal I_E(H))
 =\sum_i{\rm Tr}(E_iH\rho^{-1}H)=q_\rho(H).                    \tag{35}
\]
The identity also holds with an arbitrary untouched reference.

In fact this instrument preserves standard Petz Rényi divergence of order two exactly, on every pair and every finite reference. Put \(A_i=\sqrt{E_i}\otimes I_R\). For faithful \(\beta\),
\[
\begin{aligned}
 Q_2(\mathcal I_{E,R}\alpha\Vert\mathcal I_{E,R}\beta)
 &=\sum_i{\rm Tr}[(A_i\alpha A_i)^2(A_i\beta A_i)^{-1}]\\
 &=\sum_i{\rm Tr}[A_i\alpha\beta^{-1}\alpha A_i]
  ={\rm Tr}(\alpha\beta^{-1}\alpha)
  =Q_2(\alpha\Vert\beta),
 \qquad D_2=\log Q_2.                                         \tag{35a}
\end{aligned}
\]
For a singular denominator with \({\rm supp}\,\alpha\subseteq{\rm supp}\,\beta\), set \(G_i=A_i\beta^{1/2}\) on \({\rm supp}\,\beta\) and \(T=\beta^{-1/2}\alpha\beta^{-1/2}\). Full column rank gives
\(G_i^*(G_iG_i^*)^+G_i=I_{{\rm supp}\,\beta}\); the \(i\)-th summand is therefore still
\({\rm Tr}[A_i\alpha\beta^+\alpha A_i]\). Summing proves (35a). If the support inclusion fails, invertibility of each \(A_i\) preserves its failure in every outcome block, and both divergences are infinite.

Consequently \(\mathcal I_E\) and the identity channel are completely \(D_2\)-equivalent, whereas (36) below shows that \(\mathcal I_E\) need not dominate the identity in complete SLD order. This is an **unconditional explicit separation for general finite channels**, independent of the manuscript and its compiler. It does not supply a separation using two measurement channels.

A genuinely complementary flagged pair can therefore be built with
\[
 N=\tfrac12F\oplus\tfrac12\mathcal I_E,\qquad
 N^c=\tfrac12\mathcal I_F\oplus\tfrac12E.
\]
Its RLD anti-comparison difference is exactly half the RLD comparison difference between \(E\) and \(F\), because the two instrument terms in (35) cancel.

The needed inference from this cancellation to complete RE dominance is false. Take the qubit POVM
\[
 E_\pm=\tfrac12(I\pm tZ),\quad0<t<1,\qquad
 \rho=I/2,\quad H=X/2.
\]
Then
\[
 g_\rho(H)=1,\qquad
 g_{\mathcal I_E(\rho)}(\mathcal I_E(H))=1-t^2,                 \tag{36}
\]
although (35) gives exact RLD equality. At \(t=1/2\), the instrument's BKM Hessian on this tangent is
\[
 \frac{1-t^2}{2t}\log\frac{1+t}{1-t}
      =\tfrac34\log3<1.
\]
For the faithful pair \(\rho+sH,\rho\) and sufficiently small nonzero \(s\), the second-order expansion of relative entropy therefore also shows strict loss under \(\mathcal I_E\). RLD preservation does not imply RE preservation, let alone dominance over the identity. This falsifies the metric bridge required by the proposed complementary promotion.

The general-channel separation can even have rational channel matrices. Choose \(t=3/5\), so \(E_+=\operatorname{diag}(4/5,1/5)\), \(E_-=\operatorname{diag}(1/5,4/5)\). Writing an input as \(\begin{pmatrix}a&z\\w&b\end{pmatrix}\), the instrument output blocks are
\[
 \begin{pmatrix}4a/5&2z/5\\2w/5&b/5\end{pmatrix}
 \ \oplus\
 \begin{pmatrix}a/5&2z/5\\2w/5&4b/5\end{pmatrix}.
\]
Its superoperator and Choi matrix have rational entries, and (36) gives SLD value \(16/25<1\). Irrational entries in one Kraus representation do not make the channel's matrix description irrational.

## 9. Quantitative consequence with unbounded free helper multiplicity

This additional result concerns a different resource accounting from an ordinary fixed finite channel. Define
\[
 P_{\rm free}(W)=\sup_{m\ge0}P(W\otimes\mathcal S_2^{\otimes m}), \tag{37}
\]
where one use of \(W\), together with any finite number of helper uses, is charged as one resource use.

For broadcasts with classical receiver \(B\), this quantity is finite:
\[
 0\le P_{\rm free}(W)\le\log|B|.                               \tag{38}
\]
Indeed the helper marginal channel is identical at Bob and Eve, even for correlated inputs. In each block the helper-only mutual information cancels from the private-information difference. The remaining receiver term is \(I(U:B^r\mid D)\le r\log|B|\), since \(B^r\) is classical; the remaining Eve conditional mutual information is nonnegative.

The source's computable entropy margin yields a computable positive margin for (37), unlike the ordinary fixed-helper capacity.

Here is the quantitative conversion. If faithful states obey \(\alpha\le C\beta\), let \(H=\alpha-\beta\), \(\mu_p=\beta+pH\), and \(f(p)=D(\mu_p\Vert\beta)\). The BKM Hessian is bounded by the RLD quadratic form, and \(\mu_p\ge(1-p)\beta\), so for \(0\le p\le1/2\),
\[
 f''(p)\le2{\rm Tr}(H\beta^{-1}H)\le2(C-1).
\]
The last inequality follows from
\({\rm Tr}(\alpha\beta^{-1}\alpha)\le C\), by \(\alpha\le C\beta\).
Since \(f(0)=f'(0)=0\),
\[
 D(\mu_p\Vert\beta)\le(C-1)p^2.                                \tag{39}
\]
The same bound survives either channel.

For a manuscript witness (4), equation (6) therefore gives
\[
 I(U:FR)-I(U:ER)\ge p\varepsilon_G-(C_G-1)p^2.
\]
Choose the computable positive rational
\[
 p_G=\min\{1/2,\varepsilon_G/[2(C_G-1)]\}.
\]
For the source construction \(C_G=2Z_0>1\). The information advantage is at least \(p_G\varepsilon_G/2\). The witness has the common physical marginal proved in (10); applying the broadcast (23) scales that advantage by \(1/2\). Lemma 2 makes its private information approach half of the latter quantity as \(b\to0\). Thus the halting case has
\[
 P_{\rm free}(W_{E,F})\ge p_G\varepsilon_G/8,                  \tag{40}
\]
whereas complete order makes the nonhalting case zero.

Set \(c_G=p_G\varepsilon_G/16\), so a finite helper multiplicity gives one-use private information exceeding \(c_G\). The \(k\)-fold product of that finite protocol has private information exceeding \(kc_G\) for \(W^{\otimes k}\), with its finite helper supply. Taking the computable integer \(k_G=\lceil1/c_G\rceil\) makes the halting value exceed one and the nonhalting value zero. Equation (38) keeps every value finite. Consequently, **conditional on the source's normalized margin proof**, no total algorithm approximates \(P_{\rm free}\) on these rational classical-output broadcasts even to fixed additive error \(1/4\).

This does not prove numerical uncomputability of \(P(W\otimes\mathcal S_2)\). In that ordinary capacity, helper compression uses a block of unknown length and divides the achieved private information by that length. Exact zero undecidability alone gives no computable positive rate margin.

## 10. Exact tensor additivity of the manuscript's bounded defect

For strictly positive POVM pairs define
\[
 V(E,F)=\sup_{R,\alpha,\beta\ {\rm faithful}}
 [D(F_R\alpha\Vert F_R\beta)-D(E_R\alpha\Vert E_R\beta)].
\]
Then
\[
 V(E_1\otimes E_2,F_1\otimes F_2)
     =V(E_1,F_1)+V(E_2,F_2).                                  \tag{41}
\]

For the upper bound telescope the defect through \(E_1\otimes F_2\). In the first difference, the \(F_2\) output and original reference are an untouched reference for the pair \(E_1,F_1\). In the second, the \(E_1\) output and original reference are a reference for \(E_2,F_2\). Each difference is bounded by its corresponding \(V\). Strictly positive measurement effects and a faithful input ensure these intermediate states are faithful on their classical output blocks, so they fall within the stated supremum.

For the lower bound take product pairs of arbitrarily near-optimal witnesses. Relative entropy is additive on products, so their defects add. Taking the suprema proves equality.

Equation (6) also identifies each defect as the limiting small-prior slope of a binary ensemble's information advantage. This is a clean complete resource potential, but the telescoping argument is characteristic of complete amortized comparison and is not, by itself, a landmark operational discovery.

## 11. Falsification, priority, and significance assessment

**Finite checks.** A direct finite symplectic enumeration was run for all 15 stabilizer subspaces of \([[2,1]]\) and all 315 of \([[3,1]]\). For a fixed nonzero Pauli the observed normalizer-minus-stabilizer frequencies were \(2/5\) and \(4/21\), exactly (11). Every enumerated code had equal Bob/Eve recovery-pattern probabilities and no simultaneous recovery. The RLD counterexample at \(t=1/2\) gave SLD values \(1\) and \(3/4\), and BKM output coefficient \(0.8239592165\ldots<1\). These finite checks test formulas and conventions; the proofs above, not the enumeration, establish the unrestricted statements.

**Closest primary precedents.**

* Hirche's October 2026 paper already proves the variable-dimension erasure-assisted private-information converse. The fixed qubit reduction here is the proposed additional refinement.
* Smith–Yard already proves (19), not the fixed qubit replacement. This report uses that theorem and supplies all entropy and coding steps needed for (22).
* Smith's [Private classical capacity with a symmetric side channel and its application to quantum cryptography](https://arxiv.org/html/0705.3838) and Smith–Smolin–Winter's [The quantum capacity with symmetric side channels](https://arxiv.org/html/quant-ph/0607039) establish the broader symmetric-assistance framework. Their results make a bare “complete order detects useful symmetric assistance” claim insufficient for novelty.
* Hirche–Rouzé–Stilck França, [On contraction coefficients, partial orders and approximation of capacities for quantum channels](https://arxiv.org/html/2011.05949v3), establishes complete-order equivalences and tensorization in the existing comparison framework. The RE/ensemble and tensorization arguments above are standard ingredients, not claimed discoveries.
* Tikku–Berta–Renes supplies the designated quantum wiretap framework and single-letter capacity for quantum-input/two-classical-output broadcasts. Section 6.3 gives the specific zero-capacity argument directly.

**What is established here independently of Dots.** The stabilizer replacement lemma, fixed-qubit private characterization (17), and genuine-channel quantum characterization (22) have complete finite-dimensional proofs above, conditional only on established coding theorems and standard exact quantum error correction. Full-complement hypotheses are explicit. The antidegradability obstruction (33), metric-bridge counterexample, and explicit rational general-channel complete-\(D_2\)-versus-SLD separation (35a)–(36) are exact.

**What is conditional on Dots.** RE/coRE completeness of designated-output private superactivation, its individual-zero-capacity promise, and the fixed-error obstruction for \(P_{\rm free}\) require the manuscript's reduction or normalized-margin theorem as identified. The equal physical marginal in its Section 13 follows directly from the displayed states; it does not add a new source premise.

**What remains unproved.** A reduction to genuinely complementary channel pairs, ordinary quantum/private capacity undecidability, numerical uncomputability of the ordinary fixed-helper capacity, a total computable sufficient activation-blocklength bound from the POVM input, and historical priority of the fixed-helper theorem are not established. The precise missing map is (34), and preserving the constructed measurement receiver cannot supply it.

The operational interpretation is substantial: the same fixed zero-capacity qubit channel tests exactly whether complete environmental dominance holds, provided arbitrarily long codes are allowed. The conditional hardness theorem then says that, in the designated-output wiretap model, two individually useless privacy resources can have an undecidable zero-versus-positive joint capacity. The result should not be promoted to the standard complementary-channel capacity problem without the missing reduction.
