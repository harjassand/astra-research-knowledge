"""Finite falsification of measurement packing and honest fixed-carrier formulas.

This also checks the ordered-word square identity, but does not validate the
manuscript's dimension-uniform anchor or smoothing estimates.
"""

from fractions import Fraction
import json
from pathlib import Path

import numpy as np


def polynomial_coefficients(labels, index):
    result = [Fraction(1)]
    for j, label in enumerate(labels):
        if j == index:
            continue
        denominator = labels[index] - label
        updated = [Fraction(0)] * (len(result) + 1)
        for k, coefficient in enumerate(result):
            updated[k] -= coefficient * label / denominator
            updated[k + 1] += coefficient / denominator
        result = updated
    return result


def evaluate(coefficients, matrix):
    result = np.zeros_like(matrix)
    identity = np.eye(matrix.shape[0], dtype=complex)
    for coefficient in reversed(coefficients):
        result = result @ matrix + float(coefficient) * identity
    return result


def psd_sqrt(matrix):
    values, vectors = np.linalg.eigh(matrix)
    return (vectors * np.sqrt(np.maximum(values, 0))) @ vectors.conj().T


def verify_fixed_carrier():
    """Check the actual Choi/Jordan embedding, including transpose chirality."""
    sigma_x = np.array([[0, 1], [1, 0]], dtype=complex)
    sigma_y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sigma_z = np.diag([1, -1]).astype(complex)
    paulis = [sigma_x, sigma_y, sigma_z]
    identity_2 = np.eye(2, dtype=complex)
    effect_a = (identity_2 + 0.4 * sigma_y + 0.2 * sigma_z) / 2
    effect_b = (identity_2 + 0.3 * sigma_x - 0.2 * sigma_y) / 2

    def pack(effects):
        label_matrix = np.kron(np.diag([0, 1 / 3, 2 / 3]), identity_2)
        star_matrix = np.zeros((6, 6), dtype=complex)
        for index, effect in enumerate(effects, start=1):
            root = psd_sqrt(effect) / 2
            star_matrix[index * 2 : (index + 1) * 2, :2] = root
            star_matrix[:2, index * 2 : (index + 1) * 2] = root
        identity = np.eye(6, dtype=complex)
        return [(identity + label_matrix) / 4, (identity + star_matrix) / 4, (2 * identity - label_matrix - star_matrix) / 4]

    payload_a = pack([effect_a, identity_2 - effect_a])
    payload_b = pack([effect_b, identity_2 - effect_b])
    n = m = 12

    def choi(payloads):
        result = np.zeros((6 * n, 6 * n), dtype=complex)
        for u in range(2):
            for v in range(2):
                output_pauli_unit = np.zeros((2, 2), dtype=complex)
                output_pauli_unit[u, v] = 1
                for g in range(3):
                    physical_unit = np.zeros((6, 6), dtype=complex)
                    physical_unit[3 * u + g, 3 * v + g] = 1
                    result += np.kron(physical_unit, np.kron(output_pauli_unit, payloads[g]))
        return result

    baseline_r = choi(payload_a)
    baseline_s = choi(payload_b).T
    identity_6 = np.eye(6, dtype=complex)
    identity_nm = np.eye(n * m, dtype=complex)

    def partial(base, effect, size):
        return np.einsum("pq,qrpc->rc", effect, base.reshape(6, size, 6, size))

    def centered(base_r, base_s, effect):
        left = partial(base_r, effect, n)
        right = partial(base_s, effect, m).T
        # The two Choi identity marginals give D = 2 I exactly.
        denominator = np.kron(left, np.eye(m)) + np.kron(np.eye(n), right)
        return 2 * (denominator - identity_nm)

    physical_effects = {}
    centered_letters = {}
    for i, pauli in enumerate(paulis):
        effect = (identity_6 + np.kron(pauli, np.eye(3)) / 2) / 2
        physical_effects[i] = effect
        centered_letters[i] = centered(baseline_r, baseline_s, effect)
        for g in range(2):
            label = np.zeros((3, 3), dtype=complex)
            label[g, g] = 1
            effect = (identity_6 + np.kron(pauli, label) / 2) / 2
            physical_effects[i, g] = effect
            centered_letters[i, g] = centered(baseline_r, baseline_s, effect)

    tx, ty, tz = (centered_letters[i] for i in range(3))
    anchor_commutator = tx @ ty - ty @ tx
    left_anchor = tz + 1j * anchor_commutator
    right_anchor = tz - 1j * anchor_commutator
    worst_extractor_error = 0.0
    for g in range(2):
        tyg = centered_letters[1, g]
        tzg = centered_letters[2, g]
        mixed_commutator = tx @ tyg - tyg @ tx
        left_payload = tzg + 1j * mixed_commutator
        right_payload = tzg - 1j * mixed_commutator
        p = (left_anchor @ left_payload + left_payload @ left_anchor) / 2
        q = (right_anchor @ right_payload + right_payload @ right_anchor) / 2
        expected_p = np.kron(np.kron(identity_2, payload_a[g]), np.eye(m))
        expected_q = np.kron(np.eye(n), np.kron(identity_2, payload_b[g]))
        worst_extractor_error = max(worst_extractor_error, float(np.linalg.norm(p - expected_p, 2)), float(np.linalg.norm(q - expected_q, 2)))

    epsilon = 0.01
    faithful_r = (1 - epsilon) * baseline_r + epsilon * np.kron(identity_6 / 6, np.eye(n))
    faithful_s = (1 - epsilon) * baseline_s + epsilon * np.kron(identity_6 / 6, np.eye(m))
    worst_regularization_error = 0.0
    for key, effect in physical_effects.items():
        regularized = centered(faithful_r, faithful_s, effect)
        worst_regularization_error = max(worst_regularization_error, float(np.linalg.norm(regularized - (1 - epsilon) * centered_letters[key], 2)))

    result = {
        "physical_dimension": 6,
        "fixed_effect_count": len(physical_effects),
        "left_reference_dimension": n,
        "right_reference_dimension": m,
        "maximum_honest_extractor_error": worst_extractor_error,
        "maximum_centered_letter_regularization_error": worst_regularization_error,
        "minimum_regularized_baseline_eigenvalue": min(float(np.linalg.eigvalsh(faithful_r)[0]), float(np.linalg.eigvalsh(faithful_s)[0])),
    }
    assert worst_extractor_error < 1e-10, result
    assert worst_regularization_error < 1e-10, result
    return result


def verify_word_compiler():
    """Check noncommuting marginal congruence and ordered suffix orientation."""
    rng = np.random.default_rng(20261012)
    square_error = congruence_error = graph_error = kernel_error = 0.0
    minimum_penalty_slack = float("inf")
    words = [(), (0,), (1,), (0, 1), (1, 0), (0, 1, 0)]
    coefficients = {(): 0.5, (0,): 0.2, (1,): -0.3, (0, 1): 0.2 + 0.1j, (1, 0): 0.2 - 0.1j, (0, 1, 0): -0.1}
    word_index = {word: j for j, word in enumerate(words)}
    graph_size = len(words)
    root_matrix = np.zeros((graph_size, graph_size), dtype=complex)
    root_matrix[0, 0] = coefficients[()]
    for word in words[1:]:
        index = word_index[word]
        root_matrix[0, index] = coefficients[word] / 2
        root_matrix[index, 0] = coefficients[word].conjugate() / 2

    for instance in range(30):
        dimension = 2 + instance % 2
        raw = rng.standard_normal((dimension, dimension)) + 1j * rng.standard_normal((dimension, dimension))
        denominator = raw @ raw.conj().T + 0.1 * np.eye(dimension)
        root = psd_sqrt(denominator)
        inverse_denominator = np.linalg.inv(denominator)
        letters = []
        for _ in range(2):
            raw = rng.standard_normal((dimension, dimension)) + 1j * rng.standard_normal((dimension, dimension))
            unitary, _ = np.linalg.qr(raw)
            letters.append((unitary * rng.uniform(0.25, 0.75, dimension)) @ unitary.conj().T)

        vectors = rng.standard_normal((graph_size, dimension)) + 1j * rng.standard_normal((graph_size, dimension))
        coefficient_0 = root_matrix.copy()
        coefficient_plus = [np.zeros_like(root_matrix) for _ in letters]
        coefficient_minus = [np.zeros_like(root_matrix) for _ in letters]
        penalty_scale = 0.7
        expected_penalty = 0.0
        for word in words[1:]:
            letter_index, suffix = word[0], word[1:]
            v, w = word_index[word], word_index[suffix]
            letter = letters[letter_index]
            base = root @ letter @ root
            complement = denominator - base
            u_v, u_w = root @ vectors[v], root @ vectors[w]
            residual = vectors[v] - letter @ vectors[w]
            lhs = np.vdot(u_v, np.linalg.solve(base, u_v)) + np.vdot(u_w - u_v, np.linalg.solve(complement, u_w - u_v)) - np.vdot(u_w, inverse_denominator @ u_w)
            rhs = np.vdot(residual, np.linalg.solve(letter @ (np.eye(dimension) - letter), residual))
            square_error = max(square_error, float(abs(lhs - rhs)))
            minimum_penalty_slack = min(minimum_penalty_slack, float(rhs.real - 4 * np.vdot(residual, residual).real))
            congruence_error = max(congruence_error, float(np.linalg.norm(root @ np.linalg.inv(base) @ root - np.linalg.inv(letter), 2)))
            expected_penalty += penalty_scale * rhs.real

            e_v = np.eye(graph_size, dtype=complex)[:, v]
            e_w = np.eye(graph_size, dtype=complex)[:, w]
            coefficient_0 -= penalty_scale * np.outer(e_w, e_w.conj())
            coefficient_plus[letter_index] += penalty_scale * np.outer(e_v, e_v.conj())
            coefficient_minus[letter_index] += penalty_scale * np.outer(e_w - e_v, (e_w - e_v).conj())

        kernel = np.kron(coefficient_0, inverse_denominator)
        for j, letter in enumerate(letters):
            base = root @ letter @ root
            kernel += np.kron(coefficient_plus[j], np.linalg.inv(base)) + np.kron(coefficient_minus[j], np.linalg.inv(denominator - base))
        u = np.concatenate([root @ vector for vector in vectors])
        expected_root_form = np.vdot(vectors.reshape(-1), np.kron(root_matrix, np.eye(dimension)) @ vectors.reshape(-1)).real
        kernel_error = max(kernel_error, float(abs(np.vdot(u, kernel @ u).real - expected_root_form - expected_penalty)))

        xi = rng.standard_normal(dimension) + 1j * rng.standard_normal(dimension)
        exact_graph = []
        polynomial = np.zeros((dimension, dimension), dtype=complex)
        for word in words:
            word_matrix = np.eye(dimension, dtype=complex)
            for letter_index in word:
                word_matrix = word_matrix @ letters[letter_index]
            exact_graph.append(word_matrix @ xi)
            polynomial += coefficients[word] * word_matrix
        exact_graph = np.concatenate(exact_graph)
        graph_error = max(graph_error, float(abs(np.vdot(exact_graph, np.kron(root_matrix, np.eye(dimension)) @ exact_graph) - np.vdot(xi, polynomial @ xi))))

    result = {
        "instances": 30,
        "maximum_square_completion_error": square_error,
        "maximum_inverse_normalization_error": congruence_error,
        "maximum_ordered_root_graph_error": graph_error,
        "maximum_full_kernel_form_error": kernel_error,
        "minimum_penalty_slack_over_four_times_residual": minimum_penalty_slack,
    }
    assert max(square_error, congruence_error, graph_error, kernel_error) < 1e-8, result
    assert minimum_penalty_slack > -1e-9, result
    return result


def run():
    rng = np.random.default_rng(20261011)
    worst_identity_error = 0.0
    worst_question_error = 0.0
    smallest_payload_eigenvalue = 1.0
    max_star_norm = 0.0
    count = 0
    for dimension, question_count, answer_count in [(2, 2, 2), (3, 2, 3), (2, 3, 2)]:
        payload_count = question_count * answer_count
        labels = [Fraction(j, payload_count + 1) for j in range(payload_count + 1)]
        for _ in range(10):
            effects = []
            for _question in range(question_count):
                matrices = []
                for _answer in range(answer_count):
                    raw = rng.standard_normal((dimension, dimension)) + 1j * rng.standard_normal((dimension, dimension))
                    matrices.append(raw @ raw.conj().T)
                total = sum(matrices)
                values, vectors = np.linalg.eigh(total)
                inverse_root = (vectors * values ** (-0.5)) @ vectors.conj().T
                effects.extend(inverse_root @ matrix @ inverse_root for matrix in matrices)

            packed_dimension = (payload_count + 1) * dimension
            label_matrix = np.kron(np.diag([float(label) for label in labels]), np.eye(dimension)).astype(complex)
            star_matrix = np.zeros((packed_dimension, packed_dimension), dtype=complex)
            for index, effect in enumerate(effects, start=1):
                root = psd_sqrt(effect) / payload_count
                star_matrix[index * dimension : (index + 1) * dimension, :dimension] = root
                star_matrix[:dimension, index * dimension : (index + 1) * dimension] = root

            identity = np.eye(packed_dimension, dtype=complex)
            payloads = [(identity + label_matrix) / 4, (identity + star_matrix) / 4, (2 * identity - label_matrix - star_matrix) / 4]
            smallest_payload_eigenvalue = min(smallest_payload_eigenvalue, *(float(np.linalg.eigvalsh(payload)[0]) for payload in payloads))
            max_star_norm = max(max_star_norm, float(np.linalg.norm(star_matrix, 2)))

            root_selector = evaluate(polynomial_coefficients(labels, 0), label_matrix)
            decoded = []
            for index, effect in enumerate(effects, start=1):
                selector = evaluate(polynomial_coefficients(labels, index), label_matrix)
                decoder = payload_count * selector @ star_matrix @ root_selector
                unpacked = decoder.conj().T @ decoder
                expected = np.zeros_like(unpacked)
                expected[:dimension, :dimension] = effect
                worst_identity_error = max(worst_identity_error, float(np.linalg.norm(unpacked - expected, 2)))
                decoded.append(unpacked)

            for question in range(question_count):
                total = sum(decoded[question * answer_count : (question + 1) * answer_count])
                worst_question_error = max(worst_question_error, float(np.linalg.norm(total - root_selector, 2)))
            count += 1

    result = {
        "status": "finite_falsification_only",
        "seed": 20261011,
        "instances": count,
        "worst_packing_operator_norm_error": worst_identity_error,
        "worst_question_sum_operator_norm_error": worst_question_error,
        "minimum_three_outcome_payload_eigenvalue": smallest_payload_eigenvalue,
        "maximum_star_operator_norm": max_star_norm,
        "assertion_tolerance": 1e-7,
        "fixed_carrier_falsification": verify_fixed_carrier(),
        "word_compiler_falsification": verify_word_compiler(),
    }
    assert worst_identity_error < 1e-7, result
    assert worst_question_error < 1e-7, result
    assert smallest_payload_eigenvalue > -1e-12, result
    assert max_star_norm <= 1 + 1e-12, result
    destination = Path(__file__).with_name("sol04_packing_falsification.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run()
