# Primary-source audit: the Petz-α=2 / RLD channel order

**Scope and date.** Focused primary-source check, 11 October 2026. The target is the complete pairwise preorder for two channels with common input: for every finite untouched reference, every faithful reference-input state ρ, and every traceless Hermitian tangent H, compare the RLD quadratic forms of the two channel outputs. Equivalently, compare standard Petz order-two divergences on every input state pair, with the same channel applied separately to both members of each pair. This is not a comparison of one channel family at one parameter value.

## Priority disposition

I found **no matching primary-source theorem** giving a finite reference-dimension cutoff for this complete pairwise RLD/Petz-α=2 preorder. The closest sources establish the RLD metric, optimize RLD information for a fixed differentiable channel family, compare statistical models through all decision tests, or optimize a divergence between two channels on one shared probe. None states the target two-channel all-pairs predicate or the bound

\[
\dim R\le 1+b^2,
\]

where b is the effective target-output dimension; for a target POVM channel with v nonzero outcomes, the sharper proposed bound is \(1+v\). The exact cutoff and its compression proof are in [`rld_finite_cutoff.md`](rld_finite_cutoff.md); that is an internally reconstructed argument and has not received independent external proof review. The literature check supports “no matching result located in this focused search,” not an absolute priority or novelty claim.

The endpoint is standardly RLD: Petz–Sudár’s classification identifies the largest monotone metric with the RLD metric; in their notation the harmonic operator mean gives \(g_D^{RL}(H,H)=\operatorname{Tr}D^{-1}H^2\) (Theorems 3.1–3.2 and Eq. (12) in [their accessible preprint](https://arxiv.org/abs/quant-ph/0102132); the related published *Geometries of quantum states* is [J. Math. Phys. 37 (1996), 2662–2673, DOI 10.1063/1.531535](https://doi.org/10.1063/1.531535)). Standard Petz–Rényi divergence is \(D_\alpha(\rho\|\sigma)=(\alpha-1)^{-1}\log\operatorname{Tr}\rho^\alpha\sigma^{1-\alpha}\); Morgan–Wilde give this as Eq. (111) and its DPI at \(0<\alpha\le2\) as Eq. (112) in [*Entropy of a quantum channel*, arXiv:1808.06980](https://arxiv.org/abs/1808.06980). At \(\alpha=2\), direct expansion for faithful \(\sigma\) and Hermitian traceless H gives

\[
\operatorname{Tr}(\sigma+H)^2\sigma^{-1}
=1+\operatorname{Tr}H\sigma^{-1}H.
\]

The same identity holds after applying either trace-preserving channel, including every extension by an untouched reference. Thus the pairwise Petz-α=2 comparison and RLD quadratic comparison are exactly equivalent on faithful pairs; this is an algebraic identity, not a limiting Hessian claim. (The RLD formula appears explicitly in Petz–Sudár, Theorem 3.2 / Eq. (12) of the preprint.)

## Nearest results and why they do not subsume the cutoff

1. **Channel RLD estimation is a fixed-model optimization.** Hayashi’s Theorem 1 in [*Comparison between the Cramer-Rao and the mini-max approaches in quantum channel estimation*, arXiv:1003.4575](https://arxiv.org/abs/1003.4575) gives a Choi expression for the maximal RLD Fisher information of a differentiable one-parameter channel family \(\{\Lambda_\theta\}\). Katariya–Wilde define the RLD channel Fisher value for a differentiable family in Eqs. (10)–(11), express it in Choi form in Proposition 3, and use it for a sequential Cramér–Rao bound in Theorem 8 of [arXiv:2008.11178](https://arxiv.org/abs/2008.11178). Their reference/probe can be chosen isomorphic to the channel input. These are optimizations over probes for a *given parameterized family and tangent*. They do not compare two arbitrary channels at every base state, tangent, input pair, and reference.

2. **Channel divergence asks a different question.** Koßmann–Wilde define Umegaki channel relative entropy by
   \(D(P\|Q)=\sup_{\rho_{AR}}D(P(\rho_{AR})\|Q(\rho_{AR}))\)
   (Eq. (15)) in [*Semidefinite optimization of the quantum relative entropy of channels*, arXiv:2410.16362](https://arxiv.org/abs/2410.16362). It tests the two channels on the *same single probe state* and compares their outputs. The target order here instead compares \(D_2(P(\rho)\|P(\sigma))\) to \(D_2(Q(\rho)\|Q(\sigma))\) for every pair \((\rho,\sigma)\); it is a relation between two data-processing actions, not their channel-discrimination divergence.

3. **Max-relative entropy of channels is CP domination.** Saxena–Chitambar–Gour define \(D_{\max}(P\|Q)=\log\inf\{t:tQ\succeq P\}\) for CP maps, where \(tQ-P\) must itself be CP, and rewrite it as Choi operator domination in Eqs. (40)–(41) of [*Dynamical resource theory of quantum coherence*, Phys. Rev. Research 2, 023298 (2020)](https://doi.org/10.1103/PhysRevResearch.2.023298). This map-order quantity is not Petz order two on output state pairs.

4. **Channel simulation is a supermap conversion task.** Fang–Wang–Tomamichel–Berta define simulation of a target channel from a resource channel by an allowed supermap/code and diamond-norm error; their Proposition 1 gives an SDP for a specified assisted-code class in [*Quantum Channel Simulation and the Channel’s Smooth Max-Information*, arXiv:1807.05354](https://arxiv.org/abs/1807.05354). This optimizes a conversion protocol and its simulation error. It does not ask whether one channel contracts every state-pair Petz-α=2 divergence at least as much as another.

5. **Quantum Blackwell tests compare all decision tasks.** Buscemi’s Proposition 6 in [*Comparison of quantum statistical models: equivalent conditions for sufficiency*, arXiv:1004.3794](https://arxiv.org/abs/1004.3794) characterizes comparison of quantum information structures by a maximally entangled auxiliary system whose two dimensions equal the target output dimension. This is a finite test for the all-decision/statistical-morphism comparison in that proposition, not a test for ordering one fixed divergence or metric on every state pair. Its ancilla bound cannot be transferred to the RLD preorder without a theorem identifying those predicates.

6. **The complete less-noisy framework is an α=1 near-match.** Hirche–Rouzé–Stilck França identify complete less-noisy comparison with Umegaki relative-entropy comparison under arbitrary finite quantum references (Proposition 2.3) and prove tensorization (Lemma 3.1) in [*On contraction coefficients, partial orders and approximation of capacities for quantum channels*, *Quantum* 6, 862 (2022), arXiv:2011.05949](https://arxiv.org/abs/2011.05949). They remark in §2.1 that no restriction on the quantum reference dimension was known for that order. This does not contradict the order-two cutoff: it concerns Umegaki/complete less-noisy order, which is a different divergence and whose reference need not obey the endpoint compression argument.

## Relation to the SLD undecidability claim

The finite cutoff is compatible with the manuscript’s proposed complete SLD undecidability result. SLD and RLD are distinct monotone metrics (the SLD is the minimal and RLD the maximal endpoint in Petz–Sudár’s classification); the exact Petz-α=2 quadratic identity uses the inverse kernel and does not extend to the SLD kernel by substitution. The manuscript’s asserted coRE-hardness for complete SLD order therefore is not subsumed or contradicted by a decidable RLD endpoint. If its hardness theorem is valid, decidability at α=2 yields a strict separation from complete SLD order on that rational POVM class. That separation is conditional on the manuscript reduction; this priority note does not certify the reduction.

The finite references in channel estimation, channel-divergence, or all-decision theorems are therefore not counterexamples to the manuscript’s unbounded-reference SLD statement. Each has a different quantified property. Conversely, the endpoint cutoff does not imply finite cutoffs for \(0<\alpha<2\).

## Search record

I searched primary-source records and papers for “complete RLD channel order,” “RLD Fisher information order for channels reference dimension,” “Petz Rényi order two channel comparison finite ancilla,” and “quantum Fisher information ordering channels all states”; I then checked the theorem/equation statements listed above. No theorem matching the complete pairwise predicate with cutoff \(1+b^2\), or the POVM refinement \(1+v\), was located. Search-engine coverage is imperfect, so the defensible conclusion remains a targeted negative search result rather than a proof of priority.
