# Fixed-order Petz Rényi comparison and complete SLD order

## Verdict

For each fixed α in (0,2) with α ≠ 1, the saturated-reference Hessian argument proves

complete Petz–Rényi-α order  ⇒  complete SLD order.

The converse also follows from the manuscript’s Section 2.1: complete SLD order compares every Petz f_s quasi-entropy, and a positive integral representation expresses the signed Petz Rényi overlap through those f_s quantities. Thus, with the standard extended-value support conventions, the complete orders coincide for each fixed α in (0,2)\{1}. At α=1 the Petz Rényi divergence is Umegaki relative entropy, and Sections 2.1–2.3 already prove the equivalence with SLD order.

There is one concrete endpoint failure in the proposed single formula: at α=1, q=0, so −sgn(q)=0 and |sin(πq)|=0. The stated signed overlap is identically zero and its Hessian cannot recover SLD information. Treat α=1 separately by the manuscript’s Umegaki argument. The open endpoints α=0 and α=2 are also outside the proof; the integral representations degenerate there.

The α ≠ 1 Hessian identity is correct. One technical point needs an explicit sentence in a proof: for q<0, the filter test function is unbounded at zero, so weak concentration alone does not justify the limit. The beta-prime filter has uniformly bounded negative moments, which supplies the missing uniform-integrability step.

## Forward implication: Petz Rényi order implies SLD order

Fix a finite original reference and a faithful input state ρ with traceless Hermitian tangent H. Absorb the original reference into the input and channel notation. For either channel Φ, set A=Φ(ρ) and K=Φ(H), restricting to the fixed output support. Since ρ is positive definite, there is c<∞ with −cρ≤H≤cρ. Positivity of Φ gives −cA≤K≤cA, so K is supported in supp(A); also A is positive definite on supp(Φ(I)).

Choose a finite auxiliary reference with a centre vector e₀ and leaves. Let W=diag(1,W_leaf)>0, Z=Tr W, let τ=vv* be a rank-one leaf-supported state with ||v||=1, and set L=|e₀⟩⟨w|+|w⟩⟨e₀| for a leaf vector w. Then Tr L=0. For small positive and negative ε, the states

α_in = ρ⊗τ,
β_in(ε) = (ρ⊗W + ε H⊗L)/Z

are valid: the trace is one and the denominator is positive because ρ⊗W is positive definite. Their channel outputs are A⊗τ and (A⊗W+εK⊗L)/Z. The latter stays positive definite on supp(A)⊗the auxiliary space for sufficiently small |ε|.

Write q=1−α and TΦ(ε)=Tr[(A⊗τ)^α ((A⊗W+εK⊗L)/Z)^q]. For α<1, Petz divergence comparison Dα(P)≥Dα(Q) is equivalent to T_P≤T_Q; for α>1 it is equivalent to T_P≥T_Q. Both cases are captured by JΦ(ε)=−sgn(q)TΦ(ε): the assumed order gives J_P(ε)−J_Q(ε)≥0.

At ε=0,
TΦ(0) = Tr(A^{α+q}) · Z^(−q) · Tr(τW^q)
       = Z^(−q) ⟨v,W^qv⟩,
because α+q=1 and Tr A=1. This is independent of Φ. Hence J_P(0)=J_Q(0). The difference has a local minimum at ε=0, so its second derivative is nonnegative.

For q in (0,1), the scalar resolvent identity
x^q = (sin(πq)/π) ∫₀∞ t^(q−1) x/(x+t) dt
gives
D²(B^q)[Y,Y] = −(2 sin(πq)/π) ∫₀∞ t^q R_t Y R_t Y R_t dt,
where R_t=(B+tI)^(−1). For q in (−1,0),
x^q = (−sin(πq)/π) ∫₀∞ t^q/(x+t) dt
gives the same expression with positive sign and coefficient 2|sin(πq)|/π. Multiplication by −sgn(q) makes the signed-overlap Hessian positive in both cases.

Take B=A⊗W and Y=K⊗L. In an eigenbasis of A, write A|i⟩=a_i|i⟩. The rank-two form of L forces the auxiliary path to go from a leaf to the centre and back. With F(t)=w*(W_leaf+tI)^(−1)v, the exact contraction is

⟨v|R_i^leaf L R_j L R_i^leaf|v⟩ = |F(t/a_i)|² / (a_i²(a_j+t)),

where R_i^leaf=(a_iW_leaf+tI)^(−1) and R_j=(a_jW+tI)^(−1).

After t=a_i s, the powers of a_i cancel since α+q=1. Therefore, for every fixed q∈(−1,1)\{0},

JΦ''(0) = (2|sin(πq)|/π) Z^(−q)
          Σᵢⱼ |Kᵢⱼ|² ∫₀∞ s^q |F(s)|²/(aⱼ+aᵢs) ds.

This confirms the proposed sign, factor, Z normalization, and ordered indices. The expression is nonnegative. Near zero its integrand is O(s^q), which is integrable because q>−1; at infinity F(s)=O(s^(−1)), so the integrand is O(s^(q−3)).

For the finite filters, take λ_k=1+k/m³ for k=0,…,2m and
F_m(t)=t^m/∏ₖ(t+λ_k), with I_m=∫₀∞F_m(t)²dt.
The normalized measures μ_m(dt)=F_m(t)²dt/I_m converge to a point mass at 1. For q≥0, t^q/(aⱼ+aᵢt) is bounded and continuous, so

I_m^(−1) ∫₀∞ t^q F_m(t)²/(aⱼ+aᵢt) dt → 1/(aᵢ+aⱼ).

For q=−r∈(−1,0), the test function is unbounded at zero. Put f_m(t)=t^m/(1+t)^(2m+1). The density proportional to f_m² is beta-prime with parameters (2m+1,2m+1), and
E[T^(−2r)] = B(2m+1−2r,2m+1+2r)/B(2m+1,2m+1),
which is finite for m≥1 and remains bounded as m→∞. Also F_m/f_m is bounded above by 1 and below by exp(−2/m−1/m²), so μ_m is uniformly comparable to that beta-prime law. Since μ_m concentrates at 1, Cauchy–Schwarz gives
Eμm[T^(−r) 1_{|T−1|≥δ}] → 0
for every δ>0. This proves the same kernel limit for q<0.

Divide the second-derivative comparison by the common positive factor
(|sin(πq)|/π) Z^(−q) I_m.
The factor may depend on m, but is identical for both channels and is positive for every fixed q≠0. The normalized kernel limit contributes 2/(aᵢ+aⱼ), so the limit gives

Σᵢⱼ 2|(K_P)ᵢⱼ|²/(aᵢ+aⱼ)
≥
Σᵢⱼ 2|(K_Q)ᵢⱼ|²/(bᵢ+bⱼ),

which is precisely g_{P(ρ)}(P(H))≥g_{Q(ρ)}(Q(H)). The original reference was arbitrary and the auxiliary reference is finite, so this is complete SLD order.

## Converse: SLD order implies fixed Petz Rényi order

For α∈(0,2), let
f_s(x)=(x−1)²/(x+s), s>0,
and let Bα=B(α+1,2−α). Direct differentiation gives f_s''(x)=2(s+1)²/(x+s)³ and

sgn(α−1)[x^α−1−α(x−1)]
= [α|α−1|/Bα] ∫₀∞ [s^α/(1+s)²] f_s(x) ds
for α≠1.

To check the constant, the second derivative of the integral is
2∫₀∞s^α/(x+s)³ ds = Bα x^(α−2);
both sides and their first derivatives vanish at x=1. The weight is positive and integrable for 0<α<2.

For positive definite states A,B, apply this identity to the relative modular operator Δ=L_A R_(B^(−1)) and take the quadratic form at B^(1/2). The affine terms cancel because Tr A=Tr B=1. This yields

sgn(α−1)[Tr(A^α B^(1−α))−1]
= [α|α−1|/Bα] ∫₀∞ [s^α/(1+s)²] D_f_s(A||B) ds.

Section 2.1 shows that complete SLD order compares D_f_s for every s>0, using the auxiliary-qubit identity. Integrating the nonnegative differences gives
sgn(α−1)[T_P−T_Q]≥0.
Since −sgn(q)=sgn(α−1), this is exactly the signed-overlap order. Monotonicity of log, with the sign of 1/(α−1), converts it to Dα(Pρ||Pσ)≥Dα(Qρ||Qσ).

For boundary states, split by support. When α>1 and supp(A) is not contained in supp(B), the Petz divergence is +∞. Complete Umegaki order rules out finite P divergence with infinite Q divergence: infinite Q relative entropy forces infinite P relative entropy, hence the required Petz support failure on the P side as well. In the finite case, restrict to supp(B) and use faithful approximation there. For 0<α<1, powers are continuous at zero; common faithful regularization and finite-dimensional limits extend the formula. Do not apply B^(−1) on a kernel without this support reduction.

## Endpoint and scope

- α=1: the proposed signed-overlap Hessian has zero prefactor and is vacuous. The divergence itself is the Umegaki limit; use Sections 2.1–2.3, whose log-resolvent Hessian has a nonzero SLD limit.
- α=0 or α=2: excluded. The sine prefactor vanishes and the q=−1 integral has a nonintegrable zero-end behavior at α=2. This argument makes no endpoint claim.
- The saturated-reference direction uses only faithful base ρ and traceless Hermitian H; rank deficiency is confined to the auxiliary numerator τ. If the Petz-order hypothesis is stated only for faithful input pairs, replace τ by τζ=(1−ζ)τ+ζI/(N+1), apply the order, and let ζ↓0. The denominator remains positive on the fixed output support, and finite-dimensional power continuity for α>0 gives the rank-one formula in the limit.
- The identity maps act as identity on every pre-existing reference, so A and K may be arbitrary noncommuting output matrices. Diagonalizing A is only a basis choice; no simultaneous diagonalization with K is assumed.
- The argument proves equality of the complete fixed-order preorders for α∈(0,2), interpreting α=1 as Umegaki. It does not cover Petz orders at α=0 or α=2, the sandwiched Rényi divergence, or orders restricted to equal reference marginals.

## Changes needed before using the claim

State explicitly that the displayed Hessian formula is for α≠1. Add the negative-q uniform-integrability argument (or an equivalent tail bound) after the filter concentration lemma. State the support convention for q<0 and the faithful-numerator regularization if the order is defined only on faithful pairs. With these clarifications, the fixed-order collapse is valid on the claimed open interval, with α=1 supplied by the existing Umegaki proof.

## Final adversarial audit of `root_universality.tex` (Theorem 1 and Hessian H)

I independently checked the general-generator localization argument requested by root. I found no fatal error in Theorem 1, the saturated-reference Hessian, or its limits. The displayed Hessian coefficient is exact:

\[
2p^2Z\frac{(1+s)^2}{s^3}|F(pZ/s)|^2
\sum_{ij}\frac{|K_{ij}|^2}{a_i pZ/s+a_jw_0}.
\]

To verify the normalization, put `r=pa_i` in the perspective resolvent formula. Twice differentiating the inverse contributes `2(s+1)^2r^2`; the two factors of `Y=K⊗L/Z` contribute `Z^{-2}`; each exterior leaf resolvent contributes `Z/(sa_i)` times the corresponding factor in `F`; and the middle centre resolvent is `(Z/s)/(a_i pZ/s+a_jw_0)`. Multiplying gives exactly the coefficient above, with ordered system indices `|K_ij|^2` and no missing factor of two.

For the quadratic generator, the only nonzero numerator-supported Hessian paths start at a leaf vector `v`, visit the centre through `L`, then return to the leaf. Their amplitude contains `F(0)=w^*W_leaf^{-1}v`; hence `F_m(0)=0` makes the quadratic Hessian zero for each channel separately. The dummy numerator eigenspace is killed by `L`, and zero numerator eigenspaces have zero quadratic weight.

The choice `p_m=c_0/Z_m` is valid for all sufficiently large `m` because `Z_m→∞`, and gives the exact identity `p_m Z_m=c_0`. This is essential: the filter is sampled at the fixed point `c_0/s`, independent of `m`, while the Hessian's remaining `2p_m^2Z_m` is a common strictly positive scalar for each finite `m` and may safely be divided out.

The localization measure is finite. Under `t=c_0/s`, its weight
`(1+s)^2/[s^3(t+w_0)^2]` is `O(1/s)` both as `s↓0` and `s→∞`; the two stated integrability assumptions on `ν` cover these tails. Its support contains `w_0`, since `s_0` is in the support of `ν` and the weight is strictly positive. The reference filter satisfies

\[
F_m(t)/f_m(t)=\prod_{j=0}^{2m}\frac{t+w_0}{t+w_0(1+j/m^3)},\qquad
e^{-2/m-1/m^2}\leq F_m(t)/f_m(t)\leq1,
\]

where `f_m(t)=t^m/(t+w_0)^{2m+1}`; the lower bound follows from `log(1+x)≤x` and `sum_j j/m^3=2/m+1/m^2`. Therefore the normalized filter measures are uniformly equivalent, with ratio tending uniformly to one, to the measures proportional to `h(t)^{2m}dμ(t)`. The unique maximum of `h(t)=4w_0t/(t+w_0)^2` is at `w_0`; finite μ-mass in every neighborhood of this support point proves concentration there even when ν is singular or has no atom at `s_0`.

For each fixed filter instance, the nonzero numerator eigenvalues are bounded away from zero and the output denominator is positive definite on the fixed channel support. The Hessian integrand is `O(1)` as `s↓0` and `O(1/s)` as `s→∞`, hence is dominated by `C/(1+s)` after adjusting the finite-instance constant. This justifies differentiating the ν integral. The numerator's auxiliary factor `τ_p` is singular, but no unsupported Hessian-limit interchange is necessary: first replace it by a faithful mixture, apply the assumed order for every ε near zero, then pass the divergence inequality pointwise to the singular numerator using `f(0+)<∞` and the fixed faithful denominator. The resulting difference is nonnegative near zero and equals zero at zero. Its second derivative exists by the resolvent representation; zero numerator eigenspaces contribute only a term linear in the denominator, while positive eigenvalues use the bound above. Thus its Hessian is nonnegative as claimed.

Finally, after dividing the Hessian inequality by its common positive mass, the concentration limit of the actual kernel `(a_i t+a_jw_0)^{-1}` at `t=w_0` is `1/[w_0(a_i+a_j)]`. Consequently the limit is `g_A(K)/(2w_0)`, with `g_A(K)=2∑_{ij}|K_{ij}|^2/(a_i+a_j)`. The final displayed SLD coefficient in the manuscript is correct.

The earlier scope notes remain: α=1 needs the Umegaki route, and the separate fixed-α filter argument for negative q needs its negative-moment uniform-integrability sentence. Those points do not undermine the general-generator proof in `root_universality.tex`.
