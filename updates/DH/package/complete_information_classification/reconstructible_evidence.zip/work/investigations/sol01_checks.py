"""Numerical falsification checks for sol01_stronger.md; not a proof certificate."""
import json
import numpy as np

rng = np.random.default_rng(20261011)


def herm(n):
    z = rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n))
    return (z + z.conj().T) / 2


def state(n):
    z = rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n))
    a = z @ z.conj().T + np.eye(n)
    return a / np.trace(a)


def ptr(a, d, n):
    return np.einsum("iaib->ab", a.reshape(d, n, d, n))


def out(effects, a, d, n):
    return [ptr(np.kron(e, np.eye(n)) @ a, d, n) for e in effects]


def score(a, h):
    v, u = np.linalg.eigh(a)
    k = u.conj().T @ h @ u
    return (np.abs(k) ** 2 * 2 / (v[:, None] + v[None, :])).sum().real


def omega_inv(a, h):
    v, u = np.linalg.eigh(a)
    k = u.conj().T @ h @ u
    return u @ (k * 2 / (v[:, None] + v[None, :])) @ u.conj().T


def logm(a):
    v, u = np.linalg.eigh(a)
    return (u * np.log(v)) @ u.conj().T


def rel(a, b):
    return np.trace(a @ (logm(a) - logm(b))).real


def fisher(es, rho, h, d, n):
    return sum(score(a, k) for a, k in zip(out(es, rho, d, n), out(es, h, d, n)))


def entropy(es, rho, sigma, d, n):
    return sum(rel(a, b) for a, b in zip(out(es, rho, d, n), out(es, sigma, d, n)))


def povm(d):
    bs = []
    for j in range(d - 1):
        b = np.zeros((d, d), complex)
        b[j, j], b[-1, -1] = 1, -1
        bs.append(b)
    for j in range(d):
        for k in range(j + 1, d):
            b = np.zeros((d, d), complex)
            b[j, k] = b[k, j] = 1
            bs.append(b)
            b = np.zeros((d, d), complex)
            b[j, k], b[k, j] = 1j, -1j
            bs.append(b)
    z = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d))
    u, _ = np.linalg.qr(z)
    bs = [u @ b @ u.conj().T for b in bs]
    return [(np.eye(d) + sign * 0.15 * b) / (2 * len(bs))
            for b in bs for sign in [-1, 1]]


errors = {k: 0.0 for k in ["gauge_trace", "gauge_conditional", "fisher_scaling",
                           "entropy_scaling", "matching_traces", "normalization"]}
trials = 0
for d in [2, 3]:
    for n in [2, 3]:
        for _ in range(12):
            trials += 1
            es, fs = povm(d), povm(d)
            rho, sigma, h = state(d * n), state(d * n), herm(d * n)
            h -= np.trace(h).real * np.eye(d * n) / (d * n)
            w, k = ptr(rho, d, n), ptr(h, d, n)
            a = omega_inv(w, k)
            z = np.kron(np.eye(d), a)
            hp = h - (rho @ z + z @ rho) / 2
            errors["gauge_trace"] = max(errors["gauge_trace"], np.linalg.norm(ptr(hp, d, n)))
            gref = score(w, k)
            ie = fisher(es, rho, h, d, n) - gref
            if_ = fisher(fs, rho, h, d, n) - gref
            errors["gauge_conditional"] = max(errors["gauge_conditional"],
                abs(ie - fisher(es, rho, hp, d, n)),
                abs(if_ - fisher(fs, rho, hp, d, n)))
            t = 0.17
            ws = [np.trace(e).real / d for e in es]
            ep = [t * e for e in es] + [(1 - t) * wi * np.eye(d) for wi in ws]
            fp = [t * f for f in fs] + [(1 - t) * f for f in fs]
            errors["fisher_scaling"] = max(errors["fisher_scaling"],
                abs(fisher(ep, rho, h, d, n) - gref - t * ie),
                abs(fisher(fp, rho, h, d, n) - gref - if_))
            dr = rel(ptr(rho, d, n), ptr(sigma, d, n))
            ue = entropy(es, rho, sigma, d, n) - dr
            uf = entropy(fs, rho, sigma, d, n) - dr
            errors["entropy_scaling"] = max(errors["entropy_scaling"],
                abs(entropy(ep, rho, sigma, d, n) - dr - t * ue),
                abs(entropy(fp, rho, sigma, d, n) - dr - uf))
            errors["matching_traces"] = max(errors["matching_traces"],
                max(abs(np.trace(e - f)) for e, f in zip(ep, fp)))
            errors["normalization"] = max(errors["normalization"],
                np.linalg.norm(sum(ep) - np.eye(d)), np.linalg.norm(sum(fp) - np.eye(d)))

result = {"seed": 20261011, "trials": trials, "max_absolute_errors": errors,
          "status": "PASS" if max(errors.values()) < 1e-8 else "FAIL",
          "scope": "Finite numerical checks of identities, not the infinite-dimensional reduction."}
print(json.dumps(result, indent=2))
