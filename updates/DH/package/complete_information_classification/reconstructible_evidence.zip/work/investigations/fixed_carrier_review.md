# Adversarial review: fixed normalized-Jordan carrier

Prepared 11 October 2026 against `work/investigations/sol04_transfer.md` (790-line version). This is a proof-scope review, not a second certification of the manuscript's analytic lemmas.

## Verdict

I found no counterexample in the fixed-alphabet packing, game-gap construction, suffix-descendant transport, or inverse-Jordan compiler as stated. Their quantifiers match the claimed operator-system reduction: one fixed six-dimensional physical algebra and nine fixed effects; all finite reference dimensions and all faithful positive baselines; a common pair of baselines for every letter in each evaluation; and growing polynomial degree and coefficient-matrix size. The resulting theorem is a **conditional coRE-hardness theorem for a fixed operator system's growing matrix cone**, not fixed-degree positivity, scalar-level positivity, or fixed-input channel-order hardness.

The condition is substantive: the transfer needs the manuscript's actual-domain representation, uniform action-norm smoothing estimate, and common local Stinespring dilation limit (transfer report (A1), (A4), and §14.4). The algebraic reduction does not prove these source lemmas. I have not independently certified those analytic steps, so the exact verdict is: *the fixed-carrier deduction appears valid conditional on those stated inputs; the unconditional fixed-carrier claim remains unproved by this review*. This is appropriate as a secondary, conservatively labeled consequence.

## Theorem and quantifier audit

The physical carrier is $\mathcal A=M_2\otimes\mathbb C^3\subset M_6$, with the nine effects in (J1). For each $n,m\ge1$, each faithful $R>0$ on $\mathbb C^6\otimes\mathbb C^n$, and each faithful $S>0$ on $\mathbb C^6\otimes\mathbb C^m$, the letters are

\[
Z_C=D^{-1/2}\big(\operatorname{Tr}_6[(C\otimes I)R]\otimes I_m
+I_n\otimes\operatorname{Tr}_6[(C\otimes I)S]^T\big)D^{-1/2},
\quad D=B_I.
\]

The same $R,S,D$ are used for all nine $C$'s. These letters satisfy $I/4\le Z_C\le3I/4$, but they are **not nine independently quantified contractions**. This distinction is central: every soundness statement is over this two-factor normalized-Jordan family, not over the full free box.

The packing step is exact and dimension-explicit. Given any finite $M$-question, $K$-answer POVM family, it uses two selfadjoint contractions $U,V$ on an enlarged local space of dimension $(MK+1)\dim H$. Rational Lagrange polynomials in $U$ isolate the label blocks, and $L_g^*L_g$ recovers the original POVM elements on the label-zero corner. The three effects $(I+U)/4,(I+V)/4,(2I-U-V)/4$ are positive and sum to $I$, without requiring $U,V$ to commute. No unknown POVM entries enter the reduction's rational coefficients; the square roots occur only in constructing an honest witness strategy.

The game reduction invokes the MIP*=RE gap $\omega^*=1$ versus $\omega^*\le1/2$. With $r=3/4,\gamma=1/4$, the transfer's soundness estimate and square penalties give $F\ge I/8$ on every actual evaluation in the low-value case. A high-value game has a finite strategy scoring above $15/16$; the packed strategy has zero descendant and normalization penalties. Faithful regularization preserves a value below $-1/8$. This uses a finite witness but no computable bound on its dimension and no perfect-strategy attainment claim.

The word-graph compiler has the right quantifiers. Its suffix-closed node set includes every supported word and every raw suffix of length at most the polynomial degree. In the telescoping identity (T3), each one-step error is applied to a raw suffix descendant, and the descendant sum (T1) includes both the suffix and its one-letter extension. Thus the smoothing estimate is only used where its energy terms are present. Degree, coefficient $\ell_1$ bounds, graph node count, and matrix size are all computable from the input and can grow without limit.

The exact inverse identity (C1) is a Schur-complement identity for one positive contraction $Z_j=B_{A_j}$ relative to $D$; it does not commute $B_{A_j}$ with $D$. Its lower bound is valid because the spectrum of $Z_j$ is contained in $[1/4,3/4]$, so $[Z_j(I-Z_j)]^{-1}\ge4I$. The compiler yields

\[
K=H_0\otimes D^{-1}+\sum_j\left(H_j^+\otimes B_{A_j}^{-1}
+H_j^-\otimes B_{I-A_j}^{-1}\right),
\qquad
(I\otimes D^{1/2})K(I\otimes D^{1/2})=X_H.
\]

The fixed operator system is the span of $I,Z_{A_j}^{-1},(I-Z_{A_j})^{-1}$, hence has dimension at most 19. Its input is a variable-size rational Hermitian matrix of coefficients $H_0,H_j^\pm\in M_d(\mathbb Q(i))$. The computable scaling in (O5) gives the promised dichotomy $X_H\ge I$ on every block versus a finite faithful block with an eigenvalue below $-1$. Thus the hardness is genuinely at complete matrix order: neither $d$, the polynomial degree, nor the word-graph residue dimension is fixed.

The coRE upper bound is also appropriately scoped. A strict negative value on a real faithful block persists under rational approximation. Rational faithful baselines can be enumerated; the congruent unnormalized kernel has rational entries and its signature is decidable. This enumerates the complement of positivity. The reduction and this enumeration therefore give coRE-completeness for rational matrix-coordinate descriptions of the fixed system.

## Free positivity, convexity, and witness bounds

There is no contradiction with the usual free Positivstellensätze. Helton–McCullough's archimedean theorem concerns positivity in the universal free *-algebra of contractions (all admissible representations): positivity is characterized by approximate sums of hermitian squares [HM04, DOI](https://doi.org/10.1090/S0002-9947-04-03433-6). Helton–Klep–McCullough's convex Positivstellensatz gives an exact degree-controlled weighted SOS certificate for a matrix polynomial positive on a free spectrahedron/free LMI domain [Theorem 1.1](https://arxiv.org/abs/1102.4859): for degree at most $2d+1$, the certificate weights have degree at most $d$ (with the theorem's monic/concavity hypotheses). Their Remark 1.2 also gives a computable test-size bound $t\le\nu\sum_{j=0}^{\lceil k/2\rceil}g^j$ for matrix coefficient size $\nu$, degree $k$, and $g$ free variables on that LMI domain. Volčič's rational [Theorem B](https://doi.org/10.1017/fms.2021.54) gives a rational quadratic-module certificate for rational functions positive on a free spectrahedron intersected with their domain. These theorems require positivity on those full free domains. The carrier proof establishes positivity only on the constrained $Z_C$'s generated by a shared pair $(R,S)$, with the two-factor normalization and its relations; it does not establish positivity on independent contractions in the containing box. No domain-preserving embedding into a free spectrahedron or free rational domain is supplied, so those certificate and size bounds do not apply.

For each input, the compiled object is indeed a matrix-valued rational expression in a fixed inverse alphabet. That is not a single fixed scalar free rational function whose positivity is decided uniformly: the coefficient-matrix order and graph grow with the instance, and the quantified evaluation family remains the normalized two-factor domain. If a computable bound $b(H)$ on sufficient reference dimensions $n,m$ were available, one could test all sizes through $b(H)$ by real-algebraic quantifier elimination, using the kernel formulation and a witness vector. That would decide the gapped coRE-hard promise. Hence no such total computable witness cutoff follows or can exist for this promised family. The physical matrix size $6$ is fixed; the reference and matrix-coefficient sizes are not.

Nor does the proof give a finite semidefinite representation of the global domain. Matrix-convex/free-spectrahedral theorems characterize or certify positivity for matrix levels of an LMI domain; they do not convert an arbitrary structured image of pairs of positive baselines into one. Fritz–Netzer–Thom's finite-realization criterion for the *maximal* matrix ordering of a scalar cone (Theorem 3.2: finite realization iff the cone is polyhedral) is a useful framework result, not a direct contradiction or a proof of hardness here. The transfer report's separate scalar-spectrum argument rules out a finite order embedding for this particular system, but that is a structural consequence of a commutative interval subsystem, not the distinctive undecidability claim.

## Prior-art boundary

The following primary results sharply limit the novelty claim.

* Mehta–Slofstra–Zhao, [Theorem 1.1](https://arxiv.org/html/2312.05617v2), prove coRE-hard positivity for tensor products of free *-polynomial algebras with a fixed two-generator alphabet in each factor. Their [Theorem 6.1](https://arxiv.org/html/2312.05617v2) is a promise reduction and their §6 discussion extends it to bounded-contraction algebras. Their positivity quantifier is over all *-representations; they explicitly distinguish this from finite-dimensional spatial positivity and note that the tensor product need not be RFD. This is decisive prior art against presenting fixed generators, SOS failure, or broad noncommutative positivity hardness as new.
* Ji–Natarajan–Vidick–Wright–Yuen, [MIP*=RE](https://arxiv.org/abs/2001.04383), give an effective halting reduction to games with value (1) versus at most (1/2). This is the source of the gap, not a new complexity theorem of the carrier construction.
* Fu–Miller–Slofstra, [Theorem 1.1](https://arxiv.org/html/2101.11087), show undecidable membership for a fixed finite quantum-correlation scenario (with the commuting-operator membership problem coRE-complete and the tensor-product variant coRE-hard). This is important fixed-scenario precedent, but the input is a correlation point and the theorem is not this SLD comparison or this inverse-Jordan cone.
* Fixed universal operator systems for POVM families are established framework, not novelty by themselves. Fritz, [Operator system structures on the unital direct sum of C*-algebras](https://arxiv.org/abs/1011.1247), identifies the operator-system coproduct; for finite settings and outcomes, the usual ℓ-infinity-coordinate systems encode POVMs through UCP maps. Todorov–Turowska, [§2 and subsequent universal-operator-system results](https://arxiv.org/abs/2009.07016), develop universal systems for stochastic operator matrices and their correlation models. These precedents support the general universality viewpoint; they do not establish the specific nine-effect normalized-Jordan representation or its matrix-cone reduction.
* Fritz–Netzer–Thom, [Theorem 3.2](https://arxiv.org/html/1609.07908v2), concern finite-dimensional realizations of maximal matrix orderings. Goldbring–Sinclair, [Corollary 5.5 and Corollary 5.8](https://arxiv.org/html/2509.15086v1), give noncomputability results for standard presentations and convergence moduli of $C^*(\mathbb F_n\times\mathbb F_n)$. They make broad fixed-generator tensor-norm noncomputability an especially poor novelty claim; neither theorem is this concrete SLD-coordinate cone.
* Volčič, [Theorem B](https://doi.org/10.1017/fms.2021.54), proves a rational Positivstellensatz on free spectrahedra; its Theorem 5.2 gives a quantitative version. Helton–Klep–McCullough, [Theorem 1.1](https://arxiv.org/abs/1102.4859), give the degree-controlled convex free Positivstellensatz. Both have a free-LMI domain hypothesis absent from the claimed physical domain. Ozawa's extension of tracial positivity certificates is about traces on archimedean *-algebras; it does not identify the two-factor normalized-Jordan domain with that setting.

The transfer report's §13 comparison further proves, without Dots or the manuscript, coRE-hard growing matrix-cone positivity for an at-most-nine-dimensional system generated by four free spatial contractions and their squares. Therefore “some fixed finite-dimensional operator system has a hard matrix cone” is already subsumed by an elementary consequence of the MIP* gap and linearization. The distinctive candidate here is narrower: the explicit $M_2\otimes\mathbb C^3$ carrier, nine fixed physical effects, and the resulting 19-coordinate inverse-Jordan system.

## Final theorem-level decision

Keep the carrier result only as a conditional specialized corollary. Its strongest defensible wording is:

> Assuming the manuscript's actual-domain Pauli transport, action-norm smoothing bound, and common local dilation limit, rational complete positivity in the fixed operator system spanned by the nine normalized-Jordan inverse pairs is coRE-complete. The hardness uses unbounded matrix coefficient size and polynomial degree, while the physical carrier and nine-effect alphabet remain fixed.

Do not infer a computable bound on reference dimension, fixed polynomial degree, $d=1$ scalar hardness, or fixed-input measurement-channel dimension. The two-factor normalized-Jordan domain is exactly why free-box and free-spectrahedron certificates do not dispose of the result. The coRE-hardness is mathematically coherent conditional on the named analytic gates, but broad fixed-system hardness and noncomputability are established prior territory; no landmark or priority claim is supported here.
