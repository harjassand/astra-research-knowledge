# Structural computability boundary for complete information comparison

Investigator: sol03_boundary. Date: 2026-10-11.

Status: independently reconstructed finite-dimensional proofs below; not externally reviewed. The manuscript's MIP*=RE reduction has **not** been independently validated by this investigation. Consequences using its hardness theorem are explicitly conditional. No publication, commit, or repository mutation was performed.

## Findings that survive independently of the hardness manuscript

1. The normalized spatial Jordan domain used by the manuscript is not matrix convex. An explicit example uses faithful rational 6-by-6 baselines and a compression from dimension nine to dimension two. The compressed map has Choi eigenvalue -1/10 and is neither completely positive nor completely copositive. Every size-two spatial-domain map is one of these. Thus a free-positivity compression argument really does change the domain.
2. The closed matrix-convex hull of this domain is exactly the set of unital decomposable positive maps, meaning CP + coCP maps. This is a complete characterization, with an explicit local-branch dilation proving the reverse inclusion.
3. Taking this hull defines a canonical computable sufficient strengthening of complete SLD order for **every** rational strictly positive POVM pair. It is not asserted to be necessary. It has an explicit free LMI lift, and rational positivity on that lift has a computable finite matrix-size cutoff by Volcic's rational Positivstellensatz. Thus the domain enlargement has a precise mathematical meaning and a precise algorithmic price.
4. When the source POVM effects are linearly independent, complete SLD order is exactly a single finite block-matrix positivity condition. There is a reference cutoff at most min(k, a+1), where a is the input dimension and k is the number of target outcomes. This is the measurement-algebra version of a known full-output-span mechanism; novelty is not claimed.
5. For any effective hierarchy with decidable fixed levels, decidability, a computable sufficient cutoff, and a complete recursively enumerable positive-certificate system are equivalent. Applying this to the manuscript's claimed coRE-complete order gives a boundary on every proposed finite certificate or lift, not merely a warning about one SDP.

Exact supporting calculations: `sol03_boundary_check.py` and `sol03_boundary_check.json` in this directory. The executable checks do not establish the general proofs or manuscript hardness.

## 1. Definitions and orientation

Fix a physical matrix algebra M_a. For R>0 on C^a tensor C^n and S>0 on C^a tensor C^m, put

    U_A(R) = Tr_a[(A tensor I_n)R],
    B_A(R,S) = U_A(R) tensor I_m + I_n tensor U_A(S)^T,
    D = B_I(R,S),
    Theta_{R,S}(A) = D^(-1/2) B_A(R,S) D^(-1/2).

The transpose is fixed in the right reference basis. Let J_a(nm) be the maps Theta_{R,S}, including unitary changes of the output basis; if a size has more than one factorization, include all factorizations. Positivity of R,S implies D>0 and Theta(I)=I.

Write T(A)=A^T. A map is **decomposable positive** here if

    Theta = Phi + Psi o T,       Phi,Psi completely positive.

This is CP+coCP decomposability, not the different usage of 'decomposable' for the complex linear span of CP maps.

The Choi orientation matters. For R>=0 the map A -> U_A(R) is completely copositive: its composition with T is CP. For S>=0 the map A -> U_A(S)^T is CP, since it equals T o Phi_S o T for a CP map Phi_S. Congruence by D^(-1/2), and amplification with identities, preserve these respective properties. Therefore every member of J_a is unital decomposable.

## 2. Exact failure of joint-compression closure

Take a=2 and n=m=3. Let the first two reference basis vectors be active, and let e_2 be a third, inactive vector. In C^2 tensor C^3 define the unnormalized vector

    Omega = e_0 tensor e_0 + e_1 tensor e_1

and take the same faithful rational baseline on each side:

    R=S=(3/4)|Omega><Omega|+(1/8)I_6.

Its eigenvalues are 13/8 once and 1/8 five times. Its physical partial trace is

    W=diag(1,1,1/4).

Writing tau(A)=Tr(A)/2 and phi(A)=(3/4)A+(1/4)tau(A)I_2 gives

    U_A(R) = phi(A^T) direct-sum (1/4)tau(A),
    U_A(S)^T = phi(A) direct-sum (1/4)tau(A).

Define an isometry V:C^2 -> C^3 tensor C^3 by

    Vv=(v tensor e_2 + e_2 tensor v)/sqrt(2).

The two branches are orthogonal. On their joint support D=W tensor I+I tensor W is (5/4)I. Neither the numerator B_A nor D couples these branches. Direct calculation therefore gives

    V* Theta_{R,S}(A) V
      = (3/10)(A+A^T)+(1/5)Tr(A)I_2
      = (3/5)(A+A^T)/2+(2/5)tau(A)I_2.

Call the resulting map Theta. Its Choi matrix, in the conventional unnormalized Choi convention, is

    J(Theta) =
      [ 4/5   0     0    3/10 ]
      [  0   1/5   3/10   0  ]
      [  0   3/10  1/5    0  ]
      [ 3/10  0     0    4/5 ].

The antisymmetric vector (0,1,-1,0)^T is an eigenvector with eigenvalue -1/10. Thus Theta is not CP. Also Theta o T=Theta, so it is not coCP.

But a size-two member of J_2 can only have local dimensions (n,m)=(1,2) or (2,1). In the first case the left term is a scalar positive functional times I; it is CP, as is the right term, and their common congruence is CP. In the second case the right scalar term is coCP, as is the left term, and their common congruence is coCP. Hence every size-two member is CP or coCP, even if positive semidefinite baselines and their well-defined limits are permitted.

Consequently Theta is outside the size-two spatial domain, although it is an isometric compression of a faithful size-nine member. To turn this map statement into a finite effect-tuple statement, test on

    I/2, (I+sigma_X/2)/2, (I+sigma_Y/2)/2, (I+sigma_Z/2)/2.

These strictly positive rational complex effects span Herm(2), so any linear map reproducing their images reproduces Theta. No size-two spatial model reproduces this tuple.

**What this proves.** Arbitrary joint compression of the two reference factors does not preserve the physical domain. A finite test-size theorem for free variables cannot be imported by saying that all large violations can simply be compressed.

**What it does not prove.** Domain nonclosure alone neither validates the manuscript's hardness proof nor proves that its special comparison kernels actually distinguish the spatial domain from its matrix-convex hull. The latter is a separate necessity question.

## 3. Complete description of the closed matrix-convex hull

### Theorem 3.1

At every level k,

    closed matrix-convex hull(J_a)_k
       = {Theta:M_a -> M_k : Theta unital and CP+coCP decomposable}.

Here the hull permits finite direct sums, isometric compressions, and norm limits of maps in finite dimensions.

### Proof: containment

Section 1 proves every spatial map is unital CP+coCP. Direct sums and isometric compressions preserve this property. The unital decomposable set is closed at fixed k: if Theta_l=Phi_l+Psi_l o T and Phi_l(I)+Psi_l(I)=I, the two positive Choi matrices have trace at most k. They lie in compact bounded slices of the positive cone. A convergent subsequence of each Choi component supplies a CP+coCP decomposition of the limiting map. Thus the entire closed hull lies in the right-hand side.

### Proof: reverse containment, with an explicit branch construction

Let Theta=Phi+Psi o T be unital. First assume C=Phi(I)>0 and B=Psi(I)>0, so C+B=I. Normalize the components:

    phi(A)=C^(-1/2)Phi(A)C^(-1/2),
    psi(A)=B^(-1/2)Psi(A)B^(-1/2).

These maps are UCP. On each local reference C^k direct-sum C e_0, choose a baseline with marginal

    W_epsilon=I_k direct-sum epsilon,

whose normalized left map is psi on the active block and tau on the scalar block, and whose normalized right map is phi on the active block and tau on the scalar block. Here tau is any faithful scalar state of M_a. Such baselines are supplied by the Choi correspondence, with the transpose orientations of Section 1. If the active Choi matrices are singular, replace phi and psi by (1-delta)phi+delta tau(.)I and (1-delta)psi+delta tau(.)I; all baselines are then strictly positive. Send delta to zero at the end.

Use the isometry

    Vv = B^(1/2)v tensor e_0 + e_0 tensor C^(1/2)v.

Its branches are orthogonal and V*V=B+C=I. The marginal normalizer is (1+epsilon)I on both branches. The compressed spatial map is exactly

    [Theta(A)+epsilon tau(A)I]/(1+epsilon)

when delta=0. With faithful active regularization, it converges to this formula as delta -> 0. Sending epsilon -> 0 gives Theta in the closed hull.

For possibly singular C or B, replace Theta by (1-t)Theta+t tau(.)I and split the added depolarizing term equally between its CP and coCP components. Both marginal component matrices become positive definite, the preceding construction applies, and t -> 0 gives the result. This proves the theorem.

### Interpretation and scope

Joint compression retains the CP+coCP sum but loses the requirement that its two summands live on separate tensor factors with a common Jordan normalizer. The hull theorem identifies exactly what is forgotten. This is more specific than saying that the domain is 'not free'.

The CP+coCP cone itself is classical operator-algebraic material. The explicit hull statement and faithful compression example were reconstructed here for this domain; no claim of historical originality is justified by the limited search performed.

## 4. Exact rational kernel for full-state POVM comparison

This section connects the hull to the actual information-order question, rather than an unrelated positive-map problem.

Let E=(E_i), F=(F_j) be strictly positive POVMs on C^a. Fix a rational complex Hermitian basis (B_mu) of M_a and put

    e_i,mu=Tr(E_i B_mu),    f_j,mu=Tr(F_j B_mu).

These numbers are real and rational when the POVMs are rational. The basis need not be orthonormal. Define the a^2-by-a^2 matrix-valued rational kernel

    K_EF(Theta)
      = sum_i e_i e_i^T tensor Theta(E_i)^(-1)
        - sum_j f_j f_j^T tensor Theta(F_j)^(-1).

### Proposition 4.1

Complete SLD order E >=_c F is equivalent to

    K_EF(Theta_{R,S}) >= 0

for every pair of faithful spatial baselines R,S of arbitrary finite local dimensions.

### Proof

Form a block reference with input state rho=(R direct-sum S)/t, where t=Tr R+Tr S, and off-diagonal traceless Hermitian tangent

    H=[0 Z; Z* 0].

Here Z is an arbitrary rectangular operator between C^a tensor C^m and C^a tensor C^n. The output blocks of E are (U_Ei(R) direct-sum U_Ei(S))/t and the output tangent has off-diagonal block Z_i=Tr_a[(E_i tensor I)Z]. Solving the off-diagonal Sylvester equation gives its SLD value

    4t sum_i Tr[Z_i* J_{U_Ei(R),U_Ei(S)}^(-1)(Z_i)],

where J_{U,V}(X)=UX+XV. Expand Z=sum_mu B_mu tensor Z_mu. After vectorization, the source-minus-target form is the quadratic form of

    sum_i e_i e_i^T tensor B_Ei(R,S)^(-1)
      - sum_j f_j f_j^T tensor B_Fj(R,S)^(-1),

up to a fixed common tensor swap. Because B_A=D^(1/2)Theta(A)D^(1/2), this is a common positive congruence of K_EF(Theta). The coordinates Z_mu are arbitrary, proving the forward implication. Conversely the choice R=S=rho and Z=H recovers every original SLD comparison, with an irrelevant common positive factor. Thus the rational-kernel condition is equivalent to full-state comparison.

Strict positivity of the effects makes every displayed inverse legitimate: any positive unital Theta satisfies Theta(E_i)>=alpha_i I for every scalar lower bound E_i>=alpha_i I.

## 5. A canonical computable envelope operation

Define the **decomposable-envelope order** by

    E >=_dec F
      iff K_EF(Theta)>=0
          for every finite-dimensional unital CP+coCP map Theta.

This defines a uniform operation on arbitrary POVM pairs, not just a restricted source family. Theorems 3.1 and 4.1 give

    E >=_dec F  implies  E >=_cSLD F.

It is the positivity test on the smallest closed matrix-convex domain containing all physical Jordan maps. No stronger exactness assertion follows from the hull theorem.

### Theorem 5.1: this envelope order is decidable on rational strictly positive inputs

Represent Theta=Phi+Psi o T by CP Choi variables C=[C_uv] and B=[B_uv], each an a-by-a block matrix with n-by-n blocks. Impose

    C>=0, B>=0, sum_u(C_uu+B_uu)=I_n.

These are precisely unital decomposable maps. Eliminate, for example, B_aa using the last equality. Parameterize every off-diagonal block by independent Hermitian real and imaginary parts. Center at

    C=B=(1/(2a))I_a tensor I_n.

After multiplication by 2a the two block inequalities form a single rational **monic free linear pencil** L(x)>=0. The map images Theta(A) are rational affine linear functions of its Hermitian variables. Thus K_EF is a rational matrix expression on this free spectrahedron. Every inverse exists everywhere on that domain, by strict positivity of the effects.

For completeness, a scalar reduction avoids assuming a matrix-valued extension of a scalar rational Positivstellensatz. For any Hermitian r-by-r rational matrix K(x), add r unconstrained selfadjoint free variables y_u and consider

    h(x,y)=sum_uv y_u K_uv(x)y_v.

Universal positivity of K implies positivity of h. Conversely, a negative vector (w_1,...,w_r) for K(X) yields a negative h on X direct-sum 0: take y_u to be Hermitian star matrices joining the added root vector to w_u. Applying h to the root reproduces the negative quadratic form. The monic pencil depends only on x; its scalar center 0 is feasible and all the kernel denominators are positive there.

Volcic, *Hilbert's 17th problem in free skew fields*, Theorem 5.2 and Remark 5.3, gives a computable finite evaluation-size bound for failure of h>=0 on L>=0. Rational syntax, a linear representation, and the finite subexpression spaces determine that bound. At the resulting fixed matrix size, real quantifier elimination decides whether a negative evaluation exists, introducing inverse matrices as algebraic variables if desired. Hence the envelope comparison is decidable.

This is a computability statement, not an efficient algorithm claim. It neither produces a physical witness from a nonphysical negative envelope evaluation nor certifies that envelope failure is physical-order failure.

**Indispensable unresolved question:** Is >=_dec necessary for complete SLD on the special kernels K_EF? The compression example alone does not settle it. If the manuscript's claimed coRE-completeness is correct, necessity is impossible on the whole rational strictly positive class, because it would identify an undecidable predicate with this decidable one. That is a conditional strictness conclusion, not an independent proof of a separating POVM pair.

## 6. Exact finite cutoff for independent source effects

### Theorem 6.1

Suppose E_1,...,E_m are linearly independent over the real Hermitian space. Let F have k outcomes. Then complete SLD order E >=_c F is decidable as follows.

First test whether every F_j lies in span_R{E_i}. If not, order fails already with no quantum reference. If it does, solve the unique coefficients

    F_j=sum_i d_ji E_i.

They are real, and normalization plus independence gives sum_j d_ji=1 for each i. Form the Hermitian k-by-k block matrix with a-by-a blocks

    A_jl = delta_jl F_j - sum_i d_ji d_li E_i.             (6.1)

Then

    E >=_cSLD F  iff  A >= 0.                            (6.2)

If order fails, a reference of dimension at most min(k,a+1) suffices. The k=1 case is trivial and requires dimension one. All tests are rational linear algebra and exact finite PSD testing on rational POVM inputs.

### Proof: kernel inclusion and unique lift

If E(H)=0, trace preservation implies Tr H=0, and source SLD information vanishes. Dominance forces F(H)=0. Thus ker E is contained in ker F, which is equivalent to each F_j belonging to the stated span. Since the E_i are independent, E is onto its diagonal output algebra C^m, and E tensor id_n is onto (M_n)^m. Hermitian output tuples have Hermitian preimages.

Allowing all Hermitian tangents is equivalent to allowing only traceless ones: subtract (Tr H)rho. The added metric square and cross terms agree for the two trace-preserving channels.

### Proof: eliminating inverse metrics without a minimax interchange

Fix faithful rho on C^a tensor C^n and put B_i=E_i(rho), C_j=F_j(rho). Define the positive invertible direct-sum Jordan operators

    Omega_B=direct-sum_i Omega_Bi,
    Omega_C=direct-sum_j Omega_Cj,
    Omega_W(X)=(WX+XW)/2.

Let D act on tuples by (DX)_j=sum_i d_ji X_i. Surjectivity of E tensor id_n says the Fisher comparison at this rho holds for every Hermitian tuple X. It is therefore equivalent to

    D*Omega_C^(-1)D <= Omega_B^(-1)

on the real Hilbert space of Hermitian tuples. Multiplying by the positive square roots, this is equivalent to ||Omega_C^(-1/2) D Omega_B^(1/2)||<=1, hence to

    D Omega_B D* <= Omega_C.

Evaluating the latter on an arbitrary target score tuple G=(G_1,...,G_k), G_j Hermitian, gives

    Tr rho [sum_j F_j tensor G_j^2
            -sum_i E_i tensor (sum_j d_ji G_j)^2] >= 0.

As rho ranges over faithful states, this is the operator inequality

    P(G)=sum_jl A_jl tensor G_j G_l >=0.                 (6.3)

If A>=0, factorization of this quadratic form immediately proves (6.3) at every reference size.

### Proof: finite star test for necessity and cutoff

The row and column sums of A vanish because sum_j d_ji=1 and F_j=sum_i d_ji E_i. Consequently P(G) is invariant under replacing every G_j by G_j-G_k, even when the scores do not commute. Set G_k=0 and use the upper-left (k-1)-by-(k-1) principal block A'. Then A>=0 iff A'>=0.

If A' is not PSD, choose physical vectors w_1,...,w_(k-1) with

    sum_jl <w_j,A_jl w_l> <0.

Let their span have dimension r<=min(a,k-1), with orthonormal basis u_1,...,u_r. In a reference of dimension r+1, with root e_0 and leaves e_1,...,e_r, set

    v=sum_s u_s tensor e_s.

For each j choose a Hermitian star score G_j whose root row contains the coordinates of w_j in the u_s basis, so that

    (I tensor G_j)v=w_j tensor e_0.

Take G_k=0. Then

    <v,P(G)v>=sum_jl <w_j,A_jl w_l><0.

Thus a reference size r+1<=min(a+1,k) suffices. A faithful state sufficiently close to |v><v|/||v||^2 still has Tr rho P(G)<0. The inverse-operator equivalence above produces a violating output tangent and surjectivity produces a physical Hermitian tangent at this same reference size. Subtracting its trace times rho makes it traceless without changing the sign. This proves necessity, the cutoff, and the decision procedure.

One can make that last tangent step explicit: if b=<D*G,Omega_B D*G> exceeds c=<G,Omega_C G>, choose X=Omega_B D*G. Then q_B(X)=b while q_C(DX)>=b^2/c>b. Here c>0 for a nonzero score tuple because every C_j is positive definite.

### Boundaries and failed generalization

Theorem 6.1 includes minimally informationally complete source measurements, and does not require commuting effects. It cannot be transferred to an overcomplete measurement merely by selecting an independent effect basis. Doing so leaves positivity and tangent constraints on the remaining output blocks, and the output quadratic form is only tested on im(E tensor id), not on all of (M_n)^m. The inverse-metric equivalence then gives different state-dependent optimal lifts; it does not select one common signed lift for all rho.

This is exactly where an unjustified interchange of 'for every state there exists an optimal lift' with 'there exists one lift for every state' would occur. No such interchange is used above.

The full-output-span mechanism is established prior art in Hirche, arXiv:2610.03706v1, Appendix A.2; the explicit diagonal-output block formula and star-size bound are reconstructed here. Treat these as a useful specialization and sharpening to verify against the literature, not a claimed new foundational theorem.

If all E_i commute as well as being independent, the block coefficients in (6.1) are simultaneously diagonalizable and real in the outcome indices. Scalar scores already test every diagonal scalar block, so dimension one suffices. This is a further restricted corollary, not a claim for arbitrary dependent classical-source measurements.

## 7. General computability equivalence, including positive certificates

### Theorem 7.1

Let C be a decidable set of finite input descriptions, and let Fail(x,n) be a decidable predicate, increasing in n, such that

    not P(x) iff exists n Fail(x,n).

The following are equivalent, uniformly on C:

1. P is decidable.
2. There is a total computable b(x) such that every failing x satisfies Fail(x,b(x)).
3. P is recursively enumerable.
4. There is a sound complete finite-certificate system for P with recursively enumerable acceptance (in particular, a decidable proof verifier suffices).
5. P is a union of a uniformly computable sequence of decidable sound positive subclasses.

### Proof

2 implies 1 by evaluating Fail(x,b(x)). If 1 holds, output b(x)=1 on positive inputs; on negative inputs search the decidable increasing hierarchy until Fail holds. This terminates and gives 2. The complement of P is already recursively enumerable, so 3 is equivalent to 1 by dovetailing the two enumerations. A complete sound enumerable certificate system enumerates P, and an enumeration of P is itself a finite-certificate system (certificate: the enumeration time and transcript). Thus 3 and 4 are equivalent. A uniform union in 5 is enumerable; conversely an enumeration of P yields increasing finite sets of enumerated inputs, which are decidable uniformly and sound. This proves all equivalences.

For rational strictly positive POVM inputs, validity of the input description is decidable. At fixed reference dimension, SLD failure is decidable by real quantifier elimination using faithful state and tangent coordinates plus polynomial Sylvester equations. Taking Fail(x,n) to mean failure at some dimension at most n therefore satisfies the hypotheses **independently** of any hardness premise.

### Conditional consequences of the manuscript's coRE-completeness claim

If the claimed hardness proof is correct, none of items 1-5 exists on the full POVM class. In particular:

- No recursively checkable sound positive proof system can certify every true complete dominance instance.
- No computable sequence of decidable lift/Gram/Positivstellensatz subclasses can cover every positive instance while remaining sound.
- Any common finite signed-lift criterion with a total exact decision routine is necessarily incomplete, or ceases to be necessary, or is not actually a characterization of the full physical order.
- No total computable cutoff can uniformly control the dimension, precision, and conditioning resources of all strict negative witnesses. A total bound on the complete witness encoding would in particular decide the property by finite enumeration.

These are consequences of effective proof verification, not a prohibition on individual finite certificates. Many individual positive instances can have short certificates, and every negative instance can have a finite rational witness.

### Description-length version

For finite binary encodings, let w(s) be the maximum of the least failing reference dimension among failing valid inputs of length at most s, with maximum zero for an empty set. This finite function has **no computable majorant** if the order is undecidable. A majorant would yield a total input cutoff. For every total computable g, w(s)>g(s) must occur infinitely often: otherwise adding a sufficiently large constant to g would give a computable majorant. This does not prove eventual busy-beaver-style domination and should not be described that way.

### Concentrating the hardness in dependent sources

Conditional on the manuscript's full-class hardness, its hardness can be restricted to linearly dependent source POVMs. Given a hard reduction output, test source independence. If it is dependent, retain it. If it is independent, decide it using Theorem 6.1 and substitute a fixed dependent positive or negative example of the same truth value. Positive example: identical scalar POVMs (I/2,I/2). Negative example on a qubit: source (I/2,I/2), target ((I+sigma_Z/2)/2,(I-sigma_Z/2)/2). The latter has a traceless sigma_Z tangent invisible to the source. All effects are rational and strictly positive.

Thus redundant source-output constraints, rather than merely quantum input dimension or complex matrix entries, form an exact location where the generic hardness would have to persist. This is not an assertion of hardness at fixed dimension or fixed outcome count.

## 8. Approximation and the remaining cutoff gap

For the manuscript's bounded entropy defect V(E,F), enumeration of rational faithful state pairs at every finite reference dimension gives uniform lower semicomputability: each divergence of positive rational matrices is computable, and continuity on the faithful domain makes rational pairs dense for each strict margin. If the fixed-error obstruction of Sections 12-14 is valid, no uniform upper semicomputation can complete these lower approximations to a two-sided algorithm.

A bare approximate reference cutoff requires additional care. Fixed reference dimension does not by itself make the faithful entropy optimization compact with a known modulus: reference marginals can approach singularity, and individual divergences can diverge while their reference-cancelled difference stays bounded. This investigation does not prove an effective fixed-reference entropy maximizer or a uniform compactification. The exact SLD cutoff/certificate theorem does not silently answer that distinct approximation question.

## 9. Falsification log

### Attempt A: import a free-rational finite cutoff directly

Rejected as an argument. The exact faithful compression example in Section 2 demonstrates that the physical domain is not closed under the required compressions. A free cutoff establishes a cutoff for the decomposable envelope, not automatically for the physical order.

### Attempt B: show nonclosure itself proves a separation of POVM orders

Rejected. The special kernel K_EF is a difference of inverse effects weighted by effect-coordinate rank-one matrices. Nonclosure of an arbitrary tuple domain does not automatically supply a kernel of this special type that separates the domains. This remains indispensable if one wants an unconditional strictness example for >=_dec versus >=_cSLD.

### Attempt C: reduce all sources to independent effects

Rejected. Selecting a basis of output effects does not produce a measurement with unconstrained output tangent tuples. The signed coordinates of the omitted effects retain state-dependent image constraints. The precise surjectivity step in Section 6 fails.

### Attempt D: claim a single finite signed lift for arbitrary sources

Not established. Statewise quadratic minimization supplies lifts depending on the baseline. A common lift requires an additional argument. The pinned Astra N402 material was reported by the parent to retain this exact necessity gap; no claim in this report relies on N402 necessity.

### Attempt E: strengthen a noncomputable worst-case cutoff to eventual domination

Rejected. Undecidability gives absence of any computable majorant and infinitely many exceedances of each computable function. It does not, without a quantitative reduction, prove eventual domination of every computable function.

### Executed exact checks

`python3 work/investigations/sol03_boundary_check.py` passed. It verifies the baseline's full spectrum and marginal, the compressed-map identity on all four matrix units, transpose invariance, the Choi negative eigenvector, and an informationally complete strictly positive effect span. It also checks all 63 principal minors of a concrete 6-by-6 Gram matrix for an independent source and honest stochastic postprocessing. These checks target algebraic errors; they are not a test of a universal hardness theorem.

## 10. Primary sources and priority assessment

- Christoph Hirche, *Quantum estimation, channel orders, and private capacity*, arXiv:2610.03706v1 (2 October 2026), especially Appendix A.2 and the discussion of the remaining unsmoothed-versus-common-lift question. https://arxiv.org/html/2610.03706v1 . This is primary prior art for the full-output-span mechanism; the general common-lift necessity problem is explicitly not settled there.
- Jurij Volcic, *Hilbert's 17th problem in free skew fields*, Forum of Mathematics, Sigma 9 (2021), e61, arXiv:2101.02314. Theorem 5.2 supplies rational positivity on monic free spectrahedra, and Remark 5.3 supplies an effective finite matrix test size. https://arxiv.org/abs/2101.02314 ; https://www.cambridge.org/core/journals/forum-of-mathematics-sigma/article/hilberts-17th-problem-in-free-skew-fields/1DC74DC3E0E011210C826FF4DCA24DE1 . The envelope decision proof uses these established theorems.
- Mark Girard, Seung-Hyeok Kye, Erling Stormer, *Convex cones in mapping spaces between matrix algebras*, Linear Algebra and its Applications 608 (2021), 248-269, arXiv:2002.09614. https://arxiv.org/abs/2002.09614 . Primary context for CP+coCP decomposable positive maps and mapping cones; this source does not by itself establish the particular spatial Jordan hull theorem stated here.
- Christoph Hirche, Cambyse Rouze, Daniel Stilck Franca, *On contraction coefficients, partial orders and approximation of capacities for quantum channels*, Quantum 6 (2022), 862, arXiv:2011.05949. https://arxiv.org/abs/2011.05949 . Primary context for complete less-noisy/relative-entropy comparisons and tensorization.
- Ji, Natarajan, Vidick, Wright, Yuen, *MIP*=RE*, arXiv:2001.04383. https://arxiv.org/abs/2001.04383 . External hardness premise of the manuscript; this investigation does not rederive the game-to-channel reduction.

Targeted searches for 'matrix convex hull' with 'completely copositive', 'spatial Jordan', and 'normalized Sylvester decomposable' did not return an exact prior statement of Theorem 3.1. That is weak negative search evidence, not a novelty certificate. The hull result is a short consequence of known CP/coCP normalization and branch dilation once the domain is identified. The defensible result is an explicit, proved structural boundary and operation; a landmark novelty claim is not supported.

## 11. Recommended authoritative status

**INTERNALLY RECONSTRUCTED:** Sections 2-7's independent finite-dimensional statements and the effective-hierarchy equivalence. The free-envelope decision theorem additionally imports Volcic's published rational Positivstellensatz.

**CONDITIONAL:** Generic no-positive-certificate consequences, noncomputable worst-case growth, concentration of hardness in dependent sources, and strictness of the computable envelope, insofar as they invoke the manuscript's unverified coRE-completeness theorem.

**UNRESOLVED:** An explicit complete-SLD-positive POVM pair failing the decomposable-envelope test without invoking manuscript hardness; an independently proved general common-lift necessity theorem or counterexample; an effective arbitrary fixed-reference entropy-defect optimization routine; historical originality of the hull packaging.

The most useful exact deliverable is the faithful rational compression obstruction together with the complete CP+coCP hull characterization. It explains exactly why a free positivity theorem can provide a valid decidable sufficient operation while failing to settle unrestricted physical comparison.
