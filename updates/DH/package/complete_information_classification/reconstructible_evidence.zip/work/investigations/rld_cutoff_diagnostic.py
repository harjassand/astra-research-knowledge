"""Finite noncommuting diagnostic for the elementary RLD compression proof."""
import json
import numpy as np

rng = np.random.default_rng(44217)
a, n = 2, 11
eye = np.eye(2)
pauli_x = np.array([[0, 1], [1, 0]])
pauli_z = np.diag([1, -1])
effects_e = [(eye + 0.2 * pauli_x) / 2, (eye - 0.2 * pauli_x) / 2]
effects_f = [(eye + 0.7 * pauli_z) / 2, (eye - 0.7 * pauli_z) / 2]

def random_hermitian(d):
    x = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d))
    return (x + x.conj().T) / 2

def power(x, q):
    w, v = np.linalg.eigh(x)
    return (v * w**q) @ v.conj().T

def output(effect, physical):
    refdim = len(physical) // 2
    return np.einsum('ab,biaj->ij', effect, physical.reshape(2, refdim, 2, refdim))

x = rng.normal(size=(a * n, a * n)) + 1j * rng.normal(size=(a * n, a * n))
raw = x @ x.conj().T + 2 * np.eye(a * n)
ref = output(eye, raw)
filtering = np.kron(eye, power(ref, -0.5))
normalized = filtering @ raw @ filtering
h = np.kron(pauli_z, random_hermitian(n)) + 0.3 * np.kron(pauli_x, random_hermitian(n))

def terms(effects, baseline, tangent):
    r = [output(e, baseline) for e in effects]
    k = [output(e, tangent) for e in effects]
    return r, k

re, ke = terms(effects_e, normalized, h)
rf, kf = terms(effects_f, normalized, h)
quadratic = lambda r, k: k @ np.linalg.solve(r, k)
difference = sum(quadratic(r, k) for r, k in zip(re, ke)) - sum(quadratic(r, k) for r, k in zip(rf, kf))
eigenvalues, eigenvectors = np.linalg.eigh(difference)
v = eigenvectors[:, 0]
assert eigenvalues[0] < 0
zs = [np.linalg.solve(r, k @ v) for r, k in zip(rf, kf)]
u, singular, _ = np.linalg.svd(np.column_stack([v, *zs]), full_matrices=False)
rank = int(np.sum(singular > 1e-11 * singular[0]))
isometry = u[:, :rank]
vp = isometry.conj().T @ v
physical_compression = np.kron(eye, isometry)
normalized_p = physical_compression.conj().T @ normalized @ physical_compression
hp = physical_compression.conj().T @ h @ physical_compression
rep, kep = terms(effects_e, normalized_p, hp)
rfp, kfp = terms(effects_f, normalized_p, hp)
on_vector = lambda r, k, vec: float(np.vdot(vec, quadratic(r, k) @ vec).real)
target_errors = [on_vector(rp, kp, vp) - on_vector(r, k, v) for r, k, rp, kp in zip(rf, kf, rfp, kfp)]
source_changes = [on_vector(rp, kp, vp) - on_vector(r, k, v) for r, k, rp, kp in zip(re, ke, rep, kep)]
dp = sum(quadratic(r, k) for r, k in zip(rep, kep)) - sum(quadratic(r, k) for r, k in zip(rfp, kfp))
eta = 1e-4
wp = (1 - eta) * np.outer(vp, vp.conj()) + eta * np.eye(rank) / rank
congruence = np.kron(eye, power(wp, 0.5))
rho = congruence @ normalized_p @ congruence
hh = congruence @ hp @ congruence
hh = hh - np.trace(hh).real * rho
rhoe, he = terms(effects_e, rho, hh)
rhof, hf = terms(effects_f, rho, hh)
restored = float((sum(np.trace(quadratic(r, k)) for r, k in zip(rhoe, he)) - sum(np.trace(quadratic(r, k)) for r, k in zip(rhof, hf))).real)
result = {
    'status': 'finite_floating_point_diagnostic_only',
    'original_reference_dimension': n,
    'compressed_reference_dimension': rank,
    'proved_cutoff_for_this_target': 1 + len(effects_f),
    'original_negative_vector_value': float(eigenvalues[0]),
    'compressed_negative_vector_value': float(np.vdot(vp, dp @ vp).real),
    'target_quadratic_errors': target_errors,
    'source_quadratic_changes': source_changes,
    'normalized_marginal_residual': float(np.linalg.norm(output(eye, normalized_p) - np.eye(rank))),
    'restored_state_min_eigenvalue': float(np.linalg.eigvalsh(rho)[0]),
    'restored_state_trace': float(np.trace(rho).real),
    'restored_tangent_trace': float(np.trace(hh).real),
    'restored_rld_difference': restored,
}
assert rank <= 1 + len(effects_f)
assert max(abs(e) for e in target_errors) < 1e-8
assert max(source_changes) < 1e-8
assert restored < 0
assert np.linalg.eigvalsh(rho)[0] > 0
print(json.dumps(result, indent=2))
