# A single discrimination measure and a sharp quadratic computational boundary

11 October 2026. Independent Sol investigation 05.

## Result and status

The strongest developed results are an analytic and operational equivalence and a contrasting finite endpoint cutoff, each independent of the manuscript's nonlocal-game reduction:

**Theorem A.** For arbitrary finite-dimensional channels with a common input, complete SLD dominance is equivalent to complete dominance for any one fixed standard Petz Rényi divergence of order `0 < alpha < 2`. At `alpha = 1`, use Umegaki relative entropy. “Complete” allows every finite untouched quantum reference and every state pair, without equality of reference marginals.

**Theorem B.** The same complete preorder is induced by the quantum Chernoff divergence, the optimal symmetric binary discrimination exponent. One untouched classical bit converts Chernoff comparison exactly into order-one-half Petz comparison.

**Theorem C.** At the quadratic endpoint `alpha=2`, failure of complete measurement-channel dominance has a faithful state-pair witness with reference dimension at most one plus the target's number of nonzero outcomes. For arbitrary finite channels the bound is one plus the square of the target's effective output dimension. Thus complete order-two dominance of rational POVMs is decidable. The full elementary proof is in `rld_finite_cutoff.md` alongside this report.

**Scope theorem.** For every `alpha > 2`, there are finite classical channels for which complete SLD dominance holds but Petz order-alpha dominance fails. Order zero also fails to characterize SLD, even on strictly positive rational measurements. If the manuscript's complete-SLD hardness theorem is correct, Theorems A and C imply a strict analytic/computational separation between every fixed order in `(0,2)` and the quadratic endpoint on rational strictly positive POVMs. No explicit numerical pair separating the endpoint has been constructed here.

The proofs below are complete candidate proofs, not formal-kernel or external specialist certification. Their noncommuting Hessian identities were checked numerically, and the above-two counterexample algebra was checked exactly. Historical priority remains unconfirmed. The result is a meaningful channel-comparison extension of the manuscript's coherent-reference mechanism, not a claimed historic breakthrough.

The root agent independently derived a broader result for finite-at-zero operator-convex generators with nonzero interior resolvent mass, in `work/investigations/root_universality.tex`. I reviewed its Hessian coefficient, differentiation domination, and concentration for singular representing measures without finding a defect. That broader proof is separately authored; this report gives a direct proof for the fixed Rényi family and operational Chernoff consequence.

## 1. Exact definitions

On the effective output support of a channel, define

\[
\Omega_A(X)=\frac{AX+XA}{2},\qquad
g_A(K)=\operatorname{Tr} K\Omega_A^{-1}(K)
=\sum_{ij}\frac{2|K_{ij}|^2}{a_i+a_j}.
\]

The input state is faithful and the input tangent is traceless Hermitian. Every reference in an individual test is finite dimensional; there is no common dimension bound.

For states with faithful denominator, let

\[
Q_\alpha(A,B)=\operatorname{Tr} A^\alpha B^{1-\alpha},\qquad
D_\alpha(A\Vert B)=\frac{\log Q_\alpha(A,B)}{\alpha-1}.
\]

These are **standard Petz**, not sandwiched, Rényi quantities. For `alpha < 1`, larger divergence means smaller `Q_alpha`; for `alpha > 1`, it means larger `Q_alpha`.

Define

\[
C(A,B)=-\log\inf_{0\leq u\leq1}Q_u(A,B).
\]

Boundary values use the usual support convention. It suffices for the reverse implications below to assume comparison on faithful state pairs. The resulting SLD order gives the all-state extended comparisons by the positive integral and support limits.

## 2. SLD dominance gives all the stated divergence orders

For `s > 0` set

\[
f_s(x)=\frac{(x-1)^2}{x+s},\qquad
D_{f_s}(A\Vert B)
=\langle A-B,(L_A+sR_B)^{-1}(A-B)\rangle_{\rm HS}.
\]

Given faithful inputs `rho,sigma`, put `X=rho-sigma` and append a reference qubit:

\[
\Theta_s=\frac1{1+s}\begin{pmatrix}\rho&0\\0&s\sigma\end{pmatrix},
\qquad H_X=\begin{pmatrix}0&X\\X&0\end{pmatrix}.
\]

The off-diagonal Sylvester equation gives exactly

\[
g_{\Theta_s}(H_X)=4(1+s)D_{f_s}(\rho\Vert\sigma).
\tag{1}
\]

The same identity holds after each channel. Complete SLD order therefore compares every `D_fs`.

For `0 < alpha < 2`, `alpha != 1`, define the affine-normalized operator-convex generator

\[
h_\alpha(x)=\operatorname{sgn}(\alpha-1)
\bigl(x^\alpha-1-\alpha(x-1)\bigr).
\]

The following positive scalar representation is exact:

\[
h_\alpha(x)=\frac{|\sin\pi\alpha|}{\pi}
\int_0^\infty\frac{s^\alpha}{(1+s)^2}f_s(x)\,ds.
\tag{2}
\]

To verify it, differentiate twice. The second derivative of the right side is

\[
\frac{2|\sin\pi\alpha|}{\pi}
\int_0^\infty\frac{s^\alpha}{(x+s)^3}\,ds
=\alpha|\alpha-1|x^{\alpha-2}.
\]

Both sides vanish with their first derivatives at `x=1`. Integral convergence at infinity uses exactly `alpha < 2`. Applying the spectral perspective and positive integration to (2) proves comparison of `D_halpha`, hence comparison of `D_alpha`.

At `alpha=1`, use

\[
x\log x-(x-1)=\int_0^\infty \frac{s}{(1+s)^2}f_s(x)\,ds.
\]

For the Chernoff quantity, comparison of every `Q_u`, `0<u<1`, in the direction `Q_u(P) <= Q_u(Q)` implies the same inequality after taking the infimum, hence `C(P) >= C(Q)`.

These implications are inherited from the manuscript/predecessor's coherent-qubit and positive-integral mechanism. They are not the new reverse mechanism.

## 3. A fixed Petz Rényi divergence recovers SLD

Fix `alpha in (0,2)`, `alpha != 1`, and put `q=1-alpha`, so `-1<q<1`, `q!=0`. It is convenient to compare

\[
J_\alpha(A,B)=-\operatorname{sgn}(q)\operatorname{Tr} A^\alpha B^q.
\]

Its comparison direction is exactly the direction of `D_alpha`.

### 3.1 Saturation and the exact Hessian

Fix an arbitrary original reference, faithful input `rho`, and Hermitian tangent `H`. For either channel write `A=Phi(rho)`, `K=Phi(H)`. Add a reference with one centre and `N` leaves. Let

\[
W=\operatorname{diag}(1,\lambda_1,\ldots,\lambda_N)>0,
\quad Z=\operatorname{Tr}W,
\quad\tau=vv^*,\quad\|v\|=1,
\]

where `v` is leaf supported, and set

\[
L=e_0w^*+we_0^*,\qquad
\beta(\epsilon)=\frac{\rho\otimes W+\epsilon H\otimes L}{Z}.
\]

The denominator is a faithful state for sufficiently small positive and negative `epsilon`, since `Tr L=0`. The numerator is `rho tensor tau`. At zero,

\[
J_\alpha(A\otimes\tau,A\otimes W/Z)
=-\operatorname{sgn}(q)Z^{-q}\operatorname{Tr}\tau W^q,
\tag{3}
\]

independent of the channel, because `alpha+q=1` and `Tr A=1`.

If comparison was initially required only for faithful numerators, replace `tau` by `(1-zeta)tau+zeta I/(N+1)` and then let `zeta` decrease to zero at each fixed `epsilon`. Since `alpha>0` and the denominator remains faithful, continuity gives the same inequality with the singular numerator. Saturation at zero remains exact.

Define the finite resolvent sum

\[
F(t)=w^*(W_{\rm leaf}+tI)^{-1}v.
\]

The load-bearing Hessian identity is

\[
\left.\frac{d^2}{d\epsilon^2}
J_\alpha\left(A\otimes\tau,
\frac{A\otimes W+\epsilon K\otimes L}{Z}\right)\right|_0
=\frac{2|\sin\pi q|}{\pi}Z^{-q}
\sum_{ij}|K_{ij}|^2
\int_0^\infty\frac{t^q|F(t)|^2}{a_j+a_it}\,dt.
\tag{4}
\]

**Proof of (4).** For a positive matrix `B` and Hermitian `Y`, the elementary integral formulas for positive and negative powers give, for either sign of `q`,

\[
\left.\frac{d^2}{d\epsilon^2}
[-\operatorname{sgn}(q)(B+\epsilon Y)^q]\right|_0
=\frac{2|\sin\pi q|}{\pi}
\int_0^\infty u^q(B+u)^{-1}Y(B+u)^{-1}Y(B+u)^{-1}\,du.
\]

For `q>0`, this follows by twice differentiating the Stieltjes representation of `B^q`; for `q<0`, by differentiating the positive resolvent representation of `B^q`. At `B=A tensor W`, `Y=K tensor L`, only leaf-centre-leaf paths contribute after contraction with `A^alpha tensor tau`. In an eigenbasis of `A`, the ordered indices `(i,j)` contribute

\[
|K_{ij}|^2a_i^\alpha
\int_0^\infty
\frac{u^q|F(u/a_i)/a_i|^2}{a_j+u}\,du.
\]

Substitute `u=a_i t`. The total power of `a_i` outside the denominator is

\[
a_i^{\alpha+q-1}=1.
\]

This cancellation is essential. Scaling the denominator by `1/Z` contributes `Z^(-q)`. The integrals converge because `F` is bounded at zero and `O(1/t)` at infinity, with `-1<q<1`. This proves (4).

The source-minus-target divergence difference is nonnegative near zero and vanishes at zero by (3). Its second derivative is therefore nonnegative. Thus the hypothesis compares the two right-hand sides of (4) for every realizable finite filter `F`.

### 3.2 Finite coherent filters concentrate at one

For an integer `m >= 1`, let

\[
\lambda_j=1+j/m^3,\quad 0\leq j\leq2m,
\qquad F_m(t)=\frac{t^m}{\prod_{j=0}^{2m}(t+\lambda_j)},
\qquad I_{m,q}=\int_0^\infty t^qF_m(t)^2\,dt.
\]

The poles are positive, rational and distinct, so partial fractions realize `F_m` as a finite sum of simple resolvents with rational coefficients. Explicitly, choose uniform `v_j=1/sqrt(2m+1)` and choose `w_j` so that `conjugate(w_j)v_j` is the partial-fraction coefficient. Coefficients may be large; they only shrink the admissible nonzero `epsilon` interval.

For every positive `a,b`,

\[
\frac1{I_{m,q}}\int_0^\infty
\frac{t^qF_m(t)^2}{b+at}\,dt\longrightarrow\frac1{a+b}.
\tag{5}
\]

To prove it, compare with

\[
f_m(t)=\frac{t^m}{(1+t)^{2m+1}}.
\]

Uniformly for `t>0`,

\[
e^{-2/m-1/m^2}\leq F_m(t)/f_m(t)\leq1.
\]

The probability density proportional to `t^q f_m(t)^2` is beta-prime with parameters

\[
a_m=2m+q+1,\qquad b_m=2m+1-q.
\]

Its mean is `a_m/(b_m-1)`, tending to one, and variance is

\[
\frac{a_m(a_m+b_m-1)}{(b_m-2)(b_m-1)^2},
\]

tending to zero. The uniform multiplicative comparison gives vanishing total variation distance between the two normalized densities. Applying convergence in probability to the bounded continuous function `(b+at)^(-1)` proves (5).

Divide the Hessian comparison by the positive common factor and by `I_mq`, then take the limit. Each channel has finitely many eigenvalues in the fixed test, so (5) gives

\[
\sum_{ij}\frac{|P(H)_{ij}|^2}{a_i+a_j}
\geq\sum_{ij}\frac{|Q(H)_{ij}|^2}{b_i+b_j}.
\]

This is exactly complete SLD comparison, up to the common factor two. The original reference was arbitrary. Together with Section 2, it proves Theorem A away from `alpha=1`. The manuscript's logarithmic Hessian is the corresponding `q=0` argument; alternatively the root's general-generator theorem covers `x log x` directly.

### 3.3 The additional reference does not require new entanglement

There is an exact structural normal form for this reverse witness. Put

\[
\rho^{-1/2}H\rho^{-1/2}=\sum_j x_j|j\rangle\langle j|.
\]

Then

\[
\beta(\epsilon)=\sum_j
\rho^{1/2}|j\rangle\langle j|\rho^{1/2}
\otimes\frac{W+\epsilon x_jL}{Z}.
\tag{6}
\]

Positivity of `beta` is equivalent, by the indicated local congruence, to positivity of every reference factor in (6). Thus the numerator is product and the denominator is separable across **the original input plus original reference versus the newly added reference** throughout the admissible interval. The two states have the same original-system marginal `rho`; for traceless `H`, the denominator's new-reference marginal is `W/Z`.

This does not eliminate entanglement between the physical channel input and the entire reference. It shows that the additional spectral filtering mechanism uses coherent reference states without adding entanglement across the new cut.

## 4. Exact Chernoff-to-affinity conversion

For any faithful pair `A,B`, append one untouched classical bit and form

\[
\widetilde A=\frac12(A\otimes|0\rangle\langle0|+B\otimes|1\rangle\langle1|),
\quad
\widetilde B=\frac12(B\otimes|0\rangle\langle0|+A\otimes|1\rangle\langle1|).
\]

Block-diagonal functional calculus gives exactly

\[
Q_u(\widetilde A,\widetilde B)
=\tfrac12[Q_u(A,B)+Q_{1-u}(A,B)].
\]

Each `Q_u(A,B)` is a positive sum of exponentials in `u` in mixed eigenbases, hence convex. The displayed function is symmetric about one-half and convex, so it has a minimum at one-half. Trace cyclicity gives `Q_half(A,B)=Q_half(B,A)`. Consequently

\[
\boxed{C(\widetilde A,\widetilde B)
=-\log\operatorname{Tr}\sqrt A\sqrt B
=\tfrac12D_{1/2}(A\Vert B).}
\tag{7}
\]

Apply complete Chernoff dominance to the symmetrized **input** pair, retaining any original reference. Equation (7) gives complete order-one-half Petz dominance, and Section 3 gives complete SLD dominance. The converse was proved in Section 2. This proves Theorem B.

The square-root overlap in (7) is the Petz affinity. It is not Uhlmann fidelity, which inserts a trace norm. No equivalence for sandwiched Rényi or fidelity orders has been proved here.

## 5. Counterexamples and exact boundaries

### 5.1 Complete SLD dominance can hold while every order above two fails

Fix `0<a<1`. Let `P` be the classical bit-erasure channel revealing its input with probability `a^2`, and let `Q` be the binary symmetric channel of bias `a`. Both can be regarded as quantum channels that first dephase the input.

For arbitrary Hermitian matrix-valued target scores `B_0,B_1`, including an arbitrary untouched reference, use source scores

\[
J_0=\tfrac{1+1/a}{2}B_0+\tfrac{1-1/a}{2}B_1,
\quad
J_1=\tfrac{1-1/a}{2}B_0+\tfrac{1+1/a}{2}B_1,
\quad J_?=\tfrac12(B_0+B_1).
\]

For each input letter, the source-weighted first moment is exactly the target-weighted first moment, and the source-weighted `J_i^2` is exactly the target-weighted `B_i^2`. The coefficients of both ordered products `B_0B_1` and `B_1B_0` cancel separately. This is an operator identity, not a commutative-score argument.

Apply the variational formula

\[
g_A(K)=\sup_{B=B^*}\{2\operatorname{Tr}KB-\operatorname{Tr}AB^2\}.
\]

Every target objective is achieved by a source score with the same value; the source supremum is at least the target supremum. Therefore

\[
P\succeq^c_{\rm SLD}Q.
\tag{8}
\]

Now fix any `alpha>2`. Write the two input distributions in centred coordinates, denominator `(1+x,1-x)/2` and numerator `(1+y,1-y)/2`, and define

\[
F_\alpha(x,y)=\tfrac12[(1+y)^\alpha(1+x)^{1-\alpha}
+(1-y)^\alpha(1-x)^{1-\alpha}]-1.
\]

The erasure output overlap is `1+a^2 F_alpha(x,y)`; the BSC overlap is `1+F_alpha(ax,ay)`. Set

\[
x=(\alpha-2)t/3,\qquad y=(\alpha+1)t/3.
\]

The expansion is even in `t`; its quadratic term cancels in the source-minus-target difference. The quartic coefficient of `F_alpha(x,y)` is

\[
-\frac{\alpha(\alpha-1)(\alpha-2)(\alpha+1)}{72}t^4.
\]

Indeed, with `d=y-x`, the quartic term in general is

\[
\frac{\alpha(\alpha-1)d^2}{24}
[(\alpha-2)(\alpha-3)d^2-8(\alpha-2)dx+12x^2].
\]

Consequently

\[
a^2F_\alpha(x,y)-F_\alpha(ax,ay)
=-\frac{a^2(1-a^2)\alpha(\alpha-1)(\alpha-2)(\alpha+1)}{72}t^4+O(t^6)<0
\]

for sufficiently small positive `t`. The input distributions are then faithful. Thus Petz order-alpha dominance fails already without a reference, despite (8), for every `alpha>2`.

An exact rational illustration is `alpha=3`, `a=1/2`, numerator `(0,1)`, denominator `(3/8,5/8)`:

\[
Q_3(P\rho,P\sigma)=139/100,
\quad Q_3(Q\rho,Q\sigma)=208/147,
\quad 208/147-139/100=367/14700>0.
\]

The quartic family supplies faithful witnesses; this additional rational illustration has a boundary numerator and a faithful denominator.

### 5.2 Order zero loses all measurement information

If every effect of a POVM `M` is strictly positive, each output block of `M_R(rho)` has support exactly `supp rho_R`. Therefore

\[
D_0(M_R(\rho)\Vert M_R(\sigma))
=-\log\operatorname{Tr}(P_{\operatorname{supp}\rho_R}\sigma_R),
\]

independent of the POVM. All strictly positive measurements are equivalent in complete Petz order zero.

Take the rational qubit measurements `E=(I/2,I/2)` and `F=((I+Z/2)/2,(I-Z/2)/2)`. Both are strictly positive. At `rho=I/2`, `H=Z/2`, `E` has zero Fisher information and `F` has positive Fisher information. Thus `E` does not dominate `F` in SLD, despite their complete order-zero equivalence.

### 5.3 The quadratic endpoint requires a different mechanism

At `alpha=2`, the denominator power is `q=-1`. Instead of the interior integral (4), the exact Hessian is

\[
2Z|F(0)|^2\sum_{ij}\frac{|K_{ij}|^2}{a_j}.
\tag{9}
\]

This is the RLD endpoint. Filtering with `F(0)=0` kills the entire Hessian; there is no interior spectral mass to concentrate at one. Thus the present reverse proof cannot extend to the quadratic generator.

Equation (9) is a decisive obstruction to this **method**, not a counterexample by itself. A different elementary argument subsequently resolved its finite-reference behavior: normalize the reference marginal, express the RLD difference as an operator-valued sum of one-sided inverse quadratics, and compress to the span of a negative vector and the target inverse-action vectors. The target terms remain exact; the source terms decrease by the inverse quadratic variational principle. A faithful reference marginal and a traceless tangent are then restored by congruence and an invariant scalar gauge.

The complete proof in `rld_finite_cutoff.md` gives cutoff `1+#target outcomes`, and `1+d_target^2` for general finite channels. This independently proves endpoint decidability for rational POVMs. Combining it with the manuscript hardness premise gives strict separation, but the construction of an explicit numerical endpoint-separating POVM pair is still outstanding.

## 6. Computational consequences and their dependency

If the supplied manuscript's nonlocal-game-to-POVM reduction is correct, the equality of complete preorders transfers its coRE-completeness by the identity map to every fixed Petz order in `(0,2)` and to complete Chernoff order, on the same rational strictly positive POVM class. This analytic investigation does not independently certify that hardness reduction.

For a **fixed rational** `alpha in (0,2)`, `alpha!=1`, fixed-reference Petz-order failure is a semialgebraic existence question: encode positive matrix roots for the rational powers and compare `Q_alpha`, avoiding the logarithm. Real quantifier elimination decides that fixed dimension. Therefore, conditional on the manuscript hardness theorem, no computable sufficient reference-dimension cutoff exists for that fixed rational-alpha order. For a transcendental parameter this argument requires computability and decidability assumptions that have not been supplied.

At `alpha=2`, Theorem C supplies the explicit finite cutoff independently of hardness. Fixed-reference RLD failure has rational polynomial inverse equations, so real quantifier elimination gives a total complete-order decision procedure. This contrast is the strongest developed consequence of the investigation.

No fixed-additive-error hardness statement for a Rényi or Chernoff numerical defect is inferred merely from equality of qualitative preorders. The conversions can shrink witness margins, and a new dimension-independent margin analysis would be needed. No entropy contraction coefficient, efficient algorithm, common physical simulator, equal-reference-marginal theorem, or fixed input-dimension hardness claim follows from this report.

## 7. Falsification and verification record

The script `sol05_verify.py` and its output `sol05_verify_results.json` are in this investigation directory. It uses NumPy, mpmath, and SymPy already available on the host.

- The Hessian formula was checked at a genuinely noncommuting three-dimensional `A,K`, with complex reference coupling, for `alpha=0.25,0.5,1.5,1.9`; the exact endpoint (9) was checked at `alpha=2`. Finite differences agreed with the integral formula within floating-point/quadrature error. This tests transposes, signs, factors and scaling; it is not a proof certificate.
- A direct endpoint-singular quadrature initially showed a persistent discrepancy near `alpha=1.9`. Substituting `t=u^20` near zero removed the numerical singularity. The discrepancy came from quadrature resolution, not from a changed theorem formula. The final script preserves this explicit transformation.
- The flag identity (7) was checked on noncommuting pairs in dimensions two, three and four. Its numerical minimum occurred at one-half, with identity residuals at machine precision.
- Weighted finite-resolvent densities were checked at `q=-0.8,0.5,0.8`, for `m=2,4,8,16,32`; the inverse-Jordan kernel expectations approached the predicted limit.
- First and second moment score-lift identities were verified with rational coefficients while keeping `B_0B_1` and `B_1B_0` separate. The order-three overlap values and the general quartic coefficient were checked exactly.

These checks are scoped finite diagnostics or algebraic certificates for named identities. They do not establish external validity, historical priority, the full manuscript reduction, or an explicit numerical pair separating order two from SLD. The elementary order-two cutoff has a separate complete proof.

## 8. Primary-source and predecessor comparison

The predecessor `work/manuscript/astra_operational_extensions.tex`, Section 3, already proves complete SLD equivalence to **simultaneous** complete dominance for all operator-convex modular Petz generators, including the special triangular generator. Its Section 4 has conditional coefficient claims requiring N402/N403. The fixed-single-generator reverse theorem here does not use that conditional premise. The predecessor already supplies the erasure/BSC complete score lift; the new above-two calculation uses it as an established local construction, not an invented simulator.

Focused primary-source searches and reads included:

- [Hirche, *Quantum estimation, channel orders, and private capacity*, arXiv:2610.03706v1](https://arxiv.org/html/2610.03706v1). It supplies the coherent-qubit route from complete measured chi-square comparison to complete BKM/relative-entropy comparison. No fixed-Petz-alpha reverse theorem or the Chernoff equivalence was located in the inspected text.
- [Hirche, Rouzé and Stilck França, *On contraction coefficients, partial orders and approximation of capacities for quantum channels*](https://arxiv.org/html/2011.05949v3). It supplies the complete less-noisy/relative-entropy framework and tensorization. These are antecedents, not novelty claims here.
- [Hiai and Mosonyi, *Different quantum f-divergences and the reversibility of quantum operations*](https://arxiv.org/html/1604.03089). Its operator-convex representations and support conventions clarify the finite-at-zero versus quadratic boundary. Equality in data processing for one fixed state pair is a different problem from comparing two channels on all pairs.
- [Audenaert, Nussbaum, Szkoła and Verstraete, *Asymptotic Error Rates in Quantum Hypothesis Testing*](https://arxiv.org/abs/0708.4282), and [Audenaert et al., *The Quantum Chernoff Bound*](https://arxiv.org/abs/quant-ph/0610027). These establish the operational meaning of `C`; that meaning is not new here.
- [Makur and Zheng, *Linear Bounds between Contraction Coefficients for f-Divergences*](https://arxiv.org/abs/1510.01844), establishes classical less-noisy equivalence for non-linear operator-convex generators. It is a close conceptual antecedent. The noncommutative coherent-reference reverse proof is the distinct step being proposed.

No exhaustive priority search or external expert audit was completed. The appropriate assessment is **a developed analytic theorem candidate with an operational corollary, explicit above-range counterexamples, and an elementary decidable quadratic endpoint**. A strict computational boundary follows conditional on the supplied hardness proof. Landmark significance is not established by this investigation.

## 9. Substantive failed or superseded avenues

1. **All positive Rényi orders.** Falsified by the explicit complete-SLD erasure/BSC family above. The first failure is already possible for each order strictly greater than two; an all-order statement would be wrong.
2. **Quadratic endpoint from the same filter.** The spectral measure collapses to zero, giving (9). Choosing an interference filter that cancels that endpoint cancels all available curvature. The failed filter route was replaced by the elementary one-sided compression proof in `rld_finite_cutoff.md`.
3. **Chernoff optimizer pinning by a large reference clock.** A valid preliminary route used a swapped binary reference pair repeated `n` times, whose strictly convex log-overlap profile forces the minimizer to one-half. The elementary limit recovers `D_half/2`. It is superseded by the exact one-bit flag identity (7), which needs no limit and supplies the entire Chernoff proof.
4. **Fidelity/sandwiched Rényi transfer.** No valid extension emerged. Petz affinity and Uhlmann fidelity have different matrix expressions, and metric comparison along input curves does not by itself compare unrestricted output geodesic distances. This route is not claimed solved.
5. **Universal physical simulation.** The erasure/BSC pair has complete SLD dominance while its one-shot uniform-input guessing probability is smaller. Divergence comparison cannot be promoted to a physical postprocessing map or exact guessing-probability order.
6. **Eliminating every entanglement resource.** Equation (6) proves separability only across the newly added auxiliary cut. It does not remove possible entanglement between the physical input and its original reference. A global no-entanglement claim would exceed the proof.

The decisive mechanisms are coherent spectral filtering in the open range and exact inverse-action compression at the quadratic endpoint. The former isolates the inverse-Jordan kernel from a saturated divergence; the latter preserves a single reference factor and supplies an explicit finite cutoff. Exact flag symmetrization makes the open-range mechanism apply to optimal asymptotic binary discrimination.
