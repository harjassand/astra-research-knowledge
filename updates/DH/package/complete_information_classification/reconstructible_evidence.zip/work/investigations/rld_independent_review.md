# Independent adversarial review: finite cutoff for RLD / Petz order two

11 October 2026. Independent reconstruction of `rld_finite_cutoff.md`, including its finite-channel extension.

## Verdict

I found no fatal counterexample. The POVM cutoff proof is valid as stated on faithful finite-dimensional inputs: any strict complete RLD violation has a faithful state-pair witness with reference dimension at most `1+v`, where `v` is the number of nonzero target POVM effects. The general-channel proof also works, with bound `1+b^2` where `b` is the dimension of the target channel's effective output support.

The decisive compression is mathematically sound. It compresses the full physical-reference operator and tangent, rather than substituting arbitrary output tuples. For each target quadratic term it retains the actual inverse-action vector; each source term is a variational supremum over a smaller vector space and therefore cannot increase. The normalization, faithful restoration, and trace gauge preserve the strict sign exactly where required.

This verifies the internal finite-dimensional argument, not historical priority or a machine-checked proof. The boundary-state aside in §1 is not needed for the theorem and would benefit from stating the chosen extended-value convention explicitly. The proof itself uses only faithful pairs and avoids that issue.

## Detailed reconstruction

### 1. Exact order-two expansion

For any faithful denominator block `A>0` and Hermitian tangent block `K`,

\[
 \operatorname{Tr}(A+tK)^2A^{-1}
 =\operatorname{Tr}A+2t\operatorname{Tr}K
   +t^2\operatorname{Tr}KA^{-1}K.
\]

This is exact: expand the square, cycle each linear term under the trace, and cyclically rewrite `Tr K^2 A^{-1}` as `Tr K A^{-1}K`. Summing over measurement outcomes gives `Tr A=1` and `Tr K=Tr H=0`; thus (1) has no omitted remainder. The same calculation applies to a single quantum-channel output. Given any faithful pair `(alpha,beta)`, put `rho=beta`, `H=alpha-beta`, `t=1`; the exact identity recovers `Q_2(alpha||beta)`. Conversely, small `t` around any faithful `rho` gives a faithful pair. Hence the comparison of all faithful `Q_2` pairs is equivalent to comparison of the RLD quadratic forms on traceless Hermitian tangents.

### 2. Reference normalization and negative vector

If `W=Tr_a R>0`, local congruence by `I⊗W^{-1/2}` gives `Rtilde>0` and `Tr_a Rtilde=I`. For each effect, `r_i>0`: if `y≠0`, then

\[
 \langle y,r_i y\rangle
 =\operatorname{Tr}\!\left[Rtilde(M_i\otimes|y\rangle\langle y|)\right]>0,
\]

since the second factor is nonzero positive semidefinite and `Rtilde` is positive definite. Congruence cancellation gives

\[
 \mathcal G_{W^{1/2}rW^{1/2}}(W^{1/2}kW^{1/2})
 =\operatorname{Tr}Wkr^{-1}k.
\]

Thus a strict metric violation is `Tr W D<0`. The Hermitian matrix `D` has a unit eigenvector `xi` with `<xi,D xi><0`; this inference does not require `xi` to be in any preselected support.

There is no hidden domain enlargement in using arbitrary Hermitian `h` after normalization. For example, any normalized faithful `Rtilde` can be turned into a state by taking `W=I_d/d`, `R=Rtilde/d`, and `H=h/d`; the later scalar gauge imposes `Tr H=0` without changing the comparison.

### 3. POVM compression: target equality and source monotonicity

For each target effect let `z_j=r_j^{-1}k_j xi`, and let `S=span{xi,z_1,...,z_v}`. Compression by an isometry `V:C^d→C^n` onto `S` preserves positive definiteness, the partial-trace constraint, and the actual channel blocks: `r_i'=V*r_iV`, `k_i'=V*k_iV`. With `xi'=V*xi`, `z_j'=V*z_j`, and `z_j∈S`,

\[
 r_j'z_j'=V^*r_jz_j=V^*k_jxi=k_j'xi'.
\]

Because `r_j'` is invertible, `z_j'` is its exact inverse-action solution. Its quadratic value is

\[
 \langle z_j',r_j'z_j'\rangle
 =\langle z_j,r_jz_j\rangle
 =\langle xi,k_jr_j^{-1}k_jxi\rangle.
\]

The first equality uses `z_j,xi∈S` and the compression identity `V r_j' V*=P_S r_jP_S`; the second uses Hermiticity of `k_j` and `r_jz_j=k_jxi`. So every target term is preserved exactly.

For any source effect, the compressed term is the same variational objective

\[
 \sup_{y\in S}\{2\operatorname{Re}\langle k_i xi,y\rangle-\langle y,r_i y\rangle\},
\]

whereas the full term takes the supremum over all `y∈C^n`. It can only decrease. Consequently the compressed source-minus-target expectation remains strictly negative, and `d≤1+v`. No invariance of `S` under any `r_i` is assumed or needed.

### 4. Faithful restoration and traceless gauge

Since the compressed expectation at `|xi'><xi'|` is strictly negative, continuity gives the same strict sign for a sufficiently small `eta>0` in `W_eta=(1-eta)|xi'><xi'|+eta I/d`. This `W_eta` is faithful. Restoring by `I⊗W_eta^{1/2}` yields a positive definite trace-one state because

\[
 \operatorname{Tr}R'=\operatorname{Tr}(W_eta\operatorname{Tr}_a Rtilde')=1.
\]

The restored RLD difference is precisely `Tr W_eta D<0`. Set `c=Tr H_0'∈R` and `H'=H_0'-cR'`. Then `Tr H'=0`. For one output, direct expansion gives

\[
 \mathcal G_A(K-cA)=\mathcal G_A(K)-2c\operatorname{Tr}K+c^2\operatorname{Tr}A.
\]

Both channels preserve trace, so the added terms cancel in their difference. Equivalently, before restoration, sums of the `k_i` and `r_i` agree for the two POVMs. For small nonzero `t`, `R'+tH'>0`, and the exact order-two expansion gives the strict faithful-pair violation. This completes the theorem without any boundary-state limiting argument.

### 5. Arbitrary finite channels

Let the target output support have dimension `b`, choose its orthonormal basis `e_c`, and write `A=Q_R(Rtilde)`, `K=Q_R(h)`. The reference expectation of the output RLD quadratic form is

\[
 \langle xi,\operatorname{Tr}_{B}KA^{-1}K\,xi\rangle
 =\sum_{c=1}^b\langle e_c\otimes xi,KA^{-1}K(e_c\otimes xi)\rangle.
\]

For every `c`, set `z_c=A^{-1}K(e_c⊗xi)∈B⊗C^n`, and include all its `b` reference components in `S`, together with `xi`. Thus `dim S≤1+b^2` and every `z_c∈B⊗S`. If `P=I_B⊗V V*`, the compressed blocks are `A'=V*AV`, `K'=V*KV` (with `V` acting on the reference), and

\[
 A'(I_B\otimes V^*)z_c=(I_B\otimes V^*)K(e_c\otimes xi)
 =K'(e_c\otimes xi').
\]

Hence the compressed target inverse solution is exactly `(I_B⊗V*)z_c`. Its quadratic value is preserved, since `z_c=Pz_c` and

\[
 z_c^*A z_c
 =[(I_B\otimes V^*)z_c]^*A'[(I_B\otimes V^*)z_c].
\]

For the source channel, apply the inverse quadratic variational identity separately to `u_c=K_P(e_c⊗xi)` for each orthonormal output basis vector. The compressed optimization restricts vectors from `B_P⊗C^n` to `B_P⊗S`; each source contribution therefore decreases. The argument does not require the source output dimension to equal `b`; its basis sum simply runs over its own effective output support.

The normalized channel blocks are positive definite on `supp Φ(I)⊗C^n`, because `Rtilde≥δ I` implies `Φ_R(Rtilde)≥δ Φ(I)⊗I`; compression retains strict positivity there. Finally, trace preservation gives `Tr_B Φ_R(Rtilde)=I_R` and `Tr_B Φ_R(h)=Tr_A h` for both channels. Thus the same faithful restoration and scalar tangent gauge preserve the strict difference. This validates the `1+b^2` extension.

## Exact scope notes

- For POVMs, `b` separate output-block inverse vectors each have one reference component, yielding the sharper `1+v` bound.
- The proof gives a finite reference bound depending only on the target outcome count/output dimension; it does not give a practical complexity bound for real quantifier elimination.
- The QE encoding is valid for rational real and imaginary effect entries: strict positivity is expressible by principal minors, inverse blocks by polynomial equations `T_i r_i=I`, and the strict RLD violation by a polynomial inequality. This decides the finite set of dimensions after the theorem's cutoff.
- The boundary numerator sentence in the source note is extraneous to the faithful-pair theorem. It should specify the standard support convention if retained, but it creates no gap in the cutoff or decidability result.
