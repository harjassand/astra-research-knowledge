# Fixed physical carrier and a finite-dimensional operator system with hard matrix order

Prepared 11 October 2026. Investigation sol04_transfer.

**Status:** internally reconstructed conditional theorem; not an independently certified result or a historical-priority claim. The standalone packing lemma below is proved without the manuscript. The transfer uses the manuscript's actual-domain representation, quantitative Pauli transport, local smoothing, and dilation limit in its Sections 3–5. Those are the indispensable imported mathematical lemmas, reconstructed in Section 14 of this report. The manuscript's Section 7 compiler is reconstructed explicitly below. Manuscript Sections 8–14, including the growing physical POVM realization and entropy-order equivalence, are not needed.

**Strongest claim:** there is one fixed concrete operator system \(\mathcal S_J\), spanned by at most 19 bounded selfadjoint functions associated with nine fixed rational effects on \(\mathbb C^6\), whose rational **matrix** positive-cone membership is coRE-complete. The reduction already promises either \(X\ge I\) throughout its concrete representation or a finite spatial evaluation with \(\lambda_{\min}(X)<-1\). Its matrix norms admit no total algorithm at fixed additive error \(1/2\). There is no effective sound certificate calculus complete even for its uniformly strictly positive rational matrix elements.

This is a transfer to operator-system theory and spatial noncommutative positivity. It does **not** establish undecidability of channel order with fixed physical channel-input dimension. The matrix coefficient/residue dimension grows, and converting it back to POVMs by manuscript Section 8 grows the channel input.

## 1. Target and primary-source priority boundary

The independent target was effective positivity/certification in spatial noncommutative geometry: can positivity on a concrete finite physical carrier be characterized by an effective complete calculus, or reduced to a computable finite matrix realization?

The broad statement that spatial noncommutative positivity is undecidable is already known. Ji–Natarajan–Vidick–Wright–Yuen give the effective nonlocal-game promise \(\omega^*=1\) versus \(\omega^*\le1/2\): [MIP*=RE, arXiv:2001.04383v3](https://arxiv.org/abs/2001.04383v3). Mehta–Slofstra–Zhao, [Positivity is undecidable in tensor products of free algebras, arXiv:2312.05617v2](https://arxiv.org/html/2312.05617v2), Theorem 1.1, already prove coRE-hard positivity with two free generators per factor. Their introduction also distinguishes gapped finite-dimensional positivity from positivity in all representations; the latter has a different unresolved complexity classification. Thus “fixed generators” and “no positivity certificates” by themselves are not new discoveries.

The candidate sharpening here is the **specific fixed six-dimensional normalized Jordan carrier**, followed by a **fixed finite-dimensional linear operator system of inverse functions**, with all input dependence moved into rational matrix coefficients. An exhaustive priority search for this exact operator system has not been completed. Existing free-algebra hardness could plausibly already yield other fixed finite-dimensional operator systems with noncomputable matrix cones through linearization. No claim of first such operator system is made.

Section 13 makes this comparison decisive: the packing lemma and an elementary squared word-graph penalty already produce an at-most-nine-dimensional spatial operator system with the same matrix-cone hardness, directly from MIP*=RE and without the manuscript. Thus existence of a fixed finite-dimensional system with noncomputable matrix cones is not the source-specific contribution of this investigation. The normalized Jordan realization is the actual added specialization.

There is also strong prior computable-operator-algebra context. Fritz–Netzer–Thom, [Can you compute the operator norm?](https://arxiv.org/abs/1207.0975), prove computability in important RFD/amenable group cases. Goldbring–Sinclair, [On definability of C*-tensor norms, arXiv:2509.15086v1](https://arxiv.org/html/2509.15086v1), Corollary 5.5, prove that the standard norm of \(C^*(\mathbb F_n\times\mathbb F_n)\) is noncomputable for \(n\ge2\); Corollary 5.8 excludes a computable convergence modulus for soft-commuting approximations. Their Question 5.6 asks whether some separable C*-algebra has a c.e. presentation but no computable presentation. Our result concerns specified generator coordinates and does not resolve that intrinsic presentation question.

Free rational positivity theorems have different domains. Volčič, [Hilbert's 17th problem in free skew fields](https://doi.org/10.1017/fms.2021.54), proves rational positivity certificates on full Hermitian domains and free spectrahedra. Pascoe, [Positivstellensätze for noncommutative rational expressions](https://arxiv.org/abs/1703.06951), similarly imposes free polynomial/convex domain hypotheses. Neither result can be applied to the present spatial normalized domain without a domain-preserving reduction.

## 2. The fixed physical carrier and its exact quantifiers

Use the physical algebra
\[
\mathcal A=M_2\otimes\mathbb C^3\subset M_6.
\]
Let \(e_1,e_2,e_3\) be the minimal projections of \(\mathbb C^3\). Set \(\tau=1/2\), and use the following **nine fixed** rational complex physical effects:
\[
A_i=\frac{I+\tau\sigma_i\otimes I_3}{2},
\qquad
A_{i,g}=\frac{I+\tau\sigma_i\otimes e_g}{2},
\quad i=X,Y,Z,\quad g=1,2.
\tag{J1}
\]
The third payload effect is used only to complete a local POVM; no physical letter with \(g=3\) is required. Every effect in (J1), and every complement, lies between \(I/4\) and \(3I/4\).

For **every** finite \(n,m\ge1\), **every** \(R>0\) on \(\mathbb C^6\otimes\mathbb C^n\), and **every** \(S>0\) on \(\mathbb C^6\otimes\mathbb C^m\), define
\[
\mathsf A_C(R)=\operatorname{Tr}_6[(C\otimes I)R],
\quad
B_C=\mathsf A_C(R)\otimes I_m+
I_n\otimes\mathsf A_C(S)^T,
\quad D=B_I,
\]
\[
Z_C=D^{-1/2}B_CD^{-1/2}.
\tag{J2}
\]
All nine letters share this same pair \(R,S\) and same \(D\). These are the actual spatial normalized Jordan evaluations, not arbitrary independent matrix contractions. They satisfy
\[
\frac14 I\le Z_C\le\frac34 I,\qquad
Z_{I-C}=I-Z_C.
\tag{J3}
\]
Define centered letters \(T_i=(2Z_{A_i}-I)/\tau\) and \(T_{i,g}=(2Z_{A_{i,g}}-I)/\tau\).

The input in the polynomial stage is an arbitrary finite rational Hermitian noncommutative polynomial in these nine centered letters. Polynomial degree and coefficient size may grow with a Turing-machine description. There is no fixed-degree claim. The evaluation dimensions \(n,m\) are unbounded.

## 3. Standalone packing lemma: all local measurements into one three-outcome POVM

Let \(M\) be the number of questions, \(K\) the number of answers, and \(N=MK\). Let \((M_{a|x})\) be any finite-dimensional local POVM family on \(H\). No projectivity, rationality, or attainment assumption is imposed.

Put
\[
\widehat H=\mathbb C^{N+1}\otimes H,\qquad
\ell_j=\frac{j}{N+1}\quad(0\le j\le N),
\]
\[
U=\sum_{j=0}^N\ell_j|j\rangle\langle j|\otimes I_H,
\quad
V=\frac1N\sum_{g=(x,a)}
\left(|g\rangle\langle0|+|0\rangle\langle g|\right)
\otimes M_g^{1/2}.
\tag{P1}
\]
Here the nonzero labels \(g\) are any fixed enumeration of the \(N\) question-answer pairs. Both \(U,V\) are Hermitian contractions. In fact \(\|U\|<1\), and the star column \(C:H\to H^{\oplus N}\), \(C\xi=(M_g^{1/2}\xi)_g\), satisfies
\[
C^*C=\sum_gM_g=MI,\qquad \|V\|=\sqrt M/N\le1.
\tag{P2}
\]

For each \(j\), let the rational Lagrange polynomial be
\[
q_j(t)=\prod_{k\ne j}\frac{t-\ell_k}{\ell_j-\ell_k}.
\tag{P3}
\]
Then \(q_j(U)=|j\rangle\langle j|\otimes I\). Define rational noncommutative polynomial squares
\[
L_g(U,V)=Nq_g(U)Vq_0(U),
\quad
r_g(U,V)=L_g(U,V)^*L_g(U,V)
=N^2q_0(U)Vq_g(U)^2Vq_0(U).
\tag{P4}
\]
Exactly,
\[
r_g(U,V)=|0\rangle\langle0|\otimes M_g,
\qquad
\sum_a r_{x,a}(U,V)=|0\rangle\langle0|\otimes I.
\tag{P5}
\]
These identities are proved by multiplying the selected star blocks. They hold for arbitrary POVMs because the star contains the positive square roots.

For **every** selfadjoint pair \(U,V\), even away from the honest encoding, the expression \(r_g=L_g^*L_g\) is positive. Its norm on bounded pairs has an effective coefficient bound.

Now take the three effects
\[
a_1=(I+U)/4,\qquad a_2=(I+V)/4,\qquad
a_3=(2I-U-V)/4.
\tag{P6}
\]
They are positive and sum to \(I\). The third effect is positive because \(U,V\le I\); no commutation is assumed. Recover \(U=4a_1-I,\ V=4a_2-I\). Thus one three-outcome POVM suffices to encode the whole measurement family through polynomial squares. An independent packing is used on the other party.

The square roots in (P1) occur only in the existential honest witness. The reduction outputs the rational polynomials (P3)–(P4), never the unknown strategy matrices or their square roots.

## 4. Imported analytic transport, stated precisely

The following two facts are required from manuscript Sections 3–5. They are not consequences merely of boundedness of arbitrary tuples.

First, for the actual evaluations (J2), after the manuscript's common local Stinespring dilation and positive-weight limiting construction, there are opposite Pauli representations \(x_i,y_i\), local three-outcome POVMs \(a_g,b_g\), and normalized weights \(p,q\) with
\[
T_i=px_ip+qy_iq,\qquad
T_{i,g}=px_i a_gp+qy_i b_gq.
\tag{A1}
\]
For exact representation weights, \(a_g,b_g\) are projections; after the local smoothing below they are POVMs. The formula is used with the same dilation/weight limit as the manuscript, not by asserting arbitrary compressed tuples are spatially representable.

Second, set
\[
\Delta=\sum_i(I-T_i^2)+
\sum_{(i,j)\ {\rm cyclic}}[T_i,T_j]^*[T_i,T_j],
\qquad
\delta(v)=\langle v,\Delta v\rangle.
\tag{A2}
\]
For a fixed cyclic \((K,L,H)=(X,Y,Z)\), use the manuscript's Hermitian raw extractors
\[
L_H=T_H+i[T_K,T_L],\quad R_H=T_H-i[T_K,T_L],
\]
\[
U_g=T_{H,g}+i[T_K,T_{L,g}],\quad
V_g=T_{H,g}-i[T_K,T_{L,g}],
\]
\[
P_g=(L_HU_g+U_gL_H)/2,\qquad
Q_g=(R_HV_g+V_gR_H)/2.
\tag{A3}
\]
They have norm at most 9. In an honest balanced Bell model, they equal the local payloads \(a_g,b_g\) exactly.

For each integer \(s\ge1\), the same smoothing produces local POVMs \(a_g^{(s)},b_g^{(s)}\), with all parties/payloads using one common averaging measure, such that
\[
\|(P_g-a_g^{(s)})v\|
\le\sqrt{421s\,\delta(P_gv)}
+\sqrt{842s\,\delta(v)}
+200\sqrt{\delta(v)}
+200\sqrt{3000/(2s+1)}\,\|v\|.
\tag{A4}
\]
The analogous bound holds for \(Q_g,b_g^{(s)}\). These constants are independent of \(n,m\) and marginal conditioning.

The source derives this from a positive contraction \(M_0\) which is an average of product-local unitaries, with \(E_M(v)\le421\delta(v)\), \(\delta(v)\le3000E_M(v)\), and \(M_0^s\) giving the smoothing. In this investigation the averaging identity, the action-norm nature of (A4), positivity and common normalization of the smoothed payloads, and the fixed-instance Stinespring limit are the critical gates.

## 5. New descendant transport for arbitrary fixed-alphabet polynomials

Let \(\mathcal L=\{P_1,P_2,Q_1,Q_2\}\). For an integer \(d\ge1\), define the finite positive polynomial
\[
E_d^{\rm op}=\sum_{|w|\le d}w(\mathcal L)^*\Delta w(\mathcal L),
\qquad E_d(z)=\langle z,E_d^{\rm op}z\rangle.
\tag{T1}
\]
Include the empty word. The sum runs over all words in this four-letter alphabet; it is finite, and exponential size is permitted.

Let \(\widetilde{\mathcal L}_s=\{a_1^{(s)},a_2^{(s)},b_1^{(s)},b_2^{(s)}\}\). These four letters are contractions, and opposite parties commute.

For a unit vector \(z\), a suffix \(v=w(\mathcal L)z\) of length at most \(d-1\), and \(L\in\mathcal L\), both \(\delta(v)\) and \(\delta(Lv)\) occur in (T1). Since \(\|v\|\le9^{d-1}\), (A4) gives the conservative bound
\[
\|(L-\widetilde L_s)v\|
\le12000\left(\sqrt{sE_d(z)}+
9^{d-1}s^{-1/2}\right).
\tag{T2}
\]

For a word of length \(k\le d\), use the exact ordered telescoping expansion
\[
L_1\cdots L_k-\widetilde L_1\cdots\widetilde L_k
=\sum_{j=1}^k
\widetilde L_1\cdots\widetilde L_{j-1}
(L_j-\widetilde L_j)L_{j+1}\cdots L_k.
\tag{T3}
\]
This uses one-step errors on **raw suffix descendants**; no unsupported transfer of energy to smoothed suffixes is needed.

Let \(f\) be a polynomial of degree at most \(d\), with coefficient absolute sum at most \(C_{\rm coef}\ge1\). Put
\[
C=C_{\rm coef}9^d,\qquad
C_{\rm pack}=12000dC.
\tag{T4}
\]
Then
\[
\|f(\mathcal L)\|,\ \|f(\widetilde{\mathcal L}_s)\|\le C,
\]
\[
\|[f(\mathcal L)-f(\widetilde{\mathcal L}_s)]z\|
\le \kappa_s,\qquad
\kappa_s=C_{\rm pack}\left(\sqrt{sE_d(z)}+s^{-1/2}\right).
\tag{T5}
\]
All bounds are rationally overestimated from finite polynomial coefficients. This proves the extension needed to unpack arbitrary many game measurements from just two payload letters.

## 6. A fixed-carrier gapped game polynomial

For a rational game with \(M\) questions and \(K\) answers, pad the two parties to common sizes if needed. Apply the decoder (P4) after the affine substitution \(U=4P_1-I,\ V=4P_2-I\), obtaining polynomial squares \(R_g\). Use \(U=4Q_1-I,\ V=4Q_2-I\) to obtain \(S_h\) on the other party.

Let \(d\) be a common degree bound in the **raw four-letter extractor alphabet**, and choose one \(C_{\rm coef}\) bounding all decoder coefficient sums. With \(C,C_{\rm pack}\) from (T4), both raw and smoothed decoded effects have norm at most \(C\). The smoothed decoders \(\widetilde R_g,\widetilde S_h\) are local positive effects, though they need not individually be contractions or question-wise normalized.

Set
\[
B=\sum_{x,y,a,b}\pi(x,y)V(a,b|x,y)
\frac{R_{x,a}S_{y,b}+S_{y,b}R_{x,a}}2,
\]
\[
H^{\rm op}=
\sum_x\left(\sum_aR_{x,a}-I\right)^2+
\sum_y\left(\sum_bS_{y,b}-I\right)^2,
\quad H(z)=\langle z,H^{\rm op}z\rangle.
\tag{G1}
\]
For unit \(z\), (T5) and Cauchy–Schwarz give
\[
|\langle z,Bz\rangle-\text{smoothed unnormalized score}|
\le2CK^2\kappa_s.
\tag{G2}
\]
For example, each product expectation differs by at most
\(\|(R-\widetilde R)z\|\|Sz\|+
\|\widetilde Rz\|\|(S-\widetilde S)z\|\le2C\kappa_s\).

Each smoothed question sum lies between 0 and \(L I\), where \(L=KC\ge1\). Normalize its square-root measurement column by polar decomposition, filling the kernel in one outcome exactly as manuscript Section 5.3. The normalized local column \(N\) and raw column \(C_x\) satisfy
\[
\|(C_x-N)z\|=\|(\sqrt{C_x^*C_x}-I)z\|
\le\|(C_x^*C_x-I)z\|.
\tag{G3}
\]
This works for singular question sums. For a question pair, the joint column difference is bounded by \(\sqrt L\,\upsilon_y+\tau_x\); the joint raw column has norm at most \(L\), while the normalized column is an isometry. Consequently the averaged payoff error is at most
\[
C_3\sqrt{H_s},\qquad C_3=(L+1)^2,
\]
where \(H_s\) is the marginally weighted sum of squared smoothed normalization defects. Minkowski gives
\[
\sqrt{H_s}\le\sqrt{H(z)}+2K\kappa_s.
\tag{G4}
\]
The normalized strategy is finite-dimensional and hence scores at most \(\omega^*(G)\). Thus
\[
\langle z,Bz\rangle\le\omega^*(G)+
A\left(\sqrt{sE_d(z)}+s^{-1/2}\right)+C_3\sqrt{H(z)},
\]
\[
A=(2CK^2+2KC_3)C_{\rm pack}.
\tag{G5}
\]
The manuscript's positive-weight dilation limit extends this scalar inequality to every actual evaluation (J2). Only finitely many polynomials and descendants occur, so fixed-instance convergence suffices; no uniform convergence rate is assumed.

Given rational \(r,\gamma>0\), choose
\[
t=\max\{1,\lceil4A/\gamma\rceil\},\quad s=t^2,\quad C_2=At,
\]
\[
\lambda_E\ge2C_2^2/\gamma,\qquad
\lambda_H\ge2C_3^2/\gamma,
\]
with rational or integer upper rounding, and output
\[
F=rI-B+\lambda_EE_d^{\rm op}+\lambda_HH^{\rm op}.
\tag{G6}
\]
If \(\omega^*(G)\le r-\gamma\), (G5) implies
\[
\langle z,Fz\rangle\ge
3\gamma/4-C_2\sqrt{E_d(z)}-C_3\sqrt{H(z)}
+\lambda_EE_d(z)+\lambda_HH(z)\ge\gamma/2.
\tag{G7}
\]
Each scalar square completion costs at most \(\gamma/8\).

For completeness, pack any finite strategy by (P1) independently on both parties, use the UCP maps
\[
\Phi_A((Z_g)_{g=1}^3)=\sum_g Z_g\otimes a_g,\qquad
\Phi_B((Z_g)_{g=1}^3)=\sum_g Z_g\otimes b_g,
\tag{G8}
\]
and take their identity-marginal Choi baselines. Their balanced Bell realization has \(P_g=a_g,\ Q_g=b_g\). Every raw extractor word preserves the Bell factor, so **all** descendants in (T1) have zero anchor energy. Put the game vector in the label-0 corner on both parties. Equation (P5) gives \(H=0\), and \(B\) equals the original game score.

The Choi baselines may be singular. Replace each \(R_0,S_0\), with its identity reference marginal, by
\[
R_\epsilon=(1-\epsilon)R_0+\epsilon(I_6/6)\otimes I,
\quad
S_\epsilon=(1-\epsilon)S_0+\epsilon(I_6/6)\otimes I.
\tag{G9}
\]
The common \(D=2I\) is unchanged, and every centered letter is multiplied by \(1-\epsilon\), because its physical Pauli observable is traceless. If \(F=\sum_wc_wT_w\), let
\[
B_{\rm deg}\ge\sum_w |w|\,|c_w|
\]
be an effective rational bound. Contraction telescoping yields
\[
\|F(T_\epsilon)-F(T_0)\|\le\epsilon B_{\rm deg}.
\tag{G10}
\]
For the hard games take \(r=3/4,\gamma=1/4\). Nonhalting gives \(F\ge I/8\). Halting gives \(\omega^*=1\), hence a finite strategy scoring above \(15/16\); its honest value is below \(-3/16\). Choose a rational \(\epsilon>0\) with \(\epsilon B_{\rm deg}\le1/16\). This yields faithful baselines and a unit-vector value below \(-1/8\). No perfect strategy or dimension bound is needed.

**Conditional fixed-carrier theorem.** Rational Hermitian polynomial positivity on the fixed nine-letter actual domain (J2) is coRE-complete, with the fixed promise \(F\ge I/8\) everywhere versus a finite faithful evaluation with \(\lambda_{\min}(F)<-1/8\).

The upper coRE bound follows independently: for fixed \(n,m\), violation is real-algebraically expressible using \(R,S\), a positive square root of \(D\), and a witness vector. Alternatively enumerate rational faithful \(R,S\); their normalized letters have real-algebraic entries, so sign testing is decidable. Strict violations persist under rational approximation.

## 7. Ordered-word compiler reconstructed and normalized

Substitute centered letters by their affine expressions in the nine \(Z\) letters. Let \(p(Z)\) be the resulting rational Hermitian polynomial, and suppose its low-case gap is \(g=1/8\).

Let \(\mathcal W\) be the finite suffix-closed set containing the empty word and every supported word of \(p\); let \(d_0=|\mathcal W|\), \(L_0=\sum_{w\ne\emptyset}|w|\). For nodes \(v=jw\), the edge defect for arbitrary node vectors \(z_v\) is \(r_v=z_v-Z_jz_w\).

For \(B=B_{A_j}\), and \(U_v=D^{1/2}z_v\), the exact identity is
\[
\langle U_v,B^{-1}U_v\rangle+
\langle U_w-U_v,(D-B)^{-1}(U_w-U_v)\rangle
-\langle U_w,D^{-1}U_w\rangle
\]
\[
=\langle r_v,[Z_j(I-Z_j)]^{-1}r_v\rangle
\ge4\|r_v\|^2.
\tag{C1}
\]
It follows by expanding the single-operator identities for \(Z_j\); no commutation of \(B,D\) is assumed.

Let \(H_p\) have root diagonal \(c_\emptyset\), root-to-word entries \(c_w/2\), and their conjugates. Its form on an exact graph \(z_w=Z_w\xi\) is \(\langle\xi,p(Z)\xi\rangle\). Put
\[
b=\sum_{w\ne\emptyset}|w|\,c'_w,\qquad c'_w\ge|c_w|,
\quad M_1=b^2/(8g)+1/4.
\]
Add \(M_1\) times (C1) for every edge. The resulting kernel is
\[
K(R,S)=H_0\otimes D^{-1}+
\sum_{j=1}^9\left(H_j^+\otimes B_{A_j}^{-1}
+H_j^-\otimes B_{I-A_j}^{-1}\right),
\tag{C2}
\]
with constant rational Hermitian coefficient matrices:
\[
H_0=H_p-M_1\sum_{v=jw}e_we_w^*,
\quad H_j^+=M_1\sum_{v=jw}e_ve_v^*,
\]
\[
H_j^-=M_1\sum_{v=jw}(e_w-e_v)(e_w-e_v)^*.
\tag{C3}
\]
The coefficient matrix size \(d_0\) grows; the denominator alphabet stays fixed.

For \(a=\|z_\emptyset\|\), \(u^2=\sum_{v\ne\emptyset}\|r_v\|^2\), recurrence telescoping gives the conservative estimates
\[
|P(z)-\langle z_\emptyset,p(Z)z_\emptyset\rangle|\le bau,
\quad \|z\|^2\le2d_0a^2+2L_0u^2.
\]
Consequently
\[
\langle U,KU\rangle\ge ga^2-bau+4M_1u^2
\ge(g/2)a^2+u^2,
\]
\[
K(R,S)\ge\eta I\otimes D^{-1},\qquad
\eta=\frac{g}{4d_0+2gL_0}>0.
\tag{C4}
\]
For any negative \(p\) witness, choose the exact graph \(z_w=Z_w\xi\); all edge penalties vanish. If \(\|\xi\|=1\), then \(\|z\|^2\le d_0\). Thus the faithful high-case \(p\)-value below \(-1/8\) yields a normalized kernel eigenvalue below \(-1/(8d_0)\).

## 8. One fixed operator system

For every rational faithful baseline pair from (J2), form the finite block
\[
f_0=I,\qquad
f_j^+=Z_{A_j}^{-1},\qquad
f_j^-=(I-Z_{A_j})^{-1},\quad 1\le j\le9.
\tag{O1}
\]
Take the direct sum over all finite \(n,m\) and all rational faithful \(R,S\). Each generator is a well-defined bounded selfadjoint operator on that direct-sum Hilbert space, with
\[
\|f_j^\pm\|\le4.
\]
Let
\[
\mathcal S_J=\operatorname{span}_{\mathbb C}
\{f_0,f_1^+,f_1^-,\ldots,f_9^+,f_9^-\}.
\tag{O2}
\]
It is a fixed concrete operator system of dimension at most 19. Linear independence of this spanning family is neither assumed nor needed. By continuity, positivity on the rational blocks is equivalent to positivity on all faithful actual evaluations.

For rational Hermitian coefficient matrices \(H_0,H_j^\pm\in M_d(\mathbb Q(i))\), the represented matrix element is
\[
X_H=H_0\otimes f_0+
\sum_j(H_j^+\otimes f_j^++H_j^-\otimes f_j^-)\in M_d(\mathcal S_J).
\tag{O3}
\]
The congruence
\[
(I_d\otimes D^{1/2})K(R,S)(I_d\otimes D^{1/2})
=X_H(R,S)
\tag{O4}
\]
connects (C2) to (O3) exactly.

Scale the compiler output by the computable rational
\[
\alpha=\max\{1/\eta,\ 8d_0\}.
\tag{O5}
\]
Then nonhalting gives \(\alpha X_H\ge I\) in every block, while halting gives a finite faithful block with eigenvalue strictly below \(-1\). Rational blocks with the same strict negative sign exist; for the negative margin below \(-1\), approximate closely enough to preserve it.

**Conditional operator-system theorem.** The set of rational Hermitian matrix-coordinate descriptions \(H\) with \(X_H\in M_d(\mathcal S_J)^+\), where \(d\) is part of the input, is coRE-complete. Its complement is RE-complete. The hardness reduction already satisfies the promise above.

For the upper coRE bound at this linear inverse stage, no algebraic square-root calculation is necessary. For each rational faithful pair \(R,S\), all matrices \(B_C,D\) and their inverses have rational complex entries. The unnormalized kernel \(K_H=H_0\otimes D^{-1}+\sum_j(H_j^+\otimes B_{A_j}^{-1}+H_j^-\otimes B_{I-A_j}^{-1})\) is rational Hermitian and is congruent to \(X_H(R,S)\) by (O4). Its signature is exactly decidable over rational arithmetic. Enumerating these finite rational baselines enumerates every failure by continuity.

No statement is made that positivity at the scalar level \(d=1\) is hard. Matrix-coefficient dimension is essential in the proved reduction.

## 9. Consequences with proofs and precise scope

### 9.1 No effective complete certificates, even for a positive margin

Suppose a recursively enumerable finite-certificate relation were sound for positivity of rational \(X_H\) in \(\mathcal S_J\), and complete whenever \(X_H\ge\epsilon I\) for some \(\epsilon>0\). Enumerating its certificates on the reduction outputs would enumerate exactly the nonhalting machines: nonhalting outputs have a certificate by (O5), while halting outputs cannot have one by soundness. This contradicts nonhalting not being RE.

The same argument applies when the positive margin \(1\) is supplied as part of the promised input. It excludes a complete effective SOS/Positivstellensatz calculus for this concrete spatial domain. It does not exclude certificates sound and complete for the larger commuting-operator domain.

### 9.2 No total matrix-norm approximation at fixed error

For each rational \(X_H\), calculate a rational bound
\[
B_H\ge\|H_0\|+4\sum_j(\|H_j^+\|+\|H_j^-\|).
\]
Entrywise rational absolute-sum bounds suffice. Let \(C_H=B_H+2\) and \(Y_H=C_HI-X_H\), so every block of \(Y_H\) is positive and at least \(2I\).

Since \(X_H\) is selfadjoint,
\[
\|Y_H\|=C_H-\inf_{\text{finite rational blocks}}\lambda_{\min}(X_H).
\tag{N1}
\]
On the hard promise, nonhalting gives \(\|Y_H\|\le C_H-1\), while halting gives \(\|Y_H\|>C_H+1\). A total additive-\(1/2\) matrix-norm approximation, compared to \(C_H\), would decide halting. Thus even norms of these positive matrix elements have no such total algorithm.

The norm is still lower semicomputable by enumerating finite blocks and increasing finite maxima. What fails is a computable stopping criterion uniformly in \(d,H\) and the required accuracy.

The C*-algebra generated by the concrete system is RFD by its defining family of finite-block evaluations. This is compatible with the Fritz–Netzer–Thom type computability theorem: no effective universal presentation or convergent upper-bound calculus for this C*-algebra has been supplied. If such an upper-bound procedure existed in the specified coordinates, combining it with the finite-evaluation lower bounds would contradict (N1). No claim is made that every alternative presentation of the algebra is noncomputable.

### 9.3 Finite matrix realization: effective barrier and simpler structural obstruction

If a unital complete order embedding of this fixed operator system into some \(M_q\) were given with **computable entries for the images of its 19 specified generators**, then the gapped promise could be decided by finite matrix eigenvalue approximation. Complete order embeddings preserve scalar shifts at every matrix level; hence \(X_H\ge I\) stays above \(I\), and \(X_H+I\not\ge0\) stays nonpositive. This contradicts the hard promise.

Therefore the hardness argument excludes computable finite matrix realizations. It alone says nothing about hypothetical images with noncomputable real entries.

For this particular system, however, a separate elementary argument excludes **every** finite unital order embedding, without computability or the source analytic core. Choose one of the three \(A_i\) effects. Its corresponding normalized single letter \(Z\) has spectrum in \([1/4,3/4]\), and scalar rational faithful baselines realize every rational \(t\) in the open interval: put matching positive diagonal weights on the two physical eigenspaces of the effect. The direct-sum spectrum of \(Z\) is therefore the full closed interval.

Write \(f_+=Z^{-1}\) and \(f_-=(I-Z)^{-1}\). For every \(s\in(1/4,3/4)\),
\[
g_s=s^2f_++(1-s)^2f_--I
=\frac{(Z-sI)^2}{Z(I-Z)}\ge0,
\qquad \inf\sigma(g_s)=0.
\tag{N2}
\]
If a finite unital order embedding sent \(f_+,f_-\) to \(C,D\in M_q\), respectively, then \(C,D\ge(4/3)I\). Order reflection and preservation of shifts would force
\[
G_s=s^2(C+D)-2sD+(D-I)\ge0,\qquad \det G_s=0
\]
for every \(s\) in this interval. Its determinant is a polynomial in \(s\), so it would vanish identically. But \(C+D>0\), and hence \(G_s\) is positive definite for sufficiently large \(|s|\), a contradiction.

This structural non-realizability is already visible in a three-dimensional commutative subsystem. It is not a distinctive undecidability consequence. It is consistent with the general finite-realization theory of Fritz–Netzer–Thom, [Theorem 3.2](https://arxiv.org/html/1609.07908v2): a maximal matrix ordering of a scalar cone has a finite realization exactly when that cone is polyhedral.

### 9.4 No computable spatial witness cutoff

For fixed \(d,n,m\), failure of positivity of (O3) is a first-order real-algebraic question in the entries of \(R,S\), inverse variables for the positive \(B_C,D\), and a witness vector, using the unnormalized kernel \(K_H\). Quantifier elimination decides it. A total computable upper bound from \(d,H\) on sufficient \(n,m\), or on \(nm\), would therefore decide the full order by checking finitely many sizes. Such a bound cannot exist.

This is an effective residual finite-dimensional approximation obstruction: all witnesses remain finite, but their dimensions have no computable uniform ceiling from the input.

## 10. Falsification and verification actually performed

The exact identities (P2)–(P5), positivity of (P6), ordered telescope (T3), polar-column normalization, and compiler square completion were reconstructed algebraically above.

The script sol04_packing_falsification.py independently generated 30 complex positive POVM families, with local dimensions 2 and 3, question counts 2 and 3, and answer counts 2 and 3. It checked the packed decoders, question sums on the root corner, positivity of the three payload effects, and the star norm. The saved receipt sol04_packing_falsification.json reports:

- worst operator-norm packing error \(7.26\cdot10^{-14}\);
- worst question-sum error \(7.21\cdot10^{-14}\);
- minimum three-outcome payload eigenvalue \(0.1616\);
- maximum star norm \(0.3536\).

The same script also builds actual \(6\times6\) physical Choi baselines for a complex qubit payload, with left and right reference dimensions 12, evaluates all nine fixed physical effects, and checks the normalized Jordan extractors as full operators. It uses a full transpose for the right Choi baseline, including its physical and reference indices. The receipt reports maximum honest-extractor error \(3.34\cdot10^{-16}\), maximum centered-letter regularization error \(6.67\cdot10^{-16}\), and minimum eigenvalue \(0.0016666\) of the regularized faithful baselines.

It additionally checks 30 complex matrix instances of the ordered-word compiler with noncommuting \(D,Z_j\), testing (C1), (O4), the root-to-word coefficient convention, and the full residue kernel form. The largest square-completion error is \(2.89\cdot10^{-12}\), inverse-normalization error \(1.46\cdot10^{-14}\), ordered root-graph error \(1.78\cdot10^{-15}\), and full kernel-form error \(2.72\cdot10^{-12}\). The minimum observed excess above the \(4\|r_v\|^2\) penalty bound is \(0.0316\).

Reproduce this receipt by running python3 on work/investigations/sol04_packing_falsification.py.

These finite checks target the new packing identities, the honest fixed-carrier realization, and the compiler's exact algebraic conventions. They do not certify the dimension-uniform Pauli and smoothing estimates, the asymptotic dilation argument, complexity premises, or historical novelty.

The exact falsification targets for independent review are:

1. Whether (A4) really holds for all actual domain instances via the fixed common local dilation and limit; a gap there invalidates the transfer.
2. Whether the descendant set (T1) contains both suffix energies needed in every term of (T3). It does by using all words through degree \(d\).
3. Whether positivity and locality of the decoded smoothed squares survive arbitrary payload POVMs. They do because each decoder is a local polynomial square; no spectral-label relation is needed in soundness.
4. Whether normalization is imposed only on the game root corner in completeness but globally rounded in soundness. Equations (P5), (G3)–(G4) make this distinction explicit.
5. Whether the inverse-normalization congruence is in the correct direction. Equation (O4), rather than its inverse, yields \(Z_j^{-1}\).

## 11. Other substantive avenues examined and why they do not yet yield the desired theorem

### Complete log-Sobolev or Ricci constants of Lindbladians

A reduction would need to turn two arbitrary channels into entropy production of a single CPTP semigroup, while preserving the universal reference quantifier and a computable gap. A signed difference \(\mathcal E-\mathcal F\) does not itself define a Lindblad generator. Adding a depolarizing generator changes the target inequality by a positive state-dependent entropy-production term, which can swamp arbitrarily weak or ill-conditioned violations. The present packing does not remove this obstruction.

Existing positive complete modified log-Sobolev bounds for finite-dimensional GNS-symmetric semigroups, such as [Gao–Rouzé, Complete entropic inequalities for quantum Markov chains, arXiv:2102.04146](https://arxiv.org/abs/2102.04146), concern a different class of inequalities. No undecidability of Lindblad spectral gaps, modified log-Sobolev constants, or noncommutative Ricci curvature is claimed.

### All-representation positivity and tensor-product conjectures

The source hardness lives on finite spatial factors. Replacing that domain by all commuting representations is an extra step, not a formal extension. Mehta–Slofstra–Zhao's all-representation Pos and TrPos problems have separate conjectured \(\Pi^0_2\) classifications. The new fixed-carrier result does not settle those conjectures, Connes embedding, Kirchberg-type questions, or a new case of MIP-co.

### Fixed physical dimension for the final measurement channels

Packing removes growth from the physical denominator alphabet, but not from the ordered-word coefficient graph. Manuscript Section 8 realizes each \(d_0\times d_0\) residue through \(d_0\) independent selected physical cross coordinates and chooses a lower padding dimension \(q_0\) satisfying \(6q_0\ge d_0\). Thus its final channel-input dimension grows.

The exact missing ingredient for fixed-input channel hardness is a physical realization of arbitrarily large ordered-word residue matrices at a fixed physical input dimension, with a global soundness proof on all bases/tangents. Moving those residue coordinates into the untouched reference alone is not justified: the input channel cannot directly address an arbitrary reference label, and unrestricted reference compressions can destroy the spatial denominator domain. The operator-system theorem avoids this missing ingredient by retaining matrix coefficients as matrix levels.

## 12. Consequence assessment

The strongest defensible contribution is a constructive fixed-carrier universality lemma plus a fixed finite-dimensional inverse-Jordan operator system with hard complete matrix order, conditional on the manuscript's analytic core. It is a meaningful sharpening of where the complexity resides: physical effect alphabet and its six-dimensional algebra can be held fixed, while polynomial degree and later matrix level carry the instance.

The broad foundational barrier was known before this investigation, and fixed-generator free-algebra hardness already exists. The proof currently supports a specialized operator-algebra theorem and an exact gap for the stronger fixed-input channel problem. It does not support a claim of a landmark resolution of an independent major open problem.

## 13. Matched comparison: an elementary nine-dimensional spatial system

This comparison prevents the fixed finite-dimensional operator-system formulation itself from carrying an unjustified novelty claim. It is proved here without manuscript Sections 3–14.

Let the four selfadjoint contraction variables be \(X_1,X_2\) on one party and \(Y_1,Y_2\) on the other. The domain comprises all finite spatial evaluations
\[
(X_1\otimes I,\ X_2\otimes I,\ I\otimes Y_1,\ I\otimes Y_2).
\tag{B1}
\]
Take their direct sum over rational contractions in all finite dimensions, and write the resulting four bounded selfadjoint operators as \(V_1,\ldots,V_4\). Define
\[
\mathcal S_{\rm free}=\operatorname{span}_{\mathbb C}
\{I,V_1,\ldots,V_4,V_1^2,\ldots,V_4^2\}.
\tag{B2}
\]
This is one fixed concrete operator system of dimension at most nine.

Pack arbitrary local POVMs into \(U,V\) by (P1), and use the polynomial-square decoders (P4) directly in the four local variables in (B1). The decoders are positive for every selfadjoint variable assignment. Their norms have one effectively computed common bound \(C\) on the contraction domain. Opposite-party decoders commute exactly.

For the score \(B\) and normalization polynomial \(H^{\rm op}\) in (G1), column normalization (G3) gives, with \(L=KC\) and \(C_3=(L+1)^2\),
\[
\langle z,Bz\rangle\le\omega^*(G)+C_3\sqrt{H(z)}.
\tag{B3}
\]
There is no transport error or Pauli anchor. Given the hard game's \(r=3/4,\gamma=1/4\), choose rational
\(\lambda\ge C_3^2/(2\gamma)\) and output
\[
p=rI-B+\lambda H^{\rm op}.
\tag{B4}
\]
If \(\omega^*(G)\le1/2\), scalar square completion gives \(p\ge\gamma I/2=I/8\). If \(\omega^*(G)=1\), a finite packed strategy scoring above \(15/16\), supported on the two label-0 corners, has \(H=0\) and \(p<-3/16\). Thus gapped polynomial positivity on the fixed four-variable spatial contraction domain is coRE-complete. Rational finite evaluations suffice by continuity.

Linearize \(p\) using the suffix graph from Section 7. Write its root form as \(P(z)\), its edge defects as \(r_v=z_v-V_jz_w\), and retain \(b,d_0,L_0\) there. Add the elementary positive penalty
\[
\Lambda\sum_{v=jw}\|z_v-V_jz_w\|^2,\qquad
\Lambda\ge b^2/(2g)+1,\quad g=1/8.
\tag{B5}
\]
Since each \(V_j\) is selfadjoint, the resulting matrix polynomial is
\[
\mathbb L(V)=H_p\otimes I+
\Lambda\sum_{v=jw}
\left(
e_ve_v^*\otimes I
+e_we_w^*\otimes V_j^2
-(e_ve_w^*+e_we_v^*)\otimes V_j
\right).
\tag{B6}
\]
It belongs to \(M_{d_0}(\mathcal S_{\rm free})\). The same recurrence estimates give
\[
\langle z,\mathbb L(V)z\rangle
\ge ga^2-bau+\Lambda u^2
\ge(g/2)a^2+u^2
\ge\eta\|z\|^2,
\quad \eta=\frac{g}{4d_0+2gL_0}.
\tag{B7}
\]
For a high-case negative polynomial witness, choose the exact graph; the penalty vanishes and its norm squared is at most \(d_0\). Scaling by \(\max\{1/\eta,8d_0\}\) yields the same \(+1\) versus \(<-1\) matrix-order promise. Failure is enumerable by rational finite evaluations.

Consequently the rational growing matrix cone of the fixed system (B2) is coRE-complete, and the certificate/norm/computable-realization consequences of Section 9 follow as before. This fully proved comparison does not use Dots' mechanism. Its precise historical priority has not been determined; the purpose here is to show that the broad operator-system consequence cannot by itself demonstrate a major new transfer.

For context, Fritz–Netzer–Thom, [Spectrahedral Containment and Operator Systems with Finite-Dimensional Realization](https://arxiv.org/abs/1609.07908), study when abstract operator systems have finite-dimensional concrete realizations. Their stated containment results concern a different family; no claim is made here to resolve a problem posed in that paper.

## 14. Internal reconstruction of the source analytic chain

This appendix records the algebraic audit behind the imported dependencies (A1)–(A4). It supplies more than a citation to the manuscript, but remains subject to independent review. The source-specific theorem above is conservatively labeled conditional until this analytic chain is independently checked.

### 14.1 Exact weighted representations and inverse-root anchor

In an exact finite local representation let \(r,s>0\) be the positive local marginal operators on opposite tensor factors. They commute. Put \(p=\sqrt r(r+s)^{-1/2}\), \(q=\sqrt s(r+s)^{-1/2}\), so \(p^2+q^2=I\), and let \(j=(r-s)(r+s)^{-1}\). The opposite Pauli triples \(x_i,y_i\) commute across parties, and \(x_i\) commutes with \(s\), while \(y_i\) commutes with \(r\).

For \(T_i=px_ip+qy_iq\), the column \(C:v\mapsto(pv,qv)\) is an isometry. With \(\pi_i=x_i\oplus y_i\),
\[
T_i=C^*\pi_iC,\qquad
\rho_i=\pi_iCv-CT_iv,\qquad
\|\rho_i\|^2=e_i(v):=\langle v,(I-T_i^2)v\rangle.
\tag{A5}
\]
The orthogonal complementary column \((q,-p)\) shows
\[
d_i=qx_ipv-py_iqv,\qquad \|d_i\|^2=e_i(v).
\tag{A6}
\]
Let \(U_i=px_ip-qy_iq\). Comparing \(T_iT_jv\) with \(C^*\pi_i\pi_jCv\), using opposite chirality, yields
\[
\|[T_i,T_j]v+2iU_kv\|\le\sqrt{e_i(v)}+\sqrt{e_j(v)}
\tag{A7}
\]
for cyclic \((i,j,k)\). Thus, with \(c(v)=\sum_{\rm cyclic}\|[T_i,T_j]v\|^2\),
\[
\sum_i\|U_iv\|^2\le(3/4)c(v)+(3/2)\sum_i e_i(v).
\tag{A8}
\]

Set \(A=r^{-1},B=s^{-1},F=A+B,a=\sqrt A,b=\sqrt B,\xi=F^{-1/2}v,\alpha=a\xi,\beta=b\xi\). All functions of \(A,B\) commute; \(x_i\) commutes with \(b\), and \(y_i\) with \(a\). Direct multiplication gives
\[
d_i=F^{-1/2}ab(x_i-y_i)\xi,\quad
U_iv=F^{-1/2}(B x_i-A y_i)\xi,
\]
\[
x_i\beta-y_i\alpha
=F^{1/2}(a+b)^{-1}(U_iv+d_i).
\tag{A9}
\]
The multiplier in the last line has norm at most one by
\(\sqrt{a^2+b^2}\le a+b\). Consequently
\[
E_*:=\sum_i\|x_i\beta-y_i\alpha\|^2
\le2\sum_i(\|U_iv\|^2+e_i(v))
\le5\delta(v).
\tag{A10}
\]

The commuting involutions \(x_iy_i\) obey \(\sum_i x_iy_i=4P-I\), where \(P\) is the Bell projection for the two opposite Pauli factors, and \(Q=I-P\). Expanding \(E_*\) gives
\[
E_*=3\|P(\alpha-\beta)\|^2+
3\|Q\alpha\|^2+3\|Q\beta\|^2+
2\operatorname{Re}\langle Q\alpha,Q\beta\rangle.
\tag{A11}
\]
Hence \(\|\alpha-\beta\|^2\le E_*\), and
\(\|Q\alpha\|^2+\|Q\beta\|^2\le E_*/2\).
The commuting-functional-calculus inequalities
\[
\|v-(\alpha+\beta)/\sqrt2\|\le\|\alpha-\beta\|/\sqrt2,
\qquad
\|jv\|\le\sqrt2\|\alpha-\beta\|
\]
give
\[
\|Qv\|^2,\ \|jv\|^2\le10\delta(v),\qquad
\|(p-1/\sqrt2)v\|^2,\ \|(q-1/\sqrt2)v\|^2\le5\delta(v).
\tag{A12}
\]
Writing \(\rho_i=(a'_i,b'_i)\) gives \(U_iv=jT_iv+pa'_i-qb'_i\). Combining (A7) with Cauchy–Schwarz gives the conservative
\[
\|jT_iv\|\le2\sqrt{\delta(v)}.
\]
Also
\[
\|T_iv-x_iv\|
\le\|U_iv\|+\|jv\|+(1+\sqrt2)\sqrt{e_i(v)}
\le7\sqrt{\delta(v)}.
\tag{A13}
\]
No inverse marginal norm enters any constant.

### 14.2 Weak polynomial transport

Let \(K_i=(x_i+y_i)/2\). On Bell vectors,
\(K_iPv=x_iPv\) and \(K_ix_jPv=\delta_{ij}Pv\).
The anticommutator version of the compression comparison, together with (A7), gives
\[
\|T_iT_jv\|\le\sqrt{\delta(v)}\ (i\ne j),\qquad
\|(T_i^2-I)v\|\le\sqrt{e_i(v)}.
\]
Reduce adjacent pairs from the right, always acting on the original vector after each exact replacement. Unreduced prefixes are contractions, so for a word \(w\) of length \(d\),
\[
\|T_wv-K_wPv\|
\le(\lfloor d/2\rfloor+\sqrt{10}+7\,1_{\{d\ {\rm odd}\}})
\sqrt{\delta(v)},
\]
\[
\|jT_wv\|\le(\lfloor d/2\rfloor+\sqrt{10}+2)\sqrt{\delta(v)}.
\tag{A14}
\]
The second follows by finishing with \(jv\) or \(jT_iv\), rather than by controlling energy on a new descendant.

For a payload contraction \(a_g,b_g\) commuting with its respective Pauli factor, put \(K_{H,g}=(x_Ha_g+y_Hb_g)/2\). In a matrix element of \(T_{H,g}=px_Ha_gp+qy_Hb_gq\), move the exterior weights to the tested word vectors and replace them by \(1/\sqrt2\) using (A14). Replace the tested Pauli words using the first line of (A14). For \(|u|,|t|\le d\), this proves
\[
\left|\langle T_uw,T_{H,g}T_tv\rangle-
\langle K_uPw,K_{H,g}K_tPv\rangle\right|
\le C_d\left(\|w\|\sqrt{\delta(v)}+\|v\|\sqrt{\delta(w)}\right),
\]
\[
C_d=\sqrt2(\lfloor d/2\rfloor+\sqrt{10}+2)
+\lfloor d/2\rfloor+\sqrt{10}+7.
\tag{A15}
\]
Each raw extractor (A3) has degree at most four, monomial coefficient sum at most nine, and exactly one payload occurrence per monomial. In the balanced model it equals \(a_g\) or \(b_g\) as a full operator. Expanding into these monomials, using (A15) with \(d=3\), and removing the Bell projections (payloads commute with \(P\)) proves
\[
|\langle w,(P_g-a_g)v\rangle|
\le200\left(\|w\|\sqrt{\delta(v)}+\|v\|\sqrt{\delta(w)}\right),
\tag{A16}
\]
because \(9C_3+\sqrt{10}<200\). The same holds for \(Q_g-b_g\).

### 14.3 Local averaging and action transport

Let \(\Lambda=\log r-\log s\), \(G=e^{-\Lambda^2/2}\), \(x_0=I\), and
\[
M_0=\frac{P+\sum_{i=0,X,Y,Z}x_iGx_i}{5}.
\tag{A17}
\]
This is a positive contraction. It is also an average of product-local unitaries: \(P=(I+\sum_i x_iy_i)/4\), and the Gaussian Fourier identity writes \(G\) as an average of \(r^{it}s^{-it}\). Therefore every integer power \(M_0^s\) is an average \(\mathbb E_\omega(U_\omega\otimes V_\omega)\), using the same probability measure for every payload.

Put
\[
E_0(v)=\|Qv\|^2+\sum_{i=0,X,Y,Z}\|jx_iv\|^2,\qquad
E_M(v)=\langle v,(I-M_0)v\rangle.
\]
The scalar inequalities
\(\tanh^2(t/2)\le1-e^{-t^2/2}\le8\tanh^2(t/2)\)
and \(j=\tanh(\Lambda/2)\) give
\[
E_0(v)/5\le E_M(v)\le8E_0(v)/5.
\tag{A18}
\]
Using (A12)–(A13), \(E_0(v)\le263\delta(v)\), so \(E_M(v)\le421\delta(v)\).

For the reverse inequality write \(h_i=\|jx_iv\|\), \(h_0=\|jv\|\), \(b_0=\|Qv\|\). Expanding \(d_i\) and \(U_i\) around \(p=q=1/\sqrt2\), and using \(\|(x_i-y_i)v\|\le2b_0\), gives
\[
\|d_i\|,\ \|U_iv\|
\le\sqrt2h_0+h_i+2b_0\le\sqrt{7E_0(v)}.
\tag{A19}
\]
In this expansion a weight defect applied to \(y_iv\) can be replaced by one applied to \(x_iv\), with an extra \(2b_0\); no commutation of a weight with its own Pauli factor is assumed. Equation (A7) now yields
\(\|[T_i,T_j]v\|\le4\sqrt{7E_0(v)}\).
Thus \(\delta(v)\le357E_0(v)\le1785E_M(v)\le3000E_M(v)\).

Positive-contraction functional calculus consequently gives
\[
\delta(M_0^s w)\le\frac{3000}{2s+1}\|w\|^2,\qquad
\|(I-M_0^s)v\|\le\sqrt{sE_M(v)}.
\tag{A20}
\]
Define \(a_g^{(s)}=\mathbb E U_\omega a_gU_\omega^*\), and similarly \(b_g^{(s)}\). Positivity, contraction bounds, locality, and normalization all hold for this common averaging. Applying (A16) with \(w\) replaced by \(M_0^s w\) and taking the dual supremum gives
\[
\|M_0^s(P_g-a_g)v\|
\le200\sqrt{\delta(v)}+
200\sqrt{3000/(2s+1)}\|v\|.
\]
The exact unitary-average identity
\[
\mathbb E\|(U_\omega\otimes V_\omega)v-v\|^2
=2\langle v,(I-M_0^s)v\rangle\le2sE_M(v)
\]
implies
\(\|M_0^s a_gv-a_g^{(s)}v\|\le\sqrt{2sE_M(v)}\).
Finally separate \(P_gv-M_0^sP_gv\) and use (A20), obtaining exactly (A4), including the \(\delta(P_gv)\) term. The four constants are bounded by the stated \(12000\) action estimate.

### 14.4 Arbitrary compressed maps: the common local dilation limit

For an actual faithful baseline, its marginally normalized map on \(M_2\otimes\mathbb C^3\) is UCP. Choose one finite local Stinespring isometry \(J_A\) for the whole left algebra, and one \(J_B\) for the whole right algebra. These are fixed for the instance and are used for every effect. With \(\Pi_A=J_AJ_A^*\), extend the positive marginal by
\[
W_\epsilon=J_AWJ_A^*+\epsilon(I-\Pi_A),
\]
and extend \(V\) identically on the right. For each \(\epsilon>0\) these are strictly positive exact-representation weights, so the preceding proof applies on the finite enlarged product space.

Their common \(D_\epsilon=r_\epsilon+s_\epsilon\) leaves the original product subspace invariant and restricts to the original \(D\). The compression of every centered normalized letter is exactly the original centered letter. An off-subspace output from a vector in the original product subspace contains a factor \(\sqrt\epsilon\) from the corresponding local weight; its denominator is bounded below by the opposite original marginal, which is positive for this fixed instance. Hence the off-subspace action tends to zero.

All centered letters are contractions uniformly in \(\epsilon\). Induction therefore gives action convergence for every fixed finite word, and hence convergence of all polynomial expectations and descendant energies used above. The Pauli representations, Bell projector, and embedding isometries remain fixed throughout.

For each positive \(\epsilon\), perform smoothing and column normalization on the enlarged local spaces. They produce an ordinary finite-dimensional game strategy and are bounded by \(\omega^*(G)\). The final scalar inequality contains only finitely many original-letter polynomial expectations, so it passes to the limit. The averaged payloads themselves need not have a limit, and no rate uniform in dimensions or condition numbers is asserted or required.
