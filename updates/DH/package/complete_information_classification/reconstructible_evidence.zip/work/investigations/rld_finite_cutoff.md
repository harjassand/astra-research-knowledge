# An elementary finite reference cutoff for complete Petz order two

11 October 2026. Sol05 derivation, independently reconstructed by the root agent.

## Main theorem

Let `E=(E_i)_(i=1)^u` and `F=(F_j)_(j=1)^v` be finite POVMs on the same finite-dimensional input. Discard zero effects. No rationality is needed for the mathematical statement.

**Theorem.** If complete standard Petz Rényi order-two dominance of `E` over `F` fails, it has a faithful state-pair witness with reference dimension at most

\[
\boxed{1+v.}
\]

Consequently complete order-two dominance for rational POVMs is decidable by real quantifier elimination at finitely many explicitly bounded reference dimensions. In particular this applies to rational complex strictly positive POVMs.

This theorem and the proof below are independent of the manuscript's nonlocal-game reduction, N402/N403, operator-convex localization, free Positivstellensatz, and any uniform condition-number bound. Root independently checked the normalization, exact target preservation, decrease of source quadratic terms under compression, and restoration of a faithful state/tangent without finding a defect. Historical priority and external review remain unconfirmed.

## 1. Order two is exactly an RLD quadratic comparison

For positive `A` and Hermitian `K`, write

\[
\mathcal G_A(K)=\operatorname{Tr}KA^{-1}K
=\operatorname{Tr}K^2A^{-1}.
\]

The standard Petz order-two divergence is

\[
D_2(A\Vert B)=\log Q_2(A,B),\qquad
Q_2(A,B)=\operatorname{Tr}A^2B^{-1}.
\]

For a faithful input state `rho`, a traceless Hermitian tangent `H`, and either measurement channel, write `A_i=M_i(rho)` and `K_i=M_i(H)`. An exact expansion gives

\[
Q_2(M_R(\rho+tH),M_R(\rho))
=1+t^2\sum_i\mathcal G_{A_i}(K_i).
\tag{1}
\]

There is no remainder. The linear term is `2t Tr H=0`.

Thus complete `D_2` comparison on all faithful pairs implies complete comparison of the RLD quadratic forms by taking any sufficiently small nonzero `t`. Conversely, given any faithful pair `alpha,beta`, set `rho=beta`, `H=alpha-beta`, and `t=1` in the same exact expansion. Complete RLD comparison gives complete `Q_2`, hence `D_2`, comparison. Boundary numerators follow by continuity with a faithful denominator; the usual inverse/support regularization gives the extended boundary convention when the denominator also has a kernel.

Every nonzero measurement effect has a positive-definite output block on a faithful physical-reference input, so all inverses used below exist.

## 2. Normalize the reference marginal by a local congruence

Suppose an RLD violation is witnessed by a faithful input `R` on `C^a tensor C^n` and a traceless Hermitian tangent `H`. Put

\[
W=\operatorname{Tr}_aR>0,\qquad
\widetilde R=(I_a\otimes W^{-1/2})R(I_a\otimes W^{-1/2}),
\quad
h=(I_a\otimes W^{-1/2})H(I_a\otimes W^{-1/2}).
\]

Then

\[
\widetilde R>0,\qquad\operatorname{Tr}_a\widetilde R=I_n,
\]

and `h` is Hermitian. No trace constraint on `h` is needed.

For a physical effect `M_i`, abbreviate

\[
r_i=\operatorname{Tr}_a[(M_i\otimes I)\widetilde R],\qquad
k_i=\operatorname{Tr}_a[(M_i\otimes I)h].
\]

The original output blocks are `W^(1/2) r_i W^(1/2)` and `W^(1/2) k_i W^(1/2)`. Direct cancellation of the congruence factors gives

\[
\mathcal G_{W^{1/2}r_iW^{1/2}}(W^{1/2}k_iW^{1/2})
=\operatorname{Tr}Wk_ir_i^{-1}k_i.
\tag{2}
\]

Define the Hermitian reference operator

\[
\mathcal D(\widetilde R,h)
=\sum_{i=1}^u k_i^Er_i^{E,-1}k_i^E
-\sum_{j=1}^v k_j^Fr_j^{F,-1}k_j^F.
\tag{3}
\]

The original violation is

\[
\operatorname{Tr}W\mathcal D(\widetilde R,h)<0.
\]

Therefore there is a unit reference vector `xi` with

\[
\langle\xi,\mathcal D(\widetilde R,h)\xi\rangle<0.
\tag{4}
\]

Equivalently, complete RLD dominance is positivity of (3) at every normalized faithful `Rtilde`, every Hermitian `h`, and every matrix size. The converse part of this equivalence is proved explicitly in Section 4 below; it is not an assumption about an enlarged domain.

## 3. Compress only the target's inverse-action vectors

For each target outcome define

\[
z_j=(r_j^F)^{-1}k_j^F\xi,\qquad
S=\operatorname{span}\{\xi,z_1,\ldots,z_v\}.
\]

Let `d=dim S <= 1+v`, and let `V:C^d -> C^n` be an isometry onto `S`. Compress the **entire** baseline and tangent using this same reference isometry:

\[
\widetilde R'=(I_a\otimes V^*)\widetilde R(I_a\otimes V),
\qquad h'=(I_a\otimes V^*)h(I_a\otimes V).
\tag{5}
\]

This preserves the actual physical-reference domain:

\[
\widetilde R'>0,\qquad
\operatorname{Tr}_a\widetilde R'=I_d,
\qquad h'=h'^*.
\]

Every output block compresses by that same `V`:

\[
r_i'=V^*r_iV>0,\qquad k_i'=V^*k_iV.
\]

Let `xi'=V^*xi`, a unit vector. For a target outcome, `z_j` belongs to `S`, so

\[
r_j^{F\prime}(V^*z_j)
=V^*r_j^Fz_j
=V^*k_j^F\xi
=k_j^{F\prime}\xi'.
\]

Thus its compressed inverse solution is exactly `V^*z_j`, and

\[
\langle\xi',k_j^{F\prime}r_j^{F\prime,-1}k_j^{F\prime}\xi'\rangle
=\langle\xi,k_j^Fr_j^{F,-1}k_j^F\xi\rangle.
\tag{6}
\]

Every target quadratic term is preserved **exactly**.

For a source outcome, use the elementary variational identity

\[
\langle u,r^{-1}u\rangle
=\sup_z\{2\operatorname{Re}\langle u,z\rangle-\langle z,rz\rangle\}.
\tag{7}
\]

The compressed expression optimizes the same function only over vectors in `S`. Consequently

\[
\langle\xi',k_i^{E\prime}r_i^{E\prime,-1}k_i^{E\prime}\xi'\rangle
\leq\langle\xi,k_i^Er_i^{E,-1}k_i^E\xi\rangle.
\tag{8}
\]

Source quadratic terms can only decrease. Combining (4), (6), and (8) gives

\[
\langle\xi',\mathcal D(\widetilde R',h')\xi'\rangle
\leq\langle\xi,\mathcal D(\widetilde R,h)\xi\rangle<0.
\tag{9}
\]

This is the finite-dimensional compression step. It retains actual physical blocks and uses no tensor-mixing compression or unrestricted substitution of operator tuples.

## 4. Restore a faithful state and a traceless Hermitian tangent

For sufficiently small positive `eta`, the faithful reference state

\[
W_\eta=(1-\eta)|\xi'\rangle\langle\xi'|+\eta I_d/d
\]

satisfies `Tr W_eta D(Rtilde',h')<0` by (9) and continuity. Define

\[
R'=(I_a\otimes W_\eta^{1/2})\widetilde R'(I_a\otimes W_\eta^{1/2}),
\qquad
H_0'=(I_a\otimes W_\eta^{1/2})h'(I_a\otimes W_\eta^{1/2}).
\]

Then `R'>0` and

\[
\operatorname{Tr}R'=\operatorname{Tr}W_\eta=1.
\]

Equation (2) shows that the source-minus-target RLD difference at `(R',H_0')` is strictly negative.

To impose the trace constraint, put

\[
c=\operatorname{Tr}H_0',\qquad H'=H_0'-cR'.
\]

Then `Tr H'=0`. This adjustment preserves the source-minus-target difference. Indeed

\[
\mathcal G_A(K-cA)
=\mathcal G_A(K)-2c\operatorname{Tr}K+c^2\operatorname{Tr}A,
\]

and both channels preserve trace, so the last two terms cancel in their difference.

There is even an exact normalized operator identity behind this trace argument: replacing `h'` by `h'-c Rtilde'` replaces each `k_i'` by `k_i'-c r_i'`, and hence changes (3) by

\[
-2c\left(\sum_i k_i^{E\prime}-\sum_j k_j^{F\prime}\right)
+c^2\left(\sum_i r_i^{E\prime}-\sum_j r_j^{F\prime}\right)=0.
\]

The sums are equal because the two POVMs both sum to identity.

For sufficiently small nonzero `t`, both `R'` and `R'+tH'` are faithful states. Equation (1) gives a strict order-two violation at this pair, with reference dimension `d<=1+v`. This proves the theorem.

## 5. A finite exact decision procedure

For a fixed reference dimension `d`, existence of an RLD violation is a first-order real-algebraic question. Use real and imaginary coordinates for a faithful density matrix `R`, traceless Hermitian tangent `H`, and Hermitian inverse variables `T_i` satisfying

\[
T_iM_i(R)=I_d.
\]

Impose positivity, Hermiticity and normalization by polynomial conditions. The RLD difference is the real polynomial

\[
\sum_i\operatorname{Tr}[M_i^E(H)T_i^EM_i^E(H)]
-\sum_j\operatorname{Tr}[M_j^F(H)T_j^FM_j^F(H)].
\]

Ask whether it is strictly negative. Nonzero effects and `R>0` ensure the required output inverses exist. For rational complex effects, all real polynomial coefficients are rational.

Real quantifier elimination decides this question. The theorem says that complete order holds if and only if no violation exists at any dimension `1,...,1+v`. This is a total exact algorithm. It need not be efficient.

## 6. General finite-channel version

The same elementary proof gives a broader bound. If `Q` is an arbitrary finite channel with effective output dimension `b`, failure of complete Petz order-two dominance `P over Q` has a reference witness of dimension at most

\[
\boxed{1+b^2.}
\]

Here is the additional detail needed beyond the POVM proof. Normalize the input by `W` exactly as above, and put

\[
A_\Phi=\Phi_R(\widetilde R),\qquad
K_\Phi=\Phi_R(h),
\]

\[
\mathcal D=\operatorname{Tr}_{\mathrm{out}(P)}K_PA_P^{-1}K_P
-\operatorname{Tr}_{\mathrm{out}(Q)}K_QA_Q^{-1}K_Q.
\]

Choose a negative reference vector `xi`. For an orthonormal target output basis `e_c`, define

\[
z_c=A_Q^{-1}K_Q(e_c\otimes\xi),\qquad 1\leq c\leq b.
\]

Each `z_c` has `b` reference components. Take `S` to span `xi` and all those components, so `dim S<=1+b^2`. Then every `z_c` belongs to `C^b tensor S`. Compression of the input by the reference isometry commutes with either channel. Thus the compressed target inverse problem has exactly the same solution `z_c` in each basis component, preserving the target partial-trace quadratic form on `xi`. The source components decrease by the same variational argument (7). Restoration of `W_eta` and scalar trace gauge is unchanged, using trace preservation instead of POVM normalization. Effective output supports are fixed throughout.

For measurement channels, block diagonality means each target inverse solution has only one output component, giving the sharper `1+v` bound above.

This finite-channel generalization has the same proof status as the POVM theorem; no external priority or kernel certification has been completed.

## 7. Consequence for the proposed open-range universality theorem

The coherent-reference localization proof in `root_universality.tex` and `sol05_radical.md` shows that fixed Petz orders `0<alpha<2` induce complete SLD order. The present elementary theorem shows that the quadratic endpoint has a finite reference cutoff and an exact decision procedure.

**Conditional POVM separation.** If the supplied manuscript's coRE-completeness theorem for complete SLD dominance on rational strictly positive POVMs is correct, complete Petz order two is strictly weaker than complete SLD order on that same class. Otherwise equality with the decidable endpoint would make complete SLD dominance decidable, a contradiction. This proves existence of a separating rational strictly positive POVM pair conditional on the manuscript hardness theorem; it does not give explicit matrices for such a pair. Section 9 gives an unconditional, explicit separation for general channels.

The finite-cutoff theorem itself needs none of that hardness premise. The logical status is therefore:

- Finite endpoint cutoff and decidability: proved here independently.
- Open-range analytic equivalence: separately developed proof.
- Strict separation on rational strictly positive POVMs: follows if the manuscript hardness reduction is valid.
- An explicit numerical separating endpoint pair: not constructed in this investigation.

The earlier free-rational-positivity route was useful for identifying the domain distinction, but is unnecessary for the proof. In one-sided RLD inverse actions, a common reference compression preserves the actual domain and keeps target solutions. In the two-sided tensor-Jordan SLD construction, the analogous compression need not preserve the two local factors. This is the exact structural boundary explaining why the elementary cutoff works here.

## 8. Scoped numerical diagnostic

`rld_cutoff_diagnostic.py` checks the proof's identities on a noncommuting qubit measurement example with an eleven-dimensional initial reference and a three-dimensional compressed reference. The result in `rld_cutoff_diagnostic.json` preserves both target quadratic terms to within `5.7e-14`; both source terms decrease (by approximately `0.0483` and `0.0536`). The negative vector value changes from `-77.9462` to `-78.0481`, and restoration gives a faithful state with minimum eigenvalue `5.94e-6`, traceless tangent, and RLD difference `-78.0452`. These floating point checks diagnose implementation errors; the algebraic proof above establishes the theorem.

## 9. Independent review: explicit unconditional general-channel separation

The efficient-instrument example from `sol02_operational.md`, Section 8, survives independent algebraic falsification attempts. Let a POVM have invertible effects, set `K_i=sqrt(E_i)`, and define the channel

\[
\mathcal I_E(\rho)=\bigoplus_iK_i\rho K_i.
\]

For any finite untouched reference put `G_i=K_i tensor I`. If `beta>0` and `alpha>=0`, direct cancellation and cyclicity give

\[
\begin{aligned}
Q_2(\mathcal I_{E,R}(\alpha),\mathcal I_{E,R}(\beta))
&=\sum_i\operatorname{Tr}(G_i\alpha G_i)^2
                   (G_i\beta G_i)^{-1}\\
&=\sum_i\operatorname{Tr}(E_i\otimes I)\alpha\beta^{-1}\alpha\\
&=\operatorname{Tr}\alpha^2\beta^{-1}=Q_2(\alpha,\beta).
\end{aligned}
\]

This also establishes the exact RLD identity by replacing the two occurrences of `alpha` in the quadratic expression with a Hermitian tangent `H`. For a singular denominator, invertibility of every `G_i` makes `supp(G_i alpha G_i) subset supp(G_i beta G_i)` equivalent to `supp(alpha) subset supp(beta)`. If inclusion fails, both sides are infinite. If it holds, the same trace identity follows by restricting the inverse to the denominator support (or by positive regularization). Thus the identity holds with the standard extended support convention, for every state pair and every reference. No commutativity assumption is used.

Nevertheless take `E_±=(I±tZ)/2`, `0<t<1`, `rho=I/2`, and `H=X/2`. The input SLD form is `g_rho(H)=1`. In each output block the baseline eigenvalues are `(1+t)/4` and `(1-t)/4` in either order, and the off-diagonal tangent entries are `sqrt(1-t^2)/4`. With `g_A(B)=2 sum_(j,k) |B_jk|^2/(a_j+a_k)`, each block contributes `(1-t^2)/2`. Therefore

\[
g_{\mathcal I_E(\rho)}(\mathcal I_E(H))=1-t^2<1.
\]

Consequently `P=I_E` and `Q=id` have exact complete Petz order-two equality, while `P` fails SLD dominance over `Q` already without a reference. The separation is unconditional. It can be made rational as a channel: choose `t=3/5`, so the two Kraus matrices are `diag(2,1)/sqrt(5)` and `diag(1,2)/sqrt(5)`. Their conjugation maps have rational coefficients, and the displayed SLD values are `16/25` and `1`. This example has a quantum output within each instrument block and hence does not supply the still-missing explicit POVM separation.
