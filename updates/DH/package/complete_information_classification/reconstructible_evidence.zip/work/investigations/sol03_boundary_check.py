"""Exact checks for sol03_boundary.md; these support, not replace, the proofs."""

import json
from pathlib import Path
import sympy as s


def partial_physical(A, R, h, n):
    return s.Matrix(n, n, lambda u, v: sum(
        A[p, q] * R[q*n+u, p*n+v]
        for p in range(h) for q in range(h)
    ))


def choi(phi, h):
    out = phi(s.eye(h)).rows
    return s.Matrix(h*out, h*out, lambda a, b: phi(
        s.Matrix(h, h, lambda u, v: int(u == a//out and v == b//out))
    )[a % out, b % out])


h, n = 2, 3
omega = s.zeros(h*n, 1)
omega[0, 0] = 1
omega[4, 0] = 1
R = s.Rational(3, 4)*omega*omega.T + s.eye(6)/8
W = partial_physical(s.eye(2), R, 2, 3)
D = s.kronecker_product(W, s.eye(3)) + s.kronecker_product(s.eye(3), W)
invroot = s.diag(*[1/s.sqrt(D[j, j]) for j in range(9)])
V = s.zeros(9, 2)
for j in range(2):
    V[3*j+2, j] = 1/s.sqrt(2)
    V[6+j, j] = 1/s.sqrt(2)


def compressed(A):
    AR = partial_physical(A, R, 2, 3)
    B = s.kronecker_product(AR, s.eye(3)) + s.kronecker_product(s.eye(3), AR.T)
    return s.simplify(V.T*invroot*B*invroot*V)


def formula(A):
    return s.Rational(3, 10)*(A+A.T) + s.trace(A)*s.eye(2)/5


for u in range(2):
    for v in range(2):
        A = s.Matrix(2, 2, lambda a, b: int(a == u and b == v))
        assert compressed(A) == formula(A)
assert V.T*V == s.eye(2)
assert W == s.diag(1, 1, s.Rational(1, 4))
J = choi(formula, 2)
antisymmetric = s.Matrix([0, 1, -1, 0])
assert J*antisymmetric == -antisymmetric/10
assert choi(lambda A: formula(A.T), 2) == J

# Four strictly positive rational effects spanning Herm(2).
sx = s.Matrix([[0, 1], [1, 0]])
sy = s.Matrix([[0, -s.I], [s.I, 0]])
sz = s.diag(1, -1)
spanning = [s.eye(2)/2] + [(s.eye(2)+P/2)/2 for P in (sx, sy, sz)]
assert s.Matrix.hstack(*[A.reshape(4, 1) for A in spanning]).rank() == 4
for A in spanning:
    assert min(A.eigenvals()) > 0

# A rational independent POVM and signed postprocessing example for the
# finite Gram identity; choose honest stochastic postprocessing for positivity.
vectors = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]
effects = [(s.eye(2)+(x*sx+y*sy+z*sz)/4)/4 for x, y, z in vectors]
d = s.Matrix([[s.Rational(1, 2), s.Rational(1, 3), s.Rational(1, 4), s.Rational(1, 5)],
              [s.Rational(1, 3), s.Rational(1, 2), s.Rational(1, 4), s.Rational(2, 5)],
              [s.Rational(1, 6), s.Rational(1, 6), s.Rational(1, 2), s.Rational(2, 5)]])
target = [sum((d[j, i]*effects[i] for i in range(4)), s.zeros(2)) for j in range(3)]
blocks = [[(target[j] if j == l else s.zeros(2)) -
           sum((d[j, i]*d[l, i]*effects[i] for i in range(4)), s.zeros(2))
           for l in range(3)] for j in range(3)]
Gram = s.BlockMatrix(blocks).as_explicit()
assert Gram == Gram.H
for row in blocks:
    assert sum(row, s.zeros(2)) == s.zeros(2)
# PSD follows by stochastic covariance decomposition; check exact principal minors.
principal_minors = []
import itertools
for size in range(1, Gram.rows+1):
    for indexes in itertools.combinations(range(Gram.rows), size):
        determinant = s.simplify(Gram.extract(indexes, indexes).det())
        assert determinant >= 0
        principal_minors.append(determinant)

result = {
    "status": "EXACT_CHECKS_PASS",
    "R_eigenvalues": {str(x): mult for x, mult in R.eigenvals().items()},
    "marginal": str(W),
    "compressed_map": "Theta(A)=3(A+A^T)/10+Tr(A)I/5",
    "Choi_matrix": str(J),
    "Choi_eigenvalues": {str(x): mult for x, mult in J.eigenvals().items()},
    "antisymmetric_eigenvalue": "-1/10",
    "transpose_invariance": True,
    "strictly_positive_effect_span_rank": 4,
    "independent_POVM_Gram_principal_minors_checked": len(principal_minors),
    "limits": "Finite algebra checks; not a verification of manuscript hardness or novelty.",
}
output = Path(__file__).with_suffix(".json")
output.write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
