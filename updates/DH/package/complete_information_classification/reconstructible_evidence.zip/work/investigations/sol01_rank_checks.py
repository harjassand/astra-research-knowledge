"""Exact finite check of the rank-four baseline/numerator construction."""
import json
from functools import reduce
import sympy as s

a, ell = 4, 3
d = a + ell
tau, lam = s.Rational(1, 20), s.Rational(1, 1000)
delta = lam * tau / 100
paulis = [s.Matrix([[0, 1], [1, 0]]),
          s.Matrix([[0, -s.I], [s.I, 0]]),
          s.diag(1, -1)]
payloads = [s.diag(1, 0), s.diag(0, 1)]
v = [1, 1 + s.I, 2 - s.I]
V = s.zeros(d)
for j, z in enumerate(v):
    V[0, a + j] = z
quadratures = [V + V.adjoint(), s.I * V - s.I * V.adjoint()]
effects_e, effects_f, weights = [], [], []
active_terms = 0
for sigma in paulis:
    for payload in payloads:
        raw = (s.eye(a) + tau * s.kronecker_product(sigma, payload)) / 2
        D = lam * s.diag(raw, s.eye(ell) / 2)
        Dc = lam * s.diag(s.eye(a) - raw, s.eye(ell) / 2)
        for O in quadratures:
            active_terms += 1
            for sign in [-1, 1]:
                effects_e.append((D + sign * delta * O) / 2)
                effects_f.append(D / 2)
                weights.append(lam / 4)
            for _ in range(2):
                effects_e.append(Dc / 2)
                effects_f.append(Dc / 2)
                weights.append(lam / 4)
filler_weight = 1 - active_terms * lam
effects_e.append(filler_weight * s.eye(d))
effects_f.append(filler_weight * s.eye(d))
weights.append(filler_weight)
N = s.ilcm(*[w.q for w in weights])
normalization = sum(effects_e, s.zeros(d)) == s.eye(d)
matching = all(s.trace(e) == s.trace(f) == d * w
               for e, f, w in zip(effects_e, effects_f, weights))
ranks = [(e - w * s.eye(d)).rank() for e, w in zip(effects_e, weights)]
ranks += [(f - w * s.eye(d)).rank() for f, w in zip(effects_f, weights)]
split_ranks = [(e / (N * w) - s.eye(d) / N).rank()
               for e, w in zip(effects_e, weights)]
result = {"method": "exact SymPy rational complex arithmetic", "physical_dimension": d,
          "pre_split_outcomes": len(effects_e), "uniform_split_outcomes": int(N),
          "normalization_exact": normalization, "matching_traces_exact": matching,
          "maximum_deviation_rank": max(ranks), "maximum_split_deviation_rank": max(split_ranks),
          "filler_deviation_rank": (effects_e[-1] - weights[-1] * s.eye(d)).rank(),
          "scope": "Finite check of the rank argument, not the game reduction."}
result["status"] = "PASS" if normalization and matching and max(ranks) <= 4 else "FAIL"
print(json.dumps(result, indent=2))
