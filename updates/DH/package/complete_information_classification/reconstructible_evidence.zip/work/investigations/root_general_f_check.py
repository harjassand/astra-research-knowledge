"""Finite diagnostic checks of the proposed reference-filter identities.

These checks verify algebra on finitely many matrices, not universal positivity,
undecidability, novelty, or a theorem in a formal proof kernel.
"""
import json
from pathlib import Path
import numpy as np

def overlap(a, b, alpha):
    x, u = np.linalg.eigh(a)
    y, v = np.linalg.eigh(b)
    return float(np.sum(x[:, None]**alpha * y[None, :]**(1-alpha)
                        * np.abs(u.conj().T @ v)**2).real)

def check_hessian(seed, s):
    rng = np.random.default_rng(seed)
    d, n = 3, 4
    eigs = rng.uniform(.15, 1, d)
    eigs /= eigs.sum()
    a = np.diag(eigs)
    k = rng.normal(size=(d,d)) + 1j*rng.normal(size=(d,d))
    k = (k+k.conj().T)/2
    k -= np.trace(k).real/d*np.eye(d)
    lam = rng.uniform(.3, 3, n)
    w0, wd, p = .9, 1.2, .17
    w = rng.normal(size=n) + 1j*rng.normal(size=n)
    v = np.ones(n)/np.sqrt(n)
    weights = np.r_[w0, lam, wd]
    z = weights.sum()
    l = np.zeros((n+2,n+2), complex)
    l[0,1:n+1] = w.conj()
    l[1:n+1,0] = w
    b = np.kron(a, np.diag(weights))/z
    y = np.kron(k,l)/z
    vv = np.r_[0,v,0]
    direct = 0.0
    for i, ai in enumerate(eigs):
        r = p*ai
        basis = np.eye(d)[:,i]
        u = np.kron(basis,vv)
        inv = np.linalg.inv(r*np.eye(d*(n+2))+s*b)
        direct += (2*r*r*(s+1)**2*np.vdot(u,inv@y@inv@y@inv@u)).real
    t = p*z/s
    ff = np.vdot(w, v/(lam+t))
    predicted = (2*p*p*z*(s+1)**2/s**3*abs(ff)**2
                 * np.sum(abs(k)**2/(eigs[:,None]*t+eigs[None,:]*w0)))
    relative = abs(direct-predicted)/max(1,abs(direct),abs(predicted))
    assert relative < 2e-12, (seed,s,direct,predicted)
    return relative

def check_flag(seed):
    rng = np.random.default_rng(seed)
    mats=[]
    for _ in range(2):
        t=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3))
        t=t@t.conj().T+np.eye(3)
        mats.append(t/np.trace(t))
    a,b=mats
    aa=np.block([[a,np.zeros_like(a)],[np.zeros_like(a),b]])/2
    bb=np.block([[b,np.zeros_like(a)],[np.zeros_like(a),a]])/2
    vals=[]
    for alpha in np.linspace(0,1,101):
        actual=overlap(aa,bb,float(alpha))
        predicted=(overlap(a,b,float(alpha))+overlap(a,b,float(1-alpha)))/2
        assert abs(actual-predicted)<2e-12
        vals.append(actual)
    assert abs(min(vals)-overlap(a,b,.5))<2e-12
    return True

def check_quadratic_killing():
    a=np.diag([.4,.6]); k=np.array([[.2,.1j],[-.1j,-.2]])
    weights=np.array([1.,1.,2.,1.]); z=weights.sum()
    v=np.array([0,1,1,0])/np.sqrt(2)
    w=np.array([1.,-2.]); l=np.zeros((4,4))
    l[0,1:3]=w; l[1:3,0]=w
    tau=.3*np.outer(v,v); tau[-1,-1]=.7
    aa=np.kron(a,tau); b=np.kron(a,np.diag(weights))/z
    y=np.kron(k,l)/z; inv=np.linalg.inv(b)
    hessian=2*np.trace(aa@aa@inv@y@inv@y@inv).real
    assert abs(hessian)<2e-12
    return float(hessian)

if __name__=='__main__':
    errors=[check_hessian(i,s) for i in range(10) for s in [.1,.3,1.,3.,20.]]
    result={
        'scope':'finite diagnostic identity checks; no universal proof certification',
        'resolvent_hessian_cases':len(errors),
        'max_relative_error':float(max(errors)),
        'cher noff_flag_cases'.replace(' ','') :sum(check_flag(i) for i in range(10)),
        'quadratic_killing_hessian':check_quadratic_killing(),
        'passed':True,
    }
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
