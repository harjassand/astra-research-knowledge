# Conditional information coefficients for uniformly flat tomography devices

Investigator: sol01_stronger. Date: 11 October 2026.

Status: a complete extension proof **conditional on the correctness of the game-to-POVM bridge in Sections 3–9 of the supplied Dots manuscript**. The extension does not establish an unconditional landmark result or certify that bridge. The ordinary MIP*=RE halting promise is the only external hardness premise needed; perfect PCC strategies, maximally entangled completeness, Sections 12–13, and tensor-power amplification are unnecessary here.

## Result reached

Fix any rational `0 < zeta < 1`. Consider pairs of rational complex POVMs on a common physical dimension `d`, with the same number `N` of outcomes, satisfying all of the following:

1. Both POVMs are informationally complete.
2. Every effect has trace `d/N`.
3. For every outcome,

   `(1-zeta) I/N <= E_i, F_i <= (1+zeta) I/N`.

4. In addition, every non-scalar deviation has bounded rank:

   `rank(E_i-I/N), rank(F_i-I/N) <= 4`.

Thus the devices can be chosen arbitrarily close to the uniform replacement measurement; their effects have condition number at most `(1+zeta)/(1-zeta)`, independent of the encoded machine.

More explicitly, for every finite reference and every input state, the trace norm distance between either measurement's output and the uniform replacement output is at most `zeta`. Each output-block difference lies between `-zeta rho_R/N` and `zeta rho_R/N`; writing it as `rho_R^(1/2) T rho_R^(1/2)` bounds its trace norm by `zeta/N`, and summing the blocks proves the assertion. Thus the flatness restriction controls entangled probes too.

For this restricted class, there is no total algorithm approximating the **relative conditional Umegaki contraction coefficient** `eta_D^Delta(F,E)` to additive error `1/4`. This coefficient is finite on every input in the class. The same holds for every other fixed positive rational additive error, for the conditional SLD coefficient defined below, for the unrestricted complete relative SLD coefficient, and for the relative quantum conditional-mutual-information coefficient, including its binary classical-message restriction.

Even exact complete order remains undecidable under a supplied positive, instance-dependent **strict informative-margin promise**: either `eta <= 1-delta`, or `eta >= 1+delta`, where `delta>0` is rational and supplied with the input. One can also supply a computable positive perturbation radius on which the answer is unchanged. The source is IC, so the first case is uniformly coercive on every tangent after quotienting out the unavoidable reference-only information.

For the SLD coefficient, each fixed-reference-dimension optimization is a computable real algebraic number. Nevertheless, there is no computable approximate reference cutoff, even at any one fixed positive accuracy. A halting oracle suffices for arbitrary-precision evaluation, and any uniform fixed-additive-error evaluator computes halting.

This is stronger than merely restating Dots' qualitative order membership: it treats a pre-existing numerical information coefficient, imposes a common uniform output distribution and arbitrary effect flatness with rank-at-most-four deviations, avoids the manuscript's perfect-strategy normalization, and supplies an approximate-reference obstruction for an optimization whose fixed-level problem is actually decidable.

An essential limitation is that these **relative** coefficients are finite but not uniformly bounded over all inputs. The fixed-error step uses rational source attenuation. This is not a fixed relative-error impossibility, a bounded `[0,1]` SDPI-coefficient impossibility, or a fixed-input-dimension theorem.

## Source and priority record

The supplied source is `work/manuscript/channel_order_undecidability.txt`, corresponding to `/Users/harjas/Downloads/channel_order_undecidability.pdf`, dated 10 October 2026. I read its load-bearing Sections 2–10 and its quantitative Sections 11–14 before developing the extension. The parent independently checked the visually extracted fraction in Equation (54): it is `8/lambda`, not `8 lambda`.

The coefficient itself is established, not invented here. Hirche, George, Nuradha and Wilde, [arXiv:2608.27171v1](https://arxiv.org/html/2608.27171v1), Section 2.6, Definition 4, Equation (2.45), defines the reference-subtracted relative conditional coefficient. Its Corollary 6, Equation (3.142), identifies the relative Umegaki coefficient with relative CMI coefficients, including binary classical messages. The paper's HTML contains no `SLD` or `undecid` match. The extension below proves the needed identities directly and does not infer exhaustive priority from those searches.

Other primary comparisons checked were [Hirche 2026, arXiv:2610.03706v1](https://arxiv.org/html/2610.03706v1), [Hirche–Rouze–Stilck Franca 2022, arXiv:2011.05949](https://arxiv.org/abs/2011.05949), and [Belzig–Gao–Smith–Wu, arXiv:2411.19890v2](https://arxiv.org/html/2411.19890v2). They provide channel-order and relative-coefficient context; none of the inspected material proves this restricted-class undecidability. No exhaustive novelty claim is made.

The external game premise is [Ji–Natarajan–Vidick–Wright–Yuen, MIP*=RE](https://arxiv.org/abs/2001.04383): effectively produce a finite rational game with finite-dimensional tensor-product value one in the halting case and at most one half otherwise. Only an approximate finite strategy scoring above `7/8` is used here.

## 1. Definitions and the reference gauge

Write `Phi_R = Phi tensor id_R`, `W = Tr_A rho`, and `H_R = Tr_A H`. All states in the initial definitions are faithful and all references finite. Let

`g_B(K) = <K, Omega_B^{-1} K>`, `Omega_B(K) = (BK+KB)/2`.

For any channel define its incremental SLD information

`I_Phi(rho,H) = g_{Phi_R(rho)}(Phi_R(H)) - g_W(H_R)`.

It is nonnegative. Here is a direct proof that also records the exact common gauge. Put

`A = Omega_W^{-1}(H_R)`,

`H' = H - Omega_rho(I_A tensor A)`.

Then `Tr_A H' = 0`. Trace preservation gives

`Phi_R(Omega_rho(I tensor A)) = Omega_{Phi_R(rho)}(I tensor A)`.

Expanding the quadratic form, and using

`Tr[H'(I tensor A)] = 0`,

gives the **individual-channel identity**

`g_{Phi_R(rho)}(Phi_R(H)) = g_W(H_R) + g_{Phi_R(rho)}(Phi_R(H'))`.

Consequently

`I_Phi(rho,H) = g_{Phi_R(rho)}(Phi_R(H')) >= 0`.

The gauge depends only on `rho,H` and the untouched reference, not on `Phi`. It remains valid when `Tr H = 0`; in that case `H'` is also traceless. Conversely every Hermitian `H'` with zero physical partial trace is an admissible traceless tangent.

Define

`eta_SLD^Delta(F,E) = inf { c >= 0 : I_F(rho,H) <= c I_E(rho,H) for all rho,H,R }`.

Equivalently it is the supremum of `g_F/g_E` over `H != 0` with `Tr_A H=0`, with the usual best-constant convention if a denominator vanishes. For IC `E`, every such denominator is positive.

For state pairs define

`J_Phi(rho,sigma) = D(Phi_R(rho)||Phi_R(sigma)) - D(rho_R||sigma_R) >= 0`,

and

`eta_D^Delta(F,E) = inf { c >= 0 : J_F <= c J_E for every finite faithful state pair }`.

Using best constants avoids an undefined `0/0`. After finiteness is proved below, it agrees with the supremum of ratios with positive denominators.

Finally define the unrestricted complete relative SLD coefficient

`K_SLD(F,E) = sup g_{F_R(rho)}(F_R H) / g_{E_R(rho)}(E_R H)`

over all finite references, faithful `rho`, and nonzero traceless Hermitian `H`.

For IC `E`,

`K_SLD(F,E) = max{1, eta_SLD^Delta(F,E)}`.                 (A)

Indeed the gauge expresses every quotient as `(r+b)/(r+a)`, with `r >= 0`, `a >= 0`, and `b <= eta a`. This is at most `max{1,eta}`. Zero-reference-partial-trace tangents recover `eta`. A reference-only tangent on a product base gives ratio one; a two-dimensional reference suffices. Equation (A) explains exactly why the reference-only baseline cannot be treated as an informative source contribution.

## 2. Exact quantitative entropy–SLD identity

For arbitrary finite-dimensional channel pairs,

`eta_D^Delta(F,E) = eta_SLD^Delta(F,E)`                   (B)

as extended nonnegative best constants. No IC assumption is needed for this identity. I give both directions because the coefficient-weighted statement does not follow just by multiplying Dots' unweighted order equivalence.

### 2.1 Conditional SLD domination implies conditional entropy domination

Assume `I_F <= c I_E` for some finite `c >= 0`. For `s>0` let

`D_f_s(rho||sigma) = <rho-sigma, (L_rho+s R_sigma)^{-1}(rho-sigma)>`.

Append an untouched qubit and use

`Theta_s = diag(rho,s sigma)/(1+s)`,

`H_X = [[0,rho-sigma],[rho-sigma,0]]`.

Dots' elementary Sylvester identity holds for each channel **and for physical partial trace**:

`g_{Phi(Theta_s)}(Phi H_X) = 4(1+s) D_f_s(Phi rho||Phi sigma)`.

The reference marginal has the same construction with `rho_R,sigma_R`. Subtracting its score therefore gives

`D_f_s(F rho||F sigma) - D_f_s(rho_R||sigma_R)`

`<= c [D_f_s(E rho||E sigma) - D_f_s(rho_R||sigma_R)]`.

Integrate with the positive weight `s/(1+s)^2`. The scalar identity

`x log x - (x-1) = integral_0^infinity [(x-1)^2/(x+s)] s/(1+s)^2 ds`

and mixed-eigenbasis functional calculus yield `J_F <= c J_E`. All integrals are finite for faithful states, so subtracting the reference term is legitimate. There is no equality-of-reference-marginals assumption.

### 2.2 Conditional entropy domination implies conditional SLD domination

Assume `J_F <= c J_E`. Fix `rho,H` and append a centre-and-leaves reference as in Dots Section 2:

`W_aux = diag(1,lambda_1,...,lambda_N)`,

`tau = vv*` supported on the leaves, `L = e_0 w* + w e_0*`,

`alpha = rho tensor tau`,

`beta(t) = [rho tensor W_aux + t H tensor L]/Tr W_aux`.

First replace `tau` by `(1-z)tau + z I/(N+1)` to make the numerator faithful. For every channel and also for physical partial trace, the divergence at `t=0` is the same auxiliary-reference divergence. Hence **each** `J_Phi(alpha,beta(0))=0`. The nonnegative function `c J_E-J_F` is saturated at zero, so its second derivative there is nonnegative. Pass `z down to 0`; Hessians are linear and continuous in the numerator.

The exact denominator-logarithm Hessian is

`2 sum_{ij} |K_ij|^2 integral_0^infinity |F(t)|^2/(a_j+a_i t) dt`,

where `a_i` are the eigenvalues of `Phi rho`, `K=Phi H`, and `F(t)=w*(W_leaf+tI)^{-1}v`. The same formula holds for the reference marginal with `W=Tr_A rho`, `K=Tr_A H`.

Use the realizable rational-pole filters

`F_m(t) = t^m / product_{j=0}^{2m}(t+1+j/m^3)`.

After division by their squared mass, these filters concentrate at `t=1`. One proof compares them multiplicatively with `t^m/(1+t)^{2m+1}`; its normalized square is beta-prime with mean tending to one and variance tending to zero. Each output has finitely many eigenvalues, so the Hessian limits are its SLD quadratic form. The resulting inequality is

`c [g_E-g_ref] - [g_F-g_ref] >= 0`.

This is `I_F <= c I_E`, proving (B). The coefficient `c` is retained throughout. Unlike an attempted proof from the *raw* weighted entropy inequality, the reference-subtracted inequality really is saturated at zero.

## 3. Conditional mutual information has the same best constant

Let `C` be an arbitrary finite quantum message system, `R` an untouched finite quantum reference, and `Y_Phi` the channel output. Define the relative CMI best constant by

`I(C:Y_F|R) <= c I(C:Y_E|R)` for every state on `C R A`.

Its value equals `eta_D^Delta(F,E)`, and restricting `C` to a binary classical variable leaves the value unchanged. Here is a direct reconstruction, consistent with the established Corollary 6 cited above.

For an arbitrary state `omega_CRA`, take the pair

`rho=omega_CRA`, `sigma=omega_C tensor omega_RA`,

and regard `CR` as the reference. Then

`J_Phi(rho,sigma) = I(C:RY_Phi)-I(C:R) = I(C:Y_Phi|R)`.

So the conditional entropy best constant bounds every quantum CMI ratio.

Conversely, for faithful `rho,sigma` on `RA`, use a binary classical ensemble with probability `t` for `rho` and `1-t` for `sigma`, whose average is `sigma_t=(1-t)sigma+t rho`. Its CMI is

`t J_Phi(rho,sigma_t) + (1-t) J_Phi(sigma,sigma_t)`.

After division by `t`, this tends to `J_Phi(rho,sigma)` as `t down to 0`: the second term is `O(t^2)` before division, and the first term is continuous. Thus binary CMI inequalities imply every faithful-pair conditional entropy inequality.

Faithful regularization extends the resulting CMI comparison to arbitrary finite states by continuity of entropy. Likewise, finite output/reference relative-entropy pairs are obtained as limits of faithful regularizations on their supports. No infinity-minus-infinity convention is used.

Combining Sections 1–3 gives

`eta_D^Delta(F,E) = eta_SLD^Delta(F,E)`

`= eta_CMI(F,E) = eta_binary-CMI(F,E)`.                   (C)

## 4. Finiteness and an effective bound for IC sources

Let the physical dimension be `d`, and let `B_mu`, `mu=1,...,d^2-1`, be an HS-orthonormal traceless Hermitian basis. After the common gauge write

`H' = sum_mu B_mu tensor H_mu`,

`Q_W(H') = sum_mu g_W(H_mu)`.

For a strictly positive effect `M_i` choose rational bounds

`a_i I <= M_i <= b_i I`, `a_i>0`.

Its output base lies between `a_i W` and `b_i W`. Inverse-Jordan order gives

`(1/b_i) g_W(sum_mu Tr(M_i B_mu) H_mu)`

`<= g_{M_i(rho)}(M_i(H'))`

`<= (1/a_i) g_W(sum_mu Tr(M_i B_mu) H_mu)`.

If `E` is IC, the traceless-coordinate vectors

`e_i=(Tr(E_i B_mu))_mu`

span the whole traceless coordinate space. Therefore the frame matrix

`S_E = sum_i (1/b_i) e_i e_i^T`

is positive definite. Obtain an effective positive rational lower bound `beta` for its least eigenvalue. For rational POVMs the basis can be chosen algebraic, so exact algebraic eigenvalue bounds suffice; alternatively a rational basis and its rational Gram matrix avoid square roots.

Then

`I_E(rho,H) >= beta Q_W(H')`,

whereas

`I_F(rho,H) <= B_F Q_W(H')`,

`B_F = sum_j (1/a_j^F) ||f_j||_2^2`.

Both bounds hold uniformly over reference dimensions, marginal condition numbers and all faithful bases. Thus

`0 <= eta_D^Delta(F,E) = eta_SLD^Delta(F,E) <= B_F/beta < infinity`.     (D)

The bound is computable from the finite POVM descriptions. It may be huge. In particular there are no hidden infinite ratios in the claimed input class, and a nonzero zero-partial-trace tangent always has positive source score.

## 5. Making the Dots reduction uniformly flat

This step is conditional on the correctness of the Dots game-to-kernel and kernel-to-POVM constructions, but the modification and its effect on their hypotheses are explicit.

### 5.1 The raw Pauli amplitude is freely adjustable

Replace Dots' fixed `tau=1/2` in its raw effects by a positive rational `tau` as small as desired:

`A_i=(I+tau sigma_i tensor I)/2`,

`A_i,g=(I+tau sigma_i tensor e_g)/2`.

The centered normalized letters remain

`T_i=(2 Z_A_i-I)/tau`, `T_i,g=(2 Z_A_i,g-I)/tau`.

For every actual baseline tuple, these letters are **exactly independent of `tau`**: normalized partial trace is affine in the physical effect, and its value on `I` is `I`. Thus the actual-domain representation, opposite Pauli orientations, anchor estimates, smoothing and game polynomial are unchanged. Only the finite substitution into raw `Z` letters and its coefficients change. The inverse compiler merely requires strictly positive effects and complements; here they lie between `(1-tau)I/2` and `(1+tau)I/2`.

Every denominator effect `A_r` produced by that compiler is either one of these effects, its complement, or `I`. Write its scalar centre as `c_r`, respectively `1/2` or `1`. Then

`Tr A_r / a = c_r`,

`||A_r-c_r I|| <= tau c_r`.

The zero-trace property of raw Pauli and Pauli-payload observables is essential to the exact trace equality.

### 5.2 Flat signed-residue baselines and filler

For each signed rational rank-one residue term, Dots Section 8 uses two identical baseline outcomes with upper block `lambda A_r/|c_t|` and lower scalar block `lambda c_r I/|c_t|`. Write their scalar centres as

`w_i^D = lambda c_r/|c_t|`.

They satisfy

`(1-tau) w_i^D I <= D_i <= (1+tau) w_i^D I`,

`Tr D_i = d w_i^D`.

Choose `lambda` so that the sum `s` of these scalar centres is at most `1/2`. The filler has scalar centre `1-s`, and its non-scalar upper-block deviation is at most `tau s <= tau(1-s)`; its lower block is exactly scalar. Hence it satisfies the same flatness and exact trace formula.

The numerator matrices `O_i^E,O_i^F` are off-diagonal and traceless. In addition to all Dots global-completion conditions, shrink the positive rational signal parameter `delta_s` so that

`delta_s ||O_i^E||, delta_s ||O_i^F|| <= tau w_i^D` for every `i`.

This is effective, does not change either reduction implication, and gives signal outcomes

`(D_i +/- delta_s O_i)/2`

within `1 +/- 2 tau` of their scalar centre, with source and target **exactly matching traces**.

### 5.3 Flat informational padding and matched erasure splitting

Choose Dots' block-diagonal informational padding from effects

`G_{mu,+/-}=(I +/- t_mu B_mu)/(2L_b)`,

where the `B_mu` form a rational traceless Hermitian basis of the block-diagonal subspace modulo `I`, and `t_mu` are small positive rationals with `t_mu ||B_mu|| <= tau`. The identity is already in their span by summing outcomes. These effects are strictly positive, span the required subspace, have scalar centres `1/(2L_b)`, and are `tau`-flat. The positive frame lower bound required in Dots Section 9 remains effectively available.

Split the target erasure effect into scalar outcomes with exactly the same weights as the source padding effects. Such splitting does not change its SLD score or relative entropy: its outputs are proportional copies of the reference marginal. It gives the same outcome count and matching traces on the source and target.

Now append, with common branch weight `1/2`, an identical full IC rational POVM `Q` to both devices. Construct `Q` in the same way from a rational traceless basis of all physical Hermitian matrices. Its effects can also be `tau`-flat. This makes **both** complete devices IC and multiplies every source-minus-target metric difference by `1/2`, preserving its sign exactly.

At this stage the devices have a common list of positive rational scalar weights `w_i`, summing to one, with

`Tr E_i = Tr F_i = d w_i`,

`(1-2tau)w_i I <= E_i,F_i <= (1+2tau)w_i I`.

For example take `tau <= zeta/8`; this leaves strict flatness slack for the robustness statement below. All choices are finite computable operations. The physical dimension and outcome count are allowed to grow.

### 5.4 Rank-at-most-four deviations from scalar effects

There is a further restriction independent of the input dimension. Make the following additional finite changes in the construction above.

First, **after** obtaining the game polynomial and its actual-domain gap, eliminate each formal anchor letter by

`T_i = sum_g T_i,g`.

This is an exact identity on the domain, because `sum_g e_g=I` and normalized partial trace is linear. In the proof the anchors remain the same operators; only the subsequent finite symbolic polynomial is expanded. The raw-effect alphabet for the inverse compiler can now consist solely of

`A_i,g = (I + tau sigma_i tensor e_g)/2`.

Every such effect and its complement differs from `I/2` by rank two. The extra denominator `I` is scalar. The polynomial may have many more monomials, but the expansion is finite and computable; its degree does not increase.

Second, for each baseline outcome whose denominator is a non-scalar `A_r`, add a dummy baseline outcome of the same scale with denominator `I-A_r`, putting zero numerator on both sides. Such a dummy contributes zero to the inverse-kernel signal and an identical source/target score globally. The paired baselines sum to a scalar multiple of the full physical identity, since the two upper blocks sum to `I` and their two lower scalar blocks do also. Scalar `I` denominators need no dummy. Choose `lambda` small enough for this enlarged list. The resulting filler is **exactly scalar**, not merely flat.

Third, choose the residue embedding with lower physical dimension `q=L` and selected matrix units

`P_alpha = |a_0><a+alpha|`, `alpha=1,...,L`,

for one fixed upper-block row `a_0`. They are distinct and HS-orthogonal, as required. This is allowed by Dots Section 8; it changes only the finite physical padding dimension. For every rational residue vector `v`,

`V(v)=sum_alpha v_alpha P_alpha`

has rank at most one. Consequently both Hermitian numerator quadratures `V+V*` and `iV-iV*` have rank at most two. A signal effect's deviation from its scalar centre is the sum of a rank-at-most-two baseline deviation and a rank-at-most-two numerator, hence has rank at most four. The filler is scalar, and dummy outcomes have rank-at-most-two deviations.

Finally choose both informational padding bases from matrix-unit differences: diagonal `|j><j|-|k><k|`, real off-diagonal units, and imaginary off-diagonal units. Each traceless basis matrix has rank two; those within the block-diagonal subspace provide its padding, and the full collection provides common full IC padding. Their effects have rank-at-most-two deviations.

Thus every effect before calibration satisfies `rank(E_i-w_i I),rank(F_i-w_i I)<=4`. Source erasure introduces rank-zero deviations, target duplication preserves rank, and rational proportional outcome splitting preserves rank. After uniform splitting this proves the final restriction `rank(E_i-I/N),rank(F_i-I/N)<=4`.

The quantitative argument below uses the recomputed node count, scale parameters and physical dimension for this expanded construction. In particular `q=L` is allowed throughout. It never assumes the smallest possible padding dimension.

## 6. A dimension-free ratio margin without PCC completeness

This is the key normalization distinction from Dots Sections 12–13. Hilbert–Schmidt norm, rather than operator norm, is sufficient for a **ratio**.

Set the game thresholds as in Dots: `r=3/4`, `gamma=1/4`. In the halting case choose any finite strategy scoring above `7/8`, available from value one. The honest balanced model has identity local reference marginals and root vector `z` of norm one. Faithful Choi regularization with the explicit game-computable parameter in Dots Proposition 6.1 preserves

`<z,F(T)z> <= -gamma/4`.

This uses no perfect strategy or known witness dimension. Let `L` be the number of suffix-graph nodes in its raw-effect polynomial compiler. With both reference marginals identity, `D=2I`. The exact graph coordinates are

`U_w=sqrt(2) Z_w z`.

Since every raw-effect letter is a positive contraction,

`sum_w ||U_w||^2 <= 2L`.

Let the two strategy reference dimensions be `n,m`, with no equality assumption. Put the reshaped `U_w` into the `n`-to-`m` blocks of a direct-sum reference of dimension `n+m`, and form Dots' selected physical-cross Hermitian tangent `X`. Distinct selected physical matrix units are HS-orthogonal, so

`Tr_A X=0`, `Tr X=0`, `||X||_HS^2 <= 4L`.             (E)

Realize the effective baseline `R_e direct-sum S_e` by the faithful physical padding from Dots Section 8. Its physical partial trace is exactly `I_{n+m}`. One explicit choice, writing `a` for the denominator physical dimension and `q` for the lower padding dimension, is

`T_low = e I_q tensor I_{n+m}/(2q)`,

`R_top = (R_e direct-sum S_e) - e I_a tensor I_{n+m}/(2a)`.

It is faithful because `R_e,S_e >= (e/a)I`, and its effective baseline is unchanged. Call the resulting unnormalized baseline `Theta`.

The exact graph objective transfers unchanged to the inverse kernel. Equation (54), with its correct `8/lambda` factor, and the signal branch give

`g_F(Theta,X)-g_E(Theta,X) >= delta_s^2 gamma/lambda`

before common full-IC padding. After the common weight-`1/2` padding of Section 5.3, the lower bound is

`d_G = delta_s^2 gamma/(2 lambda) > 0`.                (F)

All constants in (F) are positive rationals computable from the game. The target erasure splitting has no effect on this value.

Let `alpha>0` be a certified rational lower bound on every effect of the new IC source. Since `Tr_A Theta=I`, every output base is at least `alpha I`. Therefore

`g_E(Theta,X) <= alpha^{-1} sum_i ||Tr_A[(E_i tensor I)X]||_HS^2`

`<= alpha^{-1} [sum_i ||E_i||_HS^2] ||X||_HS^2`

`<= 4 L d/alpha = C_G`.                              (G)

The last bound uses `0<=E_i<=I`, hence `sum_i Tr E_i^2 <= Tr I=d`. This estimate is uniform in `n,m`. Source IC ensures its denominator is positive. Normalize both `Theta` and `X` by `Tr Theta` if a density matrix is desired: both Fisher quantities receive the same factor, so their ratio is unchanged.

Equations (F)–(G) yield the computable multiplicative separation

`nonhalting => eta_SLD^Delta(F,E) <= 1`,

`halting => eta_SLD^Delta(F,E) >= 1 + mu_G`,

`mu_G = d_G/C_G > 0`.                               (H)

The witness has zero physical partial trace, so it tests the conditional coefficient directly. The crucial cancellation is that trace normalization shrinks its positive gap and its source denominator by the same unknown dimension factor. No bound on `n,m` is needed to compute `mu_G`.

## 7. Exact coefficient calibration preserving flatness and traces

At this point `E,F` have matching scalar weights `w_i`. For a positive rational `t<1`, form the same-size doubled lists

`E^(t) = ( t E_i ; (1-t) w_i I )_i`,

`F^(t) = ( t F_i ; (1-t) F_i )_i`.

The first device is a flagged measurement-or-erasure device. The second is a flagged duplicate of the target measurement. All effects are strictly positive and rational, both devices are IC, and their corresponding effect traces are equal. Each effect retains exactly the same relative flatness around its new scalar centre `t w_i` or `(1-t)w_i`.

Homogeneity of the SLD quadratic form gives, for every base and tangent,

`g_{E^(t)} = t g_E + (1-t) g_ref`,

`g_{F^(t)} = g_F`.

Consequently

`I_{E^(t)} = t I_E`, `I_{F^(t)}=I_F`.

The state-independent flags similarly give

`J_{E^(t)} = t J_E`, `J_{F^(t)}=J_F`.

Thus the coefficient identity is **exact**:

`eta_D^Delta(F^(t),E^(t)) = eta_SLD^Delta(F^(t),E^(t))`

`= eta_D^Delta(F,E)/t`.                              (I)

The same exact scaling holds for conditional mutual information. By (A), the unrestricted complete SLD ratio is `max{1,eta/t}`.

Choose

`t = min{1/2, mu_G/4}`, `T_G=1/t`.

The separation (H) becomes

`nonhalting => eta^(t) <= T_G`,

`halting => eta^(t) >= T_G+4`.                        (J)

Both `t,T_G` are computed without finding the game strategy. For `K_SLD`, the same inequalities hold because `T_G>=2`.

Finally make the scalar output weights **uniform**. Write the common doubled-list weights as positive rationals `b_i`, and choose a common denominator `N` so that `b_i=m_i/N`, `m_i` positive integers. Split each source effect and its corresponding target effect into `m_i` identical effects divided by `m_i`. There are exactly `sum_i m_i=N` outcomes. Proportional outcome splitting preserves all metric, entropy and CMI values; it is undone by merging the split outcomes. Every resulting effect has trace `d/N` and lies between `(1-2tau)I/N` and `(1+2tau)I/N`. The spans, hence IC, are unchanged.

This completes the promised uniform-flat normalization. Its cost can be enormous. This is a computable many-one construction, not an efficient one.

## 8. Fixed-error hardness and its exact computability scope

Suppose an algorithm returned a rational `v` with additive error `1/4` for every pair in the fixed-`zeta` class. Apply the construction above to a machine and compute `T_G`. In the nonhalting case,

`v <= T_G+1/4`.

In the halting case,

`v >= T_G+15/4`.

Thresholding at `T_G+2` decides halting. The same proof applies to every coefficient in (C) and, by (A), to `K_SLD`.

For any other fixed positive rational error `epsilon_*`, replace the choice of `t` by a rational at most `mu_G/(4 epsilon_*+4)`. The coefficient separation exceeds `4 epsilon_*`, so a corresponding threshold again decides halting.

Uniform lower semicomputability follows from the SLD formulation: enumerate reference dimensions, rational faithful density matrices, and rational Hermitian tangents of zero physical partial trace. Solve rational Sylvester systems and enumerate their rational source/target ratios. Strict ratio violations persist on open neighborhoods, so this rational enumeration reaches the true supremum. Source IC and Section 4 provide a computable finite upper bound.

A halting oracle can decide whether this enumeration ever exceeds a rational threshold; binary search then approximates the coefficient to arbitrary precision. Therefore:

* every fixed-error uniform evaluator computes halting;
* a halting oracle suffices for uniform arbitrary-precision evaluation.

This does **not** prove that a particular single rational POVM pair has an individually noncomputable coefficient. Uniform noncomputability does not imply that stronger pointwise statement.

### 8.1 Robust promise undecidability of exact complete order

The same construction supplies a robust qualitative theorem, with no zero-margin domination instances. Start with the pair and rational `mu_G` in (H), before the source calibration used for fixed absolute error. Put

`a = 1/(1+mu_G/2)`, `delta_G = mu_G/(2+mu_G)`.

Duplicate the source and attenuate the target using corresponding flags:

`E_star = ( a E_i ; (1-a) E_i )_i`,

`F_star = ( a F_i ; (1-a) w_i I )_i`.

Now `I_{E_star}=I_E` and `I_{F_star}=a I_F`; the identical identities hold for `J` and for CMI. Therefore

`eta_star = a eta`,

`nonhalting => eta_star <= a = 1-delta_G`,

`halting => eta_star >= a(1+mu_G) = 1+delta_G`.

Both lists remain strictly positive, IC, equally traced and flat, with rank-at-most-four deviations. Uniform rational outcome splitting finishes the same restrictions as before. The rational margin `delta_G>0` is computed from the machine and supplied as part of the promise input.

In the low case, the source frame lower bound yields, on every finite reference and every base/tangent,

`g_{E_star}(rho,H)-g_{F_star}(rho,H)`

`= I_{E_star}(rho,H)-I_{F_star}(rho,H)`

`>= delta_G I_{E_star}(rho,H) >= delta_G beta Q_W(H')`.

The only universally unpenalized tangents are the exact reference-score gauge directions. The entropy comparison also satisfies `J_F <= (1-delta_G)J_E`, and the same strict factor holds for CMI.

Apply the effective continuity modulus of Section 10 with `u <= delta_G/(2K)` and the flatness slack. A computable positive radius preserves `eta<1` in the low case and `eta>1` in the high case. Thus an exact-order algorithm promised either strict informative domination or strict failure, with a supplied positive margin (and even with a supplied stability radius), would decide nonhalting/halting. No common constant margin or common radius is claimed.

## 9. Fixed-level algebraicity and no approximate reference cutoff

For the conditional SLD coefficient, restrict the reference to dimension at most `n`. For a rational threshold `q`, existence of a ratio above `q` is equivalent to existence of a faithful state `rho`, nonzero Hermitian tangent `H` with `Tr_A H=0`, and Hermitian scores `L_i` satisfying

`Omega_{E_i(rho)}(L_i^E)=E_i(H)`,

`Omega_{F_j(rho)}(L_j^F)=F_j(H)`,

`sum_j Tr[F_j(H)L_j^F] - q sum_i Tr[E_i(H)L_i^E] > 0`.

Hermiticity, trace, partial trace, positive definiteness and the Sylvester equations are finite real polynomial conditions in real and imaginary coordinates. Real quantifier elimination decides this existence question. The ratio is uniformly bounded by Section 4. Hence binary search computes its finite supremum. More strongly, the set of thresholds for which the strict witness exists is semialgebraic over the rationals; its finite endpoint is a real algebraic number.

This handles arbitrarily ill-conditioned faithful states at the fixed level; no compactness assertion about their eigenvalues is needed.

Let `eta_n` be the coefficient at reference dimension at most `n`. Then `eta_n` increases to `eta`, but for any fixed rational `epsilon_*>0` there is no total computable `b(E,F)` on this restricted input class satisfying

`0 <= eta(E,F)-eta_{b(E,F)}(E,F) <= epsilon_*`.

Otherwise compute `eta_b` to accuracy `epsilon_*`, giving a uniform approximation of `eta` to fixed error `2 epsilon_*`, contrary to Section 8. The ordinary complete SLD coefficient has the same conclusion after taking `max{1,eta_n}`; these are its actual reference-at-most-`n` levels for `n>=2`, because a two-dimensional reference supplies the ratio-one gauge witness. Replacing any proposed cutoff by its maximum with 2 handles the initial level.

This approximate-cutoff theorem is deliberately stated for the SLD optimization. It does not assume a fixed-reference algorithm for transcendental entropy optimization, and it does not automatically identify a cutoff for the CMI or entropy formulation: the equivalence (B) uses additional auxiliary reference dimensions.

## 10. The numerical separation is locally stable

The hard numerical instances need not lie at a zero-margin boundary. Here is an effective continuity argument within a fixed input/output size.

Assume all source and target effects are at least `alpha I`, and the source's traceless frame lower bound from Section 4 is at least `beta>0`. Perturb each effect by HS norm at most `u`, preserving POVM normalization. For `u <= alpha/2`, every perturbed effect remains at least `alpha I/2`.

Use the same channel-independent gauge and write `Q=Q_W(H')`. An effect perturbation of HS norm `u` changes its output tangent by a vector of `g_W`-norm at most `u sqrt(Q)`, and changes its output base by a matrix between `-u W` and `u W`. Inverse-Jordan order then bounds the base-inverse change by `2u/alpha` times the old inverse. Expanding the tangent square gives, for a device with `N` outcomes and physical dimension `d`,

`|I_M-I_M'| <= L u Q`,

where the rational conservative choice

`L = 2d/alpha^2 + 4Nd/alpha + 2N/alpha`

is valid for `u<=1`. Here `sum_i ||M_i||_HS^2<=d` and `||M_i||_HS<=d` were used. For `u<=beta/(2L)`, the perturbed source remains bounded below by `beta Q/2`. The old target is bounded above by `B Q`, for example `B=d/alpha`. Consequently each ratio, and therefore its supremum, changes by at most

`K u`, `K=L/beta + 2(B+L)L/beta^2`.

All constants are effective from the finite description. Choose `u<=1/(2K)` and preserve the strict flatness slack left in Section 5; for instance also require `u<=zeta/(4N)` after uniform splitting. Within the affine constraints of matching traces and POVM normalization, the radius is positive and computable. The low numerical case remains below `T_G+1/2`, and the high case remains above `T_G+7/2`. Thus the hardness survives a certified input-dependent open neighborhood inside the flat IC class.

The neighborhood radius is not a universal constant and no claim of physical tolerance independent of the encoded machine is intended. The ambient open-neighborhood assertion preserves flatness, IC and the affine normalization/trace constraints; arbitrary perturbations need not preserve the optional rank-four algebraic constraint. Restricted perturbations that also preserve that constraint satisfy the same bound.

## 11. Falsification attempts and failed stronger claims

### Attempt: ordinary raw entropy coefficient equals the conditional coefficient

Rejected. For `c!=1`, a raw comparison `D_F<=c D_E` is not saturated by the auxiliary product pair: its baseline is `(c-1)D_ref`. The Hessian argument cannot discard that nonzero slack. I have proved (B) only for the reference-subtracted coefficient. The unrestricted raw **SLD** ratio has the exact `max{1,eta}` formula because its gauge is quadratic; no analogous raw entropy identity is asserted.

### Attempt: keep Dots' bounded entropy defect at fixed error while taking arbitrary flatness

Decisively impossible by the source's own bound. For the uniform-flat target,

`V(E,F) <= log[(1+zeta)/(1-zeta)]`.

If, for example, `zeta=1/16`, the right-hand side is less than `1/4`; returning zero already gives an additive-`1/4` approximation. The numerical obstruction here therefore genuinely concerns a **relative coefficient**, not the old bounded defect under an impossible stronger restriction.

### Attempt: use an unnormalized Fisher gap as an absolute state-normalized gap

Rejected. Trace normalization introduces the unknown strategy-dimension factor. Section 6 retains a ratio, where numerator and denominator scale together. It would be invalid to infer Dots Section 12's absolute normalized gap from the HS estimate (E). Operator-norm control and perfect maximally entangled completeness serve a different purpose there.

### Attempt: infer fixed multiplicative approximation hardness

Not established. Source attenuation preserves the relative factor `1+mu_G`; it magnifies only the absolute coefficient difference. The current argument gives no universal factor separation and no bounded `[0,1]` contraction coefficient hardness. This is a real limitation, not a missing presentation detail.

### Attempt: force real symmetric effects by realifying the final complex effects

Blocked by a concrete domain change. Complex realification becomes a direct sum of a complex representation and its conjugate on complex Hilbert spaces. The two chirality sectors can be mixed by UCP maps and by the marginal weights. The original anchor assumes fixed opposite Pauli orientations and does not cover these additional sectors. Flagging them separately would restore a decomposition but does not automatically preserve real effects and strict positivity. No real-input theorem or impossibility is asserted.

### Attempt: fixed input dimension, fixed number of outcomes, fixed reference cutoff

Not established. Input dimensions and output counts grow in the game compiler, IC requires sufficiently many effects, and rational weight splitting can greatly increase the outcome count. Flatness alone does not reduce these parameters. The fixed-level algebraicity proof identifies precisely where an unbounded reference remains essential.

### Attempt: extract a halting-independent uniform IC frame bound

Not established and not used. The source frame becomes weak under the calibration. Finiteness is certified separately for each input by a positive computable frame bound. Claiming a common lower bound while attenuating the informative branch would be false.

## 12. Verification evidence and remaining dependency

The mathematical checks above are exact derivations. As a finite falsification aid, `work/investigations/sol01_checks.py` tested the gauge identity, zero physical partial trace after gauging, exact flagged SLD and entropy scaling, matching effect traces and POVM normalization on 48 randomly generated correlated-state instances with physical and reference dimensions 2 and 3. Seed: `20261011`. The largest observed absolute error was `1.024e-13`; all tests passed the `1e-8` threshold. Results are in `work/investigations/sol01_checks.json`.

`work/investigations/sol01_rank_checks.py` separately checked the bounded-rank construction in exact SymPy rational complex arithmetic: physical dimension 7, 49 pre-split outcomes, 4000 uniform split outcomes. Normalization and matching traces held exactly; the maximum scalar-deviation rank was 4 before and after splitting, and the filler deviation had rank zero. Its results are in `work/investigations/sol01_rank_checks.json`. This checks the new embedding algebra, not the game reduction.

These numerical checks do not test MIP*=RE, unbounded reference dimensions, the game anchor, smoothing, inverse compiler or the global-completion theorem. They are not scientific certification.

The indispensable unresolved external dependency of this investigation is the full correctness of Dots Sections 3–9. In particular:

* the common two-factor normalized Jordan domain must be retained;
* the anchor/smoothing must control arbitrary UCP compressions rather than only exact balanced models;
* the word compiler must preserve noncommutative word order;
* the residue implementation needs both quadratures;
* the global completion must control coherent baselines after the common reference gauge.

I read and checked the role of each dependency; I have not independently certified every estimate in those long sections. If the parent audit finds a flaw there, the hardness statements here become conditional candidates until the flaw is repaired. Sections 1–4 and 7's exact scaling identities do not depend on that hardness bridge.

The completed outcome is therefore a fully developed, source-conditional coefficient theorem with stringent flat IC inputs, a genuine fixed-error ratio obstruction, an exact conditional entropy–SLD–CMI identity, and a fixed-level algebraic approximate-cutoff obstruction. No publication, commit or research-repository mutation was performed.
