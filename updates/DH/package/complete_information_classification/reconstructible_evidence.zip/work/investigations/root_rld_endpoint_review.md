# Adversarial review of the elementary complete Petz order-two cutoff

Reviewer: sol03_boundary. Date: 2026-10-11.

Reviewed source: `work/investigations/rld_finite_cutoff.md`, including its arbitrary-channel extension. This report preserves the earlier `sol03_boundary.md` investigation and makes no repository or publication changes.

## Verdict

**VALID under the stated standard Petz order-two convention.** I independently reconstructed the normalization, the compression inequalities, the exact preservation of all target inverse actions, the restoration of a faithful input and a traceless tangent, and the general finite-channel version. No mathematical gap was found in these steps.

For finite measurement channels, failure has a faithful state-pair witness at reference dimension at most

    1 + number of nonzero target outcomes.

For arbitrary finite CPTP maps P,Q, if the target Q has effective output dimension b, failure has a faithful state-pair witness at reference dimension at most

    1 + b^2.

Thus complete standard Petz D_2 order for rational finite channels is decidable by fixed-size real quantifier elimination. Strictly positive POVM effects are not required for this endpoint theorem; nonzero effects suffice.

This proof uses no MIP*=RE reduction and no free rational Positivstellensatz. The remaining caveats are historical priority/external review, and the fact that a strict separation from complete SLD or open-range Petz orders still invokes the separately unverified hardness theorem or requires an explicit separating example. The theorem concerns **standard Petz** D_2, not sandwiched Renyi D_2.

## 1. Convention and reduction to the RLD quadratic form

Let Phi be a finite-dimensional CPTP map. Its fixed effective output space is

    B_eff = supp Phi(I_A).

If rho>0 on A tensor R, then Phi_R(rho)>0 on B_eff tensor R. Indeed rho>=epsilon I implies Phi_R(rho)>=epsilon Phi(I_A) tensor I_R. All inverses below are taken on this effective support.

For faithful states alpha,beta, standard Petz order two is

    D_2(alpha||beta)=log Q_2(alpha,beta),
    Q_2(alpha,beta)=Tr alpha^2 beta^(-1).

Set

    G_B(K)=Tr K B^(-1)K = Tr K^2 B^(-1)

for Hermitian K. If rho is a faithful state, H is Hermitian with Tr H=0, and rho+tH remains a state, then

    Q_2(Phi_R(rho+tH),Phi_R(rho))
        = 1+t^2 G_{Phi_R(rho)}(Phi_R(H)).                  (1)

The cross terms each have trace Tr Phi_R(H)=0; no commutation of rho and H is used. This expansion is exact.

Consequently complete D_2 comparison on faithful pairs is equivalent to comparison of these RLD quadratic forms on all faithful rho and traceless Hermitian H. One direction uses any sufficiently small nonzero t in (1). For the other, use rho=beta, H=alpha-beta, t=1, and monotonicity of the scalar logarithm.

The word 'standard' is essential. The sandwiched order-two quantity has a different quadratic form and is not covered by the argument.

## 2. Normalization audit: the weight is retained, not discarded

Suppose the source-minus-target RLD difference is negative at a faithful state R and a traceless Hermitian H on A tensor C^n. Put

    W=Tr_A R >0,
    Rtilde=(I_A tensor W^(-1/2)) R (I_A tensor W^(-1/2)),
    h=(I_A tensor W^(-1/2)) H (I_A tensor W^(-1/2)).

Then Rtilde>0, Tr_A Rtilde=I_n, and h=h*. The normalized baseline has trace n, not trace one; this is intentional. The transformed h need not be traceless; that is also intentional.

For either channel Phi define

    A_Phi=Phi_R(Rtilde),
    K_Phi=Phi_R(h).

Because Phi acts only on A,

    Phi_R(R)=(I_B tensor W^(1/2))A_Phi(I_B tensor W^(1/2)),
    Phi_R(H)=(I_B tensor W^(1/2))K_Phi(I_B tensor W^(1/2)).

Writing G=I_B tensor W^(1/2), direct multiplication gives

    (GKG)(GAG)^(-1)(GKG)=G K A^(-1) K G.

Taking the trace yields

    G_{Phi_R(R)}(Phi_R(H))
       = Tr[(I_B tensor W) K_Phi A_Phi^(-1) K_Phi].        (2)

The reference weight W is therefore indispensable; the normalization does not preserve the unweighted scalar trace.

Define a Hermitian operator on the reference alone by

    D = Tr_{B_eff(P)} K_P A_P^(-1)K_P
         - Tr_{B_eff(Q)} K_Q A_Q^(-1)K_Q.                 (3)

The original violation is Tr W D<0. Since W>0, D cannot be positive semidefinite. Choose a unit reference vector xi with

    <xi,D xi><0.                                         (4)

This is exactly the reduction used by the supplied proof. It is not the invalid assertion that a congruence leaves an RLD trace invariant. The weight and subsequent negative-vector extraction repair that potential error completely.

For a measurement channel, A and K are outcome-block diagonal; (3) reduces to the sum of reference operators k_i r_i^(-1) k_i stated in the supplied proof.

## 3. Compression audit for measurements

Use the source document's notation r_i>0, k_i=k_i*. For each target outcome define

    z_j=(r_j^F)^(-1) k_j^F xi.

Let S be the span of xi and all the z_j, and V:C^d -> C^n an isometry onto S. Then d<=1+v. Compress the complete physical objects, using the same V:

    Rtilde'=(I_A tensor V*) Rtilde (I_A tensor V),
    h'=(I_A tensor V*) h (I_A tensor V).

This gives Rtilde'>0 and Tr_A Rtilde'=I_d. Strict positivity follows because a compression by an isometry of a positive definite matrix remains positive definite. Hermiticity of h' is immediate. Every output block satisfies

    r_i'=V* r_i V,
    k_i'=V* k_i V.

Write xi'=V*xi. Since xi and z_j belong to S,

    r_j' V*z_j
      =V*r_j V V*z_j
      =V*r_j z_j
      =V*k_j xi
      =k_j' xi'.                                        (5)

Thus (r_j')^(-1) k_j'xi'=V*z_j. Its target quadratic term equals

    <k_j'xi',(r_j')^(-1)k_j'xi'>
      =<V*k_j xi,V*z_j>
      =<k_j xi,z_j>
      =<xi,k_j r_j^(-1)k_j xi>.                          (6)

The second equality is justified by z_j in S, even though k_j xi need not be in S. This is a possible hidden-projection trap, and it is handled correctly.

For a source term take u=k_i xi. The compressed source term is

    (V*u)* (V*r_i V)^(-1) (V*u).

The elementary identity

    u*r^(-1)u = sup_z [2 Re(u*z)-z*r z]                  (7)

shows that this is the same maximization restricted to z in S. It is therefore at most u*r_i^(-1)u. No matrix Jensen inequality or comparison of unrelated inverses is needed.

Every negative target term is preserved exactly, while every positive source term can only decrease. Hence

    <xi',D'xi'> <= <xi,Dxi> <0.                         (8)

All effects and tangents still arise from the same compressed physical input. This reference compression is fundamentally different from jointly compressing the two vectorization factors in the spatial SLD Jordan domain.

## 4. Arbitrary-channel extension: all b^2 components are sufficient

Let Q have effective output dimension b and fix an orthonormal basis e_1,...,e_b of that support. For each c define

    u_c=K_Q(e_c tensor xi),
    z_c=A_Q^(-1)u_c in C^b tensor C^n.

Write z_c=sum_l e_l tensor z_{lc}. Let

    S=span{xi} + span{z_{lc}:1<=l,c<=b}.

Then d=dim S<=1+b^2, and every z_c belongs to C^b tensor S. Put J_Q=I_b tensor V. Compression of the input by I_A tensor V commutes with Q tensor id, so

    A_Q'=J_Q* A_Q J_Q,
    K_Q'=J_Q* K_Q J_Q.

For f_c=e_c tensor xi and f_c'=e_c tensor xi', one has J_Q f_c'=f_c. Since z_c lies in ran J_Q,

    A_Q' J_Q*z_c
      =J_Q*A_Q z_c
      =J_Q*K_Q f_c
      =K_Q'f_c'.                                       (9)

Thus the target quadratic expression for each f_c is exactly preserved. Summing over c gives precisely the target partial-trace quadratic form on xi.

For P, repeat the source variational inequality (7) separately for every vector e_c^P tensor xi in an orthonormal basis of its effective output support. Restricting trial vectors to B_eff(P) tensor S can only decrease each nonnegative source expression. Sum over those output basis vectors. This proves (8) for arbitrary channels with d<=1+b^2.

The proof does not incorrectly assume that z_c is a single reference vector. Keeping its b output components is exactly why the general bound is quadratic in b. For measurement channels only one output component is present in each relevant inverse action, giving the sharper 1+v bound.

Effective output supports are fixed before and after reference compression: A_Phi'>0 on B_eff(Phi) tensor C^d, as follows from the positivity lower bound in Section 1. There is no moving-support inverse problem.

## 5. Faithful reconstruction and exact trace gauge

Choose a faithful reference state

    W_eta=(1-eta)|xi'><xi'|+eta I_d/d

with eta>0 small enough that Tr W_eta D'<0. This exists because the expression tends to (8) as eta decreases to zero. Now define

    R'=(I_A tensor W_eta^(1/2))Rtilde'(I_A tensor W_eta^(1/2)),
    H_0'=(I_A tensor W_eta^(1/2))h'(I_A tensor W_eta^(1/2)).

Then R'>0 and

    Tr R'=Tr[W_eta Tr_A Rtilde']=Tr W_eta=1.

By (2), its RLD source-minus-target difference is exactly Tr W_eta D'<0.

Let c=Tr H_0' and H'=H_0'-cR'. This makes Tr H'=0. For each effective output state A and Hermitian tangent K,

    G_A(K-cA)=G_A(K)-2c Tr K+c^2 Tr A.                  (10)

Trace preservation makes the last two terms identical for P and Q; the negative difference is unchanged. Equivalently, the operator-level partial traces of K and A agree between the two channels, so the normalized D itself is invariant under the corresponding scalar gauge h' -> h'-cRtilde'.

Because R' is faithful, sufficiently small nonzero t gives faithful states R' and R'+tH'. Their standard Petz D_2 comparison fails by (1). This finishes the physical reference cutoff proof without an additional block-reference ancilla. The final bound is d itself, not d+1.

## 6. Boundary states and support conventions

The faithful-pair theorem extends to the usual support convention. Here is an explicit justification, rather than an appeal to cancellation of infinite quantities.

For states A,B, put H=A-B and use a common faithful regularizer Omega. Set

    A_delta=(1-delta)A+delta Omega,
    B_delta=(1-delta)B+delta Omega.

The exact expansion gives

    Q_2(A_delta,B_delta)
       =1+(1-delta)^2 Tr H B_delta^(-1)H.               (11)

The inverse quadratic form has the extended variational expression

    Tr H B^(-1)H
      =sup_Z [2 Re Tr H*Z - Tr Z*B Z],                 (12)

with value infinity when the relevant columns of H are outside the range of B. Fixed trial matrices Z in (12) give the lower-limit inequality as delta ->0. If the value is finite, B_delta>=(1-delta)B gives the upper bound

    Tr H B_delta^(-1)H <= (1-delta)^(-1) Tr H B^(-1)H.

Thus (11) converges to the extended Q_2(A,B). For positive A, the finite-value condition agrees with supp A contained in supp B. Apply this separately to the two channel outputs of a common faithful input regularization. Inequalities on faithful pairs pass to extended limits. There is no infinity-minus-infinity expression.

Therefore failure of the extended comparison also has a faithful strict witness: a finite-source/infinite-target boundary failure is approximated by a strict faithful failure, and finite strict gaps persist. The endpoint cutoff covers the usual unrestricted state-pair order as stated.

## 7. Exact decision procedure, including rational arbitrary channels

With a known cutoff B=1+v or B=1+b^2, at each reference dimension d<=B introduce real and imaginary coordinates for a faithful density matrix R and a traceless Hermitian H. Introduce Hermitian inverse variables for every output state, and express the negative source-minus-target quadratic form using polynomial constraints.

For rational POVMs, all coefficients are rational. Zero effects can be discarded by exact equality testing, and every remaining output block is positive definite for faithful R even if the effect itself is singular.

For arbitrary rational CPTP maps, a singular ambient output is not an obstruction. Compute the orthogonal support projector P_Phi of Phi(I_A). This projector has rational complex entries: choose a rational column basis C of its image and use C(C*C)^(-1)C*. At reference dimension d impose for the inverse variable T

    T=(P_Phi tensor I_d)T(P_Phi tensor I_d),
    T A=A T=P_Phi tensor I_d.

These polynomial constraints uniquely specify the inverse on the fixed effective output support. The rational projector avoids a need for a rational orthonormal basis or an implicit irrational change of coordinates. The relevant b is rank Q(I_A), an exactly computable integer.

Positive definiteness, Hermiticity, normalization and negativity are first-order real-algebraic conditions. Real quantifier elimination therefore decides existence of a violation at each of the finitely many reference sizes. Absence at all those sizes is equivalent to complete standard Petz order-two dominance. The algorithm is total, but no practical running-time bound is asserted.

## 8. Relation to the earlier Volcic route

Before the elementary compression proof was supplied, I independently checked the alternative free-rational route. It also has the right domain: one-sided RLD inverse comparison normalizes to

    R=I_a/a tensor I + sum_mu B_mu tensor X_mu >=0,
    Tr_A R=I,

which is a monic free spectrahedron after multiplication by a. For strictly positive POVM effects, all denominators are bounded below on its closed domain. This is unlike the two-factor spatial SLD domain.

The exact primary source is Jurij Volcic, *Hilbert's 17th problem in free skew fields*, Forum of Mathematics, Sigma 9 (2021), e61, arXiv:2101.02314. Theorem 5.2 treats rational positivity on monic free spectrahedra, and Remark 5.3 gives a finite matrix-evaluation bound from expression complexity, finite subexpression-space dimensions, and linear-representation size. Section 2.3 supplies the constructive linear-representation route. Matrix-valued positivity can be reduced to the scalar expression sum_uv y_u K_uv(x)y_v using extra selfadjoint variables and a star-vector test.

Primary links:

- https://arxiv.org/abs/2101.02314
- https://www.cambridge.org/core/journals/forum-of-mathematics-sigma/article/hilberts-17th-problem-in-free-skew-fields/1DC74DC3E0E011210C826FF4DCA24DE1

That published theorem is sufficient for a computability proof in the strictly positive POVM setting. The elementary argument reviewed above is stronger: it gives the transparent 1+v and 1+b^2 cutoffs, removes strict effect positivity, covers arbitrary channels, and avoids importing the free Positivstellensatz. No n+1 conversion from a free negative evaluation is needed in the elementary proof because faithful restoration occurs inside the compressed reference dimension d.

## 9. Falsification attempts and remaining caveat

I specifically tried the following potential failure points.

1. **Congruence invariance of the scalar RLD trace:** it is false without a reference weight. The proof retains W in (2), so this does not invalidate it.
2. **Target inverse solutions outside the retained subspace:** they are explicitly included, component by component in the arbitrary-channel case. Equations (5) and (9) are exact.
3. **Compression changing the physical denominator tuple:** the same reference isometry compresses the full input Rtilde and h. It commutes with both channels. The actual physical domain is preserved.
4. **Source terms increasing:** the variational formula makes the inequality direction unambiguous. Restricting trial vectors decreases the source term.
5. **Loss of faithfulness or trace normalization:** the compressed baseline is already faithful; W_eta>0 restores trace one without enlarging the reference.
6. **Trace gauge changing the gap:** (10) and trace preservation show exact cancellation, even when channel output dimensions differ.
7. **Arbitrary channels with non-full ambient support:** effective supports are fixed and have explicit rational projector equations for the decision algorithm.
8. **Boundary infinities:** the separate extended-limit argument in Section 6 handles them without subtracting infinities.
9. **Confusion with sandwiched D_2:** explicitly excluded; the theorem is for the standard Petz divergence.

**Exact remaining caveat:** I found no unresolved proof obligation for the elementary cutoff and its arbitrary finite-channel extension under these conventions. Historical priority has not been exhaustively checked and the proof has not had external specialist review. A claimed strict endpoint separation from complete SLD/open-range Petz order still needs the manuscript hardness theorem to be valid or a separate explicit separating pair. Neither compilation nor this same-model reconstruction resolves those distinct issues.
