# Fixed qubit half-erasure characterization: proof and priority audit

Prepared 11 October 2026. Scope: independent audit of the fixed-helper argument in [`sol02_operational.md`](sol02_operational.md), with a focused primary-source priority check against symmetric-side-channel and Smith–Yard results. This is a proof review, not external peer review.

## Verdict

The fixed-helper theorem is valid under the stated finite-dimensional, full-Stinespring-complement, and standard unassisted-capacity assumptions. I found no gap in the random-stabilizer replacement, private-information estimate, or private-to-quantum-capacity passage. The genuinely added step is the replacement of a witness-dependent finite-dimensional half-erasure helper by finitely many uses of the one fixed qubit half-erasure channel. The required number of helper uses depends on the witness and its gap; the result gives neither a uniform blocklength nor a computable activation rate.

Precisely, for each finite-dimensional channel $N:A\to B$, with full complement $N^c:A\to E$, and the qubit erasure channel $S_2=\mathcal E_{2,1/2}$,

\[
N^c\succeq_{\rm RE}^c N
\quad\Longleftrightarrow\quad
P(N\otimes S_2)=0
\quad\Longleftrightarrow\quad
Q(N\otimes S_2)=0.
\]

Here capacities are regularized unassisted capacities of the displayed memoryless channel, and (N^c) is the full complementary output. The complete order tests arbitrary finite untouched references; the communication protocol does not receive an external reference. All dimensions and code lengths in the converse are finite but may depend on the strict witness.

## Audit of the decisive coding lemma

Fix $k\ge1$, and choose a uniformly Clifford-conjugated $[[n,k]]$ stabilizer code. For a fixed erased set $T$ of size $m$, exact erasure correction is equivalent to there being no nontrivial logical Pauli in $S^\perp\setminus S$ supported inside $T$. The stabilizer and normalizer dimensions are $n-k$ and $n+k$. Clifford transitivity on nonzero Paulis therefore gives

\[
\Pr_C[v\in S^\perp\setminus S]
=\frac{2^{n+k}-2^{n-k}}{4^n-1}\le 2^{k-n}.
\]

There are $4^m-1$ nonidentity Paulis supported on $T$, so the union bound is at most $2^{2m-n+k}$. In particular, when $m\le(n-k)/2-t$, the code-averaged probability that Bob's erased set is not correctable is at most $2^{-2t}$. Applying the same estimate to $T^c$ gives the same bound for Eve when $m\ge(n+k)/2+t$.

For a fixed code the two exact-good events are disjoint: otherwise two local decoders would clone an arbitrary $2^k$-dimensional state. Complementing the erasure pattern swaps the events, so their probabilities are equal. The only patterns not covered by one of the two tail estimates lie in a central window of constant width when $k,t$ are fixed. For $M\sim\mathrm{Bin}(n,1/2)$, that window has probability tending to zero as $n\to\infty$. Taking $t$ large first and then $n$ large makes the code-averaged probability of the bad event arbitrarily small; some finite code has bad probability $b<\eta$. This is the correct critical-point argument: each side recovers on probability approaching $1/2$, while the undecodable fraction goes to zero. It does not claim reliable transmission to either side with probability approaching one and so does not conflict with $Q(S_2)=0$.

The exact decoupling step is sound. If the erased set is correctable, dilate Bob's recovery to $U:D\to CG$. The composite $C\to CGF$ dilates the identity channel on the logical system. Uniqueness of a Stinespring dilation then yields

\[
(U\otimes I_F)V|\psi\rangle=|\psi\rangle_C\otimes|\zeta\rangle_{GF},
\]

including when (C) is correlated with the principal channel input and a purifying reference. Thus Eve's *entire* helper environment is constant on Bob-good patterns, not only on a selected decoder's view. The same reasoning applies with the sides reversed. No approximate decoupling is being smuggled into the capacity estimate.

The averaging and existence step is also effective for fixed $k,\eta$: the binomial tail can be bounded by searching over $n$, stabilizer codes at that $n$ are a finite set, and each code's correctability pattern count is finite. The proof does not give a useful uniform bound as $k,\eta$ vary.

## Private-capacity direction

If complete RE order fails, the order/ensemble equivalence supplies a finite ensemble on $AR$ with

\[
\Delta=I(X:BR)-I(X:ER)>0.
\]

The small-prior binary construction in sol02_operational.md handles a finite faithful relative-entropy witness; standard common faithful regularization handles boundary states and extended divergences. The mask register $K=X-U\pmod m$ makes the physical $A$ marginal independent of the message while preserving the full reference-assisted gap after $K$ is observed:

\[
I(U:BRK)-I(U:ERK)=\Delta.
\]

This masking is important: on a good branch, the principal channel's designated output alone then carries no message information. The code sends the finite $RK$ system through $n$ copies of $S_2$. On Bob-good patterns the private-information difference is $+\Delta$; on Eve-good patterns it is $-\Delta$; on bad patterns it is at least $-H(U)$. With equal good probabilities $q=(1-b)/2$,

\[
I(U:BD)-I(U:EF)\ge \frac{1-b}{2}\Delta-bH(U).
\]

Choosing $b<\Delta/(\Delta+2H(U))$ makes this positive. Padding the other $n-1$ principal-channel inputs with fixed message-independent states embeds the protocol in a finite block of $N\otimes S_2$. The private coding theorem then gives strictly positive regularized private capacity. The reverse direction is valid because complete RE order tensorizes, $S_2$ is self-complementary, and the complete environment dominates every finite-block receiver ensemble; the constant message attains zero.

The use of arbitrary finite $R$ does not give the encoder a free side resource: $R$ is physically transmitted through helper uses after the code embedding. This resolves a likely interface objection.

## Quantum-capacity direction

The forward zero implication follows from $Q\le P$ for a genuine channel. For the converse, $P(N\otimes S_2)>0$ gives a finite block $T=(N\otimes S_2)^{\otimes r}$ and a finite ensemble with positive private information. The Smith–Yard entropy identity, for a pure full Stinespring dilation and an erasure helper of dimension $d=\sum_x\operatorname{rank}\rho_x$, converts this to a state with

\[
I_c(T\otimes\mathcal E_{d,1/2},\theta)
=\tfrac12[I(X:B)-I(X:E)]>0.
\]

Purify $\theta$ with finite $K$, and encode its $d$-dimensional helper input into $k=\lceil\log_2d\rceil$ logical qubits of the stabilizer code. On each good pattern, coherent information is exactly the corresponding Smith–Yard branch value; the decoder's $G$ system and the environment's $F$ system have equal entropy because they are in the fixed pure state $\zeta$. For a bad pattern, purity of the full $BDEFK$ output gives

\[
I_c(BD\rangle EF)=-S(K\mid BD)\ge -S(K).
\]

Pattern-flag entropies cancel between receiver and environment. Thus the total coherent information is at least $(1-b)c-bS(K)>0$ for sufficiently small $b$, where $c=I_c(T\otimes\mathcal E_{d,1/2},\theta)>0$. Finally, place the $n$ qubit helpers in $n$ further copies of $N\otimes S_2$ and feed those $N$ inputs pure, fixed states. Their independent coherent information is zero, so this padding preserves the positive coherent information in a finite tensor power. The regularized quantum-capacity theorem gives $Q(N\otimes S_2)>0$.

I checked both signs in the branch and bad-pattern terms. The lower bound depends on the entropy of a finite purifying system but the stabilizer lemma allows the bad fraction to be made smaller than any positive threshold, so this dependence is not an obstruction.

## Closest exact precedents and priority boundary

1. **Hirche, 2026, §4.2, equations (4.8)–(4.9).** A failure of complete less-noisy order yields a finite reference-assisted ensemble; a classical mask makes the physical marginal constant; transmitting the reference and mask through a *witness-dimension* half-erasure channel gives positive private information. Complete order rules out activation with any antidegradable helper by tensorization. This is the direct variable-dimension antecedent. It does not fix the helper input dimension at two or replace it by repeated uses of one helper. [Primary source, arXiv:2610.03706v1](https://arxiv.org/abs/2610.03706).

2. **Smith–Yard, 2008, supplementary theorem and equations (S1)–(S4).** A positive private-information ensemble for a genuine channel gives positive coherent information after tensoring with a finite (50\%\)-erasure channel whose input dimension is the sum of the ensemble-state ranks. Their proof is the exact entropy conversion used above. The helper dimension is witness-dependent; the paper does not state the repeated-fixed-qubit replacement. [Primary source, arXiv:0807.4935](https://arxiv.org/abs/0807.4935).

3. **Smith, 2008, Theorem 5 and equation (4).** The symmetric-side-channel-assisted private capacity optimizes over arbitrary finite symmetric helpers, equivalently a supremum over helper dimension. This framework already explains why complete comparison can be tested by allowing a suitable symmetric zero-capacity side channel. It does not identify one fixed qubit half-erasure as a universal helper under tensor repetition. [Primary source, arXiv:0705.3838](https://arxiv.org/abs/0705.3838).

4. **Smith–Smolin–Winter, 2006.** The symmetric-side-channel quantum capacity is an established additive/convex upper-bound framework using freely available symmetric channels of arbitrary dimension. It is not a fixed-qubit-helper theorem. [Primary source, arXiv:quant-ph/0607039](https://arxiv.org/abs/quant-ph/0607039).

5. **Hirche–Rouzé–Stilck França, 2022, Proposition 2.3 and Lemma 3.1.** The equivalence between complete relative-entropy and complete less-noisy orders, and the tensorization needed for the zero direction, are established channel-order results. They are not part of the novelty claim. [Primary source, arXiv:2011.05949](https://arxiv.org/abs/2011.05949).

**Priority conclusion:** in these primary sources I found the arbitrary finite symmetric-helper characterization, the witness-dependent half-erasure private activator, and the witness-dependent Smith–Yard quantum activator. I did not find the stronger statement that the *same fixed qubit* half-erasure channel, repeated an instance-dependent finite number of times, detects failure of complete environmental dominance, nor the resulting equivalence for both ordinary (P) and (Q). The focused search cannot certify firstness. The defensible claim is a fixed-helper refinement of the variable-dimension symmetric-side-channel results, with the random stabilizer lemma as its new ingredient.

## Scope limits and interface warning

The result is a zero-versus-positive characterization, not a computable bound on $n$, a positive lower bound on the ordinary capacity, or a one-use activation theorem. Its blocklength depends on the reference dimension, entropy gap, and (for the quantum conversion) purification entropy. The random stabilizer argument only proves existence of such a finite block.

The designated-output broadcast built from measurement channels in the Dots manuscript remains a different interface. Its receiver marginal is a measurement channel, antidegradable relative to its full Stinespring complement. Therefore a designated-output private-capacity reduction for that broadcast cannot be promoted to ordinary complementary-channel $P$ or $Q$ undecidability while preserving the same receiver marginal. The fixed-helper theorem itself is unconditional and does not repair that missing reduction.

## Primary sources

- Hirche, [*Quantum estimation, channel orders, and private capacity*](https://arxiv.org/abs/2610.03706).
- Smith–Yard, [*Quantum Communication With Zero-Capacity Channels*](https://arxiv.org/abs/0807.4935).
- Smith, [*The private classical capacity with a symmetric side channel and its application to quantum cryptography*](https://arxiv.org/abs/0705.3838).
- Smith–Smolin–Winter, [*The quantum capacity with symmetric side channels*](https://arxiv.org/abs/quant-ph/0607039).
- Hirche–Rouzé–Stilck França, [*On contraction coefficients, partial orders and approximation of capacities for quantum channels*](https://arxiv.org/abs/2011.05949).
- Devetak, [*The private classical capacity and quantum capacity of a quantum channel*](https://arxiv.org/abs/quant-ph/0304127).
