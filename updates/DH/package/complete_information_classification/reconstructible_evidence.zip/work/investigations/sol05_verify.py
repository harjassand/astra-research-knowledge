"""Diagnostic checks for the analytic identities in sol05_radical.md.

These checks are finite floating-point evidence, not proof certificates.
Uses only numpy and mpmath already present on this host.
"""

import json
import math
from fractions import Fraction

import mpmath as mp
import numpy as np

mp.mp.dps = 45


def matrix_power(a, power):
    eig, vectors = np.linalg.eigh(a)
    eig = np.maximum(eig, 0)
    if power < 0 and np.min(eig) <= 0:
        raise ValueError("Negative power on singular matrix")
    return (vectors * (eig**power)) @ vectors.conj().T


def block_diagonal(a, b):
    result = np.zeros((len(a) + len(b),) * 2, dtype=complex)
    result[: len(a), : len(a)] = a
    result[len(a) :, len(a) :] = b
    return result


def q_alpha(a, b, alpha):
    return float(np.trace(matrix_power(a, alpha) @ matrix_power(b, 1 - alpha)).real)


def hessian_checks():
    a = np.array([[0.50, 0.04 + 0.03j, 0.02], [0.04 - 0.03j, 0.30, 0.025j], [0.02, -0.025j, 0.20]])
    k = np.array([[0.1, 0.03 - 0.02j, -0.04j], [0.03 + 0.02j, -0.04, 0.015], [0.04j, 0.015, -0.06]])
    leaves = np.array([0.7, 1.3, 2.2])
    wdiag = np.r_[1.0, leaves]
    z = float(wdiag.sum())
    v = np.r_[0.0, np.ones(3) / math.sqrt(3)]
    w = np.array([0.0, 0.7 + 0.2j, -0.4 + 0.1j, 0.3 - 0.2j])
    e0 = np.array([1.0, 0, 0, 0])
    l = np.outer(e0, w.conj()) + np.outer(w, e0)
    tau = np.outer(v, v.conj())
    b0 = np.kron(a, np.diag(wdiag))
    y = np.kron(k, l)
    aeig, au = np.linalg.eigh(a)
    keig = au.conj().T @ k @ au
    leafcoeff = [mp.mpc(complex(w[j + 1].conjugate() * v[j + 1])) for j in range(3)]

    def filter_value(t):
        return sum(c / (mp.mpf(float(lam)) + t) for c, lam in zip(leafcoeff, leaves))

    checks = []
    for alpha in [0.25, 0.5, 1.5, 1.9, 2.0]:
        q = 1 - alpha
        numerator_power = np.kron(matrix_power(a, alpha), tau)

        def objective(eps):
            return (-np.sign(q)) * z ** (-q) * float(np.trace(numerator_power @ matrix_power(b0 + eps * y, q)).real)

        if alpha == 2:
            endpoint = abs(filter_value(mp.mpf("0"))) ** 2
            predicted = 2 * z * float(endpoint) * sum(abs(keig[i, j]) ** 2 / aeig[j] for i in range(3) for j in range(3))
        else:
            predicted = mp.mpf("0")
            for i in range(3):
                for j in range(3):
                    ai = mp.mpf(float(aeig[i]))
                    aj = mp.mpf(float(aeig[j]))
                    # Remove the integrable endpoint singularity when q is near -1.
                    low = mp.quad(lambda x: 20 * x ** (20 * (mp.mpf(q) + 1) - 1) * abs(filter_value(x**20)) ** 2 / (aj + ai * x**20), [0, 1])
                    high = mp.quad(lambda t: t**mp.mpf(q) * abs(filter_value(t)) ** 2 / (aj + ai * t), [1, mp.inf])
                    integral = low + high
                    predicted += abs(keig[i, j]) ** 2 * integral
            predicted = float(2 * abs(mp.sin(mp.pi * q)) / mp.pi * z ** (-q) * predicted)
        finite_differences = {}
        for eps in [0.002, 0.001, 0.0005]:
            value = (objective(eps) - 2 * objective(0) + objective(-eps)) / eps**2
            finite_differences[str(eps)] = {"value": value, "relative_error": abs(value - predicted) / max(1e-30, abs(predicted))}
        checks.append({"alpha": alpha, "predicted": predicted, "finite_differences": finite_differences})
    return {"commutator_hs_norm": float(np.linalg.norm(a @ k - k @ a)), "checks": checks}


def flag_checks():
    rng = np.random.default_rng(7013)
    results = []
    for dim in [2, 3, 4]:
        def state():
            x = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim))
            y = x @ x.conj().T + 0.2 * np.eye(dim)
            return y / np.trace(y)

        rho, sigma = state(), state()
        left = block_diagonal(rho, sigma) / 2
        right = block_diagonal(sigma, rho) / 2
        grid = np.linspace(0.005, 0.995, 199)
        errors = [abs(q_alpha(left, right, s) - (q_alpha(rho, sigma, s) + q_alpha(rho, sigma, 1 - s)) / 2) for s in grid]
        values = [q_alpha(left, right, s) for s in grid]
        affinity = q_alpha(rho, sigma, 0.5)
        results.append({"dim": dim, "identity_max_abs_error": max(errors), "argmin_grid": float(grid[int(np.argmin(values))]), "minimum_minus_affinity": float(min(values) - affinity), "commutator_hs_norm": float(np.linalg.norm(rho @ sigma - sigma @ rho))})
    return results


def filter_checks():
    results = []
    aa, bb = mp.mpf("1.7"), mp.mpf("0.6")
    for q in [-0.8, 0.5, 0.8]:
        entries = []
        for m in [2, 4, 8, 16, 32]:
            poles = [1 + mp.mpf(j) / m**3 for j in range(2 * m + 1)]
            at_one = sum(mp.log(1 + pole) for pole in poles)

            def density(t):
                if t == 0:
                    return mp.mpf("0")
                logf = m * mp.log(t) - sum(mp.log(t + pole) for pole in poles) + at_one
                return mp.exp(2 * logf + mp.mpf(q) * mp.log(t))

            pieces = [0, mp.mpf("0.25"), mp.mpf("0.5"), mp.mpf("0.75"), 1, mp.mpf("1.25"), mp.mpf("1.5"), 2, 4, mp.inf]
            normalizer = mp.quad(density, pieces)
            kernel = mp.quad(lambda t: density(t) / (bb + aa * t), pieces) / normalizer
            entries.append({"m": m, "kernel": float(kernel), "target": float(1 / (aa + bb)), "absolute_error": float(abs(kernel - 1 / (aa + bb)))})
        results.append({"q": q, "entries": entries})
    return results


def exact_checks():
    import sympy as sp

    a = Fraction(1, 2)
    lift = [(Fraction(3, 2), Fraction(-1, 2)), (Fraction(-1, 2), Fraction(3, 2)), (Fraction(1, 2), Fraction(1, 2))]
    for weights, target in [([Fraction(1, 4), 0, Fraction(3, 4)], [Fraction(3, 4), Fraction(1, 4)]), ([0, Fraction(1, 4), Fraction(3, 4)], [Fraction(1, 4), Fraction(3, 4)])]:
        assert [sum(weight * coeff[j] for weight, coeff in zip(weights, lift)) for j in range(2)] == target
        # Keep B0 B1 and B1 B0 separate, so this verifies matrix-valued scores.
        squares = {(i, j): sum(weight * coeff[i] * coeff[j] for weight, coeff in zip(weights, lift)) for i in range(2) for j in range(2)}
        assert squares == {(0, 0): target[0], (0, 1): 0, (1, 0): 0, (1, 1): target[1]}
    source = Fraction(139, 100)
    target = Fraction(208, 147)
    assert target - source == Fraction(367, 14700)
    alpha, t = sp.symbols("alpha t")
    xx, yy = (alpha - 2) / 3, (alpha + 1) / 3
    binomial = lambda u, k: sp.prod(u - j for j in range(k)) / sp.factorial(k)
    fourth = sp.factor(sum(binomial(alpha, k) * binomial(1 - alpha, 4 - k) * yy**k * xx ** (4 - k) for k in range(5)))
    assert sp.simplify(fourth + alpha * (alpha - 1) * (alpha - 2) * (alpha + 1) / 72) == 0
    return {"noncommutative_square_lift": "exact_pass", "alpha3_source_Q": str(source), "alpha3_target_Q": str(target), "alpha3_gap": str(target - source), "alpha_above_two_fourth_coefficient": str(fourth)}


if __name__ == "__main__":
    print(json.dumps({"status": "finite_diagnostic_only", "exact": exact_checks(), "hessian": hessian_checks(), "flag": flag_checks(), "filters": filter_checks()}, indent=2))
