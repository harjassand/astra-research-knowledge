"""Package frozen research evidence; no scientific certification is implied."""
from pathlib import Path
import hashlib
import json
import zipfile

base = Path(__file__).resolve().parent.parent
out = base / 'outputs'
handoff = {
  'date': '2026-10-11',
  'campaign_status': 'Complete internally reconstructed mathematical investigation; historic objective not achieved',
  'authoritative_report': 'outputs/research_report.pdf',
  'editable_source': 'outputs/research_report.tex',
  'read_order': ['outputs/research_report.pdf', 'outputs/ASTRA_HANDOFF.json',
                'work/investigations/root_universality.tex',
                'work/investigations/rld_finite_cutoff.md',
                'work/investigations/root_rld_endpoint_review.md',
                'work/investigations/alpha_independent_review.md'],
  'selected_results': [
    {
      'id': 'FIXED_PETZ_GENERATOR_UNIVERSALITY',
      'statement': 'For finite channels and every finite untouched quantum reference, dominance on every faithful pair for one fixed standard modular Petz divergence with finite f(0+) and nonzero interior resolvent measure is equivalent to complete SLD dominance.',
      'mechanism': 'Saturated auxiliary-reference denominator Hessian; rational resolvent filters localize any positive representing-measure support point, including singular measures; F(0)=0 kills the quadratic endpoint.',
      'dots_dependency': False,
      'status': 'Complete internally reconstructed proof; independent AI adversarial reviews found no fatal gap; external and formal validation absent',
      'priority': 'No exact predecessor located in focused primary-source search; historical originality UNKNOWN'
    },
    {
      'id': 'QUADRATIC_FINITE_REFERENCE_COMPRESSION',
      'statement': 'Failure of complete standard Petz D2 order P>=Q has a faithful reference witness of dimension <=1+b_Q^2. For a target POVM with v nonzero outcomes, <=1+v suffices. Rational strictly positive POVM order is decidable by real quantifier elimination.',
      'mechanism': 'Reference-marginal congruence produces operator-valued comparison; retain target inverse-action vectors, compress the actual input, preserve target costs and decrease source costs; restore faithful reference and traceless tangent.',
      'dots_dependency': False,
      'status': 'Complete elementary proof reconstructed by Sol05/root and two independent AI reviewers; no external or formal validation',
      'priority': 'Generic decidability already follows from Volcic 2021 Thm5.2/Rem5.3; potential contribution is small target-only geometric cutoff, exact priority UNKNOWN'
    },
    {
      'id': 'FINITE_AT_ZERO_COMPUTABILITY_CLASSIFICATION',
      'statement': 'Modulo affine terms: affine order is trivial; pure positive quadratic order is decidable; every nonquadratic finite-at-zero operator-convex modular Petz generator induces SLD order. If Dots core reduction is valid, the last case is coRE-complete on rational strictly positive POVMs.',
      'dots_dependency': 'Only the coRE-completeness, no-computable-cutoff and strict endpoint separation conclusions depend on Dots core.',
      'instances': 'Every fixed standard Petz Renyi alpha in (0,2), Umegaki and state-pair Chernoff orders coincide. Alpha2 is the decidable endpoint. Any fixed positive resolvent perturbation of a quadratic restores the SLD order. Explicit rational efficient instrument versus identity gives unconditional strict endpoint separation for GENERAL finite channels: D2 is completely preserved but SLD16/25<1 on a qubit tangent.',
      'status': 'Analytic classification has complete internal proof; hardness is conditional; originality UNKNOWN'
    }
  ],
  'source': {
    'original_path': '/Users/harjas/Downloads/channel_order_undecidability.pdf',
    'preserved_copy': 'work/manuscript/channel_order_undecidability.pdf',
    'sha256': 'e7ca558825f266d892ec1cedaac40ad33b3db3ecaf5ebd456ef70938cb4e127f',
    'pages': 27,
    'source_date': '2026-10-10',
    'source_status': 'User-supplied internally developed candidate, not independently established',
    'audit': 'MIP finite-perfect PCC premise checked; targeted Sections3-6 anchor/rounding, Sections7-9 global compiler/completion, and Sections11-14 quantitative audits found no fatal gap. The full source game-to-global-POVM theorem remains an internally reconstructed hardness dependency, not externally certified.',
    'coordinate_correction': 'For V(v)=sum v_alpha P_alpha and X=sum(P_alpha tensor Z_alpha+P_alpha* tensor Z_alpha*), physical trace uses zeta=sum conjugate(v_alpha) Z_alpha. Equivalently conjugate V coefficient convention. PDF Eq54 is8/lambda; text extraction omitted fraction bar.',
    'source_bytes_changed': False
  },
  'repositories': {
    'https://github.com/harjassand/astra-research-knowledge': '902172b63c13874f5572e4f1336afad3694ea328',
    'https://github.com/openai/math': 'fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb'
  },
  'allocation': {
    'literature_workers': 16,
    'literature_model': 'gpt-6-luna',
    'literature_reasoning': 'max',
    'mathematical_workers': 5,
    'mathematical_model': 'gpt-6.1-sol',
    'mathematical_reasoning': 'max',
    'notes': 'Distinct primary-literature missions in waves; lit06 repeatedly disconnected and was replaced by lit16. Root developed general measure-localization proof and combined classification. Worker count is not validation.'
  },
  'secondary_results': {
    'fixed_qubit_helper': 'Complete internally reconstructed proof: for genuine finite N and fixed qubit half-erasure S2, Nc>=cRE N iff P(N tensor S2)=0 iff Q(N tensor S2)=0; independent of Dots, uses established coding theorems; independent AI proof audit found no gap. Fixed-helper priority unresolved. See sol02_operational.md and fixed_helper_review.md.',
    'uniform_flatness': 'Conditional fixed-additive relative conditional coefficient hardness with IC, equal-trace, arbitrary fixed flatness and rank<=4 scalar deviations. Independent AI review found no fatal gap; coefficients unbounded across input class. See sol01_stronger.md and lit12_sol01_review.md.',
    'fixed_carrier': 'Conditional fixed h6 inverse-Jordan operator-system matrix-cone hardness. Broad fixed-OS hardness has direct MIP predecessors; no fixed channel input dimension. See sol04_transfer.md and fixed_carrier_review.md.'
  },
  'falsification': {
    'general_f_hessian': '50 finite matrix cases; max relative discrepancy7.948201924659617e-16',
    'chernoff_flag': '10 finite cases; exact global identity also proved analytically',
    'quadratic_blindness': 'F(0)=0 gives zero quadratic Hessian',
    'rld_compression': 'Noncommuting reference11->3; target term error<=5.7e-14; source terms decrease; faithful restored violation retained',
    'domain_compression': 'Exact spatial Jordan counterexample has Choi eigenvalue-1/10; arbitrary joint compression changes domain',
    'beyond_alpha2': 'Archived exact/rational alpha3 counterexample and analytic family for every alpha>2',
    'scope': 'Finite diagnostics are scoped evidence only, not proofs of universal claims, hardness or novelty'
  },
  'limits': [
    'No established historic9-10/10 breakthrough; substantial potential structural research result only',
    'No fixed physical channel-input dimension hardness; input dimension/outcome count may grow',
    'No sandwiched Renyi theorem; no equal-reference-marginal restriction',
    'No ordinary complementary private/quantum-capacity hardness or locality-preserving Hamiltonian compiler',
    'No fixed-error hardness for every new divergence defect; no uniform reference-filter preparation or coefficient-size bound',
    'Pure quadratic versus SLD strictness with BOTH channels rational positive POVMs remains conditional on hardness; general-channel strictness has an explicit rational instrument counterexample',
    'No algorithm for recognizing generator class from an arbitrary function oracle'
  ],
  'next_indispensable_gate': [
    'External specialist reconstruction of selected two complete proofs and exact priority check',
    'Validate source actual-spatial-domain to completed global POVM bridge with conjugation convention corrected',
    'For genuine capacity or physics hardness, construct complement- or locality-preserving compiler; current channels alone do not supply it'
  ],
  'publication_actions': 'None: no commit, push, PR, publication or scientific outreach',
  'manifest': 'SHA256SUMS.json inside reconstructible_evidence.zip'
}
(out / 'ASTRA_HANDOFF.json').write_text(json.dumps(handoff, indent=2) + '\n')

readme = '''# Reconstruction package

The authoritative exposition is outputs/research_report.pdf (editable .tex alongside it).
Read outputs/ASTRA_HANDOFF.json for claim dependencies and exact unresolved gates.
These are complete internally reconstructed proposed proofs, not formal or external certification.
Generic endpoint decidability has prior rational-positivity machinery; sharp bounds and fixed-generator localization have unresolved priority.
All hardness relying on Dots is explicitly conditional.

## Contents and provenance

- work/manuscript/channel_order_undecidability.pdf: unchanged supplied source, SHA256 in manifest and handoff.
- work/manuscript/channel_order_undecidability.txt: lossy extraction; PDF controls fraction bars and conjugations.
- work/manuscript/astra_operational_extensions.tex: pinned internal antecedent, not external validation.
- work/investigations/: five complementary mathematical investigations, selected proofs, adversarial reviews and finite diagnostics.
- work/literature/: focused original-source receipts. They are research notes, not an exhaustive priority survey.
- SHA256SUMS.json: integrity hashes of every included file except the manifest itself.

The report supersedes developmental status wording in earlier investigation notes.
No Git repositories or bulk third-party source caches are included. Repository revisions are pinned in the handoff.
All source PDFs and quoted mathematics remain attributed to their original sources.

## Replay finite diagnostics

From the extracted package root, Python with numpy, sympy and mpmath is sufficient.
Observed runtimes: Python3.14.3/numpy2.5.3/sympy1.14.0/mpmath1.3.0;
root numerical checks also replayed on bundled Python3.12.14/numpy2.3.5.
Small last-digit floating-point differences across BLAS/platforms are possible.

    python3 work/investigations/root_general_f_check.py
    python3 work/investigations/rld_cutoff_diagnostic.py
    python3 work/investigations/sol03_boundary_check.py
    python3 work/investigations/sol05_verify.py
    python3 work/investigations/sol01_checks.py
    python3 work/investigations/sol01_rank_checks.py
    python3 work/investigations/sol04_packing_falsification.py

Some scripts write a sibling .json result; others print JSON. Captured original results are included.
These executions verify finite algebra/identities only. The proofs must be reconstructed from the mathematics.

## Compile the standalone proof report

The Codex built-in compiler returned success. The exported PDF was also compiled with TeXLive2024 pdflatex;
the final log had no undefined references or overfull boxes, and all pages were rendered for layout review.
With a TeX installation, from the extracted package root:

    pdflatex -interaction=nonstopmode -halt-on-error outputs/research_report.tex
    pdflatex -interaction=nonstopmode -halt-on-error outputs/research_report.tex

work/build_report.py reconstructs the report from the root derivation and campaign exposition.
SHA256 integrity, successful compilation, finite replays and AI-review agreement do not establish correctness or originality.
'''
files = [out / 'research_report.tex', out / 'research_report.pdf', out / 'ASTRA_HANDOFF.json',
         base / 'work/build_report.py', base / 'work/render_report.py', base / 'work/package_evidence.py']
files += sorted((base / 'work/investigations').glob('*'))
files += sorted((base / 'work/literature').glob('*.md'))
files += [base / 'work/manuscript/channel_order_undecidability.pdf',
          base / 'work/manuscript/channel_order_undecidability.txt',
          base / 'work/manuscript/astra_operational_extensions.tex']
files = [p for p in files if p.is_file()]
manifest = {str(p.relative_to(base)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
manifest['README.md'] = hashlib.sha256(readme.encode()).hexdigest()
destination = out / 'reconstructible_evidence.zip'
with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
    for p in files:
        archive.write(p, str(p.relative_to(base)))
    archive.writestr('README.md', readme)
    archive.writestr('SHA256SUMS.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    checks = json.loads(archive.read('SHA256SUMS.json'))
    for name, expected in checks.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected, name
print(json.dumps({'archive': str(destination), 'files': len(manifest)+1,
                  'bytes': destination.stat().st_size, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
                  'integrity_verified': True}, indent=2))
