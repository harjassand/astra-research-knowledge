from pathlib import Path
import pypdfium2 as pdfium
from PIL import Image, ImageOps, ImageDraw

base = Path(__file__).resolve().parent.parent
out = base / 'work/report-render'
out.mkdir(exist_ok=True)
pdf = pdfium.PdfDocument(str(base / 'outputs/research_report.pdf'))
thumbs = []
for i, page in enumerate(pdf):
    im = page.render(scale=1.5).to_pil().convert('RGB')
    im.save(out / f'page-{i+1:02d}.png')
    thumb = ImageOps.contain(im, (390, 560))
    tile = Image.new('RGB', (410, 600), 'white')
    tile.paste(thumb, ((410-thumb.width)//2, 25))
    ImageDraw.Draw(tile).text((10, 580), str(i+1), fill='black')
    thumbs.append(tile)
sheet = Image.new('RGB', (1230, 600*((len(thumbs)+2)//3)), '#d0d0d0')
for i, tile in enumerate(thumbs):
    sheet.paste(tile, ((i%3)*410, (i//3)*600))
sheet.save(out / 'contact.png')
print(f'Rendered {len(pdf)} pages.')
