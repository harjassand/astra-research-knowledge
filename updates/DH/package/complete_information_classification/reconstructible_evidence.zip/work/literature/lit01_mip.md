# MIP*=RE premise used by `channel_order_undecidability.txt`

## Finding

The external premise in Sections 1 and 12 is supported by the cited primary source, with one encoding clarification below. The manuscript cites the correct detailed result: Ji, Natarajan, Vidick, Wright, and Yuen, *MIP*=RE*, arXiv:2001.04383v3. Theorem 12.6 (printed p. 172) gives a computable map from a Turing machine `M` to a two-player game `G` with:

- if `M` halts on the empty input, `ω*(G) = 1` and, additionally, a **finite-dimensional PCC strategy wins with certainty**;
- if `M` does not halt on the empty input, `ω*(G) ≤ 1/2`.

The source’s exact completeness wording is: “there is a (finite-dimensional) PCC strategy for the players in G that wins with certainty.” ([Theorem 12.6, arXiv v3 PDF, p. 172](https://arxiv.org/pdf/2001.04383v3#page=172).) Its Theorem 12.6 is stronger than the headline value promise alone and supplies precisely the finite attainment Section 12 needs.

For a machine with a supplied input, first effectively wrap it in a machine that starts on blank input and simulates the original machine on that input. Thus the source’s empty-input formulation gives the manuscript’s stated machine-and-input reduction.

## What “finite rational game” means here

The source defines a finite game by finite question and answer alphabets, a question distribution, and a Boolean decision predicate (Definitions 5.1–5.3). The reduction outputs a bounded-time sampler and decision procedure (Definition 5.29 and Theorem 12.6). Bounded random tapes give a finite-support distribution with dyadic rational probabilities, and the predicate is computable on the finite alphabets. Enumerating all random tapes therefore expands the succinct verifier into an explicit finite rational game table. This expansion is computable, which suffices for the manuscript’s computable many-one reduction. It can be exponentially larger than the sampler/decider description, so a polynomial-time claim applies to the succinct verifier encoding, not automatically to an explicit table encoding. Section 1 only claims effective construction; there is no mismatch for its stated classification.

The source’s ω* is the supremum over finite-dimensional tensor-product strategies (Definition 5.3). Hence the nonhalting soundness statement is exactly a bound over the strategy domain used by the manuscript. In the halting case, Theorem 12.6 separately states finite-dimensional attainment.

## Consistency and the maximally entangled sector

Definitions 5.9–5.11 (printed pp. 51–52) define a PCC strategy as projective, consistent, and commuting. “Consistent” applies to every answer projector in each player’s measurement family: its action on the first register of the shared vector agrees with the corresponding same-matrix action on the second register. The finite-dimensional and projective hypotheses in Theorem 12.6 are explicit. The source also says PCC implies synchrony in its proof overview (printed p. 10); Remark 5.13 (printed p. 51) records the finite-dimensional characterization of synchronous strategies for symmetric games in terms of projectivity, consistency, and a maximally entangled state.

The manuscript’s Lemma 12.1 gives a direct route that does not need to assume that the original perfect state is maximally entangled or that an arbitrary game has a maximally entangled optimizer. Write the finite pure state as `ψ = vec(C)`. For every consistent Hermitian projector `M`, consistency gives `MC = CMᵀ`; combining this with its adjoint yields `[M, CC*] = 0`. The corresponding right-side projectors preserve the matching eigenspaces of `(C*C)ᵀ`. On a positive Schmidt eigenvalue `λ` of multiplicity `dλ`, the normalized restriction of `ψ` is maximally entangled of local dimension `dλ`. All measurement families restrict to projective measurements on that sector. Since the original score is a convex combination of sector scores in `[0, 1]`, a score of one forces every nonzero sector to score one. Selecting any such sector yields a finite perfect maximally entangled strategy. The commuting part of PCC is not needed for this sector argument.

This is a source-specific existence argument. The machine-to-game reduction does not output the strategy, its dimension, its Schmidt eigenvalue, or a sector basis, and it does not need to find them.

## Gap and computability consequences

There are two distinct uses of completeness:

1. **Undecidability in Sections 1 and 10.** The original game promise is `1` versus at most `1/2`. With `r = 3/4` and `γ = 1/4`, the nonhalting side gives the manuscript’s uniform positive polynomial gap `γ/2 = 1/8`. On the halting side, `ω* = 1` implies that some finite strategy scores above `7/8`, even without attainment. Section 10 explicitly uses this weaker fact, so its strict violation does not depend on a perfect strategy.
2. **Computable margin in Sections 12–14.** For the additive-approximation result, a merely unattained supremum of one would not provide a concrete finite witness. Theorem 12.6’s finite perfect PCC strategy and Lemma 12.1 supply one. The manuscript then normalizes its witness so that the unknown sector dimension cancels from the Fisher lower bound `δG = 4δs²γ/λ > 0` (Eq. 71). Sections 12–13 express the remaining bounds using rational quantities computed from the game; Lemma 13.1 turns them into a positive rational entropy margin `εG`. Thus `εG` is effectively positive **per game**, not one uniform margin for all games. The strategy and witness dimension are not computed. The tensor-power argument in Section 14 uses the computed `εG` to reach fixed additive error `1/4`.

The manuscript correctly distinguishes these two arguments: Section 1.1 says attainment is not needed for the base reduction, while Section 12 imports the stronger finite-perfect part for dimension-independent margins. The only precision edit worth considering is to state in Section 1.1 that the game can first be output succinctly as the source’s sampler/decider and then effectively expanded to a finite rational table; this avoids suggesting that the explicit table is produced in polynomial time.

## Primary references

- Ji, Natarajan, Vidick, Wright, and Yuen, [*MIP*=RE*, arXiv:2001.04383v3](https://arxiv.org/abs/2001.04383v3), especially Theorem 12.6 (p. 172), Definitions 5.1–5.3 and 5.9–5.11 (pp. 50–52), Remark 5.13 (p. 51), and the proof overview (pp. 10–11).
- Paulsen, Severini, Stahlke, Todorov, and Winter, [*Estimating quantum chromatic numbers*, arXiv:1407.6918](https://arxiv.org/abs/1407.6918), the synchronous-strategy reference cited by Remark 5.13; published in *Journal of Functional Analysis* 270 (2016), 2188–2222, [doi:10.1016/j.jfa.2016.01.010](https://doi.org/10.1016/j.jfa.2016.01.010).

This review verifies the imported MIP*=RE premise and its use for finite-dimensional completeness. It does not independently re-audit the manuscript’s internal channel, POVM, Fisher-gap, or entropy-filter lemmas.
