# Sections 7–9 global compiler audit

Investigator: `/root/lit12_global`. Date: 11 October 2026.

## Finding

I find no fatal counterexample in Sections 7–9. On direct reconstruction, the ordered-word penalty compiler, complex residue realization, and all-base POVM completion are mathematically consistent, with one local conjugation error in Section 8.2's definition of `U_t`. Under the stated matrix-unit and tangent conventions, the correct coordinate is

`U_t = sum_alpha conjugate((v_t)_alpha) Z_alpha = v_t^* Z`.

This is exactly the coordinate selected by `H_r = sum_t c_t v_t v_t^*`. The physical numerator effects as defined in the PDF already implement this coordinate, so the construction and the kernel identity are correct after this line is repaired. If the displayed bilinear `sum (v_t)_alpha Z_alpha` is used literally with the stated `V(v)` and `X`, it can reverse an imaginary-residue contribution. This is a proof/notation correction, not a counterexample to the constructed POVMs. I visually checked the authoritative PDF: Eq. (54) is `8/lambda`, with lambda in the denominator; the extracted text's `8 lambda` is wrong.

The all-base completion is substantive: it proves the signal-plus-padding comparison for every faithful base and Hermitian tangent, including coherent physical baselines and arbitrary finite reference size. The gauge and paired resolvent identity close those two cases with explicit, dimension-independent constants.

## Source checked

I read the manuscript text at `work/manuscript/channel_order_undecidability.txt` and rendered the corresponding authoritative PDF at `/Users/harjas/Downloads/channel_order_undecidability.pdf`. Visual checks included PDF pp. 3–4 for the SLD convention, p. 7 for the raw effects, pp. 14–20 for Sections 7–9, and p. 17 for Eq. (54). The report distinguishes this primary-source inspection from numerical tests; no numerical test is used to establish the infinite-reference assertions.

## Section 7: finite ordered-word compiler

The domain is the manuscript's actual joint spatial tensor-Jordan domain. For one fixed pair `R,S`, all letters share the same positive `D=B_I(R,S)` and

`Z_j = D^(-1/2) B_{A_j}(R,S) D^(-1/2)`, with `alpha I <= A_j <= (1-alpha) I`.

Thus `alpha I <= Z_j <= (1-alpha)I`; the letters are contractions but are not treated as arbitrary unrelated matrix tuples. The output kernel uses only the fixed positive denominators `B_{A_j}`, `B_{I-A_j}=D-B_{A_j}`, and `D`.

For an edge `v=jw`, set `u=D^(1/2)x`, `w'=D^(1/2)y` (using `w'` here to distinguish the vector from a word). The penalty is

`Q_j(u,w') = <u,B^(-1)u> + <w'-u,(D-B)^(-1)(w'-u)> - <w',D^(-1)w'>`.

After congruence by `D^(1/2)`, this is the one-operator identity

`Q_j = <x-Z_j y, [Z_j(I-Z_j)]^(-1)(x-Z_j y)> >= 4 ||x-Z_j y||^2`.

Only functions of the same Hermitian `Z_j` are multiplied; no unproved commutation of `B` and `D` is needed.

For the suffix-closed word set `W`, the root-to-word matrix `H_p` represents

`P(z)=c_empty ||z_empty||^2 + Re sum_(w != empty) c_w <z_empty,z_w>`.

On the exact graph `z_v=Z_j z_w`, this is `<z_empty,p(Z)z_empty>`. The residues in Eq. (47) subtract `M_1` at each parent, add `M_1` at each child through the `B_A^(-1)` term, and add `M_1(e_w-e_v)(e_w-e_v)^*` through the complement term. Their total quadratic form is exactly `P(z)+M_1 sum_edges Q_j`.

For completeness, let `r_v=z_v-Z_j z_w`, `t^2=sum_v ||r_v||^2`, and `a=||z_empty||`. Iterating along the suffix path gives

`||z_v-Z_v z_empty|| <= sqrt(|v|) t`,
`sum_v ||z_v-Z_v z_empty||^2 <= L_w t^2`.

Hence the root-only objective error is at most `b a t`, where `b=sum_(w != empty)|w| c'_w` and rational `c'_w >= |c_w|`. With `M_1=b^2/(8g)+1/4`, Young's inequality and the edge bound give

`<U,KU> >= (g/2)a^2+t^2`.

Also `sum_v ||z_v||^2 <= 2N_w a^2+2L_w t^2`, yielding the stated conservative

`eta = g/(4N_w+2gL_w)` and `K >= eta I_nodes tensor D^(-1)`.

This works for every finite reference pair on the actual domain whenever `p(Z)>=gI` there. A strict negative polynomial witness transfers with every edge residual zero (`z_v=Z_v xi`), exactly and at the same baseline/reference. The constant-polynomial case is covered by `L_w=0`. A finite matrix-coefficient extension follows by tensoring the root/node construction with the coefficient space and bounding each coefficient term by a rational operator-norm bound. The compiler requires a uniform positive gap; it does not compile mere nonnegativity.

## Section 8: rational complex residues as measurement numerators

Every rational Hermitian residue has a finite signed rank-one decomposition over rational complex vectors. Diagonal units and the outer products of `e_j +/- e_k` and `e_j +/- i e_k` span the Hermitian matrix units, so irrational eigenvector choices are unnecessary.

For a signed term `c_t v_t v_t^*` at denominator `A_r`, the two identical baseline outcomes use upper block `lambda A_r/|c_t|` and lower scalar block `lambda Tr(A_r)/(p_0|c_t|) I`. A rational sufficiently small `lambda` makes their sum strictly below identity; the common positive filler completes a rational strictly positive POVM. The numerator quadratures are `O_1=V(v_t)+V(v_t)^*`, `O_2=iV(v_t)-iV(v_t)^*`, with `V(v)=sum_alpha v_alpha P_alpha`; both are assigned to source for `c_t>0`, to target for `c_t<0`, and zero on the other side. The effects are rational Hermitian and need not be positive themselves because a later rational `delta` is chosen to make `D_i +/- delta O_i` strictly positive.

For a block-diagonal physical baseline and a cross tangent

`X=sum_alpha (P_alpha tensor Z_alpha + P_alpha^* tensor Z_alpha^*)`,

direct partial trace gives, for the first quadrature,

`Tr_H[(V(v)+V(v)^*)X] = U+U^*`, with `U=sum_alpha conjugate(v_alpha) Z_alpha`.

The second gives `iU^*-iU` (an overall sign does not affect its quadratic cost). These are the two Hermitian quadratures of the same arbitrary complex `U`; summing their SLD costs cancels cross terms and equals `4 <U,Omega^(-1)U> = 8 <U,J^(-1)U>`, where `Omega=J/2` and `J(Z)=AZ+ZA`. This explains both why complex residues are represented and the factor eight.

Each baseline denominator block evaluates to `(lambda/|c_t|) B_{A_r}(R_eff,R_eff)`, with `R_eff=R_0+(I_{p_0}/p_0) tensor Tr_{q_0}T`. Both physical diagonal blocks can be faithful while realizing every `R_eff>0`: choose a sufficiently small positive scalar lower block and subtract its effective contribution from `R_eff`. Combining the two quadratures, the scale, and the signed assignment gives exactly

`Gamma_Rbar(X) = (8/lambda) <vec Z, K(R_eff,R_eff) vec Z>`.

The vectorization identity uses the same standard residue action: `<z,(v v^*)z>=|v^*z|^2`. This is why the bar in `U=v^*Z` matters. Eq. (54)'s denominator is verified visually from PDF p. 17.

A rectangular negative kernel witness embeds as an off-diagonal reference block of the square baseline `R direct-sum S`; the square Sylvester inverse restricts to the rectangular one. The resulting tangent is traceless and has zero physical partial trace. Faithful physical padding preserves the effective baseline. Thus both the positive coercivity and strict negative slice transfer have the required finite-dimensional witnesses.

## Section 9: completion for every base/tangent

For an arbitrary faithful physical-reference base `R`, put `W=Tr_H R` and

`A=Omega_W^(-1)(Tr_H X)`, `X'=X-Omega_R(I_H tensor A)`.

Then `Tr_H X'=0`. Every physical trace-preserving channel obeys

`Phi_R(Omega_R(I tensor A))=Omega_{Phi_R(R)}(I tensor A)`.

Expanding the SLD metric shows the shift from `X` to `X'` is channel independent: its value is `-2 Tr[X(I tensor A)]+Tr[R(I tensor A^2)]`. It therefore cancels in the source-minus-target difference. This quotient is necessary because reference-only scores have exactly equal metric at both outputs. It does not posit coercivity on those unobservable directions.

Write the gauged tangent as physical diagonal `Y`, selected cross component `X_C`, and cross component `X_inv` orthogonal to the numerator span. The target erasure branch sees zero; signal numerators see `Y` only through `U_i=Tr_H(D_iY)` and `X_C` through `Z_i=Tr_H(O_i X_C)`; `X_inv` is invisible. The source's strictly positive block-diagonal informationally complete padding sees only `Y`. Since each padding effect `G_h<=I`, its output base is at most `W`, so inverse-Jordan order and the positive frame Gram matrix give a uniform lower bound `c |Y|_W^2`.

For a paired signal, let `R_i=Tr_H(D_iR)`, `V=Tr_H(OR)`, `J=Omega_{R_i}`, `K=Omega_V`, `u=J^(-1/2)U`, `z=J^(-1/2)Z`, and `T=J^(-1/2)KJ^(-1/2)`. Averaging the inverse of `I +/- delta T` gives the exact identity

`F_pair=||u||^2 + delta^2 <z-Tu,(I-delta^2 T^2)^(-1)(z-Tu)>`.

The first term cancels between source and target. With `||T||<=kappa`, the remainder satisfies `0 <= (I-delta^2 T^2)^(-1)-I <= (4/3)delta^2 kappa^2 I` when `delta kappa<=1/2`.

Define `a=|X_C|_W`, `b=|Y|_W`, `gamma=2eta/lambda`, and the rational bounds `B_z,B_u` of Eq. (59). Pinching the physical base preserves `W`, all `R_i`, and `R_eff`; hence the leading `z^2` difference is at least `gamma a^2` even when the actual base has coherent physical blocks. The mixed and resolvent terms give Eq. (60):

`delta^(-2) Delta_signal >= gamma a^2 - 2 kappa sqrt(B_z B_u) ab - kappa^2 B_u b^2 - (8/3)delta^2 kappa^2(B_z a^2+kappa^2 B_u b^2)`.

The bounds `delta^2<=3gamma/(16 kappa^2 B_z)` and `delta kappa<=1/2`, followed by Young, leave `gamma a^2/4-C_0 b^2`, with `C_0=(5/3)kappa^2B_u+4kappa^2B_zB_u/gamma`. Because final signal outcomes carry weight `1/2`, the padding's corresponding `c/2` lower bound absorbs the diagonal loss if `delta^2<=c/C_0`. All these are effective rational conditions; a positive dyadic `delta` can be selected below them and below the strict-effect positivity bound.

For a negative witness, the block-diagonal base makes `V=0`, a pure cross tangent makes `U=0`, and the padding tangents vanish. The final gap is exactly `delta^2 Gamma_R(X)/2<0`, with no remainder estimate. Positive and negative claims therefore cover every faithful base/tangent in the required directions.

## Section 10: reduction and computability consequences

With game threshold `r=3/4` and gap `gamma=1/4`, nonhalting gives `omega*(G)<=1/2=r-gamma`. Proposition 6.1 supplies the uniform polynomial gap `g=gamma/2=1/8`; Section 7 turns it into an inverse-kernel gap; Section 9 turns that into complete SLD dominance. If the machine halts, `omega*(G)=1`, so some finite strategy scores strictly above `7/8=r+gamma/2`. The resulting faithful strict-negative polynomial witness transfers exactly through Sections 7–8 and gives the Section 9 cross-slice SLD violation. The POVM output depends only on the finite rational game and effective constants, not on a computed strategy or reference dimension. This is a computable many-one reduction from halting to failure of complete SLD dominance.

The upper bound is also correctly scoped. For rational strictly positive POVMs, enumerate reference sizes, rational faithful input states, and rational traceless Hermitian tangents. Solve the rational SLD Sylvester systems exactly; each Fisher difference is rational and its sign decidable. Strict violations persist under small perturbations, so the dense rational enumeration finds every real strict violation. Thus failure is RE; with the reduction it is RE-complete and dominance coRE-complete. For any fixed reference size, violation existence is a first-order real-algebraic question: state/tangent/scores are real coordinates, strict positivity is semialgebraic, and Sylvester equations plus the score inequality are polynomial constraints. Quantifier elimination decides that fixed level. This fixed-level decision fact alone is not a computable reference cutoff.

## Exact defects and audit limits

1. **Section 8.2 coordinate repair.** Under the PDF's explicit `P_alpha`, `V(v)`, and `X` conventions, direct partial trace yields `v^*Z`, not `v^T Z`. Correct that definition (or conjugate the `V` convention throughout). The residue quadratic is `v v^*`, and the actual outputs realize it. A two-coordinate imaginary off-diagonal Hermitian residue witnesses the sign mismatch if the printed bilinear is used literally.
2. **Eq. (54) extraction.** Authoritative PDF p. 17 reads `8/lambda`; plaintext extraction loses the fraction and may report `8 lambda`. Any calculation must use `8/lambda`.
3. No flaw found in the all-base reference gauge, complex quadrature cancellation, filler normalization, pinching argument, resolvent coercivity constants, or faithful witness padding. This is a reconstruction/audit of the cited sections, not an independent reproof of the long preceding game-to-polynomial construction in Sections 3–6.

## Strongest compiler statement and neighboring literature

The strongest justified generic statement is a finite effective compiler for scalar rational Hermitian noncommutative polynomials (and, by coefficient-space tensoring, finite matrix-coefficient polynomials) evaluated on the specified common-`D` spatial two-factor domain: a uniform positive polynomial gap yields an explicit rational finite sum of inverse Jordan denominators with a uniform operator gap `K>=eta I tensor D^(-1)`; a strict negative polynomial witness on that same domain transfers exactly. The statement is about this explicit inverse-Jordan kernel representation. It is not a theorem that general positive free polynomials or arbitrary noncommutative rational functions admit this compiler, and it does not supply a finite-size cutoff.

Primary context:

- Helton–Klep–McCullough, [*The Tracial Hahn–Banach Theorem, Polar Duals, Matrix Convex Sets, and Projections of Free Spectrahedra*](https://arxiv.org/abs/1407.8198), develops matrix-convex/spectrahedrop Positivstellensatz frameworks for free polynomial positivity. Its levelwise free-domain hypotheses are not shown to coincide with the manuscript's constrained spatial two-factor domain, so it supplies context rather than a ready-made cutoff or compiler.
- Volčič, [*Matrix coefficient realization theory of noncommutative rational functions*](https://arxiv.org/abs/1505.07472) and [*On domains of noncommutative rational functions*](https://arxiv.org/abs/1608.02594), treats matrix evaluations, realizations, extended domains, and rational identity testing. Those results do not directly give signed inverse-Jordan measurement residues or the all-base POVM completion.
- Hirche–Rouzé–França, [*On contraction coefficients, partial orders and approximation of capacities for quantum channels*](https://arxiv.org/abs/2011.05949), gives the broader quantum partial-order/contraction-coefficient setting.
- Hirche, [*Quantum estimation, channel orders, and private capacity*](https://arxiv.org/html/2610.03706v1), posted 2 October 2026. Its complete measured-`chi^2` comparison implies complete relative-entropy/less-noisy comparison through a coherent-qubit construction (Theorem 3.2, especially Eqs. (3.6) and the proof at HTML lines 277–279). This overlaps the manuscript's SLD-to-relative-entropy direction; the manuscript's Section 2 proof is not priority evidence for that direction by itself. It does not provide the Sections 7–9 rational-POVM undecidability compiler.
- Hirche–George–Nuradha–Wilde, [*Conditional contraction coefficients and their applications to quantum networks*](https://arxiv.org/html/2608.27171v1), defines the relative conditional coefficient in Eq. (2.45) and proves its CMI/binary-CMI equality in Corollary 6. This is relevant to the later numerical extension, not a substitute for this manuscript's POVM bridge.

No exhaustive novelty claim is made. This audit found no external result in the cited neighboring frameworks that removes the manuscript's need to prove its domain-specific kernel-to-POVM and global-completion steps.
