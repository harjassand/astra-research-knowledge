# Capacity and quantum-automata results: interface and transfer audit

## Decisive conclusion

The capacity literature establishes serious non-computability phenomena, but the strongest exact results target different objects from the manuscript's defect. The manuscript's Sections 11–14 define, for a rational strictly positive POVM pair \(E,F\),

\[
V(E,F)=\sup_{R,\rho,\sigma}\big[D(F_R(\rho)\Vert F_R(\sigma))-D(E_R(\rho)\Vert E_R(\sigma))\big],
\]

where every finite untouched reference is allowed and the input-state pair has **no equal-reference-marginal condition**. The note proves coRE-completeness of complete SLD/relative-entropy order, no computable sufficient reference cutoff, and no total algorithm for approximating \(V\), including at fixed additive error \(1/4\). Its target-side input is an explicit pair of strictly positive measurement channels, with a bounded entropy-defect objective.

The nearest capacity landmarks do not subsume that theorem:

* Cubitt–Elkouss–Matthews–Ozols–Pérez-García–Strelchuk prove that no *uniform finite number of channel uses* detects positive quantum capacity. They explicitly describe this as evidence for, not a proof of, uncomputability.
* Elkouss–Strelchuk prove private-information superadditivity persists to arbitrarily high blocklength across a family of channels. This is another obstruction to a universal truncation formula, not a reduction from halting or a computability classification for private capacity.
* Bhattacharyya–Mehta–Zhao give a full RE-hardness reduction for a restricted **one-shot, maximally-entangled-assisted zero-error** classical capacity of a c-q channel, and a QMA-hard promise-gap result for quantum capacity of **circuit-described** channels. Neither is the same channel class, optimization, or input encoding as \(V(E,F)\).
* Measure-once quantum finite automata (MO-QFA) have precise threshold undecidability results, but their input is a word over fixed unitary generators. The reduction needed to turn those word-value predicates into admissible positive inverse-Jordan measurement kernels is absent.

There are nonetheless exact, useful consequences and obstructions. Complete relative-entropy order implies the expected ordering of classical and entanglement-assisted classical information rates, but undecidability of the stronger order does not imply undecidability of comparing those scalar capacities. Every strictly positive measurement channel has zero zero-error capacity and cannot transmit private or quantum information, while its ordinary classical capacity is a computable finite-dimensional optimization. This rules out importing the zero-error/Q/P undecidability results by merely re-labeling the manuscript's channels.

## 1. Cubitt–Elkouss et al.: quantum capacity and no finite block cutoff

**Primary source:** Toby S. Cubitt, David Elkouss, William Matthews, Maris Ozols, David Pérez-García, and Sergii Strelchuk, [*Unbounded number of channel uses are required to see quantum capacity*](https://arxiv.org/abs/1408.5115), later published as [*Unbounded number of channel uses may be required to detect quantum capacity*](https://doi.org/10.1038/ncomms7739), *Nature Communications* 6, 6739 (2015).

**Exact interface and theorem.** A finite-dimensional quantum channel is built from an erasure channel, a noisy PPT-binding channel whose Choi state approximates a private bit, and a classical switch retained at the output. For every positive integer \(n\), the authors choose a channel \(\mathcal M\) (whose dimension and parameters depend on \(n\)) such that

\[
Q^{(n)}(\mathcal M)=0,\qquad Q^{(N+1)}(\mathcal M)>0
\]

for some \(N+1>n\). The first equality is optimized over *all* states on \(n\) copies; it is not just a failure of their exhibited code. The positive later coherent information certifies \(Q(\mathcal M)>0\). The construction's switch chooses, per use, between a noisy private-bit channel and an erasure channel; repetition across many shield parts eventually lets the receiver distinguish the hiding states and recover entanglement. The paper leaves a dimension-independent strengthening open and says its theorem is an indication that capacity may be uncomputable. It does not prove that.

**Transfer assessment.** This is a theorem about the regularization index needed to witness positive coherent information. It proves there is no single channel-use cutoff that works for all channels. It is not a halting reduction, and it does not show a fixed channel whose positive capacity has no finite witness: each positive-capacity instance has some finite \(N+1\). The manuscript's reference-cutoff theorem has a related shape but a different quantifier: it rules out any total computable bound on the reference dimension sufficient for every failure of a *given* channel-order instance, using the manuscript's own undecidability reduction. Neither cutoff theorem alone supplies the other.

The CEM+ result also cannot be specialized by simply taking \(\mathcal M\) to be a strictly positive POVM channel. A POVM channel is entanglement-breaking and has zero quantum capacity. Its Stinespring environment can recover the classical outcome label, so it cannot provide private communication either. The switch construction relies on coherent quantum transmission and approximate private-bit structure that this measurement-channel form removes.

## 2. Elkouss–Strelchuk: private information and regularization

**Primary source:** David Elkouss and Sergii Strelchuk, [*Superadditivity of private information for any number of uses of the channel*](https://arxiv.org/abs/1502.05326), *Physical Review Letters* 115, 040501 (2015).

They use the regularized formula

\[
P(\mathcal N)=\lim_{k\to\infty} k^{-1}P^{(1)}(\mathcal N^{\otimes k}),\qquad
P^{(1)}(\mathcal N)=\max_{\{p_x,\rho_x\}} I(X;B)-I(X;E).
\]

Their Theorem 1 states that for each \(n\), there is a quantum channel \(\mathcal N_n\) such that for each \(n>k\ge 1\),

\[
\frac1kP^{(1)}(\mathcal N_n^{\otimes k})
<\frac1{k+1}Q^{(1)}(\mathcal N_n^{\otimes(k+1)}).
\]

This yields arbitrarily long strict regularization/superadditivity behavior, and also a qualitative interleaving of the private and coherent-information sequences. It does not provide an undecidable zero-versus-positive promise, a lower bound on the asymptotic private capacity tied to a machine, or a fixed-error approximation obstruction. In particular, one cannot promote “arbitrarily many channel uses matter” to “private capacity is uncomputable” without a uniform reduction and a margin argument.

This is useful context for Sections 11–14 because those sections do *more* than exhibit nonadditivity: they compute a positive per-instance entropy margin from the game and tensor-amplify it to a fixed error. Conversely, Elkouss–Strelchuk's regularization concerns one channel's coding ensembles and its complementary channel, not a comparison of two channels on every reference-entangled state pair.

## 2.5 Classical capacity: regularization and computability are separate

For an ordinary finite classical channel, Shannon's formula is the single-letter maximum of input-output mutual information; with a finite rational transition table this is a computable optimization. For a general quantum channel, the Holevo–Schumacher–Westmoreland coding theorem gives the regularized Holevo quantity, and Hastings' primary counterexample [*Superadditivity of communication capacity using entangled inputs*](https://arxiv.org/abs/0809.3972) disproves the hoped-for general additivity. This shows that entangled codewords and multiple uses can improve classical transmission through quantum channels. It does not establish undecidability or rule out arbitrary-precision algorithms.

The distinction matters here: Dots' input channels are q-to-c measurements, a much narrower entanglement-breaking class with additive Holevo capacity, while the standard quantum-channel classical capacity question ranges over arbitrary quantum outputs. No classical-capacity undecidability follows just from Hastings' nonadditivity, and the standard classical Shannon capacity has a different one-use interface again.

## 3. Modern capacity hardness and zero-error undecidability

**Primary source:** Archishna Bhattacharyya, Arthur Mehta, and Yuming Zhao, [*On the undecidability of quantum channel capacities*](https://arxiv.org/abs/2601.22471), arXiv:2601.22471v3. The version reviewed states two distinct results.

### 3.1 QMA-hard quantum-capacity estimation is circuit-input hardness

Corollary 3.13 gives a Karp reduction from QMA to the promise problem: given a channel \(\Phi_\mathcal C\) by a succinct quantum circuit \(\mathcal C\), decide whether

\[
Q(\Phi_\mathcal C)\ge 3/4 \quad\text{or}\quad Q(\Phi_\mathcal C)\le 1/4,
\]

promised one case holds. In fact, their reduction lands in degradable channels, where the regularized capacity equals one-shot coherent information. The construction applies the QMA verifier isometry, measures its decision qubit, and uses a symmetric direct sum of an identity channel and a zero-capacity anti-degradable amplitude-damping channel. The capacity equals the verifier's maximum acceptance probability.

The result rules out an efficient constant-error classical algorithm for this **circuit encoding** unless \(P=QMA\). It is not unconditional uncomputability and it is not a statement for an explicit rational POVM list. A circuit on \(m\) qubits can have a superoperator/Choi description of size exponential in \(m\); transferring this lower bound to a representation that explicitly lists matrix entries needs an encoding-size analysis. It also does not establish hardness for the quantum capacity of measurement channels, whose quantum capacity is zero.

### 3.2 RE-hard restricted one-shot zero-error capacity

Theorem 4.1 maps each finite simple graph \(G\) computably to a classical-to-quantum channel \(\Phi_G\) satisfying

\[
C^{(1)}_{0,\mathrm{PME}}(\Phi_G)=\log\alpha_q(G),
\]

where \(\alpha_q(G)\) is the quantum independence number. The capacity in Definition 2.3 is for one channel use, with a maximally entangled shared state of an arbitrary finite local dimension and projective quantum-to-classical encoders. Zero error means the receiver's conditional output states for different messages have orthogonal supports. Since determining \(\alpha_q(G)\ge t\) is RE-hard by the MIP*=RE-based perfect independent-set-game reduction, Corollary 4.2 makes the capacity threshold problem RE-hard. This is a genuine computability result for a capacity, unlike the QMA-hardness result above.

The exact threshold problem is reduced via an integer-valued graph parameter. This establishes arbitrary-precision noncomputability: an algorithm that approximated the capacity to every requested rational precision would allow a sufficiently fine, effectively chosen precision to distinguish \(\log(t)\) from \(\log(t-1)\). The theorem as stated does **not** give a fixed numerical gap independent of \(t\), since \(\log(t)-\log(t-1)\to0\). It therefore does not by itself imply impossibility of a universal additive-\(1/4\) approximation. Sections 12–14 of the manuscript address exactly this gap for \(V\) by computing a game-dependent positive margin and tensor-amplifying it.

This zero-error theorem shares one structural feature with Dots: both quantify over arbitrary finite but unbounded ancillary/shared-state dimension, and both ultimately use perfect finite-dimensional strategies for yes-instances. The target predicates remain different. The graph-channel construction encodes pairwise orthogonality and PVM codewords; Dots embeds a gapped game polynomial into complete SLD/relative-entropy comparison for strictly positive measurement channels. No map from \(\Phi_G\) or \(\alpha_q(G)\) to a Dots pair preserving the threshold is stated in the capacity paper.

## 4. Quantum finite automata: exact word-threshold interfaces

**Primary sources:**

* Vincent D. Blondel, Emmanuel Jeandel, Pascal Koiran, and Natacha Portier, [*Decidable and undecidable problems about quantum automata*](https://arxiv.org/abs/quant-ph/0304082), later *SIAM Journal on Computing* 34(6), 1464–1473 (2005).
* Paul C. Bell and Mika Hirvensalo, [*On Injectivity of Quantum Finite Automata*](https://arxiv.org/abs/1907.01471).

For the measure-once model in Blondel et al., an automaton is specified by rational unitary matrices \(X_a\) (one per alphabet symbol), an initial unit vector \(s\), and a projection \(P\); its value on a finite word is

\[
\operatorname{Val}_A(w)=\|sX_wP\|^2.
\]

For non-strict threshold recognition, emptiness is undecidable; their PCP reduction already gives fixed-size presentations (7 matrices in dimension 6, or 2 matrices in dimension 42), and the threshold can be shifted to any rational \(\lambda<1\) by an effective construction. In contrast, for MO-QFA with rational unitary generators, the strict-threshold existential problems \(\exists w:\operatorname{Val}(w)>\lambda\) and \(\exists w:\operatorname{Val}(w)<\lambda\) are decidable. The strict result uses that the closure of the generated unitary semigroup is an effectively enumerable algebraic compact group and then applies real quantifier elimination. The threshold convention is material; it cannot be dropped in a summary of the undecidability theorem. Measure-many models have different results.

Bell–Hirvensalo prove that injectivity of the MO-QFA acceptance-probability function over all words is undecidable for 8 states and alphabet size 17, even when transition unitaries and the projection have rational entries and the initial vector is real algebraic. They also obtain undecidability with rational initial vector at a huge state bound. This is a PCP-style equality-of-word-products problem, not a capacity problem.

**Transfer assessment.** The word form is suggestive because Dots Sections 7–9 compile ordered words into inverse-Jordan kernels and rational positive effects. But the interfaces do not coincide: QFA ranges over products of fixed unitaries and asks whether one finite word crosses a cutpoint; Dots tests a channel-information inequality over the full normalized two-factor Jordan domain and all finite references. A complete transfer would need an explicit effective encoding of each QFA letter by admissible positive measurement effects, plus proof that the acceptance gap is equivalent to the sign of the *global* Dots defect over every allowed tuple. The existing word compiler only compiles the manuscript's game polynomial after its domain and soundness proof; it is not, by itself, such an automaton embedding. Also, MO-QFA strict emptiness is decidable, while non-strict undecidability often lives exactly at a boundary with no uniform gap. This does not provide the computable positive margin needed for fixed-error approximation hardness.

## 5. Zero-error superactivation is not capacity undecidability

**Primary source:** Toby S. Cubitt, Jianxin Chen, and Aram W. Harrow, [*Superactivation of the Asymptotic Zero-Error Classical Capacity of a Quantum Channel*](https://arxiv.org/abs/0906.2547), *IEEE Transactions on Information Theory* 57, 8114 (2011). They construct two channels each with zero asymptotic zero-error classical capacity, whose joint use has positive zero-error classical capacity. Chen, Cubitt, Harrow, and Smith further show simultaneous superactivation phenomena for classical and quantum zero-error capacities in [*Entanglement can completely defeat quantum noise*](https://arxiv.org/abs/1109.0540). Cubitt and Smith show extreme superactivation of zero-error quantum capacity in [*An Extreme Form of Superactivation for Quantum Zero-Error Capacities*](https://arxiv.org/abs/0912.2737).

These are existence and nonadditivity results about orthogonal code states and noncommutative confusability graphs. They do not establish undecidability or rule out a computable approximation to ordinary noisy capacity. The 2026 graph/quantum-independence reduction above is the sharper computability result and targets a different, explicitly restricted one-shot assisted zero-error quantity.

For Dots' channel class, every POVM effect satisfies \(E_i\ge a_i I\) for some \(a_i>0\). Thus for any input \(\rho_{AR}\), the output block obeys

\[
\operatorname{Tr}_A[(E_i\otimes I)\rho_{AR}]\ge a_i\rho_R.
\]

Every outcome block has the same reference support for every encoded message. Consequently no two messages can have orthogonal channel-output supports, even with an arbitrary finite shared/reference system, and the zero-error capacity is zero. This support property is discontinuous at the boundary where effects lose strict positivity, so taking a limit of positive Dots effects does not preserve a zero-error code.

## 6. What transfers exactly, and what blocks the inference

1. **Exact order implies capacity monotonicity, but not an undecidable capacity comparison.** If \(E\succeq_{c\mathrm{RE}}F\), then for any finite classical ensemble \(\{p_x,\rho_x\}\), each relative-entropy term \(D(E(\rho_x)\Vert E(\bar\rho))\) is at least its \(F\)-counterpart. Averaging yields \(\chi_E\ge\chi_F\); replacing channel factors one at a time extends this to block ensembles, so the unassisted classical capacities satisfy \(C(E)\ge C(F)\). The same order also implies \(C_E(E)\ge C_E(F)\) for entanglement-assisted classical capacity: its one-shot objective is

   \[
   I(R;B)=D((E\otimes\mathrm{id})(\phi_\rho)\Vert E(\rho)\otimes\rho_R),
   \]

   a special pair with matching reference marginal (Bennett–Shor–Smolin–Thapliyal's single-letter formula). This only gives a **one-way implication from order to capacity inequality**. The converse fails in principle because capacity compares one optimized aggregate number, while complete order quantifies over every pair and reference. A reduction proving complete-order undecidability therefore does not decide either capacity comparison.

2. **Strict measurement channels have trivial quantum/private/zero-error capacities.** They are entanglement-breaking and hence have \(Q=0\). In a Stinespring realization that copies the outcome label to the environment, the complementary channel can measure that label and reproduce the receiver's classical output; the environment can simulate the receiver, so private communication also has capacity zero. Strict positivity gives the common-support argument above, forcing zero zero-error capacity. These results directly forbid transferring positive-Q, private-bit, or orthogonality-code constructions into this restricted class without changing its interface.

3. **Their ordinary classical capacity is a different, computable scalar.** A finite POVM channel is entanglement-breaking. Shor's additivity theorem for entanglement-breaking channels gives a single-letter Holevo-capacity formula for its classical capacity. With \(m\) outcomes, the induced classical channel has a compact input set of probability vectors; an optimal ensemble needs at most \(m+1\) signal states. For rational strictly positive effects, every output probability is bounded below by an effectively computable positive number, so the finite-dimensional optimization has an effective continuity modulus and admits uniform arbitrary-precision approximation. This sharply separates computing \(C(E)\) from deciding whether \(E\) dominates \(F\) on all complete relative-entropy tests. The same observation applies to the scalar entanglement-assisted capacity by its one-letter mutual-information formula and compact finite-dimensional optimization.

4. **Unbounded witnesses are not by themselves a margin theorem.** CEM+ and Elkouss–Strelchuk exclude universal finite regularization cutoffs. The quantum-automata results encode existential word thresholds, often without a uniform strict gap. The graph capacity theorem uses integer thresholds whose neighboring logarithms approach each other. By contrast, Dots Sections 12–14 compute a positive rational margin for each hard game without learning the strategy dimension, turn the Fisher gap into a faithful entropy gap, and amplify by a computable tensor power. That additional work is what supports the manuscript's fixed \(1/4\)-error claim.

5. **Potential research route, still missing a reduction.** A future transfer from MO-QFA to \(V\) would need to preserve rationality, strict positivity, normalization, arbitrary references, and global soundness while realizing the automaton's unitary-word threshold as a sign of the complete channel defect. The manuscript's own game-to-kernel compiler is strong evidence that structured word polynomials can be encoded, but the automata source alone does not supply this domain-preserving map. A transfer from the 2026 zero-error theorem would additionally need to overcome the support obstruction caused by strict POVM positivity. Neither route is established by the cited papers.

## Primary references

* Cubitt, Elkouss, Matthews, Ozols, Pérez-García, Strelchuk, [arXiv:1408.5115](https://arxiv.org/abs/1408.5115), especially the main theorem and switched-channel construction; journal version [doi:10.1038/ncomms7739](https://doi.org/10.1038/ncomms7739).
* Elkouss and Strelchuk, [arXiv:1502.05326](https://arxiv.org/abs/1502.05326), Theorem 1.
* Shannon, [*A Mathematical Theory of Communication*](https://doi.org/10.1002/j.1538-7305.1948.tb01338.x); Hastings, [arXiv:0809.3972](https://arxiv.org/abs/0809.3972), for single-letter classical DMC capacity versus nonadditive quantum-channel classical capacity.
* Bhattacharyya, Mehta, Zhao, [arXiv:2601.22471](https://arxiv.org/abs/2601.22471), Corollary 3.13, Definition 2.3, Theorem 4.1, Corollary 4.2.
* Blondel, Jeandel, Koiran, Portier, [arXiv:quant-ph/0304082](https://arxiv.org/abs/quant-ph/0304082), Theorems 2.1 and 3.2, Corollary 2.3.
* Bell and Hirvensalo, [arXiv:1907.01471](https://arxiv.org/abs/1907.01471), Theorem 4 and rational-initial-vector extension.
* Cubitt, Chen, Harrow, [arXiv:0906.2547](https://arxiv.org/abs/0906.2547); Chen, Cubitt, Harrow, Smith, [arXiv:1109.0540](https://arxiv.org/abs/1109.0540); Cubitt and Smith, [arXiv:0912.2737](https://arxiv.org/abs/0912.2737), for zero-error superactivation.
* Shor, [*Additivity of the Classical Capacity of Entanglement-Breaking Quantum Channels*](https://arxiv.org/abs/quant-ph/0201149), for the single-letter classical-capacity claim on measurement channels.
* Bennett, Shor, Smolin, Thapliyal, [*Entanglement-Assisted Capacity of a Quantum Channel and the Reverse Shannon Theorem*](https://arxiv.org/abs/quant-ph/0106052), for the one-shot mutual-information formula for entanglement-assisted classical capacity.
* Wolf, Cubitt, Pérez-García, [*Are problems in Quantum Information Theory (un)decidable?*](https://arxiv.org/abs/1111.5425), especially §§2.7, 3.5–3.6: fixed-block zero-error questions admit semialgebraic decision procedures, while quantification over unbounded blocklength removes that finite quantifier-elimination route; the authors distinguish undecidability from quantitative computability.

This note audits neighboring capacity and automata results and their interfaces. It does not independently re-check the manuscript's new Jordan-kernel, POVM-completion, or entropy-filter proofs.
