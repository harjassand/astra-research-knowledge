# Focused proof audit: Sections 3–6 (Pauli anchor, UCP limit, smoothing, and rounding)

**Verdict, scoped to these sections.** I found no explicit counterexample or fatal proof gap in Sections 3–6. The Pauli rigidity estimate, its conditioning-free inverse-root step, the pointwise passage from arbitrary UCP maps, the local-unitary smoothing, and the final game-score rounding are internally consistent with the stated hypotheses. The inequalities are quantitative and their constants have substantial slack at the final score bound. The UCP extension is pointwise for each fixed finite-dimensional instance; no uniform rate in the marginal condition numbers is proved or needed. One effective-input qualification should be made explicit if Proposition 6.1 is read as an algorithmic statement: its γ must be a rational/effectively supplied positive gap (or come with a computable positive lower bound), since the construction uses ceilings involving (1/\gamma). The fixed rational promise gap used in the reduction satisfies this qualification.

This audit uses the authoritative PDF, `work/manuscript/channel_order_undecidability.pdf`, as the equation source; its pp. 7–14 were checked against the text extraction, with the ambiguous fractions on the Pauli effects and smoothing operator read from the PDF. In particular, Eq. (15) is (A_i=(I+\tau\sigma_i\otimes I)/2), (A_{i,g}=(I+\tau\sigma_i\otimes e_g)/2), τ=1/2, and Eq. (31) is the full average (M_0=(P+\sum_{i=0,X,Y,Z}x_iGx_i)/5). Eq. (31) includes (x_0=I). The detailed verification below follows the printed equation numbers.

## 1. Domain and exact Stinespring structure

For physical dimension (h=2N), (N=MK), the effects live in (M_2\otimes\mathbb C^N\cong\bigoplus_{g=1}^N M_2). The central minimal projections (e_g) encode the question–answer labels. With τ=1/2, the physical effects

\[
A_i=\frac{I+\tau\sigma_i\otimes I}{2},\qquad
A_{i,g}=\frac{I+\tau\sigma_i\otimes e_g}{2}
\]

and their complements lie in ([I/4,3I/4]). Thus their normalized centered variables (T_i=(2Z_{A_i}-I)/\tau) and (T_{i,g}=(2Z_{A_{i,g}}-I)/\tau) are self-adjoint contractions on the actual two-factor normalized Jordan domain. This is not a relaxation to arbitrary unrelated tuples: a single pair (R,S>0) fixes the common (D), (p,q), and all normalized letters.

The two Choi-derived maps are UCP maps on the *whole* finite-dimensional physical algebra. The left map uses (B^T) in the Choi pairing, so its Pauli action has the transposed orientation; the right map has the ordinary orientation. Dilating each full map gives exact opposite Pauli representations (x_i,y_i), with payload projections (a_g,b_g) commuting with the Pauli representation on their own side and summing to the identity. The formula

\[
T_i=px_ip+qy_iq,\qquad T_{i,g}=px_ia_gp+qy_ib_gq
\]

is valid in that common local Stinespring dilation. It is not asserted for arbitrary decomposable compressions before the dilation argument. This distinction is essential: exact Pauli multiplication and cross-party commutation are used in Lemma 4.1.

For honest finite strategies, (a_{x,a}=M_{a|x}/M), (b_{y,b}=N_{b|y}/M), (p=q=I/\sqrt2), and (x_i=\sigma_i^T,y_i=\sigma_i). The Bell vector is fixed by the opposite Pauli products, while the payloads act on the strategy spaces. These honest Choi baselines can be singular, but (D=2I) is invertible; later strict negativity is made faithful by a separate perturbation.

## 2. Lemma 4.1: quantitative Pauli rigidity

Write (e_i(v)=\langle v,(I-T_i^2)v\rangle), (e=\sum_i e_i), (c=\sum_{(i,j)\,\mathrm{cyclic}}\|[T_i,T_j]v\|^2), and δ=e+c. For (C:v\mapsto(pv,qv)), (C) is an isometry and (T_i=C^*\pi_i C), where πi=(x_i\oplus y_i). The compression residual ρi=πiCv−CTiv obeys \(\|\rho_i\|^2=e_i(v)\). Opposite chirality gives

\[
\|[T_i,T_j]v+2iU_kv\|\le \sqrt{e_i(v)}+\sqrt{e_j(v)},\qquad U_i=px_ip-qy_iq,
\]

and the anticommutator comparison gives \(\|\{T_i,T_j\}v\|\le\sqrt{e_i} +\sqrt{e_j}\) for (i\ne j). Squaring the commutator estimate with the weighted Young inequality gives exactly the manuscript's bound

\[
\sum_k\|U_kv\|^2\le \tfrac34 c(v)+\tfrac32 e(v).
\]

The critical inverse-root calculation does not commute a same-side Pauli through its marginal weight. Set (A=r^{-1}), (B=s^{-1}), (F=A+B), (a=A^{1/2}), (b=B^{1/2}), ξ=(F^{-1/2}v), α=(a\xi), β=(b\xi). Then (p=bF^{-1/2}), (q=aF^{-1/2}); only the cross-side commutations ([b,x_i]=[a,y_i]=0) are used. The residual in the column orthogonal to (C) and the skew compression term are

\[
d_i=F^{-1/2}ab(x_i-y_i)\xi,\quad \|d_i\|^2=e_i(v),\qquad
U_iv=F^{-1/2}(Bx_i-Ay_i)\xi.
\]

Adding these identities yields the exact Eq. (25)

\[
x_i\beta-y_i\alpha=F^{1/2}(a+b)^{-1}(U_iv+d_i).
\]

The multiplier is a function of the commuting positive (A,B), with norm at most one because \(\sqrt{a^2+b^2}/(a+b)\le1\). Consequently

\[
E_*:=\sum_{i=X,Y,Z}\|x_i\beta-y_i\alpha\|^2
\le 2\sum_i(\|U_iv\|^2+e_i(v))\le5\delta(v).
\]

The sum here is over the three Pauli letters, not the identity. For (c_i=x_iy_i), Σi=X,Y,Z (c_i=4P-I). Splitting the displayed (E_*) into (P,Q) components gives the PDF's exact identity

\[
E_*=3\|P(\alpha-\beta)\|^2+3\|Q\alpha\|^2+3\|Q\beta\|^2
 +2\operatorname{Re}\langle Q\alpha,Q\beta\rangle.
\]

This implies \(\|\alpha-\beta\|^2\le E_*\) and \(\|Q\alpha\|^2+\|Q\beta\|^2\le E_*/2\). The scalar comparison between \(\sqrt{a^2+b^2}\) and ((a+b)/\sqrt2) then yields \(\|Qv\|^2\le2E_*\); the formula for (j=(r-s)(r+s)^{-1}) gives \(\|jv\|^2\le2E_*\). Hence both are at most (10\delta(v)). Since (p^2=(I+j)/2), (q^2=(I-j)/2), the same scalar functional calculus gives

\[
\|(p-I/\sqrt2)v\|^2,\ \|(q-I/\sqrt2)v\|^2\le5\delta(v).
\]

The per-letter form of the commutator estimate gives \(\|U_iv\|\le\sqrt{3/4}\sqrt{\delta(v)}\); combining the residual and weight estimates proves the stated action bounds with slack:

\[
\|T_iv-x_iv\|\le7\sqrt{\delta(v)},\qquad
\|jT_iv\|\le2\sqrt{\delta(v)}.
\]

The displayed constants (10,5,7,2) follow from the stated inequalities; I found no hidden conditioning factor. A point that is easy to misread in the (E_*) identity is that its sum is over (X,Y,Z); including an identity term would change the coefficients. The PDF's identity and subsequent estimates are consistent as printed.

## 3. Passage to arbitrary UCP maps

For arbitrary UCP compressions, fix local Stinespring isometries for the entire physical algebra and extend the positive marginal weights by

\[
W_\epsilon=J_HWJ_H^*+\epsilon(I-J_HJ_H^*),\qquad
V_\epsilon=J_KVJ_K^*+\epsilon(I-J_KJ_K^*).
\]

For every ε>0 the enlarged marginal weights are strictly positive, so the exact-representation proof applies. The embedded original tensor subspace reduces the commuting weight operators; (D_\epsilon), (p_\epsilon), and (q_\epsilon) restrict there to the original (D,p,q). Compressing each normalized letter back to this subspace gives the original UCP letter.

The only nontrivial limiting issue is that a Stinespring representation can send an original vector outside the embedded subspace. Such a transition is followed by the corresponding exterior weight: on a left-complement block, (p_\epsilon^2=\epsilon/(\epsilon+s)\le\epsilon/s_{\min}) when the right marginal is in its original block; on a right-complement block, (q_\epsilon^2=\epsilon/(r+\epsilon)\le\epsilon/r_{\min}). Thus off-subspace outputs are (O(\sqrt\epsilon)) for the fixed instance. Uniform boundedness of each letter and finite word length give convergence of every fixed word matrix element. The energies in Lemma 4.1 and Sections 4–6 involve only finitely many such words, so they converge too. The local isometries, the Bell projector, and the balance operator on the embedded subspace stay fixed.

This proves exactly the claimed UCP version: take ε down to zero *after fixing the instance*. It gives no uniform convergence rate as the original marginal's least eigenvalue varies, but all constants in the inequalities are independent of ε and of that condition number. Later, Section 5.4 passes a scalar score inequality to the limit; it does not need convergence of the smoothed POVMs or compactness across dimensions. I found no gap in this use of a pointwise limit.

## 4. Word and payload transport

With balanced anchors (K_i=(x_i+y_i)/2), Bell-vector reductions agree with the Pauli relations. For (i\ne j), the commutator and anticommutator estimates give \(\|T_iT_jv\|\le\sqrt{\delta(v)}\); for equal adjacent letters \(\|(T_i^2-I)v\|\le\sqrt{e_i(v)}\). Cancelling pairs from the right and using the one-letter action estimate for an odd final letter proves

\[
\|T_wv-K_wPv\|\le(\lfloor d/2\rfloor+\sqrt{10}+7\,1_{d\text{ odd}})\sqrt{\delta(v)},\qquad
\|jT_wv\|\le b_d\sqrt{\delta(v)},\quad b_d=\lfloor d/2\rfloor+\sqrt{10}+2.
\]

The payload comparison (Eq. (28)) moves the two outer balance weights onto the tested word vectors, replaces them by (1/\sqrt2), and applies word transport on both sides. Its constant is (C_d=\sqrt2 b_d+\lfloor d/2\rfloor+\sqrt{10}+7). The degree-four Hermitian extractors (P_g,Q_g) have norm and monomial coefficient absolute sum at most 9, and each monomial contains one raw payload occurrence. In the honest model they equal the actual local payload effects as operators. Applying Eq. (28) with (d=3), then removing the Bell projections at cost √10, gives Eq. (30), with (9C_3+\sqrt{10}<200):

\[
|\langle w,(P_g-a_g)v\rangle|\le200(\|w\|\sqrt{\delta(v)}+\|v\|\sqrt{\delta(w)}),
\]

and likewise for (Q_g-b_g). This is only a weak bilinear estimate. The next section is necessary to turn it into a vector-action estimate; no operator-norm closeness is claimed at this point.

## 5. Smoothing and action transport

For strictly positive exact-representation weights, Λ=(\log r-\log s), (G=e^{-\Lambda^2/2}), and

\[
M_0=\frac{P+\sum_{i=0,X,Y,Z}x_iGx_i}{5},\qquad x_0=I.
\]

This is a positive contraction and a convex average of product-local unitaries: (P=(I+\sum_{X,Y,Z}x_iy_i)/4), while the Gaussian Fourier representation of (G) averages (r^{it}\otimes s^{-it}). Conjugation by (x_i) preserves locality; independent products show (M_0^n=\mathbb E(U_\omega\otimes V_\omega)). This integral is an analytic proof device, not part of the symbolic reduction.

Since (j=\tanh(\Lambda/2)), the scalar bounds

\[
\tanh^2(t/2)\le1-e^{-t^2/2}\le8\tanh^2(t/2)
\]

give (E_0/5\le E_M\le8E_0/5), where (E_M(v)=\langle v,(I-M_0)v\rangle) and (E_0(v)=\|Qv\|^2+\sum_{i=0,X,Y,Z}\|jx_iv\|^2). From the anchor bounds, (E_0\le263\delta): the (Q) and (jv) terms cost (10+10), and each of the three Pauli terms obeys \(\|jx_iv\|\le\|jT_iv\|+\|T_iv-x_iv\|\le9\sqrt\delta\), for a further (243). Thus (E_M\le421\delta).

For the reverse comparison, set (h_i=\|jx_iv\|) for (i=X,Y,Z), (h_0=\|jv\|), and (b=\|Qv\|). The exact compression defect is (d_i=q x_i p v-py_iqv) and ∥d_i∥²=(e_i(v)). Replacing (p,q) by (1/\sqrt2) on the tested vector, using cross-party commutation and \(\|(x_i-y_i)v\|\le2b\), gives

\[
\|d_i\|,\ \|U_iv\|\le\sqrt2h_0+h_i+2b\le\sqrt{7E_0(v)}.
\]

The last step is Cauchy–Schwarz with squared coefficients (2+1+4=7), since all three quantities occur in (E_0). Equation (23) then gives each commutator at most (4\sqrt{7E_0}), while Σe_i≤21E0. Hence δ≤357E0≤1785EM, so the stated δ≤3000EM is valid. Functional calculus on (0\le M_0\le I) gives

\[
\delta(M_0^nw)\le\frac{3000}{2n+1}\|w\|^2,\qquad
\|v-M_0^nv\|^2\le nE_M(v).
\]

For each party, (a_g^{(n)}=\mathbb E U_\omega a_gU_\omega^*) and (b_g^{(n)}=\mathbb E V_\omega b_gV_\omega^*) remain local positive POVMs over the global label set. Dualizing Eq. (30) with (M_0^nw), then comparing (M_0^na_gv) with (a_g^{(n)}v), yields the four-term Eq. (37):

\[
\|P_gv-a_g^{(n)}v\|
\le\sqrt{421n\delta(P_gv)}+\sqrt{842n\delta(v)}
 +200\sqrt{\delta(v)}+200\sqrt{\frac{3000}{2n+1}}\|v\|,
\]

and the same for (Q_g,b_g^{(n)}). The comparison uses the exact average identity

\[
\mathbb E\|(U_\omega\otimes V_\omega)v-v\|^2
=2\langle v,(I-M_0^n)v\rangle\le2nE_M(v).
\]

For a unit root (z), let (E(z)=\delta(z)+\sum_g\delta(P_gz)+\sum_g\delta(Q_gz)). Each action error is bounded, without a small-energy premise, by

\[
\kappa_n=C_s(\sqrt n\sqrt{E(z)}+n^{-1/2}),\qquad C_s=12000.
\]

The numerical constant covers each of the four terms in Eq. (37) for every integer (n\ge1).

## 6. Question normalization and Proposition 6.1

For a fixed question, the smoothed global effects (a_g^{(n)}) need not already sum to (I/M). Define (C_x=\sum_a M a_{x,a}^{(n)}\le MI) and likewise (D_y\le MI). The stacked square-root column (C=(\sqrt{E_a})_a) obeys (C^*C=Q\le MI). Its polar partial isometry extends to an isometry (N) by assigning \(\ker Q\) to one outcome block; every \(\sqrt{E_a}\) annihilates that kernel because (E_a\le Q). Then

\[
C=N\sqrt Q,\qquad \|(C-N)z\|=\|(\sqrt Q-I)z\|\le\|(Q-I)z\|.
\]

This construction remains valid when (Q) is singular and creates a genuine POVM. It does not require the individual scaled positive effects to have norm at most one; only (Q\le MI) and (E_a\le Q) are used. For a joint question pair, compare columns in the order (C_x\otimes(D_y-M_y)+(C_x-N_x)\otimes M_y); this gives \(\sqrt M\,\upsilon_y+\tau_x\). Since the two joint columns have norms at most (M) and 1 and the payoff is a contraction, the expectation changes by at most ((M+1)(\sqrt M\upsilon_y+\tau_x)). Averaging and Cauchy–Schwarz give Eq. (40), (C_3=(M+1)^2).

With \(\|P_g\|,\|Q_h\|\le9\), the action bounds imply

\[
|\langle P_gz,Q_hz\rangle-\langle a_g^{(n)}z,b_h^{(n)}z\rangle|\le10\kappa_n.
\]

There are (K^2) outcome pairs and the game score has the (M^2) rescaling, so its unnormalized score error is at most (10M^2K^2\kappa_n). Minkowski gives \(\sqrt{H_n}\le\sqrt{H(z)}+\sqrt2MK\kappa_n\le\sqrt{H(z)}+2MK\kappa_n\). The completed normalized local strategy has score at most ω*(G), which proves Eq. (43):

\[
\langle z,Bz\rangle\le\omega^*(G)+C_1C_s\sqrt n\sqrt{E(z)}
 +\frac{C_1C_s}{\sqrt n}+C_3\sqrt{H(z)},
\]

where (C_1=10M^2K^2+2C_3MK). This is the key all-strategies soundness inequality; it applies to every vector and every instance of the actual normalized domain after the pointwise UCP limit.

For (s_0=\max\{1,\lceil4C_1C_s/\gamma\rceil\}), (n=s_0^2), (C_2=C_1C_ss_0), and

\[
\lambda_E=\left\lceil\frac{2C_2^2}{\gamma}\right\rceil,\qquad
\lambda_H=\left\lceil\frac{2C_3^2}{\gamma}\right\rceil,
\]

the polynomial (F=rI-B+\lambda_EE_{op}+\lambda_HH_{op}) has degree at most 12. If ω*(G)≤r−γ, Eq. (43) gives the lower bound (3\gamma/4-C_2\sqrt E-C_3\sqrt H+\lambda_EE+\lambda_HH\); completing the two scalar squares costs at most γ/8 each, leaving (F\ge(\gamma/2)I). If ω*(G)>r+γ/2, a finite strategy exists by the definition of supremum; in its honest Bell realization (E=H=0), and (\langle F\rangle< -\gamma/2). Mixing each Choi baseline with ((I_h/h)\otimes I) preserves its identity marginal and scales every centered physical Pauli/payload letter to ((1-\epsilon)T_0), because all such physical letters are traceless. For (F=\sum_wc_wT_w), the telescoping estimate (\|F(T_\epsilon)-F(T_0)\|\le\epsilon\sum_w|w||c_w|\) preserves strict negativity for an explicit rational ε. This proves the faithful-witness clause without requiring a faithful exact-zero anchor.

The only formal effective-input caveat found is that the proposition explicitly calls (r) rational but writes only “γ>0”. Its ceiling definitions and rational output require an effective γ. Stating γ rational (as in the fixed rational MIP* promise gap) resolves this; it does not affect the displayed inequalities or the reduction with a fixed gap.

## 7. Relation to primary self-testing and rounding literature

These sections use a rigidity-and-rounding mechanism related in spirit to self-testing, but the source of rigidity differs. Robust self-testing starts with observed correlations near a designated Bell-game optimum and deduces that the unknown state and measurements approximate a target up to local isometries; the singlet framework and later Pauli self-tests are representative [McKague–Yang–Scarani (2012)](https://arxiv.org/abs/1203.2976), [Bowles–Šupić–Cavalcanti–Acín (2018)](https://arxiv.org/abs/1801.10446). Natarajan–Vidick's many-qubit test likewise certifies Pauli (X/Z) structure and EPR pairs from a near-optimal game score [Natarajan–Vidick (2016)](https://arxiv.org/abs/1610.03574).

Here the anchor is not inferred from a near-optimal Bell score. It is an explicit vector-energy estimate for every pair of UCP compressions of a fixed physical Pauli-plus-payload algebra, with defects δ measuring contraction and commutation failures of the normalized Choi letters. The proof inserts an exact opposite Pauli factor in the physical effect algebra, obtains the Bell-sector estimate by the inverse-root balance identity, and then transports payload actions. The game is used only after that anchor exists, to round the extracted local effects and compare their score with ω*(G).

The closest rounding analogy is Paddock's conversion of near-optimal strategies for BCS, XOR, and synchronous games into approximate representations and then into strategies using maximally entangled states [Paddock, *Rounding near-optimal quantum strategies for nonlocal games to strategies using maximally entangled states*](https://arxiv.org/abs/2203.02525). That work establishes robust representation-theoretic stability in specified game-algebra classes and normalized Hilbert–Schmidt distances. Sections 3–6 instead use state-vector energy, a bespoke local-unitary average (M_0^n) to upgrade weak matrix-element transport to action transport, and a polar completion that handles singular per-question totals. The result is an inequality for arbitrary actual-domain points, not a theorem that an arbitrary near-optimal strategy is close to a maximally entangled strategy. This is a mechanism comparison, not a priority claim.

## 8. Exact status and limits

- **Verified:** equations (15), (25), (31), (33)–(43), including fractions, averaging indices, and stated constants; exact full-algebra Stinespring hypotheses; Lemma 4.1's three-Pauli decomposition; singular-safe question normalization; low-value gap and faithful negative-witness perturbation.
- **No counterexample found:** the tested inverse-root identity respects noncommuting same-side weights; smoothing uses local unitaries; action errors are state dependent and are charged through the explicit descendant energy (E(z)); score rounding handles question normalization explicitly.
- **Scope:** the UCP limiting argument is per fixed finite instance and only for finitely many words at a time. It makes no uniform convergence-rate claim across dimensions or ill-conditioned marginals. That limitation does not enter Eq. (43), whose constants are uniform after taking the limit.
- **Small formal clarification:** make γ an effective rational input whenever “effectively construct” is meant literally. The fixed rational gap needed in the reduction already has this property.

This is a focused reconstruction and adversarial audit of Sections 3–6, not formal proof certification, external expert review, or validation of the separate hardness premise.
