# Free positivity, matrix convexity, and the two-factor Jordan domain

## Decision

The standard free Positivstellensatz literature would give a computable finite matrix-size witness bound for a polynomial or rational function that is positive on a standard free spectrahedron (and, in the polynomial case, on a free spectrahedrop). This is strong enough that an exact effective reduction of the manuscript's SLD dominance test to that setting would contradict its claimed no-computable-reference-cutoff theorem.

That reduction has not been made, and the domain in Sections 3 and 7–10 is outside the standard hypotheses as currently written. Its points are built from two independently sized reference systems and the normalized tensor-Jordan expression

\[
Z_A=D^{-1/2}\big(A_A(R)\otimes I_m+I_n\otimes A_A(S)^T\big)D^{-1/2},\qquad
D=W\otimes I_m+I_n\otimes V^T.
\]

The output acts on \(\mathbb C^n\otimes\mathbb C^m\); it is not an evaluation of one ordinary free rational expression at a tuple of matrices of one common size. The square-root normalization, partial traces, transpose/opposite action, and tensor-factorization constraints are part of the domain. Section 7 compiles the polynomial into inverse-Jordan kernels, but those kernels still have the structured two-reference input \((R,S)\). The manuscript does not identify that set with a free spectrahedron, free spectrahedrop, or another domain covered by the cited theorems.

Thus the theorem-level answer is: **a standard free-rational encoding with computable witness transfer cannot exist while preserving the manuscript's claimed classification; the two-factor normalized Jordan domain evades the available one-level bounds.** This is an applicability conclusion, not a proof that no richer, explicitly structured two-level rational formalism could ever be developed.

## What the source manuscript actually proves

Section 3 defines a common tuple \(Z_A(R,S)\) from two baselines \(R>0\) and \(S>0\), with different reference dimensions \(n,m\). The entries share the same denominator \(D\), and their local terms act on opposite tensor factors. Section 3.2 represents honest finite tensor-product game strategies in the positive-semidefinite closure of this domain. Sections 4–6 establish a gapped polynomial on this actual domain; the text explicitly says it does not enlarge to arbitrary unrelated contraction tuples. Section 7 turns ordered words into inverse-Jordan kernels by a suffix-graph construction. Sections 8–9 realize those kernels as strictly positive POVMs and prove a global comparison over every state and tangent. Section 10 then claims coRE-completeness and no computable sufficient reference cutoff.

For any *fixed* reference dimension, Section 10.2 gives a first-order real-algebraic test, hence quantifier elimination decides whether a violation exists at that size. The obstruction is uniformity over unbounded reference sizes. This per-size real-algebraic formula should not be conflated with a free rational function: it is a family of formulas whose numbers of scalar variables grow with the reference dimension.

## The strongest directly relevant free theorems

1. **Helton–McCullough, strict free Positivstellensatz.** In “A Positivstellensatz for Non-Commutative Polynomials,” *Transactions of the AMS* 356 (2004), Theorem 1.2, a symmetric matrix polynomial strictly positive on a bounded operator positivity domain \(D_P\) has a weighted sum-of-squares certificate. If \(D_P\) is also convex, positivity need only be checked on matrices of dimension at most
   \[
   \ell\sum_{k=0}^{d}(2g)^k,
   \]
   for polynomial degree \(d\), \(g\) free variables, and output matrix size \(\ell\). The theorem's domain is defined by noncommutative polynomial inequalities and its convexity is essential to the finite-size conclusion. The base Positivstellensatz quantifies over bounded operators, a stronger condition than positivity only on finite-dimensional tensor-product strategies.

   Primary source: [author-hosted paper PDF](https://www.math.ucsd.edu/~helton/osiris/NONCOMMINEQ/PosSS.pdf), Theorem 1.2 and Proposition 2.3.

2. **Helton–Klep–McCullough, exact free convex Positivstellensatz.** For a monic linear pencil \(L\), let \(D_L\) be the free spectrahedron consisting of all same-level self-adjoint matrix tuples satisfying \(L(X)\succeq0\). Their Theorem 1.1 says a matrix nc polynomial \(p\) is positive semidefinite on all levels of \(D_L\) iff it has a weighted SOS certificate with degree at most half the degree of \(p\). Remark 1.2 gives a computable test-rank bound: for degree \(k\) and output size \(\nu\), it is at most
   \[
   \nu\sum_{j=0}^{\lceil k/2\rceil}g^j.
   \]
   This is a genuine finite matrix-size bound for standard one-level free positivity.

   Primary source: [arXiv:1102.4859](https://arxiv.org/abs/1102.4859), Theorem 1.1 and Remark 1.2; journal version, *Advances in Mathematics* 231 (2012), 516–534.

3. **Helton–Klep–McCullough, free spectrahedrops.** A free spectrahedrop is a same-level projection of an LMI domain: \(X\) belongs at level \(n\) when there exists an auxiliary tuple \(Y\) of the *same* matrix size \(n\) with \(L(X,Y)\succeq0\). Theorem 5.1 in “The tracial Hahn–Banach theorem, polar duals, matrix convex sets, and projections of free spectrahedra,” *JEMS* 19 (2017), says a symmetric polynomial of degree at most \(2r+1\) is positive on that projection iff it lies in a finite truncated quadratic module, with auxiliary polynomial degree at most \(r\). So replacing “spectrahedron” with an ordinary same-level semidefinite lift does not by itself escape the finite-certificate route.

   Primary source: [JEMS article PDF](https://ems.press/content/serial-article-files/32218?nt=1), definition (1.4), Theorem 5.1; [arXiv:1407.8198](https://arxiv.org/abs/1407.8198).

4. **Volčič, rational free Positivstellensatz and an explicit witness size.** In “Hilbert’s 17th problem in free skew fields,” *Forum of Mathematics, Sigma* 9 (2021), Theorem 5.2 gives a rational convex Positivstellensatz: for a Hermitian monic pencil \(L\), an nc rational function \(r\) is PSD on \(\operatorname{hdom}(r)\cap D(L)\) iff it lies in the rational quadratic module generated by \(L\). More pointedly for the present question, Remark 5.3 gives an explicit level \(n\) witnessing failure:
   \[
   n=2\big(e^3m^2+em(2e\ell-1)+\ell(e\ell-2)\big),
   \]
   where \(e\) is the size of a linear representation of the rational expression, \(\ell=\dim V_{2\tau(r)-1}\), and \(m=\dim V_{2\tau(r)}-\dim V_{2\tau(r)-1}\). These are finite syntactic/algebraic quantities determined by a concrete free rational expression. If the manuscript's complete comparison were such an \(r\) on such a \(D(L)\), with a computable transfer from matrix level to reference dimension, this would supply exactly the kind of cutoff its Theorem 1.2(3) rules out.

   Primary source: [Cambridge article](https://www.cambridge.org/core/journals/forum-of-mathematics-sigma/article/hilberts-17th-problem-in-free-skew-fields/1DC74DC3E0E011210C826FF4DCA24DE1), Theorem 5.2 and Remark 5.3; [arXiv:2101.02314](https://arxiv.org/abs/2101.02314).

## Why the hypotheses do not match Sections 3 and 7–10

**One free level versus two local sizes.** In the standard free setup, the input is a tuple \(X\in M_n^g\), all coordinates have the same level \(n\), and a free rational expression is built from constants, variables, addition, multiplication, and inverses. Its matrix value has size proportional to \(n\) for fixed expression size. Section 3 instead starts with \(R\) on \(\mathbb C^h\otimes\mathbb C^n\) and \(S\) on \(\mathbb C^h\otimes\mathbb C^m\), independently; it then forms matrices on the product reference of dimension \(nm\). The levels and their factorization carry semantic content.

**The normalization is not a free rational operation.** The displayed \(Z_A\) uses \(D^{-1/2}\), partial-trace block maps, a transpose, and Kronecker sums. Ordinary free rational expressions allow matrix inverses, not square roots, partial-trace maps between different levels, or a Kronecker product of two independently sized variables. Clearing scalar denominators is not enough here because the operator factors need not commute. Section 7's exact graph compiler avoids square roots by using \(B_A^{-1}\), \((D-B_A)^{-1}\), and \(D^{-1}\), but its positivity claim remains on the paired \((R,S)\) tensor domain.

**The global Fisher comparison acts on an operator space.** For an output block \(Q_i\), the SLD inverse is the inverse of the Sylvester operator \(X\mapsto Q_iX+XQ_i\). Under vectorization this is a Kronecker sum involving left multiplication and right multiplication by \(Q_i^T\), acting on a space of dimension \(n^2\). The comparison for all tangents is a PSD test on this enlarged space. Expressing its entries rationally at each fixed size does not make it a usual free rational matrix evaluation at level \(n\), nor does it supply a finite common-level LMI domain.

**Matrix convex lifts quantify over same-level tuples.** A free spectrahedrop allows auxiliary matrices \(Y\) with the same size as \(X\), and yields a matrix-convex family (closed under direct sums and compressions). Sections 3 and 7 preserve the actual tensor-factor structure. The manuscript gives no proof that the two-factor normalized Jordan family has those closure properties or a same-level LMI lift. Replacing it by the full matrix convex hull or by all unrelated contractions changes the quantified set; the Section 3 construction explicitly warns against that enlargement.

**The older operator theorem has a different quantifier.** Helton–McCullough's bounded-domain theorem assumes positivity on every bounded operator tuple in its domain. The game premise in the manuscript concerns finite-dimensional tensor-product strategies with no uniform dimension bound. Positivity on that finite-dimensional tensor family does not establish positivity on arbitrary infinite-dimensional operator representations, so the 2004 theorem cannot be invoked by simply calling the variables operators.

## Contradiction test

The hypothetical argument would have to provide, uniformly from the rational POVM pair (or its game), (i) one standard free rational expression \(r\), (ii) one effectively described monic pencil \(L\) or a same-level free spectrahedrop lift, (iii) equivalence between channel dominance and \(r\succeq0\) on the entire corresponding free domain, and (iv) an effective map from the free matrix level of a negative witness back to a valid SLD reference dimension. Given those four items, Volčič's Remark 5.3 (or the polynomial test-rank results above) gives a computable reference cutoff and contradicts the claimed cutoff obstruction. Therefore at least one item cannot hold. Inspection of the manuscript identifies the missing step as (i)–(iii): the construction is for a structured two-factor domain, not a standard one-level free rational/LMI domain. There is no contradiction with the classical theorems.

An exact finite SDP representation of the relevant tensor-strategy domain, with computable coefficients and a uniform conversion to the game value, would likewise make the constant-gap game promise decidable. Ji–Natarajan–Vidick–Wright–Yuen's Theorem 12.10 gives a computable game with value 1 if a machine halts and at most 1/2 otherwise; Corollary 12.13 states \(\mathrm{MIP}^*=\mathrm{RE}\). Thus no such effective exact representation can preserve all of those values. Infinite convergent SDP hierarchies are compatible with this: undecidability rules out a computable uniform stopping level, not finite outer bounds at each chosen level.

Primary source: [Ji et al., “MIP* = RE” PDF](https://www.cs.cmu.edu/~cdm/projects/MIPSRE.pdf), Theorem 12.10 and Corollary 12.13.

## Bottom line for the manuscript review

Do not claim that free rational positivity proves a reference cutoff, or that it refutes the manuscript. Do state the useful conditional clearly: **if** the global comparison can be represented as standard free rational positivity on a computably specified free spectrahedron/spectrahedrop with witness-size transfer, the published test-rank bounds contradict the manuscript's theorem. The present Sections 3, 7–10 do not supply that representation; their independent tensor factors, transpose/right-action, square-root normalization, and \(n\times m\) level structure are exactly where the classical theorem hypotheses stop applying.
