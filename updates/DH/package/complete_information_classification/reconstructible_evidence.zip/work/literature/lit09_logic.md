# Logic and computable-analysis consequences around channel-order undecidability

## Finding

The manuscript’s no-computable-reference-cutoff claim has a clean, exact computability-theoretic strengthening: the least-reference-dimension search defines a computable binary sequence for each rational POVM pair, whose limit is the failure predicate, but this sequence has no computable uniform convergence modulus. Its worst-case stabilization envelope over descriptions of length at most $n$ is lower semicomputable, has no computable eventual upper bound, and exceeds every total computable function infinitely often. This is a precise Busy Beaver style statement, but it is weaker than the usual busy-beaver theorem that eventually dominates every computable function. The manuscript’s proof gives no lower bound relating a halting machine’s runtime to its least violating reference dimension.

The main external ingredient is inherited from MIP*=RE: the gap promise for entangled game value is RE-hard and the game value itself is uniformly lower semicomputable, so no fixed-precision algorithm or computable convergence rate can approximate it uniformly. Transferring that hardness to rational strictly positive POVMs, complete SLD order, and unrestricted complete Umegaki order requires the manuscript’s own reductions. The asserted equivalence between complete relative-entropy order and complete SLD order is stronger than the nearby published channel-order hierarchy, which gives measured-χ²/SLD order ⇒ quantum-χ²/BKM order ⇔ relative-entropy order, but does not state the reverse implication.

Busy-beaver-scale finite-size growth is already explicit in quantum many-body work: Bausch et al. prove a size-driven phase-transition threshold $N_{q+4}\ge S(q)/\sqrt 2$ for a family built from a $q$-state Busy Beaver machine. That result is a separate computational embedding. It does not transfer to channel reference dimensions without an additional quantitative lower-bound lemma.

I interpret “Dots’ reference-dimension obstruction” as Theorem 1.2(3) and §10.2 of `channel_order_undecidability.txt`; I found no separate Dots-named result in this workspace. This is a literature and consequence audit, not an independent proof-check of the manuscript’s long channel-construction lemmas.

## What follows from MIP*=RE

Ji–Natarajan–Vidick–Wright–Yuen construct, effectively from a Turing machine $M$, a finite two-player game $G_M$ with rational description such that

\[
M\text{ halts}\Rightarrow \omega^*(G_M)=1,
\qquad
M\text{ does not halt}\Rightarrow \omega^*(G_M)\le \tfrac12.
\]

This is an RE-complete gap promise, not merely an undecidability statement. The paper also explains that ω* is uniformly approximable from below by enumerating finite-dimensional strategies. Consequently, a uniform additive approximation to ω* at any error strictly below $1/4$ would decide halting by thresholding the answer. Equivalently, the canonical lower approximations to ω* have no computable uniform over input descriptions convergence modulus at a fixed error below the promise gap. These are inherited consequences; a new application does not become a new theorem merely by replacing the game-value name with another function unless the transfer is proved.

The MIP* paper also proves a quantitatively strong compression statement. In its informal Theorem 1.1 discussion / compression theorem, if the source game at index $2^n$ has value at most $1/2$, then the compressed game requires local entangled dimension at least $2^{2^{\Omega(n)}}$ to reach score $1/2$, as well as at least the dimension required by the source game. The halting construction uses this on bounded prefixes that have not yet halted. Thus the cited dimension lower bound is on a low-value, bounded-nonhalting branch. In the channel manuscript’s reduction, failure of dominance comes from a high-value strategy in the halting branch. The MIP* lower bound therefore does not give a lower bound on the least reference dimension witnessing channel-order failure.

The primary MIP* source also refutes Tsirelson’s problem and, through known equivalences, Connes embedding. A separate Gödelian strengthening by Goldbring–Hart proves that for any consistent recursively axiomatizable extension $T$ of the theory of II₁ factors, there is a II₁ factor satisfying $T$ that does not embed into an ultrapower of the hyperfinite II₁ factor. Their paper proves noncomputability of the universal theory of that factor. These are operator-algebraic logical consequences, not consequences about channel reference dimensions.

## What is new in the channel manuscript if its proofs validate

The inherited MIP* theorem does not itself imply any undecidability for channel comparisons. The manuscript must validate a computable, promise-preserving route from the game gap to a rational pair of strictly positive measurement channels, and then prove that its high and low game branches transfer to opposite sides of complete SLD order. Its sections 3–9 contain the target-specific mechanisms: realization on the actual two-factor normalized Jordan domain, anchor/smoothing estimates, ordered-word to inverse-Jordan compilation, positive-effect implementation, and global POVM completion. The complexity classification for this restricted input class depends on those lemmas.

The manuscript’s channel-order bridge is also a substantive point. Its Theorem 1.2(2) says, for arbitrary finite-dimensional channels,

\[
P\succeq_c^{\mathrm{SLD}}Q
\quad\Longleftrightarrow\quad
P\succeq_c^{\mathrm{RE}}Q,
\]

where the RE comparison quantifies over arbitrary finite untouched references and all state pairs, including unequal reference marginals. The nearby result in Hirche’s October 2026 preprint, Theorem “Hierarchy of channel orders,” states complete measured-χ² ordering ⇒ complete quantum-χ² ordering, and complete quantum-χ² ⇔ complete relative entropy ⇔ complete less-noisy. SLD Fisher information is the measured-χ² quantity in this hierarchy. That source does not state RE ⇒ measured-χ². The manuscript’s saturated-reference construction is intended to close precisely this converse; it should be described as a new bridge if correct, not as a routine corollary of the known order equivalences.

The fixed-additive-error theorem for the bounded entropy defect

\[
V(E,F)=\sup_{R,\rho,\sigma}\bigl[D(F_R(\rho)\Vert F_R(\sigma))-D(E_R(\rho)\Vert E_R(\sigma))\bigr]
\]

is stronger than qualitative order undecidability. The manuscript needs its computable, dimension-independent positive witness margin and finite tensor amplification to reach error $1/4$. The MIP* promise alone only gives fixed error hardness for game value; it does not automatically give this statement for $V$. The contraction-coefficient/partial-order literature (Hirche–Rouzé–Stilck França, 2022) supplies context on channel orders, tensorization, and approximate orders, but not this reduction or this defect theorem.

## Exact convergence theorem available from the cutoff proof

Fix an effective binary encoding of finite rational complex strictly positive POVM pairs. For an encoded pair $e=(E,F)$, let

\[
d(e)=\min\{r\ge1:\text{there are a faithful input }\rho\text{ and Hermitian tangent }H
\text{ on input}\otimes\mathbb C^r\text{ with a strict SLD violation}\},
\]

and set $d(e)=\infty$ if no such witness exists. Define

\[
a_s(e)=\begin{cases}
1,&\text{if a strict violation exists with reference dimension at most }s,\\
0,&\text{otherwise.}
\end{cases}
\]

For each fixed $s$, $a_s(e)$ is decidable. Encode complex variables by real and imaginary coordinates, impose Hermiticity, trace, positive definiteness, and the rational Sylvester equations for the SLD scores, and express the Fisher-sign test polynomially. Feasibility is then a first-order real-algebraic decision problem, so real quantifier elimination decides it. The sequence $s\mapsto a_s(e)$ is computable and nondecreasing, and its limit is exactly the characteristic function of failure of complete SLD dominance.

There is no total computable modulus $m(e)$ such that $a_s(e)$ has reached its limit by $s=m(e)$. If there were, compute $a_{m(e)}(e)$; this decides the RE-complete failure set and its coRE-complete complement. This is the precise noncomputable-convergence statement latent in §10.2. The claim is uniform over input descriptions; it does not say an individual pair’s pointwise sequence fails to converge.

One can state a worst-case envelope. For fixed coding let

\[
B_{\rm ref}(n)=\max\{d(e): |e|\le n,\ d(e)<\infty\},
\]

with maximum $0$ for the empty set. This is a finite, well-defined, nondecreasing integer function. It has a computable monotone approximation from below: run the fixed-dimension QE tests for each of the finitely many codes of length at most $n$, increasing the current maximum whenever a least witness dimension is found. It has no total computable eventual upper bound. Indeed, if some computable $g$ bounded $B_{\rm ref}(n)$ for all $n\ge n_0$, the finite prefix could be absorbed in a fixed integer constant $C$, making $g(n)+C$ a computable global bound. Then $b(e)=g(|e|)+C$ would be a computable sufficient reference cutoff, contradicting §10.2. Hence for every total computable $g$, $B_{\rm ref}(n)>g(n)$ for infinitely many $n$: otherwise it would be eventually bounded by $g$.

This is an exact “Busy Beaver style” worst-case witness-growth result derived from the reference obstruction. It is encoding-dependent and gives infinitely-often exceedance, not eventual domination and not an explicit numerical lower bound. Calling it a Busy Beaver lower bound without those qualifications would overstate it.

The same idea yields a bounded-entropy convergence corollary if the manuscript’s §11–14 claims are accepted. Since faithful rational state pairs are dense at every fixed reference and their output relative entropies are computable reals for strictly positive rational POVMs, enumerate them and approximate their defects from below. This gives a uniform lower-computable sequence converging to $V(E,F)$. Theorem 14.2’s impossibility of a total $1/4$-approximation algorithm therefore rules out a computable convergence modulus uniform over input descriptions at error $1/4$. The additional mathematical content of §12–14 is what proves the fixed-error obstruction for $V$, rather than the generic no-modulus reformulation.

## Why the manuscript does not yet yield a runtime-to-dimension Busy Beaver bound

The cutoff contradiction proves only that no computable function of a pair description bounds its least violating reference. It does not establish an inequality such as

\[
d(\Phi(M))\ge f(T_M),
\]

where $T_M$ is the halting time of $M$, or $d(\Phi(M))\ge S(n)$ for a Busy Beaver champion. The MIP* compression lower bound located above applies to games whose finite-dimensional value is low because the machine has not halted by a bounded time; the channel map’s violating witness uses the opposite, high-value branch. The manuscript does not prove that every channel violation decodes to a game strategy with a dimension lower bound, nor does it compare that dimension to a runtime or to the MIP* compression parameter. A quantitative transfer theorem of that form is the missing gate.

There is a trivial way to manufacture a Busy-Beaver search-time statement: write a wrapper that simulates a source machine before computing the channel pair and searching for a violating reference. Its runtime is at least the source halting time by construction. This is not an intrinsic channel-order result and should not be presented as one. The meaningful theorem already available is the noncomputable uniform convergence modulus and $B_{\rm ref}$ envelope above.

## Predecessors and separation of mechanisms

* **MIP*=RE:** Ji et al., [arXiv:2001.04383](https://arxiv.org/abs/2001.04383), especially Theorem 1.1 and the introduction’s compression theorem. Provides RE-complete game-value gap, lower semicomputability, Connes/Tsirelson consequences, and the bounded-prefix entanglement lower bound.
* **Spectral gap:** Cubitt, Pérez-García, and Wolf, [arXiv:1502.04573](https://arxiv.org/abs/1502.04573), full version and main theorem. Gives an undecidable, strongly promised gapped/gapless property for translationally invariant nearest-neighbour 2D Hamiltonians with a fixed finite local dimension. The paper also states an axiomatically independent instance for every consistent recursive formal system at a sufficiently large fixed $d$. This is a separate Hamiltonian computation encoding; it is not a corollary of MIP*=RE.
* **Busy-beaver finite-size threshold:** Bausch et al., [arXiv:1512.05687](https://arxiv.org/abs/1512.05687), §“Busy Beaver,” prove a transition threshold at least $S(q)/\sqrt2$ for local dimension $q+4$ in their explicit phase-transition construction; for $d>6$, they give a family whose threshold grows faster than any computable function. This is direct prior art for noncomputable finite-size/convergence scales in quantum systems.
* **MIP* and incompleteness:** Goldbring–Hart, [arXiv:2006.05629](https://arxiv.org/abs/2006.05629), prove the universal theory of the hyperfinite II₁ factor is not computable and derive a Gödelian refutation of CEP: every consistent recursively axiomatizable extension $T$ of II₁-factor theory has a model not embeddable into $\mathcal R^\omega$. Their dimension-density obstruction for finite matrix models is a close methodological predecessor to “no computable cutoff,” though it concerns approximation of tracial polynomial ranges, not ancillary reference dimensions for channel order.
* **Existing channel-order hierarchy:** Hirche, Rouzé, and Stilck França, [arXiv:2011.05949](https://arxiv.org/abs/2011.05949), develop channel partial orders and approximate-order/tensorization frameworks. Hirche, [arXiv:2610.03706](https://arxiv.org/abs/2610.03706), Theorem “Hierarchy of channel orders,” states complete measured-χ² ⇒ complete quantum-χ² ⇔ complete relative-entropy ⇔ complete less-noisy. The reverse from RE to measured-χ²/SLD is not in that theorem.
* **Thermalization:** Shiraishi–Matsumoto, [arXiv:2012.13889](https://arxiv.org/abs/2012.13889) and long companion [arXiv:2012.13890](https://arxiv.org/abs/2012.13890), give undecidability of relaxation/thermalization for one-dimensional shift-invariant nearest-neighbour dynamics with a fixed product initial state. This is further prior art for asymptotic observables and noncomputability, but their quantity/order of limits differs from the reference cutoff in this manuscript.

## Suggested manuscript positioning

1. Attribute the game-value gap, its lower semicomputability, generic fixed-error nonapproximation, and the compression dimension bound to MIP*=RE.
2. Present the rational-POVM channel reduction, the complete-RE/SLD converse, the no-reference-cutoff theorem, and the bounded $V$ fixed-error result as the manuscript’s separate claims; do not infer them from MIP* without the construction lemmas.
3. State the exact convergence corollary above if desired. Describe $B_{\rm ref}$ as a lower-computable worst-case envelope with no computable eventual majorant, exceeded infinitely often by every computable function. Do not claim standard busy-beaver eventual domination or a lower bound in the halting runtime unless a quantitative witness-size transfer is proved.
4. Cite Bausch et al. as direct precedent for Busy Beaver controlled finite-size scales, and Goldbring–Hart as precedent for no computable finite-dimensional approximation/density moduli. These limit broad novelty language while leaving the channel-specific theorem potentially new.

