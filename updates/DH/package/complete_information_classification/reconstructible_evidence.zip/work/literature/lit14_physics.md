# Lit14 — finite quantum-information observable versus thermodynamic Hamiltonian targets

## Finding

The strongest defensible physical endpoint in `channel_order_undecidability.txt` is already a finite-device problem: deciding whether one finite rational POVM is at least as informative as another in **every** finite ancilla-assisted experiment. The note's complete SLD order is the universal comparison of local quantum Fisher information (QFI); its complete relative-entropy order compares all finite-pair distinguishability tests. Its bounded defect `$V(E,F)$` is a dimensionless operational quantity, and the note claims it cannot be approximated on all rational strictly positive POVM pairs even to additive error $1/4$ (§§11–14). This is a legitimate quantum metrology and detector certification problem without a Hamiltonian bridge.

I found no theorem that transfers the note's positivity problem to spectral-gap undecidability, an uncomputable thermodynamic phase diagram, or a Hamiltonian-identification inverse problem. The obstruction is structural: the note's “spatial” tensor product is a bipartite product constraint on two reference factors, not geometric locality on a lattice; its positive kernels depend on shared, variable positive baselines. The established spectral-gap results instead require a uniform map to fixed-local-dimension, nearest-neighbour lattice interactions and a thermodynamic-limit promise. Hamiltonian universality preserves the physics of a supplied target Hamiltonian; it does not furnish the missing map from this constrained matrix domain to a local Hamiltonian family.

The immediate research direction is therefore either (a) finish independent proof/priority validation of the finite POVM theorem and frame it as universal detector ordering, or (b) prove a new locality-preserving compiler. Calling the existing construction a consequence of spectral-gap or phase-diagram undecidability would skip that compiler.

## What the finite observable says

For a faithful input model `ρ(t)=ρ+tH+O(t²)`, with Hermitian tangent `H=H*` and `Tr(H)=0`, and any finite untouched reference `R`, measurement `E=(E_i)` produces the block state

\[
  E_R(\rho(t))=\bigoplus_i \operatorname{Tr}_{A}[(E_i\otimes I_R)\rho(t)].
\]

Its local QFI is the sum of the block SLD quadratic forms,

\[
  F_Q(E_R(\rho(t)))\big|_{t=0}
  =\sum_i g_{\rho_i}(\dot\rho_i),\qquad
  g_W(X)=\langle X,\Omega_W^{-1}(X)\rangle,
  \quad \Omega_W(X)=\tfrac12(WX+XW).
\]

Thus `$E\succeq_{c\mathrm{SLD}}F$` means exactly that `E` never loses local parameter information relative to `F`, for any finite reference, faithful state, or tangent. This is a strong guarantee for comparing two detectors. The tangent `H` need not come from a unitary Hamiltonian parameter, so this is a quantum statistical order rather than a theorem about learning an unknown generator.

The note additionally defines

\[
 V(E,F)=\sup_{R,\rho,\sigma}\{D(F_R(\rho)\Vert F_R(\sigma))-D(E_R(\rho)\Vert E_R(\sigma))\},
\]

over finite references and faithful states. Its §11 proves a finite upper bound for strictly positive effects; `$V(E,F)=0$` precisely when `E` dominates `F` in the stated complete entropy order, and `$V(E,F)>0$` when that order fails. The claimed §14 reduction supplies a game-computable positive witness margin on the failure side, then tensorizes to rule out every total additive-$1/4$ approximation algorithm. So the strongest physical reading is a **worst-case distinguishability advantage** for competing finite devices. It is not the outcome of one experiment and does quantify over unbounded finite ancillas, but each strict failure has a finite witness.

The bridge from the note's Jordan/resolvent algebra to this observable is explicit in the note itself: actual POVM blocks lead to Ω-inverse Fisher costs; the edge recurrence compiler preserves ordered words on the shared-baseline domain; rational signed residues are implemented by positive signal effects; and the global padding/resolvent estimate controls all states and tangents (§§7–9). That is a complete *claimed* transfer to finite quantum measurement physics. I have not independently re-proved those internal lemmas; existing `lit08_algebras.md` records the proof-audit boundary and relevant channel-order prior art.

## What the normalized two-factor domain is, and why it is not a lattice

For each physical effect `A`, the note fixes the same two positive baselines `R ∈ M_h ⊗ M_n` and `S ∈ M_h ⊗ M_m` and defines

\[
 A_A(R)=\operatorname{Tr}_{h}[(A\otimes I_n)R],\qquad
 B_A(R,S)=A_A(R)\otimes I_m+I_n\otimes A_A(S)^T,
 \qquad Z_A=D^{-1/2}B_AD^{-1/2},\quad D=B_I.
\]

For `αI ≤ A ≤ (1−α)I`, the tuple satisfies `αI ≤ Z_A ≤ (1−α)I`. All letters share `R,S,D`, with the same tensor-vectorization and transposition convention. The note's Pauli/Choi representation (Eq. 18) gives left and right local UCP maps and opposite Pauli representations. The game value is recovered on honest finite tensor-product strategies; the soundness proof has to smooth and normalize those actual local maps.

Here “spatial tensor” means a tensor product of two party/reference algebras, in the operator-algebra and nonlocal-game sense. It does not mean a finite range interaction on `ℤ`, `ℤ²`, or a finite lattice. An arbitrary compression or tuple substitution can destroy the two-factor structure, which the manuscript itself flags in §15. Its inverse Jordan kernel `B_A(R,S)^{-1}` is a resolvent on this shared product domain, not an energy operator of a spin lattice model.

## Primary Hamiltonian results and their exact interfaces

### Spectral gap in two dimensions

Cubitt, Pérez-García, and Wolf prove undecidability for translationally invariant nearest-neighbour Hamiltonians on a 2D square lattice with a local dimension (d) fixed independently of the input. Their 2022 full paper proves a sharp promise: the thermodynamic-limit system is either gapped with a constant lower bound (indeed the local interaction strength can serve as the bound) or gapless with continuous spectrum above the ground state. Given a machine/input, the interactions are effectively described with **algebraic**, computable entries; the published construction does not establish rational entries. The construction encodes a computation through phase estimation, local Hamiltonian history terms, robust aperiodic tilings, and a final coupling to gapped/gapless sectors. The relevant theorem is a computable reduction from halting to that lattice promise, not a matrix-to-Hamiltonian conversion for arbitrary positivity domains.

Primary sources: Cubitt, Pérez-García, Wolf, [*Undecidability of the Spectral Gap*](https://doi.org/10.1017/fmp.2021.15), *Forum of Mathematics, Pi* 10 (2022), e14; full preprint [arXiv:1502.04573](https://arxiv.org/abs/1502.04573). The short Nature version appeared in 2015, [doi:10.1038/nature16059](https://doi.org/10.1038/nature16059). The 2022 theorem is the priority-bearing full proof.

### One-dimensional gap undecidability

Bausch, Cubitt, Lucia, and Pérez-García prove the same broad no-algorithm phenomenon for translationally invariant nearest-neighbour spin chains in 1D, by a different finite-size/computation construction. It rules out “perhaps only 2D spatial complexity causes the issue” as a useful barrier. It still concerns a family of chain Hamiltonians in the thermodynamic limit; it does not encode the note's two-baseline (Z_A) domain. Primary source: [*Undecidability of the Spectral Gap in One Dimension*](https://doi.org/10.1103/PhysRevX.10.031038), *Physical Review X* 10, 031038 (2020), [arXiv:1810.01858](https://arxiv.org/abs/1810.01858).

### Uncomputable phase diagrams

Bausch, Cubitt, and Watson construct a continuous one-parameter family of 2D translationally invariant nearest-neighbour Hamiltonians whose gap/phase membership is undecidable, and show undecidability on a set of positive measure in parameter space. This strengthens the physical endpoint from one machine-indexed Hamiltonian to a genuinely uncomputable phase diagram. The parameter dependence and thermodynamic limit are load-bearing; this result does not take a finite measurement pair as input. Primary source: [*Uncomputability of Phase Diagrams*](https://doi.org/10.1038/s41467-020-20504-6), *Nature Communications* 12, 452 (2021), [arXiv:1910.01631](https://arxiv.org/abs/1910.01631).

Purcell, Li, and Cubitt's later preprint constructs a continuous 2D translationally invariant nearest-neighbour family with exactly one transition, at Chaitin's Ω. It shows that a simple-looking phase diagram can have an uncomputable critical coordinate. Primary source: [*Chaitin Phase Transition*](https://arxiv.org/abs/2410.02600) (2024 preprint). It is a useful benchmark for a future stability target, but it still begins with a local Hamiltonian family and an externally varied real parameter.

### Universal Hamiltonian simulation

Cubitt, Montanaro, and Piddock define a local-encoding notion under which the low-energy sector of a simulator reproduces a target many-body Hamiltonian and its physical properties. They prove universality for models including 2D Heisenberg and XY systems with nonuniform, tunable couplings. This is strong evidence that many local-Hamiltonian phenomena can be moved among interaction families once a target local Hamiltonian is specified. It does not assert that an arbitrary noncommutative matrix-positivity predicate can be made into such a target. Primary source: [*Universal Quantum Hamiltonians*](https://arxiv.org/abs/1701.05182), published in *PNAS* 115 (2018), 9497–9502, [doi:10.1073/pnas.1804949115](https://doi.org/10.1073/pnas.1804949115).

Piddock and Montanaro prove universality for broad qudit interaction families, including the `SU(d)` Heisenberg interaction, using low-energy encodings and gadgets. Kohler, Piddock, Bausch, and Cubitt prove universal Hamiltonians even for translationally invariant 1D chains and derive PSPACE-completeness of the 1D translationally invariant local Hamiltonian problem with an exponentially small promise gap. These are finite-input ground energy and simulation results; an exponentially small finite size promise gap is not the thermodynamic spectral gap dichotomy used above. Primary sources: [*Universal Qudit Hamiltonians*](https://arxiv.org/abs/1802.07130) and [*Translationally-Invariant Universal Quantum Hamiltonians in 1D*](https://arxiv.org/abs/2003.13753).

### Stability warning from a new 2026 result

Castilla-Castellano and Lucia (July 2026 preprint) show that the particular 1D family with undecidable gap can be made decidable by adding, for every `ε>0`, a tailored 1-local rank-one perturbation of norm `O(ε)`. Their mechanism breaks an exact energy cancellation used by the halting encoding. This is not a theorem that all gap undecidability is fragile, nor does it affect the independent 2D theorem. It is a concrete warning that a proposed transfer of a promise or stability margin must preserve the exact structure and coefficients that carry the computation. Primary source: [*Instability of the undecidable behavior of the spectral gap in 1D*](https://arxiv.org/abs/2607.08686) (Laura Castilla-Castellano and Angelo Lucia, arXiv v1, 2026).

## The finite-rational boundary

The input to the supplied note is already a finite rational object: each constructed POVM has finitely many strictly positive rational-complex effects. The hard property is not the spectrum of one finite output matrix. It is a universal statement over all finite references, states, and tangents, with no computable reference cutoff. The note's RE upper bound enumerates finite rational witnesses; its hardness comes from MIP*=RE's unbounded finite-dimensional strategy quantifier.

By contrast, a single finite rational Hamiltonian has a computable finite spectrum. Its characteristic polynomial has rational coefficients, so exact root/multiplicity comparison decides whether its finite-size ground-state gap is zero or positive. A reduction to one finite Hamiltonian therefore cannot yield spectral-gap undecidability. A thermodynamic or other unbounded-limit encoding is essential. This is the main finite-versus-thermodynamic barrier.

There is also a coefficient-field mismatch in the most prominent lattice result: Cubitt–Pérez-García–Wolf give computable algebraic local entries, while the manuscript carefully outputs rational POVMs. Approximation of each algebraic number by rationals is not by itself enough: gapless behavior is not generally protected by a uniform perturbation theorem, and the proof must show that its promise survives the chosen rationalization. Universal simulation from rational target data can approximate a given finite Hamiltonian; it is not a proof that this thermodynamic undecidability construction can be rationalized.

## Missing theorem for a local spectral-gap transfer

A valid transfer would need an explicit computable map `$M\mapsto h_M$`, where `$h_M$` is a local interaction with fixed local dimension `d`, finite range (ideally nearest-neighbour and translation-invariant), rational or explicitly represented algebraic entries, and a proof of a sharp dichotomy such as:

1. if the actual shared-baseline kernel `$K_M(R,S)\succeq\eta I\otimes D^{-1}$` for every finite `$R,S$`, then the thermodynamic model `$H_M$` is gapped with a computable positive lower bound; and
2. if `$K_M$` has the note's faithful finite negative witness, then `$H_M$` is gapless (or lies in a distinguishable second phase).

The construction must preserve the two local party factors, the common `$R,S,D$` across every letter, positivity and normalization, and the finite-witness/unbounded-reference logic. It must also specify boundary conditions, thermodynamic-limit definition, local-dimension bound, coefficient representation, and promised gap constants. No cited universal-Hamiltonian theorem supplies this map. A straightforward “put the kernel into the local Hamiltonian” step is invalid: the kernel is a family of inverse Kronecker sums indexed by freely varying reference baselines, rather than one fixed operator acting on a lattice.

## Inverse problems and what the theorem does not say

Hamiltonian identification papers ask whether couplings can be uniquely recovered from a specified class of steady states, time traces, or observables, under a model and access assumptions. For example, [*Recovery of a Generic Local Hamiltonian from a Steady State*](https://doi.org/10.1103/PhysRevA.105.012615) studies recovery for specified spin-chain classes and local data. Such identifiability results do not decide whether one arbitrary detector dominates another for all states/references, and the channel-order reduction does not reconstruct an unknown Hamiltonian from sampled data. It gives a worst-case comparison problem between two *known* finite measurement devices.

A legitimate inverse-problem framing is therefore **model-independent detector certification**: from exact rational device descriptions, can one certify that every finite ancilla-assisted local estimation task is at least as well served by (E) as by (F)? The supplied theorem claims no algorithm can solve this universally. A practical, resource-bounded reconstruction problem would add access/noise/sample assumptions and is a different problem; undecidability alone does not show an experimentally realizable blind spot or an algorithmic lower bound for a given finite sample budget.

## Source assumptions and priority map

| Result | Primary theorem/assumptions | Relation to the supplied reduction |
|---|---|---|
| Ji–Natarajan–Vidick–Wright–Yuen (2020), [MIP*=RE](https://arxiv.org/abs/2001.04383) | Computable two-player nonlocal game from a Turing machine; value 1 if it halts and at most 1/2 otherwise. The stronger finite-perfect PCC case is also used by the supplied note's margin argument. | Supplies hardness only. It says nothing by itself about POVM order, Hamiltonian phases, or spectral gaps. |
| Cubitt–Pérez-García–Wolf (2022), [spectral gap](https://doi.org/10.1017/fmp.2021.15) | 2D square lattice, translation-invariant nearest-neighbour interactions, fixed local dimension `d`, computably specified algebraic entries, sharp thermodynamic gapped/gapless promise. | Closest major-physics analogue; no map from the note's restricted two-factor positivity domain. |
| Bausch–Cubitt–Lucia–Pérez-García (2020), [1D spectral gap](https://doi.org/10.1103/PhysRevX.10.031038) | 1D translationally invariant nearest-neighbour chains; presence of a thermodynamic gap undecidable. | Shows one spatial dimension is enough, but still no channel/Jordan compiler. |
| Bausch–Cubitt–Watson (2021), [phase diagrams](https://doi.org/10.1038/s41467-020-20504-6) | Continuous one-parameter 2D TI nearest-neighbour family; phase/gap membership uncomputable, including a positive-measure set. | Provides a phase-diagram target only after a local parameter family is built. |
| Cubitt–Montanaro–Piddock (2018), [universal Hamiltonians](https://doi.org/10.1073/pnas.1804949115) | Efficient local low-energy encodings; universal spin models with tunable couplings. | Can simulate a target Hamiltonian once built; does not convert arbitrary matrix-domain positivity to a Hamiltonian. |
| Castilla-Castellano–Lucia (2026 preprint), [1D instability](https://arxiv.org/abs/2607.08686) | Arbitrarily small tailored 1-local perturbation makes one known 1D undecidable family decidable. | A local warning about perturbation-sensitive computation encodings, not a general no-go for robust undecidability. |

## Priority and validation status

The broad ingredients all have prior art: MIP*=RE supplies game hardness; quantum Fisher information and complete channel orders are established; 1D/2D spectral-gap undecidability, uncomputable phase diagrams, and universal Hamiltonian simulation are established results. The new claimed contribution in the supplied note is the chain from finite rational game to positivity on the **actual normalized two-factor Jordan domain**, then to inverse-Jordan kernels, strictly positive rational POVMs, and complete channel order, with an additional bounded-defect approximation theorem. The literature above neither proves nor contradicts that chain. Its novelty/priority cannot be settled by analogy to Hamiltonian universality, and its internal lemmas remain unverified in this physics-literature note.

The relevant 2026 channel-order prior result is Hirche, [*Quantum Estimation, Channel Orders, and Private Capacity*](https://arxiv.org/abs/2610.03706): it establishes complete measured-χ²/SLD order implying complete relative-entropy order. The reverse direction used by the supplied note is a distinct claim; `lit08_algebras.md` describes it. The channel construction should be dated and priority-checked against this preprint before asserting novelty.
