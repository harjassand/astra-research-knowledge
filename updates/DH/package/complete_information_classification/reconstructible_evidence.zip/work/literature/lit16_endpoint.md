# Literature endpoint: complete Petz order two / RLD channel comparison

**Verdict (11 October 2026).** I found no primary paper in the focused search that states the exact channel-order theorem reconstructed in [rld_finite_cutoff.md](../investigations/rld_finite_cutoff.md): complete standard Petz $D_2$ (equivalently, complete RLD quadratic-form) comparison has a target-effective-output cutoff $1+b^2$, sharpened to $1+v$ for a measurement target with $v$ nonzero outcomes. The sharper dimension-only bounds therefore remain a plausible contribution, subject to proof and priority review. However, the *qualitative* result that a rational finite-channel pair has a finite, effective reference cutoff is already a generic consequence of Jurij Volčič’s 2021 rational free Positivstellensatz, once this comparison is encoded as one-level free rational positivity. The new argument’s likely novelty is the small, target-only cutoff and its outcome-count refinement, not the bare existence of a finite decision procedure.

## Why Volčič’s theorem applies

Fix channels $\Phi$ and $\Psi$ with input dimension $a$, and restrict each output to its effective support. For an untouched reference of dimension $n$, normalize a faithful baseline $R$ by $\operatorname{Tr}_A R=I_n$, as in the local proof. Choose a Hermitian basis $T_1,\ldots,T_{a^2-1}$ of traceless input matrices and write

\[
R_n(X)=\frac{I_A}{a}\otimes I_n+\sum_{\mu=1}^{a^2-1}T_\mu\otimes X_\mu,
\qquad X_\mu=X_\mu^*\in M_n.
\]

This parameterizes the entire normalized Hermitian affine slice. The positivity constraint is the monic pencil
$L(X)=aR_n(X)=I_{A\otimes R}+a\sum_\mu T_\mu\otimes X_\mu\succeq0$,
hence a standard free spectrahedron with all coordinates at the same matrix level $n$. Expand an arbitrary Hermitian tangent $h_n(Y)$ in a full Hermitian basis of the input with unrestricted Hermitian $n\times n$ coordinates $Y$. For either channel set
$A_\Phi(X)=(\Phi\otimes\mathrm{id})(R_n(X))$ and
$K_\Phi(Y)=(\Phi\otimes\mathrm{id})(h_n(Y))$, and similarly for $\Psi$. The reference-space difference

\[
r(X,Y)=\operatorname{Tr}_{\Phi(A)} K_\Phi A_\Phi^{-1}K_\Phi
-\operatorname{Tr}_{\Psi(A)} K_\Psi A_\Psi^{-1}K_\Psi
\]

is a scalar noncommutative rational function: block inverses, fixed block traces, and channel maps are finite rational operations on the free variables. On Hermitian evaluations it is Hermitian. At $X=0$, both $A_\Phi$ and $A_\Psi$ are invertible on their effective output supports, so the expression is nondegenerate. When the channel data are rational (or otherwise effectively exact), this encoding and its coefficients are effective. Faithful $R_n(X)$ makes each output block invertible on the effective support, since $R_n(X)\succ0$ implies
$A_\Phi(X)\succeq c\,\Phi(I_A)\otimes I_n$ for some $c>0$.

The local proof’s normalization/compression lemma identifies complete RLD dominance with $r(X,Y)\succeq0$ for every reference level $n$, every normalized faithful baseline, and every Hermitian tangent. Positivity is homogeneous under adding a scalar multiple of $R$ to the tangent because both channels preserve trace, so the free coordinates need no trace constraint. Boundary points of $L(X)\succeq0$ where $r$ is defined add no stronger condition: approximate $R$ by
$(1-\epsilon)R+\epsilon I_A/a\otimes I_n\succ0$
and use continuity.

Volčič, *Hilbert’s 17th problem in free skew fields*, Forum of Mathematics, Sigma 9 (2021), e61, Theorem 5.2 and Remark 5.3, gives the needed exact theorem. For a Hermitian monic pencil $L$ and noncommutative rational function $r$, positivity on $\operatorname{hdom}(r)\cap\mathcal D(L)$ is equivalent to a rational quadratic-module certificate. More directly, if positivity fails there is a negative evaluation at a finite matrix level

\[
n=2\big(e^3m^2+em(2e\ell-1)+\ell(e\ell-2)\big),
\]

where $e$ is the size of a linear representation of $r$,
$\ell=\dim V_{2\tau(r)-1}$, and
$m=\dim V_{2\tau(r)}-\dim V_{2\tau(r)-1}$.
In the encoding above, that matrix level is exactly the untouched-reference dimension. A negative boundary evaluation can be perturbed to a negative faithful-baseline evaluation. Thus this prior theorem gives a finite syntactic/representation-dependent witness bound for the RLD comparison. It is not the proposed $1+b^2$ bound: $e,\ell,m$ depend on the rational representation of the channel pair and can be much larger; the result does not isolate the target dimension or improve to outcome count. Primary source: [Volčič, arXiv:2101.02314](https://arxiv.org/abs/2101.02314), especially Theorem 5.2, Remark 5.3, and Proposition 2.1 on representatives with full Hermitian domain; journal version [doi:10.1017/fms.2021.54](https://doi.org/10.1017/fms.2021.54).

For the divergence interface,
$D_2(\rho\Vert\sigma)=\log\operatorname{Tr}(\rho^2\sigma^{-1})$.
On a faithful $\sigma$ and traceless Hermitian $H$, its Petz order-two quantity has the exact expansion

\[
\operatorname{Tr}(\sigma+tH)^2\sigma^{-1}
=1+t^2\operatorname{Tr}(H\sigma^{-1}H),
\]

so pairwise complete $D_2$ comparison is equivalent to complete comparison of the RLD quadratic form, not merely related by an informal local analogy. The RLD/standard-Petz-$\alpha=2$ identification also appears in the state-estimation literature; see [Yang et al., “Attaining the Ultimate Precision Limit in Quantum State Estimation,” CMP (2020), Eqs. (80)–(83)](https://doi.org/10.1007/s00220-019-03433-4). The exact channel-level perturbation and reference normalization used here are reconstructed in the linked local proof.

## Close results that do not have the same interface

- **Complete measured $\chi^2$, BKM $\chi^2$, relative entropy, and less-noisy orders.** Hirche’s current 2026 preprint defines complete measured-$\chi^2$ comparison over every finite reference and state pair, proves it implies complete BKM quantum-$\chi^2$ and relative-entropy/less-noisy comparison, and explicitly says arbitrary finite references remain part of those definitions. Its quantum $\chi^2$ is the BKM integral
  $\int_0^\infty\operatorname{Tr}[X(\sigma+sI)^{-1}X(\sigma+sI)^{-1}]\,ds$,
  not the RLD/Petz-$\alpha=2$ form. Its $d_B^2$ test is for the *Hermitian-smoothed measured-$\chi^2$* criterion, equivalent to a complete signed-lift certificate; it does not establish the RLD comparison or unsmoothed measured-order converse. The paper itself says the implication from unsmoothed complete measured-$\chi^2$ to a signed lift remains open in general. See [Hirche, arXiv:2610.03706v1](https://arxiv.org/abs/2610.03706), Eqs. (1.9)–(1.10), Theorem 3.2, Appendix A.1, and §6. The match in a $d_B^2$ scale is suggestive, but the tested object and proof interface differ.

- **Complete relative-entropy / less-noisy order.** Hirche, Rouzé, and Stilck França, *Quantum* 6, 862 (2022), §2.1, define the complete quantum-reference version and state that “there is no known restriction” on reference dimension. Their order is equivalent to a Umegaki relative-entropy/ensemble comparison, not Petz $D_2$/RLD; it neither supplies nor rules out the later finite cutoff. [arXiv:2011.05949](https://arxiv.org/abs/2011.05949).

- **Quantum statistical experiments and physical simulation.** Buscemi, *Comparison of quantum statistical models: equivalent conditions for sufficiency*, CMP 310 (2012), Proposition 6, reduces an all-auxiliary comparison of quantum information structures to a maximally entangled auxiliary whose dimension equals the target system dimension. This is a finite ancilla criterion for statistical sufficiency/postprocessing, not a pairwise Petz-$\alpha=2$ inequality between two channels. [arXiv:1004.3794](https://arxiv.org/abs/1004.3794).

- **Channel RLD Fisher information.** Katariya and Wilde express the RLD Fisher-information value of a parameterized channel through its Choi operator and show that a maximizing probe can use a reference isomorphic to the channel *input*. This optimizes one channel family’s local estimation information; it does not compare two channels for every state/tangent and gives no target-output cutoff for the order here. [arXiv:2008.11178](https://arxiv.org/abs/2008.11178), Eqs. (10)–(12).

## Bounded-search priority finding

The exact-match search covered the preceding primary sources and focused queries for complete RLD / Petz-$\alpha=2$ / channel $\chi^2$ ordering with bounded untouched reference, plus the surrounding comparison, statistical-experiment, and channel-estimation literature. No source found states the $1+b^2$ arbitrary-channel witness theorem or the $1+v$ measurement-channel refinement. Do not claim an unrestricted historical first on this search alone. The defensible priority statement is narrower: **Volčič already provides a generic effective finite-level theorem after this order is encoded as standard free rational positivity; the newly reconstructed result replaces that generic complexity bound with explicit target-only geometric bounds, including the sharper measurement count.**
