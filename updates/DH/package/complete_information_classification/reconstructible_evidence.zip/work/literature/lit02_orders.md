# Complete SLD / relative-entropy order: predecessors and degradation boundary

## Finding

The manuscript's (P\succeq_{c\mathrm{RE}}Q) is the established *completely less-noisy* channel preorder, expressed as a pairwise Umegaki relative-entropy comparison with every finite untouched quantum reference. Its definition permits unequal reference marginals. The usual support-inclusion formulation gives exactly the same preorder as the manuscript's unrestricted (+\infty)-extended formulation.

The established hierarchy is

\[
P\succeq_{\rm deg}Q\;\Longrightarrow\;
P\succeq_{c\mathrm{SLD}}Q\;\Longrightarrow\;
P\succeq_{c\mathrm{RE}}Q,
\]

where the second arrow is known through complete measured-\(\chi^2\)/BKM comparison. The manuscript's Section 2 proves the converse arrow (c\mathrm{RE}\Rightarrow c\mathrm{SLD}) using a saturated auxiliary reference and finite resolvent filters. That converse is stronger than the predecessor results below; none of them states it. The qutrit example of Zhu–Wang establishes that complete relative-entropy order does **not** imply physical channel degradation in general, so a finite degradation test is not a finite-reference test for (c\mathrm{RE}) or (c\mathrm{SLD}).

## Exact match to the established complete less-noisy order

Hirche–Rouzé–Stilck França, [“On contraction coefficients, partial orders and approximation of capacities for quantum channels”](https://arxiv.org/abs/2011.05949), [full text](https://arxiv.org/html/2011.05949), Quantum 6, 862 (2022):

- Proposition 2.3, Eq. (2.13), proves that the less-noisy mutual-information comparison is equivalent to pairwise Umegaki relative-entropy comparison for all state pairs satisfying input support inclusion. Applying that proposition to \(\operatorname{id}_R\otimes P\) and \(\operatorname{id}_R\otimes Q\), separately for every finite \(R\), gives the complete order. No equality of the two states' \(R\)-marginals is imposed.
- Lemma 3.1 proves tensorization of the complete order. Proposition 3.2 proves degradation implies complete less-noisy order by data processing. It does not prove the converse.
- Remark 8.5 (2022 version) records that a separation between *complete* less-noisy order and degradation remained open at that time, even for classical channels. Its examples in Proposition 8.4 separate only ordinary, noncomplete less-noisy order from degradation.

The manuscript asks for all finite references and gives the extended relative entropy on every state pair, including pairs without input support inclusion. This convention does not strengthen the preorder. Here is the boundary argument. Fix a finite \(R\), arbitrary input states \(\alpha,\beta\), and a full-rank state \(\tau\) on \(RA\). Put \(\alpha_\epsilon=(1-\epsilon)\alpha+\epsilon\tau\) and \(\beta_\epsilon=(1-\epsilon)\beta+\epsilon\tau\). The support-inclusion order applies to this regularized pair. For any channel \(\Phi\), if \(D(\Phi\alpha\|\Phi\beta)<\infty\), joint convexity gives

\[
D(\Phi\alpha_\epsilon\|\Phi\beta_\epsilon)\le(1-\epsilon)D(\Phi\alpha\|\Phi\beta),
\]

and lower semicontinuity gives convergence to that finite value. If the target-channel divergence is infinite, lower semicontinuity makes its regularized divergences tend to infinity; the comparison then forces the source-channel divergence to be infinite too. Thus the support-inclusion order is equivalent to the manuscript's all-pairs convention. This argument leaves the reference marginals unrestricted.

Hirche–George–Nuradha–Wilde, [“Conditional contraction coefficients and their applications to quantum networks”](https://arxiv.org/abs/2608.27171), [full text](https://arxiv.org/html/2608.27171), makes the unequal-marginal point explicit. Theorem 1, Eq. (3.16), characterizes the conditional-mutual-information comparison by

\[
\eta\big[D(P_R\alpha\|P_R\beta)-D(\alpha_R\|\beta_R)\big]
\ge D(Q_R\alpha\|Q_R\beta)-D(\alpha_R\|\beta_R)
\]

for all support-compatible \(\alpha_{RA},\beta_{RA}\), with no constraint \(\alpha_R=\beta_R\). At \(\eta=1\), the identical reference-divergence terms cancel, leaving precisely the complete relative-entropy order. Do not confuse this with the *complete contraction coefficient* defined in that paper's Eq. (1.4), which does impose equal reference marginals.

## Relation of the manuscript's SLD order to prior orders

Hirche, [“Quantum estimation, channel orders, and private capacity”](https://arxiv.org/abs/2610.03706), [full text](https://arxiv.org/html/2610.03706), gives the relevant established one-way hierarchy:

- Section 2.1, Eqs. (2.3)–(2.5), identifies measured \(\chi^2\) with the SLD quadratic form: \(\chi_m^2(\rho\|\sigma)=q_\sigma(\rho-\sigma)\), where \(q_\sigma(X)=\operatorname{Tr}X\mathcal S_\sigma^{-1}(X)\) and \(\mathcal S_\sigma(G)=(\sigma G+G\sigma)/2\). For faithful base \(\sigma\), this is exactly the local tangent expression in the manuscript, since \(\chi_m^2(\sigma+tH\|\sigma)=t^2g_\sigma(H)\).
- Section 3.1, Eq. (3.1), defines complete measured-\(\chi^2\) comparison over every finite reference and every state pair. The introduction's Eq. (1.9), with the proof via Proposition 3.5 in Section 3.1, establishes complete measured-\(\chi^2\) \(\Rightarrow\) complete quantum-\(\chi^2\) (the BKM metric) \(\Leftrightarrow c\mathrm{RE}\) \(\Leftrightarrow\) completely less noisy. Equivalently, the established direction is (c\mathrm{SLD}\Rightarrow c\mathrm{RE}).
- The same paper's Eq. (1.10) and Section 3.1 distinguish a stronger smoothed measured-\(\chi^2\) order, characterized by a common complete signed lift. Neither a signed lift nor a complete measured-\(\chi^2\) comparison is automatically a CPTP postprocessing: the lift is only Hermiticity-preserving and may fail positivity.

The manuscript's Section 2.1 gives another route for (c\mathrm{SLD}\Rightarrow c\mathrm{RE}): a coherent reference qubit realizes the resolvent (f_s)-divergences, whose positive integral is Umegaki relative entropy. Sections 2.2–2.3 prove the converse by using a center-and-leaves reference and a sequence of realizable finite resolvent filters concentrating at denominator ratio one. The prior hierarchy supplies the forward implication, not this reverse implication. Therefore the manuscript's claimed equivalence is a new strengthening relative to these identified sources; it does not contradict their stated one-way hierarchy.

## Degradation is strictly stronger than these entropy orders

Degradation has the expected forward implication: if (Q=\Theta\circ P) for a CPTP map \(\Theta\), then DPI gives (P\succeq_{c\mathrm{RE}}Q), with every finite reference and every pair. The converse is false.

Zhu–Wang, [“Quantum incapacity from observable shadows”](https://arxiv.org/abs/2607.24693v3), [full text](https://arxiv.org/html/2607.24693), gives an explicit counterexample. Their Eq. (6) defines

\[
\Lambda(X)=\tfrac12X+\tfrac14\bigl[\operatorname{Tr}(X)I-X^{\mathsf T}\bigr],
\]

a qutrit channel with a four-dimensional complement \(\Lambda^c\). Equations (7)–(8) give a fixed, unbiased, variance-contracting observable shadow \(\mathcal J\) of \(\Lambda\) through \(\Lambda^c\); it is not positive, since \(\mathcal J(|0\rangle\langle0|)=\operatorname{diag}(1,-1,2,2)/3\). Theorem S5 and Lemma S2 prove \(\Lambda^c\succeq_{c\mathrm{RE}}\Lambda\) for every finite reference and every support-compatible input pair. Theorem S13 states the resulting complete relative-entropy order for every tensor power. Proposition S16 proves \(\Lambda\) is not antidegradable, i.e. there is no CPTP \(\Theta:\mathcal L(\mathbb C^4)\to\mathcal L(\mathbb C^3)\) with \(\Lambda=\Theta\circ\Lambda^c\). The proposition's short obstruction is that such a \(\Theta\) would require positive output states \(\sigma,\tau_0,\tau_1,\tau_2\) obeying \(\sigma+\tau_i=I-|i\rangle\langle i|\) for all three basis indices, forcing \(\operatorname{Tr}\sigma=0\), contradicting trace preservation.

This is also a counterexample to (c\mathrm{SLD}\Rightarrow\) degradation: the same observable shadow satisfies the complete variance/signed-lift condition, whose variational formula yields complete measured-\(\chi^2\) comparison (Hirche 2026, Eq. (3.5)); at faithful bases this is the manuscript's SLD order. This last sentence combines the two cited results; the qutrit paper itself explicitly proves cRE, while its shadow certificate supplies the stronger variance premise.

The cRE definition in Zhu–Wang is written only for support-compatible input pairs. The regularization argument above upgrades its order to the manuscript's unrestricted extended-valued convention, including pairs with unequal reference marginals. Thus the nondegradability counterexample matches the manuscript's order, not just a restricted-marginal variant.

## Why finite comparison theorems do not give a cRE/SLD reference cutoff

These theorems characterize full decision or guessing orders, which are stronger than pairwise Umegaki relative-entropy comparison:

| Primary result | Exact finite-comparison statement | Why it is not a cRE/SLD cutoff |
|---|---|---|
| Anna Jenčová, [“Comparison of quantum channels and statistical experiments”](https://arxiv.org/abs/1512.07016), Theorem 1 | Approximate channel deficiency \(\delta(\Phi,\Psi)\le\epsilon\) iff all reference-assisted ensemble guessing-success probabilities compare with the specified error. The theorem says it suffices to use ancilla \(K_0=K\), where \(K\) is the output of \(\Phi\), and equiprobable ensembles of \(d_K^2\) states. At \(\epsilon=0\), this is exact postprocessing of \(\Psi\) to \(\Phi\). | It tests every guessing payoff, not just relative entropy or its SLD Hessian. The qutrit pair above satisfies cRE/cSLD without such a postprocessing. |
| Francesco Buscemi, [“Comparison of quantum statistical models: equivalent conditions for sufficiency”](https://arxiv.org/abs/1004.3794), Theorem 3 (noncommutative BSS) | For fixed statistical models, dominance in all Bayesian decision problems is equivalent to sufficiency by a CPTP map. | This is the all-decision Blackwell order on models, not the two-channel pairwise cRE order. |
| Francesco Buscemi, [“Degradable channels, less noisy channels, and quantum statistical morphisms: an equivalence relation”](https://arxiv.org/abs/1511.08893), Proposition 1; Lemma 1 and Corollary 1 | All cq-ensemble min-entropy/guessing comparisons give a Hermitian trace-preserving statistical morphism. If the target channel's outputs commute, that morphism can be extended to a CPTP degrader (Corollary 1); the classical-channel version is Corollary 3. | The entropy in the premise is min-entropy/guessing, not Shannon mutual information/Umegaki relative entropy. The change of divergence is decisive. |
| Keiji Matsumoto, [“A quantum version of randomization criteria”](https://arxiv.org/abs/1012.2650), Theorem 5 and Corollary 6 | q-\(\epsilon\)-deficiency for quantum decision problems is equivalent to existence of a CPTP map approximating every state in one model; at zero error this is exact randomization. Corollary 6 recasts zero deficiency through all finite-argument CPTP-monotone functionals. | It concerns full decision-problem dominance / model randomization, not one entropy comparison between channel outputs. |
| E. Shmaya, [“Comparison of Information structures and Completely Positive Maps”](https://arxiv.org/abs/quant-ph/0410233), Theorem 2 | One bipartite information structure is better in every game—including arbitrary independent environment systems and payoff observables—iff a CPTP map on the observer's accessible subsystem converts it to the other. Equality of the untouched marginal follows necessarily from this local simulation. | It tests every game and payoff, not only pairwise Umegaki divergences. |

For POVM channels, physical degradation is the finite LP feasibility problem \(F_j=\sum_i t_{j|i}E_i\), \(t_{j|i}\ge0\), and \(\sum_j t_{j|i}=1\). If the manuscript's complete SLD/RE order were identified with this LP order on its POVM subclass, its undecidability and no-computable-reference-cutoff claims would indeed conflict with finite degradation testing. None of the results above establishes that subclass implication. The qutrit counterexample proves that no such identification is valid for arbitrary quantum channels; it is not itself a measurement-channel counterexample. HRSF's 2022 remark identified the complete less-noisy/degradation comparison as open then; the later qutrit example settles non-equivalence for general quantum channels, while leaving the special rational-POVM subclass to the manuscript's own theorem and proof.

## Primary-source index

- Hirche–Rouzé–Stilck França, arXiv:2011.05949, Props. 2.3, 3.2; Lemma 3.1; Remark 8.5: <https://arxiv.org/html/2011.05949>.
- Hirche, arXiv:2610.03706, Eqs. (2.3)–(2.5), (1.9)–(1.10), (3.1)–(3.6): <https://arxiv.org/html/2610.03706>.
- Hirche–George–Nuradha–Wilde, arXiv:2608.27171, Theorem 1, Eq. (3.16), Sec. 3.4, Eqs. (3.67)–(3.70): <https://arxiv.org/html/2608.27171>.
- Zhu–Wang, arXiv:2607.24693v3, Eq. (6), Eqs. (7)–(8), Theorem S5, Lemma S2, Theorem S13, Proposition S16: <https://arxiv.org/html/2607.24693>.
- Jenčová, arXiv:1512.07016, Theorem 1: <https://arxiv.org/html/1512.07016>.
- Buscemi, arXiv:1004.3794, Theorem 3: <https://arxiv.org/html/1004.3794>.
- Buscemi, arXiv:1511.08893, Proposition 1, Lemma 1, Corollaries 1 and 3: <https://arxiv.org/html/1511.08893>.
- Matsumoto, arXiv:1012.2650, Theorem 5, Corollary 6: <https://arxiv.org/html/1012.2650>.
- Shmaya, arXiv:quant-ph/0410233, Theorem 2: <https://arxiv.org/html/quant-ph/0410233>.
