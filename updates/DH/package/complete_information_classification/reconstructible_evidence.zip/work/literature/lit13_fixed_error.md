# Adversarial audit: fixed-additive-error argument (Sections 11–14)

**Audit result (11 October 2026).** I found no quantitative obstruction in Sections 11–14. The fixed-error conclusion follows from the stated finite perfect PCC premise, the Schmidt-sector reduction, the dimension-independent Fisher normalization on manuscript pp. 22–23, the explicit entropy-filter constants on pp. 24–25, and the tensor amplification on p. 26. This is a proof-level reconstruction of those indispensable steps, conditional on the correctness of the earlier channel-order/game reduction (Sections 1–10); it is not a complete audit of that earlier reduction or an exhaustive novelty review.

The authoritative manuscript used here is [`channel_order_undecidability.pdf`](../manuscript/channel_order_undecidability.pdf), especially pp. 21–26. The page images were inspected directly because the text extraction corrupts several displayed formulas.

## 1. Exact external premise and maximally entangled sector

Ji, Natarajan, Vidick, Wright, and Yuen, *MIP*=RE*, arXiv:2001.04383v3, Theorem 12.6 (printed p. 172), gives an effective machine-to-game map with:

- halting: game value one, **attained by a finite-dimensional PCC strategy winning with certainty**;
- nonhalting: game value at most (1/2).

The finite-dimensional attainment is explicit in the theorem, not inferred from the supremum definition of (operatorname{val}^*). Definitions 5.9–5.11 (printed pp. 51–52) define PCC as projective, consistent, and commuting. The consistency part used by the manuscript is the exact vector equation, for each answer projector on corresponding question families,
\[
(M^A_{x,a}\otimes I)|\psi\rangle=(I\otimes M^B_{x,a})|\psi\rangle.
\]
The additional projective/commuting conditions are stronger than the lemma needs. The paper's efficient game/verifier description can be converted effectively to an explicit finite rational table, if one is needed downstream: enumerate the bounded verifier random tapes, all finite questions and answers, and the deterministic payoff bits. This may be exponentially large, but the reduction requires computability, not polynomial output size.

The manuscript's Lemma 12.1 is correct. With the fixed vectorization convention 
\(|\psi\rangle=\operatorname{vec}C\), consistency gives (M_A C=C M_B^T). Since the projectors are Hermitian, this and its adjoint imply
\[
M_A CC^*=CC^*M_A.
\]
The matching argument on Bob's side shows that every answer projector preserves the corresponding left/right Schmidt eigenspaces. In a positive Schmidt sector of eigenvalue \(\lambda\) and multiplicity (d_\lambda\), the normalized component is maximally entangled on dimension (d_\lambda). Projectors preserve sectors, so each game payoff is the Schmidt-weighted convex combination of sector payoffs. A total payoff of one and payoffs in \([0,1]\) force every nonzero sector payoff to be one. Restriction to one sector therefore yields a finite perfect maximally entangled strategy. No claim that arbitrary games have maximally entangled optimizers is used.

## 2. Bounded defect and the dimension-free Fisher witness

For the manuscript's
\[
V(E,F)=\sup_{R,\rho,\sigma}\{D(F_R(\rho)\|F_R(\sigma))-D(E_R(\rho)\|E_R(\sigma))\},
\]
strict positivity makes every displayed divergence finite for faithful inputs. If \(\alpha_i I\le M_i\le\beta_i I\), the outcome blocks satisfy \(\alpha_i\rho_R\le\rho_i\le\beta_i\rho_R\). Monotonicity of the operator logarithm and cancellation of the reference-marginal terms give
\[
0\le G_M:=D(M_R(\rho)\|M_R(\sigma))-D(\rho_R\|\sigma_R)
\le\max_i\log(\beta_i/\alpha_i).
\]
The lower bound is data processing after forgetting the outcome. Since (V=G_F-G_E), this proves the manuscript's finite bound (0\le V(E,F)\le\max_i\log(\beta_i/\alpha_i)). It does not give an approximation algorithm.

For the halting witness, the manuscript fixes (r=3/4), \(\gamma=1/4\), initial physical dimension (a=2MK), compiler node count (L), and padding dimension (q_0=\lceil L/a\rceil). With the centered-letter polynomial (F=\sum_w c_w T_w), choose rational (B_{\rm deg}\ge\sum_w |w||c_w|) and
\[
e=\min\{1/2,\gamma/(8\max\{1,B_{\rm deg}\})\}.
\]
The faithful Choi mixture adds (e(I_a/a)\otimes I_\ell), preserving the reference marginal (I_\ell). Every centered letter is multiplied by (1-e), so its polynomial expectation changes by at most (e B_{\rm deg}\); the perfect strategy's value (-\gamma) remains at most (-\gamma/2). The physical Choi baselines obey
\[
(e/a)I\le R_e,S_e\le aI,
\]
where the upper bound follows from pinching a positive block matrix with physical partial trace (I_\ell).

The crucial norm is operator norm. At the identity marginals the reshaped positive-effect letter acts as (Z\mapsto(C_AZ+ZD_A)/2), with (0\le C_A,D_A\le I), hence contracts operator norm. Starting at (I_\ell/\sqrt\ell), each word node has norm at most (1/\sqrt\ell); the (L) selected cross coordinates yield a Hermitian, trace-zero tangent (X) with \(\|X\|\le2L/\sqrt\ell\). The padded baseline \(\Theta_0\) has trace (2\ell), reference marginal (I_{2\ell}), and
\[
\frac{e}{2\max\{a,q_0\}}I\le\Theta_0\le aI.
\]
Thus for \(\rho=\Theta_0/(2\ell)\), \(H=X/\sqrt\ell\), and
\[
h=\frac{8L\max\{a,q_0\}}{e},
\]
we have \(-h\rho\le H\le h\rho\), with (h) independent of the unknown strategy dimension \(\ell\). If all final effects have certified rational lower bound \(\alpha I\) and upper bound \((1-\alpha)I\), then each outcome block of either full output state lies between \(\alpha I/(2\ell)\) and \((1-\alpha)I/(2\ell)\). Its condition number is at most \(\kappa=1/\alpha\), again independent of \(\ell\).

The normalization factor in the Fisher gap checks exactly. Equation (54), together with the graph identity, gives the unnormalized gap from the polynomial expectation. The signal branch has weight (1/2) and signal factor \(\delta_s^2\), producing source-minus-target at most \(-2\delta_s^2\gamma/\lambda\) on \((\Theta_0,X)\). Scaling the base by (1/(2\ell)) and tangent by (1/\sqrt\ell) multiplies the SLD quadratic form by (2), because it is quadratic in the tangent and inverse-linear in the base. Therefore
\[
g_{A_F}(K_F)-g_{A_E}(K_E)\ge d_0=\delta_G=\frac{4\delta_s^2\gamma}{\lambda}>0.
\]
The rational (h,\kappa,d_0) are computable from the game data and do not contain \(\ell\). The maximally entangled sector is essential for this operator-norm normalization; replacing it with an arbitrary perfect strategy would not establish the same bound.

## 3. Entropy-filter margin and Taylor remainder

The image of manuscript p. 24 fixes the filter constants (including the easily misread exponent):
\[
m=\max\{6,\lceil288\kappa^2h^4/d_0^2\rceil\},\quad N=2m+1,\quad r_0=N+1,
\]
\[
\Lambda_0=\sum_{j=0}^{2m}|c_j|,\quad q_*=h\kappa\Lambda_0,\quad
j_* = \frac{5^{-(4m+2)}}{N},
\]
\[
\eta_0=\min\{1/4,j_*d_0/(16q_*^2)\},\quad
t_0=\min\{1/(2q_*),3j_*d_0/(256q_*^3)\},\quad
\epsilon_0=j_*d_0t_0^2/16.
\]
The exponent is (-(4m+2)), and the resulting power is then divided by (N). All quantities are positive and rational/effectively computable: the poles \(\lambda_j=1+j/m^3\) and partial-fraction coefficients (c_j) are rational. The auxiliary reference dimension (r_0=2m+2) depends only on (h,\kappa,d_0).

For \(W=\operatorname{diag}(1,\lambda_0,\ldots,\lambda_{2m})\), (v=N^{-1/2}\sum_j e_{j+1}), (w=\sum_jc_je_{j+1}), take \(\tau=vv^*\), \(L=e_0w^*+we_0^*\), and \(\sigma_{\eta_0}=(1-\eta_0)\tau+\eta_0 I/r_0\). Although (v) uses a square root, \(\tau,L,\sigma_{\eta_0}\) have rational entries. The input pair
\[
\alpha=\rho\otimes\sigma_{\eta_0},\qquad
\beta(t)=\frac{\rho\otimes W+tH\otimes L}{Z_0},\quad Z_0=\operatorname{Tr}W,
\]
is faithful for the chosen (t=t_0): the relative tangent bound is \(q_*=h\kappa\Lambda_0\), and \(|t|\le1/(2q_*)\) gives \(\beta(t)\ge\alpha/(2Z_0)\). Hence both divergences are finite and at most \(\log(2Z_0)\).

The normalized filter density \(\nu_m\) obeys the manuscript's exact bound \(\mathbb E_{\nu_m}|s-1|\le3\sqrt{2/m}\). For output eigenvalues (a,b), the inverse-kernel relative error is at most \(\kappa|s-1|\); the SLD score obeys (g_A(K)\le h^2). Consequently the per-channel normalized Hessian error is at most \(3\kappa h^2\sqrt{2/m}\le d_0/4\); the two-channel error is at most (d_0/2). On (s\in[1,2]), all \(\lambda_j\le3\), so (F_m(s)^2\ge5^{-(4m+2)}), and (J_m=I_m/N\ge j_*\). Thus the ideal target-minus-source Hessian is at least (J_md_0/2\ge j_*d_0/2\).

For \(G_{\sigma}(t)\), the target-minus-source entropy gap along this path, saturation gives (G_\sigma(0)=0), and conjugating the auxiliary center coordinate by (-1) makes (G_\sigma(t)) even. The Hessian is linear in the numerator, and the displayed constants give
\[
G''_{\sigma_{\eta_0}}(0)\ge j_*d_0/4.
\]
The resolvent derivative bound gives absolute third derivative at most (32q_*^3) for the two-channel difference on ([-1/(2q_*),1/(2q_*)]). Taylor's theorem therefore yields
\[
G_{\sigma_{\eta_0}}(t)\ge(j_*d_0/8)t^2-(16/3)q_*^3|t|^3.
\]
The selected (t_0\le3j_*d_0/(256q_*^3)) makes the cubic loss at most ((j_*d_0/16)t_0^2), leaving a gap at least \(\epsilon_0=j_*d_0t_0^2/16>0\). This closes the Fisher-to-entropy step with a game-computable margin independent of \(\ell\).

## 4. Fixed (1/4) amplification

Theorem 14.1 uses the game-computable \(\epsilon_G=\epsilon_0>0\): nonhalting gives complete entropy dominance and (V(E,F)=0); halting gives a faithful witness with (V(E,F)\ge\epsilon_G). An additive-\(\epsilon_G/4\) total approximation algorithm would distinguish outputs below \(\epsilon_G/2\) from outputs above it and decide halting.

For the fixed-error corollary, unrestricted complete relative-entropy dominance tensorizes by replacing one channel factor at a time; all other inputs/outputs form an allowed finite reference, and the order is valid for arbitrary state pairs. Set (k=\lceil1/\epsilon_G\rceil), which is computable because \(\epsilon_G\) is positive rational. Tensor-product POVMs remain rational, normalized, and strictly positive. Nonhalting still gives (V(E^{\otimes k},F^{\otimes k})=0). In the halting case, the (k)-fold products of the faithful witness states remain faithful, and relative entropy additivity gives defect at least (k\epsilon_G\ge1). An additive-(1/4) algorithm therefore returns at most (1/4) in the first case and at least (3/4) in the second; threshold (1/2) decides halting. The tensor dimension may be enormous, but only total computability is claimed.

## 5. Relation to known computability results

The functional (V(E,F)) is a complete relative-entropy-order defect: it takes a **difference** of two relative entropies evaluated on the same input pair \((\rho,\sigma)\), then ranges over every finite untouched reference. It is not the standard relative entropy of two channels,
\[
D(\mathcal N\|\mathcal M)=\sup_{\rho_{AR}}D(\mathcal N(\rho_{AR})\|\mathcal M(\rho_{AR})),
\]
which compares the two channel outputs on one common input state. Koßmann–Wilde, arXiv:2410.16362, reduce that channel-divergence optimization to a reference isomorphic to the input and give arbitrary-precision upper/lower bounds by SDP methods. Those algorithms do not bound or optimize the two-state complete-order defect (V).

Hirche–Rouzé–Stilck França, arXiv:2011.05949v4, §2.1, explicitly note that complete less-noisy comparison with a quantum reference has no known reference-dimension restriction and is harder to check. Hirche, arXiv:2610.03706v1, §3.1, likewise defines complete relative-entropy order over every finite reference and relates it to complete quantum \(\chi^2\) and less-noisy order. Its finite-dimensional signed-lift characterization concerns a distinct Hermitian-smoothed condition; it does not supply a fixed cutoff for the unsmoothed complete order in this manuscript. These sources are consistent with, rather than counterexamples to, the asserted undecidability.

## Primary sources

- Zhengfeng Ji, Anand Natarajan, Thomas Vidick, John Wright, and Henry Yuen, [*MIP*=RE*, arXiv:2001.04383v3](https://arxiv.org/pdf/2001.04383v3), Theorem 12.6 (printed p. 172), Definitions 5.9–5.11 (printed pp. 51–52).
- Christoph Hirche, Cambyse Rouzé, and Daniel Stilck França, [*On contraction coefficients, partial orders and approximation of capacities for quantum channels*, arXiv:2011.05949v4](https://arxiv.org/abs/2011.05949), §2.1.
- Gereon Koßmann and Mark M. Wilde, [*Semidefinite Optimization of the Quantum Relative Entropy of Channels*, arXiv:2410.16362](https://arxiv.org/abs/2410.16362), definition (15), finite-reference reduction and SDP bounds.
- Christoph Hirche, [*Quantum estimation, channel orders, and private capacity*, arXiv:2610.03706v1](https://arxiv.org/abs/2610.03706), §3.1 and Appendix A.1.

