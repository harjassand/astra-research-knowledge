# Complete information order, sufficiency, and reference cutoffs

## Finding

There is a sharp negative result for the proposed implication

> complete relative-entropy / SLD order \(\Longrightarrow\) physical channel degradation.

The complementary channel of an explicit qutrit channel completely dominates that channel in measured-\(\chi^2\) (equivalently SLD quadratic-form), BKM, and relative-entropy order, while the channel is not antidegradable. Thus even allowing every finite reference and every state pair does not make these orders a Blackwell test for a CPTP simulator. The example also has zero unassisted private and quantum capacity, so the order still has a substantial operational consequence without certifying a physical reconstruction.

This does **not** answer the stronger question whether simultaneous domination in **every Petz monotone metric** forces degradation. The qutrit certificate gives SLD/measured-\(\chi^2\), BKM, and relative entropy, not a proof of inequalities for the whole Petz family. I found no theorem or counterexample in the primary sources reviewed that settles that stronger channel-order question. In particular, equality/recoverability theorems for one channel must not be read as order characterizations for two channels.

## Explicit nondegradation example

Zhu and Wang (2026 preprint, v3) define complete observable shadowing of \(\mathcal N\) by \(\mathcal M\): one fixed Hermiticity-preserving observable map \(J\) is unbiased and has no larger variance for every Hermitian score, input state, and finite reference. Their exact qutrit example is

\[
\Lambda(X)=\tfrac12X+\tfrac14(\operatorname{Tr}(X)I-X^{\mathsf T}),\qquad \mathcal M=\Lambda^c,\quad \mathcal N=\Lambda.
\]

They give \(J^\dagger\circ\Lambda^c=\Lambda\), an explicit Kraus factorization certifying the complete variance inequality, and \(J(|0\rangle\langle0|)=\operatorname{diag}(1,-1,2,2)/3\), so \(J\) is not positive. They separately prove that \(\Lambda\) is not antidegradable. Therefore no CPTP \(D\) satisfies \(\Lambda=D\circ\Lambda^c\).

The metric/entropy consequences follow by chaining two precise results:

1. Complete variance domination gives complete measured-\(\chi^2\) domination. For faithful \(\sigma\) and traceless Hermitian \(X\), \(\chi_m^2(\sigma+tX\|\sigma)=t^2 q_\sigma(X)\), where \(q\) is the SLD quadratic form; hence this comparison includes every finite-reference SLD tangent test.
2. Hirche (2026 preprint) proves complete measured-\(\chi^2\) order implies complete quantum-\(\chi^2\)/BKM and complete relative-entropy order. The latter is equivalent to complete less-noisy order in the earlier Hirche–Rouzé–Stilck França result.

So this is already a counterexample to “complete entropy order forces degradation,” and a stronger counterexample than one based only on unassisted state pairs. The proven implication chain is

\[
\Lambda^c\succeq^c_{\chi_m^2}\Lambda
\;\Longrightarrow\;
\Lambda^c\succeq^c_{\rm SLD}\Lambda,\quad
\Lambda^c\succeq^c_{\rm BKM}\Lambda,\quad
\Lambda^c\succeq^c_{\rm RE}\Lambda,
\]

but none of these comparisons supplies a physical degrading map. See [Zhu–Wang, *Quantum incapacity from observable shadows*](https://arxiv.org/abs/2607.24693), especially Sections 2–3 and Supplement S2–S5; [Hirche, *Quantum estimation, channel orders, and private capacity*](https://arxiv.org/abs/2610.03706), Sections 2–3; and [Hirche–Rouzé–Stilck França (2022)](https://arxiv.org/abs/2011.05949), Proposition 2.3. The 2026 items are preprints, so their claims should retain that status until independently checked or published.

## What equality does buy

Petz sufficiency is an equality statement for a **single channel acting on a fixed model**, not an inequality between arbitrary channels. Petz's sufficiency theorems identify equality in relative-entropy data processing with a recovery map for the tested state pair/model ([Petz 1986](https://doi.org/10.1007/BF01212345); [Petz 1988](https://doi.org/10.1093/qmath/39.1.97)). The modern metric form is particularly sharp: for faithful \(\rho\), a tangent \(A\), and a channel \(\Phi\), Gao–Li–Marvian–Rouzé prove that equality of one regular monotone metric at \((\rho,A)\) is equivalent to a rotated Petz map recovering both \(\rho\) and \(A\); equality for a state pair is equivalent to sufficiency for that pair. Their theorem excludes the nonregular SLD and RLD metrics. Conversely, they exhibit a full-rank one-parameter family whose SLD Fisher information is preserved at every parameter despite the absence of a common recovery map. Thus “all monotone metrics” is stronger than needed for a regular-metric equality test, while SLD equality alone is insufficient even for a family. See [Gao et al. (2023)](https://arxiv.org/abs/2302.02341), Theorems 1.2, 1.4, 4.6 and Corollary 4.7.

Petz's classification associates quantum monotone metrics with normalized symmetric operator-monotone functions ([Petz 1996](https://doi.org/10.1016/0024-3795(94)00211-8); [Petz–Sudár 1996](https://doi.org/10.1063/1.531535)). This family classification does not itself say that ordering two channels in all metrics is equivalent to postprocessing. It classifies each state's local metric and its data processing under an already specified CPTP map.

## Exact reference-cutoff boundary

| Comparison being tested | What the literature gives |
|---|---|
| All quantum statistical decision problems | The noncommutative Blackwell–Sherman–Stein theorem gives equivalence with **m-sufficiency/statistical morphism**. This morphism need not be CPTP; for an abelian target the distinction disappears. [Shmaya 2005](https://arxiv.org/abs/quant-ph/0410233); [Buscemi 2012](https://arxiv.org/abs/1004.3794), Theorem 3 and Proposition 4. |
| Physical CPTP comparison of quantum information structures | Buscemi reduces all auxiliary comparisons to one maximally entangled auxiliary state whose two sides have dimension \(d_{B'}\), the target system dimension. This finite cutoff belongs to the full decision/information-structure comparison, not to complete relative-entropy or Fisher-metric order. [Buscemi 2012](https://arxiv.org/abs/1004.3794), Proposition 6. |
| Complete relative entropy / less-noisy order | The definition quantifies over every finite untouched reference. Hirche–Rouzé–Stilck França state that no reference-dimension restriction is known in general. [HRSF 2022](https://arxiv.org/abs/2011.05949), introduction and Proposition 2.3. |
| Complete SLD order for rational strictly positive POVMs | The supplied local note claims there is no total computable witness-reference bound, and claims equivalence with unrestricted complete Umegaki order. Its proof reduces an undecidable problem; for a fixed SLD reference size it uses real quantifier elimination. This is a claim in an AI-generated, explicitly unreviewed note, not established literature. If correct, it rules out a computable sufficient cutoff for that stated class. It does not establish such a boundary for every Petz metric. |
| Equality for a fixed pair under one channel | No reference is needed to state Petz sufficiency: equality of a regular \(\chi^2\)/monotone metric for the pair characterizes recovery of that pair. Extending to a model requires one recovery map to work across the model. [Gao et al. (2023)](https://arxiv.org/abs/2302.02341), Theorem 1.4 and Corollary 4.7. |

The supplied manuscript is [`channel_order_undecidability.txt`](../manuscript/channel_order_undecidability.txt). Its front matter labels the work AI-generated, not peer-reviewed, with originality and priority unconfirmed. The precise cutoff assertion is Theorem 1.2(3), restricted to rational strictly positive POVM pairs and SLD witnesses. Section 10.2's finite-size quantifier-elimination argument is specifically for SLD. The note explicitly says its entropy undecidability transfer does not assume an algorithm for fixed-size transcendental Umegaki formulas. Treat the theorem as a promising conditional result until the reduction and especially the SLD-to-unrestricted-RE equivalence have been independently audited.

## Research conclusion

The strongest verified opportunity here is not “all metrics imply Blackwell.” It is the precise separation between (a) complete *local/entropic* comparisons, which can have deep capacity consequences yet admit only a nonpositive statistical lift, and (b) all-decision comparison, which is the setting that characterizes physical postprocessing after a finite ancilla test. For the unresolved all-Petz-metrics channel preorder, the next decisive test is whether the qutrit signed-lift construction satisfies some regular metric comparison beyond SLD/BKM or whether an additional Petz metric witnesses the gap. Until that is checked, report the all-metrics implication as unresolved, not as proved or refuted.

## Primary references

- F. Buscemi, “Comparison of quantum statistical models: equivalent conditions for sufficiency,” *Communications in Mathematical Physics* 310 (2012), 625–647, [arXiv:1004.3794](https://arxiv.org/abs/1004.3794).
- E. Shmaya, “Comparison of Information Structures and Completely Positive Maps,” *Journal of Physics A* 38 (2005), 9717–9727, [arXiv:quant-ph/0410233](https://arxiv.org/abs/quant-ph/0410233).
- D. Petz, “Sufficient subalgebras and the relative entropy of states of a von Neumann algebra,” *Communications in Mathematical Physics* 105 (1986), 123–131, [DOI](https://doi.org/10.1007/BF01212345).
- D. Petz, “Sufficiency of Channels over von Neumann Algebras,” *Quarterly Journal of Mathematics* 39 (1988), 97–108, [DOI](https://doi.org/10.1093/qmath/39.1.97).
- D. Petz, “Monotone metrics on matrix spaces,” *Linear Algebra and its Applications* 244 (1996), 81–96, [DOI](https://doi.org/10.1016/0024-3795(94)00211-8).
- D. Petz and C. Sudár, “Geometries of quantum states,” *Journal of Mathematical Physics* 37 (1996), 2662–2673, [DOI](https://doi.org/10.1063/1.531535).
- C. Hirche, C. Rouzé, and D. Stilck França, “On contraction coefficients, partial orders and approximation of capacities for quantum channels,” *Quantum* 6 (2022), 862, [arXiv:2011.05949](https://arxiv.org/abs/2011.05949).
- L. Gao, H. Li, I. Marvian, and C. Rouzé, “Sufficient statistic and recoverability via Quantum Fisher Information metrics,” [arXiv:2302.02341](https://arxiv.org/abs/2302.02341).
- C. Zhu and X. Wang, “Quantum incapacity from observable shadows,” arXiv:2607.24693v3 (5 Oct 2026), [arXiv](https://arxiv.org/abs/2607.24693).
- C. Hirche, “Quantum estimation, channel orders, and private capacity,” arXiv:2610.03706v1 (2 Oct 2026), [arXiv](https://arxiv.org/abs/2610.03706).
