# Lit03: complete Fisher orders, Petz divergences, and resolvent filters

**Scope checked (11 Oct 2026).** I read Sections 1–2 of `work/manuscript/channel_order_undecidability.txt`, the proposed general fixed-generator argument in `work/investigations/root_universality.tex`, and the order-two endpoint note in `work/investigations/rld_finite_cutoff.md`. I checked primary papers on complete measured-χ²/SLD and relative-entropy order, Petz quasi-entropies and operator-convex representations, integral f-divergences, quantum Rényi divergences, and Chernoff distance. This is a targeted priority check, not an exhaustive review; the novelty verdict stays unresolved.

## Exact orders and the manuscript's bridge

For channels (P,Q:A\to B) with a common finite-dimensional input, the manuscript's complete SLD order compares

\[
 g_{(P\otimes\mathrm{id}_R)(\rho)}((P\otimes\mathrm{id}_R)(H))
 \ \geq\
 g_{(Q\otimes\mathrm{id}_R)(\rho)}((Q\otimes\mathrm{id}_R)(H)),\qquad
 g_A(K)=\sum_{ij}\frac{2|K_{ij}|^2}{a_i+a_j},
\]

for **every finite untouched quantum reference** (R), every faithful state ρ on (RA), and every traceless Hermitian tangent (H). The complete Umegaki order compares output relative entropies for every such (R) and every pair of input states. The manuscript does not require equal reference marginals for that pair. These quantifiers are central: a theorem for no reference, a classical reference, or a reference constrained to have equal marginals is not the same order.

The manuscript's Section 2 proves SLD ⇒ relative entropy by adjoining a coherent qubit to ρ,σ and using the exact identity

\[
 g_{\operatorname{diag}(\rho,s\sigma)/(1+s)}
 \!\begin{pmatrix}0&X\\X&0\end{pmatrix}
 =4(1+s)D_{f_s}(\rho\Vert\sigma),\qquad
 f_s(x)=\frac{(x-1)^2}{x+s},\quad X=\rho-\sigma.
\]

The positive representation (x\log x-(x-1)=\int_0^\infty \frac{s}{(1+s)^2}f_s(x)\,ds) then yields the relative-entropy comparison. In the reverse direction, the manuscript fixes an arbitrary original state/tangent, appends a finite center-and-leaf reference with a rank-one numerator, and differentiates a **denominator** perturbation at a saturated pair. The Hessian is a positive integral of resolvent terms weighted by |F(t)|². Realizable finite-resolvent filters concentrate that integral at an interior spectral point and recover (2/(a_i+a_j)), the SLD kernel. This is a nonlinear finite-reference isolation argument; it is not the ordinary Hessian of Umegaki relative entropy.

The proposed root extension asserts the same reverse for one fixed Petz (D_f) whenever (f) is finite at zero and has nonzero interior resolvent mass, and then specializes to each fixed standard Petz Rényi order (0<\alpha<2). It also reduces complete quantum Chernoff order to the α=1/2 case with a finite untouched binary flag. These are proposed internal results, not literature-established theorems in the sources checked here.

## Primary-source map

1. **The closest direct predecessor is one-way: complete SLD/measured-χ² ⇒ complete BKM/relative entropy.** Hirche, *Quantum estimation, channel orders, and private capacity*, arXiv:2610.03706v1 (2 Oct 2026), states the hierarchy in Eq. (1.9): complete measured-χ² ⇒ complete quantum-χ² ⇔ complete relative entropy ⇔ complete less-noisy. The paper's Section 2, Eq. (2.4) and following display identify the SLD quadratic form with measured χ²; Section 3.1 defines all complete comparisons over every finite reference and every pair of states. Proposition 3.5 supplies a coherent-qubit identity integrating measured-χ² into the quantum-χ². Section 3.2, Eqs. (3.13)–(3.15), identifies that quantum-χ² as BKM, the Hessian metric of relative entropy. The proof explicitly applies the construction at each fixed reference. The displayed result gives the forward direction only; Figure 2 also warns that nested channel classes do not by themselves imply strictness of every inclusion. **Overlap:** it establishes the manuscript's SLD ⇒ Umegaki direction and the complete entropy/less-noisy equivalence. **Gap:** it does not give Umegaki/less-noisy ⇒ SLD. [Hirche, arXiv:2610.03706v1](https://arxiv.org/abs/2610.03706).

2. **Hirche–Rouzé–Stilck França (HRSF) is the nearest Petz-f/order predecessor, but its arrows do not reverse from relative entropy.** In *On contraction coefficients, partial orders and approximation of capacities for quantum channels*, *Quantum* 6, 862 (2022), Proposition 2.3 identifies pairwise Umegaki relative-entropy order with ordinary less-noisy order; applying that statement to (P\otimes\mathrm{id}_R,Q\otimes\mathrm{id}_R) yields the complete version. Lemma 3.1 gives tensorization, and the discussion at p. 4 says no general reference-dimension restriction was known.

   The key near-miss is §6.2, Eq. (6.21), and Proposition 6.7. Its premise (i) is a **simultaneous family** of quadratic/resolvent comparisons, including the χ² kernels for every (t\geq0). It proves (i) ⇒ (ii) all Petz (D_g) comparisons ⇒ (iii) all corresponding monotone χ² metrics; complete and regularized analogues are called straightforward extensions. If (ii) is known only for one given (g), the proposition yields only that (g)'s associated (k)-metric through Eq. (6.23). The text immediately before Proposition 6.7 says that equivalence of less-noisy order with quantum-χ² ordering seemed unlikely in the quantum setting. Thus Prop. 6.7 does **not** prove that complete Umegaki order implies all Petz f-orders, nor that one arbitrary Petz f-order implies SLD. It is a stronger-premise all-f theorem, not a subsumer of the proposed converse. [HRSF, arXiv:2011.05949v4](https://arxiv.org/abs/2011.05949).

   One exact special overlap is worth separating from the generic claim. For (g_1(x)=(x-1)^2/(x+1)), Eq. (6.23) gives (k(w)=2/(1+w)), the SLD/Bures metric kernel. Hence a **single (D_{g_1}) order** yields SLD by its local Hessian (or via Prop. 6.7(ii)→(iii)); conversely the manuscript's coherent-qubit identity at (s=1) gives this divergence from complete SLD order. This special-generator equivalence does not cover (D_{f_s}) for general (s), arbitrary operator-convex (f), or fixed Rényi α.

3. **Hessian geometry explains why relative entropy alone is not the elementary reverse.** Lesniewski–Ruskai, Theorems 2.5 and 2.8, give resolvent representations and identify the mixed Hessian of relative entropy with the Kubo–Mori/BKM monotone metric. Petz–Sudár, Theorems 3.1–3.4, classify the monotone metrics and identify SLD/Bures as the smallest Fisher-adjusted monotone metric, while the scalar entropy Hessian yields Kubo–Mori/BKM. In eigenvalues, the respective kernels are (2/(a_i+a_j)) and ((\log a_i-\log a_j)/(a_i-a_j)). They are distinct away from the commuting/diagonal directions. So simply taking a local Hessian of the assumed Umegaki comparison gives BKM; it cannot by itself deliver SLD. [Lesniewski–Ruskai, arXiv:math-ph/9808016](https://arxiv.org/abs/math-ph/9808016); [Petz–Sudár, arXiv:quant-ph/0102132](https://arxiv.org/abs/quant-ph/0102132).

4. **Operator-convex representations provide the kernel decomposition, not the order converse.** Hiai–Mosonyi–Petz–Bény, *Quantum f-divergences and error correction*, Theorem 8.1, represent continuous operator-convex (f:[0,\infty)\to\mathbb R) uniquely by an affine part, a nonnegative quadratic endpoint (b x^2), and a positive interior measure over resolvents (x/(1+t)-x/(x+t)). Corollary 8.2 states that a non-polynomial operator-convex function has nonzero interior measure; the representation of (x\log x) is given in Example 8.3. This substantiates the endpoint/interior-measure split used by the candidate theorem, but Theorem 8.1 is a representation theorem, not a channel-order theorem. The pure quadratic generator has no interior measure and is outside the proposed localization argument. [Hiai–Mosonyi–Petz–Bény, arXiv:1008.2529v6](https://arxiv.org/abs/1008.2529).

5. **A recent Petz-χ² mixture representation overlaps the kernel language.** Salazar, *Universal Thermodynamic Uncertainty Relation for Quantum f-Divergences*, arXiv:2511.10817v1, Eqs. (3)–(4) and Sec. II, represents each Petz f-divergence as a positive mixture of χ² contrasts generated by (f_\lambda(u)=(u-1)^2/((1-\lambda)u+\lambda)). It identifies Pearson χ² as an endpoint atom, while canonical smooth generators have interior weights. This gives a primary-source overlap for decomposing f-divergences and recognizing endpoint cases. A positive mixture comparison alone only controls the weighted integral of channel differences; it does not imply pointwise comparison at one resolvent parameter or isolate the SLD kernel. The saturated reference and coherent-filter concentration in the internal proof candidate are the additional step; priority for that step remains open. [Salazar, arXiv:2511.10817v1](https://arxiv.org/abs/2511.10817).

6. **The apparent all-f equivalence in Hirche–Tomamichel uses a different quantum divergence.** Their *Quantum Rényi and f-divergences from integral representations*, Proposition 4.8, proves that ordinary less-noisy order is equivalent to pairwise order for each nonlinear operator-convex **hockey-stick-integral** quantum f-divergence defined in that paper. Applying the theorem to (P\otimes\mathrm{id}_R,Q\otimes\mathrm{id}_R) gives its complete-reference analogue. But the authors explicitly distinguish this new divergence from the standard Petz f-divergence and say that different orders for Petz f-divergences were not known equivalent (Prop. 4.8 discussion, citing HRSF Prop. 6.7). It therefore does not imply the proposed fixed Petz-α result. [Hirche–Tomamichel, arXiv:2306.12343v3](https://arxiv.org/abs/2306.12343).

7. **Chernoff literature supplies the scalar facts for the flag reduction, not a channel-order theorem.** Audenaert et al., *The Quantum Chernoff Bound*, Eq. (2) define (C(A,B)=-\log\min_{0\leq u\leq1}\operatorname{Tr}A^uB^{1-u}); §IV proves convexity in (u) by writing the trace as a positive spectral sum of exponentials and computes its infinitesimal metric. The proposed complete-order reduction appends an untouched classical bit and swaps the two states across the bit. Its overlap becomes ½((Q_u+Q_{1-u})), symmetric and convex, so its minimum is at (u=1/2) and the flagged Chernoff divergence is (D_{1/2}/2). The cited paper does not state this channel-order equivalence; it is an elementary consequence combined with the proposed fixed-α converse. [Audenaert et al., arXiv:quant-ph/0610027](https://arxiv.org/abs/quant-ph/0610027).

## Nearest-predecessor verdict by claim

| Candidate claim | Closest prior theorem | Exact gap / priority status |
|---|---|---|
| Complete SLD/measured-χ² order ⇒ complete Umegaki/BKM order | Hirche 2026, Eq. (1.9), Theorem 3.2, Proposition 3.5 | Established direction. The output quadratic form on the entropy side is BKM, not SLD. |
| Complete Umegaki order ⇒ complete SLD order, arbitrary finite references | HRSF Prop. 2.3 gives entropy↔less-noisy; HRSF Prop. 6.7 gives a stronger all-resolvent-premise ⇒ all-f conclusion; Hirche 2026 gives the reverse-direction *forward* implication from SLD | No matching reverse theorem found. Standard Hessian gives BKM only. Proposed saturated-reference filtering is the candidate missing step. Priority unresolved. |
| Complete order for one fixed (D_f) with finite (f(0)) and nonzero interior resolvent mass ⇔ SLD | HRSF Prop. 6.7: all-resolvent premise ⇒ all (f), or one given (D_g) ⇒ its own metric only | No theorem found converting a single generic Petz divergence order into SLD. Hiai et al. and Salazar provide representations, not this order implication. Candidate reverse localization is priority-unresolved. |
| One fixed Petz Rényi (D_\alpha) for each (0<\alpha<2) ⇔ SLD | HRSF Prop. 6.7 plus standard Petz generator representations | No exact predecessor found. For generic fixed α, the local metric is its associated monotone metric, not SLD; the argument must exploit the complete nonlocal pairwise order. The α=1 case is the manuscript's relative entropy order. |
| Complete quantum Chernoff order ⇔ SLD | Audenaert et al. Eq. (2), §IV convexity and local metric | No channel-order equivalence found. The finite flag reduction makes the reverse conditional on fixed-α=1/2 theorem; priority unresolved. |
| Pure quadratic / Petz (D_2) endpoint | Hiai representation isolates (b x^2); internal `rld_finite_cutoff.md` proves a finite reference cutoff for order-two comparison on finite measurement pairs | This endpoint has no interior resolvent mass, so it is expressly excluded from the proposed fixed-f universality theorem. If the internal cutoff and SLD hardness proofs both survive review, they imply these order classes differ on that measurement-channel input class; no contradiction with the stated (0<\alpha<2) range. |

## Overall conclusion

The strongest confirmed overlap is the complete implication **SLD/measured-χ² ⇒ BKM/relative entropy**, proved in Hirche's Oct. 2026 preprint. The manuscript's intended reverse is not obtained by that result, by the classical less-noisy/f-divergence equivalence, by HRSF's all-resolvent-to-all-f proposition, or by the ordinary BKM Hessian. HRSF's explicit premise direction matters: its all-f conclusion starts from simultaneous resolvent-χ² order, not from relative entropy order. The newer Hirche–Tomamichel equivalence concerns a distinct hockey-stick-integral divergence, not Petz's quasi-entropy.

Thus the candidate reverse and its fixed-Petz-α/Chernoff corollaries are not subsumed by the exact predecessors checked here. This is a supported *gap assessment*, not a firstness claim and not proof validation. The positive-resolvent-mixture literature creates real methodological overlap; whether the finite coherent filter localization is novel needs a broader historical check. No contradiction was found. The α=2 quadratic endpoint is a meaningful excluded boundary rather than a counterexample to the stated open interval.

## Primary source links

- [Hirche 2026, arXiv:2610.03706v1](https://arxiv.org/abs/2610.03706)
- [Hirche–Rouzé–Stilck França 2022, arXiv:2011.05949v4](https://arxiv.org/abs/2011.05949)
- [Hiai–Mosonyi–Petz–Bény 2011, arXiv:1008.2529v6](https://arxiv.org/abs/1008.2529)
- [Lesniewski–Ruskai 1999, arXiv:math-ph/9808016](https://arxiv.org/abs/math-ph/9808016)
- [Petz–Sudár 2001, arXiv:quant-ph/0102132](https://arxiv.org/abs/quant-ph/0102132)
- [Salazar, arXiv:2511.10817v1](https://arxiv.org/abs/2511.10817)
- [Hirche–Tomamichel 2024, arXiv:2306.12343v3](https://arxiv.org/abs/2306.12343)
- [Audenaert et al. 2007, arXiv:quant-ph/0610027](https://arxiv.org/abs/quant-ph/0610027)
