# ASTRA research checkpoint — 12 October 2026

## Retained objective and actual advance

High-precision transport for the same nonperturbative, finite-range, number-conserving one-dimensional Hamiltonians with pure on-site dephasing and tracial response. A full derivation now gives a randomized polynomial-time **finite-volume scalar** approximation at fixed physical bounds. It does not produce the previous exact rational f,g witness pair or establish thermodynamic precision.

## Decisive mechanism

Add artificial complete occupation measurements at Poisson rate r, represented by r(P-I). They restart every trajectory in a sampled product occupation state without destroying the ensemble's classical population correlations. This global numerical operation is not asserted to exist in the target physical device.

With B=S+A, Q=I-P and K=ker(PA|Q), the response exactly compresses to <j,(C+rI)^-1j>/n on K, Re C>=d. Hence it is analytic on Re r>-d with a size-independent bound a/(d+Re r). Rational nodes in [d/8,d/4], O(log(1/epsilon)) interpolation order, and explicitly paid polynomial weight amplification remove the artificial measurements while keeping physical d.

Positive-rate nodes are estimated using random exponential stopping. A self-contained adjacent-swap comparison yields population coercivity sigma=t_min/(2n^2) and a polynomial full inverse bound Rcal. It sets a paid Laplace bias/time budget. All long times, excessive events, and long coherent intervals are truncated with their bounded-payoff bias charged. Retained coherent intervals are logarithmic. Osborne's constructive 1D short-time block representation gives polynomial classical trajectory sampling; no compact high-precision response operator is assumed.

## Preserved failures

The full coherence-eliminated population Schur complement is not generally Markov: an exact four-site offdiagonal is 115904/10076409>0 in negative-generator convention. This does not invalidate the previous bare-S exclusion correction. Ordinary scalar regularization damps populations and does not supply the protected analytic domain. Integrator time steps do not reset entanglement. Generic extrapolation without a complex-domain bound is insufficient.

## Exact next theorem

Constructive quantitative finite-size/DC transfer to the infinite-chain coefficient, e.g. |D_n-D|<=C n^-p uniformly over the fixed physical class, or an alternative polynomial-cost thermodynamic procedure. The previous existence proof uses a different order of limits and is not such a rate. Gaussian hydrodynamics and finite-temperature/zero-physical-noise extensions are separate.

## Computational/physical boundary

Polynomial degree depends on G/d and may be enormous. A conservative n=8, kappa-error=.01 calculation exceeds 10^74 samples per node. No practical superiority is established. Full local coefficients are inputs; the earlier Xi statistic alone is insufficient. Calibration transfer within the structural model is explicit but acquisition is not free. No experimental operations or state preparation are required by the model-supplied classical algorithm.

## Evidence and provenance

Exact symbolic/rational block checks and a Markov-sign counterexample; floating interacting n=5,6,7 reconstructions; a 16,000-trajectory synthetic diagnostic. No implemented production block/MPS compiler, independent review, formal verification, historical-priority clearance, or physical experiment. Astra revision ac6ce52c80d55173ca38f9cb99cd3ba7f50fb132 read; openai/math fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb source inspected but no unreviewed theorem imported. No external writes.
