# CRAY relative-energy research package

Read **RESEARCH_NOTE.md** for the theorem, complete converse proof, scientific scope, benchmark failures, resource accounting, and prior-art limitations.

## Main rigorous output

For the local spin motif

```
hweak   = S0.S1 + S0.S2 + S1.S3
hstrong = 2*S0.S1 + S0.S2 + S1.S3
```

and any common Hamiltonian on sites 2,3 and any additional environment,

```
-0.75 <= Estrong - Eweak <= -0.22421.
```

The upper bound is certified by exact rational unital-Choi and residual positivity checks. A rational four-spin counterenvironment places the sharp uniform upper endpoint within 0.00000874 of the certificate. On the tested kagome patch, no improvement on [-0.75,0.25] is possible with the same unrestricted-environment input contract.

This package does not establish a molecular chemical-accuracy calculation, a quantum-hardware advantage, or historical novelty. General analytical theorems are not proof-assistant formalized. Only the identified finite certificates are machine-checked by exact arithmetic.

## Reproduce exact certificate checks

Python with NumPy, SciPy, and SymPy is required. Tested versions are recorded in requirements.txt.

```bash
python rational_verify.py --verify-only
python exact_certificate.py
python verify_environment.py
python kagome_adversary.py
```

`rational_verify.py --verify-only` reads the already supplied rational fixture and does not need to trust the floating-point optimizer.

## Reproduce discovery diagnostics

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python symmetric.py --system chain --reverse --iter 160
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python symmetric.py --system chain --iter 160
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python symmetric.py --system kagome --reverse --iter 160
python extremal_chain.py
python rational_verify.py
```

The original unsymmetrized cutting-plane experiment is retained in experiment.py. It converges much more slowly and its floating-point output is not a formal certificate. The symmetry-reduced solver applies to the stated isotropic two-spin active region; it is not a general-purpose SDP implementation.

## Files

- `rational_chain_certificate.json`: exact rational Choi and local Hamiltonian matrices.
- `rational_chain_verification.json`: exact-check receipt.
- `exact_amplitude_certificate.json`: symbolic spectrum of a simple analytic channel.
- `rational_environment_fixture.json`: exact data for a near-extremal environment.
- `kagome_adversary.json`: explicit failure witness and analytical bounds.
- `sym_*.json`, `sym_*.npz`: floating-point control runs and optimizer history.
- `SHA256SUMS.txt`: package file checksums.

The benchmark graphs are canonical small lattice controls assembled by the included code, not externally supplied molecular data. No external research repository was modified.
