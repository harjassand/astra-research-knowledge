# Hamiltonian-referenced noise for nearly optimal kinetic transport

**ASTRA FRONTIER — research attempt, 13 October 2026**

## Status and main result

This packet supplies a candidate reservoir-design construction, self-contained proofs of its kinetic comparison and pulse-cost bounds, exact rational checks, and finite floating-point quantum diagnostics. It does **not** establish a civilization-changing capability, an experimentally available material interface, historical novelty, or a volume-uniform finite-hopping quantum-transport theorem. No independent reviewer has checked these proofs. No experiment was performed. Nothing was committed to Astra.

The construction uses a physical diagonal interaction/disorder operator as its own reference. A common non-Gaussian phase process generates different dephasing widths for different, possibly configuration-dependent energy differences without estimating those differences individually. In the weak-hopping kinetic limit, one explicit law delivers at least 97% of every transition's independently optimized rate. Consequently it delivers at least 97% of the corresponding reversible capacities and variational transport coefficients on **every finite configuration graph**, including exponentially large interacting-particle configuration spaces.

The independently optimized transition rates are an upper benchmark, not assumed physically realizable controls. This is stronger than comparison with one uniform dephasing strength, but it does not include controls that change coherent detunings, hopping amplitudes, bath temperature, memory, or the observable being optimized.

A further obstruction places the best universal symmetric independent-increment phase law below 0.972849 of this edgewise benchmark. The 0.97 construction is therefore within 0.002849 of that class's unknown optimal competitive ratio. This is not an optimality theorem against arbitrary physical controllers.

Most importantly, if the same actuator can simply cancel the diagonal Hamiltonian and the task permits doing so, that direct controller dominates the proposed noise law. A genuine application needs a physical or functional reason why the diagonal Hamiltonian must remain, not a restriction invented to rescue this construction.

## 1. Scientific task and alternatives examined

The intended target is solver-free design of macroscopic particle/excitation transport in disordered interacting matter. The immediate bottleneck is simultaneous control of many differently detuned hopping processes, whose detunings change with neighboring occupation. Existing work already establishes noise-assisted transport, optimized dephasing, spatial/temporal noise engineering, and strong-interaction transport calculations [1–4]. None of those general ideas is claimed here as new.

Three approaches were considered. Trajectory reweighting would require acquiring an effective change of path measure rather than merely writing its optimal expression. Adding noise to make quantum computation easier would change the physical target unless accompanied by a controlled correction. Hamiltonian-referenced noise instead changes an actual actuator operation: it uses a physical operator, not a supplied loss table, to generate configuration-dependent control. This third approach produced the concrete results below. The first two did not produce a new constructive result in this investigation.

Astra was inspected at commit `f437df815bef12f123ae4fe313d861ec1c862bc4`. In particular, dossier N765 retains a known-model transport-design certificate and explicitly distinguishes tighter regret bounds from runtime advantage. Those proofs are not premises of this packet. The OpenAI mathematical repository was consulted for orientation; no theorem from it is imported here.

## 2. Exact model and access contract

Set hbar=1. On a finite occupation basis Omega, let

    H_epsilon = D + epsilon T,
    D|x> = E_x |x>,
    Delta_xy = E_x - E_y.

T is Hermitian and connects allowed particle hops. D may contain finite-range diagonal many-body interactions as well as disorder. No low-rank representation of the many-body state is assumed. For hard-core particles on n sites, one may work in any fixed-particle-number sector.

The baseline dephaser is

    D_0(rho) = (eta/4) sum_i (Z_i rho Z_i - rho),    eta > 0.

A matrix element between bit strings at Hamming distance r decays at eta r/2. Every single-particle hop changes two bits, so its baseline width is exactly eta. Every off-diagonal element in a fixed-number sector has width at least eta.

The required additional operation is a common random diagonal phase

    U_s = exp(-i s D).

This must act through the actual D, while the hopping term is not multiplied by the same noise. It is **not** modulation of the full Hamiltonian. If the actuator instead modulates D+epsilon T, the theorem does not describe that system.

The physical access requirement is substantial. It can be native common modulation, or compiled commuting diagonal gates when their local coefficients are known. The latter requires local coefficient acquisition and O(n) spatial actuation, not a constant-size physical device. Generic materials are not assumed to offer either access mode. Uniform baseline dephasing, independent control of D versus T, and their calibration are parts of the contract, not conclusions.

## 3. A valid common phase process

Define

    A = 32/25,      m = (15/4) eta,
    psi(omega) = A (sqrt(m^2 + omega^2) - m).

Use a symmetric independent-increment process X_t satisfying

    E exp(i omega X_t) = exp[-t psi(omega)].

This is a scaled symmetric normal-inverse-Gaussian / relativistic-Cauchy exponent, not a new probability distribution [5]. Fractional completely positive semigroups also have prior literature [6].

### Complete positivity without independently assigning linewidths

The integral identity

    psi(omega) = A/(2 sqrt(pi)) * integral_0^infinity
                 (1-exp(-s omega^2)) exp(-m^2 s) s^(-3/2) ds

follows by differentiating in omega^2 and integrating back from zero. For each s>0, exp(-s ad_D^2) is a Gaussian average of unitary phases exp(-iuD), with u of variance 2s. A positive mixture of the generators exp(-s ad_D^2)-I therefore generates a completely positive, trace-preserving, unital phase semigroup. Equivalently, it has symmetric Levy density

    nu(u) = A m K_1(m|u|)/(pi |u|),    u != 0.

Here the defining integral can be written

    nu(u) = A/(4 pi) * integral_0^infinity
            s^(-2) exp[-m^2 s - u^2/(4s)] ds.

Thus nu(u) <= A/(pi u^2), and integral u^2 nu(u)du=A/m. The ideal process has finite variance but infinite absolute jump variation at small u. It is not a free bounded-bandwidth laboratory signal.

All populations are unchanged by the noise, and particle number is conserved. On an allowed hopping coherence, the total linewidth is

    gamma_M(Delta) = eta + psi(Delta).

No transition table is supplied or acquired to evaluate this expression physically. The unknown operator appears in the actuator itself. This is an operator-access advantage, not an information-theoretic statement that a detailed Hamiltonian can never be learned.

## 4. Weak-hopping reduction: exact scope

At each fixed finite volume, write L_epsilon=L_0+epsilon V, with V=-i[T, .]. Let P project onto diagonal matrices and Q=I-P. Then PL_0=0, PVP=0, and

    L_0 |x><y| = -(gamma_xy + i Delta_xy)|x><y|,    x != y.

Q L_0 Q is invertible because gamma_xy>=eta. The usual finite-dimensional singular perturbation on slow time tau=epsilon^2 t gives the population generator

    K = -P V Q (Q L_0 Q)^(-1) Q V P.

This can also be derived directly: solve the fast off-diagonal equation to first order,

    rho_xy = -i epsilon T_xy (p_y-p_x)/(gamma_xy+i Delta_xy) + O(epsilon^2),

and substitute into the population equation. The resulting transition rates in physical time, to second order, are

    q_xy(gamma) = 2 epsilon^2 |T_xy|^2 gamma/(gamma^2+Delta_xy^2).       (1)

For fixed finite Omega the scaled semigroup converges on compact slow-time intervals; constants in elementary remainder estimates depend on Omega and ||T||. Equation (1) is not asserted to be an exact finite-epsilon quantum generator, a uniform-in-volume approximation, or a license to exchange weak-hopping, long-time and thermodynamic limits.

The kinetic comparison theorems below are exact statements about the rates (1).

## 5. The 97% edge theorem

For each edge, allow an oracle to choose gamma independently subject only to gamma>=eta. Differentiating (1) gives

    gamma_*(Delta) = max(eta, |Delta|).

Let q_* use this linewidth and q_M use gamma_M. Then, on every edge,

    0.97 q_* <= q_M <= q_*.                                      (2)

The upper inequality follows from the definition of the edge oracle. Here is a proof of the lower inequality for every real detuning.

Normalize x=|Delta|/eta and write

    g(x) = gamma_M/eta = (8 sqrt(225+16x^2)-95)/25.

### Low detunings: 0<=x<=1

The ratio to the oracle is

    R(x)=g(x)(1+x^2)/(g(x)^2+x^2).

Set t=sqrt(225+16x^2)-15>=0. The inequality R>=97/100 is equivalent to

    P(t) = 2t^3 + (502547/10000)t^2 - (4891/200)t + 3 >= 0.

The cubic term is nonnegative. Completing the square in the remaining quadratic gives minimum

    3 - (4891/200)^2/[4(502547/10000)]
      = 200375/8040752 > 0.

This proves the inequality throughout the low-detuning interval without a grid argument.

### High detunings: x>=1

Put r=g(x)/x. Direct differentiation, or minimization after z=1/x, gives

    sqrt(688/1125) <= r <= 32/25.

For completeness, r=A sqrt(1+B^2 z^2)-(AB-1)z, B=15/4, on z in [0,1]. It is convex. Its unrestricted minimum is sqrt(A^2-(A-1/B)^2)=sqrt(688/1125). Its endpoint maximum on this interval is A; the other endpoint is smaller than A.

The rate ratio is R=2r/(1+r^2). The two endpoint checks are

    2(32/25)/(1+(32/25)^2) = 1600/1649 > 97/100,

and

    [2 sqrt(688/1125)/(1+688/1125)]^2 - (97/100)^2
      = 32908679/32869690000 > 0.

Since 2r/(1+r^2) increases to r=1 and decreases thereafter, these checks prove (2).

The number 0.97 is a proved convenient guarantee, not a claim that this particular formula attains exactly 0.97. A dense numerical diagnostic finds its minimum close to 1600/1649, but the theorem needs only the exact rational inequalities above.

## 6. Why the comparison is global and many-body

Both rate systems are symmetric, with the same uniform stationary measure pi on each connected configuration sector. Their Dirichlet forms obey

    0.97 E_*(f,f) <= E_M(f,f) <= E_*(f,f).

Taking an infimum over potentials with specified boundary values proves the same comparison for every reversible capacity between two sets. Taking the variational infimum that defines the spectral gap gives the corresponding gap comparison. On mean-zero functions in a connected sector, inverse quadratic forms are bounded in the reverse order, with factor at most 1/0.97.

For an antisymmetric displacement label d_xy, a reversible finite-state Markov additive process has directional transport form

    C_q(v)= (1/2) inf_f sum_x pi_x sum_y q_xy
                      [v.d_xy+f(y)-f(x)]^2.                       (3)

Applying (2) inside this infimum gives

    0.97 C_*(v) <= C_M(v) <= C_*(v)                               (4)

for every direction and every finite configuration graph. Normalization per physical volume does not change the comparison. Finite periodic interacting exclusion systems are included. A thermodynamic variational limit inherits the inequalities when that limit exists; existence or a quantum hydrodynamic limit is not assumed proved.

For simple exclusion hops on a periodic lattice with |T_xy|>=T_min and local hop detunings bounded by W, the oracle rates satisfy

    q_* >= epsilon^2 T_min^2/max(eta,W).

Therefore the matched rates dominate a constant-rate symmetric exclusion process. On a one-dimensional n-site ring in the K-particle sector, the associated current coefficient is at least

    0.97 epsilon^2 T_min^2/max(eta,W) * K(n-K)/[n(n-1)].            (5)

This follows directly from (3): constant-rate exclusion has zero configuration-wise total signed drift, so the cross term in f vanishes and a constant corrector minimizes the form. Equation (5) is a volume-independent positive bound at fixed nonzero density.

This absolute bound is not itself a unique new advantage: setting one sufficiently large uniform dephasing strength also gives a standard positive comparison bound. The distinctive candidate contribution is nearly optimal **configuration-adaptive** broadening without evaluating the exponentially many conditional responses.

These statements do not establish monotonicity of every individual first-passage time or arbitrary driven nonequilibrium current. They do not address finite-temperature detailed balance or selected pure quantum phases.

## 7. An upper obstruction for universal symmetric phase laws

Let phi be any symmetric Levy characteristic exponent, including a Gaussian part. The elementary inequality

    1-cos(4z) <= 16(1-cos z)

implies phi(4w)<=16 phi(w). Consider detunings w=(2/3)eta and 4w=(8/3)eta, and write t=phi(w)/eta.

If t>=69/1000, the rate ratio at w is at most

    13897000/14284849 = 0.972848925459415... .

Indeed, at a detuning below eta the rate decreases when gamma increases above eta.

If t<=69/1000, then gamma(4w)/eta<=1+16(69/1000)=2.104, still below the optimal 8/3. The rate ratio at 4w is consequently at most

    1578000/1622521 = 0.972560601680964... .

Thus no universal symmetric independent-increment phase law with fixed coherent detunings and baseline eta can guarantee an edge ratio greater than 13897000/14284849 for all detunings. The 0.97 construction comes within 0.002849 of this upper bound.

This obstruction is scoped to a **single universal symmetric phase law** and the edgewise guarantee. It does not bound adaptive controllers supplied with additional information, asymmetric noise that changes coherent phases, coherent refocusing, modified hopping, or arbitrary laboratory control.

## 8. Finite-rate pulse construction and cost

The ideal infinite-jump process is not an implementation. Fix a local hop-gap bound W>=eta and an allowed relative linewidth error delta in (0,1/2). Let c_l=3/4; Section 5 implies gamma_M(w)>=max(eta,c_l|w|).

Keep only jumps whose absolute phase lies in [a,b], where

    a = pi delta c_l/(2 A W),
    b = 8 A/(pi delta eta).

The omitted small-jump exponent is at most A w^2 a/pi. The omitted large-jump exponent is at most 4A/(pi b). Consequently, for every allowed hop |w|<=W,

    0 <= psi(w)-psi_[a,b](w) <= delta gamma_M(w).

The remaining process is a finite-rate compound Poisson sequence of the same physical gates exp(-isD). Its hop rates obey

    q_[a,b] >= (1-delta) q_M >= 0.97(1-delta)q_*.                  (6)

The first inequality follows directly by comparing the Lorentzian at linewidths differing by a factor in [1-delta,1].

### Acquired pulse distribution, not an unspecified compiler

An envelope Levy density A/(pi s^2) on the signed interval gives proposal rate

    Lambda_env = (2A/pi)(1/a-1/b)
               <= 4A^2 W/(pi^2 delta c_l).

Generate an exponential proposal clock. Draw a random sign and uniform u in [0,1], then set

    |s| = [1/a - u(1/a-1/b)]^(-1).

Accept the pulse with probability m|s|K_1(m|s|), which lies in [0,1]. This is an explicit thinning sampler. Evaluating an ordinary one-variable special function is required; no many-body diagonalization is required. A floating implementation of finite truncation checks is included, not an interval-certified laboratory random-number generator.

The expected absolute phase delivered per unit target time is

    V_[a,b] = (2A/pi)[K_0(ma)-K_0(mb)]
            <= (2A/pi)log(b/a).

For eta=1, W=10 and delta=.01, the executed diagnostic gives a proposal rate 885.36, expected absolute phase 4.714 per target-time unit, and conservative phase bound 10.412. These are dimensionless model costs, not measured hardware specifications. A controller with bounded coefficient magnitude M requires at least |s|/M time to implement an isolated phase s. Pulse duration, overlap, continuing background dynamics, switching power and noise generation must therefore be charged. The pulse construction does not make them vanish.

If phase s is rounded with error at most h, its exponent error is at most Lambda_env |w| h. Taking h<=delta_2 c_l/Lambda_env bounds this error by delta_2 gamma_M(w). Acceptance-probability errors of at most p_err add at most 2 Lambda_env p_err to the exponent; choosing p_err<=delta_3 eta/(2 Lambda_env) controls that contribution. Clock discretization and finite gate duration require their own budgets. The required amplitudes, rare large pulses and target duration also enter the number of stored bits and high-probability resource bounds.

### Why the leading bandwidth and phase-action costs are substantive

For any finite jump process delivering a constant-factor approximation, psi(W)<=2 Lambda forces Lambda=Omega(W) when W/eta is large. Likewise, if the rate guarantee forces gamma(w)>=r_- w for w>=eta, then psi(w)>=r_-w/2 for w>=2eta/r_-. Fubini and

    integral_0^infinity (1-cos(w s))/w^2 dw = (pi/2)|s|

give an absolute-phase lower bound

    integral |s|nu(ds) >= (r_-/pi)log[W r_-/(2eta)]

when the logarithm is positive. Thus the construction's linear dependence on local bandwidth and logarithmic dependence of phase action are not solely artifacts of an arbitrary implementation. No optimal dependence on precision delta is claimed.

### Crucial limitation of local cutoffs

W bounds **single-hop** detunings, not the extensive bandwidth of D. This is sufficient for the kinetic theorem. Higher-order quantum coherences can have much larger energy differences. The finite pulse process is completely positive on the whole Hilbert space, but a local cutoff is not asserted to approximate the ideal many-body channel in diamond norm or its finite-hopping current uniformly in volume.

## 9. Calibration, preparation and uncertainty

For finite-range D, a hop changes only the local terms touching its two sites. Known bounds on these local terms give W without enumerating configurations. An unknown uncontrolled long-range tail invalidates such a bound unless separately bounded.

Suppose the phase actuator actually couples to D+E, with E diagonal, and every allowed hop has |E_x-E_y|<=e. Since |psi'(w)|<=A, its linewidth error is at most A e. If A e<=zeta eta, the edge-rate comparison loses at most a factor 1-zeta. General small multiplicative linewidth errors can be combined with (6) by adding their error budgets.

In a programmable finite-range device, a proposed way to acquire this local mismatch bound is conditional Ramsey calibration: disable hopping during calibration, prepare the neighboring occupations, create a two-site |10>+|01> coherence, and compare native versus actuator-induced phases. It uses the system itself, not an assumed isolated sensor. It nevertheless requires those preparation, hopping-disable and readout controls. Without them, the calibration is not supplied by this packet.

If each bond's detuning depends on at most k neighboring bits, there are O(n 2^k) local contexts. Using Ramsey times of order 1/W to avoid unwrapping ambiguity gives the conservative shot scale

    O(n 2^k [A W/(zeta eta)]^2 log[n 2^k/alpha])

for failure probability alpha, under ideal bounded-outcome readout and state preparation. SPAM bias, drift, thermal occupation errors and long-range tails need additional measured budgets. This is local calibration of an actuator contract, not a general many-body identification theorem.

The stationary ensemble used in the theorem is uniform in a number sector. It can be prepared by uniformly sampling K occupied sites and preparing that product state; no Gibbs-state solver is hidden in that preparation. Actual material states at finite temperature are not covered. Selection of the proposed noise law does not require measuring a global loss table, but experimental validation of an absolute transport coefficient still requires finite-time and finite-size error control.

## 10. Two decisive adversarial tests

### 10.1 The unrestricted actuator can make the proposal unnecessary

If the actuator can add -D and doing so is allowed by the scientific task, it sets every detuning to zero. With baseline eta, its kinetic rate is

    q_cancel = 2 epsilon^2 |T_xy|^2/eta >= q_*.

For |Delta|>=eta,

    q_cancel/q_* = 2|Delta|/eta,

which is unbounded as detuning grows. No spectroscopy is needed if the same native common multiplier can simply be set to zero. This is a stronger direct controller, not a straw-man full-model-identification method.

Preserving D may be a legitimate physical or functional requirement, but it must be established independently. A material that does not permit coherent cancellation but does permit calibrated Hamiltonian-referenced reservoir coupling has not been identified and validated in this investigation. A programmable demonstration that artificially prohibits cancellation would test the mathematics; by itself it would not establish new engineering power.

### 10.2 A uniform all-observable quantum-to-kinetic theorem is false

Take N independent hard-core dimers, one particle in each, with H=J sum_i X_i, D=0 and independent dephasing eta. Choose 0<J<eta/4. For one dimer the infinite-temperature Z autocorrelation c(t) satisfies

    c''+eta c'+4J^2 c=0,  c(0)=1, c'(0)=0,

and is positive and decreasing. For the product observable Z_1...Z_N, independence gives correlation c(t)^N. Since c(t)=1-2J^2 t^2+O(t^3), Laplace scaling yields

    integral_0^infinity c(t)^N dt
       ~ sqrt(pi)/(2 sqrt(2) J sqrt(N)).

The independent kinetic flip chain instead gives

    integral_0^infinity exp[-4N J^2 t/eta]dt = eta/(4N J^2).

The ratio grows as sqrt(2pi) J sqrt(N)/eta. Hence fixed small J/eta does not give a volume-uniform approximation for all zero-frequency observable quadratic forms. This remains true in an exceptionally simple member of the physical class.

It does not disprove a volume-uniform theorem for the local current. It proves that a general norm or all-observable Schur-complement argument cannot supply that theorem. A successful extension must exploit current locality, conservation and the physical control errors specifically.

## 11. Executed diagnostics

`checks.py` performs exact rational assertions for the 97% inequality and universal upper obstruction, a 200,003-point detuning diagnostic, four numerical Levy-integral checks, and finite four-/six-site half-filled interacting-ring solves. The finite quantum generator retains the diagonal interactions and all coherences in the number sector. A sparse bordered inverse enforces trace zero. These are floating-point calculations, not interval-certified transport proofs.

The tested Hamiltonian is

    H = sum_i v_i n_i + sum_i U_i n_i n_(i+1)
        - epsilon sum_i (sigma_i^+ sigma_(i+1)^- + h.c.),

with periodic boundaries and fixed random seed 17. All fields and interactions are stored in `results.json`.

The reported quantum quantity is the zero-frequency current quadratic form

    kappa_Q = Re Tr[J(-L)^+J]/(n dim),

not a claimed independently certified thermodynamic material conductivity. The kinetic comparison uses the corresponding finite-ring displacement variational form. The scalar baseline is **numerically optimized**, using a 129-point logarithmic grid and local refinement. It is not a rigorously certified global numerical optimizer. Since every edge rate decreases above the maximum detuning, the numerical search domain is bounded without losing a scalar maximizer.

For four sites the kinetic matched/oracle ratio is about 0.98682, and matched/numerically-optimized-scalar is about 1.13861. For six sites these are about 0.98537 and 1.27710. At epsilon=.02, the full quantum current divided by its kinetic prediction differs by approximately 0.0113% and 0.0063%, respectively. At larger epsilon the discrepancies grow; no uniform error law is inferred.

Cancelling D gives kinetic current improvements of about 7.85 and 6.20 over the matched controller. The same dominance appears in the small-epsilon full quantum tests. This is a failure of an unrestricted advantage claim, not evidence to be omitted.

`additional_checks.py` tests the finite-pulse cutoff on 42 detunings and evaluates the exact product-dimer correlation formula. At J=.05, eta=1, the product observable's quantum/kinetic integrated-correlation ratio grows from 1 for one dimer to about 125.67 for one million independent dimers. The latter calculation uses the analytic product formula, not a million-dimer Hilbert-space simulation.

## 12. What remains and what should not be claimed

The surviving candidate is a constructive physical-functional-calculus principle plus a near-optimal all-configuration kinetic guarantee. It is not merely a decision-identification example, and it does not require an acquired global loss table. Its nontrivial input is instead access to the correct physical operator through a controllable reservoir or phase actuator.

The first unresolved capability requirement is an actual interface where this access is affordable and where stronger direct control cannot simply remove the bottleneck. The second is a volume-uniform, finite-hopping local-current comparison that includes pulse duration, bandwidth, mismatch and uncertainty. The dimer example narrows the needed mathematical statement rather than simply naming a missing solver.

For a real proposal, the comparison must use the native admissible control set, the same acquisition and training budget, and transport per laboratory time or another stated physical objective. It must include coherent cancellation/refocusing whenever available, direct local-noise optimization, and relevant finite-memory drives. No energy-efficiency gain follows from a particle-current improvement: the noise is unital, can exchange hopping energy with the system, and its generation/switching cost has not been experimentally measured.

The defining next statement would bound the actual local-current transport at fixed nonzero hopping and increasing system size, after physical overheads, relative to the strongest native controller. In the actuator class that allows cancellation of D, the present law fails that target and should not be promoted as an enabling technology. In a genuinely constrained reservoir-engineering class, the 97% theorem is a concrete starting mechanism, but the physical class and finite-hopping extension remain to be established.

## References and provenance

[1] C. Maier et al., *Environment-Assisted Quantum Transport in a 10-qubit Network*, Physical Review Letters 122, 050501 (2019). DOI: 10.1103/PhysRevLett.122.050501. Preprint: https://arxiv.org/abs/1809.07680 . Publisher/abstract consulted; confirms prior experimental ENAQT and spectral-noise effects, not this proposal.

[2] J. J. Mendoza-Arenas et al., *Dephasing enhanced transport in nonequilibrium strongly correlated quantum systems*, Physical Review B 87, 235130 (2013). DOI: 10.1103/PhysRevB.87.235130. Publisher abstract consulted; establishes relevant strong-interaction and matrix-product-simulation prior art.

[3] C. Uchiyama, W. J. Munro and K. Nemoto, *Environmental engineering for quantum energy transport*, npj Quantum Information (2018). DOI: 10.1038/s41534-018-0079-x. Full HTML inspected: https://arxiv.org/html/1711.01025v2 . Spatial/temporal correlation engineering is established prior art.

[4] S. Jacob et al., *Dephasing-assisted transport in a tight-binding chain with a linear potential*, arXiv:2407.21715. Abstract consulted: https://arxiv.org/abs/2407.21715 . Analytical dephasing optimization compared with exact solutions in a simpler chain is prior art.

[5] O. E. Barndorff-Nielsen, *Processes of normal inverse Gaussian type*, Finance and Stochastics 2, 41–68. DOI: 10.1007/s007800050032. Publisher abstract consulted. The NIG probability law is not claimed new. The integral representation needed here is proved directly above.

[6] V. E. Tarasov, *Fractional generalization of the quantum Markovian master equation*, Theoretical and Mathematical Physics 158, 179–195 (2009). DOI: 10.1007/s11232-009-0015-5. Publisher abstract consulted; completely positive fractional-generator methods are prior art.

[7] SciPy, *Normal Inverse Gaussian Distribution*, official documentation consulted: https://docs.scipy.org/doc/scipy/tutorial/stats/continuous_norminvgauss.html . The implementation here uses Levy-integral checks rather than distribution fitting.

[8] Astra Research Knowledge, commit f437df815bef12f123ae4fe313d861ec1c862bc4, entry and N765 dossier; https://github.com/harjassand/astra-research-knowledge . Prior research context only, no imported proof premise.

[9] OpenAI mathematical repository, README inspected; https://github.com/openai/math . Orientation only; no theorem imported or validation inferred.

The literature search was selective, not an exhaustive priority review. Novelty of the performance/cost construction and obstruction remains UNKNOWN.
