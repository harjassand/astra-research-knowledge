# Independently checked peak-rate certificate closure

Scope: exact optimization of the sufficient Poisson-pinch certificate only. No physical error lower bound, new hardware claim, external review, or canonical repository edit.

Immutable source: https://github.com/harjassand/astra-research-knowledge/blob/9dbe934e5475f415c2d160a6c0715534aafa546b/updates/GB-dots-capital-genesis-20261016/package/derived/workers/gb_finite_rate_genesis/COST_AND_INCUMBENT.md (Section 1 leaves the cap-infeasible unconstrained schedule as a lower bound only).

Let J≥0, duration τ≥0, finite cap L>0, and 0≤Λ≤Lτ. For measurable 0≤λ(t)≤L of integral Λ, set u(t)=∫₀ᵗλ(s)ds and push μ=u₍#₎(J dt) onto [0,Λ]. Its total mass is a=Jτ and its certificate is E(μ)=∫∫exp(-|u-v|)dμ(u)dμ(v).

## Rigorous measure constraint

For any nonnegative Borel function f, monotone absolutely continuous substitution gives

∫ f dμ = Jintegral_0^tau f(u(t))dt ≥ (J/L)integral_0^tau f(u(t))u'(t)dt = (J/L)integral_0^Lambda f(v)dv.

Thus μ≥d dv where d=J/L. This holds with arbitrary plateaus or singular parts of the inverse; no strictly positive rate or smooth inverse is assumed. It suffices to optimize over this larger measure class and exhibit an admissible schedule attaining the minimizer.

## Cap-active regime: Λ≤Lτ≤Λ+2

Set q=(a-dΛ)/2, so 0≤q≤d. Candidate μ*=d dv+qδ₀+qδΛ has potential

V(v)=2d+(q-d)[exp(-v)+exp(-(Λ-v))].

The bracket attains its maximum at endpoints and q-d≤0, so V is minimized at both endpoints, with equal value. Every feasible μ=d dv+ν has ν≥0 and mass 2q. Therefore ∫V d(μ-μ*)=∫V dν-2qV(0)≥0. The exponential kernel is positive definite on finite signed measures (Fourier transform 2/(1+ω²)); consequently

E(μ)-E(μ*)=2∫V d(μ-μ*)+E(μ-μ*)≥0.

This proves the global minimum without claiming all feasible measures are realizable. The minimizer is realized by rate zero for first/last h=q/J=(τ-Λ/L)/2 and rate L for the middle duration Λ/L, whenever J>0. For J=0 all certificates vanish.

The exact value is

C*=2d²(Λ-1+e^(-Λ))+4dq(1-e^(-Λ))+2q²(1+e^(-Λ)).

## Cap-inactive regime: Lτ≥Λ+2

The old unconstrained minimizer μ*=a/(Λ+2)[dv+δ₀+δΛ] satisfies μ*≥d dv and remains optimal. It is attained by endpoint holds τ/(Λ+2) and middle rate (Λ+2)/τ≤L. Its value is 2a²/(Λ+2).

## Boundary checks

- At Lτ=Λ+2, q=d and the formulas agree: 2d²(Λ+2).
- At Λ=Lτ, q=0 and the schedule is constant maximal rate L with value 2J²[τ/L-(1-e^(-Lτ))/L²].
- At Λ=0, every allowed schedule has λ=0 almost everywhere; the two endpoint atoms coincide and C*=a². The formula remains valid. If L=0, necessarily Λ=0 and this separate case applies.
- If Λ>Lτ, no admissible schedule exists.

The proof establishes the optimum within fixed total action Jτ, fixed integrated intensity Λ, fixed duration, and a peak-rate cap. It does not compare hardware acquisition costs or identify this certificate with actual error probability.
