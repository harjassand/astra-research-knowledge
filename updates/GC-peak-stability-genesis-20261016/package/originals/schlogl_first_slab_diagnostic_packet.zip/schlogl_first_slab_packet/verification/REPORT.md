# Independent challenge of the continuous-slab certification gate

## Decision and useful results

All three exported first slabs fail decisively: the original uniform-enrichment candidate, the localized-weight follow-up, and one reduced-only constrained-Galerkin test. These are rejections of the immutable candidates, not of tAMEn or every tensor-time approach.

Localized-weight repair: exact integrated residual is at least 7.17097266849711e-5, and a rigorous physical-state comparison with an outward mass enclosure gives actual augmented-state l1 error at least 1.509585413105462e-4. The detailed repair section below explains the representation-specific obstruction.

Latest constrained test: the broad enrichment direction was removed, while the localized basis and every physical parameter were held fixed. The all-50 coordinate alone gives a rigorous integrated full residual lower bound of 1.4918533657070469e-5. This exceeds the entire 1e-9 interior budget without a full residual Gram contraction. No additional basis generation, tuning, simulation, or propagation was performed by this verifier.

1. Exact full-operator separating-functional verification gives

   integral from 0 to 0.0001 of ||q'(t) - G q(t)||_1 dt >= 0.06901324601471871.

   Initial and join defects are exactly zero. The result includes the overflow scalar. It exceeds both the proportional-time planning share 1e-13 and the entire 1e-9 interior budget. A planning share is an allocation, not a necessary accuracy threshold. This lower bound prevents the usual full-forward-residual certificate from fitting the entire budget for this trajectory, even if all later slabs were exact. It does not itself lower-bound success-probability error.

2. A separate exact localization argument proves a genuine error of the represented state:

   ||q(0.0001) - p(0.0001)||_1 >= 0.1380019503471046.

   The candidate assigns 0.06900102765226694 mass to the complement of [38,62]^8 plus overflow; the true process assigns at most 5.247871456897941e-8 there. The displayed strengthened result uses the balanced indicator witness and an outward mass-defect bound of 1.4718662285217174e-16. The simpler unbalanced witness independently gives 0.06900097517355237. These results concern the augmented state, not the success coordinate alone.

3. Independently reconstructing the existing cap proof gives an additional physical contradiction: true overflow by this slab endpoint is at most 7.569068430849771e-14, whereas the exported overflow is 0.004565377350727602. Thus the overflow coordinate alone proves augmented-state error at least 0.004565377350651912. The original horizon-1 cap allowance remains 7.569068427447863e-10, separate from the interior error budget. It is not subtracted from or counted twice in the residual test.

4. The generic all-50 coordinate test is inconclusive: its rigorous integrated residual lower bound is 2.06043577766598e-15. A small residual at the most obvious coordinate therefore misses this failure. The separating functional exposes global spatial pollution caused by the constant enrichment direction.

All displayed decimals above are descriptive. Exact authoritative fractions are in the JSON results. The tests use the complete eight-site generator, all ten edges, counts 0 through 162, initial all 50, target all counts at most 15, and true outward overflow. There was no simulation, fitting, model replacement, source MATLAB execution, package installation, or candidate modification.

## Candidate and implementation boundaries

Candidate: ../experiments/candidate.npz and candidate.json.

SHA256: 6d4ec68772eb0cb748605d09ed5096f37a5d1a168c0bc90edcb0097ff790f526.

The candidate is an independently written conservation-enriched TT Arnoldi/Galerkin construction with a degree-32 Chebyshev time solve, 13 grid basis vectors, and an overflow coordinate. It is not an execution or port of the acquired tAMEn implementation. Spatial ranks were adaptive only up to the candidate's rank-16 cap. Consequently this result does not exhaust the acquired conservation-enriched AMEn method or rank growth beyond 16.

The grid retains every target state as frozen. Success is the sum on that target; adding a second success scalar would double count it. Overflow is a separate scalar. With H the ordinary killed-at-cap grid operator and P_B the all-low projector, the grid generator is G_grid = H(I-P_B). The overflow row is the physical outward-rate functional. The augmented operator is conservative, while its grid restriction is substochastic.

Saved binary64 arrays define exact dyadic coefficients of the candidate. The anchored time convention is

  y_j(t) = initial_j + sum over k>=1 of c_jk [T_k(2t/h-1) - (-1)^k].

The independent verifier forms the constant shifts with exact rationals. It verifies every initial coefficient, every entry of the exact delta basis, and zero initial overflow; hence the full initial l1 defect is exactly zero. There is no prior slab and no join. For an arbitrary later export, verify_slab.py requires the previous slab and explicitly charges selected-coordinate and overflow initial/join mismatches. An uncharged join cannot be silently accepted.

## Generic bounded polynomial rejection gate

verify_slab.py consumes the exported TT basis vectors and time-coefficient matrix without importing candidate or old residual code. It independently constructs every full generator predecessor of each selected physical coordinate. At all 50 there are 37, including the diagonal. All reaction, diffusion, target-column removal, and outward-cap losses are included; the operator is not projected onto the solver's span.

The exact initial derivative is independently enumerated. Its support has 37 states, with diagonal -114319.516. Actual cap and absorbing-target checks retain all eight sites and all physical count levels. test_verifier.py passes 1,026 checks, including directed point, full-mass, and signed-product contractions against exact Fraction calculations, plus the exact initial parity-generator identity.

Spatial contractions use Decimal.from_float for exact binary64 input conversion and separate ROUND_FLOOR/ROUND_CEILING contexts for each multiply and addition. There is no floating BLAS contraction. Interval endpoints are then exact rational numbers. Physical parameters are exact decimal rationals. Chebyshev-to-power conversion, derivatives, antiderivatives, endpoint evaluations, generator combinations, and all decisive comparisons use exact rational interval arithmetic. Errors from generating the approximation are already represented by the difference between its exact saved polynomial and the exact generator; they are not assumed small because the solver reported a tolerance.

For a selected coordinate's residual polynomial r(u), u in [0,1], and a dyadic partition I_j,

  h sum_j |integral over I_j of r(u) du| <= integral_0^h |r(t/h)| dt.

The implemented bound takes the minimum absolute value of each rigorously enclosed signed bin integral. This keeps temporal cancellation within each bin and needs no approximate root finding. It is a lower bound, so it can reject an error allocation but can never certify a pass. Summing distinct coordinates remains a lower bound on the full l1 residual. The independent integrated-square diagnostic retains every signed i,j cross term of the polynomial Gram sum. For example, the tests recover integral(1-2u)^2 = 1/3, not the incorrect 7/3 obtained by dropping the cross term.

The all-50 run took 1.89 seconds and 46,988 KiB peak RSS, under 512 MiB address-space and 120 CPU-second caps. The export was present before this run, and its approximately 19.1 MB uncompressed size was checked before contracting. Generic runs refuse exports consuming more than 60% of the stated address-space budget. SHA256 computation is streamed. No full residual Gram or expensive eight-dimensional enumeration was needed.

## Exact tail separating functional

verify_uniform_tail.py checks the actual arrays, not a claim in the solver log:

- Basis 0 is exactly constant at all physical coordinates. Its exact per-state value is the rational product of its eight saved binary64 core constants, called gamma.
- Every nonconstant basis core is exactly zero outside physical counts 39 through 61. Thus those grid tensors are supported in [39,61]^8.
- A full original reaction or hop changes a coordinate by at most one. Their full operator images are supported in C=[38,62]^8. Target-column corrections vanish for those tensors because their supports are disjoint from B.

Let A be the complement of C in the full retained grid. Only the exported constant component contributes to q or its full residual when summed on A. Write its per-state coefficient as p_u(t)=gamma*y_0(t), and let w=25. Then

  |A| = 163^8 - w^8.

The sum of physical overflow rates over all grid states is exactly

  F = 8*b(162)*163^7 + 20*D*(sum from n=0 to 162 of n)*163^6.

The sum over C of the ordinary operator applied to a constant grid field is

  J = 8*[b(37)-b(62)+d(63)-d(38)]*25^7 + 20*D*25^8.

The reaction row sums telescope. Each of the ten interior edges contributes 2D per row for a uniform field. Every target-column H P_B has total mass zero and no row in this distant cube. Consequently the full frozen-target generator satisfies

  sum over A of (G_grid 1) = -F - J.

Therefore the exact aggregate grid residual and scalar overflow residual are

  r_A(t) = |A|*p_u'(t) + (F+J)*p_u(t),
  r_overflow(t) = q_overflow'(t) - F*p_u(t).

This includes the complete original operator action, target freezing, true overflow, and all signed polynomial terms. Since the two functionals act on disjoint coordinates,

  integral ||r||_1 >= integral |r_A| + integral |r_overflow|.

The dyadic-bin lower bounds are respectively 0.06901324601471871 and 2.759077876914825e-18. The exact run took 0.90 seconds with 62,340 KiB peak RSS under the same 512 MiB / 120 CPU-second limits. It is a lower-bound certificate, not a floating triangle upper estimate.

Exact endpoint values also give:

- Tail grid mass on A: 0.06443565030153935
- Overflow: 0.004565377350727602
- Success sum on B: 5.553737834073413e-10

These endpoint values are not claimed accurate probabilities. In particular the success value cannot be promoted to a certificate because mass conservation or a projected ODE solve was accurate.

## Genuine augmented-state error: local first-exit bound

check_localization.py proves a bound directly for the real process, without a simulation or a reduced model. Stop at the first exit from C=[38,62]^8. Before this exit, each site's upward counting intensity is bounded by

  lambda_plus = b(62) + 3*D*62 = 58788921/5000,

and its downward intensity is bounded by

  lambda_minus = d(62) + 3*D*62 = 64772361/5000.

Birth and death monotonicity on this count range are checked exactly. Degree at most three is verified from all ten actual graph edges. Any exit from the starting count 50 requires at least 13 upward or at least 13 downward jumps at one coordinate. Bounded-intensity stopped counting processes admit Poisson domination; independence between coordinates or signs is not assumed.

For mu=lambda*h<14,

  P(Poisson(mu)>=13) <= mu^13 / [13!*(1-mu/14)].

This follows by dropping exp(-mu)<=1 and bounding the successive tail ratios by mu/14. A union bound over eight coordinates and two directions gives the exact probability upper bound 5.247871456897941e-8. Target or overflow absorption cannot occur before exit from C. Hence true mass outside C plus overflow is no larger than this first-exit probability.

For the indicator functional f of outside C plus overflow, ||f||_infinity=1. Thus

  ||q(h)-p(h)||_1 >= f(q(h))-f(p(h))
                   >= 0.06900102765226694 - 5.247871456897941e-8
                   = 0.06900097517355237 (descriptive decimal).

This proof does not assume that the candidate is positive or exactly mass-normalized. The additional balanced witness phi=2*f-1 has infinity norm one and yields

  ||q-p||_1 >= 2*[f(q)-exit_upper] - |sum(q)-1|.

verify_product_tail.py rigorously contracts every physical basis's full mass with directed Decimal arithmetic and combines exact saved endpoint coefficients. For the original candidate, the mass-defect upper bound is 1.4718662285217174e-16, giving the strengthened state-error lower bound 0.1380019503471046. This is an ordinary dual norm witness, valid for signed q. No comparable success-coordinate error lower bound follows. Results are in original_balanced_rejection.json.

## Independent reconstruction of the global cap result

The source text and exact audit were acquired read-only at repository commit f80a8f15137575133ad2c9af975513b32e8fa93e under the fz_kinetic_path_genesis and fz_kinetic_cap_certificate_audit records. check_physical_overflow.py does not import or execute their programs. It reconstructs the argument and matches the acquired exact rational constants and directed edge list.

For r=161/100, use V(n)=sum_i r^n_i. A symmetric edge with counts a,b obeys the diffusion upper bound

  Q_edge V <= D*(r+r^-1-2)*(a*r^a+b*r^b),

because (a-b)*(r^a-r^b)>=0. With graph degree at most three,

  Q V <= sum_i r^n_i F_r(n_i),
  F_r(m)=b(m)*(r-1)+d(m)*(r^-1-1)+3*D*m*(r+r^-1-2).

Every coefficient of F_r(111+k) is strictly negative, proved with exact fractions, so F_r is negative for every real k>=0. Exact enumeration of m=0,...,110 gives the maximum K of r^m F_r(m) at m=103. The localized finite-chain Dynkin argument then gives

  P(first count-163 crossing by T) <= [8*r^50+8*K*T]/r^163.

The same coercive exit bounds imply nonexplosion, without assuming the unbounded-process Dynkin identity in advance. Target absorption only reduces the competing overflow event. The exact horizon-1 rational agrees with the source, and evaluating the same expression at h gives the sharper 7.569068430849771e-14 bound used here. This is separate from approximation-error accounting.

## Product-weight Cauchy: what can and cannot be repaired

For a full residual, let a(n)=integral R(t,n)^2 dt. With positive normalized site weights mu_i and product mu,

  integral ||R(t)||_1 dt <= sqrt(h * sum_n a(n)/product_i mu_i(n_i)).

Normalization is mathematical, not a floating convention. Every Gram entry must include signed temporal cross terms, full unprojected operator actions, sink terms under the chosen augmented norm, and outward enclosures. A projected residual or uncharged compressed residual is not interchangeable with R.

Optimization is a valid secondary diagnostic for a new candidate. Setting x_i(n)=log(mu_i(n)), log of the squared objective is log-sum-exp of affine functions, and the constraints sum_n exp(x_i(n))<=1 are convex. Nonzero objectives saturate the normalization constraints. For fixed other sites, define a_i(n) by contracting a divided by their weights. The coordinate optimum is mu_i(n) proportional to sqrt(a_i(n)). With positive lower floors, the KKT formula is mu_i(n)=max(floor_i(n),sqrt(a_i(n)/lambda)), with lambda chosen to normalize. Zero coefficients and strict positivity require care; without floors an infimum can lie on a zero-weight boundary. Optimization residuals and contraction errors must themselves be enclosed before claiming an upper certificate.

But optimized product weights cannot eliminate all spatial correlation loss. On the actual eight-dimensional grid, consider an arbitrary residual equal to 1/m on m diagonal states (j,j,...,j) and zero elsewhere. Its l1 norm is one. The best normalized product weighted l2 norm is m^(7/2). A Holder inequality gives this minimum, achieved by uniform marginals on the m active values. At m=163 the ratio is approximately 55,291,276. This is a norm counterexample on the real state space, not a substitute dynamics or a claim that the true residual has that shape. A scalar multiple can have arbitrarily small l1 norm while retaining the same relative overestimate.

The old arbitrary Gaussian-plus-floor weight gives mu_i(50) approximately 0.09964197, so even a singleton residual at all 50 incurs a norm ratio approximately 10,144.5. That choice can be loose. Conversely, a zero residual has zero bound under every positive weight, and a suitable product residual can have a sharp product-weight bound. There is no universal structural explosion for every good approximation. The actual new export is already excluded by weight-independent exact tests, so weight optimization cannot rescue it and was not run.

## Computable rigorous alternatives without unknown state promises

There are ordinary norm alternatives; none is claimed novel.

1. The separating-functional lower bound implemented here avoids product denominators entirely. Any explicitly known f with ||f||_infinity<=1 gives integral ||R||_1 >= integral |f(R)|. Indicator coordinates, boxes, their complements, and sink coordinates can be useful. This is a rejection tool, not an upper certificate.

2. unweighted_bounds.py implements a rigorous upper bound for any saved TT T:

   ||T||_1 <= [sum_n |G_1(n)|] ... [sum_n |G_8(n)|].

   Each matrix product is a nonnegative contraction with upward-rounded Decimal arithmetic. It needs no positivity of T, no unknown support, and no weight denominator. For a complete residual polynomial represented in Bernstein form R(u)=sum_k B_k,K(u)*V_k,

   integral ||R||_1 <= h/(K+1) * sum_k ||V_k||_1.

   The implementation requires an explicit extra bound for every error used to construct the supplied full residual coefficients. A caller cannot pass zero merely because a solver or compression tolerance was small. Exact signed polynomial combinations should be formed before this safe triangle bound. The helper was checked on an eight-site signed rank-one tensor; it was not used to make a candidate upper certificate.

3. Spatial partition refinement or fully enumerated absolute norms also gives rigorous bounds. Optimizing unrestricted joint weights instead of products removes the product-correlation penalty, but requires the generally expensive quantity sum_n sqrt(a(n)). These methods offer no generic polynomial-cost guarantee for signed TTs. Absolute-core contraction can itself be very loose when internal TT paths cancel. Thus a universally sharp and affordable full-state l1 upper bound has not been acquired merely by writing the norm identity.

## Localized weighted-Galerkin geometry and its tested repair

A product measure mu_i(n)=2^(-|n-50|)/Z, with exact Z=3-2^-50-2^-112, offers a different candidate-generation geometry. Under q=sqrt(D_mu)*y, the transformed grid operator is D_mu^-1/2 * G_grid * D_mu^1/2. The mass representer is sqrt(mu), which maps back to the localized distribution mu, rather than the global constant field. The initial whitened delta has norm Z^4, approximately 81. Reaction scaling ratios are at most sqrt(2), hopping ratios at most 2, and the target projector commutes with this positive diagonal transform. The one-site cap weight is 2^-112/Z.

For the augmented state, an important normalization factor cannot be omitted. With weights (mu,1), the mass representer (sqrt(mu),1) has norm sqrt(2), and the full physical l1 residual is bounded by sqrt(2) times augmented whitened l2. One may instead use the sum of the grid weighted norm and absolute overflow residual, or use normalized augmented weights (mu/2,1/2). The latter has norm-one mass representer and initial whitened norm approximately 81*sqrt(2); its transformed operator is unchanged by the common scalar rescaling. In the frozen-grid embedding there is no second success scalar.

The transformed overflow row is the original exact outward-rate functional times the grid square-root weights, divided by the sink square-root weight. It must be retained. Artificially suppressing cap exits would change the model. Square-root evaluation, basis construction, reduced solves, and conversion back to physical TT coefficients need enclosure or must be bypassed by verifying the exact saved physical polynomial afterward.

This weighting can remove the specific uniform-tail enrichment artifact. It does not prove sufficient ranks, a well-conditioned reduced time solve, late-time weight suitability, positivity, or a small full residual. A narrow weight centered at 50 can become badly mismatched at later times or near the target.

A documented follow-up tested geometric weighting with per-vector rank cap 32, degree 32, and 13 basis vectors. The original export was unchanged. Its physical export is ../experiments/weighted_repair/candidate.npz, SHA256 185fba86aa640ce702bd7b7d3c96915e8bf463ae4e5989fe2f7736370d285297. This verifier did not propagate or tune that candidate; it independently checked the resulting exact dyadic physical polynomial.

verify_product_tail.py generalizes the exact tail test to an arbitrary rank-one product enrichment g(n)=product_i w_i(n_i), with the actual saved w_i values. It verifies literal zeros outside [39,61] for every other basis. Let t_i=sum_n w_i(n) and c_i=sum_{n=38}^{62} w_i(n). The enrichment's tail functional is product_i t_i - product_i c_i. Its exact physical overflow functional is the sum of birth-cap terms and all twenty oriented diffusion-cap terms. The interior generator functional is computed by exact one-dimensional reaction row sums and exact two-factor oriented-hop sums, multiplied by the remaining c_i. The target-column correction again has zero aggregate outside the distant cube. Thus no uniform-cardinality shortcut is reused incorrectly.

The specialized uniform formula and generalized product formula produce identical exact residual fractions on the original export, an additional independent algebra check. On the weighted repair the generalized verifier obtains:

- Integrated tail residual lower bound: 7.17097266849711e-5
- Integrated overflow residual lower bound: 3.8522930475215e-49
- Candidate tail endpoint mass: 7.553174937018623e-5
- True outside-cube-or-overflow upper bound: 5.247871456897941e-8
- Simple actual-state l1 error lower bound: 7.547927065561725e-5
- Outward augmented mass-defect upper bound: 6.883077546281024e-16
- Balanced-witness actual-state l1 error lower bound: 1.509585413105462e-4

Initial and join errors are again verified exactly zero. The weighted verification, including full mass contractions, took 3.10 seconds and 146,448 KiB peak RSS under 512 MiB and 120 CPU-second limits. Results are in weighted_rejection.json. This is not a claim that a better weight or all conservation methods must fail. The surviving specific obstruction is representational: if q=a*g+v with v supported inside the local cube, then outside that cube q equals a*g exactly. A physically impossible amount of mass can therefore be introduced by the conservation direction while the projected solve and total mass look accurate.

## Constrained-Galerkin alternative and its reduced-only test

An equality constraint can preserve mass without appending a broad state direction. For only the localized physical basis B, let M=B^T W B, K=B^T W G_grid B, m=B^T 1, and f^T be the exact outward-flux row on that basis. If M is positive definite and m is nonzero, the weighted least-squares derivative subject to m^T a'=-f^T a has

  C = M^-1 K - M^-1 m * (m^T M^-1 K + f^T)/(m^T M^-1 m),
  a'=C a, overflow'=f^T a.

Indeed multiplying by m^T gives m^T C=-f^T. This is ordinary equality-constrained least squares, not a new operation. The state derivative remains in the original local trial space and creates no broad enrichment tail. For the currently exported localized basis, every cap flux is exactly zero, so f=0. Its approximation would retain zero overflow on this slab, but its omitted physical boundary leakage must still be charged by the full residual. Positivity, rank adequacy, and numerical conditioning remain unresolved.

A reduced-only diagnostic can reuse the saved forms after removing the enrichment row and column, provided coordinates are handled consistently. The weighted exporter replaced physical basis 1 by an exact delta and scaled coefficients by S with S_11 equal to the whitened-to-physical delta scale. Its saved M and K remain in the earlier coordinates. In exported coordinates the forms are S^-T M S^-1 and S^-T K S^-1, before taking the localized submatrices. Merely slicing the already inverted projected generator C is not equivalent. Floating physical conversion also means reused forms are diagnostics rather than exact bilinear forms of the saved dyadic physical bases. A rigorous result still requires a fresh full physical residual enclosure.

A third, documented structural follow-up reused the 12 localized physical basis vectors unchanged, removed the broad product direction, retained the same h, degree, rank limits and weights, and enforced the physical overflow row (exactly zero on these supported basis columns). No new Arnoldi vectors were produced. The immutable export is ../experiments/constrained_test/candidate.npz, SHA256 666c95606ed5965fcbf312eac4ac3bd8f6761b1e0ea62df4fe798d8634249381. Its exact delta is now basis 0 rather than basis 1.

The independent generic full-predecessor check needs no special tail hypothesis for this export. At the single coordinate (50,...,50), it encloses the complete degree-32 derivative-minus-generator polynomial and proves

  integral |R(t,(50,...,50))| dt >= 1.4918533657070469e-5.

The full initial defect is verified exactly zero from the saved initial coefficients and delta cores; the anchored overflow is exactly zero initially. There is no slab join. The computation took approximately 4.7 seconds under the 512 MiB / 120 CPU-second caps. The exact rational lower endpoint and final measured runtime are in constrained_coordinate.json. The bound exceeds the full 1e-9 interior budget, so the candidate cannot pass this full-forward-residual certification gate. It removes the off-support enrichment defect but leaves a material dynamical defect. This result is not an actual success-coordinate error lower bound.

The code also contains a prepared full-generator parity witness, verify_parity.py. On the literally verified localized support, each reaction flips parity and every diffusion hop preserves it, so G^T phi=-2*sum_i(b+d)*phi for phi=(-1)^(sum_i n_i). Its bounded weighted contractions and exact initial identity are self-tested. No parity contraction was run on the third candidate because the cheaper coordinate certificate already decisively rejected it. The duplicate multi-minute full-residual QR was not run after this decisive rejection.

## Reproduction

All files are under kinetic_residual_challenge; acquired sources and candidate files remain read-only.

Run test_verifier.py for the bounded independent self-tests. Run verify_slab.py with the candidate manifest, an output path, --budget 1e-13, --memory-mib 512, and --cpu-seconds 120 for the generic all-50 test. Run verify_uniform_tail.py with that same manifest and an output path for the exact tail certificate. Run check_localization.py with the manifest, --tail-result pointing to that tail JSON, and an output path. Run check_physical_overflow.py with the manifest, --source-audit pointing to kinetic_cap_source/fz_kinetic_cap_certificate_audit_EXACT_AUDIT.json, and an output path.

Run verify_product_tail.py on either candidate manifest with --total-mass and an output path for the generalized tail and balanced-witness checks.

Key outputs: self_tests.json, candidate_rejection.json, tail_rejection.json, localization_rejection.json, physical_rejection.json, original_balanced_rejection.json, weighted_rejection.json, constrained_coordinate.json. The scripts and their JSON exact fractions, rather than rounded prose numbers, are the replay artifacts.
