# Independent audit and a quantitative stability extension

## Finding

The all-positive-parameter separated-first-potential Jensen theorem at commit `61389569d6c53b439764f0d148b35b7fa6083eec` passes an independent exact algebra check and analytic review. Its particular stress-conservation shortcut cannot enlarge the fixed-field all-background class: conservation at three distinct backgrounds already forces separation. Nevertheless, its strict reserve implies a small, rigorously quantified **nonseparated all-background neighborhood**, for each fixed parameter, without requiring stress conservation. This is a stability consequence, not unrestricted quasiconvexity or a priority claim.

All averages and norms below use normalized measure on the square torus. Functions are real, periodic, and in W^{1,4}.

## 1. Source and reconstruction

[Proof at the exact commit](https://github.com/harjassand/astra-research-knowledge/blob/61389569d6c53b439764f0d148b35b7fa6083eec/updates/GA-conformal-causal-genesis-20261016/package/derived/workers/ga_parametric_stress_genesis/ALL_R_THEOREM_PROOF.txt).

[Exact matrix data at the exact commit](https://github.com/harjassand/astra-research-knowledge/blob/61389569d6c53b439764f0d148b35b7fa6083eec/updates/GA-conformal-causal-genesis-20261016/package/derived/workers/ga_parametric_stress_genesis/ALL_R_STRESS_EXACT_CERTIFICATE.json), Git blob `164aa93f1124930cd8d501ac66e7fde5c03d6f46`.

For V=[[a,b],[c,d]], set u=a²+c², v=b²+d², j=ad−bc. The original integrand is

J_r(V)=3r(u+v−2j)²/[8(r+2)]+r(r−1)u²/6+j²+ruj.

For r>0 and s real, set

S_1(b)=−(r+2)s²b+7rb³/[6(r+2)],

S_2(a)=(r+2)s³+(5r/2+2)s²a+7rsa²/4+r(4r+3)a³/[12(r+2)].

The residual G is J_r(sI+V) minus (r+2)(r+3)s⁴/6, minus (r+2)(2r+3)s³a/3, minus S_1c+S_2d. The accompanying independent checker reconstructs these expressions directly. It checks the certificate identity (r+2)G=z0ᵀQ0z0+r z1ᵀQ1z1, exact rational LDL reconstruction and positive pivots for Q0, Q1 and Q1−I/512. No producer program is executed. The JSON is data; its matrix entries are parsed as rational numbers.

Consequently

G ≥ α|V|⁴+β0s²(a²+c²+d²),

α=5r/[4096(r+2)], β0=r/[512(r+2)].

If div(S_1(f_y),S_2(f_x))=0 distributionally, its pairing with Dg vanishes. This is valid for W^{1,4}: the stress is L^{4/3}, and smooth g approximate strongly in W^{1,4}. Also <f_x>=0. Thus E_r(f,g,s):=<J_r(sI+D(f,g))>−J_r(sI) has the same lower bound after integration. Separation f=F(x)+H(y) ensures conservation for every s, while g is unrestricted.

## 2. Exact limitation of conservation at multiple backgrounds

Fix r and f. The divergence is the distribution-valued quadratic polynomial

(3r/2)s² f_xy +(7r/4)s ∂y(f_x²)
+7r/[6(r+2)] ∂x(f_y³)+r(4r+3)/[12(r+2)] ∂y(f_x³).

If it vanishes for three distinct s, Vandermonde inversion forces f_xy=0. This statement does not multiply a rough mixed derivative by a nonlinear coefficient. On the torus, f_xy=0 implies that all Fourier coefficients with both frequencies nonzero vanish, so f=F(x)+H(y) almost everywhere. The profiles belong to W^{1,4}, also directly obtained by coordinate averaging. Conversely separated f satisfies conservation for every s.

Therefore a fixed nonseparated f can satisfy this particular conservation law at at most two backgrounds. This is not a no-go theorem for Jensen inequalities by other methods.

## 3. A genuine but local all-background extension

Fix r>0 and a separated f0 with

R=||Df0||4, A=||f0_x||2>0.

There exists an explicit positive ε0 such that every f with ||D(f−f0)||4≤ε0 satisfies Jensen for every s and every g. The neighborhood includes nonseparated first potentials.

Here are conservative constants. Set M=max(1,R+1) and

L_B=2(r+1)(r+2),
L_P=2(r+2)(4r+9)/3,
L_Q=4(r³+7r²+34r+12)/[3(r+2)],

C=(3/2)L_B M+(3/2)L_P M²+4L_Q M³,

m=min(αR⁴,α,β0A²,β0),
ε0=min(1,m/(2C)).

Then, for every such f, g, and s,

E_r(f,g,s) ≥ (1/2) E_r(f0,g,s) ≥ 0.

### Proof

Compatibility gives <ad−bc>=0. After integration, the exact conformal expansion is

E_r(f,g,s)=s²<B>+s<P>+<Q>,

B=((r+1)a+d)²+r(r+2)c²/3,

P=r[d+(2r+1)a/3](a²+c²)+2(ad−bc)((r+1)a+d),

Q=J_r([[a,b],[c,d]]).

In particular the entire quadratic acoustic term is retained, rather than estimated through a tiny uniform Gram floor.

The stated L_B,L_P,L_Q are the sums of absolute monomial coefficients in ∂a and ∂b of B,P,Q respectively. All coefficient signs used in those sums are fixed for r>0, as can be checked directly by expansion. Let ε=||D(f−f0)||4≤1, t=||Dg||4, v=||Dg||2. Along the line segment between Df0 and Df, its L4 norm is at most R+1≤M. The fundamental theorem of calculus and Hölder give

|<ΔB>| ≤ ε L_B M(1+v),
|<ΔP>| ≤ ε L_P M²(1+t+t²),
|<ΔQ>| ≤ ε L_Q M³(1+t+t²+t³).

These bounds use cancellation of the terms independent of the first row: ΔP contains at most two second-row factors; ΔQ at most three. Since

1+v ≤ (3/2)(1+v²),
|s|(1+t+t²) ≤ (3/2)(1+t⁴+s²),
1+t+t²+t³ ≤ 4(1+t⁴),

we obtain

|E_r(f,g,s)−E_r(f0,g,s)| ≤ Cε W,
W=1+t⁴+s²(1+v²).

The separated theorem gives

E_r(f0,g,s)≥α(R⁴+t⁴)+β0s²(A²+v²)≥mW.

Thus Cε≤m/2 proves the claim. This argument is uniform over s and g; its constants depend on r and f0. It does not produce one uniform radius for all r>0.

## 4. Fully explicit example

Take r=1 and f0=sin x+sin y. Then R⁴=5/4, A²=1/2, R<2, α=5/12288, β0=1/1536, m=1/3072. The coefficient sums are L_B=12,L_P=26,L_Q=24. Because M<3,

C<54+351+2592=2997<3000.

Therefore ε0=1/20,000,000 is admissible: 3000/20,000,000<1/6144=m/2. Every f within this gradient-L4 radius works for all s and all g. For example

f=sin x+sin y+(1/100,000,000)sin(x+y)

is nonseparated and lies in this radius, since its gradient perturbation norm is (3/2)^(1/4)/100,000,000<1/20,000,000.

The radius is deliberately tiny and nonoptimal. This establishes a concrete neighborhood, not a useful global sharp constant.

## 5. What remains unresolved

For a general first potential the exact stress pairing remains signed. A Hodge projection merely isolates its gradient component; it does not supply the missing comparison with the full positive residual. Exact minimization over the second potential, without an additional proved estimate, restates a restricted version of the original problem. Expanding the full energy and demanding nonnegativity for every background likewise returns the cubic discriminant condition. The stability result above resolves a local robustness question, not that global obstruction.

No negative compatible Jensen field was found or asserted. The original certificate, the new stability deduction, external review, historical originality and unrestricted positive-core quasiconvexity are separate matters.
